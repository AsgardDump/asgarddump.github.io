#pragma once

// Borderlands 3 SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "BL3_A_PsychoMale_Taunt_02_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function A_PsychoMale_Taunt_02.A_PsychoMale_Taunt_02_C.GbxAsyncRequest_Hit_2240004D48A27591019A10BDDF41A7FB
struct UA_PsychoMale_Taunt_02_C_GbxAsyncRequest_Hit_2240004D48A27591019A10BDDF41A7FB_Params
{
	struct FHitResult                                  Result;                                                   // (ConstParm, BlueprintVisible, BlueprintReadOnly, Parm, OutParm, ReferenceParm, IsPlainOldData)
};

// Function A_PsychoMale_Taunt_02.A_PsychoMale_Taunt_02_C.OnBegin
struct UA_PsychoMale_Taunt_02_C_OnBegin_Params
{
	class AActor**                                     Actor;                                                    // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

// Function A_PsychoMale_Taunt_02.A_PsychoMale_Taunt_02_C.MeleeStrike
struct UA_PsychoMale_Taunt_02_C_MeleeStrike_Params
{
};

// Function A_PsychoMale_Taunt_02.A_PsychoMale_Taunt_02_C.ExecuteUbergraph_A_PsychoMale_Taunt_02
struct UA_PsychoMale_Taunt_02_C_ExecuteUbergraph_A_PsychoMale_Taunt_02_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
