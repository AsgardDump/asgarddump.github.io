#pragma once

// Borderlands 3 SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "BL3_Ability_ArtifactStat_Vladof_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Ability_ArtifactStat_Vladof.Ability_ArtifactStat_Vladof_C.OnActivated
struct UAbility_ArtifactStat_Vladof_C_OnActivated_Params
{
};

// Function Ability_ArtifactStat_Vladof.Ability_ArtifactStat_Vladof_C.ExecuteUbergraph_Ability_ArtifactStat_Vladof
struct UAbility_ArtifactStat_Vladof_C_ExecuteUbergraph_Ability_ArtifactStat_Vladof_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
