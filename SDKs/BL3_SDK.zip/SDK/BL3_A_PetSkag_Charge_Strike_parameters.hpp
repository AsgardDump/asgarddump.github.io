#pragma once

// Borderlands 3 SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "BL3_A_PetSkag_Charge_Strike_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function A_PetSkag_Charge_Strike.A_PetSkag_Charge_Strike_C.Notify_Melee
struct UA_PetSkag_Charge_Strike_C_Notify_Melee_Params
{
};

// Function A_PetSkag_Charge_Strike.A_PetSkag_Charge_Strike_C.ExecuteUbergraph_A_PetSkag_Charge_Strike
struct UA_PetSkag_Charge_Strike_C_ExecuteUbergraph_A_PetSkag_Charge_Strike_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
