#pragma once

// Borderlands 3 SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "BL3_Ability_Beast_RakkCharge_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Ability_Beast_RakkCharge.Ability_Beast_RakkCharge_C.OnActivated
struct UAbility_Beast_RakkCharge_C_OnActivated_Params
{
};

// Function Ability_Beast_RakkCharge.Ability_Beast_RakkCharge_C.OnDeactivated
struct UAbility_Beast_RakkCharge_C_OnDeactivated_Params
{
};

// Function Ability_Beast_RakkCharge.Ability_Beast_RakkCharge_C.ExecuteUbergraph_Ability_Beast_RakkCharge
struct UAbility_Beast_RakkCharge_C_ExecuteUbergraph_Ability_Beast_RakkCharge_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
