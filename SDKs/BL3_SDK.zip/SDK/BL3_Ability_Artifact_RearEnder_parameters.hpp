#pragma once

// Borderlands 3 SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "BL3_Ability_Artifact_RearEnder_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Ability_Artifact_RearEnder.Ability_Artifact_RearEnder_C.OnActivated
struct UAbility_Artifact_RearEnder_C_OnActivated_Params
{
};

// Function Ability_Artifact_RearEnder.Ability_Artifact_RearEnder_C.OnDeactivated
struct UAbility_Artifact_RearEnder_C_OnDeactivated_Params
{
};

// Function Ability_Artifact_RearEnder.Ability_Artifact_RearEnder_C.ExecuteUbergraph_Ability_Artifact_RearEnder
struct UAbility_Artifact_RearEnder_C_ExecuteUbergraph_Ability_Artifact_RearEnder_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
