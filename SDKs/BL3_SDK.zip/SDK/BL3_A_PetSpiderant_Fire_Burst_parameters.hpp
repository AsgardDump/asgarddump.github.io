#pragma once

// Borderlands 3 SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "BL3_A_PetSpiderant_Fire_Burst_classes.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function A_PetSpiderant_Fire_Burst.A_PetSpiderant_Fire_Burst_C.Notify_SkillUse
struct UA_PetSpiderant_Fire_Burst_C_Notify_SkillUse_Params
{
};

// Function A_PetSpiderant_Fire_Burst.A_PetSpiderant_Fire_Burst_C.ExecuteUbergraph_A_PetSpiderant_Fire_Burst
struct UA_PetSpiderant_Fire_Burst_C_ExecuteUbergraph_A_PetSpiderant_Fire_Burst_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
