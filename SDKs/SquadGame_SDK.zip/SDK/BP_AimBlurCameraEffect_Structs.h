#pragma once 
#include "SDK.h" 
 
 
// Function BP_AimBlurCameraEffect.BP_AimBlurCameraEffect_C.ExecuteUbergraph_BP_AimBlurCameraEffect
// Size: 0x5F9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AimBlurCameraEffect
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FWeightedBlendable K2Node_MakeStruct_WeightedBlendable;  // 0x8(0x10)
	struct ASQPlayerController* K2Node_Event_InPlayerController;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x28(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables;  // 0x38(0x10)
	float K2Node_Event_DeltaTime;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct ASQSoldier* K2Node_Event_SoldierToApplyTo;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings;  // 0x60(0x560)
	char pad_1472_1 : 7;  // 0x5C0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x5C0(0x1)
	char pad_1473_1 : 7;  // 0x5C1(0x1)
	bool CallFunc_IsInVehicle_ReturnValue : 1;  // 0x5C1(0x1)
	char pad_1474[6];  // 0x5C2(0x6)
	struct ASQEquipableItem* CallFunc_GetCurrentWeapon_ReturnValue;  // 0x5C8(0x8)
	char pad_1488_1 : 7;  // 0x5D0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5D0(0x1)
	char pad_1489[7];  // 0x5D1(0x7)
	struct ASQWeapon* K2Node_DynamicCast_AsSQWeapon;  // 0x5D8(0x8)
	char pad_1504_1 : 7;  // 0x5E0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x5E0(0x1)
	char pad_1505[3];  // 0x5E1(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x5E4(0x4)
	char pad_1512_1 : 7;  // 0x5E8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x5E8(0x1)
	char pad_1513_1 : 7;  // 0x5E9(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x5E9(0x1)
	char pad_1514[2];  // 0x5EA(0x2)
	float CallFunc_GetFloatValue_ReturnValue;  // 0x5EC(0x4)
	char pad_1520_1 : 7;  // 0x5F0(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x5F0(0x1)
	char pad_1521[3];  // 0x5F1(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x5F4(0x4)
	char pad_1528_1 : 7;  // 0x5F8(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x5F8(0x1)

}; 
// Function BP_AimBlurCameraEffect.BP_AimBlurCameraEffect_C.BP_InitCameraEffect
// Size: 0x8(Inherited: 0x8) 
struct FBP_InitCameraEffect : public FBP_InitCameraEffect
{
	struct ASQPlayerController* InPlayerController;  // 0x0(0x8)

}; 
// Function BP_AimBlurCameraEffect.BP_AimBlurCameraEffect_C.BP_ApplyCameraEffect
// Size: 0x10(Inherited: 0x10) 
struct FBP_ApplyCameraEffect : public FBP_ApplyCameraEffect
{
	float DeltaTime;  // 0x0(0x4)
	struct ASQSoldier* SoldierToApplyTo;  // 0x8(0x8)

}; 
