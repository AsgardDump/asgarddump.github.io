#pragma once 
#include <BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C
// Size: 0xC8(Inherited: 0xC8) 
struct UBP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C : public USQRestriction_FOBInRange
{

	bool IsRestrictedWithFOBsInRange(struct ASQPlayerController* InPlayer, struct TArray<struct ASQForwardBase*>& InFOBsInRange); // Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.IsRestrictedWithFOBsInRange
	bool IsRestrictedForTeam(struct ASQTeam* InTeam); // Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.IsRestrictedForTeam
	bool GetRestrictionReason(struct FDataTableRowHandle& OutRestrictionReason); // Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.GetRestrictionReason
	float GetRange(struct USQLayer* Layer); // Function BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB.BP_GCRestriction_Warfare_FOBInRange_WithinFriendlyFOB_C.GetRange
}; 



