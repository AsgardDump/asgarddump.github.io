#pragma once 
#include <BP_AK74MGP25_Rifle_1P63_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74MGP25_Rifle_1P63.BP_AK74MGP25_Rifle_1P63_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74MGP25_Rifle_1P63_C : public ABP_AK74MGP25_Rifle_C
{

}; 



