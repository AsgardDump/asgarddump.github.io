#pragma once 
#include <BP_BaseFobCreator_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseFobCreator.BP_BaseFobCreator_C
// Size: 0x634(Inherited: 0x598) 
struct ABP_BaseFobCreator_C : public ABP_ForwardBase_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x598(0x8)
	struct USQMapIconComponent* SQMapIcon;  // 0x5A0(0x8)
	struct USphereComponent* NearbyEnemyDetection;  // 0x5A8(0x8)
	struct ASQForwardBase* fob;  // 0x5B0(0x8)
	struct FTimerHandle ServerDecreaseHealthHandle;  // 0x5B8(0x8)
	struct ASQPlayerController* UsingSquadLeader;  // 0x5C0(0x8)
	struct FTimerHandle ServerCheckValidUse;  // 0x5C8(0x8)
	float SLUseHealthLoss;  // 0x5D0(0x4)
	float RespawnDelayPenaltyPerEnemy;  // 0x5D4(0x4)
	int32_t NumEnemiesToDisable;  // 0x5D8(0x4)
	char pad_1500_1 : 7;  // 0x5DC(0x1)
	bool bShouldOverrunOnDestroy : 1;  // 0x5DC(0x1)
	char pad_1501[3];  // 0x5DD(0x3)
	struct FSQUsableData Enemy Usable Data;  // 0x5E0(0x40)
	char pad_1568_1 : 7;  // 0x620(0x1)
	bool bHasBeenOverrun : 1;  // 0x620(0x1)
	char pad_1569[7];  // 0x621(0x7)
	struct UParticleSystemComponent* FobBleedOutEffect;  // 0x628(0x8)
	int32_t EnemiesNear;  // 0x630(0x4)

	struct FSQUsableData GetUsableData(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.GetUsableData
	void Remove Nearby FOB Request Markers(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.Remove Nearby FOB Request Markers
	void UserConstructionScript(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.ReceiveBeginPlay
	void BPOnGhostMade(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPOnGhostMade
	void ReceiveDestroyed(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.ReceiveDestroyed
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.ReceiveEndPlay
	void CompletedConstruction(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.CompletedConstruction
	void BPOnUsed(struct AController* User); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPOnUsed
	void BPStopUsed(struct AController* User); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPStopUsed
	void BPOverrun(bool bFriendly); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPOverrun
	void BPPostTicketTick(float Difference); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPPostTicketTick
	void InvalidatePlacement(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.InvalidatePlacement
	void BPOnIsBleedingChanged(); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPOnIsBleedingChanged
	void ExecuteUbergraph_BP_BaseFobCreator(int32_t EntryPoint); // Function BP_BaseFobCreator.BP_BaseFobCreator_C.ExecuteUbergraph_BP_BaseFobCreator
}; 



