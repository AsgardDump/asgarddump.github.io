#pragma once 
#include <BP_attachment_RailCovers_Woodland_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_attachment_RailCovers_Woodland.BP_attachment_RailCovers_Woodland_C
// Size: 0x500(Inherited: 0x500) 
struct UBP_attachment_RailCovers_Woodland_C : public UBP_attachment_RailCovers_C
{

}; 



