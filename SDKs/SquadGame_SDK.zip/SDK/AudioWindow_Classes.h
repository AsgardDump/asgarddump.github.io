#pragma once 
#include <AudioWindow_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AudioWindow.AudioWindow_C
// Size: 0x331(Inherited: 0x260) 
struct UAudioWindow_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct USettingsComboboxItem_C* AudioInputDevice;  // 0x268(0x8)
	struct USettingsComboboxItem_C* AUDIOOUTPUTDEVICE;  // 0x270(0x8)
	struct USettingsItem_GraphicsToggle_C* AUDIOQUALITY;  // 0x278(0x8)
	struct USettingsItem_Slider_LR_C* COMMANDVOICEBALANCE;  // 0x280(0x8)
	struct USettingsItem_Slider_C* COMMANDVOICEVOLUME;  // 0x288(0x8)
	struct USettingsItem_Slider_C* EffectsVolume;  // 0x290(0x8)
	struct USettingsItem_Slider_C* LOCALVOICEVOLUME;  // 0x298(0x8)
	struct USettingsItem_Slider_C* MasterVolume;  // 0x2A0(0x8)
	struct USettingsItem_Slider_C* MusicVolume;  // 0x2A8(0x8)
	struct USettingsItem_Slider_C* OUTOFGAMEVOLUME;  // 0x2B0(0x8)
	struct USettingsItem_Slider_C* PrioritySpeakerDucking;  // 0x2B8(0x8)
	struct UScrollBox* ScrollBox;  // 0x2C0(0x8)
	struct UImage* Separator0;  // 0x2C8(0x8)
	struct UImage* Separator1;  // 0x2D0(0x8)
	struct USettingsItem_Slider_LR_C* SQUADVOICEBALANCE;  // 0x2D8(0x8)
	struct USettingsItem_Slider_C* SquadVoiceVolume;  // 0x2E0(0x8)
	struct USettingsItem_TickBox_C* ToggleCOMMANDBEEP;  // 0x2E8(0x8)
	struct USettingsItem_TickBox_C* ToggleLeaderOnlyBias;  // 0x2F0(0x8)
	struct USettingsItem_TickBox_C* ToggleRADIOFILTER;  // 0x2F8(0x8)
	struct USettingsItem_TickBox_C* ToggleSQUADBEEP;  // 0x300(0x8)
	struct USettingsItem_Slider_C* UIVolume;  // 0x308(0x8)
	struct TArray<struct FScreenResolutionStruct> ScreenResolutions;  // 0x310(0x10)
	struct TArray<struct FScreenResolutionStruct> ValidResolutions;  // 0x320(0x10)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool bConstructed : 1;  // 0x330(0x1)

	struct UWidget* Get_ToggleLeaderOnlyBias_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_ToggleLeaderOnlyBias_ToolTipWidget_1
	struct UWidget* Get_ToggleRADIOFILTER_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_ToggleRADIOFILTER_ToolTipWidget_1
	struct UWidget* Get_PrioritySpeakerDucking_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_PrioritySpeakerDucking_ToolTipWidget_1
	struct UWidget* Get_LOCALVOICEVOLUME_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_LOCALVOICEVOLUME_ToolTipWidget_1
	struct UWidget* Get_SQUADVOICEBALANCE_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_SQUADVOICEBALANCE_ToolTipWidget_1
	struct UWidget* Get_SQUADVOICEVOLUME_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_SQUADVOICEVOLUME_ToolTipWidget_1
	struct UWidget* Get_COMMANDVOICEBALANCE_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_COMMANDVOICEBALANCE_ToolTipWidget_1
	struct UWidget* Get_COMMANDVOICEVOLUME_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_COMMANDVOICEVOLUME_ToolTipWidget_1
	struct UWidget* Get_AUDIOINPUTDEVICE_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_AUDIOINPUTDEVICE_ToolTipWidget_1
	struct UWidget* Get_AUDIOOUTPUTDEVICE_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_AUDIOOUTPUTDEVICE_ToolTipWidget_1
	struct UWidget* Get_AUDIOQUALITY_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_AUDIOQUALITY_ToolTipWidget_1
	void UpdateSoundDevices(); // Function AudioWindow.AudioWindow_C.UpdateSoundDevices
	struct UWidget* Get_ToggleSQUADBEEP_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_ToggleSQUADBEEP_ToolTipWidget_1
	struct UWidget* Get_ToggleCOMMANDBEEP_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_ToggleCOMMANDBEEP_ToolTipWidget_1
	struct UWidget* Get_OUTOFGAMENEW_ToolTipWidget_1(); // Function AudioWindow.AudioWindow_C.Get_OUTOFGAMENEW_ToolTipWidget_1
	void UpdateButtons(); // Function AudioWindow.AudioWindow_C.UpdateButtons
	void Construct(); // Function AudioWindow.AudioWindow_C.Construct
	void BndEvt__AUDIONEW_K2Node_ComponentBoundEvent_51_OnButtonClick__DelegateSignature(int32_t ButtonNumber, struct USettingsItem_GraphicsToggle_C* ToggleItem); // Function AudioWindow.AudioWindow_C.BndEvt__AUDIONEW_K2Node_ComponentBoundEvent_51_OnButtonClick__DelegateSignature
	void BndEvt__ToggleCOMMANDBEEP_K2Node_ComponentBoundEvent_8_OnClicked__DelegateSignature(bool bSelected, struct USettingsItem_TickBox_C* Button); // Function AudioWindow.AudioWindow_C.BndEvt__ToggleCOMMANDBEEP_K2Node_ComponentBoundEvent_8_OnClicked__DelegateSignature
	void BndEvt__ToggleSQUADBEEP_K2Node_ComponentBoundEvent_9_OnClicked__DelegateSignature(bool bSelected, struct USettingsItem_TickBox_C* Button); // Function AudioWindow.AudioWindow_C.BndEvt__ToggleSQUADBEEP_K2Node_ComponentBoundEvent_9_OnClicked__DelegateSignature
	void BndEvt__ToggleRADIO_K2Node_ComponentBoundEvent_10_OnClicked__DelegateSignature(bool bSelected, struct USettingsItem_TickBox_C* Button); // Function AudioWindow.AudioWindow_C.BndEvt__ToggleRADIO_K2Node_ComponentBoundEvent_10_OnClicked__DelegateSignature
	void BndEvt__MASTERNEW_K2Node_ComponentBoundEvent_33_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__MASTERNEW_K2Node_ComponentBoundEvent_33_OnValueChanged__DelegateSignature
	void BndEvt__EFFECTSNEW_K2Node_ComponentBoundEvent_49_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__EFFECTSNEW_K2Node_ComponentBoundEvent_49_OnValueChanged__DelegateSignature
	void BndEvt__UINEW_K2Node_ComponentBoundEvent_82_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__UINEW_K2Node_ComponentBoundEvent_82_OnValueChanged__DelegateSignature
	void BndEvt__OUTOFGAMENEW_K2Node_ComponentBoundEvent_150_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__OUTOFGAMENEW_K2Node_ComponentBoundEvent_150_OnValueChanged__DelegateSignature
	void BndEvt__COMMANDVOICENEW_K2Node_ComponentBoundEvent_27_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__COMMANDVOICENEW_K2Node_ComponentBoundEvent_27_OnValueChanged__DelegateSignature
	void BndEvt__VOICENEW_K2Node_ComponentBoundEvent_30_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__VOICENEW_K2Node_ComponentBoundEvent_30_OnValueChanged__DelegateSignature
	void BndEvt__LOCALVOICENEW_K2Node_ComponentBoundEvent_45_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__LOCALVOICENEW_K2Node_ComponentBoundEvent_45_OnValueChanged__DelegateSignature
	void Apply(); // Function AudioWindow.AudioWindow_C.Apply
	void Revert(); // Function AudioWindow.AudioWindow_C.Revert
	void Default(); // Function AudioWindow.AudioWindow_C.Default
	void BndEvt__MUSICNEW_K2Node_ComponentBoundEvent_27_OnCaptureEnd__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__MUSICNEW_K2Node_ComponentBoundEvent_27_OnCaptureEnd__DelegateSignature
	void BndEvt__CommandVoiceBias_K2Node_ComponentBoundEvent_0_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__CommandVoiceBias_K2Node_ComponentBoundEvent_0_OnValueChanged__DelegateSignature
	void BndEvt__SquadVoiceBias_K2Node_ComponentBoundEvent_2_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__SquadVoiceBias_K2Node_ComponentBoundEvent_2_OnValueChanged__DelegateSignature
	void BndEvt__PrioritySpeakerDucking_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature(float Value); // Function AudioWindow.AudioWindow_C.BndEvt__PrioritySpeakerDucking_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature
	void BndEvt__ToggleLeaderOnlyBias_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(bool bSelected, struct USettingsItem_TickBox_C* Button); // Function AudioWindow.AudioWindow_C.BndEvt__ToggleLeaderOnlyBias_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
	void BndEvt__AUDIOOUTPUTDEVICE_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature(struct FString Option, int32_t Index); // Function AudioWindow.AudioWindow_C.BndEvt__AUDIOOUTPUTDEVICE_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature
	void BndEvt__AUDIOINPUTDEVICE_K2Node_ComponentBoundEvent_3_OnValueChanged__DelegateSignature(struct FString Option, int32_t Index); // Function AudioWindow.AudioWindow_C.BndEvt__AUDIOINPUTDEVICE_K2Node_ComponentBoundEvent_3_OnValueChanged__DelegateSignature
	void ExecuteUbergraph_AudioWindow(int32_t EntryPoint); // Function AudioWindow.AudioWindow_C.ExecuteUbergraph_AudioWindow
}; 



