#pragma once 
#include <BP_Attachment_1p29_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_1p29.BP_Attachment_1p29_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_1p29_C : public USQWeaponAttachment_Scope
{

}; 



