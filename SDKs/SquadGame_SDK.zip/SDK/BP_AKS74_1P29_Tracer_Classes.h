#pragma once 
#include <BP_AKS74_1P29_Tracer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74_1P29_Tracer.BP_AKS74_1P29_Tracer_C
// Size: 0x7E8(Inherited: 0x7E8) 
struct ABP_AKS74_1P29_Tracer_C : public ABP_AKS74_1P29_C
{

}; 



