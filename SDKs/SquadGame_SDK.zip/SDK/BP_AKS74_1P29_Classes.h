#pragma once 
#include <BP_AKS74_1P29_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74_1P29.BP_AKS74_1P29_C
// Size: 0x7E8(Inherited: 0x7D0) 
struct ABP_AKS74_1P29_C : public ABP_AKS74_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x7D0(0x8)
	struct UStaticMeshComponent* Front;  // 0x7D8(0x8)
	struct UStaticMeshComponent* Scope;  // 0x7E0(0x8)

	void StopModifyZeroing(); // Function BP_AKS74_1P29.BP_AKS74_1P29_C.StopModifyZeroing
	void ExecuteUbergraph_BP_AKS74_1P29(int32_t EntryPoint); // Function BP_AKS74_1P29.BP_AKS74_1P29_C.ExecuteUbergraph_BP_AKS74_1P29
}; 



