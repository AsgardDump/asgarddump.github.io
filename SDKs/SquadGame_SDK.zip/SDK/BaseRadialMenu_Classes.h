#pragma once 
#include <BaseRadialMenu_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BaseRadialMenu.BaseRadialMenu_C
// Size: 0x3A8(Inherited: 0x260) 
struct UBaseRadialMenu_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* Fade;  // 0x268(0x8)
	struct UNamedSlot* CenterSlot;  // 0x270(0x8)
	struct UBorder* CursorRing;  // 0x278(0x8)
	struct UCanvasPanel* Panel;  // 0x280(0x8)
	struct UImage* RingBG;  // 0x288(0x8)
	struct UCanvasPanel* RingWidgetsPanel;  // 0x290(0x8)
	struct TArray<struct USQRadialButton*> OuterRingWidgets;  // 0x298(0x10)
	struct USQRadialButton* Center Widget;  // 0x2A8(0x8)
	float MaxOuterDistance;  // 0x2B0(0x4)
	float ActiveOuterRingDistance;  // 0x2B4(0x4)
	float InactiveOuterRingDistance;  // 0x2B8(0x4)
	char pad_700[4];  // 0x2BC(0x4)
	struct FMulticastInlineDelegate OnOptionClicked;  // 0x2C0(0x10)
	struct FMulticastInlineDelegate OnCenterClicked;  // 0x2D0(0x10)
	struct FName CloseMenuActionName;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool Inactive : 1;  // 0x2E8(0x1)
	char pad_745[7];  // 0x2E9(0x7)
	UBP_RadialMenuModel_C* RadialMenuModel;  // 0x2F0(0x8)
	struct UObject* Context;  // 0x2F8(0x8)
	struct UCurveFloat* RingScale;  // 0x300(0x8)
	float MaxDistanceFromContext;  // 0x308(0x4)
	float RadialSize;  // 0x30C(0x4)
	struct FMulticastInlineDelegate HoverWidgetChanged;  // 0x310(0x10)
	struct USoundBase* MouseClickSoundCue;  // 0x320(0x8)
	float Desired Angle;  // 0x328(0x4)
	float Mouse Speed Threshold;  // 0x32C(0x4)
	struct FVector2D LastMousePos;  // 0x330(0x8)
	int32_t Last Hover Index;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct FMulticastInlineDelegate Centre Hover Changed;  // 0x340(0x10)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool Hovering Centre : 1;  // 0x350(0x1)
	char pad_849[7];  // 0x351(0x7)
	struct FMulticastInlineDelegate OnRadialMenuDestroyed;  // 0x358(0x10)
	struct TArray<struct UBP_RadialItemModel_C*> OuterRingModels;  // 0x368(0x10)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool Is Open : 1;  // 0x378(0x1)
	char pad_889[3];  // 0x379(0x3)
	float Radial Centre Hover Division;  // 0x37C(0x4)
	struct TArray<UBP_RadialMenuModel_C*> LastOpenedMenu;  // 0x380(0x10)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool bEditMode : 1;  // 0x390(0x1)
	char pad_913[7];  // 0x391(0x7)
	struct FMulticastInlineDelegate OnSelfClosed;  // 0x398(0x10)

	void SequenceEvent__ENTRYPOINTBaseRadialMenu_1(); // Function BaseRadialMenu.BaseRadialMenu_C.SequenceEvent__ENTRYPOINTBaseRadialMenu_1
	void GetWidgetCenter(struct FVector2D& WidgetCenter); // Function BaseRadialMenu.BaseRadialMenu_C.GetWidgetCenter
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function BaseRadialMenu.BaseRadialMenu_C.OnMouseButtonUp
	void Finished Closed Animation(); // Function BaseRadialMenu.BaseRadialMenu_C.Finished Closed Animation
	void FadeAnimation(bool Reverse); // Function BaseRadialMenu.BaseRadialMenu_C.FadeAnimation
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Function BaseRadialMenu.BaseRadialMenu_C.OnMouseButtonDoubleClick
	void Return to Previous Menu(); // Function BaseRadialMenu.BaseRadialMenu_C.Return to Previous Menu
	void Sort Radial Z Order(); // Function BaseRadialMenu.BaseRadialMenu_C.Sort Radial Z Order
	void CreateToolTip(struct UBP_RadialItemModel_C* InOuterItemModel, struct UUserWidget*& OutToolTip); // Function BaseRadialMenu.BaseRadialMenu_C.CreateToolTip
	void CreateRadialWidget(USQUserWidget* WidgetClass, struct USQUserWidget*& CreatedWidget); // Function BaseRadialMenu.BaseRadialMenu_C.CreateRadialWidget
	void GetSelectedOuterWidget(int32_t& Output_Get, float& Actual Angle); // Function BaseRadialMenu.BaseRadialMenu_C.GetSelectedOuterWidget
	void Destroy(); // Function BaseRadialMenu.BaseRadialMenu_C.Destroy
	void CloseSelf(); // Function BaseRadialMenu.BaseRadialMenu_C.CloseSelf
	void CreateMenuFromModel(); // Function BaseRadialMenu.BaseRadialMenu_C.CreateMenuFromModel
	void SetHoveringWidget(struct USQRadialButton* NewHover, struct USQRadialButton* OldHover); // Function BaseRadialMenu.BaseRadialMenu_C.SetHoveringWidget
	void GetHoverWidget(struct USQRadialButton*& HoverWidget); // Function BaseRadialMenu.BaseRadialMenu_C.GetHoverWidget
	void Notify HoverOver(); // Function BaseRadialMenu.BaseRadialMenu_C.Notify HoverOver
	struct FEventReply OnKeyUp(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function BaseRadialMenu.BaseRadialMenu_C.OnKeyUp
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function BaseRadialMenu.BaseRadialMenu_C.OnMouseButtonDown
	void LayoutOuterRing(); // Function BaseRadialMenu.BaseRadialMenu_C.LayoutOuterRing
	void AddChild(struct USQRadialButton* Entry, struct UBP_RadialItemModel_C* Model); // Function BaseRadialMenu.BaseRadialMenu_C.AddChild
	void Clear Menu(); // Function BaseRadialMenu.BaseRadialMenu_C.Clear Menu
	void Add Center Widget(struct USQRadialButton* Entry); // Function BaseRadialMenu.BaseRadialMenu_C.Add Center Widget
	void GetOuterWidgetIndex(int32_t& WidgetIndex); // Function BaseRadialMenu.BaseRadialMenu_C.GetOuterWidgetIndex
	void IsMouseInCenterHitbox(bool& CenterHitbox); // Function BaseRadialMenu.BaseRadialMenu_C.IsMouseInCenterHitbox
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function BaseRadialMenu.BaseRadialMenu_C.Tick
	void Center Button Clicked(); // Function BaseRadialMenu.BaseRadialMenu_C.Center Button Clicked
	void Radial Option Clicked(int32_t Index); // Function BaseRadialMenu.BaseRadialMenu_C.Radial Option Clicked
	void ButtonPress(struct UBP_RadialItemModel_C* Item); // Function BaseRadialMenu.BaseRadialMenu_C.ButtonPress
	void Reset(bool bCenterMouse); // Function BaseRadialMenu.BaseRadialMenu_C.Reset
	void Radial Option Released(int32_t Index); // Function BaseRadialMenu.BaseRadialMenu_C.Radial Option Released
	void ButtonRelease(struct UBP_RadialItemModel_C* Item); // Function BaseRadialMenu.BaseRadialMenu_C.ButtonRelease
	void ExecuteUbergraph_BaseRadialMenu(int32_t EntryPoint); // Function BaseRadialMenu.BaseRadialMenu_C.ExecuteUbergraph_BaseRadialMenu
	void OnSelfClosed__DelegateSignature(); // Function BaseRadialMenu.BaseRadialMenu_C.OnSelfClosed__DelegateSignature
	void OnRadialMenuDestroyed__DelegateSignature(); // Function BaseRadialMenu.BaseRadialMenu_C.OnRadialMenuDestroyed__DelegateSignature
	void Centre Hover Changed__DelegateSignature(bool Centre Hovered); // Function BaseRadialMenu.BaseRadialMenu_C.Centre Hover Changed__DelegateSignature
	void HoverWidgetChanged__DelegateSignature(); // Function BaseRadialMenu.BaseRadialMenu_C.HoverWidgetChanged__DelegateSignature
	void OnCenterClicked__DelegateSignature(struct UBaseRadialMenu_C* Context); // Function BaseRadialMenu.BaseRadialMenu_C.OnCenterClicked__DelegateSignature
	void OnOptionClicked__DelegateSignature(int32_t OptionIndex, struct UBaseRadialMenu_C* Context); // Function BaseRadialMenu.BaseRadialMenu_C.OnOptionClicked__DelegateSignature
}; 



