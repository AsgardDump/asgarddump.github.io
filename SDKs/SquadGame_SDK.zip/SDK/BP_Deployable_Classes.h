#pragma once 
#include <BP_Deployable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Deployable.BP_Deployable_C
// Size: 0x434(Inherited: 0x428) 
struct ABP_Deployable_C : public ASQDeployable
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x428(0x8)
	float InteriorCheckHeight;  // 0x430(0x4)

	void ReceiveTick(float DeltaSeconds); // Function BP_Deployable.BP_Deployable_C.ReceiveTick
	void ExecuteUbergraph_BP_Deployable(int32_t EntryPoint); // Function BP_Deployable.BP_Deployable_C.ExecuteUbergraph_BP_Deployable
}; 



