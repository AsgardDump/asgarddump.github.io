#pragma once 
#include <BP_AK74MGP25_Rifle_StaticInfo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74MGP25_Rifle_StaticInfo.BP_AK74MGP25_Rifle_StaticInfo_C
// Size: 0x9B0(Inherited: 0x9B0) 
struct UBP_AK74MGP25_Rifle_StaticInfo_C : public UBP_AK74GP25_Rifle_StaticInfo_C
{

}; 



