#pragma once 
#include "SDK.h" 
 
 
// Function BP_40MM_VOG_Proj2.BP_40MM_VOG_Proj2_C.ExecuteUbergraph_BP_40MM_VOG_Proj2
// Size: 0xC8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_40MM_VOG_Proj2
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* K2Node_Event_SelfActor;  // 0x8(0x8)
	struct AActor* K2Node_Event_OtherActor;  // 0x10(0x8)
	struct FVector K2Node_Event_NormalImpulse;  // 0x18(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0x24(0x88)
	char pad_172[4];  // 0xAC(0x4)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0xB0(0x8)
	float CallFunc_GetGameTimeSinceCreation_ReturnValue;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0xC0(0x8)

}; 
// Function BP_40MM_VOG_Proj2.BP_40MM_VOG_Proj2_C.OnImpact
// Size: 0xA4(Inherited: 0xA8) 
struct FOnImpact : public FOnImpact
{
	struct AActor* SelfActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct FVector NormalImpulse;  // 0x10(0xC)
	struct FHitResult Hit;  // 0x1C(0x88)

}; 
