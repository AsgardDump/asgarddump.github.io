#pragma once 
#include <BP_BaseRoleChangeModel_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseRoleChangeModel.BP_BaseRoleChangeModel_C
// Size: 0xB8(Inherited: 0xA8) 
struct UBP_BaseRoleChangeModel_C : public UBP_RadialActionModel_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct UBP_SQRoleSettings_C* Role;  // 0xB0(0x8)

	void OnClicked(struct UBaseRadialMenu_C* Radial); // Function BP_BaseRoleChangeModel.BP_BaseRoleChangeModel_C.OnClicked
	void ExecuteUbergraph_BP_BaseRoleChangeModel(int32_t EntryPoint); // Function BP_BaseRoleChangeModel.BP_BaseRoleChangeModel_C.ExecuteUbergraph_BP_BaseRoleChangeModel
}; 



