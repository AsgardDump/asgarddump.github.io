#pragma once 
#include "SDK.h" 
 
 
// Function BP_AKS74_1P29.BP_AKS74_1P29_C.ExecuteUbergraph_BP_AKS74_1P29
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AKS74_1P29
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
