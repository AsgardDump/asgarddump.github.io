#pragma once 
#include <BP_AK74MGP25_1P78_UGL_Smoke_Red_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74MGP25_1P78_UGL_Smoke_Red.BP_AK74MGP25_1P78_UGL_Smoke_Red_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74MGP25_1P78_UGL_Smoke_Red_C : public ABP_AK74MGP25_1P78_UGL_Smoke_C
{

}; 



