#pragma once 
#include "SDK.h" 
 
 
// Function BP_EmoteMenu.BP_EmoteMenu_C.ExecuteUbergraph_BP_EmoteMenu
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EmoteMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBaseRadialMenu_C* K2Node_Event_BaseRadialMenu;  // 0x8(0x8)

}; 
// Function BP_EmoteMenu.BP_EmoteMenu_C.CreateChildWidgets
// Size: 0x8(Inherited: 0x8) 
struct FCreateChildWidgets : public FCreateChildWidgets
{
	struct UBaseRadialMenu_C* BaseRadialMenu;  // 0x0(0x8)

}; 
// Function BP_EmoteMenu.BP_EmoteMenu_C.CreateChildEntries
// Size: 0xE4(Inherited: 0x0) 
struct FCreateChildEntries
{
	struct UBaseRadialMenu_C* BaseRadial;  // 0x0(0x8)
	struct UBPRadialPopulatorEmote_C* L Entry Populator;  // 0x8(0x8)
	struct UBP_EmotesMenu_RadialEntry_C* CallFunc_SpawnObject_ReturnValue;  // 0x10(0x8)
	struct USQUserWidget* CallFunc_CreateRadialChildWidget_CreatedWidget;  // 0x18(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UObject* CallFunc_GetDefaultObjectFor_ReturnValue;  // 0x30(0x8)
	struct UBP_EmotesMenu_RadialEntry_C* CallFunc_SpawnObject_ReturnValue_2;  // 0x38(0x8)
	struct UBPRadialPopulatorEmote_C* K2Node_DynamicCast_AsBPRadial_Populator_Emote;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USQUserWidget* CallFunc_CreateRadialChildWidget_CreatedWidget_2;  // 0x50(0x8)
	struct UEmoteRadialEntry_C* K2Node_DynamicCast_AsEmote_Radial_Entry;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t Temp_int_Variable;  // 0x64(0x4)
	struct UBP_RadialItemModel_C* CallFunc_GetModelReferencesFromClass_AsBP_Radial_Item_Model;  // 0x68(0x8)
	struct UBPRadialPopulatorIcon_C* CallFunc_GetModelReferencesFromClass_AsBPRadial_Populator_Icon;  // 0x70(0x8)
	struct USQUserWidget* CallFunc_CreateRadialChildWidget_CreatedWidget_3;  // 0x78(0x8)
	struct TSoftObjectPtr<USQEmotesData> CallFunc_GetEmoteAtIndex_ReturnValue;  // 0x80(0x28)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct USQEmotesData* K2Node_DynamicCast_AsSQEmotes_Data;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0xC8(0x18)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xE0(0x4)

}; 
