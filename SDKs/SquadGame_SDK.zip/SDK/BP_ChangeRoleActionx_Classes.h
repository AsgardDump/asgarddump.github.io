#pragma once 
#include <BP_ChangeRoleActionx_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ChangeRoleActionx.BP_ChangeRoleActionx_C
// Size: 0x38(Inherited: 0x30) 
struct UBP_ChangeRoleActionx_C : public UBP_RadialAction_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)

	void ChangeRole(struct UBaseRadialMenu_C* Radial, struct USQRoleSettings* Role); // Function BP_ChangeRoleActionx.BP_ChangeRoleActionx_C.ChangeRole
	void ExecuteUbergraph_BP_ChangeRoleActionx(int32_t EntryPoint); // Function BP_ChangeRoleActionx.BP_ChangeRoleActionx_C.ExecuteUbergraph_BP_ChangeRoleActionx
}; 



