#pragma once 
#include <BP_GenericDeployableItem_StaticInfo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GenericDeployableItem_StaticInfo.BP_GenericDeployableItem_StaticInfo_C
// Size: 0x558(Inherited: 0x558) 
struct UBP_GenericDeployableItem_StaticInfo_C : public USQDeployableItemStaticInfo
{

}; 



