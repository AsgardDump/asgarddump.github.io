#pragma once 
#include <BP_AK74M_Recruit_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74M_Recruit.BP_AK74M_Recruit_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74M_Recruit_C : public ABP_AK74M_C
{

}; 



