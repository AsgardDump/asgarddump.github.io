#pragma once 
#include <BP_Generic_Helicopter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Generic_Helicopter.BP_Generic_Helicopter_C
// Size: 0xDF0(Inherited: 0x920) 
struct ABP_Generic_Helicopter_C : public ASQHelicopter2
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x920(0x8)
	struct USceneComponent* WaterDamagePoint;  // 0x928(0x8)
	struct UBP_RotorWashSender_C* BP_RotorWashSender;  // 0x930(0x8)
	struct USQArmorMeshComponent* CollisionArmorMesh;  // 0x938(0x8)
	struct UDecalComponent* Warning Decal 04;  // 0x940(0x8)
	struct UDecalComponent* Warning Decal 03;  // 0x948(0x8)
	struct UDecalComponent* Warning Decal 02;  // 0x950(0x8)
	struct UDecalComponent* Warning Decal 01;  // 0x958(0x8)
	struct UAudioComponent* WarningAudio;  // 0x960(0x8)
	struct UPointLightComponent* PointLight3;  // 0x968(0x8)
	struct UPointLightComponent* PointLight2;  // 0x970(0x8)
	struct UPointLightComponent* PointLight1;  // 0x978(0x8)
	struct UPointLightComponent* PointLight;  // 0x980(0x8)
	struct USceneComponent* Warning Parent;  // 0x988(0x8)
	struct UStaticMeshComponent* LandingMarker;  // 0x990(0x8)
	struct UCameraComponent* LandingCamera;  // 0x998(0x8)
	struct USQVehicleBurningComponent* VehicleBurning;  // 0x9A0(0x8)
	struct UBPComponent_RadialModel_C* BPComponent_RadialModel;  // 0x9A8(0x8)
	struct UParticleSystemComponent* GroundEffect;  // 0x9B0(0x8)
	struct USQVehicleExitPointComponent* SQVehicleExitPoint1;  // 0x9B8(0x8)
	struct USQVehicleExitPointComponent* SQVehicleExitPoint;  // 0x9C0(0x8)
	struct UArrowComponent* LandingArrowStabilizer;  // 0x9C8(0x8)
	struct UArrowComponent* LandingArrowBottomRight;  // 0x9D0(0x8)
	struct UArrowComponent* LandingArrowTopRight;  // 0x9D8(0x8)
	struct UArrowComponent* LandingArrowBottomLeft;  // 0x9E0(0x8)
	struct UArrowComponent* LandingArrowTopLeft;  // 0x9E8(0x8)
	char ETimelineDirection Warning_Light_Animation__Direction_BED4FDDF4B03AF41E9D22382105F3A83;  // 0x9F0(0x1)
	char pad_2545[7];  // 0x9F1(0x7)
	struct UTimelineComponent* Warning Light Animation;  // 0x9F8(0x8)
	float Timeline_2_Default_Power_079618E342F7064103BFCC9F05CBEF12;  // 0xA00(0x4)
	char ETimelineDirection Timeline_2__Direction_079618E342F7064103BFCC9F05CBEF12;  // 0xA04(0x1)
	char pad_2565[3];  // 0xA05(0x3)
	struct UTimelineComponent* Timeline_3;  // 0xA08(0x8)
	char pad_2576_1 : 7;  // 0xA10(0x1)
	bool Physics-IsLanded? : 1;  // 0xA10(0x1)
	char pad_2577[3];  // 0xA11(0x3)
	float Physics-DefaultThrust;  // 0xA14(0x4)
	char pad_2584_1 : 7;  // 0xA18(0x1)
	bool Physics-IsReadyToLand? : 1;  // 0xA18(0x1)
	char pad_2585[3];  // 0xA19(0x3)
	float Physics-StrafePassiveInterp;  // 0xA1C(0x4)
	float Physics-BaseDeltaSpeed;  // 0xA20(0x4)
	float Physics-AntiThrustPower;  // 0xA24(0x4)
	float Physics-AddVelocityFromRotation;  // 0xA28(0x4)
	float Physics-StrafeOnRollInterp;  // 0xA2C(0x4)
	float Physics-ThrustPower;  // 0xA30(0x4)
	float Physics-PitchSpeedMultiplier;  // 0xA34(0x4)
	float Physics-BaseMaxFlySpeed;  // 0xA38(0x4)
	float Physics-ReservedAcceleration;  // 0xA3C(0x4)
	float Physics-AccelerationByPitchCutoff;  // 0xA40(0x4)
	float Physics-MaxFlySpeed;  // 0xA44(0x4)
	float Physics-CollisionMinSpeed;  // 0xA48(0x4)
	float Physics-MaxDeltaSpeed;  // 0xA4C(0x4)
	float RotorAccelerationScale;  // 0xA50(0x4)
	float Game-DeltaSeconds;  // 0xA54(0x4)
	struct AController* Controller-ServerController;  // 0xA58(0x8)
	char pad_2656_1 : 7;  // 0xA60(0x1)
	bool Controller-IsPossessed? : 1;  // 0xA60(0x1)
	char pad_2657[7];  // 0xA61(0x7)
	struct APlayerController* Controller-PlayerController;  // 0xA68(0x8)
	struct FRotator Controller-CurrentRotation;  // 0xA70(0xC)
	struct FRotator Controller-PreviousRotation;  // 0xA7C(0xC)
	char pad_2696_1 : 7;  // 0xA88(0x1)
	bool Game-BegunPlay? : 1;  // 0xA88(0x1)
	char pad_2697[3];  // 0xA89(0x3)
	float LandingDistance;  // 0xA8C(0x4)
	float MaxVelocityToLand;  // 0xA90(0x4)
	char pad_2708_1 : 7;  // 0xA94(0x1)
	bool Collision-GotCollisionHit? : 1;  // 0xA94(0x1)
	char pad_2709[3];  // 0xA95(0x3)
	float StrafePassive;  // 0xA98(0x4)
	float Twitchiness;  // 0xA9C(0x4)
	float StrafeOnRoll;  // 0xAA0(0x4)
	float StrafeOnRollSpeed;  // 0xAA4(0x4)
	float RotorLiftMin;  // 0xAA8(0x4)
	float RotorLiftMax;  // 0xAAC(0x4)
	float Gravity;  // 0xAB0(0x4)
	float AirFriction;  // 0xAB4(0x4)
	float Friction;  // 0xAB8(0x4)
	char pad_2748[4];  // 0xABC(0x4)
	struct UCurveFloat* FrictionByPitch;  // 0xAC0(0x8)
	struct UCurveFloat* BrakeByPitch;  // 0xAC8(0x8)
	struct UCurveVector* AccelerationInterpolationSpeed;  // 0xAD0(0x8)
	struct UCurveVector* UpDirectionByPitch;  // 0xAD8(0x8)
	struct UCurveFloat* ForwardDirectionByPitch;  // 0xAE0(0x8)
	struct UCurveFloat* RightDirectionByRoll;  // 0xAE8(0x8)
	struct UCurveVector* TurnByRollOnSpeed;  // 0xAF0(0x8)
	float MaximumSpeed;  // 0xAF8(0x4)
	float AverageSpeedPercent;  // 0xAFC(0x4)
	float RotorStrength;  // 0xB00(0x4)
	float RotorStrengthMultiplier;  // 0xB04(0x4)
	float CollisionMinSpeed;  // 0xB08(0x4)
	float FrictionMultiplier;  // 0xB0C(0x4)
	char pad_2832_1 : 7;  // 0xB10(0x1)
	bool Debug-IsDebugging? : 1;  // 0xB10(0x1)
	char pad_2833[3];  // 0xB11(0x3)
	float YawInputInterpt;  // 0xB14(0x4)
	float YawResistenceFromPitchStart;  // 0xB18(0x4)
	float YawResistenceFromPitchMax;  // 0xB1C(0x4)
	float YawResistenceFromVelocityMinSpeed;  // 0xB20(0x4)
	float YawResistenceFromVelocityInputMul;  // 0xB24(0x4)
	float BrakeByYawMinSpeed;  // 0xB28(0x4)
	float BrakeByYawSpeedCutOff;  // 0xB2C(0x4)
	char pad_2864_1 : 7;  // 0xB30(0x1)
	bool IsBrakeByYawInputSmooth? : 1;  // 0xB30(0x1)
	char pad_2865[3];  // 0xB31(0x3)
	float RollDumpSpeed;  // 0xB34(0x4)
	float RollDumpFactor;  // 0xB38(0x4)
	float RollPushTime;  // 0xB3C(0x4)
	char pad_2880_1 : 7;  // 0xB40(0x1)
	bool IsRollStabilizationEnabled? : 1;  // 0xB40(0x1)
	char pad_2881[7];  // 0xB41(0x7)
	struct UCurveFloat* RollStabilization;  // 0xB48(0x8)
	char pad_2896_1 : 7;  // 0xB50(0x1)
	bool IsPitchStabilizationEnabled? : 1;  // 0xB50(0x1)
	char pad_2897[3];  // 0xB51(0x3)
	float Input-Pitch;  // 0xB54(0x4)
	float Input-PitchSensitivityScale;  // 0xB58(0x4)
	float Input-PitchBounce;  // 0xB5C(0x4)
	float Input-PitchAxisValue;  // 0xB60(0x4)
	float Input-PitchBounceSecond;  // 0xB64(0x4)
	float Input-PitchRemaining;  // 0xB68(0x4)
	float Input-Yaw;  // 0xB6C(0x4)
	float Input-YawAxisValue;  // 0xB70(0x4)
	float Input-YawResistenceFromVelocity;  // 0xB74(0x4)
	float Input-YawRemaining;  // 0xB78(0x4)
	float Input-Roll;  // 0xB7C(0x4)
	float Input-RollPushValue;  // 0xB80(0x4)
	float Input-RollSensitivityScale;  // 0xB84(0x4)
	float Input-RolltoYawInterp;  // 0xB88(0x4)
	float Input-RollAxisValue;  // 0xB8C(0x4)
	float Input-RollRemaining;  // 0xB90(0x4)
	float Input-BrakeByYawVelocityCut;  // 0xB94(0x4)
	float Input-BrakeByYawInputMultiplier;  // 0xB98(0x4)
	float Input-AccelerationInputTime;  // 0xB9C(0x4)
	char pad_2976_1 : 7;  // 0xBA0(0x1)
	bool Input-IsAccelerating? : 1;  // 0xBA0(0x1)
	char pad_2977_1 : 7;  // 0xBA1(0x1)
	bool Input-IsDownPressed? : 1;  // 0xBA1(0x1)
	char pad_2978_1 : 7;  // 0xBA2(0x1)
	bool Input-IsYawBraking? : 1;  // 0xBA2(0x1)
	char pad_2979[1];  // 0xBA3(0x1)
	struct FVector Velocity-CurrentWorldOffset;  // 0xBA4(0xC)
	struct FVector Velocity-CurrentLocalOffset;  // 0xBB0(0xC)
	struct FVector Velocity-PreviousWorldOffset;  // 0xBBC(0xC)
	struct FVector Velocity-PreviousLocalOffset;  // 0xBC8(0xC)
	char pad_3028[4];  // 0xBD4(0x4)
	struct FTimerHandle Timer-CheckIfLiftOff;  // 0xBD8(0x8)
	float Input-RawInputRudder;  // 0xBE0(0x4)
	float RollInputInterpt;  // 0xBE4(0x4)
	float PitchInputInterpt;  // 0xBE8(0x4)
	char pad_3052[4];  // 0xBEC(0x4)
	struct UCurveFloat* PitchStabilization;  // 0xBF0(0x8)
	float RollPushStrength;  // 0xBF8(0x4)
	float RollSensitivityScaleLow;  // 0xBFC(0x4)
	float RollSensitivityScaleMiddle;  // 0xC00(0x4)
	float RollSensitivityScaleMax;  // 0xC04(0x4)
	struct UCurveFloat* RollInputScale;  // 0xC08(0x8)
	float PitchSensitivityScaleLow;  // 0xC10(0x4)
	float PitchSensitivityScaleMiddle;  // 0xC14(0x4)
	float PitchSensitivityScaleMax;  // 0xC18(0x4)
	char pad_3100[4];  // 0xC1C(0x4)
	struct UCurveFloat* PitchInputScale;  // 0xC20(0x8)
	float YawSensitivity (user);  // 0xC28(0x4)
	float YawSensitivity;  // 0xC2C(0x4)
	float YawSpeed;  // 0xC30(0x4)
	float RollSensitivity (user);  // 0xC34(0x4)
	float RollSensitivity;  // 0xC38(0x4)
	float RollAxisInputClamp;  // 0xC3C(0x4)
	float PitchSensitivity (user);  // 0xC40(0x4)
	float PitchSensitivity;  // 0xC44(0x4)
	float PitchAxisInputClamp;  // 0xC48(0x4)
	char pad_3148_1 : 7;  // 0xC4C(0x1)
	bool IsAddingYawWhenRolling? : 1;  // 0xC4C(0x1)
	char pad_3149[3];  // 0xC4D(0x3)
	float PitchToYawAngleThreshold;  // 0xC50(0x4)
	float PitchToYawScale;  // 0xC54(0x4)
	int32_t MainRotorMaxRPM;  // 0xC58(0x4)
	int32_t TailRotorMaxRPM;  // 0xC5C(0x4)
	char pad_3168_1 : 7;  // 0xC60(0x1)
	bool MainRotorCCW : 1;  // 0xC60(0x1)
	char pad_3169_1 : 7;  // 0xC61(0x1)
	bool TailRotorCCW : 1;  // 0xC61(0x1)
	char pad_3170[2];  // 0xC62(0x2)
	float BladesBlurMaxRPM;  // 0xC64(0x4)
	float BladesBlurMinRPM;  // 0xC68(0x4)
	float GroundEffectMaxDistanceMeters;  // 0xC6C(0x4)
	struct UCurveFloat* VerticalStabilizerAngleMultiplier;  // 0xC70(0x8)
	struct UCurveVector* StabilizerCorrectionBySpeed;  // 0xC78(0x8)
	struct FRotator Pilot-InitialCameraRotation;  // 0xC80(0xC)
	char pad_3212[4];  // 0xC8C(0x4)
	struct USQPhysicalMaterial* Effects-PrevPhysMat;  // 0xC90(0x8)
	struct UCurveFloat* HorizontalStabilizerAngleMultiplier;  // 0xC98(0x8)
	struct FRotator Pilot-ZoomCameraRotation;  // 0xCA0(0xC)
	float Instruments-AltitudeMeters;  // 0xCAC(0x4)
	struct FTransform Debug-ServerTransformLocation;  // 0xCB0(0x30)
	float Physics-MaxAltitude;  // 0xCE0(0x4)
	struct FRotator Target Landing Camera Rotation;  // 0xCE4(0xC)
	char pad_3312_1 : 7;  // 0xCF0(0x1)
	bool Warning On : 1;  // 0xCF0(0x1)
	char pad_3313[3];  // 0xCF1(0x3)
	float Physics-MainRotorRotationalForce;  // 0xCF4(0x4)
	float Physics-PreventTailRotorLossEffectTime;  // 0xCF8(0x4)
	char pad_3324_1 : 7;  // 0xCFC(0x1)
	bool Engine-IsActive : 1;  // 0xCFC(0x1)
	char pad_3325[3];  // 0xCFD(0x3)
	struct UCurveFloat* RotorEfficiencyByAOA;  // 0xD00(0x8)
	struct UCurveFloat* RotorEfficiencyByAirspeed;  // 0xD08(0x8)
	float RotorEfficiencyMax;  // 0xD10(0x4)
	float MaxTailRotorLossSpinForce;  // 0xD14(0x4)
	float Physics-FlipOverSpeedTailLoss;  // 0xD18(0x4)
	float HullWarningThreshold;  // 0xD1C(0x4)
	float EngineWarningThreshold;  // 0xD20(0x4)
	float MainRotorWarningThreshold;  // 0xD24(0x4)
	float TailRotorWarningThreshold;  // 0xD28(0x4)
	char pad_3372_1 : 7;  // 0xD2C(0x1)
	bool DebugMovement : 1;  // 0xD2C(0x1)
	char pad_3373[3];  // 0xD2D(0x3)
	struct FVector Debug True Velocity;  // 0xD30(0xC)
	struct FVector Debug Previous Frame True Velocity;  // 0xD3C(0xC)
	struct FVector Debug Previous Frame location;  // 0xD48(0xC)
	struct FVector Debug True Acceleration;  // 0xD54(0xC)
	struct FVector Debug Previous Frame Acceleration;  // 0xD60(0xC)
	float Input-RawYaw;  // 0xD6C(0x4)
	float Input-RawRoll;  // 0xD70(0x4)
	float Input-RawPitch;  // 0xD74(0x4)
	float Input-RawAcceleration;  // 0xD78(0x4)
	float AutoRotationBuffer;  // 0xD7C(0x4)
	float AutoRotationEnergyDrainFactor;  // 0xD80(0x4)
	float EngineDamageMinThrust;  // 0xD84(0x4)
	char pad_3464_1 : 7;  // 0xD88(0x1)
	bool StabilizerDebug : 1;  // 0xD88(0x1)
	char pad_3465[3];  // 0xD89(0x3)
	float YawInputRPMThreshold;  // 0xD8C(0x4)
	char pad_3472_1 : 7;  // 0xD90(0x1)
	bool bIsJoy : 1;  // 0xD90(0x1)
	char pad_3473[3];  // 0xD91(0x3)
	float Collective;  // 0xD94(0x4)
	float JoyPitch;  // 0xD98(0x4)
	float JoyRoll;  // 0xD9C(0x4)
	float JoyYaw;  // 0xDA0(0x4)
	char pad_3492_1 : 7;  // 0xDA4(0x1)
	bool bIsLockFreeLook : 1;  // 0xDA4(0x1)
	char pad_3493[3];  // 0xDA5(0x3)
	float Last FreeLookTime;  // 0xDA8(0x4)
	float LookRight;  // 0xDAC(0x4)
	float LookUp;  // 0xDB0(0x4)
	struct FVector2D LookState;  // 0xDB4(0x8)
	char pad_3516_1 : 7;  // 0xDBC(0x1)
	bool IsCamZoom : 1;  // 0xDBC(0x1)
	char pad_3517[3];  // 0xDBD(0x3)
	float MousePitch;  // 0xDC0(0x4)
	float MouseRoll;  // 0xDC4(0x4)
	float KeyPitch;  // 0xDC8(0x4)
	float KeyRoll;  // 0xDCC(0x4)
	float Rotor Wash Radius;  // 0xDD0(0x4)
	float DistanceToCullRotorWash_Meters;  // 0xDD4(0x4)
	float FatalWaterImpactVelocity;  // 0xDD8(0x4)
	float WaterDamageInterval;  // 0xDDC(0x4)
	float WaterMaxDepth;  // 0xDE0(0x4)
	float MinimumWaterDamage;  // 0xDE4(0x4)
	struct FTimerHandle WaterDamageHandle;  // 0xDE8(0x8)

	void Is Using Landing Camera(bool& Using Landing Camera); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Is Using Landing Camera
	void Get UI Tint(struct FLinearColor& Color); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Get UI Tint
	void GetKnots(float& Knots); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetKnots
	void HAT Look To(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HAT Look To
	void GetRotorEfficiency(float& Efficiency); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetRotorEfficiency
	float GetThrottle(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetThrottle
	void GetVisualCollective(float& Collectives); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetVisualCollective
	float GetMainRotorThrust(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetMainRotorThrust
	float GetTailRotorThrust(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetTailRotorThrust
	void Set UI Enabled(bool Enable UI); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Set UI Enabled
	void DoRotors(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoRotors
	void OnRep_Warning On(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.OnRep_Warning On
	void DoRotationFromRoll(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoRotationFromRoll
	void DebugVectorToString(struct FVector Vector, int32_t digits, struct FString& String); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DebugVectorToString
	void Manage Landing Camera(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Manage Landing Camera
	void DrawDebugLocation(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DrawDebugLocation
	void GetEngineThrust(float& EngineThrust); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetEngineThrust
	void CheckPhysics(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CheckPhysics
	bool IsLanded(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.IsLanded
	void DoStabilizers(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoStabilizers
	void PilotZoom(float InputPin); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.PilotZoom
	void GetThrustPower(float& Thrust); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetThrustPower
	void DebugVariablesMap(struct TMap<struct FString, struct FString> Map, struct FColor Color); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DebugVariablesMap
	void GetRotationDiff(struct FRotator& NewParam); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetRotationDiff
	void DrawDebug(bool Draw); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DrawDebug
	void SetGroundEffect(float& Height); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.SetGroundEffect
	void ResetMovementState(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ResetMovementState
	void ResetState(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ResetState
	int32_t GetMaxRPM(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetMaxRPM
	void EnablePhysics(bool bEnable); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.EnablePhysics
	void PolishPitchInput(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.PolishPitchInput
	void GetDistanceFromTheGround(float TraceSize, float& distance, bool& GotDistance); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetDistanceFromTheGround
	void PolishRollInput(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.PolishRollInput
	void GetGradualRotationIncrement(float& Roll, float& Pitch); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetGradualRotationIncrement
	void DoRollToYawTransfer(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoRollToYawTransfer
	void DoPushAndBounce(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.DoPushAndBounce
	void AddRoll(float Roll_); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddRoll
	void AddPitch(float Pitch); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddPitch
	void AddYaw(float Yaw); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddYaw
	void CalcBrakebyYaw(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CalcBrakebyYaw
	void CalcYawResistances(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CalcYawResistances
	void GetVelocityLength(float& NewParam); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetVelocityLength
	void GetRollNormalized(float& NewParam); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetRollNormalized
	void GetPitchNormalized(float& NewParam); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.GetPitchNormalized
	void CanLand(bool& CanLand?); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CanLand
	void CalcCustomVelocity(struct FVector& Velocity); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CalcCustomVelocity
	void AddAcceleration(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.AddAcceleration
	void UserConstructionScript(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.UserConstructionScript
	void Timeline_2__FinishedFunc(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Timeline_2__FinishedFunc
	void Timeline_2__UpdateFunc(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Timeline_2__UpdateFunc
	void Warning Light Animation__FinishedFunc(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Warning Light Animation__FinishedFunc
	void Warning Light Animation__UpdateFunc(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Warning Light Animation__UpdateFunc
	void Warning Light Animation__LightOff__EventFunc(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Warning Light Animation__LightOff__EventFunc
	void Warning Light Animation__LightOn__EventFunc(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Warning Light Animation__LightOn__EventFunc
	void InpActEvt_Helicopter_Recenter_View_K2Node_InputActionEvent_10(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_Helicopter_Recenter_View_K2Node_InputActionEvent_10
	void InpActEvt_DropAmmo_K2Node_InputActionEvent_9(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropAmmo_K2Node_InputActionEvent_9
	void InpActEvt_DropAmmo_K2Node_InputActionEvent_8(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropAmmo_K2Node_InputActionEvent_8
	void InpActEvt_DropConstruct_K2Node_InputActionEvent_7(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropConstruct_K2Node_InputActionEvent_7
	void InpActEvt_DropConstruct_K2Node_InputActionEvent_6(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_DropConstruct_K2Node_InputActionEvent_6
	void InpActEvt_PickupAmmo_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupAmmo_K2Node_InputActionEvent_5
	void InpActEvt_PickupAmmo_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupAmmo_K2Node_InputActionEvent_4
	void InpActEvt_PickupConstruct_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupConstruct_K2Node_InputActionEvent_3
	void InpActEvt_PickupConstruct_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_PickupConstruct_K2Node_InputActionEvent_2
	void InpActEvt_VehicleToggleCamera_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpActEvt_VehicleToggleCamera_K2Node_InputActionEvent_1
	void LandVehicle(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.LandVehicle
	void MC_SetLandingState(bool NewIsLandedState); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.MC_SetLandingState
	void CheckLiftOff(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CheckLiftOff
	void StartCheckLiftOff(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.StartCheckLiftOff
	void ROS_UpdateLandingState(bool IsLanded?); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ROS_UpdateLandingState
	void HandleInput_Acceleration(float AxisInput); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Acceleration
	void Acceleration_ModifySensitivity(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Acceleration_ModifySensitivity
	void HandleInput_Yaw(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Yaw
	void HandleInput_Roll(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Roll
	void HandleInput_Pitch(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput_Pitch
	void InpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterUp_K2Node_InputAxisEvent_1
	void InpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterRight_K2Node_InputAxisEvent_2
	void InpAxisEvt_MoveAileron_K2Node_InputAxisEvent_3(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_MoveAileron_K2Node_InputAxisEvent_3
	void InpAxisEvt_MoveElevator_K2Node_InputAxisEvent_4(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_MoveElevator_K2Node_InputAxisEvent_4
	void HandleInput(float DeltaTimeRatio); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.HandleInput
	void InpAxisEvt_Helicopter_Collective_K2Node_InputAxisEvent_9(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Helicopter_Collective_K2Node_InputAxisEvent_9
	void InpAxisEvt_HelicopterCyclic_Pitch_K2Node_InputAxisEvent_10(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterCyclic_Pitch_K2Node_InputAxisEvent_10
	void InpAxisEvt_HelicopterCyclic_Roll_K2Node_InputAxisEvent_11(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterCyclic_Roll_K2Node_InputAxisEvent_11
	void InpAxisEvt_HelicopterCyclic_Yaw_K2Node_InputAxisEvent_12(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterCyclic_Yaw_K2Node_InputAxisEvent_12
	void InpAxisEvt_HelicopterPitchKey_K2Node_InputAxisEvent_7(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterPitchKey_K2Node_InputAxisEvent_7
	void InpAxisEvt_Helicopter_Look_Up_Down_K2Node_InputAxisEvent_3(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Helicopter_Look_Up_Down_K2Node_InputAxisEvent_3
	void InpAxisEvt_Helicopter_Look_Right_Left_K2Node_InputAxisEvent_5(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Helicopter_Look_Right_Left_K2Node_InputAxisEvent_5
	void InpAxisEvt_HelicopterRollKey_K2Node_InputAxisEvent_6(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_HelicopterRollKey_K2Node_InputAxisEvent_6
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_8(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_8
	void InpAxisEvt_LookUp_K2Node_InputAxisEvent_14(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_14
	void ReceiveBeginPlay(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceiveBeginPlay
	void ReceivePossessed(struct AController* NewController); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceivePossessed
	void ROC_VehiclePosessed(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ROC_VehiclePosessed
	void ReceiveUnpossessed(struct AController* OldController); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceiveUnpossessed
	void MC_VehicleUnpossessed(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.MC_VehicleUnpossessed
	void TurnOnPhysics(bool IgnoreLandingCheck, struct FVector NewLinearVelocity, struct FVector NewAngularVelocity); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.TurnOnPhysics
	void ReceiveTick(float DeltaSeconds); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceiveTick
	void BeginPlay_Landing(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.BeginPlay_Landing
	void CheckIfCanLandVehicle(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.CheckIfCanLandVehicle
	void OnEngineActive(bool bActive); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.OnEngineActive
	void BndEvt__VehicleMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.BndEvt__VehicleMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void InpAxisEvt_VehicleZoom_K2Node_InputAxisEvent_9(float AxisValue); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.InpAxisEvt_VehicleZoom_K2Node_InputAxisEvent_9
	void TickGroundEffect(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.TickGroundEffect
	void EnteredVehicle(struct ASQSoldier* Soldier, struct USQVehicleSeatComponent* NewSeat); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.EnteredVehicle
	void SwitchedSeat(struct ASQSoldier* Soldier, struct USQVehicleSeatComponent* PreviousSeat, struct USQVehicleSeatComponent* NewSeat); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.SwitchedSeat
	void OnPhysicsReplicated(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.OnPhysicsReplicated
	void Toggle Landing Camera(bool Condition); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Toggle Landing Camera
	void LeftVehicle(struct ASQSoldier* Soldier, struct USQVehicleSeatComponent* PreviousSeat); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.LeftVehicle
	void Warning Light Anim(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Warning Light Anim
	void ReceiveDestroyed(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ReceiveDestroyed
	void Start Warning Anim(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Start Warning Anim
	void Stop Warning Anim(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Stop Warning Anim
	void On Entered Bounds(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.On Entered Bounds
	void On Out of Bounds(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.On Out of Bounds
	void Evaluate Warning(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Evaluate Warning
	void Set Landing Camera(bool Active); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Set Landing Camera
	void OnFDMImpact(struct FHitResult& HitResult, float TimeSlice, struct FVector& MoveDelta); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.OnFDMImpact
	void UpdateFreeLookSetting(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.UpdateFreeLookSetting
	void Optimize Sender(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.Optimize Sender
	void ApplyWaterDamage(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ApplyWaterDamage
	void StartWaterDamage(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.StartWaterDamage
	void BndEvt__TailBladesCollision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.BndEvt__TailBladesCollision_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__MainBladesCollision_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.BndEvt__MainBladesCollision_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
	void EndWaterDamage(); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.EndWaterDamage
	void ExecuteUbergraph_BP_Generic_Helicopter(int32_t EntryPoint); // Function BP_Generic_Helicopter.BP_Generic_Helicopter_C.ExecuteUbergraph_BP_Generic_Helicopter
}; 



