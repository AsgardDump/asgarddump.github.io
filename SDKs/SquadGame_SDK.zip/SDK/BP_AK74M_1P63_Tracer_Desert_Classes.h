#pragma once 
#include <BP_AK74M_1P63_Tracer_Desert_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74M_1P63_Tracer_Desert.BP_AK74M_1P63_Tracer_Desert_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74M_1P63_Tracer_Desert_C : public ABP_AK74M_1P63_Tracer_C
{

}; 



