#pragma once 
#include "SDK.h" 
 
 
// Function BP_BackBlastShockWave.BP_BackBlastShockWave_C.ExecuteUbergraph_BP_BackBlastShockWave
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BackBlastShockWave
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* K2Node_Event_Instigator;  // 0x8(0x8)

}; 
// Function BP_BackBlastShockWave.BP_BackBlastShockWave_C.Explode
// Size: 0x8(Inherited: 0x9C) 
struct FExplode : public FExplode
{
	struct AActor* Instigator;  // 0x0(0x8)

}; 
// Function BP_BackBlastShockWave.BP_BackBlastShockWave_C.BackBlastShockWave
// Size: 0x74(Inherited: 0x0) 
struct FBackBlastShockWave
{
	struct AActor* Instigator;  // 0x0(0x8)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x14(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x20(0xC)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x30(0x4)
	int32_t Temp_int_Variable;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x3C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x40(0xC)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x4C(0xC)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FVector CallFunc_GreaterGreater_VectorRotator_ReturnValue;  // 0x5C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x68(0xC)

}; 
