#pragma once 
#include <BP_EmptyVehicleRadial_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmptyVehicleRadial.BP_EmptyVehicleRadial_C
// Size: 0x58(Inherited: 0x58) 
struct UBP_EmptyVehicleRadial_C : public UBP_RadialMenuModel_C
{

}; 



