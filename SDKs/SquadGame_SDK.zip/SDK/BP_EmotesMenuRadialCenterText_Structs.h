#pragma once 
#include "SDK.h" 
 
 
// Function BP_EmotesMenuRadialCenterText.BP_EmotesMenuRadialCenterText_C.ExecuteUbergraph_BP_EmotesMenuRadialCenterText
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EmotesMenuRadialCenterText
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBaseRadialMenu_C* K2Node_Event_Radial;  // 0x8(0x8)

}; 
// Function BP_EmotesMenuRadialCenterText.BP_EmotesMenuRadialCenterText_C.OnClicked
// Size: 0x8(Inherited: 0x8) 
struct FOnClicked : public FOnClicked
{
	struct UBaseRadialMenu_C* Radial;  // 0x0(0x8)

}; 
