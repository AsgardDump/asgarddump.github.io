#pragma once 
#include <BP_EmplacedUB32_Deployable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmplacedUB32_Deployable.BP_EmplacedUB32_Deployable_C
// Size: 0x4C8(Inherited: 0x434) 
struct ABP_EmplacedUB32_Deployable_C : public ABP_Deployable_C
{
	char pad_1076[4];  // 0x434(0x4)
	struct UStaticMeshComponent* StaticMesh47;  // 0x438(0x8)
	struct UStaticMeshComponent* StaticMesh48;  // 0x440(0x8)
	struct UStaticMeshComponent* StaticMesh44;  // 0x448(0x8)
	struct UStaticMeshComponent* StaticMesh45;  // 0x450(0x8)
	struct UStaticMeshComponent* StaticMesh46;  // 0x458(0x8)
	struct UStaticMeshComponent* StaticMesh43;  // 0x460(0x8)
	struct UStaticMeshComponent* StaticMesh42;  // 0x468(0x8)
	struct UStaticMeshComponent* StaticMesh41;  // 0x470(0x8)
	struct UStaticMeshComponent* StaticMesh40;  // 0x478(0x8)
	struct UStaticMeshComponent* SM_S5_Rocket_Stack1;  // 0x480(0x8)
	struct UStaticMeshComponent* SM_S5_Rocket_Stack;  // 0x488(0x8)
	struct UStaticMeshComponent* StaticMesh39;  // 0x490(0x8)
	struct USkeletalMeshComponent* SkeletalMesh2;  // 0x498(0x8)
	struct UStaticMeshComponent* StaticMesh5;  // 0x4A0(0x8)
	struct USQDeployableChildActorComponent* SQDeployableChildActor;  // 0x4A8(0x8)
	struct USkeletalMeshComponent* SkeletalMesh1;  // 0x4B0(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x4B8(0x8)
	struct UBoxComponent* Box;  // 0x4C0(0x8)

}; 



