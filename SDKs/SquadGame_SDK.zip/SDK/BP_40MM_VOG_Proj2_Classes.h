#pragma once 
#include <BP_40MM_VOG_Proj2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_40MM_VOG_Proj2.BP_40MM_VOG_Proj2_C
// Size: 0x528(Inherited: 0x500) 
struct ABP_40MM_VOG_Proj2_C : public ASQMortarProjectile
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x500(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x508(0x8)
	struct UChildActorComponent* Shockwave;  // 0x510(0x8)
	struct UParticleSystem* BPEffectOnUnderMinFlightTime;  // 0x518(0x8)
	struct USoundBase* BPSoundonUnderMinFlightTime;  // 0x520(0x8)

	void OnImpact(struct AActor* SelfActor, struct AActor* OtherActor, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_40MM_VOG_Proj2.BP_40MM_VOG_Proj2_C.OnImpact
	void ExecuteUbergraph_BP_40MM_VOG_Proj2(int32_t EntryPoint); // Function BP_40MM_VOG_Proj2.BP_40MM_VOG_Proj2_C.ExecuteUbergraph_BP_40MM_VOG_Proj2
}; 



