#pragma once 
#include "SDK.h" 
 
 
// Function AudioWindow.AudioWindow_C.BndEvt__AUDIOOUTPUTDEVICE_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature
// Size: 0x14(Inherited: 0x0) 
struct FBndEvt__AUDIOOUTPUTDEVICE_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature
{
	struct FString Option;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)

}; 
// Function AudioWindow.AudioWindow_C.ExecuteUbergraph_AudioWindow
// Size: 0x1C0(Inherited: 0x0) 
struct FExecuteUbergraph_AudioWindow
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t Temp_int_Variable_2;  // 0x8(0x4)
	int32_t Temp_int_Variable_3;  // 0xC(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x10(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_2;  // 0x18(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_3;  // 0x20(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_4;  // 0x28(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_5;  // 0x30(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_6;  // 0x38(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_7;  // 0x40(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_8;  // 0x48(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_9;  // 0x50(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_10;  // 0x58(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_11;  // 0x60(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_12;  // 0x68(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_13;  // 0x70(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_14;  // 0x78(0x8)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_15;  // 0x80(0x8)
	int32_t K2Node_ComponentBoundEvent_ButtonNumber;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct USettingsItem_GraphicsToggle_C* K2Node_ComponentBoundEvent_ToggleItem;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_ComponentBoundEvent_bSelected_4 : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct USettingsItem_TickBox_C* K2Node_ComponentBoundEvent_Button_4;  // 0xA0(0x8)
	int32_t K2Node_Select_Default;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool K2Node_ComponentBoundEvent_bSelected_3 : 1;  // 0xAD(0x1)
	char pad_174[2];  // 0xAE(0x2)
	struct USettingsItem_TickBox_C* K2Node_ComponentBoundEvent_Button_3;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_ComponentBoundEvent_bSelected_2 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct USettingsItem_TickBox_C* K2Node_ComponentBoundEvent_Button_2;  // 0xC0(0x8)
	float K2Node_ComponentBoundEvent_Value_11;  // 0xC8(0x4)
	float K2Node_ComponentBoundEvent_Value_10;  // 0xCC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xD0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xD4(0x4)
	float K2Node_ComponentBoundEvent_Value_9;  // 0xD8(0x4)
	float K2Node_ComponentBoundEvent_Value_8;  // 0xDC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0xE0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0xE4(0x4)
	float K2Node_ComponentBoundEvent_Value_7;  // 0xE8(0x4)
	float K2Node_ComponentBoundEvent_Value_6;  // 0xEC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_5;  // 0xF0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_6;  // 0xF4(0x4)
	float K2Node_ComponentBoundEvent_Value_5;  // 0xF8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_7;  // 0xFC(0x4)
	struct TArray<struct UMusicPlayer_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x100(0x10)
	struct UMusicPlayer_C* CallFunc_Array_Get_Item;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	float K2Node_ComponentBoundEvent_Value_4;  // 0x11C(0x4)
	float K2Node_ComponentBoundEvent_Value_3;  // 0x120(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_8;  // 0x124(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_9;  // 0x128(0x4)
	float K2Node_ComponentBoundEvent_Value_2;  // 0x12C(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_16;  // 0x130(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue_10;  // 0x138(0x4)
	char pad_316[4];  // 0x13C(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_17;  // 0x140(0x8)
	float K2Node_ComponentBoundEvent_Value;  // 0x148(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_11;  // 0x14C(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_18;  // 0x150(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x158(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x15C(0x4)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool K2Node_ComponentBoundEvent_bSelected : 1;  // 0x160(0x1)
	char pad_353[7];  // 0x161(0x7)
	struct USettingsItem_TickBox_C* K2Node_ComponentBoundEvent_Button;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_19;  // 0x178(0x8)
	struct FString K2Node_ComponentBoundEvent_Option_2;  // 0x180(0x10)
	int32_t K2Node_ComponentBoundEvent_Index_2;  // 0x190(0x4)
	char pad_404[4];  // 0x194(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_20;  // 0x198(0x8)
	struct FString K2Node_ComponentBoundEvent_Option;  // 0x1A0(0x10)
	int32_t K2Node_ComponentBoundEvent_Index;  // 0x1B0(0x4)
	char pad_436[4];  // 0x1B4(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_21;  // 0x1B8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__AUDIOINPUTDEVICE_K2Node_ComponentBoundEvent_3_OnValueChanged__DelegateSignature
// Size: 0x14(Inherited: 0x0) 
struct FBndEvt__AUDIOINPUTDEVICE_K2Node_ComponentBoundEvent_3_OnValueChanged__DelegateSignature
{
	struct FString Option;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__MUSICNEW_K2Node_ComponentBoundEvent_27_OnCaptureEnd__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__MUSICNEW_K2Node_ComponentBoundEvent_27_OnCaptureEnd__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.Get_AUDIOQUALITY_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_AUDIOQUALITY_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__ToggleLeaderOnlyBias_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ToggleLeaderOnlyBias_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USettingsItem_TickBox_C* Button;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__PrioritySpeakerDucking_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__PrioritySpeakerDucking_K2Node_ComponentBoundEvent_1_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.Get_SQUADVOICEBALANCE_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_SQUADVOICEBALANCE_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__EFFECTSNEW_K2Node_ComponentBoundEvent_49_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__EFFECTSNEW_K2Node_ComponentBoundEvent_49_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__SquadVoiceBias_K2Node_ComponentBoundEvent_2_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__SquadVoiceBias_K2Node_ComponentBoundEvent_2_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__MASTERNEW_K2Node_ComponentBoundEvent_33_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__MASTERNEW_K2Node_ComponentBoundEvent_33_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__CommandVoiceBias_K2Node_ComponentBoundEvent_0_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__CommandVoiceBias_K2Node_ComponentBoundEvent_0_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__LOCALVOICENEW_K2Node_ComponentBoundEvent_45_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__LOCALVOICENEW_K2Node_ComponentBoundEvent_45_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__VOICENEW_K2Node_ComponentBoundEvent_30_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__VOICENEW_K2Node_ComponentBoundEvent_30_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.Get_ToggleCOMMANDBEEP_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_ToggleCOMMANDBEEP_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__COMMANDVOICENEW_K2Node_ComponentBoundEvent_27_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__COMMANDVOICENEW_K2Node_ComponentBoundEvent_27_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__OUTOFGAMENEW_K2Node_ComponentBoundEvent_150_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__OUTOFGAMENEW_K2Node_ComponentBoundEvent_150_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__UINEW_K2Node_ComponentBoundEvent_82_OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__UINEW_K2Node_ComponentBoundEvent_82_OnValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__ToggleRADIO_K2Node_ComponentBoundEvent_10_OnClicked__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ToggleRADIO_K2Node_ComponentBoundEvent_10_OnClicked__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USettingsItem_TickBox_C* Button;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__ToggleSQUADBEEP_K2Node_ComponentBoundEvent_9_OnClicked__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ToggleSQUADBEEP_K2Node_ComponentBoundEvent_9_OnClicked__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USettingsItem_TickBox_C* Button;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__ToggleCOMMANDBEEP_K2Node_ComponentBoundEvent_8_OnClicked__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ToggleCOMMANDBEEP_K2Node_ComponentBoundEvent_8_OnClicked__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USettingsItem_TickBox_C* Button;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.BndEvt__AUDIONEW_K2Node_ComponentBoundEvent_51_OnButtonClick__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__AUDIONEW_K2Node_ComponentBoundEvent_51_OnButtonClick__DelegateSignature
{
	int32_t ButtonNumber;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USettingsItem_GraphicsToggle_C* ToggleItem;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.UpdateButtons
// Size: 0xA8(Inherited: 0x0) 
struct FUpdateButtons
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	int32_t Temp_int_Variable_2;  // 0x4(0x4)
	int32_t Temp_int_Variable_3;  // 0x8(0x4)
	int32_t Temp_int_Variable_4;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	int32_t Temp_int_Variable_5;  // 0x1C(0x4)
	struct TArray<struct UObject*> K2Node_MakeArray_Array;  // 0x20(0x10)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x30(0x8)
	struct UObject* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_GetAudioQualityLevel_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct USettingsItem_Slider_LR_C* K2Node_DynamicCast_AsSettings_Item_Slider_LR;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct USettingsItem_Slider_C* K2Node_DynamicCast_AsSettings_Item_Slider;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t K2Node_Select_Default;  // 0x64(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_3;  // 0x80(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x88(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x8C(0x4)
	struct TArray<float> K2Node_MakeArray_Array_2;  // 0x90(0x10)
	float CallFunc_Array_Get_Item_2;  // 0xA0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xA4(0x4)

}; 
// Function AudioWindow.AudioWindow_C.Get_OUTOFGAMENEW_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_OUTOFGAMENEW_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_ToggleSQUADBEEP_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_ToggleSQUADBEEP_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.UpdateSoundDevices
// Size: 0xD8(Inherited: 0x0) 
struct FUpdateSoundDevices
{
	struct FString CurrentAudio;  // 0x0(0x10)
	int32_t L Selected Input Device;  // 0x10(0x4)
	int32_t L Selected Output Device;  // 0x14(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0x28(0x8)
	struct TArray<struct FMediaCaptureDevice> CallFunc_EnumerateAudioCaptureDevices_OutDevices;  // 0x30(0x10)
	struct FString CallFunc_GetActiveAudioInputDevice_OutCurrentDevice;  // 0x40(0x10)
	struct FMediaCaptureDevice CallFunc_Array_Get_Item;  // 0x50(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x80(0x10)
	struct TArray<struct USettingsComboboxItem_C*> K2Node_MakeArray_Array;  // 0x90(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue_2;  // 0xB0(0x8)
	struct TArray<struct FString> CallFunc_GetAvailableAudioOutputDevice_OutAvailableDevice;  // 0xB8(0x10)
	struct FString CallFunc_GetAvailableAudioOutputDevice_OutCurrentDevice;  // 0xC8(0x10)

}; 
// Function AudioWindow.AudioWindow_C.Get_ToggleRADIOFILTER_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_ToggleRADIOFILTER_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_LOCALVOICEVOLUME_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_LOCALVOICEVOLUME_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_AUDIOOUTPUTDEVICE_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_AUDIOOUTPUTDEVICE_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_AUDIOINPUTDEVICE_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_AUDIOINPUTDEVICE_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_COMMANDVOICEVOLUME_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_COMMANDVOICEVOLUME_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_COMMANDVOICEBALANCE_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_COMMANDVOICEBALANCE_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_SQUADVOICEVOLUME_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_SQUADVOICEVOLUME_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_PrioritySpeakerDucking_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_PrioritySpeakerDucking_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AudioWindow.AudioWindow_C.Get_ToggleLeaderOnlyBias_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_ToggleLeaderOnlyBias_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UUMG_Tooltip_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
