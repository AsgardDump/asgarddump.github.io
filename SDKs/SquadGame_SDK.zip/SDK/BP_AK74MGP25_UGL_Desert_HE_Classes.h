#pragma once 
#include <BP_AK74MGP25_UGL_Desert_HE_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74MGP25_UGL_Desert_HE.BP_AK74MGP25_UGL_Desert_HE_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74MGP25_UGL_Desert_HE_C : public ABP_AK74MGP25_UGL_Desert_Parent_C
{

}; 



