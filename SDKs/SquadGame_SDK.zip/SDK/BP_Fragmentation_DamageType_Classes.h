#pragma once 
#include <BP_Fragmentation_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Fragmentation_DamageType.BP_Fragmentation_DamageType_C
// Size: 0x48(Inherited: 0x48) 
struct UBP_Fragmentation_DamageType_C : public USQDamageType
{

}; 



