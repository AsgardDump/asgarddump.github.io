#pragma once 
#include <BP_Crewman_Kits_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Crewman_Kits.BP_Crewman_Kits_C
// Size: 0x80(Inherited: 0x78) 
struct UBP_Crewman_Kits_C : public UBP_DynamicSpecificKits_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x78(0x8)

	void ShouldUseRole(struct UBP_SQRoleSettings_C* In Role, bool& Out ShouldUse); // Function BP_Crewman_Kits.BP_Crewman_Kits_C.ShouldUseRole
	void CreateChildWidgets(struct UBaseRadialMenu_C* BaseRadialMenu); // Function BP_Crewman_Kits.BP_Crewman_Kits_C.CreateChildWidgets
	void ExecuteUbergraph_BP_Crewman_Kits(int32_t EntryPoint); // Function BP_Crewman_Kits.BP_Crewman_Kits_C.ExecuteUbergraph_BP_Crewman_Kits
}; 



