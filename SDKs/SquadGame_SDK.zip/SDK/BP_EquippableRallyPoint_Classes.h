#pragma once 
#include <BP_EquippableRallyPoint_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EquippableRallyPoint.BP_EquippableRallyPoint_C
// Size: 0x4B8(Inherited: 0x460) 
struct ABP_EquippableRallyPoint_C : public ABP_GenericEquippableItem_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x460(0x8)
	struct TMap<char ESQBiome, struct USkeletalMesh*> PerBiomeMesh;  // 0x468(0x50)

	void UserConstructionScript(); // Function BP_EquippableRallyPoint.BP_EquippableRallyPoint_C.UserConstructionScript
	void BPBeginUse(); // Function BP_EquippableRallyPoint.BP_EquippableRallyPoint_C.BPBeginUse
	void Post Place Rally(); // Function BP_EquippableRallyPoint.BP_EquippableRallyPoint_C.Post Place Rally
	void ReceiveBeginPlay(); // Function BP_EquippableRallyPoint.BP_EquippableRallyPoint_C.ReceiveBeginPlay
	void On Rally Created Successfully(); // Function BP_EquippableRallyPoint.BP_EquippableRallyPoint_C.On Rally Created Successfully
	void Attempt Place Rally(); // Function BP_EquippableRallyPoint.BP_EquippableRallyPoint_C.Attempt Place Rally
	void ExecuteUbergraph_BP_EquippableRallyPoint(int32_t EntryPoint); // Function BP_EquippableRallyPoint.BP_EquippableRallyPoint_C.ExecuteUbergraph_BP_EquippableRallyPoint
}; 



