#pragma once 
#include <BP_ForwardBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ForwardBase.BP_ForwardBase_C
// Size: 0x598(Inherited: 0x578) 
struct ABP_ForwardBase_C : public ASQForwardBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x578(0x8)
	struct USQMapIconComponent* SquadMapIcon;  // 0x580(0x8)
	struct TArray<struct FSQFOBDeployableCount> DeployableCount;  // 0x588(0x10)

	void RemoveDeployable(char ESQDeployable InType); // Function BP_ForwardBase.BP_ForwardBase_C.RemoveDeployable
	void AddDeployable(char ESQDeployable InType); // Function BP_ForwardBase.BP_ForwardBase_C.AddDeployable
	void GetDeployableCount(struct TSet<char ESQDeployable> InDeployableTypes, char& OutCount); // Function BP_ForwardBase.BP_ForwardBase_C.GetDeployableCount
	void BP_OnDeployableAdded(struct ASQDeployable* InDeployable); // Function BP_ForwardBase.BP_ForwardBase_C.BP_OnDeployableAdded
	void BP_OnDeployableRemoved(struct ASQDeployable* InDeployable); // Function BP_ForwardBase.BP_ForwardBase_C.BP_OnDeployableRemoved
	void ExecuteUbergraph_BP_ForwardBase(int32_t EntryPoint); // Function BP_ForwardBase.BP_ForwardBase_C.ExecuteUbergraph_BP_ForwardBase
}; 



