#pragma once 
#include "SDK.h" 
 
 
// Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.ExecuteUbergraph_BP_EnemyScalingSpawn
// Size: 0xEC(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EnemyScalingSpawn
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x10(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x18(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x20(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x30(0x88)
	int32_t Temp_int_Variable_2;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_IsSameTeam_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0xC8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xD0(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xD8(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_IsSameTeam_ReturnValue_2 : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xE8(0x4)

}; 
// Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.BndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_351_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_351_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.OnEnemiesInRadiusChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnEnemiesInRadiusChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.BndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_327_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__EnemyDetectionRadius_K2Node_ComponentBoundEvent_327_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.GetRespawnDelay
// Size: 0x10(Inherited: 0x4) 
struct FGetRespawnDelay : public FGetRespawnDelay
{
	float ReturnValue;  // 0x0(0x4)
	float CallFunc_GetRespawnDelay_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)

}; 
// Function BP_EnemyScalingSpawn.BP_EnemyScalingSpawn_C.IsSameTeam
// Size: 0x41(Inherited: 0x0) 
struct FIsSameTeam
{
	struct UObject* Object;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ASQSoldier* K2Node_DynamicCast_AsSQSoldier;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	uint8_t  CallFunc_GetTeam_ReturnValue;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x20(0x8)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_GetTeam_ReturnValue_2;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x40(0x1)

}; 
