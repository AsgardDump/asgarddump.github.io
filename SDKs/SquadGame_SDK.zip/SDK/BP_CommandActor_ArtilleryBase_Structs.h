#pragma once 
#include "SDK.h" 
 
 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Landscape Hit Location
// Size: 0x189(Inherited: 0x0) 
struct FGet Landscape Hit Location
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Success : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x20(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x30(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x3C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x48(0xC)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FHitResult> CallFunc_LineTraceMulti_OutHits;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_LineTraceMulti_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x6C(0x4)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x70(0x88)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xF9(0x1)
	char pad_250_1 : 7;  // 0xFA(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xFA(0x1)
	char pad_251[1];  // 0xFB(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xFC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x100(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x104(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x110(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x11C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x128(0xC)
	char pad_308[4];  // 0x134(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x138(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x140(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x148(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x150(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x158(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x15C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x160(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x164(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x170(0xC)
	char pad_380[4];  // 0x17C(0x4)
	struct ALandscape* K2Node_DynamicCast_AsLandscape;  // 0x180(0x8)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x188(0x1)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.ExecuteUbergraph_BP_CommandActor_ArtilleryBase
// Size: 0xF9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CommandActor_ArtilleryBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Variable;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	struct FVector CallFunc_GetActorUpVector_ReturnValue;  // 0x2C(0xC)
	struct TArray<struct FVector> K2Node_CustomEvent_Locations;  // 0x38(0x10)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x48(0xC)
	struct FVector CallFunc_Array_Get_Item;  // 0x54(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x60(0xC)
	struct FVector CallFunc_RebaseZeroOriginOntoLocal_ReturnValue;  // 0x6C(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x78(0x4)
	int32_t Temp_int_Variable_2;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FVector K2Node_Select_Default;  // 0x84(0xC)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	float CallFunc_BreakVector2D_X;  // 0x98(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x9C(0x4)
	struct TArray<struct FVector> CallFunc_Get_Main_Barrage_Array_Out_Locations;  // 0xA0(0x10)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xB8(0x8)
	struct TArray<struct FVector> CallFunc_Get_Prewarn_Barrage_Array_Out_Locations;  // 0xC0(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0xD0(0x10)
	float CallFunc_BreakVector2D_X_2;  // 0xE0(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0xE4(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0xE8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0xEC(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xF8(0x1)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Fire Projectiles
// Size: 0x10(Inherited: 0x0) 
struct FFire Projectiles
{
	struct TArray<struct FVector> Locations;  // 0x0(0x10)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Main Barrage Array
// Size: 0x4C(Inherited: 0x0) 
struct FGet Main Barrage Array
{
	struct TArray<struct FVector> Out Locations;  // 0x0(0x10)
	struct TArray<struct FVector> Barrage Locations;  // 0x10(0x10)
	int32_t Temp_int_Variable;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x24(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x28(0xC)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x34(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x38(0xC)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x48(0x4)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Randomise Location
// Size: 0x1B8(Inherited: 0x0) 
struct FRandomise Location
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x10(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x14(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x18(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x20(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x30(0xC)
	float CallFunc_Get_Distance_Dist;  // 0x3C(0x4)
	float CallFunc_Get_Radius_Radius;  // 0x40(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x44(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)
	float K2Node_Select_Default;  // 0x50(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x54(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue_5;  // 0x60(0x4)
	float CallFunc_BreakVector_X;  // 0x64(0x4)
	float CallFunc_BreakVector_Y;  // 0x68(0x4)
	float CallFunc_BreakVector_Z;  // 0x6C(0x4)
	float K2Node_Select_Default_2;  // 0x70(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x74(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x80(0x88)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	struct FHitResult CallFunc_K2_AddActorWorldOffset_SweepHitResult;  // 0x10C(0x88)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x194(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x1A0(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x1AC(0xC)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Radius
// Size: 0x4(Inherited: 0x0) 
struct FGet Radius
{
	float Radius;  // 0x0(0x4)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Distance
// Size: 0x4(Inherited: 0x0) 
struct FGet Distance
{
	float Dist;  // 0x0(0x4)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Init Artillery
// Size: 0xC(Inherited: 0x0) 
struct FInit Artillery
{
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x0(0xC)

}; 
// Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Prewarn Barrage Array
// Size: 0x58(Inherited: 0x0) 
struct FGet Prewarn Barrage Array
{
	struct TArray<struct FVector> Out Locations;  // 0x0(0x10)
	struct TArray<struct FVector> Barrage Locations;  // 0x10(0x10)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x20(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x38(0xC)
	char pad_68[4];  // 0x44(0x4)
	struct TArray<struct FVector> K2Node_MakeArray_Array;  // 0x48(0x10)

}; 
