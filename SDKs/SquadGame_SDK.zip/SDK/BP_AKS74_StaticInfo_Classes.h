#pragma once 
#include <BP_AKS74_StaticInfo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74_StaticInfo.BP_AKS74_StaticInfo_C
// Size: 0x9B0(Inherited: 0x9B0) 
struct UBP_AKS74_StaticInfo_C : public UBP_AK74_StaticInfo_C
{

}; 



