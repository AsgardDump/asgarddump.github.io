#pragma once 
#include <BP_EmplacedUB32_Tripod_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C
// Size: 0x9C8(Inherited: 0x994) 
struct ABP_EmplacedUB32_Tripod_C : public ABP_GenericDeployableTripodVehicle_C
{
	char pad_2452[4];  // 0x994(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x998(0x8)
	struct USQArmorMeshComponent* SQArmorMesh2;  // 0x9A0(0x8)
	struct USQArmorMeshComponent* SQArmorMesh;  // 0x9A8(0x8)
	struct UStaticMeshComponent* UB-32_mount;  // 0x9B0(0x8)
	USQVehicleViewWidget* TurretOverlay;  // 0x9B8(0x8)
	struct AController* PlayerControllerRef;  // 0x9C0(0x8)

	void InpActEvt_Focus_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.InpActEvt_Focus_K2Node_InputActionEvent_2
	void InpActEvt_Focus_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.InpActEvt_Focus_K2Node_InputActionEvent_1
	void ReceivePossessed(struct AController* NewController); // Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.ReceivePossessed
	void ReceiveUnpossessed(struct AController* OldController); // Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.ReceiveUnpossessed
	void ExecuteUbergraph_BP_EmplacedUB32_Tripod(int32_t EntryPoint); // Function BP_EmplacedUB32_Tripod.BP_EmplacedUB32_Tripod_C.ExecuteUbergraph_BP_EmplacedUB32_Tripod
}; 



