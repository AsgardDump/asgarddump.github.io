#pragma once 
#include <BP_GameplayFunctionLibrary_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_GameplayFunctionLibrary_C : public UBlueprintFunctionLibrary
{

	void Show Hide Mouse(struct UUserWidget* Focus, bool Game Input, bool Display Input, bool UI Input, bool New Input State, struct FString Reason, struct UObject* __WorldContext); // Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.Show Hide Mouse
	void GetSquadGameMode(struct UObject* __WorldContext, struct ASQGameMode*& Return Value); // Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.GetSquadGameMode
	void GetSquadGameState(struct UObject* __WorldContext, struct ASQGameState*& Return Value); // Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.GetSquadGameState
	void GetSquadPlayerController(int32_t Player Index, struct UObject* __WorldContext, struct ASQPlayerController*& Return Value); // Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.GetSquadPlayerController
}; 



