#pragma once 
#include "SDK.h" 
 
 
// Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.ExecuteUbergraph_BP_DOF_Manager_Effect
// Size: 0xF0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DOF_Manager_Effect
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ASQPlayerController* K2Node_Event_InPlayerController;  // 0x8(0x8)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x20(0x8)
	struct AActor* CallFunc_GetViewTarget_ReturnValue;  // 0x28(0x8)
	struct ASQVehicleSeat* K2Node_DynamicCast_AsSQVehicle_Seat;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ABP_ControlledCamera_C* K2Node_DynamicCast_AsBP_Controlled_Camera;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct ASQDeployableTripodVehicle* K2Node_DynamicCast_AsSQDeployable_Tripod_Vehicle;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct ASQSoldier* K2Node_DynamicCast_AsSQSoldier;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct ASQVehicleSeat* K2Node_DynamicCast_AsSQVehicle_Seat_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float K2Node_Event_DeltaTime;  // 0x7C(0x4)
	struct ASQSoldier* K2Node_Event_SoldierToApplyTo;  // 0x80(0x8)
	struct ASQVehicleTurret* K2Node_DynamicCast_AsSQVehicle_Turret;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct ASQEquipableItem* CallFunc_GetCurrentWeapon_ReturnValue;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_IsAimingDownSights_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct ASQWeapon* K2Node_DynamicCast_AsSQWeapon;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool Temp_bool_Variable : 1;  // 0xB2(0x1)
	char pad_179[1];  // 0xB3(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xB4(0x10)
	char pad_196[4];  // 0xC4(0x4)
	struct USQGameUserSettings* CallFunc_GetSquadGameUserSettings_ReturnValue;  // 0xC8(0x8)
	struct USQGameUserSettings* K2Node_CustomEvent_UserSettings;  // 0xD0(0x8)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0xD8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xDC(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_2;  // 0xE0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xE4(0x4)
	float K2Node_Select_Default;  // 0xE8(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0xEC(0x4)

}; 
// Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.RefreshCachedFOVSetting
// Size: 0x8(Inherited: 0x0) 
struct FRefreshCachedFOVSetting
{
	struct USQGameUserSettings* UserSettings;  // 0x0(0x8)

}; 
// Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.BP_InitCameraEffect
// Size: 0x8(Inherited: 0x8) 
struct FBP_InitCameraEffect : public FBP_InitCameraEffect
{
	struct ASQPlayerController* InPlayerController;  // 0x0(0x8)

}; 
// Function BP_DOF_Manager_Effect.BP_DOF_Manager_Effect_C.BP_ApplyCameraEffect
// Size: 0x10(Inherited: 0x10) 
struct FBP_ApplyCameraEffect : public FBP_ApplyCameraEffect
{
	float DeltaTime;  // 0x0(0x4)
	struct ASQSoldier* SoldierToApplyTo;  // 0x8(0x8)

}; 
