#pragma once 
#include <BP_DynamicRoleChangeModel_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DynamicRoleChangeModel.BP_DynamicRoleChangeModel_C
// Size: 0xC0(Inherited: 0xB8) 
struct UBP_DynamicRoleChangeModel_C : public UBP_BaseRoleChangeModel_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB8(0x8)

	void OnClicked(struct UBaseRadialMenu_C* Radial); // Function BP_DynamicRoleChangeModel.BP_DynamicRoleChangeModel_C.OnClicked
	void Set Role(struct USQRoleSettings* In Role); // Function BP_DynamicRoleChangeModel.BP_DynamicRoleChangeModel_C.Set Role
	void ExecuteUbergraph_BP_DynamicRoleChangeModel(int32_t EntryPoint); // Function BP_DynamicRoleChangeModel.BP_DynamicRoleChangeModel_C.ExecuteUbergraph_BP_DynamicRoleChangeModel
}; 



