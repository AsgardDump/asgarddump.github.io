#pragma once 
#include <BP_CameraManager_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CameraManager.BP_CameraManager_C
// Size: 0x2890(Inherited: 0x2890) 
struct ABP_CameraManager_C : public ASQPlayerCameraManager
{

}; 



