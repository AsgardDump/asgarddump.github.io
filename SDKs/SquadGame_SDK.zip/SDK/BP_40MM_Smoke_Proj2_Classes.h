#pragma once 
#include <BP_40MM_Smoke_Proj2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_40MM_Smoke_Proj2.BP_40MM_Smoke_Proj2_C
// Size: 0x540(Inherited: 0x528) 
struct ABP_40MM_Smoke_Proj2_C : public ABP_40MM_Proj2_C
{
	struct UParticleSystemComponent* Effect;  // 0x528(0x8)
	struct UParticleSystem* SmokeEffect;  // 0x530(0x8)
	struct USoundCue* SmokeSound;  // 0x538(0x8)

}; 



