#pragma once 
#include "SDK.h" 
 
 
// Function BP_DynamicRoleChangeModel.BP_DynamicRoleChangeModel_C.ExecuteUbergraph_BP_DynamicRoleChangeModel
// Size: 0x150(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DynamicRoleChangeModel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_GetRoleEntry_Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FFSQRoleEntry CallFunc_GetRoleEntry_RoleEntry;  // 0x8(0xC0)
	struct UObject* CallFunc_GetDefaultObjectFor_ReturnValue;  // 0xC8(0x8)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0xD0(0x8)
	struct UBP_ChangeRoleAction_C* K2Node_DynamicCast_AsBP_Change_Role_Action;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0xF8(0x8)
	struct UBaseRadialMenu_C* K2Node_Event_Radial;  // 0x100(0x8)
	struct USQRoleSettings* K2Node_CustomEvent_In_Role;  // 0x108(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x110(0x10)
	struct UBP_SQRoleSettings_C* K2Node_DynamicCast_AsBP_SQRole_Settings;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x130(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x140(0x10)

}; 
// Function BP_DynamicRoleChangeModel.BP_DynamicRoleChangeModel_C.Set Role
// Size: 0x8(Inherited: 0x0) 
struct FSet Role
{
	struct USQRoleSettings* In Role;  // 0x0(0x8)

}; 
// Function BP_DynamicRoleChangeModel.BP_DynamicRoleChangeModel_C.OnClicked
// Size: 0x8(Inherited: 0x8) 
struct FOnClicked : public FOnClicked
{
	struct UBaseRadialMenu_C* Radial;  // 0x0(0x8)

}; 
