#pragma once 
#include <BP_BleedingCameraEffect_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BleedingCameraEffect.BP_BleedingCameraEffect_C
// Size: 0x5C0(Inherited: 0x5A0) 
struct UBP_BleedingCameraEffect_C : public USQLocalCameraEffectHandler
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x5A0(0x8)
	struct ASQPlayerController* PlayerController;  // 0x5A8(0x8)
	struct UMaterialInstanceDynamic* Mid;  // 0x5B0(0x8)
	char pad_1464_1 : 7;  // 0x5B8(0x1)
	bool BlendTarget : 1;  // 0x5B8(0x1)
	char pad_1465[3];  // 0x5B9(0x3)
	float BlendWeight;  // 0x5BC(0x4)

	void BP_ApplyCameraEffect(float DeltaTime, struct ASQSoldier* SoldierToApplyTo); // Function BP_BleedingCameraEffect.BP_BleedingCameraEffect_C.BP_ApplyCameraEffect
	void BP_InitCameraEffect(struct ASQPlayerController* InPlayerController); // Function BP_BleedingCameraEffect.BP_BleedingCameraEffect_C.BP_InitCameraEffect
	void ExecuteUbergraph_BP_BleedingCameraEffect(int32_t EntryPoint); // Function BP_BleedingCameraEffect.BP_BleedingCameraEffect_C.ExecuteUbergraph_BP_BleedingCameraEffect
}; 



