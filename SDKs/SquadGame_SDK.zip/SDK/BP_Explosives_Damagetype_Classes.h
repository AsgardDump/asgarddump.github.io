#pragma once 
#include <BP_Explosives_Damagetype_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Explosives_Damagetype.BP_Explosives_Damagetype_C
// Size: 0x48(Inherited: 0x48) 
struct UBP_Explosives_Damagetype_C : public USQDamageType
{

}; 



