#pragma once 
#include <BP_Attachment_M110_Front_Black_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_M110_Front_Black.BP_Attachment_M110_Front_Black_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_M110_Front_Black_C : public USQWeaponAttachment_Scope
{

}; 



