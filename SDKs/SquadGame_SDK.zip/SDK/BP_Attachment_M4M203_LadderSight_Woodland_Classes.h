#pragma once 
#include <BP_Attachment_M4M203_LadderSight_Woodland_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Attachment_M4M203_LadderSight_Woodland.BP_Attachment_M4M203_LadderSight_Woodland_C
// Size: 0x5A0(Inherited: 0x5A0) 
struct UBP_Attachment_M4M203_LadderSight_Woodland_C : public UBP_Attachment_M4M203_LadderSight_C
{

}; 



