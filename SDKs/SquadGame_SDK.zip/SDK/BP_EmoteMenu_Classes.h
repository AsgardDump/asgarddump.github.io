#pragma once 
#include <BP_EmoteMenu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmoteMenu.BP_EmoteMenu_C
// Size: 0x68(Inherited: 0x58) 
struct UBP_EmoteMenu_C : public UBP_RadialMenuModel_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x58(0x8)
	struct UBaseRadialMenu_C* Radial;  // 0x60(0x8)

	void CreateChildEntries(struct UBaseRadialMenu_C* BaseRadial); // Function BP_EmoteMenu.BP_EmoteMenu_C.CreateChildEntries
	void CreateChildWidgets(struct UBaseRadialMenu_C* BaseRadialMenu); // Function BP_EmoteMenu.BP_EmoteMenu_C.CreateChildWidgets
	void ExecuteUbergraph_BP_EmoteMenu(int32_t EntryPoint); // Function BP_EmoteMenu.BP_EmoteMenu_C.ExecuteUbergraph_BP_EmoteMenu
}; 



