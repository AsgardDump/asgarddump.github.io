#pragma once 
#include "SDK.h" 
 
 
// Function BP_EmplacedUB32.BP_EmplacedUB32_C.ExecuteUbergraph_BP_EmplacedUB32
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EmplacedUB32
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FVector K2Node_Event_Origin;  // 0x8(0xC)

}; 
// Function BP_EmplacedUB32.BP_EmplacedUB32_C.BlueprintOnFire
// Size: 0xC(Inherited: 0xC) 
struct FBlueprintOnFire : public FBlueprintOnFire
{
	struct FVector Origin;  // 0x0(0xC)

}; 
