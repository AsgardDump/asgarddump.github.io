#pragma once 
#include <BP_AK74_Tracer_Founder_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74_Tracer_Founder.BP_AK74_Tracer_Founder_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74_Tracer_Founder_C : public ABP_AK74_Tracer_C
{

}; 



