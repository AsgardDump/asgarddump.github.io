#pragma once 
#include <BlockoutToolsPlugin_Structs.h>
 
 
 
// Class BlockoutToolsPlugin.BlockoutToolsParent
// Size: 0x2C0(Inherited: 0x228) 
struct ABlockoutToolsParent : public AActor
{
	struct USceneComponent* Root;  // 0x228(0x8)
	struct UBillboardComponent* Billboard;  // 0x230(0x8)
	struct UMaterialInterface* BlockoutGridParent;  // 0x238(0x8)
	struct UMaterialInstanceDynamic* BlockoutGridMID;  // 0x240(0x8)
	struct UMaterialInterface* BlockoutCurrentMaterial;  // 0x248(0x8)
	struct TArray<struct UStaticMeshComponent*> BlockoutMeshComponents;  // 0x250(0x10)
	char EBlockoutMaterialType BlockoutMaterialType;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	struct FLinearColor BlockoutMaterialColor;  // 0x264(0x10)
	char pad_628_1 : 7;  // 0x274(0x1)
	bool bBlockoutMaterialUseGrid : 1;  // 0x274(0x1)
	char pad_629_1 : 7;  // 0x275(0x1)
	bool bBlockoutWorldAligned : 1;  // 0x275(0x1)
	char pad_630[2];  // 0x276(0x2)
	float BlockoutMaterialGridSize;  // 0x278(0x4)
	float BlockoutMaterialCheckerLuminance;  // 0x27C(0x4)
	float BlockoutMaterialRoughness;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool bBlockoutMaterialUseTopColor : 1;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct FLinearColor BlockoutMaterialTopColor;  // 0x288(0x10)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool bUseCustomMaterial : 1;  // 0x298(0x1)
	char pad_665[7];  // 0x299(0x7)
	struct UMaterialInterface* CustomMaterial;  // 0x2A0(0x8)
	struct UMaterialInterface* BlockoutCustomMaterial;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool bBlockoutEnableCollisions : 1;  // 0x2B0(0x1)
	char pad_689_1 : 7;  // 0x2B1(0x1)
	bool bBlockoutEnableCustomCollision : 1;  // 0x2B1(0x1)
	char pad_690[2];  // 0x2B2(0x2)
	struct FName BlockoutCustomCollisionProfileName;  // 0x2B4(0x8)
	char pad_700_1 : 7;  // 0x2BC(0x1)
	bool bBlockoutCastShadows : 1;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)

	void RerunConstructionScript(); // Function BlockoutToolsPlugin.BlockoutToolsParent.RerunConstructionScript
	void BlockoutSetMaterial(); // Function BlockoutToolsPlugin.BlockoutToolsParent.BlockoutSetMaterial
}; 



// Class BlockoutToolsPlugin.BlockoutToolsSettings
// Size: 0x60(Inherited: 0x28) 
struct UBlockoutToolsSettings : public UObject
{
	char EBlockoutMaterialType BlockoutMaterialType;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor BlockoutMaterialColor;  // 0x2C(0x10)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bBlockoutMaterialUseGrid : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool bBlockoutWorldAligned : 1;  // 0x3D(0x1)
	char pad_62[2];  // 0x3E(0x2)
	float BlockoutMaterialGridSize;  // 0x40(0x4)
	float BlockoutMaterialCheckerLuminance;  // 0x44(0x4)
	float BlockoutMaterialRoughness;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bBlockoutMaterialUseTopColor : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FLinearColor BlockoutMaterialTopColor;  // 0x50(0x10)

}; 



