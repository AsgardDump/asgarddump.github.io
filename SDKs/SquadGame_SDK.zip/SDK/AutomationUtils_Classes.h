#pragma once 
#include <AutomationUtils_Structs.h>
 
 
 
// Class AutomationUtils.AutomationUtilsBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAutomationUtilsBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void TakeGameplayAutomationScreenshot(struct FString ScreenshotName, float MaxGlobalError, float MaxLocalError, struct FString MapNameOverride); // Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot
}; 



