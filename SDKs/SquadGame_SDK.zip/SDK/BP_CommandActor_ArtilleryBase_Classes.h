#pragma once 
#include <BP_CommandActor_ArtilleryBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C
// Size: 0x2C0(Inherited: 0x268) 
struct ABP_CommandActor_ArtilleryBase_C : public ABP_CommandActor_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	float Max Drop Radius;  // 0x270(0x4)
	char pad_628_1 : 7;  // 0x274(0x1)
	bool Edge Only : 1;  // 0x274(0x1)
	char pad_629[3];  // 0x275(0x3)
	int32_t Pre Warning Shells;  // 0x278(0x4)
	float Pre Warning Delay;  // 0x27C(0x4)
	int32_t Shells Per Barrage;  // 0x280(0x4)
	int32_t Barrage Count;  // 0x284(0x4)
	struct FVector2D Barrage Interval;  // 0x288(0x8)
	float First Barrage Height Variance;  // 0x290(0x4)
	float Main Barrage Height Variance;  // 0x294(0x4)
	int32_t Current Prewarning Shells;  // 0x298(0x4)
	int32_t Current Barrage;  // 0x29C(0x4)
	struct FVector Origin Location;  // 0x2A0(0xC)
	struct FVector Target Location;  // 0x2AC(0xC)
	ASQMortarProjectile* Projectile;  // 0x2B8(0x8)

	void Get Prewarn Barrage Array(struct TArray<struct FVector>& Out Locations); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Prewarn Barrage Array
	void Get Main Barrage Array(struct TArray<struct FVector>& Out Locations); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Main Barrage Array
	void Init Artillery(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Init Artillery
	void Get Distance(float& Dist); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Distance
	void Get Radius(float& Radius); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Radius
	void Randomise Location(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Randomise Location
	void OnRep_Start Move(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.OnRep_Start Move
	void Get Landscape Hit Location(struct FVector& Location, bool& Success); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Get Landscape Hit Location
	void ReceiveBeginPlay(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.ReceiveBeginPlay
	void Server Projectiles(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Server Projectiles
	void Fire Projectiles(struct TArray<struct FVector>& Locations); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Fire Projectiles
	void Server End Active Duration(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Server End Active Duration
	void Server Start Active Duration(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Server Start Active Duration
	void Server Prewarning Projectiles(); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.Server Prewarning Projectiles
	void ExecuteUbergraph_BP_CommandActor_ArtilleryBase(int32_t EntryPoint); // Function BP_CommandActor_ArtilleryBase.BP_CommandActor_ArtilleryBase_C.ExecuteUbergraph_BP_CommandActor_ArtilleryBase
}; 



