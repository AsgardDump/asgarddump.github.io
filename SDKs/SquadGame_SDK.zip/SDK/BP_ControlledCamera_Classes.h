#pragma once 
#include <BP_ControlledCamera_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ControlledCamera.BP_ControlledCamera_C
// Size: 0x300(Inherited: 0x228) 
struct ABP_ControlledCamera_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x228(0x8)
	struct UCameraComponent* Camera;  // 0x230(0x8)
	struct USceneComponent* Scene;  // 0x238(0x8)
	struct USceneComponent* Pitch;  // 0x240(0x8)
	struct USceneComponent* Yaw;  // 0x248(0x8)
	float Desired Zoom;  // 0x250(0x4)
	char pad_596[4];  // 0x254(0x4)
	struct ASQPlayerController* My SQPC;  // 0x258(0x8)
	struct UTexture2D* Button Icon;  // 0x260(0x8)
	struct UW_CamControlButton_C* Cam Control Button;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool Is Active : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)
	struct FMulticastInlineDelegate Created Button;  // 0x278(0x10)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool ExtraSpeed : 1;  // 0x288(0x1)
	char pad_649[7];  // 0x289(0x7)
	struct AActor* Follow Actor;  // 0x290(0x8)
	float Battery Percent;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	USQGridData_CommandOption* Action;  // 0x2A0(0x8)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Can Possess : 1;  // 0x2A8(0x1)
	char pad_681[7];  // 0x2A9(0x7)
	UW_CameraWidget_C* Camera Widget;  // 0x2B0(0x8)
	float Min Pitch;  // 0x2B8(0x4)
	float Max Pitch;  // 0x2BC(0x4)
	struct UW_CameraWidget_C* W_CameraUI;  // 0x2C0(0x8)
	float Min Yaw;  // 0x2C8(0x4)
	float Max Yaw;  // 0x2CC(0x4)
	int32_t Zoom Level;  // 0x2D0(0x4)
	float Cam Rotate Speed;  // 0x2D4(0x4)
	struct TArray<float> Zoom Levels;  // 0x2D8(0x10)
	struct USoundBase* Open Sound;  // 0x2E8(0x8)
	struct USoundBase* Close Sound;  // 0x2F0(0x8)
	float NearClipPlaneDistance;  // 0x2F8(0x4)
	float LastNearClipPlaneDistance;  // 0x2FC(0x4)

	void Can Become View Target(bool& Can View); // Function BP_ControlledCamera.BP_ControlledCamera_C.Can Become View Target
	void Init Camera(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Init Camera
	void Check Soldier Wound(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Check Soldier Wound
	void Create Stabilisation Point(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Create Stabilisation Point
	void Update Follow(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Update Follow
	void Find Vehicle(bool& Found Vehicle); // Function BP_ControlledCamera.BP_ControlledCamera_C.Find Vehicle
	void Update Zoom(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Update Zoom
	void Clamp Camera Rotation(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Clamp Camera Rotation
	void Add Camera Movement(float X Delta, float Y Delta); // Function BP_ControlledCamera.BP_ControlledCamera_C.Add Camera Movement
	void Add Zoom Delta(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Add Zoom Delta
	void InpActEvt_LeanLeft_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_LeanLeft_K2Node_InputActionEvent_5
	void InpActEvt_Sprint_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_Sprint_K2Node_InputActionEvent_4
	void InpActEvt_Sprint_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_Sprint_K2Node_InputActionEvent_3
	void InpActEvt_ToggleStabilization_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_ToggleStabilization_K2Node_InputActionEvent_2
	void InpActEvt_Interact_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_ControlledCamera.BP_ControlledCamera_C.InpActEvt_Interact_K2Node_InputActionEvent_1
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_ControlledCamera.BP_ControlledCamera_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
	void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_ControlledCamera.BP_ControlledCamera_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
	void ReceiveTick(float DeltaSeconds); // Function BP_ControlledCamera.BP_ControlledCamera_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_ControlledCamera.BP_ControlledCamera_C.ReceiveBeginPlay
	void Toggle View(bool Active); // Function BP_ControlledCamera.BP_ControlledCamera_C.Toggle View
	void K2_OnBecomeViewTarget(struct APlayerController* PC); // Function BP_ControlledCamera.BP_ControlledCamera_C.K2_OnBecomeViewTarget
	void K2_OnEndViewTarget(struct APlayerController* PC); // Function BP_ControlledCamera.BP_ControlledCamera_C.K2_OnEndViewTarget
	void Disable Cam(); // Function BP_ControlledCamera.BP_ControlledCamera_C.Disable Cam
	void ExecuteUbergraph_BP_ControlledCamera(int32_t EntryPoint); // Function BP_ControlledCamera.BP_ControlledCamera_C.ExecuteUbergraph_BP_ControlledCamera
	void Created Button__DelegateSignature(struct UW_CamControlButton_C* Cam Button); // Function BP_ControlledCamera.BP_ControlledCamera_C.Created Button__DelegateSignature
}; 



