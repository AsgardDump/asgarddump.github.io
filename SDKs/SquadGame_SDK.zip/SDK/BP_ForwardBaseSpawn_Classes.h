#pragma once 
#include <BP_ForwardBaseSpawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ForwardBaseSpawn.BP_ForwardBaseSpawn_C
// Size: 0x400(Inherited: 0x400) 
struct ABP_ForwardBaseSpawn_C : public ASQGameSpawn
{

}; 



