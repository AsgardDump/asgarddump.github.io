#pragma once 
#include <BP_attachment_RailCovers_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_attachment_RailCovers.BP_attachment_RailCovers_C
// Size: 0x500(Inherited: 0x500) 
struct UBP_attachment_RailCovers_C : public USQWeaponAttachment
{

}; 



