#pragma once 
#include "SDK.h" 
 
 
// Function BP_BackToPreviousMenuAction.BP_BackToPreviousMenuAction_C.ExecuteUbergraph_BP_BackToPreviousMenuAction
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BackToPreviousMenuAction
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBaseRadialMenu_C* K2Node_Event_Raidal_Menu;  // 0x8(0x8)

}; 
// Function BP_BackToPreviousMenuAction.BP_BackToPreviousMenuAction_C.OnClicked
// Size: 0x8(Inherited: 0x8) 
struct FOnClicked : public FOnClicked
{
	struct UBaseRadialMenu_C* Raidal Menu;  // 0x0(0x8)

}; 
// Function BP_BackToPreviousMenuAction.BP_BackToPreviousMenuAction_C.CanClick
// Size: 0x11(Inherited: 0x14) 
struct FCanClick : public FCanClick
{
	struct APlayerController* Controller;  // 0x0(0x8)
	struct UBP_RadialItemModel_C* Model;  // 0x8(0x8)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CanClick : 1;  // 0x10(0x1)

}; 
