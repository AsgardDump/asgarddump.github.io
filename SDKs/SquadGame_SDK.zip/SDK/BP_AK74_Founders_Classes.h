#pragma once 
#include <BP_AK74_Founders_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74_Founders.BP_AK74_Founders_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74_Founders_C : public ABP_AK74_C
{

}; 



