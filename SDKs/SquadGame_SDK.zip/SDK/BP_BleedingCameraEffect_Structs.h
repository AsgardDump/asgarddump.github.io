#pragma once 
#include "SDK.h" 
 
 
// Function BP_BleedingCameraEffect.BP_BleedingCameraEffect_C.ExecuteUbergraph_BP_BleedingCameraEffect
// Size: 0xB1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BleedingCameraEffect
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ASQPlayerController* K2Node_Event_InPlayerController;  // 0x8(0x8)
	float K2Node_Event_DeltaTime;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct ASQSoldier* K2Node_Event_SoldierToApplyTo;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_Conv_BoolToFloat_ReturnValue;  // 0x34(0x4)
	struct FWeightedBlendable K2Node_MakeStruct_WeightedBlendable;  // 0x38(0x10)
	struct TArray<struct FWeightedBlendable> K2Node_MakeArray_Array;  // 0x48(0x10)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float CallFunc_FInterpTo_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x78(0x8)
	struct AActor* CallFunc_GetViewTarget_ReturnValue;  // 0x80(0x8)
	struct ASQVehicleSeat* K2Node_DynamicCast_AsSQVehicle_Seat;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct ABP_ControlledCamera_C* K2Node_DynamicCast_AsBP_Controlled_Camera;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct ASQSoldier* K2Node_DynamicCast_AsSQSoldier;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xB0(0x1)

}; 
// Function BP_BleedingCameraEffect.BP_BleedingCameraEffect_C.BP_InitCameraEffect
// Size: 0x8(Inherited: 0x8) 
struct FBP_InitCameraEffect : public FBP_InitCameraEffect
{
	struct ASQPlayerController* InPlayerController;  // 0x0(0x8)

}; 
// Function BP_BleedingCameraEffect.BP_BleedingCameraEffect_C.BP_ApplyCameraEffect
// Size: 0x10(Inherited: 0x10) 
struct FBP_ApplyCameraEffect : public FBP_ApplyCameraEffect
{
	float DeltaTime;  // 0x0(0x4)
	struct ASQSoldier* SoldierToApplyTo;  // 0x8(0x8)

}; 
