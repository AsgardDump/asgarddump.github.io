#pragma once 
#include <BP_AKS74_1P29_Tracer_Founders_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AKS74_1P29_Tracer_Founders.BP_AKS74_1P29_Tracer_Founders_C
// Size: 0x7E8(Inherited: 0x7E8) 
struct ABP_AKS74_1P29_Tracer_Founders_C : public ABP_AKS74_1P29_Tracer_C
{

}; 



