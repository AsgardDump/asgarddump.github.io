#pragma once 
#include "SDK.h" 
 
 
// Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.GetSquadGameState
// Size: 0x21(Inherited: 0x0) 
struct FGetSquadGameState
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct ASQGameState* Return Value;  // 0x8(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	struct ASQGameState* K2Node_DynamicCast_AsSQGame_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.GetSquadPlayerController
// Size: 0x29(Inherited: 0x0) 
struct FGetSquadPlayerController
{
	int32_t Player Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct ASQPlayerController* Return Value;  // 0x10(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x18(0x8)
	struct ASQPlayerController* K2Node_DynamicCast_AsSQPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.GetSquadGameMode
// Size: 0x21(Inherited: 0x0) 
struct FGetSquadGameMode
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct ASQGameMode* Return Value;  // 0x8(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	struct ASQGameMode* K2Node_DynamicCast_AsSQGame_Mode;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_GameplayFunctionLibrary.BP_GameplayFunctionLibrary_C.Show Hide Mouse
// Size: 0xE9(Inherited: 0x0) 
struct FShow Hide Mouse
{
	struct UUserWidget* Focus;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Game Input : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Display Input : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool UI Input : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool New Input State : 1;  // 0xB(0x1)
	char pad_12[4];  // 0xC(0x4)
	struct FString Reason;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct ASQPlayerController* L PC;  // 0x28(0x8)
	struct ASQPlayerController* CallFunc_GetSquadPlayerController_Return_Value;  // 0x30(0x8)
	struct ASQPlayerController* CallFunc_GetSquadPlayerController_Return_Value_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x48(0x8)
	struct ASQHUD* K2Node_DynamicCast_AsSQHUD;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FSQInputState K2Node_MakeStruct_SQInputState;  // 0x60(0x20)
	struct FSQInputState CallFunc_RemoveInputStackState_ReturnValue;  // 0x80(0x20)
	struct FSQInputState CallFunc_AddInputStackState_ReturnValue;  // 0xA0(0x20)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool Temp_bool_Variable : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct FSQInputState K2Node_Select_Default;  // 0xC8(0x20)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xE8(0x1)

}; 
