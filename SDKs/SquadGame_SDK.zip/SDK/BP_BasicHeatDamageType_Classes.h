#pragma once 
#include <BP_BasicHeatDamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BasicHeatDamageType.BP_BasicHeatDamageType_C
// Size: 0x48(Inherited: 0x48) 
struct UBP_BasicHeatDamageType_C : public USQDamageType
{

}; 



