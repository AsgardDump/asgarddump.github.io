#pragma once 
#include <BP_AK74M_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AK74M.BP_AK74M_C
// Size: 0x7D0(Inherited: 0x7D0) 
struct ABP_AK74M_C : public ABP_AK74_C
{

}; 



