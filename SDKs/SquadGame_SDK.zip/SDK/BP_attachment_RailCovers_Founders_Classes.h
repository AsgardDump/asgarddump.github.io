#pragma once 
#include <BP_attachment_RailCovers_Founders_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_attachment_RailCovers_Founders.BP_attachment_RailCovers_Founders_C
// Size: 0x500(Inherited: 0x500) 
struct UBP_attachment_RailCovers_Founders_C : public UBP_attachment_RailCovers_C
{

}; 



