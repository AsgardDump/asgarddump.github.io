#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPPostTicketTick
// Size: 0x4(Inherited: 0x4) 
struct FBPPostTicketTick : public FBPPostTicketTick
{
	float Difference;  // 0x0(0x4)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.UserConstructionScript
// Size: 0x48(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FTransform CallFunc_GetRelativeTransform_ReturnValue;  // 0x10(0x30)
	struct UParticleSystemComponent* CallFunc_AddComponent_ReturnValue;  // 0x40(0x8)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPStopUsed
// Size: 0x8(Inherited: 0x8) 
struct FBPStopUsed : public FBPStopUsed
{
	struct AController* User;  // 0x0(0x8)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.ExecuteUbergraph_BP_BaseFobCreator
// Size: 0xA8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseFobCreator
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_K2_TimerExistsHandle_ReturnValue : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_IsGhost_ReturnValue : 1;  // 0x23(0x1)
	int32_t Temp_int_Variable;  // 0x24(0x4)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct AController* K2Node_Event_User_2;  // 0x30(0x8)
	struct AController* K2Node_Event_User;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_Event_bFriendly : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float K2Node_Event_Difference;  // 0x44(0x4)
	struct ASQGameSpawn* CallFunc_Array_Get_Item;  // 0x48(0x8)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x50(0x10)
	struct ABP_ForwardBaseSpawn_C* K2Node_DynamicCast_AsBP_Forward_Base_Spawn;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct AActor* CallFunc_Array_Get_Item_2;  // 0x70(0x8)
	struct ASQSoldier* K2Node_DynamicCast_AsSQSoldier;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t CallFunc_GetTeam_ReturnValue;  // 0x84(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x92(0x1)
	char pad_147[1];  // 0x93(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsGhost_ReturnValue_2 : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x9C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xA0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xA4(0x4)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPOverrun
// Size: 0x1(Inherited: 0x1) 
struct FBPOverrun : public FBPOverrun
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bFriendly : 1;  // 0x0(0x1)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.BPOnUsed
// Size: 0x8(Inherited: 0x8) 
struct FBPOnUsed : public FBPOnUsed
{
	struct AController* User;  // 0x0(0x8)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.Remove Nearby FOB Request Markers
// Size: 0xD0(Inherited: 0x0) 
struct FRemove Nearby FOB Request Markers
{
	float Radius;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USQMapMarkerManagerComponent* MarkerManager;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct UBP_SQLayer_C* CallFunc_TryGetCurrentLayer_OutLayer;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_TryGetCurrentLayer_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FDataTableRowHandle CallFunc_GetFobRadiusTableRow_ReturnValue;  // 0x28(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x38(0xC)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_IsGhost_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FS_FOBRadius CallFunc_GetDataTableRowFromName_OutRow;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct TArray<struct FSQMapMarkerGameplayData> CallFunc_FindMapMarkersByType_OutMarkers;  // 0x58(0x10)
	struct FSQMapMarkerGameplayData CallFunc_Array_Get_Item;  // 0x68(0x38)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	int32_t CallFunc_GetTeamId_ReturnValue;  // 0xA4(0x4)
	char CallFunc_Conv_IntToByte_ReturnValue;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float CallFunc_Vector_Distance2D_ReturnValue;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB9(0x1)
	char pad_186[2];  // 0xBA(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xBC(0x4)
	struct ASQGameState* CallFunc_GetSquadGameState_Return_Value;  // 0xC0(0x8)
	struct USQMapMarkerManagerComponent* CallFunc_GetMarkerManager_ReturnValue;  // 0xC8(0x8)

}; 
// Function BP_BaseFobCreator.BP_BaseFobCreator_C.GetUsableData
// Size: 0x98(Inherited: 0x40) 
struct FGetUsableData : public FGetUsableData
{
	struct FSQUsableData ReturnValue;  // 0x0(0x40)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool Temp_bool_Variable : 1;  // 0x40(0x1)
	struct ASQPlayerController* CallFunc_GetSquadPlayerController_Return_Value;  // 0x48(0x8)
	int32_t CallFunc_GetTeam_ReturnValue;  // 0x50(0x4)
	char pad_141_1 : 7;  // 0x8D(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x54(0x1)
	struct FSQUsableData K2Node_Select_Default;  // 0x58(0x40)

}; 
