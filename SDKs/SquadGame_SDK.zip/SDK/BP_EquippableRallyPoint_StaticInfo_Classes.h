#pragma once 
#include <BP_EquippableRallyPoint_StaticInfo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EquippableRallyPoint_StaticInfo.BP_EquippableRallyPoint_StaticInfo_C
// Size: 0x558(Inherited: 0x558) 
struct UBP_EquippableRallyPoint_StaticInfo_C : public UBP_GenericDeployableItem_StaticInfo_C
{

}; 



