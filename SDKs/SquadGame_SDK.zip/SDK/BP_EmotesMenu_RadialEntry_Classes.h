#pragma once 
#include <BP_EmotesMenu_RadialEntry_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EmotesMenu_RadialEntry.BP_EmotesMenu_RadialEntry_C
// Size: 0xBC(Inherited: 0xA8) 
struct UBP_EmotesMenu_RadialEntry_C : public UBP_RadialActionModel_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct USQEmotesData* EmoteItem;  // 0xB0(0x8)
	int32_t EmoteIndex;  // 0xB8(0x4)

	struct TArray<struct FString> CanClick(struct ASQPlayerController* PC, bool& bCanClick); // Function BP_EmotesMenu_RadialEntry.BP_EmotesMenu_RadialEntry_C.CanClick
	void OnClicked(struct UBaseRadialMenu_C* Radial); // Function BP_EmotesMenu_RadialEntry.BP_EmotesMenu_RadialEntry_C.OnClicked
	void ExecuteUbergraph_BP_EmotesMenu_RadialEntry(int32_t EntryPoint); // Function BP_EmotesMenu_RadialEntry.BP_EmotesMenu_RadialEntry_C.ExecuteUbergraph_BP_EmotesMenu_RadialEntry
}; 



