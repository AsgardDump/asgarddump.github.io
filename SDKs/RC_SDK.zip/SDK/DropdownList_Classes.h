#pragma once 
#include <DropdownList_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DropdownList.DropdownList_C
// Size: 0x5A8(Inherited: 0x528) 
struct UDropdownList_C : public UKSWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x528(0x8)
	struct UButton* ClickBlocker;  // 0x530(0x8)
	struct UScrollBox* DropdownScroll;  // 0x538(0x8)
	struct USizeBox* SizeBox_1;  // 0x540(0x8)
	struct TArray<struct FText> Options;  // 0x548(0x10)
	struct FMulticastInlineDelegate OnSelection;  // 0x558(0x10)
	struct FMulticastInlineDelegate OnCancel;  // 0x568(0x10)
	struct TArray<struct UDropdownEntry_C*> DropdownEntries;  // 0x578(0x10)
	struct UDropdownEntry_C* SelectedEntry;  // 0x588(0x8)
	float SizeBoxMaxHeight;  // 0x590(0x4)
	char pad_1428[4];  // 0x594(0x4)
	struct FMulticastInlineDelegate OnHoverPreview;  // 0x598(0x10)

	bool NavigateBack(); // Function DropdownList.DropdownList_C.NavigateBack
	void InitializeWidget(struct APUMG_HUD* HUD); // Function DropdownList.DropdownList_C.InitializeWidget
	void Selection(int32_t Index, struct FText Text); // Function DropdownList.DropdownList_C.Selection
	void InitializeWidgetNavigation(); // Function DropdownList.DropdownList_C.InitializeWidgetNavigation
	void HandleOnHover(struct UWidget* Widget, int32_t Index); // Function DropdownList.DropdownList_C.HandleOnHover
	void SetSelectedEntryByIndex(int32_t Index); // Function DropdownList.DropdownList_C.SetSelectedEntryByIndex
	void BndEvt__Button_123_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DropdownList.DropdownList_C.BndEvt__Button_123_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_DropdownList(int32_t EntryPoint); // Function DropdownList.DropdownList_C.ExecuteUbergraph_DropdownList
	void OnHoverPreview__DelegateSignature(int32_t Index); // Function DropdownList.DropdownList_C.OnHoverPreview__DelegateSignature
	void OnCancel__DelegateSignature(); // Function DropdownList.DropdownList_C.OnCancel__DelegateSignature
	void OnSelection__DelegateSignature(int32_t Index, struct FText Text); // Function DropdownList.DropdownList_C.OnSelection__DelegateSignature
}; 



