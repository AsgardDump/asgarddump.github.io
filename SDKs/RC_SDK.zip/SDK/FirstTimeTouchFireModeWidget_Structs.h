#pragma once 
#include "SDK.h" 
 
 
// Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.ExecuteUbergraph_FirstTimeTouchFireModeWidget
// Size: 0x129(Inherited: 0x0) 
struct FExecuteUbergraph_FirstTimeTouchFireModeWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UWidget* K2Node_ComponentBoundEvent_Widget;  // 0x8(0x8)
	struct UAkAudioEvent* Temp_object_Variable;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x20(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x28(0x8)
	struct UKSGameUserSettings* K2Node_DynamicCast_AsKSGame_User_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x40(0x8)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_Remove_Top_View_Route_ViewChanged : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool Temp_bool_Variable : 1;  // 0x52(0x1)
	char pad_83[1];  // 0x53(0x1)
	struct FDelegate Temp_delegate_Variable;  // 0x54(0x10)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_GetFontByName_HasFound : 1;  // 0x65(0x1)
	char pad_102[2];  // 0x66(0x2)
	struct FSlateFontInfo CallFunc_GetFontByName_FontInfo;  // 0x68(0x50)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_GetColorByName_HasFound : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	struct FLinearColor CallFunc_GetColorByName_Color;  // 0xBC(0x10)
	char pad_204[4];  // 0xCC(0x4)
	struct UOverlaySlot* CallFunc_AddChildToOverlay_ReturnValue;  // 0xD0(0x8)
	struct UWBP_SettingsEntryList_C* K2Node_DynamicCast_AsWBP_Settings_Entry_List;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct UKSSettingsWidget* CallFunc_CreateSettingsWidgetWithConfig_ReturnValue;  // 0xF8(0x8)
	struct UAkAudioEvent* K2Node_Select_Default;  // 0x100(0x8)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x108(0x10)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x118(0x4)
	char pad_284[4];  // 0x11C(0x4)
	struct UWBP_SettingsEntryList_C* K2Node_DynamicCast_AsWBP_Settings_Entry_List_2;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x128(0x1)

}; 
// Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.BndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
{
	struct UWidget* Widget;  // 0x0(0x8)

}; 
// Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
// Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
