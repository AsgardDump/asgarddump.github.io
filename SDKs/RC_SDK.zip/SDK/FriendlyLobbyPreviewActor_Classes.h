#pragma once 
#include <FriendlyLobbyPreviewActor_Structs.h>
 
 
 
// BlueprintGeneratedClass FriendlyLobbyPreviewActor.FriendlyLobbyPreviewActor_C
// Size: 0x5D0(Inherited: 0x5C8) 
struct AFriendlyLobbyPreviewActor_C : public AKSJobSelectPreviewActor_Lobby
{
	struct UPlayerInfoPrevwLoadoutComponent* PlayerInfoLoadoutComponent;  // 0x5C8(0x8)

}; 



