#pragma once 
#include <FriendlyLobbyCharacter_Structs.h>
 
 
 
// BlueprintGeneratedClass FriendlyLobbyCharacter.FriendlyLobbyCharacter_C
// Size: 0x3F98(Inherited: 0x3F74) 
struct AFriendlyLobbyCharacter_C : public ALobbyMainCharacter_C
{
	char pad_16244[4];  // 0x3F74(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F78(0x8)
	struct UWidgetComponent* WidgetNameplate;  // 0x3F80(0x8)
	char pad_16264_1 : 7;  // 0x3F88(0x1)
	bool NeedsToSetNameplate : 1;  // 0x3F88(0x1)
	char pad_16265[7];  // 0x3F89(0x7)
	struct UKSPlayerInfo* PendingPlayerInfo;  // 0x3F90(0x8)

	void ReceiveTick(float DeltaSeconds); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ReceiveTick
	void HideLobbyNameplate(); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.HideLobbyNameplate
	void ShowLobbyNameplate(); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ShowLobbyNameplate
	void SetLobbyNameplate(struct UKSPlayerInfo* playerinfo); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.SetLobbyNameplate
	void ExecuteUbergraph_FriendlyLobbyCharacter(int32_t EntryPoint); // Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ExecuteUbergraph_FriendlyLobbyCharacter
}; 



