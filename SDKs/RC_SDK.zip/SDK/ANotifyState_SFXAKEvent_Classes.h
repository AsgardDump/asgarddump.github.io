#pragma once 
#include <ANotifyState_SFXAKEvent_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_SFXAKEvent.ANotifyState_SFXAKEvent_C
// Size: 0x5D(Inherited: 0x30) 
struct UANotifyState_SFXAKEvent_C : public UAnimNotifyState
{
	struct UAkAudioEvent* AK Event Start;  // 0x30(0x8)
	struct UAkAudioEvent* AK Event Stop;  // 0x38(0x8)
	struct FName StartRowName;  // 0x40(0x8)
	struct FName StopRowName;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool SpawnNewComponentAttachedToMesh : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	struct FName AttachPointName;  // 0x54(0x8)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool Grab Emote Semaphore : 1;  // 0x5C(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_SFXAKEvent.ANotifyState_SFXAKEvent_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_SFXAKEvent.ANotifyState_SFXAKEvent_C.Received_NotifyBegin
}; 



