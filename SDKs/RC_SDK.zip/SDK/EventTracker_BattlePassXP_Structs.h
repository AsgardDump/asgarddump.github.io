#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessBoosterBonuses
// Size: 0x10C(Inherited: 0x0) 
struct FProcessBoosterBonuses
{
	float OutProgress;  // 0x0(0x4)
	float TotalBoosterProgress;  // 0x4(0x4)
	float BoosterProgress;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString CurrentBoosterName;  // 0x10(0x10)
	struct TMap<struct FString, float> BoosterMultipliers;  // 0x20(0x50)
	float Progress;  // 0x70(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x74(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x78(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x7C(0x4)
	struct TArray<struct FString> CallFunc_Map_Keys_Keys;  // 0x80(0x10)
	struct FString CallFunc_Array_Get_Item;  // 0x90(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xA8(0x4)
	float CallFunc_Map_Find_Value;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xB4(0x4)
	struct TMap<struct FString, float> CallFunc_GetBonusProgressionMultiplierFromBoosters_ReturnValue;  // 0xB8(0x50)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x108(0x4)

}; 
// Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ExecuteUbergraph_EventTracker_BattlePassXP
// Size: 0x5C(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_BattlePassXP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x18(0x8)
	float CallFunc_ComputeBaseProgress_OutProgress;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float CallFunc_ProcessBoosterBonuses_OutProgress;  // 0x28(0x4)
	float CallFunc_ProcessQueueBonus_OutProgress;  // 0x2C(0x4)
	float CallFunc_ProcessWinBonus_OutProgress;  // 0x30(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x38(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x3C(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x40(0x4)
	float CallFunc_ProcessEventBonuses_OutProgress;  // 0x44(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x48(0x10)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x58(0x4)

}; 
// Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.IsWinningTeam
// Size: 0x21(Inherited: 0x0) 
struct FIsWinningTeam
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsWinningTeam : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct AKSGameState* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_GetTeamNum_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_GetWinningTeamNum_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ComputeBaseProgress
// Size: 0x38(Inherited: 0x0) 
struct FComputeBaseProgress
{
	float OutProgress;  // 0x0(0x4)
	float timePlayed;  // 0x4(0x4)
	float Progress;  // 0x8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xC(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	float CallFunc_GetMatchTimeElapsed_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_IsBackfilling_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float CallFunc_GetCurrentTimePlayed_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x28(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x2C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x30(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x34(0x4)

}; 
// Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessQueueBonus
// Size: 0x14(Inherited: 0x0) 
struct FProcessQueueBonus
{
	float OutProgress;  // 0x0(0x4)
	float Progress;  // 0x4(0x4)
	float CallFunc_GetBonusProgressionMultiplier_ReturnValue;  // 0x8(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)

}; 
// Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessWinBonus
// Size: 0x50(Inherited: 0x0) 
struct FProcessWinBonus
{
	float OutProgress;  // 0x0(0x4)
	float Progress;  // 0x4(0x4)
	uint8_t  Temp_byte_Variable;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_Variable : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	float Temp_float_Variable;  // 0xC(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsWinningTeam_IsWinningTeam : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsBackfilling_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_IsBackfilling_ReturnValue_2 : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsInCustomMatch_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x31(0x1)
	uint8_t  K2Node_Select_Default;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_IsWinningTeam_IsWinningTeam_2 : 1;  // 0x33(0x1)
	char pad_52[4];  // 0x34(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x43(0x1)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float K2Node_Select_Default_2;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)

}; 
// Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessEventBonuses
// Size: 0x10C(Inherited: 0x0) 
struct FProcessEventBonuses
{
	float OutProgress;  // 0x0(0x4)
	float TotalEventProgress;  // 0x4(0x4)
	struct FString CurrentEventName;  // 0x8(0x10)
	float EventProgress;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TMap<struct FString, float> EventMultipliers;  // 0x20(0x50)
	int32_t Temp_int_Array_Index_Variable;  // 0x70(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x74(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct TArray<struct FString> CallFunc_Map_Keys_Keys;  // 0x80(0x10)
	struct FString CallFunc_Array_Get_Item;  // 0x90(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xA8(0x4)
	float CallFunc_Map_Find_Value;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xB4(0x4)
	struct TMap<struct FString, float> CallFunc_GetBonusProgressionMultiplierFromEvents_ReturnValue;  // 0xB8(0x50)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x108(0x4)

}; 
