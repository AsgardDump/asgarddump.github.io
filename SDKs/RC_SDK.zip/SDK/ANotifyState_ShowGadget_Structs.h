#pragma once 
#include "SDK.h" 
 
 
// Function ANotifyState_ShowGadget.ANotifyState_ShowGadget_C.Received_NotifyBegin
// Size: 0x42(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x18(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x20(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x28(0x8)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst_2;  // 0x38(0x8)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_79_1 : 7;  // 0x4F(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x41(0x1)

}; 
// Function ANotifyState_ShowGadget.ANotifyState_ShowGadget_C.Received_NotifyEnd
// Size: 0x9B(Inherited: 0x18) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x30(0x8)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue;  // 0x38(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x40(0x8)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	struct UKSWeaponAsset* CallFunc_GetWeaponAsset_ReturnValue;  // 0x50(0x8)
	struct FGameplayTag CallFunc_GetWeaponType_ReturnValue;  // 0x58(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x60(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst_2;  // 0x68(0x8)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x70(0x1)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x71(0x1)
	char pad_117[3];  // 0x75(0x3)
	struct FGameplayTagContainer CallFunc_MakeLiteralGameplayTagContainer_ReturnValue;  // 0x78(0x20)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_MatchesAnyTags_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x9A(0x1)

}; 
