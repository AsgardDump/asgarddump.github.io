#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_EndOfRound.EventTracker_EndOfRound_C.ExecuteUbergraph_EventTracker_EndOfRound
// Size: 0x59(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_EndOfRound
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSGameState* CallFunc_GetGameState_ReturnValue;  // 0x8(0x8)
	struct AKSGameState_RoundGame* K2Node_DynamicCast_AsKSGame_State_Round_Game;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	char pad_44[4];  // 0x2C(0x4)
	struct AKSGameState* K2Node_CustomEvent_GameState;  // 0x30(0x8)
	struct FRoundResult K2Node_CustomEvent_RoundResult;  // 0x38(0x20)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsRoundResultConditionMet_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function EventTracker_EndOfRound.EventTracker_EndOfRound_C.RoundHasEnded_Event
// Size: 0x28(Inherited: 0x0) 
struct FRoundHasEnded_Event
{
	struct AKSGameState* GameState;  // 0x0(0x8)
	struct FRoundResult RoundResult;  // 0x8(0x20)

}; 
