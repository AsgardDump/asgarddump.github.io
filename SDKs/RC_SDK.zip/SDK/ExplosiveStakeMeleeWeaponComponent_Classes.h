#pragma once 
#include <ExplosiveStakeMeleeWeaponComponent_Structs.h>
 
 
 
// DynamicClass ExplosiveStakeMeleeWeaponComponent.ExplosiveStakeMeleeWeaponComponent_C
// Size: 0x1910(Inherited: 0x18D0) 
struct UExplosiveStakeMeleeWeaponComponent_C : public UMasterMelee_WeaponComponent_C
{
	char pad_6352_1 : 7;  // 0x18D0(0x1)
	bool IsPlayingAbilityVO : 1;  // 0x18C8(0x1)
	float K2Node_Event_DeltaSeconds;  // 0x18CC(0x4)
	uint8_t  K2Node_Event_OldState;  // 0x18D0(0x1)
	uint8_t  K2Node_Event_NewState;  // 0x18D1(0x1)
	char pad_6359_1 : 7;  // 0x18D7(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x18D2(0x1)
	struct UKSCharacterAnimInst* CallFunc_Get_Character_Anim_Instance_Anim_Inst;  // 0x18D8(0x8)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x18E0(0x10)
	struct FName Temp_name_Variable;  // 0x18F0(0x8)
	int32_t CallFunc_GetAudioEvent_Priority;  // 0x18F8(0x4)
	struct FDelegate Temp_delegate_Variable;  // 0x18FC(0x10)
	char pad_6412[4];  // 0x190C(0x4)

	void Resolve Combat State when Aiming Throw on Zipline(); // Function ExplosiveStakeMeleeWeaponComponent.ExplosiveStakeMeleeWeaponComponent_C.Resolve Combat State when Aiming Throw on Zipline
}; 



