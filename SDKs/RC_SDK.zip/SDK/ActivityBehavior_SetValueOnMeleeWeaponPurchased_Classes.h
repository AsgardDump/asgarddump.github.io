#pragma once 
#include <ActivityBehavior_SetValueOnMeleeWeaponPurchased_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_SetValueOnMeleeWeaponPurchased.ActivityBehavior_SetValueOnMeleeWeaponPurchased_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_SetValueOnMeleeWeaponPurchased_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_SetValueOnMeleeWeaponPurchased.ActivityBehavior_SetValueOnMeleeWeaponPurchased_C.HandleBehaviorInitialized
	void HandleShopItemPurchased(struct UKSGameShopItemComponent* ShopItemComponent); // Function ActivityBehavior_SetValueOnMeleeWeaponPurchased.ActivityBehavior_SetValueOnMeleeWeaponPurchased_C.HandleShopItemPurchased
	void ExecuteUbergraph_ActivityBehavior_SetValueOnMeleeWeaponPurchased(int32_t EntryPoint); // Function ActivityBehavior_SetValueOnMeleeWeaponPurchased.ActivityBehavior_SetValueOnMeleeWeaponPurchased_C.ExecuteUbergraph_ActivityBehavior_SetValueOnMeleeWeaponPurchased
}; 



