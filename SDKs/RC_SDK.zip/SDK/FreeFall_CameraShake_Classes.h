#pragma once 
#include <FreeFall_CameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass FreeFall_CameraShake.FreeFall_CameraShake_C
// Size: 0x180(Inherited: 0x180) 
struct UFreeFall_CameraShake_C : public UKSFreeFallCameraShake
{

}; 



