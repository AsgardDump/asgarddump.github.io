#pragma once 
#include "SDK.h" 
 
 
// Function BP_LobbyState.BP_LobbyState_C.ExecuteUbergraph_BP_LobbyState
// Size: 0x58(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LobbyState
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x48(0x8)
	struct AEmoteSoundManager_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x50(0x8)

}; 
// Function BP_LobbyState.BP_LobbyState_C.GetEmoteMusicManager
// Size: 0x8(Inherited: 0x0) 
struct FGetEmoteMusicManager
{
	struct AKSEmoteMusicManager* ReturnValue;  // 0x0(0x8)

}; 
