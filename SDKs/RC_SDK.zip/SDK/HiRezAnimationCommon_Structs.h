#pragma once 
#include "SDK.h" 
 
 
// Function HiRezAnimationCommon.HiRezAnimationStatics.FindPositionFromDistanceCurve
// Size: 0x20(Inherited: 0x0) 
struct FFindPositionFromDistanceCurve
{
	struct FName DistanceCurveName;  // 0x0(0x8)
	float Distance;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UAnimSequenceBase* InAnimSequence;  // 0x10(0x8)
	float ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
