#pragma once 
#include <ABP_GAD_ZiplineDevice_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C
// Size: 0x21F8(Inherited: 0x1190) 
struct UABP_GAD_ZiplineDevice_C : public UKSZiplineAnimInst
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1190(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x1198(0x40)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x11D8(0x118)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x12F0(0x118)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x1408(0x118)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // 0x1520(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // 0x1550(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x1580(0xB0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x1630(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x16B8(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x16F8(0xC0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // 0x17B8(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // 0x17E8(0x30)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x1818(0xC8)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x18E0(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x1918(0x88)
	struct FAnimNode_CCDIK AnimGraphNode_CCDIK;  // 0x19A0(0x190)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x1B30(0x118)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x1C48(0xB0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x1CF8(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x1D28(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x1D58(0x88)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x1DE0(0x118)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x1EF8(0xB0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x1FA8(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x1FD8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x2008(0x88)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x2090(0x118)
	struct UPCM_Hero_ABP_C* HeroABP;  // 0x21A8(0x8)
	struct FVector Zipline IK Target Location;  // 0x21B0(0xC)
	struct FVector Zipline Device Rope Pivot;  // 0x21BC(0xC)
	struct FRotator Zipline IK Target Rotation;  // 0x21C8(0xC)
	struct FVector L_ZiplineDevice Location;  // 0x21D4(0xC)
	struct FVector R_ZiplineDevice Location;  // 0x21E0(0xC)
	struct FVector Default Zipline Location;  // 0x21EC(0xC)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_GAD_ZiplineDevice_AnimGraphNode_ModifyBone_7CEDEA8140508F2195275BB58C7B7F7B(); // Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_GAD_ZiplineDevice_AnimGraphNode_ModifyBone_7CEDEA8140508F2195275BB58C7B7F7B
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_GAD_ZiplineDevice(int32_t EntryPoint); // Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.ExecuteUbergraph_ABP_GAD_ZiplineDevice
}; 



