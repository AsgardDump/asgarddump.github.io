#pragma once 
#include <EventTracker_Damage_Single_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_Damage_Single.EventTracker_Damage_Single_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_Damage_Single_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_Damage_Single.EventTracker_Damage_Single_C.HandleTrackerInitialized
	void OwnedPawnInstigateDamage(struct FCombatEventInfo& DamageInfo); // Function EventTracker_Damage_Single.EventTracker_Damage_Single_C.OwnedPawnInstigateDamage
	void ExecuteUbergraph_EventTracker_Damage_Single(int32_t EntryPoint); // Function EventTracker_Damage_Single.EventTracker_Damage_Single_C.ExecuteUbergraph_EventTracker_Damage_Single
}; 



