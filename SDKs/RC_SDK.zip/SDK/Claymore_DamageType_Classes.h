#pragma once 
#include <Claymore_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass Claymore_DamageType.Claymore_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UClaymore_DamageType_C : public UMasterMelee_DamageType_C
{

}; 



