#pragma once 
#include <ANotifyState_MeleeCombo_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_MeleeCombo.ANotifyState_MeleeCombo_C
// Size: 0x39(Inherited: 0x30) 
struct UANotifyState_MeleeCombo_C : public UAnimNotifyState
{
	struct FName ComboTarget;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool IsQuickMelee : 1;  // 0x38(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_MeleeCombo.ANotifyState_MeleeCombo_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_MeleeCombo.ANotifyState_MeleeCombo_C.Received_NotifyBegin
}; 



