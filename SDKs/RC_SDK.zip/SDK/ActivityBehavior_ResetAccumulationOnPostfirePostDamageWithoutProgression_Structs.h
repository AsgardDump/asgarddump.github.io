#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression.ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression
// Size: 0x38(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_ResetAccumulationOnPostfirePostDamageWithoutProgression
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_GetAccumulatedProgress_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_GetAccumulatedProgress_ReturnValue_2;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_GetAccumulatedProgress_ReturnValue_3;  // 0x34(0x4)

}; 
