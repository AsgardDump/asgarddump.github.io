#pragma once 
#include <AKSAnimNotifyState_WeaponProp_Structs.h>
 
 
 
// BlueprintGeneratedClass AKSAnimNotifyState_WeaponProp.AKSAnimNotifyState_WeaponProp_C
// Size: 0x99(Inherited: 0x98) 
struct UAKSAnimNotifyState_WeaponProp_C : public UKSAnimNotifyState_WeaponProp
{
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Hide Weapons on Back if In Emote : 1;  // 0x98(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AKSAnimNotifyState_WeaponProp.AKSAnimNotifyState_WeaponProp_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AKSAnimNotifyState_WeaponProp.AKSAnimNotifyState_WeaponProp_C.Received_NotifyBegin
}; 



