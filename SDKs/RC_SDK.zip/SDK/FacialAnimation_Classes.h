#pragma once 
#include <FacialAnimation_Structs.h>
 
 
 
// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x830(Inherited: 0x7F0) 
struct UAudioCurveSourceComponent : public UAudioComponent
{
	struct FName CurveSourceBindingName;  // 0x7F0(0x8)
	float CurveSyncOffset;  // 0x7F8(0x4)
	char pad_2044[52];  // 0x7FC(0x34)

}; 



