#pragma once 
#include <ActivityBehavior_SetValueOnPerkPurchased_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_SetValueOnPerkPurchased.ActivityBehavior_SetValueOnPerkPurchased_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_SetValueOnPerkPurchased_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_SetValueOnPerkPurchased.ActivityBehavior_SetValueOnPerkPurchased_C.HandleBehaviorInitialized
	void HandleShopItemPurchased(struct UKSGameShopItemComponent* ShopItemComponent); // Function ActivityBehavior_SetValueOnPerkPurchased.ActivityBehavior_SetValueOnPerkPurchased_C.HandleShopItemPurchased
	void ExecuteUbergraph_ActivityBehavior_SetValueOnPerkPurchased(int32_t EntryPoint); // Function ActivityBehavior_SetValueOnPerkPurchased.ActivityBehavior_SetValueOnPerkPurchased_C.ExecuteUbergraph_ActivityBehavior_SetValueOnPerkPurchased
}; 



