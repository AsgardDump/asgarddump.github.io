#pragma once 
#include "SDK.h" 
 
 
// Function DroppedMagazine.DroppedMagazine_C.ExecuteUbergraph_DroppedMagazine
// Size: 0x19D(Inherited: 0x0) 
struct FExecuteUbergraph_DroppedMagazine
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USkeletalMesh* K2Node_CustomEvent_NewSkelMesh;  // 0x8(0x8)
	struct UStaticMesh* K2Node_CustomEvent_NewStaticMesh;  // 0x10(0x8)
	struct FBoxSphereBounds CallFunc_GetBounds_ReturnValue;  // 0x18(0x1C)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FVector CallFunc_NegateVector_ReturnValue;  // 0x38(0xC)
	struct FBoxSphereBounds CallFunc_GetImportedBounds_ReturnValue;  // 0x44(0x1C)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FVector CallFunc_NegateVector_ReturnValue_2;  // 0x64(0xC)
	struct FVector K2Node_CustomEvent_Velocity;  // 0x70(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x7C(0x88)
	char pad_260[4];  // 0x104(0x4)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x111(0x1)
	char pad_274[2];  // 0x112(0x2)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_2;  // 0x114(0x88)
	char pad_412_1 : 7;  // 0x19C(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x19C(0x1)

}; 
// Function DroppedMagazine.DroppedMagazine_C.SetVelocity
// Size: 0xC(Inherited: 0x0) 
struct FSetVelocity
{
	struct FVector Velocity;  // 0x0(0xC)

}; 
// Function DroppedMagazine.DroppedMagazine_C.SetMesh
// Size: 0x10(Inherited: 0x0) 
struct FSetMesh
{
	struct USkeletalMesh* NewSkelMesh;  // 0x0(0x8)
	struct UStaticMesh* NewStaticMesh;  // 0x8(0x8)

}; 
