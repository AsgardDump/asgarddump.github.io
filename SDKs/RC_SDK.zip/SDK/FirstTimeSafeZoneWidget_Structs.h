#pragma once 
#include "SDK.h" 
 
 
// Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.ExecuteUbergraph_FirstTimeSafeZoneWidget
// Size: 0xC4(Inherited: 0x0) 
struct FExecuteUbergraph_FirstTimeSafeZoneWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x8(0x8)
	struct UKSGameUserSettings* K2Node_DynamicCast_AsKSGame_User_Settings;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x1C(0x8)
	char pad_36[4];  // 0x24(0x4)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Remove_Top_View_Route_ViewChanged : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x32(0x1)
	char pad_51[5];  // 0x33(0x5)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x38(0x8)
	struct UKSSettingsWidget* CallFunc_CreateSettingsWidgetWithConfig_ReturnValue;  // 0x40(0x8)
	struct UWidget* K2Node_ComponentBoundEvent_Widget;  // 0x48(0x8)
	struct UOverlaySlot* CallFunc_AddChildToOverlay_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_GetFontByName_HasFound : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FSlateFontInfo CallFunc_GetFontByName_FontInfo;  // 0x60(0x50)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_GetColorByName_HasFound : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	struct FLinearColor CallFunc_GetColorByName_Color;  // 0xB4(0x10)

}; 
// Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
// Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function FirstTimeSafeZoneWidget.FirstTimeSafeZoneWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
{
	struct UWidget* Widget;  // 0x0(0x8)

}; 
