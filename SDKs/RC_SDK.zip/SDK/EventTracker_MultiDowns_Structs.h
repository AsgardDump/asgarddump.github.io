#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_MultiDowns.EventTracker_MultiDowns_C.ExecuteUbergraph_EventTracker_MultiDowns
// Size: 0xD9(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_MultiDowns
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	int32_t K2Node_CustomEvent_DownCount;  // 0x2C(0x4)
	struct FCombatEventInfoContainer K2Node_CustomEvent_CombatEventContainer;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FCombatEventInfo CallFunc_Array_Get_Item;  // 0x48(0x88)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_IsCombatConditionMet_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xD4(0x4)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xD8(0x1)

}; 
// Function EventTracker_MultiDowns.EventTracker_MultiDowns_C.MultiDownAchieved
// Size: 0x18(Inherited: 0x0) 
struct FMultiDownAchieved
{
	int32_t DownCount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FCombatEventInfoContainer CombatEventContainer;  // 0x8(0x10)

}; 
