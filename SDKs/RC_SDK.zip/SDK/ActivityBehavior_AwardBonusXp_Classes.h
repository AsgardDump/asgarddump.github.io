#pragma once 
#include <ActivityBehavior_AwardBonusXp_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C
// Size: 0x64(Inherited: 0x38) 
struct UActivityBehavior_AwardBonusXp_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)
	float BonusTriggers;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString BonusKey;  // 0x48(0x10)
	struct UKSEventTracker* Tracker;  // 0x58(0x8)
	float TriggerCount;  // 0x60(0x4)

	void IsWinningTeam(bool& bIsWinningTeam); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.IsWinningTeam
	void ProcessEventBonus(float& OutProgress); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.ProcessEventBonus
	void ProcessWinBonus(float& OutProgress); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.ProcessWinBonus
	void ProcessQueueBonus(float& OutProgress); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.ProcessQueueBonus
	void ProcessBoosterBonus(float& OutProgress); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.ProcessBoosterBonus
	void HandleActivityTriggered(); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.HandleActivityTriggered
	void HandleBehaviorInitialized(); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.HandleBehaviorInitialized
	void OnMatchEnded(); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.OnMatchEnded
	void ExecuteUbergraph_ActivityBehavior_AwardBonusXp(int32_t EntryPoint); // Function ActivityBehavior_AwardBonusXp.ActivityBehavior_AwardBonusXp_C.ExecuteUbergraph_ActivityBehavior_AwardBonusXp
}; 



