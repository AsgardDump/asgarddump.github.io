#pragma once 
#include "SDK.h" 
 
 
// Function Checkbox.Checkbox_C.OnCheckChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnCheckChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Checked : 1;  // 0x0(0x1)

}; 
// Function Checkbox.Checkbox_C.ExecuteUbergraph_Checkbox
// Size: 0x78(Inherited: 0x0) 
struct FExecuteUbergraph_Checkbox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x7(0x1)
	uint8_t  K2Node_Select_Default;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x9(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x10(0x10)
	uint8_t  K2Node_Select_Default_2;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FDelegate Temp_delegate_Variable;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2;  // 0x38(0x10)
	struct FDelegate Temp_delegate_Variable_2;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool K2Node_CustomEvent_Checked : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x60(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x68(0x8)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x70(0x4)
	int32_t CallFunc_PostEvent_ReturnValue_2;  // 0x74(0x4)

}; 
// Function Checkbox.Checkbox_C.SetCheckedState
// Size: 0x1(Inherited: 0x0) 
struct FSetCheckedState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Checked : 1;  // 0x0(0x1)

}; 
// Function Checkbox.Checkbox_C.NavigateConfirm
// Size: 0x1(Inherited: 0x1) 
struct FNavigateConfirm : public FNavigateConfirm
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
