#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct FBP_CustomMatchTeam.FBP_CustomMatchTeam
// Size: 0x28(Inherited: 0x0) 
struct FFBP_CustomMatchTeam
{
	int32_t TeamID_7_BAB34AE24596157B7EFD959A8D453F62;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FPUMG_CustomMatchMember> Members_3_15C42158406155E59954E2A8A801EA3D;  // 0x8(0x10)
	struct TArray<struct UKSWidget*> Widgets_11_6E324FD94AEEDB2A614F75A909EA63D9;  // 0x18(0x10)

}; 
