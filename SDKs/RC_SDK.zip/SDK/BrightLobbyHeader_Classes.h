#pragma once 
#include <BrightLobbyHeader_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BrightLobbyHeader.BrightLobbyHeader_C
// Size: 0x548(Inherited: 0x528) 
struct UBrightLobbyHeader_C : public UKSWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x528(0x8)
	struct TArray<uint8_t > LoggedOutStates;  // 0x530(0x10)
	struct UPUMG_LoginDataFactory* LoginDataFactory;  // 0x540(0x8)

	void HandleLobbyStartMenuInputAction(); // Function BrightLobbyHeader.BrightLobbyHeader_C.HandleLobbyStartMenuInputAction
	void StartShowSequence(struct FName FromRoute, struct FName ToRoute); // Function BrightLobbyHeader.BrightLobbyHeader_C.StartShowSequence
	void StartHideSequence(struct FName FromRoute, struct FName ToRoute); // Function BrightLobbyHeader.BrightLobbyHeader_C.StartHideSequence
	void ExecuteUbergraph_BrightLobbyHeader(int32_t EntryPoint); // Function BrightLobbyHeader.BrightLobbyHeader_C.ExecuteUbergraph_BrightLobbyHeader
}; 



