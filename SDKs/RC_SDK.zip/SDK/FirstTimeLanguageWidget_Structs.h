#pragma once 
#include "SDK.h" 
 
 
// Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
// Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.ExecuteUbergraph_FirstTimeLanguageWidget
// Size: 0x189(Inherited: 0x0) 
struct FExecuteUbergraph_FirstTimeLanguageWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x8(0x10)
	struct FDelegate Temp_delegate_Variable;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UAkAudioEvent* Temp_object_Variable;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x40(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x48(0x8)
	struct UKSGameUserSettings* K2Node_DynamicCast_AsKSGame_User_Settings;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	uint8_t  Temp_byte_Variable;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Remove_Top_View_Route_ViewChanged : 1;  // 0x78(0x1)
	char PGAME_INPUT_STATE CallFunc_GetCurrentInputState_ReturnValue;  // 0x79(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x7A(0x1)
	char pad_123[5];  // 0x7B(0x5)
	struct UWidget* K2Node_ComponentBoundEvent_Widget;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_GetFontByName_HasFound : 1;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct FSlateFontInfo CallFunc_GetFontByName_FontInfo;  // 0x90(0x50)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_GetColorByName_HasFound : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FLinearColor CallFunc_GetColorByName_Color;  // 0xE4(0x10)
	char pad_244[4];  // 0xF4(0x4)
	struct UOverlaySlot* CallFunc_AddChildToOverlay_ReturnValue;  // 0xF8(0x8)
	uint8_t  Temp_byte_Variable_3;  // 0x100(0x1)
	char pad_257[3];  // 0x101(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x104(0x10)
	char PGAME_INPUT_STATE K2Node_CustomEvent_InputState;  // 0x114(0x1)
	char pad_277[3];  // 0x115(0x3)
	struct UWBP_SettingsEntryList_C* K2Node_DynamicCast_AsWBP_Settings_Entry_List;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x120(0x1)
	char PGAME_INPUT_STATE CallFunc_GetCurrentInputState_ReturnValue_2;  // 0x121(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x122(0x1)
	char pad_291_1 : 7;  // 0x123(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x123(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x124(0x10)
	char pad_308[4];  // 0x134(0x4)
	struct UWBP_SettingsEntryList_C* K2Node_DynamicCast_AsWBP_Settings_Entry_List_2;  // 0x138(0x8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x144(0x10)
	char PGAME_INPUT_STATE Temp_byte_Variable_5;  // 0x154(0x1)
	char pad_341[3];  // 0x155(0x3)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x158(0x8)
	uint8_t  K2Node_Select_Default;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x161(0x1)
	char pad_354[6];  // 0x162(0x6)
	struct UKSSettingsWidget* CallFunc_CreateSettingsWidgetWithConfig_ReturnValue;  // 0x168(0x8)
	struct UAkAudioEvent* K2Node_Select_Default_2;  // 0x170(0x8)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x178(0x4)
	char pad_380[4];  // 0x17C(0x4)
	struct UWBP_SettingsEntryList_C* K2Node_DynamicCast_AsWBP_Settings_Entry_List_3;  // 0x180(0x8)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x188(0x1)

}; 
// Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
{
	struct UWidget* Widget;  // 0x0(0x8)

}; 
// Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.HandleInputState
// Size: 0x1(Inherited: 0x0) 
struct FHandleInputState
{
	char PGAME_INPUT_STATE InputState;  // 0x0(0x1)

}; 
