#pragma once 
#include "SDK.h" 
 
 
// Function ANotify_PlayParticleEffectMirroring.ANotify_PlayParticleEffectMirroring_C.Received_Notify
// Size: 0x49(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x18(0x8)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x28(0x8)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	struct FName K2Node_Select_Default;  // 0x34(0x8)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0x40(0x8)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)

}; 
