#pragma once 
#include <AttackBomb_Disarm_InteractionType_Structs.h>
 
 
 
// BlueprintGeneratedClass AttackBomb_Disarm_InteractionType.AttackBomb_Disarm_InteractionType_C
// Size: 0x398(Inherited: 0x398) 
struct UAttackBomb_Disarm_InteractionType_C : public UInteractionTypeBase_C
{

}; 



