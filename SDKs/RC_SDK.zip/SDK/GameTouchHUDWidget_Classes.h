#pragma once 
#include <GameTouchHUDWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GameTouchHUDWidget.GameTouchHUDWidget_C
// Size: 0x6F1(Inherited: 0x598) 
struct UGameTouchHUDWidget_C : public UKSTouchHudWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x598(0x8)
	struct UWBP_TouchButtonGeneric_C* AOSToggleButton;  // 0x5A0(0x8)
	struct UWBP_TouchButtonGeneric_C* AutoSprintToggleButton;  // 0x5A8(0x8)
	struct UButton* BtnScoreboard;  // 0x5B0(0x8)
	struct UButton* BtnStore;  // 0x5B8(0x8)
	struct UWBP_TouchButtonGeneric_C* CrouchButton;  // 0x5C0(0x8)
	struct UWidgetSwitcher* CrouchSlideSwitcher;  // 0x5C8(0x8)
	struct UWBP_TouchButtonGeneric_C* DodgeRoll;  // 0x5D0(0x8)
	struct UWBP_TouchButtonGeneric_C* DragSprintToggleButton;  // 0x5D8(0x8)
	struct UWBP_TouchButtonGeneric_C* GadgetCancelButton;  // 0x5E0(0x8)
	struct UCanvasPanel* InGameHUDCanvasPanel;  // 0x5E8(0x8)
	struct UWBP_TouchButtonGeneric_C* InteractButton;  // 0x5F0(0x8)
	struct UWBP_TouchButtonGeneric_C* JumpButton_2;  // 0x5F8(0x8)
	struct UImage* LeftStickDir;  // 0x600(0x8)
	struct UImage* LeftStickDir_Shadow;  // 0x608(0x8)
	struct UOverlay* LeftStickDirWrapper;  // 0x610(0x8)
	struct UImage* LeftStickOrigin;  // 0x618(0x8)
	struct UImage* LeftStickOrigin_Shadow;  // 0x620(0x8)
	struct UOverlay* LeftStickOriginWrapper;  // 0x628(0x8)
	struct UWBP_TouchButtonGeneric_C* MenuButton;  // 0x630(0x8)
	struct UButton* OpenMapButton;  // 0x638(0x8)
	struct UWBP_TouchButtonGeneric_C* PrimaryMeleeButton;  // 0x640(0x8)
	struct UOverlay* PrimaryWeaponFireOverlay;  // 0x648(0x8)
	struct UPUMG_UnsafeZone* PUMG_UnsafeZone_1;  // 0x650(0x8)
	struct UWBP_TouchButtonGeneric_C* ReloadButton;  // 0x658(0x8)
	struct UWBP_TouchButtonGeneric_C* ShoulderSwap;  // 0x660(0x8)
	struct UWBP_TouchButtonGeneric_C* SlideButton;  // 0x668(0x8)
	struct UWBP_GadgetTouchButton_C* ThrowGrenadeButton;  // 0x670(0x8)
	struct UWBP_BombTouchButton_C* WBP_BombTouchButton;  // 0x678(0x8)
	struct UWBP_LocalPlayerHealth_Mobile_C* WBP_LocalPlayerHealth_Mobile;  // 0x680(0x8)
	struct UWBP_TouchAbilityButton_C* WBP_TouchAbilityButton;  // 0x688(0x8)
	struct UWBP_TouchGadgetButton_C* WBP_TouchGadgetButton;  // 0x690(0x8)
	struct UWBP_TouchWeaponSelectionTray_C* WBP_TouchWeaponSelectionTray;  // 0x698(0x8)
	struct UScrollBox* WeaponPickup_ScrollBox;  // 0x6A0(0x8)
	char pad_1704_1 : 7;  // 0x6A8(0x1)
	bool IsGrenadeActive : 1;  // 0x6A8(0x1)
	char pad_1705_1 : 7;  // 0x6A9(0x1)
	bool IsReviveTextSet : 1;  // 0x6A9(0x1)
	char pad_1706[6];  // 0x6AA(0x6)
	struct TArray<struct AActor*> PreviousNearbyCrateItems;  // 0x6B0(0x10)
	struct TArray<struct AActor*> SortedNearbyCrateItems;  // 0x6C0(0x10)
	struct FVector2D DefaultLeftStickDir;  // 0x6D0(0x8)
	struct FVector2D DefaultLeftStickOrigin;  // 0x6D8(0x8)
	struct UTexture2D* MyZiplineIcon;  // 0x6E0(0x8)
	struct UTexture2D* MyInteractIcon;  // 0x6E8(0x8)
	char pad_1776_1 : 7;  // 0x6F0(0x1)
	bool IsJoystickActive : 1;  // 0x6F0(0x1)

	void Set Character Auto Sprint(bool ShouldAutoSprint); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Set Character Auto Sprint
	void Cancel Next Release(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Cancel Next Release
	void UpdateStateTouchCancelButton(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.UpdateStateTouchCancelButton
	void GetHudMaskableButtons(struct TArray<struct UWidget*>& MaskableButtons); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.GetHudMaskableButtons
	void SetButtonMask(struct TArray<bool>& MaskArray); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.SetButtonMask
	struct FVector2D Get Touch Cursor Screen Space(struct FKey KeyState); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Get Touch Cursor Screen Space
	void SnapJoystickToCursor(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.SnapJoystickToCursor
	void ResetJoystick(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.ResetJoystick
	void TriggerInputAction(struct FName InActionName, char EInputEvent InInputEvent); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.TriggerInputAction
	void GetWidgetBounds(struct UWidget* Widget, struct FVector2D& TopLeft, struct FVector2D& BottomRight); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.GetWidgetBounds
	void IsPointOverWidget(struct FVector2D ScreenPoint, struct UWidget* Widget, bool& IsPointOverWidget); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.IsPointOverWidget
	void Construct(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Construct
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Tick
	void BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_4_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_4_OnButtonPressedEvent__DelegateSignature
	void BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_5_OnButtonReleasedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnWeaponSwap_K2Node_ComponentBoundEvent_5_OnButtonReleasedEvent__DelegateSignature
	void BndEvt__BtnStore_K2Node_ComponentBoundEvent_12_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnStore_K2Node_ComponentBoundEvent_12_OnButtonPressedEvent__DelegateSignature
	void BndEvt__BtnStore_K2Node_ComponentBoundEvent_13_OnButtonReleasedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnStore_K2Node_ComponentBoundEvent_13_OnButtonReleasedEvent__DelegateSignature
	void BndEvt__BtnScoreboard_K2Node_ComponentBoundEvent_14_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__BtnScoreboard_K2Node_ComponentBoundEvent_14_OnButtonPressedEvent__DelegateSignature
	void BndEvt__OpenMapButton_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__OpenMapButton_K2Node_ComponentBoundEvent_0_OnButtonPressedEvent__DelegateSignature
	void ViewTargetChanged(struct AKSPlayerController* Controller, struct AActor* OldViewTarget, struct AActor* NewViewTarget); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.ViewTargetChanged
	void ShoulderSwapPressed(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.ShoulderSwapPressed
	void ShoulderSwapUpdate(struct AKSCharacter* Character); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.ShoulderSwapUpdate
	void HandleEquipmentChange(struct AKSCharacter* EquipmentOwner, struct UKSWeaponComponent* Equipment); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.HandleEquipmentChange
	void SetWidgetIconTexture(struct UWidget* Widget, struct FSoftObjectPath& Texture); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.SetWidgetIconTexture
	void InitializeWidget(struct APUMG_HUD* HUD); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.InitializeWidget
	void OnHoveredInteractableChanged(struct AActor* HoverTarget); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnHoveredInteractableChanged
	void BndEvt__AutoSprintToggleButton_K2Node_ComponentBoundEvent_1_OnButtonPressed__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__AutoSprintToggleButton_K2Node_ComponentBoundEvent_1_OnButtonPressed__DelegateSignature
	void UpdatePickupableItems(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.UpdatePickupableItems
	void BndEvt__MenuButton_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__MenuButton_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature
	void HandleDeathStateChanged(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.HandleDeathStateChanged
	void HandleWeaponChange(struct AKSCharacter* Character); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.HandleWeaponChange
	void BndEvt__GadgetCancelButton_K2Node_ComponentBoundEvent_6_OnButtonPressed__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__GadgetCancelButton_K2Node_ComponentBoundEvent_6_OnButtonPressed__DelegateSignature
	void BndEvt__GadgetCancelButton_K2Node_ComponentBoundEvent_15_OnReleased__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__GadgetCancelButton_K2Node_ComponentBoundEvent_15_OnReleased__DelegateSignature
	void BndEvt__ThrowGrenadeButton_K2Node_ComponentBoundEvent_17_OnReleased__DelegateSignature(); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.BndEvt__ThrowGrenadeButton_K2Node_ComponentBoundEvent_17_OnReleased__DelegateSignature
	void HandleAimStateChanged(uint8_t  NewAimMode); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.HandleAimStateChanged
	void Event Handle Result Received(uint8_t  Result); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.Event Handle Result Received
	void OnDelayedHUDAnnouncementComponentCreated(struct AKSPlayerController* OwningPlayerController, struct UKSHUDAnnouncementComponent* SpawnedHUDAnnouncementComponent); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnDelayedHUDAnnouncementComponentCreated
	void ViewChange (struct FName CurrentRoute, struct FName PreviousRoute, uint8_t  Layer); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.ViewChange 
	void OnSprintChanged(bool IsSprinting); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnSprintChanged
	void ExecuteUbergraph_GameTouchHUDWidget(int32_t EntryPoint); // Function GameTouchHUDWidget.GameTouchHUDWidget_C.ExecuteUbergraph_GameTouchHUDWidget
}; 



