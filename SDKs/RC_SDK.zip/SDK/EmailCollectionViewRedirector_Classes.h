#pragma once 
#include <EmailCollectionViewRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass EmailCollectionViewRedirector.EmailCollectionViewRedirector_C
// Size: 0x60(Inherited: 0x60) 
struct UEmailCollectionViewRedirector_C : public UKSEmailCollection_ViewRedirector
{

	struct UKSActivityManagerBase* GetRelevantActivityManager(struct UKSGameInstance* GameInstance); // Function EmailCollectionViewRedirector.EmailCollectionViewRedirector_C.GetRelevantActivityManager
}; 



