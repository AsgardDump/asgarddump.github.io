#pragma once 
#include "SDK.h" 
 
 
// Function BP_InWorld_Reticle.BP_InWorld_Reticle_C.ExecuteUbergraph_BP_InWorld_Reticle
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_InWorld_Reticle
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UKSWeaponComponent* K2Node_CustomEvent_WeaponComponent;  // 0x8(0x8)
	struct APlayerState* K2Node_CustomEvent_PlayerState;  // 0x10(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x18(0x8)
	struct UWBP_InWorld_Reticle_C* CallFunc_Create_ReturnValue;  // 0x20(0x8)

}; 
// Function BP_InWorld_Reticle.BP_InWorld_Reticle_C.SetPossession
// Size: 0x8(Inherited: 0x0) 
struct FSetPossession
{
	struct APlayerState* PlayerState;  // 0x0(0x8)

}; 
// Function BP_InWorld_Reticle.BP_InWorld_Reticle_C.SetWeaponComponent
// Size: 0x8(Inherited: 0x0) 
struct FSetWeaponComponent
{
	struct UKSWeaponComponent* WeaponComponent;  // 0x0(0x8)

}; 
