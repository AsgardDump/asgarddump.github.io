#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_EndOfMatch_SecondsPlayed.EventTracker_EndOfMatch_SecondsPlayed_C.ExecuteUbergraph_EventTracker_EndOfMatch_SecondsPlayed
// Size: 0x3C(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_EndOfMatch_SecondsPlayed
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_GetCurrentTimePlayed_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x2C(0x10)

}; 
