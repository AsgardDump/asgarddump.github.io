#pragma once 
#include <ANotify_Ragdoll_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotify_Ragdoll.ANotify_Ragdoll_C
// Size: 0x38(Inherited: 0x38) 
struct UANotify_Ragdoll_C : public UAnimNotify
{

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotify_Ragdoll.ANotify_Ragdoll_C.Received_Notify
}; 



