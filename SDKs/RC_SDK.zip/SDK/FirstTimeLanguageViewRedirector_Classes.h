#pragma once 
#include <FirstTimeLanguageViewRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass FirstTimeLanguageViewRedirector.FirstTimeLanguageViewRedirector_C
// Size: 0x30(Inherited: 0x30) 
struct UFirstTimeLanguageViewRedirector_C : public UKSViewRedirector_LocalSetting
{

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function FirstTimeLanguageViewRedirector.FirstTimeLanguageViewRedirector_C.DoesLocalSettingApply
}; 



