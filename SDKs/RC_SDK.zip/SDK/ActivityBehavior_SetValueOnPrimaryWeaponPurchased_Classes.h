#pragma once 
#include <ActivityBehavior_SetValueOnPrimaryWeaponPurchased_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_SetValueOnPrimaryWeaponPurchased.ActivityBehavior_SetValueOnPrimaryWeaponPurchased_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_SetValueOnPrimaryWeaponPurchased_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_SetValueOnPrimaryWeaponPurchased.ActivityBehavior_SetValueOnPrimaryWeaponPurchased_C.HandleBehaviorInitialized
	void HandleShopItemPurchased(struct UKSGameShopItemComponent* ShopItemComponent); // Function ActivityBehavior_SetValueOnPrimaryWeaponPurchased.ActivityBehavior_SetValueOnPrimaryWeaponPurchased_C.HandleShopItemPurchased
	void ExecuteUbergraph_ActivityBehavior_SetValueOnPrimaryWeaponPurchased(int32_t EntryPoint); // Function ActivityBehavior_SetValueOnPrimaryWeaponPurchased.ActivityBehavior_SetValueOnPrimaryWeaponPurchased_C.ExecuteUbergraph_ActivityBehavior_SetValueOnPrimaryWeaponPurchased
}; 



