#pragma once 
#include <ANotifyState_ShowTablet_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_ShowTablet.ANotifyState_ShowTablet_C
// Size: 0x32(Inherited: 0x30) 
struct UANotifyState_ShowTablet_C : public UAnimNotifyState
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bReverse : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bKeepTabletUnhidden : 1;  // 0x31(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_ShowTablet.ANotifyState_ShowTablet_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_ShowTablet.ANotifyState_ShowTablet_C.Received_NotifyBegin
}; 



