#pragma once 
#include "SDK.h" 
 
 
// Function BrightLobbyHeader.BrightLobbyHeader_C.ExecuteUbergraph_BrightLobbyHeader
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_BrightLobbyHeader
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName K2Node_Event_FromRoute;  // 0x4(0x8)
	struct FName K2Node_Event_ToRoute;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Add_View_Route_ViewChanged : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UPUMG_InputManager* CallFunc_GetInputManager_ReturnValue;  // 0x40(0x8)
	struct UPUMG_InputManager* CallFunc_GetInputManager_ReturnValue_2;  // 0x48(0x8)
	struct FName K2Node_Event_FromRoute_2;  // 0x50(0x8)
	struct FName K2Node_Event_ToRoute_2;  // 0x58(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x60(0x10)

}; 
// Function BrightLobbyHeader.BrightLobbyHeader_C.StartHideSequence
// Size: 0x10(Inherited: 0x10) 
struct FStartHideSequence : public FStartHideSequence
{
	struct FName FromRoute;  // 0x0(0x8)
	struct FName ToRoute;  // 0x8(0x8)

}; 
// Function BrightLobbyHeader.BrightLobbyHeader_C.StartShowSequence
// Size: 0x10(Inherited: 0x10) 
struct FStartShowSequence : public FStartShowSequence
{
	struct FName FromRoute;  // 0x0(0x8)
	struct FName ToRoute;  // 0x8(0x8)

}; 
