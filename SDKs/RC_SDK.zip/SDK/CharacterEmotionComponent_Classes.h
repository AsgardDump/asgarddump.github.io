#pragma once 
#include <CharacterEmotionComponent_Structs.h>
 
 
 
// DynamicClass CharacterEmotionComponent.CharacterEmotionComponent_C
// Size: 0x2B0(Inherited: 0x238) 
struct UCharacterEmotionComponent_C : public UKSEmotionComponent
{
	float CachedPlayerHealth;  // 0x238(0x4)
	float PainedDuration;  // 0x23C(0x4)
	int32_t FocusedId;  // 0x240(0x4)
	int32_t DeadId;  // 0x244(0x4)
	int32_t WoundedId;  // 0x248(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x24C(0x10)
	char pad_604[4];  // 0x25C(0x4)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x268(0x1)
	char pad_617[3];  // 0x269(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x26C(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x27C(0x10)
	char pad_652[4];  // 0x28C(0x4)
	struct AKSCharacterBase* K2Node_DynamicCast_AsKSCharacter_Base;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x298(0x1)
	char pad_665[3];  // 0x299(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x29C(0x10)
	char pad_684[4];  // 0x2AC(0x4)

	void ReceiveBeginPlay(); // Function CharacterEmotionComponent.CharacterEmotionComponent_C.ReceiveBeginPlay
	void Player Downed Changed(struct AKSCharacter* bpp__Character__pf); // Function CharacterEmotionComponent.CharacterEmotionComponent_C.Player Downed Changed
	void Check Death State(); // Function CharacterEmotionComponent.CharacterEmotionComponent_C.Check Death State
	void Character Health Changed(struct AKSCharacterFoundation* bpp__KSCharacterFoundation__pf); // Function CharacterEmotionComponent.CharacterEmotionComponent_C.Character Health Changed
	void Character Aim State Changed(uint8_t  bpp__NewParam__pf); // Function CharacterEmotionComponent.CharacterEmotionComponent_C.Character Aim State Changed
	void OnHealthChanged__DelegateSignature(struct AKSCharacterFoundation* bpp__Character__pf); // DelegateFunction CharacterEmotionComponent.CharacterEmotionComponent_C.OnHealthChanged__DelegateSignature
	void OnDeathStateChanged__DelegateSignature(); // DelegateFunction CharacterEmotionComponent.CharacterEmotionComponent_C.OnDeathStateChanged__DelegateSignature
	void OnCharacterDownedChanged__DelegateSignature(struct AKSCharacter* bpp__Character__pf); // DelegateFunction CharacterEmotionComponent.CharacterEmotionComponent_C.OnCharacterDownedChanged__DelegateSignature
	void OnAimStateChange__DelegateSignature(uint8_t  bpp__NewAimMode__pf); // DelegateFunction CharacterEmotionComponent.CharacterEmotionComponent_C.OnAimStateChange__DelegateSignature
}; 



