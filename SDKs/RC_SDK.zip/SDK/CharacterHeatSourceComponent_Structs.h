#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.OnTempChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnTempChanged__DelegateSignature
{
	struct UKSHeatSourceComponent* bpp__HeatSource__pf;  // 0x0(0x8)
	float bpp__NewTemperature__pf;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.OnTemperatureChanged_Event_1
// Size: 0x10(Inherited: 0x0) 
struct FOnTemperatureChanged_Event_1
{
	struct UKSHeatSourceComponent* bpp__HeatSource__pf__const;  // 0x0(0x8)
	float bpp__NewTemperature__pf;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.Apply Temperature
// Size: 0x4(Inherited: 0x0) 
struct FApply Temperature
{
	float bpp__AppliedxTemp__pfT;  // 0x0(0x4)

}; 
// Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.Conditionally Apply Temperature
// Size: 0x4(Inherited: 0x0) 
struct FConditionally Apply Temperature
{
	float bpp__AppliedxTemp__pfT;  // 0x0(0x4)

}; 
// Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.ExecuteUbergraph_CharacterHeatSourceComponent_2
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_CharacterHeatSourceComponent_2
{
	int32_t bpp__EntryPoint__pf;  // 0x0(0x4)

}; 
// Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.OnThermalVisionStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnThermalVisionStateChanged
{
	uint8_t  bpp__NewState__pf;  // 0x0(0x1)

}; 
// Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x0) 
struct FReceiveEndPlay
{
	char EEndPlayReason bpp__EndPlayReason__pf;  // 0x0(0x1)

}; 
