#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_Damage_Single.EventTracker_Damage_Single_C.ExecuteUbergraph_EventTracker_Damage_Single
// Size: 0xAA(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_Damage_Single
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FCombatEventInfo K2Node_CustomEvent_DamageInfo;  // 0x18(0x88)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_IsCombatConditionMet_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA9(0x1)

}; 
// Function EventTracker_Damage_Single.EventTracker_Damage_Single_C.OwnedPawnInstigateDamage
// Size: 0x88(Inherited: 0x0) 
struct FOwnedPawnInstigateDamage
{
	struct FCombatEventInfo DamageInfo;  // 0x0(0x88)

}; 
