#pragma once 
#include "SDK.h" 
 
 
// Function Braze.Braze.LogPurchase
// Size: 0x38(Inherited: 0x0) 
struct FLogPurchase
{
	struct FString ProductIdentifier;  // 0x0(0x10)
	struct FString CurrencyCode;  // 0x10(0x10)
	struct FString Price;  // 0x20(0x10)
	char Quantity;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function Braze.BrazePropertiesLibrary.AddFloat
// Size: 0x68(Inherited: 0x0) 
struct FAddFloat
{
	struct FBrazeProperties Properties;  // 0x0(0x50)
	struct FString Key;  // 0x50(0x10)
	float Value;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// Function Braze.Braze.LogCustomEvent
// Size: 0x10(Inherited: 0x0) 
struct FLogCustomEvent
{
	struct FString EventName;  // 0x0(0x10)

}; 
// ScriptStruct Braze.BrazeAttributionData
// Size: 0x40(Inherited: 0x0) 
struct FBrazeAttributionData
{
	struct FString Network;  // 0x0(0x10)
	struct FString Campaign;  // 0x10(0x10)
	struct FString AdGroup;  // 0x20(0x10)
	struct FString Creative;  // 0x30(0x10)

}; 
// ScriptStruct Braze.BrazeProperties
// Size: 0x50(Inherited: 0x0) 
struct FBrazeProperties
{
	struct TMap<struct FString, struct FBrazeAny> Properties;  // 0x0(0x50)

}; 
// Function Braze.BrazeUser.SetLanguage
// Size: 0x18(Inherited: 0x0) 
struct FSetLanguage
{
	struct FString Language;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Braze.BrazePropertiesLibrary.MakeBrazeAnyBoolean
// Size: 0x30(Inherited: 0x0) 
struct FMakeBrazeAnyBoolean
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FBrazeAny ReturnValue;  // 0x8(0x28)

}; 
// ScriptStruct Braze.BrazeAny
// Size: 0x28(Inherited: 0x0) 
struct FBrazeAny
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t IntValue;  // 0x4(0x4)
	float FloatValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool BooleanValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FString StringValue;  // 0x10(0x10)
	struct FDateTime DateValue;  // 0x20(0x8)

}; 
// Function Braze.Braze.ChangeUser
// Size: 0x10(Inherited: 0x0) 
struct FChangeUser
{
	struct FString UserId;  // 0x0(0x10)

}; 
// Function Braze.BrazePropertiesLibrary.MakeBrazeAnyDate
// Size: 0x30(Inherited: 0x0) 
struct FMakeBrazeAnyDate
{
	struct FDateTime Value;  // 0x0(0x8)
	struct FBrazeAny ReturnValue;  // 0x8(0x28)

}; 
// Function Braze.Braze.GetCurrentUser
// Size: 0x8(Inherited: 0x0) 
struct FGetCurrentUser
{
	struct UBrazeUser* ReturnValue;  // 0x0(0x8)

}; 
// Function Braze.Braze.LogCustomEventWithProperties
// Size: 0x60(Inherited: 0x0) 
struct FLogCustomEventWithProperties
{
	struct FString EventName;  // 0x0(0x10)
	struct FBrazeProperties Properties;  // 0x10(0x50)

}; 
// Function Braze.Braze.LogPurchaseWithProperties
// Size: 0x88(Inherited: 0x0) 
struct FLogPurchaseWithProperties
{
	struct FString ProductIdentifier;  // 0x0(0x10)
	struct FString CurrencyCode;  // 0x10(0x10)
	struct FString Price;  // 0x20(0x10)
	char Quantity;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FBrazeProperties Properties;  // 0x38(0x50)

}; 
// Function Braze.BrazePropertiesLibrary.AddBoolean
// Size: 0x68(Inherited: 0x0) 
struct FAddBoolean
{
	struct FBrazeProperties Properties;  // 0x0(0x50)
	struct FString Key;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Value : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function Braze.BrazePropertiesLibrary.AddDate
// Size: 0x68(Inherited: 0x0) 
struct FAddDate
{
	struct FBrazeProperties Properties;  // 0x0(0x50)
	struct FString Key;  // 0x50(0x10)
	struct FDateTime Value;  // 0x60(0x8)

}; 
// Function Braze.BrazeUser.SetCustomAttributeArray
// Size: 0x28(Inherited: 0x0) 
struct FSetCustomAttributeArray
{
	struct FString AttributeKey;  // 0x0(0x10)
	struct TArray<struct FString> Values;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function Braze.BrazePropertiesLibrary.AddInt
// Size: 0x68(Inherited: 0x0) 
struct FAddInt
{
	struct FBrazeProperties Properties;  // 0x0(0x50)
	struct FString Key;  // 0x50(0x10)
	int32_t Value;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// Function Braze.BrazePropertiesLibrary.AddString
// Size: 0x70(Inherited: 0x0) 
struct FAddString
{
	struct FBrazeProperties Properties;  // 0x0(0x50)
	struct FString Key;  // 0x50(0x10)
	struct FString Value;  // 0x60(0x10)

}; 
// Function Braze.BrazePropertiesLibrary.MakeBrazeAnyFloat
// Size: 0x30(Inherited: 0x0) 
struct FMakeBrazeAnyFloat
{
	float Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FBrazeAny ReturnValue;  // 0x8(0x28)

}; 
// Function Braze.BrazePropertiesLibrary.MakeBrazeAnyInt
// Size: 0x30(Inherited: 0x0) 
struct FMakeBrazeAnyInt
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FBrazeAny ReturnValue;  // 0x8(0x28)

}; 
// Function Braze.BrazePropertiesLibrary.MakeBrazeAnyString
// Size: 0x38(Inherited: 0x0) 
struct FMakeBrazeAnyString
{
	struct FString Value;  // 0x0(0x10)
	struct FBrazeAny ReturnValue;  // 0x10(0x28)

}; 
// Function Braze.BrazeUser.SetPhoneNumber
// Size: 0x18(Inherited: 0x0) 
struct FSetPhoneNumber
{
	struct FString PhoneNumber;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Braze.BrazeUser.SetCustomUserAttributeString
// Size: 0x28(Inherited: 0x0) 
struct FSetCustomUserAttributeString
{
	struct FString AttributeKey;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function Braze.BrazeSubsystem.AndroidSetLogLevel
// Size: 0x1(Inherited: 0x0) 
struct FAndroidSetLogLevel
{
	uint8_t  BrazeLogLevel;  // 0x0(0x1)

}; 
// Function Braze.BrazeSubsystem.InitializeBraze
// Size: 0x10(Inherited: 0x0) 
struct FInitializeBraze
{
	struct UBrazeConfig* Config;  // 0x0(0x8)
	struct UBraze* ReturnValue;  // 0x8(0x8)

}; 
// Function Braze.BrazeUser.SetLastName
// Size: 0x18(Inherited: 0x0) 
struct FSetLastName
{
	struct FString LastName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Braze.BrazeUser.AddAlias
// Size: 0x28(Inherited: 0x0) 
struct FAddAlias
{
	struct FString Alias;  // 0x0(0x10)
	struct FString Label;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function Braze.BrazeUser.AddToCustomAttributeArray
// Size: 0x28(Inherited: 0x0) 
struct FAddToCustomAttributeArray
{
	struct FString AttributeKey;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function Braze.BrazeUser.IncrementCustomUserAttribute
// Size: 0x18(Inherited: 0x0) 
struct FIncrementCustomUserAttribute
{
	struct FString AttributeKey;  // 0x0(0x10)
	int32_t IncrementValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function Braze.BrazeUser.SetCountry
// Size: 0x18(Inherited: 0x0) 
struct FSetCountry
{
	struct FString Country;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Braze.BrazeUser.RemoveFromCustomAttributeArray
// Size: 0x28(Inherited: 0x0) 
struct FRemoveFromCustomAttributeArray
{
	struct FString AttributeKey;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function Braze.BrazeUser.SetEmailSubscriptionType
// Size: 0x2(Inherited: 0x0) 
struct FSetEmailSubscriptionType
{
	uint8_t  SubscriptionType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function Braze.BrazeUser.SetAttributionData
// Size: 0x48(Inherited: 0x0) 
struct FSetAttributionData
{
	struct FBrazeAttributionData attributionData;  // 0x0(0x40)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function Braze.BrazeUser.SetCustomUserAttributeBool
// Size: 0x18(Inherited: 0x0) 
struct FSetCustomUserAttributeBool
{
	struct FString AttributeKey;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Value : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function Braze.BrazeUser.SetCustomUserAttributeDate
// Size: 0x20(Inherited: 0x0) 
struct FSetCustomUserAttributeDate
{
	struct FString AttributeKey;  // 0x0(0x10)
	struct FDateTime Date;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function Braze.BrazeUser.SetCustomUserAttributeFloat
// Size: 0x18(Inherited: 0x0) 
struct FSetCustomUserAttributeFloat
{
	struct FString AttributeKey;  // 0x0(0x10)
	float Value;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function Braze.BrazeUser.SetPushSubscriptionType
// Size: 0x2(Inherited: 0x0) 
struct FSetPushSubscriptionType
{
	uint8_t  SubscriptionType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function Braze.BrazeUser.SetGender
// Size: 0x2(Inherited: 0x0) 
struct FSetGender
{
	uint8_t  Gender;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function Braze.BrazeUser.SetCustomUserAttributeInt
// Size: 0x18(Inherited: 0x0) 
struct FSetCustomUserAttributeInt
{
	struct FString AttributeKey;  // 0x0(0x10)
	int32_t Value;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function Braze.BrazeUser.SetCustomUserAttributeLong
// Size: 0x20(Inherited: 0x0) 
struct FSetCustomUserAttributeLong
{
	struct FString AttributeKey;  // 0x0(0x10)
	int64_t Value;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function Braze.BrazeUser.SetDateOfBirth
// Size: 0x10(Inherited: 0x0) 
struct FSetDateOfBirth
{
	int32_t Year;  // 0x0(0x4)
	uint8_t  Month;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Day;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function Braze.BrazeUser.SetEmail
// Size: 0x18(Inherited: 0x0) 
struct FSetEmail
{
	struct FString Email;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Braze.BrazeUser.SetFirstName
// Size: 0x18(Inherited: 0x0) 
struct FSetFirstName
{
	struct FString FirstName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Braze.BrazeUser.SetHomeCity
// Size: 0x18(Inherited: 0x0) 
struct FSetHomeCity
{
	struct FString HomeCity;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Braze.BrazeUser.SetLastKnownLocation
// Size: 0x10(Inherited: 0x0) 
struct FSetLastKnownLocation
{
	float Latitude;  // 0x0(0x4)
	float Longitude;  // 0x4(0x4)
	float Altitude;  // 0x8(0x4)
	float Accuracy;  // 0xC(0x4)

}; 
// Function Braze.BrazeUser.UnsetCustomAttribute
// Size: 0x18(Inherited: 0x0) 
struct FUnsetCustomAttribute
{
	struct FString AttributeKey;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
