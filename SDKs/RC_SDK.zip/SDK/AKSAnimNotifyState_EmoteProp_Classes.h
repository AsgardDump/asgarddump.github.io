#pragma once 
#include <AKSAnimNotifyState_EmoteProp_Structs.h>
 
 
 
// BlueprintGeneratedClass AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C
// Size: 0x9C(Inherited: 0x98) 
struct UAKSAnimNotifyState_EmoteProp_C : public UKSAnimNotifyState_EmoteProp
{
	float Montage Prediction Offset;  // 0x98(0x4)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.Received_NotifyBegin
	void OnStaticMeshComponentInitialized(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration, struct UStaticMeshComponent* SpawnedStaticMeshComponent); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.OnStaticMeshComponentInitialized
	void OnSkeletalMeshComponentInitialized(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration, struct USkeletalMeshComponent* SpawnedSkeletalMeshComponent); // Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.OnSkeletalMeshComponentInitialized
}; 



