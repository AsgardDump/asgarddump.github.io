#pragma once 
#include "SDK.h" 
 
 
// Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry
// Size: 0x18(Inherited: 0x0) 
struct FSetBypassSourceEffectChainEntry
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundEffectSourcePresetChain* PresetChain;  // 0x8(0x8)
	int32_t EntryIndex;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bBypassed : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// ScriptStruct AudioMixer.SubmixEffectDynamicProcessorFilterSettings
// Size: 0xC(Inherited: 0x0) 
struct FSubmixEffectDynamicProcessorFilterSettings
{
	char bEnabled : 1;  // 0x0(0x1)
	char pad_0_1 : 7;  // 0x0(0x1)
	char pad_1[4];  // 0x1(0x4)
	float Cutoff;  // 0x4(0x4)
	float GainDb;  // 0x8(0x4)

}; 
// DelegateFunction AudioMixer.OnSynthEnvelopeValue__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnSynthEnvelopeValue__DelegateSignature
{
	float EnvelopeValue;  // 0x0(0x4)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache
// Size: 0x8(Inherited: 0x0) 
struct FTrimAudioCache
{
	float InMegabytesToFree;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// DelegateFunction AudioMixer.OnSoundLoadComplete__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSoundLoadComplete__DelegateSignature
{
	struct USoundWave* LoadedSoundWave;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool WasCancelled : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AudioMixer.SubmixEffectReverbFastSettings
// Size: 0x38(Inherited: 0x0) 
struct FSubmixEffectReverbFastSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bBypass : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Density;  // 0x4(0x4)
	float Diffusion;  // 0x8(0x4)
	float Gain;  // 0xC(0x4)
	float GainHF;  // 0x10(0x4)
	float DecayTime;  // 0x14(0x4)
	float DecayHFRatio;  // 0x18(0x4)
	float ReflectionsGain;  // 0x1C(0x4)
	float ReflectionsDelay;  // 0x20(0x4)
	float LateGain;  // 0x24(0x4)
	float LateDelay;  // 0x28(0x4)
	float AirAbsorptionGainHF;  // 0x2C(0x4)
	float WetLevel;  // 0x30(0x4)
	float DryLevel;  // 0x34(0x4)

}; 
// ScriptStruct AudioMixer.SubmixEffectDynamicsProcessorSettings
// Size: 0x50(Inherited: 0x0) 
struct FSubmixEffectDynamicsProcessorSettings
{
	uint8_t  DynamicsProcessorType;  // 0x0(0x1)
	uint8_t  PeakMode;  // 0x1(0x1)
	uint8_t  LinkMode;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float InputGainDb;  // 0x4(0x4)
	float ThresholdDb;  // 0x8(0x4)
	float Ratio;  // 0xC(0x4)
	float KneeBandwidthDb;  // 0x10(0x4)
	float LookAheadMsec;  // 0x14(0x4)
	float AttackTimeMsec;  // 0x18(0x4)
	float ReleaseTimeMsec;  // 0x1C(0x4)
	struct USoundSubmix* ExternalSubmix;  // 0x20(0x8)
	char bChannelLinked : 1;  // 0x28(0x1)
	char bAnalogMode : 1;  // 0x28(0x1)
	char bKeyAudition : 1;  // 0x28(0x1)
	char pad_40_1 : 5;  // 0x28(0x1)
	char pad_41[4];  // 0x29(0x4)
	float KeyGainDb;  // 0x2C(0x4)
	float OutputGainDb;  // 0x30(0x4)
	struct FSubmixEffectDynamicProcessorFilterSettings KeyHighshelf;  // 0x34(0xC)
	struct FSubmixEffectDynamicProcessorFilterSettings KeyLowshelf;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct AudioMixer.SubmixEffectSubmixEQSettings
// Size: 0x10(Inherited: 0x0) 
struct FSubmixEffectSubmixEQSettings
{
	struct TArray<struct FSubmixEffectEQBand> EQBands;  // 0x0(0x10)

}; 
// ScriptStruct AudioMixer.SubmixEffectEQBand
// Size: 0x10(Inherited: 0x0) 
struct FSubmixEffectEQBand
{
	float Frequency;  // 0x0(0x4)
	float Bandwidth;  // 0x4(0x4)
	float GainDb;  // 0x8(0x4)
	char bEnabled : 1;  // 0xC(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	char pad_13[4];  // 0xD(0x4)

}; 
// ScriptStruct AudioMixer.SubmixEffectReverbSettings
// Size: 0x34(Inherited: 0x0) 
struct FSubmixEffectReverbSettings
{
	float Density;  // 0x0(0x4)
	float Diffusion;  // 0x4(0x4)
	float Gain;  // 0x8(0x4)
	float GainHF;  // 0xC(0x4)
	float DecayTime;  // 0x10(0x4)
	float DecayHFRatio;  // 0x14(0x4)
	float ReflectionsGain;  // 0x18(0x4)
	float ReflectionsDelay;  // 0x1C(0x4)
	float LateGain;  // 0x20(0x4)
	float LateDelay;  // 0x24(0x4)
	float AirAbsorptionGainHF;  // 0x28(0x4)
	float WetLevel;  // 0x2C(0x4)
	float DryLevel;  // 0x30(0x4)

}; 
// Function AudioMixer.SynthComponent.IsPlaying
// Size: 0x1(Inherited: 0x0) 
struct FIsPlaying
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AudioMixer.SynthComponent.SetSubmixSend
// Size: 0x10(Inherited: 0x0) 
struct FSetSubmixSend
{
	struct USoundSubmixBase* Submix;  // 0x0(0x8)
	float SendLevel;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AudioMixer.SynthComponent.SetVolumeMultiplier
// Size: 0x4(Inherited: 0x0) 
struct FSetVolumeMultiplier
{
	float VolumeMultiplier;  // 0x0(0x4)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput
// Size: 0x18(Inherited: 0x0) 
struct FStartAnalyzingOutput
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SubmixToAnalyze;  // 0x8(0x8)
	uint8_t  FFTSize;  // 0x10(0x1)
	uint8_t  InterpolationMethod;  // 0x11(0x1)
	uint8_t  WindowType;  // 0x12(0x1)
	char pad_19[1];  // 0x13(0x1)
	float HopSize;  // 0x14(0x4)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect
// Size: 0x10(Inherited: 0x0) 
struct FAddMasterSubmixEffect
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundEffectSubmixPreset* SubmixEffectPreset;  // 0x8(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain
// Size: 0x20(Inherited: 0x0) 
struct FAddSourceEffectToPresetChain
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundEffectSourcePresetChain* PresetChain;  // 0x8(0x8)
	struct FSourceEffectChainEntry Entry;  // 0x10(0x10)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect
// Size: 0x20(Inherited: 0x0) 
struct FAddSubmixEffect
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SoundSubmix;  // 0x8(0x8)
	struct USoundEffectSubmixPreset* SubmixEffectPreset;  // 0x10(0x8)
	int32_t ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects
// Size: 0x8(Inherited: 0x0) 
struct FClearMasterSubmixEffects
{
	struct UObject* WorldContextObject;  // 0x0(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects
// Size: 0x10(Inherited: 0x0) 
struct FClearSubmixEffects
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SoundSubmix;  // 0x8(0x8)

}; 
// Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix
// Size: 0x8(Inherited: 0x0) 
struct FSetExternalSubmix
{
	struct USoundSubmix* Submix;  // 0x0(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies
// Size: 0x30(Inherited: 0x0) 
struct FGetMagnitudeForFrequencies
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<float> Frequencies;  // 0x8(0x10)
	struct TArray<float> Magnitudes;  // 0x18(0x10)
	struct USoundSubmix* SubmixToAnalyze;  // 0x28(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput
// Size: 0x18(Inherited: 0x0) 
struct FStartRecordingOutput
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	float ExpectedDuration;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct USoundSubmix* SubmixToRecord;  // 0x10(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain
// Size: 0x18(Inherited: 0x0) 
struct FGetNumberOfEntriesInSourceEffectChain
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundEffectSourcePresetChain* PresetChain;  // 0x8(0x8)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies
// Size: 0x30(Inherited: 0x0) 
struct FGetPhaseForFrequencies
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<float> Frequencies;  // 0x8(0x10)
	struct TArray<float> Phases;  // 0x18(0x10)
	struct USoundSubmix* SubmixToAnalyze;  // 0x28(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput
// Size: 0x10(Inherited: 0x0) 
struct FPauseRecordingOutput
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SubmixToPause;  // 0x8(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback
// Size: 0x8(Inherited: 0x0) 
struct FPrimeSoundCueForPlayback
{
	struct USoundCue* SoundCue;  // 0x0(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain
// Size: 0x18(Inherited: 0x0) 
struct FRemoveSourceEffectFromPresetChain
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundEffectSourcePresetChain* PresetChain;  // 0x8(0x8)
	int32_t EntryIndex;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback
// Size: 0x18(Inherited: 0x0) 
struct FPrimeSoundForPlayback
{
	struct USoundWave* SoundWave;  // 0x0(0x8)
	struct FDelegate OnLoadCompletion;  // 0x8(0x10)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect
// Size: 0x10(Inherited: 0x0) 
struct FRemoveMasterSubmixEffect
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundEffectSubmixPreset* SubmixEffectPreset;  // 0x8(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset
// Size: 0x18(Inherited: 0x0) 
struct FRemoveSubmixEffectPreset
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SoundSubmix;  // 0x8(0x8)
	struct USoundEffectSubmixPreset* SubmixEffectPreset;  // 0x10(0x8)

}; 
// Function AudioMixer.SubmixEffectReverbFastPreset.SetSettings
// Size: 0x38(Inherited: 0x0) 
struct FSetSettings
{
	struct FSubmixEffectReverbFastSettings InSettings;  // 0x0(0x38)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex
// Size: 0x18(Inherited: 0x0) 
struct FRemoveSubmixEffectPresetAtIndex
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SoundSubmix;  // 0x8(0x8)
	int32_t SubmixChainIndex;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix
// Size: 0x20(Inherited: 0x0) 
struct FReplaceSoundEffectSubmix
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* InSoundSubmix;  // 0x8(0x8)
	int32_t SubmixChainIndex;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct USoundEffectSubmixPreset* SubmixEffectPreset;  // 0x18(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput
// Size: 0x10(Inherited: 0x0) 
struct FResumeRecordingOutput
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SubmixToPause;  // 0x8(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput
// Size: 0x10(Inherited: 0x0) 
struct FStopAnalyzingOutput
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundSubmix* SubmixToStopAnalyzing;  // 0x8(0x8)

}; 
// Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput
// Size: 0x48(Inherited: 0x0) 
struct FStopRecordingOutput
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	uint8_t  ExportType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Name;  // 0x10(0x10)
	struct FString Path;  // 0x20(0x10)
	struct USoundSubmix* SubmixToRecord;  // 0x30(0x8)
	struct USoundWave* ExistingSoundWaveToOverwrite;  // 0x38(0x8)
	struct USoundWave* ReturnValue;  // 0x40(0x8)

}; 
// Function AudioMixer.SubmixEffectReverbFastPreset.SetSettingsWithReverbEffect
// Size: 0x10(Inherited: 0x0) 
struct FSetSettingsWithReverbEffect
{
	struct UReverbEffect* InReverbEffect;  // 0x0(0x8)
	float WetLevel;  // 0x8(0x4)
	float DryLevel;  // 0xC(0x4)

}; 
