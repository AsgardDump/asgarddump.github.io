#pragma once 
#include <ACLPlugin_Structs.h>
 
 
 
// Class ACLPlugin.ACLStatsDumpCommandlet
// Size: 0x80(Inherited: 0x80) 
struct UACLStatsDumpCommandlet : public UCommandlet
{

}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACLBase
// Size: 0x38(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACLBase : public UAnimBoneCompressionCodec
{

}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACL
// Size: 0x40(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACL : public UAnimBoneCompressionCodec_ACLBase
{
	struct UAnimBoneCompressionCodec* SafetyFallbackCodec;  // 0x38(0x8)

}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACLCustom
// Size: 0x38(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACLCustom : public UAnimBoneCompressionCodec_ACLBase
{

}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACLSafe
// Size: 0x38(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACLSafe : public UAnimBoneCompressionCodec_ACLBase
{

}; 



// Class ACLPlugin.AnimCurveCompressionCodec_ACL
// Size: 0x28(Inherited: 0x28) 
struct UAnimCurveCompressionCodec_ACL : public UAnimCurveCompressionCodec
{

}; 



