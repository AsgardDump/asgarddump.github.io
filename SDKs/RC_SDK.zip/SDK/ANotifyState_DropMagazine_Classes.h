#pragma once 
#include <ANotifyState_DropMagazine_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_DropMagazine.ANotifyState_DropMagazine_C
// Size: 0x31(Inherited: 0x30) 
struct UANotifyState_DropMagazine_C : public UAnimNotifyState
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Is DodgeRollReload : 1;  // 0x30(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_DropMagazine.ANotifyState_DropMagazine_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_DropMagazine.ANotifyState_DropMagazine_C.Received_NotifyBegin
}; 



