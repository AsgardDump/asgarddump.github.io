#pragma once 
#include <BloodEffectCurveComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BloodEffectCurveComponent.BloodEffectCurveComponent_C
// Size: 0x148(Inherited: 0x140) 
struct UBloodEffectCurveComponent_C : public UKSBloodSplatterComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x140(0x8)

	void UpdateScalarTrack(struct FName TrackName, float TrackValue); // Function BloodEffectCurveComponent.BloodEffectCurveComponent_C.UpdateScalarTrack
	void ExecuteUbergraph_BloodEffectCurveComponent(int32_t EntryPoint); // Function BloodEffectCurveComponent.BloodEffectCurveComponent_C.ExecuteUbergraph_BloodEffectCurveComponent
}; 



