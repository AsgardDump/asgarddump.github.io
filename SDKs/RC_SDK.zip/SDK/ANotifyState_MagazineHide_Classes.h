#pragma once 
#include <ANotifyState_MagazineHide_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_MagazineHide.ANotifyState_MagazineHide_C
// Size: 0x38(Inherited: 0x30) 
struct UANotifyState_MagazineHide_C : public UAnimNotifyState
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Is DodgeRollReload Montage : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Reverse : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool Only Unhide : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool Only Hide : 1;  // 0x33(0x1)
	int32_t WepMeshIndex;  // 0x34(0x4)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_MagazineHide.ANotifyState_MagazineHide_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_MagazineHide.ANotifyState_MagazineHide_C.Received_NotifyBegin
}; 



