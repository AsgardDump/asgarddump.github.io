#pragma once 
#include "SDK.h" 
 
 
// Function DebugMenuItem.DebugMenuItem_C.ExecuteUbergraph_DebugMenuItem
// Size: 0x39(Inherited: 0x0) 
struct FExecuteUbergraph_DebugMenuItem
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x7(0x1)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x8(0x18)
	uint8_t  K2Node_Select_Default;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UPanelWidget* CallFunc_GetParent_ReturnValue;  // 0x28(0x8)
	struct UScrollBox* K2Node_DynamicCast_AsScroll_Box;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)

}; 
// Function DebugMenuItem.DebugMenuItem_C.ItemSelected__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FItemSelected__DelegateSignature
{
	struct FDebugMenuCommandInfo Command;  // 0x0(0x18)

}; 
// Function DebugMenuItem.DebugMenuItem_C.NavigateConfirm
// Size: 0x1(Inherited: 0x1) 
struct FNavigateConfirm : public FNavigateConfirm
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
