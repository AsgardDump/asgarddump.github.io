#pragma once 
#include <BPI_SetSlomo_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_SetSlomo.BPI_SetSlomo_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_SetSlomo_C : public UInterface
{

	void SetSlomo(bool bEnableSlomo); // Function BPI_SetSlomo.BPI_SetSlomo_C.SetSlomo
}; 



