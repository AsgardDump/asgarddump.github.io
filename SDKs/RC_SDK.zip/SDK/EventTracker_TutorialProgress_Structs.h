#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.ExecuteUbergraph_EventTracker_TutorialProgress
// Size: 0x51(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_TutorialProgress
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGameplayTag CallFunc_MakeLiteralGameplayTag_ReturnValue;  // 0x4(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x20(0x8)
	struct AKSGameMode_TutorialBase* K2Node_DynamicCast_AsKSGame_Mode_Tutorial_Base;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UKSGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x38(0x8)
	struct UKSNPETrackManager* CallFunc_GetNPETrackManager_ReturnValue;  // 0x40(0x8)
	struct UKSActivityInstance* CallFunc_GetActivityInstanceByTag_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IncrementProgress_ReturnValue : 1;  // 0x50(0x1)

}; 
