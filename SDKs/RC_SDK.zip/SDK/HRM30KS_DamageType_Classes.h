#pragma once 
#include <HRM30KS_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass HRM30KS_DamageType.HRM30KS_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UHRM30KS_DamageType_C : public UMasterRifle_DamageType_C
{

}; 



