#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_Damage.EventTracker_Damage_C.ExecuteUbergraph_EventTracker_Damage
// Size: 0xB1(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_Damage
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FCombatEventInfo K2Node_CustomEvent_DamageInfo;  // 0x18(0x88)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_IsCombatConditionMet_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165_1 : 7;  // 0xA5(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xA5(0x1)
	char pad_166[2];  // 0xA6(0x2)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB0(0x1)

}; 
// Function EventTracker_Damage.EventTracker_Damage_C.PlayerStateInstigateDamage
// Size: 0x88(Inherited: 0x0) 
struct FPlayerStateInstigateDamage
{
	struct FCombatEventInfo DamageInfo;  // 0x0(0x88)

}; 
