#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListBase
// Size: 0xA8(Inherited: 0x20) 
struct FAnimNode_BlendListBase : public FAnimNode_Base
{
	struct TArray<struct FPoseLink> BlendPose;  // 0x20(0x10)
	struct TArray<float> BlendTime;  // 0x30(0x10)
	uint8_t  TransitionType;  // 0x40(0x1)
	uint8_t  BlendType;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool bResetChildOnActivation : 1;  // 0x42(0x1)
	char pad_67[5];  // 0x43(0x5)
	struct UCurveFloat* CustomBlendCurve;  // 0x48(0x8)
	struct UBlendProfile* BlendProfile;  // 0x50(0x8)
	char pad_88[80];  // 0x58(0x50)

}; 
// ScriptStruct AnimGraphRuntime.AnimLegIKDefinition
// Size: 0x2C(Inherited: 0x0) 
struct FAnimLegIKDefinition
{
	struct FBoneReference IKFootBone;  // 0x0(0x10)
	struct FBoneReference FKFootBone;  // 0x10(0x10)
	int32_t NumBonesInLimb;  // 0x20(0x4)
	float MinRotationAngle;  // 0x24(0x4)
	char EAxis FootBoneForwardAxis;  // 0x28(0x1)
	char EAxis HingeRotationAxis;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bEnableRotationLimit : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bEnableKneeTwistCorrection : 1;  // 0x2B(0x1)

}; 
// ScriptStruct AnimGraphRuntime.AngularRangeLimit
// Size: 0x28(Inherited: 0x0) 
struct FAngularRangeLimit
{
	struct FVector LimitMin;  // 0x0(0xC)
	struct FVector LimitMax;  // 0xC(0xC)
	struct FBoneReference Bone;  // 0x18(0x10)

}; 
// DelegateFunction AnimGraphRuntime.OnMontagePlayDelegate__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnMontagePlayDelegate__DelegateSignature
{
	struct FName NotifyName;  // 0x0(0x8)
	int32_t MontageInstanceID;  // 0x8(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpacePlayer
// Size: 0xF0(Inherited: 0x40) 
struct FAnimNode_BlendSpacePlayer : public FAnimNode_AssetPlayerBase
{
	float X;  // 0x40(0x4)
	float Y;  // 0x44(0x4)
	float Z;  // 0x48(0x4)
	float PlayRate;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bLoop : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool bResetPlayTimeWhenBlendSpaceChanges : 1;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	float StartPosition;  // 0x54(0x4)
	struct UBlendSpaceBase* BlendSpace;  // 0x58(0x8)
	char pad_96[136];  // 0x60(0x88)
	struct UBlendSpaceBase* PreviousBlendSpace;  // 0xE8(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CopyBone
// Size: 0x100(Inherited: 0xD8) 
struct FAnimNode_CopyBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone;  // 0xD8(0x10)
	struct FBoneReference TargetBone;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool bCopyTranslation : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool bCopyRotation : 1;  // 0xF9(0x1)
	char pad_250_1 : 7;  // 0xFA(0x1)
	bool bCopyScale : 1;  // 0xFA(0x1)
	char EBoneControlSpace ControlSpace;  // 0xFB(0x1)
	char pad_252[4];  // 0xFC(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RotationOffsetBlendSpace
// Size: 0x198(Inherited: 0xF0) 
struct FAnimNode_RotationOffsetBlendSpace : public FAnimNode_BlendSpacePlayer
{
	struct FPoseLink BasePose;  // 0xF0(0x10)
	int32_t LODThreshold;  // 0x100(0x4)
	float Alpha;  // 0x104(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x108(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x110(0x48)
	struct FName AlphaCurveName;  // 0x158(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0x160(0x30)
	char pad_400[4];  // 0x190(0x4)
	uint8_t  AlphaInputType;  // 0x194(0x1)
	char pad_405_1 : 7;  // 0x195(0x1)
	bool bAlphaBoolEnabled : 1;  // 0x195(0x1)
	char pad_406[2];  // 0x196(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ApplyAdditive
// Size: 0xD8(Inherited: 0x20) 
struct FAnimNode_ApplyAdditive : public FAnimNode_Base
{
	struct FPoseLink Base;  // 0x20(0x10)
	struct FPoseLink Additive;  // 0x30(0x10)
	float Alpha;  // 0x40(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x44(0x8)
	int32_t LODThreshold;  // 0x4C(0x4)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x50(0x48)
	struct FName AlphaCurveName;  // 0x98(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0xA0(0x30)
	char pad_208[4];  // 0xD0(0x4)
	uint8_t  AlphaInputType;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool bAlphaBoolEnabled : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimPhysPlanarLimit
// Size: 0x40(Inherited: 0x0) 
struct FAnimPhysPlanarLimit
{
	struct FBoneReference DrivingBone;  // 0x0(0x10)
	struct FTransform PlaneTransform;  // 0x10(0x30)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseHandler
// Size: 0x88(Inherited: 0x40) 
struct FAnimNode_PoseHandler : public FAnimNode_AssetPlayerBase
{
	struct UPoseAsset* PoseAsset;  // 0x40(0x8)
	char pad_72[64];  // 0x48(0x40)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseBlendNode
// Size: 0xA8(Inherited: 0x88) 
struct FAnimNode_PoseBlendNode : public FAnimNode_PoseHandler
{
	struct FPoseLink SourcePose;  // 0x88(0x10)
	uint8_t  BlendOption;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct UCurveFloat* CustomCurve;  // 0xA0(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SequenceEvaluator
// Size: 0x58(Inherited: 0x40) 
struct FAnimNode_SequenceEvaluator : public FAnimNode_AssetPlayerBase
{
	struct UAnimSequenceBase* Sequence;  // 0x40(0x8)
	float ExplicitTime;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bShouldLoop : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool bTeleportToExplicitTime : 1;  // 0x4D(0x1)
	char ESequenceEvalReinit ReinitializationBehavior;  // 0x4E(0x1)
	char pad_79[1];  // 0x4F(0x1)
	float StartPosition;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendSpaceEvaluator
// Size: 0xF8(Inherited: 0xF0) 
struct FAnimNode_BlendSpaceEvaluator : public FAnimNode_BlendSpacePlayer
{
	float NormalizedTime;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SkeletalControlBase
// Size: 0xD8(Inherited: 0x20) 
struct FAnimNode_SkeletalControlBase : public FAnimNode_Base
{
	struct FComponentSpacePoseLink ComponentPose;  // 0x20(0x10)
	int32_t LODThreshold;  // 0x30(0x4)
	float ActualAlpha;  // 0x34(0x4)
	uint8_t  AlphaInputType;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bAlphaBoolEnabled : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float Alpha;  // 0x3C(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x40(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x48(0x48)
	struct FName AlphaCurveName;  // 0x90(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0x98(0x30)
	char pad_200[16];  // 0xC8(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseDriver
// Size: 0x138(Inherited: 0x88) 
struct FAnimNode_PoseDriver : public FAnimNode_PoseHandler
{
	struct FPoseLink SourcePose;  // 0x88(0x10)
	struct TArray<struct FBoneReference> SourceBones;  // 0x98(0x10)
	struct TArray<struct FBoneReference> OnlyDriveBones;  // 0xA8(0x10)
	struct TArray<struct FPoseDriverTarget> PoseTargets;  // 0xB8(0x10)
	char pad_200[48];  // 0xC8(0x30)
	struct FBoneReference EvalSpaceBone;  // 0xF8(0x10)
	struct FRBFParams RBFParams;  // 0x108(0x2C)
	uint8_t  DriveSource;  // 0x134(0x1)
	uint8_t  DriveOutput;  // 0x135(0x1)
	char bOnlyDriveSelectedBones : 1;  // 0x136(0x1)
	char pad_310_1 : 7;  // 0x136(0x1)
	char pad_311[2];  // 0x137(0x2)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RigidBody
// Size: 0x5B0(Inherited: 0xD8) 
struct FAnimNode_RigidBody : public FAnimNode_SkeletalControlBase
{
	char pad_216[8];  // 0xD8(0x8)
	struct UPhysicsAsset* OverridePhysicsAsset;  // 0xE0(0x8)
	char pad_232[160];  // 0xE8(0xA0)
	struct FVector OverrideWorldGravity;  // 0x188(0xC)
	struct FVector ExternalForce;  // 0x194(0xC)
	struct FVector ComponentLinearAccScale;  // 0x1A0(0xC)
	struct FVector ComponentLinearVelScale;  // 0x1AC(0xC)
	struct FVector ComponentAppliedLinearAccClamp;  // 0x1B8(0xC)
	float CachedBoundsScale;  // 0x1C4(0x4)
	struct FBoneReference BaseBoneRef;  // 0x1C8(0x10)
	char ECollisionChannel OverlapChannel;  // 0x1D8(0x1)
	uint8_t  SimulationSpace;  // 0x1D9(0x1)
	char pad_474_1 : 7;  // 0x1DA(0x1)
	bool bForceDisableCollisionBetweenConstraintBodies : 1;  // 0x1DA(0x1)
	char pad_475[1];  // 0x1DB(0x1)
	char bEnableWorldGeometry : 1;  // 0x1DC(0x1)
	char bOverrideWorldGravity : 1;  // 0x1DC(0x1)
	char bTransferBoneVelocities : 1;  // 0x1DC(0x1)
	char bFreezeIncomingPoseOnStart : 1;  // 0x1DC(0x1)
	char bClampLinearTranslationLimitToRefPose : 1;  // 0x1DC(0x1)
	char pad_476_1 : 3;  // 0x1DC(0x1)
	char pad_477[4];  // 0x1DD(0x4)
	struct FSolverIterations OverrideSolverIterations;  // 0x1E0(0x18)
	char pad_504[952];  // 0x1F8(0x3B8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_AimOffsetLookAt
// Size: 0x1C0(Inherited: 0xF0) 
struct FAnimNode_AimOffsetLookAt : public FAnimNode_BlendSpacePlayer
{
	char pad_240[96];  // 0xF0(0x60)
	struct FPoseLink BasePose;  // 0x150(0x10)
	int32_t LODThreshold;  // 0x160(0x4)
	struct FName SourceSocketName;  // 0x164(0x8)
	struct FName PivotSocketName;  // 0x16C(0x8)
	struct FVector LookAtLocation;  // 0x174(0xC)
	struct FVector SocketAxis;  // 0x180(0xC)
	float Alpha;  // 0x18C(0x4)
	char pad_400[48];  // 0x190(0x30)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_AnimDynamics
// Size: 0x450(Inherited: 0xD8) 
struct FAnimNode_AnimDynamics : public FAnimNode_SkeletalControlBase
{
	float LinearDampingOverride;  // 0xD8(0x4)
	float AngularDampingOverride;  // 0xDC(0x4)
	char pad_224[96];  // 0xE0(0x60)
	struct FBoneReference RelativeSpaceBone;  // 0x140(0x10)
	struct FBoneReference BoundBone;  // 0x150(0x10)
	struct FBoneReference ChainEnd;  // 0x160(0x10)
	struct FVector BoxExtents;  // 0x170(0xC)
	struct FVector LocalJointOffset;  // 0x17C(0xC)
	float GravityScale;  // 0x188(0x4)
	struct FVector GravityOverride;  // 0x18C(0xC)
	float LinearSpringConstant;  // 0x198(0x4)
	float AngularSpringConstant;  // 0x19C(0x4)
	float WindScale;  // 0x1A0(0x4)
	struct FVector ComponentLinearAccScale;  // 0x1A4(0xC)
	struct FVector ComponentLinearVelScale;  // 0x1B0(0xC)
	struct FVector ComponentAppliedLinearAccClamp;  // 0x1BC(0xC)
	float AngularBiasOverride;  // 0x1C8(0x4)
	int32_t NumSolverIterationsPreUpdate;  // 0x1CC(0x4)
	int32_t NumSolverIterationsPostUpdate;  // 0x1D0(0x4)
	struct FAnimPhysConstraintSetup ConstraintSetup;  // 0x1D4(0x48)
	char pad_540[4];  // 0x21C(0x4)
	struct TArray<struct FAnimPhysSphericalLimit> SphericalLimits;  // 0x220(0x10)
	float SphereCollisionRadius;  // 0x230(0x4)
	struct FVector ExternalForce;  // 0x234(0xC)
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits;  // 0x240(0x10)
	uint8_t  CollisionType;  // 0x250(0x1)
	uint8_t  SimulationSpace;  // 0x251(0x1)
	char pad_594[2];  // 0x252(0x2)
	char bUseSphericalLimits : 1;  // 0x254(0x1)
	char bUsePlanarLimit : 1;  // 0x254(0x1)
	char bDoUpdate : 1;  // 0x254(0x1)
	char bDoEval : 1;  // 0x254(0x1)
	char bOverrideLinearDamping : 1;  // 0x254(0x1)
	char bOverrideAngularBias : 1;  // 0x254(0x1)
	char bOverrideAngularDamping : 1;  // 0x254(0x1)
	char bEnableWind : 1;  // 0x254(0x1)
	char pad_597_1 : 1;  // 0x255(0x1)
	char bUseGravityOverride : 1;  // 0x255(0x1)
	char bLinearSpring : 1;  // 0x255(0x1)
	char bAngularSpring : 1;  // 0x255(0x1)
	char bChain : 1;  // 0x255(0x1)
	char pad_597_2 : 3;  // 0x255(0x1)
	char pad_598[11];  // 0x256(0xB)
	struct FRotationRetargetingInfo RetargetingSettings;  // 0x260(0x130)
	char pad_912[192];  // 0x390(0xC0)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ObserveBone
// Size: 0x110(Inherited: 0xD8) 
struct FAnimNode_ObserveBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToObserve;  // 0xD8(0x10)
	char EBoneControlSpace DisplaySpace;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool bRelativeToRefPose : 1;  // 0xE9(0x1)
	char pad_234[2];  // 0xEA(0x2)
	struct FVector Translation;  // 0xEC(0xC)
	struct FRotator Rotation;  // 0xF8(0xC)
	struct FVector Scale;  // 0x104(0xC)

}; 
// ScriptStruct AnimGraphRuntime.RotationRetargetingInfo
// Size: 0x130(Inherited: 0x0) 
struct FRotationRetargetingInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FTransform Source;  // 0x10(0x30)
	struct FTransform Target;  // 0x40(0x30)
	uint8_t  RotationComponent;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	struct FVector TwistAxis;  // 0x74(0xC)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bUseAbsoluteAngle : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	float SourceMinimum;  // 0x84(0x4)
	float SourceMaximum;  // 0x88(0x4)
	float TargetMinimum;  // 0x8C(0x4)
	float TargetMaximum;  // 0x90(0x4)
	uint8_t  EasingType;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	struct FRuntimeFloatCurve CustomCurve;  // 0x98(0x88)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bFlipEasing : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	float EasingWeight;  // 0x124(0x4)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool bClamp : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendBoneByChannel
// Size: 0x78(Inherited: 0x20) 
struct FAnimNode_BlendBoneByChannel : public FAnimNode_Base
{
	struct FPoseLink A;  // 0x20(0x10)
	struct FPoseLink B;  // 0x30(0x10)
	struct TArray<struct FBlendBoneByChannelEntry> BoneDefinitions;  // 0x40(0x10)
	char pad_80[16];  // 0x50(0x10)
	float Alpha;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x68(0x8)
	char EBoneControlSpace TransformsSpace;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseByName
// Size: 0xA0(Inherited: 0x88) 
struct FAnimNode_PoseByName : public FAnimNode_PoseHandler
{
	struct FName PoseName;  // 0x88(0x8)
	float PoseWeight;  // 0x90(0x4)
	char pad_148[12];  // 0x94(0xC)

}; 
// ScriptStruct AnimGraphRuntime.IKChain
// Size: 0x38(Inherited: 0x0) 
struct FIKChain
{
	char pad_0[56];  // 0x0(0x38)

}; 
// ScriptStruct AnimGraphRuntime.AnimPhysSphericalLimit
// Size: 0x24(Inherited: 0x0) 
struct FAnimPhysSphericalLimit
{
	struct FBoneReference DrivingBone;  // 0x0(0x10)
	struct FVector SphereLocalOffset;  // 0x10(0xC)
	float LimitRadius;  // 0x1C(0x4)
	uint8_t  LimitType;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)

}; 
// ScriptStruct AnimGraphRuntime.AnimPhysConstraintSetup
// Size: 0x48(Inherited: 0x0) 
struct FAnimPhysConstraintSetup
{
	uint8_t  LinearXLimitType;  // 0x0(0x1)
	uint8_t  LinearYLimitType;  // 0x1(0x1)
	uint8_t  LinearZLimitType;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	struct FVector LinearAxesMin;  // 0x4(0xC)
	struct FVector LinearAxesMax;  // 0x10(0xC)
	uint8_t  AngularConstraintType;  // 0x1C(0x1)
	uint8_t  TwistAxis;  // 0x1D(0x1)
	uint8_t  AngularTargetAxis;  // 0x1E(0x1)
	char pad_31[1];  // 0x1F(0x1)
	float ConeAngle;  // 0x20(0x4)
	struct FVector AngularLimitsMin;  // 0x24(0xC)
	struct FVector AngularLimitsMax;  // 0x30(0xC)
	struct FVector AngularTarget;  // 0x3C(0xC)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ApplyLimits
// Size: 0xF8(Inherited: 0xD8) 
struct FAnimNode_ApplyLimits : public FAnimNode_SkeletalControlBase
{
	struct TArray<struct FAngularRangeLimit> AngularRangeLimits;  // 0xD8(0x10)
	struct TArray<struct FVector> AngularOffsets;  // 0xE8(0x10)

}; 
// ScriptStruct AnimGraphRuntime.PoseDriverTarget
// Size: 0xC0(Inherited: 0x0) 
struct FPoseDriverTarget
{
	struct TArray<struct FPoseDriverTransform> BoneTransforms;  // 0x0(0x10)
	struct FRotator TargetRotation;  // 0x10(0xC)
	float TargetScale;  // 0x1C(0x4)
	uint8_t  DistanceMethod;  // 0x20(0x1)
	uint8_t  FunctionType;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool bApplyCustomCurve : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct FRichCurve CustomCurve;  // 0x28(0x80)
	struct FName DrivenName;  // 0xA8(0x8)
	char pad_176[8];  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bIsHidden : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)

}; 
// ScriptStruct AnimGraphRuntime.BlendBoneByChannelEntry
// Size: 0x24(Inherited: 0x0) 
struct FBlendBoneByChannelEntry
{
	struct FBoneReference SourceBone;  // 0x0(0x10)
	struct FBoneReference TargetBone;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bBlendTranslation : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bBlendRotation : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool bBlendScale : 1;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByBool
// Size: 0xB0(Inherited: 0xA8) 
struct FAnimNode_BlendListByBool : public FAnimNode_BlendListBase
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bActiveValue : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByEnum
// Size: 0xC0(Inherited: 0xA8) 
struct FAnimNode_BlendListByEnum : public FAnimNode_BlendListBase
{
	struct TArray<int32_t> EnumToPoseIndex;  // 0xA8(0x10)
	char ActiveEnumValue;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BlendListByInt
// Size: 0xB0(Inherited: 0xA8) 
struct FAnimNode_BlendListByInt : public FAnimNode_BlendListBase
{
	int32_t ActiveChildIndex;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CurveSource
// Size: 0x50(Inherited: 0x20) 
struct FAnimNode_CurveSource : public FAnimNode_Base
{
	struct FPoseLink SourcePose;  // 0x20(0x10)
	struct FName SourceBinding;  // 0x30(0x8)
	float Alpha;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct TScriptInterface<ICurveSourceInterface> CurveSource;  // 0x40(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_BoneDrivenController
// Size: 0x128(Inherited: 0xD8) 
struct FAnimNode_BoneDrivenController : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone;  // 0xD8(0x10)
	struct UCurveFloat* DrivingCurve;  // 0xE8(0x8)
	float Multiplier;  // 0xF0(0x4)
	float RangeMin;  // 0xF4(0x4)
	float RangeMax;  // 0xF8(0x4)
	float RemappedMin;  // 0xFC(0x4)
	float RemappedMax;  // 0x100(0x4)
	struct FName ParameterName;  // 0x104(0x8)
	struct FBoneReference TargetBone;  // 0x10C(0x10)
	uint8_t  DestinationMode;  // 0x11C(0x1)
	uint8_t  ModificationMode;  // 0x11D(0x1)
	char EComponentType SourceComponent;  // 0x11E(0x1)
	char bUseRange : 1;  // 0x11F(0x1)
	char bAffectTargetTranslationX : 1;  // 0x11F(0x1)
	char bAffectTargetTranslationY : 1;  // 0x11F(0x1)
	char bAffectTargetTranslationZ : 1;  // 0x11F(0x1)
	char bAffectTargetRotationX : 1;  // 0x11F(0x1)
	char bAffectTargetRotationY : 1;  // 0x11F(0x1)
	char bAffectTargetRotationZ : 1;  // 0x11F(0x1)
	char bAffectTargetScaleX : 1;  // 0x11F(0x1)
	char bAffectTargetScaleY : 1;  // 0x120(0x1)
	char bAffectTargetScaleZ : 1;  // 0x120(0x1)
	char pad_288_1 : 6;  // 0x120(0x1)
	char pad_289[8];  // 0x121(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CCDIK
// Size: 0x190(Inherited: 0xD8) 
struct FAnimNode_CCDIK : public FAnimNode_SkeletalControlBase
{
	struct FVector EffectorLocation;  // 0xD8(0xC)
	char EBoneControlSpace EffectorLocationSpace;  // 0xE4(0x1)
	char pad_229[11];  // 0xE5(0xB)
	struct FBoneSocketTarget EffectorTarget;  // 0xF0(0x60)
	struct FBoneReference TipBone;  // 0x150(0x10)
	struct FBoneReference RootBone;  // 0x160(0x10)
	float Precision;  // 0x170(0x4)
	int32_t MaxIterations;  // 0x174(0x4)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool bStartFromTail : 1;  // 0x178(0x1)
	char pad_377_1 : 7;  // 0x179(0x1)
	bool bEnableRotationLimit : 1;  // 0x179(0x1)
	char pad_378[6];  // 0x17A(0x6)
	struct TArray<float> RotationLimitPerJoints;  // 0x180(0x10)

}; 
// ScriptStruct AnimGraphRuntime.BoneSocketTarget
// Size: 0x60(Inherited: 0x0) 
struct FBoneSocketTarget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseSocket : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FBoneReference BoneReference;  // 0x4(0x10)
	char pad_20[12];  // 0x14(0xC)
	struct FSocketReference SocketReference;  // 0x20(0x40)

}; 
// ScriptStruct AnimGraphRuntime.SocketReference
// Size: 0x40(Inherited: 0x0) 
struct FSocketReference
{
	char pad_0[48];  // 0x0(0x30)
	struct FName SocketName;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)

}; 
// ScriptStruct AnimGraphRuntime.SplineIKCachedBoneData
// Size: 0x14(Inherited: 0x0) 
struct FSplineIKCachedBoneData
{
	struct FBoneReference Bone;  // 0x0(0x10)
	int32_t RefSkeletonIndex;  // 0x10(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RotateRootBone
// Size: 0xB0(Inherited: 0x20) 
struct FAnimNode_RotateRootBone : public FAnimNode_Base
{
	struct FPoseLink BasePose;  // 0x20(0x10)
	float Pitch;  // 0x30(0x4)
	float Yaw;  // 0x34(0x4)
	struct FInputScaleBiasClamp PitchScaleBiasClamp;  // 0x38(0x30)
	struct FInputScaleBiasClamp YawScaleBiasClamp;  // 0x68(0x30)
	struct FRotator MeshToComponent;  // 0x98(0xC)
	char pad_164[12];  // 0xA4(0xC)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Constraint
// Size: 0x118(Inherited: 0xD8) 
struct FAnimNode_Constraint : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify;  // 0xD8(0x10)
	struct TArray<struct FConstraint> ConstraintSetup;  // 0xE8(0x10)
	struct TArray<float> ConstraintWeights;  // 0xF8(0x10)
	char pad_264[16];  // 0x108(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RotationMultiplier
// Size: 0x100(Inherited: 0xD8) 
struct FAnimNode_RotationMultiplier : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference TargetBone;  // 0xD8(0x10)
	struct FBoneReference SourceBone;  // 0xE8(0x10)
	float Multiplier;  // 0xF8(0x4)
	char EBoneAxis RotationAxisToRefer;  // 0xFC(0x1)
	char pad_253_1 : 7;  // 0xFD(0x1)
	bool bIsAdditive : 1;  // 0xFD(0x1)
	char pad_254[2];  // 0xFE(0x2)

}; 
// ScriptStruct AnimGraphRuntime.Constraint
// Size: 0x1C(Inherited: 0x0) 
struct FConstraint
{
	struct FBoneReference TargetBone;  // 0x0(0x10)
	uint8_t  OffsetOption;  // 0x10(0x1)
	uint8_t  TransformType;  // 0x11(0x1)
	struct FFilterOptionPerAxis PerAxis;  // 0x12(0x3)
	char pad_21[7];  // 0x15(0x7)

}; 
// ScriptStruct AnimGraphRuntime.RandomPlayerSequenceEntry
// Size: 0x50(Inherited: 0x0) 
struct FRandomPlayerSequenceEntry
{
	struct UAnimSequence* Sequence;  // 0x0(0x8)
	float ChanceToPlay;  // 0x8(0x4)
	int32_t MinLoopCount;  // 0xC(0x4)
	int32_t MaxLoopCount;  // 0x10(0x4)
	float MinPlayRate;  // 0x14(0x4)
	float MaxPlayRate;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FAlphaBlend BlendIn;  // 0x20(0x30)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CopyBoneDelta
// Size: 0x108(Inherited: 0xD8) 
struct FAnimNode_CopyBoneDelta : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SourceBone;  // 0xD8(0x10)
	struct FBoneReference TargetBone;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool bCopyTranslation : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool bCopyRotation : 1;  // 0xF9(0x1)
	char pad_250_1 : 7;  // 0xFA(0x1)
	bool bCopyScale : 1;  // 0xFA(0x1)
	uint8_t  CopyMode;  // 0xFB(0x1)
	float TranslationMultiplier;  // 0xFC(0x4)
	float RotationMultiplier;  // 0x100(0x4)
	float ScaleMultiplier;  // 0x104(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ModifyCurve
// Size: 0x68(Inherited: 0x20) 
struct FAnimNode_ModifyCurve : public FAnimNode_Base
{
	struct FPoseLink SourcePose;  // 0x20(0x10)
	struct TArray<float> CurveValues;  // 0x30(0x10)
	struct TArray<struct FName> CurveNames;  // 0x40(0x10)
	char pad_80[16];  // 0x50(0x10)
	float Alpha;  // 0x60(0x4)
	uint8_t  ApplyMode;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_PoseSnapshot
// Size: 0xA0(Inherited: 0x20) 
struct FAnimNode_PoseSnapshot : public FAnimNode_Base
{
	struct FName SnapshotName;  // 0x20(0x8)
	struct FPoseSnapshot Snapshot;  // 0x28(0x38)
	uint8_t  Mode;  // 0x60(0x1)
	char pad_97[63];  // 0x61(0x3F)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_MakeDynamicAdditive
// Size: 0x48(Inherited: 0x20) 
struct FAnimNode_MakeDynamicAdditive : public FAnimNode_Base
{
	struct FPoseLink Base;  // 0x20(0x10)
	struct FPoseLink Additive;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bMeshSpaceAdditive : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_CopyPoseFromMesh
// Size: 0x150(Inherited: 0x20) 
struct FAnimNode_CopyPoseFromMesh : public FAnimNode_Base
{
	struct TWeakObjectPtr<USkeletalMeshComponent> SourceMeshComponent;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bUseAttachedParent : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bCopyCurves : 1;  // 0x29(0x1)
	char pad_42[294];  // 0x2A(0x126)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Fabrik
// Size: 0x1A0(Inherited: 0xD8) 
struct FAnimNode_Fabrik : public FAnimNode_SkeletalControlBase
{
	char pad_216[8];  // 0xD8(0x8)
	struct FTransform EffectorTransform;  // 0xE0(0x30)
	struct FBoneSocketTarget EffectorTarget;  // 0x110(0x60)
	struct FBoneReference TipBone;  // 0x170(0x10)
	struct FBoneReference RootBone;  // 0x180(0x10)
	float Precision;  // 0x190(0x4)
	int32_t MaxIterations;  // 0x194(0x4)
	char EBoneControlSpace EffectorTransformSpace;  // 0x198(0x1)
	char EBoneRotationSource EffectorRotationSource;  // 0x199(0x1)
	char pad_410[6];  // 0x19A(0x6)

}; 
// ScriptStruct AnimGraphRuntime.PoseDriverTransform
// Size: 0x18(Inherited: 0x0) 
struct FPoseDriverTransform
{
	struct FVector TargetTranslation;  // 0x0(0xC)
	struct FRotator TargetRotation;  // 0xC(0xC)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_HandIKRetargeting
// Size: 0x130(Inherited: 0xD8) 
struct FAnimNode_HandIKRetargeting : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference RightHandFK;  // 0xD8(0x10)
	struct FBoneReference LeftHandFK;  // 0xE8(0x10)
	struct FBoneReference RightHandIK;  // 0xF8(0x10)
	struct FBoneReference LeftHandIK;  // 0x108(0x10)
	struct TArray<struct FBoneReference> IKBonesToMove;  // 0x118(0x10)
	float HandFKWeight;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_LayeredBoneBlend
// Size: 0xD0(Inherited: 0x20) 
struct FAnimNode_LayeredBoneBlend : public FAnimNode_Base
{
	struct FPoseLink BasePose;  // 0x20(0x10)
	struct TArray<struct FPoseLink> BlendPoses;  // 0x30(0x10)
	struct TArray<struct FInputBlendPose> LayerSetup;  // 0x40(0x10)
	struct TArray<float> BlendWeights;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bMeshSpaceRotationBlend : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool bMeshSpaceScaleBlend : 1;  // 0x61(0x1)
	char ECurveBlendOption CurveBlendOption;  // 0x62(0x1)
	char pad_99_1 : 7;  // 0x63(0x1)
	bool bBlendRootMotionBasedOnRootBone : 1;  // 0x63(0x1)
	char pad_100[4];  // 0x64(0x4)
	int32_t LODThreshold;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct TArray<struct FPerBoneBlendWeight> PerBoneBlendWeights;  // 0x70(0x10)
	struct FGuid SkeletonGuid;  // 0x80(0x10)
	struct FGuid VirtualBoneGuid;  // 0x90(0x10)
	char pad_160[48];  // 0xA0(0x30)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_LegIK
// Size: 0x108(Inherited: 0xD8) 
struct FAnimNode_LegIK : public FAnimNode_SkeletalControlBase
{
	float ReachPrecision;  // 0xD8(0x4)
	int32_t MaxIterations;  // 0xDC(0x4)
	struct TArray<struct FAnimLegIKDefinition> LegsDefinition;  // 0xE0(0x10)
	char pad_240[24];  // 0xF0(0x18)

}; 
// ScriptStruct AnimGraphRuntime.AnimLegIKData
// Size: 0xA0(Inherited: 0x0) 
struct FAnimLegIKData
{
	char pad_0[160];  // 0x0(0xA0)

}; 
// ScriptStruct AnimGraphRuntime.IKChainLink
// Size: 0x3C(Inherited: 0x0) 
struct FIKChainLink
{
	char pad_0[60];  // 0x0(0x3C)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ResetRoot
// Size: 0xE8(Inherited: 0xD8) 
struct FAnimNode_ResetRoot : public FAnimNode_SkeletalControlBase
{
	char pad_216[16];  // 0xD8(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_LookAt
// Size: 0x1C0(Inherited: 0xD8) 
struct FAnimNode_LookAt : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify;  // 0xD8(0x10)
	char pad_232[8];  // 0xE8(0x8)
	struct FBoneSocketTarget LookAtTarget;  // 0xF0(0x60)
	struct FVector LookAtLocation;  // 0x150(0xC)
	struct FAxis LookAt_Axis;  // 0x15C(0x10)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool bUseLookUpAxis : 1;  // 0x16C(0x1)
	char EInterpolationBlend InterpolationType;  // 0x16D(0x1)
	char pad_366[2];  // 0x16E(0x2)
	struct FAxis LookUp_Axis;  // 0x170(0x10)
	float LookAtClamp;  // 0x180(0x4)
	float InterpolationTime;  // 0x184(0x4)
	float InterpolationTriggerThreashold;  // 0x188(0x4)
	char pad_396[52];  // 0x18C(0x34)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ModifyBone
// Size: 0x118(Inherited: 0xD8) 
struct FAnimNode_ModifyBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference BoneToModify;  // 0xD8(0x10)
	struct FVector Translation;  // 0xE8(0xC)
	struct FRotator Rotation;  // 0xF4(0xC)
	struct FVector Scale;  // 0x100(0xC)
	char EBoneModificationMode TranslationMode;  // 0x10C(0x1)
	char EBoneModificationMode RotationMode;  // 0x10D(0x1)
	char EBoneModificationMode ScaleMode;  // 0x10E(0x1)
	char EBoneControlSpace TranslationSpace;  // 0x10F(0x1)
	char EBoneControlSpace RotationSpace;  // 0x110(0x1)
	char EBoneControlSpace ScaleSpace;  // 0x111(0x1)
	char pad_274[6];  // 0x112(0x6)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_MultiWayBlend
// Size: 0x60(Inherited: 0x20) 
struct FAnimNode_MultiWayBlend : public FAnimNode_Base
{
	struct TArray<struct FPoseLink> Poses;  // 0x20(0x10)
	struct TArray<float> DesiredAlphas;  // 0x30(0x10)
	char pad_64[16];  // 0x40(0x10)
	struct FInputScaleBias AlphaScaleBias;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bAdditiveNode : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool bNormalizeAlpha : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)

}; 
// ScriptStruct AnimGraphRuntime.RBFParams
// Size: 0x2C(Inherited: 0x0) 
struct FRBFParams
{
	int32_t TargetDimensions;  // 0x0(0x4)
	uint8_t  SolverType;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Radius;  // 0x8(0x4)
	uint8_t  Function;  // 0xC(0x1)
	uint8_t  DistanceMethod;  // 0xD(0x1)
	char EBoneAxis TwistAxis;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)
	float WeightThreshold;  // 0x10(0x4)
	uint8_t  NormalizeMethod;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FVector MedianReference;  // 0x18(0xC)
	float MedianMin;  // 0x24(0x4)
	float MedianMax;  // 0x28(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RandomPlayer
// Size: 0x88(Inherited: 0x20) 
struct FAnimNode_RandomPlayer : public FAnimNode_Base
{
	struct TArray<struct FRandomPlayerSequenceEntry> Entries;  // 0x20(0x10)
	char pad_48[80];  // 0x30(0x50)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bShuffleMode : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_MeshSpaceRefPose
// Size: 0x20(Inherited: 0x20) 
struct FAnimNode_MeshSpaceRefPose : public FAnimNode_Base
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RefPose
// Size: 0x28(Inherited: 0x20) 
struct FAnimNode_RefPose : public FAnimNode_Base
{
	char ERefPoseType RefPoseType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_RigidBody_Chaos
// Size: 0x590(Inherited: 0xD8) 
struct FAnimNode_RigidBody_Chaos : public FAnimNode_SkeletalControlBase
{
	struct UPhysicsAsset* OverridePhysicsAsset;  // 0xD8(0x8)
	struct FVector OverrideWorldGravity;  // 0xE0(0xC)
	struct FVector ExternalForce;  // 0xEC(0xC)
	struct FVector ComponentLinearAccScale;  // 0xF8(0xC)
	struct FVector ComponentLinearVelScale;  // 0x104(0xC)
	struct FVector ComponentAppliedLinearAccClamp;  // 0x110(0xC)
	float CachedBoundsScale;  // 0x11C(0x4)
	struct FBoneReference BaseBoneRef;  // 0x120(0x10)
	char ECollisionChannel OverlapChannel;  // 0x130(0x1)
	uint8_t  SimulationSpace;  // 0x131(0x1)
	char pad_306_1 : 7;  // 0x132(0x1)
	bool bForceDisableCollisionBetweenConstraintBodies : 1;  // 0x132(0x1)
	char bEnableWorldGeometry : 1;  // 0x133(0x1)
	char bOverrideWorldGravity : 1;  // 0x133(0x1)
	char bTransferBoneVelocities : 1;  // 0x133(0x1)
	char bFreezeIncomingPoseOnStart : 1;  // 0x133(0x1)
	char bClampLinearTranslationLimitToRefPose : 1;  // 0x133(0x1)
	char pad_307_1 : 3;  // 0x133(0x1)
	struct FSolverIterations OverrideSolverIterations;  // 0x134(0x18)
	char pad_332[1092];  // 0x14C(0x444)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_ScaleChainLength
// Size: 0x88(Inherited: 0x20) 
struct FAnimNode_ScaleChainLength : public FAnimNode_Base
{
	struct FPoseLink InputPose;  // 0x20(0x10)
	float DefaultChainLength;  // 0x30(0x4)
	struct FBoneReference ChainStartBone;  // 0x34(0x10)
	struct FBoneReference ChainEndBone;  // 0x44(0x10)
	struct FVector TargetLocation;  // 0x54(0xC)
	float Alpha;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x68(0x8)
	uint8_t  ChainInitialLength;  // 0x70(0x1)
	char pad_113[23];  // 0x71(0x17)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Slot
// Size: 0x58(Inherited: 0x20) 
struct FAnimNode_Slot : public FAnimNode_Base
{
	struct FPoseLink Source;  // 0x20(0x10)
	struct FName SlotName;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bAlwaysUpdateSourcePose : 1;  // 0x38(0x1)
	char pad_57[31];  // 0x39(0x1F)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SplineIK
// Size: 0x270(Inherited: 0xD8) 
struct FAnimNode_SplineIK : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference StartBone;  // 0xD8(0x10)
	struct FBoneReference EndBone;  // 0xE8(0x10)
	uint8_t  BoneAxis;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool bAutoCalculateSpline : 1;  // 0xF9(0x1)
	char pad_250[2];  // 0xFA(0x2)
	int32_t PointCount;  // 0xFC(0x4)
	struct TArray<struct FTransform> ControlPoints;  // 0x100(0x10)
	float Roll;  // 0x110(0x4)
	float TwistStart;  // 0x114(0x4)
	float TwistEnd;  // 0x118(0x4)
	char pad_284[4];  // 0x11C(0x4)
	struct FAlphaBlend TwistBlend;  // 0x120(0x30)
	float Stretch;  // 0x150(0x4)
	float Offset;  // 0x154(0x4)
	char pad_344[280];  // 0x158(0x118)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_SpringBone
// Size: 0x138(Inherited: 0xD8) 
struct FAnimNode_SpringBone : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference SpringBone;  // 0xD8(0x10)
	float MaxDisplacement;  // 0xE8(0x4)
	float SpringStiffness;  // 0xEC(0x4)
	float SpringDamping;  // 0xF0(0x4)
	float ErrorResetThresh;  // 0xF4(0x4)
	char pad_248[60];  // 0xF8(0x3C)
	char bLimitDisplacement : 1;  // 0x134(0x1)
	char bTranslateX : 1;  // 0x134(0x1)
	char bTranslateY : 1;  // 0x134(0x1)
	char bTranslateZ : 1;  // 0x134(0x1)
	char bRotateX : 1;  // 0x134(0x1)
	char bRotateY : 1;  // 0x134(0x1)
	char bRotateZ : 1;  // 0x134(0x1)
	char pad_308_1 : 1;  // 0x134(0x1)
	char pad_309[4];  // 0x135(0x4)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_StateResult
// Size: 0x40(Inherited: 0x40) 
struct FAnimNode_StateResult : public FAnimNode_Root
{

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_Trail
// Size: 0x270(Inherited: 0xD8) 
struct FAnimNode_Trail : public FAnimNode_SkeletalControlBase
{
	char pad_216[56];  // 0xD8(0x38)
	struct FBoneReference TrailBone;  // 0x110(0x10)
	int32_t ChainLength;  // 0x120(0x4)
	char EAxis ChainBoneAxis;  // 0x124(0x1)
	char bInvertChainBoneAxis : 1;  // 0x125(0x1)
	char bLimitStretch : 1;  // 0x125(0x1)
	char bLimitRotation : 1;  // 0x125(0x1)
	char bUsePlanarLimit : 1;  // 0x125(0x1)
	char bActorSpaceFakeVel : 1;  // 0x125(0x1)
	char bReorientParentToChild : 1;  // 0x125(0x1)
	char pad_293_1 : 2;  // 0x125(0x1)
	char pad_294[3];  // 0x126(0x3)
	float MaxDeltaTime;  // 0x128(0x4)
	float RelaxationSpeedScale;  // 0x12C(0x4)
	struct FRuntimeFloatCurve TrailRelaxationSpeed;  // 0x130(0x88)
	struct FInputScaleBiasClamp RelaxationSpeedScaleInputProcessor;  // 0x1B8(0x30)
	struct TArray<struct FRotationLimit> RotationLimits;  // 0x1E8(0x10)
	struct TArray<struct FVector> RotationOffsets;  // 0x1F8(0x10)
	struct TArray<struct FAnimPhysPlanarLimit> PlanarLimits;  // 0x208(0x10)
	float StretchLimit;  // 0x218(0x4)
	struct FVector FakeVelocity;  // 0x21C(0xC)
	struct FBoneReference BaseJoint;  // 0x228(0x10)
	float LastBoneRotationAnimAlphaBlend;  // 0x238(0x4)
	char pad_572[52];  // 0x23C(0x34)

}; 
// ScriptStruct AnimGraphRuntime.RotationLimit
// Size: 0x18(Inherited: 0x0) 
struct FRotationLimit
{
	struct FVector LimitMin;  // 0x0(0xC)
	struct FVector LimitMax;  // 0xC(0xC)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage
// Size: 0x30(Inherited: 0x0) 
struct FCreateProxyObjectForPlayMontage
{
	struct USkeletalMeshComponent* InSkeletalMeshComponent;  // 0x0(0x8)
	struct UAnimMontage* MontageToPlay;  // 0x8(0x8)
	int32_t CreatedInstanceID;  // 0x10(0x4)
	float PlayRate;  // 0x14(0x4)
	float StartingPosition;  // 0x18(0x4)
	struct FName StartingSection;  // 0x1C(0x8)
	char pad_36[4];  // 0x24(0x4)
	struct UPlayMontageCallbackProxy* ReturnValue;  // 0x28(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_TwistCorrectiveNode
// Size: 0x148(Inherited: 0xD8) 
struct FAnimNode_TwistCorrectiveNode : public FAnimNode_SkeletalControlBase
{
	struct FReferenceBoneFrame BaseFrame;  // 0xD8(0x20)
	struct FReferenceBoneFrame TwistFrame;  // 0xF8(0x20)
	struct FAxis TwistPlaneNormalAxis;  // 0x118(0x10)
	float RangeMax;  // 0x128(0x4)
	float RemappedMin;  // 0x12C(0x4)
	float RemappedMax;  // 0x130(0x4)
	struct FAnimCurveParam Curve;  // 0x134(0xC)
	char pad_320[8];  // 0x140(0x8)

}; 
// ScriptStruct AnimGraphRuntime.ReferenceBoneFrame
// Size: 0x20(Inherited: 0x0) 
struct FReferenceBoneFrame
{
	struct FBoneReference Bone;  // 0x0(0x10)
	struct FAxis Axis;  // 0x10(0x10)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_TwoBoneIK
// Size: 0x1F0(Inherited: 0xD8) 
struct FAnimNode_TwoBoneIK : public FAnimNode_SkeletalControlBase
{
	struct FBoneReference IKBone;  // 0xD8(0x10)
	float StartStretchRatio;  // 0xE8(0x4)
	float MaxStretchScale;  // 0xEC(0x4)
	struct FVector EffectorLocation;  // 0xF0(0xC)
	char pad_252[4];  // 0xFC(0x4)
	struct FBoneSocketTarget EffectorTarget;  // 0x100(0x60)
	struct FVector JointTargetLocation;  // 0x160(0xC)
	char pad_364[4];  // 0x16C(0x4)
	struct FBoneSocketTarget JointTarget;  // 0x170(0x60)
	struct FAxis TwistAxis;  // 0x1D0(0x10)
	char EBoneControlSpace EffectorLocationSpace;  // 0x1E0(0x1)
	char EBoneControlSpace JointTargetLocationSpace;  // 0x1E1(0x1)
	char bAllowStretching : 1;  // 0x1E2(0x1)
	char bTakeRotationFromEffectorSpace : 1;  // 0x1E2(0x1)
	char bMaintainEffectorRelRot : 1;  // 0x1E2(0x1)
	char bAllowTwist : 1;  // 0x1E2(0x1)
	char pad_482_1 : 4;  // 0x1E2(0x1)
	char pad_483[14];  // 0x1E3(0xE)

}; 
// ScriptStruct AnimGraphRuntime.AnimNode_TwoWayBlend
// Size: 0xD8(Inherited: 0x20) 
struct FAnimNode_TwoWayBlend : public FAnimNode_Base
{
	struct FPoseLink A;  // 0x20(0x10)
	struct FPoseLink B;  // 0x30(0x10)
	uint8_t  AlphaInputType;  // 0x40(0x1)
	char bAlphaBoolEnabled : 1;  // 0x41(0x1)
	char pad_65_1 : 2;  // 0x41(0x1)
	char bResetChildOnActivation : 1;  // 0x41(0x1)
	char pad_65_2 : 4;  // 0x41(0x1)
	char pad_66[3];  // 0x42(0x3)
	float Alpha;  // 0x44(0x4)
	struct FInputScaleBias AlphaScaleBias;  // 0x48(0x8)
	struct FInputAlphaBoolBlend AlphaBoolBlend;  // 0x50(0x48)
	struct FName AlphaCurveName;  // 0x98(0x8)
	struct FInputScaleBiasClamp AlphaScaleBiasClamp;  // 0xA0(0x30)
	char pad_208[8];  // 0xD0(0x8)

}; 
// ScriptStruct AnimGraphRuntime.AnimSequencerInstanceProxy
// Size: 0x970(Inherited: 0x6E0) 
struct FAnimSequencerInstanceProxy : public FAnimInstanceProxy
{
	char pad_1760[656];  // 0x6E0(0x290)

}; 
// ScriptStruct AnimGraphRuntime.PositionHistory
// Size: 0x30(Inherited: 0x0) 
struct FPositionHistory
{
	struct TArray<struct FVector> Positions;  // 0x0(0x10)
	float Range;  // 0x10(0x4)
	char pad_20[28];  // 0x14(0x1C)

}; 
// ScriptStruct AnimGraphRuntime.RBFEntry
// Size: 0x10(Inherited: 0x0) 
struct FRBFEntry
{
	struct TArray<float> Values;  // 0x0(0x10)

}; 
// ScriptStruct AnimGraphRuntime.RBFTarget
// Size: 0xA0(Inherited: 0x10) 
struct FRBFTarget : public FRBFEntry
{
	float ScaleFactor;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bApplyCustomCurve : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FRichCurve CustomCurve;  // 0x18(0x80)
	uint8_t  DistanceMethod;  // 0x98(0x1)
	uint8_t  FunctionType;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory
// Size: 0x50(Inherited: 0x0) 
struct FK2_CalculateVelocityFromPositionHistory
{
	float DeltaSeconds;  // 0x0(0x4)
	struct FVector Position;  // 0x4(0xC)
	struct FPositionHistory History;  // 0x10(0x30)
	int32_t NumberOfSamples;  // 0x40(0x4)
	float VelocityMin;  // 0x44(0x4)
	float VelocityMax;  // 0x48(0x4)
	float ReturnValue;  // 0x4C(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets
// Size: 0x100(Inherited: 0x0) 
struct FK2_CalculateVelocityFromSockets
{
	float DeltaSeconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USkeletalMeshComponent* Component;  // 0x8(0x8)
	struct FName SocketOrBoneName;  // 0x10(0x8)
	struct FName ReferenceSocketOrBone;  // 0x18(0x8)
	char ERelativeTransformSpace SocketSpace;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FVector OffsetInBoneSpace;  // 0x24(0xC)
	struct FPositionHistory History;  // 0x30(0x30)
	int32_t NumberOfSamples;  // 0x60(0x4)
	float VelocityMin;  // 0x64(0x4)
	float VelocityMax;  // 0x68(0x4)
	uint8_t  EasingType;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct FRuntimeFloatCurve CustomCurve;  // 0x70(0x88)
	float ReturnValue;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets
// Size: 0x28(Inherited: 0x0) 
struct FK2_DirectionBetweenSockets
{
	struct USkeletalMeshComponent* Component;  // 0x0(0x8)
	struct FName SocketOrBoneNameFrom;  // 0x8(0x8)
	struct FName SocketOrBoneNameTo;  // 0x10(0x8)
	struct FVector ReturnValue;  // 0x18(0xC)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange
// Size: 0x38(Inherited: 0x0) 
struct FK2_DistanceBetweenTwoSocketsAndMapRange
{
	struct USkeletalMeshComponent* Component;  // 0x0(0x8)
	struct FName SocketOrBoneNameA;  // 0x8(0x8)
	char ERelativeTransformSpace SocketSpaceA;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FName SocketOrBoneNameB;  // 0x14(0x8)
	char ERelativeTransformSpace SocketSpaceB;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool bRemapRange : 1;  // 0x1D(0x1)
	char pad_30[2];  // 0x1E(0x2)
	float InRangeMin;  // 0x20(0x4)
	float InRangeMax;  // 0x24(0x4)
	float OutRangeMin;  // 0x28(0x4)
	float OutRangeMax;  // 0x2C(0x4)
	float ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer
// Size: 0x20(Inherited: 0x0) 
struct FK2_EndProfilingTimer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLog : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString LogPrefix;  // 0x8(0x10)
	float ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt
// Size: 0x90(Inherited: 0x0) 
struct FK2_LookAt
{
	struct FTransform CurrentTransform;  // 0x0(0x30)
	struct FVector TargetPosition;  // 0x30(0xC)
	struct FVector LookAtVector;  // 0x3C(0xC)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bUseUpVector : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FVector UpVector;  // 0x4C(0xC)
	float ClampConeInDegree;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FTransform ReturnValue;  // 0x60(0x30)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap
// Size: 0x10(Inherited: 0x0) 
struct FK2_MakePerlinNoiseAndRemap
{
	float Value;  // 0x0(0x4)
	float RangeOutMin;  // 0x4(0x4)
	float RangeOutMax;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap
// Size: 0x30(Inherited: 0x0) 
struct FK2_MakePerlinNoiseVectorAndRemap
{
	float X;  // 0x0(0x4)
	float Y;  // 0x4(0x4)
	float Z;  // 0x8(0x4)
	float RangeOutMinX;  // 0xC(0x4)
	float RangeOutMaxX;  // 0x10(0x4)
	float RangeOutMinY;  // 0x14(0x4)
	float RangeOutMaxY;  // 0x18(0x4)
	float RangeOutMinZ;  // 0x1C(0x4)
	float RangeOutMaxZ;  // 0x20(0x4)
	struct FVector ReturnValue;  // 0x24(0xC)

}; 
// Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK
// Size: 0x60(Inherited: 0x0) 
struct FK2_TwoBoneIK
{
	struct FVector RootPos;  // 0x0(0xC)
	struct FVector JointPos;  // 0xC(0xC)
	struct FVector EndPos;  // 0x18(0xC)
	struct FVector JointTarget;  // 0x24(0xC)
	struct FVector Effector;  // 0x30(0xC)
	struct FVector OutJointPos;  // 0x3C(0xC)
	struct FVector OutEndPos;  // 0x48(0xC)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bAllowStretching : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	float StartStretchRatio;  // 0x58(0x4)
	float MaxStretchScale;  // 0x5C(0x4)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut
// Size: 0x10(Inherited: 0x0) 
struct FOnMontageBlendingOut
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded
// Size: 0x10(Inherited: 0x0) 
struct FOnMontageEnded
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInterrupted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived
// Size: 0x28(Inherited: 0x0) 
struct FOnNotifyBeginReceived
{
	struct FName NotifyName;  // 0x0(0x8)
	struct FBranchingPointNotifyPayload BranchingPointNotifyPayload;  // 0x8(0x20)

}; 
// Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived
// Size: 0x28(Inherited: 0x0) 
struct FOnNotifyEndReceived
{
	struct FName NotifyName;  // 0x0(0x8)
	struct FBranchingPointNotifyPayload BranchingPointNotifyPayload;  // 0x8(0x20)

}; 
