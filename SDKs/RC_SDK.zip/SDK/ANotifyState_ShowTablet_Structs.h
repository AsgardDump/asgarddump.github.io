#pragma once 
#include "SDK.h" 
 
 
// Function ANotifyState_ShowTablet.ANotifyState_ShowTablet_C.Received_NotifyBegin
// Size: 0x42(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x18(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x20(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x28(0x8)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst_2;  // 0x38(0x8)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_79_1 : 7;  // 0x4F(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x41(0x1)

}; 
// Function ANotifyState_ShowTablet.ANotifyState_ShowTablet_C.Received_NotifyEnd
// Size: 0x42(Inherited: 0x18) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x18(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x30(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst_2;  // 0x38(0x8)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x41(0x1)

}; 
