#pragma once 
#include <GuavaSpiderExplosive_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass GuavaSpiderExplosive_DamageType.GuavaSpiderExplosive_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UGuavaSpiderExplosive_DamageType_C : public UMasterExplosion_DamageType_C
{

}; 



