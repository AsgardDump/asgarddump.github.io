#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_ActivityEvent_Combat.EventTracker_ActivityEvent_Combat_C.ExecuteUbergraph_EventTracker_ActivityEvent_Combat
// Size: 0xBB(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_ActivityEvent_Combat
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FGameplayTag K2Node_CustomEvent_ActivityEventType;  // 0x24(0x8)
	char pad_44[4];  // 0x2C(0x4)
	struct FCombatEventInfo K2Node_CustomEvent_DamageInfo;  // 0x30(0x88)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_IsActivityEventTriggerConditionMet_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_IsCombatConditionMet_ReturnValue : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xBA(0x1)

}; 
// Function EventTracker_ActivityEvent_Combat.EventTracker_ActivityEvent_Combat_C.HandleCombatActivityEventTriggered
// Size: 0x90(Inherited: 0x0) 
struct FHandleCombatActivityEventTriggered
{
	struct FGameplayTag ActivityEventType;  // 0x0(0x8)
	struct FCombatEventInfo DamageInfo;  // 0x8(0x88)

}; 
