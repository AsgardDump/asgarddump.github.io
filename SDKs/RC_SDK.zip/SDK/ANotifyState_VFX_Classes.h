#pragma once 
#include <ANotifyState_VFX_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_VFX.ANotifyState_VFX_C
// Size: 0x74(Inherited: 0x30) 
struct UANotifyState_VFX_C : public UAnimNotifyState
{
	struct UParticleSystem* ParticleSystem;  // 0x30(0x8)
	struct FVector LocationOffset;  // 0x38(0xC)
	struct FRotator RotationOffset;  // 0x44(0xC)
	struct FVector Scale;  // 0x50(0xC)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool Attached : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct FName SocketName;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool UseSkinnedParticleSystem : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	struct FName SkinnedParticleSystemName;  // 0x6C(0x8)

	void GetSkinnedParticleSystemFromRelevantSkinObject(struct AActor* OwningActor, struct FName DataTableRowName, struct UParticleSystem*& OutParticleSystem); // Function ANotifyState_VFX.ANotifyState_VFX_C.GetSkinnedParticleSystemFromRelevantSkinObject
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_VFX.ANotifyState_VFX_C.Received_NotifyBegin
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_VFX.ANotifyState_VFX_C.Received_NotifyEnd
}; 



