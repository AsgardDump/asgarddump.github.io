#pragma once 
#include "SDK.h" 
 
 
// Function CamMod_Mantle.CamMod_Mantle_C.ExecuteUbergraph_CamMod_Mantle
// Size: 0x2F(Inherited: 0x0) 
struct FExecuteUbergraph_CamMod_Mantle
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_GetKSCharacterData_Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AKSCharacter* CallFunc_GetKSCharacterData_KSCharacter;  // 0x8(0x8)
	struct UKSCharacterMovementComponent* CallFunc_GetKSCharacterData_MovementComponent;  // 0x10(0x8)
	struct AKSCameraManager_C* CallFunc_GetKSCharacterData_Camera_Manager;  // 0x18(0x8)
	struct UKSCharacterAnimInst* CallFunc_GetKSCharacterAnimInst_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_3 : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_4 : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_5 : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_6 : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_7 : 1;  // 0x2E(0x1)

}; 
// Function CamMod_Mantle.CamMod_Mantle_C.ShouldModifyCamera
// Size: 0x32(Inherited: 0x20) 
struct FShouldModifyCamera : public FShouldModifyCamera
{
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bSuccess : 1;  // 0x0(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_GetKSCharacterData_Success : 1;  // 0x1(0x1)
	struct AKSCharacter* CallFunc_GetKSCharacterData_KSCharacter;  // 0x8(0x8)
	struct UKSCharacterMovementComponent* CallFunc_GetKSCharacterData_MovementComponent;  // 0x10(0x8)
	struct AKSCameraManager_C* CallFunc_GetKSCharacterData_Camera_Manager;  // 0x18(0x8)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	struct UKSCharacterAnimInst* CallFunc_GetKSCharacterAnimInst_ReturnValue;  // 0x28(0x8)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x31(0x1)

}; 
