#pragma once 
#include <Bleed_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass Bleed_DamageType.Bleed_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UBleed_DamageType_C : public UMaster_DamageType_C
{

}; 



