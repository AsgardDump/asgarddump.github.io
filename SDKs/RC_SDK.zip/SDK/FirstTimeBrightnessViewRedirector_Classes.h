#pragma once 
#include <FirstTimeBrightnessViewRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass FirstTimeBrightnessViewRedirector.FirstTimeBrightnessViewRedirector_C
// Size: 0x30(Inherited: 0x30) 
struct UFirstTimeBrightnessViewRedirector_C : public UKSViewRedirector_LocalSetting
{

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function FirstTimeBrightnessViewRedirector.FirstTimeBrightnessViewRedirector_C.DoesLocalSettingApply
}; 



