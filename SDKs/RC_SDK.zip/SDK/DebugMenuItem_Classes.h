#pragma once 
#include <DebugMenuItem_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DebugMenuItem.DebugMenuItem_C
// Size: 0x570(Inherited: 0x528) 
struct UDebugMenuItem_C : public UKSWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x528(0x8)
	struct UImage* Arrow;  // 0x530(0x8)
	struct UBorder* ColorBkg;  // 0x538(0x8)
	struct UTextBlock* CommandText;  // 0x540(0x8)
	struct FMulticastInlineDelegate ItemSelected;  // 0x548(0x10)
	struct FDebugMenuCommandInfo DebugCommand;  // 0x558(0x18)

	bool NavigateConfirm(); // Function DebugMenuItem.DebugMenuItem_C.NavigateConfirm
	void Construct(); // Function DebugMenuItem.DebugMenuItem_C.Construct
	void GamepadHover(); // Function DebugMenuItem.DebugMenuItem_C.GamepadHover
	void GamepadUnhover(); // Function DebugMenuItem.DebugMenuItem_C.GamepadUnhover
	void ExecuteUbergraph_DebugMenuItem(int32_t EntryPoint); // Function DebugMenuItem.DebugMenuItem_C.ExecuteUbergraph_DebugMenuItem
	void ItemSelected__DelegateSignature(struct FDebugMenuCommandInfo Command); // Function DebugMenuItem.DebugMenuItem_C.ItemSelected__DelegateSignature
}; 



