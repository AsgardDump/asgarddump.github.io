#pragma once 
#include <ABP_SupplyDropCharacter_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SupplyDropCharacter.ABP_SupplyDropCharacter_C
// Size: 0x1230(Inherited: 0x1150) 
struct UABP_SupplyDropCharacter_C : public UKSCharacterAnimInst
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1150(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x1158(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x1198(0x88)
	struct UAnimSequenceBase* Character Pose;  // 0x1220(0x8)
	struct UDataTable* CharacterPoseAnimations;  // 0x1228(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_SupplyDropCharacter.ABP_SupplyDropCharacter_C.AnimGraph
	void BlueprintInitializeAnimation(); // Function ABP_SupplyDropCharacter.ABP_SupplyDropCharacter_C.BlueprintInitializeAnimation
	void Set Skinned Local Parameters(struct TSet<struct FName>& Keywords); // Function ABP_SupplyDropCharacter.ABP_SupplyDropCharacter_C.Set Skinned Local Parameters
	void Force animation(); // Function ABP_SupplyDropCharacter.ABP_SupplyDropCharacter_C.Force animation
	void ExecuteUbergraph_ABP_SupplyDropCharacter(int32_t EntryPoint); // Function ABP_SupplyDropCharacter.ABP_SupplyDropCharacter_C.ExecuteUbergraph_ABP_SupplyDropCharacter
}; 



