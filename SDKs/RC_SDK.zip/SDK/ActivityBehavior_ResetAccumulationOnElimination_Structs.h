#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_ResetAccumulationOnElimination.ActivityBehavior_ResetAccumulationOnElimination_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnElimination
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_ResetAccumulationOnElimination
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x30(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x38(0x10)

}; 
// Function ActivityBehavior_ResetAccumulationOnElimination.ActivityBehavior_ResetAccumulationOnElimination_C.HandlePlayerEliminated
// Size: 0x8(Inherited: 0x0) 
struct FHandlePlayerEliminated
{
	struct AKSPlayerState* PlayerState;  // 0x0(0x8)

}; 
