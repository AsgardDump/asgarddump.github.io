#pragma once 
#include "SDK.h" 
 
 
// Function EpicAntiCheatCommon.EpicAntiCheatNetComponent.ClientMessage
// Size: 0x10(Inherited: 0x0) 
struct FClientMessage
{
	struct TArray<char> Message;  // 0x0(0x10)

}; 
// Function EpicAntiCheatCommon.EpicAntiCheatNetComponent.ServerMessage
// Size: 0x10(Inherited: 0x0) 
struct FServerMessage
{
	struct TArray<char> Message;  // 0x0(0x10)

}; 
