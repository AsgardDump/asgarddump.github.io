#pragma once 
#include <ActivityBehavior_ResetAccumulationOnElimination_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnElimination.ActivityBehavior_ResetAccumulationOnElimination_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_ResetAccumulationOnElimination_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnElimination.ActivityBehavior_ResetAccumulationOnElimination_C.HandleBehaviorInitialized
	void HandlePlayerEliminated(struct AKSPlayerState* PlayerState); // Function ActivityBehavior_ResetAccumulationOnElimination.ActivityBehavior_ResetAccumulationOnElimination_C.HandlePlayerEliminated
	void HandlePlayerKilled(); // Function ActivityBehavior_ResetAccumulationOnElimination.ActivityBehavior_ResetAccumulationOnElimination_C.HandlePlayerKilled
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnElimination(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnElimination.ActivityBehavior_ResetAccumulationOnElimination_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnElimination
}; 



