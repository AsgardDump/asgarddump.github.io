#pragma once 
#include "SDK.h" 
 
 
// Function BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C.CallRemoveTopViewRoute
// Size: 0x2(Inherited: 0x0) 
struct FCallRemoveTopViewRoute
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ForceTransition : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ViewChanged : 1;  // 0x1(0x1)

}; 
// Function BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C.CallAddViewRoute
// Size: 0xB(Inherited: 0x0) 
struct FCallAddViewRoute
{
	struct FName RouteName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ClearRouteStack : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ForceTransition : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool ViewChanged : 1;  // 0xA(0x1)

}; 
