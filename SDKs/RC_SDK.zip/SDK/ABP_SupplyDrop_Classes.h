#pragma once 
#include <ABP_SupplyDrop_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SupplyDrop.ABP_SupplyDrop_C
// Size: 0x1318(Inherited: 0x270) 
struct UABP_SupplyDrop_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x270(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x278(0x40)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x2B8(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x2F0(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x328(0x38)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // 0x360(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // 0x390(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x3C0(0x118)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x4D8(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x508(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x538(0x118)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x650(0x118)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x768(0x118)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x880(0x118)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x998(0x30)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x9C8(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x9F8(0x118)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9;  // 0xB10(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8;  // 0xB98(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7;  // 0xC20(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0xCA8(0x88)
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt_2;  // 0xD30(0xB0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0xDE0(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0xE20(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0xEA8(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0xF30(0x88)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0xFB8(0x88)
	struct FAnimNode_BlendListByInt AnimGraphNode_BlendListByInt;  // 0x1040(0xB0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x10F0(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x1130(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x11B8(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x11F8(0xC0)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x12B8(0x58)
	int32_t Number of Items;  // 0x1310(0x4)
	char pad_4884_1 : 7;  // 0x1314(0x1)
	bool isOpening : 1;  // 0x1314(0x1)
	char pad_4885_1 : 7;  // 0x1315(0x1)
	bool isOpened : 1;  // 0x1315(0x1)
	char pad_4886_1 : 7;  // 0x1316(0x1)
	bool bIsReset : 1;  // 0x1316(0x1)
	char pad_4887_1 : 7;  // 0x1317(0x1)
	bool bIsEpic : 1;  // 0x1317(0x1)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_SupplyDrop.ABP_SupplyDrop_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SupplyDrop_AnimGraphNode_TransitionResult_92A33B6C434C43A90B9215BE48C6356E(); // Function ABP_SupplyDrop.ABP_SupplyDrop_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_SupplyDrop_AnimGraphNode_TransitionResult_92A33B6C434C43A90B9215BE48C6356E
	void ExecuteUbergraph_ABP_SupplyDrop(int32_t EntryPoint); // Function ABP_SupplyDrop.ABP_SupplyDrop_C.ExecuteUbergraph_ABP_SupplyDrop
}; 



