#pragma once 
#include <HiRezNetTools_Structs.h>
 
 
 
