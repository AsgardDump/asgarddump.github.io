#pragma once 
#include "SDK.h" 
 
 
// Function DropdownEntry.DropdownEntry_C.OnOptionHovered__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnOptionHovered__DelegateSignature
{
	struct UWidget* Widget;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)

}; 
// Function DropdownEntry.DropdownEntry_C.OnOptionSelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnOptionSelected__DelegateSignature
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Text;  // 0x8(0x18)

}; 
// Function DropdownEntry.DropdownEntry_C.NavigateConfirm
// Size: 0x1(Inherited: 0x1) 
struct FNavigateConfirm : public FNavigateConfirm
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DropdownEntry.DropdownEntry_C.ExecuteUbergraph_DropdownEntry
// Size: 0x7C(Inherited: 0x0) 
struct FExecuteUbergraph_DropdownEntry
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsMobile_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x8(0x10)
	struct FDelegate Temp_delegate_Variable;  // 0x18(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2;  // 0x28(0x10)
	struct FDelegate Temp_delegate_Variable_2;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Temp_bool_Variable : 1;  // 0x48(0x1)
	uint8_t  Temp_byte_Variable;  // 0x49(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x4A(0x1)
	char pad_75[1];  // 0x4B(0x1)
	float CallFunc_GetAnimationCurrentTime_ReturnValue;  // 0x4C(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x50(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x58(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x60(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_CustomEvent_Selected : 1;  // 0x70(0x1)
	uint8_t  K2Node_Select_Default;  // 0x71(0x1)
	char pad_114[2];  // 0x72(0x2)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x74(0x4)
	int32_t CallFunc_PostEvent_ReturnValue_2;  // 0x78(0x4)

}; 
// Function DropdownEntry.DropdownEntry_C.ChangeSelectionState
// Size: 0x1(Inherited: 0x0) 
struct FChangeSelectionState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Selected : 1;  // 0x0(0x1)

}; 
