#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_ActivityEvent_TargetedWhileEquipped.EventTracker_ActivityEvent_TargetedWhileEquipped_C.ExecuteUbergraph_EventTracker_ActivityEvent_TargetedWhileEquipped
// Size: 0x7F(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_ActivityEvent_TargetedWhileEquipped
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AKSCharacterBase* CallFunc_GetCharacterOwner_ReturnValue;  // 0x18(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x30(0x8)
	struct AKSWeapon* CallFunc_GetActiveWeapon_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x44(0x10)
	char pad_84[4];  // 0x54(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_3;  // 0x58(0x8)
	struct FGameplayTag K2Node_CustomEvent_ActivityEventType;  // 0x60(0x8)
	struct AKSCharacterFoundation* K2Node_CustomEvent_TargetCharacter;  // 0x68(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_IsWeaponConditionMet_ReturnValue : 1;  // 0x7A(0x1)
	char pad_123_1 : 7;  // 0x7B(0x1)
	bool CallFunc_IsTargetConditionMet_ReturnValue : 1;  // 0x7B(0x1)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_IsActivityEventTriggerConditionMet_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x7D(0x1)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x7E(0x1)

}; 
// Function EventTracker_ActivityEvent_TargetedWhileEquipped.EventTracker_ActivityEvent_TargetedWhileEquipped_C.HandleTargetedActivityEventTriggered
// Size: 0x10(Inherited: 0x0) 
struct FHandleTargetedActivityEventTriggered
{
	struct FGameplayTag ActivityEventType;  // 0x0(0x8)
	struct AKSCharacterFoundation* TargetCharacter;  // 0x8(0x8)

}; 
