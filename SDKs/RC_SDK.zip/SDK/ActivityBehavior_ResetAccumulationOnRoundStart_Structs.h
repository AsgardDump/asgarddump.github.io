#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRoundStart
// Size: 0x3D(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRoundStart
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSGameState* CallFunc_GetKSGameState_ReturnValue;  // 0x8(0x8)
	struct AKSGameState_RoundGame* K2Node_DynamicCast_AsKSGame_State_Round_Game;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	struct FRoundInitState K2Node_CustomEvent_RoundInitState;  // 0x2C(0x10)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3C(0x1)

}; 
// Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.HandleRoundStart
// Size: 0x10(Inherited: 0x0) 
struct FHandleRoundStart
{
	struct FRoundInitState RoundInitState;  // 0x0(0x10)

}; 
