#pragma once 
#include <CensorAssets_Structs.h>
 
 
 
// Class CensorAssets.CensorTable
// Size: 0x40(Inherited: 0x28) 
struct UCensorTable : public UObject
{
	struct FSoftObjectPath CensorTablePath;  // 0x28(0x18)

}; 



