#pragma once 
#include "SDK.h" 
 
 
// Function ANotifyState_PreventReturnToHolsterFlag.ANotifyState_PreventReturnToHolsterFlag_C.Received_NotifyBegin
// Size: 0x99(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct FGameplayTagContainer CallFunc_MakeLiteralGameplayTagContainer_ReturnValue;  // 0x20(0x20)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x40(0x8)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue;  // 0x50(0x8)
	struct UKSWeaponAsset* CallFunc_GetWeaponAsset_ReturnValue;  // 0x58(0x8)
	struct UExplosiveStakeMeleeWeaponComponent_C* K2Node_DynamicCast_AsExplosive_Stake_Melee_Weapon_Component;  // 0x60(0x8)
	char pad_118_1 : 7;  // 0x76(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	struct FGameplayTag CallFunc_GetItemType_ReturnValue;  // 0x6C(0x8)
	struct FGameplayTagContainer CallFunc_MakeGameplayTagContainerFromTag_ReturnValue;  // 0x78(0x20)
	char pad_159_1 : 7;  // 0x9F(0x1)
	bool CallFunc_HasAnyTags_ReturnValue : 1;  // 0x98(0x1)

}; 
// Function ANotifyState_PreventReturnToHolsterFlag.ANotifyState_PreventReturnToHolsterFlag_C.Received_NotifyEnd
// Size: 0x11(Inherited: 0x18) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)

}; 
