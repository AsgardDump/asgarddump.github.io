#pragma once 
#include <AsyncTraceUtil_Structs.h>
 
 
 
// Class AsyncTraceUtil.AsyncTraceUtilBPLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAsyncTraceUtilBPLibrary : public UBlueprintFunctionLibrary
{

	void OnMultiAsyncTraceResult__DelegateSignature(bool bBlockingHit, struct TArray<struct FHitResult>& OutHits, struct FVector& start, struct FVector& end); // DelegateFunction AsyncTraceUtil.AsyncTraceUtilBPLibrary.OnMultiAsyncTraceResult__DelegateSignature
	void MultiSphereSweepByChannelAsync(struct UObject* WorldContextObject, struct FVector& start, struct FVector& end, char ECollisionChannel TraceChannel, float SphereRadius, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, char EDrawDebugTrace DrawDebugType, struct FDelegate OnTraceComplete, bool bIgnoreSelf, struct FLatentActionInfo LatentInfo, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultiSphereSweepByChannelAsync
	bool MultipleLineTraceAsync(struct UObject* WorldContextObject, struct TArray<struct FVector> Starts, struct TArray<struct FVector> Ends, char ECollisionChannel TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, char EDrawDebugTrace DrawDebugType, struct TArray<struct FHitResult>& OutHits, bool bIgnoreSelf, struct FLatentActionInfo LatentInfo, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultipleLineTraceAsync
	void MultiLineTraceByChannelAsync(struct UObject* WorldContextObject, struct FVector& start, struct FVector& end, char ECollisionChannel TraceChannel, bool bTraceComplex, struct TArray<struct AActor*>& ActorsToIgnore, char EDrawDebugTrace DrawDebugType, struct FDelegate OnTraceComplete, bool bIgnoreSelf, struct FLatentActionInfo LatentInfo, struct FLinearColor TraceColor, struct FLinearColor TraceHitColor, float DrawTime); // Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultiLineTraceByChannelAsync
}; 



