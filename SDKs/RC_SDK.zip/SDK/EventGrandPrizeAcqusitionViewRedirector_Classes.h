#pragma once 
#include <EventGrandPrizeAcqusitionViewRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass EventGrandPrizeAcqusitionViewRedirector.EventGrandPrizeAcqusitionViewRedirector_C
// Size: 0x38(Inherited: 0x38) 
struct UEventGrandPrizeAcqusitionViewRedirector_C : public UKSAcquisitionViewRedirector
{

}; 



