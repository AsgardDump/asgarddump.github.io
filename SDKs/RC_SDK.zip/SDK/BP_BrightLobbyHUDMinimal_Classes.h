#pragma once 
#include <BP_BrightLobbyHUDMinimal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C
// Size: 0x6E0(Inherited: 0x6D8) 
struct ABP_BrightLobbyHUDMinimal_C : public AKSLobbyHUDNew
{
	struct USceneComponent* DefaultSceneRoot;  // 0x6D8(0x8)

	void CallRemoveTopViewRoute(bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C.CallRemoveTopViewRoute
	void CallAddViewRoute(struct FName RouteName, bool ClearRouteStack, bool ForceTransition, bool& ViewChanged); // Function BP_BrightLobbyHUDMinimal.BP_BrightLobbyHUDMinimal_C.CallAddViewRoute
}; 



