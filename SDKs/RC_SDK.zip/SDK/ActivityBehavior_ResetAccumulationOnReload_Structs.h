#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_ResetAccumulationOnReload.ActivityBehavior_ResetAccumulationOnReload_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnReload
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_ResetAccumulationOnReload
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)

}; 
