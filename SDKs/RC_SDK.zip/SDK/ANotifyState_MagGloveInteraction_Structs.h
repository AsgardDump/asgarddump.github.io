#pragma once 
#include "SDK.h" 
 
 
// Function ANotifyState_MagGloveInteraction.ANotifyState_MagGloveInteraction_C.Received_NotifyBegin
// Size: 0x29(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x18(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x20(0x8)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function ANotifyState_MagGloveInteraction.ANotifyState_MagGloveInteraction_C.Received_NotifyEnd
// Size: 0x29(Inherited: 0x18) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x18(0x8)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
