#pragma once 
#include <EventTracker_Reveal_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_Reveal.EventTracker_Reveal_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_Reveal_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_Reveal.EventTracker_Reveal_C.HandleTrackerInitialized
	void HandleRevealTriggered(struct FKSRevealInfo RevealInfo); // Function EventTracker_Reveal.EventTracker_Reveal_C.HandleRevealTriggered
	void ExecuteUbergraph_EventTracker_Reveal(int32_t EntryPoint); // Function EventTracker_Reveal.EventTracker_Reveal_C.ExecuteUbergraph_EventTracker_Reveal
}; 



