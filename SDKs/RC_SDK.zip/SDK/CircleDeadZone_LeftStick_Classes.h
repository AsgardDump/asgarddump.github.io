#pragma once 
#include <CircleDeadZone_LeftStick_Structs.h>
 
 
 
// BlueprintGeneratedClass CircleDeadZone_LeftStick.CircleDeadZone_LeftStick_C
// Size: 0x40(Inherited: 0x40) 
struct UCircleDeadZone_LeftStick_C : public UKSCircleDeadZoneFilter
{

}; 



