#pragma once 
#include <FirstTimeLanguageWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FirstTimeLanguageWidget.FirstTimeLanguageWidget_C
// Size: 0x520(Inherited: 0x4C8) 
struct UFirstTimeLanguageWidget_C : public UPUMG_Widget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C8(0x8)
	struct UImage* Decro;  // 0x4D0(0x8)
	struct UImage* Image_159;  // 0x4D8(0x8)
	struct UOverlay* SettingsWidgetContainer;  // 0x4E0(0x8)
	struct UTextBlock* Title;  // 0x4E8(0x8)
	struct UWBP_StandardButtonMedium_C* WBP_StandardButtonMedium;  // 0x4F0(0x8)
	struct FKSSettingsWidgetConfig SettingsWidgetConfig;  // 0x4F8(0x10)
	struct UKSSettingsInfoBase* SettingsInfo;  // 0x508(0x8)
	struct UKSSettingsWidget* SettingsWidget;  // 0x510(0x8)
	struct UAkAudioEvent* ShowFirstTimeLanguageSFX;  // 0x518(0x8)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.InitializeWidget
	void OnShown(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.OnShown
	void BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(struct UWidget* Widget); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.PreConstruct
	void HandleInputState(char PGAME_INPUT_STATE InputState); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.HandleInputState
	void SaveSetting(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.SaveSetting
	void OnHide(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.OnHide
	void OnSettingSelected(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.OnSettingSelected
	void InitializeWidgetNavigation(); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.InitializeWidgetNavigation
	void ExecuteUbergraph_FirstTimeLanguageWidget(int32_t EntryPoint); // Function FirstTimeLanguageWidget.FirstTimeLanguageWidget_C.ExecuteUbergraph_FirstTimeLanguageWidget
}; 



