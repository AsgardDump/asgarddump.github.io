#pragma once 
#include <FirstTimeTutorialWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FirstTimeTutorialWidget.FirstTimeTutorialWidget_C
// Size: 0x518(Inherited: 0x4C8) 
struct UFirstTimeTutorialWidget_C : public UPUMG_Widget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C8(0x8)
	struct UWidgetAnimation* Show;  // 0x4D0(0x8)
	struct UImage* Blocker;  // 0x4D8(0x8)
	struct UImage* Decro;  // 0x4E0(0x8)
	struct UImage* Image_134;  // 0x4E8(0x8)
	struct UTextBlock* TextBlock_295;  // 0x4F0(0x8)
	struct UWBP_ModalPopupContainer_C* WBP_ModalPopupContainer;  // 0x4F8(0x8)
	struct UWBP_StandardButtonLarge_C* WBP_StandardButtonLarge;  // 0x500(0x8)
	struct UWBP_StandardButtonMedium_C* WBP_StandardButtonMedium;  // 0x508(0x8)
	struct UAkAudioEvent* ShowTutorialWidgetSFX;  // 0x510(0x8)

	void LaunchTutorial(bool Force Close Screen); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.LaunchTutorial
	void InitializeWidgetNavigation(); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.InitializeWidgetNavigation
	void OnShown(); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.OnShown
	void PreConstruct(bool IsDesignTime); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.PreConstruct
	void BndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(struct UWidget* Widget); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.BndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
	void BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature(struct UWidget* Widget); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature
	void BndEvt__WBP_ModalPopupContainer_K2Node_ComponentBoundEvent_9_CloseButtonClicked__DelegateSignature(); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.BndEvt__WBP_ModalPopupContainer_K2Node_ComponentBoundEvent_9_CloseButtonClicked__DelegateSignature
	void OnHide(); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.OnHide
	void ExecuteUbergraph_FirstTimeTutorialWidget(int32_t EntryPoint); // Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.ExecuteUbergraph_FirstTimeTutorialWidget
}; 



