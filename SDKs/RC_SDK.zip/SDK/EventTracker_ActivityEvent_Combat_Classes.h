#pragma once 
#include <EventTracker_ActivityEvent_Combat_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_ActivityEvent_Combat.EventTracker_ActivityEvent_Combat_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_ActivityEvent_Combat_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_ActivityEvent_Combat.EventTracker_ActivityEvent_Combat_C.HandleTrackerInitialized
	void HandleCombatActivityEventTriggered(struct FGameplayTag ActivityEventType, struct FCombatEventInfo& DamageInfo); // Function EventTracker_ActivityEvent_Combat.EventTracker_ActivityEvent_Combat_C.HandleCombatActivityEventTriggered
	void ExecuteUbergraph_EventTracker_ActivityEvent_Combat(int32_t EntryPoint); // Function EventTracker_ActivityEvent_Combat.EventTracker_ActivityEvent_Combat_C.ExecuteUbergraph_EventTracker_ActivityEvent_Combat
}; 



