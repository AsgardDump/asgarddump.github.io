#pragma once 
#include "SDK.h" 
 
 
// Function DamageResistModInst.DamageResistModInst_C.ExecuteUbergraph_DamageResistModInst
// Size: 0x9C(Inherited: 0x0) 
struct FExecuteUbergraph_DamageResistModInst
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue;  // 0x20(0x8)
	struct AActor* K2Node_CustomEvent_DamagedActor;  // 0x28(0x8)
	float K2Node_CustomEvent_Damage;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UDamageType* K2Node_CustomEvent_DamageType;  // 0x38(0x8)
	struct AController* K2Node_CustomEvent_InstigatedBy;  // 0x40(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	UDamageType* CallFunc_GetObjectClass_ReturnValue;  // 0x58(0x8)
	struct UKSPlayerMod* CallFunc_GetModAsset_ReturnValue;  // 0x60(0x8)
	struct UKSPlayerMod_DamageTaken* K2Node_DynamicCast_AsKSPlayer_Mod_Damage_Taken;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x74(0x4)
	struct TArray<UDamageType*> CallFunc_GetValidDamageTypes_ReturnValue;  // 0x78(0x10)
	UDamageType* CallFunc_Array_Get_Item;  // 0x88(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_ClassIsChildOf_ReturnValue : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x95(0x1)
	char pad_150_1 : 7;  // 0x96(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x96(0x1)
	char pad_151[1];  // 0x97(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x98(0x4)

}; 
// Function DamageResistModInst.DamageResistModInst_C.DamageTaken
// Size: 0x28(Inherited: 0x0) 
struct FDamageTaken
{
	struct AActor* DamagedActor;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UDamageType* DamageType;  // 0x10(0x8)
	struct AController* InstigatedBy;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
