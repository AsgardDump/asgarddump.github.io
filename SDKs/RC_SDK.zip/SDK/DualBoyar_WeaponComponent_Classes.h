#pragma once 
#include <DualBoyar_WeaponComponent_Structs.h>
 
 
 
// DynamicClass DualBoyar_WeaponComponent.DualBoyar_WeaponComponent_C
// Size: 0x1640(Inherited: 0x15C0) 
struct UDualBoyar_WeaponComponent_C : public UMasterDualSMGs_WeaponComponent_C
{
	struct TArray<struct UKSPlayerMod*> AdsMods;  // 0x15C0(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x15D0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x15D4(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x15D8(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x15DC(0x4)
	uint8_t  K2Node_CustomEvent_NewAimMode;  // 0x15E0(0x1)
	char pad_5601[7];  // 0x15E1(0x7)
	struct AMainCharacter_C* K2Node_DynamicCast_AsMain_Character;  // 0x15E8(0x8)
	char pad_5616_1 : 7;  // 0x15F0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x15F0(0x1)
	char pad_5617_1 : 7;  // 0x15F1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x15F1(0x1)
	char pad_5618[6];  // 0x15F2(0x6)
	struct AMainCharacter_C* K2Node_DynamicCast_AsMain_Character_2;  // 0x15F8(0x8)
	char pad_5632_1 : 7;  // 0x1600(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1600(0x1)
	char pad_5633[7];  // 0x1601(0x7)
	struct AMainCharacter_C* K2Node_DynamicCast_AsMain_Character_3;  // 0x1608(0x8)
	char pad_5648_1 : 7;  // 0x1610(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1610(0x1)
	char pad_5649[7];  // 0x1611(0x7)
	struct UKSPlayerMod* CallFunc_Array_Get_Item;  // 0x1618(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1620(0x10)
	struct UKSPlayerMod* CallFunc_Array_Get_Item_2;  // 0x1630(0x8)
	char pad_5688[8];  // 0x1638(0x8)

	void asdasd(uint8_t  bpp__NewAimMode__pf); // Function DualBoyar_WeaponComponent.DualBoyar_WeaponComponent_C.asdasd
	void OnAimStateChange__DelegateSignature(uint8_t  bpp__NewAimMode__pf); // DelegateFunction DualBoyar_WeaponComponent.DualBoyar_WeaponComponent_C.OnAimStateChange__DelegateSignature
}; 



