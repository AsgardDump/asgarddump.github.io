#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_ActivityEvent.EventTracker_ActivityEvent_C.ExecuteUbergraph_EventTracker_ActivityEvent
// Size: 0x2D(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_ActivityEvent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FGameplayTag K2Node_CustomEvent_ActivityEventType;  // 0x24(0x8)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsActivityEventTriggerConditionMet_ReturnValue : 1;  // 0x2C(0x1)

}; 
// Function EventTracker_ActivityEvent.EventTracker_ActivityEvent_C.HandleActivityEventTriggered
// Size: 0x8(Inherited: 0x0) 
struct FHandleActivityEventTriggered
{
	struct FGameplayTag ActivityEventType;  // 0x0(0x8)

}; 
