#pragma once 
#include <FirstTimeSafeZoneViewRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass FirstTimeSafeZoneViewRedirector.FirstTimeSafeZoneViewRedirector_C
// Size: 0x30(Inherited: 0x30) 
struct UFirstTimeSafeZoneViewRedirector_C : public UKSViewRedirector_LocalSetting
{

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function FirstTimeSafeZoneViewRedirector.FirstTimeSafeZoneViewRedirector_C.DoesLocalSettingApply
}; 



