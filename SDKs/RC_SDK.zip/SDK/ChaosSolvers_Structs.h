#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ChaosSolvers.SolverBreakingFilterSettings
// Size: 0x10(Inherited: 0x0) 
struct FSolverBreakingFilterSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FilterEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinVolume;  // 0xC(0x4)

}; 
// ScriptStruct ChaosSolvers.SolverTrailingFilterSettings
// Size: 0x10(Inherited: 0x0) 
struct FSolverTrailingFilterSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FilterEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinVolume;  // 0xC(0x4)

}; 
// ScriptStruct ChaosSolvers.SolverCollisionFilterSettings
// Size: 0x10(Inherited: 0x0) 
struct FSolverCollisionFilterSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FilterEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinImpulse;  // 0xC(0x4)

}; 
