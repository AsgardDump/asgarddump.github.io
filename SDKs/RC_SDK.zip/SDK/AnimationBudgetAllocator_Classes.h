#pragma once 
#include <AnimationBudgetAllocator_Structs.h>
 
 
 
// Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
}; 



// Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted
// Size: 0xBB0(Inherited: 0xB90) 
struct USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{
	char pad_2960[24];  // 0xB90(0x18)
	char bAutoRegisterWithBudgetAllocator : 1;  // 0xBA8(0x1)
	char bAutoCalculateSignificance : 1;  // 0xBA8(0x1)
	char bShouldUseActorRenderedFlag : 1;  // 0xBA8(0x1)
	char pad_2984_1 : 5;  // 0xBA8(0x1)
	char pad_2985[8];  // 0xBA9(0x8)

	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
}; 



