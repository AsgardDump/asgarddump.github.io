#pragma once 
#include "SDK.h" 
 
 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.TurnOnMeter__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FTurnOnMeter__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsOn : 1;  // 0x0(0x1)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.TurnOffMeter__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FTurnOffMeter__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsOn : 1;  // 0x0(0x1)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UpdateDisplay__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FUpdateDisplay__DelegateSignature
{
	struct FText QuantityText;  // 0x0(0x18)
	int32_t CurrentCharge;  // 0x18(0x4)
	int32_t RequiredCharge;  // 0x1C(0x4)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UpdateFillMeterDisplay
// Size: 0x29(Inherited: 0x0) 
struct FUpdateFillMeterDisplay
{
	int32_t CurrentCharge;  // 0x0(0x4)
	int32_t RequiredCharge;  // 0x4(0x4)
	float Temp_float_Variable;  // 0x8(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float K2Node_Select_Default;  // 0x1C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_FMin_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.HandleModActivated
// Size: 0x1(Inherited: 0x0) 
struct FHandleModActivated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InBool : 1;  // 0x0(0x1)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UpdateCharge
// Size: 0x64(Inherited: 0x0) 
struct FUpdateCharge
{
	struct UKSModInst_Activated* KSModInstActivated;  // 0x0(0x8)
	struct FText Quantity Text;  // 0x8(0x18)
	int32_t CallFunc_GetRequiredCharge_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UKSPlayerMod_Activated* CallFunc_GetActivatedModAsset_ReturnValue;  // 0x28(0x8)
	int32_t CallFunc_GetRequiredCharge_ReturnValue_2;  // 0x30(0x4)
	int32_t CallFunc_GetCurrentCharge_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x48(0x18)
	int32_t CallFunc_GetRequiredCharge_ReturnValue_3;  // 0x60(0x4)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.PostFlashTrapActivated__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FPostFlashTrapActivated__DelegateSignature
{
	struct UTexture2D* NewIcon;  // 0x0(0x8)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.SetFillValue__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FSetFillValue__DelegateSignature
{
	float SetFillValue;  // 0x0(0x4)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.ExecuteUbergraph_BP_AbilityIconAnimationHelper
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AbilityIconAnimationHelper
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UTexture2D* Temp_object_Variable;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Temp_bool_Variable : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_2 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct UKSModInst_Activated* K2Node_CustomEvent_KSModInstActivated;  // 0x18(0x8)
	struct UKSPlayerMod_Activated* K2Node_CustomEvent_KSPlayerModActivated;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_CustomEvent_InBool : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UKSPlayerMod_Activated* CallFunc_GetActivatedModAsset_ReturnValue;  // 0x30(0x8)
	struct UFlashTrapModInst_C* K2Node_DynamicCast_AsFlash_Trap_Mod_Inst;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x43(0x1)
	float CallFunc_Lerp_ReturnValue;  // 0x44(0x4)
	struct UTexture2D* Temp_object_Variable_2;  // 0x48(0x8)
	struct UTexture2D* K2Node_Select_Default;  // 0x50(0x8)
	struct AKSHUDCommon* K2Node_DynamicCast_AsKSHUDCommon;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState;  // 0x68(0x8)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.DownStateChange
// Size: 0x8(Inherited: 0x0) 
struct FDownStateChange
{
	struct AKSPlayerState* PlayerState;  // 0x0(0x8)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.HandlePlayerModCharge
// Size: 0x8(Inherited: 0x0) 
struct FHandlePlayerModCharge
{
	struct UKSPlayerMod_Activated* KSPlayerModActivated;  // 0x0(0x8)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.HandleModChargeChange
// Size: 0x8(Inherited: 0x0) 
struct FHandleModChargeChange
{
	struct UKSModInst_Activated* KSModInstActivated;  // 0x0(0x8)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.CheckForFullCharge
// Size: 0x17(Inherited: 0x0) 
struct FCheckForFullCharge
{
	struct UKSModInst_Activated* KSModInstActivated;  // 0x0(0x8)
	struct AKSPlayerState* CallFunc_GetPlayerStateOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsDowned_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_CanActivateWhileDowned_ReturnValue : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x16(0x1)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.BindToChanges
// Size: 0x44(Inherited: 0x0) 
struct FBindToChanges
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x34(0x10)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UnbindChanges
// Size: 0x44(Inherited: 0x0) 
struct FUnbindChanges
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x34(0x10)

}; 
// Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.TrySetupBasicDisplay
// Size: 0x9(Inherited: 0x0) 
struct FTrySetupBasicDisplay
{
	struct UKSPlayerMod_Activated* CallFunc_GetDisplayActivatedModAsset_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)

}; 
