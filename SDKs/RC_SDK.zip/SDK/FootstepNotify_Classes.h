#pragma once 
#include <FootstepNotify_Structs.h>
 
 
 
// DynamicClass FootstepNotify.FootstepNotify_C
// Size: 0x58(Inherited: 0x48) 
struct UFootstepNotify_C : public UKSAnimNotify_Footstep
{
	uint8_t  StepType;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FName BoneName;  // 0x4C(0x8)
	char pad_84[4];  // 0x54(0x4)

	bool Received_Notify(struct USkeletalMeshComponent* bpp__MeshComp__pf, struct UAnimSequenceBase* bpp__Animation__pf); // Function FootstepNotify.FootstepNotify_C.Received_Notify
	void GetSFXMaterial(struct UAnimInstance* bpp__AnimInstance__pf, struct FName bpp__BonexName__pfT, struct FName& bpp__MaterialxReturn__pfT, struct AActor*& bpp__ActorxReturn__pfT); // Function FootstepNotify.FootstepNotify_C.GetSFXMaterial
	struct FName GetBoneName(); // Function FootstepNotify.FootstepNotify_C.GetBoneName
	bool CanStepTypeShowFootprint(struct AKSCharacter* bpp__CheckCharacter__pf); // Function FootstepNotify.FootstepNotify_C.CanStepTypeShowFootprint
}; 



