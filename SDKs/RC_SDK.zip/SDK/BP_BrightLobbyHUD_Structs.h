#pragma once 
#include "SDK.h" 
 
 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Loadout Slot Change__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FLoadout Slot Change__DelegateSignature
{
	char Loadout Slot Edit;  // 0x0(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.ExecuteUbergraph_BP_BrightLobbyHUD
// Size: 0x2B0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BrightLobbyHUD
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UKSEMODataFactory* CallFunc_GetEMODataFactory_ReturnValue;  // 0x8(0x8)
	float K2Node_Event_SafeFrameScale;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct UPUMG_ViewManager* CallFunc_GetViewManager_ReturnValue;  // 0x18(0x8)
	struct UPUMG_PlayerInfo* K2Node_Event_Player;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_RemoveRoute_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct UKSQueueDataFactory* CallFunc_GetKSQueueDataFactory_ReturnValue;  // 0x30(0x8)
	struct FClientQueueInfo CallFunc_GetCurrentCustomMatchInfo_InClientQueueInfo;  // 0x38(0xE8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_GetCurrentCustomMatchInfo_ReturnValue : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_Add_View_Route_ViewChanged : 1;  // 0x121(0x1)
	char pad_290_1 : 7;  // 0x122(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x122(0x1)
	char pad_291[5];  // 0x123(0x5)
	struct UPUMG_ViewManager* CallFunc_GetViewManager_ReturnValue_2;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_ReplaceRoute_ReturnValue : 1;  // 0x130(0x1)
	uint8_t  K2Node_Event_MatchStatus;  // 0x131(0x1)
	char pad_306_1 : 7;  // 0x132(0x1)
	bool CallFunc_HasCurrentMatchId_ReturnValue : 1;  // 0x132(0x1)
	char pad_307_1 : 7;  // 0x133(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x133(0x1)
	char pad_308_1 : 7;  // 0x134(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x134(0x1)
	char pad_309[3];  // 0x135(0x3)
	struct FString K2Node_Event_MediaUrl;  // 0x138(0x10)
	int32_t K2Node_Event_WatchTimer;  // 0x148(0x4)
	char pad_332[4];  // 0x14C(0x4)
	struct UPUMG_ViewManager* CallFunc_GetViewManager_ReturnValue_3;  // 0x150(0x8)
	struct UTestMediaPlayerParams_C* CallFunc_SpawnObject_ReturnValue;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_PushRoute_ReturnValue : 1;  // 0x161(0x1)
	char pad_354_1 : 7;  // 0x162(0x1)
	bool K2Node_Event_BeginChatCommand : 1;  // 0x162(0x1)
	char pad_355[5];  // 0x163(0x5)
	struct UPUMG_PlayerInfo* K2Node_CustomEvent_Inviter;  // 0x168(0x8)
	struct APlayerController* CallFunc_GetOwningPlayerController_ReturnValue;  // 0x170(0x8)
	struct FText CallFunc_GetName_ReturnValue;  // 0x178(0x18)
	struct APlayerController* CallFunc_GetOwningPlayerController_ReturnValue_2;  // 0x190(0x8)
	struct UBrightLobbyWidget_C* CallFunc_Create_ReturnValue;  // 0x198(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1A0(0x10)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool CallFunc_AddToPlayerScreen_ReturnValue : 1;  // 0x1B0(0x1)
	char pad_433[3];  // 0x1B1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1B4(0x10)
	char pad_452[4];  // 0x1C4(0x4)
	struct UPUMG_LoginDataFactory* CallFunc_GetLoginDataFactory_ReturnValue;  // 0x1C8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x1D0(0x10)
	uint8_t  CallFunc_GetCurrentLoginState_ReturnValue;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct UKSPartyDataFactory* CallFunc_GetPartyDataFactory_ReturnValue;  // 0x1E8(0x8)
	struct UKSEMODataFactory* CallFunc_GetEMODataFactory_ReturnValue_2;  // 0x1F0(0x8)
	struct FPlayerRewardsSummary K2Node_CustomEvent_playerRewardsSummary;  // 0x1F8(0x50)
	struct FScoreboardStats K2Node_CustomEvent_scoreBoardStats;  // 0x248(0x68)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.TestMediaPlayerUrl
// Size: 0x14(Inherited: 0x18) 
struct FTestMediaPlayerUrl : public FTestMediaPlayerUrl
{
	struct FString MediaUrl;  // 0x0(0x10)
	int32_t WatchTimer;  // 0x10(0x4)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandleMatchStatusUpdated
// Size: 0x1(Inherited: 0x1) 
struct FHandleMatchStatusUpdated : public FHandleMatchStatusUpdated
{
	uint8_t  MatchStatus;  // 0x0(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandleRewardsReceived
// Size: 0xB8(Inherited: 0x0) 
struct FHandleRewardsReceived
{
	struct FPlayerRewardsSummary PlayerRewardsSummary;  // 0x0(0x50)
	struct FScoreboardStats ScoreboardStats;  // 0x50(0x68)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.ApplySafeFrameScale
// Size: 0x4(Inherited: 0x4) 
struct FApplySafeFrameScale : public FApplySafeFrameScale
{
	float SafeFrameScale;  // 0x0(0x4)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandleOpenTextChat
// Size: 0x1(Inherited: 0x1) 
struct FHandleOpenTextChat : public FHandleOpenTextChat
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool BeginChatCommand : 1;  // 0x0(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.SetupQueueEvents
// Size: 0x18(Inherited: 0x0) 
struct FSetupQueueEvents
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	struct UKSQueueDataFactory* CallFunc_GetKSQueueDataFactory_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.OpenTextChatToPlayer
// Size: 0x8(Inherited: 0x8) 
struct FOpenTextChatToPlayer : public FOpenTextChatToPlayer
{
	struct UPUMG_PlayerInfo* Player;  // 0x0(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.OnAcquisition
// Size: 0x5B(Inherited: 0x0) 
struct FOnAcquisition
{
	struct UKSAcquisition* Acquisition;  // 0x0(0x8)
	struct UAcquisitionItemData* CallFunc_Array_Get_Item;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct TArray<struct UPUMG_StoreItemPrice*> CallFunc_GetPrices_ReturnValue;  // 0x18(0x10)
	struct UPUMG_StoreItemPrice* CallFunc_Array_Get_Item_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x38(0x8)
	struct UPlatformInventoryItem* K2Node_DynamicCast_AsPlatform_Inventory_Item;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_AddViewRoute_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_AddViewRoute_ReturnValue_2 : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_IsMobile_ReturnValue : 1;  // 0x4B(0x1)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_AddViewRoute_ReturnValue_3 : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_RemoveViewRoute_ReturnValue : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	struct FName CallFunc_Get_Current_View_Route_Current_Route;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_AddViewRoute_ReturnValue_4 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_AddViewRoute_ReturnValue_5 : 1;  // 0x5A(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Handle Party Invite Received
// Size: 0x8(Inherited: 0x0) 
struct FHandle Party Invite Received
{
	struct UPUMG_PlayerInfo* Inviter;  // 0x0(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetPopupManager
// Size: 0x8(Inherited: 0x8) 
struct FGetPopupManager : public FGetPopupManager
{
	struct UPUMG_PopupManager* ReturnValue;  // 0x0(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Handle Login State Change
// Size: 0x1F(Inherited: 0x0) 
struct FHandle Login State Change
{
	uint8_t  Login State;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Add_View_Route_ViewChanged : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Add_View_Route_ViewChanged_2 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Add_View_Route_ViewChanged_3 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_Add_View_Route_ViewChanged_4 : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Add_View_Route_ViewChanged_5 : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_Add_View_Route_ViewChanged_6 : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_Add_View_Route_ViewChanged_7 : 1;  // 0x1E(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetFocusableWidgetContainers
// Size: 0x38(Inherited: 0x10) 
struct FGetFocusableWidgetContainers : public FGetFocusableWidgetContainers
{
	struct TArray<struct UPanelWidget*> ReturnValue;  // 0x0(0x10)
	struct TArray<struct UPanelWidget*> CallFunc_GetFocusableWidgetContainers_ReturnValue;  // 0x10(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	struct TArray<struct UPanelWidget*> K2Node_MakeArray_Array;  // 0x28(0x10)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.FallbackLogoutCleanup
// Size: 0x58(Inherited: 0x0) 
struct FFallbackLogoutCleanup
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xC(0x4)
	struct TArray<struct UPanelWidget*> CallFunc_GetFocusableWidgetContainers_ReturnValue;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	struct UPanelWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x38(0x8)
	struct UPUMG_Widget* K2Node_DynamicCast_AsPUMG_Widget;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x55(0x1)
	char pad_86_1 : 7;  // 0x56(0x1)
	bool CallFunc_CanCloseOnLogout_ReturnValue : 1;  // 0x56(0x1)
	char pad_87_1 : 7;  // 0x57(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x57(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.TempBootstrapFunctionality
// Size: 0x18(Inherited: 0x0) 
struct FTempBootstrapFunctionality
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	struct UKSAcquisitionManager* CallFunc_GetAcquisitionManager_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Cache Current Loadout Slot
// Size: 0x1(Inherited: 0x0) 
struct FCache Current Loadout Slot
{
	char Loadout Slot Edit;  // 0x0(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Get Current Loadout Slot
// Size: 0x1(Inherited: 0x0) 
struct FGet Current Loadout Slot
{
	char Current Loadout Slot;  // 0x0(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Focus Sticky Loadout Panel
// Size: 0x8(Inherited: 0x0) 
struct FFocus Sticky Loadout Panel
{
	struct UWidget* CallFunc_SetFocusToThis_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Get Current View Route
// Size: 0x10(Inherited: 0x0) 
struct FGet Current View Route
{
	struct FName Current Route;  // 0x0(0x8)
	struct FName CallFunc_GetCurrentRoute_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.BindSettingCallbacks
// Size: 0x30(Inherited: 0x0) 
struct FBindSettingCallbacks
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	struct FSettingDelegateStruct K2Node_MakeStruct_SettingDelegateStruct;  // 0x10(0x20)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetLobbyWidget
// Size: 0x8(Inherited: 0x8) 
struct FGetLobbyWidget : public FGetLobbyWidget
{
	struct UKSLobbyWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetCurrentTransitionRoute
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentTransitionRoute
{
	struct FName Current Route;  // 0x0(0x8)
	struct FName CallFunc_GetCurrentTransitionRoute_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.GetDefaultPlayerAccountItem
// Size: 0x21(Inherited: 0x10) 
struct FGetDefaultPlayerAccountItem : public FGetDefaultPlayerAccountItem
{
	uint8_t  ItemSlot;  // 0x0(0x1)
	struct UKSItem* ReturnValue;  // 0x8(0x8)
	struct UPlatformInventoryItem* CallFunc_GetDefaultAccountItemForSlot_Default_Item;  // 0x10(0x8)
	struct UKSItem* K2Node_DynamicCast_AsKSItem;  // 0x18(0x8)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.HandeEOMResults
// Size: 0x10(Inherited: 0x0) 
struct FHandeEOMResults
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ForceTransition : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Is_in_EOM_View_State_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Add_View_Route_ViewChanged : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct UKSEMODataFactory* CallFunc_GetEMODataFactory_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Add View Route
// Size: 0xC(Inherited: 0x0) 
struct FAdd View Route
{
	struct FName RouteName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ClearRouteStack : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ForceTransition : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool ViewChanged : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_InternalAddViewRoute_ViewChanged : 1;  // 0xB(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Remove Top View Route
// Size: 0x42(Inherited: 0x0) 
struct FRemove Top View Route
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ForceTransition : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ViewChanged : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FName Temp_name_Variable;  // 0x4(0x8)
	struct FName Temp_name_Variable_2;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct UPUMG_LoginDataFactory* CallFunc_GetLoginDataFactory_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsLoggedIn_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FName CallFunc_GetTopViewRoute_ReturnValue;  // 0x24(0x8)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	int32_t CallFunc_GetViewRouteCount_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Temp_bool_Variable : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x35(0x1)
	char pad_54[2];  // 0x36(0x2)
	struct FName K2Node_Select_Default;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Add_View_Route_ViewChanged : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_RemoveTopViewRoute_ReturnValue : 1;  // 0x41(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.CallAddViewRoute
// Size: 0xC(Inherited: 0xB) 
struct FCallAddViewRoute : public FCallAddViewRoute
{
	struct FName RouteName;  // 0x0(0x8)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool ClearRouteStack : 1;  // 0x8(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ForceTransition : 1;  // 0x9(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool ViewChanged : 1;  // 0xA(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_Add_View_Route_ViewChanged : 1;  // 0xB(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.SwapViewRoute
// Size: 0x22(Inherited: 0x0) 
struct FSwapViewRoute
{
	struct FName RouteName;  // 0x0(0x8)
	struct FName SwapTargetRoute;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ForceTransition : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UPUMG_ViewManager* CallFunc_GetViewManager_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_SwapViewRoute_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.InternalAddViewRoute
// Size: 0x35(Inherited: 0x0) 
struct FInternalAddViewRoute
{
	struct FName RouteName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ClearRouteStack : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ForceTransition : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct UObject* Data;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ViewChanged : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName NewViewRoute;  // 0x1C(0x8)
	struct FName PreviousViewRoute;  // 0x24(0x8)
	struct FName CallFunc_GetTopViewRoute_ReturnValue;  // 0x2C(0x8)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_AddViewRoute_ReturnValue : 1;  // 0x34(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.CallRemoveTopViewRoute
// Size: 0x3(Inherited: 0x2) 
struct FCallRemoveTopViewRoute : public FCallRemoveTopViewRoute
{
	char pad_2_1 : 7;  // 0x2(0x1)
	bool ForceTransition : 1;  // 0x0(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool ViewChanged : 1;  // 0x1(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Remove_Top_View_Route_ViewChanged : 1;  // 0x2(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Show Lobby Radial Select
// Size: 0x1(Inherited: 0x0) 
struct FShow Lobby Radial Select
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BrightLobbyHUD.BP_BrightLobbyHUD_C.Is in EOM View State
// Size: 0x2B(Inherited: 0x0) 
struct FIs in EOM View State
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x8(0x10)
	struct FName CallFunc_GetCurrentTransitionRoute_Current_Route;  // 0x18(0x8)
	struct FName CallFunc_Get_Current_View_Route_Current_Route;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x2A(0x1)

}; 
