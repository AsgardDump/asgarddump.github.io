#pragma once 
#include "SDK.h" 
 
 
// Function AnimNotify_AkEvent.AnimNotify_AkEvent_C.Received_Notify
// Size: 0xD9(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x18(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x28(0xC)
	struct FDelegate Temp_delegate_Variable;  // 0x34(0x10)
	struct FRotator Temp_struct_Variable_2;  // 0x44(0xC)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x50(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x58(0x10)
	struct FString CallFunc_GetDisplayName_ReturnValue_2;  // 0x68(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x78(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x88(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x98(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0xA8(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0xB8(0x8)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool CallFunc_Hirez_Get_Ak_Component_bComponentCreated : 1;  // 0xC0(0x1)
	struct UAkComponent* CallFunc_Hirez_Get_Ak_Component_Return_Value;  // 0xC8(0x8)
	int32_t CallFunc_PostAkEvent_ReturnValue;  // 0xD0(0x4)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0xD4(0x4)
	char pad_226_1 : 7;  // 0xE2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xD8(0x1)

}; 
// Function AnimNotify_AkEvent.AnimNotify_AkEvent_C.Hirez Get Ak Component
// Size: 0x78(Inherited: 0x0) 
struct FHirez Get Ak Component
{
	struct USkeletalMeshComponent* AttachComponent;  // 0x0(0x8)
	struct FName AttachPointName;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bComponentCreated : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UAkComponent* Return Value;  // 0x18(0x8)
	struct FName Temp_name_Variable;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x30(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x38(0x8)
	struct FName K2Node_Select_Default;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FVector Temp_struct_Variable;  // 0x4C(0xC)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct USceneComponent* K2Node_Select_Default_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_GetAkComponent_ComponentCreated : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UAkComponent* CallFunc_GetAkComponent_ReturnValue;  // 0x70(0x8)

}; 
