#pragma once 
#include <ActivityBehavior_SetTimestampForAction_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_SetTimestampForAction.ActivityBehavior_SetTimestampForAction_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_SetTimestampForAction_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleActivityTriggered(); // Function ActivityBehavior_SetTimestampForAction.ActivityBehavior_SetTimestampForAction_C.HandleActivityTriggered
	void ExecuteUbergraph_ActivityBehavior_SetTimestampForAction(int32_t EntryPoint); // Function ActivityBehavior_SetTimestampForAction.ActivityBehavior_SetTimestampForAction_C.ExecuteUbergraph_ActivityBehavior_SetTimestampForAction
}; 



