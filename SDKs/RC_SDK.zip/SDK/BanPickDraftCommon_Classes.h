#pragma once 
#include <BanPickDraftCommon_Structs.h>
 
 
 
// Class BanPickDraftCommon.DraftAuthority
// Size: 0xAB0(Inherited: 0x220) 
struct ADraftAuthority : public AInfo
{
	char pad_544[112];  // 0x220(0x70)
	struct FName DraftName;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool bAllowUnownedChoices : 1;  // 0x298(0x1)
	char pad_665[7];  // 0x299(0x7)
	struct TSet<struct UObject*> AllowUnownedSpecificChoices;  // 0x2A0(0x50)
	UDraftRules* DraftRules;  // 0x2F0(0x8)
	struct TArray<struct FDraftChoice> Choices;  // 0x2F8(0x10)
	struct FDraftTaskList CompletedDraftTasks;  // 0x308(0x130)
	struct FDraftTaskList ActiveDraftTasks;  // 0x438(0x130)
	struct FDraftTaskList PendingDraftTasks;  // 0x568(0x130)
	struct FDraftTaskList DelayedDraftTasks;  // 0x698(0x130)
	struct TSet<struct FDraftPlayerIdHandle> ParticipatingPlayers;  // 0x7C8(0x50)
	struct TSet<struct FDraftPlayerIdHandle> RemainingPlayers;  // 0x818(0x50)
	struct TMap<struct FDraftPlayerIdHandle, struct ADraftReplicatedActor*> ActiveDraftReplicatedActors;  // 0x868(0x50)
	struct TSet<struct FDraftPlayerIdHandle> KnownDisconnectPlayers;  // 0x8B8(0x50)
	struct TArray<struct FDraftPlayerIdHandle> AvailableProxies;  // 0x908(0x10)
	struct TSet<struct FDraftPlayerIdHandle> AIPlayers;  // 0x918(0x50)
	char pad_2408_1 : 7;  // 0x968(0x1)
	bool bHasStarted : 1;  // 0x968(0x1)
	char pad_2409_1 : 7;  // 0x969(0x1)
	bool bHasCompletedInitialDraft : 1;  // 0x969(0x1)
	char pad_2410[2];  // 0x96A(0x2)
	int32_t TimesStarted;  // 0x96C(0x4)
	struct FPGame_ReplicatedTimerManager TimerManager;  // 0x970(0x128)
	char pad_2712[24];  // 0xA98(0x18)

}; 



// Class BanPickDraftCommon.DraftActorInterface
// Size: 0x28(Inherited: 0x28) 
struct UDraftActorInterface : public UInterface
{

	bool IsUIRelevantOrSpectator(); // Function BanPickDraftCommon.DraftActorInterface.IsUIRelevantOrSpectator
	struct ADraftReplicatedActor* GetDraftActor(struct FName& InDraftName); // Function BanPickDraftCommon.DraftActorInterface.GetDraftActor
}; 



// Class BanPickDraftCommon.DraftReplicatedActor
// Size: 0x9D0(Inherited: 0x220) 
struct ADraftReplicatedActor : public AInfo
{
	struct FName DraftName;  // 0x220(0x8)
	UDraftRules* DraftRules;  // 0x228(0x8)
	struct FDraftTask PersonalActiveTask;  // 0x230(0x48)
	struct FDraftTask LocalPersonalActiveTask;  // 0x278(0x48)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool bLocalPersonalTaskPendingComplete : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)
	struct TArray<struct FDraftChoice> Choices;  // 0x2C8(0x10)
	struct FDraftTaskList CompletedTasks;  // 0x2D8(0x130)
	struct FDraftTaskList ActiveTasks;  // 0x408(0x130)
	struct FDraftTaskList PendingTasks;  // 0x538(0x130)
	char pad_1640_1 : 7;  // 0x668(0x1)
	bool bAllPersonalTasksAreComplete : 1;  // 0x668(0x1)
	char pad_1641_1 : 7;  // 0x669(0x1)
	bool bLocalAllPersonalTasksAreComplete : 1;  // 0x669(0x1)
	char pad_1642_1 : 7;  // 0x66A(0x1)
	bool bDraftHasEnded : 1;  // 0x66A(0x1)
	char pad_1643[5];  // 0x66B(0x5)
	struct FMulticastInlineDelegate OnRequestSelectSuccessful;  // 0x670(0x10)
	struct FMulticastInlineDelegate OnRequestSelectFailed;  // 0x680(0x10)
	struct FMulticastInlineDelegate OnRequestCompleteSuccessful;  // 0x690(0x10)
	struct FMulticastInlineDelegate OnRequestCompleteFailed;  // 0x6A0(0x10)
	struct FMulticastInlineDelegate OnDraftChoicesChanged;  // 0x6B0(0x10)
	struct FMulticastInlineDelegate OnTasksChanged;  // 0x6C0(0x10)
	struct FMulticastInlineDelegate OnPendingTasksChanged;  // 0x6D0(0x10)
	struct FMulticastInlineDelegate OnTaskCompleted;  // 0x6E0(0x10)
	struct FMulticastInlineDelegate OnPersonalActiveTaskChanged;  // 0x6F0(0x10)
	struct FMulticastInlineDelegate OnAllPersonalTasksCompleted;  // 0x700(0x10)
	struct FMulticastInlineDelegate OnEndDraft;  // 0x710(0x10)
	struct TWeakObjectPtr<ADraftAuthority> DraftAuthority;  // 0x720(0x8)
	float PostDraftLifeSpan;  // 0x728(0x4)
	int32_t DraftActorId;  // 0x72C(0x4)
	struct FDraftPlayerIdHandle CachedDraftPlayerId;  // 0x730(0x10)
	struct FPGame_ReplicatedTimerManagerSlave TimerManager;  // 0x740(0x170)
	char pad_2224[16];  // 0x8B0(0x10)
	char pad_2240_1 : 7;  // 0x8C0(0x1)
	bool bChoicesAreDirty : 1;  // 0x8C0(0x1)
	char pad_2241_1 : 7;  // 0x8C1(0x1)
	bool bTasksAreDirty : 1;  // 0x8C1(0x1)
	char pad_2242_1 : 7;  // 0x8C2(0x1)
	bool bPendingTasksAreDirty : 1;  // 0x8C2(0x1)
	char pad_2243_1 : 7;  // 0x8C3(0x1)
	bool bPersonalTaskIsDirty : 1;  // 0x8C3(0x1)
	char pad_2244_1 : 7;  // 0x8C4(0x1)
	bool bAllPersonTasksCompleteIsDirty : 1;  // 0x8C4(0x1)
	char pad_2245_1 : 7;  // 0x8C5(0x1)
	bool bOwnerIsDirty : 1;  // 0x8C5(0x1)
	char pad_2246[2];  // 0x8C6(0x2)
	struct TSet<struct FDraftTaskId> BroadcastedTasks;  // 0x8C8(0x50)
	struct TMap<struct UObject*, int32_t> ObjectToChoiceIndexMap;  // 0x918(0x50)
	char pad_2408[80];  // 0x968(0x50)
	struct APlayerController* OwningPlayerController;  // 0x9B8(0x8)
	struct TWeakObjectPtr<UObject> PrevLocalSelectedChoice;  // 0x9C0(0x8)
	struct TWeakObjectPtr<UObject> PrevLockedChoiceForLocalPlayer;  // 0x9C8(0x8)

	bool TasksEqual(struct FDraftTask& A, struct FDraftTask& B); // Function BanPickDraftCommon.DraftReplicatedActor.TasksEqual
	void ServerRequestSelect(struct FDraftTaskId TaskId, struct UObject* ChoiceObject); // Function BanPickDraftCommon.DraftReplicatedActor.ServerRequestSelect
	void ServerRequestComplete(struct FDraftTaskId TaskId, struct UObject* ChoiceObject); // Function BanPickDraftCommon.DraftReplicatedActor.ServerRequestComplete
	uint8_t  RequestSelect(struct UObject* ChoiceObject); // Function BanPickDraftCommon.DraftReplicatedActor.RequestSelect
	uint8_t  RequestCompleteTask(struct UObject* ChoiceObject); // Function BanPickDraftCommon.DraftReplicatedActor.RequestCompleteTask
	void OnRep_PersonalActiveTask(); // Function BanPickDraftCommon.DraftReplicatedActor.OnRep_PersonalActiveTask
	void OnRep_DraftName(); // Function BanPickDraftCommon.DraftReplicatedActor.OnRep_DraftName
	void OnRep_Choices(); // Function BanPickDraftCommon.DraftReplicatedActor.OnRep_Choices
	void OnRep_AllPersonalTasksAreComplete(); // Function BanPickDraftCommon.DraftReplicatedActor.OnRep_AllPersonalTasksAreComplete
	void OnPlayerOwnerLogout(struct AActor* InActor); // Function BanPickDraftCommon.DraftReplicatedActor.OnPlayerOwnerLogout
	uint8_t  IsValidChoiceForPersonalActiveTask(struct UObject* ChoiceObject); // Function BanPickDraftCommon.DraftReplicatedActor.IsValidChoiceForPersonalActiveTask
	bool IsTaskValid(struct FDraftTask& InTask); // Function BanPickDraftCommon.DraftReplicatedActor.IsTaskValid
	bool IsTaskIdValid(struct FDraftTaskId& InTaskId); // Function BanPickDraftCommon.DraftReplicatedActor.IsTaskIdValid
	bool IsTaskIdsEqual(struct FDraftTaskId& A, struct FDraftTaskId& B); // Function BanPickDraftCommon.DraftReplicatedActor.IsTaskIdsEqual
	float GetTimeUntilNextActiveTaskExpires(); // Function BanPickDraftCommon.DraftReplicatedActor.GetTimeUntilNextActiveTaskExpires
	float GetTimeUntilLastActiveTaskExpires(); // Function BanPickDraftCommon.DraftReplicatedActor.GetTimeUntilLastActiveTaskExpires
	uint8_t  GetTimerStateByTimerId(struct FPGame_ReplicatedTimerId& TimerId); // Function BanPickDraftCommon.DraftReplicatedActor.GetTimerStateByTimerId
	uint8_t  GetTimerStateByTaskId(struct FDraftTaskId& TaskId); // Function BanPickDraftCommon.DraftReplicatedActor.GetTimerStateByTaskId
	float GetTimeRemainingByTimerId(struct FPGame_ReplicatedTimerId& TimerId); // Function BanPickDraftCommon.DraftReplicatedActor.GetTimeRemainingByTimerId
	float GetTimeRemainingByTaskId(struct FDraftTaskId& TaskId); // Function BanPickDraftCommon.DraftReplicatedActor.GetTimeRemainingByTaskId
	struct APlayerController* GetOwningPlayerController(); // Function BanPickDraftCommon.DraftReplicatedActor.GetOwningPlayerController
	struct TArray<struct FDraftTask> GetCompletedTasksForPlayer(struct FDraftPlayerIdHandle& InPlayerId); // Function BanPickDraftCommon.DraftReplicatedActor.GetCompletedTasksForPlayer
	struct FDraftTask GetActiveTaskForPlayer(struct FDraftPlayerIdHandle& InPlayerId, bool& bPendingComplete); // Function BanPickDraftCommon.DraftReplicatedActor.GetActiveTaskForPlayer
	struct FDraftChoice FindChoiceByUObject(struct UObject* ChoiceObject); // Function BanPickDraftCommon.DraftReplicatedActor.FindChoiceByUObject
	void ClientAcknowledgeSelect(struct FDraftTaskId TaskId, bool bSuccess); // Function BanPickDraftCommon.DraftReplicatedActor.ClientAcknowledgeSelect
	void ClientAcknowledgeComplete(struct FDraftTaskId TaskId, bool bSuccess); // Function BanPickDraftCommon.DraftReplicatedActor.ClientAcknowledgeComplete
}; 



// Class BanPickDraftCommon.DraftRules
// Size: 0x90(Inherited: 0x28) 
struct UDraftRules : public UObject
{
	uint8_t  PickExclusivity;  // 0x28(0x1)
	uint8_t  PickProxyRules;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bProxyAlwaysCompletesPicks : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bCanAbstainFromBan : 1;  // 0x2B(0x1)
	uint8_t  BanEffects;  // 0x2C(0x1)
	uint8_t  BanProxyRules;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool bProxyAlwaysCompletesBans : 1;  // 0x2E(0x1)
	uint8_t  LockProxyRules;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bProxyAlwaysCompletesLocks : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float ReselectTime;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bRequireChoiceOwnership : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bShowUnavailableChoicesOnUI : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct FGameplayTagQuery AIDraftQuery;  // 0x40(0x48)
	ADraftReplicatedActor* DraftReplicatedActorClass;  // 0x88(0x8)

	struct FText GetOverallStatusTextAndTimer(struct ADraftReplicatedActor* InDraftActor, struct FPGame_ReplicatedTimerId& OutActiveTimerId, struct FDraftTask& PrimaryTask); // Function BanPickDraftCommon.DraftRules.GetOverallStatusTextAndTimer
}; 



