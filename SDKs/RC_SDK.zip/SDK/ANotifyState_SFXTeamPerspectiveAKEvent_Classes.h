#pragma once 
#include <ANotifyState_SFXTeamPerspectiveAKEvent_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C
// Size: 0x5D(Inherited: 0x5D) 
struct UANotifyState_SFXTeamPerspectiveAKEvent_C : public UANotifyState_SFXAKEvent_C
{

	void SetTeamPerspective(struct USkeletalMeshComponent* MeshComp); // Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.SetTeamPerspective
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.Received_NotifyBegin
}; 



