#pragma once 
#include <CombatKnife_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass CombatKnife_DamageType.CombatKnife_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UCombatKnife_DamageType_C : public UMasterMelee_DamageType_C
{

}; 



