#pragma once 
#include <Dropdown_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Dropdown.Dropdown_C
// Size: 0x611(Inherited: 0x528) 
struct UDropdown_C : public UKSWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x528(0x8)
	struct UWidgetAnimation* MobileLayout;  // 0x530(0x8)
	struct UWidgetAnimation* hoveranim;  // 0x538(0x8)
	struct UImage* DropArrow;  // 0x540(0x8)
	struct UMenuAnchor* DropdownAnchor;  // 0x548(0x8)
	struct UImage* DropDownBkg;  // 0x550(0x8)
	struct UWBP_KeyCallout_C* GamepadPrompt;  // 0x558(0x8)
	struct UCanvasPanel* GamepadPromptContainer;  // 0x560(0x8)
	struct UButton* HitTarget;  // 0x568(0x8)
	struct UTextBlock* SelectionText;  // 0x570(0x8)
	struct FMulticastInlineDelegate OnSelectionChanged;  // 0x578(0x10)
	struct TArray<struct FText> Options;  // 0x588(0x10)
	struct FText DefaultSelection;  // 0x598(0x18)
	int32_t HoverIndex;  // 0x5B0(0x4)
	int32_t SelectionIndex;  // 0x5B4(0x4)
	struct FText HintText;  // 0x5B8(0x18)
	char pad_1488_1 : 7;  // 0x5D0(0x1)
	bool IgnoreFirst : 1;  // 0x5D0(0x1)
	char pad_1489_1 : 7;  // 0x5D1(0x1)
	bool IgnoreCanceled : 1;  // 0x5D1(0x1)
	char pad_1490[6];  // 0x5D2(0x6)
	struct UDropdownList_C* DropdownList;  // 0x5D8(0x8)
	struct UAkAudioEvent* ClickDropdownSFX;  // 0x5E0(0x8)
	struct UAkAudioEvent* HoverDropdownSFX;  // 0x5E8(0x8)
	struct FMulticastInlineDelegate OnHoverPreview;  // 0x5F0(0x10)
	struct FMulticastInlineDelegate OnSelectionCanceled;  // 0x600(0x10)
	char pad_1552_1 : 7;  // 0x610(0x1)
	bool KeyPromptSet : 1;  // 0x610(0x1)

	void SetKeyPrompt(struct FKey KeyPrompt); // Function Dropdown.Dropdown_C.SetKeyPrompt
	void UpdateGamepadPromptVisibility(); // Function Dropdown.Dropdown_C.UpdateGamepadPromptVisibility
	void OnInputStateChanged(char PGAME_INPUT_STATE InputState); // Function Dropdown.Dropdown_C.OnInputStateChanged
	void IsSelecting(bool& IsSelecting); // Function Dropdown.Dropdown_C.IsSelecting
	bool NavigateConfirm(); // Function Dropdown.Dropdown_C.NavigateConfirm
	void AppendOptions(struct TArray<struct FText>& OptionsToAppend); // Function Dropdown.Dropdown_C.AppendOptions
	void ForceClose(); // Function Dropdown.Dropdown_C.ForceClose
	void ForceToggle(); // Function Dropdown.Dropdown_C.ForceToggle
	void ForceOpen(); // Function Dropdown.Dropdown_C.ForceOpen
	struct UWidget* InitializeDropdownList(); // Function Dropdown.Dropdown_C.InitializeDropdownList
	void SetSelectedOptionByIndex(int32_t Index, bool& Success); // Function Dropdown.Dropdown_C.SetSelectedOptionByIndex
	void SetSelectedOptionByText(struct FText Text, bool& Success); // Function Dropdown.Dropdown_C.SetSelectedOptionByText
	void RemoveOptionByIndex(int32_t Index, bool& Success); // Function Dropdown.Dropdown_C.RemoveOptionByIndex
	void RemoveOptionByText(struct FText Option, bool& Success); // Function Dropdown.Dropdown_C.RemoveOptionByText
	void GetSelectedOption(struct FText& Selection, int32_t& Index); // Function Dropdown.Dropdown_C.GetSelectedOption
	void GetOptionCount(int32_t& Count); // Function Dropdown.Dropdown_C.GetOptionCount
	void FindIndexForOption(struct FText Option, bool& Success, int32_t& Index); // Function Dropdown.Dropdown_C.FindIndexForOption
	void FindOptionByIndex(int32_t Index, bool& Success, struct FText& Option); // Function Dropdown.Dropdown_C.FindOptionByIndex
	void ClearSelection(); // Function Dropdown.Dropdown_C.ClearSelection
	void ClearOptions(); // Function Dropdown.Dropdown_C.ClearOptions
	void AddOption(struct FText OptionText); // Function Dropdown.Dropdown_C.AddOption
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function Dropdown.Dropdown_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature
	void SelectionMade(int32_t Index, struct FText Selection); // Function Dropdown.Dropdown_C.SelectionMade
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature(); // Function Dropdown.Dropdown_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature
	void SelectionCancel(); // Function Dropdown.Dropdown_C.SelectionCancel
	void BndEvt__DropdownAnchor_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature(bool bIsOpen); // Function Dropdown.Dropdown_C.BndEvt__DropdownAnchor_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature
	void HandleSetCurrentHoverIndex(int32_t CurrentHoverIndex); // Function Dropdown.Dropdown_C.HandleSetCurrentHoverIndex
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function Dropdown.Dropdown_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature
	void GamepadHover(); // Function Dropdown.Dropdown_C.GamepadHover
	void GamepadUnhover(); // Function Dropdown.Dropdown_C.GamepadUnhover
	void On Selected(); // Function Dropdown.Dropdown_C.On Selected
	void Hover(); // Function Dropdown.Dropdown_C.Hover
	void Unhover(); // Function Dropdown.Dropdown_C.Unhover
	void HoverPreview(int32_t Index); // Function Dropdown.Dropdown_C.HoverPreview
	void InitializeWidget(struct APUMG_HUD* HUD); // Function Dropdown.Dropdown_C.InitializeWidget
	void ExecuteUbergraph_Dropdown(int32_t EntryPoint); // Function Dropdown.Dropdown_C.ExecuteUbergraph_Dropdown
	void OnSelectionCanceled__DelegateSignature(); // Function Dropdown.Dropdown_C.OnSelectionCanceled__DelegateSignature
	void OnHoverPreview__DelegateSignature(int32_t Index); // Function Dropdown.Dropdown_C.OnHoverPreview__DelegateSignature
	void OnSelectionChanged__DelegateSignature(struct FText SelectionText, int32_t SelectionIndex); // Function Dropdown.Dropdown_C.OnSelectionChanged__DelegateSignature
}; 



