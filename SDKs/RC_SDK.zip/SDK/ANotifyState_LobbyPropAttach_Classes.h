#pragma once 
#include <ANotifyState_LobbyPropAttach_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_LobbyPropAttach.ANotifyState_LobbyPropAttach_C
// Size: 0x2E0(Inherited: 0x30) 
struct UANotifyState_LobbyPropAttach_C : public UAnimNotifyState
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Deattach On Notify End : 1;  // 0x30(0x1)
	char pad_49[15];  // 0x31(0xF)
	struct FLobbySkeletalPropInfo LobbyWeapon01;  // 0x40(0x80)
	struct FLobbySkeletalPropInfo LobbyWeapon02;  // 0xC0(0x80)
	struct FLobbySkeletalPropInfo LobbyProp01;  // 0x140(0x80)
	struct FLobbySkeletalPropInfo LobbyProp02;  // 0x1C0(0x80)
	struct FLobbyStaticPropInfo LobbyPropStatic01;  // 0x240(0x50)
	struct FLobbyStaticPropInfo LobbyPropStatic02;  // 0x290(0x50)

	bool Received_NotifyTick(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float FrameDeltaTime); // Function ANotifyState_LobbyPropAttach.ANotifyState_LobbyPropAttach_C.Received_NotifyTick
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_LobbyPropAttach.ANotifyState_LobbyPropAttach_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_LobbyPropAttach.ANotifyState_LobbyPropAttach_C.Received_NotifyBegin
}; 



