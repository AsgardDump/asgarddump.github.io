#pragma once 
#include <ActivityBehavior_ResetAccumulationOnReload_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnReload.ActivityBehavior_ResetAccumulationOnReload_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_ResetAccumulationOnReload_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnReload.ActivityBehavior_ResetAccumulationOnReload_C.HandleBehaviorInitialized
	void HandlePlayerReloaded(); // Function ActivityBehavior_ResetAccumulationOnReload.ActivityBehavior_ResetAccumulationOnReload_C.HandlePlayerReloaded
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnReload(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnReload.ActivityBehavior_ResetAccumulationOnReload_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnReload
}; 



