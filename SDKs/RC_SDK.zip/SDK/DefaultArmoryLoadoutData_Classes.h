#pragma once 
#include <DefaultArmoryLoadoutData_Structs.h>
 
 
 
// BlueprintGeneratedClass DefaultArmoryLoadoutData.DefaultArmoryLoadoutData_C
// Size: 0x58(Inherited: 0x58) 
struct UDefaultArmoryLoadoutData_C : public UKSArmoryLoadoutData
{

}; 



