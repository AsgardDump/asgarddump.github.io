#pragma once 
#include <BaseballBatProjectile_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass BaseballBatProjectile_DamageType.BaseballBatProjectile_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UBaseballBatProjectile_DamageType_C : public UMasterMelee_DamageType_C
{

}; 



