#pragma once 
#include <DamageResistModInst_Structs.h>
 
 
 
// BlueprintGeneratedClass DamageResistModInst.DamageResistModInst_C
// Size: 0x1E8(Inherited: 0x1E0) 
struct UDamageResistModInst_C : public UKSModInst_DamageTaken
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1E0(0x8)

	void OnNewCharacterFoundation(); // Function DamageResistModInst.DamageResistModInst_C.OnNewCharacterFoundation
	void DamageTaken(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function DamageResistModInst.DamageResistModInst_C.DamageTaken
	void ExecuteUbergraph_DamageResistModInst(int32_t EntryPoint); // Function DamageResistModInst.DamageResistModInst_C.ExecuteUbergraph_DamageResistModInst
}; 



