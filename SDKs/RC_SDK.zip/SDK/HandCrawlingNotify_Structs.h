#pragma once 
#include "SDK.h" 
 
 
// Function HandCrawlingNotify.HandCrawlingNotify_C.GetNotifyName
// Size: 0x10(Inherited: 0x10) 
struct FGetNotifyName : public FGetNotifyName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function HandCrawlingNotify.HandCrawlingNotify_C.Received_Notify
// Size: 0x84(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x18(0x8)
	struct UPCM_Hero_ABP_C* K2Node_DynamicCast_AsPCM_Hero_ABP;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x29(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x2A(0x1)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x2B(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x2C(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x2D(0x1)
	char pad_63_1 : 7;  // 0x3F(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x2E(0x1)
	struct FDelegate Temp_delegate_Variable;  // 0x30(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x40(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x50(0x1)
	struct FName Temp_name_Variable;  // 0x54(0x8)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool Temp_bool_Variable : 1;  // 0x5C(0x1)
	struct FName K2Node_Select_Default;  // 0x60(0x8)
	struct FName CallFunc_Get_Footstep_SFX_Material_Material_Return;  // 0x68(0x8)
	struct AActor* CallFunc_Get_Footstep_SFX_Material_Actor_Return;  // 0x70(0x8)
	struct AActor* CallFunc_Set_Footstep_SFX_Switches_Actor_Return;  // 0x78(0x8)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x80(0x4)

}; 
