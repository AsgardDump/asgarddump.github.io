#pragma once 
#include <ANotify_PlayParticleEffectMirroring_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotify_PlayParticleEffectMirroring.ANotify_PlayParticleEffectMirroring_C
// Size: 0x74(Inherited: 0x38) 
struct UANotify_PlayParticleEffectMirroring_C : public UAnimNotify
{
	struct UParticleSystem* Particle System;  // 0x38(0x8)
	struct FVector Location Offset;  // 0x40(0xC)
	struct FRotator Rotation Offset;  // 0x4C(0xC)
	struct FVector Scale;  // 0x58(0xC)
	struct FName Socket Attach;  // 0x64(0x8)
	struct FName Socket Attach Mirrored;  // 0x6C(0x8)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotify_PlayParticleEffectMirroring.ANotify_PlayParticleEffectMirroring_C.Received_Notify
}; 



