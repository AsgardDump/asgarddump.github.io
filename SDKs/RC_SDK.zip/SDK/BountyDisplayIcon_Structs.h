#pragma once 
#include "SDK.h" 
 
 
// Function BountyDisplayIcon.BountyDisplayIcon_C.UpdateBountyLevel
// Size: 0xE8(Inherited: 0x0) 
struct FUpdateBountyLevel
{
	int32_t NewBounty;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	uint8_t  Temp_byte_Variable;  // 0x21(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x23(0x1)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x24(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x48(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FText CallFunc_Format_ReturnValue;  // 0xA0(0x18)
	struct FText K2Node_Select_Default;  // 0xB8(0x18)
	int32_t Temp_int_Variable;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0xD8(0x8)
	uint8_t  K2Node_Select_Default_2;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xE1(0x1)
	char pad_226[2];  // 0xE2(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xE4(0x4)

}; 
