#pragma once 
#include <DashChargesModInst_Structs.h>
 
 
 
// BlueprintGeneratedClass DashChargesModInst.DashChargesModInst_C
// Size: 0x280(Inherited: 0x1E0) 
struct UDashChargesModInst_C : public UKSPlayerModInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1E0(0x8)
	int32_t MaxCharges;  // 0x1E8(0x4)
	float ChargeTime;  // 0x1EC(0x4)
	struct UKSPlayerMod* ToggledMod;  // 0x1F0(0x8)
	int32_t CurrentChargesReplicated;  // 0x1F8(0x4)
	int32_t CurrentCharges;  // 0x1FC(0x4)
	struct FTimerHandle TimerHandle;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool DebugPrint : 1;  // 0x208(0x1)
	char pad_521[7];  // 0x209(0x7)
	struct FMulticastInlineDelegate OnCurrentChargesChanged;  // 0x210(0x10)
	struct FMulticastInlineDelegate OnChargeTimerActivated;  // 0x220(0x10)
	struct FMulticastInlineDelegate OnChargeTimerComplete;  // 0x230(0x10)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool IsDashing : 1;  // 0x240(0x1)
	char pad_577[3];  // 0x241(0x3)
	struct FName WeaponDash;  // 0x244(0x8)
	char pad_588[4];  // 0x24C(0x4)
	struct FGameplayTagContainer Rifle Rocket Dash;  // 0x250(0x20)
	struct UAnimMontage* animation To play;  // 0x270(0x8)
	struct FName Dash Montage Section;  // 0x278(0x8)

	void NewFunction_1(); // Function DashChargesModInst.DashChargesModInst_C.NewFunction_1
	void CanDashNow(); // Function DashChargesModInst.DashChargesModInst_C.CanDashNow
	void Process Mod Status(); // Function DashChargesModInst.DashChargesModInst_C.Process Mod Status
	void DashEnd(); // Function DashChargesModInst.DashChargesModInst_C.DashEnd
	void DashStart(); // Function DashChargesModInst.DashChargesModInst_C.DashStart
	void OnRep_TimerHandle(); // Function DashChargesModInst.DashChargesModInst_C.OnRep_TimerHandle
	void OnRep_CurrentCharges(); // Function DashChargesModInst.DashChargesModInst_C.OnRep_CurrentCharges
	void OnNotifyEnd_779C2D4547E65B767165349AFCB6D547(struct FName NotifyName, int32_t MontageInstanceID); // Function DashChargesModInst.DashChargesModInst_C.OnNotifyEnd_779C2D4547E65B767165349AFCB6D547
	void OnNotifyBegin_779C2D4547E65B767165349AFCB6D547(struct FName NotifyName, int32_t MontageInstanceID); // Function DashChargesModInst.DashChargesModInst_C.OnNotifyBegin_779C2D4547E65B767165349AFCB6D547
	void OnInterrupted_779C2D4547E65B767165349AFCB6D547(struct FName NotifyName, int32_t MontageInstanceID); // Function DashChargesModInst.DashChargesModInst_C.OnInterrupted_779C2D4547E65B767165349AFCB6D547
	void OnBlendOut_779C2D4547E65B767165349AFCB6D547(struct FName NotifyName, int32_t MontageInstanceID); // Function DashChargesModInst.DashChargesModInst_C.OnBlendOut_779C2D4547E65B767165349AFCB6D547
	void OnCompleted_779C2D4547E65B767165349AFCB6D547(struct FName NotifyName, int32_t MontageInstanceID); // Function DashChargesModInst.DashChargesModInst_C.OnCompleted_779C2D4547E65B767165349AFCB6D547
	void ChargeAvailableSFX(); // Function DashChargesModInst.DashChargesModInst_C.ChargeAvailableSFX
	void DodgeRollChanged(bool IsDodgeRolling); // Function DashChargesModInst.DashChargesModInst_C.DodgeRollChanged
	void OnNewCharacterFoundation(); // Function DashChargesModInst.DashChargesModInst_C.OnNewCharacterFoundation
	void SingleChargeComplete(); // Function DashChargesModInst.DashChargesModInst_C.SingleChargeComplete
	void TryStartChargeTimer(); // Function DashChargesModInst.DashChargesModInst_C.TryStartChargeTimer
	void Toggle SubMod(bool State); // Function DashChargesModInst.DashChargesModInst_C.Toggle SubMod
	void CharacterDestroyed(struct AActor* DestroyedActor); // Function DashChargesModInst.DashChargesModInst_C.CharacterDestroyed
	void Remove SubMod(struct AKSCharacter* KSCharacter); // Function DashChargesModInst.DashChargesModInst_C.Remove SubMod
	void ModInstRemoved(); // Function DashChargesModInst.DashChargesModInst_C.ModInstRemoved
	void PlayAlternateEvadeAnim(bool IsDodgeRolling, struct FName Direction); // Function DashChargesModInst.DashChargesModInst_C.PlayAlternateEvadeAnim
	void ExecuteUbergraph_DashChargesModInst(int32_t EntryPoint); // Function DashChargesModInst.DashChargesModInst_C.ExecuteUbergraph_DashChargesModInst
	void OnChargeTimerComplete__DelegateSignature(); // Function DashChargesModInst.DashChargesModInst_C.OnChargeTimerComplete__DelegateSignature
	void OnChargeTimerActivated__DelegateSignature(float ChargeTime); // Function DashChargesModInst.DashChargesModInst_C.OnChargeTimerActivated__DelegateSignature
	void OnCurrentChargesChanged__DelegateSignature(int32_t CurrentCharges); // Function DashChargesModInst.DashChargesModInst_C.OnCurrentChargesChanged__DelegateSignature
}; 



