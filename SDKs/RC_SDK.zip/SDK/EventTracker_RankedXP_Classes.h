#pragma once 
#include <EventTracker_RankedXP_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_RankedXP.EventTracker_RankedXP_C
// Size: 0x1DC(Inherited: 0x1C0) 
struct UEventTracker_RankedXP_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t Progress;  // 0x1C8(0x4)
	float RankedXpBonus;  // 0x1CC(0x4)
	float RankedXpBase;  // 0x1D0(0x4)
	float RankedXpFavoredMatchBonus;  // 0x1D4(0x4)
	float RankedXpAwarded;  // 0x1D8(0x4)

	void LogExtraData(); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.LogExtraData
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.IsWinningTeam
	void HandleTrackerInitialized(); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_RankedXP(int32_t EntryPoint); // Function EventTracker_RankedXP.EventTracker_RankedXP_C.ExecuteUbergraph_EventTracker_RankedXP
}; 



