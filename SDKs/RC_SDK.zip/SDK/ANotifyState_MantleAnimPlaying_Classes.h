#pragma once 
#include <ANotifyState_MantleAnimPlaying_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_MantleAnimPlaying.ANotifyState_MantleAnimPlaying_C
// Size: 0x30(Inherited: 0x30) 
struct UANotifyState_MantleAnimPlaying_C : public UAnimNotifyState
{

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_MantleAnimPlaying.ANotifyState_MantleAnimPlaying_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_MantleAnimPlaying.ANotifyState_MantleAnimPlaying_C.Received_NotifyBegin
}; 



