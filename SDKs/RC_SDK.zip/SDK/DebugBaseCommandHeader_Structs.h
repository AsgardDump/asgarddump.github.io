#pragma once 
#include "SDK.h" 
 
 
// Function DebugBaseCommandHeader.DebugBaseCommandHeader_C.ExecuteUbergraph_DebugBaseCommandHeader
// Size: 0x40(Inherited: 0x0) 
struct FExecuteUbergraph_DebugBaseCommandHeader
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UOverlaySlot* CallFunc_SlotAsOverlaySlot_ReturnValue;  // 0x8(0x8)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x10(0x18)
	int32_t K2Node_CustomEvent_Index;  // 0x28(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x2C(0x4)
	struct FMargin K2Node_MakeStruct_Margin;  // 0x30(0x10)

}; 
// Function DebugBaseCommandHeader.DebugBaseCommandHeader_C.EstablishIndex
// Size: 0x4(Inherited: 0x0) 
struct FEstablishIndex
{
	int32_t Index;  // 0x0(0x4)

}; 
