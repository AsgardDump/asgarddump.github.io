#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AppsFlyerSDK.AppsFlyerConversionData
// Size: 0x50(Inherited: 0x0) 
struct FAppsFlyerConversionData
{
	struct TMap<struct FString, struct FString> InstallData;  // 0x0(0x50)

}; 
// DelegateFunction AppsFlyerSDK.OnAppOpenAttribution__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAppOpenAttribution__DelegateSignature
{
	struct FString attributionData;  // 0x0(0x10)

}; 
// DelegateFunction AppsFlyerSDK.OnConversionDataReceived__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnConversionDataReceived__DelegateSignature
{
	struct FAppsFlyerConversionData InstallData;  // 0x0(0x50)

}; 
// DelegateFunction AppsFlyerSDK.OnAppOpenAttributionFailure__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAppOpenAttributionFailure__DelegateSignature
{
	struct FString Error;  // 0x0(0x10)

}; 
// DelegateFunction AppsFlyerSDK.OnConversionDataRequestFailure__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnConversionDataRequestFailure__DelegateSignature
{
	struct FString Error;  // 0x0(0x10)

}; 
// Function AppsFlyerSDK.AppsFlyerSDKBlueprint.advertisingIdentifier
// Size: 0x10(Inherited: 0x0) 
struct FadvertisingIdentifier
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AppsFlyerSDK.AppsFlyerSDKBlueprint.logEvent
// Size: 0x60(Inherited: 0x0) 
struct FlogEvent
{
	struct FString EventName;  // 0x0(0x10)
	struct TMap<struct FString, struct FString> Values;  // 0x10(0x50)

}; 
// Function AppsFlyerSDK.AppsFlyerSDKBlueprint.getAppsFlyerUID
// Size: 0x10(Inherited: 0x0) 
struct FgetAppsFlyerUID
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AppsFlyerSDK.AppsFlyerSDKBlueprint.setAdditionalData
// Size: 0x50(Inherited: 0x0) 
struct FsetAdditionalData
{
	struct TMap<struct FString, struct FString> customData;  // 0x0(0x50)

}; 
// Function AppsFlyerSDK.AppsFlyerSDKBlueprint.setCustomerUserId
// Size: 0x10(Inherited: 0x0) 
struct FsetCustomerUserId
{
	struct FString customerUserId;  // 0x0(0x10)

}; 
// Function AppsFlyerSDK.AppsFlyerSDKBlueprint.setRemoteNotificationsToken
// Size: 0x10(Inherited: 0x0) 
struct FsetRemoteNotificationsToken
{
	struct TArray<char> Token;  // 0x0(0x10)

}; 
// Function AppsFlyerSDK.AppsFlyerSDKBlueprint.waitForATTUserAuthorizationWithTimeoutInterval
// Size: 0x4(Inherited: 0x0) 
struct FwaitForATTUserAuthorizationWithTimeoutInterval
{
	int32_t timeoutInterval;  // 0x0(0x4)

}; 
