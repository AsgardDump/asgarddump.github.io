#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.OwnedPawnInstigateDamage
// Size: 0x88(Inherited: 0x0) 
struct FOwnedPawnInstigateDamage
{
	struct FCombatEventInfo DamageInfo;  // 0x0(0x88)

}; 
// Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.ExecuteUbergraph_EventTracker_WeeklyContract_VarietyDowns
// Size: 0xE1(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_WeeklyContract_VarietyDowns
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x28(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FCombatEventInfo K2Node_CustomEvent_DamageInfo;  // 0x48(0x88)
	int32_t CallFunc_Min_ReturnValue;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_IsCombatConditionMet_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)
	int32_t CallFunc_Min_ReturnValue_2;  // 0xD8(0x4)
	int32_t CallFunc_Min_ReturnValue_3;  // 0xDC(0x4)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xE0(0x1)

}; 
// Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckGadget
// Size: 0x14(Inherited: 0x0) 
struct FCheckGadget
{
	struct UKSWeaponAsset* WeaponAsset;  // 0x0(0x8)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_IsGadget_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)

}; 
// Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckPrimary
// Size: 0x1C(Inherited: 0x0) 
struct FCheckPrimary
{
	struct UKSWeaponAsset* WeaponAsset;  // 0x0(0x8)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	struct FGameplayTag Temp_struct_Variable;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)

}; 
// Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckAbility
// Size: 0xD8(Inherited: 0x0) 
struct FCheckAbility
{
	struct FCombatEventInfo DamageInfo;  // 0x0(0x88)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x88(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8C(0x4)
	UKSDamageTypeBase* K2Node_ClassDynamicCast_AsKSDamage_Type_Base;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x9C(0x4)
	int32_t Temp_int_Variable;  // 0xA0(0x4)
	struct FGameplayTag Temp_struct_Variable;  // 0xA4(0x8)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xB0(0x4)
	int32_t Temp_int_Variable_2;  // 0xB4(0x4)
	int32_t Temp_int_Variable_3;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct UKSActivityRewardCondition* CallFunc_Array_Get_Item;  // 0xC0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_IsCombatConditionMet_ReturnValue : 1;  // 0xCC(0x1)
	char pad_205_1 : 7;  // 0xCD(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xCD(0x1)
	char pad_206[2];  // 0xCE(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0xD0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0xD4(0x4)

}; 
// Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckSecondary
// Size: 0x1C(Inherited: 0x0) 
struct FCheckSecondary
{
	struct UKSWeaponAsset* WeaponAsset;  // 0x0(0x8)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	struct FGameplayTag Temp_struct_Variable;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)

}; 
