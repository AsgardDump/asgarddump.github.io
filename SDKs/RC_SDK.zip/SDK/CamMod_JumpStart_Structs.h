#pragma once 
#include "SDK.h" 
 
 
// Function CamMod_JumpStart.CamMod_JumpStart_C.ExecuteUbergraph_CamMod_JumpStart
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_CamMod_JumpStart
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_GetKSCharacterData_Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AKSCharacter* CallFunc_GetKSCharacterData_KSCharacter;  // 0x8(0x8)
	struct UKSCharacterMovementComponent* CallFunc_GetKSCharacterData_MovementComponent;  // 0x10(0x8)
	struct AKSCameraManager_C* CallFunc_GetKSCharacterData_Camera_Manager;  // 0x18(0x8)

}; 
// Function CamMod_JumpStart.CamMod_JumpStart_C.ShouldModifyCamera
// Size: 0x21(Inherited: 0x20) 
struct FShouldModifyCamera : public FShouldModifyCamera
{
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bSuccess : 1;  // 0x0(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_GetKSCharacterData_Success : 1;  // 0x1(0x1)
	struct AKSCharacter* CallFunc_GetKSCharacterData_KSCharacter;  // 0x8(0x8)
	struct UKSCharacterMovementComponent* CallFunc_GetKSCharacterData_MovementComponent;  // 0x10(0x8)
	struct AKSCameraManager_C* CallFunc_GetKSCharacterData_Camera_Manager;  // 0x18(0x8)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x20(0x1)

}; 
