#pragma once 
#include "SDK.h" 
 
 
// Function Blocker.Blocker_C.ExecuteUbergraph_Blocker
// Size: 0x71(Inherited: 0x0) 
struct FExecuteUbergraph_Blocker
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_NavigateBack_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AKSLobbyHUDNew* K2Node_DynamicCast_AsKSLobby_HUDNew;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool K2Node_CustomEvent_Show : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct UUserWidget* K2Node_CustomEvent_InWidget;  // 0x28(0x8)
	struct UPUMG_Widget* K2Node_DynamicCast_AsPUMG_Widget;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UPanelWidget* CallFunc_GetParent_ReturnValue;  // 0x40(0x8)
	struct UPUMG_CanvasPanel* K2Node_DynamicCast_AsPUMG_Canvas_Panel;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x54(0x10)
	char pad_100[4];  // 0x64(0x4)
	struct UPUMG_Widget* K2Node_CustomEvent_Widget;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_CustomEvent_ClickToClose : 1;  // 0x70(0x1)

}; 
// Function Blocker.Blocker_C.HandleBlockerChange
// Size: 0x10(Inherited: 0x0) 
struct FHandleBlockerChange
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Show : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UUserWidget* InWidget;  // 0x8(0x8)

}; 
// Function Blocker.Blocker_C.Bind
// Size: 0x9(Inherited: 0x0) 
struct FBind
{
	struct UPUMG_Widget* Widget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ClickToClose : 1;  // 0x8(0x1)

}; 
// Function Blocker.Blocker_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
