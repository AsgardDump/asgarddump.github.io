#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct HiRezAutomation.PGame_PerformanceCaptureProfile
// Size: 0x1C(Inherited: 0x0) 
struct FPGame_PerformanceCaptureProfile
{
	struct FName ProfileName;  // 0x0(0x8)
	int32_t ScalabilityBucket;  // 0x8(0x4)
	int32_t ResolutionX;  // 0xC(0x4)
	int32_t ResolutionY;  // 0x10(0x4)
	int32_t VsyncInterval;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bFullScreen : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function HiRezAutomation.PerfCharacter.LoadCharacters
// Size: 0x20(Inherited: 0x0) 
struct FLoadCharacters
{
	struct FString CharactersToTest;  // 0x0(0x10)
	struct TArray<struct FString> LogToPrint;  // 0x10(0x10)

}; 
// Function HiRezAutomation.PerfCharacter.GetCharacterName
// Size: 0x20(Inherited: 0x0) 
struct FGetCharacterName
{
	struct FString SkinName;  // 0x0(0x10)
	struct FString CharacterName;  // 0x10(0x10)

}; 
// Function HiRezAutomation.PerfCharacter.SetSkin
// Size: 0x4(Inherited: 0x0) 
struct FSetSkin
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function HiRezAutomation.PerfCharacter.SpawnCharacters
// Size: 0x4(Inherited: 0x0) 
struct FSpawnCharacters
{
	int32_t NumCharacter;  // 0x0(0x4)

}; 
