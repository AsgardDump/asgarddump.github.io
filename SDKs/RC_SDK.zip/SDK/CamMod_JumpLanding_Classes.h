#pragma once 
#include <CamMod_JumpLanding_Structs.h>
 
 
 
// BlueprintGeneratedClass CamMod_JumpLanding.CamMod_JumpLanding_C
// Size: 0x71(Inherited: 0x68) 
struct UCamMod_JumpLanding_C : public UCamMod_Master_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool WasJumping : 1;  // 0x70(0x1)

	void ShouldModifyCamera(bool& bSuccess); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.ShouldModifyCamera
	void PlayTimeline(); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.PlayTimeline
	void OnCamModFinished(); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.OnCamModFinished
	void ExecuteUbergraph_CamMod_JumpLanding(int32_t EntryPoint); // Function CamMod_JumpLanding.CamMod_JumpLanding_C.ExecuteUbergraph_CamMod_JumpLanding
}; 



