#pragma once 
#include <EventTracker_EndOfRound_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_EndOfRound.EventTracker_EndOfRound_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_EndOfRound_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_EndOfRound.EventTracker_EndOfRound_C.HandleTrackerInitialized
	void RoundHasEnded_Event(struct AKSGameState* GameState, struct FRoundResult& RoundResult); // Function EventTracker_EndOfRound.EventTracker_EndOfRound_C.RoundHasEnded_Event
	void ExecuteUbergraph_EventTracker_EndOfRound(int32_t EntryPoint); // Function EventTracker_EndOfRound.EventTracker_EndOfRound_C.ExecuteUbergraph_EventTracker_EndOfRound
}; 



