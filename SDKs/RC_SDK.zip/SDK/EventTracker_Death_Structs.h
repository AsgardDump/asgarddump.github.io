#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_Death.EventTracker_Death_C.ExecuteUbergraph_EventTracker_Death
// Size: 0xB3(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_Death
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct AKSGameState* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x18(0x10)
	struct FCombatEventInfo K2Node_CustomEvent_EventInfo;  // 0x28(0x88)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_IsCombatConditionMet_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB2(0x1)

}; 
// Function EventTracker_Death.EventTracker_Death_C.OnPlayerDeath
// Size: 0x88(Inherited: 0x0) 
struct FOnPlayerDeath
{
	struct FCombatEventInfo EventInfo;  // 0x0(0x88)

}; 
