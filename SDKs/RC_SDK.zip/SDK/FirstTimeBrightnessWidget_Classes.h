#pragma once 
#include <FirstTimeBrightnessWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C
// Size: 0x518(Inherited: 0x4C8) 
struct UFirstTimeBrightnessWidget_C : public UPUMG_Widget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C8(0x8)
	struct UImage* Decro;  // 0x4D0(0x8)
	struct UOverlay* SettingsWidgetContainer;  // 0x4D8(0x8)
	struct UTextBlock* Title;  // 0x4E0(0x8)
	struct UWBP_StandardButtonMedium_C* WBP_StandardButtonMedium;  // 0x4E8(0x8)
	struct FKSSettingsWidgetConfig SettingsWidgetConfig;  // 0x4F0(0x10)
	struct UKSSettingsInfoBase* SettingsInfo;  // 0x500(0x8)
	struct UKSSettingsWidget* SettingsWidget;  // 0x508(0x8)
	struct UAkAudioEvent* ShowFirstTimeBrightnessSFX;  // 0x510(0x8)

	void OnShown(); // Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.OnShown
	void OnHide(); // Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.OnHide
	void InitializeWidget(struct APUMG_HUD* HUD); // Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.InitializeWidget
	void InitializeWidgetNavigation(); // Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.InitializeWidgetNavigation
	void BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature(struct UWidget* Widget); // Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.PreConstruct
	void ExecuteUbergraph_FirstTimeBrightnessWidget(int32_t EntryPoint); // Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.ExecuteUbergraph_FirstTimeBrightnessWidget
}; 



