#pragma once 
#include <GamepadPrompt_Bright_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GamepadPrompt_Bright.GamepadPrompt_Bright_C
// Size: 0x2A0(Inherited: 0x238) 
struct UGamepadPrompt_Bright_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UImage* GamepadIcon;  // 0x240(0x8)
	struct UTextBlock* PromptText;  // 0x248(0x8)
	struct FText Prompt;  // 0x250(0x18)
	struct FName Action;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool IsConfirmGamepad : 1;  // 0x270(0x1)
	char pad_625_1 : 7;  // 0x271(0x1)
	bool IsCancelGamepad : 1;  // 0x271(0x1)
	char pad_626[6];  // 0x272(0x6)
	struct FSlateColor FontColor;  // 0x278(0x28)

	void Construct(); // Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.Construct
	void PreConstruct(bool IsDesignTime); // Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.PreConstruct
	void ExecuteUbergraph_GamepadPrompt_Bright(int32_t EntryPoint); // Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.ExecuteUbergraph_GamepadPrompt_Bright
}; 



