#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_Purchase_Single.EventTracker_Purchase_Single_C.ExecuteUbergraph_EventTracker_Purchase_Single
// Size: 0x99(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_Purchase_Single
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UKSGameShopItemComponent* K2Node_CustomEvent_ShopItemComponent;  // 0x8(0x8)
	int32_t Temp_int_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UKSItem* CallFunc_GetNextItem_ReturnValue;  // 0x18(0x8)
	int32_t Temp_int_Variable_2;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x34(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x44(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x54(0x10)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_IsShopPurchaseConditionMet_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x70(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x80(0x8)
	struct UKSGameShopItemComponent* K2Node_CustomEvent_ShopItemComponent_2;  // 0x88(0x8)
	struct UKSItem* CallFunc_GetCurrentItem_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsShopPurchaseConditionMet_ReturnValue_2 : 1;  // 0x98(0x1)

}; 
// Function EventTracker_Purchase_Single.EventTracker_Purchase_Single_C.OnShopItemPurchased
// Size: 0x8(Inherited: 0x0) 
struct FOnShopItemPurchased
{
	struct UKSGameShopItemComponent* ShopItemComponent;  // 0x0(0x8)

}; 
// Function EventTracker_Purchase_Single.EventTracker_Purchase_Single_C.OnShopItemRefunded
// Size: 0x8(Inherited: 0x0) 
struct FOnShopItemRefunded
{
	struct UKSGameShopItemComponent* ShopItemComponent;  // 0x0(0x8)

}; 
