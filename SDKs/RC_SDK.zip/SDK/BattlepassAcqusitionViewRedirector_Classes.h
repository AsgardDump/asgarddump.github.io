#pragma once 
#include <BattlepassAcqusitionViewRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass BattlepassAcqusitionViewRedirector.BattlepassAcqusitionViewRedirector_C
// Size: 0x38(Inherited: 0x38) 
struct UBattlepassAcqusitionViewRedirector_C : public UKSAcquisitionViewRedirector
{

}; 



