#pragma once 
#include <DefaultGamepadLookManager_Structs.h>
 
 
 
// BlueprintGeneratedClass DefaultGamepadLookManager.DefaultGamepadLookManager_C
// Size: 0xE8(Inherited: 0xE8) 
struct UDefaultGamepadLookManager_C : public UKSGamepadCurvedLookSpeedManager
{

}; 



