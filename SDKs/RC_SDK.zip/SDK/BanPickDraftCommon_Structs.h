#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction BanPickDraftCommon.OnDraftActorAdded__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnDraftActorAdded__DelegateSignature
{
	struct ADraftReplicatedActor* DraftActor;  // 0x0(0x8)

}; 
// ScriptStruct BanPickDraftCommon.DraftTaskId
// Size: 0x2(Inherited: 0x0) 
struct FDraftTaskId
{
	uint16_t ID;  // 0x0(0x2)

}; 
// DelegateFunction BanPickDraftCommon.OnDraftChoicesChangedSignature__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnDraftChoicesChangedSignature__DelegateSignature
{
	struct TArray<struct UObject*> RemovedChoices;  // 0x0(0x10)
	struct TArray<struct UObject*> AddedOrUpdatedChoices;  // 0x10(0x10)

}; 
// ScriptStruct BanPickDraftCommon.DraftTaskList
// Size: 0x130(Inherited: 0x108) 
struct FDraftTaskList : public FFastArraySerializer
{
	struct TArray<struct FDraftTask> Tasks;  // 0x108(0x10)
	char pad_280[24];  // 0x118(0x18)

}; 
// DelegateFunction BanPickDraftCommon.OnTaskCompletedSignature__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnTaskCompletedSignature__DelegateSignature
{
	struct FDraftTask CompletedTask;  // 0x0(0x48)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetOwningPlayerController
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningPlayerController
{
	struct APlayerController* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct BanPickDraftCommon.DraftTask
// Size: 0x48(Inherited: 0xC) 
struct FDraftTask : public FFastArraySerializerItem
{
	struct FDraftTaskId TaskId;  // 0xC(0x2)
	uint8_t  TaskType;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)
	struct UObject* SelectedChoice;  // 0x10(0x8)
	struct FDraftPlayerIdHandle Player;  // 0x18(0x10)
	struct FDraftPlayerIdHandle SelectingProxy;  // 0x28(0x10)
	int32_t TeamNum;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bHaltingTask : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	float TimeForTask;  // 0x40(0x4)
	struct FPGame_ReplicatedTimerId TimerId;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.RequestSelect
// Size: 0x10(Inherited: 0x0) 
struct FRequestSelect
{
	struct UObject* ChoiceObject;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct BanPickDraftCommon.DraftPlayerIdHandle
// Size: 0x10(Inherited: 0x0) 
struct FDraftPlayerIdHandle
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct BanPickDraftCommon.DraftChoice
// Size: 0x10(Inherited: 0x0) 
struct FDraftChoice
{
	struct UObject* ChoiceObject;  // 0x0(0x8)
	char bIsVisibleToUI : 1;  // 0x8(0x1)
	char bIsUnavailable : 1;  // 0x8(0x1)
	char bIsUnavailableByOwnership : 1;  // 0x8(0x1)
	char bIsBanned : 1;  // 0x8(0x1)
	char bAlreadyPicked : 1;  // 0x8(0x1)
	char bAlreadyLocked : 1;  // 0x8(0x1)
	char bCannotLock : 1;  // 0x8(0x1)
	char bSelectedByTeammate : 1;  // 0x8(0x1)
	char bSelectedByOpponent : 1;  // 0x9(0x1)
	char bSelectedBySelf : 1;  // 0x9(0x1)
	char bPendingCompleteBySelf : 1;  // 0x9(0x1)
	char bPickedByLocalTeam : 1;  // 0x9(0x1)
	char bPickedByOpponent : 1;  // 0x9(0x1)
	char bLockedByLocalPlayer : 1;  // 0x9(0x1)
	char pad_9_1 : 2;  // 0x9(0x1)
	uint8_t  OwnershipState;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// ScriptStruct BanPickDraftCommon.DraftPlayerIdInternal
// Size: 0x8(Inherited: 0x0) 
struct FDraftPlayerIdInternal
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function BanPickDraftCommon.DraftActorInterface.GetDraftActor
// Size: 0x10(Inherited: 0x0) 
struct FGetDraftActor
{
	struct FName InDraftName;  // 0x0(0x8)
	struct ADraftReplicatedActor* ReturnValue;  // 0x8(0x8)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetTimerStateByTaskId
// Size: 0x4(Inherited: 0x0) 
struct FGetTimerStateByTaskId
{
	struct FDraftTaskId TaskId;  // 0x0(0x2)
	uint8_t  ReturnValue;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)

}; 
// Function BanPickDraftCommon.DraftActorInterface.IsUIRelevantOrSpectator
// Size: 0x1(Inherited: 0x0) 
struct FIsUIRelevantOrSpectator
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.ClientAcknowledgeComplete
// Size: 0x4(Inherited: 0x0) 
struct FClientAcknowledgeComplete
{
	struct FDraftTaskId TaskId;  // 0x0(0x2)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bSuccess : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.ClientAcknowledgeSelect
// Size: 0x4(Inherited: 0x0) 
struct FClientAcknowledgeSelect
{
	struct FDraftTaskId TaskId;  // 0x0(0x2)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bSuccess : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.FindChoiceByUObject
// Size: 0x18(Inherited: 0x0) 
struct FFindChoiceByUObject
{
	struct UObject* ChoiceObject;  // 0x0(0x8)
	struct FDraftChoice ReturnValue;  // 0x8(0x10)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetActiveTaskForPlayer
// Size: 0x60(Inherited: 0x0) 
struct FGetActiveTaskForPlayer
{
	struct FDraftPlayerIdHandle InPlayerId;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bPendingComplete : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FDraftTask ReturnValue;  // 0x18(0x48)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetCompletedTasksForPlayer
// Size: 0x20(Inherited: 0x0) 
struct FGetCompletedTasksForPlayer
{
	struct FDraftPlayerIdHandle InPlayerId;  // 0x0(0x10)
	struct TArray<struct FDraftTask> ReturnValue;  // 0x10(0x10)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetTimeRemainingByTaskId
// Size: 0x8(Inherited: 0x0) 
struct FGetTimeRemainingByTaskId
{
	struct FDraftTaskId TaskId;  // 0x0(0x2)
	char pad_2[2];  // 0x2(0x2)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetTimeRemainingByTimerId
// Size: 0x8(Inherited: 0x0) 
struct FGetTimeRemainingByTimerId
{
	struct FPGame_ReplicatedTimerId TimerId;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetTimerStateByTimerId
// Size: 0x2(Inherited: 0x0) 
struct FGetTimerStateByTimerId
{
	struct FPGame_ReplicatedTimerId TimerId;  // 0x0(0x1)
	uint8_t  ReturnValue;  // 0x1(0x1)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetTimeUntilLastActiveTaskExpires
// Size: 0x4(Inherited: 0x0) 
struct FGetTimeUntilLastActiveTaskExpires
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.GetTimeUntilNextActiveTaskExpires
// Size: 0x4(Inherited: 0x0) 
struct FGetTimeUntilNextActiveTaskExpires
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.IsTaskIdsEqual
// Size: 0x6(Inherited: 0x0) 
struct FIsTaskIdsEqual
{
	struct FDraftTaskId A;  // 0x0(0x2)
	struct FDraftTaskId B;  // 0x2(0x2)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[1];  // 0x5(0x1)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.IsTaskIdValid
// Size: 0x4(Inherited: 0x0) 
struct FIsTaskIdValid
{
	struct FDraftTaskId InTaskId;  // 0x0(0x2)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool ReturnValue : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.IsTaskValid
// Size: 0x50(Inherited: 0x0) 
struct FIsTaskValid
{
	struct FDraftTask InTask;  // 0x0(0x48)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.IsValidChoiceForPersonalActiveTask
// Size: 0x10(Inherited: 0x0) 
struct FIsValidChoiceForPersonalActiveTask
{
	struct UObject* ChoiceObject;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.OnPlayerOwnerLogout
// Size: 0x8(Inherited: 0x0) 
struct FOnPlayerOwnerLogout
{
	struct AActor* InActor;  // 0x0(0x8)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.RequestCompleteTask
// Size: 0x10(Inherited: 0x0) 
struct FRequestCompleteTask
{
	struct UObject* ChoiceObject;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.ServerRequestComplete
// Size: 0x10(Inherited: 0x0) 
struct FServerRequestComplete
{
	struct FDraftTaskId TaskId;  // 0x0(0x2)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* ChoiceObject;  // 0x8(0x8)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.ServerRequestSelect
// Size: 0x10(Inherited: 0x0) 
struct FServerRequestSelect
{
	struct FDraftTaskId TaskId;  // 0x0(0x2)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* ChoiceObject;  // 0x8(0x8)

}; 
// Function BanPickDraftCommon.DraftReplicatedActor.TasksEqual
// Size: 0x98(Inherited: 0x0) 
struct FTasksEqual
{
	struct FDraftTask A;  // 0x0(0x48)
	struct FDraftTask B;  // 0x48(0x48)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool ReturnValue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
// Function BanPickDraftCommon.DraftRules.GetOverallStatusTextAndTimer
// Size: 0x70(Inherited: 0x0) 
struct FGetOverallStatusTextAndTimer
{
	struct ADraftReplicatedActor* InDraftActor;  // 0x0(0x8)
	struct FPGame_ReplicatedTimerId OutActiveTimerId;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FDraftTask PrimaryTask;  // 0x10(0x48)
	struct FText ReturnValue;  // 0x58(0x18)

}; 
