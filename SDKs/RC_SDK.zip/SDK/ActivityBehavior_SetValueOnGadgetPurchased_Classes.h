#pragma once 
#include <ActivityBehavior_SetValueOnGadgetPurchased_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_SetValueOnGadgetPurchased.ActivityBehavior_SetValueOnGadgetPurchased_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_SetValueOnGadgetPurchased_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_SetValueOnGadgetPurchased.ActivityBehavior_SetValueOnGadgetPurchased_C.HandleBehaviorInitialized
	void HandleShopItemPurchased(struct UKSGameShopItemComponent* ShopItemComponent); // Function ActivityBehavior_SetValueOnGadgetPurchased.ActivityBehavior_SetValueOnGadgetPurchased_C.HandleShopItemPurchased
	void ExecuteUbergraph_ActivityBehavior_SetValueOnGadgetPurchased(int32_t EntryPoint); // Function ActivityBehavior_SetValueOnGadgetPurchased.ActivityBehavior_SetValueOnGadgetPurchased_C.ExecuteUbergraph_ActivityBehavior_SetValueOnGadgetPurchased
}; 



