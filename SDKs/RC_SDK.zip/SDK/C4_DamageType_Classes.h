#pragma once 
#include <C4_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass C4_DamageType.C4_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UC4_DamageType_C : public UMasterExplosion_DamageType_C
{

}; 



