#pragma once 
#include "SDK.h" 
 
 
// Function BombActivator_ABP.BombActivator_ABP_C.ExecuteUbergraph_BombActivator_ABP
// Size: 0xF0(Inherited: 0x0) 
struct FExecuteUbergraph_BombActivator_ABP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate Temp_delegate_Variable;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x18(0x10)
	struct FDelegate Temp_delegate_Variable_2;  // 0x28(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2;  // 0x38(0x10)
	struct FDelegate Temp_delegate_Variable_3;  // 0x48(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_3;  // 0x58(0x10)
	struct FDelegate Temp_delegate_Variable_4;  // 0x68(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_4;  // 0x78(0x10)
	struct FDelegate Temp_delegate_Variable_5;  // 0x88(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_5;  // 0x98(0x10)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;  // 0xA8(0x4)
	struct FDelegate Temp_delegate_Variable_6;  // 0xAC(0x10)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_6;  // 0xC0(0x10)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0xD0(0x8)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0xD8(0x4)
	int32_t CallFunc_PostEvent_ReturnValue_2;  // 0xDC(0x4)
	int32_t CallFunc_PostEvent_ReturnValue_3;  // 0xE0(0x4)
	int32_t CallFunc_PostEvent_ReturnValue_4;  // 0xE4(0x4)
	int32_t CallFunc_PostEvent_ReturnValue_5;  // 0xE8(0x4)
	int32_t CallFunc_PostEvent_ReturnValue_6;  // 0xEC(0x4)

}; 
// Function BombActivator_ABP.BombActivator_ABP_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
