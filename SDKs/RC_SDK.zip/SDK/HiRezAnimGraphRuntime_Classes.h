#pragma once 
#include <HiRezAnimGraphRuntime_Structs.h>
 
 
 
