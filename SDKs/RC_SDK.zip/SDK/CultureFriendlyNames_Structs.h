#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct CultureFriendlyNames.CultureFriendlyNames
// Size: 0x28(Inherited: 0x0) 
struct FCultureFriendlyNames
{
	struct FString CultureString_2_1D905AD34039FD917A623B801CD6C394;  // 0x0(0x10)
	struct FText FriendlyName_5_01E74C8D4A7648211DFCD4AEE881C6AE;  // 0x10(0x18)

}; 
