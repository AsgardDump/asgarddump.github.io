#pragma once 
#include <ActivityBehavior_ReportMobileXPTick_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_ReportMobileXPTick.ActivityBehavior_ReportMobileXPTick_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_ReportMobileXPTick_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleProgressedFromSubActivity(struct UKSActivityInstance* SubActivity, int32_t ProgressFromSubActivity); // Function ActivityBehavior_ReportMobileXPTick.ActivityBehavior_ReportMobileXPTick_C.HandleProgressedFromSubActivity
	void ExecuteUbergraph_ActivityBehavior_ReportMobileXPTick(int32_t EntryPoint); // Function ActivityBehavior_ReportMobileXPTick.ActivityBehavior_ReportMobileXPTick_C.ExecuteUbergraph_ActivityBehavior_ReportMobileXPTick
}; 



