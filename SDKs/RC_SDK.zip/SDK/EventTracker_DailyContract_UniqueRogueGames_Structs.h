#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.ExecuteUbergraph_EventTracker_DailyContract_UniqueRogueGames
// Size: 0x30(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_DailyContract_UniqueRogueGames
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_GetJobItemId_JobItemId;  // 0x24(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x28(0x8)

}; 
// Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.IsWinningTeam
// Size: 0x21(Inherited: 0x0) 
struct FIsWinningTeam
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsWinningTeam : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct AKSGameState* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_GetTeamNum_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_GetWinningTeamNum_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.GetJobItemId
// Size: 0x1C(Inherited: 0x0) 
struct FGetJobItemId
{
	int32_t JobItemId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct UKSJobItem* CallFunc_GetJob_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_GetItemId_ReturnValue;  // 0x18(0x4)

}; 
