#pragma once 
#include <BaseballBat_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass BaseballBat_DamageType.BaseballBat_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UBaseballBat_DamageType_C : public UMasterMelee_DamageType_C
{

}; 



