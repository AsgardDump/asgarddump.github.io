#pragma once 
#include <EventTracker_MobileWeaponXp_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C
// Size: 0x1D9(Inherited: 0x1C0) 
struct UEventTracker_MobileWeaponXp_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool bIsEquipped : 1;  // 0x1C8(0x1)
	char pad_457[7];  // 0x1C9(0x7)
	struct FDateTime TimeEquipped;  // 0x1D0(0x8)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool MatchStarted : 1;  // 0x1D8(0x1)

	void GetTimeSinceEquipped(float& TimeElapsed); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.GetTimeSinceEquipped
	void HandleTrackerInitialized(); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.HandleTrackerInitialized
	void OnWeaponEquipped(struct AKSCharacter* Character, struct UKSWeaponComponent* EquippedWeapon); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.OnWeaponEquipped
	void OnWeaponUnequipped(struct AKSCharacter* Character, struct UKSWeaponComponent* UnequippedWeapon); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.OnWeaponUnequipped
	void ViewTargetChanged(struct AKSPlayerController* Controller, struct AActor* OldViewTarget, struct AActor* NewViewTarget); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.ViewTargetChanged
	void Handle Match Ended(); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.Handle Match Ended
	void OnPhaseChanged(struct FMatchPhase PreviousPhase, struct FMatchPhase NewPhase); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.OnPhaseChanged
	void ExecuteUbergraph_EventTracker_MobileWeaponXp(int32_t EntryPoint); // Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.ExecuteUbergraph_EventTracker_MobileWeaponXp
}; 



