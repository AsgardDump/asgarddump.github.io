#pragma once 
#include <EventTracker_CashEarned_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_CashEarned.EventTracker_CashEarned_C
// Size: 0x1CC(Inherited: 0x1C0) 
struct UEventTracker_CashEarned_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t CashEarned;  // 0x1C8(0x4)

	void HandleTrackerInitialized(); // Function EventTracker_CashEarned.EventTracker_CashEarned_C.HandleTrackerInitialized
	void HandleCashEarned(int32_t Money, struct FText Reason); // Function EventTracker_CashEarned.EventTracker_CashEarned_C.HandleCashEarned
	void ExecuteUbergraph_EventTracker_CashEarned(int32_t EntryPoint); // Function EventTracker_CashEarned.EventTracker_CashEarned_C.ExecuteUbergraph_EventTracker_CashEarned
}; 



