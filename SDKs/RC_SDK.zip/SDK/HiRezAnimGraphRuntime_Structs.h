#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct HiRezAnimGraphRuntime.AnimNode_BlendByLOD
// Size: 0xB0(Inherited: 0xA8) 
struct FAnimNode_BlendByLOD : public FAnimNode_BlendListBase
{
	int32_t LOD;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)

}; 
// ScriptStruct HiRezAnimGraphRuntime.AnimNode_BlendByDedicatedServer
// Size: 0x48(Inherited: 0x20) 
struct FAnimNode_BlendByDedicatedServer : public FAnimNode_Base
{
	struct FPoseLink NotDedicatedServer;  // 0x20(0x10)
	struct FPoseLink DedicatedServer;  // 0x30(0x10)
	char pad_64[8];  // 0x40(0x8)

}; 
// ScriptStruct HiRezAnimGraphRuntime.AnimNode_RigidBodySkipServer
// Size: 0x5B0(Inherited: 0x5B0) 
struct FAnimNode_RigidBodySkipServer : public FAnimNode_RigidBody
{
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool bIsDedicatedServer : 1;  // 0x5A8(0x1)

}; 
