#pragma once 
#include <EventTracker_Purchase_CashSpent_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C
// Size: 0x1CC(Inherited: 0x1C0) 
struct UEventTracker_Purchase_CashSpent_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t CashSpent;  // 0x1C8(0x4)

	void HandleTrackerInitialized(); // Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.MatchHasEnded_Event
	void OnShopItemPurchased(struct UKSGameShopItemComponent* ShopItemComponent); // Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.OnShopItemPurchased
	void OnShopItemRefunded(struct UKSGameShopItemComponent* ShopItemComponent); // Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.OnShopItemRefunded
	void ExecuteUbergraph_EventTracker_Purchase_CashSpent(int32_t EntryPoint); // Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.ExecuteUbergraph_EventTracker_Purchase_CashSpent
}; 



