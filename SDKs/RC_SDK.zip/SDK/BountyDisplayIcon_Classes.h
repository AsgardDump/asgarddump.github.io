#pragma once 
#include <BountyDisplayIcon_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BountyDisplayIcon.BountyDisplayIcon_C
// Size: 0x4E4(Inherited: 0x4C8) 
struct UBountyDisplayIcon_C : public UPUMG_Widget
{
	struct UHorizontalBox* BountyIconContainer;  // 0x4C8(0x8)
	struct UTextBlock* CrownAmountTextDisplay;  // 0x4D0(0x8)
	struct UWidgetSwitcher* CrownSwitcher;  // 0x4D8(0x8)
	int32_t BountyLevel;  // 0x4E0(0x4)

	void UpdateBountyLevel(int32_t NewBounty); // Function BountyDisplayIcon.BountyDisplayIcon_C.UpdateBountyLevel
}; 



