#pragma once 
#include "SDK.h" 
 
 
// Function BPI_SetSlomo.BPI_SetSlomo_C.SetSlomo
// Size: 0x1(Inherited: 0x0) 
struct FSetSlomo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnableSlomo : 1;  // 0x0(0x1)

}; 
