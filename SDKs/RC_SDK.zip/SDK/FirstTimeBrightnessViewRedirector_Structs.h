#pragma once 
#include "SDK.h" 
 
 
// Function FirstTimeBrightnessViewRedirector.FirstTimeBrightnessViewRedirector_C.DoesLocalSettingApply
// Size: 0xA(Inherited: 0x10) 
struct FDoesLocalSettingApply : public FDoesLocalSettingApply
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsPlatform_ReturnValue : 1;  // 0x9(0x1)

}; 
