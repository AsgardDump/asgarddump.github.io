#pragma once 
#include "SDK.h" 
 
 
// Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ExecuteUbergraph_FriendlyLobbyCharacter
// Size: 0x40(Inherited: 0x0) 
struct FExecuteUbergraph_FriendlyLobbyCharacter
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x8(0x8)
	struct UNewWBP_LobbyNameplate_C* K2Node_DynamicCast_AsNew_WBP_Lobby_Nameplate;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UKSPlayerInfo* K2Node_Event_PlayerInfo;  // 0x20(0x8)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue_2;  // 0x28(0x8)
	struct UNewWBP_LobbyNameplate_C* K2Node_DynamicCast_AsNew_WBP_Lobby_Nameplate_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x3C(0x4)

}; 
// Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.SetLobbyNameplate
// Size: 0x8(Inherited: 0x8) 
struct FSetLobbyNameplate : public FSetLobbyNameplate
{
	struct UKSPlayerInfo* playerinfo;  // 0x0(0x8)

}; 
// Function FriendlyLobbyCharacter.FriendlyLobbyCharacter_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
