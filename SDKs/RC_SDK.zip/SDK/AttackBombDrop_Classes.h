#pragma once 
#include <AttackBombDrop_Structs.h>
 
 
 
// BlueprintGeneratedClass AttackBombDrop.AttackBombDrop_C
// Size: 0xA70(Inherited: 0xA40) 
struct AAttackBombDrop_C : public AKSAttackBombDrop
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA40(0x8)
	struct UKSSkeletalMeshComponent* BombSkeletalMesh;  // 0xA48(0x8)
	struct UCapsuleComponent* BuildBlocker;  // 0xA50(0x8)
	struct UDistance_OcclusionKSAkComponent_C* DistanceKSAkComponent;  // 0xA58(0x8)
	struct UParticleSystem* ExplosionParticleSystem;  // 0xA60(0x8)
	struct UAkAudioEvent* ExplosionSoundEvent;  // 0xA68(0x8)

	void Update Bomb Tick(); // Function AttackBombDrop.AttackBombDrop_C.Update Bomb Tick
	void BombBeepPlaySFX(); // Function AttackBombDrop.AttackBombDrop_C.BombBeepPlaySFX
	void BombBeepStopSFX(); // Function AttackBombDrop.AttackBombDrop_C.BombBeepStopSFX
	void ReceiveBeginPlay(); // Function AttackBombDrop.AttackBombDrop_C.ReceiveBeginPlay
	void ExplodeCosmetic(); // Function AttackBombDrop.AttackBombDrop_C.ExplodeCosmetic
	void ReceiveDestroyed(); // Function AttackBombDrop.AttackBombDrop_C.ReceiveDestroyed
	void BndEvt__CollisionMesh_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function AttackBombDrop.AttackBombDrop_C.BndEvt__CollisionMesh_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
	void PlayDestroyedEffects(); // Function AttackBombDrop.AttackBombDrop_C.PlayDestroyedEffects
	void OnObjectiveStateChanged(struct TScriptInterface<IKSObjective> GameObjective); // Function AttackBombDrop.AttackBombDrop_C.OnObjectiveStateChanged
	void OnCurrentStateChanged(uint8_t  Objective State); // Function AttackBombDrop.AttackBombDrop_C.OnCurrentStateChanged
	void OnObjectiveTimerTickEvent(float Time); // Function AttackBombDrop.AttackBombDrop_C.OnObjectiveTimerTickEvent
	void ReceiveTick(float DeltaSeconds); // Function AttackBombDrop.AttackBombDrop_C.ReceiveTick
	void ExecuteUbergraph_AttackBombDrop(int32_t EntryPoint); // Function AttackBombDrop.AttackBombDrop_C.ExecuteUbergraph_AttackBombDrop
}; 



