#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C.ExecuteUbergraph_EventTracker_TotalCashEarned
// Size: 0xA4(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_TotalCashEarned
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_GetTotalCashEarned_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_GetInitialCash_ReturnValue;  // 0x38(0x4)
	int32_t K2Node_CustomEvent_Money;  // 0x3C(0x4)
	int32_t K2Node_CustomEvent_Delta;  // 0x40(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x4C(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_3;  // 0x50(0x8)
	struct AKSGameState* CallFunc_GetGameState_ReturnValue;  // 0x58(0x8)
	int32_t CallFunc_GetTotalCashEarned_ReturnValue_2;  // 0x60(0x4)
	int32_t CallFunc_GetInitialCash_ReturnValue_2;  // 0x64(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x68(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x78(0x4)
	struct FMatchPhase K2Node_CustomEvent_NewPhase;  // 0x7C(0x14)
	struct FMatchPhase K2Node_CustomEvent_PreviousPhase;  // 0x90(0x14)

}; 
// Function EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C.HandlePhaseChanged
// Size: 0x28(Inherited: 0x0) 
struct FHandlePhaseChanged
{
	struct FMatchPhase NewPhase;  // 0x0(0x14)
	struct FMatchPhase PreviousPhase;  // 0x14(0x14)

}; 
// Function EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C.HandleCashEarned
// Size: 0x8(Inherited: 0x0) 
struct FHandleCashEarned
{
	int32_t Money;  // 0x0(0x4)
	int32_t Delta;  // 0x4(0x4)

}; 
