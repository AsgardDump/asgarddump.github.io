#pragma once 
#include <EventTracker_MobilePlayerXP_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C
// Size: 0x208(Inherited: 0x1C0) 
struct UEventTracker_MobilePlayerXP_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	float BaseProgress;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct AKSPlayerState* PlayerState;  // 0x1D0(0x8)
	float AccumulatedProgress;  // 0x1D8(0x4)
	float PremiumBoostMultiplier;  // 0x1DC(0x4)
	float WinMultiplier;  // 0x1E0(0x4)
	char pad_484[4];  // 0x1E4(0x4)
	struct FString BonusKey;  // 0x1E8(0x10)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool MatchStarted : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct FDateTime MatchStartTime;  // 0x200(0x8)

	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessEventBonuses
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.IsWinningTeam
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessWinBonus
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessQueueBonus
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessBoosterBonuses
	void ComputeBaseProgess(float& OutProgress); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ComputeBaseProgess
	void HandleTrackerInitialized(); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.MatchHasEnded_Event
	void OnPhaseChanged(struct FMatchPhase PreviousPhase, struct FMatchPhase NewPhase); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.OnPhaseChanged
	void ExecuteUbergraph_EventTracker_MobilePlayerXP(int32_t EntryPoint); // Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ExecuteUbergraph_EventTracker_MobilePlayerXP
}; 



