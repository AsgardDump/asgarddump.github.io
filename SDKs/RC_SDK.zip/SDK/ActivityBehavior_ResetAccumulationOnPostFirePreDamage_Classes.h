#pragma once 
#include <ActivityBehavior_ResetAccumulationOnPostFirePreDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnPostFirePreDamage.ActivityBehavior_ResetAccumulationOnPostFirePreDamage_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_ResetAccumulationOnPostFirePreDamage_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnPostFirePreDamage.ActivityBehavior_ResetAccumulationOnPostFirePreDamage_C.HandleBehaviorInitialized
	void HandleWeaponFiredPreDamage(); // Function ActivityBehavior_ResetAccumulationOnPostFirePreDamage.ActivityBehavior_ResetAccumulationOnPostFirePreDamage_C.HandleWeaponFiredPreDamage
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnPostFirePreDamage(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnPostFirePreDamage.ActivityBehavior_ResetAccumulationOnPostFirePreDamage_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnPostFirePreDamage
}; 



