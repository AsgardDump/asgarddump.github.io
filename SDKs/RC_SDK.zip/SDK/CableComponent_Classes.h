#pragma once 
#include <CableComponent_Structs.h>
 
 
 
// Class CableComponent.CableActor
// Size: 0x228(Inherited: 0x220) 
struct ACableActor : public AActor
{
	struct UCableComponent* CableComponent;  // 0x220(0x8)

}; 



// Class CableComponent.CableComponent
// Size: 0x4F0(Inherited: 0x460) 
struct UCableComponent : public UMeshComponent
{
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool bUpdateOnlyIfRendered : 1;  // 0x458(0x1)
	char pad_1121_1 : 7;  // 0x461(0x1)
	bool bAttachStart : 1;  // 0x459(0x1)
	char pad_1122_1 : 7;  // 0x462(0x1)
	bool bAttachEnd : 1;  // 0x45A(0x1)
	struct FComponentReference AttachEndTo;  // 0x460(0x28)
	struct FName AttachEndToSocketName;  // 0x488(0x8)
	struct FVector EndLocation;  // 0x490(0xC)
	float CableLength;  // 0x49C(0x4)
	int32_t NumSegments;  // 0x4A0(0x4)
	float SubstepTime;  // 0x4A4(0x4)
	int32_t SolverIterations;  // 0x4A8(0x4)
	char pad_1199_1 : 7;  // 0x4AF(0x1)
	bool bEnableStiffness : 1;  // 0x4AC(0x1)
	char pad_1200_1 : 7;  // 0x4B0(0x1)
	bool bEnableCollision : 1;  // 0x4AD(0x1)
	float CollisionFriction;  // 0x4B0(0x4)
	struct FVector CableForce;  // 0x4B4(0xC)
	float CableGravityScale;  // 0x4C0(0x4)
	float CableWidth;  // 0x4C4(0x4)
	int32_t NumSides;  // 0x4C8(0x4)
	float TileMaterial;  // 0x4CC(0x4)
	char pad_1233[31];  // 0x4D1(0x1F)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor
}; 



