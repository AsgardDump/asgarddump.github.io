#pragma once 
#include <EventTracker_Death_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_Death.EventTracker_Death_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_Death_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_Death.EventTracker_Death_C.HandleTrackerInitialized
	void OnPlayerDeath(struct FCombatEventInfo EventInfo); // Function EventTracker_Death.EventTracker_Death_C.OnPlayerDeath
	void ExecuteUbergraph_EventTracker_Death(int32_t EntryPoint); // Function EventTracker_Death.EventTracker_Death_C.ExecuteUbergraph_EventTracker_Death
}; 



