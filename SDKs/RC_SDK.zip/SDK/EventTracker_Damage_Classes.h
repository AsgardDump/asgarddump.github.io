#pragma once 
#include <EventTracker_Damage_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_Damage.EventTracker_Damage_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_Damage_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_Damage.EventTracker_Damage_C.HandleTrackerInitialized
	void PlayerStateInstigateDamage(struct FCombatEventInfo& DamageInfo); // Function EventTracker_Damage.EventTracker_Damage_C.PlayerStateInstigateDamage
	void ExecuteUbergraph_EventTracker_Damage(int32_t EntryPoint); // Function EventTracker_Damage.EventTracker_Damage_C.ExecuteUbergraph_EventTracker_Damage
}; 



