#pragma once 
#include <Braze_Structs.h>
 
 
 
// Class Braze.Braze
// Size: 0x28(Inherited: 0x28) 
struct UBraze : public UObject
{

	void RequestImmediateDataFlush(); // Function Braze.Braze.RequestImmediateDataFlush
	void LogPurchaseWithProperties(struct FString ProductIdentifier, struct FString CurrencyCode, struct FString Price, char Quantity, struct FBrazeProperties& Properties); // Function Braze.Braze.LogPurchaseWithProperties
	void LogPurchase(struct FString ProductIdentifier, struct FString CurrencyCode, struct FString Price, char Quantity); // Function Braze.Braze.LogPurchase
	void LogCustomEventWithProperties(struct FString EventName, struct FBrazeProperties& Properties); // Function Braze.Braze.LogCustomEventWithProperties
	void LogCustomEvent(struct FString EventName); // Function Braze.Braze.LogCustomEvent
	struct UBrazeUser* GetCurrentUser(); // Function Braze.Braze.GetCurrentUser
	void ChangeUser(struct FString UserId); // Function Braze.Braze.ChangeUser
}; 



// Class Braze.BrazeConfig
// Size: 0xC8(Inherited: 0x28) 
struct UBrazeConfig : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bAutoInitialize : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString AndroidApiKey;  // 0x30(0x10)
	struct FString IOSApiKey;  // 0x40(0x10)
	struct FString CustomEndpoint;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bIsLocationCollectionEnabled : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool bGeofencesEnabled : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool bAutomaticGeofenceRequestsEnabled : 1;  // 0x62(0x1)
	char pad_99[1];  // 0x63(0x1)
	int32_t SessionTimeout;  // 0x64(0x4)
	int32_t TriggerActionMinimumTimeIntervalSeconds;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bIsAutomaticFlushEnabled : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	float FlushInterval;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool bEnableIOSPushDelegate : 1;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool bShowPushWhenAppInForeground : 1;  // 0x75(0x1)
	char pad_118[2];  // 0x76(0x2)
	struct FString DefaultNotificationChannelName;  // 0x78(0x10)
	struct FString DefaultNotificationChannelDescription;  // 0x88(0x10)
	int32_t DefaultNotificationAccentColor;  // 0x98(0x4)
	int32_t BadNetworkDataFlushInterval;  // 0x9C(0x4)
	int32_t GoodNetworkDataFlushInterval;  // 0xA0(0x4)
	int32_t GreatNetworkDataFlushInterval;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bIsSessionStartBasedTimeoutEnabled : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bEnableFirebaseCloudMessagingSupport : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bIsFirebaseCloudMessagingRegistrationEnabled : 1;  // 0xAA(0x1)
	char pad_171[5];  // 0xAB(0x5)
	struct FString FirebaseCloudMessagingSenderIdKey;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bIsPushWakeScreenForNotificationEnabled : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool bPushHtmlRenderingEnabled : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool bNewsFeedVisualIndicatorOn : 1;  // 0xC2(0x1)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool bAdmMessagingRegistrationEnabled : 1;  // 0xC3(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool bContentCardsUnreadVisualIndicatorEnabled : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool bIsInAppMessageAccessibilityExclusiveModeEnabled : 1;  // 0xC5(0x1)
	char pad_198_1 : 7;  // 0xC6(0x1)
	bool bInAppMessageTestPushEagerDisplayEnabled : 1;  // 0xC6(0x1)
	char pad_199[1];  // 0xC7(0x1)

}; 



// Class Braze.BrazePropertiesLibrary
// Size: 0x28(Inherited: 0x28) 
struct UBrazePropertiesLibrary : public UBlueprintFunctionLibrary
{

	struct FBrazeAny MakeBrazeAnyString(struct FString Value); // Function Braze.BrazePropertiesLibrary.MakeBrazeAnyString
	struct FBrazeAny MakeBrazeAnyInt(int32_t Value); // Function Braze.BrazePropertiesLibrary.MakeBrazeAnyInt
	struct FBrazeAny MakeBrazeAnyFloat(float Value); // Function Braze.BrazePropertiesLibrary.MakeBrazeAnyFloat
	struct FBrazeAny MakeBrazeAnyDate(struct FDateTime& Value); // Function Braze.BrazePropertiesLibrary.MakeBrazeAnyDate
	struct FBrazeAny MakeBrazeAnyBoolean(bool Value); // Function Braze.BrazePropertiesLibrary.MakeBrazeAnyBoolean
	void AddString(struct FBrazeProperties& Properties, struct FString Key, struct FString Value); // Function Braze.BrazePropertiesLibrary.AddString
	void AddInt(struct FBrazeProperties& Properties, struct FString Key, int32_t Value); // Function Braze.BrazePropertiesLibrary.AddInt
	void AddFloat(struct FBrazeProperties& Properties, struct FString Key, float Value); // Function Braze.BrazePropertiesLibrary.AddFloat
	void AddDate(struct FBrazeProperties& Properties, struct FString Key, struct FDateTime& Value); // Function Braze.BrazePropertiesLibrary.AddDate
	void AddBoolean(struct FBrazeProperties& Properties, struct FString Key, bool Value); // Function Braze.BrazePropertiesLibrary.AddBoolean
}; 



// Class Braze.BrazeUser
// Size: 0x28(Inherited: 0x28) 
struct UBrazeUser : public UObject
{

	bool UnsetCustomAttribute(struct FString AttributeKey); // Function Braze.BrazeUser.UnsetCustomAttribute
	bool SetPushSubscriptionType(uint8_t  SubscriptionType); // Function Braze.BrazeUser.SetPushSubscriptionType
	bool SetPhoneNumber(struct FString PhoneNumber); // Function Braze.BrazeUser.SetPhoneNumber
	bool SetLastName(struct FString LastName); // Function Braze.BrazeUser.SetLastName
	void SetLastKnownLocation(float Latitude, float Longitude, float Altitude, float Accuracy); // Function Braze.BrazeUser.SetLastKnownLocation
	bool SetLanguage(struct FString Language); // Function Braze.BrazeUser.SetLanguage
	bool SetHomeCity(struct FString HomeCity); // Function Braze.BrazeUser.SetHomeCity
	bool SetGender(uint8_t  Gender); // Function Braze.BrazeUser.SetGender
	bool SetFirstName(struct FString FirstName); // Function Braze.BrazeUser.SetFirstName
	bool SetEmailSubscriptionType(uint8_t  SubscriptionType); // Function Braze.BrazeUser.SetEmailSubscriptionType
	bool SetEmail(struct FString Email); // Function Braze.BrazeUser.SetEmail
	bool SetDateOfBirth(int32_t Year, uint8_t  Month, int32_t Day); // Function Braze.BrazeUser.SetDateOfBirth
	bool SetCustomUserAttributeString(struct FString AttributeKey, struct FString Value); // Function Braze.BrazeUser.SetCustomUserAttributeString
	bool SetCustomUserAttributeLong(struct FString AttributeKey, int64_t Value); // Function Braze.BrazeUser.SetCustomUserAttributeLong
	bool SetCustomUserAttributeInt(struct FString AttributeKey, int32_t Value); // Function Braze.BrazeUser.SetCustomUserAttributeInt
	bool SetCustomUserAttributeFloat(struct FString AttributeKey, float Value); // Function Braze.BrazeUser.SetCustomUserAttributeFloat
	bool SetCustomUserAttributeDate(struct FString AttributeKey, struct FDateTime& Date); // Function Braze.BrazeUser.SetCustomUserAttributeDate
	bool SetCustomUserAttributeBool(struct FString AttributeKey, bool Value); // Function Braze.BrazeUser.SetCustomUserAttributeBool
	bool SetCustomAttributeArray(struct FString AttributeKey, struct TArray<struct FString>& Values); // Function Braze.BrazeUser.SetCustomAttributeArray
	bool SetCountry(struct FString Country); // Function Braze.BrazeUser.SetCountry
	bool SetAttributionData(struct FBrazeAttributionData& attributionData); // Function Braze.BrazeUser.SetAttributionData
	bool RemoveFromCustomAttributeArray(struct FString AttributeKey, struct FString Value); // Function Braze.BrazeUser.RemoveFromCustomAttributeArray
	bool IncrementCustomUserAttribute(struct FString AttributeKey, int32_t IncrementValue); // Function Braze.BrazeUser.IncrementCustomUserAttribute
	bool AddToCustomAttributeArray(struct FString AttributeKey, struct FString Value); // Function Braze.BrazeUser.AddToCustomAttributeArray
	bool AddAlias(struct FString Alias, struct FString Label); // Function Braze.BrazeUser.AddAlias
}; 



// Class Braze.BrazeSubsystem
// Size: 0x38(Inherited: 0x30) 
struct UBrazeSubsystem : public UEngineSubsystem
{
	struct UBraze* BrazeInstance;  // 0x30(0x8)

	void WipeData(); // Function Braze.BrazeSubsystem.WipeData
	struct UBraze* InitializeBraze(struct UBrazeConfig* Config); // Function Braze.BrazeSubsystem.InitializeBraze
	void EnableSDK(); // Function Braze.BrazeSubsystem.EnableSDK
	void DisableSDK(); // Function Braze.BrazeSubsystem.DisableSDK
	void AndroidSetLogLevel(uint8_t  BrazeLogLevel); // Function Braze.BrazeSubsystem.AndroidSetLogLevel
}; 



