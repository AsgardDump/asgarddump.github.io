#pragma once 
#include <CosmeticSlotDetails_Structs.h>
 
 
 
