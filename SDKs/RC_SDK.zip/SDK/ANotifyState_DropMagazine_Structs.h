#pragma once 
#include "SDK.h" 
 
 
// Function ANotifyState_DropMagazine.ANotifyState_DropMagazine_C.Received_NotifyBegin
// Size: 0x91(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x20(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x30(0x8)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue;  // 0x40(0x8)
	struct TArray<struct UKSPlayerModInstance*> CallFunc_GetModInstances_OutMods;  // 0x48(0x10)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool CallFunc_GetModInstances_ReturnValue : 1;  // 0x58(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x5C(0x4)
	struct UKSCharacterAnimInst* CallFunc_GetKSCharacterAnimInst_ReturnValue;  // 0x60(0x8)
	char pad_107_1 : 7;  // 0x6B(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_QueryModsForAnimEvent_ReturnValue : 1;  // 0x69(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x6C(0x4)
	struct UKSPlayerModInstance* CallFunc_Array_Get_Item;  // 0x70(0x8)
	struct UReloadMagWepOnDodgeRollModInst_C* K2Node_DynamicCast_AsReload_Mag_Wep_on_Dodge_Roll_Mod_Inst;  // 0x78(0x8)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	char pad_130[6];  // 0x82(0x6)
	struct UReloadOnDodgeRollModInst_C* K2Node_DynamicCast_AsReload_on_Dodge_Roll_Mod_Inst;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x90(0x1)

}; 
// Function ANotifyState_DropMagazine.ANotifyState_DropMagazine_C.Received_NotifyEnd
// Size: 0x11(Inherited: 0x18) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)

}; 
