#pragma once 
#include <FlashBangGrenadeDamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass FlashBangGrenadeDamageType.FlashBangGrenadeDamageType_C
// Size: 0x148(Inherited: 0x148) 
struct UFlashBangGrenadeDamageType_C : public UKSDamageTypeFlashBang
{

}; 



