#pragma once 
#include <BP_GameInstance_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GameInstance.BP_GameInstance_C
// Size: 0x598(Inherited: 0x590) 
struct UBP_GameInstance_C : public UKSGameInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x590(0x8)

	void EndLoading(); // Function BP_GameInstance.BP_GameInstance_C.EndLoading
	void BeginLoading(struct FString mapName); // Function BP_GameInstance.BP_GameInstance_C.BeginLoading
	void ExecuteUbergraph_BP_GameInstance(int32_t EntryPoint); // Function BP_GameInstance.BP_GameInstance_C.ExecuteUbergraph_BP_GameInstance
}; 



