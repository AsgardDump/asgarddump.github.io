#pragma once 
#include <ExplosiveStakeDamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass ExplosiveStakeDamageType.ExplosiveStakeDamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UExplosiveStakeDamageType_C : public UMasterExplosion_DamageType_C
{

}; 



