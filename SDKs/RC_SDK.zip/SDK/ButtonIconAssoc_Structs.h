#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ButtonIconAssoc.ButtonIconAssoc
// Size: 0x28(Inherited: 0x0) 
struct FButtonIconAssoc
{
	struct UTexture2D* XboxIcon_2_1E15CF55443F0ABB0D9D80AD919E399B;  // 0x0(0x8)
	struct UTexture2D* XSXIcon_15_87C5D8BD4B20AB18B5B9539CCB22FD81;  // 0x8(0x8)
	struct UTexture2D* PlayStationIcon_4_81A75B5741B9D4449269A08158D8DED9;  // 0x10(0x8)
	struct UTexture2D* PS5Icon_16_EBDFAF1E42BB98180B76349E0C721243;  // 0x18(0x8)
	struct UTexture2D* SwitchIcon_10_99EC023740543B8F361E89B4491D92B2;  // 0x20(0x8)

}; 
