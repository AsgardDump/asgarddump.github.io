#pragma once 
#include <HandCrawlingNotify_Structs.h>
 
 
 
// BlueprintGeneratedClass HandCrawlingNotify.HandCrawlingNotify_C
// Size: 0x44(Inherited: 0x38) 
struct UHandCrawlingNotify_C : public UAnimNotify
{
	char StepType StepType;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FName BoneName;  // 0x3C(0x8)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function HandCrawlingNotify.HandCrawlingNotify_C.Received_Notify
	struct FString GetNotifyName(); // Function HandCrawlingNotify.HandCrawlingNotify_C.GetNotifyName
}; 



