#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessBoosterBonuses
// Size: 0x104(Inherited: 0x0) 
struct FProcessBoosterBonuses
{
	float OutProgress;  // 0x0(0x4)
	float BoosterProgress;  // 0x4(0x4)
	struct TMap<struct FString, float> BoosterMultipliers;  // 0x8(0x50)
	struct FString CurrentBoosterName;  // 0x58(0x10)
	float TotalBoosterProgress;  // 0x68(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x6C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x70(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x74(0x4)
	struct TArray<struct FString> CallFunc_Map_Keys_Keys;  // 0x78(0x10)
	struct FString CallFunc_Array_Get_Item;  // 0x88(0x10)
	struct TMap<struct FString, float> CallFunc_GetBonusProgressionMultiplierFromBoosters_ReturnValue;  // 0x98(0x50)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xE8(0x4)
	char pad_236_1 : 7;  // 0xEC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xEC(0x1)
	char pad_237[3];  // 0xED(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xF0(0x4)
	float CallFunc_Map_Find_Value;  // 0xF4(0x4)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xFC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x100(0x4)

}; 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ExecuteUbergraph_EventTracker_MobilePlayerXP
// Size: 0xD6(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_MobilePlayerXP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDateTime CallFunc_Now_ReturnValue;  // 0x8(0x8)
	float Temp_float_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x18(0x8)
	float CallFunc_ComputeBaseProgess_OutProgress;  // 0x20(0x4)
	struct FMatchPhase CallFunc_GetMatchPhase_ReturnValue;  // 0x24(0x14)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float CallFunc_ProcessBoosterBonuses_OutProgress;  // 0x3C(0x4)
	float CallFunc_ProcessQueueBonus_OutProgress;  // 0x40(0x4)
	float CallFunc_ProcessWinBonus_OutProgress;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Temp_bool_Variable : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x4C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x50(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x54(0x4)
	float CallFunc_ProcessEventBonuses_OutProgress;  // 0x58(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x5C(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x70(0x8)
	struct FMatchPhase K2Node_CustomEvent_PreviousPhase;  // 0x78(0x14)
	struct FMatchPhase K2Node_CustomEvent_NewPhase;  // 0x8C(0x14)
	float CallFunc_FindFloatProperty_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165_1 : 7;  // 0xA5(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0xA5(0x1)
	char pad_166[2];  // 0xA6(0x2)
	float K2Node_Select_Default;  // 0xA8(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xAC(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xBC(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0xC0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0xC4(0x10)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xD5(0x1)

}; 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessEventBonuses
// Size: 0x10C(Inherited: 0x0) 
struct FProcessEventBonuses
{
	float OutProgress;  // 0x0(0x4)
	float TotalEventProgress;  // 0x4(0x4)
	float EventProgress;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString CurrentEventName;  // 0x10(0x10)
	struct TMap<struct FString, float> EventMultipliers;  // 0x20(0x50)
	int32_t Temp_int_Array_Index_Variable;  // 0x70(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x74(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct TArray<struct FString> CallFunc_Map_Keys_Keys;  // 0x80(0x10)
	struct FString CallFunc_Array_Get_Item;  // 0x90(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xA8(0x4)
	float CallFunc_Map_Find_Value;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xB4(0x4)
	struct TMap<struct FString, float> CallFunc_GetBonusProgressionMultiplierFromEvents_ReturnValue;  // 0xB8(0x50)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x108(0x4)

}; 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.OnPhaseChanged
// Size: 0x28(Inherited: 0x0) 
struct FOnPhaseChanged
{
	struct FMatchPhase PreviousPhase;  // 0x0(0x14)
	struct FMatchPhase NewPhase;  // 0x14(0x14)

}; 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ComputeBaseProgess
// Size: 0x39(Inherited: 0x0) 
struct FComputeBaseProgess
{
	float OutProgress;  // 0x0(0x4)
	float timePlayed;  // 0x4(0x4)
	float Progress;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FDateTime CallFunc_Now_ReturnValue;  // 0x10(0x8)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x18(0x8)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue;  // 0x20(0x8)
	float CallFunc_GetMatchTimeElapsed_ReturnValue;  // 0x28(0x4)
	float CallFunc_GetTotalSeconds_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x30(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsBackfilling_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessQueueBonus
// Size: 0x14(Inherited: 0x0) 
struct FProcessQueueBonus
{
	float OutProgress;  // 0x0(0x4)
	float Progress;  // 0x4(0x4)
	float CallFunc_GetBonusProgressionMultiplier_ReturnValue;  // 0x8(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)

}; 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.ProcessWinBonus
// Size: 0x50(Inherited: 0x0) 
struct FProcessWinBonus
{
	float OutProgress;  // 0x0(0x4)
	float Progress;  // 0x4(0x4)
	uint8_t  Temp_byte_Variable;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_Variable : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	float Temp_float_Variable;  // 0xC(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsBackfilling_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_IsWinningTeam_IsWinningTeam : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_IsBackfilling_ReturnValue_2 : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool CallFunc_IsWinningTeam_IsWinningTeam_2 : 1;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x31(0x1)
	uint8_t  K2Node_Select_Default;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_IsInCustomMatch_ReturnValue : 1;  // 0x33(0x1)
	char pad_52[4];  // 0x34(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x43(0x1)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float K2Node_Select_Default_2;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)

}; 
// Function EventTracker_MobilePlayerXP.EventTracker_MobilePlayerXP_C.IsWinningTeam
// Size: 0x21(Inherited: 0x0) 
struct FIsWinningTeam
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsWinningTeam : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct AKSGameState* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_GetTeamNum_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_GetWinningTeamNum_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)

}; 
