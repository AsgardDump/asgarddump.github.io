#pragma once 
#include "SDK.h" 
 
 
// Function BrightLobbyWidget.BrightLobbyWidget_C.ExecuteUbergraph_BrightLobbyWidget
// Size: 0x160(Inherited: 0x0) 
struct FExecuteUbergraph_BrightLobbyWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UDataTable* Temp_object_Variable;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct UPUMG_ViewManager* CallFunc_SpawnObject_ReturnValue;  // 0x18(0x8)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x20(0x8)
	struct FName K2Node_CustomEvent_CurrentRoute_2;  // 0x28(0x8)
	struct FName K2Node_CustomEvent_LastRoute;  // 0x30(0x8)
	uint8_t  K2Node_CustomEvent_Layer_2;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UDataTable* Temp_object_Variable_2;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x4C(0x58)
	float K2Node_Event_InDeltaTime;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_CustomEvent_BeginChatCommand : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UPUMG_PlayerInfo* K2Node_CustomEvent_Player;  // 0xB0(0x8)
	struct FName K2Node_CustomEvent_CurrentRoute;  // 0xB8(0x8)
	struct FName K2Node_CustomEvent_NextRoute;  // 0xC0(0x8)
	uint8_t  K2Node_CustomEvent_Layer;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue_2 : 1;  // 0xCA(0x1)
	char pad_203_1 : 7;  // 0xCB(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue_3 : 1;  // 0xCB(0x1)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	struct TArray<struct UCanvasPanel*> K2Node_MakeArray_Array;  // 0xD0(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0xF4(0x10)
	uint8_t  Temp_byte_Variable;  // 0x104(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x105(0x1)
	char pad_262[2];  // 0x106(0x2)
	struct UPUMG_ViewManager* CallFunc_GetViewManager_ReturnValue;  // 0x108(0x8)
	struct FName CallFunc_GetCurrentRoute_ReturnValue;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool K2Node_SwitchName_CmpSuccess_2 : 1;  // 0x119(0x1)
	char pad_282_1 : 7;  // 0x11A(0x1)
	bool CallFunc_AddViewRoute_ReturnValue : 1;  // 0x11A(0x1)
	char pad_283_1 : 7;  // 0x11B(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x11B(0x1)
	char pad_284[4];  // 0x11C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_AllowCheats_ReturnValue : 1;  // 0x128(0x1)
	uint8_t  K2Node_Select_Default;  // 0x129(0x1)
	char pad_298[6];  // 0x12A(0x6)
	struct UPUMG_InputManager* CallFunc_GetInputManager_ReturnValue;  // 0x130(0x8)
	struct UPUMG_InputManager* CallFunc_GetInputManager_ReturnValue_2;  // 0x138(0x8)
	struct UPUMG_InputManager* CallFunc_GetInputManager_ReturnValue_3;  // 0x140(0x8)
	struct UPUMG_InputManager* CallFunc_GetInputManager_ReturnValue_4;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_DoesDataTableRowExist_ReturnValue : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_DoesDataTableRowExist_ReturnValue_2 : 1;  // 0x151(0x1)
	char pad_338_1 : 7;  // 0x152(0x1)
	bool CallFunc_IsMobile_ReturnValue : 1;  // 0x152(0x1)
	char pad_339[5];  // 0x153(0x5)
	struct UDataTable* K2Node_Select_Default_2;  // 0x158(0x8)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.HandleSpecialRouteCases
// Size: 0x11(Inherited: 0x0) 
struct FHandleSpecialRouteCases
{
	struct FName CurrentRoute;  // 0x0(0x8)
	struct FName LastRoute;  // 0x8(0x8)
	uint8_t  Layer;  // 0x10(0x1)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.HandleViewStateChangeStarted
// Size: 0x11(Inherited: 0x0) 
struct FHandleViewStateChangeStarted
{
	struct FName CurrentRoute;  // 0x0(0x8)
	struct FName NextRoute;  // 0x8(0x8)
	uint8_t  Layer;  // 0x10(0x1)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.OnKeyUp
// Size: 0x230(Inherited: 0x150) 
struct FOnKeyUp : public FOnKeyUp
{
	struct FGeometry MyGeometry;  // 0x0(0x58)
	struct FKeyEvent InKeyEvent;  // 0x58(0x38)
	struct FEventReply ReturnValue;  // 0x90(0xC0)
	struct FKey CallFunc_GetKey_ReturnValue;  // 0x150(0x18)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue : 1;  // 0x168(0x1)
	char pad_697_1 : 7;  // 0x2B9(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_2 : 1;  // 0x169(0x1)
	struct FEventReply CallFunc_Unhandled_ReturnValue;  // 0x170(0xC0)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.Tick
// Size: 0x5C(Inherited: 0x5C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x58)
	float InDeltaTime;  // 0x58(0x4)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.OpenTextChatToPlayer
// Size: 0x8(Inherited: 0x0) 
struct FOpenTextChatToPlayer
{
	struct UPUMG_PlayerInfo* Player;  // 0x0(0x8)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.HandleOpenTextChat
// Size: 0x1(Inherited: 0x0) 
struct FHandleOpenTextChat
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool BeginChatCommand : 1;  // 0x0(0x1)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.Set Safe Frame
// Size: 0x4(Inherited: 0x0) 
struct FSet Safe Frame
{
	float Scale;  // 0x0(0x4)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.CreateStickyWidgetData
// Size: 0x90(Inherited: 0x0) 
struct FCreateStickyWidgetData
{
	struct FStickyWidgetData K2Node_MakeStruct_StickyWidgetData;  // 0x0(0x10)
	struct FStickyWidgetData K2Node_MakeStruct_StickyWidgetData_2;  // 0x10(0x10)
	struct FStickyWidgetData K2Node_MakeStruct_StickyWidgetData_3;  // 0x20(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x30(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x34(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FStickyWidgetData K2Node_MakeStruct_StickyWidgetData_4;  // 0x40(0x10)
	struct FStickyWidgetData K2Node_MakeStruct_StickyWidgetData_5;  // 0x50(0x10)
	int32_t CallFunc_Array_Add_ReturnValue_4;  // 0x60(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_5;  // 0x64(0x4)
	struct FStickyWidgetData K2Node_MakeStruct_StickyWidgetData_6;  // 0x68(0x10)
	struct FStickyWidgetData K2Node_MakeStruct_StickyWidgetData_7;  // 0x78(0x10)
	int32_t CallFunc_Array_Add_ReturnValue_6;  // 0x88(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_7;  // 0x8C(0x4)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.HidePersistentWidgets
// Size: 0x30(Inherited: 0x0) 
struct FHidePersistentWidgets
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UPUMG_Widget* K2Node_DynamicCast_AsPUMG_Widget;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2C(0x4)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.InitializeSubWidgets
// Size: 0x3A(Inherited: 0x0) 
struct FInitializeSubWidgets
{
	struct UPanelWidget* Container;  // 0x0(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x18(0x8)
	struct UPanelWidget* K2Node_DynamicCast_AsPanel_Widget;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UPUMG_Widget* K2Node_DynamicCast_AsPUMG_Widget;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x39(0x1)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.UninitializeSubWidgets
// Size: 0x2A(Inherited: 0x0) 
struct FUninitializeSubWidgets
{
	struct UPanelWidget* Container;  // 0x0(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x18(0x8)
	struct UKSWidget* K2Node_DynamicCast_AsKSWidget;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x29(0x1)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.SetErrorMessageDT
// Size: 0x18(Inherited: 0x0) 
struct FSetErrorMessageDT
{
	struct AKSHUDCommon* K2Node_DynamicCast_AsKSHUDCommon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UPUMG_LoginDataFactory* CallFunc_GetLoginDataFactory_ReturnValue;  // 0x10(0x8)

}; 
// Function BrightLobbyWidget.BrightLobbyWidget_C.OnKeyDown
// Size: 0x22A(Inherited: 0x150) 
struct FOnKeyDown : public FOnKeyDown
{
	struct FGeometry MyGeometry;  // 0x0(0x58)
	struct FKeyEvent InKeyEvent;  // 0x58(0x38)
	struct FEventReply ReturnValue;  // 0x90(0xC0)
	struct FKey CallFunc_GetKey_ReturnValue;  // 0x150(0x18)
	struct FEventReply CallFunc_Unhandled_ReturnValue;  // 0x168(0xC0)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue : 1;  // 0x228(0x1)
	char pad_889_1 : 7;  // 0x379(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_2 : 1;  // 0x229(0x1)

}; 
