#pragma once 
#include <Distance_OcclusionKSAkComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass Distance_OcclusionKSAkComponent.Distance_OcclusionKSAkComponent_C
// Size: 0x4B0(Inherited: 0x4B0) 
struct UDistance_OcclusionKSAkComponent_C : public UKSAkAmbientComponent
{

}; 



