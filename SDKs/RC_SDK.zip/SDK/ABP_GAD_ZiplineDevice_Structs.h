#pragma once 
#include "SDK.h" 
 
 
// Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.ExecuteUbergraph_ABP_GAD_ZiplineDevice
// Size: 0x134(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_GAD_ZiplineDevice
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaTimeX;  // 0x4(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct AKSCharacterBase* CallFunc_TryGetKSCharacterBase_ReturnValue;  // 0x18(0x8)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x20(0x30)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue_2;  // 0x50(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x80(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x8C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x98(0xC)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0xA4(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0xB0(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0xBC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0xC8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0xD4(0xC)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue_3;  // 0xE0(0x30)
	struct FVector CallFunc_BreakTransform_Location_3;  // 0x110(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_3;  // 0x11C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_3;  // 0x128(0xC)

}; 
// Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_GAD_ZiplineDevice.ABP_GAD_ZiplineDevice_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
