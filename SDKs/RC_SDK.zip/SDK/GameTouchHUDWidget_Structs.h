#pragma once 
#include "SDK.h" 
 
 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.TriggerInputAction
// Size: 0x41(Inherited: 0x0) 
struct FTriggerInputAction
{
	struct FName InActionName;  // 0x0(0x8)
	char EInputEvent InInputEvent;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FKey CallFunc_GetButtonForActionMapping_Button;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_GetButtonForActionMapping_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x30(0x8)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.HandleAimStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FHandleAimStateChanged
{
	uint8_t  NewAimMode;  // 0x0(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.Event Handle Result Received
// Size: 0x1(Inherited: 0x0) 
struct FEvent Handle Result Received
{
	uint8_t  Result;  // 0x0(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.ExecuteUbergraph_GameTouchHUDWidget
// Size: 0x53C(Inherited: 0x0) 
struct FExecuteUbergraph_GameTouchHUDWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsHovered_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	struct FVector2D Temp_struct_Variable;  // 0x18(0x8)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* CallFunc_GetViewTarget_ReturnValue;  // 0x30(0x8)
	struct AKSPlayerController* K2Node_CustomEvent_Controller;  // 0x38(0x8)
	struct AActor* K2Node_CustomEvent_OldViewTarget;  // 0x40(0x8)
	struct AActor* K2Node_CustomEvent_NewViewTarget;  // 0x48(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x70(0x8)
	struct AKSCharacter* K2Node_CustomEvent_Character_2;  // 0x78(0x8)
	struct AActor* CallFunc_GetViewTarget_ReturnValue_2;  // 0x80(0x8)
	uint8_t  CallFunc_GetDesiredCameraShoulder_ReturnValue;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_3;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller_2;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct AKSCharacter* K2Node_CustomEvent_EquipmentOwner;  // 0xB0(0x8)
	struct UKSWeaponComponent* K2Node_CustomEvent_Equipment;  // 0xB8(0x8)
	struct UWidget* K2Node_Event_Widget;  // 0xC0(0x8)
	struct FSoftObjectPath K2Node_Event_Texture;  // 0xC8(0x18)
	struct UWBP_KillstreakMeter_C* K2Node_DynamicCast_AsWBP_Killstreak_Meter;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct UWBP_TouchButtonGeneric_C* K2Node_DynamicCast_AsWBP_Touch_Button_Generic;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x100(0x8)
	struct AActor* K2Node_CustomEvent_HoverTarget;  // 0x108(0x8)
	struct AKSZipLine* K2Node_DynamicCast_AsKSZip_Line;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x119(0x1)
	char pad_282_1 : 7;  // 0x11A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x11A(0x1)
	char pad_283[5];  // 0x11B(0x5)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x120(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_4;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_IsTouchModeAutoSprintActive_ReturnValue : 1;  // 0x131(0x1)
	char pad_306_1 : 7;  // 0x132(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x132(0x1)
	char pad_307[5];  // 0x133(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x138(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_3;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue : 1;  // 0x148(0x1)
	char pad_329[7];  // 0x149(0x7)
	struct UWBP_Touch_WeaponPickupEntry_C* CallFunc_Create_ReturnValue;  // 0x150(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_WasInputKeyJustReleased_ReturnValue : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_WasInputKeyJustPressed_ReturnValue : 1;  // 0x161(0x1)
	char pad_354_1 : 7;  // 0x162(0x1)
	bool CallFunc_IsPlatformType_ReturnValue : 1;  // 0x162(0x1)
	char pad_355[5];  // 0x163(0x5)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x168(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_5;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x178(0x1)
	char pad_377_1 : 7;  // 0x179(0x1)
	bool CallFunc_Array_Identical_ReturnValue : 1;  // 0x179(0x1)
	char pad_378[2];  // 0x17A(0x2)
	struct FVector2D CallFunc_Get_Touch_Cursor_Screen_Space_ReturnValue;  // 0x17C(0x8)
	float CallFunc_BreakVector2D_X;  // 0x184(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x188(0x4)
	float CallFunc_BreakVector2D_X_2;  // 0x18C(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0x190(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x194(0x4)
	float CallFunc_DegAtan2_ReturnValue;  // 0x198(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x19C(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1A4(0x4)
	struct FVector2D CallFunc_Multiply_Vector2DFloat_ReturnValue;  // 0x1A8(0x8)
	struct FVector2D CallFunc_Multiply_Vector2DFloat_ReturnValue_2;  // 0x1B0(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x1B8(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_2;  // 0x1C0(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_3;  // 0x1C8(0x8)
	struct FVector2D CallFunc_GetPosition_ReturnValue;  // 0x1D0(0x8)
	struct FVector2D CallFunc_GetPosition_ReturnValue_2;  // 0x1D8(0x8)
	struct FVector2D CallFunc_Add_Vector2DVector2D_ReturnValue;  // 0x1E0(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_4;  // 0x1E8(0x8)
	struct FVector2D CallFunc_GetPosition_ReturnValue_3;  // 0x1F0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1F8(0x10)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x208(0x58)
	float K2Node_Event_InDeltaTime;  // 0x260(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x264(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x274(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x284(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x294(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x2A4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x2B4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0x2C4(0x10)
	char pad_724[4];  // 0x2D4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_4;  // 0x2D8(0x8)
	struct TScriptInterface<IKSControllerInterface> K2Node_DynamicCast_AsKSController_Interface;  // 0x2E0(0x10)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct AKSCharacterBase* CallFunc_GetKSCharacter_ReturnValue;  // 0x2F8(0x8)
	uint8_t  Temp_byte_Variable;  // 0x300(0x1)
	char pad_769[3];  // 0x301(0x3)
	struct FVector2D Temp_struct_Variable_2;  // 0x304(0x8)
	struct FVector2D K2Node_Select_Default;  // 0x30C(0x8)
	char pad_788[4];  // 0x314(0x4)
	struct UWBP_FireWeapon_TouchButton_C* K2Node_DynamicCast_AsWBP_Fire_Weapon_Touch_Button;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool K2Node_DynamicCast_bSuccess_12 : 1;  // 0x320(0x1)
	char pad_801[7];  // 0x321(0x7)
	struct UWBP_FireWeapon_TouchButton_C* K2Node_DynamicCast_AsWBP_Fire_Weapon_Touch_Button_2;  // 0x328(0x8)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool K2Node_DynamicCast_bSuccess_13 : 1;  // 0x330(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x331(0x1)
	char pad_818[6];  // 0x332(0x6)
	struct AKSCharacter* K2Node_CustomEvent_Character;  // 0x338(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0x340(0x10)
	uint8_t  Temp_byte_Variable_3;  // 0x350(0x1)
	char pad_849[3];  // 0x351(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10;  // 0x354(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11;  // 0x364(0x10)
	uint8_t  K2Node_CustomEvent_NewAimMode;  // 0x374(0x1)
	char pad_885_1 : 7;  // 0x375(0x1)
	bool Temp_bool_Variable : 1;  // 0x375(0x1)
	char pad_886[2];  // 0x376(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12;  // 0x378(0x10)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_2;  // 0x388(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_6;  // 0x390(0x8)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool K2Node_DynamicCast_bSuccess_14 : 1;  // 0x398(0x1)
	uint8_t  CallFunc_GetCurrentAimState_ReturnValue;  // 0x399(0x1)
	char pad_922_1 : 7;  // 0x39A(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x39A(0x1)
	char pad_923[5];  // 0x39B(0x5)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_3;  // 0x3A0(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_7;  // 0x3A8(0x8)
	char pad_944_1 : 7;  // 0x3B0(0x1)
	bool K2Node_DynamicCast_bSuccess_15 : 1;  // 0x3B0(0x1)
	uint8_t  CallFunc_GetCurrentAimState_ReturnValue_2;  // 0x3B1(0x1)
	char pad_946_1 : 7;  // 0x3B2(0x1)
	bool CallFunc_IsPlatformType_ReturnValue_2 : 1;  // 0x3B2(0x1)
	char pad_947_1 : 7;  // 0x3B3(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_2 : 1;  // 0x3B3(0x1)
	char pad_948[4];  // 0x3B4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_5;  // 0x3B8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13;  // 0x3C0(0x10)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller_3;  // 0x3D0(0x8)
	char pad_984_1 : 7;  // 0x3D8(0x1)
	bool K2Node_DynamicCast_bSuccess_16 : 1;  // 0x3D8(0x1)
	uint8_t  K2Node_CustomEvent_Result;  // 0x3D9(0x1)
	char pad_986[6];  // 0x3DA(0x6)
	struct UKSHUDAnnouncementComponent* CallFunc_GetHUDAnnouncementComponent_ReturnValue;  // 0x3E0(0x8)
	struct AKSGameState_RoundGame* CallFunc_GetKSGameState_RoundGame_ReturnValue;  // 0x3E8(0x8)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool CallFunc_RoundHasEnded_ReturnValue : 1;  // 0x3F0(0x1)
	char pad_1009_1 : 7;  // 0x3F1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x3F1(0x1)
	char pad_1010[6];  // 0x3F2(0x6)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_4;  // 0x3F8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14;  // 0x400(0x10)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_8;  // 0x410(0x8)
	char pad_1048_1 : 7;  // 0x418(0x1)
	bool K2Node_DynamicCast_bSuccess_17 : 1;  // 0x418(0x1)
	uint8_t  CallFunc_GetCurrentAimState_ReturnValue_3;  // 0x419(0x1)
	char pad_1050[6];  // 0x41A(0x6)
	struct AKSPlayerController* K2Node_CustomEvent_OwningPlayerController;  // 0x420(0x8)
	struct UKSHUDAnnouncementComponent* K2Node_CustomEvent_SpawnedHUDAnnouncementComponent;  // 0x428(0x8)
	char pad_1072_1 : 7;  // 0x430(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_3 : 1;  // 0x430(0x1)
	char pad_1073_1 : 7;  // 0x431(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x431(0x1)
	char pad_1074_1 : 7;  // 0x432(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x432(0x1)
	char pad_1075[5];  // 0x433(0x5)
	struct AKSCharacterBase* Temp_object_Variable;  // 0x438(0x8)
	char pad_1088_1 : 7;  // 0x440(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x440(0x1)
	char pad_1089[7];  // 0x441(0x7)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_9;  // 0x448(0x8)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool K2Node_DynamicCast_bSuccess_18 : 1;  // 0x450(0x1)
	char pad_1105[3];  // 0x451(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15;  // 0x454(0x10)
	char pad_1124_1 : 7;  // 0x464(0x1)
	bool CallFunc_IsDeadOrDestroyed_ReturnValue : 1;  // 0x464(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x465(0x1)
	char pad_1126[2];  // 0x466(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16;  // 0x468(0x10)
	struct UPUMG_ViewManager* CallFunc_GetViewManager_ReturnValue;  // 0x478(0x8)
	uint8_t  K2Node_Select_Default_2;  // 0x480(0x1)
	char pad_1153[3];  // 0x481(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_17;  // 0x484(0x10)
	struct FName K2Node_CustomEvent_CurrentRoute;  // 0x494(0x8)
	struct FName K2Node_CustomEvent_PreviousRoute;  // 0x49C(0x8)
	uint8_t  K2Node_CustomEvent_Layer;  // 0x4A4(0x1)
	char pad_1189_1 : 7;  // 0x4A5(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x4A5(0x1)
	char pad_1190[2];  // 0x4A6(0x2)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_5;  // 0x4A8(0x8)
	uint8_t  Temp_byte_Variable_5;  // 0x4B0(0x1)
	char pad_1201[7];  // 0x4B1(0x7)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_10;  // 0x4B8(0x8)
	char pad_1216_1 : 7;  // 0x4C0(0x1)
	bool K2Node_DynamicCast_bSuccess_19 : 1;  // 0x4C0(0x1)
	uint8_t  CallFunc_GetCurrentAimState_ReturnValue_4;  // 0x4C1(0x1)
	char pad_1218[2];  // 0x4C2(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4C4(0x4)
	char pad_1224_1 : 7;  // 0x4C8(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_4 : 1;  // 0x4C8(0x1)
	char pad_1225[3];  // 0x4C9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4CC(0x4)
	char pad_1232_1 : 7;  // 0x4D0(0x1)
	bool K2Node_CustomEvent_IsSprinting : 1;  // 0x4D0(0x1)
	char pad_1233_1 : 7;  // 0x4D1(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x4D1(0x1)
	char pad_1234[2];  // 0x4D2(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_18;  // 0x4D4(0x10)
	uint8_t  K2Node_Select_Default_3;  // 0x4E4(0x1)
	char pad_1253_1 : 7;  // 0x4E5(0x1)
	bool CallFunc_IsPlatformType_ReturnValue_3 : 1;  // 0x4E5(0x1)
	char pad_1254[2];  // 0x4E6(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_19;  // 0x4E8(0x10)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_6;  // 0x4F8(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_11;  // 0x500(0x8)
	char pad_1288_1 : 7;  // 0x508(0x1)
	bool K2Node_DynamicCast_bSuccess_20 : 1;  // 0x508(0x1)
	char pad_1289_1 : 7;  // 0x509(0x1)
	bool CallFunc_GetSettingAsBool_OutBool : 1;  // 0x509(0x1)
	char pad_1290_1 : 7;  // 0x50A(0x1)
	bool CallFunc_GetSettingAsBool_ReturnValue : 1;  // 0x50A(0x1)
	char pad_1291_1 : 7;  // 0x50B(0x1)
	bool CallFunc_IsSprinting_ReturnValue : 1;  // 0x50B(0x1)
	char pad_1292[4];  // 0x50C(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x510(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x518(0x4)
	char pad_1308[4];  // 0x51C(0x4)
	struct AKSItemDrop* K2Node_DynamicCast_AsKSItem_Drop;  // 0x520(0x8)
	char pad_1320_1 : 7;  // 0x528(0x1)
	bool K2Node_DynamicCast_bSuccess_21 : 1;  // 0x528(0x1)
	char pad_1321_1 : 7;  // 0x529(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x529(0x1)
	char pad_1322_1 : 7;  // 0x52A(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x52A(0x1)
	char pad_1323[5];  // 0x52B(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x530(0x8)
	char pad_1336_1 : 7;  // 0x538(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue_2 : 1;  // 0x538(0x1)
	char pad_1337_1 : 7;  // 0x539(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x539(0x1)
	char pad_1338_1 : 7;  // 0x53A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x53A(0x1)
	char pad_1339_1 : 7;  // 0x53B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x53B(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.Tick
// Size: 0x5C(Inherited: 0x5C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x58)
	float InDeltaTime;  // 0x58(0x4)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.ViewChange 
// Size: 0x11(Inherited: 0x0) 
struct FViewChange 
{
	struct FName CurrentRoute;  // 0x0(0x8)
	struct FName PreviousRoute;  // 0x8(0x8)
	uint8_t  Layer;  // 0x10(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnSprintChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnSprintChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsSprinting : 1;  // 0x0(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnDelayedHUDAnnouncementComponentCreated
// Size: 0x10(Inherited: 0x0) 
struct FOnDelayedHUDAnnouncementComponentCreated
{
	struct AKSPlayerController* OwningPlayerController;  // 0x0(0x8)
	struct UKSHUDAnnouncementComponent* SpawnedHUDAnnouncementComponent;  // 0x8(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.HandleWeaponChange
// Size: 0x8(Inherited: 0x0) 
struct FHandleWeaponChange
{
	struct AKSCharacter* Character;  // 0x0(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.OnHoveredInteractableChanged
// Size: 0x8(Inherited: 0x0) 
struct FOnHoveredInteractableChanged
{
	struct AActor* HoverTarget;  // 0x0(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.SetWidgetIconTexture
// Size: 0x20(Inherited: 0x20) 
struct FSetWidgetIconTexture : public FSetWidgetIconTexture
{
	struct UWidget* Widget;  // 0x0(0x8)
	struct FSoftObjectPath Texture;  // 0x8(0x18)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.HandleEquipmentChange
// Size: 0x10(Inherited: 0x0) 
struct FHandleEquipmentChange
{
	struct AKSCharacter* EquipmentOwner;  // 0x0(0x8)
	struct UKSWeaponComponent* Equipment;  // 0x8(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.ShoulderSwapUpdate
// Size: 0x8(Inherited: 0x0) 
struct FShoulderSwapUpdate
{
	struct AKSCharacter* Character;  // 0x0(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.ViewTargetChanged
// Size: 0x18(Inherited: 0x0) 
struct FViewTargetChanged
{
	struct AKSPlayerController* Controller;  // 0x0(0x8)
	struct AActor* OldViewTarget;  // 0x8(0x8)
	struct AActor* NewViewTarget;  // 0x10(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.IsPointOverWidget
// Size: 0x43(Inherited: 0x0) 
struct FIsPointOverWidget
{
	struct FVector2D ScreenPoint;  // 0x0(0x8)
	struct UWidget* Widget;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsPointOverWidget : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_BreakVector2D_X;  // 0x14(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x18(0x4)
	struct FVector2D CallFunc_GetWidgetBounds_TopLeft;  // 0x1C(0x8)
	struct FVector2D CallFunc_GetWidgetBounds_BottomRight;  // 0x24(0x8)
	float CallFunc_BreakVector2D_X_2;  // 0x2C(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0x30(0x4)
	float CallFunc_BreakVector2D_X_3;  // 0x34(0x4)
	float CallFunc_BreakVector2D_Y_3;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x3E(0x1)
	char pad_63_1 : 7;  // 0x3F(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x3F(0x1)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x42(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.GetWidgetBounds
// Size: 0x98(Inherited: 0x0) 
struct FGetWidgetBounds
{
	struct UWidget* Widget;  // 0x0(0x8)
	struct FVector2D TopLeft;  // 0x8(0x8)
	struct FVector2D BottomRight;  // 0x10(0x8)
	struct FGeometry CallFunc_GetCachedGeometry_ReturnValue;  // 0x18(0x58)
	struct FVector2D CallFunc_LocalToViewport_PixelPosition;  // 0x70(0x8)
	struct FVector2D CallFunc_LocalToViewport_ViewportPosition;  // 0x78(0x8)
	struct FVector2D CallFunc_GetLocalSize_ReturnValue;  // 0x80(0x8)
	struct FVector2D CallFunc_LocalToViewport_PixelPosition_2;  // 0x88(0x8)
	struct FVector2D CallFunc_LocalToViewport_ViewportPosition_2;  // 0x90(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.ResetJoystick
// Size: 0x10(Inherited: 0x0) 
struct FResetJoystick
{
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x0(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_2;  // 0x8(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.SnapJoystickToCursor
// Size: 0x4C(Inherited: 0x0) 
struct FSnapJoystickToCursor
{
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x0(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue_2;  // 0x8(0x8)
	struct FVector2D CallFunc_Get_Touch_Cursor_Screen_Space_ReturnValue;  // 0x10(0x8)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0x18(0x8)
	float CallFunc_BreakVector2D_X;  // 0x20(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x24(0x4)
	float CallFunc_BreakVector2D_X_2;  // 0x28(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0x2C(0x4)
	float CallFunc_GetViewportScale_ReturnValue;  // 0x30(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x38(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x3C(0x8)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue;  // 0x44(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.Get Touch Cursor Screen Space
// Size: 0x54(Inherited: 0x0) 
struct FGet Touch Cursor Screen Space
{
	struct FKey KeyState;  // 0x0(0x18)
	struct FVector2D ReturnValue;  // 0x18(0x8)
	struct FKey NewLocalVar_1;  // 0x20(0x18)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x38(0x8)
	struct FVector CallFunc_GetInputVectorKeyState_ReturnValue;  // 0x40(0xC)
	struct FVector2D CallFunc_Conv_VectorToVector2D_ReturnValue;  // 0x4C(0x8)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.SetButtonMask
// Size: 0x49(Inherited: 0x0) 
struct FSetButtonMask
{
	struct TArray<bool> MaskArray;  // 0x0(0x10)
	uint8_t  Temp_byte_Variable;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x18(0x4)
	uint8_t  Temp_byte_Variable_2;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t Temp_int_Variable;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Array_Get_Item : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct TArray<struct UWidget*> CallFunc_GetHudMaskableButtons_MaskableButtons;  // 0x30(0x10)
	struct UWidget* CallFunc_Array_Get_Item_2;  // 0x40(0x8)
	uint8_t  K2Node_Select_Default;  // 0x48(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.GetHudMaskableButtons
// Size: 0x20(Inherited: 0x0) 
struct FGetHudMaskableButtons
{
	struct TArray<struct UWidget*> MaskableButtons;  // 0x0(0x10)
	struct TArray<struct UWidget*> K2Node_MakeArray_Array;  // 0x10(0x10)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.UpdateStateTouchCancelButton
// Size: 0x54(Inherited: 0x0) 
struct FUpdateStateTouchCancelButton
{
	uint8_t  Temp_byte_Variable;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x3(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x8(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	uint8_t  CallFunc_GetCurrentAimState_ReturnValue;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UKSWeaponComponent* CallFunc_GetActiveGadgetComponent_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UKSWeaponAsset* CallFunc_GetWeaponAsset_ReturnValue;  // 0x40(0x8)
	struct FGameplayTag CallFunc_GetWeaponEquipType_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_MatchesTag_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x51(0x1)
	uint8_t  K2Node_Select_Default;  // 0x52(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x53(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.Cancel Next Release
// Size: 0x19(Inherited: 0x0) 
struct FCancel Next Release
{
	struct UWBP_FireWeapon_TouchButton_C* K2Node_DynamicCast_AsWBP_Fire_Weapon_Touch_Button;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UWBP_FireWeapon_TouchButton_C* K2Node_DynamicCast_AsWBP_Fire_Weapon_Touch_Button_2;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x18(0x1)

}; 
// Function GameTouchHUDWidget.GameTouchHUDWidget_C.Set Character Auto Sprint
// Size: 0x19(Inherited: 0x0) 
struct FSet Character Auto Sprint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ShouldAutoSprint : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x8(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
