#pragma once 
#include <BulwarkShield_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass BulwarkShield_DamageType.BulwarkShield_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UBulwarkShield_DamageType_C : public UMasterMelee_DamageType_C
{

}; 



