#pragma once 
#include <EventTracker_DailyContract_UniqueRogueGames_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C
// Size: 0x1E8(Inherited: 0x1C0) 
struct UEventTracker_DailyContract_UniqueRogueGames_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	struct TArray<int32_t> ItemIds;  // 0x1C8(0x10)
	struct TArray<int32_t> LootTableItemIds;  // 0x1D8(0x10)

	void GetJobItemId(int32_t& JobItemId); // Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.GetJobItemId
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.IsWinningTeam
	void HandleTrackerInitialized(); // Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_DailyContract_UniqueRogueGames(int32_t EntryPoint); // Function EventTracker_DailyContract_UniqueRogueGames.EventTracker_DailyContract_UniqueRogueGames_C.ExecuteUbergraph_EventTracker_DailyContract_UniqueRogueGames
}; 



