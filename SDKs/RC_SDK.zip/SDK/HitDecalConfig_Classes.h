#pragma once 
#include <HitDecalConfig_Structs.h>
 
 
 
// BlueprintGeneratedClass HitDecalConfig.HitDecalConfig_C
// Size: 0x50(Inherited: 0x28) 
struct UHitDecalConfig_C : public UObject
{
	struct FHitDecalInfo Info;  // 0x28(0x28)

}; 



