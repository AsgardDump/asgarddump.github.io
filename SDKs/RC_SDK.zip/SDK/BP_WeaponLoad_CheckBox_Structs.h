#pragma once 
#include "SDK.h" 
 
 
// Function BP_WeaponLoad_CheckBox.BP_WeaponLoad_CheckBox_C.ExecuteUbergraph_BP_WeaponLoad_CheckBox
// Size: 0xB0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_WeaponLoad_CheckBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x18(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x28(0x88)

}; 
// Function BP_WeaponLoad_CheckBox.BP_WeaponLoad_CheckBox_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_WeaponLoad_CheckBox.BP_WeaponLoad_CheckBox_C.Trace
// Size: 0xB9(Inherited: 0x0) 
struct FTrace
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hit : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x8(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x18(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x24(0xC)
	struct FHitResult CallFunc_SphereTraceSingleForObjects_OutHit;  // 0x30(0x88)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_SphereTraceSingleForObjects_ReturnValue : 1;  // 0xB8(0x1)

}; 
