#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction CharacterEmotionComponent.CharacterEmotionComponent_C.OnCharacterDownedChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnCharacterDownedChanged__DelegateSignature
{
	struct AKSCharacter* bpp__Character__pf;  // 0x0(0x8)

}; 
// DelegateFunction CharacterEmotionComponent.CharacterEmotionComponent_C.OnAimStateChange__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnAimStateChange__DelegateSignature
{
	uint8_t  bpp__NewAimMode__pf;  // 0x0(0x1)

}; 
// DelegateFunction CharacterEmotionComponent.CharacterEmotionComponent_C.OnHealthChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnHealthChanged__DelegateSignature
{
	struct AKSCharacterFoundation* bpp__Character__pf;  // 0x0(0x8)

}; 
// Function CharacterEmotionComponent.CharacterEmotionComponent_C.Character Aim State Changed
// Size: 0x1(Inherited: 0x0) 
struct FCharacter Aim State Changed
{
	uint8_t  bpp__NewParam__pf;  // 0x0(0x1)

}; 
// Function CharacterEmotionComponent.CharacterEmotionComponent_C.Character Health Changed
// Size: 0x8(Inherited: 0x0) 
struct FCharacter Health Changed
{
	struct AKSCharacterFoundation* bpp__KSCharacterFoundation__pf;  // 0x0(0x8)

}; 
// Function CharacterEmotionComponent.CharacterEmotionComponent_C.Player Downed Changed
// Size: 0x8(Inherited: 0x0) 
struct FPlayer Downed Changed
{
	struct AKSCharacter* bpp__Character__pf;  // 0x0(0x8)

}; 
