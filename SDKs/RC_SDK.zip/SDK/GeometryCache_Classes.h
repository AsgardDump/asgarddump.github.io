#pragma once 
#include <GeometryCache_Structs.h>
 
 
 
// Class GeometryCache.GeometryCacheComponent
// Size: 0x4B0(Inherited: 0x460) 
struct UGeometryCacheComponent : public UMeshComponent
{
	struct UGeometryCache* GeometryCache;  // 0x458(0x8)
	char pad_1128_1 : 7;  // 0x468(0x1)
	bool bRunning : 1;  // 0x460(0x1)
	char pad_1129_1 : 7;  // 0x469(0x1)
	bool bLooping : 1;  // 0x461(0x1)
	float StartTimeOffset;  // 0x464(0x4)
	float PlaybackSpeed;  // 0x468(0x4)
	int32_t NumTracks;  // 0x46C(0x4)
	float ElapsedTime;  // 0x470(0x4)
	char pad_1146[42];  // 0x47A(0x2A)
	float Duration;  // 0x4A4(0x4)
	char pad_1192_1 : 7;  // 0x4A8(0x1)
	bool bManualTick : 1;  // 0x4A8(0x1)
	char pad_1193[7];  // 0x4A9(0x7)

	void TickAtThisTime(float Time, bool bInIsRunning, bool bInBackwards, bool bInIsLooping); // Function GeometryCache.GeometryCacheComponent.TickAtThisTime
	void Stop(); // Function GeometryCache.GeometryCacheComponent.Stop
	void SetStartTimeOffset(float NewStartTimeOffset); // Function GeometryCache.GeometryCacheComponent.SetStartTimeOffset
	void SetPlaybackSpeed(float NewPlaybackSpeed); // Function GeometryCache.GeometryCacheComponent.SetPlaybackSpeed
	void SetLooping(bool bNewLooping); // Function GeometryCache.GeometryCacheComponent.SetLooping
	bool SetGeometryCache(struct UGeometryCache* NewGeomCache); // Function GeometryCache.GeometryCacheComponent.SetGeometryCache
	void PlayReversedFromEnd(); // Function GeometryCache.GeometryCacheComponent.PlayReversedFromEnd
	void PlayReversed(); // Function GeometryCache.GeometryCacheComponent.PlayReversed
	void PlayFromStart(); // Function GeometryCache.GeometryCacheComponent.PlayFromStart
	void Play(); // Function GeometryCache.GeometryCacheComponent.Play
	void Pause(); // Function GeometryCache.GeometryCacheComponent.Pause
	bool IsPlayingReversed(); // Function GeometryCache.GeometryCacheComponent.IsPlayingReversed
	bool IsPlaying(); // Function GeometryCache.GeometryCacheComponent.IsPlaying
	bool IsLooping(); // Function GeometryCache.GeometryCacheComponent.IsLooping
	float GetStartTimeOffset(); // Function GeometryCache.GeometryCacheComponent.GetStartTimeOffset
	float GetPlaybackSpeed(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackSpeed
	float GetPlaybackDirection(); // Function GeometryCache.GeometryCacheComponent.GetPlaybackDirection
	int32_t GetNumberOfFrames(); // Function GeometryCache.GeometryCacheComponent.GetNumberOfFrames
	float GetDuration(); // Function GeometryCache.GeometryCacheComponent.GetDuration
	float GetAnimationTime(); // Function GeometryCache.GeometryCacheComponent.GetAnimationTime
}; 



// Class GeometryCache.GeometryCache
// Size: 0x68(Inherited: 0x28) 
struct UGeometryCache : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x30(0x10)
	struct TArray<struct UGeometryCacheTrack*> Tracks;  // 0x40(0x10)
	char pad_80[16];  // 0x50(0x10)
	int32_t StartFrame;  // 0x60(0x4)
	int32_t EndFrame;  // 0x64(0x4)

}; 



// Class GeometryCache.GeometryCacheActor
// Size: 0x228(Inherited: 0x220) 
struct AGeometryCacheActor : public AActor
{
	struct UGeometryCacheComponent* GeometryCacheComponent;  // 0x220(0x8)

	struct UGeometryCacheComponent* GetGeometryCacheComponent(); // Function GeometryCache.GeometryCacheActor.GetGeometryCacheComponent
}; 



// Class GeometryCache.GeometryCacheCodecBase
// Size: 0x38(Inherited: 0x28) 
struct UGeometryCacheCodecBase : public UObject
{
	struct TArray<int32_t> TopologyRanges;  // 0x28(0x10)

}; 



// Class GeometryCache.GeometryCacheTrack
// Size: 0x58(Inherited: 0x28) 
struct UGeometryCacheTrack : public UObject
{
	float Duration;  // 0x28(0x4)
	char pad_44[44];  // 0x2C(0x2C)

}; 



// Class GeometryCache.GeometryCacheTrack_FlipbookAnimation
// Size: 0x80(Inherited: 0x58) 
struct UGeometryCacheTrack_FlipbookAnimation : public UGeometryCacheTrack
{
	uint32_t NumMeshSamples;  // 0x58(0x4)
	char pad_92[36];  // 0x5C(0x24)

	void AddMeshSample(struct FGeometryCacheMeshData& MeshData, float SampleTime); // Function GeometryCache.GeometryCacheTrack_FlipbookAnimation.AddMeshSample
}; 



// Class GeometryCache.GeometryCacheCodecRaw
// Size: 0x40(Inherited: 0x38) 
struct UGeometryCacheCodecRaw : public UGeometryCacheCodecBase
{
	int32_t DummyProperty;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class GeometryCache.GeometryCacheCodecV1
// Size: 0x40(Inherited: 0x38) 
struct UGeometryCacheCodecV1 : public UGeometryCacheCodecBase
{
	char pad_56[8];  // 0x38(0x8)

}; 



// Class GeometryCache.GeometryCacheTrackStreamable
// Size: 0xD0(Inherited: 0x58) 
struct UGeometryCacheTrackStreamable : public UGeometryCacheTrack
{
	struct UGeometryCacheCodecBase* Codec;  // 0x58(0x8)
	char pad_96[104];  // 0x60(0x68)
	float StartSampleTime;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)

}; 



// Class GeometryCache.GeometryCacheTrack_TransformAnimation
// Size: 0x100(Inherited: 0x58) 
struct UGeometryCacheTrack_TransformAnimation : public UGeometryCacheTrack
{
	char pad_88[168];  // 0x58(0xA8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformAnimation.SetMesh
}; 



// Class GeometryCache.GeometryCacheTrack_TransformGroupAnimation
// Size: 0x100(Inherited: 0x58) 
struct UGeometryCacheTrack_TransformGroupAnimation : public UGeometryCacheTrack
{
	char pad_88[168];  // 0x58(0xA8)

	void SetMesh(struct FGeometryCacheMeshData& NewMeshData); // Function GeometryCache.GeometryCacheTrack_TransformGroupAnimation.SetMesh
}; 



