#pragma once 
#include <ActivityBehavior_ResetAccumulationOnRoundStart_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_ResetAccumulationOnRoundStart_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.HandleBehaviorInitialized
	void HandleRoundStart(struct FRoundInitState& RoundInitState); // Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.HandleRoundStart
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRoundStart(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnRoundStart.ActivityBehavior_ResetAccumulationOnRoundStart_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRoundStart
}; 



