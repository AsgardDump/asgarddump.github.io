#pragma once 
#include <FirstTimeTutorialRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass FirstTimeTutorialRedirector.FirstTimeTutorialRedirector_C
// Size: 0x30(Inherited: 0x30) 
struct UFirstTimeTutorialRedirector_C : public UKSViewRedirector_LocalSetting
{

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function FirstTimeTutorialRedirector.FirstTimeTutorialRedirector_C.DoesLocalSettingApply
}; 



