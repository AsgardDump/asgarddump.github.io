#pragma once 
#include <EventTracker_Reputation_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_Reputation.EventTracker_Reputation_C
// Size: 0x1F0(Inherited: 0x1C0) 
struct UEventTracker_Reputation_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	struct AKSPlayerState* PlayerState;  // 0x1C8(0x8)
	float BaseProgress;  // 0x1D0(0x4)
	float AccumulatedProgress;  // 0x1D4(0x4)
	float ReputationPerMinute;  // 0x1D8(0x4)
	float WinMultiplier;  // 0x1DC(0x4)
	struct FString BonusKey;  // 0x1E0(0x10)

	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessBoosterBonuses
	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessEventBonuses
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_Reputation.EventTracker_Reputation_C.IsWinningTeam
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessWinBonus
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ProcessQueueBonus
	void ComputeBaseProgress(float& OutProgress); // Function EventTracker_Reputation.EventTracker_Reputation_C.ComputeBaseProgress
	void HandleTrackerInitialized(); // Function EventTracker_Reputation.EventTracker_Reputation_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_Reputation.EventTracker_Reputation_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_Reputation(int32_t EntryPoint); // Function EventTracker_Reputation.EventTracker_Reputation_C.ExecuteUbergraph_EventTracker_Reputation
}; 



