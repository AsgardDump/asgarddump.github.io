#pragma once 
#include <EpicAntiCheatCommon_Structs.h>
 
 
 
// Class EpicAntiCheatCommon.EpicAntiCheatNetComponent
// Size: 0xB8(Inherited: 0xB0) 
struct UEpicAntiCheatNetComponent : public UActorComponent
{
	char pad_176[8];  // 0xB0(0x8)

	void ServerMessage(struct TArray<char> Message); // Function EpicAntiCheatCommon.EpicAntiCheatNetComponent.ServerMessage
	void ClientMessage(struct TArray<char> Message); // Function EpicAntiCheatCommon.EpicAntiCheatNetComponent.ClientMessage
}; 



