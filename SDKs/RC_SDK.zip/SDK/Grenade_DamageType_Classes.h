#pragma once 
#include <Grenade_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass Grenade_DamageType.Grenade_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UGrenade_DamageType_C : public UMasterExplosion_DamageType_C
{

}; 



