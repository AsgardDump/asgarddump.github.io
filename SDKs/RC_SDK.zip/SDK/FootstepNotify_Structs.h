#pragma once 
#include "SDK.h" 
 
 
// Function FootstepNotify.FootstepNotify_C.CanStepTypeShowFootprint
// Size: 0x10(Inherited: 0x0) 
struct FCanStepTypeShowFootprint
{
	struct AKSCharacter* bpp__CheckCharacter__pf;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function FootstepNotify.FootstepNotify_C.GetBoneName
// Size: 0x8(Inherited: 0x0) 
struct FGetBoneName
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function FootstepNotify.FootstepNotify_C.GetSFXMaterial
// Size: 0x20(Inherited: 0x0) 
struct FGetSFXMaterial
{
	struct UAnimInstance* bpp__AnimInstance__pf;  // 0x0(0x8)
	struct FName bpp__BonexName__pfT;  // 0x8(0x8)
	struct FName bpp__MaterialxReturn__pfT;  // 0x10(0x8)
	struct AActor* bpp__ActorxReturn__pfT;  // 0x18(0x8)

}; 
// Function FootstepNotify.FootstepNotify_C.Received_Notify
// Size: 0x18(Inherited: 0x0) 
struct FReceived_Notify
{
	struct USkeletalMeshComponent* bpp__MeshComp__pf;  // 0x0(0x8)
	struct UAnimSequenceBase* bpp__Animation__pf;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
