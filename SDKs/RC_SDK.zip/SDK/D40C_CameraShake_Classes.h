#pragma once 
#include <D40C_CameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass D40C_CameraShake.D40C_CameraShake_C
// Size: 0x160(Inherited: 0x160) 
struct UD40C_CameraShake_C : public UCameraShake
{

}; 



