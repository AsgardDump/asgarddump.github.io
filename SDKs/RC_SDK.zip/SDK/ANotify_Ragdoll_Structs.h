#pragma once 
#include "SDK.h" 
 
 
// Function ANotify_Ragdoll.ANotify_Ragdoll_C.Received_Notify
// Size: 0x2A(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_InitRagdoll_ReturnValue : 1;  // 0x29(0x1)

}; 
