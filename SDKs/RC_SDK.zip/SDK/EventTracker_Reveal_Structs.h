#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_Reveal.EventTracker_Reveal_C.HandleRevealTriggered
// Size: 0x48(Inherited: 0x0) 
struct FHandleRevealTriggered
{
	struct FKSRevealInfo RevealInfo;  // 0x0(0x48)

}; 
// Function EventTracker_Reveal.EventTracker_Reveal_C.ExecuteUbergraph_EventTracker_Reveal
// Size: 0x6A(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_Reveal
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKSRevealInfo K2Node_CustomEvent_RevealInfo;  // 0x8(0x48)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x50(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_IsRevealConditionMet_ReturnValue : 1;  // 0x69(0x1)

}; 
