#pragma once 
#include "SDK.h" 
 
 
// Function ABP_SupplyDrop.ABP_SupplyDrop_C.ExecuteUbergraph_ABP_SupplyDrop
// Size: 0x9(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_SupplyDrop
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function ABP_SupplyDrop.ABP_SupplyDrop_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
