#pragma once 
#include <ANotifyState_PreventReturnToHolsterFlag_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_PreventReturnToHolsterFlag.ANotifyState_PreventReturnToHolsterFlag_C
// Size: 0x51(Inherited: 0x30) 
struct UANotifyState_PreventReturnToHolsterFlag_C : public UAnimNotifyState
{
	struct FGameplayTagContainer Desired Weapon Type Tag;  // 0x30(0x20)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Use Tag Comparison : 1;  // 0x50(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_PreventReturnToHolsterFlag.ANotifyState_PreventReturnToHolsterFlag_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_PreventReturnToHolsterFlag.ANotifyState_PreventReturnToHolsterFlag_C.Received_NotifyBegin
}; 



