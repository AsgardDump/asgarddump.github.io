#pragma once 
#include <EventTracker_ActivityEvent_Targeted_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_ActivityEvent_Targeted.EventTracker_ActivityEvent_Targeted_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_ActivityEvent_Targeted_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_ActivityEvent_Targeted.EventTracker_ActivityEvent_Targeted_C.HandleTrackerInitialized
	void HandleTargetedActivityEventTriggered(struct FGameplayTag ActivityEventType, struct AKSCharacterFoundation* TargetCharacter); // Function EventTracker_ActivityEvent_Targeted.EventTracker_ActivityEvent_Targeted_C.HandleTargetedActivityEventTriggered
	void ExecuteUbergraph_EventTracker_ActivityEvent_Targeted(int32_t EntryPoint); // Function EventTracker_ActivityEvent_Targeted.EventTracker_ActivityEvent_Targeted_C.ExecuteUbergraph_EventTracker_ActivityEvent_Targeted
}; 



