#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction DualBoyar_WeaponComponent.DualBoyar_WeaponComponent_C.OnAimStateChange__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnAimStateChange__DelegateSignature
{
	uint8_t  bpp__NewAimMode__pf;  // 0x0(0x1)

}; 
// Function DualBoyar_WeaponComponent.DualBoyar_WeaponComponent_C.asdasd
// Size: 0x1(Inherited: 0x0) 
struct Fasdasd
{
	uint8_t  bpp__NewAimMode__pf;  // 0x0(0x1)

}; 
