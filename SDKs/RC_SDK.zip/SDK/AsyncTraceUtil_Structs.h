#pragma once 
#include "SDK.h" 
 
 
// Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultiSphereSweepByChannelAsync
// Size: 0x98(Inherited: 0x0) 
struct FMultiSphereSweepByChannelAsync
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector start;  // 0x8(0xC)
	struct FVector end;  // 0x14(0xC)
	char ECollisionChannel TraceChannel;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float SphereRadius;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bTraceComplex : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<struct AActor*> ActorsToIgnore;  // 0x30(0x10)
	char EDrawDebugTrace DrawDebugType;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FDelegate OnTraceComplete;  // 0x44(0x10)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bIgnoreSelf : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FLatentActionInfo LatentInfo;  // 0x58(0x18)
	struct FLinearColor TraceColor;  // 0x70(0x10)
	struct FLinearColor TraceHitColor;  // 0x80(0x10)
	float DrawTime;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)

}; 
// Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultiLineTraceByChannelAsync
// Size: 0x90(Inherited: 0x0) 
struct FMultiLineTraceByChannelAsync
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector start;  // 0x8(0xC)
	struct FVector end;  // 0x14(0xC)
	char ECollisionChannel TraceChannel;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bTraceComplex : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct TArray<struct AActor*> ActorsToIgnore;  // 0x28(0x10)
	char EDrawDebugTrace DrawDebugType;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FDelegate OnTraceComplete;  // 0x3C(0x10)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bIgnoreSelf : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FLatentActionInfo LatentInfo;  // 0x50(0x18)
	struct FLinearColor TraceColor;  // 0x68(0x10)
	struct FLinearColor TraceHitColor;  // 0x78(0x10)
	float DrawTime;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)

}; 
// DelegateFunction AsyncTraceUtil.AsyncTraceUtilBPLibrary.OnMultiAsyncTraceResult__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnMultiAsyncTraceResult__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bBlockingHit : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FHitResult> OutHits;  // 0x8(0x10)
	struct FVector start;  // 0x18(0xC)
	struct FVector end;  // 0x24(0xC)

}; 
// Function AsyncTraceUtil.AsyncTraceUtilBPLibrary.MultipleLineTraceAsync
// Size: 0xA0(Inherited: 0x0) 
struct FMultipleLineTraceAsync
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<struct FVector> Starts;  // 0x8(0x10)
	struct TArray<struct FVector> Ends;  // 0x18(0x10)
	char ECollisionChannel TraceChannel;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bTraceComplex : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct TArray<struct AActor*> ActorsToIgnore;  // 0x30(0x10)
	char EDrawDebugTrace DrawDebugType;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TArray<struct FHitResult> OutHits;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bIgnoreSelf : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FLatentActionInfo LatentInfo;  // 0x60(0x18)
	struct FLinearColor TraceColor;  // 0x78(0x10)
	struct FLinearColor TraceHitColor;  // 0x88(0x10)
	float DrawTime;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool ReturnValue : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)

}; 
