#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct HiRezNetTools.RepPreloaderItem
// Size: 0x38(Inherited: 0xC) 
struct FRepPreloaderItem : public FFastArraySerializerItem
{
	struct FPrimaryAssetId PrimaryAssetId;  // 0xC(0x10)
	struct FName BundleName;  // 0x1C(0x8)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bEntryWasReplicated : 1;  // 0x24(0x1)
	char pad_37[19];  // 0x25(0x13)

}; 
// ScriptStruct HiRezNetTools.ReplicatedLog
// Size: 0x70(Inherited: 0x0) 
struct FReplicatedLog
{
	int32_t MaxEntryReplication;  // 0x0(0x4)
	int32_t MaxHistory;  // 0x4(0x4)
	int32_t TailRepIndex;  // 0x8(0x4)
	int32_t HeadRepIndex;  // 0xC(0x4)
	int32_t ItemArrayTail;  // 0x10(0x4)
	int32_t ItemArrayHead;  // 0x14(0x4)
	char pad_24[88];  // 0x18(0x58)

}; 
// ScriptStruct HiRezNetTools.ReplicatedLogItem
// Size: 0x1(Inherited: 0x0) 
struct FReplicatedLogItem
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct HiRezNetTools.ReplicatedPreloader
// Size: 0x1E0(Inherited: 0x108) 
struct FReplicatedPreloader : public FFastArraySerializer
{
	char pad_264[80];  // 0x108(0x50)
	struct TArray<struct FRepPreloaderItem> RepArray;  // 0x158(0x10)
	struct TArray<struct FName> AlwaysIncludeBundles;  // 0x168(0x10)
	char pad_376[104];  // 0x178(0x68)

}; 
