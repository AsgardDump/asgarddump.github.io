#pragma once 
#include "SDK.h" 
 
 
// Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.ExecuteUbergraph_FirstTimeTutorialWidget
// Size: 0x119(Inherited: 0x0) 
struct FExecuteUbergraph_FirstTimeTutorialWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x8(0x10)
	struct UAkAudioEvent* Temp_object_Variable;  // 0x18(0x8)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_Remove_Top_View_Route_ViewChanged : 1;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)
	struct UKSNPEDataFactory* CallFunc_GetNPEDataFactory_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_GetFontByName_HasFound : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FSlateFontInfo CallFunc_GetFontByName_FontInfo;  // 0x40(0x50)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool Temp_bool_Variable : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct UWidget* K2Node_ComponentBoundEvent_Widget_2;  // 0x98(0x8)
	struct UWidget* K2Node_ComponentBoundEvent_Widget;  // 0xA0(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0xA8(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0xC0(0x8)
	struct UKSGameUserSettings* K2Node_DynamicCast_AsKSGame_User_Settings;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct UAkAudioEvent* K2Node_Select_Default;  // 0xD8(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0xE0(0x8)
	struct FDelegate Temp_delegate_Variable;  // 0xE8(0x10)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD_2;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct UKSNPEDataFactory* CallFunc_GetNPEDataFactory_ReturnValue_2;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_ShouldForceTutorial_ReturnValue : 1;  // 0x118(0x1)

}; 
// Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature
{
	struct UWidget* Widget;  // 0x0(0x8)

}; 
// Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.BndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
{
	struct UWidget* Widget;  // 0x0(0x8)

}; 
// Function FirstTimeTutorialWidget.FirstTimeTutorialWidget_C.LaunchTutorial
// Size: 0x20(Inherited: 0x0) 
struct FLaunchTutorial
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Force Close Screen : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Remove_Top_View_Route_ViewChanged : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct UKSNPEDataFactory* CallFunc_GetNPEDataFactory_ReturnValue;  // 0x18(0x8)

}; 
