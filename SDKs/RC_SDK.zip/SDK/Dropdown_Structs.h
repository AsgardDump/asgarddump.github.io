#pragma once 
#include "SDK.h" 
 
 
// Function Dropdown.Dropdown_C.OnSelectionChanged__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FOnSelectionChanged__DelegateSignature
{
	struct FText SelectionText;  // 0x0(0x18)
	int32_t SelectionIndex;  // 0x18(0x4)

}; 
// Function Dropdown.Dropdown_C.HoverPreview
// Size: 0x4(Inherited: 0x0) 
struct FHoverPreview
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function Dropdown.Dropdown_C.RemoveOptionByIndex
// Size: 0x6(Inherited: 0x0) 
struct FRemoveOptionByIndex
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x5(0x1)

}; 
// Function Dropdown.Dropdown_C.OnHoverPreview__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnHoverPreview__DelegateSignature
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function Dropdown.Dropdown_C.ExecuteUbergraph_Dropdown
// Size: 0xCC(Inherited: 0x0) 
struct FExecuteUbergraph_Dropdown
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsMobile_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_ComponentBoundEvent_bIsOpen : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t K2Node_CustomEvent_CurrentHoverIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_SetSelectedOptionByIndex_Success : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t K2Node_CustomEvent_Index_2;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FText K2Node_CustomEvent_Selection;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_SetSelectedOptionByIndex_Success_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x38(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x40(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x48(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x50(0x8)
	int32_t K2Node_CustomEvent_Index;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x60(0x8)
	struct FDelegate Temp_delegate_Variable;  // 0x68(0x10)
	char PGAME_INPUT_STATE CallFunc_GetCurrentInputState_ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x80(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x90(0x10)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0xA0(0x4)
	struct FDelegate Temp_delegate_Variable_2;  // 0xA4(0x10)
	char pad_180[4];  // 0xB4(0x4)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2;  // 0xB8(0x10)
	int32_t CallFunc_PostEvent_ReturnValue_2;  // 0xC8(0x4)

}; 
// Function Dropdown.Dropdown_C.SelectionMade
// Size: 0x20(Inherited: 0x0) 
struct FSelectionMade
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Selection;  // 0x8(0x18)

}; 
// Function Dropdown.Dropdown_C.InitializeDropdownList
// Size: 0x48(Inherited: 0x0) 
struct FInitializeDropdownList
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x18(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x28(0x10)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x38(0x8)
	struct UDropdownList_C* CallFunc_Create_ReturnValue;  // 0x40(0x8)

}; 
// Function Dropdown.Dropdown_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
// Function Dropdown.Dropdown_C.HandleSetCurrentHoverIndex
// Size: 0x4(Inherited: 0x0) 
struct FHandleSetCurrentHoverIndex
{
	int32_t CurrentHoverIndex;  // 0x0(0x4)

}; 
// Function Dropdown.Dropdown_C.BndEvt__DropdownAnchor_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__DropdownAnchor_K2Node_ComponentBoundEvent_0_OnMenuOpenChangedEvent__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsOpen : 1;  // 0x0(0x1)

}; 
// Function Dropdown.Dropdown_C.AddOption
// Size: 0x1C(Inherited: 0x0) 
struct FAddOption
{
	struct FText OptionText;  // 0x0(0x18)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x18(0x4)

}; 
// Function Dropdown.Dropdown_C.FindOptionByIndex
// Size: 0x40(Inherited: 0x0) 
struct FFindOptionByIndex
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText Option;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText CallFunc_Array_Get_Item;  // 0x28(0x18)

}; 
// Function Dropdown.Dropdown_C.FindIndexForOption
// Size: 0x25(Inherited: 0x0) 
struct FFindIndexForOption
{
	struct FText Option;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Index;  // 0x1C(0x4)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x24(0x1)

}; 
// Function Dropdown.Dropdown_C.GetOptionCount
// Size: 0x8(Inherited: 0x0) 
struct FGetOptionCount
{
	int32_t Count;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)

}; 
// Function Dropdown.Dropdown_C.GetSelectedOption
// Size: 0x39(Inherited: 0x0) 
struct FGetSelectedOption
{
	struct FText Selection;  // 0x0(0x18)
	int32_t Index;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FText CallFunc_Array_Get_Item;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function Dropdown.Dropdown_C.RemoveOptionByText
// Size: 0x1A(Inherited: 0x0) 
struct FRemoveOptionByText
{
	struct FText Option;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function Dropdown.Dropdown_C.AppendOptions
// Size: 0x10(Inherited: 0x0) 
struct FAppendOptions
{
	struct TArray<struct FText> OptionsToAppend;  // 0x0(0x10)

}; 
// Function Dropdown.Dropdown_C.SetSelectedOptionByText
// Size: 0x28(Inherited: 0x0) 
struct FSetSelectedOptionByText
{
	struct FText Text;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Scratch;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_SetSelectedOptionByIndex_Success : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x24(0x4)

}; 
// Function Dropdown.Dropdown_C.SetSelectedOptionByIndex
// Size: 0x21(Inherited: 0x0) 
struct FSetSelectedOptionByIndex
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText CallFunc_Array_Get_Item;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function Dropdown.Dropdown_C.ForceToggle
// Size: 0xB(Inherited: 0x0) 
struct FForceToggle
{
	struct UWidget* CallFunc_SetFocusToThis_ReturnValue;  // 0x0(0x8)
	char PGAME_INPUT_STATE CallFunc_GetCurrentInputState_ReturnValue;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsOpen_ReturnValue : 1;  // 0xA(0x1)

}; 
// Function Dropdown.Dropdown_C.NavigateConfirm
// Size: 0x2(Inherited: 0x1) 
struct FNavigateConfirm : public FNavigateConfirm
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_NavigateConfirm_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function Dropdown.Dropdown_C.IsSelecting
// Size: 0x2(Inherited: 0x0) 
struct FIsSelecting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsSelecting : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsOpen_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function Dropdown.Dropdown_C.OnInputStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnInputStateChanged
{
	char PGAME_INPUT_STATE InputState;  // 0x0(0x1)

}; 
// Function Dropdown.Dropdown_C.UpdateGamepadPromptVisibility
// Size: 0x14(Inherited: 0x0) 
struct FUpdateGamepadPromptVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct AKSHUDCommon* CallFunc_GetHUDCommon_HUD_Common;  // 0x8(0x8)
	char PGAME_INPUT_STATE CallFunc_GetCurrentInputState_ReturnValue;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x12(0x1)
	uint8_t  K2Node_Select_Default;  // 0x13(0x1)

}; 
// Function Dropdown.Dropdown_C.SetKeyPrompt
// Size: 0x19(Inherited: 0x0) 
struct FSetKeyPrompt
{
	struct FKey KeyPrompt;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Key_IsValid_ReturnValue : 1;  // 0x18(0x1)

}; 
