#pragma once 
#include "SDK.h" 
 
 
// Function DashChargesModInst.DashChargesModInst_C.OnRep_TimerHandle
// Size: 0x29(Inherited: 0x0) 
struct FOnRep_TimerHandle
{
	float CallFunc_K2_GetTimerRemainingTimeHandle_ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_K2_IsValidTimerHandle_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function DashChargesModInst.DashChargesModInst_C.CharacterDestroyed
// Size: 0x8(Inherited: 0x0) 
struct FCharacterDestroyed
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnCurrentChargesChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnCurrentChargesChanged__DelegateSignature
{
	int32_t CurrentCharges;  // 0x0(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnChargeTimerActivated__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnChargeTimerActivated__DelegateSignature
{
	float ChargeTime;  // 0x0(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.PlayAlternateEvadeAnim
// Size: 0xC(Inherited: 0x0) 
struct FPlayAlternateEvadeAnim
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsDodgeRolling : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName Direction;  // 0x4(0x8)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnRep_CurrentCharges
// Size: 0x22(Inherited: 0x0) 
struct FOnRep_CurrentCharges
{
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function DashChargesModInst.DashChargesModInst_C.ExecuteUbergraph_DashChargesModInst
// Size: 0x231(Inherited: 0x0) 
struct FExecuteUbergraph_DashChargesModInst
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDodgeRolling : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FName K2Node_Event_Direction;  // 0x8(0x8)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x10(0x8)
	int32_t K2Node_CustomEvent_MontageInstanceID_3;  // 0x18(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x2C(0x8)
	int32_t K2Node_CustomEvent_MontageInstanceID_2;  // 0x34(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x38(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x48(0x8)
	int32_t K2Node_CustomEvent_MontageInstanceID;  // 0x50(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x54(0x10)
	int32_t Temp_int_Variable;  // 0x64(0x4)
	struct FName Temp_name_Variable;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Temp_bool_Variable : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x72(0x1)
	char pad_115[5];  // 0x73(0x5)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue;  // 0x78(0x8)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue_2;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_CustomEvent_IsDodgeRolling : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x89(0x1)
	char pad_138[2];  // 0x8A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x8C(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x9C(0x10)
	char pad_172[4];  // 0xAC(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_K2_IsValidTimerHandle_ReturnValue : 1;  // 0xB9(0x1)
	char pad_186[2];  // 0xBA(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xBC(0x4)
	int32_t CallFunc_Min_ReturnValue;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool K2Node_CustomEvent_State : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue_3;  // 0xC8(0x8)
	struct AKSPlayerState* CallFunc_GetKSPlayerState_ReturnValue;  // 0xD0(0x8)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue_4;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_GiveMod_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_RemoveMod_ReturnValue : 1;  // 0xE1(0x1)
	char pad_226[2];  // 0xE2(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0xE4(0x10)
	char pad_244[4];  // 0xF4(0x4)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0xF8(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x10C(0x8)
	int32_t K2Node_CustomEvent_MontageInstanceID_4;  // 0x114(0x4)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct AKSCharacter* K2Node_CustomEvent_KSCharacter;  // 0x120(0x8)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue_5;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x134(0x10)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x144(0x8)
	int32_t K2Node_CustomEvent_MontageInstanceID_5;  // 0x14C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0x150(0x10)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue_6;  // 0x160(0x8)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue_7;  // 0x168(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0x170(0x10)
	struct AKSWeapon* CallFunc_GetActiveWeapon_ReturnValue;  // 0x180(0x8)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue_8;  // 0x188(0x8)
	struct UKSWeaponAsset* CallFunc_GetWeaponAsset_ReturnValue;  // 0x190(0x8)
	struct FGameplayTag CallFunc_GetWeaponType_ReturnValue;  // 0x198(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_MatchesAnyTags_ReturnValue : 1;  // 0x1A8(0x1)
	char pad_425[7];  // 0x1A9(0x7)
	struct UKSCharacterAnimInst* K2Node_DynamicCast_AsKSCharacter_Anim_Inst;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1B8(0x1)
	char pad_441[7];  // 0x1B9(0x7)
	struct UMultiSkinObject* CallFunc_GetSkinObject_ReturnValue;  // 0x1C0(0x8)
	int32_t CallFunc_GetAnimMontage_Priority;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct UAnimMontage* CallFunc_GetAnimMontage_ReturnValue;  // 0x1D0(0x8)
	int32_t CallFunc_CreateProxyObjectForPlayMontage_CreatedInstanceID;  // 0x1D8(0x4)
	char pad_476[4];  // 0x1DC(0x4)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1E8(0x1)
	char pad_489_1 : 7;  // 0x1E9(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1E9(0x1)
	char pad_490[2];  // 0x1EA(0x2)
	struct FDelegate Temp_delegate_Variable;  // 0x1EC(0x10)
	char pad_508_1 : 7;  // 0x1FC(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x1FC(0x1)
	char pad_509[3];  // 0x1FD(0x3)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x200(0x10)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x210(0x4)
	char pad_532[4];  // 0x214(0x4)
	struct AKSCharacter* K2Node_Select_Default;  // 0x218(0x8)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool CallFunc_RemoveMod_ReturnValue_2 : 1;  // 0x220(0x1)
	char pad_545[7];  // 0x221(0x7)
	struct AKSPlayerState* CallFunc_GetKSBestPlayerState_ReturnValue;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool CallFunc_RemoveMod_ReturnValue_3 : 1;  // 0x230(0x1)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnNotifyEnd_779C2D4547E65B767165349AFCB6D547
// Size: 0xC(Inherited: 0x0) 
struct FOnNotifyEnd_779C2D4547E65B767165349AFCB6D547
{
	struct FName NotifyName;  // 0x0(0x8)
	int32_t MontageInstanceID;  // 0x8(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.DodgeRollChanged
// Size: 0x1(Inherited: 0x0) 
struct FDodgeRollChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsDodgeRolling : 1;  // 0x0(0x1)

}; 
// Function DashChargesModInst.DashChargesModInst_C.Toggle SubMod
// Size: 0x1(Inherited: 0x0) 
struct FToggle SubMod
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool State : 1;  // 0x0(0x1)

}; 
// Function DashChargesModInst.DashChargesModInst_C.Remove SubMod
// Size: 0x8(Inherited: 0x0) 
struct FRemove SubMod
{
	struct AKSCharacter* KSCharacter;  // 0x0(0x8)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnCompleted_779C2D4547E65B767165349AFCB6D547
// Size: 0xC(Inherited: 0x0) 
struct FOnCompleted_779C2D4547E65B767165349AFCB6D547
{
	struct FName NotifyName;  // 0x0(0x8)
	int32_t MontageInstanceID;  // 0x8(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnBlendOut_779C2D4547E65B767165349AFCB6D547
// Size: 0xC(Inherited: 0x0) 
struct FOnBlendOut_779C2D4547E65B767165349AFCB6D547
{
	struct FName NotifyName;  // 0x0(0x8)
	int32_t MontageInstanceID;  // 0x8(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnInterrupted_779C2D4547E65B767165349AFCB6D547
// Size: 0xC(Inherited: 0x0) 
struct FOnInterrupted_779C2D4547E65B767165349AFCB6D547
{
	struct FName NotifyName;  // 0x0(0x8)
	int32_t MontageInstanceID;  // 0x8(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.OnNotifyBegin_779C2D4547E65B767165349AFCB6D547
// Size: 0xC(Inherited: 0x0) 
struct FOnNotifyBegin_779C2D4547E65B767165349AFCB6D547
{
	struct FName NotifyName;  // 0x0(0x8)
	int32_t MontageInstanceID;  // 0x8(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.DashStart
// Size: 0x54(Inherited: 0x0) 
struct FDashStart
{
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x10(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x20(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x30(0x10)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_Max_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x4C(0x4)
	int32_t CallFunc_Max_ReturnValue_2;  // 0x50(0x4)

}; 
// Function DashChargesModInst.DashChargesModInst_C.DashEnd
// Size: 0x1(Inherited: 0x0) 
struct FDashEnd
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DashChargesModInst.DashChargesModInst_C.Process Mod Status
// Size: 0x2(Inherited: 0x0) 
struct FProcess Mod Status
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x1(0x1)

}; 
