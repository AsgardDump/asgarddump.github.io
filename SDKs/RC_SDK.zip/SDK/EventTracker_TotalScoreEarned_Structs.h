#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C.ExecuteUbergraph_EventTracker_TotalScoreEarned
// Size: 0x98(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_TotalScoreEarned
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x18(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t K2Node_CustomEvent_Money;  // 0x34(0x4)
	struct FText K2Node_CustomEvent_Reason;  // 0x38(0x18)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x5C(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_3;  // 0x60(0x8)
	struct FMatchPhase K2Node_CustomEvent_NewPhase;  // 0x68(0x14)
	struct FMatchPhase K2Node_CustomEvent_PreviousPhase;  // 0x7C(0x14)
	struct AKSGameState* CallFunc_GetGameState_ReturnValue;  // 0x90(0x8)

}; 
// Function EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C.HandlePhaseChanged
// Size: 0x28(Inherited: 0x0) 
struct FHandlePhaseChanged
{
	struct FMatchPhase NewPhase;  // 0x0(0x14)
	struct FMatchPhase PreviousPhase;  // 0x14(0x14)

}; 
// Function EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C.HandleScoreEarned
// Size: 0x20(Inherited: 0x0) 
struct FHandleScoreEarned
{
	int32_t Money;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Reason;  // 0x8(0x18)

}; 
