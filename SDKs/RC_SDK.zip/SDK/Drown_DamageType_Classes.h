#pragma once 
#include <Drown_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass Drown_DamageType.Drown_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UDrown_DamageType_C : public UMaster_DamageType_C
{

}; 



