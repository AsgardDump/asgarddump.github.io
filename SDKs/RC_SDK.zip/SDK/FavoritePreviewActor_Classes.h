#pragma once 
#include <FavoritePreviewActor_Structs.h>
 
 
 
// BlueprintGeneratedClass FavoritePreviewActor.FavoritePreviewActor_C
// Size: 0x5D0(Inherited: 0x5C8) 
struct AFavoritePreviewActor_C : public AKSJobSelectPreviewActor_Lobby
{
	struct UFavoritePreviewLoadoutComponent* FavoritePreviewLoadout;  // 0x5C8(0x8)

}; 



