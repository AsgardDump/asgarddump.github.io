#pragma once 
#include <EventTracker_TripleThreatChallenge_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C
// Size: 0x1E8(Inherited: 0x1C0) 
struct UEventTracker_TripleThreatChallenge_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	struct TArray<int32_t> ItemIds;  // 0x1C8(0x10)
	struct TArray<int32_t> LootTableItemIds;  // 0x1D8(0x10)

	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.IsWinningTeam
	void HandleTrackerInitialized(); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_TripleThreatChallenge(int32_t EntryPoint); // Function EventTracker_TripleThreatChallenge.EventTracker_TripleThreatChallenge_C.ExecuteUbergraph_EventTracker_TripleThreatChallenge
}; 



