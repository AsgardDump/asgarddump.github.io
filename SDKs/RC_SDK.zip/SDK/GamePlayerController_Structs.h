#pragma once 
#include "SDK.h" 
 
 
// Function GamePlayerController.GamePlayerController_C.ExecuteUbergraph_GamePlayerController
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_GamePlayerController
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)

}; 
// Function GamePlayerController.GamePlayerController_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
