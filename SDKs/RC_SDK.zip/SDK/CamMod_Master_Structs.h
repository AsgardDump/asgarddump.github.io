#pragma once 
#include "SDK.h" 
 
 
// Function CamMod_Master.CamMod_Master_C.BlueprintModifyCamera
// Size: 0x5C(Inherited: 0x3C) 
struct FBlueprintModifyCamera : public FBlueprintModifyCamera
{
	float DeltaTime;  // 0x0(0x4)
	struct FVector ViewLocation;  // 0x4(0xC)
	struct FRotator ViewRotation;  // 0x10(0xC)
	float FOV;  // 0x1C(0x4)
	struct FVector NewViewLocation;  // 0x20(0xC)
	struct FRotator NewViewRotation;  // 0x2C(0xC)
	float NewFOV;  // 0x38(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_ShouldModifyCamera_bSuccess : 1;  // 0x3C(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x40(0x4)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x50(0xC)

}; 
// Function CamMod_Master.CamMod_Master_C.GetKSCharacterData
// Size: 0x89(Inherited: 0x0) 
struct FGetKSCharacterData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AKSCharacter* KSCharacter;  // 0x8(0x8)
	struct UKSCharacterMovementComponent* MovementComponent;  // 0x10(0x8)
	struct AKSCameraManager_C* Camera Manager;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AKSCameraManager_C* OutKSCameraManager;  // 0x28(0x8)
	struct UKSCharacterMovementComponent* OutKSCharMoveComp;  // 0x30(0x8)
	struct AKSCharacter* OutKSCharacter;  // 0x38(0x8)
	struct AActor* CallFunc_GetViewTarget_ReturnValue;  // 0x40(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UKSCharacterMovementComponent* K2Node_DynamicCast_AsKSCharacter_Movement_Component;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x68(0x8)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct AKSCameraManager_C* K2Node_DynamicCast_AsKSCamera_Manager;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x88(0x1)

}; 
// Function CamMod_Master.CamMod_Master_C.UpdateValues
// Size: 0x1C(Inherited: 0x0) 
struct FUpdateValues
{
	struct FVector InLocation;  // 0x0(0xC)
	struct FRotator InRotation;  // 0xC(0xC)
	float InFOV;  // 0x18(0x4)

}; 
// Function CamMod_Master.CamMod_Master_C.ShouldModifyCamera
// Size: 0x20(Inherited: 0x0) 
struct FShouldModifyCamera
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSuccess : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_GetKSCharacterData_Success : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct AKSCharacter* CallFunc_GetKSCharacterData_KSCharacter;  // 0x8(0x8)
	struct UKSCharacterMovementComponent* CallFunc_GetKSCharacterData_MovementComponent;  // 0x10(0x8)
	struct AKSCameraManager_C* CallFunc_GetKSCharacterData_Camera_Manager;  // 0x18(0x8)

}; 
