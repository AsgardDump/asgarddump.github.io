#pragma once 
#include "SDK.h" 
 
 
// Function BP_GameInstance.BP_GameInstance_C.ExecuteUbergraph_BP_GameInstance
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GameInstance
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString K2Node_Event_MapName;  // 0x8(0x10)

}; 
// Function BP_GameInstance.BP_GameInstance_C.BeginLoading
// Size: 0x10(Inherited: 0x10) 
struct FBeginLoading : public FBeginLoading
{
	struct FString mapName;  // 0x0(0x10)

}; 
