#pragma once 
#include <EventTracker_MobileRogueXp_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C
// Size: 0x209(Inherited: 0x1C0) 
struct UEventTracker_MobileRogueXp_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t JobItemId;  // 0x1C8(0x4)
	float PremiumBoostMultiplier;  // 0x1CC(0x4)
	float WinMultiplier;  // 0x1D0(0x4)
	char pad_468_1 : 7;  // 0x1D4(0x1)
	bool IsSelected : 1;  // 0x1D4(0x1)
	char pad_469[3];  // 0x1D5(0x3)
	float TimeSpentInJob;  // 0x1D8(0x4)
	char pad_476[4];  // 0x1DC(0x4)
	struct FDateTime LastUpdateTime;  // 0x1E0(0x8)
	float BaseProgress;  // 0x1E8(0x4)
	float AccumulatedProgress;  // 0x1EC(0x4)
	struct AKSPlayerState* PlayerState;  // 0x1F0(0x8)
	struct FString BonusKey;  // 0x1F8(0x10)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool MatchStarted : 1;  // 0x208(0x1)

	void HandleJobChanged(); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.HandleJobChanged
	void SetJobItemId(); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.SetJobItemId
	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.ProcessEventBonuses
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.ProcessWinBonus
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.ProcessQueueBonus
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.ProcessBoosterBonuses
	void ComputeBaseProgress(float& OutProgress); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.ComputeBaseProgress
	void AccumulateTimeSpent(); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.AccumulateTimeSpent
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.IsWinningTeam
	void AwardRogueXp(); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.AwardRogueXp
	void UpdateJobSelected(); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.UpdateJobSelected
	void HandleMatchEnded(); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.HandleMatchEnded
	void HandlePhaseChanged(struct FMatchPhase PreviousPhase, struct FMatchPhase NewPhase); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.HandlePhaseChanged
	void HandleTrackerInitialized(); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.HandleTrackerInitialized
	void ExecuteUbergraph_EventTracker_MobileRogueXp(int32_t EntryPoint); // Function EventTracker_MobileRogueXp.EventTracker_MobileRogueXp_C.ExecuteUbergraph_EventTracker_MobileRogueXp
}; 



