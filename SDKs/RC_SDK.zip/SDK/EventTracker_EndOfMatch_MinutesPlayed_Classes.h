#pragma once 
#include <EventTracker_EndOfMatch_MinutesPlayed_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_EndOfMatch_MinutesPlayed.EventTracker_EndOfMatch_MinutesPlayed_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_EndOfMatch_MinutesPlayed_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_EndOfMatch_MinutesPlayed.EventTracker_EndOfMatch_MinutesPlayed_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_EndOfMatch_MinutesPlayed.EventTracker_EndOfMatch_MinutesPlayed_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_EndOfMatch_MinutesPlayed(int32_t EntryPoint); // Function EventTracker_EndOfMatch_MinutesPlayed.EventTracker_EndOfMatch_MinutesPlayed_C.ExecuteUbergraph_EventTracker_EndOfMatch_MinutesPlayed
}; 



