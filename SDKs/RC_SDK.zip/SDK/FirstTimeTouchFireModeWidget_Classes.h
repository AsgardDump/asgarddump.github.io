#pragma once 
#include <FirstTimeTouchFireModeWidget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C
// Size: 0x530(Inherited: 0x4C8) 
struct UFirstTimeTouchFireModeWidget_C : public UPUMG_Widget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C8(0x8)
	struct UImage* Decro;  // 0x4D0(0x8)
	struct UImage* Image_159;  // 0x4D8(0x8)
	struct UPUMG_UnsafeZone* PUMG_UnsafeZone_1;  // 0x4E0(0x8)
	struct UOverlay* SettingsWidgetContainer;  // 0x4E8(0x8)
	struct UTextBlock* Title;  // 0x4F0(0x8)
	struct UTextBlock* Title_3;  // 0x4F8(0x8)
	struct UWBP_StandardButtonLarge_C* WBP_StandardButtonLarge;  // 0x500(0x8)
	struct FKSSettingsWidgetConfig SettingsWidgetConfig;  // 0x508(0x10)
	struct UKSSettingsInfoBase* SettingsInfo;  // 0x518(0x8)
	struct UKSSettingsWidget* SettingsWidget;  // 0x520(0x8)
	struct UAkAudioEvent* ShowFirstTimeLanguageSFX;  // 0x528(0x8)

	void InitializeWidget(struct APUMG_HUD* HUD); // Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.InitializeWidget
	void OnShown(); // Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.OnShown
	void PreConstruct(bool IsDesignTime); // Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.PreConstruct
	void SaveSetting(); // Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.SaveSetting
	void InitializeWidgetNavigation(); // Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.InitializeWidgetNavigation
	void BndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature(struct UWidget* Widget); // Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.BndEvt__WBP_StandardButtonLarge_K2Node_ComponentBoundEvent_0_OnClicked__DelegateSignature
	void ExecuteUbergraph_FirstTimeTouchFireModeWidget(int32_t EntryPoint); // Function FirstTimeTouchFireModeWidget.FirstTimeTouchFireModeWidget_C.ExecuteUbergraph_FirstTimeTouchFireModeWidget
}; 



