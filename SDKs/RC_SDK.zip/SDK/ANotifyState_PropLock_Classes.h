#pragma once 
#include <ANotifyState_PropLock_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_PropLock.ANotifyState_PropLock_C
// Size: 0x34(Inherited: 0x30) 
struct UANotifyState_PropLock_C : public UAnimNotifyState
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool HolsterLock : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Left Holster Lock : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool No Prop Lock While Moving : 1;  // 0x32(0x1)
	char ESpeed Prop Lock Blend Speed;  // 0x33(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_PropLock.ANotifyState_PropLock_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_PropLock.ANotifyState_PropLock_C.Received_NotifyBegin
}; 



