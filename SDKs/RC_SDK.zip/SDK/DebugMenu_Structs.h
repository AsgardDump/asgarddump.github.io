#pragma once 
#include "SDK.h" 
 
 
// Function DebugMenu.DebugMenu_C.AddBaseCommandHeader
// Size: 0x30(Inherited: 0x0) 
struct FAddBaseCommandHeader
{
	struct FString BaseCommand;  // 0x0(0x10)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UDebugBaseCommandHeader_C* CallFunc_Create_ReturnValue;  // 0x20(0x8)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0x28(0x8)

}; 
// Function DebugMenu.DebugMenu_C.ExecuteUbergraph_DebugMenu
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_DebugMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey CallFunc_GetGamepadConfirmButton_ReturnValue;  // 0x8(0x18)
	struct FKey CallFunc_GetGamepadCancelButton_ReturnValue;  // 0x20(0x18)
	struct UTexture2D* CallFunc_GetIconForGamepadButton_Icon;  // 0x38(0x8)
	struct UTexture2D* CallFunc_GetIconForGamepadButton_Icon_2;  // 0x40(0x8)

}; 
// Function DebugMenu.DebugMenu_C.CommandSelected
// Size: 0x5C(Inherited: 0x0) 
struct FCommandSelected
{
	struct FDebugMenuCommandInfo Command;  // 0x0(0x18)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool K2Node_SwitchString_CmpSuccess : 1;  // 0x1D(0x1)
	char pad_30[2];  // 0x1E(0x2)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x20(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x38(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x50(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x58(0x4)

}; 
// Function DebugMenu.DebugMenu_C.PopulateList
// Size: 0x43(Inherited: 0x0) 
struct FPopulateList
{
	int32_t Depth;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FDebugMenuCommandInfo> CallFunc_MakeBoolSubmenu_Array;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x1C(0x4)
	struct TArray<struct FDebugMenuCommandInfo> CallFunc_GetSortedBaseDebugCommands_SortedCommands;  // 0x20(0x10)
	struct TArray<struct FDebugMenuCommandInfo> CallFunc_GetSubmenu_Submenu;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_GetSubmenu_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x42(0x1)

}; 
// Function DebugMenu.DebugMenu_C.InternalPopulate
// Size: 0x99(Inherited: 0x0) 
struct FInternalPopulate
{
	struct TArray<struct FDebugMenuCommandInfo> Commands;  // 0x0(0x10)
	struct TArray<struct UDebugMenuItem_C*> DebugItems;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	struct FDebugMenuCommandInfo CallFunc_Array_Get_Item;  // 0x28(0x18)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x40(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4C(0x4)
	struct UWidget* CallFunc_SetFocusToThis_ReturnValue;  // 0x50(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x58(0x10)
	struct UDebugMenuItem_C* CallFunc_Array_Get_Item_2;  // 0x68(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x70(0x8)
	struct UDebugMenuItem_C* CallFunc_Create_ReturnValue;  // 0x78(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x88(0x8)
	struct UScrollBoxSlot* K2Node_DynamicCast_AsScroll_Box_Slot;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x98(0x1)

}; 
// Function DebugMenu.DebugMenu_C.MakeBoolSubmenu
// Size: 0x50(Inherited: 0x0) 
struct FMakeBoolSubmenu
{
	struct TArray<struct FDebugMenuCommandInfo> Array;  // 0x0(0x10)
	struct FDebugMenuCommandInfo K2Node_MakeStruct_DebugMenuCommandInfo;  // 0x10(0x18)
	struct FDebugMenuCommandInfo K2Node_MakeStruct_DebugMenuCommandInfo_2;  // 0x28(0x18)
	struct TArray<struct FDebugMenuCommandInfo> K2Node_MakeArray_Array;  // 0x40(0x10)

}; 
// Function DebugMenu.DebugMenu_C.GetParamTypeForSubCommand
// Size: 0x12(Inherited: 0x18) 
struct FGetParamTypeForSubCommand : public FGetParamTypeForSubCommand
{
	struct FString BaseCommandString;  // 0x0(0x10)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool K2Node_SwitchString_CmpSuccess : 1;  // 0x11(0x1)

}; 
// Function DebugMenu.DebugMenu_C.NavigateBack
// Size: 0x1(Inherited: 0x1) 
struct FNavigateBack : public FNavigateBack
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DebugMenu.DebugMenu_C.CloseDebugMenu
// Size: 0x1(Inherited: 0x0) 
struct FCloseDebugMenu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_RemoveViewRoute_ReturnValue : 1;  // 0x0(0x1)

}; 
