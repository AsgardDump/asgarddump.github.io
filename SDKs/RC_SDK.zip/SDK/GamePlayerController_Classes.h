#pragma once 
#include <GamePlayerController_Structs.h>
 
 
 
// BlueprintGeneratedClass GamePlayerController.GamePlayerController_C
// Size: 0x1020(Inherited: 0x1018) 
struct AGamePlayerController_C : public AGamePlayerControllerNoHUD_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1018(0x8)

	void ReceiveBeginPlay(); // Function GamePlayerController.GamePlayerController_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function GamePlayerController.GamePlayerController_C.ReceiveTick
	void ExecuteUbergraph_GamePlayerController(int32_t EntryPoint); // Function GamePlayerController.GamePlayerController_C.ExecuteUbergraph_GamePlayerController
}; 



