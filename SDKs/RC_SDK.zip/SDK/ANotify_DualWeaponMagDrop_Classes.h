#pragma once 
#include <ANotify_DualWeaponMagDrop_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotify_DualWeaponMagDrop.ANotify_DualWeaponMagDrop_C
// Size: 0x3C(Inherited: 0x38) 
struct UANotify_DualWeaponMagDrop_C : public UAnimNotify
{
	int32_t WeaponMeshToDropFrom;  // 0x38(0x4)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotify_DualWeaponMagDrop.ANotify_DualWeaponMagDrop_C.Received_Notify
}; 



