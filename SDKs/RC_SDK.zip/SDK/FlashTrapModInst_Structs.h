#pragma once 
#include "SDK.h" 
 
 
// Function FlashTrapModInst.FlashTrapModInst_C.Init_RemoteThrow
// Size: 0x8(Inherited: 0x0) 
struct FInit_RemoteThrow
{
	struct AKSWeapon_RemoteThrow* RemoteThrow;  // 0x0(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.On Detonator Spawned
// Size: 0x8(Inherited: 0x0) 
struct FOn Detonator Spawned
{
	struct AKSWeapon_RemoteTrigger* Detonator;  // 0x0(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.OnWeaponStateChanged
// Size: 0xA(Inherited: 0x10) 
struct FOnWeaponStateChanged : public FOnWeaponStateChanged
{
	struct AKSWeapon* Weapon;  // 0x0(0x8)
	uint8_t  OldState;  // 0x8(0x1)
	uint8_t  NewState;  // 0x9(0x1)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.On Reclaimed
// Size: 0x8(Inherited: 0x0) 
struct FOn Reclaimed
{
	struct AKSProjectile* Reclaimed;  // 0x0(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.ExecuteUbergraph_FlashTrapModInst
// Size: 0x1B1(Inherited: 0x0) 
struct FExecuteUbergraph_FlashTrapModInst
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x40(0x10)
	struct AKSWeapon_RemoteThrow* K2Node_DynamicCast_AsKSWeapon_Remote_Throw;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct AKSWeapon* K2Node_Event_Weapon;  // 0x60(0x8)
	uint8_t  K2Node_Event_OldState;  // 0x68(0x1)
	uint8_t  K2Node_Event_NewState;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x6A(0x1)
	char pad_107_1 : 7;  // 0x6B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x6B(0x1)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0x6D(0x1)
	char pad_110[2];  // 0x6E(0x2)
	struct AKSWeapon_RemoteThrow* K2Node_DynamicCast_AsKSWeapon_Remote_Throw_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct AKSProjectile_Grenade* K2Node_CustomEvent_Grenade;  // 0x80(0x8)
	struct AKSProjectile_RemoteTrigger* K2Node_DynamicCast_AsKSProjectile_Remote_Trigger;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_TryToCancel_ReturnValue : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_TryToCancel_ReturnValue_2 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct AKSWeapon_RemoteThrow* K2Node_CustomEvent_RemoteThrow_2;  // 0xA8(0x8)
	struct AKSWeapon* K2Node_DynamicCast_AsKSWeapon;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_StartFire_ReturnValue : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xBA(0x1)
	char pad_187[5];  // 0xBB(0x5)
	struct AKSWeapon_RemoteTrigger* K2Node_CustomEvent_Detonator_2;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0xCA(0x1)
	char pad_203_1 : 7;  // 0xCB(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0xCB(0x1)
	char pad_204[4];  // 0xCC(0x4)
	struct AKSWeapon_RemoteTrigger* K2Node_CustomEvent_Detonator;  // 0xD0(0x8)
	struct AKSWeapon_RemoteThrow* K2Node_CustomEvent_RemoteThrow;  // 0xD8(0x8)
	struct AKSWeapon_RemoteTrigger* K2Node_DynamicCast_AsKSWeapon_Remote_Trigger;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct TArray<struct AKSProjectile_RemoteTrigger*> CallFunc_GetAttachedCharges_OutCharges;  // 0xF0(0x10)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_TryToCancel_ReturnValue_3 : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct AKSProjectile_RemoteTrigger* CallFunc_Array_Get_Item;  // 0x108(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x110(0x4)
	char pad_276_1 : 7;  // 0x114(0x1)
	bool CallFunc_IsDetonatable_ReturnValue : 1;  // 0x114(0x1)
	char pad_277[3];  // 0x115(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x118(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_TryToCancel_ReturnValue_4 : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x13C(0x4)
	struct AKSWeapon_RemoteThrow* K2Node_DynamicCast_AsKSWeapon_Remote_Throw_3;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x149(0x1)
	char pad_330[2];  // 0x14A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14C(0x4)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct AKSProjectile* K2Node_CustomEvent_Reclaimed;  // 0x158(0x8)
	struct UKSPlayerMod* CallFunc_GetModAsset_ReturnValue;  // 0x160(0x8)
	struct UKSPlayerMod_GiveWeaponConfig* K2Node_DynamicCast_AsKSPlayer_Mod_Give_Weapon_Config;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x170(0x1)
	char pad_369[3];  // 0x171(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x174(0x10)
	float CallFunc_GetReclaimCharge_ReturnValue;  // 0x184(0x4)
	struct AKSWeapon* K2Node_DynamicCast_AsKSWeapon_2;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct AKSCharacter* CallFunc_GetCharacterOwner_ReturnValue;  // 0x198(0x8)
	struct AKSCharacterFoundation* K2Node_CustomEvent_KillerCharacter;  // 0x1A0(0x8)
	struct AKSCharacterFoundation* K2Node_CustomEvent_KilledCharacter;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1B0(0x1)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.On Character Died
// Size: 0x10(Inherited: 0x0) 
struct FOn Character Died
{
	struct AKSCharacterFoundation* KillerCharacter;  // 0x0(0x8)
	struct AKSCharacterFoundation* KilledCharacter;  // 0x8(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.On Remote Throw Spawned
// Size: 0x8(Inherited: 0x0) 
struct FOn Remote Throw Spawned
{
	struct AKSWeapon_RemoteThrow* RemoteThrow;  // 0x0(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.Init_Detonator
// Size: 0x8(Inherited: 0x0) 
struct FInit_Detonator
{
	struct AKSWeapon_RemoteTrigger* Detonator;  // 0x0(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.OnGrenadeDestroyed
// Size: 0x8(Inherited: 0x0) 
struct FOnGrenadeDestroyed
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.OnGrenadeSpawned
// Size: 0x8(Inherited: 0x0) 
struct FOnGrenadeSpawned
{
	struct AKSProjectile_Grenade* Grenade;  // 0x0(0x8)

}; 
// Function FlashTrapModInst.FlashTrapModInst_C.IsInActivatableState
// Size: 0x2D(Inherited: 0x2) 
struct FIsInActivatableState : public FIsInActivatableState
{
	uint8_t  OutAbilityFailureType;  // 0x0(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)
	uint8_t  CallFunc_IsInActivatableState_OutAbilityFailureType;  // 0x2(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsInActivatableState_ReturnValue : 1;  // 0x3(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct AKSWeapon_RemoteThrow* K2Node_DynamicCast_AsKSWeapon_Remote_Throw;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct AKSProjectile_RemoteTrigger*> CallFunc_GetAttachedCharges_OutCharges;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x2C(0x1)

}; 
