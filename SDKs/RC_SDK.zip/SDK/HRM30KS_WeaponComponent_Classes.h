#pragma once 
#include <HRM30KS_WeaponComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass HRM30KS_WeaponComponent.HRM30KS_WeaponComponent_C
// Size: 0x1560(Inherited: 0x1560) 
struct UHRM30KS_WeaponComponent_C : public UMasterRifle_WeaponComponent_C
{

}; 



