#pragma once 
#include <Cam_Barricade_Base_Deploy_Structs.h>
 
 
 
// BlueprintGeneratedClass Cam_Barricade_Base_Deploy.Cam_Barricade_Base_Deploy_C
// Size: 0x160(Inherited: 0x160) 
struct UCam_Barricade_Base_Deploy_C : public UCameraShake
{

}; 



