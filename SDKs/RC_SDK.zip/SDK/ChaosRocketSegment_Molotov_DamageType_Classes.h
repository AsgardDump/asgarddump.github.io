#pragma once 
#include <ChaosRocketSegment_Molotov_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass ChaosRocketSegment_Molotov_DamageType.ChaosRocketSegment_Molotov_DamageType_C
// Size: 0x148(Inherited: 0x148) 
struct UChaosRocketSegment_Molotov_DamageType_C : public UMasterFire_DamageType_C
{

}; 



