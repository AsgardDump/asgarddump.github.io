#pragma once 
#include <BombActivator_ABP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BombActivator_ABP.BombActivator_ABP_C
// Size: 0x7D3(Inherited: 0x270) 
struct UBombActivator_ABP_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x270(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x278(0x40)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2B8(0x58)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x310(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x348(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x380(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B8(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x3F0(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0x478(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x4B8(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x540(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x580(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x608(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x648(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x6D0(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x710(0xC0)
	char pad_2000_1 : 7;  // 0x7D0(0x1)
	bool BombDisarming : 1;  // 0x7D0(0x1)
	char pad_2001_1 : 7;  // 0x7D1(0x1)
	bool BombPlanted : 1;  // 0x7D1(0x1)
	char pad_2002_1 : 7;  // 0x7D2(0x1)
	bool NewVar_1 : 1;  // 0x7D2(0x1)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BombActivator_ABP.BombActivator_ABP_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BombActivator_ABP_AnimGraphNode_TransitionResult_BAB1EF554FE8E3E61CD2458A88DC7339(); // Function BombActivator_ABP.BombActivator_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_BombActivator_ABP_AnimGraphNode_TransitionResult_BAB1EF554FE8E3E61CD2458A88DC7339
	void AnimNotify_PlayBombPlantedSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_PlayBombPlantedSFX
	void AnimNotify_PlayBombLoopSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_PlayBombLoopSFX
	void AnimNotify_PlayBombDisarmingSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_PlayBombDisarmingSFX
	void AnimNotify_StopBombPlantedSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_StopBombPlantedSFX
	void AnimNotify_StopBombLoopSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_StopBombLoopSFX
	void AnimNotify_StopBombDisarmingSFX(); // Function BombActivator_ABP.BombActivator_ABP_C.AnimNotify_StopBombDisarmingSFX
	void ExecuteUbergraph_BombActivator_ABP(int32_t EntryPoint); // Function BombActivator_ABP.BombActivator_ABP_C.ExecuteUbergraph_BombActivator_ABP
}; 



