#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_SetTimestampForAction.ActivityBehavior_SetTimestampForAction_C.ExecuteUbergraph_ActivityBehavior_SetTimestampForAction
// Size: 0x34(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_SetTimestampForAction
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString CallFunc_Conv_ObjectToString_ReturnValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x2C(0x8)

}; 
