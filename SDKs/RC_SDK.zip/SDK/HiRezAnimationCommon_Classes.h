#pragma once 
#include <HiRezAnimationCommon_Structs.h>
 
 
 
// Class HiRezAnimationCommon.HiRezAnimationStatics
// Size: 0x28(Inherited: 0x28) 
struct UHiRezAnimationStatics : public UBlueprintFunctionLibrary
{

	float FindPositionFromDistanceCurve(struct FName& DistanceCurveName, float Distance, struct UAnimSequenceBase* InAnimSequence); // Function HiRezAnimationCommon.HiRezAnimationStatics.FindPositionFromDistanceCurve
}; 



// Class HiRezAnimationCommon.HRA_AnimNotify_PlayCameraAnim
// Size: 0x58(Inherited: 0x38) 
struct UHRA_AnimNotify_PlayCameraAnim : public UAnimNotify
{
	UCameraShake* CameraShake;  // 0x38(0x8)
	float Scale;  // 0x40(0x4)
	char ECameraAnimPlaySpace Space;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FRotator CustomPlaySpace;  // 0x48(0xC)
	char pad_84[4];  // 0x54(0x4)

}; 



