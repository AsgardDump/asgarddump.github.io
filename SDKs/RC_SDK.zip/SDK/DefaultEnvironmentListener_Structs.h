#pragma once 
#include "SDK.h" 
 
 
// Function DefaultEnvironmentListener.DefaultEnvironmentListener_C.ExecuteUbergraph_DefaultEnvironmentListener
// Size: 0x144(Inherited: 0x0) 
struct FExecuteUbergraph_DefaultEnvironmentListener
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FName CallFunc_GetCurrentEnvironment_ReturnValue;  // 0x8(0x8)
	struct FName K2Node_Event_OldEnvironmentTag;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_CustomEvent_Print_to_Screen : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool K2Node_CustomEvent_Print_to_Log : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	struct FLinearColor K2Node_CustomEvent_Text_Color;  // 0x1C(0x10)
	float K2Node_CustomEvent_Duration;  // 0x2C(0x4)
	struct FName CallFunc_GetCurrentEnvironment_ReturnValue_2;  // 0x30(0x8)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x38(0x18)
	struct FText CallFunc_Conv_NameToText_ReturnValue_2;  // 0x50(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x68(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xE8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xF8(0x18)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x110(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x120(0x10)
	struct FName CallFunc_Map_Find_Value;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	struct FName K2Node_Select_Default;  // 0x13C(0x8)

}; 
// Function DefaultEnvironmentListener.DefaultEnvironmentListener_C.Print State
// Size: 0x18(Inherited: 0x0) 
struct FPrint State
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Print to Screen : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Print to Log : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FLinearColor Text Color;  // 0x4(0x10)
	float Duration;  // 0x14(0x4)

}; 
// Function DefaultEnvironmentListener.DefaultEnvironmentListener_C.OnEnvironmentChanged
// Size: 0x8(Inherited: 0x8) 
struct FOnEnvironmentChanged : public FOnEnvironmentChanged
{
	struct FName OldEnvironmentTag;  // 0x0(0x8)

}; 
