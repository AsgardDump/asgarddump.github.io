#pragma once 
#include "SDK.h" 
 
 
// Function DropdownList.DropdownList_C.OnHoverPreview__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnHoverPreview__DelegateSignature
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function DropdownList.DropdownList_C.OnSelection__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnSelection__DelegateSignature
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Text;  // 0x8(0x18)

}; 
// Function DropdownList.DropdownList_C.HandleOnHover
// Size: 0xC(Inherited: 0x0) 
struct FHandleOnHover
{
	struct UWidget* Widget;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)

}; 
// Function DropdownList.DropdownList_C.ExecuteUbergraph_DropdownList
// Size: 0xC9(Inherited: 0x0) 
struct FExecuteUbergraph_DropdownList
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FText CallFunc_Array_Get_Item;  // 0x18(0x18)
	int32_t K2Node_CustomEvent_Index_3;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FText K2Node_CustomEvent_Text;  // 0x38(0x18)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x50(0x8)
	struct UDropdownEntry_C* CallFunc_Create_ReturnValue;  // 0x58(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x60(0x8)
	struct UScrollBoxSlot* K2Node_DynamicCast_AsScroll_Box_Slot;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x74(0x4)
	struct UDropdownEntry_C* CallFunc_Array_Get_Item_2;  // 0x78(0x8)
	struct UWidget* K2Node_CustomEvent_Widget;  // 0x80(0x8)
	int32_t K2Node_CustomEvent_Index_2;  // 0x88(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8C(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x9C(0x10)
	int32_t K2Node_CustomEvent_Index;  // 0xAC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct UDropdownEntry_C* CallFunc_Array_Get_Item_3;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC1(0x1)
	char pad_194[2];  // 0xC2(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xC8(0x1)

}; 
// Function DropdownList.DropdownList_C.SetSelectedEntryByIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetSelectedEntryByIndex
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function DropdownList.DropdownList_C.Selection
// Size: 0x20(Inherited: 0x0) 
struct FSelection
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Text;  // 0x8(0x18)

}; 
// Function DropdownList.DropdownList_C.NavigateBack
// Size: 0x1(Inherited: 0x1) 
struct FNavigateBack : public FNavigateBack
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DropdownList.DropdownList_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
