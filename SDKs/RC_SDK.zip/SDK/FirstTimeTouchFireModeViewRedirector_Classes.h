#pragma once 
#include <FirstTimeTouchFireModeViewRedirector_Structs.h>
 
 
 
// BlueprintGeneratedClass FirstTimeTouchFireModeViewRedirector.FirstTimeTouchFireModeViewRedirector_C
// Size: 0x30(Inherited: 0x30) 
struct UFirstTimeTouchFireModeViewRedirector_C : public UKSViewRedirector_LocalSetting
{

	bool DoesLocalSettingApply(struct APUMG_HUD* HUD); // Function FirstTimeTouchFireModeViewRedirector.FirstTimeTouchFireModeViewRedirector_C.DoesLocalSettingApply
}; 



