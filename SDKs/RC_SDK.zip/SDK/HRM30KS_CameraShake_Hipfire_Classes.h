#pragma once 
#include <HRM30KS_CameraShake_Hipfire_Structs.h>
 
 
 
// BlueprintGeneratedClass HRM30KS_CameraShake_Hipfire.HRM30KS_CameraShake_Hipfire_C
// Size: 0x160(Inherited: 0x160) 
struct UHRM30KS_CameraShake_Hipfire_C : public UCameraShake
{

}; 



