#pragma once 
#include <FlashTrapModInst_Structs.h>
 
 
 
// BlueprintGeneratedClass FlashTrapModInst.FlashTrapModInst_C
// Size: 0x549(Inherited: 0x540) 
struct UFlashTrapModInst_C : public UKSModInst_GiveWeaponOnActivation
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x540(0x8)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool HasDetonator : 1;  // 0x548(0x1)

	bool IsInActivatableState(uint8_t & OutAbilityFailureType); // Function FlashTrapModInst.FlashTrapModInst_C.IsInActivatableState
	void ReceiveBeginPlay(); // Function FlashTrapModInst.FlashTrapModInst_C.ReceiveBeginPlay
	void OnNewGivenItem(); // Function FlashTrapModInst.FlashTrapModInst_C.OnNewGivenItem
	void OnWeaponStateChanged(struct AKSWeapon* Weapon, uint8_t  OldState, uint8_t  NewState); // Function FlashTrapModInst.FlashTrapModInst_C.OnWeaponStateChanged
	void BeginActivation(); // Function FlashTrapModInst.FlashTrapModInst_C.BeginActivation
	void OnGrenadeSpawned(struct AKSProjectile_Grenade* Grenade); // Function FlashTrapModInst.FlashTrapModInst_C.OnGrenadeSpawned
	void OnGrenadeDestroyed(struct AActor* DestroyedActor); // Function FlashTrapModInst.FlashTrapModInst_C.OnGrenadeDestroyed
	void Init_RemoteThrow(struct AKSWeapon_RemoteThrow* RemoteThrow); // Function FlashTrapModInst.FlashTrapModInst_C.Init_RemoteThrow
	void Init_Detonator(struct AKSWeapon_RemoteTrigger* Detonator); // Function FlashTrapModInst.FlashTrapModInst_C.Init_Detonator
	void On Detonator Spawned(struct AKSWeapon_RemoteTrigger* Detonator); // Function FlashTrapModInst.FlashTrapModInst_C.On Detonator Spawned
	void On Remote Throw Spawned(struct AKSWeapon_RemoteThrow* RemoteThrow); // Function FlashTrapModInst.FlashTrapModInst_C.On Remote Throw Spawned
	void FiredOnAuthority(); // Function FlashTrapModInst.FlashTrapModInst_C.FiredOnAuthority
	void On Reclaimed(struct AKSProjectile* Reclaimed); // Function FlashTrapModInst.FlashTrapModInst_C.On Reclaimed
	void OnAbilityReleased(); // Function FlashTrapModInst.FlashTrapModInst_C.OnAbilityReleased
	void OnNewCharacterFoundation(); // Function FlashTrapModInst.FlashTrapModInst_C.OnNewCharacterFoundation
	void On Character Died(struct AKSCharacterFoundation* KillerCharacter, struct AKSCharacterFoundation* KilledCharacter); // Function FlashTrapModInst.FlashTrapModInst_C.On Character Died
	void ExecuteUbergraph_FlashTrapModInst(int32_t EntryPoint); // Function FlashTrapModInst.FlashTrapModInst_C.ExecuteUbergraph_FlashTrapModInst
}; 



