#pragma once 
#include <EventTracker_TutorialProgress_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_TutorialProgress.EventTracker_TutorialProgress_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_TutorialProgress_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.HandleTrackerInitialized
	void TutorialComplete(); // Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.TutorialComplete
	void ExecuteUbergraph_EventTracker_TutorialProgress(int32_t EntryPoint); // Function EventTracker_TutorialProgress.EventTracker_TutorialProgress_C.ExecuteUbergraph_EventTracker_TutorialProgress
}; 



