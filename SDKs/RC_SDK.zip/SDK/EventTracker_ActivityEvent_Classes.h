#pragma once 
#include <EventTracker_ActivityEvent_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_ActivityEvent.EventTracker_ActivityEvent_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_ActivityEvent_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_ActivityEvent.EventTracker_ActivityEvent_C.HandleTrackerInitialized
	void HandleActivityEventTriggered(struct FGameplayTag ActivityEventType); // Function EventTracker_ActivityEvent.EventTracker_ActivityEvent_C.HandleActivityEventTriggered
	void ExecuteUbergraph_EventTracker_ActivityEvent(int32_t EntryPoint); // Function EventTracker_ActivityEvent.EventTracker_ActivityEvent_C.ExecuteUbergraph_EventTracker_ActivityEvent
}; 



