#pragma once 
#include <EventTracker_WeeklyContract_VarietyDowns_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C
// Size: 0x1E8(Inherited: 0x1C0) 
struct UEventTracker_WeeklyContract_VarietyDowns_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t PrimaryDowns;  // 0x1C8(0x4)
	int32_t SecondaryDowns;  // 0x1CC(0x4)
	int32_t GadgetDowns;  // 0x1D0(0x4)
	int32_t AbilityDowns;  // 0x1D4(0x4)
	struct TArray<struct UKSActivityRewardCondition*> AbilityRewardConditions;  // 0x1D8(0x10)

	void CheckAbility(struct FCombatEventInfo DamageInfo); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckAbility
	void CheckGadget(struct UKSWeaponAsset* WeaponAsset); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckGadget
	void CheckSecondary(struct UKSWeaponAsset* WeaponAsset); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckSecondary
	void CheckPrimary(struct UKSWeaponAsset* WeaponAsset); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.CheckPrimary
	void HandleTrackerInitialized(); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.HandleTrackerInitialized
	void OwnedPawnInstigateDamage(struct FCombatEventInfo& DamageInfo); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.OwnedPawnInstigateDamage
	void MatchHasEnded_Event(); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_WeeklyContract_VarietyDowns(int32_t EntryPoint); // Function EventTracker_WeeklyContract_VarietyDowns.EventTracker_WeeklyContract_VarietyDowns_C.ExecuteUbergraph_EventTracker_WeeklyContract_VarietyDowns
}; 



