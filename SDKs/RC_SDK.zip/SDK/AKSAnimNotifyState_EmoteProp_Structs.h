#pragma once 
#include "SDK.h" 
 
 
// Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.Received_NotifyEnd
// Size: 0x11(Inherited: 0x18) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)

}; 
// Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.OnSkeletalMeshComponentInitialized
// Size: 0xA8(Inherited: 0x20) 
struct FOnSkeletalMeshComponentInitialized : public FOnSkeletalMeshComponentInitialized
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	struct USkeletalMeshComponent* SpawnedSkeletalMeshComponent;  // 0x18(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x20(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x38(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x40(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	struct UAnimMontage* CallFunc_GetCurrentMontage_ReturnValue;  // 0x50(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x58(0x4)
	float CallFunc_Montage_GetPosition_ReturnValue;  // 0x5C(0x4)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x60(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x64(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x68(0x4)
	float CallFunc_Montage_Play_ReturnValue;  // 0x6C(0x4)
	float CallFunc_Montage_Play_ReturnValue_2;  // 0x70(0x4)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x74(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x78(0x4)
	struct FSkeletalMaterial CallFunc_Array_Get_Item;  // 0x80(0x28)

}; 
// Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.OnStaticMeshComponentInitialized
// Size: 0x20(Inherited: 0x20) 
struct FOnStaticMeshComponentInitialized : public FOnStaticMeshComponentInitialized
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	struct UStaticMeshComponent* SpawnedStaticMeshComponent;  // 0x18(0x8)

}; 
// Function AKSAnimNotifyState_EmoteProp.AKSAnimNotifyState_EmoteProp_C.Received_NotifyBegin
// Size: 0x15(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)

}; 
