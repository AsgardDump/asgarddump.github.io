#pragma once 
#include "SDK.h" 
 
 
// Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.ExecuteUbergraph_GDT_RadarDart_ABP
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_GDT_RadarDart_ABP
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float K2Node_Event_DeltaTimeX;  // 0xC(0x4)

}; 
// Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.Set Weapon State
// Size: 0x17(Inherited: 0x0) 
struct FSet Weapon State
{
	struct UKSWeaponComponent* Owning Weapon Component;  // 0x0(0x8)
	uint8_t  Old State;  // 0x8(0x1)
	uint8_t  New State;  // 0x9(0x1)
	uint8_t  Temp_byte_Variable;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool Temp_bool_Variable : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool Temp_bool_Variable_9 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable_10 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool Temp_bool_Variable_11 : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool K2Node_Select_Default : 1;  // 0x16(0x1)

}; 
// Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
