#pragma once 
#include <HudEditor_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass HudEditor.HudEditor_C
// Size: 0x5B0(Inherited: 0x540) 
struct UHudEditor_C : public UKSHudEditor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x540(0x8)
	struct UButton* ApplyButton;  // 0x548(0x8)
	struct USizeBox* ApplyButtonSizeBox;  // 0x550(0x8)
	struct UBlocker_C* Blocker;  // 0x558(0x8)
	struct UGameTouchHUDWidget_C* GameTouchHUDWidget;  // 0x560(0x8)
	struct UPUMG_UnsafeZone* PUMG_UnsafeZone_2;  // 0x568(0x8)
	struct UButton* RevertButton;  // 0x570(0x8)
	struct USizeBox* RevertButtonSizeBox;  // 0x578(0x8)
	struct UWBP_TouchBackButton_C* WBP_TouchBackButton;  // 0x580(0x8)
	struct TArray<struct UUserWidget*> EditableWidgets;  // 0x588(0x10)
	struct UAkAudioEvent* BackSettingsMenuSFX;  // 0x598(0x8)
	struct UAkAudioEvent* RevertSettingsMenuSFX;  // 0x5A0(0x8)
	struct UAkAudioEvent* ApplySettingsMenuSFX;  // 0x5A8(0x8)

	void BndEvt__Button_192_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__Button_192_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__SaveHudEditableData_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__SaveHudEditableData_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void BndEvt__SaveHudEditableData_1_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__SaveHudEditableData_1_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature
	void BndEvt__SaveHudEditableData_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__SaveHudEditableData_K2Node_ComponentBoundEvent_3_OnButtonPressedEvent__DelegateSignature
	void BndEvt__ExitHudEditorButton_K2Node_ComponentBoundEvent_4_OnButtonPressedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__ExitHudEditorButton_K2Node_ComponentBoundEvent_4_OnButtonPressedEvent__DelegateSignature
	void BndEvt__RestoreDefaultHudEditableData_K2Node_ComponentBoundEvent_5_OnButtonPressedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__RestoreDefaultHudEditableData_K2Node_ComponentBoundEvent_5_OnButtonPressedEvent__DelegateSignature
	void InitializeWidget(struct APUMG_HUD* HUD); // Function HudEditor.HudEditor_C.InitializeWidget
	void OnBackButton(); // Function HudEditor.HudEditor_C.OnBackButton
	void OnApplyButton(); // Function HudEditor.HudEditor_C.OnApplyButton
	void OnRevertButton(); // Function HudEditor.HudEditor_C.OnRevertButton
	void OnHide(); // Function HudEditor.HudEditor_C.OnHide
	void OnShown(); // Function HudEditor.HudEditor_C.OnShown
	void BndEvt__RevertButton_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__RevertButton_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature
	void BndEvt__ApplyButton_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature(); // Function HudEditor.HudEditor_C.BndEvt__ApplyButton_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_HudEditor(int32_t EntryPoint); // Function HudEditor.HudEditor_C.ExecuteUbergraph_HudEditor
}; 



