#pragma once 
#include <HRM30KS_Drop_Structs.h>
 
 
 
// BlueprintGeneratedClass HRM30KS_Drop.HRM30KS_Drop_C
// Size: 0x860(Inherited: 0x860) 
struct AHRM30KS_Drop_C : public AMaster_WeaponDrop_C
{

}; 



