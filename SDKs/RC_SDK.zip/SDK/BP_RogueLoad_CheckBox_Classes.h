#pragma once 
#include <BP_RogueLoad_CheckBox_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RogueLoad_CheckBox.BP_RogueLoad_CheckBox_C
// Size: 0x260(Inherited: 0x220) 
struct ABP_RogueLoad_CheckBox_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* end;  // 0x228(0x8)
	struct USceneComponent* start;  // 0x230(0x8)
	struct UBoxComponent* Box;  // 0x238(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool hasHit : 1;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct TArray<char EObjectTypeQuery> objs;  // 0x250(0x10)

	void Trace(bool& Hit); // Function BP_RogueLoad_CheckBox.BP_RogueLoad_CheckBox_C.Trace
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_RogueLoad_CheckBox.BP_RogueLoad_CheckBox_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void TraceHit(); // Function BP_RogueLoad_CheckBox.BP_RogueLoad_CheckBox_C.TraceHit
	void ExecuteUbergraph_BP_RogueLoad_CheckBox(int32_t EntryPoint); // Function BP_RogueLoad_CheckBox.BP_RogueLoad_CheckBox_C.ExecuteUbergraph_BP_RogueLoad_CheckBox
}; 



