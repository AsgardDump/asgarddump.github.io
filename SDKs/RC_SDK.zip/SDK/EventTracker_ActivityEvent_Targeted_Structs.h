#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_ActivityEvent_Targeted.EventTracker_ActivityEvent_Targeted_C.ExecuteUbergraph_EventTracker_ActivityEvent_Targeted
// Size: 0x54(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_ActivityEvent_Targeted
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsTriggerConditionMet_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x28(0x8)
	struct FGameplayTag K2Node_CustomEvent_ActivityEventType;  // 0x30(0x8)
	struct AKSCharacterFoundation* K2Node_CustomEvent_TargetCharacter;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsActivityEventTriggerConditionMet_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsTargetConditionMet_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x53(0x1)

}; 
// Function EventTracker_ActivityEvent_Targeted.EventTracker_ActivityEvent_Targeted_C.HandleTargetedActivityEventTriggered
// Size: 0x10(Inherited: 0x0) 
struct FHandleTargetedActivityEventTriggered
{
	struct FGameplayTag ActivityEventType;  // 0x0(0x8)
	struct AKSCharacterFoundation* TargetCharacter;  // 0x8(0x8)

}; 
