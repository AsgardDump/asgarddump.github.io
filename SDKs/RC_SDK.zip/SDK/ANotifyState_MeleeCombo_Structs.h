#pragma once 
#include "SDK.h" 
 
 
// Function ANotifyState_MeleeCombo.ANotifyState_MeleeCombo_C.Received_NotifyBegin
// Size: 0x48(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool Temp_bool_Variable : 1;  // 0x15(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x20(0x8)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponentForSubType_ReturnValue;  // 0x30(0x8)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue;  // 0x38(0x8)
	struct UKSWeaponComponent* K2Node_Select_Default;  // 0x40(0x8)

}; 
// Function ANotifyState_MeleeCombo.ANotifyState_MeleeCombo_C.Received_NotifyEnd
// Size: 0x48(Inherited: 0x18) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable : 1;  // 0x11(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x20(0x8)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponentAtIndex_ReturnValue;  // 0x30(0x8)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue;  // 0x38(0x8)
	struct UKSWeaponComponent* K2Node_Select_Default;  // 0x40(0x8)

}; 
