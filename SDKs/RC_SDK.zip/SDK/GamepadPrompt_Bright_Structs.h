#pragma once 
#include "SDK.h" 
 
 
// Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.ExecuteUbergraph_GamepadPrompt_Bright
// Size: 0x78(Inherited: 0x0) 
struct FExecuteUbergraph_GamepadPrompt_Bright
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FKey CallFunc_GetGamepadButtonForAction_Button;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_GetGamepadButtonForAction_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UTexture2D* CallFunc_GetIconForGamepadButton_Icon;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FKey CallFunc_GetGamepadCancelButton_ReturnValue;  // 0x38(0x18)
	struct UTexture2D* CallFunc_GetIconForGamepadButton_Icon_2;  // 0x50(0x8)
	struct FKey CallFunc_GetGamepadConfirmButton_ReturnValue;  // 0x58(0x18)
	struct UTexture2D* CallFunc_GetIconForGamepadButton_Icon_3;  // 0x70(0x8)

}; 
// Function GamepadPrompt_Bright.GamepadPrompt_Bright_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
