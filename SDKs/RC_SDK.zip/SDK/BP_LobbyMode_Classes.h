#pragma once 
#include <BP_LobbyMode_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LobbyMode.BP_LobbyMode_C
// Size: 0x3D8(Inherited: 0x3D0) 
struct ABP_LobbyMode_C : public APGame_GameModeBase
{
	struct USceneComponent* DefaultSceneRoot;  // 0x3D0(0x8)

}; 



