#pragma once 
#include <GamePlayerControllerNoHUD_Structs.h>
 
 
 
// BlueprintGeneratedClass GamePlayerControllerNoHUD.GamePlayerControllerNoHUD_C
// Size: 0x1018(Inherited: 0x1000) 
struct AGamePlayerControllerNoHUD_C : public AKSPlayerController
{
	struct UPlayerControllerThreatComponent_C* PlayerControllerThreatComponent;  // 0x1000(0x8)
	struct UAkComponent* ControllerAkComponent;  // 0x1008(0x8)
	struct UDefaultEnvironmentListener_C* DefaultEnvironmentListener;  // 0x1010(0x8)

}; 



