#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.ExecuteUbergraph_EventTracker_MobileWeaponXp
// Size: 0x1CC(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_MobileWeaponXp
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_GetTimeSinceEquipped_TimeElapsed;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool Temp_bool_Variable : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct AKSPlayerController* K2Node_DynamicCast_AsKSPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AKSPlayerController* K2Node_CustomEvent_Controller;  // 0x30(0x8)
	struct AActor* K2Node_CustomEvent_OldViewTarget;  // 0x38(0x8)
	struct AActor* K2Node_CustomEvent_NewViewTarget;  // 0x40(0x8)
	struct AActor* CallFunc_GetViewTarget_ReturnValue;  // 0x48(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue;  // 0x60(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UKSWeaponComponent* CallFunc_GetActiveWeaponComponent_ReturnValue_2;  // 0x78(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x80(0x10)
	struct AKSCharacter* K2Node_CustomEvent_Character;  // 0x90(0x8)
	struct UKSWeaponComponent* K2Node_CustomEvent_UnequippedWeapon;  // 0x98(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct AKSWeapon* CallFunc_GetOwningWeapon_ReturnValue;  // 0xB8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool CallFunc_IsWeaponConditionMet_ReturnValue : 1;  // 0xD1(0x1)
	char pad_210[6];  // 0xD2(0x6)
	struct AKSCharacter* K2Node_CustomEvent_Character_2;  // 0xD8(0x8)
	struct UKSWeaponComponent* K2Node_CustomEvent_EquippedWeapon;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xE9(0x1)
	char pad_234[6];  // 0xEA(0x6)
	struct AKSWeapon* CallFunc_GetOwningWeapon_ReturnValue_2;  // 0xF0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0xF8(0x10)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_IsWeaponConditionMet_ReturnValue_2 : 1;  // 0x109(0x1)
	char pad_266_1 : 7;  // 0x10A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x10A(0x1)
	char pad_267[1];  // 0x10B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x10C(0x10)
	char pad_284[4];  // 0x11C(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x120(0x8)
	struct FMatchPhase CallFunc_GetMatchPhase_ReturnValue;  // 0x128(0x14)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x13C(0x1)
	char pad_317[3];  // 0x13D(0x3)
	float CallFunc_GetTimeSinceEquipped_TimeElapsed_2;  // 0x140(0x4)
	char pad_324_1 : 7;  // 0x144(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x144(0x1)
	char pad_325[3];  // 0x145(0x3)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x148(0x8)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x150(0x8)
	float CallFunc_FindFloatProperty_ReturnValue;  // 0x158(0x4)
	float CallFunc_FindFloatProperty_ReturnValue_2;  // 0x15C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x160(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x164(0x4)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x168(0x1)
	char pad_361_1 : 7;  // 0x169(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x169(0x1)
	char pad_362[2];  // 0x16A(0x2)
	float K2Node_Select_Default;  // 0x16C(0x4)
	float K2Node_Select_Default_2;  // 0x170(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x174(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x178(0x4)
	char pad_380[4];  // 0x17C(0x4)
	struct FDateTime CallFunc_Now_ReturnValue;  // 0x180(0x8)
	struct FMatchPhase K2Node_CustomEvent_PreviousPhase;  // 0x188(0x14)
	struct FMatchPhase K2Node_CustomEvent_NewPhase;  // 0x19C(0x14)
	struct FDateTime CallFunc_Now_ReturnValue_2;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x1B9(0x1)
	char pad_442[2];  // 0x1BA(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x1BC(0x10)

}; 
// Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.GetTimeSinceEquipped
// Size: 0x1C(Inherited: 0x0) 
struct FGetTimeSinceEquipped
{
	float TimeElapsed;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDateTime CallFunc_Now_ReturnValue;  // 0x8(0x8)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue;  // 0x10(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue;  // 0x18(0x4)

}; 
// Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.OnPhaseChanged
// Size: 0x28(Inherited: 0x0) 
struct FOnPhaseChanged
{
	struct FMatchPhase PreviousPhase;  // 0x0(0x14)
	struct FMatchPhase NewPhase;  // 0x14(0x14)

}; 
// Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.ViewTargetChanged
// Size: 0x18(Inherited: 0x0) 
struct FViewTargetChanged
{
	struct AKSPlayerController* Controller;  // 0x0(0x8)
	struct AActor* OldViewTarget;  // 0x8(0x8)
	struct AActor* NewViewTarget;  // 0x10(0x8)

}; 
// Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.OnWeaponUnequipped
// Size: 0x10(Inherited: 0x0) 
struct FOnWeaponUnequipped
{
	struct AKSCharacter* Character;  // 0x0(0x8)
	struct UKSWeaponComponent* UnequippedWeapon;  // 0x8(0x8)

}; 
// Function EventTracker_MobileWeaponXp.EventTracker_MobileWeaponXp_C.OnWeaponEquipped
// Size: 0x10(Inherited: 0x0) 
struct FOnWeaponEquipped
{
	struct AKSCharacter* Character;  // 0x0(0x8)
	struct UKSWeaponComponent* EquippedWeapon;  // 0x8(0x8)

}; 
