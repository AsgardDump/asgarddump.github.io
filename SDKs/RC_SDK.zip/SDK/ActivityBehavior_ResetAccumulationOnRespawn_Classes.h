#pragma once 
#include <ActivityBehavior_ResetAccumulationOnRespawn_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_ResetAccumulationOnRespawn_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.HandleBehaviorInitialized
	void HandlePlayerRespawned(struct AKSPlayerState* PlayerState, struct AKSCharacterBase* Character); // Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.HandlePlayerRespawned
	void HandleRespawnTimerComplete(); // Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.HandleRespawnTimerComplete
	void ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRespawn(int32_t EntryPoint); // Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRespawn
}; 



