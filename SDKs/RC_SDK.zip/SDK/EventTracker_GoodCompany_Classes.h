#pragma once 
#include <EventTracker_GoodCompany_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_GoodCompany.EventTracker_GoodCompany_C
// Size: 0x1E8(Inherited: 0x1C0) 
struct UEventTracker_GoodCompany_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	struct TArray<int32_t> ItemIds;  // 0x1C8(0x10)
	struct TArray<int32_t> LootTableItemIds;  // 0x1D8(0x10)

	void GetJobItemId(int32_t& JobItemId); // Function EventTracker_GoodCompany.EventTracker_GoodCompany_C.GetJobItemId
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_GoodCompany.EventTracker_GoodCompany_C.IsWinningTeam
	void HandleTrackerInitialized(); // Function EventTracker_GoodCompany.EventTracker_GoodCompany_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_GoodCompany.EventTracker_GoodCompany_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_GoodCompany(int32_t EntryPoint); // Function EventTracker_GoodCompany.EventTracker_GoodCompany_C.ExecuteUbergraph_EventTracker_GoodCompany
}; 



