#pragma once 
#include "SDK.h" 
 
 
// Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.ExecuteUbergraph_FirstTimeBrightnessWidget
// Size: 0x13C(Inherited: 0x0) 
struct FExecuteUbergraph_FirstTimeBrightnessWidget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x8(0x8)
	struct UKSGameUserSettings* K2Node_DynamicCast_AsKSGame_User_Settings;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x1C(0x8)
	char pad_36[4];  // 0x24(0x4)
	struct UAkAudioEvent* Temp_object_Variable;  // 0x28(0x8)
	struct ABP_BrightLobbyHUD_C* K2Node_DynamicCast_AsBP_Bright_Lobby_HUD;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_Remove_Top_View_Route_ViewChanged : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct AKSLobbyHUDNew* K2Node_DynamicCast_AsKSLobby_HUDNew;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AKSLobbyHUDNew* K2Node_DynamicCast_AsKSLobby_HUDNew_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct APUMG_HUD* K2Node_Event_hud;  // 0x60(0x8)
	struct UKSSettingsWidget* CallFunc_CreateSettingsWidgetWithConfig_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Temp_bool_Variable : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UOverlaySlot* CallFunc_AddChildToOverlay_ReturnValue;  // 0x78(0x8)
	struct FDelegate Temp_delegate_Variable;  // 0x80(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct UWidget* K2Node_ComponentBoundEvent_Widget;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_GetFontByName_HasFound : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)
	struct FSlateFontInfo CallFunc_GetFontByName_FontInfo;  // 0xB8(0x50)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_GetColorByName_HasFound : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	struct FLinearColor CallFunc_GetColorByName_Color;  // 0x10C(0x10)
	char pad_284[4];  // 0x11C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct UAkAudioEvent* K2Node_Select_Default;  // 0x130(0x8)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x138(0x4)

}; 
// Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.InitializeWidget
// Size: 0x8(Inherited: 0x8) 
struct FInitializeWidget : public FInitializeWidget
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)

}; 
// Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function FirstTimeBrightnessWidget.FirstTimeBrightnessWidget_C.BndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__WBP_StandardButtonMedium_K2Node_ComponentBoundEvent_1_OnClicked__DelegateSignature
{
	struct UWidget* Widget;  // 0x0(0x8)

}; 
