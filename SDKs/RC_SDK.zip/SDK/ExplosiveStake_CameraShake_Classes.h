#pragma once 
#include <ExplosiveStake_CameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass ExplosiveStake_CameraShake.ExplosiveStake_CameraShake_C
// Size: 0x160(Inherited: 0x160) 
struct UExplosiveStake_CameraShake_C : public UCameraShake
{

}; 



