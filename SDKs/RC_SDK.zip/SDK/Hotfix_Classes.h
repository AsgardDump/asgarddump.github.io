#pragma once 
#include <Hotfix_Structs.h>
 
 
 
// Class Hotfix.OnlineHotfixManager
// Size: 0x220(Inherited: 0x28) 
struct UOnlineHotfixManager : public UObject
{
	char pad_40[440];  // 0x28(0x1B8)
	struct FString OSSName;  // 0x1E0(0x10)
	struct FString HotfixManagerClassName;  // 0x1F0(0x10)
	struct FString DebugPrefix;  // 0x200(0x10)
	struct TArray<struct UObject*> AssetsHotfixedFromIniFiles;  // 0x210(0x10)

	void StartHotfixProcess(); // Function Hotfix.OnlineHotfixManager.StartHotfixProcess
}; 



// Class Hotfix.UpdateManager
// Size: 0x118(Inherited: 0x28) 
struct UUpdateManager : public UObject
{
	char pad_40[96];  // 0x28(0x60)
	float HotfixCheckCompleteDelay;  // 0x88(0x4)
	float UpdateCheckCompleteDelay;  // 0x8C(0x4)
	float HotfixAvailabilityCheckCompleteDelay;  // 0x90(0x4)
	float UpdateCheckAvailabilityCompleteDelay;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool bCheckPlatformOSSForUpdate : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool bCheckOSSForUpdate : 1;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	int32_t AppSuspendedUpdateCheckTimeSeconds;  // 0x9C(0x4)
	char pad_160[8];  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bPlatformEnvironmentDetected : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bInitialUpdateFinished : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bCheckHotfixAvailabilityOnly : 1;  // 0xAA(0x1)
	uint8_t  CurrentUpdateState;  // 0xAB(0x1)
	int32_t WorstNumFilesPendingLoadViewed;  // 0xAC(0x4)
	uint8_t  LastPatchCheckResult;  // 0xB0(0x1)
	uint8_t  LastHotfixResult;  // 0xB1(0x1)
	char pad_178[46];  // 0xB2(0x2E)
	struct FDateTime LastUpdateCheck[2];  // 0xE0(0x10)
	uint8_t  LastCompletionResult[2];  // 0xF0(0x2)
	char pad_242[22];  // 0xF2(0x16)
	struct UEnum* UpdateStateEnum;  // 0x108(0x8)
	struct UEnum* UpdateCompletionEnum;  // 0x110(0x8)

}; 



