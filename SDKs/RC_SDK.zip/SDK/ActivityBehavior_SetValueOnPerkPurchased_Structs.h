#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_SetValueOnPerkPurchased.ActivityBehavior_SetValueOnPerkPurchased_C.ExecuteUbergraph_ActivityBehavior_SetValueOnPerkPurchased
// Size: 0x49(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_SetValueOnPerkPurchased
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UKSGameShopItemComponent* K2Node_CustomEvent_ShopItemComponent;  // 0x8(0x8)
	struct UKSItem* CallFunc_GetCurrentItem_ReturnValue;  // 0x10(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x18(0x10)
	struct FGameplayTag Temp_struct_Variable;  // 0x28(0x8)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x48(0x1)

}; 
// Function ActivityBehavior_SetValueOnPerkPurchased.ActivityBehavior_SetValueOnPerkPurchased_C.HandleShopItemPurchased
// Size: 0x8(Inherited: 0x0) 
struct FHandleShopItemPurchased
{
	struct UKSGameShopItemComponent* ShopItemComponent;  // 0x0(0x8)

}; 
