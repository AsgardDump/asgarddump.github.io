#pragma once 
#include <ActivityBehavior_SetValueOnMultiDownAchieved_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivityBehavior_SetValueOnMultiDownAchieved.ActivityBehavior_SetValueOnMultiDownAchieved_C
// Size: 0x40(Inherited: 0x38) 
struct UActivityBehavior_SetValueOnMultiDownAchieved_C : public UKSActivityBehavior
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void HandleBehaviorInitialized(); // Function ActivityBehavior_SetValueOnMultiDownAchieved.ActivityBehavior_SetValueOnMultiDownAchieved_C.HandleBehaviorInitialized
	void HandleMultiDownAchieved(int32_t DownCount); // Function ActivityBehavior_SetValueOnMultiDownAchieved.ActivityBehavior_SetValueOnMultiDownAchieved_C.HandleMultiDownAchieved
	void ExecuteUbergraph_ActivityBehavior_SetValueOnMultiDownAchieved(int32_t EntryPoint); // Function ActivityBehavior_SetValueOnMultiDownAchieved.ActivityBehavior_SetValueOnMultiDownAchieved_C.ExecuteUbergraph_ActivityBehavior_SetValueOnMultiDownAchieved
}; 



