#pragma once 
#include <BP_AbilityIconAnimationHelper_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C
// Size: 0xF0(Inherited: 0x28) 
struct UBP_AbilityIconAnimationHelper_C : public UObject
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28(0x8)
	int32_t CurrentCharge;  // 0x30(0x4)
	int32_t RequiredCharge;  // 0x34(0x4)
	int32_t ChargeDisplayThreshold;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool IsMeterOn : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FLinearColor Activation;  // 0x40(0x10)
	struct FLinearColor BaseColor;  // 0x50(0x10)
	struct FMulticastInlineDelegate TurnOnMeter;  // 0x60(0x10)
	struct FMulticastInlineDelegate TurnOffMeter;  // 0x70(0x10)
	struct FMulticastInlineDelegate UpdateDisplay;  // 0x80(0x10)
	struct FMulticastInlineDelegate SetupBasicDisplay;  // 0x90(0x10)
	struct AKSPlayerState* KSPlayerState;  // 0xA0(0x8)
	struct UKSModInst_Activated* KSModInstActivated;  // 0xA8(0x8)
	struct FMulticastInlineDelegate PostFlashTrapActivated;  // 0xB0(0x10)
	float PreviousChargeValue;  // 0xC0(0x4)
	float TargetChargeValue;  // 0xC4(0x4)
	float CurrentChargeTweenValue;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct FMulticastInlineDelegate SetFillValue;  // 0xD0(0x10)
	float AnimateInterpSpeed;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct APUMG_HUD* MyHud;  // 0xE8(0x8)

	void TrySetupBasicDisplay(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.TrySetupBasicDisplay
	void UpdateFillMeterDisplay(int32_t CurrentCharge, int32_t RequiredCharge); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UpdateFillMeterDisplay
	void UnbindChanges(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UnbindChanges
	void BindToChanges(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.BindToChanges
	void CheckForFullCharge(struct UKSModInst_Activated* KSModInstActivated); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.CheckForFullCharge
	void UpdateCharge(struct UKSModInst_Activated* KSModInstActivated); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UpdateCharge
	void HandleModChargeChange(struct UKSModInst_Activated* KSModInstActivated); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.HandleModChargeChange
	void HandlePlayerModCharge(struct UKSPlayerMod_Activated* KSPlayerModActivated); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.HandlePlayerModCharge
	void HandleModActivated(bool InBool); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.HandleModActivated
	void SetupHelper(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.SetupHelper
	void Tick(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.Tick
	void OpenAnimateMeterGate(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.OpenAnimateMeterGate
	void CloseAnimateMeterGate(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.CloseAnimateMeterGate
	void OpenRetryBasicDisplay(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.OpenRetryBasicDisplay
	void CloseRetryBasicDisplay(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.CloseRetryBasicDisplay
	void RetryBasicDisplay(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.RetryBasicDisplay
	void DownStateChange(struct AKSPlayerState* PlayerState); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.DownStateChange
	void ExecuteUbergraph_BP_AbilityIconAnimationHelper(int32_t EntryPoint); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.ExecuteUbergraph_BP_AbilityIconAnimationHelper
	void SetFillValue__DelegateSignature(float SetFillValue); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.SetFillValue__DelegateSignature
	void PostFlashTrapActivated__DelegateSignature(struct UTexture2D* NewIcon); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.PostFlashTrapActivated__DelegateSignature
	void SetupBasicDisplay__DelegateSignature(); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.SetupBasicDisplay__DelegateSignature
	void UpdateDisplay__DelegateSignature(struct FText QuantityText, int32_t CurrentCharge, int32_t RequiredCharge); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.UpdateDisplay__DelegateSignature
	void TurnOffMeter__DelegateSignature(bool IsOn); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.TurnOffMeter__DelegateSignature
	void TurnOnMeter__DelegateSignature(bool IsOn); // Function BP_AbilityIconAnimationHelper.BP_AbilityIconAnimationHelper_C.TurnOnMeter__DelegateSignature
}; 



