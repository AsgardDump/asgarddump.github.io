#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct CensorAssets.CensorTableRow
// Size: 0x58(Inherited: 0x8) 
struct FCensorTableRow : public FTableRowBase
{
	struct TSoftObjectPtr<UObject> CensoredAsset;  // 0x8(0x28)
	struct TSoftObjectPtr<UObject> ReplacementAsset;  // 0x30(0x28)

}; 
