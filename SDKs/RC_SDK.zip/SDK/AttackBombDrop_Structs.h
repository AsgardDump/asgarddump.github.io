#pragma once 
#include "SDK.h" 
 
 
// Function AttackBombDrop.AttackBombDrop_C.OnObjectiveStateChanged
// Size: 0x10(Inherited: 0x0) 
struct FOnObjectiveStateChanged
{
	struct TScriptInterface<IKSObjective> GameObjective;  // 0x0(0x10)

}; 
// Function AttackBombDrop.AttackBombDrop_C.ExecuteUbergraph_AttackBombDrop
// Size: 0x261(Inherited: 0x0) 
struct FExecuteUbergraph_AttackBombDrop
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FRotator Temp_struct_Variable;  // 0x4(0xC)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FDelegate Temp_delegate_Variable;  // 0x24(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x34(0xC)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x40(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x48(0xC)
	char pad_84[4];  // 0x54(0x4)
	struct APlayerController* CallFunc_GetLocalPlayerController_ReturnValue;  // 0x58(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x60(0x8)
	struct FRotator Temp_struct_Variable_3;  // 0x68(0xC)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x74(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x78(0xC)
	char pad_132[4];  // 0x84(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x88(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x90(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x98(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0xA0(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0xAC(0x88)
	int32_t CallFunc_PostEventAtLocation_ReturnValue_2;  // 0x134(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x138(0xC)
	char pad_324[4];  // 0x144(0x4)
	struct UAkComponent* CallFunc_SpawnAkComponentAtLocation_ReturnValue;  // 0x148(0x8)
	struct AKSGameState* CallFunc_GetKSGameState_ReturnValue;  // 0x150(0x8)
	struct TScriptInterface<IKSObjective> K2Node_CustomEvent_GameObjective;  // 0x158(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x168(0x10)
	struct UObject* CallFunc_Conv_InterfaceToObject_ReturnValue;  // 0x178(0x8)
	struct FKSObjectiveState CallFunc_GetObjectiveState_ReturnValue;  // 0x180(0x28)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1A9(0x1)
	uint8_t  K2Node_CustomEvent_Objective_State;  // 0x1AA(0x1)
	char pad_427_1 : 7;  // 0x1AB(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1AB(0x1)
	char pad_428[4];  // 0x1AC(0x4)
	struct TScriptInterface<IKSObjective> CallFunc_OnObjectiveStateChanged_GameObjective_CastInput;  // 0x1B0(0x10)
	float K2Node_Event_Time;  // 0x1C0(0x4)
	char pad_452[4];  // 0x1C4(0x4)
	struct AKSGameState_Modular* CallFunc_GetKSGameState_Modular_ReturnValue;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1D0(0x1)
	char pad_465_1 : 7;  // 0x1D1(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x1D1(0x1)
	char pad_466[2];  // 0x1D2(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x1D4(0x4)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_IsKillCamWorld_ReturnValue : 1;  // 0x1D8(0x1)
	char pad_473_1 : 7;  // 0x1D9(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x1D9(0x1)
	char pad_474[6];  // 0x1DA(0x6)
	struct AKSGameState* CallFunc_GetKSGameState_ReturnValue_2;  // 0x1E0(0x8)
	float CallFunc_GetMatchTimer_OutPhaseTimeRemaining;  // 0x1E8(0x4)
	float CallFunc_GetMatchTimer_OutTotalPhaseTime;  // 0x1EC(0x4)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1F0(0x1)
	char pad_497[3];  // 0x1F1(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1F4(0x4)
	struct AKSGameState_Modular* CallFunc_GetKSGameState_Modular_ReturnValue_2;  // 0x1F8(0x8)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_4;  // 0x200(0x10)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x210(0x1)
	char pad_529[3];  // 0x211(0x3)
	int32_t CallFunc_PostAkEvent_ReturnValue;  // 0x214(0x4)
	char pad_536_1 : 7;  // 0x218(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // 0x218(0x1)
	char pad_537_1 : 7;  // 0x219(0x1)
	bool CallFunc_IsKillCamWorld_ReturnValue_2 : 1;  // 0x219(0x1)
	char pad_538[2];  // 0x21A(0x2)
	struct FDelegate Temp_delegate_Variable_2;  // 0x21C(0x10)
	char pad_556[4];  // 0x22C(0x4)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x230(0x8)
	int32_t CallFunc_PostAkEvent_ReturnValue_2;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)
	struct UBombActivator_ABP_C* K2Node_DynamicCast_AsBomb_Activator_ABP;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x250(0x8)
	struct UBombActivator_ABP_C* K2Node_DynamicCast_AsBomb_Activator_ABP_2;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x260(0x1)

}; 
// Function AttackBombDrop.AttackBombDrop_C.OnObjectiveTimerTickEvent
// Size: 0x4(Inherited: 0x4) 
struct FOnObjectiveTimerTickEvent : public FOnObjectiveTimerTickEvent
{
	float Time;  // 0x0(0x4)

}; 
// Function AttackBombDrop.AttackBombDrop_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function AttackBombDrop.AttackBombDrop_C.OnCurrentStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnCurrentStateChanged
{
	uint8_t  Objective State;  // 0x0(0x1)

}; 
// Function AttackBombDrop.AttackBombDrop_C.BndEvt__CollisionMesh_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__CollisionMesh_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function AttackBombDrop.AttackBombDrop_C.Update Bomb Tick
// Size: 0x18(Inherited: 0x0) 
struct FUpdate Bomb Tick
{
	struct UKSTimerComponent* CallFunc_GetObjectiveTimer_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_GetTimeRemaining_ReturnValue;  // 0xC(0x4)
	float CallFunc_GetInitialTime_ReturnValue;  // 0x10(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
