#pragma once 
#include <EventTracker_RogueMasteryPoints_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C
// Size: 0x208(Inherited: 0x1C0) 
struct UEventTracker_RogueMasteryPoints_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t JobItemId;  // 0x1C8(0x4)
	float XpPerMinute;  // 0x1CC(0x4)
	float PremiumBoostMultiplier;  // 0x1D0(0x4)
	float WinMultiplier;  // 0x1D4(0x4)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool IsSelected : 1;  // 0x1D8(0x1)
	char pad_473[3];  // 0x1D9(0x3)
	float TimeSpentInJob;  // 0x1DC(0x4)
	struct FDateTime TimeWhenSelected;  // 0x1E0(0x8)
	float BaseProgress;  // 0x1E8(0x4)
	float AccumulatedProgress;  // 0x1EC(0x4)
	struct AKSPlayerState* PlayerState;  // 0x1F0(0x8)
	struct FString BonusKey;  // 0x1F8(0x10)

	void HandleJobChanged(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandleJobChanged
	void SetJobItemId(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.SetJobItemId
	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessEventBonuses
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessWinBonus
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessQueueBonus
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ProcessBoosterBonuses
	void ComputeBaseProgress(float& OutProgress); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ComputeBaseProgress
	void AccumulateTimeSpent(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.AccumulateTimeSpent
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.IsWinningTeam
	void AwardRogueMasteryPoints(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.AwardRogueMasteryPoints
	void UpdateJobSelected(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.UpdateJobSelected
	void HandleMatchEnded(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandleMatchEnded
	void HandlePhaseChanged(struct FMatchPhase PreviousPhase, struct FMatchPhase NewPhase); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandlePhaseChanged
	void HandleTrackerInitialized(); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.HandleTrackerInitialized
	void ExecuteUbergraph_EventTracker_RogueMasteryPoints(int32_t EntryPoint); // Function EventTracker_RogueMasteryPoints.EventTracker_RogueMasteryPoints_C.ExecuteUbergraph_EventTracker_RogueMasteryPoints
}; 



