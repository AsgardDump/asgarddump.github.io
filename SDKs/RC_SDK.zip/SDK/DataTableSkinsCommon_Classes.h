#pragma once 
#include <DataTableSkinsCommon_Structs.h>
 
 
 
// Class DataTableSkinsCommon.SkinTagAssetInterface
// Size: 0x28(Inherited: 0x28) 
struct USkinTagAssetInterface : public UInterface
{

}; 



// Class DataTableSkinsCommon.SkinnableStaticMeshComponent
// Size: 0x5B0(Inherited: 0x4F0) 
struct USkinnableStaticMeshComponent : public UStaticMeshComponent
{
	char pad_1264_1 : 7;  // 0x4F0(0x1)
	bool bDelaySkinUpdatesUntilTick : 1;  // 0x4E8(0x1)
	char pad_1265_1 : 7;  // 0x4F1(0x1)
	bool bSkinUpdateIsQueued : 1;  // 0x4E9(0x1)
	struct FName StaticMeshKeyword;  // 0x4EC(0x8)
	struct UStaticMesh* FailSafeStaticMesh;  // 0x4F8(0x8)
	struct UMultiSkinObject* SkinObject;  // 0x500(0x8)
	char pad_1290_1 : 7;  // 0x50A(0x1)
	bool bAllowMaterialSkinning : 1;  // 0x508(0x1)
	char pad_1291[5];  // 0x50B(0x5)
	struct TSet<struct FName> MaterialSkinningPrefixes;  // 0x510(0x50)
	char pad_1376[80];  // 0x560(0x50)

	void SetStaticMeshKeyword(struct FName InKeyword, struct UStaticMesh* InFailSafeStaticMesh); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetStaticMeshKeyword
	int32_t SetPersistentVectorParameterOnAllMaterials(struct FName ParameterName, struct FLinearColor ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameterOnAllMaterials
	int32_t SetPersistentVectorParameter(int32_t MaterialSlot, struct FName ParameterName, struct FLinearColor ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameter
	int32_t SetPersistentTextureParameterOnAllMaterials(struct FName ParameterName, struct UTexture* ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameterOnAllMaterials
	int32_t SetPersistentTextureParameter(int32_t MaterialSlot, struct FName ParameterName, struct UTexture* ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameter
	int32_t SetPersistentScalarParameterOnAllMaterials(struct FName ParameterName, float ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameterOnAllMaterials
	int32_t SetPersistentScalarParameter(int32_t MaterialSlot, struct FName ParameterName, float ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameter
	int32_t SetPersistentMaterialOverrideOnAllSlots(struct UMaterialInterface* MaterialInterface, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentMaterialOverrideOnAllSlots
	int32_t SetPersistentMaterialOverride(int32_t MaterialSlot, struct UMaterialInterface* MaterialInterface, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentMaterialOverride
	void RemovePersistentMaterialParameter(int32_t ParameterId); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.RemovePersistentMaterialParameter
	struct UMultiSkinObject* GetSkinObject(); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.GetSkinObject
	bool ChangePersistentVectorOverrideById(int32_t ParameterId, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentVectorOverrideById
	bool ChangePersistentTextureOverrideById(int32_t ParameterId, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentTextureOverrideById
	bool ChangePersistentScalarOverrideById(int32_t ParameterId, float ParameterValue); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentScalarOverrideById
	bool ChangePersistentMaterialOverrideById(int32_t ParameterId, struct UMaterialInterface* MaterialInterface); // Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentMaterialOverrideById
}; 



// Class DataTableSkinsCommon.SkinnableMergedMeshComponent
// Size: 0xD50(Inherited: 0xD00) 
struct USkinnableMergedMeshComponent : public USkinnableSkeletalMeshComponent
{
	struct FMulticastInlineDelegate OnMeshMergeComplete;  // 0xCF8(0x10)
	struct TArray<struct FName> CompositeSkeletalMeshKeywords;  // 0xD08(0x10)
	char pad_3360_1 : 7;  // 0xD20(0x1)
	bool bAlwaysUseTheFailsafeMeshWhileMerging : 1;  // 0xD18(0x1)
	struct FName MeshNeedsCPUAccessKeyword;  // 0xD1C(0x8)
	char pad_3369_1 : 7;  // 0xD29(0x1)
	bool bDelayFullSkinUpdateUntilMeshMergingIsComplete : 1;  // 0xD24(0x1)
	struct USkeletalMesh* BestPlaceHolderMesh;  // 0xD28(0x8)
	char pad_3378_1 : 7;  // 0xD32(0x1)
	bool bMergeMarkedComplete : 1;  // 0xD30(0x1)
	char pad_3379[5];  // 0xD33(0x5)
	struct USkeletalMesh* CachedMergeResult;  // 0xD38(0x8)
	char pad_3392[16];  // 0xD40(0x10)

	void SetSkeletalMeshKeywords(struct TArray<struct FName>& InKeywords, struct USkeletalMesh* InFailSafeSkeletalMesh); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.SetSkeletalMeshKeywords
	void RemoveSkeletalMeshKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.RemoveSkeletalMeshKeyword
	void OnMeshMergeComplete__DelegateSignature(); // DelegateFunction DataTableSkinsCommon.SkinnableMergedMeshComponent.OnMeshMergeComplete__DelegateSignature
	void AddSkeletalMeshKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.SkinnableMergedMeshComponent.AddSkeletalMeshKeyword
}; 



// Class DataTableSkinsCommon.SkinnableSkeletalMeshComponent
// Size: 0xD00(Inherited: 0xBB0) 
struct USkinnableSkeletalMeshComponent : public USkeletalMeshComponentBudgeted
{
	char pad_2992_1 : 7;  // 0xBB0(0x1)
	bool bDelaySkinUpdatesUntilTick : 1;  // 0xBB0(0x1)
	char pad_2993_1 : 7;  // 0xBB1(0x1)
	bool bSkinUpdateIsQueued : 1;  // 0xBB1(0x1)
	char pad_2994[2];  // 0xBB2(0x2)
	struct FName SkeletalMeshKeyword;  // 0xBB4(0x8)
	char pad_3004[4];  // 0xBBC(0x4)
	struct USkeletalMesh* FailSafeSkeletalMesh;  // 0xBC0(0x8)
	struct FName PhysicsAssetKeyword;  // 0xBC8(0x8)
	struct UPhysicsAsset* FailSafePhysicsAsset;  // 0xBD0(0x8)
	struct FName AnimInstanceClassKeyword;  // 0xBD8(0x8)
	UAnimInstance* FailSafeAnimClass;  // 0xBE0(0x8)
	UAnimInstance* LastSkinnedAnimClass;  // 0xBE8(0x8)
	char pad_3056_1 : 7;  // 0xBF0(0x1)
	bool bForceAnimationUpdateOnSkinUpdate : 1;  // 0xBF0(0x1)
	char pad_3057[7];  // 0xBF1(0x7)
	struct UMultiSkinObject* SkinObject;  // 0xBF8(0x8)
	struct FMulticastInlineDelegate OnAnimInitializedOnSkinnableMeshDel;  // 0xC00(0x10)
	char pad_3088[48];  // 0xC10(0x30)
	char pad_3136_1 : 7;  // 0xC40(0x1)
	bool bAllowMaterialSkinning : 1;  // 0xC40(0x1)
	char pad_3137[7];  // 0xC41(0x7)
	struct TArray<struct FString> MaterialSkinningPrefixes;  // 0xC48(0x10)
	struct TSet<struct FName> MaterialSkinningPrefixes_New;  // 0xC58(0x50)
	char pad_3240[72];  // 0xCA8(0x48)
	int32_t ForcedLodModel_Skinned;  // 0xCF0(0x4)
	char pad_3316[12];  // 0xCF4(0xC)

	void StaticSetForcedLOD(struct USkinnedMeshComponent* InMeshComp, int32_t InForcedLOD); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.StaticSetForcedLOD
	void SetSkeletalMeshKeyword(struct FName InKeyword, struct USkeletalMesh* InFailSafeSkeletalMesh); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetSkeletalMeshKeyword
	void SetPhysicsAssetKeyword(struct FName InKeyword, struct UPhysicsAsset* InFailSafePhysicsAsset); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPhysicsAssetKeyword
	int32_t SetPersistentVectorParameterOnAllMaterials(struct FName ParameterName, struct FLinearColor ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentVectorParameterOnAllMaterials
	int32_t SetPersistentVectorParameter(int32_t MaterialSlot, struct FName ParameterName, struct FLinearColor ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentVectorParameter
	int32_t SetPersistentTextureParameterOnAllMaterials(struct FName ParameterName, struct UTexture* ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentTextureParameterOnAllMaterials
	int32_t SetPersistentTextureParameter(int32_t MaterialSlot, struct FName ParameterName, struct UTexture* ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentTextureParameter
	int32_t SetPersistentScalarParameterOnAllMaterials(struct FName ParameterName, float ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentScalarParameterOnAllMaterials
	int32_t SetPersistentScalarParameter(int32_t MaterialSlot, struct FName ParameterName, float ParameterValue, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentScalarParameter
	int32_t SetPersistentMaterialOverrideOnAllSlots(struct UMaterialInterface* MaterialInterface, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentMaterialOverrideOnAllSlots
	int32_t SetPersistentMaterialOverride(int32_t MaterialSlot, struct UMaterialInterface* MaterialInterface, bool bForceNewOverride); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPersistentMaterialOverride
	void SetForcedLOD_Skinned(int32_t InNewForcedLOD); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetForcedLOD_Skinned
	void SetAnimClassKeyword(struct FName InKeyword, UAnimInstance* InFailSafeAnimClass); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetAnimClassKeyword
	void RemovePersistentMaterialParameter(int32_t ParameterId); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.RemovePersistentMaterialParameter
	struct UMultiSkinObject* GetSkinObject(); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.GetSkinObject
	void ForwardAnimInitialized(); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.ForwardAnimInitialized
	bool ChangePersistentVectorOverrideById(int32_t ParameterId, struct FLinearColor ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.ChangePersistentVectorOverrideById
	bool ChangePersistentTextureOverrideById(int32_t ParameterId, struct UTexture* ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.ChangePersistentTextureOverrideById
	bool ChangePersistentScalarOverrideById(int32_t ParameterId, float ParameterValue); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.ChangePersistentScalarOverrideById
	bool ChangePersistentMaterialOverrideById(int32_t ParameterId, struct UMaterialInterface* MaterialInterface); // Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.ChangePersistentMaterialOverrideById
}; 



// Class DataTableSkinsCommon.DynamicSkinTable
// Size: 0x298(Inherited: 0x28) 
struct UDynamicSkinTable : public UObject
{
	struct TArray<struct FDataTableInfo> ActiveDataTables;  // 0x28(0x10)
	struct TArray<struct FDataTableInfo> InactiveDataTables;  // 0x38(0x10)
	struct FMulticastInlineDelegate OnFinishedAllPendingLoadsDel;  // 0x48(0x10)
	char pad_88[544];  // 0x58(0x220)
	char bWantsToBeRecycled : 1;  // 0x278(0x1)
	char pad_632_1 : 7;  // 0x278(0x1)
	char pad_633[8];  // 0x279(0x8)
	struct TScriptInterface<ISkinTagAssetInterface> SkinTagAsset;  // 0x280(0x10)
	char pad_656[8];  // 0x290(0x8)

	void RemoveDataTables(struct TArray<struct UDataTable*>& InTables); // Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTables
	void RemoveDataTable(struct UDataTable* InTable); // Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTable
	bool IsTablePendingAssetLoad(); // Function DataTableSkinsCommon.DynamicSkinTable.IsTablePendingAssetLoad
	struct UTexture* GetTexture(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetTexture
	struct UStaticMesh* GetStaticMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetStaticMesh
	struct USkeletalMesh* GetSkeletalMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetSkeletalMesh
	struct USelectiveAkAudioEvent* GetSelectiveAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetSelectiveAudioEvent
	struct UPoseAsset* GetPoseAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetPoseAsset
	struct UPhysicsAsset* GetPhysicsAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetPhysicsAsset
	struct UParticleSystem* GetParticleSystem(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetParticleSystem
	struct FName GetNameField(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetNameField
	struct UMaterialInterface* GetMaterialInterface(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetMaterialInterface
	struct FLinearColor GetLinearColor(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetLinearColor
	int32_t GetInt(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetInt
	float GetFloat(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetFloat
	UObject* GetClass(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetClass
	bool GetBool(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetBool
	struct UAkAudioEvent* GetAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAudioEvent
	struct UAnimSequence* GetAnimSequence(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimSequence
	struct UAnimMontage* GetAnimMontage(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimMontage
	struct UBlendSpace* GetAnimBlendSpace(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimBlendSpace
	struct UAnimationAsset* GetAnimationAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimationAsset
	struct UAimOffsetBlendSpace* GetAnimAimOffset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.DynamicSkinTable.GetAnimAimOffset
	void GetAllKeywords(struct TSet<struct FName>& InOutKeywords); // Function DataTableSkinsCommon.DynamicSkinTable.GetAllKeywords
	void AddDataTableWithQuery(struct UDataTable* InTable, int32_t InPriority, struct FGameplayTagQuery& InQuery); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTableWithQuery
	void AddDataTables(struct TArray<struct FDataTableInfo>& InTableInfos); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTables
	void AddDataTable(struct UDataTable* InTable, int32_t InPriority); // Function DataTableSkinsCommon.DynamicSkinTable.AddDataTable
}; 



// Class DataTableSkinsCommon.MultiSkinObject
// Size: 0x1D0(Inherited: 0x28) 
struct UMultiSkinObject : public UObject
{
	struct TArray<struct UMultiSkinObject*> ParentSkinnedObjects;  // 0x28(0x10)
	struct TArray<struct TWeakObjectPtr<UMultiSkinObject>> ChildSkinnedObjects;  // 0x38(0x10)
	struct TSet<struct FName> SubscribedKeywords;  // 0x48(0x50)
	struct TSet<struct FName> SubscribedMaterialPrefixes;  // 0x98(0x50)
	char bSubscribeToAllKeywords : 1;  // 0xE8(0x1)
	char bWantsToBeRecycled : 1;  // 0xE8(0x1)
	char pad_232_1 : 6;  // 0xE8(0x1)
	char pad_233[32];  // 0xE9(0x20)
	struct FMulticastInlineDelegate OnFinishedAllPendingLoadsDel;  // 0x108(0x10)
	char pad_280[24];  // 0x118(0x18)
	struct TMap<int32_t, struct FDynamicSkinTableMapEntry> DynamicSkinTables;  // 0x130(0x50)
	struct TMap<struct FName, struct FCachedRowsEntry> CachedRows;  // 0x180(0x50)

	void UnsubscribeToKeywords(struct TArray<struct FName>& InKeywords); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeywords
	void UnsubscribeToKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeyword
	void UnsubscribeToAllKeywords(); // Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToAllKeywords
	void SubscribeToKeywords(struct TArray<struct FName>& InKeywords); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeywords
	void SubscribeToKeyword(struct FName InKeyword); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeyword
	void SubscribeToAllKeywords(); // Function DataTableSkinsCommon.MultiSkinObject.SubscribeToAllKeywords
	void RemoveParent(struct UMultiSkinObject* InParent); // Function DataTableSkinsCommon.MultiSkinObject.RemoveParent
	struct UTexture* GetTexture(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetTexture
	struct UStaticMesh* GetStaticMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetStaticMesh
	struct USkeletalMesh* GetSkeletalMesh(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetSkeletalMesh
	struct USelectiveAkAudioEvent* GetSelectiveAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetSelectiveAudioEvent
	struct UPoseAsset* GetPoseAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetPoseAsset
	struct UPhysicsAsset* GetPhysicsAsset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetPhysicsAsset
	struct UParticleSystem* GetParticleSystem(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetParticleSystem
	struct FName GetNameField(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetNameField
	struct UMaterialInterface* GetMaterialInterface(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetMaterialInterface
	struct FLinearColor GetLinearColor(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetLinearColor
	int32_t GetInt(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetInt
	float GetFloat(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetFloat
	UObject* GetClass(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetClass
	bool GetBool(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetBool
	struct UAkAudioEvent* GetAudioEvent(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAudioEvent
	struct UAnimSequence* GetAnimSequence(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimSequence
	struct UAnimMontage* GetAnimMontage(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimMontage
	struct UBlendSpace* GetAnimBlendSpace(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimBlendSpace
	struct UAimOffsetBlendSpace* GetAnimAimOffset(struct FName RowName, int32_t& Priority); // Function DataTableSkinsCommon.MultiSkinObject.GetAnimAimOffset
	void GetAllSkinKeywords(struct TSet<struct FName>& InOutKeywords); // Function DataTableSkinsCommon.MultiSkinObject.GetAllSkinKeywords
	void AddParent(struct UMultiSkinObject* InParent); // Function DataTableSkinsCommon.MultiSkinObject.AddParent
}; 



// Class DataTableSkinsCommon.SkinObjectManagerComponent
// Size: 0x150(Inherited: 0xB0) 
struct USkinObjectManagerComponent : public UActorComponent
{
	struct TMap<struct FName, struct UMultiSkinObject*> SkinObjects;  // 0xB0(0x50)
	struct TSet<struct UMultiSkinObject*> SkinObjectsSet;  // 0x100(0x50)

}; 



