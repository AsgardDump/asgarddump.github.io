#pragma once 
#include <GDT_RadarDart_ABP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass GDT_RadarDart_ABP.GDT_RadarDart_ABP_C
// Size: 0x641(Inherited: 0x270) 
struct UGDT_RadarDart_ABP_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x270(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x278(0x40)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x2B8(0x38)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x2F0(0x38)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x328(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x3B0(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3F0(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x478(0x40)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x4B8(0x88)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x540(0x40)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x580(0xC0)
	char pad_1600_1 : 7;  // 0x640(0x1)
	bool IsStopped : 1;  // 0x640(0x1)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.AnimGraph
	void Set Weapon State(struct UKSWeaponComponent* Owning Weapon Component, uint8_t  Old State, uint8_t  New State); // Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.Set Weapon State
	void EvaluateGraphExposedInputs_ExecuteUbergraph_GDT_RadarDart_ABP_AnimGraphNode_TransitionResult_8458AFA14F08C6BCB56AEB8DFEFA1DAE(); // Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_GDT_RadarDart_ABP_AnimGraphNode_TransitionResult_8458AFA14F08C6BCB56AEB8DFEFA1DAE
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_GDT_RadarDart_ABP(int32_t EntryPoint); // Function GDT_RadarDart_ABP.GDT_RadarDart_ABP_C.ExecuteUbergraph_GDT_RadarDart_ABP
}; 



