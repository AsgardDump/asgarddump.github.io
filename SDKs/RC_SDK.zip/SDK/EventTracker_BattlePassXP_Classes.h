#pragma once 
#include <EventTracker_BattlePassXP_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_BattlePassXP.EventTracker_BattlePassXP_C
// Size: 0x1F8(Inherited: 0x1C0) 
struct UEventTracker_BattlePassXP_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	struct AKSPlayerState* PlayerState;  // 0x1C8(0x8)
	float BaseProgress;  // 0x1D0(0x4)
	float AccumulatedProgress;  // 0x1D4(0x4)
	float XpPerMinute;  // 0x1D8(0x4)
	float PremiumBoostMultiplier;  // 0x1DC(0x4)
	float WinMultiplier;  // 0x1E0(0x4)
	char pad_484[4];  // 0x1E4(0x4)
	struct FString BonusKey;  // 0x1E8(0x10)

	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessEventBonuses
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessWinBonus
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessQueueBonus
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ProcessBoosterBonuses
	void ComputeBaseProgress(float& OutProgress); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ComputeBaseProgress
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.IsWinningTeam
	void HandleTrackerInitialized(); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_BattlePassXP(int32_t EntryPoint); // Function EventTracker_BattlePassXP.EventTracker_BattlePassXP_C.ExecuteUbergraph_EventTracker_BattlePassXP
}; 



