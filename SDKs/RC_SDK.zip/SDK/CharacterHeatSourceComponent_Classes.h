#pragma once 
#include <CharacterHeatSourceComponent_Structs.h>
 
 
 
// DynamicClass CharacterHeatSourceComponent.CharacterHeatSourceComponent_C
// Size: 0x160(Inherited: 0x100) 
struct UCharacterHeatSourceComponent_C : public UKSHeatSourceComponent
{
	struct UParticleSystem* ThermalVisionExtraParticlesPS;  // 0x100(0x8)
	struct UParticleSystemComponent* ThermalVisionExtraParticlesComp;  // 0x108(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x110(0x10)
	uint8_t  K2Node_Event_NewState;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x121(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x122(0x1)
	char pad_291[5];  // 0x123(0x5)
	struct AKSCharacterBase* K2Node_DynamicCast_AsKSCharacter_Base;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct UKSHeatSourceComponent* K2Node_CustomEvent_HeatSource;  // 0x138(0x8)
	float K2Node_CustomEvent_NewTemperature;  // 0x140(0x4)
	char pad_324[4];  // 0x144(0x4)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x150(0x1)
	char pad_337[3];  // 0x151(0x3)
	int32_t CallFunc_GetFloat_Priority;  // 0x154(0x4)
	int32_t CallFunc_GetParticleSystem_Priority;  // 0x158(0x4)
	char pad_348[4];  // 0x15C(0x4)

	void ReceiveEndPlay(char EEndPlayReason bpp__EndPlayReason__pf); // Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.ReceiveEndPlay
	void OnThermalVisionStateChanged(uint8_t  bpp__NewState__pf); // Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.OnThermalVisionStateChanged
	void OnTemperatureChanged_Event_1(struct UKSHeatSourceComponent* bpp__HeatSource__pf__const, float bpp__NewTemperature__pf); // Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.OnTemperatureChanged_Event_1
	void OnOwnerInfoUpdateNotify(); // Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.OnOwnerInfoUpdateNotify
	void ExecuteUbergraph_CharacterHeatSourceComponent_2(int32_t bpp__EntryPoint__pf); // Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.ExecuteUbergraph_CharacterHeatSourceComponent_2
	void Conditionally Apply Temperature(float bpp__AppliedxTemp__pfT); // Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.Conditionally Apply Temperature
	void Apply Temperature(float bpp__AppliedxTemp__pfT); // Function CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.Apply Temperature
	void OnTempChanged__DelegateSignature(struct UKSHeatSourceComponent* bpp__HeatSource__pf, float bpp__NewTemperature__pf); // DelegateFunction CharacterHeatSourceComponent.CharacterHeatSourceComponent_C.OnTempChanged__DelegateSignature
}; 



