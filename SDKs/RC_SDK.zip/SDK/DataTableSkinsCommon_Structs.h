#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction DataTableSkinsCommon.OnFinishedAllPendingLoads__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnFinishedAllPendingLoads__DelegateSignature
{
	struct UDynamicSkinTable* DynamicSkinTable;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.IsTablePendingAssetLoad
// Size: 0x1(Inherited: 0x0) 
struct FIsTablePendingAssetLoad
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction DataTableSkinsCommon.OnFinishedAllPendingLoadsKeywords__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnFinishedAllPendingLoadsKeywords__DelegateSignature
{
	struct TSet<struct FName> Keywords;  // 0x0(0x50)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.GetSkinObject
// Size: 0x8(Inherited: 0x0) 
struct FGetSkinObject
{
	struct UMultiSkinObject* ReturnValue;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetSkeletalMesh
// Size: 0x18(Inherited: 0x0) 
struct FGetSkeletalMesh
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct USkeletalMesh* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct DataTableSkinsCommon.SkinStaticMeshUpdateTickFunction
// Size: 0x30(Inherited: 0x28) 
struct FSkinStaticMeshUpdateTickFunction : public FTickFunction
{
	char pad_40[8];  // 0x28(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentMaterialOverrideById
// Size: 0x18(Inherited: 0x0) 
struct FChangePersistentMaterialOverrideById
{
	int32_t ParameterId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInterface* MaterialInterface;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetAnimBlendSpace
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimBlendSpace
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UBlendSpace* ReturnValue;  // 0x10(0x8)

}; 
// DelegateFunction DataTableSkinsCommon.OnAnimInitializedOnSkinnableMesh__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAnimInitializedOnSkinnableMesh__DelegateSignature
{
	struct USkinnableSkeletalMeshComponent* SkinnableSkelComp;  // 0x0(0x8)
	struct UAnimInstance* AnimInstance;  // 0x8(0x8)

}; 
// ScriptStruct DataTableSkinsCommon.SkinUpdateTickFunction
// Size: 0x30(Inherited: 0x28) 
struct FSkinUpdateTickFunction : public FTickFunction
{
	char pad_40[8];  // 0x28(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentScalarOverrideById
// Size: 0xC(Inherited: 0x0) 
struct FChangePersistentScalarOverrideById
{
	int32_t ParameterId;  // 0x0(0x4)
	float ParameterValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentTextureOverrideById
// Size: 0x18(Inherited: 0x0) 
struct FChangePersistentTextureOverrideById
{
	int32_t ParameterId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UTexture* ParameterValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.StaticSetForcedLOD
// Size: 0x10(Inherited: 0x0) 
struct FStaticSetForcedLOD
{
	struct USkinnedMeshComponent* InMeshComp;  // 0x0(0x8)
	int32_t InForcedLOD;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.ChangePersistentVectorOverrideById
// Size: 0x18(Inherited: 0x0) 
struct FChangePersistentVectorOverrideById
{
	int32_t ParameterId;  // 0x0(0x4)
	struct FLinearColor ParameterValue;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// ScriptStruct DataTableSkinsCommon.HardAssetTableRow
// Size: 0x98(Inherited: 0x8) 
struct FHardAssetTableRow : public FTableRowBase
{
	struct UAnimationAsset* AnimationAsset;  // 0x8(0x8)
	struct UAkAudioEvent* AudioEvent;  // 0x10(0x8)
	struct USelectiveAkAudioEvent* SelectiveAudioEvent;  // 0x18(0x8)
	struct USkeletalMesh* SkeletalMesh;  // 0x20(0x8)
	struct UPhysicsAsset* PhysicsAsset;  // 0x28(0x8)
	struct UStaticMesh* StaticMesh;  // 0x30(0x8)
	struct UParticleSystem* ParticleSystem;  // 0x38(0x8)
	struct UMaterialInterface* MaterialInterface;  // 0x40(0x8)
	struct UTexture* Texture;  // 0x48(0x8)
	UObject* Class;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool Bool : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	float float;  // 0x5C(0x4)
	struct FLinearColor LinearColor;  // 0x60(0x10)
	int32_t Int;  // 0x70(0x4)
	struct FName NameField;  // 0x74(0x8)
	char pad_124[28];  // 0x7C(0x1C)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.RemovePersistentMaterialParameter
// Size: 0x4(Inherited: 0x0) 
struct FRemovePersistentMaterialParameter
{
	int32_t ParameterId;  // 0x0(0x4)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.GetAnimationAsset
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimationAsset
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UAnimationAsset* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetAnimClassKeyword
// Size: 0x10(Inherited: 0x0) 
struct FSetAnimClassKeyword
{
	struct FName InKeyword;  // 0x0(0x8)
	UAnimInstance* InFailSafeAnimClass;  // 0x8(0x8)

}; 
// ScriptStruct DataTableSkinsCommon.MaterialSkinInfo
// Size: 0x1C(Inherited: 0x0) 
struct FMaterialSkinInfo
{
	struct FName Prefix;  // 0x0(0x8)
	int32_t MaterialSlot;  // 0x8(0x4)
	uint8_t  SkinType;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FName ParamName;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bValid : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetForcedLOD_Skinned
// Size: 0x4(Inherited: 0x0) 
struct FSetForcedLOD_Skinned
{
	int32_t InNewForcedLOD;  // 0x0(0x4)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentMaterialOverride
// Size: 0x18(Inherited: 0x0) 
struct FSetPersistentMaterialOverride
{
	int32_t MaterialSlot;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInterface* MaterialInterface;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bForceNewOverride : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetTexture
// Size: 0x18(Inherited: 0x0) 
struct FGetTexture
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UTexture* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.GetAllKeywords
// Size: 0x50(Inherited: 0x0) 
struct FGetAllKeywords
{
	struct TSet<struct FName> InOutKeywords;  // 0x0(0x50)

}; 
// ScriptStruct DataTableSkinsCommon.CachedRowsEntry
// Size: 0xA0(Inherited: 0x0) 
struct FCachedRowsEntry
{
	int32_t Priority;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FHardAssetTableRow Row;  // 0x8(0x98)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameterOnAllMaterials
// Size: 0x20(Inherited: 0x0) 
struct FSetPersistentVectorParameterOnAllMaterials
{
	struct FName ParameterName;  // 0x0(0x8)
	struct FLinearColor ParameterValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bForceNewOverride : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t ReturnValue;  // 0x1C(0x4)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentMaterialOverrideOnAllSlots
// Size: 0x10(Inherited: 0x0) 
struct FSetPersistentMaterialOverrideOnAllSlots
{
	struct UMaterialInterface* MaterialInterface;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bForceNewOverride : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetAudioEvent
// Size: 0x18(Inherited: 0x0) 
struct FGetAudioEvent
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UAkAudioEvent* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableMergedMeshComponent.AddSkeletalMeshKeyword
// Size: 0x8(Inherited: 0x0) 
struct FAddSkeletalMeshKeyword
{
	struct FName InKeyword;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetPersistentScalarParameter
{
	int32_t MaterialSlot;  // 0x0(0x4)
	struct FName ParameterName;  // 0x4(0x8)
	float ParameterValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bForceNewOverride : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentScalarParameterOnAllMaterials
// Size: 0x14(Inherited: 0x0) 
struct FSetPersistentScalarParameterOnAllMaterials
{
	struct FName ParameterName;  // 0x0(0x8)
	float ParameterValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bForceNewOverride : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t ReturnValue;  // 0x10(0x4)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.AddParent
// Size: 0x8(Inherited: 0x0) 
struct FAddParent
{
	struct UMultiSkinObject* InParent;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTables
// Size: 0x10(Inherited: 0x0) 
struct FRemoveDataTables
{
	struct TArray<struct UDataTable*> InTables;  // 0x0(0x10)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetPhysicsAsset
// Size: 0x18(Inherited: 0x0) 
struct FGetPhysicsAsset
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPhysicsAsset* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameter
// Size: 0x20(Inherited: 0x0) 
struct FSetPersistentTextureParameter
{
	int32_t MaterialSlot;  // 0x0(0x4)
	struct FName ParameterName;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct UTexture* ParameterValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bForceNewOverride : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t ReturnValue;  // 0x1C(0x4)

}; 
// Function DataTableSkinsCommon.SkinnableMergedMeshComponent.RemoveSkeletalMeshKeyword
// Size: 0x8(Inherited: 0x0) 
struct FRemoveSkeletalMeshKeyword
{
	struct FName InKeyword;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentTextureParameterOnAllMaterials
// Size: 0x18(Inherited: 0x0) 
struct FSetPersistentTextureParameterOnAllMaterials
{
	struct FName ParameterName;  // 0x0(0x8)
	struct UTexture* ParameterValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bForceNewOverride : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetNameField
// Size: 0x14(Inherited: 0x0) 
struct FGetNameField
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	struct FName ReturnValue;  // 0xC(0x8)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.AddDataTable
// Size: 0x10(Inherited: 0x0) 
struct FAddDataTable
{
	struct UDataTable* InTable;  // 0x0(0x8)
	int32_t InPriority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetPersistentVectorParameter
// Size: 0x24(Inherited: 0x0) 
struct FSetPersistentVectorParameter
{
	int32_t MaterialSlot;  // 0x0(0x4)
	struct FName ParameterName;  // 0x4(0x8)
	struct FLinearColor ParameterValue;  // 0xC(0x10)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bForceNewOverride : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t ReturnValue;  // 0x20(0x4)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetBool
// Size: 0x10(Inherited: 0x0) 
struct FGetBool
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetPhysicsAssetKeyword
// Size: 0x10(Inherited: 0x0) 
struct FSetPhysicsAssetKeyword
{
	struct FName InKeyword;  // 0x0(0x8)
	struct UPhysicsAsset* InFailSafePhysicsAsset;  // 0x8(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableSkeletalMeshComponent.SetSkeletalMeshKeyword
// Size: 0x10(Inherited: 0x0) 
struct FSetSkeletalMeshKeyword
{
	struct FName InKeyword;  // 0x0(0x8)
	struct USkeletalMesh* InFailSafeSkeletalMesh;  // 0x8(0x8)

}; 
// Function DataTableSkinsCommon.SkinnableMergedMeshComponent.SetSkeletalMeshKeywords
// Size: 0x18(Inherited: 0x0) 
struct FSetSkeletalMeshKeywords
{
	struct TArray<struct FName> InKeywords;  // 0x0(0x10)
	struct USkeletalMesh* InFailSafeSkeletalMesh;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetAnimMontage
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimMontage
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UAnimMontage* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct DataTableSkinsCommon.DataTableInfo
// Size: 0x58(Inherited: 0x0) 
struct FDataTableInfo
{
	struct UDataTable* DataTable;  // 0x0(0x8)
	int32_t TablePriority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FGameplayTagQuery SkinTagQuery;  // 0x10(0x48)

}; 
// ScriptStruct DataTableSkinsCommon.SoftAssetTableRow
// Size: 0x1D8(Inherited: 0x8) 
struct FSoftAssetTableRow : public FTableRowBase
{
	struct TSoftObjectPtr<UAnimationAsset> AnimationAsset;  // 0x8(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> AudioEvent;  // 0x30(0x28)
	struct TSoftObjectPtr<USelectiveAkAudioEvent> SelectiveAudioEvent;  // 0x58(0x28)
	struct TSoftObjectPtr<USkeletalMesh> SkeletalMesh;  // 0x80(0x28)
	struct TSoftObjectPtr<UPhysicsAsset> PhysicsAsset;  // 0xA8(0x28)
	struct TSoftObjectPtr<UStaticMesh> StaticMesh;  // 0xD0(0x28)
	struct TSoftObjectPtr<UParticleSystem> ParticleSystem;  // 0xF8(0x28)
	struct TSoftObjectPtr<UMaterialInterface> MaterialInterface;  // 0x120(0x28)
	struct TSoftObjectPtr<UTexture> Texture;  // 0x148(0x28)
	struct TSoftClassPtr<UObject> Class;  // 0x170(0x28)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool Bool : 1;  // 0x198(0x1)
	char pad_409[3];  // 0x199(0x3)
	float float;  // 0x19C(0x4)
	struct FLinearColor LinearColor;  // 0x1A0(0x10)
	int32_t Int;  // 0x1B0(0x4)
	struct FName NameField;  // 0x1B4(0x8)
	char pad_444[28];  // 0x1BC(0x1C)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetClass
// Size: 0x18(Inherited: 0x0) 
struct FGetClass
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	UObject* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.AddDataTables
// Size: 0x10(Inherited: 0x0) 
struct FAddDataTables
{
	struct TArray<struct FDataTableInfo> InTableInfos;  // 0x0(0x10)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.RemoveDataTable
// Size: 0x8(Inherited: 0x0) 
struct FRemoveDataTable
{
	struct UDataTable* InTable;  // 0x0(0x8)

}; 
// ScriptStruct DataTableSkinsCommon.DynamicSkinTableMapEntry
// Size: 0x18(Inherited: 0x0) 
struct FDynamicSkinTableMapEntry
{
	struct UDynamicSkinTable* Table;  // 0x0(0x8)
	char pad_8[16];  // 0x8(0x10)

}; 
// Function DataTableSkinsCommon.DynamicSkinTable.AddDataTableWithQuery
// Size: 0x58(Inherited: 0x0) 
struct FAddDataTableWithQuery
{
	struct UDataTable* InTable;  // 0x0(0x8)
	int32_t InPriority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FGameplayTagQuery InQuery;  // 0x10(0x48)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetParticleSystem
// Size: 0x18(Inherited: 0x0) 
struct FGetParticleSystem
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UParticleSystem* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetAnimAimOffset
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimAimOffset
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UAimOffsetBlendSpace* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetAnimSequence
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimSequence
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UAnimSequence* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetAllSkinKeywords
// Size: 0x50(Inherited: 0x0) 
struct FGetAllSkinKeywords
{
	struct TSet<struct FName> InOutKeywords;  // 0x0(0x50)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetFloat
// Size: 0x10(Inherited: 0x0) 
struct FGetFloat
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetInt
// Size: 0x10(Inherited: 0x0) 
struct FGetInt
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetLinearColor
// Size: 0x1C(Inherited: 0x0) 
struct FGetLinearColor
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	struct FLinearColor ReturnValue;  // 0xC(0x10)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetSelectiveAudioEvent
// Size: 0x18(Inherited: 0x0) 
struct FGetSelectiveAudioEvent
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct USelectiveAkAudioEvent* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.RemoveParent
// Size: 0x8(Inherited: 0x0) 
struct FRemoveParent
{
	struct UMultiSkinObject* InParent;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetMaterialInterface
// Size: 0x18(Inherited: 0x0) 
struct FGetMaterialInterface
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UMaterialInterface* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetPoseAsset
// Size: 0x18(Inherited: 0x0) 
struct FGetPoseAsset
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPoseAsset* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.GetStaticMesh
// Size: 0x18(Inherited: 0x0) 
struct FGetStaticMesh
{
	struct FName RowName;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UStaticMesh* ReturnValue;  // 0x10(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeyword
// Size: 0x8(Inherited: 0x0) 
struct FSubscribeToKeyword
{
	struct FName InKeyword;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.SubscribeToKeywords
// Size: 0x10(Inherited: 0x0) 
struct FSubscribeToKeywords
{
	struct TArray<struct FName> InKeywords;  // 0x0(0x10)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeyword
// Size: 0x8(Inherited: 0x0) 
struct FUnsubscribeToKeyword
{
	struct FName InKeyword;  // 0x0(0x8)

}; 
// Function DataTableSkinsCommon.MultiSkinObject.UnsubscribeToKeywords
// Size: 0x10(Inherited: 0x0) 
struct FUnsubscribeToKeywords
{
	struct TArray<struct FName> InKeywords;  // 0x0(0x10)

}; 
// Function DataTableSkinsCommon.SkinnableStaticMeshComponent.SetStaticMeshKeyword
// Size: 0x10(Inherited: 0x0) 
struct FSetStaticMeshKeyword
{
	struct FName InKeyword;  // 0x0(0x8)
	struct UStaticMesh* InFailSafeStaticMesh;  // 0x8(0x8)

}; 
