#pragma once 
#include "SDK.h" 
 
 
// Function BloodEffectCurveComponent.BloodEffectCurveComponent_C.UpdateScalarTrack
// Size: 0xC(Inherited: 0xC) 
struct FUpdateScalarTrack : public FUpdateScalarTrack
{
	struct FName TrackName;  // 0x0(0x8)
	float TrackValue;  // 0x8(0x4)

}; 
// Function BloodEffectCurveComponent.BloodEffectCurveComponent_C.ExecuteUbergraph_BloodEffectCurveComponent
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_BloodEffectCurveComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName K2Node_Event_TrackName;  // 0x4(0x8)
	float K2Node_Event_TrackValue;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x18(0x1)

}; 
