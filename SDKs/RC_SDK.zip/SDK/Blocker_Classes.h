#pragma once 
#include <Blocker_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Blocker.Blocker_C
// Size: 0x551(Inherited: 0x528) 
struct UBlocker_C : public UKSWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x528(0x8)
	struct UButton* Closer;  // 0x530(0x8)
	struct UImage* Image_1;  // 0x538(0x8)
	struct UPUMG_UnsafeZone* PUMG_UnsafeZone_1;  // 0x540(0x8)
	struct UPUMG_Widget* Target;  // 0x548(0x8)
	char pad_1360_1 : 7;  // 0x550(0x1)
	bool ClickToClose : 1;  // 0x550(0x1)

	void BndEvt__Closer_K2Node_ComponentBoundEvent_10_OnButtonClickedEvent__DelegateSignature(); // Function Blocker.Blocker_C.BndEvt__Closer_K2Node_ComponentBoundEvent_10_OnButtonClickedEvent__DelegateSignature
	void Bind(struct UPUMG_Widget* Widget, bool ClickToClose); // Function Blocker.Blocker_C.Bind
	void InitializeWidget(struct APUMG_HUD* HUD); // Function Blocker.Blocker_C.InitializeWidget
	void HandleBlockerChange(bool Show, struct UUserWidget* InWidget); // Function Blocker.Blocker_C.HandleBlockerChange
	void ExecuteUbergraph_Blocker(int32_t EntryPoint); // Function Blocker.Blocker_C.ExecuteUbergraph_Blocker
}; 



