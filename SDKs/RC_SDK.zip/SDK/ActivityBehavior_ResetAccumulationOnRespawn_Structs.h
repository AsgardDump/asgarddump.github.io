#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.ExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRespawn
// Size: 0x51(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_ResetAccumulationOnRespawn
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AKSPlayerState* K2Node_CustomEvent_PlayerState;  // 0x28(0x8)
	struct AKSCharacterBase* K2Node_CustomEvent_Character;  // 0x30(0x8)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x38(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x50(0x1)

}; 
// Function ActivityBehavior_ResetAccumulationOnRespawn.ActivityBehavior_ResetAccumulationOnRespawn_C.HandlePlayerRespawned
// Size: 0x10(Inherited: 0x0) 
struct FHandlePlayerRespawned
{
	struct AKSPlayerState* PlayerState;  // 0x0(0x8)
	struct AKSCharacterBase* Character;  // 0x8(0x8)

}; 
