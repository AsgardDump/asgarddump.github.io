#pragma once 
#include <EventTracker_TotalCashEArned_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C
// Size: 0x1D0(Inherited: 0x1C0) 
struct UEventTracker_TotalCashEarned_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t PreviousValue;  // 0x1C8(0x4)
	int32_t InitialCash;  // 0x1CC(0x4)

	void HandleTrackerInitialized(); // Function EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C.HandleTrackerInitialized
	void HandleCashEarned(int32_t Money, int32_t Delta); // Function EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C.HandleCashEarned
	void HandlePhaseChanged(struct FMatchPhase NewPhase, struct FMatchPhase PreviousPhase); // Function EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C.HandlePhaseChanged
	void ExecuteUbergraph_EventTracker_TotalCashEarned(int32_t EntryPoint); // Function EventTracker_TotalCashEArned.EventTracker_TotalCashEarned_C.ExecuteUbergraph_EventTracker_TotalCashEarned
}; 



