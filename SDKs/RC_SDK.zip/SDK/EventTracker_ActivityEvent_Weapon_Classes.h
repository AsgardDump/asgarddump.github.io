#pragma once 
#include <EventTracker_ActivityEvent_Weapon_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_ActivityEvent_Weapon.EventTracker_ActivityEvent_Weapon_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_ActivityEvent_Weapon_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_ActivityEvent_Weapon.EventTracker_ActivityEvent_Weapon_C.HandleTrackerInitialized
	void HandleWeaponActivityEventTriggered(struct FGameplayTag ActivityEventType, struct AKSWeapon* Weapon); // Function EventTracker_ActivityEvent_Weapon.EventTracker_ActivityEvent_Weapon_C.HandleWeaponActivityEventTriggered
	void ExecuteUbergraph_EventTracker_ActivityEvent_Weapon(int32_t EntryPoint); // Function EventTracker_ActivityEvent_Weapon.EventTracker_ActivityEvent_Weapon_C.ExecuteUbergraph_EventTracker_ActivityEvent_Weapon
}; 



