#pragma once 
#include <FavoriteLobbyCharacter_Structs.h>
 
 
 
// BlueprintGeneratedClass FavoriteLobbyCharacter.FavoriteLobbyCharacter_C
// Size: 0x3F98(Inherited: 0x3F74) 
struct AFavoriteLobbyCharacter_C : public ALobbyMainCharacter_C
{
	char pad_16244[4];  // 0x3F74(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F78(0x8)
	struct UWidgetComponent* WidgetNameplate;  // 0x3F80(0x8)
	char pad_16264_1 : 7;  // 0x3F88(0x1)
	bool NeedsToSetNameplate : 1;  // 0x3F88(0x1)
	char pad_16265[7];  // 0x3F89(0x7)
	struct UKSPlayerInfo* PendingPlayerInfo;  // 0x3F90(0x8)

	void SetLobbyNameplate(struct UKSPlayerInfo* playerinfo); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.SetLobbyNameplate
	void HideLobbyNameplate(); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.HideLobbyNameplate
	void ShowLobbyNameplate(); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ShowLobbyNameplate
	void ReceiveTick(float DeltaSeconds); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ReceiveTick
	void ExecuteUbergraph_FavoriteLobbyCharacter(int32_t EntryPoint); // Function FavoriteLobbyCharacter.FavoriteLobbyCharacter_C.ExecuteUbergraph_FavoriteLobbyCharacter
}; 



