#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct CosmeticSlotDetails.CosmeticSlotDetails
// Size: 0x18(Inherited: 0x0) 
struct FCosmeticSlotDetails
{
	struct UPlatformInventoryItem* CosmeticItem_15_B7D9C0A442E79C8543A25E851BA3CD93;  // 0x0(0x8)
	struct UKSJobItem* AssociatedJobItem_5_C4CDDC7E47E0690DC2FACCA2B2E68A1B;  // 0x8(0x8)
	uint8_t  MercCosmeticSlot_8_2915050748C9085E1DD7BC8F113D7A53;  // 0x10(0x1)
	uint8_t  WeaponSlot_11_B5AA9D88414CFC0B28DE789456A68BDD;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t SlotPosition_14_A7CCEA944C2A098D2B251C884A3D7FC0;  // 0x14(0x4)

}; 
