#pragma once 
#include "SDK.h" 
 
 
// Function FirstTimeTutorialRedirector.FirstTimeTutorialRedirector_C.DoesLocalSettingApply
// Size: 0xB(Inherited: 0x10) 
struct FDoesLocalSettingApply : public FDoesLocalSettingApply
{
	struct APUMG_HUD* HUD;  // 0x0(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsPlatformType_ReturnValue : 1;  // 0x9(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xA(0x1)

}; 
