#pragma once 
#include "SDK.h" 
 
 
// Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.ExecuteUbergraph_EventTracker_Purchase_CashSpent
// Size: 0x94(Inherited: 0x0) 
struct FExecuteUbergraph_EventTracker_Purchase_CashSpent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSGameMode* CallFunc_GetGameMode_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x34(0x10)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x48(0x8)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x50(0x8)
	struct UKSGameShopItemComponent* K2Node_CustomEvent_ShopItemComponent_2;  // 0x58(0x8)
	struct UKSItem* CallFunc_GetCurrentItem_ReturnValue;  // 0x60(0x8)
	int32_t CallFunc_GetCurrentPrice_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_IsShopPurchaseConditionMet_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct UKSGameShopItemComponent* K2Node_CustomEvent_ShopItemComponent;  // 0x78(0x8)
	struct UKSItem* CallFunc_GetNextItem_ReturnValue;  // 0x80(0x8)
	int32_t CallFunc_GetNextPrice_ReturnValue;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_IsShopPurchaseConditionMet_ReturnValue_2 : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x90(0x4)

}; 
// Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.OnShopItemPurchased
// Size: 0x8(Inherited: 0x0) 
struct FOnShopItemPurchased
{
	struct UKSGameShopItemComponent* ShopItemComponent;  // 0x0(0x8)

}; 
// Function EventTracker_Purchase_CashSpent.EventTracker_Purchase_CashSpent_C.OnShopItemRefunded
// Size: 0x8(Inherited: 0x0) 
struct FOnShopItemRefunded
{
	struct UKSGameShopItemComponent* ShopItemComponent;  // 0x0(0x8)

}; 
