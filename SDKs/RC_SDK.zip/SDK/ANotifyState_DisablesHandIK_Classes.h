#pragma once 
#include <ANotifyState_DisablesHandIK_Structs.h>
 
 
 
// BlueprintGeneratedClass ANotifyState_DisablesHandIK.ANotifyState_DisablesHandIK_C
// Size: 0x34(Inherited: 0x30) 
struct UANotifyState_DisablesHandIK_C : public UAnimNotifyState
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool LeftHand Disable : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool RightHand Disable : 1;  // 0x31(0x1)
	char ESpeed Left Hand IK Blend Speed;  // 0x32(0x1)
	char ESpeed Right Hand IK Blend Speed;  // 0x33(0x1)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function ANotifyState_DisablesHandIK.ANotifyState_DisablesHandIK_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function ANotifyState_DisablesHandIK.ANotifyState_DisablesHandIK_C.Received_NotifyBegin
}; 



