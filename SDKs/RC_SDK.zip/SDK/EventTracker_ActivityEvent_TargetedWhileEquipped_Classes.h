#pragma once 
#include <EventTracker_ActivityEvent_TargetedWhileEquipped_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_ActivityEvent_TargetedWhileEquipped.EventTracker_ActivityEvent_TargetedWhileEquipped_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_ActivityEvent_TargetedWhileEquipped_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_ActivityEvent_TargetedWhileEquipped.EventTracker_ActivityEvent_TargetedWhileEquipped_C.HandleTrackerInitialized
	void HandleTargetedActivityEventTriggered(struct FGameplayTag ActivityEventType, struct AKSCharacterFoundation* TargetCharacter); // Function EventTracker_ActivityEvent_TargetedWhileEquipped.EventTracker_ActivityEvent_TargetedWhileEquipped_C.HandleTargetedActivityEventTriggered
	void ExecuteUbergraph_EventTracker_ActivityEvent_TargetedWhileEquipped(int32_t EntryPoint); // Function EventTracker_ActivityEvent_TargetedWhileEquipped.EventTracker_ActivityEvent_TargetedWhileEquipped_C.ExecuteUbergraph_EventTracker_ActivityEvent_TargetedWhileEquipped
}; 



