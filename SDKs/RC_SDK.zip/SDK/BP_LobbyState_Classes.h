#pragma once 
#include <BP_LobbyState_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LobbyState.BP_LobbyState_C
// Size: 0x2A8(Inherited: 0x290) 
struct ABP_LobbyState_C : public AGameState
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x298(0x8)
	struct AKSEmoteMusicManager* EmoteMusicManager;  // 0x2A0(0x8)

	struct AKSEmoteMusicManager* GetEmoteMusicManager(); // Function BP_LobbyState.BP_LobbyState_C.GetEmoteMusicManager
	void ReceiveBeginPlay(); // Function BP_LobbyState.BP_LobbyState_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_LobbyState(int32_t EntryPoint); // Function BP_LobbyState.BP_LobbyState_C.ExecuteUbergraph_BP_LobbyState
}; 



