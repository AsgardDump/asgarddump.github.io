#pragma once 
#include "SDK.h" 
 
 
// Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.Received_NotifyBegin
// Size: 0x16(Inherited: 0xB5) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool CallFunc_Received_NotifyBegin_ReturnValue : 1;  // 0x15(0x1)

}; 
// Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.Received_NotifyEnd
// Size: 0x12(Inherited: 0xCC) 
struct FReceived_NotifyEnd : public FReceived_NotifyEnd
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_221_1 : 7;  // 0xDD(0x1)
	bool CallFunc_Received_NotifyEnd_ReturnValue : 1;  // 0x11(0x1)

}; 
// Function ANotifyState_SFXTeamPerspectiveAKEvent.ANotifyState_SFXTeamPerspectiveAKEvent_C.SetTeamPerspective
// Size: 0x58(Inherited: 0x0) 
struct FSetTeamPerspective
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct FName Temp_name_Variable;  // 0x8(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	struct AKSCharacter* K2Node_DynamicCast_AsKSCharacter;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FName Temp_name_Variable_2;  // 0x24(0x8)
	uint8_t  CallFunc_IsFriendlyWithLocalPlayer_ReturnValue;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_IsLocallyViewed_ReturnValue : 1;  // 0x2E(0x1)
	char pad_47[1];  // 0x2F(0x1)
	struct FName Temp_name_Variable_3;  // 0x30(0x8)
	struct FName Temp_name_Variable_4;  // 0x38(0x8)
	struct FName Temp_name_Variable_5;  // 0x40(0x8)
	struct FName Temp_name_Variable_6;  // 0x48(0x8)
	struct FName Temp_name_Variable_7;  // 0x50(0x8)

}; 
