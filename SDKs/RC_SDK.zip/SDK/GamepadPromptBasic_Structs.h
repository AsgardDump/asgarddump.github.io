#pragma once 
#include "SDK.h" 
 
 
// Function GamepadPromptBasic.GamepadPromptBasic_C.ExecuteUbergraph_GamepadPromptBasic
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_GamepadPromptBasic
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function GamepadPromptBasic.GamepadPromptBasic_C.SetPrompt
// Size: 0x30(Inherited: 0x0) 
struct FSetPrompt
{
	struct FButtonPromptData Data;  // 0x0(0x30)

}; 
