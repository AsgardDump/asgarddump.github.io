#pragma once 
#include <HiRezAutomation_Structs.h>
 
 
 
// Class HiRezAutomation.PerfSpline
// Size: 0x2D0(Inherited: 0x220) 
struct APerfSpline : public AActor
{
	struct USplineComponent* SplineCamPosComponent;  // 0x220(0x8)
	struct AActor* CamComponent;  // 0x228(0x8)
	struct USplineComponent* SplineCamLookAtComponent;  // 0x230(0x8)
	float SplineDuration;  // 0x238(0x4)
	int32_t NumOfCaptures;  // 0x23C(0x4)
	char pad_576[144];  // 0x240(0x90)

	void InitPerfMovementAndCapture(); // Function HiRezAutomation.PerfSpline.InitPerfMovementAndCapture
	void CaptureStats(); // Function HiRezAutomation.PerfSpline.CaptureStats
}; 



// Class HiRezAutomation.PerfCharacter
// Size: 0x230(Inherited: 0x220) 
struct APerfCharacter : public AActor
{
	struct TArray<struct FString> SkinNames;  // 0x220(0x10)

	void SpawnCharacters(int32_t NumCharacter); // Function HiRezAutomation.PerfCharacter.SpawnCharacters
	void SetSkin(int32_t Index); // Function HiRezAutomation.PerfCharacter.SetSkin
	void LoadSkins(); // Function HiRezAutomation.PerfCharacter.LoadSkins
	void LoadCharacters(struct FString CharactersToTest, struct TArray<struct FString>& LogToPrint); // Function HiRezAutomation.PerfCharacter.LoadCharacters
	void GetCharacterName(struct FString SkinName, struct FString& CharacterName); // Function HiRezAutomation.PerfCharacter.GetCharacterName
}; 



// Class HiRezAutomation.PGame_PerformanceCaptureSettings
// Size: 0x90(Inherited: 0x28) 
struct UPGame_PerformanceCaptureSettings : public UObject
{
	float FOV;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct FName> StatsForAll;  // 0x30(0x10)
	struct TArray<struct FName> StatsForMap;  // 0x40(0x10)
	struct TArray<struct FName> StatsForCharacter;  // 0x50(0x10)
	struct TArray<struct FString> MapsToProfile;  // 0x60(0x10)
	float StartingOffsetTime;  // 0x70(0x4)
	int32_t NumberOfSamples;  // 0x74(0x4)
	float TimeBetweenSamples;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct TArray<struct FPGame_PerformanceCaptureProfile> Profiles;  // 0x80(0x10)

}; 



