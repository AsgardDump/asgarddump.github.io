#pragma once 
#include <EventTracker_EndOfMatch_Streak_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_EndOfMatch_Streak.EventTracker_EndOfMatch_Streak_C
// Size: 0x1C8(Inherited: 0x1C0) 
struct UEventTracker_EndOfMatch_Streak_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)

	void HandleTrackerInitialized(); // Function EventTracker_EndOfMatch_Streak.EventTracker_EndOfMatch_Streak_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_EndOfMatch_Streak.EventTracker_EndOfMatch_Streak_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_EndOfMatch_Streak(int32_t EntryPoint); // Function EventTracker_EndOfMatch_Streak.EventTracker_EndOfMatch_Streak_C.ExecuteUbergraph_EventTracker_EndOfMatch_Streak
}; 



