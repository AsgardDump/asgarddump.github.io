#pragma once 
#include <EventTracker_TotalScoreEarned_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C
// Size: 0x1CC(Inherited: 0x1C0) 
struct UEventTracker_TotalScoreEarned_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	int32_t PreviousValue;  // 0x1C8(0x4)

	void HandleTrackerInitialized(); // Function EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C.HandleTrackerInitialized
	void HandleScoreEarned(int32_t Money, struct FText Reason); // Function EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C.HandleScoreEarned
	void HandlePhaseChanged(struct FMatchPhase NewPhase, struct FMatchPhase PreviousPhase); // Function EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C.HandlePhaseChanged
	void ExecuteUbergraph_EventTracker_TotalScoreEarned(int32_t EntryPoint); // Function EventTracker_TotalScoreEarned.EventTracker_TotalScoreEarned_C.ExecuteUbergraph_EventTracker_TotalScoreEarned
}; 



