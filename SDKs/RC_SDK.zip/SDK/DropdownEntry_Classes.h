#pragma once 
#include <DropdownEntry_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DropdownEntry.DropdownEntry_C
// Size: 0x5A8(Inherited: 0x528) 
struct UDropdownEntry_C : public UKSWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x528(0x8)
	struct UWidgetAnimation* Hover;  // 0x530(0x8)
	struct UImage* Color_Swatch_Brush;  // 0x538(0x8)
	struct UButton* HitTarget;  // 0x540(0x8)
	struct UTextBlock* OptionText;  // 0x548(0x8)
	struct UImage* Selected;  // 0x550(0x8)
	struct FText Text;  // 0x558(0x18)
	int32_t Index;  // 0x570(0x4)
	char pad_1396[4];  // 0x574(0x4)
	struct FMulticastInlineDelegate OnOptionSelected;  // 0x578(0x10)
	struct FMulticastInlineDelegate OnOptionHovered;  // 0x588(0x10)
	struct UAkAudioEvent* HoverDropdownEntrySFX;  // 0x598(0x8)
	struct UAkAudioEvent* ClickDropdownEntrySFX;  // 0x5A0(0x8)

	bool NavigateConfirm(); // Function DropdownEntry.DropdownEntry_C.NavigateConfirm
	void Construct(); // Function DropdownEntry.DropdownEntry_C.Construct
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function DropdownEntry.DropdownEntry_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature(); // Function DropdownEntry.DropdownEntry_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_6_OnButtonHoverEvent__DelegateSignature
	void BndEvt__HitTarget_K2Node_ComponentBoundEvent_7_OnButtonHoverEvent__DelegateSignature(); // Function DropdownEntry.DropdownEntry_C.BndEvt__HitTarget_K2Node_ComponentBoundEvent_7_OnButtonHoverEvent__DelegateSignature
	void GamepadHover(); // Function DropdownEntry.DropdownEntry_C.GamepadHover
	void GamepadUnhover(); // Function DropdownEntry.DropdownEntry_C.GamepadUnhover
	void GamepadConfirm(); // Function DropdownEntry.DropdownEntry_C.GamepadConfirm
	void ChangeSelectionState(bool Selected); // Function DropdownEntry.DropdownEntry_C.ChangeSelectionState
	void ExecuteUbergraph_DropdownEntry(int32_t EntryPoint); // Function DropdownEntry.DropdownEntry_C.ExecuteUbergraph_DropdownEntry
	void OnOptionHovered__DelegateSignature(struct UWidget* Widget, int32_t Index); // Function DropdownEntry.DropdownEntry_C.OnOptionHovered__DelegateSignature
	void OnOptionSelected__DelegateSignature(int32_t Index, struct FText Text); // Function DropdownEntry.DropdownEntry_C.OnOptionSelected__DelegateSignature
}; 



