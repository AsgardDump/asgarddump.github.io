#pragma once 
#include "SDK.h" 
 
 
// Function ActivityBehavior_SetValueOnMultiDownAchieved.ActivityBehavior_SetValueOnMultiDownAchieved_C.ExecuteUbergraph_ActivityBehavior_SetValueOnMultiDownAchieved
// Size: 0x32(Inherited: 0x0) 
struct FExecuteUbergraph_ActivityBehavior_SetValueOnMultiDownAchieved
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	int32_t K2Node_CustomEvent_DownCount;  // 0x24(0x4)
	struct AKSPlayerState* CallFunc_GetPlayerState_ReturnValue_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x31(0x1)

}; 
// Function ActivityBehavior_SetValueOnMultiDownAchieved.ActivityBehavior_SetValueOnMultiDownAchieved_C.HandleMultiDownAchieved
// Size: 0x4(Inherited: 0x0) 
struct FHandleMultiDownAchieved
{
	int32_t DownCount;  // 0x0(0x4)

}; 
