#pragma once 
#include <AppsFlyerSDK_Structs.h>
 
 
 
// Class AppsFlyerSDK.AppsFlyerSDKBlueprint
// Size: 0x28(Inherited: 0x28) 
struct UAppsFlyerSDKBlueprint : public UBlueprintFunctionLibrary
{

	void waitForATTUserAuthorizationWithTimeoutInterval(int32_t timeoutInterval); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.waitForATTUserAuthorizationWithTimeoutInterval
	void start(); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.start
	void setRemoteNotificationsToken(struct TArray<char>& Token); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.setRemoteNotificationsToken
	void setCustomerUserId(struct FString customerUserId); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.setCustomerUserId
	void setAdditionalData(struct TMap<struct FString, struct FString> customData); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.setAdditionalData
	void logEvent(struct FString EventName, struct TMap<struct FString, struct FString> Values); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.logEvent
	struct FString getAppsFlyerUID(); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.getAppsFlyerUID
	struct FString advertisingIdentifier(); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.advertisingIdentifier
}; 



// Class AppsFlyerSDK.AppsFlyerSDKCallbacks
// Size: 0xF0(Inherited: 0xB0) 
struct UAppsFlyerSDKCallbacks : public UActorComponent
{
	struct FMulticastInlineDelegate OnAppOpenAttribution;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnConversionDataReceived;  // 0xC0(0x10)
	struct FMulticastInlineDelegate OnAppOpenAttributionFailure;  // 0xD0(0x10)
	struct FMulticastInlineDelegate OnConversionDataRequestFailure;  // 0xE0(0x10)

}; 



// Class AppsFlyerSDK.AppsFlyerSDKSettings
// Size: 0x68(Inherited: 0x28) 
struct UAppsFlyerSDKSettings : public UObject
{
	struct FString appsFlyerDevKey;  // 0x28(0x10)
	struct FString appleAppID;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bIsDebug : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString CurrencyCode;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bDisableSKAdNetwork : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool bEnableAutoStart : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)

}; 



