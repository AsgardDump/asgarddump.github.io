#pragma once 
#include <D40C_CameraShake_3P_Structs.h>
 
 
 
// BlueprintGeneratedClass D40C_CameraShake_3P.D40C_CameraShake_3P_C
// Size: 0x160(Inherited: 0x160) 
struct UD40C_CameraShake_3P_C : public UCameraShake
{

}; 



