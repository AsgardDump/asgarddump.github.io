#pragma once 
#include <ClaymoreProjectile_DamageType_Structs.h>
 
 
 
// BlueprintGeneratedClass ClaymoreProjectile_DamageType.ClaymoreProjectile_DamageType_C
// Size: 0x140(Inherited: 0x140) 
struct UClaymoreProjectile_DamageType_C : public UMasterMelee_DamageType_C
{

}; 



