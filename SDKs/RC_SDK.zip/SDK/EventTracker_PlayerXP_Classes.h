#pragma once 
#include <EventTracker_PlayerXP_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_PlayerXP.EventTracker_PlayerXP_C
// Size: 0x1F8(Inherited: 0x1C0) 
struct UEventTracker_PlayerXP_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	float BaseProgress;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct AKSPlayerState* PlayerState;  // 0x1D0(0x8)
	float AccumulatedProgress;  // 0x1D8(0x4)
	float XpPerMinute;  // 0x1DC(0x4)
	float PremiumBoostMultiplier;  // 0x1E0(0x4)
	float WinMultiplier;  // 0x1E4(0x4)
	struct FString BonusKey;  // 0x1E8(0x10)

	void ProcessEventBonuses(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessEventBonuses
	void IsWinningTeam(bool& IsWinningTeam); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.IsWinningTeam
	void ProcessWinBonus(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessWinBonus
	void ProcessQueueBonus(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessQueueBonus
	void ProcessBoosterBonuses(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ProcessBoosterBonuses
	void ComputeBaseProgess(float& OutProgress); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ComputeBaseProgess
	void HandleTrackerInitialized(); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.HandleTrackerInitialized
	void MatchHasEnded_Event(); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.MatchHasEnded_Event
	void ExecuteUbergraph_EventTracker_PlayerXP(int32_t EntryPoint); // Function EventTracker_PlayerXP.EventTracker_PlayerXP_C.ExecuteUbergraph_EventTracker_PlayerXP
}; 



