#pragma once 
#include <EventTracker_MultiDowns_Structs.h>
 
 
 
// BlueprintGeneratedClass EventTracker_MultiDowns.EventTracker_MultiDowns_C
// Size: 0x1C9(Inherited: 0x1C0) 
struct UEventTracker_MultiDowns_C : public UKSEventTracker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1C0(0x8)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool IsConditionMet : 1;  // 0x1C8(0x1)

	void HandleTrackerInitialized(); // Function EventTracker_MultiDowns.EventTracker_MultiDowns_C.HandleTrackerInitialized
	void MultiDownAchieved(int32_t DownCount, struct FCombatEventInfoContainer CombatEventContainer); // Function EventTracker_MultiDowns.EventTracker_MultiDowns_C.MultiDownAchieved
	void ExecuteUbergraph_EventTracker_MultiDowns(int32_t EntryPoint); // Function EventTracker_MultiDowns.EventTracker_MultiDowns_C.ExecuteUbergraph_EventTracker_MultiDowns
}; 



