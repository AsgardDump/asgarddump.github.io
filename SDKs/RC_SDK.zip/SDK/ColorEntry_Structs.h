#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ColorEntry.ColorEntry
// Size: 0x28(Inherited: 0x0) 
struct FColorEntry
{
	struct FSlateColor Color_5_95A3887F414F0B9F0A5AB59D355DA568;  // 0x0(0x28)

}; 
