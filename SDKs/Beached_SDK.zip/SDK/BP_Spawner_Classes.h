#pragma once 
#include <BP_Spawner_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Spawner.BP_Spawner_C
// Size: 0x240(Inherited: 0x220) 
struct ABP_Spawner_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	AActor* Enemy;  // 0x230(0x8)
	struct AActor* Spawned Actor;  // 0x238(0x8)

	void Spawn(struct ABP_EnemyCamp_C* Enemy Camp); // Function BP_Spawner.BP_Spawner_C.Spawn
	void ExecuteUbergraph_BP_Spawner(int32_t EntryPoint); // Function BP_Spawner.BP_Spawner_C.ExecuteUbergraph_BP_Spawner
}; 



