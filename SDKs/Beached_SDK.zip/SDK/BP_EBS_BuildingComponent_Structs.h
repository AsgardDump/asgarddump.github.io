#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRemove
// Size: 0x1A(Inherited: 0x0) 
struct FTryRemove
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* LocalBuildingObject;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_CompleteRemove_Success : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingCompleted__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnBuildingCompleted__DelegateSignature
{
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x0(0x8)
	struct AActor* TargetActor;  // 0x8(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingInteractionCompleted__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnBuildingInteractionCompleted__DelegateSignature
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x8(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingModeChanged__DelegateSignature
// Size: 0x2(Inherited: 0x0) 
struct FOnBuildingModeChanged__DelegateSignature
{
	char E_EBS_BuildingMode NewBuildingMode;  // 0x0(0x1)
	char E_EBS_BuildingMode PrevBuildingMode;  // 0x1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnUpgradingCompleted__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnUpgradingCompleted__DelegateSignature
{
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeMaxTraceDistance
// Size: 0x18(Inherited: 0x0) 
struct FChangeMaxTraceDistance
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	float K2Node_Select_Default;  // 0x14(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingMessageReceived__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnBuildingMessageReceived__DelegateSignature
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool InteractionResult : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FText Message;  // 0x8(0x18)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnRepairingCompleted__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnRepairingCompleted__DelegateSignature
{
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnRemovingCompleted__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnRemovingCompleted__DelegateSignature
{
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeTopDownViewMode
// Size: 0x5(Inherited: 0x0) 
struct FChangeTopDownViewMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool TopDownViewMode : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool TraceToMouseMode : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Success : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_UpdateFloorActorsVisibility_Success : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_ResetFloorActorsVisibility_Success : 1;  // 0x4(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnDestructionCompleted__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnDestructionCompleted__DelegateSignature
{
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnRotationCompleted__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnRotationCompleted__DelegateSignature
{
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetCorrectHitLocation
// Size: 0x34(Inherited: 0x0) 
struct FGetCorrectHitLocation
{
	struct FVector HitLocation;  // 0x0(0xC)
	struct FVector ReturnLocation;  // 0xC(0xC)
	float CallFunc_BreakVector_X;  // 0x18(0x4)
	float CallFunc_BreakVector_Y;  // 0x1C(0x4)
	float CallFunc_BreakVector_Z;  // 0x20(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x24(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x28(0xC)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnTargetActorChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnTargetActorChanged__DelegateSignature
{
	struct AActor* TargetActor;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRepair
// Size: 0x1B(Inherited: 0x0) 
struct FTryRepair
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* LocalBuildingObject;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_CompleteRepair_Success : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_CheckRepair_Result : 1;  // 0x1A(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnTargetBuildingObjectChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnTargetBuildingObjectChanged__DelegateSignature
{
	struct ABP_EBS_Building_BaseObject_C* TargetBuildingObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildingList
// Size: 0x29(Inherited: 0x0) 
struct FUpdateBuildingList
{
	struct FDataTableRowHandle BuildingListHandle;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.FinishBuild (Server)
// Size: 0x58(Inherited: 0x0) 
struct FFinishBuild (Server)
{
	ABP_EBS_Building_BaseObject_C* BuildingObjectClass;  // 0x0(0x8)
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform BuildingTransform;  // 0x20(0x30)
	struct AActor* TargetActor;  // 0x50(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ExecuteUbergraph_BP_EBS_BuildingComponent
// Size: 0x138(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_BuildingComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	UUserWidget* K2Node_CustomEvent_BuildingWidgetClass;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_ChangeBuildingWidget_Success : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_TryBuild_Success : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	ABP_EBS_Building_BaseObject_C* K2Node_CustomEvent_BuildingObjectClass;  // 0x18(0x8)
	struct FDataTableRowHandle K2Node_CustomEvent_BuildingObjectHandle_3;  // 0x20(0x10)
	struct FTransform K2Node_CustomEvent_BuildingTransform;  // 0x30(0x30)
	struct AActor* K2Node_CustomEvent_TargetActor;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_FinishBuild_Success : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_CustomEvent_TargetObject_5;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_TryRemove_Success : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_CustomEvent_TargetObject_4;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_TryDestruct_Success : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_CustomEvent_TargetObject_3;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_TryUpgrade_Success : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FText CallFunc_TryUpgrade_Message;  // 0xA0(0x18)
	struct ABP_EBS_Building_BaseObject_C* K2Node_CustomEvent_TargetObject_2;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_TryRotate_Success : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_CustomEvent_TargetObject;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_TryRepair_Success : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool CallFunc_UpdateProcess_Success : 1;  // 0xD1(0x1)
	char pad_210_1 : 7;  // 0xD2(0x1)
	bool CallFunc_ShowBuildingMenu_Success : 1;  // 0xD2(0x1)
	char pad_211_1 : 7;  // 0xD3(0x1)
	bool CallFunc_HideBuildingMenu_Success : 1;  // 0xD3(0x1)
	char pad_212[4];  // 0xD4(0x4)
	struct FDataTableRowHandle K2Node_CustomEvent_BuildingListHandle;  // 0xD8(0x10)
	char E_EBS_BuildingMode K2Node_CustomEvent_BuildingMode_2;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_UpdateBuildingList_Success : 1;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool CallFunc_ChangeBuildingMode_Success : 1;  // 0xEA(0x1)
	char E_EBS_BuildingMode K2Node_CustomEvent_BuildingMode;  // 0xEB(0x1)
	char pad_236_1 : 7;  // 0xEC(0x1)
	bool K2Node_CustomEvent_InteractionResult : 1;  // 0xEC(0x1)
	char pad_237[3];  // 0xED(0x3)
	struct FText K2Node_CustomEvent_Message;  // 0xF0(0x18)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_AutoInitComponent_Success : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_SendBuildingMessage_Success : 1;  // 0x109(0x1)
	char pad_266_1 : 7;  // 0x10A(0x1)
	bool CallFunc_CancelBuild_Success : 1;  // 0x10A(0x1)
	char pad_267[5];  // 0x10B(0x5)
	struct FDataTableRowHandle K2Node_CustomEvent_BuildingObjectHandle_2;  // 0x110(0x10)
	struct FDataTableRowHandle K2Node_CustomEvent_BuildingObjectHandle;  // 0x120(0x10)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_StartBuildObject_Success : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_TryStartBuildObject_Success : 1;  // 0x131(0x1)
	char pad_306[2];  // 0x132(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x134(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingWidget (Client)
// Size: 0x8(Inherited: 0x0) 
struct FChangeBuildingWidget (Client)
{
	UUserWidget* BuildingWidgetClass;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateProcess
// Size: 0xA2(Inherited: 0x0) 
struct FUpdateProcess
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_PrintDebugInformation_Success : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FHitResult CallFunc_GetTraceHitResult_HitResult;  // 0x4(0x8C)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_UpdateTargetActor_Success : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct AActor* CallFunc_UpdateTargetActor_TargetActor;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_UpdateBuildingPosition_Success : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xA1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetTargetBuildingObject
// Size: 0x22(Inherited: 0x0) 
struct FSetTargetBuildingObject
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* LocalBuildingObject;  // 0x10(0x8)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryStartBuildObject (Server)
// Size: 0x10(Inherited: 0x0) 
struct FTryStartBuildObject (Server)
{
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x0(0x10)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.StartBuildObject (Client)
// Size: 0x10(Inherited: 0x0) 
struct FStartBuildObject (Client)
{
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x0(0x10)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryUpgrade (Server)
// Size: 0x8(Inherited: 0x0) 
struct FTryUpgrade (Server)
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SendBuildingMessage (Client)
// Size: 0x20(Inherited: 0x0) 
struct FSendBuildingMessage (Client)
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool InteractionResult : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FText Message;  // 0x8(0x18)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingMode (Client)
// Size: 0x1(Inherited: 0x0) 
struct FSetBuildingMode (Client)
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildingList (Client)
// Size: 0x10(Inherited: 0x0) 
struct FUpdateBuildingList (Client)
{
	struct FDataTableRowHandle BuildingListHandle;  // 0x0(0x10)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRepair (Server)
// Size: 0x8(Inherited: 0x0) 
struct FTryRepair (Server)
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetCorrectBuildingRotation
// Size: 0x40(Inherited: 0x0) 
struct FGetCorrectBuildingRotation
{
	struct FRotator Rotation;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FRotator CallFunc_GetCameraRotation_ReturnValue;  // 0x10(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x20(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x24(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x28(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x2C(0x4)
	float K2Node_Select_Default;  // 0x30(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x34(0xC)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CancelBuild
// Size: 0x2(Inherited: 0x0) 
struct FCancelBuild
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_ChangeBuildingMode_Success : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRotate (Server)
// Size: 0x8(Inherited: 0x0) 
struct FTryRotate (Server)
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeDisplayedFloor
// Size: 0x24(Inherited: 0x0) 
struct FChangeDisplayedFloor
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool UpdateVisibility : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Success : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool LocalUpdateVisibility : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool Temp_bool_Variable : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_UpdateFloorActorsVisibility_Success : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xD(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t K2Node_Select_Default;  // 0x18(0x4)
	int32_t K2Node_Select_Default_2;  // 0x1C(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.FinishBuild
// Size: 0xE9(Inherited: 0x0) 
struct FFinishBuild
{
	ABP_EBS_Building_BaseObject_C* BuildingObjectClass;  // 0x0(0x8)
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform BuildingTransform;  // 0x20(0x30)
	struct AActor* TargetActor;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool Success : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct ABP_EBS_Building_BaseObject_C* LocalBuildingObject;  // 0x60(0x8)
	struct AActor* LocalTargetActor;  // 0x68(0x8)
	struct FTransform LocalTransform;  // 0x70(0x30)
	struct FDataTableRowHandle LocalBuildingObjectHandle;  // 0xA0(0x10)
	ABP_EBS_Building_BaseObject_C* LocalBuildingObjectClass;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_CompleteBuild_Success : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_CheckSupport_HasSupport : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_CompleteRemove_Success : 1;  // 0xBA(0x1)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool CallFunc_CompleteBuildingRequirements_Success : 1;  // 0xBB(0x1)
	char pad_188[4];  // 0xBC(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xC0(0x8)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xC8(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_CheckAndAttachToTarget_Success : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_CheckBuildStatus_CanBeBuilt : 1;  // 0xE8(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryDestruct (Server)
// Size: 0x8(Inherited: 0x0) 
struct FTryDestruct (Server)
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeNearSnappingMode
// Size: 0x2(Inherited: 0x0) 
struct FChangeNearSnappingMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NearSnappingMode : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRemove (Server)
// Size: 0x8(Inherited: 0x0) 
struct FTryRemove (Server)
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.InitComponent
// Size: 0x51(Inherited: 0x0) 
struct FInitComponent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_TryToCreateBuildingWidget_Success : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x40(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingRotationZ
// Size: 0x28(Inherited: 0x0) 
struct FChangeBuildingRotationZ
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x1C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x20(0x4)
	float K2Node_Select_Default;  // 0x24(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingObjectTransform
// Size: 0xC3(Inherited: 0x0) 
struct FSetBuildingObjectTransform
{
	struct FTransform NewTransform;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool TransformChanged : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FHitResult CallFunc_K2_SetActorTransform_SweepHitResult;  // 0x34(0x8C)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_K2_SetActorTransform_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_NearlyEqual_TransformTransform_ReturnValue : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC2(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingOffsetZ
// Size: 0x1C(Inherited: 0x0) 
struct FChangeBuildingOffsetZ
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	float K2Node_Select_Default;  // 0x14(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x18(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeMinBuildingOffsetZ
// Size: 0x18(Inherited: 0x0) 
struct FChangeMinBuildingOffsetZ
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	float K2Node_Select_Default;  // 0x14(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeMaxBuildingOffsetZ
// Size: 0x18(Inherited: 0x0) 
struct FChangeMaxBuildingOffsetZ
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	float K2Node_Select_Default;  // 0x14(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeTraceDistance
// Size: 0x1C(Inherited: 0x0) 
struct FChangeTraceDistance
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	float K2Node_Select_Default;  // 0x14(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x18(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CompleteBuildingRequirements
// Size: 0x12B(Inherited: 0x0) 
struct FCompleteBuildingRequirements
{
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FSTR_EBS_BuildingObjectSettings CallFunc_GetDataTableRowFromName_OutRow;  // 0x20(0xF0)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x118(0x10)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x128(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x129(0x1)
	char pad_298_1 : 7;  // 0x12A(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x12A(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeGridMode
// Size: 0x2(Inherited: 0x0) 
struct FChangeGridMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool GridMode : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingMode
// Size: 0x6(Inherited: 0x0) 
struct FChangeBuildingMode
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)
	char E_EBS_BuildingMode LocalPrevBuildingMode;  // 0x2(0x1)
	char E_EBS_BuildingMode LocalNewBuildingMode;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_DestroyBuildingObject_Success : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x5(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetPropTransform
// Size: 0x130(Inherited: 0x0) 
struct FGetPropTransform
{
	struct FVector HitLocation;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform Transform;  // 0x10(0x30)
	struct FVector LocalHitLocation;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool Temp_bool_Variable : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float CallFunc_BreakVector_X;  // 0x50(0x4)
	float CallFunc_BreakVector_Y;  // 0x54(0x4)
	float CallFunc_BreakVector_Z;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x5D(0x1)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x5E(0x1)
	char pad_95_1 : 7;  // 0x5F(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5F(0x1)
	float CallFunc_BreakVector_X_2;  // 0x60(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x64(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x68(0x4)
	struct FRotator CallFunc_GetCorrectBuildingRotation_Rotation;  // 0x6C(0xC)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x78(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x7C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x80(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x84(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0x88(0x4)
	int32_t CallFunc_Round_ReturnValue_2;  // 0x8C(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x90(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0x94(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x98(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x9C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0xA0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xA4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xA8(0xC)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct FRotator K2Node_Select_Default;  // 0xB8(0xC)
	float K2Node_Select_Default_2;  // 0xC4(0x4)
	float K2Node_Select_Default_3;  // 0xC8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xCC(0xC)
	float CallFunc_BreakVector_X_3;  // 0xD8(0x4)
	float CallFunc_BreakVector_Y_3;  // 0xDC(0x4)
	float CallFunc_BreakVector_Z_3;  // 0xE0(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0xE4(0xC)
	struct FVector K2Node_Select_Default_4;  // 0xF0(0xC)
	char pad_252[4];  // 0xFC(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x100(0x30)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetFoundationTransform
// Size: 0x150(Inherited: 0x0) 
struct FGetFoundationTransform
{
	struct FVector HitLocation;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform Transform;  // 0x10(0x30)
	struct FVector LocalHitLocation;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool Temp_bool_Variable : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float CallFunc_BreakVector_X;  // 0x50(0x4)
	float CallFunc_BreakVector_Y;  // 0x54(0x4)
	float CallFunc_BreakVector_Z;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x5D(0x1)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x5E(0x1)
	char pad_95[1];  // 0x5F(0x1)
	float CallFunc_BreakVector_X_2;  // 0x60(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x64(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x68(0x4)
	struct FRotator CallFunc_GetCorrectBuildingRotation_Rotation;  // 0x6C(0xC)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x78(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x7C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x80(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x84(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x88(0xC)
	struct FRotator K2Node_Select_Default;  // 0x94(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xA0(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0xA4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0xA8(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xAC(0x4)
	int32_t CallFunc_Round_ReturnValue_2;  // 0xB0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xB4(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0xB8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xBC(0x4)
	float K2Node_Select_Default_2;  // 0xC0(0x4)
	float K2Node_Select_Default_3;  // 0xC4(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xC8(0xC)
	float CallFunc_BreakVector_X_3;  // 0xD4(0x4)
	float CallFunc_BreakVector_Y_3;  // 0xD8(0x4)
	float CallFunc_BreakVector_Z_3;  // 0xDC(0x4)
	struct FVector CallFunc_GetCorrectHitLocation_ReturnLocation;  // 0xE0(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0xEC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0xF0(0x4)
	int32_t CallFunc_Round_ReturnValue_3;  // 0xF4(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_3;  // 0xF8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0xFC(0xC)
	struct FVector K2Node_Select_Default_4;  // 0x108(0xC)
	char pad_276[12];  // 0x114(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x120(0x30)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingObjectMaterials
// Size: 0x65(Inherited: 0x0) 
struct FSetBuildingObjectMaterials
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanBeBuilt : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UMaterialInterface* K2Node_Select_Default;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<struct UMeshComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x30(0x10)
	struct UMeshComponent* CallFunc_Array_Get_Item;  // 0x40(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x50(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x64(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateTargetActor
// Size: 0x11A(Inherited: 0x0) 
struct FUpdateTargetActor
{
	struct FHitResult HitResult;  // 0x0(0x8C)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool Success : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct AActor* TargetActor;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x9C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xA0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xA4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xB0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xBC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xC8(0xC)
	char pad_212[4];  // 0xD4(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xD8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xE0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0xE8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0xF0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0xF8(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xFC(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x100(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x10C(0xC)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_SetTargetActor_Success : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool CallFunc_SetTargetActor_Success_2 : 1;  // 0x119(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.StartBuildObject
// Size: 0x198(Inherited: 0x0) 
struct FStartBuildObject
{
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x20(0x30)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValidHandle_IsValid : 1;  // 0x50(0x1)
	char pad_81[15];  // 0x51(0xF)
	struct FSTR_EBS_BuildingObjectSettings CallFunc_GetDataTableRowFromName_OutRow;  // 0x60(0xF0)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_DestroyBuildingObject_Success : 1;  // 0x151(0x1)
	char pad_338_1 : 7;  // 0x152(0x1)
	bool CallFunc_ChangeBuildingMode_Success : 1;  // 0x152(0x1)
	char pad_339[5];  // 0x153(0x5)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x158(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0x160(0x30)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x190(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryBuild
// Size: 0xC(Inherited: 0x0) 
struct FTryBuild
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t LocalFloorNumber;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_ChangeBuildingMode_Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_ChangeDisplayedFloor_Success : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_DestroyBuildingObject_Success : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_SetFloorNumberByTargetActor_Success : 1;  // 0xB(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.DestroyBuildingObject
// Size: 0x2(Inherited: 0x0) 
struct FDestroyBuildingObject
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryDestruct
// Size: 0x1A(Inherited: 0x0) 
struct FTryDestruct
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* LocalBuildingObject;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_CompleteRemove_Success : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildStatus
// Size: 0x6(Inherited: 0x0) 
struct FUpdateBuildStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_CheckFloorNumber_Result : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_SetCanBeBuilt_Success : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_CheckBuildStatus_CanBeBuilt : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_CheckClaim_Result : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_SetCanBeBuilt_Success_2 : 1;  // 0x5(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetCanBeBuilt
// Size: 0x3(Inherited: 0x0) 
struct FSetCanBeBuilt
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanBeBuilt : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_SetBuildingObjectMaterials_Success : 1;  // 0x2(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryUpgrade
// Size: 0x33(Inherited: 0x0) 
struct FTryUpgrade
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FText Message;  // 0x10(0x18)
	struct ABP_EBS_Building_BaseObject_C* LocalBuildingObject;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_CompleteUpgrade_Success : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_CheckUpgrade_Success : 1;  // 0x32(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRotate
// Size: 0x1B(Inherited: 0x0) 
struct FTryRotate
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* LocalBuildingObject;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_CompleteRotate_Success : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_CheckRotate_Success : 1;  // 0x1A(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryToCreateBuildingWidget
// Size: 0x64(Inherited: 0x0) 
struct FTryToCreateBuildingWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget_2;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x34(0x4)
	struct UUserWidget* CallFunc_Create_ReturnValue;  // 0x38(0x8)
	struct TArray<struct UUserWidget*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x40(0x10)
	struct UUserWidget* CallFunc_Array_Get_Item;  // 0x50(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CheckBuildingRequirements
// Size: 0x12C(Inherited: 0x0) 
struct FCheckBuildingRequirements
{
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FSTR_EBS_BuildingObjectSettings CallFunc_GetDataTableRowFromName_OutRow;  // 0x20(0xF0)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x118(0x10)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x128(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x129(0x1)
	char pad_298_1 : 7;  // 0x12A(0x1)
	bool CallFunc_CheckRequirements_BPI_Success : 1;  // 0x12A(0x1)
	char pad_299_1 : 7;  // 0x12B(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x12B(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildingPosition
// Size: 0x262(Inherited: 0x0) 
struct FUpdateBuildingPosition
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector LocalHitLocation;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FRotator CallFunc_GetCorrectBuildingRotation_Rotation;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_SetCanBeBuilt_Success : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FVector CallFunc_GetCorrectHitLocation_ReturnLocation;  // 0x24(0xC)
	struct FRotator CallFunc_GetCorrectBuildingRotation_Rotation_2;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x40(0x30)
	float CallFunc_BreakRotator_Roll;  // 0x70(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x74(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_SetBuildingObjectTransform_TransformChanged : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_UpdateBuildStatus_Success : 1;  // 0x7D(0x1)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7E(0x1)
	char pad_127_1 : 7;  // 0x7F(0x1)
	bool CallFunc_UpdateBuildStatus_Success_2 : 1;  // 0x7F(0x1)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_BuildingObjectIsFloorPlaceable_Result : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	float K2Node_Select_Default;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_CheckSnap_CanBeSnapped : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FTransform CallFunc_GetSnapTransform_ReturnTransform;  // 0x90(0x30)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_SetBuildingObjectTransform_TransformChanged_2 : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_UpdateBuildStatus_Success_3 : 1;  // 0xC1(0x1)
	char pad_194[14];  // 0xC2(0xE)
	struct FTransform CallFunc_GetPropTransform_Transform;  // 0xD0(0x30)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_SetBuildingObjectTransform_TransformChanged_3 : 1;  // 0x100(0x1)
	char pad_257[15];  // 0x101(0xF)
	struct FTransform CallFunc_GetFoundationTransform_Transform;  // 0x110(0x30)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_SetBuildingObjectTransform_TransformChanged_4 : 1;  // 0x140(0x1)
	char pad_321_1 : 7;  // 0x141(0x1)
	bool CallFunc_BuildingObjectIsFloorPlaceable_Result_2 : 1;  // 0x141(0x1)
	char pad_322_1 : 7;  // 0x142(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x142(0x1)
	char pad_323[1];  // 0x143(0x1)
	struct FHitResult CallFunc_GetTraceHitResult_HitResult;  // 0x144(0x8C)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_UpdateTargetActor_Success : 1;  // 0x1D0(0x1)
	char pad_465[7];  // 0x1D1(0x7)
	struct AActor* CallFunc_UpdateTargetActor_TargetActor;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1E0(0x1)
	char pad_481_1 : 7;  // 0x1E1(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1E1(0x1)
	char pad_482_1 : 7;  // 0x1E2(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x1E2(0x1)
	char pad_483[1];  // 0x1E3(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x1E4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1E8(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1EC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1F8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x204(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x210(0xC)
	char pad_540[4];  // 0x21C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x220(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x228(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x230(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x238(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x240(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x244(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x248(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x254(0xC)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool CallFunc_ActorIsLandscape_Result : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x261(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetDebugInformation
// Size: 0xA30(Inherited: 0x0) 
struct FGetDebugInformation
{
	struct FText DebugInformation;  // 0x0(0x18)
	struct FText LocalTargetActorInformation;  // 0x18(0x18)
	struct FText LocalBuildingObjectInformation;  // 0x30(0x18)
	struct FText LocalDefaultDebugInformation;  // 0x48(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x60(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct FText CallFunc_Format_ReturnValue;  // 0xF8(0x18)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x110(0x10)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x120(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x138(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x150(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x190(0x40)
	ABP_EBS_Building_BaseObject_C* CallFunc_GetObjectClass_ReturnValue;  // 0x1D0(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue;  // 0x1D8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x1E8(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5;  // 0x200(0x40)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x248(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x258(0x18)
	AActor* CallFunc_GetObjectClass_ReturnValue_2;  // 0x270(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue_2;  // 0x278(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_3;  // 0x288(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_6;  // 0x2A0(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_7;  // 0x2E0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_3;  // 0x320(0x10)
	struct FText CallFunc_Format_ReturnValue_3;  // 0x330(0x18)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x348(0x1)
	char pad_841[7];  // 0x349(0x7)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue_2;  // 0x350(0x10)
	struct FText CallFunc_Conv_NameToText_ReturnValue_2;  // 0x360(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_4;  // 0x378(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_8;  // 0x390(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_9;  // 0x3D0(0x40)
	ABP_EBS_Building_BaseObject_C* CallFunc_GetObjectClass_ReturnValue_3;  // 0x410(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue_3;  // 0x418(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_5;  // 0x428(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_10;  // 0x440(0x40)
	char pad_1152_1 : 7;  // 0x480(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x480(0x1)
	char pad_1153[7];  // 0x481(0x7)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_4;  // 0x488(0x10)
	struct FText CallFunc_Format_ReturnValue_4;  // 0x498(0x18)
	AActor* CallFunc_GetObjectClass_ReturnValue_4;  // 0x4B0(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue_4;  // 0x4B8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_6;  // 0x4C8(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_11;  // 0x4E0(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_12;  // 0x520(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_5;  // 0x560(0x10)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_13;  // 0x570(0x40)
	struct FText CallFunc_Format_ReturnValue_5;  // 0x5B0(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_6;  // 0x5C8(0x10)
	struct FText CallFunc_Format_ReturnValue_6;  // 0x5D8(0x18)
	char pad_1520_1 : 7;  // 0x5F0(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x5F0(0x1)
	char pad_1521_1 : 7;  // 0x5F1(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x5F1(0x1)
	char pad_1522[6];  // 0x5F2(0x6)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_14;  // 0x5F8(0x40)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue_3;  // 0x638(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_7;  // 0x648(0x18)
	struct FText CallFunc_Conv_NameToText_ReturnValue_3;  // 0x660(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_15;  // 0x678(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_16;  // 0x6B8(0x40)
	ABP_EBS_Building_BaseObject_C* CallFunc_GetObjectClass_ReturnValue_5;  // 0x6F8(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue_5;  // 0x700(0x10)
	struct FText CallFunc_Conv_BoolToText_ReturnValue;  // 0x710(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_8;  // 0x728(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_17;  // 0x740(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_18;  // 0x780(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_7;  // 0x7C0(0x10)
	struct FText CallFunc_Conv_BoolToText_ReturnValue_2;  // 0x7D0(0x18)
	struct FText CallFunc_Format_ReturnValue_7;  // 0x7E8(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_19;  // 0x800(0x40)
	struct FText CallFunc_Conv_BoolToText_ReturnValue_3;  // 0x840(0x18)
	struct FText CallFunc_Conv_BoolToText_ReturnValue_4;  // 0x858(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_20;  // 0x870(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_21;  // 0x8B0(0x40)
	struct FText CallFunc_Conv_BoolToText_ReturnValue_5;  // 0x8F0(0x18)
	struct FText CallFunc_Conv_BoolToText_ReturnValue_6;  // 0x908(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_22;  // 0x920(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_23;  // 0x960(0x40)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue_4;  // 0x9A0(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_9;  // 0x9B0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_24;  // 0x9C8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_8;  // 0xA08(0x10)
	struct FText CallFunc_Format_ReturnValue_8;  // 0xA18(0x18)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetFloorIgnoringActors
// Size: 0x78(Inherited: 0x0) 
struct FGetFloorIgnoringActors
{
	int32_t TargetFloor;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AActor*> IgnoringActors;  // 0x8(0x10)
	struct TArray<struct AActor*> LocalActors;  // 0x18(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x38(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t CallFunc_GetFloorNumber_BPI_FloorNumber;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x74(0x4)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetTraceHitResult
// Size: 0x251(Inherited: 0x0) 
struct FGetTraceHitResult
{
	struct FHitResult HitResult;  // 0x0(0x8C)
	char EDrawDebugTrace Temp_byte_Variable;  // 0x8C(0x1)
	char EDrawDebugTrace Temp_byte_Variable_2;  // 0x8D(0x1)
	char pad_142_1 : 7;  // 0x8E(0x1)
	bool Temp_bool_Variable : 1;  // 0x8E(0x1)
	char pad_143_1 : 7;  // 0x8F(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x8F(0x1)
	char EDrawDebugTrace K2Node_Select_Default;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x98(0x8)
	struct TArray<struct AActor*> CallFunc_GetFloorIgnoringActors_IgnoringActors;  // 0xA0(0x10)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0xB0(0x10)
	struct FRotator CallFunc_GetCameraRotation_ReturnValue;  // 0xC0(0xC)
	float K2Node_Select_Default_2;  // 0xCC(0x4)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xD0(0xC)
	struct FVector CallFunc_GetCameraLocation_ReturnValue;  // 0xDC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xE8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xF4(0xC)
	struct FVector CallFunc_DeprojectMousePositionToWorld_WorldLocation;  // 0x100(0xC)
	struct FVector CallFunc_DeprojectMousePositionToWorld_WorldDirection;  // 0x10C(0xC)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_DeprojectMousePositionToWorld_ReturnValue : 1;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x11C(0x8C)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x1A8(0x1)
	char pad_425[3];  // 0x1A9(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x1AC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x1B8(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit_2;  // 0x1C4(0x8C)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue_2 : 1;  // 0x250(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickInteraction
// Size: 0x2(Inherited: 0x0) 
struct FTryQuickInteraction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ShowBuildingMenu
// Size: 0x19(Inherited: 0x0) 
struct FShowBuildingMenu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.HideBuildingMenu
// Size: 0x19(Inherited: 0x0) 
struct FHideBuildingMenu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingWidget
// Size: 0x9(Inherited: 0x0) 
struct FSetBuildingWidget
{
	struct UUserWidget* BuildingWidget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SendBuildingMessage
// Size: 0x21(Inherited: 0x0) 
struct FSendBuildingMessage
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool InteractionResult : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FText Message;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Success : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryStartBuildObject
// Size: 0x12(Inherited: 0x0) 
struct FTryStartBuildObject
{
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_CheckBuildingRequirements_Success : 1;  // 0x11(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.AutoInitComponent
// Size: 0x2(Inherited: 0x0) 
struct FAutoInitComponent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetTargetActor
// Size: 0xB(Inherited: 0x0) 
struct FSetTargetActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_SetTargetBuildingObject_Success : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0xA(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetBuildingMode
// Size: 0x1(Inherited: 0x0) 
struct FGetBuildingMode
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetBuildingStatus
// Size: 0x20(Inherited: 0x0) 
struct FGetBuildingStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanBeBuild : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x8(0x8)
	struct AActor* TargetActor;  // 0x10(0x8)
	struct ABP_EBS_Building_BaseObject_C* TargetBuildingObject;  // 0x18(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetInteractionStatus
// Size: 0x18(Inherited: 0x0) 
struct FGetInteractionStatus
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* TargetActor;  // 0x8(0x8)
	struct ABP_EBS_Building_BaseObject_C* TargetBuildingObject;  // 0x10(0x8)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.PrintDebugInformation
// Size: 0x20(Inherited: 0x0) 
struct FPrintDebugInformation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText CallFunc_GetDebugInformation_DebugInformation;  // 0x8(0x18)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeDebugMode
// Size: 0x4(Inherited: 0x0) 
struct FChangeDebugMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool DebugMode : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)
	char E_EBS_BuildingMode LocalPrevBuildingMode;  // 0x2(0x1)
	char E_EBS_BuildingMode LocalNewBuildingMode;  // 0x3(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CheckFloorNumber
// Size: 0x4(Inherited: 0x0) 
struct FCheckFloorNumber
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_SetFloorNumberByTargetActor_Success : 1;  // 0x3(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateFloorActorsVisibility
// Size: 0x62(Inherited: 0x0) 
struct FUpdateFloorActorsVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x10(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor_2;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_GetFloorNumber_BPI_FloorNumber;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_SetFloorActorHidden_BPI_Success : 1;  // 0x61(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ResetFloorActorsVisibility
// Size: 0x43(Inherited: 0x0) 
struct FResetFloorActorsVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x10(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_SetFloorActorHidden_BPI_Success : 1;  // 0x42(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CheckInitReferences
// Size: 0x21(Inherited: 0x0) 
struct FCheckInitReferences
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_InitComponent_Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ShowMalletMenu
// Size: 0x32(Inherited: 0x0) 
struct FShowMalletMenu
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_CheckClaim_Result : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.HideMalletMenu
// Size: 0x19(Inherited: 0x0) 
struct FHideMalletMenu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingWidget
// Size: 0x21(Inherited: 0x0) 
struct FChangeBuildingWidget
{
	UUserWidget* BuildingWidgetClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_TryToCreateBuildingWidget_Success : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct TScriptInterface<IBPI_EBS_BuildingWidget_C> K2Node_DynamicCast_AsBPI_EBS_Building_Widget;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
