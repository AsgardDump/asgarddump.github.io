#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.GetInteractionText_BPI
// Size: 0x88(Inherited: 0x0) 
struct FGetInteractionText_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	struct FText InteractionText;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Temp_bool_Variable : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FText Temp_text_Variable;  // 0x40(0x18)
	struct FText Temp_text_Variable_2;  // 0x58(0x18)
	struct FText K2Node_Select_Default;  // 0x70(0x18)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.ExecuteUbergraph_BP_EBS_Building_SmallWoodenBox
// Size: 0x6C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_Building_SmallWoodenBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AController* K2Node_CustomEvent_Executor;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Event_Toggle_2 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool K2Node_CustomEvent_Toggle : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct APlayerController* K2Node_Event_PlayerController_2;  // 0x18(0x8)
	struct FName K2Node_Event_NotifyName;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_Event_Released : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FKey K2Node_Event_InteractionKey;  // 0x30(0x18)
	struct APlayerController* K2Node_Event_PlayerController;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct AController* K2Node_Event_Executor;  // 0x58(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x60(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x68(0x4)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.CustomEvent_2
// Size: 0x1(Inherited: 0x0) 
struct FCustomEvent_2
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.GetInteractionObjectName_BPI
// Size: 0x18(Inherited: 0x0) 
struct FGetInteractionObjectName_BPI
{
	struct FText Name;  // 0x0(0x18)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.TryInteract_BPI
// Size: 0x28(Inherited: 0x0) 
struct FTryInteract_BPI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Released : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FKey InteractionKey;  // 0x8(0x18)
	struct APlayerController* PlayerController;  // 0x20(0x8)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.CompleteInteractionNotify_BPI
// Size: 0x10(Inherited: 0x0) 
struct FCompleteInteractionNotify_BPI
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FName NotifyName;  // 0x8(0x8)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Toggle Chest
// Size: 0x1(Inherited: 0x0) 
struct FToggle Chest
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.CustomEvent
// Size: 0x8(Inherited: 0x0) 
struct FCustomEvent
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.OnRep_TurnedOn
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_TurnedOn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.GetFormatedVariables_BPI
// Size: 0x40(Inherited: 0x10) 
struct FGetFormatedVariables_BPI : public FGetFormatedVariables_BPI
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct TArray<struct FString> CallFunc_GetFormatedVariables_BPI_FormatedVariables;  // 0x10(0x10)
	struct FString CallFunc_FormatBooleanVariableToString_FormatedVariable;  // 0x20(0x10)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x30(0x10)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.LoadData_BPI
// Size: 0x82(Inherited: 0x90) 
struct FLoadData_BPI : public FLoadData_BPI
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Success : 1;  // 0x8(0x1)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x10(0x10)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_LoadData_BPI_Success : 1;  // 0x21(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool CallFunc_GetActorSaveData_BPI_Success : 1;  // 0x22(0x1)
	struct FSTR_EBS_SaveData_Actor CallFunc_GetActorSaveData_BPI_SaveData;  // 0x30(0x50)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool CallFunc_GetFormatedVariableBooleanValue_Success : 1;  // 0x80(0x1)
	char pad_253_1 : 7;  // 0xFD(0x1)
	bool CallFunc_GetFormatedVariableBooleanValue_Value : 1;  // 0x81(0x1)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.IsCanInteract_BPI
// Size: 0x21(Inherited: 0x0) 
struct FIsCanInteract_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Get Interaction Data
// Size: 0x18(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)

}; 
// Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
