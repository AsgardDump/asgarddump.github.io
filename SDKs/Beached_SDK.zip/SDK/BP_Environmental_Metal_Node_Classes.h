#pragma once 
#include <BP_Environmental_Metal_Node_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Environmental_Metal_Node.BP_Environmental_Metal_Node_C
// Size: 0x2C1(Inherited: 0x2C1) 
struct ABP_Environmental_Metal_Node_C : public ABP_Environmental_C
{

}; 



