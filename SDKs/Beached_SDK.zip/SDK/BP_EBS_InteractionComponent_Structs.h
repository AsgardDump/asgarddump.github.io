#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnInteractionActorChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnInteractionActorChanged__DelegateSignature
{
	struct AActor* InteractionActor;  // 0x0(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnTargetActorChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnTargetActorChanged__DelegateSignature
{
	struct AActor* TargetActor;  // 0x0(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.PlayInteractionMontage
// Size: 0x11(Inherited: 0x0) 
struct FPlayInteractionMontage
{
	char E_EBS_InteractionType InteractionType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UAnimMontage* CallFunc_Map_Find_Value;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ExecuteUbergraph_BP_EBS_InteractionComponent
// Size: 0xC1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_InteractionComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_UpdateProcess_Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TScriptInterface<IBPI_EBS_InteractionObject_C> K2Node_DynamicCast_AsBPI_EBS_Interaction_Object;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool K2Node_CustomEvent_Released : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FKey K2Node_CustomEvent_InteractionKey;  // 0x20(0x18)
	struct AActor* K2Node_CustomEvent_InteractionActor;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TScriptInterface<IBPI_EBS_InteractionObject_C> K2Node_DynamicCast_AsBPI_EBS_Interaction_Object_2;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct TScriptInterface<IBPI_EBS_InteractionObject_C> K2Node_DynamicCast_AsBPI_EBS_Interaction_Object_3;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_IsCanInteract_BPI_Result : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool K2Node_CustomEvent_Released_2 : 1;  // 0x72(0x1)
	char pad_115[5];  // 0x73(0x5)
	struct FKey K2Node_CustomEvent_InteractionKey_2;  // 0x78(0x18)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_AutoInitComponent_Success : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x94(0x4)
	struct UAnimMontage* K2Node_CustomEvent_AnimMontage;  // 0x98(0x8)
	struct FRotator K2Node_CustomEvent_TargetRotation;  // 0xA0(0xC)
	float CallFunc_PlayAnimMontage_ReturnValue;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_StartRotateCharacter_Success : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	UUserWidget* K2Node_CustomEvent_InteractionWidgetClass;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_ChangeInteractionWidget_Success : 1;  // 0xC0(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnInteractionNotify__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnInteractionNotify__DelegateSignature
{
	struct ACharacter* Character;  // 0x0(0x8)
	struct AActor* InteractionActor;  // 0x8(0x8)
	struct FName NotifyName;  // 0x10(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnInteractionStanceChanged__DelegateSignature
// Size: 0x2(Inherited: 0x0) 
struct FOnInteractionStanceChanged__DelegateSignature
{
	char E_EBS_InteractionType NewInteractionStance;  // 0x0(0x1)
	char E_EBS_InteractionType PrevInteractionStance;  // 0x1(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeInteractionWidget (Client)
// Size: 0x8(Inherited: 0x0) 
struct FChangeInteractionWidget (Client)
{
	UUserWidget* InteractionWidgetClass;  // 0x0(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.PlayInteractionMontage (Multicast)
// Size: 0x8(Inherited: 0x0) 
struct FPlayInteractionMontage (Multicast)
{
	struct UAnimMontage* AnimMontage;  // 0x0(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryInteract (Server)
// Size: 0x28(Inherited: 0x0) 
struct FTryInteract (Server)
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Released : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FKey InteractionKey;  // 0x8(0x18)
	struct AActor* InteractionActor;  // 0x20(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.StartRotateCharacter (Multicast)
// Size: 0xC(Inherited: 0x0) 
struct FStartRotateCharacter (Multicast)
{
	struct FRotator TargetRotation;  // 0x0(0xC)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryInteract (Client)
// Size: 0x20(Inherited: 0x0) 
struct FTryInteract (Client)
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Released : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FKey InteractionKey;  // 0x8(0x18)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.InitComponent
// Size: 0x51(Inherited: 0x0) 
struct FInitComponent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_InitCharacterReferences_Success : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_TryToCreateInteractionWidget_Success : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x40(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetTargetActor
// Size: 0x8(Inherited: 0x0) 
struct FGetTargetActor
{
	struct AActor* TargetActor;  // 0x0(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.AutoInitComponent
// Size: 0x2(Inherited: 0x0) 
struct FAutoInitComponent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.BindCharacterInteractionStanceChanged
// Size: 0x3(Inherited: 0x0) 
struct FBindCharacterInteractionStanceChanged
{
	char E_EBS_InteractionType NewInteractionStance;  // 0x0(0x1)
	char E_EBS_InteractionType PrevInteractionStance;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_ChangeInteractionStance_Success : 1;  // 0x2(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryToCreateInteractionWidget
// Size: 0x55(Inherited: 0x0) 
struct FTryToCreateInteractionWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct TScriptInterface<IBPI_EBS_InteractionWidget_C> K2Node_DynamicCast_AsBPI_EBS_Interaction_Widget;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	struct UUserWidget* CallFunc_Create_ReturnValue;  // 0x20(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct UUserWidget*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UUserWidget* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x54(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateInteractionActor
// Size: 0x13A(Inherited: 0x0) 
struct FUpdateInteractionActor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_SetTargetActor_Success : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FHitResult CallFunc_GetTraceHitResult_HitResult;  // 0x4(0x8C)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x9C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xA0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xA4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xB0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xBC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xC8(0xC)
	char pad_212[4];  // 0xD4(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xD8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xE0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0xE8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0xF0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0xF8(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xFC(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x100(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x10C(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x118(0xC)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_SetTargetActor_Success_2 : 1;  // 0x124(0x1)
	char pad_293[3];  // 0x125(0x3)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x128(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x134(0x4)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x139(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetDebugInformation
// Size: 0x310(Inherited: 0x0) 
struct FGetDebugInformation
{
	struct FText DebugInformation;  // 0x0(0x18)
	struct FText LocalTargetActorInformation;  // 0x18(0x18)
	struct FText LocalDefaultDebugInformation;  // 0x30(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x48(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x88(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xC8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xD8(0x18)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	AActor* CallFunc_GetObjectClass_ReturnValue;  // 0xF8(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue;  // 0x100(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x110(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x128(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x168(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x1A8(0x10)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x1B8(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x1C8(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x1E0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5;  // 0x1F8(0x40)
	struct FText CallFunc_Conv_BoolToText_ReturnValue;  // 0x238(0x18)
	struct FText CallFunc_Conv_BoolToText_ReturnValue_2;  // 0x250(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_6;  // 0x268(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_7;  // 0x2A8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_3;  // 0x2E8(0x10)
	struct FText CallFunc_Format_ReturnValue_3;  // 0x2F8(0x18)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetFloorIgnoringActors
// Size: 0x78(Inherited: 0x0) 
struct FGetFloorIgnoringActors
{
	int32_t FloorNumber;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AActor*> IgnoringActors;  // 0x8(0x10)
	struct TArray<struct AActor*> LocalActors;  // 0x18(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x38(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t CallFunc_GetFloorNumber_BPI_FloorNumber;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x74(0x4)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetTraceHitResult
// Size: 0x24D(Inherited: 0x0) 
struct FGetTraceHitResult
{
	struct FHitResult HitResult;  // 0x0(0x8C)
	char EDrawDebugTrace Temp_byte_Variable;  // 0x8C(0x1)
	char EDrawDebugTrace Temp_byte_Variable_2;  // 0x8D(0x1)
	char pad_142_1 : 7;  // 0x8E(0x1)
	bool Temp_bool_Variable : 1;  // 0x8E(0x1)
	char pad_143[1];  // 0x8F(0x1)
	struct TArray<struct AActor*> CallFunc_GetFloorIgnoringActors_IgnoringActors;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xA0(0x1)
	char EDrawDebugTrace K2Node_Select_Default;  // 0xA1(0x1)
	char pad_162[2];  // 0xA2(0x2)
	float K2Node_Select_Default_2;  // 0xA4(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0xA8(0x8)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0xB0(0x10)
	struct FRotator CallFunc_GetCameraRotation_ReturnValue;  // 0xC0(0xC)
	struct FVector CallFunc_GetCameraLocation_ReturnValue;  // 0xCC(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xD8(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xE4(0xC)
	struct FVector CallFunc_DeprojectMousePositionToWorld_WorldLocation;  // 0xF0(0xC)
	struct FVector CallFunc_DeprojectMousePositionToWorld_WorldDirection;  // 0xFC(0xC)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_DeprojectMousePositionToWorld_ReturnValue : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x10C(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x118(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x124(0x8C)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x1B0(0x1)
	char pad_433[3];  // 0x1B1(0x3)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x1B4(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit_2;  // 0x1C0(0x8C)
	char pad_588_1 : 7;  // 0x24C(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue_2 : 1;  // 0x24C(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.SetInteractionActor
// Size: 0xA(Inherited: 0x0) 
struct FSetInteractionActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeDisplayedFloor
// Size: 0x20(Inherited: 0x0) 
struct FChangeDisplayedFloor
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool UpdateVisibility : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Success : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool LocalUpdateVisibility : 1;  // 0xA(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_UpdateFloorActorsVisibility_Success : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t K2Node_Select_Default;  // 0x18(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x1C(0x4)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetInteractionActor
// Size: 0x8(Inherited: 0x0) 
struct FGetInteractionActor
{
	struct AActor* InteractionActor;  // 0x0(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.SetTargetActor
// Size: 0x2A(Inherited: 0x0) 
struct FSetTargetActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AActor* Temp_object_Variable;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct AActor* K2Node_Select_Default;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_SetInteractionActor_Success : 1;  // 0x29(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryStartInteractonWithActor
// Size: 0x4C(Inherited: 0x0) 
struct FTryStartInteractonWithActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char E_EBS_InteractionType InteractionType;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool RotateToTarget : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Success : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsPlayingRootMotion_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_PlayInteractionMontage_Success : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1C(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x28(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x34(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x38(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x3C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x40(0xC)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeDebugMode
// Size: 0x2(Inherited: 0x0) 
struct FChangeDebugMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool DebugMode : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.StartRotateCharacter
// Size: 0xD(Inherited: 0x0) 
struct FStartRotateCharacter
{
	struct FRotator TargetRotation;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Success : 1;  // 0xC(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetInteractionStance
// Size: 0x1(Inherited: 0x0) 
struct FGetInteractionStance
{
	char E_EBS_InteractionType InteractionStance;  // 0x0(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateCharacterRotation
// Size: 0x46(Inherited: 0x0) 
struct FUpdateCharacterRotation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x4(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x8(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0xC(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x10(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x14(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x20(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x2C(0xC)
	struct FRotator CallFunc_RInterpTo_ReturnValue;  // 0x38(0xC)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_NotEqual_RotatorRotator_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x45(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.CheckInitReferences
// Size: 0x2A(Inherited: 0x0) 
struct FCheckInitReferences
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_InitComponent_Success : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x29(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.CompleteInteractionNotify
// Size: 0x22(Inherited: 0x0) 
struct FCompleteInteractionNotify
{
	struct FName NotifyName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TScriptInterface<IBPI_EBS_InteractionObject_C> K2Node_DynamicCast_AsBPI_EBS_Interaction_Object;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeInteractionStance
// Size: 0x4(Inherited: 0x0) 
struct FChangeInteractionStance
{
	char E_EBS_InteractionType NewInteractionStance;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)
	char E_EBS_InteractionType LocalPrevInteractionStance;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeTopDownView
// Size: 0x5(Inherited: 0x0) 
struct FChangeTopDownView
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool TopDownViewMode : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool TraceToMouseMode : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Success : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_ResetFloorActorsVisibility_Success : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_UpdateFloorActorsVisibility_Success : 1;  // 0x4(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateFloorActorsVisibility
// Size: 0x62(Inherited: 0x0) 
struct FUpdateFloorActorsVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x10(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor_2;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_GetFloorNumber_BPI_FloorNumber;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_SetFloorActorHidden_BPI_Success : 1;  // 0x61(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ResetFloorActorsVisibility
// Size: 0x4A(Inherited: 0x0) 
struct FResetFloorActorsVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TScriptInterface<IBPI_EBS_Floor_C> K2Node_DynamicCast_AsBPI_EBS_Floor;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_SetFloorActorHidden_BPI_Success : 1;  // 0x49(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.InitCharacterReferences
// Size: 0x49(Inherited: 0x0) 
struct FInitCharacterReferences
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct UBP_EBS_InteractionComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x28(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.BindCharacterInteractionNotify
// Size: 0x18(Inherited: 0x0) 
struct FBindCharacterInteractionNotify
{
	struct ACharacter* Character;  // 0x0(0x8)
	struct AActor* InteractionActor;  // 0x8(0x8)
	struct FName NotifyName;  // 0x10(0x8)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeInteractionWidget
// Size: 0x21(Inherited: 0x0) 
struct FChangeInteractionWidget
{
	UUserWidget* InteractionWidgetClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_TryToCreateInteractionWidget_Success : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct TScriptInterface<IBPI_EBS_InteractionWidget_C> K2Node_DynamicCast_AsBPI_EBS_Interaction_Widget;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.PrintDebugInformation
// Size: 0x50(Inherited: 0x0) 
struct FPrintDebugInformation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText LocalTargetActorInformation;  // 0x8(0x18)
	struct FText LocalDefaultDebugInformation;  // 0x20(0x18)
	struct FText CallFunc_GetDebugInformation_DebugInformation;  // 0x38(0x18)

}; 
// Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateProcess
// Size: 0x6(Inherited: 0x0) 
struct FUpdateProcess
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_PrintDebugInformation_Success : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_UpdateCharacterRotation_Success : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_UpdateInteractionActor_Success : 1;  // 0x5(0x1)

}; 
