#pragma once 
#include <BP_Checkpoint_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Checkpoint.BP_Checkpoint_C
// Size: 0x278(Inherited: 0x220) 
struct ABP_Checkpoint_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct UW_Marker_C* Marker;  // 0x230(0x8)
	struct TArray<struct UW_Marker_C*> Markers;  // 0x238(0x10)
	struct FS_Marker Marker Data;  // 0x248(0x30)

	void ReceiveBeginPlay(); // Function BP_Checkpoint.BP_Checkpoint_C.ReceiveBeginPlay
	void ReceiveDestroyed(); // Function BP_Checkpoint.BP_Checkpoint_C.ReceiveDestroyed
	void ExecuteUbergraph_BP_Checkpoint(int32_t EntryPoint); // Function BP_Checkpoint.BP_Checkpoint_C.ExecuteUbergraph_BP_Checkpoint
}; 



