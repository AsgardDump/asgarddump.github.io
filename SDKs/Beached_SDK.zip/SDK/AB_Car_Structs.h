#pragma once 
#include "SDK.h" 
 
 
// Function AB_Car.AB_Car_C.ExecuteUbergraph_AB_Car
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_AB_Car
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function AB_Car.AB_Car_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
