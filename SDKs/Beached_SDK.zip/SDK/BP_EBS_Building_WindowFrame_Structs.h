#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_WindowFrame.BP_EBS_Building_WindowFrame_C.GetSocketTransform
// Size: 0xA1(Inherited: 0x90) 
struct FGetSocketTransform : public FGetSocketTransform
{
	struct FName SocketName;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	struct FTransform Transform;  // 0x10(0x30)
	struct FTransform CallFunc_GetSocketTransform_Transform;  // 0x40(0x30)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x70(0x30)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0xA0(0x1)

}; 
