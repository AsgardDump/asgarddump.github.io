#pragma once 
#include <BP_EBS_Building_Stairs_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Stairs.BP_EBS_Building_Stairs_C
// Size: 0x488(Inherited: 0x479) 
struct ABP_EBS_Building_Stairs_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct UBoxComponent* BuildCollision;  // 0x480(0x8)

	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_Stairs.BP_EBS_Building_Stairs_C.GetSnapTransform
}; 



