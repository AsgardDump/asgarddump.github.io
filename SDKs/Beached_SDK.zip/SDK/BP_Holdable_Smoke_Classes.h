#pragma once 
#include <BP_Holdable_Smoke_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_Smoke.BP_Holdable_Smoke_C
// Size: 0x370(Inherited: 0x370) 
struct ABP_Holdable_Smoke_C : public ABP_Holdable_Throwable_C
{

}; 



