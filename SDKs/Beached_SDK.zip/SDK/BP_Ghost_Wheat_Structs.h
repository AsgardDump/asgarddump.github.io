#pragma once 
#include "SDK.h" 
 
 
// Function BP_Ghost_Wheat.BP_Ghost_Wheat_C.Custom Condition Pass
// Size: 0x13B(Inherited: 0x112) 
struct FCustom Condition Pass : public FCustom Condition Pass
{
	struct FHitResult Hit;  // 0x0(0x8C)
	char pad_414_1 : 7;  // 0x19E(0x1)
	bool Return : 1;  // 0x8C(0x1)
	struct TArray<AActor*> K2Node_MakeArray_Array;  // 0x90(0x10)
	char pad_431_1 : 7;  // 0x1AF(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xA0(0x1)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xA1(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xA4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xA8(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xAC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xB8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xC4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xD0(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xE0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xE8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0xF0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0xF8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x100(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x104(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x108(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x114(0xC)
	float CallFunc_BreakVector_X;  // 0x120(0x4)
	float CallFunc_BreakVector_Y;  // 0x124(0x4)
	float CallFunc_BreakVector_Z;  // 0x128(0x4)
	AActor* CallFunc_GetObjectClass_ReturnValue;  // 0x130(0x8)
	char pad_573_1 : 7;  // 0x23D(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x138(0x1)
	char pad_574_1 : 7;  // 0x23E(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x139(0x1)
	char pad_575_1 : 7;  // 0x23F(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x13A(0x1)

}; 
