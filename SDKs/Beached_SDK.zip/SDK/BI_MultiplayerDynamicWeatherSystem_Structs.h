#pragma once 
#include "SDK.h" 
 
 
// Function BI_MultiplayerDynamicWeatherSystem.BI_MultiplayerDynamicWeatherSystem_C.On Rain
// Size: 0x1(Inherited: 0x0) 
struct FOn Rain
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Raining? : 1;  // 0x0(0x1)

}; 
// Function BI_MultiplayerDynamicWeatherSystem.BI_MultiplayerDynamicWeatherSystem_C.On Weather Changed
// Size: 0x8(Inherited: 0x0) 
struct FOn Weather Changed
{
	struct FName Weather Name;  // 0x0(0x8)

}; 
// Function BI_MultiplayerDynamicWeatherSystem.BI_MultiplayerDynamicWeatherSystem_C.Toggle Raining
// Size: 0x1(Inherited: 0x0) 
struct FToggle Raining
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
