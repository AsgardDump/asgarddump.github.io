#pragma once 
#include "SDK.h" 
 
 
// Function BP_Breeder.BP_Breeder_C.Check Animal Validity
// Size: 0x31(Inherited: 0x0) 
struct FCheck Animal Validity
{
	struct TArray<struct AActor*> L Animals;  // 0x0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BP_Breeder.BP_Breeder_C.ExecuteUbergraph_BP_Breeder
// Size: 0x94(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Breeder
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xC(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x18(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x24(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x28(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x2C(0x4)
	struct FVector CallFunc_GetActorUpVector_ReturnValue;  // 0x30(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x3C(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x48(0xC)
	struct FVector CallFunc_GetActorRightVector_ReturnValue;  // 0x54(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x60(0xC)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x6C(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x70(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x7C(0xC)
	struct APawn* CallFunc_SpawnAIFromClass_ReturnValue;  // 0x88(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x90(0x4)

}; 
