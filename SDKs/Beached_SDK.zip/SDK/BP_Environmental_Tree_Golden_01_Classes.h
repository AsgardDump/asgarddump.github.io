#pragma once 
#include <BP_Environmental_Tree_Golden_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Environmental_Tree_Golden_01.BP_Environmental_Tree_Golden_01_C
// Size: 0x2C1(Inherited: 0x2C1) 
struct ABP_Environmental_Tree_Golden_01_C : public ABP_Environmental_C
{

}; 



