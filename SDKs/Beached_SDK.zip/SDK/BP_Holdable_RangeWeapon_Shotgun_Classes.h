#pragma once 
#include <BP_Holdable_RangeWeapon_Shotgun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_Shotgun.BP_Holdable_RangeWeapon_Shotgun_C
// Size: 0x4C8(Inherited: 0x49D) 
struct ABP_Holdable_RangeWeapon_Shotgun_C : public ABP_Holdable_RangeWeapon_C
{
	char pad_1181[3];  // 0x49D(0x3)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A0(0x8)
	int32_t Shell Amount;  // 0x4A8(0x4)
	float Spread;  // 0x4AC(0x4)
	int32_t Shell Index;  // 0x4B0(0x4)
	char pad_1204[4];  // 0x4B4(0x4)
	struct TArray<struct FHitResult> HIts;  // 0x4B8(0x10)

	float Get Damage(struct FHitResult& Hit); // Function BP_Holdable_RangeWeapon_Shotgun.BP_Holdable_RangeWeapon_Shotgun_C.Get Damage
	void Do Custom Shot Effects(bool Bullet Hit, struct FHitResult Hit , bool No Ammo, struct FVector Water Hit); // Function BP_Holdable_RangeWeapon_Shotgun.BP_Holdable_RangeWeapon_Shotgun_C.Do Custom Shot Effects
	void Change Firemode(); // Function BP_Holdable_RangeWeapon_Shotgun.BP_Holdable_RangeWeapon_Shotgun_C.Change Firemode
	void Do Shot Action(); // Function BP_Holdable_RangeWeapon_Shotgun.BP_Holdable_RangeWeapon_Shotgun_C.Do Shot Action
	void ExecuteUbergraph_BP_Holdable_RangeWeapon_Shotgun(int32_t EntryPoint); // Function BP_Holdable_RangeWeapon_Shotgun.BP_Holdable_RangeWeapon_Shotgun_C.ExecuteUbergraph_BP_Holdable_RangeWeapon_Shotgun
}; 



