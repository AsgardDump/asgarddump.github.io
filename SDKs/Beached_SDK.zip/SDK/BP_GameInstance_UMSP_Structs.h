#pragma once 
#include "SDK.h" 
 
 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Completed_6C0182614574E20C8A02D58CF57A44AB
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6C0182614574E20C8A02D58CF57A44AB
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Player Data
// Size: 0x10A(Inherited: 0x0) 
struct FSave Player Data
{
	struct FString Player ID;  // 0x0(0x10)
	struct FS_PlayerSave Save;  // 0x10(0xE0)
	int32_t Player Index;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0xF8(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x109(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.ExecuteUbergraph_BP_GameInstance_UMSP
// Size: 0x454(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GameInstance_UMSP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_3;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_CustomEvent_bSuccess_3 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x34(0x10)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool Temp_bool_Variable : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct USaveGame* Temp_object_Variable;  // 0x48(0x8)
	struct UBP_EBS_SaveGame_C* K2Node_DynamicCast_AsBP_EBS_Save_Game;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue;  // 0x60(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USaveGame* K2Node_CustomEvent_SaveGame_2;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_CustomEvent_bSuccess_2 : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct USaveGame* Temp_object_Variable_2;  // 0x90(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_CustomEvent_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0xA4(0x10)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct USaveGame* Temp_object_Variable_3;  // 0xB8(0x8)
	struct FString K2Node_CustomEvent_Build_ID_2;  // 0xC0(0x10)
	struct FS_BuildSave K2Node_CustomEvent_New_Save_2;  // 0xD0(0xF0)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x1C0(0x10)
	struct FString K2Node_CustomEvent_Build_ID;  // 0x1D0(0x10)
	struct FS_BuildSave K2Node_CustomEvent_New_Save;  // 0x1E0(0xF0)
	int32_t K2Node_Event_LocalPlayerNum;  // 0x2D0(0x4)
	char pad_724[4];  // 0x2D4(0x4)
	struct FBPUniqueNetId K2Node_Event_PersonInvited;  // 0x2D8(0x20)
	struct FBlueprintSessionResult K2Node_Event_SessionToJoin;  // 0x2F8(0x108)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x400(0x8)
	struct UJoinSessionCallbackProxy* CallFunc_JoinSession_ReturnValue;  // 0x408(0x8)
	struct UDestroySessionCallbackProxy* CallFunc_DestroySession_ReturnValue;  // 0x410(0x8)
	char pad_1048_1 : 7;  // 0x418(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x418(0x1)
	char pad_1049_1 : 7;  // 0x419(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x419(0x1)
	char pad_1050_1 : 7;  // 0x41A(0x1)
	bool CallFunc_HasOnlineSubsystem_ReturnValue : 1;  // 0x41A(0x1)
	char pad_1051[5];  // 0x41B(0x5)
	struct UBP_EBS_SaveGame_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x420(0x8)
	struct UBP_EBS_SaveGame_C* CallFunc_SaveGridBuildings_SaveGameOut;  // 0x428(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue;  // 0x430(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_2;  // 0x438(0x8)
	char pad_1088_1 : 7;  // 0x440(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x440(0x1)
	char pad_1089_1 : 7;  // 0x441(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x441(0x1)
	char pad_1090[2];  // 0x442(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x444(0x10)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Building
// Size: 0x100(Inherited: 0x0) 
struct FSave Building
{
	struct FString Build ID;  // 0x0(0x10)
	struct FS_BuildSave New Save;  // 0x10(0xF0)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.OnSessionInviteAccepted
// Size: 0x130(Inherited: 0x130) 
struct FOnSessionInviteAccepted : public FOnSessionInviteAccepted
{
	int32_t LocalPlayerNum;  // 0x0(0x4)
	struct FBPUniqueNetId PersonInvited;  // 0x8(0x20)
	struct FBlueprintSessionResult SessionToJoin;  // 0x28(0x108)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Completed_DAADE8BF40EA586D5BEB91B0BE42B7A2
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_DAADE8BF40EA586D5BEB91B0BE42B7A2
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Building Directly
// Size: 0x100(Inherited: 0x0) 
struct FSave Building Directly
{
	struct FString Build ID;  // 0x0(0x10)
	struct FS_BuildSave New Save;  // 0x10(0xF0)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Completed_20386FB04A461883E6B3F39B0A6A3220
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_20386FB04A461883E6B3F39B0A6A3220
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Add New Building
// Size: 0x342(Inherited: 0x0) 
struct FAdd New Building
{
	struct FS_BuildSave Build Data;  // 0x0(0xF0)
	struct FString Build ID;  // 0xF0(0x10)
	int32_t L Normal ID;  // 0x100(0x4)
	char pad_260[12];  // 0x104(0xC)
	struct FS_BuildSave K2Node_MakeStruct_S_BuildSave;  // 0x110(0xF0)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool CallFunc_Is_Current_Level_Saveable_ReturnValue : 1;  // 0x200(0x1)
	char pad_513[7];  // 0x201(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x208(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x218(0x10)
	int32_t CallFunc_RandomInteger_ReturnValue;  // 0x228(0x4)
	char pad_556[4];  // 0x22C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x230(0x10)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x240(0x1)
	char pad_577[15];  // 0x241(0xF)
	struct FS_BuildSave CallFunc_Map_Find_Value;  // 0x250(0xF0)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x340(0x1)
	char pad_833_1 : 7;  // 0x341(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x341(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Remove Building
// Size: 0x12(Inherited: 0x0) 
struct FRemove Building
{
	struct FString Build ID;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Map_Remove_ReturnValue : 1;  // 0x11(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Existing Building
// Size: 0x100(Inherited: 0x0) 
struct FSave Existing Building
{
	struct FString Build ID;  // 0x0(0x10)
	struct FS_BuildSave New Save;  // 0x10(0xF0)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Get Saved Data
// Size: 0x201(Inherited: 0x0) 
struct FGet Saved Data
{
	struct FString Build ID;  // 0x0(0x10)
	struct FS_BuildSave Saved Data;  // 0x10(0xF0)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool ReturnValue : 1;  // 0x100(0x1)
	char pad_257[15];  // 0x101(0xF)
	struct FS_BuildSave CallFunc_Map_Find_Value;  // 0x110(0xF0)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x200(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Add Vehicle Save
// Size: 0x72(Inherited: 0x0) 
struct FAdd Vehicle Save
{
	struct FString Key;  // 0x0(0x10)
	struct FS_VehicleSaveData Value;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_Is_Current_Level_Saveable_ReturnValue : 1;  // 0x71(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Remove Vehicle Save
// Size: 0x13(Inherited: 0x0) 
struct FRemove Vehicle Save
{
	struct FString Key;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Map_Remove_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_Is_Current_Level_Saveable_ReturnValue : 1;  // 0x12(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.SaveGridBuildings
// Size: 0x101(Inherited: 0x0) 
struct FSaveGridBuildings
{
	struct UBP_EBS_SaveGame_C* SaveGame;  // 0x0(0x8)
	struct UBP_EBS_SaveGame_C* SaveGameOut;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_ClearTemporaryData_BPI_Success : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game_2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game_3;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x5C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x64(0x4)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x68(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_SaveLevelData_BPI_Success : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x84(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x90(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct TScriptInterface<IBPI_EBS_SaveObject_C> K2Node_DynamicCast_AsBPI_EBS_Save_Object;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_SaveData_BPI_Success : 1;  // 0xC9(0x1)
	char pad_202[6];  // 0xCA(0x6)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct AActor* CallFunc_Array_Get_Item_2;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_InitActor_BPI_Success : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object_2;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xFC(0x4)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x100(0x1)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.SavePlacables
// Size: 0x110(Inherited: 0x0) 
struct FSavePlacables
{
	struct FString Build ID;  // 0x0(0x10)
	struct FS_BuildSave New Save;  // 0x10(0xF0)
	struct UBP_EBS_SaveGame_C* SaveGame;  // 0x100(0x8)
	struct UBP_EBS_SaveGame_C* SaveGameOut;  // 0x108(0x8)

}; 
// Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.SavePlayerDataOptimized
// Size: 0x30(Inherited: 0x0) 
struct FSavePlayerDataOptimized
{
	struct FString Player ID;  // 0x0(0x10)
	struct FS_PlayerSaveOptimized Save;  // 0x10(0x20)

}; 
