#pragma once 
#include <BP_Holdable_MeeleWeapon_Harvestable_Knife_Skin_2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_Harvestable_Knife_Skin_2.BP_Holdable_MeeleWeapon_Harvestable_Knife_Skin_1_C
// Size: 0x329(Inherited: 0x329) 
struct ABP_Holdable_MeeleWeapon_Harvestable_Knife_Skin_1_C : public ABP_Holdable_MeeleWeapon_Harvestable_C
{

}; 



