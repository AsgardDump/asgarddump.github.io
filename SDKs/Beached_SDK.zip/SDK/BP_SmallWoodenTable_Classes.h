#pragma once 
#include <BP_SmallWoodenTable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SmallWoodenTable.BP_SmallWoodenTable_C
// Size: 0x228(Inherited: 0x220) 
struct ABP_SmallWoodenTable_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)

}; 



