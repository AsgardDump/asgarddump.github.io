#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.ExecuteUbergraph_BP_EBS_Building_DoorFrame
// Size: 0x9C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_Building_DoorFrame
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x4(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x10(0x8C)

}; 
// Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.OpenDoor
// Size: 0x1(Inherited: 0x0) 
struct FOpenDoor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.CloseDoor
// Size: 0x1(Inherited: 0x0) 
struct FCloseDoor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.GetSocketTransform
// Size: 0xA1(Inherited: 0x90) 
struct FGetSocketTransform : public FGetSocketTransform
{
	struct FName SocketName;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	struct FTransform Transform;  // 0x10(0x30)
	struct FTransform CallFunc_GetSocketTransform_Transform;  // 0x40(0x30)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x70(0x30)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0xA0(0x1)

}; 
// Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.GetFormatedVariables_BPI
// Size: 0x40(Inherited: 0x10) 
struct FGetFormatedVariables_BPI : public FGetFormatedVariables_BPI
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct TArray<struct FString> CallFunc_GetFormatedVariables_BPI_FormatedVariables;  // 0x10(0x10)
	struct FString CallFunc_FormatBooleanVariableToString_FormatedVariable;  // 0x20(0x10)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x30(0x10)

}; 
// Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.LoadData_BPI
// Size: 0x82(Inherited: 0x90) 
struct FLoadData_BPI : public FLoadData_BPI
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Success : 1;  // 0x8(0x1)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x10(0x10)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_LoadData_BPI_Success : 1;  // 0x21(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool CallFunc_GetActorSaveData_BPI_Success : 1;  // 0x22(0x1)
	struct FSTR_EBS_SaveData_Actor CallFunc_GetActorSaveData_BPI_SaveData;  // 0x30(0x50)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool CallFunc_GetFormatedVariableBooleanValue_Success : 1;  // 0x80(0x1)
	char pad_253_1 : 7;  // 0xFD(0x1)
	bool CallFunc_GetFormatedVariableBooleanValue_Value : 1;  // 0x81(0x1)

}; 
