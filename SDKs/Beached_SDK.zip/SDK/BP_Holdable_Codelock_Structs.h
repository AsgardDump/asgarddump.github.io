#pragma once 
#include "SDK.h" 
 
 
// Function BP_Holdable_Codelock.BP_Holdable_Codelock_C.ExecuteUbergraph_BP_Holdable_Codelock
// Size: 0x6A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Holdable_Codelock
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDataTableRowHandle K2Node_MakeStruct_DataTableRowHandle;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform Temp_struct_Variable;  // 0x20(0x30)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_Event_Pressed : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x58(0x8)
	struct UBP_EBS_BuildingComponent_C* CallFunc_AddComponent_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_HideBuildingMenu_Success : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_ShowBuildingMenu_Success : 1;  // 0x69(0x1)

}; 
// Function BP_Holdable_Codelock.BP_Holdable_Codelock_C.Aiming Action
// Size: 0x1(Inherited: 0x1) 
struct FAiming Action : public FAiming Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable_Codelock.BP_Holdable_Codelock_C.Primary Action
// Size: 0x1(Inherited: 0x1) 
struct FPrimary Action : public FPrimary Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Pressed : 1;  // 0x0(0x1)

}; 
