#pragma once 
#include "SDK.h" 
 
 
// Function BP_Fire.BP_Fire_C.ExecuteUbergraph_BP_Fire
// Size: 0xFC(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Fire
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FHitResult CallFunc_MakeHitResult_ReturnValue;  // 0x4(0x8C)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x90(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x9C(0x10)
	char pad_172[4];  // 0xAC(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xB0(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xB8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xBC(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xC5(0x1)
	char pad_198[2];  // 0xC6(0x2)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0xC8(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xD8(0xC)
	char pad_228[4];  // 0xE4(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0xE8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_ActorHasTag_ReturnValue : 1;  // 0xF4(0x1)
	char pad_245_1 : 7;  // 0xF5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xF5(0x1)
	char pad_246_1 : 7;  // 0xF6(0x1)
	bool CallFunc_ActorHasTag_ReturnValue_2 : 1;  // 0xF6(0x1)
	char pad_247[1];  // 0xF7(0x1)
	float CallFunc_ApplyPointDamage_ReturnValue;  // 0xF8(0x4)

}; 
