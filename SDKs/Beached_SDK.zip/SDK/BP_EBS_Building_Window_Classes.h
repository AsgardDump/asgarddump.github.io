#pragma once 
#include <BP_EBS_Building_Window_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Window.BP_EBS_Building_Window_C
// Size: 0x488(Inherited: 0x479) 
struct ABP_EBS_Building_Window_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct ABP_EBS_Building_WindowFrame_C* WindowFrameReference;  // 0x480(0x8)

	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_Window.BP_EBS_Building_Window_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_Window.BP_EBS_Building_Window_C.GetFormatedVariables_BPI
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_Window.BP_EBS_Building_Window_C.CheckSupport
	void CheckAndAttachToTarget(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_Window.BP_EBS_Building_Window_C.CheckAndAttachToTarget
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_Window.BP_EBS_Building_Window_C.GetSnapTransform
	void CheckBuildStatus(struct AActor* TargetActor, bool& CanBeBuilt); // Function BP_EBS_Building_Window.BP_EBS_Building_Window_C.CheckBuildStatus
	void CheckSnap(struct AActor* TargetActor, bool& CanBeSnapped); // Function BP_EBS_Building_Window.BP_EBS_Building_Window_C.CheckSnap
}; 



