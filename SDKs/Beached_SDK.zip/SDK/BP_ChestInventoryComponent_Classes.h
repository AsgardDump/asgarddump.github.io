#pragma once 
#include <BP_ChestInventoryComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ChestInventoryComponent.BP_ChestInventoryComponent_C
// Size: 0xEC(Inherited: 0xCC) 
struct UBP_ChestInventoryComponent_C : public UBP_MasterInventoryComponent_C
{
	char pad_204[4];  // 0xCC(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xD0(0x8)
	struct TArray<struct UBP_PlayerInventoryComponent_C*> Controlling Components;  // 0xD8(0x10)
	int32_t Random Loot Spawn Count;  // 0xE8(0x4)

	void Spawn Destroyed Items(); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Spawn Destroyed Items
	void Update Inventory To All Clients(); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Update Inventory To All Clients
	void Create Inventory(); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Create Inventory
	void Event Destroyed(struct AActor* DestroyedActor); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Event Destroyed
	void Reinitialize(); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Reinitialize
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.ReceiveEndPlay
	void Update All Clients Inventory(); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Update All Clients Inventory
	void ReceiveBeginPlay(); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ChestInventoryComponent(int32_t EntryPoint); // Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.ExecuteUbergraph_BP_ChestInventoryComponent
}; 



