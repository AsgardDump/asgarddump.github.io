#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatBooleanVariableToString
// Size: 0x70(Inherited: 0x0) 
struct FFormatBooleanVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Value : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FString FormatedVariable;  // 0x20(0x10)
	struct FString CallFunc_Conv_BoolToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x60(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatTransformVariableToString
// Size: 0x120(Inherited: 0x0) 
struct FFormatTransformVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	struct FTransform Value;  // 0x10(0x30)
	struct UObject* __WorldContext;  // 0x40(0x8)
	struct FString FormatedVariable;  // 0x48(0x10)
	struct FVector CallFunc_BreakTransform_Location;  // 0x58(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x64(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x70(0xC)
	char pad_124[4];  // 0x7C(0x4)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x80(0x10)
	struct FString CallFunc_Conv_VectorToString_ReturnValue;  // 0x90(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xA0(0x10)
	struct FString CallFunc_Conv_RotatorToString_ReturnValue;  // 0xB0(0x10)
	struct FString CallFunc_Conv_VectorToString_ReturnValue_2;  // 0xC0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xD0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0xE0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0xF0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x100(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x110(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedDelimiter
// Size: 0x18(Inherited: 0x0) 
struct FGetFormatedDelimiter
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct FString Delimiter;  // 0x8(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableByteValue
// Size: 0xA8(Inherited: 0x0) 
struct FGetFormatedVariableByteValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char Value;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x44(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x50(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x78(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct FString CallFunc_Array_Get_Item_3;  // 0x90(0x10)
	char CallFunc_Conv_IntToByte_ReturnValue;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xA1(0x1)
	char pad_162[2];  // 0xA2(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xA4(0x4)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatIntegerVariableToString
// Size: 0x70(Inherited: 0x0) 
struct FFormatIntegerVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	int32_t Value;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FString FormatedVariable;  // 0x20(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x60(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableBooleanValue
// Size: 0xA5(Inherited: 0x0) 
struct FGetFormatedVariableBooleanValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Value : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x44(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x50(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FString CallFunc_Array_Get_Item_3;  // 0x90(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0xA4(0x1)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatByteVariableToString
// Size: 0x70(Inherited: 0x0) 
struct FFormatByteVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	char Value;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FString FormatedVariable;  // 0x20(0x10)
	struct FString CallFunc_Conv_ByteToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x60(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatFloatVariableToString
// Size: 0x70(Inherited: 0x0) 
struct FFormatFloatVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	float Value;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FString FormatedVariable;  // 0x20(0x10)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x60(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatNameVariableToString
// Size: 0x70(Inherited: 0x0) 
struct FFormatNameVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	struct FName Value;  // 0x10(0x8)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FString FormatedVariable;  // 0x20(0x10)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x60(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatStringVariableToString
// Size: 0x68(Inherited: 0x0) 
struct FFormatStringVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FString FormatedVariable;  // 0x28(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableStringArray
// Size: 0xB0(Inherited: 0x0) 
struct FGetFormatedVariableStringArray
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<struct FString> Value;  // 0x30(0x10)
	struct TArray<struct FString> LocalStringArray;  // 0x40(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x50(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x64(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x70(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x80(0x10)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xAC(0x4)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatTextVariableToString
// Size: 0x80(Inherited: 0x0) 
struct FFormatTextVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	struct FText Value;  // 0x10(0x18)
	struct UObject* __WorldContext;  // 0x28(0x8)
	struct FString FormatedVariable;  // 0x30(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x40(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x70(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatVectorVariableToString
// Size: 0x78(Inherited: 0x0) 
struct FFormatVectorVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	struct FVector Value;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FString FormatedVariable;  // 0x28(0x10)
	struct FString CallFunc_Conv_VectorToString_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x58(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x68(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatRotatorVariableToString
// Size: 0x78(Inherited: 0x0) 
struct FFormatRotatorVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	struct FRotator Value;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FString FormatedVariable;  // 0x28(0x10)
	struct FString CallFunc_Conv_RotatorToString_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x58(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x68(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableFloatValue
// Size: 0xA5(Inherited: 0x0) 
struct FGetFormatedVariableFloatValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float Value;  // 0x2C(0x4)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x44(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x50(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x78(0x10)
	float CallFunc_Conv_StringToFloat_ReturnValue;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct FString CallFunc_Array_Get_Item_3;  // 0x90(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xA4(0x1)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableIntegerValue
// Size: 0xA5(Inherited: 0x0) 
struct FGetFormatedVariableIntegerValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Value;  // 0x2C(0x4)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x44(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x50(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x78(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct FString CallFunc_Array_Get_Item_3;  // 0x90(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xA4(0x1)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableNameValue
// Size: 0xAD(Inherited: 0x0) 
struct FGetFormatedVariableNameValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FName Value;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x38(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x58(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x80(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x90(0x8)
	struct FString CallFunc_Array_Get_Item_3;  // 0x98(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xAC(0x1)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableTransformValue
// Size: 0x154(Inherited: 0x0) 
struct FGetFormatedVariableTransformValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FTransform Value;  // 0x30(0x30)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x60(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x70(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x74(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x80(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0xA8(0x10)
	struct FVector CallFunc_Conv_StringToVector_OutConvertedVector;  // 0xB8(0xC)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_Conv_StringToVector_OutIsValid : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	struct FString CallFunc_Array_Get_Item_3;  // 0xC8(0x10)
	struct FString CallFunc_Array_Get_Item_4;  // 0xD8(0x10)
	struct FRotator CallFunc_Conv_StringToRotator_OutConvertedRotator;  // 0xE8(0xC)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_Conv_StringToRotator_OutIsValid : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	struct FVector CallFunc_Conv_StringToVector_OutConvertedVector_2;  // 0xF8(0xC)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_Conv_StringToVector_OutIsValid_2 : 1;  // 0x104(0x1)
	char pad_261[3];  // 0x105(0x3)
	struct FString CallFunc_Array_Get_Item_5;  // 0x108(0x10)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x119(0x1)
	char pad_282_1 : 7;  // 0x11A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x11A(0x1)
	char pad_283[5];  // 0x11B(0x5)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x120(0x30)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x150(0x4)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatStringArrayVariableToString
// Size: 0xC0(Inherited: 0x0) 
struct FFormatStringArrayVariableToString
{
	struct FString VariableName;  // 0x0(0x10)
	struct TArray<struct FString> Value;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FString FormatedVariable;  // 0x28(0x10)
	struct FString LocalValue;  // 0x38(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x48(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x60(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x70(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x74(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8C(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x90(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0xA0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0xB0(0x10)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableStringValue
// Size: 0xAD(Inherited: 0x0) 
struct FGetFormatedVariableStringValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString Value;  // 0x30(0x10)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x40(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x54(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x60(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x88(0x10)
	struct FString CallFunc_Array_Get_Item_3;  // 0x98(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xAC(0x1)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableTextValue
// Size: 0xCD(Inherited: 0x0) 
struct FGetFormatedVariableTextValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Value;  // 0x30(0x18)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x48(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x5C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x68(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x90(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xA0(0x18)
	struct FString CallFunc_Array_Get_Item_3;  // 0xB8(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xCC(0x1)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableVectorValue
// Size: 0xB8(Inherited: 0x0) 
struct FGetFormatedVariableVectorValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FVector Value;  // 0x2C(0xC)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x38(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x58(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x80(0x10)
	struct FVector CallFunc_Conv_StringToVector_OutConvertedVector;  // 0x90(0xC)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_Conv_StringToVector_OutIsValid : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	struct FString CallFunc_Array_Get_Item_3;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB4(0x4)

}; 
// Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableRotatorValue
// Size: 0xB8(Inherited: 0x0) 
struct FGetFormatedVariableRotatorValue
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString VariableName;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Success : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FRotator Value;  // 0x2C(0xC)
	struct FString CallFunc_GetFormatedDelimiter_Delimiter;  // 0x38(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x58(0x10)
	struct TArray<struct FString> CallFunc_ParseIntoArray_ReturnValue;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0x80(0x10)
	struct FRotator CallFunc_Conv_StringToRotator_OutConvertedRotator;  // 0x90(0xC)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_Conv_StringToRotator_OutIsValid : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	struct FString CallFunc_Array_Get_Item_3;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB4(0x4)

}; 
