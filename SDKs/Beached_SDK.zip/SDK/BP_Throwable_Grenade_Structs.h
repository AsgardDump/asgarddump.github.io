#pragma once 
#include "SDK.h" 
 
 
// Function BP_Throwable_Grenade.BP_Throwable_Grenade_C.ExecuteUbergraph_BP_Throwable_Grenade
// Size: 0x168(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Throwable_Grenade
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x20(0x30)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x58(0x8)
	float K2Node_Event_Damage;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x68(0x8)
	struct FVector K2Node_Event_HitLocation;  // 0x70(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x7C(0xC)
	struct UPrimitiveComponent* K2Node_Event_HitComponent;  // 0x88(0x8)
	struct FName K2Node_Event_BoneName;  // 0x90(0x8)
	struct FVector K2Node_Event_ShotFromDirection;  // 0x98(0xC)
	char pad_164[4];  // 0xA4(0x4)
	struct AController* K2Node_Event_InstigatedBy;  // 0xA8(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0xB0(0x8)
	struct FHitResult K2Node_Event_HitInfo;  // 0xB8(0x8C)
	char pad_324[4];  // 0x144(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x148(0x8)
	UDamageType* CallFunc_GetObjectClass_ReturnValue;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_NotEqual_ClassClass_ReturnValue : 1;  // 0x158(0x1)
	char pad_345[7];  // 0x159(0x7)
	struct ABP_Explosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x160(0x8)

}; 
// Function BP_Throwable_Grenade.BP_Throwable_Grenade_C.ReceivePointDamage
// Size: 0xE4(Inherited: 0xE8) 
struct FReceivePointDamage : public FReceivePointDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct UPrimitiveComponent* HitComponent;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	struct FVector ShotFromDirection;  // 0x38(0xC)
	struct AController* InstigatedBy;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)
	struct FHitResult HitInfo;  // 0x58(0x8C)

}; 
