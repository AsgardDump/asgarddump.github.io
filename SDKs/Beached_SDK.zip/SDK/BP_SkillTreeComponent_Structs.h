#pragma once 
#include "SDK.h" 
 
 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Add Experience
// Size: 0x8(Inherited: 0x0) 
struct FAdd Experience
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Experience Points;  // 0x4(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Add Skill Points
// Size: 0x8(Inherited: 0x0) 
struct FAdd Skill Points
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Amount;  // 0x4(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.ExecuteUbergraph_BP_SkillTreeComponent
// Size: 0x420(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SkillTreeComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	struct FText Temp_text_Variable_2;  // 0x20(0x18)
	char E_SkillType Temp_byte_Variable;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FText Temp_text_Variable_3;  // 0x40(0x18)
	struct FText Temp_text_Variable_4;  // 0x58(0x18)
	struct FText Temp_text_Variable_5;  // 0x70(0x18)
	struct FS_Notification K2Node_MakeStruct_S_Notification;  // 0x88(0x20)
	struct FText Temp_text_Variable_6;  // 0xA8(0x18)
	char E_SkillType Temp_byte_Variable_2;  // 0xC0(0x1)
	char E_SkillType K2Node_CustomEvent_Skill_Type_6;  // 0xC1(0x1)
	char pad_194[2];  // 0xC2(0x2)
	int32_t K2Node_CustomEvent_Level;  // 0xC4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0xC8(0x8)
	struct AController* K2Node_DynamicCast_AsController;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0xE0(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0xE8(0x8)
	struct AController* K2Node_DynamicCast_AsController_2;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x100(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_2;  // 0x108(0x8)
	struct AController* K2Node_DynamicCast_AsController_3;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_3;  // 0x120(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x128(0x8)
	struct AController* K2Node_DynamicCast_AsController_4;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct FText Temp_text_Variable_7;  // 0x140(0x18)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x158(0x1)
	char E_SkillType K2Node_CustomEvent_Skill_Type_5;  // 0x159(0x1)
	char pad_346[2];  // 0x15A(0x2)
	int32_t K2Node_CustomEvent_Experience_Points_2;  // 0x15C(0x4)
	char E_SkillType K2Node_CustomEvent_Skill_Type_4;  // 0x160(0x1)
	char pad_353[3];  // 0x161(0x3)
	int32_t CallFunc_Get_Skill_Level_ReturnValue;  // 0x164(0x4)
	struct FText K2Node_Select_Default;  // 0x168(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x180(0x10)
	struct FText Temp_text_Variable_8;  // 0x190(0x18)
	char E_SkillType K2Node_CustomEvent_Skill_Type_3;  // 0x1A8(0x1)
	char pad_425[3];  // 0x1A9(0x3)
	int32_t K2Node_CustomEvent_Skill_Points;  // 0x1AC(0x4)
	char E_SkillType K2Node_CustomEvent_Skill_Type_2;  // 0x1B0(0x1)
	char pad_433[3];  // 0x1B1(0x3)
	int32_t K2Node_CustomEvent_Experience_Points;  // 0x1B4(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x1B8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x1F8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x208(0x18)
	struct FText K2Node_Select_Default_2;  // 0x220(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0x238(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue_3;  // 0x248(0x10)
	int32_t CallFunc_Get_Total_Experience_Points_ReturnValue;  // 0x258(0x4)
	char pad_604[4];  // 0x25C(0x4)
	struct FS_Notification K2Node_MakeStruct_S_Notification_2;  // 0x260(0x20)
	char E_SkillType K2Node_CustomEvent_Skill_Type;  // 0x280(0x1)
	char pad_641[3];  // 0x281(0x3)
	int32_t K2Node_CustomEvent_Amount;  // 0x284(0x4)
	int32_t CallFunc_Get_Skill_Points_ReturnValue;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)
	struct TArray<struct FS_SkillDatabase> K2Node_CustomEvent_Unlocked_Skills_2;  // 0x290(0x10)
	struct FS_CurrentSkills K2Node_CustomEvent_Current_Skill_Abilities_2;  // 0x2A0(0x18)
	struct FS_SkillDataSave K2Node_CustomEvent_Survivor_Skill_Data;  // 0x2B8(0xC)
	struct FS_SkillDataSave K2Node_CustomEvent_Agility_Skill_Data;  // 0x2C4(0xC)
	struct FS_SkillDataSave K2Node_CustomEvent_Power_Skill_Data;  // 0x2D0(0xC)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2DC(0x4)
	struct FS_CurrentSkills K2Node_CustomEvent_Current_Skill_Abilities;  // 0x2E0(0x18)
	struct TArray<struct FS_SkillDatabase> K2Node_CustomEvent_Unlocked_Skills;  // 0x2F8(0x10)
	struct FText Temp_text_Variable_9;  // 0x308(0x18)
	struct UDataTable* K2Node_CustomEvent_Datatable;  // 0x320(0x8)
	struct FName K2Node_CustomEvent_Skill_ID;  // 0x328(0x8)
	struct FS_SkillTreeMaster CallFunc_GetDataTableRowFromName_OutRow;  // 0x330(0x60)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x390(0x1)
	char pad_913[7];  // 0x391(0x7)
	struct FS_SkillDatabase K2Node_MakeStruct_S_SkillDatabase;  // 0x398(0x10)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool CallFunc_Can_Be_Skill_Unlocked__Success : 1;  // 0x3A8(0x1)
	char pad_937[3];  // 0x3A9(0x3)
	struct FS_CurrentSkills CallFunc_Update_Skill_Abilities_Current_Skill_Abilities;  // 0x3AC(0x18)
	char E_SkillType Temp_byte_Variable_3;  // 0x3C4(0x1)
	char pad_965[3];  // 0x3C5(0x3)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x3C8(0x4)
	char pad_972[4];  // 0x3CC(0x4)
	struct FText K2Node_Select_Default_3;  // 0x3D0(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue_4;  // 0x3E8(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x3F8(0x4)
	char pad_1020[4];  // 0x3FC(0x4)
	struct FS_Notification K2Node_MakeStruct_S_Notification_3;  // 0x400(0x20)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Unlock Skill
// Size: 0x10(Inherited: 0x0) 
struct FUnlock Skill
{
	struct UDataTable* DataTable;  // 0x0(0x8)
	struct FName Skill ID;  // 0x8(0x8)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Skill Points
// Size: 0x8(Inherited: 0x0) 
struct FSERVER Set Skill Points
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Skill Points;  // 0x4(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Skill Maximum Level
// Size: 0x10(Inherited: 0x0) 
struct FGet Skill Maximum Level
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)
	char E_SkillType Temp_byte_Variable;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t K2Node_Select_Default;  // 0xC(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Data
// Size: 0x28(Inherited: 0x0) 
struct FSERVER Set Data
{
	struct FS_CurrentSkills Current Skill Abilities;  // 0x0(0x18)
	struct TArray<struct FS_SkillDatabase> Unlocked Skills;  // 0x18(0x10)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Skill Points
// Size: 0x10(Inherited: 0x0) 
struct FGet Skill Points
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)
	char E_SkillType Temp_byte_Variable;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t K2Node_Select_Default;  // 0xC(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.CLIENT Load Skill Data
// Size: 0x4C(Inherited: 0x0) 
struct FCLIENT Load Skill Data
{
	struct TArray<struct FS_SkillDatabase> Unlocked Skills;  // 0x0(0x10)
	struct FS_CurrentSkills Current Skill Abilities;  // 0x10(0x18)
	struct FS_SkillDataSave Survivor Skill Data;  // 0x28(0xC)
	struct FS_SkillDataSave Agility Skill Data;  // 0x34(0xC)
	struct FS_SkillDataSave Power Skill Data;  // 0x40(0xC)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Event On Level Up
// Size: 0x1(Inherited: 0x0) 
struct FEvent On Level Up
{
	char E_SkillType Skill Type;  // 0x0(0x1)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Experience Points
// Size: 0x8(Inherited: 0x0) 
struct FSERVER Set Experience Points
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Experience Points;  // 0x4(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Skill Level
// Size: 0x10(Inherited: 0x0) 
struct FGet Skill Level
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)
	char E_SkillType Temp_byte_Variable;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t K2Node_Select_Default;  // 0xC(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Level
// Size: 0x8(Inherited: 0x0) 
struct FSERVER Set Level
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Level;  // 0x4(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Can Be Skill Unlocked?
// Size: 0xE5(Inherited: 0x0) 
struct FCan Be Skill Unlocked?
{
	struct FS_SkillDatabase skill;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FS_SkillTreeMaster Skill Data L;  // 0x18(0x60)
	struct FS_SkillTreeMaster CallFunc_GetDataTableRowFromName_OutRow;  // 0x78(0x60)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xDA(0x1)
	char pad_219_1 : 7;  // 0xDB(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0xDB(0x1)
	char E_SkillType Temp_byte_Variable;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	int32_t K2Node_Select_Default;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0xE4(0x1)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Update Skill Abilities
// Size: 0x9D(Inherited: 0x0) 
struct FUpdate Skill Abilities
{
	struct FS_SkillTreeMaster skill;  // 0x0(0x60)
	struct FS_CurrentSkills Current Skill Abilities;  // 0x60(0x18)
	float New Value | Float;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool New Value | Bool : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x80(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x90(0x4)
	struct FS_SkillToUnlock CallFunc_Array_Get_Item;  // 0x94(0x8)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x9C(0x1)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Update Experience
// Size: 0x5C(Inherited: 0x0) 
struct FUpdate Experience
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Experience Points;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t CallFunc_Get_Skill_Maximum_Level_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Get_Skill_Level_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Get_Skill_Maximum_Level_ReturnValue_2;  // 0x1C(0x4)
	int32_t CallFunc_Get_Skill_Level_ReturnValue_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	int32_t CallFunc_Get_Level_Information_Maximum_Total_XP;  // 0x28(0x4)
	int32_t CallFunc_Get_Level_Information_Minimum_Total_XP;  // 0x2C(0x4)
	int32_t CallFunc_Get_Total_Experience_Points_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t CallFunc_Get_Skill_Maximum_Level_ReturnValue_3;  // 0x38(0x4)
	int32_t CallFunc_Get_Level_Information_Maximum_Total_XP_2;  // 0x3C(0x4)
	int32_t CallFunc_Get_Level_Information_Minimum_Total_XP_2;  // 0x40(0x4)
	int32_t CallFunc_Get_Skill_Level_ReturnValue_3;  // 0x44(0x4)
	int32_t CallFunc_Get_Level_Information_Maximum_Total_XP_3;  // 0x48(0x4)
	int32_t CallFunc_Get_Level_Information_Minimum_Total_XP_3;  // 0x4C(0x4)
	int32_t CallFunc_Get_Total_Experience_Points_ReturnValue_2;  // 0x50(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x54(0x4)
	int32_t CallFunc_Clamp_ReturnValue_2;  // 0x58(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Set Skill Level
// Size: 0x9(Inherited: 0x0) 
struct FSet Skill Level
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Level;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x8(0x1)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Set Skill Points
// Size: 0x9(Inherited: 0x0) 
struct FSet Skill Points
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Skill Points;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x8(0x1)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Level Information
// Size: 0x34(Inherited: 0x0) 
struct FGet Level Information
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Level;  // 0x4(0x4)
	int32_t Maximum Total XP;  // 0x8(0x4)
	int32_t Minimum Total XP;  // 0xC(0x4)
	int32_t CallFunc_Get_Level_Experience_Range_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Get_Level_Experience_Range_ReturnValue_2;  // 0x14(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x18(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0x20(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x24(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_3;  // 0x28(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Level Experience Range
// Size: 0x10(Inherited: 0x0) 
struct FGet Level Experience Range
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)
	char E_SkillType Temp_byte_Variable;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t K2Node_Select_Default;  // 0xC(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Total Experience Points
// Size: 0x10(Inherited: 0x0) 
struct FGet Total Experience Points
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)
	char E_SkillType Temp_byte_Variable;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t K2Node_Select_Default;  // 0xC(0x4)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Set Skill Experience Points
// Size: 0x9(Inherited: 0x0) 
struct FSet Skill Experience Points
{
	char E_SkillType Skill Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Experience Points;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x8(0x1)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Player Pawn
// Size: 0x28(Inherited: 0x0) 
struct FGet Player Pawn
{
	struct APawn* ReturnValue;  // 0x0(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct AController* K2Node_DynamicCast_AsController;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x20(0x8)

}; 
// Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Save Player Data
// Size: 0x11(Inherited: 0x0) 
struct FSave Player Data
{
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x0(0x8)
	struct AController* K2Node_DynamicCast_AsController;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
