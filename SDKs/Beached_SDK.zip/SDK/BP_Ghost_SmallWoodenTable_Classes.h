#pragma once 
#include <BP_Ghost_SmallWoodenTable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_SmallWoodenTable.BP_Ghost_SmallWoodenTable_C
// Size: 0x280(Inherited: 0x280) 
struct ABP_Ghost_SmallWoodenTable_C : public ABP_GhostActor_C
{

	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_SmallWoodenTable.BP_Ghost_SmallWoodenTable_C.Custom Condition Pass
}; 



