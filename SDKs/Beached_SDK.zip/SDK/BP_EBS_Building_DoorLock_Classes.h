#pragma once 
#include <BP_EBS_Building_DoorLock_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C
// Size: 0x4B8(Inherited: 0x479) 
struct ABP_EBS_Building_DoorLock_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x480(0x8)
	struct ABP_EBS_Building_Door_C* DoorReference;  // 0x488(0x8)
	char pad_1168_1 : 7;  // 0x490(0x1)
	bool IsLocked : 1;  // 0x490(0x1)
	char pad_1169[7];  // 0x491(0x7)
	struct TArray<struct FString> AuthorizedPlayers;  // 0x498(0x10)
	struct USoundBase* OpenLockSound;  // 0x4A8(0x8)
	struct USoundBase* CloseLockSound;  // 0x4B0(0x8)

	void IsCanInteract_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.IsCanInteract_BPI
	void GetInteractionObjectName_BPI(struct FText& Name); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetInteractionObjectName_BPI
	void GetInteractionText_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, struct FText& InteractionText); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetInteractionText_BPI
	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetFormatedVariables_BPI
	void OnRep_IsLocked(); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.OnRep_IsLocked
	void CheckAuthorizedPlayer(struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckAuthorizedPlayer
	void Unlock(bool& Success); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.Unlock
	void UnlockByPlayer(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.UnlockByPlayer
	void LockByPlayer(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.LockByPlayer
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckSupport
	void CheckAndAttachToTarget(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckAndAttachToTarget
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetSnapTransform
	void CheckBuildStatus(struct AActor* TargetActor, bool& CanBeBuilt); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckBuildStatus
	void CheckSnap(struct AActor* TargetActor, bool& CanBeSnapped); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckSnap
	void TryInteract_BPI(bool Released, struct FKey InteractionKey, struct APlayerController* PlayerController); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.TryInteract_BPI
	void CompleteInteractionNotify_BPI(struct APlayerController* PlayerController, struct FName NotifyName); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CompleteInteractionNotify_BPI
	void PlayOpenLockSound (Multicast)(); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.PlayOpenLockSound (Multicast)
	void PlayCloseLockSound (Multicast)(); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.PlayCloseLockSound (Multicast)
	void ExecuteUbergraph_BP_EBS_Building_DoorLock(int32_t EntryPoint); // Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.ExecuteUbergraph_BP_EBS_Building_DoorLock
}; 



