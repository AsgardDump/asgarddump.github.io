#pragma once 
#include "SDK.h" 
 
 
// Function BP_GarageDoors.BP_GarageDoors_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_GarageDoors.BP_GarageDoors_C.ExecuteUbergraph_BP_GarageDoors
// Size: 0x1C0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GarageDoors
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x8(0x10)
	struct AActor* CallFunc_GetParentActor_ReturnValue;  // 0x18(0x8)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct AController* K2Node_Event_Executor;  // 0x30(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct FString CallFunc_Get_Player_Unique_ID_Unique_ID;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Is_In_Cupboard_Return : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool K2Node_CustomEvent_Toggle : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91[1];  // 0x5B(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x5C(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x68(0xC)
	char pad_116[4];  // 0x74(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x78(0x10)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x88(0xC)
	struct FHitResult CallFunc_BoxTraceSingleForObjects_OutHit;  // 0x94(0x8C)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_BoxTraceSingleForObjects_ReturnValue : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x124(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x128(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x134(0x8C)

}; 
// Function BP_GarageDoors.BP_GarageDoors_C.Toggle Doors
// Size: 0x1(Inherited: 0x0) 
struct FToggle Doors
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_GarageDoors.BP_GarageDoors_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_GarageDoors.BP_GarageDoors_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_GarageDoors.BP_GarageDoors_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_GarageDoors.BP_GarageDoors_C.Get Interaction Data
// Size: 0x68(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText Temp_text_Variable;  // 0x20(0x18)
	struct FText Temp_text_Variable_2;  // 0x38(0x18)
	struct FText K2Node_Select_Default;  // 0x50(0x18)

}; 
