#pragma once 
#include <BP_Holdable_Molotov_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_Molotov.BP_Holdable_Molotov_C
// Size: 0x378(Inherited: 0x370) 
struct ABP_Holdable_Molotov_C : public ABP_Holdable_Throwable_C
{
	struct UParticleSystemComponent* ParticleSystem;  // 0x370(0x8)

}; 



