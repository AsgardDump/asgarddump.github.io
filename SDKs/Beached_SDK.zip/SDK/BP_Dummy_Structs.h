#pragma once 
#include "SDK.h" 
 
 
// Function BP_Dummy.BP_Dummy_C.ExecuteUbergraph_BP_Dummy
// Size: 0x260(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Dummy
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x10(0x8)
	float K2Node_Event_Damage_2;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UDamageType* K2Node_Event_DamageType_2;  // 0x20(0x8)
	struct FVector K2Node_Event_HitLocation;  // 0x28(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x34(0xC)
	struct UPrimitiveComponent* K2Node_Event_HitComponent;  // 0x40(0x8)
	struct FName K2Node_Event_BoneName;  // 0x48(0x8)
	struct FVector K2Node_Event_ShotFromDirection;  // 0x50(0xC)
	char pad_92[4];  // 0x5C(0x4)
	struct AController* K2Node_Event_InstigatedBy_2;  // 0x60(0x8)
	struct AActor* K2Node_Event_DamageCauser_2;  // 0x68(0x8)
	struct FHitResult K2Node_Event_HitInfo;  // 0x70(0x8C)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue;  // 0xFC(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x108(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x10C(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x110(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x114(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x120(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue_2;  // 0x12C(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x138(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0x144(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x148(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x14C(0x4)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x150(0x8C)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x1DC(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue_3;  // 0x1E8(0xC)
	struct FRotator CallFunc_NormalizedDeltaRotator_ReturnValue;  // 0x1F4(0xC)
	float CallFunc_BreakRotator_Roll_3;  // 0x200(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x204(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x208(0x4)
	float CallFunc_BreakRotator_Roll_4;  // 0x20C(0x4)
	float CallFunc_BreakRotator_Pitch_4;  // 0x210(0x4)
	float CallFunc_BreakRotator_Yaw_4;  // 0x214(0x4)
	float CallFunc_DegSin_ReturnValue;  // 0x218(0x4)
	float CallFunc_DegCos_ReturnValue;  // 0x21C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x220(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x224(0x4)
	struct FRotator K2Node_CustomEvent_Target_Rotation;  // 0x228(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0x234(0xC)
	float K2Node_Event_Damage;  // 0x240(0x4)
	char pad_580[4];  // 0x244(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x248(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x250(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x258(0x8)

}; 
// Function BP_Dummy.BP_Dummy_C.ReceivePointDamage
// Size: 0xE4(Inherited: 0xE8) 
struct FReceivePointDamage : public FReceivePointDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct UPrimitiveComponent* HitComponent;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	struct FVector ShotFromDirection;  // 0x38(0xC)
	struct AController* InstigatedBy;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)
	struct FHitResult HitInfo;  // 0x58(0x8C)

}; 
// Function BP_Dummy.BP_Dummy_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function BP_Dummy.BP_Dummy_C.MULTICAST Hit Effect
// Size: 0xC(Inherited: 0x0) 
struct FMULTICAST Hit Effect
{
	struct FRotator Target Rotation;  // 0x0(0xC)

}; 
