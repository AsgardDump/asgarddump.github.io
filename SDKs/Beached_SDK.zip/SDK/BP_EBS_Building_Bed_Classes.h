#pragma once 
#include <BP_EBS_Building_Bed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Bed.BP_EBS_Building_Bed_C
// Size: 0x4F4(Inherited: 0x4A8) 
struct ABP_EBS_Building_Bed_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct USphereComponent* OwnershipCollision;  // 0x4B0(0x8)
	struct UBoxComponent* BuildCollision;  // 0x4B8(0x8)
	struct UBoxComponent* SupportChecker4;  // 0x4C0(0x8)
	struct UBoxComponent* SupportChecker3;  // 0x4C8(0x8)
	struct UBoxComponent* SupportChecker2;  // 0x4D0(0x8)
	char pad_1240_1 : 7;  // 0x4D8(0x1)
	bool IsOwned : 1;  // 0x4D8(0x1)
	char pad_1241[7];  // 0x4D9(0x7)
	struct TArray<struct FString> OwnerNames;  // 0x4E0(0x10)
	float OwnershipDistance;  // 0x4F0(0x4)

	void IsCanInteract_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.IsCanInteract_BPI
	void GetInteractionObjectName_BPI(struct FText& Name); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.GetInteractionObjectName_BPI
	void GetInteractionText_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, struct FText& InteractionText); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.GetInteractionText_BPI
	void GetOwners_BPI(struct TArray<struct FString>& OwnerNames); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.GetOwners_BPI
	void CheckPlayerIsOwner_BPI(struct APlayerController* PlayerController, bool& IsOwner); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.CheckPlayerIsOwner_BPI
	void GetOwnershipInfo_BPI(bool& IsOwned, struct TArray<struct FString>& OwnerNames, float& OwnershipDistance); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.GetOwnershipInfo_BPI
	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.GetFormatedVariables_BPI
	void UserConstructionScript(); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.UserConstructionScript
	void CompleteInteractionNotify_BPI(struct APlayerController* PlayerController, struct FName NotifyName); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.CompleteInteractionNotify_BPI
	void TryInteract_BPI(bool Released, struct FKey InteractionKey, struct APlayerController* PlayerController); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.TryInteract_BPI
	void AddOwner_BPI(struct APlayerController* PlayerController); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.AddOwner_BPI
	void RemoveOwner_BPI(struct APlayerController* PlayerController); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.RemoveOwner_BPI
	void ExecuteUbergraph_BP_EBS_Building_Bed(int32_t EntryPoint); // Function BP_EBS_Building_Bed.BP_EBS_Building_Bed_C.ExecuteUbergraph_BP_EBS_Building_Bed
}; 



