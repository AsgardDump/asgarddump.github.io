#pragma once 
#include <BP_Holdable_MeeleWeapon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon.BP_Holdable_MeeleWeapon_C
// Size: 0x31C(Inherited: 0x30A) 
struct ABP_Holdable_MeeleWeapon_C : public ABP_Holdable_C
{
	char pad_778[2];  // 0x30A(0x2)
	float Damage;  // 0x30C(0x4)
	UDamageType* Damage Type;  // 0x310(0x8)
	float Minus Durability;  // 0x318(0x4)

}; 



