#pragma once 
#include <BP_Furnace_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Furnace.BP_Furnace_C
// Size: 0x240(Inherited: 0x240) 
struct ABP_Furnace_C : public ABP_Crafting_Master_C
{

}; 



