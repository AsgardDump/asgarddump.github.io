#pragma once 
#include "SDK.h" 
 
 
// Function BFL_LobbySystem.BFL_LobbySystem_C.Get Lobby Component
// Size: 0x61(Inherited: 0x0) 
struct FGet Lobby Component
{
	struct UObject* Player Controller;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UBP_LobbyComponent_C* BP_LobbyComponent;  // 0x10(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x18(0x10)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x38(0x10)
	struct UBP_LobbyComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x48(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)

}; 
// Function BFL_LobbySystem.BFL_LobbySystem_C.Get Player Name
// Size: 0x50(Inherited: 0x0) 
struct FGet Player Name
{
	struct APlayerController* Controller;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FString Name;  // 0x10(0x10)
	struct FBPUniqueNetId CallFunc_GetUniqueNetID_UniqueNetId;  // 0x20(0x20)
	struct FString CallFunc_GetSteamPersonaName_ReturnValue;  // 0x40(0x10)

}; 
// Function BFL_LobbySystem.BFL_LobbySystem_C.Get Player Unique ID
// Size: 0x50(Inherited: 0x0) 
struct FGet Player Unique ID
{
	struct APlayerController* Controller;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FString Unique ID;  // 0x10(0x10)
	struct FBPUniqueNetId CallFunc_GetUniqueNetID_UniqueNetId;  // 0x20(0x20)
	struct FString CallFunc_UniqueNetIdToString_String;  // 0x40(0x10)

}; 
// Function BFL_LobbySystem.BFL_LobbySystem_C.Get Player Icon
// Size: 0x51(Inherited: 0x0) 
struct FGet Player Icon
{
	struct FString Unique ID;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UTexture2D* Icon;  // 0x18(0x8)
	struct FBPUniqueNetId CallFunc_CreateSteamIDFromString_ReturnValue;  // 0x20(0x20)
	uint8_t  CallFunc_GetSteamFriendAvatar_Result;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UTexture2D* CallFunc_GetSteamFriendAvatar_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x50(0x1)

}; 
// Function BFL_LobbySystem.BFL_LobbySystem_C.Get Online Component
// Size: 0x61(Inherited: 0x0) 
struct FGet Online Component
{
	struct UObject* Player Controller;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UBP_OnlineComponent_C* BP_OnlineComponent;  // 0x10(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x18(0x10)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x38(0x10)
	struct UBP_OnlineComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x48(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)

}; 
