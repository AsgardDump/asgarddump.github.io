#pragma once 
#include <BP_EBS_Building_Ceiling_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Ceiling.BP_EBS_Building_Ceiling_C
// Size: 0x520(Inherited: 0x479) 
struct ABP_EBS_Building_Ceiling_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct USceneComponent* RoofSocket;  // 0x480(0x8)
	struct USceneComponent* FloorSocket;  // 0x488(0x8)
	struct USceneComponent* StairsSocket;  // 0x490(0x8)
	struct USceneComponent* WallSockets;  // 0x498(0x8)
	struct USceneComponent* TriangleCeilingSockets;  // 0x4A0(0x8)
	struct USceneComponent* CeilingSockets;  // 0x4A8(0x8)
	struct UBoxComponent* BuildCollision;  // 0x4B0(0x8)
	struct USceneComponent* BuildComponents;  // 0x4B8(0x8)
	struct USceneComponent* TriangleCeilingSocket4;  // 0x4C0(0x8)
	struct USceneComponent* TriangleCeilingSocket3;  // 0x4C8(0x8)
	struct USceneComponent* TriangleCeilingSocket2;  // 0x4D0(0x8)
	struct USceneComponent* TriangleCeilingSocket1;  // 0x4D8(0x8)
	struct USceneComponent* WallSocket4;  // 0x4E0(0x8)
	struct USceneComponent* WallSocket3;  // 0x4E8(0x8)
	struct USceneComponent* WallSocket2;  // 0x4F0(0x8)
	struct USceneComponent* WallSocket1;  // 0x4F8(0x8)
	struct USceneComponent* CeilingSocket4;  // 0x500(0x8)
	struct USceneComponent* CeilingSocket3;  // 0x508(0x8)
	struct USceneComponent* CeilingSocket2;  // 0x510(0x8)
	struct USceneComponent* CeilingSocket1;  // 0x518(0x8)

	void SetFloorNumberByTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_Ceiling.BP_EBS_Building_Ceiling_C.SetFloorNumberByTargetActor
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_Ceiling.BP_EBS_Building_Ceiling_C.CheckSupport
}; 



