#pragma once 
#include <BP_Buggy_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Buggy.BP_Buggy_C
// Size: 0x3E0(Inherited: 0x290) 
struct ABP_Buggy_C : public AWheeledVehicle
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct USceneComponent* Passenger Location;  // 0x298(0x8)
	struct USpotLightComponent* SpotLight;  // 0x2A0(0x8)
	struct UBoxComponent* Damage Box;  // 0x2A8(0x8)
	struct UParticleSystemComponent* P_ExhaustSmoke1;  // 0x2B0(0x8)
	struct UParticleSystemComponent* P_ExhaustSmoke;  // 0x2B8(0x8)
	struct UStaticMeshComponent* Collision Body;  // 0x2C0(0x8)
	struct USceneComponent* Driver Location;  // 0x2C8(0x8)
	struct UAudioComponent* Audio;  // 0x2D0(0x8)
	struct UCameraComponent* ChaseCamera;  // 0x2D8(0x8)
	struct USpringArmComponent* SpringArm;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool IsInCar : 1;  // 0x2E8(0x1)
	char pad_745[3];  // 0x2E9(0x3)
	struct FLinearColor GearDisplayColor;  // 0x2EC(0x10)
	struct FLinearColor GearDisplayReverseColor;  // 0x2FC(0x10)
	char pad_780[4];  // 0x30C(0x4)
	struct FString Speed Display String;  // 0x310(0x10)
	struct FString Gear Display String;  // 0x320(0x10)
	struct FTransform Transform;  // 0x330(0x30)
	struct AAIController* AI Controller;  // 0x360(0x8)
	float Fuel Amount;  // 0x368(0x4)
	char pad_876[4];  // 0x36C(0x4)
	struct FTimerHandle Fuel Decerase Timer Handle;  // 0x370(0x8)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool Is Player Controlled : 1;  // 0x378(0x1)
	char pad_889_1 : 7;  // 0x379(0x1)
	bool Headlights : 1;  // 0x379(0x1)
	char pad_890[2];  // 0x37A(0x2)
	float Health;  // 0x37C(0x4)
	float Maximum Health;  // 0x380(0x4)
	float Fuel Decerase Time;  // 0x384(0x4)
	struct UMaterialInstanceDynamic* Dynamic Buggy Material;  // 0x388(0x8)
	struct UParticleSystemComponent* Fire Emitter;  // 0x390(0x8)
	struct ABP_CarSpawner_C* Spawner Reference;  // 0x398(0x8)
	struct UAudioComponent* Horn Sound;  // 0x3A0(0x8)
	struct FVector Color;  // 0x3A8(0xC)
	char pad_948[4];  // 0x3B4(0x4)
	struct TArray<bool> Passengers;  // 0x3B8(0x10)
	char pad_968_1 : 7;  // 0x3C8(0x1)
	bool Is Engine On : 1;  // 0x3C8(0x1)
	char pad_969[7];  // 0x3C9(0x7)
	struct FString Unique ID;  // 0x3D0(0x10)

	void Passenger DIsmount Request(struct USceneComponent* From Attach Point, bool Info Call Only, struct FVector& Dismount Location); // Function BP_Buggy.BP_Buggy_C.Passenger DIsmount Request
	void Add Health to Vehicle(float Amount, bool& Success); // Function BP_Buggy.BP_Buggy_C.Add Health to Vehicle
	void Remove Fuel(float& Add Durability); // Function BP_Buggy.BP_Buggy_C.Remove Fuel
	void Add Fuel(float Fuel Amount, float& Take Durability); // Function BP_Buggy.BP_Buggy_C.Add Fuel
	void Get Fuel(float& Fuel Amount, float& Max Fuel); // Function BP_Buggy.BP_Buggy_C.Get Fuel
	void Local Can Overlap(bool& Success); // Function BP_Buggy.BP_Buggy_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_Buggy.BP_Buggy_C.Get Interaction Data
	void Unsave Vehicle(); // Function BP_Buggy.BP_Buggy_C.Unsave Vehicle
	void Find Dismount Location(struct FVector& Output_Get); // Function BP_Buggy.BP_Buggy_C.Find Dismount Location
	void Change Color(); // Function BP_Buggy.BP_Buggy_C.Change Color
	void Save Vehicle(); // Function BP_Buggy.BP_Buggy_C.Save Vehicle
	void OnRep_Is Engine On(); // Function BP_Buggy.BP_Buggy_C.OnRep_Is Engine On
	void Water Deepness(float& Deepness); // Function BP_Buggy.BP_Buggy_C.Water Deepness
	void OnRep_Color(); // Function BP_Buggy.BP_Buggy_C.OnRep_Color
	void Possess To Character(); // Function BP_Buggy.BP_Buggy_C.Possess To Character
	void Possess To Vehicle(struct AController* Target); // Function BP_Buggy.BP_Buggy_C.Possess To Vehicle
	void OnRep_Is Player Controlled(); // Function BP_Buggy.BP_Buggy_C.OnRep_Is Player Controlled
	void On Destroyed(); // Function BP_Buggy.BP_Buggy_C.On Destroyed
	void OnRep_Headlights(); // Function BP_Buggy.BP_Buggy_C.OnRep_Headlights
	void OnRep_Fuel Amount(); // Function BP_Buggy.BP_Buggy_C.OnRep_Fuel Amount
	void Decerase Fuel(); // Function BP_Buggy.BP_Buggy_C.Decerase Fuel
	void Toggle Simulate Physics(bool Toggle); // Function BP_Buggy.BP_Buggy_C.Toggle Simulate Physics
	void UserConstructionScript(); // Function BP_Buggy.BP_Buggy_C.UserConstructionScript
	void InpActEvt_SpaceBar_K2Node_InputKeyEvent_6(struct FKey Key); // Function BP_Buggy.BP_Buggy_C.InpActEvt_SpaceBar_K2Node_InputKeyEvent_6
	void InpActEvt_SpaceBar_K2Node_InputKeyEvent_5(struct FKey Key); // Function BP_Buggy.BP_Buggy_C.InpActEvt_SpaceBar_K2Node_InputKeyEvent_5
	void InpActEvt_E_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_Buggy.BP_Buggy_C.InpActEvt_E_K2Node_InputKeyEvent_4
	void InpActEvt_F_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_Buggy.BP_Buggy_C.InpActEvt_F_K2Node_InputKeyEvent_3
	void InpActEvt_G_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_Buggy.BP_Buggy_C.InpActEvt_G_K2Node_InputKeyEvent_2
	void InpActEvt_G_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_Buggy.BP_Buggy_C.InpActEvt_G_K2Node_InputKeyEvent_1
	void Local Overlap(bool Overlap); // Function BP_Buggy.BP_Buggy_C.Local Overlap
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7(float AxisValue); // Function BP_Buggy.BP_Buggy_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7
	void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16(float AxisValue); // Function BP_Buggy.BP_Buggy_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16
	void ReceiveTick(float DeltaSeconds); // Function BP_Buggy.BP_Buggy_C.ReceiveTick
	void SERVER Set Transform(struct FTransform Transform); // Function BP_Buggy.BP_Buggy_C.SERVER Set Transform
	void ReceiveUnpossessed(struct AController* OldController); // Function BP_Buggy.BP_Buggy_C.ReceiveUnpossessed
	void ReceiveBeginPlay(); // Function BP_Buggy.BP_Buggy_C.ReceiveBeginPlay
	void On Interacted(struct AController* Executor); // Function BP_Buggy.BP_Buggy_C.On Interacted
	void InpAxisEvt_LookUp_K2Node_InputAxisEvent_41(float AxisValue); // Function BP_Buggy.BP_Buggy_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_41
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_48(float AxisValue); // Function BP_Buggy.BP_Buggy_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_48
	void ReceivePossessed(struct AController* NewController); // Function BP_Buggy.BP_Buggy_C.ReceivePossessed
	void SERVER Toggle Headlights(bool Headlights); // Function BP_Buggy.BP_Buggy_C.SERVER Toggle Headlights
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_Buggy.BP_Buggy_C.ReceiveAnyDamage
	void Unpossess Player(); // Function BP_Buggy.BP_Buggy_C.Unpossess Player
	void Explode(); // Function BP_Buggy.BP_Buggy_C.Explode
	void MULTICAST On Death(); // Function BP_Buggy.BP_Buggy_C.MULTICAST On Death
	void Toggle Engine(bool Toggle); // Function BP_Buggy.BP_Buggy_C.Toggle Engine
	void MULTICAST On Destroyed(); // Function BP_Buggy.BP_Buggy_C.MULTICAST On Destroyed
	void MULTICAST Disembark(struct ACharacter* Target, struct FVector NewLocation); // Function BP_Buggy.BP_Buggy_C.MULTICAST Disembark
	void ReceiveDestroyed(); // Function BP_Buggy.BP_Buggy_C.ReceiveDestroyed
	void SERVER Start Horn(); // Function BP_Buggy.BP_Buggy_C.SERVER Start Horn
	void MULTICAST Start Horn(); // Function BP_Buggy.BP_Buggy_C.MULTICAST Start Horn
	void SERVER Stop Horn(); // Function BP_Buggy.BP_Buggy_C.SERVER Stop Horn
	void MULTICAST Stop Horn(); // Function BP_Buggy.BP_Buggy_C.MULTICAST Stop Horn
	void BndEvt__Sedan_Damage Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Buggy.BP_Buggy_C.BndEvt__Sedan_Damage Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void Apply Point Damage(struct AActor* DamagedActor); // Function BP_Buggy.BP_Buggy_C.Apply Point Damage
	void Toggle Selected(bool Toggle); // Function BP_Buggy.BP_Buggy_C.Toggle Selected
	void Update Camera Rotation Lag(); // Function BP_Buggy.BP_Buggy_C.Update Camera Rotation Lag
	void SERVER Set Engine Value(bool Is Engine On); // Function BP_Buggy.BP_Buggy_C.SERVER Set Engine Value
	void ExecuteUbergraph_BP_Buggy(int32_t EntryPoint); // Function BP_Buggy.BP_Buggy_C.ExecuteUbergraph_BP_Buggy
}; 



