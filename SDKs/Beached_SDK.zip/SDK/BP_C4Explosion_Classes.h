#pragma once 
#include <BP_C4Explosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_C4Explosion.BP_C4Explosion_C
// Size: 0x244(Inherited: 0x220) 
struct ABP_C4Explosion_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* Box;  // 0x228(0x8)
	struct URadialForceComponent* RadialForce;  // 0x230(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x238(0x8)
	float Base Damage;  // 0x240(0x4)

	void Apply Explosion Damage(); // Function BP_C4Explosion.BP_C4Explosion_C.Apply Explosion Damage
	void UserConstructionScript(); // Function BP_C4Explosion.BP_C4Explosion_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_C4Explosion.BP_C4Explosion_C.ReceiveBeginPlay
	void BndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature(struct UParticleSystemComponent* PSystem); // Function BP_C4Explosion.BP_C4Explosion_C.BndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature
	void ExecuteUbergraph_BP_C4Explosion(int32_t EntryPoint); // Function BP_C4Explosion.BP_C4Explosion_C.ExecuteUbergraph_BP_C4Explosion
}; 



