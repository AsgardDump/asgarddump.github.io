#pragma once 
#include "SDK.h" 
 
 
// Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Create Inventory
// Size: 0x14A(Inherited: 0x4D) 
struct FCreate Inventory : public FCreate Inventory
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x8(0x10)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x18(0x1)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x1C(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x24(0x4)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0x28(0x1)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0x30(0xE0)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue_2;  // 0x110(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x114(0x4)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0x118(0x30)
	char pad_391_1 : 7;  // 0x187(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x148(0x1)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x149(0x1)

}; 
// Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.ExecuteUbergraph_BP_ChestInventoryComponent
// Size: 0x280(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ChestInventoryComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x8(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x20(0x8)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x28(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x30(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x38(0x10)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x48(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x58(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x5A(0x1)
	char pad_91[5];  // 0x5B(0x5)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x60(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[15];  // 0x81(0xF)
	struct FS_BuildSave CallFunc_Get_Saved_Build_Data_Saved_Data;  // 0x90(0xF0)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_Get_Saved_Build_Data_ReturnValue : 1;  // 0x180(0x1)
	char pad_385[15];  // 0x181(0xF)
	struct FS_BuildSave K2Node_MakeStruct_S_BuildSave;  // 0x190(0xF0)

}; 
// Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Update Inventory To All Clients
// Size: 0x39(Inherited: 0x0) 
struct FUpdate Inventory To All Clients
{
	struct TArray<struct UBP_PlayerInventoryComponent_C*> L Player Components;  // 0x0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x2E(0x1)
	char pad_47[1];  // 0x2F(0x1)
	struct UBP_MasterInventoryComponent_C* Temp_object_Variable;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Event Destroyed
// Size: 0x8(Inherited: 0x0) 
struct FEvent Destroyed
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function BP_ChestInventoryComponent.BP_ChestInventoryComponent_C.Spawn Destroyed Items
// Size: 0xE0(Inherited: 0x0) 
struct FSpawn Destroyed Items
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Has_Any_Items_in_Inventory_Has : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FS_InventoryItem CallFunc_Array_Get_Item;  // 0x10(0x30)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x4C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x50(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x58(0xC)
	char pad_100[12];  // 0x64(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x70(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xA0(0x8)
	struct ABP_StorageStash_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xA8(0x8)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0xB0(0x30)

}; 
