#pragma once 
#include <AN_SwimEffect_Structs.h>
 
 
 
// BlueprintGeneratedClass AN_SwimEffect.AN_SwimEffect_C
// Size: 0x38(Inherited: 0x38) 
struct UAN_SwimEffect_C : public UAnimNotify
{

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AN_SwimEffect.AN_SwimEffect_C.Received_Notify
}; 



