#pragma once 
#include <BP_EnemyCamp_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EnemyCamp.BP_EnemyCamp_C
// Size: 0x2C8(Inherited: 0x220) 
struct ABP_EnemyCamp_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USphereComponent* Area Collision;  // 0x228(0x8)
	struct UBP_TargetComponent_C* BP_TargetComponent;  // 0x230(0x8)
	struct USphereComponent* Activation collision;  // 0x238(0x8)
	struct UBillboardComponent* Billboard;  // 0x240(0x8)
	struct TArray<struct ABP_Spawner_C*> Spawners;  // 0x248(0x10)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool Defeated? : 1;  // 0x258(0x1)
	char pad_601[3];  // 0x259(0x3)
	float Global Enemy Health;  // 0x25C(0x4)
	struct TArray<struct AController*> PlayerDatabase;  // 0x260(0x10)
	struct TArray<float> PlayerDamageDatabase;  // 0x270(0x10)
	struct FString Name;  // 0x280(0x10)
	float Respawn Delay;  // 0x290(0x4)
	int32_t Experience Reward;  // 0x294(0x4)
	float Activation Distance;  // 0x298(0x4)
	float Area Radius;  // 0x29C(0x4)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool Active? : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	struct FName Unique ID;  // 0x2A4(0x8)
	int32_t Survivor Points;  // 0x2AC(0x4)
	struct FTimerHandle Reset Timer Handle;  // 0x2B0(0x8)
	struct TArray<struct AActor*> Actors to Reset;  // 0x2B8(0x10)

	void Get Interaction Data(struct FText& Interaction Text); // Function BP_EnemyCamp.BP_EnemyCamp_C.Get Interaction Data
	void Local Can Overlap(bool& Success); // Function BP_EnemyCamp.BP_EnemyCamp_C.Local Can Overlap
	void Is Enemy Alive(struct AActor* Actor, bool& Is Alive); // Function BP_EnemyCamp.BP_EnemyCamp_C.Is Enemy Alive
	void UserConstructionScript(); // Function BP_EnemyCamp.BP_EnemyCamp_C.UserConstructionScript
	void Toggle Selected(bool Toggle); // Function BP_EnemyCamp.BP_EnemyCamp_C.Toggle Selected
	void On Interacted(struct AController* Executor); // Function BP_EnemyCamp.BP_EnemyCamp_C.On Interacted
	void Exec Enemy Camp(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Exec Enemy Camp
	void On Member Dead(); // Function BP_EnemyCamp.BP_EnemyCamp_C.On Member Dead
	void On Enemy Camp Defeated(); // Function BP_EnemyCamp.BP_EnemyCamp_C.On Enemy Camp Defeated
	void Reward Players(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Reward Players
	void BndEvt__Activation collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_EnemyCamp.BP_EnemyCamp_C.BndEvt__Activation collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Activation collision_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_EnemyCamp.BP_EnemyCamp_C.BndEvt__Activation collision_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void Reset Camp(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Reset Camp
	void ReceiveBeginPlay(); // Function BP_EnemyCamp.BP_EnemyCamp_C.ReceiveBeginPlay
	void Detect Spawners(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Detect Spawners
	void Delete Spawners(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Delete Spawners
	void Reset(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Reset
	void Stop Reset(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Stop Reset
	void Detect Respawnable Actors(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Detect Respawnable Actors
	void Delete Respawnable Actors(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Delete Respawnable Actors
	void Reset Defeated State(); // Function BP_EnemyCamp.BP_EnemyCamp_C.Reset Defeated State
	void Local Overlap(bool Overlap); // Function BP_EnemyCamp.BP_EnemyCamp_C.Local Overlap
	void ExecuteUbergraph_BP_EnemyCamp(int32_t EntryPoint); // Function BP_EnemyCamp.BP_EnemyCamp_C.ExecuteUbergraph_BP_EnemyCamp
}; 



