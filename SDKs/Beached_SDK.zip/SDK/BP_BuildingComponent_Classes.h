#pragma once 
#include <BP_BuildingComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BuildingComponent.BP_BuildingComponent_C
// Size: 0x158(Inherited: 0xB0) 
struct UBP_BuildingComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	char pad_184[8];  // 0xB8(0x8)
	struct FS_Building Build Data;  // 0xC0(0x50)
	struct FString Build ID;  // 0x110(0x10)
	struct TArray<struct FString> Attached Actors;  // 0x120(0x10)
	struct FString Cupboard ID;  // 0x130(0x10)
	float Health;  // 0x140(0x4)
	float Maximum Health;  // 0x144(0x4)
	struct FString Player ID;  // 0x148(0x10)

	void OnRep_Build Data(); // Function BP_BuildingComponent.BP_BuildingComponent_C.OnRep_Build Data
	void Handled Damage(float Damage); // Function BP_BuildingComponent.BP_BuildingComponent_C.Handled Damage
	void Is In Cupboard(struct FString Player ID, bool& Return); // Function BP_BuildingComponent.BP_BuildingComponent_C.Is In Cupboard
	void Check Cupboard Removal(); // Function BP_BuildingComponent.BP_BuildingComponent_C.Check Cupboard Removal
	void Check Respawnpoint Removal(); // Function BP_BuildingComponent.BP_BuildingComponent_C.Check Respawnpoint Removal
	void Add Attached Actor(struct FString Build ID); // Function BP_BuildingComponent.BP_BuildingComponent_C.Add Attached Actor
	void ReceiveBeginPlay(); // Function BP_BuildingComponent.BP_BuildingComponent_C.ReceiveBeginPlay
	void On Destroyed(struct AActor* DestroyedActor); // Function BP_BuildingComponent.BP_BuildingComponent_C.On Destroyed
	void Set Cupboard(struct FString Cupboard ID); // Function BP_BuildingComponent.BP_BuildingComponent_C.Set Cupboard
	void On Damaged(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_BuildingComponent.BP_BuildingComponent_C.On Damaged
	void SERVER Repair(struct ABP_Holdable_C* Repair Tool Reference); // Function BP_BuildingComponent.BP_BuildingComponent_C.SERVER Repair
	void MULTICAST Hit Effect(struct FVector Location); // Function BP_BuildingComponent.BP_BuildingComponent_C.MULTICAST Hit Effect
	void CheckForTC(); // Function BP_BuildingComponent.BP_BuildingComponent_C.CheckForTC
	void ExecuteUbergraph_BP_BuildingComponent(int32_t EntryPoint); // Function BP_BuildingComponent.BP_BuildingComponent_C.ExecuteUbergraph_BP_BuildingComponent
}; 



