#pragma once 
#include <BP_SleepingBag_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SleepingBag.BP_SleepingBag_C
// Size: 0x4B0(Inherited: 0x4A8) 
struct ABP_SleepingBag_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)

	void Local Can Overlap(bool& Success); // Function BP_SleepingBag.BP_SleepingBag_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_SleepingBag.BP_SleepingBag_C.Get Interaction Data
	void Set New Respawn Point(struct AActor* Controller); // Function BP_SleepingBag.BP_SleepingBag_C.Set New Respawn Point
	void On Interacted(struct AController* Executor); // Function BP_SleepingBag.BP_SleepingBag_C.On Interacted
	void ReceiveBeginPlay(); // Function BP_SleepingBag.BP_SleepingBag_C.ReceiveBeginPlay
	void Toggle Selected(bool Toggle); // Function BP_SleepingBag.BP_SleepingBag_C.Toggle Selected
	void Local Overlap(bool Overlap); // Function BP_SleepingBag.BP_SleepingBag_C.Local Overlap
	void ExecuteUbergraph_BP_SleepingBag(int32_t EntryPoint); // Function BP_SleepingBag.BP_SleepingBag_C.ExecuteUbergraph_BP_SleepingBag
}; 



