#pragma once 
#include <BP_EBS_Building_Foundation_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Foundation.BP_EBS_Building_Foundation_C
// Size: 0x570(Inherited: 0x479) 
struct ABP_EBS_Building_Foundation_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct UBoxComponent* SupportChecker4;  // 0x480(0x8)
	struct UBoxComponent* SupportChecker3;  // 0x488(0x8)
	struct UBoxComponent* SupportChecker2;  // 0x490(0x8)
	struct UBoxComponent* SupportChecker1;  // 0x498(0x8)
	struct USceneComponent* BuildComponents;  // 0x4A0(0x8)
	struct USceneComponent* SupportCheckers;  // 0x4A8(0x8)
	struct USceneComponent* RoofSocket;  // 0x4B0(0x8)
	struct USceneComponent* FloorSocket;  // 0x4B8(0x8)
	struct USceneComponent* StairsSocket;  // 0x4C0(0x8)
	struct USceneComponent* RampSockets;  // 0x4C8(0x8)
	struct USceneComponent* WallSockets;  // 0x4D0(0x8)
	struct USceneComponent* TriangleFoundationSockets;  // 0x4D8(0x8)
	struct USceneComponent* FoundationSockets;  // 0x4E0(0x8)
	struct UBoxComponent* BuildCollision;  // 0x4E8(0x8)
	struct USceneComponent* RampSocket4;  // 0x4F0(0x8)
	struct USceneComponent* RampSocket3;  // 0x4F8(0x8)
	struct USceneComponent* RampSocket2;  // 0x500(0x8)
	struct USceneComponent* RampSocket1;  // 0x508(0x8)
	struct USceneComponent* TriangleFoundationSocket4;  // 0x510(0x8)
	struct USceneComponent* TriangleFoundationSocket3;  // 0x518(0x8)
	struct USceneComponent* TriangleFoundationSocket2;  // 0x520(0x8)
	struct USceneComponent* TriangleFoundationSocket1;  // 0x528(0x8)
	struct USceneComponent* WallSocket4;  // 0x530(0x8)
	struct USceneComponent* WallSocket3;  // 0x538(0x8)
	struct USceneComponent* WallSocket2;  // 0x540(0x8)
	struct USceneComponent* WallSocket1;  // 0x548(0x8)
	struct USceneComponent* FoundationSocket4;  // 0x550(0x8)
	struct USceneComponent* FoundationSocket3;  // 0x558(0x8)
	struct USceneComponent* FoundationSocket2;  // 0x560(0x8)
	struct USceneComponent* FoundationSocket1;  // 0x568(0x8)

}; 



