#pragma once 
#include <BP_EBS_Library_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Library.BP_EBS_Library_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_EBS_Library_C : public UBlueprintFunctionLibrary
{

	void GetGlobalDestructChunksLifeTime(struct UObject* __WorldContext, float& StepValue); // Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalDestructChunksLifeTime
	void GetGlobalFloorNumberLimit(struct UObject* __WorldContext, int32_t& FloorNumberLimit); // Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalFloorNumberLimit
	void GetPlayerID(struct APlayerController* PlayerController, struct UObject* __WorldContext, struct FString& PlayerId); // Function BP_EBS_Library.BP_EBS_Library_C.GetPlayerID
	void GetGlobalGridSettings(struct UObject* __WorldContext, float& GridFoundationOffset, float& GridFoundationOffsetZ, float& GridPropsOffset, float& GridCorrectOffset); // Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalGridSettings
	bool NearlyEqualTransforms(struct FTransform Transform1, struct FTransform Transform2, float LocationError, float RotationError, float ScaleError, struct UObject* __WorldContext); // Function BP_EBS_Library.BP_EBS_Library_C.NearlyEqualTransforms
	void BuildingObjectIsFloorPlaceable(struct ABP_EBS_Building_BaseObject_C* BuildingObject, struct UObject* __WorldContext, bool& Result); // Function BP_EBS_Library.BP_EBS_Library_C.BuildingObjectIsFloorPlaceable
	void GetGlobalBuildingHeightStep(struct UObject* __WorldContext, float& StepValue); // Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalBuildingHeightStep
	void GetGlobalBuildingRotationStep(struct UObject* __WorldContext, float& StepValue); // Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalBuildingRotationStep
	void IsValidHandle(struct FDataTableRowHandle Handle, struct UObject* __WorldContext, bool& IsValid); // Function BP_EBS_Library.BP_EBS_Library_C.IsValidHandle
	void ActorsHaveLandscape(struct TArray<struct AActor*>& Actors, struct UObject* __WorldContext, bool& Result); // Function BP_EBS_Library.BP_EBS_Library_C.ActorsHaveLandscape
	void ActorIsLandscape(struct AActor* Actor, struct UObject* __WorldContext, bool& Result); // Function BP_EBS_Library.BP_EBS_Library_C.ActorIsLandscape
}; 



