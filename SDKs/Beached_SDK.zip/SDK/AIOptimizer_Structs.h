#pragma once 
#include "SDK.h" 
 
 
// Function AIOptimizer.AIOSubjectComponent.ReinitializeOptimizationLayers
// Size: 0x10(Inherited: 0x0) 
struct FReinitializeOptimizationLayers
{
	struct TArray<struct FAIOptimizationLayer> NewOptimizationLayers;  // 0x0(0x10)

}; 
// DelegateFunction AIOptimizer.OnOptimizationUpdate__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnOptimizationUpdate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsBeyondLastLayer : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t LayerIndex;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsSeen : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AIOptimizer.AIOSubjectComponent.SetCharacterFeatures
// Size: 0x10(Inherited: 0x0) 
struct FSetCharacterFeatures
{
	struct ACharacter* Character;  // 0x0(0x8)
	int32_t FeaturesToEnable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction AIOptimizer.OnSubsystemEnabledChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnSubsystemEnabledChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool BIsEnabled : 1;  // 0x0(0x1)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.RegisterSubject
// Size: 0x10(Inherited: 0x0) 
struct FRegisterSubject
{
	struct UAIOSubjectComponent* SubjectComponent;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AIOptimizer.AIOSubject
// Size: 0x10(Inherited: 0x0) 
struct FAIOSubject
{
	struct UAIOSubjectComponent* Component;  // 0x0(0x8)
	int32_t Priority;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct AIOptimizer.AIOPendingRespawnGroup
// Size: 0xC(Inherited: 0x0) 
struct FAIOPendingRespawnGroup
{
	float SpawnGameTime;  // 0x0(0x4)
	struct FAIOPendingSpawnGroup SpawnGroup;  // 0x4(0x8)

}; 
// Function AIOptimizer.SpawnerInterface.OnSubjectDespawnedByOptimizerSubsystem
// Size: 0x8(Inherited: 0x0) 
struct FOnSubjectDespawnedByOptimizerSubsystem
{
	struct UAIOSubjectComponent* DespawnedSubjectComponent;  // 0x0(0x8)

}; 
// DelegateFunction AIOptimizer.OnSubjectDespawned__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnSubjectDespawned__DelegateSignature
{
	struct UAIOSubjectComponent* SubjectComponent;  // 0x0(0x8)

}; 
// Function AIOptimizer.AIOBPLibrary.IsHandleValid
// Size: 0x8(Inherited: 0x0) 
struct FIsHandleValid
{
	struct FAIOSubjectHandle Handle;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct AIOptimizer.AIOSpawnPoint
// Size: 0x30(Inherited: 0x0) 
struct FAIOSpawnPoint
{
	struct FTransform Transform;  // 0x0(0x30)

}; 
// DelegateFunction AIOptimizer.OnSubjectSpawned__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnSubjectSpawned__DelegateSignature
{
	struct UAIOSubjectComponent* SubjectComponent;  // 0x0(0x8)

}; 
// DelegateFunction AIOptimizer.OnPreDespawn__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnPreDespawn__DelegateSignature
{
	struct UAIOData_Base* Data;  // 0x0(0x8)

}; 
// DelegateFunction AIOptimizer.OnPostSpawned__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnPostSpawned__DelegateSignature
{
	struct UAIOData_Base* Data;  // 0x0(0x8)

}; 
// ScriptStruct AIOptimizer.AIOPendingSpawnGroup
// Size: 0x8(Inherited: 0x0) 
struct FAIOPendingSpawnGroup
{
	int32_t SpawnedAmount;  // 0x0(0x4)
	int32_t TotalAmountToSpawn;  // 0x4(0x4)

}; 
// ScriptStruct AIOptimizer.AIODebugSubjectData
// Size: 0x28(Inherited: 0x0) 
struct FAIODebugSubjectData
{
	int32_t Layer;  // 0x0(0x4)
	struct FVector SubjectLocation;  // 0x4(0xC)
	struct FVector InvokerLocation;  // 0x10(0xC)
	char bIsSpawned : 1;  // 0x1C(0x1)
	char bIsPending : 1;  // 0x1C(0x1)
	char bNotUpdated : 1;  // 0x1C(0x1)
	char bIsSeen : 1;  // 0x1C(0x1)
	char pad_28_1 : 4;  // 0x1C(0x1)
	char pad_29[4];  // 0x1D(0x4)
	float DistanceToInvoker;  // 0x20(0x4)
	float DespawnRadius;  // 0x24(0x4)

}; 
// Function AIOptimizer.AIOSubjectComponent.SetCanBeUpdatedBySubsystem
// Size: 0x1(Inherited: 0x0) 
struct FSetCanBeUpdatedBySubsystem
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCanBeUpdated : 1;  // 0x0(0x1)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.RemoveDespawnedSubjectByHandle
// Size: 0x8(Inherited: 0x0) 
struct FRemoveDespawnedSubjectByHandle
{
	struct FAIOSubjectHandle Handle;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubject
// Size: 0x18(Inherited: 0x0) 
struct FK2_DespawnSubject
{
	struct FAIOSubjectHandle SubjectHandle;  // 0x0(0x4)
	uint8_t  Method;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UAIOSubjectComponent* Component;  // 0x8(0x8)
	float OverrideSpawnRadius;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bAllowRespawnOnlyByHandle : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)

}; 
// ScriptStruct AIOptimizer.AIOptimizationLayer
// Size: 0x8(Inherited: 0x0) 
struct FAIOptimizationLayer
{
	float LayerRadius;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.RegisterInvoker
// Size: 0x10(Inherited: 0x0) 
struct FRegisterInvoker
{
	struct UAIOInvokerComponent* InvokerComponent;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct AIOptimizer.AIOInvoker
// Size: 0x8(Inherited: 0x0) 
struct FAIOInvoker
{
	struct UAIOInvokerComponent* Component;  // 0x0(0x8)

}; 
// Function AIOptimizer.SpawnerInterface.OnSubjectSpawnedByOptimizerSubsystem
// Size: 0x8(Inherited: 0x0) 
struct FOnSubjectSpawnedByOptimizerSubsystem
{
	struct UAIOSubjectComponent* SpawnedSubjectComponent;  // 0x0(0x8)

}; 
// Function AIOptimizer.AIOBPLibrary.AddUniqueHandle
// Size: 0x18(Inherited: 0x0) 
struct FAddUniqueHandle
{
	struct TArray<struct FAIOSubjectHandle> Array;  // 0x0(0x10)
	struct FAIOSubjectHandle Handle;  // 0x10(0x4)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// ScriptStruct AIOptimizer.AIODespawnedSubject
// Size: 0x60(Inherited: 0x0) 
struct FAIODespawnedSubject
{
	struct FTransform Transform;  // 0x0(0x30)
	AActor* Class;  // 0x30(0x8)
	float SpawnRadiusSquared;  // 0x38(0x4)
	char Priority;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct UAIOData_Base* Data;  // 0x40(0x8)
	struct FAIOSubjectHandle Handle;  // 0x48(0x4)
	char bIsForcedToSpawn : 1;  // 0x4C(0x1)
	char bCanBeRespawnedOnlyByHandle : 1;  // 0x4C(0x1)
	char pad_76_1 : 6;  // 0x4C(0x1)
	char pad_77[4];  // 0x4D(0x4)
	struct AActor* Spawner;  // 0x50(0x8)
	char pad_88[8];  // 0x58(0x8)

}; 
// ScriptStruct AIOptimizer.AIOSubjectHandle
// Size: 0x4(Inherited: 0x0) 
struct FAIOSubjectHandle
{
	int32_t HandleId;  // 0x0(0x4)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.GetCategorizedDebugSubjects
// Size: 0x60(Inherited: 0x0) 
struct FGetCategorizedDebugSubjects
{
	struct TArray<struct FAIODebugSubjectData> DebugSubjects;  // 0x0(0x10)
	struct TMap<uint8_t , int32_t> ReturnValue;  // 0x10(0x50)

}; 
// Function AIOptimizer.AIOBPLibrary.FindHandle
// Size: 0x18(Inherited: 0x0) 
struct FFindHandle
{
	struct TArray<struct FAIOSubjectHandle> Array;  // 0x0(0x10)
	struct FAIOSubjectHandle HandleToFind;  // 0x10(0x4)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function AIOptimizer.AIOInvokerComponent.DebugAIOptimizer
// Size: 0x1(Inherited: 0x0) 
struct FDebugAIOptimizer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDebug : 1;  // 0x0(0x1)

}; 
// Function AIOptimizer.AIOBPLibrary.GetInvokerTag
// Size: 0x8(Inherited: 0x0) 
struct FGetInvokerTag
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function AIOptimizer.AIOBPLibrary.SetAILogicEnabled
// Size: 0x10(Inherited: 0x0) 
struct FSetAILogicEnabled
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEnable : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIOptimizer.AIOBPLibrary.GetString
// Size: 0x18(Inherited: 0x0) 
struct FGetString
{
	struct FAIOSubjectHandle Handle;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function AIOptimizer.AIOBPLibrary.GetSubjectTag
// Size: 0x8(Inherited: 0x0) 
struct FGetSubjectTag
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.K2_SpawnSubjectByHandle
// Size: 0xC(Inherited: 0x0) 
struct FK2_SpawnSubjectByHandle
{
	uint8_t  Method;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FAIOSubjectHandle SubjectHandle;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AIOptimizer.AIOBPLibrary.RemoveHandle
// Size: 0x18(Inherited: 0x0) 
struct FRemoveHandle
{
	struct TArray<struct FAIOSubjectHandle> Array;  // 0x0(0x10)
	struct FAIOSubjectHandle Handle;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function AIOptimizer.AIOSubjectComponent.GetOptimizationLayerForCurrentDistance
// Size: 0x4(Inherited: 0x0) 
struct FGetOptimizationLayerForCurrentDistance
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIOptimizer.AIOBPLibrary.SetCharacterMovementEnabled
// Size: 0x10(Inherited: 0x0) 
struct FSetCharacterMovementEnabled
{
	struct ACharacter* Character;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEnable : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIOptimizer.AIOSubjectComponent.GetClosestInvokerLocation
// Size: 0xC(Inherited: 0x0) 
struct FGetClosestInvokerLocation
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.UnregisterInvoker
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterInvoker
{
	struct UAIOInvokerComponent* InvokerComponent;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.GetSubjectIndex
// Size: 0x10(Inherited: 0x0) 
struct FGetSubjectIndex
{
	struct UAIOSubjectComponent* Component;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.GetDebugSubjects
// Size: 0x10(Inherited: 0x0) 
struct FGetDebugSubjects
{
	struct TArray<struct FAIODebugSubjectData> ReturnValue;  // 0x0(0x10)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.GetDistanceToClosestInvokerSquared
// Size: 0x10(Inherited: 0x0) 
struct FGetDistanceToClosestInvokerSquared
{
	struct FVector QuerierLocation;  // 0x0(0xC)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.GetInvokerIndex
// Size: 0x10(Inherited: 0x0) 
struct FGetInvokerIndex
{
	struct UAIOInvokerComponent* Component;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.K2_DespawnSubjectByHandle
// Size: 0x10(Inherited: 0x0) 
struct FK2_DespawnSubjectByHandle
{
	struct FAIOSubjectHandle SubjectHandle;  // 0x0(0x4)
	uint8_t  Method;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float OverrideSpawnRadius;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bAllowRespawnOnlyByHandle : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool ReturnValue : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.SetIsSystemEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetIsSystemEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool BIsEnabled : 1;  // 0x0(0x1)

}; 
// Function AIOptimizer.AIOptimizerSubsystem.UnregisterSubject
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterSubject
{
	struct UAIOSubjectComponent* SubjectComponent;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AIOptimizer.AIOSubjectComponent.CanBeUpdatedBySubsystem
// Size: 0x1(Inherited: 0x0) 
struct FCanBeUpdatedBySubsystem
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIOptimizer.AIOSubjectComponent.GetCurrentOptimizationLayer
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentOptimizationLayer
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AIOptimizer.AIOSubjectComponent.GetDespawnRadiusSquared
// Size: 0x10(Inherited: 0x0) 
struct FGetDespawnRadiusSquared
{
	struct UAIOptimizerSubsystem* Subsystem;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIOptimizer.AIOSubjectComponent.GetDistanceToClosestInvoker
// Size: 0x4(Inherited: 0x0) 
struct FGetDistanceToClosestInvoker
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIOptimizer.AIOSubjectComponent.SetSpawner
// Size: 0x10(Inherited: 0x0) 
struct FSetSpawner
{
	struct TScriptInterface<ISpawnerInterface> NewSpawner;  // 0x0(0x10)

}; 
// Function AIOptimizer.AIOSubjectComponent.GetSpawnRadiusSquared
// Size: 0x10(Inherited: 0x0) 
struct FGetSpawnRadiusSquared
{
	struct UAIOptimizerSubsystem* Subsystem;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AIOptimizer.AIOSubjectComponent.IsDespawning
// Size: 0x1(Inherited: 0x0) 
struct FIsDespawning
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AIOptimizer.AIOSubjectComponent.IsSeenByAnyInvoker
// Size: 0x4(Inherited: 0x0) 
struct FIsSeenByAnyInvoker
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AIOptimizer.AIOSubjectComponent.ShouldBeDespawned
// Size: 0x10(Inherited: 0x0) 
struct FShouldBeDespawned
{
	struct UAIOptimizerSubsystem* Subsystem;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bForceUpdateDataToInvokers : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
