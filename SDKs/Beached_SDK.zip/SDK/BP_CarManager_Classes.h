#pragma once 
#include <BP_CarManager_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CarManager.BP_CarManager_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_CarManager_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Cube;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void Local Can Overlap(bool& Success); // Function BP_CarManager.BP_CarManager_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_CarManager.BP_CarManager_C.Get Interaction Data
	void Local Overlap(bool Overlap); // Function BP_CarManager.BP_CarManager_C.Local Overlap
	void On Interacted(struct AController* Executor); // Function BP_CarManager.BP_CarManager_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_CarManager.BP_CarManager_C.Toggle Selected
	void ExecuteUbergraph_BP_CarManager(int32_t EntryPoint); // Function BP_CarManager.BP_CarManager_C.ExecuteUbergraph_BP_CarManager
}; 



