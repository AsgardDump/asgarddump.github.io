#pragma once 
#include "SDK.h" 
 
 
// Function BP_Ghost_WoodenWall.BP_Ghost_WoodenWall_C.Custom Rotation
// Size: 0x99(Inherited: 0x161) 
struct FCustom Rotation : public FCustom Rotation
{
	struct FHitResult Hit;  // 0x0(0x8C)
	struct FRotator Current Rotation;  // 0x8C(0xC)
	char pad_505_1 : 7;  // 0x1F9(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x98(0x1)

}; 
// Function BP_Ghost_WoodenWall.BP_Ghost_WoodenWall_C.Custom Condition Pass
// Size: 0x8E(Inherited: 0x112) 
struct FCustom Condition Pass : public FCustom Condition Pass
{
	struct FHitResult Hit;  // 0x0(0x8C)
	char pad_414_1 : 7;  // 0x19E(0x1)
	bool Return : 1;  // 0x8C(0x1)
	char pad_415_1 : 7;  // 0x19F(0x1)
	bool CallFunc_Custom_Condition_Pass_Return : 1;  // 0x8D(0x1)

}; 
// Function BP_Ghost_WoodenWall.BP_Ghost_WoodenWall_C.Do Height Trace
// Size: 0x2F0(Inherited: 0x0) 
struct FDo Height Trace
{
	struct UStaticMeshComponent* Component;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Return : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x10(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x20(0xC)
	float CallFunc_BreakVector_X;  // 0x2C(0x4)
	float CallFunc_BreakVector_Y;  // 0x30(0x4)
	float CallFunc_BreakVector_Z;  // 0x34(0x4)
	float CallFunc_BreakVector_X_2;  // 0x38(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x3C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x40(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x50(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x5C(0x8C)
	float CallFunc_BreakVector_X_3;  // 0xE8(0x4)
	float CallFunc_BreakVector_Y_3;  // 0xEC(0x4)
	float CallFunc_BreakVector_Z_3;  // 0xF0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xF4(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x100(0xC)
	float CallFunc_BreakVector_X_4;  // 0x10C(0x4)
	float CallFunc_BreakVector_Y_4;  // 0x110(0x4)
	float CallFunc_BreakVector_Z_4;  // 0x114(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x118(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x124(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x130(0x10)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x140(0x8C)
	char pad_460_1 : 7;  // 0x1CC(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x1CC(0x1)
	char pad_461_1 : 7;  // 0x1CD(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1CD(0x1)
	char pad_462_1 : 7;  // 0x1CE(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x1CE(0x1)
	char pad_463[1];  // 0x1CF(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x1D0(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1D4(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1D8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1E4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1F0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x1FC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x208(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x210(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x218(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x220(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x228(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x22C(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x230(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x23C(0xC)
	float CallFunc_BreakVector_X_5;  // 0x248(0x4)
	float CallFunc_BreakVector_Y_5;  // 0x24C(0x4)
	float CallFunc_BreakVector_Z_5;  // 0x250(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x254(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_3;  // 0x258(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_2;  // 0x264(0x8C)

}; 
