#pragma once 
#include <BP_Holdable_MeeleWeapon_OneHanded_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C
// Size: 0x329(Inherited: 0x31C) 
struct ABP_Holdable_MeeleWeapon_OneHanded_C : public ABP_Holdable_MeeleWeapon_C
{
	char pad_796[4];  // 0x31C(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x320(0x8)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool Is Shielding : 1;  // 0x328(0x1)

	void Apply Damage(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.Apply Damage
	void Primary Action(bool Pressed); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.Primary Action
	void SERVER Attack(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.SERVER Attack
	void MULTICAST Attack(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.MULTICAST Attack
	void Local Request Attack(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.Local Request Attack
	void SERVER Init Attack(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.SERVER Init Attack
	void Reset(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.Reset
	void Aiming Action(bool Toggle); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.Aiming Action
	void SERVER Set Shielding(bool Is Shielding); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.SERVER Set Shielding
	void On Shielding Hit(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.On Shielding Hit
	void CLIENT On Shielding(bool Condition); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.CLIENT On Shielding
	void Mutlicast Block Effect(); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.Mutlicast Block Effect
	void ExecuteUbergraph_BP_Holdable_MeeleWeapon_OneHanded(int32_t EntryPoint); // Function BP_Holdable_MeeleWeapon_OneHanded.BP_Holdable_MeeleWeapon_OneHanded_C.ExecuteUbergraph_BP_Holdable_MeeleWeapon_OneHanded
}; 



