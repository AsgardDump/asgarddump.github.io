#pragma once 
#include <BP_Animal_Chicken_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Animal_Chicken.BP_Animal_Chicken_C
// Size: 0x510(Inherited: 0x500) 
struct ABP_Animal_Chicken_C : public ABP_AIBase_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x500(0x8)
	struct UAudioComponent* Audio;  // 0x508(0x8)

	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_Animal_Chicken.BP_Animal_Chicken_C.ReceiveAnyDamage
	void On Target Updated(); // Function BP_Animal_Chicken.BP_Animal_Chicken_C.On Target Updated
	void ReceivePossessed(struct AController* NewController); // Function BP_Animal_Chicken.BP_Animal_Chicken_C.ReceivePossessed
	void MULTICAST On Dead(); // Function BP_Animal_Chicken.BP_Animal_Chicken_C.MULTICAST On Dead
	void MULTICAST On Damage(bool Melee); // Function BP_Animal_Chicken.BP_Animal_Chicken_C.MULTICAST On Damage
	void ExecuteUbergraph_BP_Animal_Chicken(int32_t EntryPoint); // Function BP_Animal_Chicken.BP_Animal_Chicken_C.ExecuteUbergraph_BP_Animal_Chicken
}; 



