#pragma once 
#include "SDK.h" 
 
 
// Function BP_Spawner.BP_Spawner_C.ExecuteUbergraph_BP_Spawner
// Size: 0x5C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Spawner
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UBP_AI_DataComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x8(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x10(0x30)
	struct ABP_EnemyCamp_C* K2Node_CustomEvent_Enemy_Camp;  // 0x40(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x48(0x8)
	struct AActor* CallFunc_FinishSpawningActor_ReturnValue;  // 0x50(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x58(0x4)

}; 
// Function BP_Spawner.BP_Spawner_C.Spawn
// Size: 0x8(Inherited: 0x0) 
struct FSpawn
{
	struct ABP_EnemyCamp_C* Enemy Camp;  // 0x0(0x8)

}; 
