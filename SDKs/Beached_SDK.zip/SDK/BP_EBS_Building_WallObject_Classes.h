#pragma once 
#include <BP_EBS_Building_WallObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_WallObject.BP_EBS_Building_WallObject_C
// Size: 0x498(Inherited: 0x479) 
struct ABP_EBS_Building_WallObject_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct USceneComponent* SupportCheckers;  // 0x480(0x8)
	struct USceneComponent* BuildComponents;  // 0x488(0x8)
	struct UBoxComponent* SupportChecker;  // 0x490(0x8)

	void CheckWall(struct TArray<struct AActor*>& Actors, bool& Result); // Function BP_EBS_Building_WallObject.BP_EBS_Building_WallObject_C.CheckWall
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_WallObject.BP_EBS_Building_WallObject_C.CheckSupport
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_WallObject.BP_EBS_Building_WallObject_C.GetSnapTransform
	void CheckSnap(struct AActor* TargetActor, bool& CanBeSnapped); // Function BP_EBS_Building_WallObject.BP_EBS_Building_WallObject_C.CheckSnap
}; 



