#pragma once 
#include <BP_PlayerComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PlayerComponent.BP_PlayerComponent_C
// Size: 0x231(Inherited: 0xB0) 
struct UBP_PlayerComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	int32_t Level;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct FS_PlayerCustomization Customization Data;  // 0xC0(0x50)
	struct FVector Ragdoll Location;  // 0x110(0xC)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool Is Aiming : 1;  // 0x11C(0x1)
	char pad_285_1 : 7;  // 0x11D(0x1)
	bool Is Loaded : 1;  // 0x11D(0x1)
	char pad_286_1 : 7;  // 0x11E(0x1)
	bool Is Sprinting : 1;  // 0x11E(0x1)
	char pad_287_1 : 7;  // 0x11F(0x1)
	bool Is Dead : 1;  // 0x11F(0x1)
	struct TArray<struct FS_HolsterData> Replicated Holster Data;  // 0x120(0x10)
	struct TArray<struct FS_HolsterData> Holster Data;  // 0x130(0x10)
	struct TArray<struct USceneComponent*> Holster Objects;  // 0x140(0x10)
	struct ABP_Holdable_C* Holdable Actor;  // 0x150(0x8)
	struct FS_PlayerArmor Player Armor;  // 0x158(0x28)
	struct FString Player Unique ID;  // 0x180(0x10)
	struct FString Player Name;  // 0x190(0x10)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool Is In Water : 1;  // 0x1A0(0x1)
	char pad_417[3];  // 0x1A1(0x3)
	float Water Deepness;  // 0x1A4(0x4)
	struct ACharacter* Owner Character;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool Is Swimming : 1;  // 0x1B0(0x1)
	char pad_433_1 : 7;  // 0x1B1(0x1)
	bool Is Holding Jump : 1;  // 0x1B1(0x1)
	char pad_434_1 : 7;  // 0x1B2(0x1)
	bool Is Holding Crouch : 1;  // 0x1B2(0x1)
	char pad_435_1 : 7;  // 0x1B3(0x1)
	bool Is Diving : 1;  // 0x1B3(0x1)
	float Oxygen;  // 0x1B4(0x4)
	float Oxygen Decerase Rate;  // 0x1B8(0x4)
	char pad_444_1 : 7;  // 0x1BC(0x1)
	bool Is Camera Underwater : 1;  // 0x1BC(0x1)
	char pad_445[3];  // 0x1BD(0x3)
	float Temperature;  // 0x1C0(0x4)
	float New Temperature;  // 0x1C4(0x4)
	float Armor Temperature;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct FTimerHandle Temperature Damage Timer Handle;  // 0x1D0(0x8)
	struct ABP_MultiplayerDynamicWeatherManager_C* Weather System Reference;  // 0x1D8(0x8)
	float Weather Temperature;  // 0x1E0(0x4)
	float Outside Temperature;  // 0x1E4(0x4)
	char E_PlayerMovementMode Player Movement Mode;  // 0x1E8(0x1)
	char pad_489[7];  // 0x1E9(0x7)
	struct USceneComponent* Vehicle Attachment;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool Is Local Component : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct APlayerController* Player Controller;  // 0x200(0x8)
	float Additional Temperature;  // 0x208(0x4)
	char pad_524[4];  // 0x20C(0x4)
	struct TArray<char> SessionAuthTicket;  // 0x210(0x10)
	struct FSteamTicketHandle Ticket Handle;  // 0x220(0x4)
	char pad_548[4];  // 0x224(0x4)
	struct FSteamID SteamID;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool IsLoggedIn? : 1;  // 0x230(0x1)

	void Update In Vehicle Movement(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Update In Vehicle Movement
	void Update Temperature(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Update Temperature
	void OnRep_Vehicle Attachment(); // Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Vehicle Attachment
	void OnRep_Movement Mode(); // Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Movement Mode
	void Update Water Camera(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Update Water Camera
	void Update Oxygen(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Update Oxygen
	void Do Water Trace(float& Water Deepness, struct FVector& ImpactPoint); // Function BP_PlayerComponent.BP_PlayerComponent_C.Do Water Trace
	void OnRep_Player Name(); // Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Player Name
	void OnRep_Level(); // Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Level
	void OnRep_Player Unque ID(); // Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Player Unque ID
	void OnRep_Player Armor(); // Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Player Armor
	bool Can Emote(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Can Emote
	void Get Character Mesh(struct USkeletalMeshComponent*& Mesh); // Function BP_PlayerComponent.BP_PlayerComponent_C.Get Character Mesh
	void Destroy Holster(struct UStaticMesh* Holster Mesh, AActor* Holster Class, bool& Return); // Function BP_PlayerComponent.BP_PlayerComponent_C.Destroy Holster
	void Destroy Holster Socket(char E_HolsterSockets Holster Socket, bool& Return); // Function BP_PlayerComponent.BP_PlayerComponent_C.Destroy Holster Socket
	void Create Holster(struct FS_HolsterData Holster Data, bool Save); // Function BP_PlayerComponent.BP_PlayerComponent_C.Create Holster
	void Load Customization Data(struct FS_PlayerCustomization& Customization Data, bool& Valid); // Function BP_PlayerComponent.BP_PlayerComponent_C.Load Customization Data
	void Find Level Suffix(int32_t Level, struct FText& Suffix); // Function BP_PlayerComponent.BP_PlayerComponent_C.Find Level Suffix
	void On Water Entered(struct FVector Hit Location); // Function BP_PlayerComponent.BP_PlayerComponent_C.On Water Entered
	void On Water Exit(); // Function BP_PlayerComponent.BP_PlayerComponent_C.On Water Exit
	void Water Detection(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Water Detection
	void Enter Swim State(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Enter Swim State
	void Enter Default State(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Enter Default State
	void SERVER Drown(); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Drown
	void Set Customization Data(struct FS_PlayerCustomization Customization Data); // Function BP_PlayerComponent.BP_PlayerComponent_C.Set Customization Data
	void Update Customization(struct FS_PlayerCustomization Customization Data); // Function BP_PlayerComponent.BP_PlayerComponent_C.Update Customization
	void Set Ragdoll Location(struct FVector Ragdoll Location); // Function BP_PlayerComponent.BP_PlayerComponent_C.Set Ragdoll Location
	void SERVER Set Ragdoll Location(struct FVector Ragdoll Location); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Set Ragdoll Location
	void MULTICAST Set Ragdoll Location(struct FVector Ragdoll Location); // Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Set Ragdoll Location
	void Toggle Aiming(bool Toggle); // Function BP_PlayerComponent.BP_PlayerComponent_C.Toggle Aiming
	void SERVER Toggle Aiming(bool Toggle); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Toggle Aiming
	void Load Player(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Load Player
	void ReceiveBeginPlay(); // Function BP_PlayerComponent.BP_PlayerComponent_C.ReceiveBeginPlay
	void Set Data(int32_t Level); // Function BP_PlayerComponent.BP_PlayerComponent_C.Set Data
	void Set Loaded(bool Is Loaded); // Function BP_PlayerComponent.BP_PlayerComponent_C.Set Loaded
	void Add Holster(struct FS_HolsterData Holster Data); // Function BP_PlayerComponent.BP_PlayerComponent_C.Add Holster
	void SERVER Add Holster(struct FS_HolsterData Holster Data); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Add Holster
	void MULTICAST Add Holster(struct FS_HolsterData Holster Data); // Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Add Holster
	void Remove Holster Socket(char E_HolsterSockets Holster Socket); // Function BP_PlayerComponent.BP_PlayerComponent_C.Remove Holster Socket
	void SERVER Remove Holster Socket(char E_HolsterSockets Holster Socket); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Remove Holster Socket
	void MULTICAST Remove Holster Socket(char E_HolsterSockets Holster Socket); // Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Remove Holster Socket
	void On Landed(struct FHitResult Hit); // Function BP_PlayerComponent.BP_PlayerComponent_C.On Landed
	void SERVER On Landed(float Fall Velocity); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER On Landed
	void SERVER Apply Armor(struct FS_PlayerArmor Armor IDs); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Apply Armor
	void Apply Armor(struct FS_PlayerArmor& PlayerArmor); // Function BP_PlayerComponent.BP_PlayerComponent_C.Apply Armor
	void Remove Holster(struct UStaticMesh* Holster Mesh, AActor* Holster Class); // Function BP_PlayerComponent.BP_PlayerComponent_C.Remove Holster
	void SERVER Remove Holster(struct UStaticMesh* Holster Mesh, AActor* Holster Class); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Remove Holster
	void MULTICAST Remove Holster(struct UStaticMesh* Holster Mesh, AActor* Holster Class); // Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Remove Holster
	void ReceiveTick(float DeltaSeconds); // Function BP_PlayerComponent.BP_PlayerComponent_C.ReceiveTick
	void SERVER Load Player(struct FS_PlayerCustomization Customization Data, bool Load Customization); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Load Player
	void Load Holsters(struct TArray<struct FS_HolsterData>& Holster Data); // Function BP_PlayerComponent.BP_PlayerComponent_C.Load Holsters
	void Remove Holster For all (struct UStaticMesh* Holster Mesh, AActor* Holster Class); // Function BP_PlayerComponent.BP_PlayerComponent_C.Remove Holster For all 
	void Load Possession Data(struct APlayerController* Player Controller); // Function BP_PlayerComponent.BP_PlayerComponent_C.Load Possession Data
	void Play Consume Sound(struct USoundBase* Sound); // Function BP_PlayerComponent.BP_PlayerComponent_C.Play Consume Sound
	void Set To Spawn Location(struct FVector Location); // Function BP_PlayerComponent.BP_PlayerComponent_C.Set To Spawn Location
	void MULTICAST Play Land Sound(); // Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Play Land Sound
	void Decerase Temperature Health(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Decerase Temperature Health
	void Check Temperature Damage(); // Function BP_PlayerComponent.BP_PlayerComponent_C.Check Temperature Damage
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_PlayerComponent.BP_PlayerComponent_C.ReceiveEndPlay
	void SERVER Vehicle Dismount Request(); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Vehicle Dismount Request
	void MULTICAST Set Location(struct FVector NewLocation); // Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Set Location
	void SERVER Apply Internal Damage(float BaseDamage); // Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Apply Internal Damage
	void AuthenticateSteamClient(struct TArray<char>& SessionAuthTicket, struct FString SteamID); // Function BP_PlayerComponent.BP_PlayerComponent_C.AuthenticateSteamClient
	void OnLogin(); // Function BP_PlayerComponent.BP_PlayerComponent_C.OnLogin
	void ExecuteUbergraph_BP_PlayerComponent(int32_t EntryPoint); // Function BP_PlayerComponent.BP_PlayerComponent_C.ExecuteUbergraph_BP_PlayerComponent
}; 



