#pragma once 
#include "SDK.h" 
 
 
// Function AN_SwimEffect.AN_SwimEffect_C.Received_Notify
// Size: 0x111(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct UBP_PlayerComponent_C* L Player Component;  // 0x18(0x8)
	struct FHitResult L Hit;  // 0x20(0x8C)
	struct AActor* L Owner;  // 0xB0(0x8)
	struct FVector L Bone Location;  // 0xB8(0xC)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0xC8(0x8)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xD0(0x1)
	struct UBP_PlayerComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0xD8(0x8)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0xE0(0xC)
	struct FVector CallFunc_GetSocketLocation_ReturnValue_2;  // 0xEC(0xC)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0xF8(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x100(0x8)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue_2;  // 0x108(0x8)
	char pad_274_1 : 7;  // 0x112(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x110(0x1)

}; 
