#pragma once 
#include <BP_RepairBench_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RepairBench.BP_RepairBench_C
// Size: 0x4C0(Inherited: 0x4A8) 
struct ABP_RepairBench_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct UDataTable* Crafting Data Table;  // 0x4B0(0x8)
	struct FName Name;  // 0x4B8(0x8)

	void Get Interaction Data(struct FText& Interaction Text); // Function BP_RepairBench.BP_RepairBench_C.Get Interaction Data
	void Local Can Overlap(bool& Success); // Function BP_RepairBench.BP_RepairBench_C.Local Can Overlap
	void On Interacted(struct AController* Executor); // Function BP_RepairBench.BP_RepairBench_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_RepairBench.BP_RepairBench_C.Toggle Selected
	void ReceiveBeginPlay(); // Function BP_RepairBench.BP_RepairBench_C.ReceiveBeginPlay
	void Local Overlap(bool Overlap); // Function BP_RepairBench.BP_RepairBench_C.Local Overlap
	void CheckForCollisionBeneath(); // Function BP_RepairBench.BP_RepairBench_C.CheckForCollisionBeneath
	void ExecuteUbergraph_BP_RepairBench(int32_t EntryPoint); // Function BP_RepairBench.BP_RepairBench_C.ExecuteUbergraph_BP_RepairBench
}; 



