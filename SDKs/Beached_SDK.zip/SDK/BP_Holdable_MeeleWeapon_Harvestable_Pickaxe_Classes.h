#pragma once 
#include <BP_Holdable_MeeleWeapon_Harvestable_Pickaxe_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_Harvestable_Pickaxe.BP_Holdable_MeeleWeapon_Harvestable_Pickaxe_C
// Size: 0x329(Inherited: 0x329) 
struct ABP_Holdable_MeeleWeapon_Harvestable_Pickaxe_C : public ABP_Holdable_MeeleWeapon_Harvestable_C
{

}; 



