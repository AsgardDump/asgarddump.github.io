#pragma once 
#include <BP_LobbyController_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LobbyController.BP_LobbyController_C
// Size: 0x5C0(Inherited: 0x570) 
struct ABP_LobbyController_C : public APlayerController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x570(0x8)
	struct UBP_OnlineComponent_C* BP_OnlineComponent;  // 0x578(0x8)
	struct UBP_LobbyComponent_C* BP_LobbyComponent;  // 0x580(0x8)
	struct UBP_EBS_SaveGame_C* NewVar_1;  // 0x588(0x8)
	struct UBP_EBS_SaveGame_C* PlayerSave2;  // 0x590(0x8)
	struct UBP_GameInstance_UMSP_C* NewVar_2;  // 0x598(0x8)
	struct TArray<struct FSteamItemDef> Item Defs;  // 0x5A0(0x10)
	struct TArray<int32_t> Quantity;  // 0x5B0(0x10)

	void Get Chat Widget(struct UW_Chat_C*& Chat Widget Reference); // Function BP_LobbyController.BP_LobbyController_C.Get Chat Widget
	void InpActEvt_Delete_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_LobbyController.BP_LobbyController_C.InpActEvt_Delete_K2Node_InputKeyEvent_3
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_LobbyController.BP_LobbyController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2
	void InpActEvt_E_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_LobbyController.BP_LobbyController_C.InpActEvt_E_K2Node_InputKeyEvent_1
	void ReceiveBeginPlay(); // Function BP_LobbyController.BP_LobbyController_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_LobbyController.BP_LobbyController_C.ReceiveTick
	void ExecuteUbergraph_BP_LobbyController(int32_t EntryPoint); // Function BP_LobbyController.BP_LobbyController_C.ExecuteUbergraph_BP_LobbyController
}; 



