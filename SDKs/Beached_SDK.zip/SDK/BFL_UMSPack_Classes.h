#pragma once 
#include <BFL_UMSPack_Structs.h>
 
 
 
// BlueprintGeneratedClass BFL_UMSPack.BFL_UMSPack_C
// Size: 0x28(Inherited: 0x28) 
struct UBFL_UMSPack_C : public UBlueprintFunctionLibrary
{

	void Get Human Player Character(struct AActor* Controller, struct UObject* __WorldContext, struct ACharacter*& Human Player Character); // Function BFL_UMSPack.BFL_UMSPack_C.Get Human Player Character
	bool Is Current Level Saveable(struct UObject* __WorldContext); // Function BFL_UMSPack.BFL_UMSPack_C.Is Current Level Saveable
	struct FString Get Customization Slot Name(struct UObject* __WorldContext); // Function BFL_UMSPack.BFL_UMSPack_C.Get Customization Slot Name
	struct FString Get Option Slot Name(struct UObject* __WorldContext); // Function BFL_UMSPack.BFL_UMSPack_C.Get Option Slot Name
	struct UBP_PlayerComponent_C* Get Player Component(struct AActor* Character, struct UObject* __WorldContext); // Function BFL_UMSPack.BFL_UMSPack_C.Get Player Component
	struct UBP_PlayerInventoryComponent_C* Get Inventory Component(struct AActor*& Player Controller, struct UObject* __WorldContext); // Function BFL_UMSPack.BFL_UMSPack_C.Get Inventory Component
	struct UBP_SkillTreeComponent_C* Get Skill Component(struct AActor* Player, struct UObject* __WorldContext); // Function BFL_UMSPack.BFL_UMSPack_C.Get Skill Component
	void Get Leveling Component(struct AActor* Object, struct UObject* __WorldContext, struct UBP_Player_ExperienceComponent_C*& Leveling Component); // Function BFL_UMSPack.BFL_UMSPack_C.Get Leveling Component
	void Get Mission Component(struct AActor* Player, struct UObject* __WorldContext, struct UBP_MissionComponent_C*& MissionComponent); // Function BFL_UMSPack.BFL_UMSPack_C.Get Mission Component
	void Get Enemy Nametag(struct UObject* Object, struct UObject* __WorldContext, struct UWidgetComponent*& Name Tag); // Function BFL_UMSPack.BFL_UMSPack_C.Get Enemy Nametag
	void Get Player Class(struct UObject* __WorldContext, ACharacter*& Player Class); // Function BFL_UMSPack.BFL_UMSPack_C.Get Player Class
}; 



