#pragma once 
#include <BP_Ghost_WoodenWall_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_WoodenWall.BP_Ghost_WoodenWall_C
// Size: 0x288(Inherited: 0x280) 
struct ABP_Ghost_WoodenWall_C : public ABP_GhostActor_C
{
	struct UStaticMeshComponent* StaticMesh1;  // 0x280(0x8)

	void Custom Rotation(struct FHitResult Hit, struct FRotator Current Rotation); // Function BP_Ghost_WoodenWall.BP_Ghost_WoodenWall_C.Custom Rotation
	void Do Height Trace(struct UStaticMeshComponent* Component, bool& Return); // Function BP_Ghost_WoodenWall.BP_Ghost_WoodenWall_C.Do Height Trace
	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_WoodenWall.BP_Ghost_WoodenWall_C.Custom Condition Pass
}; 



