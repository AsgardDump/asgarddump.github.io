#pragma once 
#include "SDK.h" 
 
 
// Function BP_Ghost_Campfire.BP_Ghost_Campfire_C.Custom Condition Pass
// Size: 0x115(Inherited: 0x112) 
struct FCustom Condition Pass : public FCustom Condition Pass
{
	struct FHitResult Hit;  // 0x0(0x8C)
	char pad_414_1 : 7;  // 0x19E(0x1)
	bool Return : 1;  // 0x8C(0x1)
	char pad_415_1 : 7;  // 0x19F(0x1)
	bool CallFunc_Custom_Condition_Pass_Return : 1;  // 0x8D(0x1)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x8E(0x1)
	char pad_417_1 : 7;  // 0x1A1(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x8F(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x90(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x94(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x98(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xA4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xB0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xBC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xC8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xD0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0xD8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0xE0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0xE8(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xEC(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0xF0(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0xFC(0xC)
	float CallFunc_BreakVector_X;  // 0x108(0x4)
	float CallFunc_BreakVector_Y;  // 0x10C(0x4)
	float CallFunc_BreakVector_Z;  // 0x110(0x4)
	char pad_550_1 : 7;  // 0x226(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x114(0x1)

}; 
