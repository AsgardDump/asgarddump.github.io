#pragma once 
#include "SDK.h" 
 
 
// Function AN_Attack.AN_Attack_C.Received_Notify
// Size: 0x39(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue;  // 0x20(0x8)
	struct TScriptInterface<IBPI_Player_C> CallFunc_Local_Request_Attack_self_CastInput;  // 0x28(0x10)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)

}; 
