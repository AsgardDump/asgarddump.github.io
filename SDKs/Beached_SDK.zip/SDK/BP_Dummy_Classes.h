#pragma once 
#include <BP_Dummy_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Dummy.BP_Dummy_C
// Size: 0x25C(Inherited: 0x220) 
struct ABP_Dummy_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UCapsuleComponent* Capsule;  // 0x228(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float Effect_Alpha_023AD2FD4519D8D34F6FA99E5EACE48B;  // 0x240(0x4)
	char ETimelineDirection Effect__Direction_023AD2FD4519D8D34F6FA99E5EACE48B;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* Effect;  // 0x248(0x8)
	struct FRotator Target Rotation;  // 0x250(0xC)

	void Effect__FinishedFunc(); // Function BP_Dummy.BP_Dummy_C.Effect__FinishedFunc
	void Effect__UpdateFunc(); // Function BP_Dummy.BP_Dummy_C.Effect__UpdateFunc
	void ReceivePointDamage(float Damage, struct UDamageType* DamageType, struct FVector HitLocation, struct FVector HitNormal, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector ShotFromDirection, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FHitResult& HitInfo); // Function BP_Dummy.BP_Dummy_C.ReceivePointDamage
	void MULTICAST Hit Effect(struct FRotator Target Rotation); // Function BP_Dummy.BP_Dummy_C.MULTICAST Hit Effect
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_Dummy.BP_Dummy_C.ReceiveAnyDamage
	void MUTLICAST Plas Hit Sound(); // Function BP_Dummy.BP_Dummy_C.MUTLICAST Plas Hit Sound
	void ExecuteUbergraph_BP_Dummy(int32_t EntryPoint); // Function BP_Dummy.BP_Dummy_C.ExecuteUbergraph_BP_Dummy
}; 



