#pragma once 
#include <BP_Garage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Garage.BP_Garage_C
// Size: 0x250(Inherited: 0x220) 
struct ABP_Garage_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UChildActorComponent* Vehicle Manager;  // 0x228(0x8)
	struct UBoxComponent* Box;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	struct AActor* Vehicle Reference;  // 0x240(0x8)
	struct FTimerHandle Healing Timer Handle;  // 0x248(0x8)

	void ReceiveBeginPlay(); // Function BP_Garage.BP_Garage_C.ReceiveBeginPlay
	void BndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Garage.BP_Garage_C.BndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_Garage.BP_Garage_C.BndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void Heal Vehicle(); // Function BP_Garage.BP_Garage_C.Heal Vehicle
	void ExecuteUbergraph_BP_Garage(int32_t EntryPoint); // Function BP_Garage.BP_Garage_C.ExecuteUbergraph_BP_Garage
}; 



