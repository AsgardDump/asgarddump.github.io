#pragma once 
#include "SDK.h" 
 
 
// Function BP_Sky_Sphere_Modulated.BP_Sky_Sphere_Modulated_C.ExecuteUbergraph_BP_Sky_Sphere_Modulated
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Sky_Sphere_Modulated
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function BP_Sky_Sphere_Modulated.BP_Sky_Sphere_Modulated_C.UserConstructionScript
// Size: 0x8(Inherited: 0x8) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
