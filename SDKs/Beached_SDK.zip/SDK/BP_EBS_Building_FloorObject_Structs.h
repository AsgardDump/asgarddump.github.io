#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckLandscape
// Size: 0x12(Inherited: 0x0) 
struct FCheckLandscape
{
	struct TArray<struct AActor*> Actors;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_ActorsHaveLandscape_Result : 1;  // 0x11(0x1)

}; 
// Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckSnap
// Size: 0x19(Inherited: 0x3C) 
struct FCheckSnap : public FCheckSnap
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CanBeSnapped : 1;  // 0x8(0x1)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x10(0x8)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.GetSnapTransform
// Size: 0x160(Inherited: 0x110) 
struct FGetSnapTransform : public FGetSnapTransform
{
	struct AActor* TargetActor;  // 0x0(0x8)
	float InputRotation;  // 0x8(0x4)
	struct FVector HitLocation;  // 0xC(0xC)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool GridMode : 1;  // 0x18(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool SnapNear : 1;  // 0x19(0x1)
	struct FTransform ReturnTransform;  // 0x20(0x30)
	float LocalCorrectOffset;  // 0x50(0x4)
	float LocalPropsDistance;  // 0x54(0x4)
	struct FVector LocalHitLocation;  // 0x58(0xC)
	char pad_366_1 : 7;  // 0x16E(0x1)
	bool LocalGridMode : 1;  // 0x64(0x1)
	float CallFunc_BreakVector_X;  // 0x68(0x4)
	float CallFunc_BreakVector_Y;  // 0x6C(0x4)
	float CallFunc_BreakVector_Z;  // 0x70(0x4)
	float CallFunc_BreakVector_X_2;  // 0x74(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x78(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x7C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x80(0xC)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x90(0x8)
	char pad_411_1 : 7;  // 0x19B(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x98(0x1)
	float CallFunc_GetFloorWorldZ_ValueZ;  // 0x9C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xA0(0xC)
	char pad_428_1 : 7;  // 0x1AC(0x1)
	bool Temp_bool_Variable : 1;  // 0xAC(0x1)
	char pad_429_1 : 7;  // 0x1AD(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xAD(0x1)
	struct FVector CallFunc_GetGridOffsets_GridOffset;  // 0xB0(0xC)
	float CallFunc_GetGridOffsets_Grid_Props_Distance;  // 0xBC(0x4)
	float CallFunc_GetGridOffsets_Grid_Correct_Offset;  // 0xC0(0x4)
	float CallFunc_BreakVector_X_3;  // 0xC4(0x4)
	float CallFunc_BreakVector_Y_3;  // 0xC8(0x4)
	float CallFunc_BreakVector_Z_3;  // 0xCC(0x4)
	struct FVector CallFunc_GreaterGreater_VectorRotator_ReturnValue;  // 0xD0(0xC)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xDC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0xE0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xE4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xE8(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0xEC(0x4)
	int32_t CallFunc_Round_ReturnValue_2;  // 0xF0(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xF4(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0xF8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xFC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x100(0x4)
	float K2Node_Select_Default;  // 0x104(0x4)
	float K2Node_Select_Default_2;  // 0x108(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x10C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x118(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x130(0x30)

}; 
// Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckSupport
// Size: 0x4E(Inherited: 0x80) 
struct FCheckSupport : public FCheckSupport
{
	char pad_128_1 : 7;  // 0x80(0x1)
	bool HasSupport : 1;  // 0x0(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool LocalSupport : 1;  // 0x1(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_142_1 : 7;  // 0x8E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x10(0x1)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x18(0x10)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x38(0x10)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_CheckFloor_Result : 1;  // 0x49(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x4A(0x1)
	char pad_190_1 : 7;  // 0xBE(0x1)
	bool CallFunc_CheckLandscape_Result : 1;  // 0x4B(0x1)
	char pad_191_1 : 7;  // 0xBF(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x4C(0x1)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x4D(0x1)

}; 
// Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.GetGridOffsets
// Size: 0x44(Inherited: 0x0) 
struct FGetGridOffsets
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool GridMode : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector GridOffset;  // 0x4(0xC)
	float Grid Props Distance;  // 0x10(0x4)
	float Grid Correct Offset;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector Temp_struct_Variable;  // 0x1C(0xC)
	float CallFunc_GetGlobalGridSettings_GridFoundationOffset;  // 0x28(0x4)
	float CallFunc_GetGlobalGridSettings_GridFoundationOffsetZ;  // 0x2C(0x4)
	float CallFunc_GetGlobalGridSettings_GridPropsOffset;  // 0x30(0x4)
	float CallFunc_GetGlobalGridSettings_GridCorrectOffset;  // 0x34(0x4)
	struct FVector K2Node_Select_Default;  // 0x38(0xC)

}; 
// Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckFloor
// Size: 0x3A(Inherited: 0x0) 
struct FCheckFloor
{
	struct TArray<struct AActor*> Actors;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x20(0x8)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x39(0x1)

}; 
