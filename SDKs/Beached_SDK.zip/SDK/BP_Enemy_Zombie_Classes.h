#pragma once 
#include <BP_Enemy_Zombie_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Enemy_Zombie.BP_Enemy_Zombie_C
// Size: 0x51C(Inherited: 0x500) 
struct ABP_Enemy_Zombie_C : public ABP_AIBase_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x500(0x8)
	struct UAIPerceptionComponent* AIPerception;  // 0x508(0x8)
	struct FTimerHandle Attack Timer;  // 0x510(0x8)
	int32_t Mesh Number;  // 0x518(0x4)

	void ReceivePossessed(struct AController* NewController); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.ReceivePossessed
	void Perform Attack(); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.Perform Attack
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.ReceiveAnyDamage
	void Do Attack(); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.Do Attack
	void BndEvt__BP_Enemy_Bandit_AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature(struct AActor* Actor, struct FAIStimulus Stimulus); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.BndEvt__BP_Enemy_Bandit_AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature
	void MULTICAST On Damage(bool Is Alive); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.MULTICAST On Damage
	void ReceiveBeginPlay(); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.ReceiveBeginPlay
	void MULTICAST Set Mesh(int32_t Mesh Number); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.MULTICAST Set Mesh
	void MULTICAST Hit Target(struct FVector Location); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.MULTICAST Hit Target
	void MULTICAST On Vehicle Damage(); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.MULTICAST On Vehicle Damage
	void ExecuteUbergraph_BP_Enemy_Zombie(int32_t EntryPoint); // Function BP_Enemy_Zombie.BP_Enemy_Zombie_C.ExecuteUbergraph_BP_Enemy_Zombie
}; 



