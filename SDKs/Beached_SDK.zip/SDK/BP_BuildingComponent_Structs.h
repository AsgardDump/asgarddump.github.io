#pragma once 
#include "SDK.h" 
 
 
// Function BP_BuildingComponent.BP_BuildingComponent_C.Check Respawnpoint Removal
// Size: 0x221(Inherited: 0x0) 
struct FCheck Respawnpoint Removal
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x10(0x8)
	struct UBP_GameInstance_UMSP_C* K2Node_DynamicCast_AsBP_Game_Instance_UMSP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FString> CallFunc_Map_Keys_Keys;  // 0x28(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FS_PlayerSave CallFunc_Map_Find_Value;  // 0x58(0xE0)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct FS_PlayerSave K2Node_SetFieldsInStruct_StructOut;  // 0x140(0xE0)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x220(0x1)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.On Damaged
// Size: 0x28(Inherited: 0x0) 
struct FOn Damaged
{
	struct AActor* DamagedActor;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UDamageType* DamageType;  // 0x10(0x8)
	struct AController* InstigatedBy;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.ExecuteUbergraph_BP_BuildingComponent
// Size: 0x40E(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BuildingComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x20(0x8)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x38(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x50(0x8)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct ABP_Harvestable_C* K2Node_DynamicCast_AsBP_Harvestable;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x6C(0x4)
	struct FString K2Node_CustomEvent_Cupboard_ID;  // 0x70(0x10)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue_2;  // 0x80(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival_2;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x90(0x1)
	char pad_145[15];  // 0x91(0xF)
	struct FS_BuildSave CallFunc_Get_Saved_Build_Data_Saved_Data;  // 0xA0(0xF0)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_Get_Saved_Build_Data_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[15];  // 0x191(0xF)
	struct FS_BuildSave K2Node_SetFieldsInStruct_StructOut;  // 0x1A0(0xF0)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x290(0x4)
	char pad_660[4];  // 0x294(0x4)
	struct AActor* K2Node_CustomEvent_DamagedActor;  // 0x298(0x8)
	float K2Node_CustomEvent_Damage;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct UDamageType* K2Node_CustomEvent_DamageType;  // 0x2A8(0x8)
	struct AController* K2Node_CustomEvent_InstigatedBy;  // 0x2B0(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x2B8(0x8)
	struct FString CallFunc_Array_Get_Item;  // 0x2C0(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2D0(0xC)
	char pad_732_1 : 7;  // 0x2DC(0x1)
	bool CallFunc_Map_Remove_ReturnValue : 1;  // 0x2DC(0x1)
	char pad_733[3];  // 0x2DD(0x3)
	struct AActor* CallFunc_Map_Find_Value;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x2E8(0x1)
	char pad_745[7];  // 0x2E9(0x7)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x2F0(0x8)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2F9(0x1)
	char pad_762[6];  // 0x2FA(0x6)
	struct ABP_Harvestable_C* K2Node_DynamicCast_AsBP_Harvestable_2;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x308(0x1)
	char pad_777[7];  // 0x309(0x7)
	struct UDT_Melee_C* K2Node_DynamicCast_AsDT_Melee;  // 0x310(0x8)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x318(0x1)
	char pad_793[7];  // 0x319(0x7)
	struct ABP_Holdable_C* K2Node_CustomEvent_Repair_Tool_Reference;  // 0x320(0x8)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x328(0x1)
	char pad_809[7];  // 0x329(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x330(0x8)
	struct UBP_Player_ExperienceComponent_C* CallFunc_Get_Leveling_Component_Leveling_Component;  // 0x338(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_2;  // 0x340(0x8)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool CallFunc_Has_Durability_ReturnValue : 1;  // 0x348(0x1)
	char pad_841[7];  // 0x349(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x350(0x8)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x358(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x35C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x360(0x10)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x370(0x4)
	char pad_884[4];  // 0x374(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x378(0x10)
	float CallFunc_FClamp_ReturnValue;  // 0x388(0x4)
	char pad_908[4];  // 0x38C(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x390(0x10)
	struct FS_Notification K2Node_MakeStruct_S_Notification;  // 0x3A0(0x20)
	char pad_960_1 : 7;  // 0x3C0(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x3C0(0x1)
	char pad_961_1 : 7;  // 0x3C1(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3C1(0x1)
	char pad_962[2];  // 0x3C2(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x3C4(0x10)
	struct FVector K2Node_CustomEvent_Location;  // 0x3D4(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x3E0(0x8)
	struct TArray<struct ABP_Cupboard_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x3E8(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // 0x3F8(0x8)
	struct ABP_Cupboard_C* CallFunc_Array_Get_Item_2;  // 0x400(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x408(0x4)
	char pad_1036_1 : 7;  // 0x40C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x40C(0x1)
	char pad_1037_1 : 7;  // 0x40D(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue : 1;  // 0x40D(0x1)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.MULTICAST Hit Effect
// Size: 0xC(Inherited: 0x0) 
struct FMULTICAST Hit Effect
{
	struct FVector Location;  // 0x0(0xC)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.On Destroyed
// Size: 0x8(Inherited: 0x0) 
struct FOn Destroyed
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.SERVER Repair
// Size: 0x8(Inherited: 0x0) 
struct FSERVER Repair
{
	struct ABP_Holdable_C* Repair Tool Reference;  // 0x0(0x8)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.Add Attached Actor
// Size: 0x14(Inherited: 0x0) 
struct FAdd Attached Actor
{
	struct FString Build ID;  // 0x0(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x10(0x4)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.Set Cupboard
// Size: 0x10(Inherited: 0x0) 
struct FSet Cupboard
{
	struct FString Cupboard ID;  // 0x0(0x10)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.Check Cupboard Removal
// Size: 0xA8(Inherited: 0x0) 
struct FCheck Cupboard Removal
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue_2;  // 0x28(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AActor* CallFunc_Map_Find_Value;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct ABP_Cupboard_C* K2Node_DynamicCast_AsBP_Cupboard;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x60(0x8)
	struct ABP_Cupboard_C* K2Node_DynamicCast_AsBP_Cupboard_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x74(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct AActor* CallFunc_Map_Find_Value_2;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Map_Find_ReturnValue_2 : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0xA0(0x8)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.Is In Cupboard
// Size: 0x4A(Inherited: 0x0) 
struct FIs In Cupboard
{
	struct FString Player ID;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Return : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x18(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* CallFunc_Map_Find_Value;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ABP_Cupboard_C* K2Node_DynamicCast_AsBP_Cupboard;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x49(0x1)

}; 
// Function BP_BuildingComponent.BP_BuildingComponent_C.Handled Damage
// Size: 0x234(Inherited: 0x0) 
struct FHandled Damage
{
	float Damage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x18(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x30(0x8)
	char pad_56[8];  // 0x38(0x8)
	struct FS_BuildSave CallFunc_Get_Saved_Build_Data_Saved_Data;  // 0x40(0xF0)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_Get_Saved_Build_Data_ReturnValue : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)
	struct FS_BuildSave K2Node_MakeStruct_S_BuildSave;  // 0x140(0xF0)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x230(0x4)

}; 
