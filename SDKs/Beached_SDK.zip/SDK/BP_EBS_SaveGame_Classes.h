#pragma once 
#include <BP_EBS_SaveGame_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_SaveGame.BP_EBS_SaveGame_C
// Size: 0x230(Inherited: 0x28) 
struct UBP_EBS_SaveGame_C : public USaveGame
{
	struct TMap<int32_t, struct AActor*> SavedActors;  // 0x28(0x50)
	struct TMap<int32_t, struct FSTR_EBS_SaveData_Actor> SavedActorsData;  // 0x78(0x50)
	struct TMap<int32_t, struct FSTR_EBS_SaveData_BuildingObject> SavedBuildingsData;  // 0xC8(0x50)
	struct FString SlotName;  // 0x118(0x10)
	struct FName LevelName;  // 0x128(0x8)
	struct TArray<struct FSTR_EBS_SaveData_Level> LevelsData;  // 0x130(0x10)
	struct TMap<struct FString, struct FS_PlayerSave> Players Save;  // 0x140(0x50)
	struct TMap<struct FString, struct FS_BuildSave> Build Saves;  // 0x190(0x50)
	struct TMap<struct FString, struct FS_VehicleSaveData> Vehicle Saves;  // 0x1E0(0x50)

	void InitActorWithSaveID_BPI(struct AActor* Actor, int32_t SaveID, bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.InitActorWithSaveID_BPI
	void SaveGame_BPI(bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SaveGame_BPI
	void GetSavedActor_BPI(int32_t SaveID, bool& Success, struct AActor*& Actor); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.GetSavedActor_BPI
	void LoadLevelData_BPI(struct FName LevelName, bool& Success, struct FSTR_EBS_SaveData_Level& LevelData); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.LoadLevelData_BPI
	void SaveLevelData_BPI(struct FName LevelName, bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SaveLevelData_BPI
	void SaveGameToSlot_BPI(struct FString SlotName, bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SaveGameToSlot_BPI
	void LoadTemporaryData_BPI(struct FSTR_EBS_SaveData_Level LevelData, bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.LoadTemporaryData_BPI
	void ClearTemporaryData_BPI(bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.ClearTemporaryData_BPI
	void InitActor_BPI(struct AActor* Actor, bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.InitActor_BPI
	void SetActorSaveData_BPI(int32_t SaveID, struct FSTR_EBS_SaveData_Actor SaveData, bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SetActorSaveData_BPI
	void SetBuildingSaveData_BPI(int32_t SaveID, struct FSTR_EBS_SaveData_BuildingObject SaveData, bool& Success); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SetBuildingSaveData_BPI
	void GetActorSaveData_BPI(int32_t SaveID, bool& Success, struct FSTR_EBS_SaveData_Actor& SaveData); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.GetActorSaveData_BPI
	void GetBuildingSaveData_BPI(int32_t SaveID, bool& Success, struct FSTR_EBS_SaveData_BuildingObject& SaveData); // Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.GetBuildingSaveData_BPI
}; 



