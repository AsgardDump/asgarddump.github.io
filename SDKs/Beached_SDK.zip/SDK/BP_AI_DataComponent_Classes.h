#pragma once 
#include <BP_AI_DataComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AI_DataComponent.BP_AI_DataComponent_C
// Size: 0x140(Inherited: 0xB0) 
struct UBP_AI_DataComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct TArray<struct AController*> Player Database;  // 0xB8(0x10)
	struct TArray<float> Player Damage Database;  // 0xC8(0x10)
	struct FName Name;  // 0xD8(0x8)
	int32_t Experience Reward;  // 0xE0(0x4)
	float Health;  // 0xE4(0x4)
	float Maximum Health;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct ABP_EnemyCamp_C* EnemyCamp;  // 0xF0(0x8)
	int32_t Power Points Reward;  // 0xF8(0x4)
	int32_t Agility Points Reward;  // 0xFC(0x4)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool Is Alive : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct TArray<struct AActor*> Enemy Targets;  // 0x108(0x10)
	struct FTimerHandle Combat Timer Handle;  // 0x118(0x8)
	struct AActor* Current Enemy Target;  // 0x120(0x8)
	float Combat Check Time;  // 0x128(0x4)
	float Target Lost Distance;  // 0x12C(0x4)
	struct TArray<struct FS_DropItem> Items to Drop;  // 0x130(0x10)

	void BB Update Target(struct AActor* New Target); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.BB Update Target
	void CheckForCombat(); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.CheckForCombat
	void Remove Enemy Target(struct AActor*& Target to Remove); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.Remove Enemy Target
	void Add Enemy Target(struct AActor*& New Target); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.Add Enemy Target
	void Send Information To Camp(); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.Send Information To Camp
	void Handle Damage(float Damage, float& Health); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.Handle Damage
	void Add To Database(float Damage, struct AController* Damage Causer); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.Add To Database
	void On Death(); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.On Death
	void Reward Players(); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.Reward Players
	void ReceiveBeginPlay(); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.ReceiveBeginPlay
	void Widget Visibility(char E_Visibility Visibility); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.Widget Visibility
	void On Point Damage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FHitResult Hit); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.On Point Damage
	void ExecuteUbergraph_BP_AI_DataComponent(int32_t EntryPoint); // Function BP_AI_DataComponent.BP_AI_DataComponent_C.ExecuteUbergraph_BP_AI_DataComponent
}; 



