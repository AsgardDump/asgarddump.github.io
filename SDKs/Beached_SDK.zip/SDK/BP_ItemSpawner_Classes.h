#pragma once 
#include <BP_ItemSpawner_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ItemSpawner.BP_ItemSpawner_C
// Size: 0x288(Inherited: 0x220) 
struct ABP_ItemSpawner_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	float Respawn Timeout;  // 0x230(0x4)
	char pad_564[4];  // 0x234(0x4)
	struct AActor* Spawned Reference;  // 0x238(0x8)
	struct UDataTable* Spawner Data;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool Force Respawn on Timeout : 1;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct FTimerHandle Respawn Timer Handle;  // 0x250(0x8)
	struct FS_InventoryItem Override Item;  // 0x258(0x30)

	void Get Random Item to Spawn(struct FS_InventoryItem& Item to Spawn); // Function BP_ItemSpawner.BP_ItemSpawner_C.Get Random Item to Spawn
	void ReceiveBeginPlay(); // Function BP_ItemSpawner.BP_ItemSpawner_C.ReceiveBeginPlay
	void Respawn(); // Function BP_ItemSpawner.BP_ItemSpawner_C.Respawn
	void Start Respawn Timeout(); // Function BP_ItemSpawner.BP_ItemSpawner_C.Start Respawn Timeout
	void Request Respawn(); // Function BP_ItemSpawner.BP_ItemSpawner_C.Request Respawn
	void ExecuteUbergraph_BP_ItemSpawner(int32_t EntryPoint); // Function BP_ItemSpawner.BP_ItemSpawner_C.ExecuteUbergraph_BP_ItemSpawner
}; 



