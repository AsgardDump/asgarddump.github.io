#pragma once 
#include <BP_InventoryItem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_InventoryItem.BP_InventoryItem_C
// Size: 0x270(Inherited: 0x220) 
struct ABP_InventoryItem_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBP_TargetComponent_C* BP_TargetComponent;  // 0x228(0x8)
	struct UStaticMeshComponent* Item Mesh;  // 0x230(0x8)
	struct FS_InventoryItem Item Data;  // 0x238(0x30)
	struct ABP_ItemSpawner_C* Spawner Reference;  // 0x268(0x8)

	void Local Can Overlap(bool& Success); // Function BP_InventoryItem.BP_InventoryItem_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_InventoryItem.BP_InventoryItem_C.Get Interaction Data
	void DespawnItemTimer(); // Function BP_InventoryItem.BP_InventoryItem_C.DespawnItemTimer
	void Load Attachments(); // Function BP_InventoryItem.BP_InventoryItem_C.Load Attachments
	void UserConstructionScript(); // Function BP_InventoryItem.BP_InventoryItem_C.UserConstructionScript
	void Local Overlap(bool Overlap); // Function BP_InventoryItem.BP_InventoryItem_C.Local Overlap
	void ReceiveBeginPlay(); // Function BP_InventoryItem.BP_InventoryItem_C.ReceiveBeginPlay
	void Toggle Selected(bool Toggle); // Function BP_InventoryItem.BP_InventoryItem_C.Toggle Selected
	void On Interacted(struct AController* Executor); // Function BP_InventoryItem.BP_InventoryItem_C.On Interacted
	void ReceiveTick(float DeltaSeconds); // Function BP_InventoryItem.BP_InventoryItem_C.ReceiveTick
	void ExecuteUbergraph_BP_InventoryItem(int32_t EntryPoint); // Function BP_InventoryItem.BP_InventoryItem_C.ExecuteUbergraph_BP_InventoryItem
}; 



