#pragma once 
#include "SDK.h" 
 
 
// Function BP_InventoryItem.BP_InventoryItem_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.ExecuteUbergraph_BP_InventoryItem
// Size: 0x376(Inherited: 0x0) 
struct FExecuteUbergraph_BP_InventoryItem
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x20(0x10)
	struct TArray<struct AActor*> Temp_object_Variable_2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0x41(0x1)
	char pad_66[14];  // 0x42(0xE)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0x50(0xE0)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x131(0x1)
	char pad_306[6];  // 0x132(0x6)
	struct AController* K2Node_Event_Executor;  // 0x138(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x149(0x1)
	char pad_330[6];  // 0x14A(0x6)
	struct TArray<int32_t> K2Node_MakeArray_Array;  // 0x150(0x10)
	int32_t CallFunc_Find_Free_Space_for_Item_Found_Space;  // 0x160(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x164(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x168(0x4)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x16C(0x1)
	char pad_365[3];  // 0x16D(0x3)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0x170(0x30)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x1A0(0x4)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x1A4(0x1)
	char pad_421[3];  // 0x1A5(0x3)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem_2;  // 0x1A8(0x30)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_Add_Item_Success : 1;  // 0x1D8(0x1)
	char pad_473[3];  // 0x1D9(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1DC(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_2;  // 0x1E8(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1F8(0xC)
	struct FHitResult CallFunc_SphereTraceSingleForObjects_OutHit;  // 0x204(0x8C)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool CallFunc_SphereTraceSingleForObjects_ReturnValue : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0x298(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x2A0(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x2AC(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x2B8(0x4)
	char pad_700[4];  // 0x2BC(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x2C0(0x8)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x2CC(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_3;  // 0x2D8(0x10)
	struct FHitResult CallFunc_SphereTraceSingleForObjects_OutHit_2;  // 0x2E8(0x8C)
	char pad_884_1 : 7;  // 0x374(0x1)
	bool CallFunc_SphereTraceSingleForObjects_ReturnValue_2 : 1;  // 0x374(0x1)
	char pad_885_1 : 7;  // 0x375(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x375(0x1)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.Load Attachments
// Size: 0x1E5(Inherited: 0x0) 
struct FLoad Attachments
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x10(0x10)
	char CallFunc_Array_Get_Item;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	struct FS_WeaponAttachment CallFunc_GetDataTableRowFromName_OutRow;  // 0x30(0xB0)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0xE1(0x1)
	char pad_226[14];  // 0xE2(0xE)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0xF0(0xE0)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x1D0(0x8)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x1D8(0x1)
	char pad_473_1 : 7;  // 0x1D9(0x1)
	bool CallFunc_ClassIsChildOf_ReturnValue : 1;  // 0x1D9(0x1)
	char pad_474_1 : 7;  // 0x1DA(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x1DA(0x1)
	char pad_475_1 : 7;  // 0x1DB(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1DB(0x1)
	char pad_476_1 : 7;  // 0x1DC(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1DC(0x1)
	char pad_477[3];  // 0x1DD(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x1E0(0x4)
	char pad_484_1 : 7;  // 0x1E4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1E4(0x1)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.UserConstructionScript
// Size: 0x128(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0x10(0xE0)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0xF1(0x1)
	char pad_242[6];  // 0xF2(0x6)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0xF8(0x30)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_InventoryItem.BP_InventoryItem_C.Get Interaction Data
// Size: 0x1C0(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0x20(0xE0)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x100(0x40)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x140(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x158(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x198(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x1A8(0x18)

}; 
