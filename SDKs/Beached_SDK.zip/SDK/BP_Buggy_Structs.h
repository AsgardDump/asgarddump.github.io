#pragma once 
#include "SDK.h" 
 
 
// Function BP_Buggy.BP_Buggy_C.ExecuteUbergraph_BP_Buggy
// Size: 0x943(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Buggy
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float K2Node_InputAxisEvent_AxisValue_4;  // 0x24(0x4)
	float K2Node_InputAxisEvent_AxisValue_3;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_4;  // 0x30(0x18)
	float K2Node_Event_DeltaSeconds;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct AController* K2Node_DynamicCast_AsController;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x6A(0x1)
	char pad_107[5];  // 0x6B(0x5)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x70(0x30)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0xA0(0x4)
	char pad_164[12];  // 0xA4(0xC)
	struct FTransform K2Node_CustomEvent_Transform;  // 0xB0(0x30)
	struct FTransform CallFunc_TInterpTo_ReturnValue;  // 0xE0(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x110(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x11C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x128(0xC)
	char pad_308[12];  // 0x134(0xC)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x140(0x30)
	struct FHitResult CallFunc_K2_SetActorLocationAndRotation_SweepHitResult;  // 0x170(0x8C)
	char pad_508_1 : 7;  // 0x1FC(0x1)
	bool CallFunc_K2_SetActorLocationAndRotation_ReturnValue : 1;  // 0x1FC(0x1)
	char pad_509[3];  // 0x1FD(0x3)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x200(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x20C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x218(0xC)
	char pad_548[4];  // 0x224(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x228(0x8)
	struct AAIController* K2Node_DynamicCast_AsAIController;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct AController* K2Node_Event_OldController;  // 0x240(0x8)
	struct FKey Temp_struct_Variable;  // 0x248(0x18)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct FKey K2Node_InputKeyEvent_Key_5;  // 0x270(0x18)
	struct FKey K2Node_InputKeyEvent_Key_6;  // 0x288(0x18)
	struct AController* K2Node_Event_Executor;  // 0x2A0(0x8)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x2A8(0x4)
	char pad_684[4];  // 0x2AC(0x4)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character;  // 0x2B0(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x2B8(0x8)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue;  // 0x2C0(0x8)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue_2;  // 0x2C8(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x2D0(0x8)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x2D8(0x1)
	char pad_729[7];  // 0x2D9(0x7)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue_3;  // 0x2E0(0x8)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character_2;  // 0x2E8(0x8)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2F0(0x1)
	char pad_753[3];  // 0x2F1(0x3)
	float K2Node_InputAxisEvent_AxisValue;  // 0x2F4(0x4)
	struct AController* K2Node_Event_NewController;  // 0x2F8(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_2;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x308(0x1)
	char pad_777_1 : 7;  // 0x309(0x1)
	bool K2Node_CustomEvent_Headlights : 1;  // 0x309(0x1)
	char pad_778[6];  // 0x30A(0x6)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x310(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x340(0x8)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x348(0x1)
	char pad_841[7];  // 0x349(0x7)
	struct AAIController* CallFunc_FinishSpawningActor_ReturnValue;  // 0x350(0x8)
	float K2Node_Event_Damage;  // 0x358(0x4)
	char pad_860[4];  // 0x35C(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x360(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x368(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x370(0x8)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // 0x378(0x8)
	struct UDT_Explosion_C* K2Node_DynamicCast_AsDT_Explosion;  // 0x380(0x8)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x388(0x1)
	char pad_905[3];  // 0x389(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x38C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x390(0x4)
	char pad_916[4];  // 0x394(0x4)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x398(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_3;  // 0x3A0(0x8)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x3A8(0x1)
	char pad_937[3];  // 0x3A9(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x3AC(0x4)
	struct FTransform CallFunc_GetTransform_ReturnValue_3;  // 0x3B0(0x30)
	struct FVector CallFunc_BreakTransform_Location_3;  // 0x3E0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_3;  // 0x3EC(0xC)
	struct FVector CallFunc_BreakTransform_Scale_3;  // 0x3F8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x404(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0x410(0x30)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0x440(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x448(0x8)
	struct ABP_Explosion_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x450(0x8)
	char pad_1112_1 : 7;  // 0x458(0x1)
	bool K2Node_CustomEvent_Toggle : 1;  // 0x458(0x1)
	char pad_1113_1 : 7;  // 0x459(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x459(0x1)
	char pad_1114_1 : 7;  // 0x45A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x45A(0x1)
	char pad_1115[5];  // 0x45B(0x5)
	struct FKey Temp_struct_Variable_2;  // 0x460(0x18)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x478(0x18)
	char pad_1168_1 : 7;  // 0x490(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x490(0x1)
	char pad_1169_1 : 7;  // 0x491(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // 0x491(0x1)
	char pad_1170[6];  // 0x492(0x6)
	struct ACharacter* K2Node_CustomEvent_Target;  // 0x498(0x8)
	struct FVector K2Node_CustomEvent_NewLocation;  // 0x4A0(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x4AC(0x8C)
	char pad_1336_1 : 7;  // 0x538(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x538(0x1)
	char pad_1337_1 : 7;  // 0x539(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x539(0x1)
	char pad_1338_1 : 7;  // 0x53A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x53A(0x1)
	char pad_1339[5];  // 0x53B(0x5)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x540(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x548(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x550(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x558(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x560(0x4)
	char pad_1380_1 : 7;  // 0x564(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x564(0x1)
	char pad_1381[3];  // 0x565(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x568(0x8C)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x5F4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_3;  // 0x600(0x30)
	struct FVector CallFunc_BreakTransform_Location_4;  // 0x630(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_4;  // 0x63C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_4;  // 0x648(0xC)
	float CallFunc_VSizeSquared_ReturnValue;  // 0x654(0x4)
	char pad_1624_1 : 7;  // 0x658(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x658(0x1)
	char pad_1625_1 : 7;  // 0x659(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x659(0x1)
	char pad_1626_1 : 7;  // 0x65A(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x65A(0x1)
	char pad_1627_1 : 7;  // 0x65B(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x65B(0x1)
	char pad_1628[4];  // 0x65C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x660(0x8)
	char pad_1640_1 : 7;  // 0x668(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x668(0x1)
	char pad_1641[7];  // 0x669(0x7)
	struct AController* K2Node_DynamicCast_AsController_2;  // 0x670(0x8)
	char pad_1656_1 : 7;  // 0x678(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x678(0x1)
	char pad_1657_1 : 7;  // 0x679(0x1)
	bool CallFunc_IsLocalController_ReturnValue_2 : 1;  // 0x679(0x1)
	char pad_1658[6];  // 0x67A(0x6)
	struct AActor* K2Node_CustomEvent_DamagedActor;  // 0x680(0x8)
	struct FHitResult CallFunc_MakeHitResult_ReturnValue;  // 0x688(0x8C)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x714(0xC)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x720(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x728(0xC)
	char pad_1844[4];  // 0x734(0x4)
	struct AController* K2Node_DynamicCast_AsController_3;  // 0x738(0x8)
	char pad_1856_1 : 7;  // 0x740(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x740(0x1)
	char pad_1857[3];  // 0x741(0x3)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x744(0xC)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character_3;  // 0x750(0x8)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x758(0xC)
	float CallFunc_ApplyPointDamage_ReturnValue;  // 0x764(0x4)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x768(0x18)
	struct FVector CallFunc_BreakTransform_Location_5;  // 0x780(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_5;  // 0x78C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_5;  // 0x798(0xC)
	char pad_1956_1 : 7;  // 0x7A4(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x7A4(0x1)
	char pad_1957[3];  // 0x7A5(0x3)
	float CallFunc_VSizeSquared_ReturnValue_2;  // 0x7A8(0x4)
	char pad_1964_1 : 7;  // 0x7AC(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x7AC(0x1)
	char pad_1965_1 : 7;  // 0x7AD(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x7AD(0x1)
	char pad_1966[2];  // 0x7AE(0x2)
	struct FVector CallFunc_BreakTransform_Location_6;  // 0x7B0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_6;  // 0x7BC(0xC)
	struct FVector CallFunc_BreakTransform_Scale_6;  // 0x7C8(0xC)
	float CallFunc_VSizeSquared_ReturnValue_3;  // 0x7D4(0x4)
	char pad_2008_1 : 7;  // 0x7D8(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x7D8(0x1)
	char pad_2009_1 : 7;  // 0x7D9(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x7D9(0x1)
	char pad_2010_1 : 7;  // 0x7DA(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x7DA(0x1)
	char pad_2011_1 : 7;  // 0x7DB(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7DB(0x1)
	char pad_2012_1 : 7;  // 0x7DC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x7DC(0x1)
	char pad_2013_1 : 7;  // 0x7DD(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_5 : 1;  // 0x7DD(0x1)
	char pad_2014_1 : 7;  // 0x7DE(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x7DE(0x1)
	char pad_2015_1 : 7;  // 0x7DF(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x7DF(0x1)
	char pad_2016_1 : 7;  // 0x7E0(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x7E0(0x1)
	char pad_2017[7];  // 0x7E1(0x7)
	struct TScriptInterface<IBPI_Spawning_C> K2Node_DynamicCast_AsBPI_Spawning;  // 0x7E8(0x10)
	char pad_2040_1 : 7;  // 0x7F8(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x7F8(0x1)
	char pad_2041_1 : 7;  // 0x7F9(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x7F9(0x1)
	char pad_2042_1 : 7;  // 0x7FA(0x1)
	bool CallFunc_BooleanNAND_ReturnValue : 1;  // 0x7FA(0x1)
	char pad_2043_1 : 7;  // 0x7FB(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x7FB(0x1)
	float CallFunc_Water_Deepness_Deepness;  // 0x7FC(0x4)
	char pad_2048_1 : 7;  // 0x800(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0x800(0x1)
	char pad_2049[3];  // 0x801(0x3)
	float CallFunc_Water_Deepness_Deepness_2;  // 0x804(0x4)
	char pad_2056[8];  // 0x808(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue_4;  // 0x810(0x30)
	char pad_2112_1 : 7;  // 0x840(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_4 : 1;  // 0x840(0x1)
	char pad_2113[3];  // 0x841(0x3)
	struct FVector CallFunc_BreakTransform_Location_7;  // 0x844(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_7;  // 0x850(0xC)
	struct FVector CallFunc_BreakTransform_Scale_7;  // 0x85C(0xC)
	struct FVector CallFunc_GetVelocity_ReturnValue_2;  // 0x868(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x874(0x10)
	char pad_2180[12];  // 0x884(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_4;  // 0x890(0x30)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x8C0(0x8)
	char pad_2248_1 : 7;  // 0x8C8(0x1)
	bool CallFunc_NearlyEqual_TransformTransform_ReturnValue : 1;  // 0x8C8(0x1)
	char pad_2249[3];  // 0x8C9(0x3)
	float CallFunc_Conv_BoolToFloat_ReturnValue;  // 0x8CC(0x4)
	char pad_2256_1 : 7;  // 0x8D0(0x1)
	bool K2Node_CustomEvent_Is_Engine_On : 1;  // 0x8D0(0x1)
	char pad_2257[3];  // 0x8D1(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8D4(0x4)
	char pad_2264_1 : 7;  // 0x8D8(0x1)
	bool CallFunc_EqualEqual_BoolBool_ReturnValue : 1;  // 0x8D8(0x1)
	char pad_2265_1 : 7;  // 0x8D9(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_4 : 1;  // 0x8D9(0x1)
	char pad_2266_1 : 7;  // 0x8DA(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x8DA(0x1)
	char pad_2267_1 : 7;  // 0x8DB(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_5 : 1;  // 0x8DB(0x1)
	char pad_2268_1 : 7;  // 0x8DC(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0x8DC(0x1)
	char pad_2269[3];  // 0x8DD(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x8E0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x8E4(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x8E8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x8EC(0xC)
	char pad_2296_1 : 7;  // 0x8F8(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue : 1;  // 0x8F8(0x1)
	char pad_2297[3];  // 0x8F9(0x3)
	struct FVector CallFunc_BreakTransform_Location_8;  // 0x8FC(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_8;  // 0x908(0xC)
	struct FVector CallFunc_BreakTransform_Scale_8;  // 0x914(0xC)
	float CallFunc_VSizeXY_ReturnValue;  // 0x920(0x4)
	char pad_2340[4];  // 0x924(0x4)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x928(0x8)
	float CallFunc_Abs_ReturnValue;  // 0x930(0x4)
	char pad_2356[4];  // 0x934(0x4)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_4;  // 0x938(0x8)
	char pad_2368_1 : 7;  // 0x940(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x940(0x1)
	char pad_2369_1 : 7;  // 0x941(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x941(0x1)
	char pad_2370_1 : 7;  // 0x942(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_6 : 1;  // 0x942(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Toggle Engine
// Size: 0x1(Inherited: 0x0) 
struct FToggle Engine
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.SERVER Toggle Headlights
// Size: 0x1(Inherited: 0x0) 
struct FSERVER Toggle Headlights
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Headlights : 1;  // 0x0(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.MULTICAST Disembark
// Size: 0x14(Inherited: 0x0) 
struct FMULTICAST Disembark
{
	struct ACharacter* Target;  // 0x0(0x8)
	struct FVector NewLocation;  // 0x8(0xC)

}; 
// Function BP_Buggy.BP_Buggy_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Get Interaction Data
// Size: 0x1B(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_BooleanNAND_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.OnRep_Is Player Controlled
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_Is Player Controlled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.SERVER Set Engine Value
// Size: 0x1(Inherited: 0x0) 
struct FSERVER Set Engine Value
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Is Engine On : 1;  // 0x0(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function BP_Buggy.BP_Buggy_C.Apply Point Damage
// Size: 0x8(Inherited: 0x0) 
struct FApply Point Damage
{
	struct AActor* DamagedActor;  // 0x0(0x8)

}; 
// Function BP_Buggy.BP_Buggy_C.BndEvt__Sedan_Damage Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Sedan_Damage Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x8C)

}; 
// Function BP_Buggy.BP_Buggy_C.Change Color
// Size: 0x10(Inherited: 0x0) 
struct FChange Color
{
	struct FLinearColor CallFunc_Conv_VectorToLinearColor_ReturnValue;  // 0x0(0x10)

}; 
// Function BP_Buggy.BP_Buggy_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.ReceivePossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessed : public FReceivePossessed
{
	struct AController* NewController;  // 0x0(0x8)

}; 
// Function BP_Buggy.BP_Buggy_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_48
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Turn_K2Node_InputAxisEvent_48
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_41
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookUp_K2Node_InputAxisEvent_41
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_Buggy.BP_Buggy_C.OnRep_Fuel Amount
// Size: 0x3(Inherited: 0x0) 
struct FOnRep_Fuel Amount
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Toggle Simulate Physics
// Size: 0x3(Inherited: 0x0) 
struct FToggle Simulate Physics
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue_2 : 1;  // 0x2(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.ReceiveUnpossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnpossessed : public FReceiveUnpossessed
{
	struct AController* OldController;  // 0x0(0x8)

}; 
// Function BP_Buggy.BP_Buggy_C.SERVER Set Transform
// Size: 0x30(Inherited: 0x0) 
struct FSERVER Set Transform
{
	struct FTransform Transform;  // 0x0(0x30)

}; 
// Function BP_Buggy.BP_Buggy_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.InpActEvt_SpaceBar_K2Node_InputKeyEvent_6
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_SpaceBar_K2Node_InputKeyEvent_6
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Buggy.BP_Buggy_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_16
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveRight_K2Node_InputAxisEvent_16
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.Decerase Fuel
// Size: 0x8(Inherited: 0x0) 
struct FDecerase Fuel
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x4(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_7
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveForward_K2Node_InputAxisEvent_7
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Passenger DIsmount Request
// Size: 0x2A(Inherited: 0x0) 
struct FPassenger DIsmount Request
{
	struct USceneComponent* From Attach Point;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Info Call Only : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector Dismount Location;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1B(0x1)
	struct FVector CallFunc_Find_Dismount_Location_Output_Get;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_NotEqualExactly_VectorVector_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x29(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Get Fuel
// Size: 0x8(Inherited: 0x0) 
struct FGet Fuel
{
	float Fuel Amount;  // 0x0(0x4)
	float Max Fuel;  // 0x4(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.Water Deepness
// Size: 0x1AC(Inherited: 0x0) 
struct FWater Deepness
{
	float Deepness;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x1C(0xC)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0x28(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x34(0xC)
	struct FBoxSphereBounds CallFunc_GetImportedBounds_ReturnValue;  // 0x40(0x1C)
	char pad_92[4];  // 0x5C(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x60(0x10)
	float CallFunc_BreakVector_X;  // 0x70(0x4)
	float CallFunc_BreakVector_Y;  // 0x74(0x4)
	float CallFunc_BreakVector_Z;  // 0x78(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x7C(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x80(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x8C(0xC)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x98(0x8C)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x124(0x1)
	char pad_293_1 : 7;  // 0x125(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x125(0x1)
	char pad_294_1 : 7;  // 0x126(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x126(0x1)
	char pad_295[1];  // 0x127(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x128(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x12C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x130(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x13C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x148(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x154(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x160(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x168(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x170(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x178(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x180(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x184(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x188(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x194(0xC)
	float K2Node_Select_Default;  // 0x1A0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1A4(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x1A8(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.InpActEvt_G_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_G_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Buggy.BP_Buggy_C.Possess To Vehicle
// Size: 0x40(Inherited: 0x0) 
struct FPossess To Vehicle
{
	struct AController* Target;  // 0x0(0x8)
	struct FRotator L Control Rotation;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x34(0xC)

}; 
// Function BP_Buggy.BP_Buggy_C.InpActEvt_G_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_G_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Buggy.BP_Buggy_C.InpActEvt_F_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_F_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Buggy.BP_Buggy_C.InpActEvt_E_K2Node_InputKeyEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_E_K2Node_InputKeyEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Buggy.BP_Buggy_C.InpActEvt_SpaceBar_K2Node_InputKeyEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_SpaceBar_K2Node_InputKeyEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Buggy.BP_Buggy_C.UserConstructionScript
// Size: 0x8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_Buggy.BP_Buggy_C.Add Health to Vehicle
// Size: 0x14(Inherited: 0x0) 
struct FAdd Health to Vehicle
{
	float Amount;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x10(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.Possess To Character
// Size: 0x59(Inherited: 0x0) 
struct FPossess To Character
{
	struct FVector L Loc;  // 0x0(0xC)
	struct FRotator L Control Rotation;  // 0xC(0xC)
	struct FVector CallFunc_Find_Dismount_Location_Output_Get;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_NotEqualExactly_VectorVector_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x28(0x8)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x40(0x8)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character;  // 0x48(0x8)
	struct AController* CallFunc_GetController_ReturnValue_3;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.On Destroyed
// Size: 0x1(Inherited: 0x0) 
struct FOn Destroyed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Save Vehicle
// Size: 0xD9(Inherited: 0x0) 
struct FSave Vehicle
{
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x0(0x30)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x30(0x10)
	struct FS_VehicleSaveData K2Node_MakeStruct_S_VehicleSaveData;  // 0x40(0x60)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0xA0(0x10)
	struct FString CallFunc_Generate_Random_Timestamp_ID_ReturnValue;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0xC8(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Find Dismount Location
// Size: 0x315(Inherited: 0x0) 
struct FFind Dismount Location
{
	struct FVector Output_Get;  // 0x0(0xC)
	struct FVector L Loc;  // 0xC(0xC)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_2;  // 0x48(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x58(0xC)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x64(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x68(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x74(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x80(0xC)
	struct FVector CallFunc_GetActorUpVector_ReturnValue;  // 0x8C(0xC)
	struct TArray<struct AActor*> Temp_object_Variable_2;  // 0x98(0x10)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xA8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xB4(0xC)
	int32_t Temp_int_Variable;  // 0xC0(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0xC4(0xC)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xD0(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0xD4(0xC)
	float CallFunc_DegCos_ReturnValue;  // 0xE0(0x4)
	struct FHitResult CallFunc_CapsuleTraceSingle_OutHit;  // 0xE4(0x8C)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_CapsuleTraceSingle_ReturnValue : 1;  // 0x170(0x1)
	char pad_369[3];  // 0x171(0x3)
	float CallFunc_DegSin_ReturnValue;  // 0x174(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x178(0x4)
	char pad_380_1 : 7;  // 0x17C(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x17C(0x1)
	char pad_381_1 : 7;  // 0x17D(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x17D(0x1)
	char pad_382_1 : 7;  // 0x17E(0x1)
	bool CallFunc_NotEqualExactly_VectorVector_ReturnValue : 1;  // 0x17E(0x1)
	char pad_383[1];  // 0x17F(0x1)
	struct FVector CallFunc_GetActorRightVector_ReturnValue;  // 0x180(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x18C(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x198(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x1A4(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_4;  // 0x1B0(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x1BC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_5;  // 0x1C8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_4;  // 0x1D4(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_5;  // 0x1E0(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_6;  // 0x1EC(0xC)
	struct FHitResult CallFunc_CapsuleTraceSingle_OutHit_2;  // 0x1F8(0x8C)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool CallFunc_CapsuleTraceSingle_ReturnValue_2 : 1;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x288(0x8C)
	char pad_788_1 : 7;  // 0x314(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x314(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Unsave Vehicle
// Size: 0x11(Inherited: 0x0) 
struct FUnsave Vehicle
{
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x0(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_Buggy.BP_Buggy_C.Add Fuel
// Size: 0x2C(Inherited: 0x0) 
struct FAdd Fuel
{
	float Fuel Amount;  // 0x0(0x4)
	float Take Durability;  // 0x4(0x4)
	float L Durab;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x28(0x4)

}; 
// Function BP_Buggy.BP_Buggy_C.Remove Fuel
// Size: 0x15(Inherited: 0x0) 
struct FRemove Fuel
{
	float Add Durability;  // 0x0(0x4)
	float L Cached fuel;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x14(0x1)

}; 
