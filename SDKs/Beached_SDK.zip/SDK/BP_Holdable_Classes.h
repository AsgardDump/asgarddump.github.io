#pragma once 
#include <BP_Holdable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable.BP_Holdable_C
// Size: 0x30A(Inherited: 0x220) 
struct ABP_Holdable_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Item Mesh;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct FS_Crosshair Crosshair;  // 0x238(0x30)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool Holdable Swapped : 1;  // 0x268(0x1)
	char E_HoldableType Holdable Type;  // 0x269(0x1)
	char pad_618_1 : 7;  // 0x26A(0x1)
	bool Enable Holster : 1;  // 0x26A(0x1)
	char pad_619[5];  // 0x26B(0x5)
	struct FS_HolsterData Holster Data;  // 0x270(0x50)
	struct UAnimMontage* Equip Animation;  // 0x2C0(0x8)
	struct UAnimMontage* Dequip Animation;  // 0x2C8(0x8)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Dequiping : 1;  // 0x2D0(0x1)
	char pad_721_1 : 7;  // 0x2D1(0x1)
	bool Destroyed : 1;  // 0x2D1(0x1)
	char pad_722[6];  // 0x2D2(0x6)
	struct FS_InventoryItem Item Data;  // 0x2D8(0x30)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool Equiping : 1;  // 0x308(0x1)
	char pad_777_1 : 7;  // 0x309(0x1)
	bool Allow in Water : 1;  // 0x309(0x1)

	void Can Toggle Menu(bool& Pass); // Function BP_Holdable.BP_Holdable_C.Can Toggle Menu
	void On Movement Mode Updated(char E_PlayerMovementMode Movement Mode, bool& Success); // Function BP_Holdable.BP_Holdable_C.On Movement Mode Updated
	void Is Player Controlled(bool& Player Controlled); // Function BP_Holdable.BP_Holdable_C.Is Player Controlled
	void Is Alive(bool& Is Alive); // Function BP_Holdable.BP_Holdable_C.Is Alive
	void Get Hand IK Points(struct FVector& Hand IK L World Space, struct FVector& Hand IK R World Space); // Function BP_Holdable.BP_Holdable_C.Get Hand IK Points
	void Create Static Mesh Component(struct UStaticMesh* Mesh, struct USceneComponent*& Return); // Function BP_Holdable.BP_Holdable_C.Create Static Mesh Component
	void Create Child Actor Component(AActor* Actor, struct USceneComponent*& Return); // Function BP_Holdable.BP_Holdable_C.Create Child Actor Component
	void Remove Holster Component(struct USceneComponent* Component, bool& Return); // Function BP_Holdable.BP_Holdable_C.Remove Holster Component
	bool Is Owner Local(); // Function BP_Holdable.BP_Holdable_C.Is Owner Local
	void Start Aiming(struct FVector Camera Offset, float Arm Length); // Function BP_Holdable.BP_Holdable_C.Start Aiming
	void Stop Aiming(); // Function BP_Holdable.BP_Holdable_C.Stop Aiming
	void On Player Revived(); // Function BP_Holdable.BP_Holdable_C.On Player Revived
	void On Player Dead(bool Knocked); // Function BP_Holdable.BP_Holdable_C.On Player Dead
	void Load Player Customization(struct FS_PlayerCustomization Customization); // Function BP_Holdable.BP_Holdable_C.Load Player Customization
	void Update Name Tag(); // Function BP_Holdable.BP_Holdable_C.Update Name Tag
	void Toggle Sprint(bool Toggle); // Function BP_Holdable.BP_Holdable_C.Toggle Sprint
	void Set Holdable Type(char E_HoldableType Holdable Type); // Function BP_Holdable.BP_Holdable_C.Set Holdable Type
	void Primary Action(bool Pressed); // Function BP_Holdable.BP_Holdable_C.Primary Action
	void Update Armor(char E_ArmorType Armor Type, struct USkeletalMesh* Skeletal Mesh); // Function BP_Holdable.BP_Holdable_C.Update Armor
	void Show Player Tag(bool Toggle); // Function BP_Holdable.BP_Holdable_C.Show Player Tag
	void Hide Customization(struct TArray<char E_CustomizationItem>& Hide Mesh); // Function BP_Holdable.BP_Holdable_C.Hide Customization
	void Local Request Attack(); // Function BP_Holdable.BP_Holdable_C.Local Request Attack
	void On Swimming(bool Toggle); // Function BP_Holdable.BP_Holdable_C.On Swimming
	void On Vehicle Attachment Updated(); // Function BP_Holdable.BP_Holdable_C.On Vehicle Attachment Updated
	void ReceiveBeginPlay(); // Function BP_Holdable.BP_Holdable_C.ReceiveBeginPlay
	void ReceiveDestroyed(); // Function BP_Holdable.BP_Holdable_C.ReceiveDestroyed
	void On Equip(); // Function BP_Holdable.BP_Holdable_C.On Equip
	void On Dequip(); // Function BP_Holdable.BP_Holdable_C.On Dequip
	void Dequip Holdable(); // Function BP_Holdable.BP_Holdable_C.Dequip Holdable
	void MULTICAST Dequip Holdable(); // Function BP_Holdable.BP_Holdable_C.MULTICAST Dequip Holdable
	void SERVER Destroy Actor(); // Function BP_Holdable.BP_Holdable_C.SERVER Destroy Actor
	void SERVER Dequip Holdable(); // Function BP_Holdable.BP_Holdable_C.SERVER Dequip Holdable
	void Aiming Action(bool Toggle); // Function BP_Holdable.BP_Holdable_C.Aiming Action
	void MULTICAST Set Destroyed(); // Function BP_Holdable.BP_Holdable_C.MULTICAST Set Destroyed
	void SERVER Set Destroyed(); // Function BP_Holdable.BP_Holdable_C.SERVER Set Destroyed
	void ExecuteUbergraph_BP_Holdable(int32_t EntryPoint); // Function BP_Holdable.BP_Holdable_C.ExecuteUbergraph_BP_Holdable
}; 



