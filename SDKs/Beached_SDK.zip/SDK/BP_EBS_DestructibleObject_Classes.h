#pragma once 
#include <BP_EBS_DestructibleObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_DestructibleObject.BP_EBS_DestructibleObject_C
// Size: 0x24C(Inherited: 0x238) 
struct ABP_EBS_DestructibleObject_C : public ADestructibleActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UDestructibleMesh* DestructibleMesh;  // 0x240(0x8)
	float TimeRemaining;  // 0x248(0x4)

	void UserConstructionScript(); // Function BP_EBS_DestructibleObject.BP_EBS_DestructibleObject_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_EBS_DestructibleObject.BP_EBS_DestructibleObject_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_EBS_DestructibleObject(int32_t EntryPoint); // Function BP_EBS_DestructibleObject.BP_EBS_DestructibleObject_C.ExecuteUbergraph_BP_EBS_DestructibleObject
}; 



