#pragma once 
#include <BP_EBS_SaveLibrary_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_EBS_SaveLibrary_C : public UBlueprintFunctionLibrary
{

	void GetFormatedVariableStringArray(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, struct TArray<struct FString>& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableStringArray
	void GetFormatedVariableTransformValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, struct FTransform& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableTransformValue
	void GetFormatedVariableRotatorValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, struct FRotator& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableRotatorValue
	void GetFormatedVariableVectorValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, struct FVector& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableVectorValue
	void GetFormatedVariableTextValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, struct FText& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableTextValue
	void GetFormatedVariableStringValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, struct FString& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableStringValue
	void FormatStringArrayVariableToString(struct FString VariableName, struct TArray<struct FString>& Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatStringArrayVariableToString
	void GetFormatedVariableNameValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, struct FName& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableNameValue
	void GetFormatedVariableFloatValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, float& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableFloatValue
	void GetFormatedVariableIntegerValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, int32_t& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableIntegerValue
	void GetFormatedVariableByteValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, char& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableByteValue
	void FormatTransformVariableToString(struct FString VariableName, struct FTransform Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatTransformVariableToString
	void FormatRotatorVariableToString(struct FString VariableName, struct FRotator Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatRotatorVariableToString
	void FormatVectorVariableToString(struct FString VariableName, struct FVector Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatVectorVariableToString
	void FormatTextVariableToString(struct FString VariableName, struct FText Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatTextVariableToString
	void FormatStringVariableToString(struct FString VariableName, struct FString Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatStringVariableToString
	void FormatNameVariableToString(struct FString VariableName, struct FName Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatNameVariableToString
	void FormatFloatVariableToString(struct FString VariableName, float Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatFloatVariableToString
	void FormatIntegerVariableToString(struct FString VariableName, int32_t Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatIntegerVariableToString
	void FormatByteVariableToString(struct FString VariableName, char Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatByteVariableToString
	void GetFormatedVariableBooleanValue(struct TArray<struct FString>& FormatedVariables, struct FString VariableName, struct UObject* __WorldContext, bool& Success, bool& Value); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedVariableBooleanValue
	void FormatBooleanVariableToString(struct FString VariableName, bool Value, struct UObject* __WorldContext, struct FString& FormatedVariable); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.FormatBooleanVariableToString
	void GetFormatedDelimiter(struct UObject* __WorldContext, struct FString& Delimiter); // Function BP_EBS_SaveLibrary.BP_EBS_SaveLibrary_C.GetFormatedDelimiter
}; 



