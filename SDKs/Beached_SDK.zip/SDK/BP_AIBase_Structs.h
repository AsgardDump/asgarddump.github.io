#pragma once 
#include "SDK.h" 
 
 
// Function BP_AIBase.BP_AIBase_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_AIBase.BP_AIBase_C.ExecuteUbergraph_BP_AIBase
// Size: 0x181(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AIBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x8(0x8)
	struct AAIController* K2Node_DynamicCast_AsAIController;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x1C(0x8)
	float K2Node_Event_Damage_2;  // 0x24(0x4)
	struct UDamageType* K2Node_Event_DamageType_2;  // 0x28(0x8)
	struct FVector K2Node_Event_HitLocation;  // 0x30(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x3C(0xC)
	struct UPrimitiveComponent* K2Node_Event_HitComponent;  // 0x48(0x8)
	struct FName K2Node_Event_BoneName;  // 0x50(0x8)
	struct FVector K2Node_Event_ShotFromDirection;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)
	struct AController* K2Node_Event_InstigatedBy_2;  // 0x68(0x8)
	struct AActor* K2Node_Event_DamageCauser_2;  // 0x70(0x8)
	struct FHitResult K2Node_Event_HitInfo;  // 0x78(0x8C)
	char pad_260[4];  // 0x104(0x4)
	struct UAnimMontage* K2Node_CustomEvent_AnimMontage;  // 0x108(0x8)
	float CallFunc_PlayAnimMontage_ReturnValue;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x118(0x8)
	float K2Node_Event_Damage;  // 0x120(0x4)
	char pad_292[4];  // 0x124(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x128(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x130(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x138(0x8)
	struct AController* K2Node_Event_Executor;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x149(0x1)
	char pad_330_1 : 7;  // 0x14A(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x14A(0x1)
	char pad_331[5];  // 0x14B(0x5)
	struct UNavigationSystemV1* CallFunc_GetNavigationSystem_ReturnValue;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x159(0x1)
	char pad_346_1 : 7;  // 0x15A(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x15A(0x1)
	char pad_347[5];  // 0x15B(0x5)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x168(0x1)
	char pad_361_1 : 7;  // 0x169(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x169(0x1)
	char pad_362[6];  // 0x16A(0x6)
	struct TScriptInterface<IBPI_Spawning_C> K2Node_DynamicCast_AsBPI_Spawning;  // 0x170(0x10)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x180(0x1)

}; 
// Function BP_AIBase.BP_AIBase_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_AIBase.BP_AIBase_C.ReceivePointDamage
// Size: 0xE4(Inherited: 0xE8) 
struct FReceivePointDamage : public FReceivePointDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct UPrimitiveComponent* HitComponent;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	struct FVector ShotFromDirection;  // 0x38(0xC)
	struct AController* InstigatedBy;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)
	struct FHitResult HitInfo;  // 0x58(0x8C)

}; 
// Function BP_AIBase.BP_AIBase_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function BP_AIBase.BP_AIBase_C.MULTICAST Play Montage
// Size: 0x8(Inherited: 0x0) 
struct FMULTICAST Play Montage
{
	struct UAnimMontage* AnimMontage;  // 0x0(0x8)

}; 
// Function BP_AIBase.BP_AIBase_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_AIBase.BP_AIBase_C.UserConstructionScript
// Size: 0xD8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x0(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x30(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x3C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x48(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x54(0xC)
	struct FS_Marker K2Node_MakeStruct_S_Marker;  // 0x60(0x30)
	struct FS_TargetInformation K2Node_MakeStruct_S_TargetInformation;  // 0x90(0x48)

}; 
// Function BP_AIBase.BP_AIBase_C.Get Interaction Data
// Size: 0x18(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)

}; 
// Function BP_AIBase.BP_AIBase_C.Local Can Overlap
// Size: 0x22(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_GetSquaredDistanceTo_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x21(0x1)

}; 
