#pragma once 
#include <BP_Campfire_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Campfire.BP_Campfire_C
// Size: 0x4F0(Inherited: 0x4A8) 
struct ABP_Campfire_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct UAudioComponent* WAV_FireLoop_Cue;  // 0x4B0(0x8)
	struct UPointLightComponent* PointLight;  // 0x4B8(0x8)
	struct UParticleSystemComponent* P_Fireplace;  // 0x4C0(0x8)
	float Light_Effect_Alpha_E884E889485B1C430411A9B22E653DF9;  // 0x4C8(0x4)
	char ETimelineDirection Light_Effect__Direction_E884E889485B1C430411A9B22E653DF9;  // 0x4CC(0x1)
	char pad_1229[3];  // 0x4CD(0x3)
	struct UTimelineComponent* Light Effect;  // 0x4D0(0x8)
	float Additional Temperature;  // 0x4D8(0x4)
	char pad_1244[4];  // 0x4DC(0x4)
	struct UDataTable* CraftingTable;  // 0x4E0(0x8)
	struct FName Name;  // 0x4E8(0x8)

	void Get Interaction Data(struct FText& Interaction Text); // Function BP_Campfire.BP_Campfire_C.Get Interaction Data
	void Local Can Overlap(bool& Success); // Function BP_Campfire.BP_Campfire_C.Local Can Overlap
	void Light Effect__FinishedFunc(); // Function BP_Campfire.BP_Campfire_C.Light Effect__FinishedFunc
	void Light Effect__UpdateFunc(); // Function BP_Campfire.BP_Campfire_C.Light Effect__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Campfire.BP_Campfire_C.ReceiveBeginPlay
	void On Interacted(struct AController* Executor); // Function BP_Campfire.BP_Campfire_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_Campfire.BP_Campfire_C.Toggle Selected
	void Local Overlap(bool Overlap); // Function BP_Campfire.BP_Campfire_C.Local Overlap
	void ExecuteUbergraph_BP_Campfire(int32_t EntryPoint); // Function BP_Campfire.BP_Campfire_C.ExecuteUbergraph_BP_Campfire
}; 



