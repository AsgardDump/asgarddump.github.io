#pragma once 
#include <BP_SkillTreeComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SkillTreeComponent.BP_SkillTreeComponent_C
// Size: 0x11C(Inherited: 0xB0) 
struct UBP_SkillTreeComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct TArray<struct FS_SkillDatabase> Unlocked Skills;  // 0xB8(0x10)
	int32_t Survivor Skill Points;  // 0xC8(0x4)
	int32_t Agility Skill Points;  // 0xCC(0x4)
	int32_t Power Skill Points;  // 0xD0(0x4)
	struct FS_CurrentSkills Current Skill Abilities;  // 0xD4(0x18)
	int32_t Survivor Experience Points;  // 0xEC(0x4)
	int32_t Agility Experience Points;  // 0xF0(0x4)
	int32_t Power Experience Points;  // 0xF4(0x4)
	int32_t Survivor Level;  // 0xF8(0x4)
	int32_t Agility Level;  // 0xFC(0x4)
	int32_t Power Level;  // 0x100(0x4)
	int32_t Survivor Level Experience Range;  // 0x104(0x4)
	int32_t Agility Level Experience Range;  // 0x108(0x4)
	int32_t Power Level Experience Range;  // 0x10C(0x4)
	int32_t Survivor Maximum Level;  // 0x110(0x4)
	int32_t Agility Maximum Level;  // 0x114(0x4)
	int32_t Power Maximum Level;  // 0x118(0x4)

	void Save Player Data(); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Save Player Data
	struct APawn* Get Player Pawn(); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Player Pawn
	void Set Skill Experience Points(char E_SkillType Skill Type, int32_t Experience Points); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Set Skill Experience Points
	int32_t Get Skill Maximum Level(char E_SkillType Skill Type); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Skill Maximum Level
	int32_t Get Skill Level(char E_SkillType Skill Type); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Skill Level
	int32_t Get Skill Points(char E_SkillType Skill Type); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Skill Points
	int32_t Get Total Experience Points(char E_SkillType Skill Type); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Total Experience Points
	int32_t Get Level Experience Range(char E_SkillType Skill Type); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Level Experience Range
	void Get Level Information(char E_SkillType Skill Type, int32_t Level, int32_t& Maximum Total XP, int32_t& Minimum Total XP); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Get Level Information
	void Set Skill Points(char E_SkillType Skill Type, int32_t Skill Points); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Set Skill Points
	void Set Skill Level(char E_SkillType Skill Type, int32_t Level); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Set Skill Level
	void Update Experience(char E_SkillType Skill Type, int32_t Experience Points); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Update Experience
	void Update Skill Abilities(struct FS_SkillTreeMaster skill, struct FS_CurrentSkills& Current Skill Abilities); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Update Skill Abilities
	void Can Be Skill Unlocked?(struct FS_SkillDatabase skill, bool& Success); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Can Be Skill Unlocked?
	void SERVER Set Level(char E_SkillType Skill Type, int32_t Level); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Level
	void ReceiveBeginPlay(); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.ReceiveBeginPlay
	void SERVER Set Experience Points(char E_SkillType Skill Type, int32_t Experience Points); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Experience Points
	void Event On Level Up(char E_SkillType Skill Type); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Event On Level Up
	void SERVER Set Skill Points(char E_SkillType Skill Type, int32_t Skill Points); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Skill Points
	void Add Experience(char E_SkillType Skill Type, int32_t Experience Points); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Add Experience
	void Add Skill Points(char E_SkillType Skill Type, int32_t Amount); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Add Skill Points
	void CLIENT Load Skill Data(struct TArray<struct FS_SkillDatabase>& Unlocked Skills, struct FS_CurrentSkills Current Skill Abilities, struct FS_SkillDataSave& Survivor Skill Data, struct FS_SkillDataSave& Agility Skill Data, struct FS_SkillDataSave& Power Skill Data); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.CLIENT Load Skill Data
	void SERVER Set Data(struct FS_CurrentSkills Current Skill Abilities, struct TArray<struct FS_SkillDatabase>& Unlocked Skills); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Set Data
	void Unlock Skill(struct UDataTable* DataTable, struct FName Skill ID); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.Unlock Skill
	void SERVER Load Skill Data(); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.SERVER Load Skill Data
	void ExecuteUbergraph_BP_SkillTreeComponent(int32_t EntryPoint); // Function BP_SkillTreeComponent.BP_SkillTreeComponent_C.ExecuteUbergraph_BP_SkillTreeComponent
}; 



