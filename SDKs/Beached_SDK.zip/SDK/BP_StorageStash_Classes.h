#pragma once 
#include <BP_StorageStash_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_StorageStash.BP_StorageStash_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_StorageStash_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Chest;  // 0x228(0x8)
	struct UBP_ChestInventoryComponent_C* BP_ChestInventoryComponent;  // 0x230(0x8)

	void Local Can Overlap(bool& Success); // Function BP_StorageStash.BP_StorageStash_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_StorageStash.BP_StorageStash_C.Get Interaction Data
	void DespawnStash(); // Function BP_StorageStash.BP_StorageStash_C.DespawnStash
	void Local Overlap(bool Overlap); // Function BP_StorageStash.BP_StorageStash_C.Local Overlap
	void On Interacted(struct AController* Executor); // Function BP_StorageStash.BP_StorageStash_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_StorageStash.BP_StorageStash_C.Toggle Selected
	void ReceiveBeginPlay(); // Function BP_StorageStash.BP_StorageStash_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_StorageStash(int32_t EntryPoint); // Function BP_StorageStash.BP_StorageStash_C.ExecuteUbergraph_BP_StorageStash
}; 



