#pragma once 
#include <BP_Throwable_Object_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Throwable_Object.BP_Throwable_Object_C
// Size: 0x240(Inherited: 0x220) 
struct ABP_Throwable_Object_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* ObjectMesh;  // 0x228(0x8)
	struct FVector Throw Velocity;  // 0x230(0xC)
	float Object Collision Radius;  // 0x23C(0x4)

	void ReceiveBeginPlay(); // Function BP_Throwable_Object.BP_Throwable_Object_C.ReceiveBeginPlay
	void BndEvt__BP_Throwable_Object_ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Throwable_Object.BP_Throwable_Object_C.BndEvt__BP_Throwable_Object_ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void ReceiveTick(float DeltaSeconds); // Function BP_Throwable_Object.BP_Throwable_Object_C.ReceiveTick
	void On Water Hit(struct FVector Location); // Function BP_Throwable_Object.BP_Throwable_Object_C.On Water Hit
	void ExecuteUbergraph_BP_Throwable_Object(int32_t EntryPoint); // Function BP_Throwable_Object.BP_Throwable_Object_C.ExecuteUbergraph_BP_Throwable_Object
}; 



