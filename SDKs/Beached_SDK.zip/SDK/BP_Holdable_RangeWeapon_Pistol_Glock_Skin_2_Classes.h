#pragma once 
#include <BP_Holdable_RangeWeapon_Pistol_Glock_Skin_2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_Pistol_Glock_Skin_2.BP_Holdable_RangeWeapon_Pistol_Glock_Skin_1_C
// Size: 0x49D(Inherited: 0x49D) 
struct ABP_Holdable_RangeWeapon_Pistol_Glock_Skin_1_C : public ABP_Holdable_RangeWeapon_Pistol_C
{

}; 



