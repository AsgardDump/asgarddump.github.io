#pragma once 
#include "SDK.h" 
 
 
// Function BP_NPC_Base.BP_NPC_Base_C.Select Dialogue
// Size: 0x119(Inherited: 0x0) 
struct FSelect Dialogue
{
	struct UBP_MissionComponent_C* MissionComponent;  // 0x0(0x8)
	struct FName Dialogue ID;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x34(0x8)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FS_Dialogue CallFunc_GetDataTableRowFromName_OutRow;  // 0x40(0x38)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FS_TargetInformation K2Node_MakeStruct_S_TargetInformation;  // 0x80(0x48)
	int32_t CallFunc_Find_Target_In_Current_Objectives_Objective_Index;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct FS_ObjectiveTarget CallFunc_Find_Target_In_Current_Objectives_Objective_Target;  // 0xD0(0x48)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_Find_Target_In_Current_Objectives_Successful : 1;  // 0x118(0x1)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.ExecuteUbergraph_BP_NPC_Base
// Size: 0x11A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_NPC_Base
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x28(0x8)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x30(0xC)
	float CallFunc_GetCurveValue_ReturnValue;  // 0x3C(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x40(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x44(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x50(0xC)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x60(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x6C(0xC)
	struct FRotator CallFunc_REase_ReturnValue;  // 0x78(0xC)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x88(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x94(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0xA0(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0xA4(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct UUserWidget* CallFunc_GetWidget_ReturnValue;  // 0xB0(0x8)
	struct UW_NPC_Nametag_C* K2Node_DynamicCast_AsW_NPC_Nametag;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct AController* K2Node_Event_Executor;  // 0xC8(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0xD0(0x8)
	struct FName CallFunc_Select_Dialogue_Dialogue_ID;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_Event_Toggle : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0xE1(0x1)
	char pad_226[2];  // 0xE2(0x2)
	float K2Node_Event_DeltaSeconds;  // 0xE4(0x4)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0xF0(0x8)
	struct UABP_Human_NPC_C* K2Node_DynamicCast_AsABP_Human_NPC;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0x108(0x8)
	struct UABP_Human_NPC_C* K2Node_DynamicCast_AsABP_Human_NPC_2;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x119(0x1)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.UserConstructionScript
// Size: 0x8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.Local Can Overlap
// Size: 0x1D(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x10(0x8)
	float CallFunc_GetSquaredDistanceTo_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x1C(0x1)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.Get Interaction Data
// Size: 0x98(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x18(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x30(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x70(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x80(0x18)

}; 
// Function BP_NPC_Base.BP_NPC_Base_C.On Question Answered
// Size: 0x60(Inherited: 0x0) 
struct FOn Question Answered
{
	struct FName Unique ID;  // 0x0(0x8)
	struct UBP_MissionComponent_C* Caller;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FS_TargetInformation K2Node_MakeStruct_S_TargetInformation;  // 0x18(0x48)

}; 
