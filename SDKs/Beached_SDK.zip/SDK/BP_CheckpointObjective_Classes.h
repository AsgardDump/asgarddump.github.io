#pragma once 
#include <BP_CheckpointObjective_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CheckpointObjective.BP_CheckpointObjective_C
// Size: 0x290(Inherited: 0x220) 
struct ABP_CheckpointObjective_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct FS_TargetInformation Target Information;  // 0x230(0x48)
	float Overlap Distance;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	struct TArray<struct UW_Marker_C*> Markers;  // 0x280(0x10)

	void UserConstructionScript(); // Function BP_CheckpointObjective.BP_CheckpointObjective_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_CheckpointObjective.BP_CheckpointObjective_C.ReceiveBeginPlay
	void Check Distance(); // Function BP_CheckpointObjective.BP_CheckpointObjective_C.Check Distance
	void Checkpoint Overlap(bool Overlaping?); // Function BP_CheckpointObjective.BP_CheckpointObjective_C.Checkpoint Overlap
	void Destroy Checkpoint(); // Function BP_CheckpointObjective.BP_CheckpointObjective_C.Destroy Checkpoint
	void ExecuteUbergraph_BP_CheckpointObjective(int32_t EntryPoint); // Function BP_CheckpointObjective.BP_CheckpointObjective_C.ExecuteUbergraph_BP_CheckpointObjective
}; 



