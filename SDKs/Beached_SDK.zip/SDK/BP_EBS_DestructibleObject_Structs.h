#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_DestructibleObject.BP_EBS_DestructibleObject_C.ExecuteUbergraph_BP_EBS_DestructibleObject
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_DestructibleObject
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x14(0xC)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x20(0x8)

}; 
