#pragma once 
#include "SDK.h" 
 
 
// Function BP_EnemyCamp.BP_EnemyCamp_C.ExecuteUbergraph_BP_EnemyCamp
// Size: 0x34A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EnemyCamp
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x10(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x24(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x2C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x30(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x34(0x4)
	int32_t Temp_int_Array_Index_Variable_5;  // 0x38(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x3C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x40(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x44(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x48(0x4)
	int32_t Temp_int_Array_Index_Variable_6;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct AController* K2Node_Event_Executor;  // 0x58(0x8)
	struct ABP_Spawner_C* CallFunc_Array_Get_Item;  // 0x60(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x68(0x4)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0x6C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x70(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x74(0x4)
	struct FS_Notification K2Node_MakeStruct_S_Notification;  // 0x78(0x20)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct AController* CallFunc_Array_Get_Item_2;  // 0xA0(0x8)
	float CallFunc_Array_Get_Item_3;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct UBP_Player_ExperienceComponent_C* CallFunc_Get_Leveling_Component_Leveling_Component;  // 0xB0(0x8)
	struct UBP_SkillTreeComponent_C* CallFunc_Get_Skill_Component_ReturnValue;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xCC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xD0(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0xD4(0x4)
	int32_t Temp_int_Array_Index_Variable_7;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0xE0(0x10)
	struct ABP_Spawner_C* CallFunc_Array_Get_Item_4;  // 0xF0(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xF8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x108(0x10)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_Is_Enemy_Alive_Is_Alive : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x120(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x128(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x130(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x138(0x4)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x13C(0x1)
	char pad_317[3];  // 0x13D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x140(0x8C)
	char pad_460[4];  // 0x1CC(0x4)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x1D0(0x8)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1D8(0x1)
	char pad_473[7];  // 0x1D9(0x7)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1E8(0x1)
	char pad_489[7];  // 0x1E9(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x1F0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x1F8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x200(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x208(0x4)
	char pad_524[4];  // 0x20C(0x4)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_2;  // 0x210(0x8)
	char pad_536_1 : 7;  // 0x218(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x218(0x1)
	char pad_537[7];  // 0x219(0x7)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue_2;  // 0x220(0x8)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x228(0x1)
	char pad_553[3];  // 0x229(0x3)
	int32_t Temp_int_Loop_Counter_Variable_6;  // 0x22C(0x4)
	struct ABP_Spawner_C* CallFunc_Array_Get_Item_5;  // 0x230(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x238(0x4)
	char pad_572_1 : 7;  // 0x23C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x23C(0x1)
	char pad_573_1 : 7;  // 0x23D(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x23D(0x1)
	char pad_574_1 : 7;  // 0x23E(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x23E(0x1)
	char pad_575[1];  // 0x23F(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0x240(0x4)
	char pad_580[4];  // 0x244(0x4)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x248(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x258(0x4)
	char pad_604_1 : 7;  // 0x25C(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x260(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x270(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x278(0x10)
	struct FS_Notification K2Node_MakeStruct_S_Notification_2;  // 0x288(0x20)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2A9(0x1)
	char pad_682[2];  // 0x2AA(0x2)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x2AC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x2B0(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x2B4(0x4)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x2B8(0x1)
	char pad_697[7];  // 0x2B9(0x7)
	struct TArray<struct ABP_Spawner_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x2C0(0x10)
	struct ABP_Spawner_C* CallFunc_Array_Get_Item_6;  // 0x2D0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_6;  // 0x2D8(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x2DC(0x4)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x2E0(0x1)
	char pad_737[3];  // 0x2E1(0x3)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x2E4(0x4)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x2E8(0x1)
	char pad_745_1 : 7;  // 0x2E9(0x1)
	bool CallFunc_K2_IsValidTimerHandle_ReturnValue : 1;  // 0x2E9(0x1)
	char pad_746[6];  // 0x2EA(0x6)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithInterface_OutActors;  // 0x2F0(0x10)
	struct AActor* CallFunc_Array_Get_Item_7;  // 0x300(0x8)
	float CallFunc_GetDistanceTo_ReturnValue_2;  // 0x308(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_7;  // 0x30C(0x4)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x310(0x1)
	char pad_785_1 : 7;  // 0x311(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0x311(0x1)
	char pad_786[2];  // 0x312(0x2)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x314(0x4)
	struct AActor* CallFunc_Array_Get_Item_8;  // 0x318(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_8;  // 0x320(0x4)
	char pad_804[4];  // 0x324(0x4)
	struct TScriptInterface<IBPI_Spawning_C> K2Node_DynamicCast_AsBPI_Spawning;  // 0x328(0x10)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x338(0x1)
	char pad_825_1 : 7;  // 0x339(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_6 : 1;  // 0x339(0x1)
	char pad_826_1 : 7;  // 0x33A(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x33A(0x1)
	char pad_827[1];  // 0x33B(0x1)
	int32_t Temp_int_Loop_Counter_Variable_7;  // 0x33C(0x4)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_7 : 1;  // 0x340(0x1)
	char pad_833[3];  // 0x341(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_7;  // 0x344(0x4)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x348(0x1)
	char pad_841_1 : 7;  // 0x349(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x349(0x1)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.BndEvt__Activation collision_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__Activation collision_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.BndEvt__Activation collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Activation collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x8C)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.Is Enemy Alive
// Size: 0x18(Inherited: 0x0) 
struct FIs Enemy Alive
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Is Alive : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct UBP_AI_DataComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.UserConstructionScript
// Size: 0x48(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FS_TargetInformation K2Node_MakeStruct_S_TargetInformation;  // 0x0(0x48)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.Get Interaction Data
// Size: 0x18(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)

}; 
// Function BP_EnemyCamp.BP_EnemyCamp_C.Local Can Overlap
// Size: 0x21(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x10(0x8)
	float CallFunc_GetSquaredDistanceTo_ReturnValue;  // 0x18(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x20(0x1)

}; 
