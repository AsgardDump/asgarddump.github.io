#pragma once 
#include <BP_EBS_Building_Wall_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Wall.BP_EBS_Building_Wall_C
// Size: 0x4E0(Inherited: 0x479) 
struct ABP_EBS_Building_Wall_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct USceneComponent* RoofSocket2;  // 0x480(0x8)
	struct USceneComponent* RoofSocket1;  // 0x488(0x8)
	struct USceneComponent* RoofSockets;  // 0x490(0x8)
	struct USceneComponent* TriangleCeilingSocket2;  // 0x498(0x8)
	struct USceneComponent* TriangleCeilingSocket1;  // 0x4A0(0x8)
	struct USceneComponent* TriangleCeilingSockets;  // 0x4A8(0x8)
	struct USceneComponent* CeilingSocket2;  // 0x4B0(0x8)
	struct USceneComponent* CeilingSocket1;  // 0x4B8(0x8)
	struct USceneComponent* CeilingSockets;  // 0x4C0(0x8)
	struct USceneComponent* WallSocket;  // 0x4C8(0x8)
	struct UBoxComponent* BuildCollision;  // 0x4D0(0x8)
	struct USceneComponent* BuildComponents;  // 0x4D8(0x8)

	void SetFloorNumberByTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_Wall.BP_EBS_Building_Wall_C.SetFloorNumberByTargetActor
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_Wall.BP_EBS_Building_Wall_C.GetSnapTransform
}; 



