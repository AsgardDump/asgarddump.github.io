#pragma once 
#include <AutomationController_Structs.h>
 
 
 
// Class AutomationController.AutomationControllerSettings
// Size: 0x48(Inherited: 0x28) 
struct UAutomationControllerSettings : public UObject
{
	struct TArray<struct FAutomatedTestGroup> Groups;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bSuppressLogErrors : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bSuppressLogWarnings : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool bTreatLogWarningsAsTestErrors : 1;  // 0x3A(0x1)
	char pad_59[1];  // 0x3B(0x1)
	float CheckTestIntervalSeconds;  // 0x3C(0x4)
	float GameInstanceLostTimerSeconds;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 



