#pragma once 
#include <BP_SmallCarpet_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SmallCarpet.BP_SmallCarpet_C
// Size: 0x228(Inherited: 0x220) 
struct ABP_SmallCarpet_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)

}; 



