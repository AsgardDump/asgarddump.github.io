#pragma once 
#include <BP_EBS_Building_CodeLock_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C
// Size: 0x510(Inherited: 0x4B8) 
struct ABP_EBS_Building_CodeLock_C : public ABP_EBS_Building_DoorLock_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4B8(0x8)
	struct FString Password;  // 0x4C0(0x10)
	int32_t MaxPasswordLength;  // 0x4D0(0x4)
	char pad_1236[4];  // 0x4D4(0x4)
	UUserWidget* CodeLockWidgetClass;  // 0x4D8(0x8)
	struct TArray<struct APlayerController*> ActivePlayers;  // 0x4E0(0x10)
	struct UUserWidget* CodeLockWidget;  // 0x4F0(0x8)
	struct USoundBase* ConfirmPasswordSound;  // 0x4F8(0x8)
	struct USoundBase* WrongPasswordSound;  // 0x500(0x8)
	char pad_1288_1 : 7;  // 0x508(0x1)
	bool IsHeld : 1;  // 0x508(0x1)
	char pad_1289[3];  // 0x509(0x3)
	float MaxHoldTime;  // 0x50C(0x4)

	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.GetFormatedVariables_BPI
	void GetInteractionText_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, struct FText& InteractionText); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.GetInteractionText_BPI
	void RemoveCodeLockWidget(); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.RemoveCodeLockWidget
	void CloseCodeLock(struct APlayerController* PlayerController); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.CloseCodeLock
	void UpdateCodeLockWidget(bool IsLocked, bool IsAuthorized, struct FString Password); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.UpdateCodeLockWidget
	void IsCanInteract_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.IsCanInteract_BPI
	void TryToCreateCodeLockWidget(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryToCreateCodeLockWidget
	void TryToOpenCodelock(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryToOpenCodelock
	void TryToSetPassword(struct FString Password, struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryToSetPassword
	void TryInteract_BPI(bool Released, struct FKey InteractionKey, struct APlayerController* PlayerController); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryInteract_BPI
	void ReceiveDestroyed(); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.ReceiveDestroyed
	void PlayWrongPasswordSound (Multicast)(); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.PlayWrongPasswordSound (Multicast)
	void PlayConfirmPasswordSound (Multicast)(); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.PlayConfirmPasswordSound (Multicast)
	void ExecuteUbergraph_BP_EBS_Building_CodeLock(int32_t EntryPoint); // Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.ExecuteUbergraph_BP_EBS_Building_CodeLock
}; 



