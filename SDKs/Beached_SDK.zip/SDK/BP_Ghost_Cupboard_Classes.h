#pragma once 
#include <BP_Ghost_Cupboard_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_Cupboard.BP_Ghost_Cupboard_C
// Size: 0x288(Inherited: 0x280) 
struct ABP_Ghost_Cupboard_C : public ABP_GhostActor_C
{
	struct UStaticMeshComponent* Sphere;  // 0x280(0x8)

	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_Cupboard.BP_Ghost_Cupboard_C.Custom Condition Pass
}; 



