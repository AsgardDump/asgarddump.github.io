#pragma once 
#include <BP_SmallWoodenHut_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SmallWoodenHut.BP_SmallWoodenHut_C
// Size: 0x230(Inherited: 0x220) 
struct ABP_SmallWoodenHut_C : public AActor
{
	struct UChildActorComponent* Door;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)

}; 



