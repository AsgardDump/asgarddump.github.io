#pragma once 
#include "SDK.h" 
 
 
// Function BP_Landmine.BP_Landmine_C.ReceivePointDamage
// Size: 0xE4(Inherited: 0xE8) 
struct FReceivePointDamage : public FReceivePointDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct UPrimitiveComponent* HitComponent;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	struct FVector ShotFromDirection;  // 0x38(0xC)
	struct AController* InstigatedBy;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)
	struct FHitResult HitInfo;  // 0x58(0x8C)

}; 
// Function BP_Landmine.BP_Landmine_C.ExecuteUbergraph_BP_Landmine
// Size: 0x204(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Landmine
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	float K2Node_Event_Damage;  // 0x14(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x18(0x8)
	struct FVector K2Node_Event_HitLocation;  // 0x20(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x2C(0xC)
	struct UPrimitiveComponent* K2Node_Event_HitComponent;  // 0x38(0x8)
	struct FName K2Node_Event_BoneName;  // 0x40(0x8)
	struct FVector K2Node_Event_ShotFromDirection;  // 0x48(0xC)
	char pad_84[4];  // 0x54(0x4)
	struct AController* K2Node_Event_InstigatedBy;  // 0x58(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x60(0x8)
	struct FHitResult K2Node_Event_HitInfo;  // 0x68(0x8C)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xF4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x100(0x30)
	struct UDT_Bullet_C* K2Node_DynamicCast_AsDT_Bullet;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x148(0x1)
	char pad_329[7];  // 0x149(0x7)
	struct ABP_Explosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x150(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x158(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x160(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x168(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x170(0x4)
	char pad_372_1 : 7;  // 0x174(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x174(0x1)
	char pad_373[3];  // 0x175(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x178(0x8C)

}; 
// Function BP_Landmine.BP_Landmine_C.BndEvt__BP_Landmine_Box_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__BP_Landmine_Box_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x8C)

}; 
