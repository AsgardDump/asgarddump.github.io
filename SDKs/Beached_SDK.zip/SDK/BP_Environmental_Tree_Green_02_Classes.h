#pragma once 
#include <BP_Environmental_Tree_Green_02_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Environmental_Tree_Green_02.BP_Environmental_Tree_Green_02_C
// Size: 0x2C1(Inherited: 0x2C1) 
struct ABP_Environmental_Tree_Green_02_C : public ABP_Environmental_C
{

}; 



