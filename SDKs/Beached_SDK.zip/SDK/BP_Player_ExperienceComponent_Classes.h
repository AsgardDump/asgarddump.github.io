#pragma once 
#include <BP_Player_ExperienceComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C
// Size: 0x109(Inherited: 0xB0) 
struct UBP_Player_ExperienceComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct UW_HUD_C* HUD;  // 0xB8(0x8)
	int32_t Level;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool Restart Points on Levelup : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	int32_t Maximum Experience Range;  // 0xC8(0x4)
	int32_t Total Experience Points;  // 0xCC(0x4)
	int32_t Maximum Level;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct TArray<struct FS_Level> Level Suffixes;  // 0xD8(0x10)
	struct FText Level Suffix;  // 0xE8(0x18)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool Enable Levelup Notifycation : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool Decrease Level : 1;  // 0x101(0x1)
	char pad_258[2];  // 0x102(0x2)
	int32_t Level Skipping;  // 0x104(0x4)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool Enable Debug Messages : 1;  // 0x108(0x1)

	struct UBP_PlayerComponent_C* Get Character Component(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Get Character Component
	void Debug Message(struct FString Message, struct FLinearColor TextColor, float Duration); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Debug Message
	void Get Level Information(int32_t Level, int32_t& Maximum Total XP, int32_t& Minimum Total XP, int32_t& Maximum Current XP, int32_t& Minimum Current XP, int32_t& Actual Current XP); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Get Level Information
	void Find Level Suffix(int32_t Level, struct FText& Suffix); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Find Level Suffix
	void On Experience Changed(int32_t XP, int32_t& Current XP, int32_t& Maximum XP, int32_t& Minimum XP, bool& Success); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.On Experience Changed
	void Switch Experience Level Mode(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Switch Experience Level Mode
	void Switch Decrease Level(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Switch Decrease Level
	void Reset Experience(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Reset Experience
	void CLIENT Update Experience Widget(int32_t Current Level, int32_t Actual Experience Points, int32_t Maximum Experience, int32_t Minimum Experience); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.CLIENT Update Experience Widget
	void Set Level Skipping(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Set Level Skipping
	void Update Values(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Update Values
	void CLIENT Add Notification(struct FS_Notification Notification); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.CLIENT Add Notification
	void Add Experience(int32_t Experience, bool Enable Notification, struct FS_Notification Notification); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.Add Experience
	void SERVER Initialize(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.SERVER Initialize
	void CLIENT Load Component(int32_t Current Level, int32_t Experience Points, int32_t Actual Experience Points, int32_t Maximum Experience, int32_t Minimum Experience); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.CLIENT Load Component
	void ReceiveBeginPlay(); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Player_ExperienceComponent(int32_t EntryPoint); // Function BP_Player_ExperienceComponent.BP_Player_ExperienceComponent_C.ExecuteUbergraph_BP_Player_ExperienceComponent
}; 



