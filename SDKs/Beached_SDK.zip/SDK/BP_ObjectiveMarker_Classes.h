#pragma once 
#include <BP_ObjectiveMarker_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ObjectiveMarker.BP_ObjectiveMarker_C
// Size: 0x298(Inherited: 0x290) 
struct ABP_ObjectiveMarker_C : public ABP_CheckpointObjective_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)

	void Checkpoint Overlap(bool Overlaping?); // Function BP_ObjectiveMarker.BP_ObjectiveMarker_C.Checkpoint Overlap
	void ExecuteUbergraph_BP_ObjectiveMarker(int32_t EntryPoint); // Function BP_ObjectiveMarker.BP_ObjectiveMarker_C.ExecuteUbergraph_BP_ObjectiveMarker
}; 



