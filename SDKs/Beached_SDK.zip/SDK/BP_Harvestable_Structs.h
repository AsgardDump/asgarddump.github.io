#pragma once 
#include "SDK.h" 
 
 
// Function BP_Harvestable.BP_Harvestable_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_Harvestable.BP_Harvestable_C.Get Interaction Data
// Size: 0xF8(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x18(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x58(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FText CallFunc_Format_ReturnValue;  // 0x70(0x18)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x90(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0xD0(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0xE0(0x18)

}; 
// Function BP_Harvestable.BP_Harvestable_C.ExecuteUbergraph_BP_Harvestable
// Size: 0x10A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Harvestable
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x18(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x30(0x30)
	struct FTransform Temp_struct_Variable;  // 0x60(0x30)
	ABP_Harvestable_C* CallFunc_GetObjectClass_ReturnValue;  // 0x90(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x98(0x8)
	struct ABP_Harvestable_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xA0(0x8)
	int32_t CallFunc_Array_LastIndex_ReturnValue_2;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct UBP_BuildingComponent_C* CallFunc_AddComponent_ReturnValue;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xB9(0x1)
	char pad_186[6];  // 0xBA(0x6)
	struct AController* K2Node_Event_Executor;  // 0xC0(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0xC8(0x8)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue_2;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool K2Node_Event_Toggle : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool K2Node_Event_Overlap : 1;  // 0xDA(0x1)
	char pad_219_1 : 7;  // 0xDB(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xDB(0x1)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	int32_t CallFunc_Array_LastIndex_ReturnValue_3;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0xE8(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xEC(0x4)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue_2;  // 0xF0(0x8)
	float CallFunc_FClamp_ReturnValue;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival_2;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x109(0x1)

}; 
// Function BP_Harvestable.BP_Harvestable_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_Harvestable.BP_Harvestable_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_Harvestable.BP_Harvestable_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Harvestable.BP_Harvestable_C.Load Stage
// Size: 0x19(Inherited: 0x0) 
struct FLoad Stage
{
	int32_t Stage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FS_HarvestableStages CallFunc_Array_Get_Item;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_Harvestable.BP_Harvestable_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_Harvestable.BP_Harvestable_C.Drop Items
// Size: 0x79(Inherited: 0x0) 
struct FDrop Items
{
	struct TArray<struct FS_DropItem> Array;  // 0x0(0x10)
	struct UBP_PlayerInventoryComponent_C* Inventory;  // 0x10(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	struct FS_DropItem CallFunc_Array_Get_Item;  // 0x24(0x14)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62[2];  // 0x3E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x44(0x4)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0x48(0x30)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Add_Item_Success : 1;  // 0x78(0x1)

}; 
