#pragma once 
#include <BP_EBS_Building_Roof_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Roof.BP_EBS_Building_Roof_C
// Size: 0x4A8(Inherited: 0x479) 
struct ABP_EBS_Building_Roof_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct USceneComponent* RoofSocket2;  // 0x480(0x8)
	struct USceneComponent* RoofSocket1;  // 0x488(0x8)
	struct USceneComponent* RoofSockets;  // 0x490(0x8)
	struct UBoxComponent* BuildCollision;  // 0x498(0x8)
	struct USceneComponent* BuildComponents;  // 0x4A0(0x8)

	void SetFloorNumberByTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_Roof.BP_EBS_Building_Roof_C.SetFloorNumberByTargetActor
	void CheckRotate(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_Roof.BP_EBS_Building_Roof_C.CheckRotate
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_Roof.BP_EBS_Building_Roof_C.GetSnapTransform
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_Roof.BP_EBS_Building_Roof_C.CheckSupport
}; 



