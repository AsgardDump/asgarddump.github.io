#pragma once 
#include <BP_Throwable_Molotov_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Throwable_Molotov.BP_Throwable_Molotov_C
// Size: 0x254(Inherited: 0x240) 
struct ABP_Throwable_Molotov_C : public ABP_Throwable_Object_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x240(0x8)
	struct UParticleSystemComponent* P_Sparks;  // 0x248(0x8)
	float Detonation Time;  // 0x250(0x4)

	void ReceiveBeginPlay(); // Function BP_Throwable_Molotov.BP_Throwable_Molotov_C.ReceiveBeginPlay
	void BndEvt__ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Throwable_Molotov.BP_Throwable_Molotov_C.BndEvt__ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void ExecuteUbergraph_BP_Throwable_Molotov(int32_t EntryPoint); // Function BP_Throwable_Molotov.BP_Throwable_Molotov_C.ExecuteUbergraph_BP_Throwable_Molotov
}; 



