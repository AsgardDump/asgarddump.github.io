#pragma once 
#include <BP_EBS_Building_FloorObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C
// Size: 0x4A8(Inherited: 0x479) 
struct ABP_EBS_Building_FloorObject_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct USceneComponent* SupportCheckers;  // 0x480(0x8)
	struct USceneComponent* BuildComponents;  // 0x488(0x8)
	struct UBoxComponent* SupportChecker;  // 0x490(0x8)
	char pad_1176_1 : 7;  // 0x498(0x1)
	bool PlacedOnFloor : 1;  // 0x498(0x1)
	char pad_1177[3];  // 0x499(0x3)
	struct FVector GridOffset;  // 0x49C(0xC)

	void CheckLandscape(struct TArray<struct AActor*>& Actors, bool& Result); // Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckLandscape
	void CheckFloor(struct TArray<struct AActor*>& Actors, bool& Result); // Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckFloor
	void GetGridOffsets(bool GridMode, struct FVector& GridOffset, float& Grid Props Distance, float& Grid Correct Offset); // Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.GetGridOffsets
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckSupport
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.GetSnapTransform
	void CheckSnap(struct AActor* TargetActor, bool& CanBeSnapped); // Function BP_EBS_Building_FloorObject.BP_EBS_Building_FloorObject_C.CheckSnap
}; 



