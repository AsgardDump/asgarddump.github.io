#pragma once 
#include "SDK.h" 
 
 
// Function BP_Garage.BP_Garage_C.BndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_Garage.BP_Garage_C.ExecuteUbergraph_BP_Garage
// Size: 0x108(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Garage
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x18(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x28(0x8C)
	char pad_180[4];  // 0xB4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0xB8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xC0(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xC8(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)
	struct TScriptInterface<IBPI_VehicleSystem_C> K2Node_DynamicCast_AsBPI_Vehicle_System;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_Add_Health_to_Vehicle_Success : 1;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xEA(0x1)
	char pad_235_1 : 7;  // 0xEB(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xEB(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xEC(0x10)
	char pad_252[4];  // 0xFC(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x100(0x8)

}; 
// Function BP_Garage.BP_Garage_C.BndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__BP_Garage_Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x8C)

}; 
