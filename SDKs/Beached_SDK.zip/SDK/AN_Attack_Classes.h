#pragma once 
#include <AN_Attack_Structs.h>
 
 
 
// BlueprintGeneratedClass AN_Attack.AN_Attack_C
// Size: 0x38(Inherited: 0x38) 
struct UAN_Attack_C : public UAnimNotify
{

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AN_Attack.AN_Attack_C.Received_Notify
}; 



