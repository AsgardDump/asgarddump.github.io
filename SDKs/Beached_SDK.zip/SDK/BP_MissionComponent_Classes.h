#pragma once 
#include <BP_MissionComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MissionComponent.BP_MissionComponent_C
// Size: 0x1F0(Inherited: 0xB0) 
struct UBP_MissionComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct TArray<struct AController*> Players Joined;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool Mission Completed : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool Is In Mission ? : 1;  // 0xC9(0x1)
	char pad_202[6];  // 0xCA(0x6)
	struct TArray<struct FS_Objective> Current Objectives;  // 0xD0(0x10)
	struct TArray<int32_t> Current Objectives Progress;  // 0xE0(0x10)
	struct TArray<struct FS_Objectives_Markers> Objective Markers;  // 0xF0(0x10)
	struct TArray<struct ABP_CheckpointObjective_C*> Objective Checkpoints;  // 0x100(0x10)
	struct FS_MissionDatabase Current Mission;  // 0x110(0x10)
	struct FS_Mission Current Mission Information;  // 0x120(0x70)
	int32_t Current Sequence;  // 0x190(0x4)
	char pad_404[4];  // 0x194(0x4)
	struct TArray<struct FS_MissionDatabase> Quest Log;  // 0x198(0x10)
	struct TArray<struct FS_MissionDatabase> Completed Quests;  // 0x1A8(0x10)
	struct UW_InGameQuestPanel_C* Quest Panel Widget;  // 0x1B8(0x8)
	struct UW_HUD_C* HUD;  // 0x1C0(0x8)
	int32_t Time;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct FTimerHandle Mission Timer;  // 0x1D0(0x8)
	struct ABP_Checkpoint_C* Checkpoint Reference;  // 0x1D8(0x8)
	struct UW_PauseMenu_C* Pause Menu;  // 0x1E0(0x8)
	struct AActor* Cached Dialogue Actor;  // 0x1E8(0x8)

	void Save Player Data(); // Function BP_MissionComponent.BP_MissionComponent_C.Save Player Data
	void Check Already Done Progression(); // Function BP_MissionComponent.BP_MissionComponent_C.Check Already Done Progression
	void Share Progression(struct FS_TargetInformation Target Information, char E_Objective_Type Objective Type); // Function BP_MissionComponent.BP_MissionComponent_C.Share Progression
	void Skill Points Reward(struct FS_Mission_Finished Finished); // Function BP_MissionComponent.BP_MissionComponent_C.Skill Points Reward
	void Add Custom Marker(struct FS_Marker Marker, struct AActor* Target Actor, struct TArray<struct UW_Marker_C*>& Marker Reference); // Function BP_MissionComponent.BP_MissionComponent_C.Add Custom Marker
	void Remove Marker(struct UW_Marker_C* Marker); // Function BP_MissionComponent.BP_MissionComponent_C.Remove Marker
	void Create Map Checkpoint(struct FVector2D Map Location, struct FVector& ImpactPoint, bool& Success); // Function BP_MissionComponent.BP_MissionComponent_C.Create Map Checkpoint
	void Mission Completed For All(bool& Success); // Function BP_MissionComponent.BP_MissionComponent_C.Mission Completed For All
	void Destroy Marker Reference(struct UW_Marker_C* Marker Reference); // Function BP_MissionComponent.BP_MissionComponent_C.Destroy Marker Reference
	bool Are All Sequences Completed ?(); // Function BP_MissionComponent.BP_MissionComponent_C.Are All Sequences Completed ?
	void Get Completed Objectives(int32_t& Objectives Completed); // Function BP_MissionComponent.BP_MissionComponent_C.Get Completed Objectives
	bool Are Objectives Completed ?(); // Function BP_MissionComponent.BP_MissionComponent_C.Are Objectives Completed ?
	void Update Progress(struct FS_TargetInformation Target Information, char E_Objective_Type Objective Type); // Function BP_MissionComponent.BP_MissionComponent_C.Update Progress
	void Reset Current Objectives Progress(); // Function BP_MissionComponent.BP_MissionComponent_C.Reset Current Objectives Progress
	void Reset Objective Markers(); // Function BP_MissionComponent.BP_MissionComponent_C.Reset Objective Markers
	void Get Objective Target Amount(struct FS_Objective Objective, int32_t& Amount); // Function BP_MissionComponent.BP_MissionComponent_C.Get Objective Target Amount
	void Find Target In Current Objectives(struct FS_TargetInformation Target Information, int32_t& Objective Index, struct FS_ObjectiveTarget& Objective Target, bool& Successful); // Function BP_MissionComponent.BP_MissionComponent_C.Find Target In Current Objectives
	void Add Marker(int32_t Objective Index, struct FS_ObjectiveTarget Objective Target, struct FS_TargetInformation Target Information, struct TArray<struct UW_Marker_C*>& Marker Reference); // Function BP_MissionComponent.BP_MissionComponent_C.Add Marker
	void Start Mission(struct UDataTable* DataTable, struct FName Quest ID); // Function BP_MissionComponent.BP_MissionComponent_C.Start Mission
	void Load Mission(struct FS_MissionDatabase Mission, int32_t Sequence, struct TArray<int32_t>& Objectives Progress, int32_t Time); // Function BP_MissionComponent.BP_MissionComponent_C.Load Mission
	void CLIENT Load Mission(struct FS_Mission Current Mission Information, struct FS_MissionDatabase Current Mission, int32_t Sequence, struct TArray<int32_t>& Objectives Progress); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Load Mission
	void Toggle Menu(int32_t Custom Index); // Function BP_MissionComponent.BP_MissionComponent_C.Toggle Menu
	void Load Players List(); // Function BP_MissionComponent.BP_MissionComponent_C.Load Players List
	void CLIENT Load Player List(struct APawn* Player); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Load Player List
	void Stop Mission(); // Function BP_MissionComponent.BP_MissionComponent_C.Stop Mission
	void CLIENT Stop Mission(); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Stop Mission
	void Add New Player(struct AController* Player); // Function BP_MissionComponent.BP_MissionComponent_C.Add New Player
	void Event On Joined(struct AController* Invited By); // Function BP_MissionComponent.BP_MissionComponent_C.Event On Joined
	void CLIENT Set Players Joined(struct TArray<struct AController*>& Players Joined); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Set Players Joined
	void On Player Left Quest(struct AController* Player); // Function BP_MissionComponent.BP_MissionComponent_C.On Player Left Quest
	void Join Player(struct APawn* Player, struct APawn* Invited By); // Function BP_MissionComponent.BP_MissionComponent_C.Join Player
	void Update Objective(struct TArray<int32_t>& Objectives Progress, int32_t Objective Index); // Function BP_MissionComponent.BP_MissionComponent_C.Update Objective
	void On Objective Completed(int32_t Objective Index); // Function BP_MissionComponent.BP_MissionComponent_C.On Objective Completed
	void Setup Objectives Checkpoint(); // Function BP_MissionComponent.BP_MissionComponent_C.Setup Objectives Checkpoint
	void Load Sequence(int32_t Sequence); // Function BP_MissionComponent.BP_MissionComponent_C.Load Sequence
	void CLIENT Update Sequence(int32_t Sequence, struct TArray<int32_t>& Objectives Progress); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Update Sequence
	void Receive Progress(struct FS_TargetInformation Target Information, char E_Objective_Type Objective Type, bool Add Progress To Joined Players); // Function BP_MissionComponent.BP_MissionComponent_C.Receive Progress
	void On Mission Completed(bool Successful); // Function BP_MissionComponent.BP_MissionComponent_C.On Mission Completed
	void Add Quest to Quest Log(struct FS_MissionDatabase Quest); // Function BP_MissionComponent.BP_MissionComponent_C.Add Quest to Quest Log
	void CLIENT Set Quest Log(struct TArray<struct FS_MissionDatabase>& Quest Log); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Set Quest Log
	void CLIENT Set Completed Quests(struct TArray<struct FS_MissionDatabase>& Completed Quests); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Set Completed Quests
	void Start Mission Timer(int32_t Mission Time); // Function BP_MissionComponent.BP_MissionComponent_C.Start Mission Timer
	void Update Mission Time(); // Function BP_MissionComponent.BP_MissionComponent_C.Update Mission Time
	void CLIENT Start Timer(int32_t Time); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Start Timer
	void CLIENT Update Widget Timer(int32_t Time); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Update Widget Timer
	void Stop Mission Timer(); // Function BP_MissionComponent.BP_MissionComponent_C.Stop Mission Timer
	void CLIENT Stop Timer(); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Stop Timer
	void SERVER Toggle Checkpoint Marker(struct FVector Hit Location, bool Success); // Function BP_MissionComponent.BP_MissionComponent_C.SERVER Toggle Checkpoint Marker
	void Toggle Checkpoint Marker(struct FVector2D Map Location); // Function BP_MissionComponent.BP_MissionComponent_C.Toggle Checkpoint Marker
	void Play Marker Sound(bool Valid); // Function BP_MissionComponent.BP_MissionComponent_C.Play Marker Sound
	void Zoom Map(float Val); // Function BP_MissionComponent.BP_MissionComponent_C.Zoom Map
	void ReceiveBeginPlay(); // Function BP_MissionComponent.BP_MissionComponent_C.ReceiveBeginPlay
	void CLIENT Add Notification(struct FS_Notification Notification); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Add Notification
	void Toggle Pause Menu(); // Function BP_MissionComponent.BP_MissionComponent_C.Toggle Pause Menu
	void Close Inventory Menu(); // Function BP_MissionComponent.BP_MissionComponent_C.Close Inventory Menu
	void CLIENT Mission Finished(bool Completed, struct FS_MissionDatabase Mission Data); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Mission Finished
	void Check Progress(); // Function BP_MissionComponent.BP_MissionComponent_C.Check Progress
	void CLIENT Start Mission(struct FS_MissionDatabase Mission, struct FS_Mission Current Mission Information); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Start Mission
	void Quit Mission(); // Function BP_MissionComponent.BP_MissionComponent_C.Quit Mission
	void SERVER Load Mission Data(); // Function BP_MissionComponent.BP_MissionComponent_C.SERVER Load Mission Data
	void CLIENT Open Dialogue(struct UDataTable*& Dialogues Datatable, struct FName Dialogue ID, struct AActor* Dialogue Actor); // Function BP_MissionComponent.BP_MissionComponent_C.CLIENT Open Dialogue
	void ExecuteUbergraph_BP_MissionComponent(int32_t EntryPoint); // Function BP_MissionComponent.BP_MissionComponent_C.ExecuteUbergraph_BP_MissionComponent
}; 



