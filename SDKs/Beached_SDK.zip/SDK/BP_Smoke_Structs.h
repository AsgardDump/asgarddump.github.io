#pragma once 
#include "SDK.h" 
 
 
// Function BP_Smoke.BP_Smoke_C.ExecuteUbergraph_BP_Smoke
// Size: 0x1E(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Smoke
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue_2;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x1D(0x1)

}; 
