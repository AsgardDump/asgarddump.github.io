#pragma once 
#include <BP_Holdable_MeeleWeapon_Harvestable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C
// Size: 0x329(Inherited: 0x31C) 
struct ABP_Holdable_MeeleWeapon_Harvestable_C : public ABP_Holdable_MeeleWeapon_C
{
	char pad_796[4];  // 0x31C(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x320(0x8)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool Is Shielding : 1;  // 0x328(0x1)

	void SpawnSoundAndParticle(struct FVector Location); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.SpawnSoundAndParticle
	void Can Mine(bool& Return); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.Can Mine
	void Apply Damage(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.Apply Damage
	void Primary Action(bool Pressed); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.Primary Action
	void SERVER Attack(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.SERVER Attack
	void MULTICAST Attacks(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.MULTICAST Attacks
	void Local Request Attack(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.Local Request Attack
	void SERVER Init Attacks(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.SERVER Init Attacks
	void Resets(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.Resets
	void Aiming Action(bool Toggle); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.Aiming Action
	void SERVER Set Shield(bool Is Shielding); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.SERVER Set Shield
	void On Shielding Hit(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.On Shielding Hit
	void CLIENT On Shield(bool Condition); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.CLIENT On Shield
	void Mutlicast Block Effects(); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.Mutlicast Block Effects
	void HitEffectsWood(struct FVector Location); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.HitEffectsWood
	void HitEffectsMetal(struct FVector Location); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.HitEffectsMetal
	void HitEffectsPlayer(struct FVector Location); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.HitEffectsPlayer
	void ExecuteUbergraph_BP_Holdable_MeeleWeapon_Harvestable(int32_t EntryPoint); // Function BP_Holdable_MeeleWeapon_Harvestable.BP_Holdable_MeeleWeapon_Harvestable_C.ExecuteUbergraph_BP_Holdable_MeeleWeapon_Harvestable
}; 



