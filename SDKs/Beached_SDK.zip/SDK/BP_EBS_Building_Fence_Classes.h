#pragma once 
#include <BP_EBS_Building_Fence_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Fence.BP_EBS_Building_Fence_C
// Size: 0x498(Inherited: 0x479) 
struct ABP_EBS_Building_Fence_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct UBoxComponent* CheckSupportCollision;  // 0x480(0x8)
	struct UBoxComponent* BuildCollision;  // 0x488(0x8)
	struct USceneComponent* BuildComponents;  // 0x490(0x8)

	void SetFloorNumberByTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_Fence.BP_EBS_Building_Fence_C.SetFloorNumberByTargetActor
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_Fence.BP_EBS_Building_Fence_C.GetSnapTransform
}; 



