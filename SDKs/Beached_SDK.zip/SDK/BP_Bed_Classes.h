#pragma once 
#include <BP_Bed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Bed.BP_Bed_C
// Size: 0x4B0(Inherited: 0x4A8) 
struct ABP_Bed_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)

	void Local Can Overlap(bool& Success); // Function BP_Bed.BP_Bed_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_Bed.BP_Bed_C.Get Interaction Data
	void Set New Respawn Point(struct AActor* Controller); // Function BP_Bed.BP_Bed_C.Set New Respawn Point
	void On Interacted(struct AController* Executor); // Function BP_Bed.BP_Bed_C.On Interacted
	void ReceiveBeginPlay(); // Function BP_Bed.BP_Bed_C.ReceiveBeginPlay
	void Toggle Selected(bool Toggle); // Function BP_Bed.BP_Bed_C.Toggle Selected
	void Local Overlap(bool Overlap); // Function BP_Bed.BP_Bed_C.Local Overlap
	void ExecuteUbergraph_BP_Bed(int32_t EntryPoint); // Function BP_Bed.BP_Bed_C.ExecuteUbergraph_BP_Bed
}; 



