#pragma once 
#include "SDK.h" 
 
 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.ExecuteUbergraph_BP_LargeWoodenBox
// Size: 0x229(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LargeWoodenBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct ABP_StorageStash_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct AController* K2Node_Event_Executor;  // 0x58(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_CustomEvent_Toggle : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x71(0x1)
	char pad_114[2];  // 0x72(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x74(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x78(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x88(0x10)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x98(0x8)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0xA0(0x30)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_Has_Any_Items_in_Inventory_Has : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct FS_InventoryItem CallFunc_Array_Get_Item;  // 0xD8(0x30)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem_2;  // 0x110(0x30)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x140(0x4)
	char pad_324_1 : 7;  // 0x144(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x144(0x1)
	char pad_325[3];  // 0x145(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x148(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x14C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x150(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x154(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x158(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x160(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x168(0xC)
	float CallFunc_BreakVector_X;  // 0x174(0x4)
	float CallFunc_BreakVector_Y;  // 0x178(0x4)
	float CallFunc_BreakVector_Z;  // 0x17C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x180(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x184(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x190(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x19C(0x8C)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x228(0x1)

}; 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.ChestBroken
// Size: 0x8(Inherited: 0x0) 
struct FChestBroken
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Toggle Chest
// Size: 0x1(Inherited: 0x0) 
struct FToggle Chest
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Get Interaction Data
// Size: 0x18(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)

}; 
