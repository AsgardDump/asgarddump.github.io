#pragma once 
#include <BP_Holdable_Throwable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_Throwable.BP_Holdable_Throwable_C
// Size: 0x370(Inherited: 0x30A) 
struct ABP_Holdable_Throwable_C : public ABP_Holdable_C
{
	char pad_778[6];  // 0x30A(0x6)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	ABP_Throwable_Object_C* Throwable Object Class;  // 0x318(0x8)
	struct UStaticMeshComponent* Projectile Hit Component;  // 0x320(0x8)
	struct USplineComponent* Projectile Spline Component;  // 0x328(0x8)
	struct TArray<struct USplineMeshComponent*> Projectile Spline Mesh Components;  // 0x330(0x10)
	struct TArray<char EObjectTypeQuery> Trace Collision Types;  // 0x340(0x10)
	float Throw Distance;  // 0x350(0x4)
	char pad_852[4];  // 0x354(0x4)
	struct UMaterialInterface* Hit Mesh Material;  // 0x358(0x8)
	struct UMaterialInterface* Prediction Mesh Material;  // 0x360(0x8)
	float Sim Frequency;  // 0x368(0x4)
	float Max Sim Time;  // 0x36C(0x4)

	struct FVector Get Throw Velocity(); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Get Throw Velocity
	struct FVector Get Start Position(); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Get Start Position
	void Clear All Components(); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Clear All Components
	void Do Predictable Path(); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Do Predictable Path
	void SERVER Throw Object(struct FVector Spawn Location, struct FVector Throw Velocity); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.SERVER Throw Object
	void MULTICAST Play Montage(); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.MULTICAST Play Montage
	void Aiming Action(bool Toggle); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Aiming Action
	void ReceiveTick(float DeltaSeconds); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.ReceiveTick
	void ReceiveDestroyed(); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.ReceiveDestroyed
	void Primary Action(bool Pressed); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Primary Action
	void ExecuteUbergraph_BP_Holdable_Throwable(int32_t EntryPoint); // Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.ExecuteUbergraph_BP_Holdable_Throwable
}; 



