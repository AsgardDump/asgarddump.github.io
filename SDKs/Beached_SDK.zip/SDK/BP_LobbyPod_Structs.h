#pragma once 
#include "SDK.h" 
 
 
// Function BP_LobbyPod.BP_LobbyPod_C.OnBlendOut_B08AD145445B84941A6F77BED20603E1
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_B08AD145445B84941A6F77BED20603E1
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.ExecuteUbergraph_BP_LobbyPod
// Size: 0x4D8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LobbyPod
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x4(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x1C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x34(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x3C(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x4C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x54(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x64(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x6C(0x10)
	struct FName Temp_name_Variable;  // 0x7C(0x8)
	char pad_132[4];  // 0x84(0x4)
	struct FString K2Node_CustomEvent_Player_Name_2;  // 0x88(0x10)
	struct FString K2Node_CustomEvent_Unique_ID_2;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_CustomEvent_Occupied : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0xB0(0x8)
	struct UW_LobbyInfo_C* K2Node_DynamicCast_AsW_Lobby_Info;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool K2Node_CustomEvent_Ready : 1;  // 0xC1(0x1)
	char pad_194[6];  // 0xC2(0x6)
	struct FString K2Node_CustomEvent_Player_Name;  // 0xC8(0x10)
	struct FString K2Node_CustomEvent_Unique_ID;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_CustomEvent_Is_Ready : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue_2;  // 0xF0(0x8)
	struct UW_LobbyInfo_C* K2Node_DynamicCast_AsW_Lobby_Info_2;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x100(0x1)
	char pad_257[3];  // 0x101(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x104(0x4)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_CustomEvent_Toggle_2 : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	struct FLinearColor K2Node_CustomEvent_Color;  // 0x10C(0x10)
	char pad_284[4];  // 0x11C(0x4)
	struct UAnimMontage* K2Node_CustomEvent_Emote;  // 0x120(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_TouchedComponent;  // 0x128(0x8)
	struct FKey K2Node_ComponentBoundEvent_ButtonPressed;  // 0x130(0x18)
	float CallFunc_BreakRotator_Roll;  // 0x148(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x14C(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x150(0x4)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x154(0x1)
	char pad_341[3];  // 0x155(0x3)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x158(0xC)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x164(0x1)
	char pad_357[3];  // 0x165(0x3)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x168(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0x174(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x178(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x17C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x180(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x18C(0x8C)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x218(0x8)
	struct UBP_LobbyComponent_C* CallFunc_Get_Lobby_Component_BP_LobbyComponent;  // 0x220(0x8)
	float K2Node_CustomEvent_Mouse_X;  // 0x228(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x22C(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x230(0x4)
	float CallFunc_BreakRotator_Roll_3;  // 0x234(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x238(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x23C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x240(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x244(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0x248(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x254(0x8C)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2E0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2E4(0x4)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_2 : 1;  // 0x2E8(0x1)
	char pad_745_1 : 7;  // 0x2E9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2E9(0x1)
	char pad_746[2];  // 0x2EA(0x2)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x2EC(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue_3;  // 0x2F0(0x8)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool K2Node_CustomEvent_Toggle : 1;  // 0x2F8(0x1)
	char pad_761[7];  // 0x2F9(0x7)
	struct UW_InvitePlusButton_C* K2Node_DynamicCast_AsW_Invite_Plus_Button;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x308(0x1)
	char pad_777[7];  // 0x309(0x7)
	struct FS_PlayerCustomization K2Node_CustomEvent_Customization_Data;  // 0x310(0x50)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x360(0x1)
	char pad_865[7];  // 0x361(0x7)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x368(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x370(0x8)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool CallFunc_IsAnyMontagePlaying_ReturnValue : 1;  // 0x378(0x1)
	char pad_889_1 : 7;  // 0x379(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x379(0x1)
	char pad_890[6];  // 0x37A(0x6)
	struct FS_PlayerSave K2Node_CustomEvent_Player_Data;  // 0x380(0xE0)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0x460(0x8)
	char pad_1128[8];  // 0x468(0x8)
	struct FS_HolsterData CallFunc_Array_Get_Item_2;  // 0x470(0x50)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4C0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x4C4(0x4)
	char pad_1224_1 : 7;  // 0x4C8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4C8(0x1)
	char pad_1225[3];  // 0x4C9(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x4CC(0x4)
	char pad_1232_1 : 7;  // 0x4D0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x4D0(0x1)
	char pad_1233[3];  // 0x4D1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x4D4(0x4)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.OnNotifyEnd_B08AD145445B84941A6F77BED20603E1
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_B08AD145445B84941A6F77BED20603E1
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Toggle Pod Light
// Size: 0x14(Inherited: 0x0) 
struct FToggle Pod Light
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FLinearColor Color;  // 0x4(0x10)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.BndEvt__Mouse Collision_K2Node_ComponentBoundEvent_3_ComponentOnClickedSignature__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Mouse Collision_K2Node_ComponentBoundEvent_3_ComponentOnClickedSignature__DelegateSignature
{
	struct UPrimitiveComponent* TouchedComponent;  // 0x0(0x8)
	struct FKey ButtonPressed;  // 0x8(0x18)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Update Turn Value
// Size: 0x4(Inherited: 0x0) 
struct FUpdate Turn Value
{
	float Mouse X;  // 0x0(0x4)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Load Player Data
// Size: 0xE0(Inherited: 0x0) 
struct FLoad Player Data
{
	struct FS_PlayerSave Player Data;  // 0x0(0xE0)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.OnNotifyBegin_B08AD145445B84941A6F77BED20603E1
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_B08AD145445B84941A6F77BED20603E1
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Load Pod
// Size: 0x21(Inherited: 0x0) 
struct FLoad Pod
{
	struct FString Player Name;  // 0x0(0x10)
	struct FString Unique ID;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Is Ready : 1;  // 0x20(0x1)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Toggle Dance
// Size: 0x8(Inherited: 0x0) 
struct FToggle Dance
{
	struct UAnimMontage* Emote;  // 0x0(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Apply Customization
// Size: 0x50(Inherited: 0x0) 
struct FApply Customization
{
	struct FS_PlayerCustomization Customization Data;  // 0x0(0x50)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Toggle Ready
// Size: 0x1(Inherited: 0x0) 
struct FToggle Ready
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Ready : 1;  // 0x0(0x1)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Occupie Pod
// Size: 0x1(Inherited: 0x0) 
struct FOccupie Pod
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Occupied : 1;  // 0x0(0x1)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Load Player Widget Information
// Size: 0x20(Inherited: 0x0) 
struct FLoad Player Widget Information
{
	struct FString Player Name;  // 0x0(0x10)
	struct FString Unique ID;  // 0x10(0x10)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.OnCompleted_B08AD145445B84941A6F77BED20603E1
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_B08AD145445B84941A6F77BED20603E1
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.OnInterrupted_B08AD145445B84941A6F77BED20603E1
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_B08AD145445B84941A6F77BED20603E1
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Apply Armor
// Size: 0x180(Inherited: 0x0) 
struct FApply Armor
{
	struct FS_PlayerArmor Armor;  // 0x0(0x28)
	struct USkeletalMesh* L Mesh;  // 0x28(0x8)
	struct USceneComponent* Temp_object_Variable;  // 0x30(0x8)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x38(0x10)
	struct USceneComponent* Temp_object_Variable_2;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x54(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x64(0x4)
	struct USceneComponent* Temp_object_Variable_3;  // 0x68(0x8)
	struct FName CallFunc_Array_Get_Item;  // 0x70(0x8)
	char pad_120[8];  // 0x78(0x8)
	struct FS_InventoryItemData CallFunc_GetDataTableRowFromName_OutRow;  // 0x80(0xE0)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x161(0x1)
	char pad_354_1 : 7;  // 0x162(0x1)
	bool K2Node_SwitchInteger_CmpSuccess_2 : 1;  // 0x162(0x1)
	char E_CustomizationItem CallFunc_Array_Get_Item_2;  // 0x163(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x164(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x168(0x4)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x16C(0x1)
	char pad_365[3];  // 0x16D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x170(0x4)
	char E_CustomizationItem Temp_byte_Variable;  // 0x174(0x1)
	char pad_373[3];  // 0x175(0x3)
	struct USceneComponent* K2Node_Select_Default;  // 0x178(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.UserConstructionScript
// Size: 0x18(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x0(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x8(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x10(0x8)

}; 
// Function BP_LobbyPod.BP_LobbyPod_C.Create Holster
// Size: 0x1F5(Inherited: 0x0) 
struct FCreate Holster
{
	struct FS_HolsterData Holster Data;  // 0x0(0x50)
	int32_t L Holster Index;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct USceneComponent* L Holster Reference;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x61(0x1)
	char pad_98[2];  // 0x62(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x64(0x4)
	char pad_104[8];  // 0x68(0x8)
	struct FTransform Temp_struct_Variable;  // 0x70(0x30)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult;  // 0xA0(0x8C)
	char pad_300[4];  // 0x12C(0x4)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x139(0x1)
	char pad_314[6];  // 0x13A(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x140(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x148(0x10)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x15C(0x4)
	struct USceneComponent* CallFunc_Create_Child_Actor_Component_Return;  // 0x160(0x8)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult_2;  // 0x168(0x8C)
	char pad_500_1 : 7;  // 0x1F4(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x1F4(0x1)

}; 
