#pragma once 
#include <BP_OnlineComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_OnlineComponent.BP_OnlineComponent_C
// Size: 0xB8(Inherited: 0xB0) 
struct UBP_OnlineComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)

	void Send Chat Message(struct APlayerController* Player, struct FText Message, bool& Return); // Function BP_OnlineComponent.BP_OnlineComponent_C.Send Chat Message
	void SERVER Send Chat Message(struct FString Name, struct FText Message, struct FLinearColor Message Color); // Function BP_OnlineComponent.BP_OnlineComponent_C.SERVER Send Chat Message
	void CLIENT Receive Chat Message(struct FString Sender Name, struct FText Message, struct FLinearColor Message Color); // Function BP_OnlineComponent.BP_OnlineComponent_C.CLIENT Receive Chat Message
	void ExecuteUbergraph_BP_OnlineComponent(int32_t EntryPoint); // Function BP_OnlineComponent.BP_OnlineComponent_C.ExecuteUbergraph_BP_OnlineComponent
}; 



