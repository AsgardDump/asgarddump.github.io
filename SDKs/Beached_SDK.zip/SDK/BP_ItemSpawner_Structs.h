#pragma once 
#include "SDK.h" 
 
 
// Function BP_ItemSpawner.BP_ItemSpawner_C.Get Random Item to Spawn
// Size: 0x408(Inherited: 0x0) 
struct FGet Random Item to Spawn
{
	struct FS_InventoryItem Item to Spawn;  // 0x0(0x30)
	struct FS_ItemSpawner L Selected Iterm;  // 0x30(0x14)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0x44(0x1)
	char pad_69[11];  // 0x45(0xB)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0x50(0xE0)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x130(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x134(0x4)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid_2 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data_2;  // 0x140(0xE0)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0x220(0x30)
	int32_t CallFunc_Clamp_ReturnValue_2;  // 0x250(0x4)
	char pad_596_1 : 7;  // 0x254(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem_2;  // 0x258(0x30)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x290(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x2A0(0x4)
	char pad_676_1 : 7;  // 0x2A4(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x2A4(0x1)
	char pad_677[3];  // 0x2A5(0x3)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue_2;  // 0x2A8(0x4)
	char pad_684[4];  // 0x2AC(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames_2;  // 0x2B0(0x10)
	struct FS_ItemSpawner CallFunc_GetDataTableRowFromName_OutRow;  // 0x2C0(0x14)
	char pad_724_1 : 7;  // 0x2D4(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x2D4(0x1)
	char pad_725[3];  // 0x2D5(0x3)
	int32_t CallFunc_Array_LastIndex_ReturnValue_2;  // 0x2D8(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue_3;  // 0x2DC(0x4)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid_3 : 1;  // 0x2E0(0x1)
	char pad_737[15];  // 0x2E1(0xF)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data_3;  // 0x2F0(0xE0)
	char pad_976_1 : 7;  // 0x3D0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3D0(0x1)
	char pad_977[3];  // 0x3D1(0x3)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue_4;  // 0x3D4(0x4)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem_3;  // 0x3D8(0x30)

}; 
// Function BP_ItemSpawner.BP_ItemSpawner_C.ExecuteUbergraph_BP_ItemSpawner
// Size: 0x99(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ItemSpawner
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct ABP_InventoryItem_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x48(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x50(0x10)
	struct FS_InventoryItem CallFunc_Get_Random_Item_to_Spawn_Item_to_Spawn;  // 0x60(0x30)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x98(0x1)

}; 
