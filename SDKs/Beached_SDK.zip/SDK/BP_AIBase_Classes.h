#pragma once 
#include <BP_AIBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AIBase.BP_AIBase_C
// Size: 0x500(Inherited: 0x4C0) 
struct ABP_AIBase_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UAIOSubjectComponent* AIOSubject;  // 0x4C8(0x8)
	struct UNavigationInvokerComponent* NavigationInvoker;  // 0x4D0(0x8)
	struct UWidgetComponent* Info;  // 0x4D8(0x8)
	struct UBP_TargetComponent_C* BP_TargetComponent;  // 0x4E0(0x8)
	struct UBP_AI_DataComponent_C* C_AI_DataComponent;  // 0x4E8(0x8)
	struct FName Unique ID;  // 0x4F0(0x8)
	struct AActor* Spawner Reference;  // 0x4F8(0x8)

	void Get Interaction Data(struct FText& Interaction Text); // Function BP_AIBase.BP_AIBase_C.Get Interaction Data
	void Local Can Overlap(bool& Success); // Function BP_AIBase.BP_AIBase_C.Local Can Overlap
	void UserConstructionScript(); // Function BP_AIBase.BP_AIBase_C.UserConstructionScript
	void Toggle Selected(bool Toggle); // Function BP_AIBase.BP_AIBase_C.Toggle Selected
	void On Interacted(struct AController* Executor); // Function BP_AIBase.BP_AIBase_C.On Interacted
	void Perform Attack(); // Function BP_AIBase.BP_AIBase_C.Perform Attack
	void On Target Updated(); // Function BP_AIBase.BP_AIBase_C.On Target Updated
	void ReceiveBeginPlay(); // Function BP_AIBase.BP_AIBase_C.ReceiveBeginPlay
	void MULTICAST On Dead(); // Function BP_AIBase.BP_AIBase_C.MULTICAST On Dead
	void ReceivePointDamage(float Damage, struct UDamageType* DamageType, struct FVector HitLocation, struct FVector HitNormal, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector ShotFromDirection, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FHitResult& HitInfo); // Function BP_AIBase.BP_AIBase_C.ReceivePointDamage
	void MULTICAST Play Montage(struct UAnimMontage* AnimMontage); // Function BP_AIBase.BP_AIBase_C.MULTICAST Play Montage
	void On Dead(); // Function BP_AIBase.BP_AIBase_C.On Dead
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_AIBase.BP_AIBase_C.ReceiveAnyDamage
	void Local Overlap(bool Overlap); // Function BP_AIBase.BP_AIBase_C.Local Overlap
	void ReceiveDestroyed(); // Function BP_AIBase.BP_AIBase_C.ReceiveDestroyed
	void ExecuteUbergraph_BP_AIBase(int32_t EntryPoint); // Function BP_AIBase.BP_AIBase_C.ExecuteUbergraph_BP_AIBase
}; 



