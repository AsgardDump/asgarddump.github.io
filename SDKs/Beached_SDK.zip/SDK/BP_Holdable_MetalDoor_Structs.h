#pragma once 
#include "SDK.h" 
 
 
// Function BP_Holdable_MetalDoor.BP_Holdable_MetalDoor_C.ExecuteUbergraph_BP_Holdable_MetalDoor
// Size: 0x84(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Holdable_MetalDoor
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool K2Node_Event_Pressed : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x48(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x50(0x8)
	struct UBP_EBS_BuildingComponent_C* CallFunc_AddComponent_ReturnValue;  // 0x58(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_HideBuildingMenu_Success : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_ShowBuildingMenu_Success : 1;  // 0x65(0x1)
	char pad_102[2];  // 0x66(0x2)
	struct FDataTableRowHandle K2Node_MakeStruct_DataTableRowHandle;  // 0x68(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x80(0x4)

}; 
// Function BP_Holdable_MetalDoor.BP_Holdable_MetalDoor_C.Aiming Action
// Size: 0x1(Inherited: 0x1) 
struct FAiming Action : public FAiming Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable_MetalDoor.BP_Holdable_MetalDoor_C.Primary Action
// Size: 0x1(Inherited: 0x1) 
struct FPrimary Action : public FPrimary Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Pressed : 1;  // 0x0(0x1)

}; 
