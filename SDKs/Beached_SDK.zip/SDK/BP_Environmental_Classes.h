#pragma once 
#include <BP_Environmental_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Environmental.BP_Environmental_C
// Size: 0x2C1(Inherited: 0x220) 
struct ABP_Environmental_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* Item Spawn location;  // 0x228(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float Health;  // 0x240(0x4)
	float Maximum Health;  // 0x244(0x4)
	struct TMap<UDamageType*, float> Damage Types Multiplier;  // 0x248(0x50)
	float Respawn Timeout;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	struct UStaticMesh* Destroyed Mesh;  // 0x2A0(0x8)
	struct UStaticMesh* Normal Mesh;  // 0x2A8(0x8)
	struct TArray<struct FS_DropItem> Mined Item ID;  // 0x2B0(0x10)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool Mined : 1;  // 0x2C0(0x1)

	void OnRep_Mined(); // Function BP_Environmental.BP_Environmental_C.OnRep_Mined
	void Drop Items(struct UBP_PlayerInventoryComponent_C* Inventory); // Function BP_Environmental.BP_Environmental_C.Drop Items
	void UserConstructionScript(); // Function BP_Environmental.BP_Environmental_C.UserConstructionScript
	void MULTICAST On Mined(); // Function BP_Environmental.BP_Environmental_C.MULTICAST On Mined
	void MULTICAST Respawn(); // Function BP_Environmental.BP_Environmental_C.MULTICAST Respawn
	void ReceivePointDamage(float Damage, struct UDamageType* DamageType, struct FVector HitLocation, struct FVector HitNormal, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector ShotFromDirection, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FHitResult& HitInfo); // Function BP_Environmental.BP_Environmental_C.ReceivePointDamage
	void ReceiveBeginPlay(); // Function BP_Environmental.BP_Environmental_C.ReceiveBeginPlay
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_Environmental.BP_Environmental_C.ReceiveAnyDamage
	void Multicast Spawn Sound(); // Function BP_Environmental.BP_Environmental_C.Multicast Spawn Sound
	void ExecuteUbergraph_BP_Environmental(int32_t EntryPoint); // Function BP_Environmental.BP_Environmental_C.ExecuteUbergraph_BP_Environmental
}; 



