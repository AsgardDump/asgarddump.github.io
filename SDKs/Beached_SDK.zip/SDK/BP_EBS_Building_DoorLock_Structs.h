#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.ExecuteUbergraph_BP_EBS_Building_DoorLock
// Size: 0x58(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_Building_DoorLock
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_Released : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FKey K2Node_Event_InteractionKey;  // 0x8(0x18)
	struct APlayerController* K2Node_Event_PlayerController_2;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_UnlockByPlayer_Success : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_LockByPlayer_Success : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_CheckAuthorizedPlayer_Result : 1;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)
	struct APlayerController* K2Node_Event_PlayerController;  // 0x30(0x8)
	struct FName K2Node_Event_NotifyName;  // 0x38(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x4C(0xC)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CompleteInteractionNotify_BPI
// Size: 0x10(Inherited: 0x0) 
struct FCompleteInteractionNotify_BPI
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FName NotifyName;  // 0x8(0x8)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.LoadData_BPI
// Size: 0xC5(Inherited: 0x90) 
struct FLoadData_BPI : public FLoadData_BPI
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Success : 1;  // 0x8(0x1)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x10(0x10)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game_2;  // 0x28(0x10)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool CallFunc_LoadData_BPI_Success : 1;  // 0x39(0x1)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_GetActorSaveData_BPI_Success : 1;  // 0x3A(0x1)
	struct FSTR_EBS_SaveData_Actor CallFunc_GetActorSaveData_BPI_SaveData;  // 0x40(0x50)
	char pad_269_1 : 7;  // 0x10D(0x1)
	bool CallFunc_GetFormatedVariableIntegerValue_Success : 1;  // 0x90(0x1)
	int32_t CallFunc_GetFormatedVariableIntegerValue_Value;  // 0x94(0x4)
	char pad_274_1 : 7;  // 0x112(0x1)
	bool CallFunc_GetFormatedVariableStringArray_Success : 1;  // 0x98(0x1)
	struct TArray<struct FString> CallFunc_GetFormatedVariableStringArray_Value;  // 0xA0(0x10)
	char pad_291_1 : 7;  // 0x123(0x1)
	bool CallFunc_GetSavedActor_BPI_Success : 1;  // 0xB0(0x1)
	struct AActor* CallFunc_GetSavedActor_BPI_Actor;  // 0xB8(0x8)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool CallFunc_CheckAndAttachToTarget_Success : 1;  // 0xC0(0x1)
	char pad_301_1 : 7;  // 0x12D(0x1)
	bool CallFunc_GetFormatedVariableBooleanValue_Success : 1;  // 0xC1(0x1)
	char pad_302_1 : 7;  // 0x12E(0x1)
	bool CallFunc_GetFormatedVariableBooleanValue_Value : 1;  // 0xC2(0x1)
	char pad_303_1 : 7;  // 0x12F(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xC3(0x1)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xC4(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckBuildStatus
// Size: 0x1B(Inherited: 0x60) 
struct FCheckBuildStatus : public FCheckBuildStatus
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CanBeBuilt : 1;  // 0x8(0x1)
	struct ABP_EBS_Building_Door_C* K2Node_DynamicCast_AsBP_EBS_Building_Door;  // 0x10(0x8)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.TryInteract_BPI
// Size: 0x28(Inherited: 0x0) 
struct FTryInteract_BPI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Released : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FKey InteractionKey;  // 0x8(0x18)
	struct APlayerController* PlayerController;  // 0x20(0x8)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckSnap
// Size: 0x19(Inherited: 0x3C) 
struct FCheckSnap : public FCheckSnap
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CanBeSnapped : 1;  // 0x8(0x1)
	struct ABP_EBS_Building_Door_C* K2Node_DynamicCast_AsBP_EBS_Building_Door;  // 0x10(0x8)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckAndAttachToTarget
// Size: 0x19(Inherited: 0x1A) 
struct FCheckAndAttachToTarget : public FCheckAndAttachToTarget
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool Success : 1;  // 0x8(0x1)
	struct ABP_EBS_Building_Door_C* K2Node_DynamicCast_AsBP_EBS_Building_Door;  // 0x10(0x8)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetSnapTransform
// Size: 0x90(Inherited: 0x110) 
struct FGetSnapTransform : public FGetSnapTransform
{
	struct AActor* TargetActor;  // 0x0(0x8)
	float InputRotation;  // 0x8(0x4)
	struct FVector HitLocation;  // 0xC(0xC)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool GridMode : 1;  // 0x18(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool SnapNear : 1;  // 0x19(0x1)
	struct FTransform ReturnTransform;  // 0x20(0x30)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x50(0x8)
	char pad_354_1 : 7;  // 0x162(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	struct FTransform CallFunc_GetSocketTransform_Transform;  // 0x60(0x30)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckSupport
// Size: 0x2(Inherited: 0x80) 
struct FCheckSupport : public FCheckSupport
{
	char pad_128_1 : 7;  // 0x80(0x1)
	bool HasSupport : 1;  // 0x0(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.LockByPlayer
// Size: 0x24(Inherited: 0x0) 
struct FLockByPlayer
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString CallFunc_GetPlayerID_PlayerID;  // 0x10(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.UnlockByPlayer
// Size: 0x26(Inherited: 0x0) 
struct FUnlockByPlayer
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString CallFunc_GetPlayerID_PlayerID;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x25(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.Unlock
// Size: 0x1(Inherited: 0x0) 
struct FUnlock
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.CheckAuthorizedPlayer
// Size: 0x21(Inherited: 0x0) 
struct FCheckAuthorizedPlayer
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Result : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString CallFunc_GetPlayerID_PlayerID;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.OnRep_IsLocked
// Size: 0x30(Inherited: 0x0) 
struct FOnRep_IsLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTexture* Temp_object_Variable;  // 0x8(0x8)
	struct UTexture* Temp_object_Variable_2;  // 0x10(0x8)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x18(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x20(0x8)
	struct UTexture* K2Node_Select_Default;  // 0x28(0x8)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetFormatedVariables_BPI
// Size: 0x60(Inherited: 0x10) 
struct FGetFormatedVariables_BPI : public FGetFormatedVariables_BPI
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct FString CallFunc_FormatStringArrayVariableToString_FormatedVariable;  // 0x10(0x10)
	struct FString CallFunc_FormatBooleanVariableToString_FormatedVariable;  // 0x20(0x10)
	struct TArray<struct FString> CallFunc_GetFormatedVariables_BPI_FormatedVariables;  // 0x30(0x10)
	struct FString CallFunc_FormatIntegerVariableToString_FormatedVariable;  // 0x40(0x10)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x50(0x10)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetInteractionText_BPI
// Size: 0x39(Inherited: 0x0) 
struct FGetInteractionText_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	struct FText InteractionText;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_CheckAuthorizedPlayer_Result : 1;  // 0x38(0x1)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.GetInteractionObjectName_BPI
// Size: 0x18(Inherited: 0x0) 
struct FGetInteractionObjectName_BPI
{
	struct FText Name;  // 0x0(0x18)

}; 
// Function BP_EBS_Building_DoorLock.BP_EBS_Building_DoorLock_C.IsCanInteract_BPI
// Size: 0x22(Inherited: 0x0) 
struct FIsCanInteract_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_CheckAuthorizedPlayer_Result : 1;  // 0x21(0x1)

}; 
