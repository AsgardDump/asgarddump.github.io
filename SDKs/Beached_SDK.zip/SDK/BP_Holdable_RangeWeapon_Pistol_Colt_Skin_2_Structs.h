#pragma once 
#include "SDK.h" 
 
 
// Function BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2.BP_Holdable_RangeWeapon_Pistol_Colt_Skin_1_C.ExecuteUbergraph_BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
