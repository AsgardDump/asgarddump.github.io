#pragma once 
#include <BP_EBS_InteractionNotify_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_InteractionNotify.BP_EBS_InteractionNotify_C
// Size: 0x38(Inherited: 0x30) 
struct UBP_EBS_InteractionNotify_C : public UAnimNotifyState
{
	struct FName InteractionNotifyName;  // 0x30(0x8)

	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function BP_EBS_InteractionNotify.BP_EBS_InteractionNotify_C.Received_NotifyBegin
}; 



