#pragma once 
#include <BP_Holdable_RangeWeapon_SMG_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_SMG.BP_Holdable_RangeWeapon_SMG_C
// Size: 0x49D(Inherited: 0x49D) 
struct ABP_Holdable_RangeWeapon_SMG_C : public ABP_Holdable_RangeWeapon_C
{

}; 



