#pragma once 
#include <BP_LobbyComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LobbyComponent.BP_LobbyComponent_C
// Size: 0x2D8(Inherited: 0xB0) 
struct UBP_LobbyComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	APlayerController* Lobby Controller;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool Is Ready : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct UW_LobbyMenu_C* HUD;  // 0xC8(0x8)
	struct ABP_LobbyPod_C* Current Overviewing Pod;  // 0xD0(0x8)
	struct USAV_Customization_C* Customization Save;  // 0xD8(0x8)
	struct FS_PlayerCustomization Player Customization Data;  // 0xE0(0x50)
	int32_t Actual Countdown Time;  // 0x130(0x4)
	char pad_308[4];  // 0x134(0x4)
	struct FString Desired Level;  // 0x138(0x10)
	struct FTimerHandle Host Countdown Timer Handle;  // 0x148(0x8)
	int32_t Host Countdown Time;  // 0x150(0x4)
	char pad_340[4];  // 0x154(0x4)
	struct FString Player Name;  // 0x158(0x10)
	struct TArray<struct APlayerController*> Players Joined To Load;  // 0x168(0x10)
	struct TArray<struct APlayerController*> Players To Load;  // 0x178(0x10)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool Loaded : 1;  // 0x188(0x1)
	char pad_393[7];  // 0x189(0x7)
	struct TArray<struct APlayerController*> Loaded Players;  // 0x190(0x10)
	struct USAV_Options_C* Video Settings Save;  // 0x1A0(0x8)
	struct TArray<struct UAnimMontage*> Emotes;  // 0x1A8(0x10)
	struct TArray<struct FS_CustomizationItem> Hair Item;  // 0x1B8(0x10)
	struct TArray<struct FS_CustomizationItem> Beard Item;  // 0x1C8(0x10)
	struct TArray<struct FS_CustomizationItem> Eyes Item;  // 0x1D8(0x10)
	struct TArray<struct FS_CustomizationItem> Eyebrows Item;  // 0x1E8(0x10)
	struct TArray<struct FS_CustomizationItem> Hair Color;  // 0x1F8(0x10)
	struct TArray<struct FS_CustomizationItem> Skin Color;  // 0x208(0x10)
	struct TArray<struct FS_CustomizationItem> Stubble Color;  // 0x218(0x10)
	struct FGameServerItem Session Join To;  // 0x228(0xB0)

	void Is Everybody Ready(bool& Return); // Function BP_LobbyComponent.BP_LobbyComponent_C.Is Everybody Ready
	void Get Player Data(struct TMap<struct FString, struct FS_PlayerSave>& Players Save); // Function BP_LobbyComponent.BP_LobbyComponent_C.Get Player Data
	void Set Customization Item(struct FS_CustomizationItem Customization Item, char E_CustomizationItem Item Type); // Function BP_LobbyComponent.BP_LobbyComponent_C.Set Customization Item
	void Check If Player Is Loaded(struct TArray<struct APlayerController*>& Players); // Function BP_LobbyComponent.BP_LobbyComponent_C.Check If Player Is Loaded
	void Check If Player Was Loaded(struct TArray<struct APlayerController*>& Players); // Function BP_LobbyComponent.BP_LobbyComponent_C.Check If Player Was Loaded
	void CountdownHost(); // Function BP_LobbyComponent.BP_LobbyComponent_C.CountdownHost
	void Find Main Pod(struct ABP_LobbyPod_C*& Player Pod); // Function BP_LobbyComponent.BP_LobbyComponent_C.Find Main Pod
	void Check Invalid Pod(struct TArray<struct FString>& Players, struct ABP_LobbyPod_C*& Invalid Pod); // Function BP_LobbyComponent.BP_LobbyComponent_C.Check Invalid Pod
	void Get Valid Players(struct APlayerController* Player, struct TArray<struct FString>& Players); // Function BP_LobbyComponent.BP_LobbyComponent_C.Get Valid Players
	void Find Player's Pod(struct FString Player ID, struct ABP_LobbyPod_C*& Array Element); // Function BP_LobbyComponent.BP_LobbyComponent_C.Find Player's Pod
	void OnFailure_018616344CBAC188784C74BEB9094E58(); // Function BP_LobbyComponent.BP_LobbyComponent_C.OnFailure_018616344CBAC188784C74BEB9094E58
	void OnSuccess_018616344CBAC188784C74BEB9094E58(); // Function BP_LobbyComponent.BP_LobbyComponent_C.OnSuccess_018616344CBAC188784C74BEB9094E58
	void SERVER Load Main Pod(); // Function BP_LobbyComponent.BP_LobbyComponent_C.SERVER Load Main Pod
	void Load Pods At Beginning(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Load Pods At Beginning
	void CLIENT Setup Main Pod(struct FString Player Name, struct FString Unique ID, struct FS_PlayerSave Player Data); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT Setup Main Pod
	void On Destroyed(); // Function BP_LobbyComponent.BP_LobbyComponent_C.On Destroyed
	void CLIENT Load Pod(struct FString Player Name, struct FString Unique ID, bool Is Ready, struct FS_PlayerCustomization Customization Data, struct FS_PlayerSave Player Data); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT Load Pod
	void New Player Joined Lobby(struct APlayerController* New Player); // Function BP_LobbyComponent.BP_LobbyComponent_C.New Player Joined Lobby
	void Notice Player Joined(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Notice Player Joined
	void Toggle Ready(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Toggle Ready
	void SERVER Toggle Ready(bool Is Ready); // Function BP_LobbyComponent.BP_LobbyComponent_C.SERVER Toggle Ready
	void CLIENT On Player Toggle Ready(bool Ready, struct FString Unique ID); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT On Player Toggle Ready
	void Host Game(struct FString Level, float Delay); // Function BP_LobbyComponent.BP_LobbyComponent_C.Host Game
	void On Player Disconnected(struct APlayerController* Player); // Function BP_LobbyComponent.BP_LobbyComponent_C.On Player Disconnected
	void CLIENT Check Invalid Pods(struct TArray<struct FString>& Invalid Pods); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT Check Invalid Pods
	void ReceiveBeginPlay(); // Function BP_LobbyComponent.BP_LobbyComponent_C.ReceiveBeginPlay
	void Bind On Destroyed(struct AActor* DestroyedActor); // Function BP_LobbyComponent.BP_LobbyComponent_C.Bind On Destroyed
	void Toggle Dance(struct UAnimMontage* Emote); // Function BP_LobbyComponent.BP_LobbyComponent_C.Toggle Dance
	void CLIENT Toggle Dance(struct FString Player ID, struct UAnimMontage* Emote); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT Toggle Dance
	void Enable Input Events(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Enable Input Events
	void Update Overviewing Pod(struct ABP_LobbyPod_C* Lobby Pod); // Function BP_LobbyComponent.BP_LobbyComponent_C.Update Overviewing Pod
	void Update Overviewing Pod Rotation(float Mouse X); // Function BP_LobbyComponent.BP_LobbyComponent_C.Update Overviewing Pod Rotation
	void CLIENT On Hosted (float Time); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT On Hosted 
	void Load Customization(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Load Customization
	void Disconnect(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Disconnect
	void Issue Kick Player(struct FString Unique ID); // Function BP_LobbyComponent.BP_LobbyComponent_C.Issue Kick Player
	void Update Customization(struct FS_CustomizationItem Customization Item, char E_CustomizationItem Item Type); // Function BP_LobbyComponent.BP_LobbyComponent_C.Update Customization
	void SERVER Set Customization Data(struct FS_PlayerCustomization Player Customization Data); // Function BP_LobbyComponent.BP_LobbyComponent_C.SERVER Set Customization Data
	void Save Customization Data(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Save Customization Data
	void SERVER Update Customization(struct FS_PlayerCustomization Customization Data); // Function BP_LobbyComponent.BP_LobbyComponent_C.SERVER Update Customization
	void CLIENT Update Customization(struct FString Player Unique ID, struct FS_PlayerCustomization Customization Data); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT Update Customization
	void Start Host Countdown(struct FString Level, int32_t Countdown Time); // Function BP_LobbyComponent.BP_LobbyComponent_C.Start Host Countdown
	void Stop Host Countdown(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Stop Host Countdown
	void CLIENT Update Countdown(int32_t Current Countdown Time); // Function BP_LobbyComponent.BP_LobbyComponent_C.CLIENT Update Countdown
	void Set Loaded(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Set Loaded
	void Load Options(); // Function BP_LobbyComponent.BP_LobbyComponent_C.Load Options
	void Load Video Setting(char E_Video_Settings Video Setting, int32_t Level); // Function BP_LobbyComponent.BP_LobbyComponent_C.Load Video Setting
	void Join Players to Existing Session(struct FGameServerItem Session Join To); // Function BP_LobbyComponent.BP_LobbyComponent_C.Join Players to Existing Session
	void Join to Session(struct FGameServerItem& Session to Join); // Function BP_LobbyComponent.BP_LobbyComponent_C.Join to Session
	void ExecuteUbergraph_BP_LobbyComponent(int32_t EntryPoint); // Function BP_LobbyComponent.BP_LobbyComponent_C.ExecuteUbergraph_BP_LobbyComponent
}; 



