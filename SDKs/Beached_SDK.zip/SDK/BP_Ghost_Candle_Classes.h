#pragma once 
#include <BP_Ghost_Candle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_Candle.BP_Ghost_Candle_C
// Size: 0x288(Inherited: 0x280) 
struct ABP_Ghost_Candle_C : public ABP_GhostActor_C
{
	struct UParticleSystemComponent* P_CandleFire;  // 0x280(0x8)

	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_Candle.BP_Ghost_Candle_C.Custom Condition Pass
}; 



