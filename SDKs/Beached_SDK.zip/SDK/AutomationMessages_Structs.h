#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AutomationMessages.AutomationWorkerScreenImage
// Size: 0x158(Inherited: 0x0) 
struct FAutomationWorkerScreenImage
{
	struct TArray<char> ScreenImage;  // 0x0(0x10)
	struct TArray<char> FrameTrace;  // 0x10(0x10)
	struct FString ScreenShotName;  // 0x20(0x10)
	struct FAutomationScreenshotMetadata MetaData;  // 0x30(0x128)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerPerformanceDataResponse
// Size: 0x18(Inherited: 0x0) 
struct FAutomationWorkerPerformanceDataResponse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSuccess : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ErrorMessage;  // 0x8(0x10)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerTestDataResponse
// Size: 0x18(Inherited: 0x0) 
struct FAutomationWorkerTestDataResponse
{
	struct FString JsonData;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsNew : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerPerformanceDataRequest
// Size: 0x40(Inherited: 0x0) 
struct FAutomationWorkerPerformanceDataRequest
{
	struct FString Platform;  // 0x0(0x10)
	struct FString Hardware;  // 0x10(0x10)
	struct FString TestName;  // 0x20(0x10)
	struct TArray<double> DataPoints;  // 0x30(0x10)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerTestDataRequest
// Size: 0x50(Inherited: 0x0) 
struct FAutomationWorkerTestDataRequest
{
	struct FString DataType;  // 0x0(0x10)
	struct FString DataPlatform;  // 0x10(0x10)
	struct FString DataTestName;  // 0x20(0x10)
	struct FString DataName;  // 0x30(0x10)
	struct FString JsonData;  // 0x40(0x10)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerNextNetworkCommandReply
// Size: 0x1(Inherited: 0x0) 
struct FAutomationWorkerNextNetworkCommandReply
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerImageComparisonResults
// Size: 0x38(Inherited: 0x0) 
struct FAutomationWorkerImageComparisonResults
{
	struct FGuid UniqueId;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bNew : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bSimilar : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	double MaxLocalDifference;  // 0x18(0x8)
	double GlobalDifference;  // 0x20(0x8)
	struct FString ErrorMessage;  // 0x28(0x10)

}; 
// ScriptStruct AutomationMessages.AutomationScreenshotMetadata
// Size: 0x128(Inherited: 0x0) 
struct FAutomationScreenshotMetadata
{
	struct FString ScreenShotName;  // 0x0(0x10)
	struct FString Context;  // 0x10(0x10)
	struct FString TestName;  // 0x20(0x10)
	struct FString Notes;  // 0x30(0x10)
	struct FGuid ID;  // 0x40(0x10)
	struct FString Commit;  // 0x50(0x10)
	int32_t Width;  // 0x60(0x4)
	int32_t Height;  // 0x64(0x4)
	struct FString RHI;  // 0x68(0x10)
	struct FString Platform;  // 0x78(0x10)
	struct FString FeatureLevel;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool bIsStereo : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FString Vendor;  // 0xA0(0x10)
	struct FString AdapterName;  // 0xB0(0x10)
	struct FString AdapterInternalDriverVersion;  // 0xC0(0x10)
	struct FString AdapterUserDriverVersion;  // 0xD0(0x10)
	struct FString UniqueDeviceId;  // 0xE0(0x10)
	float ResolutionQuality;  // 0xF0(0x4)
	int32_t ViewDistanceQuality;  // 0xF4(0x4)
	int32_t AntiAliasingQuality;  // 0xF8(0x4)
	int32_t ShadowQuality;  // 0xFC(0x4)
	int32_t PostProcessQuality;  // 0x100(0x4)
	int32_t TextureQuality;  // 0x104(0x4)
	int32_t EffectsQuality;  // 0x108(0x4)
	int32_t FoliageQuality;  // 0x10C(0x4)
	int32_t ShadingQuality;  // 0x110(0x4)
	char pad_276_1 : 7;  // 0x114(0x1)
	bool bHasComparisonRules : 1;  // 0x114(0x1)
	char ToleranceRed;  // 0x115(0x1)
	char ToleranceGreen;  // 0x116(0x1)
	char ToleranceBlue;  // 0x117(0x1)
	char ToleranceAlpha;  // 0x118(0x1)
	char ToleranceMinBrightness;  // 0x119(0x1)
	char ToleranceMaxBrightness;  // 0x11A(0x1)
	char pad_283[1];  // 0x11B(0x1)
	float MaximumLocalError;  // 0x11C(0x4)
	float MaximumGlobalError;  // 0x120(0x4)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool bIgnoreAntiAliasing : 1;  // 0x124(0x1)
	char pad_293_1 : 7;  // 0x125(0x1)
	bool bIgnoreColors : 1;  // 0x125(0x1)
	char pad_294[2];  // 0x126(0x2)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerRequestNextNetworkCommand
// Size: 0x4(Inherited: 0x0) 
struct FAutomationWorkerRequestNextNetworkCommand
{
	uint32_t ExecutionCount;  // 0x0(0x4)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerRunTestsReply
// Size: 0x38(Inherited: 0x0) 
struct FAutomationWorkerRunTestsReply
{
	struct FString TestName;  // 0x0(0x10)
	struct TArray<struct FAutomationExecutionEntry> Entries;  // 0x10(0x10)
	int32_t WarningTotal;  // 0x20(0x4)
	int32_t ErrorTotal;  // 0x24(0x4)
	float Duration;  // 0x28(0x4)
	uint32_t ExecutionCount;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Success : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerRunTests
// Size: 0x30(Inherited: 0x0) 
struct FAutomationWorkerRunTests
{
	uint32_t ExecutionCount;  // 0x0(0x4)
	int32_t RoleIndex;  // 0x4(0x4)
	struct FString TestName;  // 0x8(0x10)
	struct FString BeautifiedTestName;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bSendAnalytics : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerFindWorkersResponse
// Size: 0x98(Inherited: 0x0) 
struct FAutomationWorkerFindWorkersResponse
{
	struct FString DeviceName;  // 0x0(0x10)
	struct FString InstanceName;  // 0x10(0x10)
	struct FString Platform;  // 0x20(0x10)
	struct FString OSVersionName;  // 0x30(0x10)
	struct FString ModelName;  // 0x40(0x10)
	struct FString GPUName;  // 0x50(0x10)
	struct FString CPUModelName;  // 0x60(0x10)
	uint32_t RAMInGB;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct FString RenderModeName;  // 0x78(0x10)
	struct FGuid SessionID;  // 0x88(0x10)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerRequestTestsReplyComplete
// Size: 0x10(Inherited: 0x0) 
struct FAutomationWorkerRequestTestsReplyComplete
{
	struct TArray<struct FAutomationWorkerSingleTestReply> Tests;  // 0x0(0x10)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerSingleTestReply
// Size: 0x80(Inherited: 0x0) 
struct FAutomationWorkerSingleTestReply
{
	struct FString DisplayName;  // 0x0(0x10)
	struct FString FullTestPath;  // 0x10(0x10)
	struct FString TestName;  // 0x20(0x10)
	struct FString TestParameter;  // 0x30(0x10)
	struct FString SourceFile;  // 0x40(0x10)
	int32_t SourceFileLine;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FString AssetPath;  // 0x58(0x10)
	struct FString OpenCommand;  // 0x68(0x10)
	uint32_t TestFlags;  // 0x78(0x4)
	uint32_t NumParticipantsRequired;  // 0x7C(0x4)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerRequestTests
// Size: 0x8(Inherited: 0x0) 
struct FAutomationWorkerRequestTests
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool DeveloperDirectoryIncluded : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	uint32_t RequestedTestFlags;  // 0x4(0x4)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerPong
// Size: 0x1(Inherited: 0x0) 
struct FAutomationWorkerPong
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerStopTests
// Size: 0x1(Inherited: 0x0) 
struct FAutomationWorkerStopTests
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerResetTests
// Size: 0x1(Inherited: 0x0) 
struct FAutomationWorkerResetTests
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerPing
// Size: 0x1(Inherited: 0x0) 
struct FAutomationWorkerPing
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerWorkerOffline
// Size: 0x1(Inherited: 0x0) 
struct FAutomationWorkerWorkerOffline
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct AutomationMessages.AutomationWorkerFindWorkers
// Size: 0x38(Inherited: 0x0) 
struct FAutomationWorkerFindWorkers
{
	int32_t Changelist;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString GameName;  // 0x8(0x10)
	struct FString ProcessName;  // 0x18(0x10)
	struct FGuid SessionID;  // 0x28(0x10)

}; 
