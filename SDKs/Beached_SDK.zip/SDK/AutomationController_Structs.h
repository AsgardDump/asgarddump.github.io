#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AutomationController.AutomatedTestPassResults
// Size: 0x50(Inherited: 0x0) 
struct FAutomatedTestPassResults
{
	struct FString ClientDescriptor;  // 0x0(0x10)
	struct FDateTime ReportCreatedOn;  // 0x10(0x8)
	int32_t Succeeded;  // 0x18(0x4)
	int32_t SucceededWithWarnings;  // 0x1C(0x4)
	int32_t Failed;  // 0x20(0x4)
	int32_t NotRun;  // 0x24(0x4)
	float TotalDuration;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ComparisonExported : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FString ComparisonExportDirectory;  // 0x30(0x10)
	struct TArray<struct FAutomatedTestResult> Tests;  // 0x40(0x10)

}; 
// ScriptStruct AutomationController.AutomatedTestGroup
// Size: 0x20(Inherited: 0x0) 
struct FAutomatedTestGroup
{
	struct FString Name;  // 0x0(0x10)
	struct TArray<struct FAutomatedTestFilter> Filters;  // 0x10(0x10)

}; 
// ScriptStruct AutomationController.AutomatedTestResult
// Size: 0x60(Inherited: 0x0) 
struct FAutomatedTestResult
{
	char pad_0[16];  // 0x0(0x10)
	struct FString TestDisplayName;  // 0x10(0x10)
	struct FString FullTestPath;  // 0x20(0x10)
	uint8_t  State;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TArray<struct FAutomationExecutionEntry> Entries;  // 0x38(0x10)
	int32_t Warnings;  // 0x48(0x4)
	int32_t Errors;  // 0x4C(0x4)
	struct TArray<struct FAutomationArtifact> Artifacts;  // 0x50(0x10)

}; 
// ScriptStruct AutomationController.AutomationArtifact
// Size: 0xC8(Inherited: 0x0) 
struct FAutomationArtifact
{
	struct FGuid ID;  // 0x0(0x10)
	struct FString Name;  // 0x10(0x10)
	uint8_t  Type;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TMap<struct FString, struct FString> Files;  // 0x28(0x50)
	char pad_120[80];  // 0x78(0x50)

}; 
// ScriptStruct AutomationController.AutomatedTestFilter
// Size: 0x18(Inherited: 0x0) 
struct FAutomatedTestFilter
{
	struct FString Contains;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool MatchFromStart : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
