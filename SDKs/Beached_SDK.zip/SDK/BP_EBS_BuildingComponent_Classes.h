#pragma once 
#include <BP_EBS_BuildingComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C
// Size: 0x288(Inherited: 0xB0) 
struct UBP_EBS_BuildingComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct APlayerController* PlayerController;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool IsLocalPlayer : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	float InputBuildingRotationZ;  // 0xC4(0x4)
	float InputBuildingOffsetZ;  // 0xC8(0x4)
	char E_EBS_BuildingMode BuildingMode;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0xD0(0x8)
	char pad_216[8];  // 0xD8(0x8)
	struct FTransform BuildTransform;  // 0xE0(0x30)
	struct AActor* TargetActor;  // 0x110(0x8)
	struct ABP_EBS_Building_BaseObject_C* TargetBuildingObject;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CanBeBuilt : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	int32_t DisplayedFloor;  // 0x124(0x4)
	ABP_EBS_Building_BaseObject_C* LastBuildingObjectClass;  // 0x128(0x8)
	struct FDataTableRowHandle LastBuildingObjectHandle;  // 0x130(0x10)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool ManualInit : 1;  // 0x140(0x1)
	char pad_321_1 : 7;  // 0x141(0x1)
	bool TraceToMouseMode : 1;  // 0x141(0x1)
	char pad_322[2];  // 0x142(0x2)
	float TraceDistance;  // 0x144(0x4)
	float MinTraceDistance;  // 0x148(0x4)
	float MaxTraceDistance;  // 0x14C(0x4)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool TopDownViewMode : 1;  // 0x150(0x1)
	char pad_337[3];  // 0x151(0x3)
	float TopDownTraceDistance;  // 0x154(0x4)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool NearSnappingMode : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool AutoStartBuildMode : 1;  // 0x159(0x1)
	char pad_346[2];  // 0x15A(0x2)
	float DestructChunksLifeTime;  // 0x15C(0x4)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool GridMode : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool GridModeForProps : 1;  // 0x161(0x1)
	char pad_354[2];  // 0x162(0x2)
	float GridFoundationOffset;  // 0x164(0x4)
	float GridFoundationOffsetZ;  // 0x168(0x4)
	float GridPropsOffset;  // 0x16C(0x4)
	float GridCorrectOffset;  // 0x170(0x4)
	float BuildingRotationStepZ;  // 0x174(0x4)
	float BuildingOffsetStepZ;  // 0x178(0x4)
	int32_t FloorNumberLimit;  // 0x17C(0x4)
	struct UMaterialInterface* CanBuildMaterial;  // 0x180(0x8)
	struct UMaterialInterface* CannotBuildMaterial;  // 0x188(0x8)
	float MinBuildingOffsetZ;  // 0x190(0x4)
	float MaxBuildingOffsetZ;  // 0x194(0x4)
	UUserWidget* BuildingWidgetClass;  // 0x198(0x8)
	struct UUserWidget* BuildingWidget;  // 0x1A0(0x8)
	struct FMulticastInlineDelegate OnBuildingModeChanged;  // 0x1A8(0x10)
	struct FMulticastInlineDelegate OnBuildingMessageReceived;  // 0x1B8(0x10)
	struct FMulticastInlineDelegate OnBuildingInteractionCompleted;  // 0x1C8(0x10)
	struct FMulticastInlineDelegate OnBuildingCompleted;  // 0x1D8(0x10)
	struct FMulticastInlineDelegate OnRemovingCompleted;  // 0x1E8(0x10)
	struct FMulticastInlineDelegate OnDestructionCompleted;  // 0x1F8(0x10)
	struct FMulticastInlineDelegate OnRepairingCompleted;  // 0x208(0x10)
	struct FMulticastInlineDelegate OnUpgradingCompleted;  // 0x218(0x10)
	struct FMulticastInlineDelegate OnRotationCompleted;  // 0x228(0x10)
	struct FMulticastInlineDelegate OnTargetActorChanged;  // 0x238(0x10)
	struct FMulticastInlineDelegate OnTargetBuildingObjectChanged;  // 0x248(0x10)
	struct FDataTableRowHandle StartingBuildingList;  // 0x258(0x10)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool DebugMode : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct FText DebugInformation;  // 0x270(0x18)

	void OnRep_PlayerController(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnRep_PlayerController
	void GetDebugInformation(struct FText& DebugInformation); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetDebugInformation
	void ChangeBuildingWidget(UUserWidget* BuildingWidgetClass, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingWidget
	void HideMalletMenu(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.HideMalletMenu
	void ShowMalletMenu(struct AActor* TargetActor, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ShowMalletMenu
	void CheckInitReferences(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CheckInitReferences
	void ResetFloorActorsVisibility(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ResetFloorActorsVisibility
	void UpdateFloorActorsVisibility(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateFloorActorsVisibility
	void CheckFloorNumber(bool& Result); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CheckFloorNumber
	void ChangeDebugMode(bool DebugMode, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeDebugMode
	void PrintDebugInformation(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.PrintDebugInformation
	void GetInteractionStatus(char E_EBS_BuildingMode& BuildingMode, struct AActor*& TargetActor, struct ABP_EBS_Building_BaseObject_C*& TargetBuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetInteractionStatus
	void GetBuildingStatus(bool& CanBeBuild, struct ABP_EBS_Building_BaseObject_C*& BuildingObject, struct AActor*& TargetActor, struct ABP_EBS_Building_BaseObject_C*& TargetBuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetBuildingStatus
	void GetBuildingMode(char E_EBS_BuildingMode& BuildingMode); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetBuildingMode
	void SetTargetBuildingObject(struct AActor* TargetActor, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetTargetBuildingObject
	void SetTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetTargetActor
	void AutoInitComponent(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.AutoInitComponent
	void TryStartBuildObject(struct FDataTableRowHandle BuildingObjectHandle, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryStartBuildObject
	void SendBuildingMessage(char E_EBS_BuildingMode BuildingMode, bool InteractionResult, struct FText Message, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SendBuildingMessage
	void SetBuildingWidget(struct UUserWidget* BuildingWidget, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingWidget
	void UpdateBuildingList(struct FDataTableRowHandle BuildingListHandle, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildingList
	void HideBuildingMenu(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.HideBuildingMenu
	void ShowBuildingMenu(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ShowBuildingMenu
	void TryToCreateBuildingWidget(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryToCreateBuildingWidget
	void TryQuickInteraction(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickInteraction
	void GetCorrectBuildingRotation(struct FRotator& Rotation); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetCorrectBuildingRotation
	void GetCorrectHitLocation(struct FVector HitLocation, struct FVector& ReturnLocation); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetCorrectHitLocation
	void GetPropTransform(struct FVector HitLocation, struct FTransform& Transform); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetPropTransform
	void GetFoundationTransform(struct FVector HitLocation, struct FTransform& Transform); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetFoundationTransform
	void GetFloorIgnoringActors(int32_t TargetFloor, struct TArray<struct AActor*>& IgnoringActors); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetFloorIgnoringActors
	void UpdateBuildStatus(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildStatus
	void SetCanBeBuilt(bool CanBeBuilt, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetCanBeBuilt
	void SetBuildingObjectMaterials(bool CanBeBuilt, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingObjectMaterials
	void SetBuildingObjectTransform(struct FTransform NewTransform, bool& TransformChanged); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingObjectTransform
	void GetTraceHitResult(struct FHitResult& HitResult); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.GetTraceHitResult
	void UpdateTargetActor(struct FHitResult& HitResult, bool& Success, struct AActor*& TargetActor); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateTargetActor
	void UpdateBuildingPosition(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildingPosition
	void UpdateProcess(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateProcess
	void CompleteBuildingRequirements(struct FDataTableRowHandle BuildingObjectHandle, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CompleteBuildingRequirements
	void CheckBuildingRequirements(struct FDataTableRowHandle BuildingObjectHandle, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CheckBuildingRequirements
	void FinishBuild(ABP_EBS_Building_BaseObject_C* BuildingObjectClass, struct FDataTableRowHandle BuildingObjectHandle, struct FTransform BuildingTransform, struct AActor* TargetActor, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.FinishBuild
	void TryRotate(struct ABP_EBS_Building_BaseObject_C* TargetObject, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRotate
	void TryUpgrade(struct ABP_EBS_Building_BaseObject_C* TargetObject, bool& Success, struct FText& Message); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryUpgrade
	void TryRepair(struct ABP_EBS_Building_BaseObject_C* TargetObject, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRepair
	void TryDestruct(struct ABP_EBS_Building_BaseObject_C* TargetObject, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryDestruct
	void TryRemove(struct ABP_EBS_Building_BaseObject_C* TargetObject, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRemove
	void DestroyBuildingObject(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.DestroyBuildingObject
	void TryBuild(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryBuild
	void CancelBuild(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CancelBuild
	void StartBuildObject(struct FDataTableRowHandle BuildingObjectHandle, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.StartBuildObject
	void ChangeBuildingMode(char E_EBS_BuildingMode BuildingMode, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingMode
	void ChangeNearSnappingMode(bool NearSnappingMode, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeNearSnappingMode
	void ChangeGridMode(bool GridMode, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeGridMode
	void ChangeTopDownViewMode(bool TopDownViewMode, bool TraceToMouseMode, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeTopDownViewMode
	void ChangeDisplayedFloor(char E_EBS_ChangeVariableOperation Operation, int32_t Value, bool UpdateVisibility, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeDisplayedFloor
	void ChangeMaxTraceDistance(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeMaxTraceDistance
	void ChangeTraceDistance(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeTraceDistance
	void ChangeMaxBuildingOffsetZ(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeMaxBuildingOffsetZ
	void ChangeMinBuildingOffsetZ(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeMinBuildingOffsetZ
	void ChangeBuildingOffsetZ(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingOffsetZ
	void ChangeBuildingRotationZ(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingRotationZ
	void InitComponent(bool& Success); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.InitComponent
	void TryQuickBuild (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickBuild (Client)
	void FinishBuild (Server)(ABP_EBS_Building_BaseObject_C* BuildingObjectClass, struct FDataTableRowHandle BuildingObjectHandle, struct FTransform BuildingTransform, struct AActor* TargetActor); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.FinishBuild (Server)
	void TryQuickRemove (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickRemove (Client)
	void TryRemove (Server)(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRemove (Server)
	void TryQuickDestruct (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickDestruct (Client)
	void TryDestruct (Server)(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryDestruct (Server)
	void TryQuickUpgrade (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickUpgrade (Client)
	void TryUpgrade (Server)(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryUpgrade (Server)
	void TryQuickRotate (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickRotate (Client)
	void TryRotate (Server)(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRotate (Server)
	void TryQuickRepair (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryQuickRepair (Client)
	void TryRepair (Server)(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryRepair (Server)
	void ShowBuildingMenu (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ShowBuildingMenu (Client)
	void HideBuildingMenu (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.HideBuildingMenu (Client)
	void UpdateBuildingList (Client)(struct FDataTableRowHandle BuildingListHandle); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.UpdateBuildingList (Client)
	void SetBuildingMode (Client)(char E_EBS_BuildingMode BuildingMode); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SetBuildingMode (Client)
	void SendBuildingMessage (Client)(char E_EBS_BuildingMode BuildingMode, bool InteractionResult, struct FText Message); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.SendBuildingMessage (Client)
	void CancelBuild (Client)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.CancelBuild (Client)
	void TryCancelBuild (Server)(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryCancelBuild (Server)
	void StartBuildObject (Client)(struct FDataTableRowHandle BuildingObjectHandle); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.StartBuildObject (Client)
	void TryStartBuildObject (Server)(struct FDataTableRowHandle BuildingObjectHandle); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.TryStartBuildObject (Server)
	void ReceiveTick(float DeltaSeconds); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ReceiveBeginPlay
	void ChangeBuildingWidget (Client)(UUserWidget* BuildingWidgetClass); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ChangeBuildingWidget (Client)
	void ExecuteUbergraph_BP_EBS_BuildingComponent(int32_t EntryPoint); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.ExecuteUbergraph_BP_EBS_BuildingComponent
	void OnTargetBuildingObjectChanged__DelegateSignature(struct ABP_EBS_Building_BaseObject_C* TargetBuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnTargetBuildingObjectChanged__DelegateSignature
	void OnTargetActorChanged__DelegateSignature(struct AActor* TargetActor); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnTargetActorChanged__DelegateSignature
	void OnRotationCompleted__DelegateSignature(struct ABP_EBS_Building_BaseObject_C* BuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnRotationCompleted__DelegateSignature
	void OnUpgradingCompleted__DelegateSignature(struct ABP_EBS_Building_BaseObject_C* BuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnUpgradingCompleted__DelegateSignature
	void OnRepairingCompleted__DelegateSignature(struct ABP_EBS_Building_BaseObject_C* BuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnRepairingCompleted__DelegateSignature
	void OnDestructionCompleted__DelegateSignature(struct ABP_EBS_Building_BaseObject_C* BuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnDestructionCompleted__DelegateSignature
	void OnRemovingCompleted__DelegateSignature(struct ABP_EBS_Building_BaseObject_C* BuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnRemovingCompleted__DelegateSignature
	void OnBuildingCompleted__DelegateSignature(struct ABP_EBS_Building_BaseObject_C* BuildingObject, struct AActor* TargetActor); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingCompleted__DelegateSignature
	void OnBuildingInteractionCompleted__DelegateSignature(char E_EBS_BuildingMode BuildingMode, struct ABP_EBS_Building_BaseObject_C* BuildingObject); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingInteractionCompleted__DelegateSignature
	void OnBuildingMessageReceived__DelegateSignature(char E_EBS_BuildingMode BuildingMode, bool InteractionResult, struct FText Message); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingMessageReceived__DelegateSignature
	void OnBuildingModeChanged__DelegateSignature(char E_EBS_BuildingMode NewBuildingMode, char E_EBS_BuildingMode PrevBuildingMode); // Function BP_EBS_BuildingComponent.BP_EBS_BuildingComponent_C.OnBuildingModeChanged__DelegateSignature
}; 



