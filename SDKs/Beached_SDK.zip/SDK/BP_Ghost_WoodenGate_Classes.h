#pragma once 
#include <BP_Ghost_WoodenGate_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_WoodenGate.BP_Ghost_WoodenGate_C
// Size: 0x298(Inherited: 0x280) 
struct ABP_Ghost_WoodenGate_C : public ABP_GhostActor_C
{
	struct UStaticMeshComponent* GateFrame;  // 0x280(0x8)
	struct UStaticMeshComponent* StaticMesh2;  // 0x288(0x8)
	struct UStaticMeshComponent* StaticMesh1;  // 0x290(0x8)

	void Custom Rotation(struct FHitResult Hit, struct FRotator Current Rotation); // Function BP_Ghost_WoodenGate.BP_Ghost_WoodenGate_C.Custom Rotation
	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_WoodenGate.BP_Ghost_WoodenGate_C.Custom Condition Pass
}; 



