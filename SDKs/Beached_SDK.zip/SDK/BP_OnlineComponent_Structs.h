#pragma once 
#include "SDK.h" 
 
 
// Function BP_OnlineComponent.BP_OnlineComponent_C.ExecuteUbergraph_BP_OnlineComponent
// Size: 0x11C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_OnlineComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TScriptInterface<IBPI_OnlineSystem_C> K2Node_DynamicCast_AsBPI_Online_System;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UW_Chat_C* CallFunc_Get_Chat_Widget_Chat_Widget_Reference;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString K2Node_CustomEvent_Name;  // 0x40(0x10)
	struct FText K2Node_CustomEvent_Message_2;  // 0x50(0x18)
	struct FLinearColor K2Node_CustomEvent_Message_Color_2;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct TArray<struct APlayerController*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x80(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FString K2Node_CustomEvent_Sender_Name;  // 0x98(0x10)
	struct FText K2Node_CustomEvent_Message;  // 0xA8(0x18)
	struct FLinearColor K2Node_CustomEvent_Message_Color;  // 0xC0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct APlayerController* CallFunc_Array_Get_Item;  // 0xD8(0x8)
	struct UBP_OnlineComponent_C* CallFunc_Get_Online_Component_BP_OnlineComponent;  // 0xE0(0x8)
	struct FString Temp_string_Variable;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct FString K2Node_Select_Default;  // 0x100(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x110(0x4)
	char pad_276_1 : 7;  // 0x114(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x114(0x1)
	char pad_277[3];  // 0x115(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x118(0x4)

}; 
// Function BP_OnlineComponent.BP_OnlineComponent_C.Send Chat Message
// Size: 0x51(Inherited: 0x0) 
struct FSend Chat Message
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FText Message;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Return : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString CallFunc_Get_Player_Name_Name;  // 0x28(0x10)
	struct FText CallFunc_MakeLiteralText_ReturnValue;  // 0x38(0x18)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_NotEqual_TextText_ReturnValue : 1;  // 0x50(0x1)

}; 
// Function BP_OnlineComponent.BP_OnlineComponent_C.CLIENT Receive Chat Message
// Size: 0x38(Inherited: 0x0) 
struct FCLIENT Receive Chat Message
{
	struct FString Sender Name;  // 0x0(0x10)
	struct FText Message;  // 0x10(0x18)
	struct FLinearColor Message Color;  // 0x28(0x10)

}; 
// Function BP_OnlineComponent.BP_OnlineComponent_C.SERVER Send Chat Message
// Size: 0x38(Inherited: 0x0) 
struct FSERVER Send Chat Message
{
	struct FString Name;  // 0x0(0x10)
	struct FText Message;  // 0x10(0x18)
	struct FLinearColor Message Color;  // 0x28(0x10)

}; 
