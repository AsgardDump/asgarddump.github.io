#pragma once 
#include <BP_SatchelExplosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SatchelExplosion.BP_SatchelExplosion_C
// Size: 0x244(Inherited: 0x220) 
struct ABP_SatchelExplosion_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* Box;  // 0x228(0x8)
	struct URadialForceComponent* RadialForce;  // 0x230(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x238(0x8)
	float Base Damage;  // 0x240(0x4)

	void Apply Explosion Damage(); // Function BP_SatchelExplosion.BP_SatchelExplosion_C.Apply Explosion Damage
	void UserConstructionScript(); // Function BP_SatchelExplosion.BP_SatchelExplosion_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_SatchelExplosion.BP_SatchelExplosion_C.ReceiveBeginPlay
	void BndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature(struct UParticleSystemComponent* PSystem); // Function BP_SatchelExplosion.BP_SatchelExplosion_C.BndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature
	void ExecuteUbergraph_BP_SatchelExplosion(int32_t EntryPoint); // Function BP_SatchelExplosion.BP_SatchelExplosion_C.ExecuteUbergraph_BP_SatchelExplosion
}; 



