#pragma once 
#include <BP_Harvestable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Harvestable.BP_Harvestable_C
// Size: 0x271(Inherited: 0x220) 
struct ABP_Harvestable_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	int32_t Current Stage;  // 0x230(0x4)
	float Saved Time;  // 0x234(0x4)
	struct FS_HarvestableData Harvestable Data;  // 0x238(0x20)
	struct FText Name;  // 0x258(0x18)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool Force Destroy : 1;  // 0x270(0x1)

	void Local Can Overlap(bool& Success); // Function BP_Harvestable.BP_Harvestable_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_Harvestable.BP_Harvestable_C.Get Interaction Data
	void Drop Items(struct TArray<struct FS_DropItem>& Array, struct UBP_PlayerInventoryComponent_C* Inventory); // Function BP_Harvestable.BP_Harvestable_C.Drop Items
	void Load Stage(int32_t Stage); // Function BP_Harvestable.BP_Harvestable_C.Load Stage
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Harvestable.BP_Harvestable_C.ReceiveEndPlay
	void ReceiveBeginPlay(); // Function BP_Harvestable.BP_Harvestable_C.ReceiveBeginPlay
	void ReceiveDestroyed(); // Function BP_Harvestable.BP_Harvestable_C.ReceiveDestroyed
	void On Interacted(struct AController* Executor); // Function BP_Harvestable.BP_Harvestable_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_Harvestable.BP_Harvestable_C.Toggle Selected
	void Local Overlap(bool Overlap); // Function BP_Harvestable.BP_Harvestable_C.Local Overlap
	void ExecuteUbergraph_BP_Harvestable(int32_t EntryPoint); // Function BP_Harvestable.BP_Harvestable_C.ExecuteUbergraph_BP_Harvestable
}; 



