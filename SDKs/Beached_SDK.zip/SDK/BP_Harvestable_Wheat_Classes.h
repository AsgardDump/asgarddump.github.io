#pragma once 
#include <BP_Harvestable_Wheat_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Harvestable_Wheat.BP_Harvestable_Wheat_C
// Size: 0x280(Inherited: 0x271) 
struct ABP_Harvestable_Wheat_C : public ABP_Harvestable_C
{
	char pad_625[7];  // 0x271(0x7)
	struct USphereComponent* Sphere;  // 0x278(0x8)

}; 



