#pragma once 
#include "SDK.h" 
 
 
// Function BP_ObjectiveMarker.BP_ObjectiveMarker_C.ExecuteUbergraph_BP_ObjectiveMarker
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ObjectiveMarker
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	struct UW_Marker_C* CallFunc_Array_Get_Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_Overlaping_ : 1;  // 0x20(0x1)

}; 
// Function BP_ObjectiveMarker.BP_ObjectiveMarker_C.Checkpoint Overlap
// Size: 0x1(Inherited: 0x1) 
struct FCheckpoint Overlap : public FCheckpoint Overlap
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Overlaping? : 1;  // 0x0(0x1)

}; 
