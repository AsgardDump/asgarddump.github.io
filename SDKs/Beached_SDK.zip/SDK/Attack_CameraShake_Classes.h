#pragma once 
#include <Attack_CameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass Attack_CameraShake.Attack_CameraShake_C
// Size: 0x180(Inherited: 0x180) 
struct UAttack_CameraShake_C : public UMatineeCameraShake
{

}; 



