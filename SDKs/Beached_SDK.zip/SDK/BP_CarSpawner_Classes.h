#pragma once 
#include <BP_CarSpawner_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CarSpawner.BP_CarSpawner_C
// Size: 0x231(Inherited: 0x220) 
struct ABP_CarSpawner_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	char Car Limit;  // 0x230(0x1)

	void Request Respawn(); // Function BP_CarSpawner.BP_CarSpawner_C.Request Respawn
	void ExecuteUbergraph_BP_CarSpawner(int32_t EntryPoint); // Function BP_CarSpawner.BP_CarSpawner_C.ExecuteUbergraph_BP_CarSpawner
}; 



