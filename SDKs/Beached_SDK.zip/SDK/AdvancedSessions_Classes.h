#pragma once 
#include <AdvancedSessions_Structs.h>
 
 
 
// Class AdvancedSessions.AdvancedSessionsLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedSessionsLibrary : public UBlueprintFunctionLibrary
{

	void UniqueNetIdToString(struct FBPUniqueNetId& UniqueNetId, struct FString& String); // Function AdvancedSessions.AdvancedSessionsLibrary.UniqueNetIdToString
	void SetPlayerName(struct APlayerController* PlayerController, struct FString PlayerName); // Function AdvancedSessions.AdvancedSessionsLibrary.SetPlayerName
	struct FSessionsSearchSetting MakeLiteralSessionSearchProperty(struct FSessionPropertyKeyPair SessionSearchProperty, uint8_t  ComparisonOp); // Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionSearchProperty
	struct FSessionPropertyKeyPair MakeLiteralSessionPropertyString(struct FName Key, struct FString Value); // Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyString
	struct FSessionPropertyKeyPair MakeLiteralSessionPropertyInt(struct FName Key, int32_t Value); // Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyInt
	struct FSessionPropertyKeyPair MakeLiteralSessionPropertyFloat(struct FName Key, float Value); // Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyFloat
	struct FSessionPropertyKeyPair MakeLiteralSessionPropertyByte(struct FName Key, char Value); // Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyByte
	struct FSessionPropertyKeyPair MakeLiteralSessionPropertyBool(struct FName Key, bool Value); // Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyBool
	bool KickPlayer(struct UObject* WorldContextObject, struct APlayerController* PlayerToKick, struct FText KickReason); // Function AdvancedSessions.AdvancedSessionsLibrary.KickPlayer
	bool IsValidUniqueNetID(struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedSessionsLibrary.IsValidUniqueNetID
	bool IsValidSession(struct FBlueprintSessionResult& SessionResult); // Function AdvancedSessions.AdvancedSessionsLibrary.IsValidSession
	void IsPlayerInSession(struct UObject* WorldContextObject, struct FBPUniqueNetId& PlayerToCheck, bool& bIsInSession); // Function AdvancedSessions.AdvancedSessionsLibrary.IsPlayerInSession
	bool HasOnlineSubsystem(struct FName SubSystemName); // Function AdvancedSessions.AdvancedSessionsLibrary.HasOnlineSubsystem
	void GetUniqueNetIDFromPlayerState(struct APlayerState* PlayerState, struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedSessionsLibrary.GetUniqueNetIDFromPlayerState
	void GetUniqueNetID(struct APlayerController* PlayerController, struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedSessionsLibrary.GetUniqueNetID
	void GetUniqueBuildID(struct FBlueprintSessionResult SessionResult, int32_t& UniqueBuildId); // Function AdvancedSessions.AdvancedSessionsLibrary.GetUniqueBuildID
	void GetSessionState(struct UObject* WorldContextObject, uint8_t & SessionState); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionState
	void GetSessionSettings(struct UObject* WorldContextObject, int32_t& NumConnections, int32_t& NumPrivateConnections, bool& bIsLAN, bool& bIsDedicated, bool& bAllowInvites, bool& bAllowJoinInProgress, bool& bIsAnticheatEnabled, int32_t& BuildUniqueID, struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, uint8_t & Result); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionSettings
	void GetSessionPropertyString(struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct FName SettingName, uint8_t & SearchResult, struct FString& SettingValue); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyString
	struct FName GetSessionPropertyKey(struct FSessionPropertyKeyPair& SessionProperty); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyKey
	void GetSessionPropertyInt(struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct FName SettingName, uint8_t & SearchResult, int32_t& SettingValue); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyInt
	void GetSessionPropertyFloat(struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct FName SettingName, uint8_t & SearchResult, float& SettingValue); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyFloat
	void GetSessionPropertyByte(struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct FName SettingName, uint8_t & SearchResult, char& SettingValue); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyByte
	void GetSessionPropertyBool(struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct FName SettingName, uint8_t & SearchResult, bool& SettingValue); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyBool
	void GetSessionID_AsString(struct FBlueprintSessionResult& SessionResult, struct FString& SessionID); // Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionID_AsString
	void GetPlayerName(struct APlayerController* PlayerController, struct FString& PlayerName); // Function AdvancedSessions.AdvancedSessionsLibrary.GetPlayerName
	void GetNumberOfNetworkPlayers(struct UObject* WorldContextObject, int32_t& NumNetPlayers); // Function AdvancedSessions.AdvancedSessionsLibrary.GetNumberOfNetworkPlayers
	void GetNetPlayerIndex(struct APlayerController* PlayerController, int32_t& NetPlayerIndex); // Function AdvancedSessions.AdvancedSessionsLibrary.GetNetPlayerIndex
	void GetExtraSettings(struct FBlueprintSessionResult SessionResult, struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings); // Function AdvancedSessions.AdvancedSessionsLibrary.GetExtraSettings
	void GetCurrentUniqueBuildID(int32_t& UniqueBuildId); // Function AdvancedSessions.AdvancedSessionsLibrary.GetCurrentUniqueBuildID
	void GetCurrentSessionID_AsString(struct UObject* WorldContextObject, struct FString& SessionID); // Function AdvancedSessions.AdvancedSessionsLibrary.GetCurrentSessionID_AsString
	void FindSessionPropertyIndexByName(struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct FName SettingName, uint8_t & Result, int32_t& OutIndex); // Function AdvancedSessions.AdvancedSessionsLibrary.FindSessionPropertyIndexByName
	void FindSessionPropertyByName(struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct FName SettingsName, uint8_t & Result, struct FSessionPropertyKeyPair& OutProperty); // Function AdvancedSessions.AdvancedSessionsLibrary.FindSessionPropertyByName
	bool EqualEqual_UNetIDUnetID(struct FBPUniqueNetId& A, struct FBPUniqueNetId& B); // Function AdvancedSessions.AdvancedSessionsLibrary.EqualEqual_UNetIDUnetID
	bool BanPlayer(struct UObject* WorldContextObject, struct APlayerController* PlayerToBan, struct FText BanReason); // Function AdvancedSessions.AdvancedSessionsLibrary.BanPlayer
	void AddOrModifyExtraSettings(struct TArray<struct FSessionPropertyKeyPair>& SettingsArray, struct TArray<struct FSessionPropertyKeyPair>& NewOrChangedSettings, struct TArray<struct FSessionPropertyKeyPair>& ModifiedSettingsArray); // Function AdvancedSessions.AdvancedSessionsLibrary.AddOrModifyExtraSettings
}; 



// Class AdvancedSessions.AdvancedFriendsLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedFriendsLibrary : public UBlueprintFunctionLibrary
{

	void SendSessionInviteToFriends(struct APlayerController* PlayerController, struct TArray<struct FBPUniqueNetId>& Friends, uint8_t & Result); // Function AdvancedSessions.AdvancedFriendsLibrary.SendSessionInviteToFriends
	void SendSessionInviteToFriend(struct APlayerController* PlayerController, struct FBPUniqueNetId& FriendUniqueNetId, uint8_t & Result); // Function AdvancedSessions.AdvancedFriendsLibrary.SendSessionInviteToFriend
	void IsAFriend(struct APlayerController* PlayerController, struct FBPUniqueNetId UniqueNetId, bool& IsFriend); // Function AdvancedSessions.AdvancedFriendsLibrary.IsAFriend
	void GetStoredRecentPlayersList(struct FBPUniqueNetId UniqueNetId, struct TArray<struct FBPOnlineRecentPlayer>& PlayersList); // Function AdvancedSessions.AdvancedFriendsLibrary.GetStoredRecentPlayersList
	void GetStoredFriendsList(struct APlayerController* PlayerController, struct TArray<struct FBPFriendInfo>& FriendsList); // Function AdvancedSessions.AdvancedFriendsLibrary.GetStoredFriendsList
	void GetFriend(struct APlayerController* PlayerController, struct FBPUniqueNetId FriendUniqueNetId, struct FBPFriendInfo& Friend); // Function AdvancedSessions.AdvancedFriendsLibrary.GetFriend
}; 



// Class AdvancedSessions.AdvancedExternalUILibrary
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedExternalUILibrary : public UBlueprintFunctionLibrary
{

	void ShowWebURLUI(struct FString URLToShow, uint8_t & Result, struct TArray<struct FString>& AllowedDomains, bool bEmbedded, bool bShowBackground, bool bShowCloseButton, int32_t OffsetX, int32_t OffsetY, int32_t SizeX, int32_t SizeY); // Function AdvancedSessions.AdvancedExternalUILibrary.ShowWebURLUI
	void ShowProfileUI(struct FBPUniqueNetId PlayerViewingProfile, struct FBPUniqueNetId PlayerToViewProfileOf, uint8_t & Result); // Function AdvancedSessions.AdvancedExternalUILibrary.ShowProfileUI
	void ShowLeaderBoardUI(struct FString LeaderboardName, uint8_t & Result); // Function AdvancedSessions.AdvancedExternalUILibrary.ShowLeaderBoardUI
	void ShowInviteUI(struct APlayerController* PlayerController, uint8_t & Result); // Function AdvancedSessions.AdvancedExternalUILibrary.ShowInviteUI
	void ShowFriendsUI(struct APlayerController* PlayerController, uint8_t & Result); // Function AdvancedSessions.AdvancedExternalUILibrary.ShowFriendsUI
	void ShowAccountUpgradeUI(struct FBPUniqueNetId PlayerRequestingAccountUpgradeUI, uint8_t & Result); // Function AdvancedSessions.AdvancedExternalUILibrary.ShowAccountUpgradeUI
	void CloseWebURLUI(); // Function AdvancedSessions.AdvancedExternalUILibrary.CloseWebURLUI
}; 



// Class AdvancedSessions.GetRecentPlayersCallbackProxy
// Size: 0x90(Inherited: 0x30) 
struct UGetRecentPlayersCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[64];  // 0x50(0x40)

	struct UGetRecentPlayersCallbackProxy* GetAndStoreRecentPlayersList(struct UObject* WorldContextObject, struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.GetRecentPlayersCallbackProxy.GetAndStoreRecentPlayersList
}; 



// Class AdvancedSessions.AdvancedVoiceLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedVoiceLibrary : public UBlueprintFunctionLibrary
{

	bool UnRegisterRemoteTalker(struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedVoiceLibrary.UnRegisterRemoteTalker
	void UnRegisterLocalTalker(char LocalPlayerNum); // Function AdvancedSessions.AdvancedVoiceLibrary.UnRegisterLocalTalker
	void UnRegisterAllLocalTalkers(); // Function AdvancedSessions.AdvancedVoiceLibrary.UnRegisterAllLocalTalkers
	bool UnMuteRemoteTalker(char LocalUserNum, struct FBPUniqueNetId& UniqueNetId, bool bIsSystemWide); // Function AdvancedSessions.AdvancedVoiceLibrary.UnMuteRemoteTalker
	void StopNetworkedVoice(char LocalPlayerNum); // Function AdvancedSessions.AdvancedVoiceLibrary.StopNetworkedVoice
	void StartNetworkedVoice(char LocalPlayerNum); // Function AdvancedSessions.AdvancedVoiceLibrary.StartNetworkedVoice
	void RemoveAllRemoteTalkers(); // Function AdvancedSessions.AdvancedVoiceLibrary.RemoveAllRemoteTalkers
	bool RegisterRemoteTalker(struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedVoiceLibrary.RegisterRemoteTalker
	bool RegisterLocalTalker(char LocalPlayerNum); // Function AdvancedSessions.AdvancedVoiceLibrary.RegisterLocalTalker
	void RegisterAllLocalTalkers(); // Function AdvancedSessions.AdvancedVoiceLibrary.RegisterAllLocalTalkers
	bool MuteRemoteTalker(char LocalUserNum, struct FBPUniqueNetId& UniqueNetId, bool bIsSystemWide); // Function AdvancedSessions.AdvancedVoiceLibrary.MuteRemoteTalker
	bool IsRemotePlayerTalking(struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedVoiceLibrary.IsRemotePlayerTalking
	bool IsPlayerMuted(char LocalUserNumChecking, struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedVoiceLibrary.IsPlayerMuted
	bool IsLocalPlayerTalking(char LocalPlayerNum); // Function AdvancedSessions.AdvancedVoiceLibrary.IsLocalPlayerTalking
	void IsHeadsetPresent(bool& bHasHeadset, char LocalPlayerNum); // Function AdvancedSessions.AdvancedVoiceLibrary.IsHeadsetPresent
	void GetNumLocalTalkers(int32_t& NumLocalTalkers); // Function AdvancedSessions.AdvancedVoiceLibrary.GetNumLocalTalkers
}; 



// Class AdvancedSessions.AdvancedFriendsGameInstance
// Size: 0x228(Inherited: 0x1A8) 
struct UAdvancedFriendsGameInstance : public UGameInstance
{
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool bCallFriendInterfaceEventsOnPlayerControllers : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool bCallIdentityInterfaceEventsOnPlayerControllers : 1;  // 0x1A9(0x1)
	char pad_426_1 : 7;  // 0x1AA(0x1)
	bool bCallVoiceInterfaceEventsOnPlayerControllers : 1;  // 0x1AA(0x1)
	char pad_427_1 : 7;  // 0x1AB(0x1)
	bool bEnableTalkingStatusDelegate : 1;  // 0x1AB(0x1)
	char pad_428[124];  // 0x1AC(0x7C)

	void OnSessionInviteReceived(int32_t LocalPlayerNum, struct FBPUniqueNetId PersonInviting, struct FString AppID, struct FBlueprintSessionResult& SessionToJoin); // Function AdvancedSessions.AdvancedFriendsGameInstance.OnSessionInviteReceived
	void OnSessionInviteAccepted(int32_t LocalPlayerNum, struct FBPUniqueNetId PersonInvited, struct FBlueprintSessionResult& SessionToJoin); // Function AdvancedSessions.AdvancedFriendsGameInstance.OnSessionInviteAccepted
	void OnPlayerTalkingStateChanged(struct FBPUniqueNetId PlayerId, bool bIsTalking); // Function AdvancedSessions.AdvancedFriendsGameInstance.OnPlayerTalkingStateChanged
	void OnPlayerLoginStatusChanged(int32_t PlayerNum, uint8_t  PreviousStatus, uint8_t  NewStatus, struct FBPUniqueNetId NewPlayerUniqueNetID); // Function AdvancedSessions.AdvancedFriendsGameInstance.OnPlayerLoginStatusChanged
	void OnPlayerLoginChanged(int32_t PlayerNum); // Function AdvancedSessions.AdvancedFriendsGameInstance.OnPlayerLoginChanged
}; 



// Class AdvancedSessions.AdvancedFriendsInterface
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedFriendsInterface : public UInterface
{

	void OnSessionInviteReceived(struct FBPUniqueNetId PersonInviting, struct FBlueprintSessionResult& SearchResult); // Function AdvancedSessions.AdvancedFriendsInterface.OnSessionInviteReceived
	void OnSessionInviteAccepted(struct FBPUniqueNetId PersonInvited, struct FBlueprintSessionResult& SearchResult); // Function AdvancedSessions.AdvancedFriendsInterface.OnSessionInviteAccepted
	void OnPlayerVoiceStateChanged(struct FBPUniqueNetId PlayerId, bool bIsTalking); // Function AdvancedSessions.AdvancedFriendsInterface.OnPlayerVoiceStateChanged
	void OnPlayerLoginStatusChanged(uint8_t  PreviousStatus, uint8_t  NewStatus, struct FBPUniqueNetId PlayerUniqueNetID); // Function AdvancedSessions.AdvancedFriendsInterface.OnPlayerLoginStatusChanged
	void OnPlayerLoginChanged(int32_t PlayerNum); // Function AdvancedSessions.AdvancedFriendsInterface.OnPlayerLoginChanged
}; 



// Class AdvancedSessions.AdvancedGameSession
// Size: 0x288(Inherited: 0x238) 
struct AAdvancedGameSession : public AGameSession
{
	struct TMap<struct FUniqueNetIdRepl, struct FText> BanList;  // 0x238(0x50)

}; 



// Class AdvancedSessions.AdvancedIdentityLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedIdentityLibrary : public UBlueprintFunctionLibrary
{

	void SetUserAccountAttribute(struct FBPUserOnlineAccount& AccountInfo, struct FString AttributeName, struct FString NewAttributeValue, uint8_t & Result); // Function AdvancedSessions.AdvancedIdentityLibrary.SetUserAccountAttribute
	void GetUserID(struct FBPUserOnlineAccount& AccountInfo, struct FBPUniqueNetId& UniqueNetId); // Function AdvancedSessions.AdvancedIdentityLibrary.GetUserID
	void GetUserAccountRealName(struct FBPUserOnlineAccount& AccountInfo, struct FString& UserName); // Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountRealName
	void GetUserAccountDisplayName(struct FBPUserOnlineAccount& AccountInfo, struct FString& DisplayName); // Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountDisplayName
	void GetUserAccountAuthAttribute(struct FBPUserOnlineAccount& AccountInfo, struct FString AttributeName, struct FString& AuthAttribute, uint8_t & Result); // Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountAuthAttribute
	void GetUserAccountAttribute(struct FBPUserOnlineAccount& AccountInfo, struct FString AttributeName, struct FString& AttributeValue, uint8_t & Result); // Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountAttribute
	void GetUserAccountAccessToken(struct FBPUserOnlineAccount& AccountInfo, struct FString& AccessToken); // Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountAccessToken
	void GetUserAccount(struct FBPUniqueNetId& UniqueNetId, struct FBPUserOnlineAccount& AccountInfo, uint8_t & Result); // Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccount
	void GetPlayerNickname(struct FBPUniqueNetId& UniqueNetId, struct FString& PlayerNickname); // Function AdvancedSessions.AdvancedIdentityLibrary.GetPlayerNickname
	void GetPlayerAuthToken(struct APlayerController* PlayerController, struct FString& AuthToken, uint8_t & Result); // Function AdvancedSessions.AdvancedIdentityLibrary.GetPlayerAuthToken
	void GetLoginStatus(struct FBPUniqueNetId& UniqueNetId, uint8_t & LoginStatus, uint8_t & Result); // Function AdvancedSessions.AdvancedIdentityLibrary.GetLoginStatus
	void GetAllUserAccounts(struct TArray<struct FBPUserOnlineAccount>& AccountInfos, uint8_t & Result); // Function AdvancedSessions.AdvancedIdentityLibrary.GetAllUserAccounts
}; 



// Class AdvancedSessions.CancelFindSessionsCallbackProxy
// Size: 0x78(Inherited: 0x30) 
struct UCancelFindSessionsCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[40];  // 0x50(0x28)

	struct UCancelFindSessionsCallbackProxy* CancelFindSessions(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function AdvancedSessions.CancelFindSessionsCallbackProxy.CancelFindSessions
}; 



// Class AdvancedSessions.CreateSessionCallbackProxyAdvanced
// Size: 0xB8(Inherited: 0x30) 
struct UCreateSessionCallbackProxyAdvanced : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[104];  // 0x50(0x68)

	struct UCreateSessionCallbackProxyAdvanced* CreateAdvancedSession(struct UObject* WorldContextObject, struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, struct APlayerController* PlayerController, int32_t PublicConnections, int32_t PrivateConnections, bool bUseLAN, bool bAllowInvites, bool bIsDedicatedServer, bool bUsePresence, bool bAllowJoinViaPresence, bool bAllowJoinViaPresenceFriendsOnly, bool bAntiCheatProtected, bool bUsesStats, bool bShouldAdvertise); // Function AdvancedSessions.CreateSessionCallbackProxyAdvanced.CreateAdvancedSession
}; 



// Class AdvancedSessions.EndSessionCallbackProxy
// Size: 0x78(Inherited: 0x30) 
struct UEndSessionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[40];  // 0x50(0x28)

	struct UEndSessionCallbackProxy* EndSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function AdvancedSessions.EndSessionCallbackProxy.EndSession
}; 



// Class AdvancedSessions.FindFriendSessionCallbackProxy
// Size: 0x98(Inherited: 0x30) 
struct UFindFriendSessionCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[72];  // 0x50(0x48)

	struct UFindFriendSessionCallbackProxy* FindFriendSession(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBPUniqueNetId& FriendUniqueNetId); // Function AdvancedSessions.FindFriendSessionCallbackProxy.FindFriendSession
}; 



// Class AdvancedSessions.FindSessionsCallbackProxyAdvanced
// Size: 0xD0(Inherited: 0x30) 
struct UFindSessionsCallbackProxyAdvanced : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[128];  // 0x50(0x80)

	struct UFindSessionsCallbackProxyAdvanced* FindSessionsAdvanced(struct UObject* WorldContextObject, struct APlayerController* PlayerController, int32_t MaxResults, bool bUseLAN, uint8_t  ServerTypeToSearch, struct TArray<struct FSessionsSearchSetting>& Filters, bool bEmptyServersOnly, bool bNonEmptyServersOnly, bool bSecureServersOnly, int32_t MinSlotsAvailable); // Function AdvancedSessions.FindSessionsCallbackProxyAdvanced.FindSessionsAdvanced
	void FilterSessionResults(struct TArray<struct FBlueprintSessionResult>& SessionResults, struct TArray<struct FSessionsSearchSetting>& Filters, struct TArray<struct FBlueprintSessionResult>& FilteredResults); // Function AdvancedSessions.FindSessionsCallbackProxyAdvanced.FilterSessionResults
}; 



// Class AdvancedSessions.GetFriendsCallbackProxy
// Size: 0x70(Inherited: 0x30) 
struct UGetFriendsCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[32];  // 0x50(0x20)

	struct UGetFriendsCallbackProxy* GetAndStoreFriendsList(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function AdvancedSessions.GetFriendsCallbackProxy.GetAndStoreFriendsList
}; 



// Class AdvancedSessions.GetUserPrivilegeCallbackProxy
// Size: 0x80(Inherited: 0x30) 
struct UGetUserPrivilegeCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[48];  // 0x50(0x30)

	struct UGetUserPrivilegeCallbackProxy* GetUserPrivilege(struct UObject* WorldContextObject, uint8_t & PrivilegeToCheck, struct FBPUniqueNetId& PlayerUniqueNetID); // Function AdvancedSessions.GetUserPrivilegeCallbackProxy.GetUserPrivilege
}; 



// Class AdvancedSessions.LoginUserCallbackProxy
// Size: 0x98(Inherited: 0x30) 
struct ULoginUserCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[72];  // 0x50(0x48)

	struct ULoginUserCallbackProxy* LoginUser(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FString UserID, struct FString UserToken); // Function AdvancedSessions.LoginUserCallbackProxy.LoginUser
}; 



// Class AdvancedSessions.LogoutUserCallbackProxy
// Size: 0x78(Inherited: 0x30) 
struct ULogoutUserCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[40];  // 0x50(0x28)

	struct ULogoutUserCallbackProxy* LogoutUser(struct UObject* WorldContextObject, struct APlayerController* PlayerController); // Function AdvancedSessions.LogoutUserCallbackProxy.LogoutUser
}; 



// Class AdvancedSessions.SendFriendInviteCallbackProxy
// Size: 0x90(Inherited: 0x30) 
struct USendFriendInviteCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[64];  // 0x50(0x40)

	struct USendFriendInviteCallbackProxy* SendFriendInvite(struct UObject* WorldContextObject, struct APlayerController* PlayerController, struct FBPUniqueNetId& UniqueNetIDInvited); // Function AdvancedSessions.SendFriendInviteCallbackProxy.SendFriendInvite
}; 



// Class AdvancedSessions.UpdateSessionCallbackProxyAdvanced
// Size: 0x98(Inherited: 0x30) 
struct UUpdateSessionCallbackProxyAdvanced : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[72];  // 0x50(0x48)

	struct UUpdateSessionCallbackProxyAdvanced* UpdateSession(struct UObject* WorldContextObject, struct TArray<struct FSessionPropertyKeyPair>& ExtraSettings, int32_t PublicConnections, int32_t PrivateConnections, bool bUseLAN, bool bAllowInvites, bool bAllowJoinInProgress, bool bRefreshOnlineData, bool bIsDedicatedServer); // Function AdvancedSessions.UpdateSessionCallbackProxyAdvanced.UpdateSession
}; 



