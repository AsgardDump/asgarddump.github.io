#pragma once 
#include "SDK.h" 
 
 
// Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.SERVER Add Fuel
// Size: 0x8(Inherited: 0x0) 
struct FSERVER Add Fuel
{
	struct UObject* Target;  // 0x0(0x8)

}; 
// Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.ExecuteUbergraph_BP_Holdable_GasTank
// Size: 0x25E(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Holdable_GasTank
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x8(0x10)
	float Temp_float_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UW_GasTank_C* CallFunc_Create_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Is_Owner_Local_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x38(0x8)
	struct FRotator CallFunc_GetCameraRotation_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_GetCameraLocation_ReturnValue;  // 0x4C(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x68(0x8)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x70(0xC)
	char pad_124[4];  // 0x7C(0x4)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x80(0x8)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x88(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x94(0x8C)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x121(0x1)
	char pad_290_1 : 7;  // 0x122(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x122(0x1)
	char pad_291[1];  // 0x123(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x124(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x128(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x12C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x138(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x150(0xC)
	char pad_348[4];  // 0x15C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x160(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x168(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x170(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x178(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x180(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x184(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x188(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x194(0xC)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool Temp_bool_Variable : 1;  // 0x1A0(0x1)
	char pad_417_1 : 7;  // 0x1A1(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x1A1(0x1)
	char pad_418[6];  // 0x1A2(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x1A8(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_2;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_Is_Owner_Local_ReturnValue_2 : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool K2Node_Event_Pressed : 1;  // 0x1B9(0x1)
	char pad_442_1 : 7;  // 0x1BA(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1BA(0x1)
	char pad_443[1];  // 0x1BB(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1BC(0x4)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x1C0(0x1)
	char pad_449[3];  // 0x1C1(0x3)
	float K2Node_Select_Default;  // 0x1C4(0x4)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool CallFunc_Is_Owner_Local_ReturnValue_3 : 1;  // 0x1C8(0x1)
	char pad_457[7];  // 0x1C9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x1D0(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_3;  // 0x1D8(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x1E0(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_4;  // 0x1E8(0x8)
	struct TScriptInterface<IBPI_VehicleSystem_C> K2Node_DynamicCast_AsBPI_Vehicle_System;  // 0x1F0(0x10)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x200(0x1)
	char pad_513[3];  // 0x201(0x3)
	float CallFunc_Get_Fuel_Fuel_Amount;  // 0x204(0x4)
	float CallFunc_Get_Fuel_Max_Fuel;  // 0x208(0x4)
	char pad_524_1 : 7;  // 0x20C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x20C(0x1)
	char pad_525_1 : 7;  // 0x20D(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x20D(0x1)
	char pad_526[2];  // 0x20E(0x2)
	struct UObject* K2Node_CustomEvent_Target_2;  // 0x210(0x8)
	struct TScriptInterface<IBPI_VehicleSystem_C> K2Node_DynamicCast_AsBPI_Vehicle_System_2;  // 0x218(0x10)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x228(0x1)
	char pad_553[7];  // 0x229(0x7)
	struct UObject* K2Node_CustomEvent_Target;  // 0x230(0x8)
	float CallFunc_Remove_Fuel_Add_Durability;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)
	struct TScriptInterface<IBPI_VehicleSystem_C> K2Node_DynamicCast_AsBPI_Vehicle_System_3;  // 0x240(0x10)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x250(0x1)
	char pad_593[3];  // 0x251(0x3)
	float CallFunc_Add_Fuel_Take_Durability;  // 0x254(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x258(0x4)
	char pad_604_1 : 7;  // 0x25C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x25C(0x1)
	char pad_605_1 : 7;  // 0x25D(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_4 : 1;  // 0x25D(0x1)

}; 
// Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.SERVER Remove Fuel
// Size: 0x8(Inherited: 0x0) 
struct FSERVER Remove Fuel
{
	struct UObject* Target;  // 0x0(0x8)

}; 
// Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.Aiming Action
// Size: 0x1(Inherited: 0x1) 
struct FAiming Action : public FAiming Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.Primary Action
// Size: 0x1(Inherited: 0x1) 
struct FPrimary Action : public FPrimary Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Pressed : 1;  // 0x0(0x1)

}; 
