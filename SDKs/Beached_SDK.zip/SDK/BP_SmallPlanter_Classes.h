#pragma once 
#include <BP_SmallPlanter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SmallPlanter.BP_SmallPlanter_C
// Size: 0x228(Inherited: 0x220) 
struct ABP_SmallPlanter_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)

}; 



