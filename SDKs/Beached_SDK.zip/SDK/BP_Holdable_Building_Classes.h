#pragma once 
#include <BP_Holdable_Building_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_Building.BP_Holdable_Building_C
// Size: 0x440(Inherited: 0x30A) 
struct ABP_Holdable_Building_C : public ABP_Holdable_C
{
	char pad_778[6];  // 0x30A(0x6)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct FHitResult Last Out Hit;  // 0x318(0x8C)
	char pad_932[12];  // 0x3A4(0xC)
	struct FS_Building Building Data;  // 0x3B0(0x50)
	struct ABP_GhostActor_C* Ghost Actor;  // 0x400(0x8)
	struct FRotator Current Rotation;  // 0x408(0xC)
	int32_t Current Rotation Index;  // 0x414(0x4)
	float Build Distance;  // 0x418(0x4)
	char pad_1052[4];  // 0x41C(0x4)
	struct ABP_Cupboard_C* Last Overlap Cupboard;  // 0x420(0x8)
	struct TArray<char EObjectTypeQuery> Object Types;  // 0x428(0x10)
	struct ABP_Cupboard_C* Actors to Ignore;  // 0x438(0x8)

	void Set Cupboard Overlap Color(struct ABP_Cupboard_C* Cupboard); // Function BP_Holdable_Building.BP_Holdable_Building_C.Set Cupboard Overlap Color
	void Spawn Building(struct FTransform Transform, struct AActor* Place On Actor, struct ABP_Cupboard_C* Cupboard, struct AActor*& Spawned Building); // Function BP_Holdable_Building.BP_Holdable_Building_C.Spawn Building
	void Do Build Check(bool& Return, struct ABP_Cupboard_C*& Cupboard); // Function BP_Holdable_Building.BP_Holdable_Building_C.Do Build Check
	void Do Camera Trace(bool& Hit, struct FVector& ImpactPoint); // Function BP_Holdable_Building.BP_Holdable_Building_C.Do Camera Trace
	void ReceiveTick(float DeltaSeconds); // Function BP_Holdable_Building.BP_Holdable_Building_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_Holdable_Building.BP_Holdable_Building_C.ReceiveBeginPlay
	void Rotate Actor(bool Up); // Function BP_Holdable_Building.BP_Holdable_Building_C.Rotate Actor
	void Force Tick(); // Function BP_Holdable_Building.BP_Holdable_Building_C.Force Tick
	void Primary Action(bool Pressed); // Function BP_Holdable_Building.BP_Holdable_Building_C.Primary Action
	void SERVER Build(struct FTransform Transform, struct AActor* Place On Actor, struct ABP_Cupboard_C* Cupboard); // Function BP_Holdable_Building.BP_Holdable_Building_C.SERVER Build
	void ReceiveDestroyed(); // Function BP_Holdable_Building.BP_Holdable_Building_C.ReceiveDestroyed
	void ExecuteUbergraph_BP_Holdable_Building(int32_t EntryPoint); // Function BP_Holdable_Building.BP_Holdable_Building_C.ExecuteUbergraph_BP_Holdable_Building
}; 



