#pragma once 
#include <BP_MultiplayerDynamicWeatherManager_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C
// Size: 0x310(Inherited: 0x220) 
struct ABP_MultiplayerDynamicWeatherManager_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Night Sound;  // 0x228(0x8)
	struct UAudioComponent* Day Sound;  // 0x230(0x8)
	struct UBillboardComponent* Billboard;  // 0x238(0x8)
	struct USceneComponent* Scene;  // 0x240(0x8)
	float Rain_Smooth_RainPhase_81DE29134BA82A98DC8639B973004B9C;  // 0x248(0x4)
	char ETimelineDirection Rain_Smooth__Direction_81DE29134BA82A98DC8639B973004B9C;  // 0x24C(0x1)
	char pad_589[3];  // 0x24D(0x3)
	struct UTimelineComponent* Rain Smooth;  // 0x250(0x8)
	struct ABP_Sky_Sphere_Modulated_C* Sky sphere;  // 0x258(0x8)
	struct AExponentialHeightFog* Exponencial Fog;  // 0x260(0x8)
	struct ADirectionalLight* Sun light;  // 0x268(0x8)
	struct ASkyLight* Sky light;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool Enable Weather Changes : 1;  // 0x278(0x1)
	char pad_633[3];  // 0x279(0x3)
	float Rain phase;  // 0x27C(0x4)
	int32_t Actual Weather;  // 0x280(0x4)
	float Thunder Origin Distance;  // 0x284(0x4)
	struct TArray<struct FName> Weathers;  // 0x288(0x10)
	struct AVolumetricCloud* Volumetric Clouds;  // 0x298(0x8)
	struct UDataTable* Weather Data Table;  // 0x2A0(0x8)
	float Weather Transition;  // 0x2A8(0x4)
	int32_t Next Weather;  // 0x2AC(0x4)
	float Current Time;  // 0x2B0(0x4)
	float Day Length;  // 0x2B4(0x4)
	float Night Length;  // 0x2B8(0x4)
	char pad_700_1 : 7;  // 0x2BC(0x1)
	bool Night Cycle : 1;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	float Sun Inclination;  // 0x2C0(0x4)
	float Sun Rotation;  // 0x2C4(0x4)
	struct UCurveFloat* Night Curve;  // 0x2C8(0x8)
	struct UCurveFloat* Night Curve Smooth;  // 0x2D0(0x8)
	struct UCurveLinearColor* Sun Color Curve;  // 0x2D8(0x8)
	struct UCurveFloat* Skyligth Curve;  // 0x2E0(0x8)
	float Update Tick Interval;  // 0x2E8(0x4)
	char pad_748[4];  // 0x2EC(0x4)
	struct UMaterial* Volumetric Cloud Material;  // 0x2F0(0x8)
	struct UMaterialInstanceDynamic* Volumetric Cloud Dynamic Material;  // 0x2F8(0x8)
	char E_Shader_Type Shader Type;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct UCurveFloat* Audio Curve;  // 0x308(0x8)

	void Set Audio Elements(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Set Audio Elements
	float Get Sun Angle Value(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Get Sun Angle Value
	float Night(float Day, float Night, struct UCurveFloat* Alpha Curve); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Night
	void Set Light Rotation(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Set Light Rotation
	void Night Cycle(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Night Cycle
	void Pick Random Weather(int32_t& Weather Row, struct FName& Weather Name); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Pick Random Weather
	void Set Parameter Collections(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Set Parameter Collections
	void Set Elements(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Set Elements
	void UserConstructionScript(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.UserConstructionScript
	void Rain Smooth__FinishedFunc(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Rain Smooth__FinishedFunc
	void Rain Smooth__UpdateFunc(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Rain Smooth__UpdateFunc
	void On Weather Changed(struct FName Weather Name); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.On Weather Changed
	void Toggle Raining(bool Toggle); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Toggle Raining
	void ReceiveTick(float DeltaSeconds); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.ReceiveBeginPlay
	void Call Event On Change Weather(int32_t Weather); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Call Event On Change Weather
	void Calling Event On Rain(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Calling Event On Rain
	void Toggle Change Weather(int32_t Next Weather, float Transition Speed); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Toggle Change Weather
	void Change Weather(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Change Weather
	void On Rain(bool Raining?); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.On Rain
	void Toggle Thunder(bool Thunder?, struct FVector Location); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Toggle Thunder
	void Call Thunder(); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Call Thunder
	void Set Time(float Time); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.Set Time
	void ExecuteUbergraph_BP_MultiplayerDynamicWeatherManager(int32_t EntryPoint); // Function BP_MultiplayerDynamicWeatherManager.BP_MultiplayerDynamicWeatherManager_C.ExecuteUbergraph_BP_MultiplayerDynamicWeatherManager
}; 



