#pragma once 
#include <BP_EBS_Building_Ramp_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Ramp.BP_EBS_Building_Ramp_C
// Size: 0x4A0(Inherited: 0x479) 
struct ABP_EBS_Building_Ramp_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct UBoxComponent* SupportChecker2;  // 0x480(0x8)
	struct UBoxComponent* SupportChecker1;  // 0x488(0x8)
	struct USceneComponent* SupportCheckers;  // 0x490(0x8)
	struct UBoxComponent* BuildCollision;  // 0x498(0x8)

	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_Ramp.BP_EBS_Building_Ramp_C.CheckSupport
}; 



