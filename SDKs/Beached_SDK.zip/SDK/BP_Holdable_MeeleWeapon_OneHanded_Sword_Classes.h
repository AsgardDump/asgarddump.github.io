#pragma once 
#include <BP_Holdable_MeeleWeapon_OneHanded_Sword_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_OneHanded_Sword.BP_Holdable_MeeleWeapon_OneHanded_Sword_C
// Size: 0x329(Inherited: 0x329) 
struct ABP_Holdable_MeeleWeapon_OneHanded_Sword_C : public ABP_Holdable_MeeleWeapon_OneHanded_C
{

}; 



