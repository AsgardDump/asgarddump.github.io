#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_RoofWall_Left.BP_EBS_Building_RoofWall_Left_C.GetSnapTransform
// Size: 0x140(Inherited: 0x110) 
struct FGetSnapTransform : public FGetSnapTransform
{
	struct AActor* TargetActor;  // 0x0(0x8)
	float InputRotation;  // 0x8(0x4)
	struct FVector HitLocation;  // 0xC(0xC)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool GridMode : 1;  // 0x18(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool SnapNear : 1;  // 0x19(0x1)
	struct FTransform ReturnTransform;  // 0x20(0x30)
	struct FTransform CallFunc_GetSnapTransform_ReturnTransform;  // 0x50(0x30)
	char pad_394_1 : 7;  // 0x18A(0x1)
	bool Temp_bool_Variable : 1;  // 0x80(0x1)
	struct FVector CallFunc_BreakTransform_Location;  // 0x84(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x90(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x9C(0xC)
	float CallFunc_GetGlobalBuildingRotationStep_StepValue;  // 0xA8(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xAC(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0xB0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xB4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xB8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xBC(0xC)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0xC8(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xE0(0x30)
	struct FTransform K2Node_Select_Default;  // 0x110(0x30)

}; 
// Function BP_EBS_Building_RoofWall_Left.BP_EBS_Building_RoofWall_Left_C.SetFloorNumberByTargetActor
// Size: 0x20(Inherited: 0x19) 
struct FSetFloorNumberByTargetActor : public FSetFloorNumberByTargetActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_SetFloorNumberByTargetActor_Success : 1;  // 0x9(0x1)
	struct ABP_EBS_Building_Wall_C* K2Node_DynamicCast_AsBP_EBS_Building_Wall;  // 0x10(0x8)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)

}; 
