#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_Ramp.BP_EBS_Building_Ramp_C.CheckSupport
// Size: 0x81(Inherited: 0x80) 
struct FCheckSupport : public FCheckSupport
{
	char pad_128_1 : 7;  // 0x80(0x1)
	bool HasSupport : 1;  // 0x0(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> CallFunc_Get_Snapped_Objects_OverlappingObjects;  // 0x18(0x10)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool CallFunc_BuildingObjectInSocket_InSocket : 1;  // 0x34(0x1)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x38(0x4)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3C(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x40(0x4)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x48(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x58(0x4)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item_2;  // 0x60(0x8)
	char pad_211_1 : 7;  // 0xD3(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x68(0x1)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x70(0x10)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_ActorsHaveLandscape_Result : 1;  // 0x80(0x1)

}; 
