#pragma once 
#include <AN_Footstep_Structs.h>
 
 
 
// BlueprintGeneratedClass AN_Footstep.AN_Footstep_C
// Size: 0x48(Inherited: 0x38) 
struct UAN_Footstep_C : public UAnimNotify
{
	struct FName Bone Name;  // 0x38(0x8)
	float Volume Multiplier;  // 0x40(0x4)
	float Pitch Multiplier;  // 0x44(0x4)

	void Foliage Hit Filter(struct TArray<struct FHitResult>& Hit, bool& Foliage); // Function AN_Footstep.AN_Footstep_C.Foliage Hit Filter
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AN_Footstep.AN_Footstep_C.Received_Notify
}; 



