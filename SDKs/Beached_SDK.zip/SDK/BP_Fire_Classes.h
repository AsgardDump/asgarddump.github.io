#pragma once 
#include <BP_Fire_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Fire.BP_Fire_C
// Size: 0x274(Inherited: 0x220) 
struct ABP_Fire_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Audio;  // 0x228(0x8)
	struct USphereComponent* Sphere;  // 0x230(0x8)
	struct UParticleSystemComponent* ParticleSystem3;  // 0x238(0x8)
	struct UParticleSystemComponent* ParticleSystem2;  // 0x240(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x248(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x250(0x8)
	struct USceneComponent* Scene;  // 0x258(0x8)
	float Animation_Animation_291067CC49DED3D0D52CCA80294B3C37;  // 0x260(0x4)
	char ETimelineDirection Animation__Direction_291067CC49DED3D0D52CCA80294B3C37;  // 0x264(0x1)
	char pad_613[3];  // 0x265(0x3)
	struct UTimelineComponent* Animation;  // 0x268(0x8)
	float Fire Life Time;  // 0x270(0x4)

	void Animation__FinishedFunc(); // Function BP_Fire.BP_Fire_C.Animation__FinishedFunc
	void Animation__UpdateFunc(); // Function BP_Fire.BP_Fire_C.Animation__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Fire.BP_Fire_C.ReceiveBeginPlay
	void MULTICAST Fire Disappear(); // Function BP_Fire.BP_Fire_C.MULTICAST Fire Disappear
	void Apply Damage in Radius(); // Function BP_Fire.BP_Fire_C.Apply Damage in Radius
	void ExecuteUbergraph_BP_Fire(int32_t EntryPoint); // Function BP_Fire.BP_Fire_C.ExecuteUbergraph_BP_Fire
}; 



