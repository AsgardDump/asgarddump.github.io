#pragma once 
#include "SDK.h" 
 
 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Escape_K2Node_InputKeyEvent_10
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Escape_K2Node_InputKeyEvent_10
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ExecuteUbergraph_BP_PlayerController
// Size: 0x160C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PlayerController
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Temp_float_Variable;  // 0x14(0x4)
	float Temp_float_Variable_2;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct USteamGameServer* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x20(0x8)
	struct USteamGameServer* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x38(0x18)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue;  // 0x50(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x58(0x10)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_2;  // 0x68(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_3;  // 0x70(0x8)
	struct UInventory* CallFunc_GetGameInstanceSubsystem_ReturnValue_3;  // 0x78(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x80(0x10)
	struct UUI_Microphone_C* CallFunc_Create_ReturnValue_4;  // 0x90(0x8)
	int32_t Temp_int_Variable;  // 0x98(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x9C(0x4)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_5;  // 0xA0(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_6;  // 0xA8(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_7;  // 0xB0(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_8;  // 0xB8(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_9;  // 0xC0(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_10;  // 0xC8(0x8)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0xD0(0x18)
	struct FKey K2Node_InputKeyEvent_Key;  // 0xE8(0x18)
	struct FKey Temp_struct_Variable;  // 0x100(0x18)
	struct USteamGameServer* CallFunc_GetGameInstanceSubsystem_ReturnValue_4;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_11;  // 0x128(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_12;  // 0x130(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_13;  // 0x138(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_14;  // 0x140(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_15;  // 0x148(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_16;  // 0x150(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_17;  // 0x158(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_18;  // 0x160(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_19;  // 0x168(0x8)
	struct UW_CraftingListing_Skin_C* CallFunc_Create_ReturnValue_20;  // 0x170(0x8)
	struct FKey K2Node_InputKeyEvent_Key_19;  // 0x178(0x18)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x190(0x1)
	char pad_401_1 : 7;  // 0x191(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x191(0x1)
	char pad_402[2];  // 0x192(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x194(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x198(0x4)
	char pad_412_1 : 7;  // 0x19C(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x19C(0x1)
	char pad_413[3];  // 0x19D(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x1A0(0x4)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1A4(0x1)
	char pad_421[3];  // 0x1A5(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1A8(0x4)
	char pad_428_1 : 7;  // 0x1AC(0x1)
	bool Temp_bool_Variable : 1;  // 0x1AC(0x1)
	char pad_429[3];  // 0x1AD(0x3)
	struct FKey K2Node_InputKeyEvent_Key_20;  // 0x1B0(0x18)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x1C8(0x1)
	char pad_457_1 : 7;  // 0x1C9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x1C9(0x1)
	char pad_458[6];  // 0x1CA(0x6)
	struct FKey K2Node_InputKeyEvent_Key_21;  // 0x1D0(0x18)
	struct FKey K2Node_InputKeyEvent_Key_22;  // 0x1E8(0x18)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_2 : 1;  // 0x200(0x1)
	char pad_513[3];  // 0x201(0x3)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x204(0x4)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x208(0x1)
	char pad_521[3];  // 0x209(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x20C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x210(0x4)
	char pad_532_1 : 7;  // 0x214(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_3 : 1;  // 0x214(0x1)
	char pad_533[3];  // 0x215(0x3)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x218(0x4)
	char pad_540_1 : 7;  // 0x21C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x21C(0x1)
	char pad_541[3];  // 0x21D(0x3)
	struct FKey K2Node_InputKeyEvent_Key_23;  // 0x220(0x18)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0x238(0x1)
	char pad_569_1 : 7;  // 0x239(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x239(0x1)
	char pad_570_1 : 7;  // 0x23A(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_4 : 1;  // 0x23A(0x1)
	char pad_571_1 : 7;  // 0x23B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x23B(0x1)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x23C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x240(0x4)
	char pad_580_1 : 7;  // 0x244(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_5 : 1;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	int32_t Temp_int_Array_Index_Variable_5;  // 0x248(0x4)
	char pad_588_1 : 7;  // 0x24C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_5 : 1;  // 0x24C(0x1)
	char pad_589_1 : 7;  // 0x24D(0x1)
	bool Temp_bool_IsClosed_Variable_4 : 1;  // 0x24D(0x1)
	char pad_590_1 : 7;  // 0x24E(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_4 : 1;  // 0x24E(0x1)
	char pad_591[1];  // 0x24F(0x1)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x250(0x4)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0x254(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x258(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0x25C(0x4)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_6 : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	int32_t Temp_int_Array_Index_Variable_6;  // 0x264(0x4)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_6 : 1;  // 0x268(0x1)
	char pad_617[3];  // 0x269(0x3)
	int32_t Temp_int_Loop_Counter_Variable_6;  // 0x26C(0x4)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool Temp_bool_IsClosed_Variable_5 : 1;  // 0x270(0x1)
	char pad_625[3];  // 0x271(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_7;  // 0x274(0x4)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_5 : 1;  // 0x278(0x1)
	char pad_633[3];  // 0x279(0x3)
	int32_t Temp_int_Loop_Counter_Variable_7;  // 0x27C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_8;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_7 : 1;  // 0x284(0x1)
	char pad_645_1 : 7;  // 0x285(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_7 : 1;  // 0x285(0x1)
	char pad_646[2];  // 0x286(0x2)
	int32_t Temp_int_Array_Index_Variable_7;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_4;  // 0x290(0x18)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Temp_bool_IsClosed_Variable_6 : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_6 : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_7 : 1;  // 0x2AA(0x1)
	char pad_683_1 : 7;  // 0x2AB(0x1)
	bool Temp_bool_IsClosed_Variable_7 : 1;  // 0x2AB(0x1)
	char pad_684[4];  // 0x2AC(0x4)
	struct FKey Temp_struct_Variable_2;  // 0x2B0(0x18)
	int32_t Temp_int_Loop_Counter_Variable_8;  // 0x2C8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_9;  // 0x2CC(0x4)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_8 : 1;  // 0x2D0(0x1)
	char pad_721[3];  // 0x2D1(0x3)
	int32_t Temp_int_Array_Index_Variable_8;  // 0x2D4(0x4)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_8 : 1;  // 0x2D8(0x1)
	char pad_729[7];  // 0x2D9(0x7)
	struct FKey K2Node_InputKeyEvent_Key_5;  // 0x2E0(0x18)
	struct FKey K2Node_InputKeyEvent_Key_24;  // 0x2F8(0x18)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool Temp_bool_IsClosed_Variable_8 : 1;  // 0x310(0x1)
	char pad_785_1 : 7;  // 0x311(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_8 : 1;  // 0x311(0x1)
	char pad_786[6];  // 0x312(0x6)
	struct FKey K2Node_InputKeyEvent_Key_25;  // 0x318(0x18)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_9 : 1;  // 0x330(0x1)
	char pad_817[3];  // 0x331(0x3)
	int32_t Temp_int_Loop_Counter_Variable_9;  // 0x334(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_10;  // 0x338(0x4)
	char pad_828_1 : 7;  // 0x33C(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_9 : 1;  // 0x33C(0x1)
	char pad_829[3];  // 0x33D(0x3)
	int32_t Temp_int_Array_Index_Variable_9;  // 0x340(0x4)
	char pad_836_1 : 7;  // 0x344(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_9 : 1;  // 0x344(0x1)
	char pad_837_1 : 7;  // 0x345(0x1)
	bool Temp_bool_IsClosed_Variable_9 : 1;  // 0x345(0x1)
	char pad_838_1 : 7;  // 0x346(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_10 : 1;  // 0x346(0x1)
	char pad_839_1 : 7;  // 0x347(0x1)
	bool Temp_bool_IsClosed_Variable_10 : 1;  // 0x347(0x1)
	struct FKey K2Node_InputKeyEvent_Key_26;  // 0x348(0x18)
	struct FKey Temp_struct_Variable_3;  // 0x360(0x18)
	int32_t Temp_int_Loop_Counter_Variable_10;  // 0x378(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_11;  // 0x37C(0x4)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_10 : 1;  // 0x380(0x1)
	char pad_897[3];  // 0x381(0x3)
	int32_t Temp_int_Array_Index_Variable_10;  // 0x384(0x4)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_10 : 1;  // 0x388(0x1)
	char pad_905[3];  // 0x389(0x3)
	int32_t Temp_int_Array_Index_Variable_11;  // 0x38C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_27;  // 0x390(0x18)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool Temp_bool_IsClosed_Variable_11 : 1;  // 0x3A8(0x1)
	char pad_937_1 : 7;  // 0x3A9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_11 : 1;  // 0x3A9(0x1)
	char pad_938_1 : 7;  // 0x3AA(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_12 : 1;  // 0x3AA(0x1)
	char pad_939_1 : 7;  // 0x3AB(0x1)
	bool Temp_bool_IsClosed_Variable_12 : 1;  // 0x3AB(0x1)
	int32_t Temp_int_Loop_Counter_Variable_11;  // 0x3AC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_12;  // 0x3B0(0x4)
	char pad_948_1 : 7;  // 0x3B4(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_11 : 1;  // 0x3B4(0x1)
	char pad_949[3];  // 0x3B5(0x3)
	int32_t Temp_int_Array_Index_Variable_12;  // 0x3B8(0x4)
	char pad_956_1 : 7;  // 0x3BC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_11 : 1;  // 0x3BC(0x1)
	char pad_957[3];  // 0x3BD(0x3)
	struct FKey K2Node_InputKeyEvent_Key_28;  // 0x3C0(0x18)
	char pad_984_1 : 7;  // 0x3D8(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_12 : 1;  // 0x3D8(0x1)
	char pad_985_1 : 7;  // 0x3D9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_12 : 1;  // 0x3D9(0x1)
	char pad_986_1 : 7;  // 0x3DA(0x1)
	bool Temp_bool_IsClosed_Variable_13 : 1;  // 0x3DA(0x1)
	char pad_987_1 : 7;  // 0x3DB(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_13 : 1;  // 0x3DB(0x1)
	char pad_988[4];  // 0x3DC(0x4)
	struct FKey K2Node_InputKeyEvent_Key_29;  // 0x3E0(0x18)
	struct FKey Temp_struct_Variable_4;  // 0x3F8(0x18)
	struct FSTR_EBS_Resource K2Node_Event_Resource;  // 0x410(0x8)
	struct TArray<struct FSTR_EBS_Resource> K2Node_Event_Resources_3;  // 0x418(0x10)
	struct TArray<struct FSTR_EBS_Resource> K2Node_Event_Resources_2;  // 0x428(0x10)
	struct FName K2Node_Event_Weather_Name;  // 0x438(0x8)
	char pad_1088_1 : 7;  // 0x440(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x440(0x1)
	char pad_1089[7];  // 0x441(0x7)
	struct FKey K2Node_InputKeyEvent_Key_30;  // 0x448(0x18)
	struct FDataTableRowHandle K2Node_Event_BuildingObjectHandle;  // 0x460(0x10)
	char E_EBS_BuildingMode K2Node_Event_BuildingMode;  // 0x470(0x1)
	char pad_1137[7];  // 0x471(0x7)
	struct FDataTableRowHandle K2Node_Event_BuildingListHandle;  // 0x478(0x10)
	struct ABP_EBS_Building_CodeLock_C* K2Node_Event_CodeLock_6;  // 0x488(0x8)
	struct ABP_EBS_Building_CodeLock_C* K2Node_Event_CodeLock_5;  // 0x490(0x8)
	char pad_1176_1 : 7;  // 0x498(0x1)
	bool K2Node_Event_IsLocked : 1;  // 0x498(0x1)
	char pad_1177_1 : 7;  // 0x499(0x1)
	bool K2Node_Event_IsAuthorized : 1;  // 0x499(0x1)
	char pad_1178[6];  // 0x49A(0x6)
	struct FString K2Node_Event_Password_2;  // 0x4A0(0x10)
	struct ABP_EBS_Building_CodeLock_C* K2Node_CustomEvent_CodeLock_6;  // 0x4B0(0x8)
	char pad_1208_1 : 7;  // 0x4B8(0x1)
	bool K2Node_CustomEvent_IsLocked : 1;  // 0x4B8(0x1)
	char pad_1209_1 : 7;  // 0x4B9(0x1)
	bool K2Node_CustomEvent_IsAuthorized : 1;  // 0x4B9(0x1)
	char pad_1210[6];  // 0x4BA(0x6)
	struct FString K2Node_CustomEvent_Password_2;  // 0x4C0(0x10)
	struct ABP_EBS_Building_CodeLock_C* K2Node_Event_CodeLock_4;  // 0x4D0(0x8)
	struct ABP_EBS_Building_CodeLock_C* K2Node_CustomEvent_CodeLock_5;  // 0x4D8(0x8)
	struct ABP_EBS_Building_CodeLock_C* K2Node_CustomEvent_CodeLock_4;  // 0x4E0(0x8)
	char pad_1256_1 : 7;  // 0x4E8(0x1)
	bool CallFunc_TryToOpenCodelock_Success : 1;  // 0x4E8(0x1)
	char pad_1257[7];  // 0x4E9(0x7)
	struct ABP_EBS_Building_CodeLock_C* K2Node_Event_CodeLock_3;  // 0x4F0(0x8)
	struct ABP_EBS_Building_CodeLock_C* K2Node_CustomEvent_CodeLock_3;  // 0x4F8(0x8)
	struct ABP_EBS_Building_CodeLock_C* K2Node_Event_CodeLock_2;  // 0x500(0x8)
	char pad_1288_1 : 7;  // 0x508(0x1)
	bool CallFunc_TryToCreateCodeLockWidget_Success : 1;  // 0x508(0x1)
	char pad_1289[7];  // 0x509(0x7)
	struct ABP_EBS_Building_CodeLock_C* K2Node_CustomEvent_CodeLock_2;  // 0x510(0x8)
	struct ABP_EBS_Building_CodeLock_C* K2Node_Event_CodeLock;  // 0x518(0x8)
	struct FString K2Node_Event_Password;  // 0x520(0x10)
	struct ABP_EBS_Building_CodeLock_C* K2Node_CustomEvent_CodeLock;  // 0x530(0x8)
	struct FString K2Node_CustomEvent_Password;  // 0x538(0x10)
	struct FDataTableRowHandle K2Node_Event_Handle;  // 0x548(0x10)
	char pad_1368_1 : 7;  // 0x558(0x1)
	bool CallFunc_TryToSetPassword_Success : 1;  // 0x558(0x1)
	char pad_1369[7];  // 0x559(0x7)
	struct FS_BuildingRequirements CallFunc_GetDataTableRowFromName_OutRow;  // 0x560(0x20)
	char pad_1408_1 : 7;  // 0x580(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x580(0x1)
	char pad_1409_1 : 7;  // 0x581(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x581(0x1)
	char pad_1410[6];  // 0x582(0x6)
	struct TArray<struct FS_InventoryItem> K2Node_Event_Resources;  // 0x588(0x10)
	char pad_1432_1 : 7;  // 0x598(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_14 : 1;  // 0x598(0x1)
	char pad_1433[7];  // 0x599(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x5A0(0x8)
	char pad_1448_1 : 7;  // 0x5A8(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x5A8(0x1)
	char pad_1449[7];  // 0x5A9(0x7)
	struct USpringArmComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x5B0(0x8)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x5B8(0x8C)
	char pad_1604_1 : 7;  // 0x644(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x644(0x1)
	char pad_1605[3];  // 0x645(0x3)
	struct FKey Temp_struct_Variable_5;  // 0x648(0x18)
	char pad_1632_1 : 7;  // 0x660(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x660(0x1)
	char pad_1633[7];  // 0x661(0x7)
	struct FKey K2Node_InputKeyEvent_Key_6;  // 0x668(0x18)
	int32_t Temp_int_Loop_Counter_Variable_12;  // 0x680(0x4)
	char pad_1668_1 : 7;  // 0x684(0x1)
	bool Temp_bool_IsClosed_Variable_14 : 1;  // 0x684(0x1)
	char pad_1669[3];  // 0x685(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_13;  // 0x688(0x4)
	char pad_1676[4];  // 0x68C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_31;  // 0x690(0x18)
	char pad_1704_1 : 7;  // 0x6A8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_15 : 1;  // 0x6A8(0x1)
	char pad_1705_1 : 7;  // 0x6A9(0x1)
	bool Temp_bool_IsClosed_Variable_15 : 1;  // 0x6A9(0x1)
	char pad_1706_1 : 7;  // 0x6AA(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x6AA(0x1)
	char pad_1707[5];  // 0x6AB(0x5)
	struct FKey K2Node_InputKeyEvent_Key_32;  // 0x6B0(0x18)
	char pad_1736_1 : 7;  // 0x6C8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_13 : 1;  // 0x6C8(0x1)
	char pad_1737_1 : 7;  // 0x6C9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_16 : 1;  // 0x6C9(0x1)
	char pad_1738_1 : 7;  // 0x6CA(0x1)
	bool Temp_bool_IsClosed_Variable_16 : 1;  // 0x6CA(0x1)
	char pad_1739[5];  // 0x6CB(0x5)
	struct ABP_EBS_Building_BaseObject_C* K2Node_Event_TargetObject_5;  // 0x6D0(0x8)
	char pad_1752_1 : 7;  // 0x6D8(0x1)
	bool CallFunc_ChangeTopDownView_Success : 1;  // 0x6D8(0x1)
	char pad_1753[3];  // 0x6D9(0x3)
	int32_t Temp_int_Loop_Counter_Variable_13;  // 0x6DC(0x4)
	struct ABP_EBS_Building_BaseObject_C* K2Node_Event_TargetObject_4;  // 0x6E0(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_14;  // 0x6E8(0x4)
	char pad_1772[4];  // 0x6EC(0x4)
	struct ABP_EBS_Building_BaseObject_C* K2Node_Event_TargetObject_3;  // 0x6F0(0x8)
	struct ABP_EBS_Building_BaseObject_C* K2Node_Event_TargetObject_2;  // 0x6F8(0x8)
	struct ABP_EBS_Building_BaseObject_C* K2Node_Event_TargetObject;  // 0x700(0x8)
	struct AActor* K2Node_CustomEvent_TargetActor;  // 0x708(0x8)
	float K2Node_CustomEvent_Damage;  // 0x710(0x4)
	char pad_1812[4];  // 0x714(0x4)
	struct FKey K2Node_InputKeyEvent_Key_7;  // 0x718(0x18)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x730(0x4)
	struct FHitResult CallFunc_GetTraceHitResult_HitResult;  // 0x734(0x8C)
	char pad_1984_1 : 7;  // 0x7C0(0x1)
	bool CallFunc_UpdateTargetActor_Success : 1;  // 0x7C0(0x1)
	char pad_1985[7];  // 0x7C1(0x7)
	struct AActor* CallFunc_UpdateTargetActor_TargetActor;  // 0x7C8(0x8)
	char E_EBS_BuildingMode CallFunc_GetBuildingMode_BuildingMode;  // 0x7D0(0x1)
	char pad_2001_1 : 7;  // 0x7D1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x7D1(0x1)
	char pad_2002_1 : 7;  // 0x7D2(0x1)
	bool CallFunc_ChangeTraceDistance_Success : 1;  // 0x7D2(0x1)
	char pad_2003_1 : 7;  // 0x7D3(0x1)
	bool CallFunc_ChangeMaxTraceDistance_Success : 1;  // 0x7D3(0x1)
	char pad_2004_1 : 7;  // 0x7D4(0x1)
	bool CallFunc_ChangeTopDownViewMode_Success : 1;  // 0x7D4(0x1)
	char pad_2005[3];  // 0x7D5(0x3)
	struct UActorComponent* K2Node_ComponentBoundEvent_Component_2;  // 0x7D8(0x8)
	char pad_2016_1 : 7;  // 0x7E0(0x1)
	bool K2Node_ComponentBoundEvent_bReset : 1;  // 0x7E0(0x1)
	char pad_2017_1 : 7;  // 0x7E1(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_17 : 1;  // 0x7E1(0x1)
	char pad_2018_1 : 7;  // 0x7E2(0x1)
	bool Temp_bool_IsClosed_Variable_17 : 1;  // 0x7E2(0x1)
	char pad_2019_1 : 7;  // 0x7E3(0x1)
	bool CallFunc_IsActive_ReturnValue : 1;  // 0x7E3(0x1)
	char pad_2020_1 : 7;  // 0x7E4(0x1)
	bool CallFunc_TryQuickInteraction_Success : 1;  // 0x7E4(0x1)
	char pad_2021[3];  // 0x7E5(0x3)
	struct UActorComponent* K2Node_ComponentBoundEvent_Component;  // 0x7E8(0x8)
	struct FName Temp_name_Variable;  // 0x7F0(0x8)
	struct FName Temp_name_Variable_2;  // 0x7F8(0x8)
	float K2Node_InputAxisKeyEvent_AxisValue;  // 0x800(0x4)
	char pad_2052_1 : 7;  // 0x804(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x804(0x1)
	char pad_2053_1 : 7;  // 0x805(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x805(0x1)
	char pad_2054[2];  // 0x806(0x2)
	float K2Node_Select_Default;  // 0x808(0x4)
	char pad_2060_1 : 7;  // 0x80C(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_18 : 1;  // 0x80C(0x1)
	char pad_2061[3];  // 0x80D(0x3)
	struct FName Temp_name_Variable_3;  // 0x810(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x818(0x10)
	char pad_2088_1 : 7;  // 0x828(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x828(0x1)
	char pad_2089_1 : 7;  // 0x829(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x829(0x1)
	char pad_2090[6];  // 0x82A(0x6)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_2;  // 0x830(0x10)
	char pad_2112_1 : 7;  // 0x840(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x840(0x1)
	char pad_2113[7];  // 0x841(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_3;  // 0x848(0x10)
	char pad_2136_1 : 7;  // 0x858(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x858(0x1)
	char pad_2137[7];  // 0x859(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_4;  // 0x860(0x10)
	char pad_2160_1 : 7;  // 0x870(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x870(0x1)
	char pad_2161[7];  // 0x871(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_5;  // 0x878(0x10)
	char pad_2184_1 : 7;  // 0x888(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x888(0x1)
	char pad_2185_1 : 7;  // 0x889(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x889(0x1)
	char pad_2186_1 : 7;  // 0x88A(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x88A(0x1)
	char pad_2187[1];  // 0x88B(0x1)
	struct FName Temp_name_Variable_4;  // 0x88C(0x8)
	char pad_2196[4];  // 0x894(0x4)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_6;  // 0x898(0x10)
	char pad_2216_1 : 7;  // 0x8A8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x8A8(0x1)
	char pad_2217_1 : 7;  // 0x8A9(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x8A9(0x1)
	char pad_2218[2];  // 0x8AA(0x2)
	struct FName Temp_name_Variable_5;  // 0x8AC(0x8)
	struct FName Temp_name_Variable_6;  // 0x8B4(0x8)
	char pad_2236_1 : 7;  // 0x8BC(0x1)
	bool Temp_bool_IsClosed_Variable_18 : 1;  // 0x8BC(0x1)
	char pad_2237[3];  // 0x8BD(0x3)
	struct FName Temp_name_Variable_7;  // 0x8C0(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x8C8(0x8)
	float CallFunc_ApplyDamage_ReturnValue_2;  // 0x8D0(0x4)
	struct FName Temp_name_Variable_8;  // 0x8D4(0x8)
	struct FName Temp_name_Variable_9;  // 0x8DC(0x8)
	struct FName Temp_name_Variable_10;  // 0x8E4(0x8)
	struct FName Temp_name_Variable_11;  // 0x8EC(0x8)
	struct FName Temp_name_Variable_12;  // 0x8F4(0x8)
	char pad_2300_1 : 7;  // 0x8FC(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x8FC(0x1)
	char pad_2301[3];  // 0x8FD(0x3)
	struct ABP_Holdable_RangeWeapon_C* K2Node_DynamicCast_AsBP_Holdable_Range_Weapon;  // 0x900(0x8)
	char pad_2312_1 : 7;  // 0x908(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x908(0x1)
	char pad_2313[3];  // 0x909(0x3)
	struct FName Temp_name_Variable_13;  // 0x90C(0x8)
	char pad_2324_1 : 7;  // 0x914(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0x914(0x1)
	char pad_2325[3];  // 0x915(0x3)
	struct ABP_Holdable_RangeWeapon_C* K2Node_DynamicCast_AsBP_Holdable_Range_Weapon_2;  // 0x918(0x8)
	char pad_2336_1 : 7;  // 0x920(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x920(0x1)
	char pad_2337_1 : 7;  // 0x921(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_19 : 1;  // 0x921(0x1)
	char pad_2338_1 : 7;  // 0x922(0x1)
	bool CallFunc_IsValid_ReturnValue_14 : 1;  // 0x922(0x1)
	char pad_2339[5];  // 0x923(0x5)
	struct ABP_Holdable_Building_C* K2Node_DynamicCast_AsBP_Holdable_Building;  // 0x928(0x8)
	char pad_2352_1 : 7;  // 0x930(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x930(0x1)
	char pad_2353_1 : 7;  // 0x931(0x1)
	bool CallFunc_IsValid_ReturnValue_15 : 1;  // 0x931(0x1)
	char pad_2354_1 : 7;  // 0x932(0x1)
	bool CallFunc_IsValid_ReturnValue_16 : 1;  // 0x932(0x1)
	char pad_2355[5];  // 0x933(0x5)
	struct ABP_Holdable_Building_C* K2Node_DynamicCast_AsBP_Holdable_Building_2;  // 0x938(0x8)
	char pad_2368_1 : 7;  // 0x940(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x940(0x1)
	char pad_2369_1 : 7;  // 0x941(0x1)
	bool CallFunc_Is_Interactable_Widget_Visible_Visible : 1;  // 0x941(0x1)
	char pad_2370_1 : 7;  // 0x942(0x1)
	bool CallFunc_IsValid_ReturnValue_17 : 1;  // 0x942(0x1)
	char pad_2371[1];  // 0x943(0x1)
	struct FName Temp_name_Variable_14;  // 0x944(0x8)
	char pad_2380_1 : 7;  // 0x94C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x94C(0x1)
	char pad_2381[3];  // 0x94D(0x3)
	struct UW_Chat_C* CallFunc_Get_Chat_Widget_Chat_Widget_Reference;  // 0x950(0x8)
	char pad_2392_1 : 7;  // 0x958(0x1)
	bool CallFunc_Is_Interactable_Widget_Visible_Visible_2 : 1;  // 0x958(0x1)
	char pad_2393_1 : 7;  // 0x959(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_14 : 1;  // 0x959(0x1)
	char pad_2394_1 : 7;  // 0x95A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_15 : 1;  // 0x95A(0x1)
	char pad_2395_1 : 7;  // 0x95B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_16 : 1;  // 0x95B(0x1)
	char pad_2396[4];  // 0x95C(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x960(0x8)
	char pad_2408_1 : 7;  // 0x968(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x968(0x1)
	char pad_2409[7];  // 0x969(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x970(0x8)
	char pad_2424_1 : 7;  // 0x978(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x978(0x1)
	char pad_2425_1 : 7;  // 0x979(0x1)
	bool CallFunc_IsValid_ReturnValue_18 : 1;  // 0x979(0x1)
	char pad_2426_1 : 7;  // 0x97A(0x1)
	bool Temp_bool_IsClosed_Variable_19 : 1;  // 0x97A(0x1)
	char pad_2427[5];  // 0x97B(0x5)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x980(0x10)
	struct FName Temp_name_Variable_15;  // 0x990(0x8)
	char pad_2456_1 : 7;  // 0x998(0x1)
	bool CallFunc_NotEqual_StrStr_ReturnValue : 1;  // 0x998(0x1)
	char pad_2457[7];  // 0x999(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_2;  // 0x9A0(0x8)
	char pad_2472_1 : 7;  // 0x9A8(0x1)
	bool CallFunc_Is_Interactable_Widget_Visible_Visible_3 : 1;  // 0x9A8(0x1)
	char pad_2473_1 : 7;  // 0x9A9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_17 : 1;  // 0x9A9(0x1)
	char pad_2474[2];  // 0x9AA(0x2)
	int32_t Temp_int_Array_Index_Variable_13;  // 0x9AC(0x4)
	struct APawn* K2Node_Event_PossessedPawn;  // 0x9B0(0x8)
	struct AThirdPersonCharacter_C* K2Node_DynamicCast_AsThird_Person_Character;  // 0x9B8(0x8)
	char pad_2496_1 : 7;  // 0x9C0(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x9C0(0x1)
	char pad_2497[7];  // 0x9C1(0x7)
	struct APawn* K2Node_Event_UnpossessedPawn;  // 0x9C8(0x8)
	struct FName Temp_name_Variable_16;  // 0x9D0(0x8)
	char pad_2520_1 : 7;  // 0x9D8(0x1)
	bool CallFunc_IsValid_ReturnValue_19 : 1;  // 0x9D8(0x1)
	char pad_2521_1 : 7;  // 0x9D9(0x1)
	bool K2Node_Event_Raining_ : 1;  // 0x9D9(0x1)
	char pad_2522_1 : 7;  // 0x9DA(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x9DA(0x1)
	char pad_2523[5];  // 0x9DB(0x5)
	struct TScriptInterface<IBI_MultiplayerDynamicWeatherSystem_C> K2Node_DynamicCast_AsBI_Multiplayer_Dynamic_Weather_System;  // 0x9E0(0x10)
	char pad_2544_1 : 7;  // 0x9F0(0x1)
	bool K2Node_DynamicCast_bSuccess_12 : 1;  // 0x9F0(0x1)
	char pad_2545[3];  // 0x9F1(0x3)
	struct FName Temp_name_Variable_17;  // 0x9F4(0x8)
	char pad_2556_1 : 7;  // 0x9FC(0x1)
	bool CallFunc_IsValid_ReturnValue_20 : 1;  // 0x9FC(0x1)
	char pad_2557_1 : 7;  // 0x9FD(0x1)
	bool CallFunc_IsValid_ReturnValue_21 : 1;  // 0x9FD(0x1)
	char pad_2558[2];  // 0x9FE(0x2)
	struct ABP_Holdable_RangeWeapon_C* K2Node_DynamicCast_AsBP_Holdable_Range_Weapon_3;  // 0xA00(0x8)
	char pad_2568_1 : 7;  // 0xA08(0x1)
	bool K2Node_DynamicCast_bSuccess_13 : 1;  // 0xA08(0x1)
	char pad_2569[7];  // 0xA09(0x7)
	struct ABP_Holdable_RangeWeapon_C* K2Node_DynamicCast_AsBP_Holdable_Range_Weapon_4;  // 0xA10(0x8)
	char pad_2584_1 : 7;  // 0xA18(0x1)
	bool K2Node_DynamicCast_bSuccess_14 : 1;  // 0xA18(0x1)
	char pad_2585[3];  // 0xA19(0x3)
	struct FName Temp_name_Variable_18;  // 0xA1C(0x8)
	struct FName Temp_name_Variable_19;  // 0xA24(0x8)
	struct FName Temp_name_Variable_20;  // 0xA2C(0x8)
	struct FName Temp_name_Variable_21;  // 0xA34(0x8)
	char pad_2620_1 : 7;  // 0xA3C(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xA3C(0x1)
	char pad_2621_1 : 7;  // 0xA3D(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_13 : 1;  // 0xA3D(0x1)
	char pad_2622_1 : 7;  // 0xA3E(0x1)
	bool CallFunc_ChangeBuildingOffsetZ_Success : 1;  // 0xA3E(0x1)
	char pad_2623_1 : 7;  // 0xA3F(0x1)
	bool CallFunc_ChangeBuildingRotationZ_Success : 1;  // 0xA3F(0x1)
	char pad_2624_1 : 7;  // 0xA40(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_18 : 1;  // 0xA40(0x1)
	char pad_2625[3];  // 0xA41(0x3)
	struct FName Temp_name_Variable_22;  // 0xA44(0x8)
	char pad_2636[4];  // 0xA4C(0x4)
	struct TArray<char> K2Node_CustomEvent_SessionAuthTicket_2;  // 0xA50(0x10)
	struct FString K2Node_CustomEvent_SteamID_2;  // 0xA60(0x10)
	struct FSteamID CallFunc_MakeSteamID_ReturnValue;  // 0xA70(0x8)
	int32_t Temp_int_Loop_Counter_Variable_14;  // 0xA78(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_15;  // 0xA7C(0x4)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0xA80(0x1)
	uint8_t  CallFunc_BeginAuthSession_ReturnValue;  // 0xA81(0x1)
	char pad_2690[6];  // 0xA82(0x6)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0xA88(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xA98(0x10)
	struct FKey K2Node_InputKeyEvent_Key_8;  // 0xAA8(0x18)
	struct FS_MissionDatabase K2Node_MakeStruct_S_MissionDatabase;  // 0xAC0(0x10)
	struct FName Temp_name_Variable_23;  // 0xAD0(0x8)
	char pad_2776_1 : 7;  // 0xAD8(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0xAD8(0x1)
	char pad_2777[7];  // 0xAD9(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_3;  // 0xAE0(0x8)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0xAE8(0x30)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0xB18(0x8)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem_2;  // 0xB20(0x30)
	char pad_2896_1 : 7;  // 0xB50(0x1)
	bool CallFunc_Add_Item_Success : 1;  // 0xB50(0x1)
	char pad_2897_1 : 7;  // 0xB51(0x1)
	bool CallFunc_Add_Item_Success_2 : 1;  // 0xB51(0x1)
	char pad_2898[6];  // 0xB52(0x6)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem_3;  // 0xB58(0x30)
	struct FSteamInventoryResultReady K2Node_CustomEvent_Data;  // 0xB88(0x8)
	char pad_2960_1 : 7;  // 0xB90(0x1)
	bool CallFunc_Add_Item_Success_3 : 1;  // 0xB90(0x1)
	char pad_2961[7];  // 0xB91(0x7)
	struct TArray<struct FSteamItemDetails> CallFunc_GetResultItems_Items;  // 0xB98(0x10)
	char pad_2984_1 : 7;  // 0xBA8(0x1)
	bool CallFunc_GetResultItems_ReturnValue : 1;  // 0xBA8(0x1)
	char pad_2985[3];  // 0xBA9(0x3)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0xBAC(0x4)
	struct FSteamItemDetails CallFunc_Array_Get_Item;  // 0xBB0(0x20)
	struct FSteamItemDetails CallFunc_Array_Get_Item_2;  // 0xBD0(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value;  // 0xBF0(0x10)
	char pad_3072_1 : 7;  // 0xC00(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue : 1;  // 0xC00(0x1)
	char pad_3073[7];  // 0xC01(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_2;  // 0xC08(0x10)
	char pad_3096_1 : 7;  // 0xC18(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_2 : 1;  // 0xC18(0x1)
	char pad_3097_1 : 7;  // 0xC19(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xC19(0x1)
	char pad_3098_1 : 7;  // 0xC1A(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0xC1A(0x1)
	char pad_3099[5];  // 0xC1B(0x5)
	struct FSteamItemDetails CallFunc_Array_Get_Item_3;  // 0xC20(0x20)
	struct FSteamItemDetails CallFunc_Array_Get_Item_4;  // 0xC40(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value_3;  // 0xC60(0x10)
	char pad_3184_1 : 7;  // 0xC70(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_3 : 1;  // 0xC70(0x1)
	char pad_3185[7];  // 0xC71(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_4;  // 0xC78(0x10)
	char pad_3208_1 : 7;  // 0xC88(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_4 : 1;  // 0xC88(0x1)
	char pad_3209_1 : 7;  // 0xC89(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_3 : 1;  // 0xC89(0x1)
	char pad_3210_1 : 7;  // 0xC8A(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_4 : 1;  // 0xC8A(0x1)
	char pad_3211[5];  // 0xC8B(0x5)
	struct FSteamItemDetails CallFunc_Array_Get_Item_5;  // 0xC90(0x20)
	struct FSteamItemDetails CallFunc_Array_Get_Item_6;  // 0xCB0(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value_5;  // 0xCD0(0x10)
	char pad_3296_1 : 7;  // 0xCE0(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_5 : 1;  // 0xCE0(0x1)
	char pad_3297[7];  // 0xCE1(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_6;  // 0xCE8(0x10)
	char pad_3320_1 : 7;  // 0xCF8(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_6 : 1;  // 0xCF8(0x1)
	char pad_3321_1 : 7;  // 0xCF9(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_5 : 1;  // 0xCF9(0x1)
	char pad_3322_1 : 7;  // 0xCFA(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_6 : 1;  // 0xCFA(0x1)
	char pad_3323[5];  // 0xCFB(0x5)
	struct FSteamItemDetails CallFunc_Array_Get_Item_7;  // 0xD00(0x20)
	struct FSteamItemDetails CallFunc_Array_Get_Item_8;  // 0xD20(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value_7;  // 0xD40(0x10)
	char pad_3408_1 : 7;  // 0xD50(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_7 : 1;  // 0xD50(0x1)
	char pad_3409[7];  // 0xD51(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_8;  // 0xD58(0x10)
	char pad_3432_1 : 7;  // 0xD68(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_8 : 1;  // 0xD68(0x1)
	char pad_3433_1 : 7;  // 0xD69(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_7 : 1;  // 0xD69(0x1)
	char pad_3434_1 : 7;  // 0xD6A(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_8 : 1;  // 0xD6A(0x1)
	char pad_3435[5];  // 0xD6B(0x5)
	struct FSteamItemDetails CallFunc_Array_Get_Item_9;  // 0xD70(0x20)
	struct FSteamItemDetails CallFunc_Array_Get_Item_10;  // 0xD90(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value_9;  // 0xDB0(0x10)
	char pad_3520_1 : 7;  // 0xDC0(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_9 : 1;  // 0xDC0(0x1)
	char pad_3521[7];  // 0xDC1(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_10;  // 0xDC8(0x10)
	char pad_3544_1 : 7;  // 0xDD8(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_10 : 1;  // 0xDD8(0x1)
	char pad_3545_1 : 7;  // 0xDD9(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_9 : 1;  // 0xDD9(0x1)
	char pad_3546_1 : 7;  // 0xDDA(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_10 : 1;  // 0xDDA(0x1)
	char pad_3547[5];  // 0xDDB(0x5)
	struct FSteamItemDetails CallFunc_Array_Get_Item_11;  // 0xDE0(0x20)
	struct FSteamItemDetails CallFunc_Array_Get_Item_12;  // 0xE00(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value_11;  // 0xE20(0x10)
	char pad_3632_1 : 7;  // 0xE30(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_11 : 1;  // 0xE30(0x1)
	char pad_3633[7];  // 0xE31(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_12;  // 0xE38(0x10)
	char pad_3656_1 : 7;  // 0xE48(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_12 : 1;  // 0xE48(0x1)
	char pad_3657_1 : 7;  // 0xE49(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_11 : 1;  // 0xE49(0x1)
	char pad_3658_1 : 7;  // 0xE4A(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_12 : 1;  // 0xE4A(0x1)
	char pad_3659[5];  // 0xE4B(0x5)
	struct FSteamItemDetails CallFunc_Array_Get_Item_13;  // 0xE50(0x20)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xE70(0x4)
	char pad_3700_1 : 7;  // 0xE74(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xE74(0x1)
	char pad_3701[3];  // 0xE75(0x3)
	struct FString CallFunc_GetItemDefinitionProperty_Value_13;  // 0xE78(0x10)
	char pad_3720_1 : 7;  // 0xE88(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_13 : 1;  // 0xE88(0x1)
	char pad_3721_1 : 7;  // 0xE89(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0xE89(0x1)
	char pad_3722_1 : 7;  // 0xE8A(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_13 : 1;  // 0xE8A(0x1)
	char pad_3723[1];  // 0xE8B(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xE8C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0xE90(0x4)
	char pad_3732_1 : 7;  // 0xE94(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xE94(0x1)
	char pad_3733_1 : 7;  // 0xE95(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0xE95(0x1)
	char pad_3734_1 : 7;  // 0xE96(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0xE96(0x1)
	char pad_3735[1];  // 0xE97(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0xE98(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0xE9C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_6;  // 0xEA0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_7;  // 0xEA4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_8;  // 0xEA8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_9;  // 0xEAC(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_10;  // 0xEB0(0x4)
	char pad_3764_1 : 7;  // 0xEB4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0xEB4(0x1)
	char pad_3765_1 : 7;  // 0xEB5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0xEB5(0x1)
	char pad_3766_1 : 7;  // 0xEB6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0xEB6(0x1)
	char pad_3767_1 : 7;  // 0xEB7(0x1)
	bool CallFunc_BooleanAND_ReturnValue_7 : 1;  // 0xEB7(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_11;  // 0xEB8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_12;  // 0xEBC(0x4)
	char pad_3776_1 : 7;  // 0xEC0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_6 : 1;  // 0xEC0(0x1)
	char pad_3777_1 : 7;  // 0xEC1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_7 : 1;  // 0xEC1(0x1)
	char pad_3778_1 : 7;  // 0xEC2(0x1)
	bool CallFunc_BooleanAND_ReturnValue_8 : 1;  // 0xEC2(0x1)
	char pad_3779_1 : 7;  // 0xEC3(0x1)
	bool CallFunc_BooleanAND_ReturnValue_9 : 1;  // 0xEC3(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_13;  // 0xEC4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_14;  // 0xEC8(0x4)
	char pad_3788_1 : 7;  // 0xECC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_8 : 1;  // 0xECC(0x1)
	char pad_3789_1 : 7;  // 0xECD(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_9 : 1;  // 0xECD(0x1)
	char pad_3790_1 : 7;  // 0xECE(0x1)
	bool CallFunc_BooleanAND_ReturnValue_10 : 1;  // 0xECE(0x1)
	char pad_3791_1 : 7;  // 0xECF(0x1)
	bool CallFunc_BooleanAND_ReturnValue_11 : 1;  // 0xECF(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_15;  // 0xED0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_16;  // 0xED4(0x4)
	char pad_3800_1 : 7;  // 0xED8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_10 : 1;  // 0xED8(0x1)
	char pad_3801_1 : 7;  // 0xED9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_11 : 1;  // 0xED9(0x1)
	char pad_3802_1 : 7;  // 0xEDA(0x1)
	bool CallFunc_BooleanAND_ReturnValue_12 : 1;  // 0xEDA(0x1)
	char pad_3803_1 : 7;  // 0xEDB(0x1)
	bool CallFunc_BooleanAND_ReturnValue_13 : 1;  // 0xEDB(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_17;  // 0xEDC(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_18;  // 0xEE0(0x4)
	char pad_3812_1 : 7;  // 0xEE4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_12 : 1;  // 0xEE4(0x1)
	char pad_3813_1 : 7;  // 0xEE5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_13 : 1;  // 0xEE5(0x1)
	char pad_3814_1 : 7;  // 0xEE6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_14 : 1;  // 0xEE6(0x1)
	char pad_3815_1 : 7;  // 0xEE7(0x1)
	bool CallFunc_BooleanAND_ReturnValue_15 : 1;  // 0xEE7(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_19;  // 0xEE8(0x4)
	int32_t Temp_int_Array_Index_Variable_14;  // 0xEEC(0x4)
	char pad_3824_1 : 7;  // 0xEF0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_14 : 1;  // 0xEF0(0x1)
	char pad_3825[7];  // 0xEF1(0x7)
	struct FSteamItemDetails CallFunc_Array_Get_Item_14;  // 0xEF8(0x20)
	char pad_3864_1 : 7;  // 0xF18(0x1)
	bool CallFunc_BooleanAND_ReturnValue_16 : 1;  // 0xF18(0x1)
	char pad_3865[7];  // 0xF19(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_14;  // 0xF20(0x10)
	char pad_3888_1 : 7;  // 0xF30(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_14 : 1;  // 0xF30(0x1)
	char pad_3889_1 : 7;  // 0xF31(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_14 : 1;  // 0xF31(0x1)
	char pad_3890[2];  // 0xF32(0x2)
	struct FName Temp_name_Variable_24;  // 0xF34(0x8)
	int32_t CallFunc_Divide_IntInt_ReturnValue_2;  // 0xF3C(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_3;  // 0xF40(0x4)
	char pad_3908[4];  // 0xF44(0x4)
	struct TArray<struct UW_Crafting_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0xF48(0x10)
	struct FKey K2Node_InputKeyEvent_Key_9;  // 0xF58(0x18)
	struct UW_Crafting_C* CallFunc_Array_Get_Item_15;  // 0xF70(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0xF78(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_2;  // 0xF7C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xF80(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0xF84(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0xF88(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_2;  // 0xF8C(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_3;  // 0xF90(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_4;  // 0xF94(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_3;  // 0xF98(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_4;  // 0xF9C(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_3;  // 0xFA0(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_4;  // 0xFA4(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_5;  // 0xFA8(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_6;  // 0xFAC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_5;  // 0xFB0(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_6;  // 0xFB4(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_5;  // 0xFB8(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_6;  // 0xFBC(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_7;  // 0xFC0(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_8;  // 0xFC4(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_7;  // 0xFC8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_8;  // 0xFCC(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_7;  // 0xFD0(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_8;  // 0xFD4(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_9;  // 0xFD8(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_10;  // 0xFDC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_9;  // 0xFE0(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_10;  // 0xFE4(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_9;  // 0xFE8(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_10;  // 0xFEC(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_11;  // 0xFF0(0x4)
	char pad_4084[4];  // 0xFF4(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0xFF8(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_11;  // 0x1000(0x4)
	char pad_4100[4];  // 0x1004(0x4)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot;  // 0x1008(0x8)
	char pad_4112_1 : 7;  // 0x1010(0x1)
	bool K2Node_DynamicCast_bSuccess_15 : 1;  // 0x1010(0x1)
	char pad_4113[3];  // 0x1011(0x3)
	int32_t CallFunc_Percent_IntInt_ReturnValue_11;  // 0x1014(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_2;  // 0x1018(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_3;  // 0x1020(0x8)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_2;  // 0x1028(0x8)
	char pad_4144_1 : 7;  // 0x1030(0x1)
	bool K2Node_DynamicCast_bSuccess_16 : 1;  // 0x1030(0x1)
	char pad_4145[7];  // 0x1031(0x7)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_3;  // 0x1038(0x8)
	char pad_4160_1 : 7;  // 0x1040(0x1)
	bool K2Node_DynamicCast_bSuccess_17 : 1;  // 0x1040(0x1)
	char pad_4161[7];  // 0x1041(0x7)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_4;  // 0x1048(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_5;  // 0x1050(0x8)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_4;  // 0x1058(0x8)
	char pad_4192_1 : 7;  // 0x1060(0x1)
	bool K2Node_DynamicCast_bSuccess_18 : 1;  // 0x1060(0x1)
	char pad_4193[7];  // 0x1061(0x7)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_5;  // 0x1068(0x8)
	char pad_4208_1 : 7;  // 0x1070(0x1)
	bool K2Node_DynamicCast_bSuccess_19 : 1;  // 0x1070(0x1)
	char pad_4209[7];  // 0x1071(0x7)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_6;  // 0x1078(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_7;  // 0x1080(0x8)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_6;  // 0x1088(0x8)
	char pad_4240_1 : 7;  // 0x1090(0x1)
	bool K2Node_DynamicCast_bSuccess_20 : 1;  // 0x1090(0x1)
	char pad_4241[7];  // 0x1091(0x7)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_7;  // 0x1098(0x8)
	char pad_4256_1 : 7;  // 0x10A0(0x1)
	bool K2Node_DynamicCast_bSuccess_21 : 1;  // 0x10A0(0x1)
	char pad_4257[7];  // 0x10A1(0x7)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_8;  // 0x10A8(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_9;  // 0x10B0(0x8)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_8;  // 0x10B8(0x8)
	char pad_4288_1 : 7;  // 0x10C0(0x1)
	bool K2Node_DynamicCast_bSuccess_22 : 1;  // 0x10C0(0x1)
	char pad_4289[7];  // 0x10C1(0x7)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_9;  // 0x10C8(0x8)
	char pad_4304_1 : 7;  // 0x10D0(0x1)
	bool K2Node_DynamicCast_bSuccess_23 : 1;  // 0x10D0(0x1)
	char pad_4305[7];  // 0x10D1(0x7)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_10;  // 0x10D8(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_11;  // 0x10E0(0x8)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_10;  // 0x10E8(0x8)
	char pad_4336_1 : 7;  // 0x10F0(0x1)
	bool K2Node_DynamicCast_bSuccess_24 : 1;  // 0x10F0(0x1)
	char pad_4337[7];  // 0x10F1(0x7)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_11;  // 0x10F8(0x8)
	char pad_4352_1 : 7;  // 0x1100(0x1)
	bool K2Node_DynamicCast_bSuccess_25 : 1;  // 0x1100(0x1)
	char pad_4353[3];  // 0x1101(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue_12;  // 0x1104(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_13;  // 0x1108(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_12;  // 0x110C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_13;  // 0x1110(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_12;  // 0x1114(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_13;  // 0x1118(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_14;  // 0x111C(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_15;  // 0x1120(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_14;  // 0x1124(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_15;  // 0x1128(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_14;  // 0x112C(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_15;  // 0x1130(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_16;  // 0x1134(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_12;  // 0x1138(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_16;  // 0x1140(0x4)
	char pad_4420[4];  // 0x1144(0x4)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_12;  // 0x1148(0x8)
	char pad_4432_1 : 7;  // 0x1150(0x1)
	bool K2Node_DynamicCast_bSuccess_26 : 1;  // 0x1150(0x1)
	char pad_4433[3];  // 0x1151(0x3)
	int32_t CallFunc_Percent_IntInt_ReturnValue_16;  // 0x1154(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_13;  // 0x1158(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_14;  // 0x1160(0x8)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_13;  // 0x1168(0x8)
	char pad_4464_1 : 7;  // 0x1170(0x1)
	bool K2Node_DynamicCast_bSuccess_27 : 1;  // 0x1170(0x1)
	char pad_4465[7];  // 0x1171(0x7)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_14;  // 0x1178(0x8)
	char pad_4480_1 : 7;  // 0x1180(0x1)
	bool K2Node_DynamicCast_bSuccess_28 : 1;  // 0x1180(0x1)
	char pad_4481[7];  // 0x1181(0x7)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_15;  // 0x1188(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_16;  // 0x1190(0x8)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_15;  // 0x1198(0x8)
	char pad_4512_1 : 7;  // 0x11A0(0x1)
	bool K2Node_DynamicCast_bSuccess_29 : 1;  // 0x11A0(0x1)
	char pad_4513[7];  // 0x11A1(0x7)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_16;  // 0x11A8(0x8)
	char pad_4528_1 : 7;  // 0x11B0(0x1)
	bool K2Node_DynamicCast_bSuccess_30 : 1;  // 0x11B0(0x1)
	char pad_4529[3];  // 0x11B1(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue_17;  // 0x11B4(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_17;  // 0x11B8(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_17;  // 0x11C0(0x4)
	char pad_4548[4];  // 0x11C4(0x4)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_17;  // 0x11C8(0x8)
	char pad_4560_1 : 7;  // 0x11D0(0x1)
	bool K2Node_DynamicCast_bSuccess_31 : 1;  // 0x11D0(0x1)
	char pad_4561[3];  // 0x11D1(0x3)
	int32_t CallFunc_Percent_IntInt_ReturnValue_17;  // 0x11D4(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_18;  // 0x11D8(0x4)
	char pad_4572[4];  // 0x11DC(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_18;  // 0x11E0(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_18;  // 0x11E8(0x4)
	char pad_4588[4];  // 0x11EC(0x4)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_18;  // 0x11F0(0x8)
	char pad_4600_1 : 7;  // 0x11F8(0x1)
	bool K2Node_DynamicCast_bSuccess_32 : 1;  // 0x11F8(0x1)
	char pad_4601[3];  // 0x11F9(0x3)
	int32_t CallFunc_Percent_IntInt_ReturnValue_18;  // 0x11FC(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_19;  // 0x1200(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue_19;  // 0x1208(0x4)
	char pad_4620[4];  // 0x120C(0x4)
	struct UUniformGridSlot* K2Node_DynamicCast_AsUniform_Grid_Slot_19;  // 0x1210(0x8)
	char pad_4632_1 : 7;  // 0x1218(0x1)
	bool K2Node_DynamicCast_bSuccess_33 : 1;  // 0x1218(0x1)
	char pad_4633[3];  // 0x1219(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_19;  // 0x121C(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_19;  // 0x1220(0x4)
	char pad_4644[4];  // 0x1224(0x4)
	struct FKey K2Node_InputKeyEvent_Key_10;  // 0x1228(0x18)
	struct FSteamInventoryResult CallFunc_GetAllItems_Handle;  // 0x1240(0x4)
	char pad_4676_1 : 7;  // 0x1244(0x1)
	bool CallFunc_GetAllItems_ReturnValue : 1;  // 0x1244(0x1)
	char pad_4677[3];  // 0x1245(0x3)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0x1248(0x8)
	struct FName Temp_name_Variable_25;  // 0x1250(0x8)
	struct TArray<struct UUI_Microphone_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_2;  // 0x1258(0x10)
	struct UUI_Microphone_C* CallFunc_Array_Get_Item_16;  // 0x1268(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_20;  // 0x1270(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_4;  // 0x1274(0x4)
	char pad_4728_1 : 7;  // 0x1278(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_15 : 1;  // 0x1278(0x1)
	char pad_4729_1 : 7;  // 0x1279(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_14 : 1;  // 0x1279(0x1)
	char pad_4730[2];  // 0x127A(0x2)
	struct FName Temp_name_Variable_26;  // 0x127C(0x8)
	char pad_4740_1 : 7;  // 0x1284(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_19 : 1;  // 0x1284(0x1)
	char pad_4741[3];  // 0x1285(0x3)
	int32_t CallFunc_Divide_IntInt_ReturnValue_5;  // 0x1288(0x4)
	struct FName Temp_name_Variable_27;  // 0x128C(0x8)
	int32_t CallFunc_Divide_IntInt_ReturnValue_6;  // 0x1294(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_7;  // 0x1298(0x4)
	struct FName Temp_name_Variable_28;  // 0x129C(0x8)
	int32_t CallFunc_Divide_IntInt_ReturnValue_8;  // 0x12A4(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_9;  // 0x12A8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_15;  // 0x12AC(0x4)
	char pad_4784_1 : 7;  // 0x12B0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_16 : 1;  // 0x12B0(0x1)
	char pad_4785[3];  // 0x12B1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_16;  // 0x12B4(0x4)
	char pad_4792_1 : 7;  // 0x12B8(0x1)
	bool CallFunc_BooleanAND_ReturnValue_17 : 1;  // 0x12B8(0x1)
	char pad_4793[3];  // 0x12B9(0x3)
	struct FName Temp_name_Variable_29;  // 0x12BC(0x8)
	char pad_4804_1 : 7;  // 0x12C4(0x1)
	bool CallFunc_VoiceChatStartSpeak_ReturnValue : 1;  // 0x12C4(0x1)
	char pad_4805_1 : 7;  // 0x12C5(0x1)
	bool CallFunc_VoiceChatStopSpeak_ReturnValue : 1;  // 0x12C5(0x1)
	char pad_4806[2];  // 0x12C6(0x2)
	struct FKey K2Node_InputKeyEvent_Key_11;  // 0x12C8(0x18)
	int32_t Temp_int_Array_Index_Variable_15;  // 0x12E0(0x4)
	char pad_4836_1 : 7;  // 0x12E4(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_15 : 1;  // 0x12E4(0x1)
	char pad_4837[3];  // 0x12E5(0x3)
	struct FSteamItemDetails CallFunc_Array_Get_Item_17;  // 0x12E8(0x20)
	char pad_4872_1 : 7;  // 0x1308(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_20 : 1;  // 0x1308(0x1)
	char pad_4873[7];  // 0x1309(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_15;  // 0x1310(0x10)
	char pad_4896_1 : 7;  // 0x1320(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_15 : 1;  // 0x1320(0x1)
	char pad_4897_1 : 7;  // 0x1321(0x1)
	bool CallFunc_BooleanAND_ReturnValue_18 : 1;  // 0x1321(0x1)
	char pad_4898_1 : 7;  // 0x1322(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_15 : 1;  // 0x1322(0x1)
	char pad_4899_1 : 7;  // 0x1323(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_16 : 1;  // 0x1323(0x1)
	char pad_4900[4];  // 0x1324(0x4)
	struct TArray<char> CallFunc_GetAuthSessionTicket_Ticket;  // 0x1328(0x10)
	struct FSteamTicketHandle CallFunc_GetAuthSessionTicket_ReturnValue;  // 0x1338(0x4)
	char pad_4924_1 : 7;  // 0x133C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_21 : 1;  // 0x133C(0x1)
	char pad_4925[3];  // 0x133D(0x3)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_2;  // 0x1340(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0x1348(0x10)
	int32_t Temp_int_Loop_Counter_Variable_16;  // 0x1358(0x4)
	struct FName Temp_name_Variable_30;  // 0x135C(0x8)
	char pad_4964_1 : 7;  // 0x1364(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_17 : 1;  // 0x1364(0x1)
	char pad_4965_1 : 7;  // 0x1365(0x1)
	bool CallFunc_BooleanAND_ReturnValue_19 : 1;  // 0x1365(0x1)
	char pad_4966[2];  // 0x1366(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_17;  // 0x1368(0x4)
	char pad_4972[4];  // 0x136C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_12;  // 0x1370(0x18)
	int32_t Temp_int_Array_Index_Variable_16;  // 0x1388(0x4)
	char pad_5004[4];  // 0x138C(0x4)
	struct TArray<char> K2Node_CustomEvent_SessionAuthTicket;  // 0x1390(0x10)
	struct FString K2Node_CustomEvent_SteamID;  // 0x13A0(0x10)
	struct FSteamItemDetails CallFunc_Array_Get_Item_18;  // 0x13B0(0x20)
	struct FSteamID CallFunc_MakeSteamID_ReturnValue_2;  // 0x13D0(0x8)
	struct FString CallFunc_GetItemDefinitionProperty_Value_16;  // 0x13D8(0x10)
	char pad_5096_1 : 7;  // 0x13E8(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_16 : 1;  // 0x13E8(0x1)
	char pad_5097_1 : 7;  // 0x13E9(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_16 : 1;  // 0x13E9(0x1)
	char pad_5098[6];  // 0x13EA(0x6)
	struct FKey K2Node_InputKeyEvent_Key_13;  // 0x13F0(0x18)
	struct FKey K2Node_InputKeyEvent_Key_14;  // 0x1408(0x18)
	uint8_t  CallFunc_BeginAuthSession_ReturnValue_2;  // 0x1420(0x1)
	char pad_5153[7];  // 0x1421(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x1428(0x8)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue_2;  // 0x1430(0x10)
	char pad_5184_1 : 7;  // 0x1440(0x1)
	bool CallFunc_IsLocalController_ReturnValue_2 : 1;  // 0x1440(0x1)
	char pad_5185[7];  // 0x1441(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x1448(0x10)
	char pad_5208_1 : 7;  // 0x1458(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_17 : 1;  // 0x1458(0x1)
	char pad_5209_1 : 7;  // 0x1459(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_22 : 1;  // 0x1459(0x1)
	char pad_5210[2];  // 0x145A(0x2)
	int32_t Temp_int_Loop_Counter_Variable_17;  // 0x145C(0x4)
	struct FName Temp_name_Variable_31;  // 0x1460(0x8)
	char pad_5224_1 : 7;  // 0x1468(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_18 : 1;  // 0x1468(0x1)
	char pad_5225_1 : 7;  // 0x1469(0x1)
	bool CallFunc_BooleanAND_ReturnValue_20 : 1;  // 0x1469(0x1)
	char pad_5226[2];  // 0x146A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_18;  // 0x146C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_15;  // 0x1470(0x18)
	int32_t Temp_int_Array_Index_Variable_17;  // 0x1488(0x4)
	int32_t Temp_int_Array_Index_Variable_18;  // 0x148C(0x4)
	struct FSteamItemDetails CallFunc_Array_Get_Item_19;  // 0x1490(0x20)
	struct FSteamItemDetails CallFunc_Array_Get_Item_20;  // 0x14B0(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value_17;  // 0x14D0(0x10)
	char pad_5344_1 : 7;  // 0x14E0(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_17 : 1;  // 0x14E0(0x1)
	char pad_5345[7];  // 0x14E1(0x7)
	struct FString CallFunc_GetItemDefinitionProperty_Value_18;  // 0x14E8(0x10)
	char pad_5368_1 : 7;  // 0x14F8(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_18 : 1;  // 0x14F8(0x1)
	char pad_5369_1 : 7;  // 0x14F9(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_17 : 1;  // 0x14F9(0x1)
	char pad_5370_1 : 7;  // 0x14FA(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_18 : 1;  // 0x14FA(0x1)
	char pad_5371_1 : 7;  // 0x14FB(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_18 : 1;  // 0x14FB(0x1)
	char pad_5372_1 : 7;  // 0x14FC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_23 : 1;  // 0x14FC(0x1)
	char pad_5373_1 : 7;  // 0x14FD(0x1)
	bool CallFunc_IsLocalPlayerController_ReturnValue : 1;  // 0x14FD(0x1)
	char pad_5374[2];  // 0x14FE(0x2)
	struct FName Temp_name_Variable_32;  // 0x1500(0x8)
	int32_t CallFunc_Divide_IntInt_ReturnValue_10;  // 0x1508(0x4)
	int32_t Temp_int_Loop_Counter_Variable_18;  // 0x150C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_16;  // 0x1510(0x18)
	char pad_5416_1 : 7;  // 0x1528(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_19 : 1;  // 0x1528(0x1)
	char pad_5417[3];  // 0x1529(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_19;  // 0x152C(0x4)
	char pad_5424_1 : 7;  // 0x1530(0x1)
	bool CallFunc_BooleanAND_ReturnValue_21 : 1;  // 0x1530(0x1)
	char pad_5425[3];  // 0x1531(0x3)
	struct FName Temp_name_Variable_33;  // 0x1534(0x8)
	int32_t Temp_int_Array_Index_Variable_19;  // 0x153C(0x4)
	struct FSteamItemDetails CallFunc_Array_Get_Item_21;  // 0x1540(0x20)
	struct FString CallFunc_GetItemDefinitionProperty_Value_19;  // 0x1560(0x10)
	char pad_5488_1 : 7;  // 0x1570(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_19 : 1;  // 0x1570(0x1)
	char pad_5489[3];  // 0x1571(0x3)
	struct FName Temp_name_Variable_34;  // 0x1574(0x8)
	char pad_5500_1 : 7;  // 0x157C(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_19 : 1;  // 0x157C(0x1)
	char pad_5501_1 : 7;  // 0x157D(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_19 : 1;  // 0x157D(0x1)
	char pad_5502_1 : 7;  // 0x157E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_24 : 1;  // 0x157E(0x1)
	char pad_5503[1];  // 0x157F(0x1)
	struct FName Temp_name_Variable_35;  // 0x1580(0x8)
	struct FName Temp_name_Variable_36;  // 0x1588(0x8)
	int32_t Temp_int_Loop_Counter_Variable_19;  // 0x1590(0x4)
	struct FName Temp_name_Variable_37;  // 0x1594(0x8)
	char pad_5532_1 : 7;  // 0x159C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_20 : 1;  // 0x159C(0x1)
	char pad_5533_1 : 7;  // 0x159D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_22 : 1;  // 0x159D(0x1)
	char pad_5534[2];  // 0x159E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_20;  // 0x15A0(0x4)
	struct FName Temp_name_Variable_38;  // 0x15A4(0x8)
	struct FName Temp_name_Variable_39;  // 0x15AC(0x8)
	char pad_5556[4];  // 0x15B4(0x4)
	struct FKey K2Node_InputKeyEvent_Key_17;  // 0x15B8(0x18)
	struct FKey K2Node_InputKeyEvent_Key_18;  // 0x15D0(0x18)
	int32_t CallFunc_Divide_IntInt_ReturnValue_11;  // 0x15E8(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_12;  // 0x15EC(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_13;  // 0x15F0(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_14;  // 0x15F4(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_15;  // 0x15F8(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_16;  // 0x15FC(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_17;  // 0x1600(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_18;  // 0x1604(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_19;  // 0x1608(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CheckforResources
// Size: 0x60(Inherited: 0x0) 
struct FCheckforResources
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FS_InventoryItem CallFunc_Array_Get_Item;  // 0x20(0x30)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_CheckforBuildingResources_Result : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x5C(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_RightMouseButton_K2Node_InputKeyEvent_25
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RightMouseButton_K2Node_InputKeyEvent_25
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_T_K2Node_InputKeyEvent_6
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_T_K2Node_InputKeyEvent_6
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Toggle Raining
// Size: 0x1(Inherited: 0x0) 
struct FToggle Raining
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.AuthenticateSteamClient
// Size: 0x20(Inherited: 0x0) 
struct FAuthenticateSteamClient
{
	struct TArray<char> SessionAuthTicket;  // 0x0(0x10)
	struct FString SteamID;  // 0x10(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ReceiveUnPossess
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnPossess : public FReceiveUnPossess
{
	struct APawn* UnpossessedPawn;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.SetResources_BPI
// Size: 0x10(Inherited: 0x0) 
struct FSetResources_BPI
{
	struct TArray<struct FSTR_EBS_Resource> Resources;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_R_K2Node_InputKeyEvent_30
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_R_K2Node_InputKeyEvent_30
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.On Rain
// Size: 0x1(Inherited: 0x0) 
struct FOn Rain
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Raining? : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ServerAuthenticateSteamClient
// Size: 0x20(Inherited: 0x0) 
struct FServerAuthenticateSteamClient
{
	struct TArray<char> SessionAuthTicket;  // 0x0(0x10)
	struct FString SteamID;  // 0x10(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_X_K2Node_InputKeyEvent_9
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_X_K2Node_InputKeyEvent_9
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.UpdateBuildingList_BPI
// Size: 0x10(Inherited: 0x0) 
struct FUpdateBuildingList_BPI
{
	struct FDataTableRowHandle BuildingListHandle;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InventoryReady
// Size: 0x8(Inherited: 0x0) 
struct FInventoryReady
{
	struct FSteamInventoryResultReady Data;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_V_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_V_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.UpdateCodeLock_BPI
// Size: 0x20(Inherited: 0x0) 
struct FUpdateCodeLock_BPI
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsLocked : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool IsAuthorized : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString Password;  // 0x10(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ReceivePossess
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossess : public FReceivePossess
{
	struct APawn* PossessedPawn;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Eight_K2Node_InputKeyEvent_15
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Eight_K2Node_InputKeyEvent_15
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpAxisKeyEvt_MouseWheelAxis_K2Node_InputAxisKeyEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisKeyEvt_MouseWheelAxis_K2Node_InputAxisKeyEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.BndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_3_ActorComponentDeactivateSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_3_ActorComponentDeactivateSignature__DelegateSignature
{
	struct UActorComponent* Component;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.DamageActor (Server)
// Size: 0xC(Inherited: 0x0) 
struct FDamageActor (Server)
{
	struct AActor* TargetActor;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.BndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_2_ActorComponentActivatedSignature__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FBndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_2_ActorComponentActivatedSignature__DelegateSignature
{
	struct UActorComponent* Component;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bReset : 1;  // 0x8(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryDestruct_BPI
// Size: 0x8(Inherited: 0x0) 
struct FTryDestruct_BPI
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_I_K2Node_InputKeyEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_I_K2Node_InputKeyEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryRemove_BPI
// Size: 0x8(Inherited: 0x0) 
struct FTryRemove_BPI
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ShowCodeLockWidget (Client)
// Size: 0x8(Inherited: 0x0) 
struct FShowCodeLockWidget (Client)
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryUpgrade_BPI
// Size: 0x8(Inherited: 0x0) 
struct FTryUpgrade_BPI
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Create Static Mesh Component
// Size: 0x10(Inherited: 0x0) 
struct FCreate Static Mesh Component
{
	struct UStaticMesh* Mesh;  // 0x0(0x8)
	struct USceneComponent* Return;  // 0x8(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryRepair_BPI
// Size: 0x8(Inherited: 0x0) 
struct FTryRepair_BPI
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CloseCodeLock_BPI
// Size: 0x8(Inherited: 0x0) 
struct FCloseCodeLock_BPI
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryRotate_BPI
// Size: 0x8(Inherited: 0x0) 
struct FTryRotate_BPI
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CompleteRequirements_BPI
// Size: 0x10(Inherited: 0x0) 
struct FCompleteRequirements_BPI
{
	struct FDataTableRowHandle Handle;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.RemoveResources_BPI
// Size: 0x10(Inherited: 0x0) 
struct FRemoveResources_BPI
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_R_K2Node_InputKeyEvent_14
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_R_K2Node_InputKeyEvent_14
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryToSetCodeLockPassword (Server)
// Size: 0x18(Inherited: 0x0) 
struct FTryToSetCodeLockPassword (Server)
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)
	struct FString Password;  // 0x8(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.GetInteractionText_BPI
// Size: 0x38(Inherited: 0x0) 
struct FGetInteractionText_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	struct FText InteractionText;  // 0x20(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Delete_K2Node_InputKeyEvent_8
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Delete_K2Node_InputKeyEvent_8
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryToSetCodeLockPassword_BPI
// Size: 0x18(Inherited: 0x0) 
struct FTryToSetCodeLockPassword_BPI
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)
	struct FString Password;  // 0x8(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Get Hand IK Points
// Size: 0x18(Inherited: 0x0) 
struct FGet Hand IK Points
{
	struct FVector Hand IK L World Space;  // 0x0(0xC)
	struct FVector Hand IK R World Space;  // 0xC(0xC)

}; 
// Function BP_PlayerController.BP_PlayerController_C.HideCodeLockWidget (Client)
// Size: 0x8(Inherited: 0x0) 
struct FHideCodeLockWidget (Client)
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_B_K2Node_InputKeyEvent_13
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_B_K2Node_InputKeyEvent_13
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.HideCodeLockWidget_BPI
// Size: 0x8(Inherited: 0x0) 
struct FHideCodeLockWidget_BPI
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ShowCodeLockWidget_BPI
// Size: 0x8(Inherited: 0x0) 
struct FShowCodeLockWidget_BPI
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.OpenCodeLock (Server)
// Size: 0x8(Inherited: 0x0) 
struct FOpenCodeLock (Server)
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CloseCodeLock (Server)
// Size: 0x8(Inherited: 0x0) 
struct FCloseCodeLock (Server)
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_M_K2Node_InputKeyEvent_26
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_M_K2Node_InputKeyEvent_26
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.UpdateCodeLock (Client)
// Size: 0x20(Inherited: 0x0) 
struct FUpdateCodeLock (Client)
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsLocked : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool IsAuthorized : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString Password;  // 0x10(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.OpenCodeLock_BPI
// Size: 0x8(Inherited: 0x0) 
struct FOpenCodeLock_BPI
{
	struct ABP_EBS_Building_CodeLock_C* CodeLock;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.SetBuildingMode_BPI
// Size: 0x1(Inherited: 0x0) 
struct FSetBuildingMode_BPI
{
	char E_EBS_BuildingMode BuildingMode;  // 0x0(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.TryStartBuildObject_BPI
// Size: 0x10(Inherited: 0x0) 
struct FTryStartBuildObject_BPI
{
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.On Weather Changed
// Size: 0x8(Inherited: 0x0) 
struct FOn Weather Changed
{
	struct FName Weather Name;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.AddResources_BPI
// Size: 0x10(Inherited: 0x0) 
struct FAddResources_BPI
{
	struct TArray<struct FSTR_EBS_Resource> Resources;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.AddResource_BPI
// Size: 0x8(Inherited: 0x0) 
struct FAddResource_BPI
{
	struct FSTR_EBS_Resource Resource;  // 0x0(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Four_K2Node_InputKeyEvent_19
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Four_K2Node_InputKeyEvent_19
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Get Chat Widget
// Size: 0x9(Inherited: 0x0) 
struct FGet Chat Widget
{
	struct UW_Chat_C* Chat Widget Reference;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Seven_K2Node_InputKeyEvent_16
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Seven_K2Node_InputKeyEvent_16
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_V_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_V_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Six_K2Node_InputKeyEvent_17
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Six_K2Node_InputKeyEvent_17
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.GetInteractionObjectName_BPI
// Size: 0x18(Inherited: 0x0) 
struct FGetInteractionObjectName_BPI
{
	struct FText Name;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Ctrl+Alt_Delete_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl+Alt_Delete_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_P_K2Node_InputKeyEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_P_K2Node_InputKeyEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_RightMouseButton_K2Node_InputKeyEvent_24
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RightMouseButton_K2Node_InputKeyEvent_24
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_T_K2Node_InputKeyEvent_7
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_T_K2Node_InputKeyEvent_7
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_11
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_MouseScrollDown_K2Node_InputKeyEvent_11
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_12
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_MouseScrollUp_K2Node_InputKeyEvent_12
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Five_K2Node_InputKeyEvent_18
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Five_K2Node_InputKeyEvent_18
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Three_K2Node_InputKeyEvent_20
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Three_K2Node_InputKeyEvent_20
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Two_K2Node_InputKeyEvent_21
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Two_K2Node_InputKeyEvent_21
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_One_K2Node_InputKeyEvent_22
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_One_K2Node_InputKeyEvent_22
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Enter_K2Node_InputKeyEvent_23
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Enter_K2Node_InputKeyEvent_23
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_27
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftMouseButton_K2Node_InputKeyEvent_27
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_28
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftMouseButton_K2Node_InputKeyEvent_28
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Tab_K2Node_InputKeyEvent_29
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Tab_K2Node_InputKeyEvent_29
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_R_K2Node_InputKeyEvent_31
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_R_K2Node_InputKeyEvent_31
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_32
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftMouseButton_K2Node_InputKeyEvent_32
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Can Toggle Menu
// Size: 0x1(Inherited: 0x0) 
struct FCan Toggle Menu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Pass : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.On Movement Mode Updated
// Size: 0x2(Inherited: 0x0) 
struct FOn Movement Mode Updated
{
	char E_PlayerMovementMode Movement Mode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Is Player Controlled
// Size: 0x1(Inherited: 0x0) 
struct FIs Player Controlled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Player Controlled : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Is Alive
// Size: 0x1(Inherited: 0x0) 
struct FIs Alive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Is Alive : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Create Child Actor Component
// Size: 0x10(Inherited: 0x0) 
struct FCreate Child Actor Component
{
	AActor* Actor;  // 0x0(0x8)
	struct USceneComponent* Return;  // 0x8(0x8)

}; 
// Function BP_PlayerController.BP_PlayerController_C.Remove Holster Component
// Size: 0x9(Inherited: 0x0) 
struct FRemove Holster Component
{
	struct USceneComponent* Component;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Return : 1;  // 0x8(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.GetOwnershipInfo_BPI
// Size: 0x1C(Inherited: 0x0) 
struct FGetOwnershipInfo_BPI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsOwned : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FString> OwnerNames;  // 0x8(0x10)
	float OwnershipDistance;  // 0x18(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CheckPlayerIsOwner_BPI
// Size: 0x9(Inherited: 0x0) 
struct FCheckPlayerIsOwner_BPI
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsOwner : 1;  // 0x8(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.GetOwners_BPI
// Size: 0x10(Inherited: 0x0) 
struct FGetOwners_BPI
{
	struct TArray<struct FString> OwnerNames;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.IsCanInteract_BPI
// Size: 0x21(Inherited: 0x0) 
struct FIsCanInteract_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.SetFloorActorHidden_BPI
// Size: 0x2(Inherited: 0x0) 
struct FSetFloorActorHidden_BPI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewHidden : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.GetFloorNumber_BPI
// Size: 0x4(Inherited: 0x0) 
struct FGetFloorNumber_BPI
{
	int32_t FloorNumber;  // 0x0(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.SetFloorNumber_BPI
// Size: 0x5(Inherited: 0x0) 
struct FSetFloorNumber_BPI
{
	int32_t FloorNumber;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.GetDurability_BPI
// Size: 0x8(Inherited: 0x0) 
struct FGetDurability_BPI
{
	float CurrentValue;  // 0x0(0x4)
	float MaxValue;  // 0x4(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.SetMaxDurability_BPI
// Size: 0x5(Inherited: 0x0) 
struct FSetMaxDurability_BPI
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.ChangeDurability_BPI
// Size: 0x9(Inherited: 0x0) 
struct FChangeDurability_BPI
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CheckforBuildingResources
// Size: 0x7B(Inherited: 0x0) 
struct FCheckforBuildingResources
{
	struct FS_InventoryItem Resource;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Result : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x3C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FS_InventoryItem CallFunc_Array_Get_Item;  // 0x48(0x30)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x7A(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.RemoveResources
// Size: 0xB4(Inherited: 0x0) 
struct FRemoveResources
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)
	int32_t L Cached Amount;  // 0x10(0x4)
	int32_t L Current Item Index;  // 0x14(0x4)
	struct TArray<int32_t> L Cached Indexes;  // 0x18(0x10)
	int32_t L Remaining Amount;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FS_InventoryItem CallFunc_Array_Get_Item;  // 0x38(0x30)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x68(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct TArray<int32_t> CallFunc_Find_Item_Indexes_from_ID_Found_Indexes;  // 0x80(0x10)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x98(0x4)
	int32_t CallFunc_Array_Get_Item_2;  // 0x9C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xA4(0x1)
	char pad_165_1 : 7;  // 0xA5(0x1)
	bool Temp_bool_Variable : 1;  // 0xA5(0x1)
	char pad_166_1 : 7;  // 0xA6(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xA6(0x1)
	char pad_167_1 : 7;  // 0xA7(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xA7(0x1)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t K2Node_Select_Default;  // 0xAC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xB0(0x4)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CheckResources_BPI
// Size: 0x12(Inherited: 0x0) 
struct FCheckResources_BPI
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_CheckforResources_Result : 1;  // 0x11(0x1)

}; 
// Function BP_PlayerController.BP_PlayerController_C.GetResources_BPI
// Size: 0x10(Inherited: 0x0) 
struct FGetResources_BPI
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)

}; 
// Function BP_PlayerController.BP_PlayerController_C.CheckRequirements_BPI
// Size: 0x50(Inherited: 0x0) 
struct FCheckRequirements_BPI
{
	struct FDataTableRowHandle Handle;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FS_BuildingRequirements CallFunc_GetDataTableRowFromName_OutRow;  // 0x20(0x20)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_CheckforResources_Result : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4C(0x4)

}; 
