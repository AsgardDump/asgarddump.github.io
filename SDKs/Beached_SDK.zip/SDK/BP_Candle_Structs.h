#pragma once 
#include "SDK.h" 
 
 
// Function BP_Candle.BP_Candle_C.ExecuteUbergraph_BP_Candle
// Size: 0xDD(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Candle
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x8(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x18(0xC)
	float CallFunc_BreakVector_X;  // 0x24(0x4)
	float CallFunc_BreakVector_Y;  // 0x28(0x4)
	float CallFunc_BreakVector_Z;  // 0x2C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x30(0xC)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x44(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x50(0x8C)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0xDC(0x1)

}; 
