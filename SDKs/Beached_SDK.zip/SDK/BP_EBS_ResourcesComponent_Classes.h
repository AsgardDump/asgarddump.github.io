#pragma once 
#include <BP_EBS_ResourcesComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C
// Size: 0x100(Inherited: 0xB0) 
struct UBP_EBS_ResourcesComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct TArray<struct FS_InventoryItem> Resources;  // 0xB8(0x10)
	struct TArray<struct FSTR_EBS_Resource> StartingResources;  // 0xC8(0x10)
	struct TArray<struct FS_InventoryItem> Inventory;  // 0xD8(0x10)
	int32_t L Current Item Index;  // 0xE8(0x4)
	int32_t L Remaining Amount;  // 0xEC(0x4)
	struct TArray<int32_t> L Cached Indexes;  // 0xF0(0x10)

	void GetResourceValue(char E_EBS_ResourceType ResourceType, float& Value); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.GetResourceValue
	void GetResources(struct TArray<struct FS_InventoryItem>& Resources); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.GetResources
	void InitComponent(); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.InitComponent
	void RemoveResources(struct TArray<struct FS_InventoryItem>& Resources, bool& Success); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResources
	void RemoveResource(struct FS_InventoryItem& Resource, bool& Success); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResource
	void CheckResources(struct TArray<struct FS_InventoryItem>& Resources, bool& Result); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.CheckResources
	void CheckResource(struct FS_InventoryItem Resource, bool& Result); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.CheckResource
	void SetResources(struct TArray<struct FS_InventoryItem>& Resources); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.SetResources
	void AddResources(struct TArray<struct FSTR_EBS_Resource>& Resources); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.AddResources
	void AddResource(struct FSTR_EBS_Resource Resource); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.AddResource
	void ReceiveBeginPlay(); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.ReceiveBeginPlay
	void RemoveResource (Server)(struct FS_InventoryItem& Resource); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResource (Server)
	void RemoveResources (Server)(struct TArray<struct FS_InventoryItem>& Resources); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResources (Server)
	void ExecuteUbergraph_BP_EBS_ResourcesComponent(int32_t EntryPoint); // Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.ExecuteUbergraph_BP_EBS_ResourcesComponent
}; 



