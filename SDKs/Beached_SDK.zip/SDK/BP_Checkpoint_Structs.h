#pragma once 
#include "SDK.h" 
 
 
// Function BP_Checkpoint.BP_Checkpoint_C.ExecuteUbergraph_BP_Checkpoint
// Size: 0x7A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Checkpoint
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UW_Marker_C* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_2;  // 0x50(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x58(0x8)
	struct TArray<struct UW_Marker_C*> CallFunc_Add_Custom_Marker_Marker_Reference;  // 0x60(0x10)
	struct AController* K2Node_DynamicCast_AsController;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x79(0x1)

}; 
