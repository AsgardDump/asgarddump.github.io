#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.ExecuteUbergraph_BP_EBS_ResourcesComponent
// Size: 0x4A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_ResourcesComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FS_InventoryItem K2Node_CustomEvent_Resource;  // 0x8(0x30)
	struct TArray<struct FS_InventoryItem> K2Node_CustomEvent_Resources;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_RemoveResource_Success : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_RemoveResources_Success : 1;  // 0x49(0x1)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResources (Server)
// Size: 0x10(Inherited: 0x0) 
struct FRemoveResources (Server)
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.SetResources
// Size: 0x10(Inherited: 0x0) 
struct FSetResources
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResource (Server)
// Size: 0x30(Inherited: 0x0) 
struct FRemoveResource (Server)
{
	struct FS_InventoryItem Resource;  // 0x0(0x30)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.AddResources
// Size: 0x10(Inherited: 0x0) 
struct FAddResources
{
	struct TArray<struct FSTR_EBS_Resource> Resources;  // 0x0(0x10)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.CheckResources
// Size: 0x60(Inherited: 0x0) 
struct FCheckResources
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FS_InventoryItem CallFunc_Array_Get_Item;  // 0x20(0x30)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_CheckResource_Result : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x5C(0x4)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.AddResource
// Size: 0x8(Inherited: 0x0) 
struct FAddResource
{
	struct FSTR_EBS_Resource Resource;  // 0x0(0x8)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.CheckResource
// Size: 0x31(Inherited: 0x0) 
struct FCheckResource
{
	struct FS_InventoryItem Resource;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Result : 1;  // 0x30(0x1)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResource
// Size: 0x31(Inherited: 0x0) 
struct FRemoveResource
{
	struct FS_InventoryItem Resource;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Success : 1;  // 0x30(0x1)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.RemoveResources
// Size: 0x4C(Inherited: 0x0) 
struct FRemoveResources
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t L Cached Amount;  // 0x14(0x4)
	struct FS_BuildingRequirements S_Building_Requirement;  // 0x18(0x20)
	int32_t Temp_int_Array_Index_Variable;  // 0x38(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x48(0x4)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.GetResourceValue
// Size: 0x8(Inherited: 0x0) 
struct FGetResourceValue
{
	char E_EBS_ResourceType ResourceType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)

}; 
// Function BP_EBS_ResourcesComponent.BP_EBS_ResourcesComponent_C.GetResources
// Size: 0x10(Inherited: 0x0) 
struct FGetResources
{
	struct TArray<struct FS_InventoryItem> Resources;  // 0x0(0x10)

}; 
