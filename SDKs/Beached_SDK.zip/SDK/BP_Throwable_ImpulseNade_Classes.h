#pragma once 
#include <BP_Throwable_ImpulseNade_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C
// Size: 0x254(Inherited: 0x240) 
struct ABP_Throwable_ImpulseNade_C : public ABP_Throwable_Object_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x240(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x248(0x8)
	float Detonation Time;  // 0x250(0x4)

	void ReceiveBeginPlay(); // Function BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C.ReceiveBeginPlay
	void ReceivePointDamage(float Damage, struct UDamageType* DamageType, struct FVector HitLocation, struct FVector HitNormal, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector ShotFromDirection, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FHitResult& HitInfo); // Function BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C.ReceivePointDamage
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C.ReceiveHit
	void ExecuteUbergraph_BP_Throwable_ImpulseNade(int32_t EntryPoint); // Function BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C.ExecuteUbergraph_BP_Throwable_ImpulseNade
}; 



