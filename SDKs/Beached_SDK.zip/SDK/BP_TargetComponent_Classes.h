#pragma once 
#include <BP_TargetComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_TargetComponent.BP_TargetComponent_C
// Size: 0x118(Inherited: 0xB0) 
struct UBP_TargetComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct TArray<struct UW_Marker_C*> Marker Reference;  // 0xB8(0x10)
	struct FTimerHandle Timer Event;  // 0xC8(0x8)
	struct FS_TargetInformation Target Information;  // 0xD0(0x48)

	void Overlap(struct AActor* Other Actor, bool Overlap?); // Function BP_TargetComponent.BP_TargetComponent_C.Overlap
	void Overlap Refresh(); // Function BP_TargetComponent.BP_TargetComponent_C.Overlap Refresh
	void Interacted(struct AController* Player); // Function BP_TargetComponent.BP_TargetComponent_C.Interacted
	void On Unoverlap(); // Function BP_TargetComponent.BP_TargetComponent_C.On Unoverlap
	void On Overlap(); // Function BP_TargetComponent.BP_TargetComponent_C.On Overlap
	void ExecuteUbergraph_BP_TargetComponent(int32_t EntryPoint); // Function BP_TargetComponent.BP_TargetComponent_C.ExecuteUbergraph_BP_TargetComponent
}; 



