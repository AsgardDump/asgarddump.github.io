#pragma once 
#include <ABP_Chicken_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Chicken.ABP_Chicken_C
// Size: 0x3E4(Inherited: 0x2C0) 
struct UABP_Chicken_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x2F8(0xE8)
	float Speed;  // 0x3E0(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Chicken.ABP_Chicken_C.AnimGraph
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Chicken.ABP_Chicken_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_Chicken(int32_t EntryPoint); // Function ABP_Chicken.ABP_Chicken_C.ExecuteUbergraph_ABP_Chicken
}; 



