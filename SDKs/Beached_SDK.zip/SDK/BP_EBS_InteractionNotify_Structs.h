#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_InteractionNotify.BP_EBS_InteractionNotify_C.Received_NotifyBegin
// Size: 0x2A(Inherited: 0x18) 
struct FReceived_NotifyBegin : public FReceived_NotifyBegin
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	float TotalDuration;  // 0x10(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct UBP_EBS_InteractionComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_CompleteInteractionNotify_Success : 1;  // 0x28(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)

}; 
