#pragma once 
#include <BP_Ghost_SmallWoodenHut_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_SmallWoodenHut.BP_Ghost_SmallWoodenHut_C
// Size: 0x280(Inherited: 0x280) 
struct ABP_Ghost_SmallWoodenHut_C : public ABP_GhostActor_C
{

	void Custom Rotation(struct FHitResult Hit, struct FRotator Current Rotation); // Function BP_Ghost_SmallWoodenHut.BP_Ghost_SmallWoodenHut_C.Custom Rotation
	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_SmallWoodenHut.BP_Ghost_SmallWoodenHut_C.Custom Condition Pass
}; 



