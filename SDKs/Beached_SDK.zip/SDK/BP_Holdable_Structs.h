#pragma once 
#include "SDK.h" 
 
 
// Function BP_Holdable.BP_Holdable_C.On Swimming
// Size: 0x1(Inherited: 0x0) 
struct FOn Swimming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Remove Holster Component
// Size: 0x9(Inherited: 0x0) 
struct FRemove Holster Component
{
	struct USceneComponent* Component;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Return : 1;  // 0x8(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.ExecuteUbergraph_BP_Holdable
// Size: 0x2A8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Holdable
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool K2Node_Event_Toggle_2 : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct USkeletalMeshComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AController* K2Node_DynamicCast_AsController;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x40(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x48(0x8)
	struct FVector K2Node_Event_Camera_Offset;  // 0x50(0xC)
	float K2Node_Event_Arm_Length;  // 0x5C(0x4)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x60(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct TArray<char E_CustomizationItem> K2Node_Event_Hide_Mesh;  // 0x90(0x10)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue_2;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_Destroy_Holster_Return : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xA9(0x1)
	char pad_170[6];  // 0xAA(0x6)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	float CallFunc_PlayAnimMontage_ReturnValue;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue_3;  // 0xC8(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_2;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	float CallFunc_PlayAnimMontage_ReturnValue_2;  // 0xDC(0x4)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_3;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	float CallFunc_PlayAnimMontage_ReturnValue_3;  // 0xEC(0x4)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0xF1(0x1)
	char pad_242_1 : 7;  // 0xF2(0x1)
	bool K2Node_Event_Toggle_3 : 1;  // 0xF2(0x1)
	char E_ArmorType K2Node_Event_Armor_Type;  // 0xF3(0x1)
	char pad_244[4];  // 0xF4(0x4)
	struct USkeletalMesh* K2Node_Event_Skeletal_Mesh;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct AController* K2Node_DynamicCast_AsController_2;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_IsLocalController_ReturnValue_2 : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_2;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool K2Node_Event_Pressed : 1;  // 0x139(0x1)
	char pad_314[6];  // 0x13A(0x6)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue_4;  // 0x140(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_Destroy_Holster_Return_2 : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_2;  // 0x158(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x160(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x168(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x170(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_3;  // 0x178(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x180(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_2;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_3;  // 0x198(0x10)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x1A8(0x1)
	char E_HoldableType K2Node_Event_Holdable_Type;  // 0x1A9(0x1)
	char pad_426_1 : 7;  // 0x1AA(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x1AA(0x1)
	char pad_427[5];  // 0x1AB(0x5)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_4;  // 0x1B0(0x10)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x1C0(0x1)
	char pad_449_1 : 7;  // 0x1C1(0x1)
	bool K2Node_Event_Toggle_4 : 1;  // 0x1C1(0x1)
	char pad_450[6];  // 0x1C2(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x1D0(0x1)
	char pad_465[7];  // 0x1D1(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_5;  // 0x1D8(0x10)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x1E8(0x1)
	char pad_489[7];  // 0x1E9(0x7)
	struct AController* K2Node_DynamicCast_AsController_3;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_5;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsLocalController_ReturnValue_3 : 1;  // 0x208(0x1)
	char pad_521[7];  // 0x209(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_4;  // 0x210(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_6;  // 0x218(0x8)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x220(0x1)
	char pad_545[7];  // 0x221(0x7)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_3;  // 0x228(0x8)
	struct FS_PlayerCustomization K2Node_Event_Customization;  // 0x230(0x50)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x280(0x1)
	char pad_641_1 : 7;  // 0x281(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x281(0x1)
	char pad_642_1 : 7;  // 0x282(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x282(0x1)
	char pad_643_1 : 7;  // 0x283(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x283(0x1)
	char pad_644[4];  // 0x284(0x4)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_6;  // 0x288(0x10)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool K2Node_DynamicCast_bSuccess_12 : 1;  // 0x298(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x299(0x1)
	char pad_666_1 : 7;  // 0x29A(0x1)
	bool K2Node_Event_Knocked : 1;  // 0x29A(0x1)
	char pad_667[5];  // 0x29B(0x5)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue_5;  // 0x2A0(0x8)

}; 
// Function BP_Holdable.BP_Holdable_C.Set Holdable Type
// Size: 0x1(Inherited: 0x0) 
struct FSet Holdable Type
{
	char E_HoldableType Holdable Type;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Hide Customization
// Size: 0x10(Inherited: 0x0) 
struct FHide Customization
{
	struct TArray<char E_CustomizationItem> Hide Mesh;  // 0x0(0x10)

}; 
// Function BP_Holdable.BP_Holdable_C.Aiming Action
// Size: 0x1(Inherited: 0x0) 
struct FAiming Action
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Primary Action
// Size: 0x1(Inherited: 0x0) 
struct FPrimary Action
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Pressed : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Show Player Tag
// Size: 0x1(Inherited: 0x0) 
struct FShow Player Tag
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Update Armor
// Size: 0x10(Inherited: 0x0) 
struct FUpdate Armor
{
	char E_ArmorType Armor Type;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USkeletalMesh* Skeletal Mesh;  // 0x8(0x8)

}; 
// Function BP_Holdable.BP_Holdable_C.Toggle Sprint
// Size: 0x1(Inherited: 0x0) 
struct FToggle Sprint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Load Player Customization
// Size: 0x50(Inherited: 0x0) 
struct FLoad Player Customization
{
	struct FS_PlayerCustomization Customization;  // 0x0(0x50)

}; 
// Function BP_Holdable.BP_Holdable_C.On Player Dead
// Size: 0x1(Inherited: 0x0) 
struct FOn Player Dead
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Knocked : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Start Aiming
// Size: 0x10(Inherited: 0x0) 
struct FStart Aiming
{
	struct FVector Camera Offset;  // 0x0(0xC)
	float Arm Length;  // 0xC(0x4)

}; 
// Function BP_Holdable.BP_Holdable_C.Is Owner Local
// Size: 0x1A(Inherited: 0x0) 
struct FIs Owner Local
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct AController* K2Node_DynamicCast_AsController;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Create Child Actor Component
// Size: 0x10(Inherited: 0x0) 
struct FCreate Child Actor Component
{
	AActor* Actor;  // 0x0(0x8)
	struct USceneComponent* Return;  // 0x8(0x8)

}; 
// Function BP_Holdable.BP_Holdable_C.Create Static Mesh Component
// Size: 0x10(Inherited: 0x0) 
struct FCreate Static Mesh Component
{
	struct UStaticMesh* Mesh;  // 0x0(0x8)
	struct USceneComponent* Return;  // 0x8(0x8)

}; 
// Function BP_Holdable.BP_Holdable_C.On Movement Mode Updated
// Size: 0x2(Inherited: 0x0) 
struct FOn Movement Mode Updated
{
	char E_PlayerMovementMode Movement Mode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Get Hand IK Points
// Size: 0x18(Inherited: 0x0) 
struct FGet Hand IK Points
{
	struct FVector Hand IK L World Space;  // 0x0(0xC)
	struct FVector Hand IK R World Space;  // 0xC(0xC)

}; 
// Function BP_Holdable.BP_Holdable_C.Is Alive
// Size: 0x1(Inherited: 0x0) 
struct FIs Alive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Is Alive : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Is Player Controlled
// Size: 0x1(Inherited: 0x0) 
struct FIs Player Controlled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Player Controlled : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable.BP_Holdable_C.Can Toggle Menu
// Size: 0x1(Inherited: 0x0) 
struct FCan Toggle Menu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Pass : 1;  // 0x0(0x1)

}; 
