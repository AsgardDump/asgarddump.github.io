#pragma once 
#include <BI_MultiplayerDynamicWeatherSystem_Structs.h>
 
 
 
// BlueprintGeneratedClass BI_MultiplayerDynamicWeatherSystem.BI_MultiplayerDynamicWeatherSystem_C
// Size: 0x28(Inherited: 0x28) 
struct UBI_MultiplayerDynamicWeatherSystem_C : public UInterface
{

	void Toggle Raining(bool Toggle); // Function BI_MultiplayerDynamicWeatherSystem.BI_MultiplayerDynamicWeatherSystem_C.Toggle Raining
	void On Weather Changed(struct FName Weather Name); // Function BI_MultiplayerDynamicWeatherSystem.BI_MultiplayerDynamicWeatherSystem_C.On Weather Changed
	void On Rain(bool Raining?); // Function BI_MultiplayerDynamicWeatherSystem.BI_MultiplayerDynamicWeatherSystem_C.On Rain
}; 



