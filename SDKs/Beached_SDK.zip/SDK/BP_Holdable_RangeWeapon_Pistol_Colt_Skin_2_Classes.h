#pragma once 
#include <BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2.BP_Holdable_RangeWeapon_Pistol_Colt_Skin_1_C
// Size: 0x4A8(Inherited: 0x49D) 
struct ABP_Holdable_RangeWeapon_Pistol_Colt_Skin_1_C : public ABP_Holdable_RangeWeapon_Pistol_C
{
	char pad_1181[3];  // 0x49D(0x3)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A0(0x8)

	void Change Firemode(); // Function BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2.BP_Holdable_RangeWeapon_Pistol_Colt_Skin_1_C.Change Firemode
	void ExecuteUbergraph_BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2(int32_t EntryPoint); // Function BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2.BP_Holdable_RangeWeapon_Pistol_Colt_Skin_1_C.ExecuteUbergraph_BP_Holdable_RangeWeapon_Pistol_Colt_Skin_2
}; 



