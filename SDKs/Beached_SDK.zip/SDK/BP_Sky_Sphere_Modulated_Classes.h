#pragma once 
#include <BP_Sky_Sphere_Modulated_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Sky_Sphere_Modulated.BP_Sky_Sphere_Modulated_C
// Size: 0x2D4(Inherited: 0x2C0) 
struct ABP_Sky_Sphere_Modulated_C : public ABP_Sky_Sphere_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct UCurveLinearColor* Sun Color Curve;  // 0x2C8(0x8)
	float Cloud Brightness;  // 0x2D0(0x4)

	void UserConstructionScript(); // Function BP_Sky_Sphere_Modulated.BP_Sky_Sphere_Modulated_C.UserConstructionScript
	void RefreshMaterial(); // Function BP_Sky_Sphere_Modulated.BP_Sky_Sphere_Modulated_C.RefreshMaterial
	void UpdateSunDirection(); // Function BP_Sky_Sphere_Modulated.BP_Sky_Sphere_Modulated_C.UpdateSunDirection
	void ExecuteUbergraph_BP_Sky_Sphere_Modulated(int32_t EntryPoint); // Function BP_Sky_Sphere_Modulated.BP_Sky_Sphere_Modulated_C.ExecuteUbergraph_BP_Sky_Sphere_Modulated
}; 



