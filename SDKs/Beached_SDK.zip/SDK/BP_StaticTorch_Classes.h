#pragma once 
#include <BP_StaticTorch_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_StaticTorch.BP_StaticTorch_C
// Size: 0x4D0(Inherited: 0x4A8) 
struct ABP_StaticTorch_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct UParticleSystemComponent* P_TorchFire;  // 0x4B0(0x8)
	struct UStaticMeshComponent* StaticMesh_1;  // 0x4B8(0x8)
	struct UAudioComponent* WAV_FireLoop_Cue;  // 0x4C0(0x8)
	struct UPointLightComponent* PointLight;  // 0x4C8(0x8)

	void ReceiveBeginPlay(); // Function BP_StaticTorch.BP_StaticTorch_C.ReceiveBeginPlay
	void CheckForCollisionBeneath(); // Function BP_StaticTorch.BP_StaticTorch_C.CheckForCollisionBeneath
	void ExecuteUbergraph_BP_StaticTorch(int32_t EntryPoint); // Function BP_StaticTorch.BP_StaticTorch_C.ExecuteUbergraph_BP_StaticTorch
}; 



