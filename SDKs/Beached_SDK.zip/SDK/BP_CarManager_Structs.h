#pragma once 
#include "SDK.h" 
 
 
// Function BP_CarManager.BP_CarManager_C.ExecuteUbergraph_BP_CarManager
// Size: 0x3A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CarManager
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ABP_Garage_C* K2Node_DynamicCast_AsBP_Garage;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AController* K2Node_Event_Executor;  // 0x28(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x39(0x1)

}; 
// Function BP_CarManager.BP_CarManager_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_CarManager.BP_CarManager_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_CarManager.BP_CarManager_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_CarManager.BP_CarManager_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_CarManager.BP_CarManager_C.Get Interaction Data
// Size: 0x18(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)

}; 
