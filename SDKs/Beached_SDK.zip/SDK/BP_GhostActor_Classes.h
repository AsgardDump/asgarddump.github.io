#pragma once 
#include <BP_GhostActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GhostActor.BP_GhostActor_C
// Size: 0x280(Inherited: 0x220) 
struct ABP_GhostActor_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)
	char pad_552[8];  // 0x228(0x8)
	struct FS_Building Build Data;  // 0x230(0x50)

	void Is Parental Cupboard(bool& Return, struct ABP_Cupboard_C*& Cupboard); // Function BP_GhostActor.BP_GhostActor_C.Is Parental Cupboard
	void Find Cupboard(struct ABP_Cupboard_C*& Return); // Function BP_GhostActor.BP_GhostActor_C.Find Cupboard
	void Collision Check(bool& Return); // Function BP_GhostActor.BP_GhostActor_C.Collision Check
	void Custom Rotation(struct FHitResult Hit, struct FRotator Current Rotation); // Function BP_GhostActor.BP_GhostActor_C.Custom Rotation
	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_GhostActor.BP_GhostActor_C.Custom Condition Pass
	void Set Ghost Color(bool Success); // Function BP_GhostActor.BP_GhostActor_C.Set Ghost Color
}; 



