#pragma once 
#include <BP_MapData_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MapData.BP_MapData_C
// Size: 0x2B1(Inherited: 0x220) 
struct ABP_MapData_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct UTexture2D* BigMap Texture;  // 0x230(0x8)
	struct UTexture2D* Minimap Texture;  // 0x238(0x8)
	struct UTexture2D* Minimap Mask Texture;  // 0x240(0x8)
	float World Size;  // 0x248(0x4)
	struct FVector2D World Middle Coordinations;  // 0x24C(0x8)
	char pad_596[4];  // 0x254(0x4)
	struct UMaterialInstanceDynamic* Dynamic Minimap Material;  // 0x258(0x8)
	struct UMaterialInstanceDynamic* Dynamic Bigmap Material;  // 0x260(0x8)
	float Minimap Zoom;  // 0x268(0x4)
	char pad_620_1 : 7;  // 0x26C(0x1)
	bool Is Circle Minimap Mask : 1;  // 0x26C(0x1)
	char pad_621_1 : 7;  // 0x26D(0x1)
	bool Enable Fog Of War : 1;  // 0x26D(0x1)
	char pad_622[2];  // 0x26E(0x2)
	int32_t Fog Of War Mask Resolution;  // 0x270(0x4)
	char pad_628[4];  // 0x274(0x4)
	struct UTextureRenderTarget2D* Fog Of War Mask;  // 0x278(0x8)
	struct UTexture2D* Fog Of War Texture;  // 0x280(0x8)
	struct UMaterialInstanceDynamic* Minimap Fog Of War Material;  // 0x288(0x8)
	float Vision Radius;  // 0x290(0x4)
	float Fog Of War Update Time;  // 0x294(0x4)
	struct UMaterialInstanceDynamic* Bigmap Fog Of War Material;  // 0x298(0x8)
	struct FLinearColor Zone Color;  // 0x2A0(0x10)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Minimap Camera Rotation : 1;  // 0x2B0(0x1)

	void Construct Minimap(); // Function BP_MapData.BP_MapData_C.Construct Minimap
	void Update Player Vision(); // Function BP_MapData.BP_MapData_C.Update Player Vision
	void ReceiveBeginPlay(); // Function BP_MapData.BP_MapData_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_MapData(int32_t EntryPoint); // Function BP_MapData.BP_MapData_C.ExecuteUbergraph_BP_MapData
}; 



