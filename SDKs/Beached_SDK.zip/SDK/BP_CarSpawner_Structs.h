#pragma once 
#include "SDK.h" 
 
 
// Function BP_CarSpawner.BP_CarSpawner_C.ExecuteUbergraph_BP_CarSpawner
// Size: 0xA0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CarSpawner
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4(0x4)
	struct TArray<struct ABP_Buggy_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x24(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x30(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x3C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x40(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x44(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x48(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x4C(0xC)
	char pad_88[8];  // 0x58(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x60(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x90(0x8)
	struct ABP_Buggy_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x98(0x8)

}; 
