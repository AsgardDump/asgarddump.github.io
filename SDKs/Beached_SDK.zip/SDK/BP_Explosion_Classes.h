#pragma once 
#include <BP_Explosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Explosion.BP_Explosion_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_Explosion_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct URadialForceComponent* RadialForce;  // 0x228(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x230(0x8)

	void Apply Explosion Damage(); // Function BP_Explosion.BP_Explosion_C.Apply Explosion Damage
	void UserConstructionScript(); // Function BP_Explosion.BP_Explosion_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_Explosion.BP_Explosion_C.ReceiveBeginPlay
	void BndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature(struct UParticleSystemComponent* PSystem); // Function BP_Explosion.BP_Explosion_C.BndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature
	void ExecuteUbergraph_BP_Explosion(int32_t EntryPoint); // Function BP_Explosion.BP_Explosion_C.ExecuteUbergraph_BP_Explosion
}; 



