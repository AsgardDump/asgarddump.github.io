#pragma once 
#include <BP_Planter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Planter.BP_Planter_C
// Size: 0x228(Inherited: 0x220) 
struct ABP_Planter_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)

}; 



