#pragma once 
#include "SDK.h" 
 
 
// Function BP_LobbyController.BP_LobbyController_C.ExecuteUbergraph_BP_LobbyController
// Size: 0xB0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LobbyController
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x8(0x18)
	struct UBP_EBS_SaveGame_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_DeleteGameInSlot_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UBP_GameInstance_UMSP_C* K2Node_DynamicCast_AsBP_Game_Instance_UMSP;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_2;  // 0x50(0x8)
	struct UAnimMontage* CallFunc_Array_Random_OutItem;  // 0x58(0x8)
	int32_t CallFunc_Array_Random_OutIndex;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct UBP_GameInstance_UMSP_C* K2Node_DynamicCast_AsBP_Game_Instance_UMSP_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x74(0x4)
	float CallFunc_GetInputAxisKeyValue_ReturnValue;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool Temp_bool_Variable : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x7D(0x1)
	char pad_126[2];  // 0x7E(0x2)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x80(0x18)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x98(0x18)

}; 
// Function BP_LobbyController.BP_LobbyController_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_LobbyController.BP_LobbyController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_LobbyController.BP_LobbyController_C.InpActEvt_E_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_E_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_LobbyController.BP_LobbyController_C.Get Chat Widget
// Size: 0x8(Inherited: 0x0) 
struct FGet Chat Widget
{
	struct UW_Chat_C* Chat Widget Reference;  // 0x0(0x8)

}; 
// Function BP_LobbyController.BP_LobbyController_C.InpActEvt_Delete_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Delete_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
