#pragma once 
#include <BP_EBS_Building_Door_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Door.BP_EBS_Building_Door_C
// Size: 0x4B8(Inherited: 0x479) 
struct ABP_EBS_Building_Door_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x480(0x8)
	struct USceneComponent* DoorLockSocket;  // 0x488(0x8)
	struct ABP_EBS_Building_DoorFrame_C* DoorFrameReference;  // 0x490(0x8)
	struct ABP_EBS_Building_DoorLock_C* DoorLockReference;  // 0x498(0x8)
	struct USoundBase* OpenDoorSound;  // 0x4A0(0x8)
	struct USoundBase* CloseDoorSound;  // 0x4A8(0x8)
	struct USoundBase* LockedDoorSound;  // 0x4B0(0x8)

	void IsCanInteract_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.IsCanInteract_BPI
	void GetInteractionObjectName_BPI(struct FText& Name); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.GetInteractionObjectName_BPI
	void GetInteractionText_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, struct FText& InteractionText); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.GetInteractionText_BPI
	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.GetFormatedVariables_BPI
	void GetSocketTransform(struct FName SocketName, int32_t Index, struct FTransform& Transform); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.GetSocketTransform
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.CheckSupport
	void CheckAndAttachToTarget(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.CheckAndAttachToTarget
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.GetSnapTransform
	void CheckBuildStatus(struct AActor* TargetActor, bool& CanBeBuilt); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.CheckBuildStatus
	void CheckSnap(struct AActor* TargetActor, bool& CanBeSnapped); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.CheckSnap
	void CompleteInteractionNotify_BPI(struct APlayerController* PlayerController, struct FName NotifyName); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.CompleteInteractionNotify_BPI
	void TryInteract_BPI(bool Released, struct FKey InteractionKey, struct APlayerController* PlayerController); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.TryInteract_BPI
	void PlayCloseDoorSound (Multicast)(); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.PlayCloseDoorSound (Multicast)
	void PlayOpenDoorSound (Multicast)(); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.PlayOpenDoorSound (Multicast)
	void PlayLockedSound (Multicast)(); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.PlayLockedSound (Multicast)
	void ExecuteUbergraph_BP_EBS_Building_Door(int32_t EntryPoint); // Function BP_EBS_Building_Door.BP_EBS_Building_Door_C.ExecuteUbergraph_BP_EBS_Building_Door
}; 



