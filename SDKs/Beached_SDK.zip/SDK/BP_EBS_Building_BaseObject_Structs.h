#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckRotate
// Size: 0xA(Inherited: 0x0) 
struct FCheckRotate
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckBuildCollisions
// Size: 0x6C(Inherited: 0x0) 
struct FCheckBuildCollisions
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool NotBlocked : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_Cupboard_C* L_Cupboard;  // 0x10(0x8)
	struct AActor* LocalActor;  // 0x18(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_BuildingObjectInSocket_InSocket : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BuildingObjectInSocket_InSocket_2 : 1;  // 0x32(0x1)
	char pad_51[5];  // 0x33(0x5)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_CheckActorCollisions_NotBlocked : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x5A(0x1)
	char pad_91[1];  // 0x5B(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x5C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x68(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ExecuteUbergraph_BP_EBS_Building_BaseObject
// Size: 0x15C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_Building_BaseObject
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x20(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x50(0x8)
	struct ABP_EBS_DestructibleObject_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x58(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x60(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x6C(0xC)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DestroyBuildComponents_Success : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x7C(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_5;  // 0x88(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x94(0xC)
	struct FHitResult CallFunc_K2_AddActorWorldRotation_SweepHitResult;  // 0xA0(0x8C)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool CallFunc_CompleteRemove_Success : 1;  // 0x12C(0x1)
	char pad_301_1 : 7;  // 0x12D(0x1)
	bool CallFunc_CreateSocketTransforms_Success : 1;  // 0x12D(0x1)
	char pad_302[2];  // 0x12E(0x2)
	float K2Node_Event_Damage;  // 0x130(0x4)
	char pad_308[4];  // 0x134(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x138(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x140(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_CheckAndAttachToTarget_Success : 1;  // 0x151(0x1)
	char pad_338[2];  // 0x152(0x2)
	float CallFunc_GetGlobalDestructChunksLifeTime_StepValue;  // 0x154(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x158(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetMaxDurability_BPI
// Size: 0xC(Inherited: 0x0) 
struct FSetMaxDurability_BPI
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRemove
// Size: 0x68(Inherited: 0x0) 
struct FCompleteRemove
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Destruct : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Success : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct APlayerController* LocalPlayerController;  // 0x10(0x8)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> LocalOverlappingObject;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool LocalDestruct : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_CompleteDestruction_Success : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_CheckSupport_HasSupport : 1;  // 0x45(0x1)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x46(0x1)
	char pad_71_1 : 7;  // 0x47(0x1)
	bool CallFunc_CompleteRemove_Success : 1;  // 0x47(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_RemoveAttachedObjects_Success : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> CallFunc_Get_Snapped_Objects_OverlappingObjects;  // 0x58(0x10)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.Get Snapped Objects
// Size: 0x1B8(Inherited: 0x0) 
struct FGet Snapped Objects
{
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> OverlappingObjects;  // 0x0(0x10)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> LocalOverlappingObjects;  // 0x10(0x10)
	char ECollisionResponse LocalResponce;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x24(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x28(0x10)
	struct ABP_Cupboard_C* K2Node_DynamicCast_AsBP_Cupboard;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_ComponentHasTag_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x48(0x10)
	struct FVector CallFunc_GetActorBounds_Origin;  // 0x58(0xC)
	struct FVector CallFunc_GetActorBounds_BoxExtent;  // 0x64(0xC)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x70(0x4)
	struct FVector CallFunc_Add_VectorFloat_ReturnValue;  // 0x74(0xC)
	struct TArray<struct FHitResult> CallFunc_BoxTraceMultiForObjects_OutHits;  // 0x80(0x10)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_BoxTraceMultiForObjects_ReturnValue : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x94(0x4)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x98(0x8C)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x124(0x1)
	char pad_293_1 : 7;  // 0x125(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x125(0x1)
	char pad_294[2];  // 0x126(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x128(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x12C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x130(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x13C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x148(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x154(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x160(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x168(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x170(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x178(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x180(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x184(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x188(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x194(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1A0(0x4)
	char pad_420[4];  // 0x1A4(0x4)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1B0(0x1)
	char pad_433_1 : 7;  // 0x1B1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1B1(0x1)
	char pad_434[2];  // 0x1B2(0x2)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x1B4(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetFloorNumber_BPI
// Size: 0x5(Inherited: 0x0) 
struct FSetFloorNumber_BPI
{
	int32_t FloorNumber;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.UserConstructionScript
// Size: 0x1C1(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult;  // 0x34(0x8C)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_EqualEqual_TransformTransform_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0xC2(0x1)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC3(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xC4(0x1)
	char pad_197[11];  // 0xC5(0xB)
	struct FSTR_EBS_BuildingObjectSettings CallFunc_GetDataTableRowFromName_OutRow;  // 0xD0(0xF0)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x1C0(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckAndAttachToTarget
// Size: 0x1A(Inherited: 0x0) 
struct FCheckAndAttachToTarget
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_SetFloorNumberByTargetActor_Success : 1;  // 0x19(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckSnap
// Size: 0x3C(Inherited: 0x0) 
struct FCheckSnap
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CanBeSnapped : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x1C(0x4)
	struct FSTR_EBS_SnapSettings CallFunc_Array_Get_Item;  // 0x20(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x35(0x1)
	char pad_54[2];  // 0x36(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckBuildStatus
// Size: 0x60(Inherited: 0x0) 
struct FCheckBuildStatus
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CanBeBuilt : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_Cupboard_C* L_Cupboard;  // 0x10(0x8)
	int32_t LocalCount;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x24(0x4)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_CheckSupport_HasSupport : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AActor* CallFunc_Array_Get_Item;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_CheckBuildCollisions_NotBlocked : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_ActorIsLandscape_Result : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x50(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x5C(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetFloorWorldZ
// Size: 0x70(Inherited: 0x0) 
struct FGetFloorWorldZ
{
	float ValueZ;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform CallFunc_GetSocketTransform_Transform;  // 0x10(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x40(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x4C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x58(0xC)
	float CallFunc_BreakVector_X;  // 0x64(0x4)
	float CallFunc_BreakVector_Y;  // 0x68(0x4)
	float CallFunc_BreakVector_Z;  // 0x6C(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSnapTransform
// Size: 0x110(Inherited: 0x0) 
struct FGetSnapTransform
{
	struct AActor* TargetActor;  // 0x0(0x8)
	float InputRotation;  // 0x8(0x4)
	struct FVector HitLocation;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool GridMode : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool SnapNear : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FTransform ReturnTransform;  // 0x20(0x30)
	struct ABP_EBS_Building_BaseObject_C* LocalTargetObject;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool LocalSnapNear : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FVector LocalHitLocation;  // 0x5C(0xC)
	float LocalInputRotation;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float CallFunc_GetGlobalBuildingRotationStep_StepValue;  // 0x7C(0x4)
	struct FTransform CallFunc_GetNearestSocketTransform_ResultTransform;  // 0x80(0x30)
	struct TArray<struct FTransform> CallFunc_GetSocketTransforms_SocketTransforms;  // 0xB0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC0(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xC4(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0xC8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xCC(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0xD0(0x4)
	char pad_212[12];  // 0xD4(0xC)
	struct FTransform CallFunc_GetSocketTransform_Transform;  // 0xE0(0x30)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.InitSaveID_BPI
// Size: 0x22(Inherited: 0x0) 
struct FInitSaveID_BPI
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_InitActor_BPI_Success : 1;  // 0x21(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckActorCollisions
// Size: 0x58(Inherited: 0x0) 
struct FCheckActorCollisions
{
	struct AActor* Actor;  // 0x0(0x8)
	struct UPrimitiveComponent* BuildCollision;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool NotBlocked : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetOverlappingComponents_OutOverlappingComponents;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_ActorHasTag_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x38(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x48(0x1)
	char ECollisionChannel CallFunc_GetCollisionObjectType_ReturnValue;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4C(0x4)
	char ECollisionResponse CallFunc_GetCollisionResponseToChannel_ReturnValue;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x52(0x1)
	char pad_83[1];  // 0x53(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x54(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetStartBuildCollisionResponse
// Size: 0x4D(Inherited: 0x0) 
struct FSetStartBuildCollisionResponse
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	int32_t Temp_int_Variable_2;  // 0x4(0x4)
	char CallFunc_Conv_IntToByte_ReturnValue;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char CallFunc_GetValidValue_ReturnValue;  // 0x10(0x1)
	char CallFunc_Conv_IntToByte_ReturnValue_2;  // 0x11(0x1)
	char CallFunc_GetEnumeratorValueFromIndex_ReturnValue;  // 0x12(0x1)
	char pad_19[1];  // 0x13(0x1)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x20(0x4)
	int32_t CallFunc_MakeLiteralInt_ReturnValue;  // 0x24(0x4)
	struct TArray<struct UPrimitiveComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x40(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x4C(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteUpgrade
// Size: 0x21(Inherited: 0x0) 
struct FCompleteUpgrade
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckSupport
// Size: 0x80(Inherited: 0x0) 
struct FCheckSupport
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool HasSupport : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> CallFunc_Get_Snapped_Objects_OverlappingObjects;  // 0x18(0x10)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_BuildingObjectInSocket_InSocket : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item_2;  // 0x50(0x8)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_ActorsHaveLandscape_Result : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x7C(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.OnRep_BuildingObjectHandle
// Size: 0x1C1(Inherited: 0x0) 
struct FOnRep_BuildingObjectHandle
{
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult;  // 0x34(0x8C)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_EqualEqual_TransformTransform_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0xC2(0x1)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC3(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xC4(0x1)
	char pad_197[11];  // 0xC5(0xB)
	struct FSTR_EBS_BuildingObjectSettings CallFunc_GetDataTableRowFromName_OutRow;  // 0xD0(0xF0)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x1C0(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetNearestTransform
// Size: 0x18D(Inherited: 0x0) 
struct FGetNearestTransform
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FTransform> Transforms;  // 0x10(0x10)
	struct FTransform ResultTransform;  // 0x20(0x30)
	struct FTransform LocalSelectedTransform;  // 0x50(0x30)
	float LocalSelectedLength;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct TArray<struct FTransform> LocalTransforms;  // 0x88(0x10)
	struct FVector LocalLocation;  // 0x98(0xC)
	int32_t Temp_int_Array_Index_Variable;  // 0xA4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xA8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xAC(0x4)
	struct FTransform CallFunc_Array_Get_Item;  // 0xB0(0x30)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FVector CallFunc_BreakTransform_Location;  // 0xE4(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0xF0(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0xFC(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x108(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x114(0x4)
	char pad_280[8];  // 0x118(0x8)
	struct FTransform CallFunc_Array_Get_Item_2;  // 0x120(0x30)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x150(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x15C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x168(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x174(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0x178(0xC)
	char pad_388_1 : 7;  // 0x184(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x184(0x1)
	char pad_389[3];  // 0x185(0x3)
	float CallFunc_VSize_ReturnValue_2;  // 0x188(0x4)
	char pad_396_1 : 7;  // 0x18C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x18C(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualSnapAndRotatePrev
// Size: 0x14(Inherited: 0x0) 
struct FManualSnapAndRotatePrev
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float K2Node_Select_Default;  // 0x10(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSocketTransform
// Size: 0x90(Inherited: 0x0) 
struct FGetSocketTransform
{
	struct FName SocketName;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform Transform;  // 0x10(0x30)
	struct TArray<struct FTransform> CallFunc_GetSocketTransforms_SocketTransforms;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[15];  // 0x51(0xF)
	struct FTransform CallFunc_Array_Get_Item;  // 0x60(0x30)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.BuildingObjectInSocket
// Size: 0xE4(Inherited: 0x0) 
struct FBuildingObjectInSocket
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool InSocket : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector LocalLocation;  // 0xC(0xC)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1C(0xC)
	struct TArray<struct USceneComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x28(0x10)
	struct TArray<struct FTransform> CallFunc_GetSocketTransforms_SocketTransforms;  // 0x38(0x10)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x54(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x60(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x6C(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x70(0x4)
	char pad_116[12];  // 0x74(0xC)
	struct FTransform CallFunc_Array_Get_Item_2;  // 0x80(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0xB0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0xBC(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0xC8(0xC)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue_2 : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xD8(0x4)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xE0(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckClaim
// Size: 0xE6(Inherited: 0x0) 
struct FCheckClaim
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Result : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_Cupboard_C* L_Cupboard;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool LocalNotClaimed : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct APlayerController* LocalPlayer;  // 0x20(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Is_Parental_Cupboard_Return : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct ABP_Cupboard_C* CallFunc_Is_Parental_Cupboard_Cupboard;  // 0x30(0x8)
	struct TScriptInterface<IBPI_EBS_Ownership_C> K2Node_DynamicCast_AsBPI_EBS_Ownership;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_GetOwnershipInfo_BPI_IsOwned : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct TArray<struct FString> CallFunc_GetOwnershipInfo_BPI_OwnerNames;  // 0x50(0x10)
	float CallFunc_GetOwnershipInfo_BPI_OwnershipDistance;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FString CallFunc_GetPlayerID_PlayerID;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x79(0x1)
	char pad_122[2];  // 0x7A(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x7C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x88(0x10)
	struct FString CallFunc_GetPlayerID_PlayerID_2;  // 0x98(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0xA8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct TScriptInterface<IBPI_EBS_Ownership_C> K2Node_DynamicCast_AsBPI_EBS_Ownership_2;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool CallFunc_GetOwnershipInfo_BPI_IsOwned_2 : 1;  // 0xCA(0x1)
	char pad_203[5];  // 0xCB(0x5)
	struct TArray<struct FString> CallFunc_GetOwnershipInfo_BPI_OwnerNames_2;  // 0xD0(0x10)
	float CallFunc_GetOwnershipInfo_BPI_OwnershipDistance_2;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0xE4(0x1)
	char pad_229_1 : 7;  // 0xE5(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_2 : 1;  // 0xE5(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CreateSocketTransforms
// Size: 0x68(Inherited: 0x0) 
struct FCreateSocketTransforms
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct FSTR_EBS_SnapSettings CallFunc_Array_Get_Item;  // 0x8(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	struct TArray<struct FTransform> CallFunc_MakeSocketTransformsPrimitive_Transforms;  // 0x18(0x10)
	struct TArray<struct FTransform> CallFunc_MakeSocketTransforms_Transforms;  // 0x28(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct TArray<struct FTransform> K2Node_Select_Default;  // 0x40(0x10)
	struct FSTR_EBS_SocketTransforms K2Node_MakeStruct_STR_EBS_SocketTransforms;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x64(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.DestroyBuildComponents
// Size: 0x30(Inherited: 0x0) 
struct FDestroyBuildComponents
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x8(0x10)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x18(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2C(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetFloorNumberByTargetActor
// Size: 0x19(Inherited: 0x0) 
struct FSetFloorNumberByTargetActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckOwnership
// Size: 0x9D(Inherited: 0x0) 
struct FCheckOwnership
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Result : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerController* LocalPlayer;  // 0x10(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x28(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct TScriptInterface<IBPI_EBS_Ownership_C> K2Node_DynamicCast_AsBPI_EBS_Ownership;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_CheckPlayerIsOwner_BPI_IsOwner : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x5B(0x1)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_GetPlayerID_PlayerID;  // 0x60(0x10)
	struct TScriptInterface<IBPI_EBS_Ownership_C> K2Node_DynamicCast_AsBPI_EBS_Ownership_2;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_2 : 1;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool CallFunc_GetOwnershipInfo_BPI_IsOwned : 1;  // 0x82(0x1)
	char pad_131[5];  // 0x83(0x5)
	struct TArray<struct FString> CallFunc_GetOwnershipInfo_BPI_OwnerNames;  // 0x88(0x10)
	float CallFunc_GetOwnershipInfo_BPI_OwnershipDistance;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x9C(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckRepair
// Size: 0x1B(Inherited: 0x0) 
struct FCheckRepair
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Result : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerController* LocalPlayerController;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_CheckClaim_Result : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_CheckRepairRequirements_Result : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckRepairRequirements
// Size: 0x23(Inherited: 0x0) 
struct FCheckRepairRequirements
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Result : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValidHandle_IsValid : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_CheckRequirements_BPI_Success : 1;  // 0x22(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.MakeSocketTransforms
// Size: 0x90(Inherited: 0x0) 
struct FMakeSocketTransforms
{
	struct FName SocketName;  // 0x0(0x8)
	struct TArray<struct FTransform> Transforms;  // 0x8(0x10)
	struct TArray<struct FTransform> LocalTransforms;  // 0x18(0x10)
	struct TArray<struct USceneComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x28(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x38(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x50(0x30)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x88(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x8C(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualSnapToTarget
// Size: 0xCF(Inherited: 0x0) 
struct FManualSnapToTarget
{
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_CreateSocketTransforms_Success : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_SetFloorNumberByTargetActor_Success : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_CheckAndAttachToTarget_Success : 1;  // 0xF(0x1)
	struct FTransform CallFunc_GetSnapTransform_ReturnTransform;  // 0x10(0x30)
	struct FHitResult CallFunc_K2_SetActorTransform_SweepHitResult;  // 0x40(0x8C)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_K2_SetActorTransform_ReturnValue : 1;  // 0xCC(0x1)
	char pad_205_1 : 7;  // 0xCD(0x1)
	bool CallFunc_CreateSocketTransforms_Success_2 : 1;  // 0xCD(0x1)
	char pad_206_1 : 7;  // 0xCE(0x1)
	bool CallFunc_CheckSnap_CanBeSnapped : 1;  // 0xCE(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRepair
// Size: 0x30(Inherited: 0x0) 
struct FCompleteRepair
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x28(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x2C(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckUpgrade
// Size: 0xB(Inherited: 0x0) 
struct FCheckUpgrade
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_CheckUpgradeRequirements_Success : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsValidHandle_IsValid : 1;  // 0xA(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckUpgradeRequirements
// Size: 0x23(Inherited: 0x0) 
struct FCheckUpgradeRequirements
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValidHandle_IsValid : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_CheckRequirements_BPI_Success : 1;  // 0x22(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.LoadData_BPI
// Size: 0x90(Inherited: 0x0) 
struct FLoadData_BPI
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct USaveGame* LocalSaveGame;  // 0x10(0x8)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_GetBuildingSaveData_BPI_Success : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct FSTR_EBS_SaveData_BuildingObject CallFunc_GetBuildingSaveData_BPI_SaveData;  // 0x30(0x60)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.RemoveAttachedObjects
// Size: 0x2(Inherited: 0x0) 
struct FRemoveAttachedObjects
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Destruct : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteDestruction
// Size: 0xA(Inherited: 0x0) 
struct FCompleteDestruction
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRotate
// Size: 0x9(Inherited: 0x0) 
struct FCompleteRotate
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualSnapAndRotateNext
// Size: 0x14(Inherited: 0x0) 
struct FManualSnapAndRotateNext
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float K2Node_Select_Default;  // 0x10(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ChangeDurability_BPI
// Size: 0x1C(Inherited: 0x0) 
struct FChangeDurability_BPI
{
	char E_EBS_ChangeVariableOperation Operation;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Value;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char E_EBS_ChangeVariableOperation Temp_byte_Variable;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x10(0x4)
	float K2Node_Select_Default;  // 0x14(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x18(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualRotate
// Size: 0x2(Inherited: 0x0) 
struct FManualRotate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_CompleteRotate_Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetFloorNumber_BPI
// Size: 0x4(Inherited: 0x0) 
struct FGetFloorNumber_BPI
{
	int32_t FloorNumber;  // 0x0(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.MakeSocketTransformsPrimitive
// Size: 0xC8(Inherited: 0x0) 
struct FMakeSocketTransformsPrimitive
{
	struct UPrimitiveComponent* PrimitiveComponent;  // 0x0(0x8)
	struct FName SocketName;  // 0x8(0x8)
	int32_t Amount;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FTransform> Transforms;  // 0x18(0x10)
	struct UPrimitiveComponent* LocalPrimitiveComponent;  // 0x28(0x8)
	struct FName LocalSocketName;  // 0x30(0x8)
	struct TArray<struct FTransform> LocalTransforms;  // 0x38(0x10)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x48(0x4)
	int32_t Temp_int_Variable;  // 0x4C(0x4)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x84(0x8)
	char pad_140[4];  // 0x8C(0x4)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x90(0x30)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xC4(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSocketTransforms
// Size: 0x29(Inherited: 0x0) 
struct FGetSocketTransforms
{
	struct FName SocketName;  // 0x0(0x8)
	struct TArray<struct FTransform> SocketTransforms;  // 0x8(0x10)
	struct FSTR_EBS_SocketTransforms CallFunc_Map_Find_Value;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetNearestSocketTransform
// Size: 0xF0(Inherited: 0x0) 
struct FGetNearestSocketTransform
{
	struct FVector Location;  // 0x0(0xC)
	struct FName SocketName;  // 0xC(0x8)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform ResultTransform;  // 0x20(0x30)
	struct FTransform LocalSelectedTransform;  // 0x50(0x30)
	float LocalSelectedLength;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct TArray<struct FTransform> LocalTransforms;  // 0x88(0x10)
	struct FVector LocalLocation;  // 0x98(0xC)
	char pad_164[4];  // 0xA4(0x4)
	struct TArray<struct FTransform> CallFunc_GetSocketTransforms_SocketTransforms;  // 0xA8(0x10)
	char pad_184[8];  // 0xB8(0x8)
	struct FTransform CallFunc_GetNearestTransform_ResultTransform;  // 0xC0(0x30)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetDurability_BPI
// Size: 0x8(Inherited: 0x0) 
struct FGetDurability_BPI
{
	float CurrentValue;  // 0x0(0x4)
	float MaxValue;  // 0x4(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteBuild
// Size: 0x9(Inherited: 0x0) 
struct FCompleteBuild
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetFloorActorHidden_BPI
// Size: 0x2(Inherited: 0x0) 
struct FSetFloorActorHidden_BPI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewHidden : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Success : 1;  // 0x1(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.Find Cupboard
// Size: 0x171(Inherited: 0x0) 
struct FFind Cupboard
{
	struct ABP_Cupboard_C* Return;  // 0x0(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x10(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x28(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x3C(0xC)
	struct TArray<struct FHitResult> CallFunc_SphereTraceMultiForObjects_OutHits;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_SphereTraceMultiForObjects_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x5C(0x4)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x60(0x8C)
	char pad_236_1 : 7;  // 0xEC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xEC(0x1)
	char pad_237_1 : 7;  // 0xED(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xED(0x1)
	char pad_238_1 : 7;  // 0xEE(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xEE(0x1)
	char pad_239[1];  // 0xEF(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xF0(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xF4(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xF8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x104(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x110(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x11C(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x128(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x130(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x138(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x140(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x148(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x14C(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x150(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x15C(0xC)
	struct ABP_Cupboard_C* K2Node_DynamicCast_AsBP_Cupboard;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x170(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SaveData_BPI
// Size: 0x161(Inherited: 0x0) 
struct FSaveData_BPI
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct USaveGame* LocalSaveGame;  // 0x10(0x8)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game_2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TArray<struct FString> CallFunc_GetFormatedVariables_BPI_FormatedVariables;  // 0x48(0x10)
	char pad_88[8];  // 0x58(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x60(0x30)
	ABP_EBS_Building_BaseObject_C* CallFunc_GetObjectClass_ReturnValue;  // 0x90(0x8)
	char pad_152[8];  // 0x98(0x8)
	struct FSTR_EBS_SaveData_Actor K2Node_MakeStruct_STR_EBS_SaveData_Actor;  // 0xA0(0x50)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_SetActorSaveData_BPI_Success : 1;  // 0xF0(0x1)
	char pad_241[15];  // 0xF1(0xF)
	struct FSTR_EBS_SaveData_BuildingObject K2Node_MakeStruct_STR_EBS_SaveData_BuildingObject;  // 0x100(0x60)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_SetBuildingSaveData_BPI_Success : 1;  // 0x160(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.Is Parental Cupboard
// Size: 0x20C(Inherited: 0x0) 
struct FIs Parental Cupboard
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Return : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_Cupboard_C* Cupboard;  // 0x8(0x8)
	struct ABP_Cupboard_C* L Cupboard;  // 0x10(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x20(0x8)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue;  // 0x28(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x40(0x10)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x50(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x5C(0xC)
	struct FVector CallFunc_BreakTransform_Location;  // 0x68(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x74(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x80(0xC)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x8C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x98(0xC)
	char pad_164[4];  // 0xA4(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0xA8(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct TArray<struct FHitResult> CallFunc_BoxTraceMultiForObjects_OutHits;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_BoxTraceMultiForObjects_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	struct FHitResult CallFunc_Array_Get_Item;  // 0xD4(0x8C)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x160(0x4)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x164(0x1)
	char pad_357_1 : 7;  // 0x165(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x165(0x1)
	char pad_358[2];  // 0x166(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x168(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x16C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x170(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x17C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x188(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x194(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x1A0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x1A8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x1B0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x1B8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x1C0(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x1C4(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x1C8(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x1D4(0xC)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct ABP_Cupboard_C* K2Node_DynamicCast_AsBP_Cupboard;  // 0x1E8(0x8)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1F0(0x1)
	char pad_497[3];  // 0x1F1(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x1F4(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x200(0x4)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x204(0x1)
	char pad_517_1 : 7;  // 0x205(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x205(0x1)
	char pad_518[2];  // 0x206(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x208(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetSaveID_BPI
// Size: 0x5(Inherited: 0x0) 
struct FSetSaveID_BPI
{
	int32_t SaveID;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSaveID_BPI
// Size: 0x4(Inherited: 0x0) 
struct FGetSaveID_BPI
{
	int32_t SaveID;  // 0x0(0x4)

}; 
// Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetFormatedVariables_BPI
// Size: 0x10(Inherited: 0x0) 
struct FGetFormatedVariables_BPI
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)

}; 
