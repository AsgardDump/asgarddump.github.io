#pragma once 
#include <BP_Holdable_MeeleWeapon_OneHanded_Machette_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_OneHanded_Machette.BP_Holdable_MeeleWeapon_OneHanded_Machette_C
// Size: 0x329(Inherited: 0x329) 
struct ABP_Holdable_MeeleWeapon_OneHanded_Machette_C : public ABP_Holdable_MeeleWeapon_OneHanded_C
{

}; 



