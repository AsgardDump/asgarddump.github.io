#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_RoofWall_Top.BP_EBS_Building_RoofWall_Top_C.GetSnapTransform
// Size: 0x140(Inherited: 0x110) 
struct FGetSnapTransform : public FGetSnapTransform
{
	struct AActor* TargetActor;  // 0x0(0x8)
	float InputRotation;  // 0x8(0x4)
	struct FVector HitLocation;  // 0xC(0xC)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool GridMode : 1;  // 0x18(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool SnapNear : 1;  // 0x19(0x1)
	struct FTransform ReturnTransform;  // 0x20(0x30)
	struct FTransform CallFunc_GetSnapTransform_ReturnTransform;  // 0x50(0x30)
	char pad_394_1 : 7;  // 0x18A(0x1)
	bool Temp_bool_Variable : 1;  // 0x80(0x1)
	struct FVector CallFunc_BreakTransform_Location;  // 0x84(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x90(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x9C(0xC)
	float CallFunc_GetGlobalBuildingRotationStep_StepValue;  // 0xA8(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xAC(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0xB0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xB4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xB8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xBC(0xC)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0xC8(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xE0(0x30)
	struct FTransform K2Node_Select_Default;  // 0x110(0x30)

}; 
// Function BP_EBS_Building_RoofWall_Top.BP_EBS_Building_RoofWall_Top_C.SetFloorNumberByTargetActor
// Size: 0x20(Inherited: 0x19) 
struct FSetFloorNumberByTargetActor : public FSetFloorNumberByTargetActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_SetFloorNumberByTargetActor_Success : 1;  // 0x9(0x1)
	struct ABP_EBS_Building_Wall_C* K2Node_DynamicCast_AsBP_EBS_Building_Wall;  // 0x10(0x8)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)

}; 
// Function BP_EBS_Building_RoofWall_Top.BP_EBS_Building_RoofWall_Top_C.BuildingObjectInSocket
// Size: 0x140(Inherited: 0xE4) 
struct FBuildingObjectInSocket : public FBuildingObjectInSocket
{
	struct ABP_EBS_Building_BaseObject_C* TargetObject;  // 0x0(0x8)
	char pad_236_1 : 7;  // 0xEC(0x1)
	bool InSocket : 1;  // 0x8(0x1)
	struct FTransform LocalTransform;  // 0x10(0x30)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x50(0x30)
	struct TArray<struct USceneComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x80(0x10)
	struct TArray<struct FTransform> CallFunc_GetSocketTransforms_SocketTransforms;  // 0x90(0x10)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0xA0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA8(0x4)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0xB0(0x30)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xE0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xE4(0x4)
	char pad_437_1 : 7;  // 0x1B5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xE8(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xEC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xF0(0x4)
	struct FTransform CallFunc_Array_Get_Item_2;  // 0x100(0x30)
	char pad_494_1 : 7;  // 0x1EE(0x1)
	bool CallFunc_NearlyEqualTransforms_ReturnValue : 1;  // 0x130(0x1)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x134(0x4)
	char pad_499_1 : 7;  // 0x1F3(0x1)
	bool CallFunc_NearlyEqualTransforms_ReturnValue_2 : 1;  // 0x138(0x1)
	char pad_500_1 : 7;  // 0x1F4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x139(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x13C(0x4)

}; 
