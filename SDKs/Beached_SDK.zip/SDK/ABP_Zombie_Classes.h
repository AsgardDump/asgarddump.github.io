#pragma once 
#include <ABP_Zombie_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Zombie.ABP_Zombie_C
// Size: 0x42C(Inherited: 0x2C0) 
struct UABP_Zombie_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x2F8(0xE8)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x3E0(0x48)
	float Speed;  // 0x428(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Zombie.ABP_Zombie_C.AnimGraph
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Zombie.ABP_Zombie_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_Zombie(int32_t EntryPoint); // Function ABP_Zombie.ABP_Zombie_C.ExecuteUbergraph_ABP_Zombie
}; 



