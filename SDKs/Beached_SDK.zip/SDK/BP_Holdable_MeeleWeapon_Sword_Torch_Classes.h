#pragma once 
#include <BP_Holdable_MeeleWeapon_Sword_Torch_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_Sword_Torch.BP_Holdable_MeeleWeapon_Sword_Torch_C
// Size: 0x348(Inherited: 0x329) 
struct ABP_Holdable_MeeleWeapon_Sword_Torch_C : public ABP_Holdable_MeeleWeapon_OneHanded_C
{
	char pad_809[7];  // 0x329(0x7)
	struct UParticleSystemComponent* P_TorchFire;  // 0x330(0x8)
	struct UAudioComponent* WAV_FireLoop_Cue;  // 0x338(0x8)
	struct UPointLightComponent* PointLight;  // 0x340(0x8)

}; 



