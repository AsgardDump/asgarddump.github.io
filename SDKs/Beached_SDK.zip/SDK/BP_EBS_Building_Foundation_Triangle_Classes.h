#pragma once 
#include <BP_EBS_Building_Foundation_Triangle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Foundation_Triangle.BP_EBS_Building_Foundation_Triangle_C
// Size: 0x560(Inherited: 0x479) 
struct ABP_EBS_Building_Foundation_Triangle_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct USceneComponent* FloorSocket;  // 0x480(0x8)
	struct USceneComponent* RampSockets;  // 0x488(0x8)
	struct USceneComponent* WallSockets;  // 0x490(0x8)
	struct USceneComponent* TriangleFoundationSockets;  // 0x498(0x8)
	struct USceneComponent* FoundationSockets;  // 0x4A0(0x8)
	struct USceneComponent* BuildCollisions;  // 0x4A8(0x8)
	struct USceneComponent* BuildComponents;  // 0x4B0(0x8)
	struct USceneComponent* RampSocket3;  // 0x4B8(0x8)
	struct USceneComponent* RampSocket2;  // 0x4C0(0x8)
	struct USceneComponent* RampSocket1;  // 0x4C8(0x8)
	struct USceneComponent* WallSocket3;  // 0x4D0(0x8)
	struct USceneComponent* WallSocket2;  // 0x4D8(0x8)
	struct USceneComponent* WallSocket1;  // 0x4E0(0x8)
	struct USceneComponent* TriangleFoundationSocket3;  // 0x4E8(0x8)
	struct USceneComponent* TriangleFoundationSocket2;  // 0x4F0(0x8)
	struct USceneComponent* TriangleFoundationSocket1;  // 0x4F8(0x8)
	struct USceneComponent* FoundationSocket3;  // 0x500(0x8)
	struct USceneComponent* FoundationSocket2;  // 0x508(0x8)
	struct USceneComponent* FoundationSocket1;  // 0x510(0x8)
	struct UBoxComponent* BuildCollision6;  // 0x518(0x8)
	struct UBoxComponent* BuildCollision5;  // 0x520(0x8)
	struct UBoxComponent* BuildCollision4;  // 0x528(0x8)
	struct UBoxComponent* BuildCollision3;  // 0x530(0x8)
	struct UBoxComponent* BuildCollision2;  // 0x538(0x8)
	struct UBoxComponent* BuildCollision1;  // 0x540(0x8)
	struct UBoxComponent* LandscapeChecker3;  // 0x548(0x8)
	struct UBoxComponent* LandscapeChecker2;  // 0x550(0x8)
	struct UBoxComponent* LandscapeChecker1;  // 0x558(0x8)

}; 



