#pragma once 
#include <AN_DequipCall_Structs.h>
 
 
 
// BlueprintGeneratedClass AN_DequipCall.AN_DequipCall_C
// Size: 0x38(Inherited: 0x38) 
struct UAN_DequipCall_C : public UAnimNotify
{

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AN_DequipCall.AN_DequipCall_C.Received_Notify
}; 



