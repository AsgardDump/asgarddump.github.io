#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.GetBuildingSaveData_BPI
// Size: 0xD1(Inherited: 0x0) 
struct FGetBuildingSaveData_BPI
{
	int32_t SaveID;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FSTR_EBS_SaveData_BuildingObject SaveData;  // 0x10(0x60)
	struct FSTR_EBS_SaveData_BuildingObject CallFunc_Map_Find_Value;  // 0x70(0x60)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xD0(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.GetActorSaveData_BPI
// Size: 0xB1(Inherited: 0x0) 
struct FGetActorSaveData_BPI
{
	int32_t SaveID;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FSTR_EBS_SaveData_Actor SaveData;  // 0x10(0x50)
	struct FSTR_EBS_SaveData_Actor CallFunc_Map_Find_Value;  // 0x60(0x50)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xB0(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.ClearTemporaryData_BPI
// Size: 0x1(Inherited: 0x0) 
struct FClearTemporaryData_BPI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SetBuildingSaveData_BPI
// Size: 0x71(Inherited: 0x0) 
struct FSetBuildingSaveData_BPI
{
	int32_t SaveID;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FSTR_EBS_SaveData_BuildingObject SaveData;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Success : 1;  // 0x70(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SetActorSaveData_BPI
// Size: 0x61(Inherited: 0x0) 
struct FSetActorSaveData_BPI
{
	int32_t SaveID;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FSTR_EBS_SaveData_Actor SaveData;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Success : 1;  // 0x60(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.InitActor_BPI
// Size: 0x30(Inherited: 0x0) 
struct FInitActor_BPI
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t LocalSaveID;  // 0xC(0x4)
	struct AActor* LocalActor;  // 0x10(0x8)
	struct TScriptInterface<IBPI_EBS_SaveObject_C> K2Node_DynamicCast_AsBPI_EBS_Save_Object;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_SetSaveID_BPI_Success : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t CallFunc_Map_Length_ReturnValue;  // 0x2C(0x4)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.LoadTemporaryData_BPI
// Size: 0xA9(Inherited: 0x0) 
struct FLoadTemporaryData_BPI
{
	struct FSTR_EBS_SaveData_Level LevelData;  // 0x0(0xA8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool Success : 1;  // 0xA8(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SaveGameToSlot_BPI
// Size: 0x12(Inherited: 0x0) 
struct FSaveGameToSlot_BPI
{
	struct FString SlotName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_SaveGame_BPI_Success : 1;  // 0x11(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SaveLevelData_BPI
// Size: 0x230(Inherited: 0x0) 
struct FSaveLevelData_BPI
{
	struct FName LevelName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FSTR_EBS_SaveData_Level LocalLevelData;  // 0x10(0xA8)
	int32_t Temp_int_Array_Index_Variable;  // 0xB8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_SaveGame_BPI_Success : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_SaveGame_BPI_Success_2 : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct FSTR_EBS_SaveData_Level CallFunc_Array_Get_Item;  // 0xD0(0xA8)
	struct FSTR_EBS_SaveData_Level K2Node_MakeStruct_STR_EBS_SaveData_Level;  // 0x178(0xA8)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x220(0x1)
	char pad_545[3];  // 0x221(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x224(0x4)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x228(0x1)
	char pad_553[3];  // 0x229(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x22C(0x4)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.LoadLevelData_BPI
// Size: 0x17F(Inherited: 0x0) 
struct FLoadLevelData_BPI
{
	struct FName LevelName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FSTR_EBS_SaveData_Level LevelData;  // 0x10(0xA8)
	struct FName LocalLevelName;  // 0xB8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0xC0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct FSTR_EBS_SaveData_Level CallFunc_Array_Get_Item;  // 0xD0(0xA8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x178(0x4)
	char pad_380_1 : 7;  // 0x17C(0x1)
	bool CallFunc_LoadTemporaryData_BPI_Success : 1;  // 0x17C(0x1)
	char pad_381_1 : 7;  // 0x17D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x17D(0x1)
	char pad_382_1 : 7;  // 0x17E(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x17E(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.GetSavedActor_BPI
// Size: 0x19(Inherited: 0x0) 
struct FGetSavedActor_BPI
{
	int32_t SaveID;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Success : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AActor* Actor;  // 0x8(0x8)
	struct AActor* CallFunc_Map_Find_Value;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.SaveGame_BPI
// Size: 0x1(Inherited: 0x0) 
struct FSaveGame_BPI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_EBS_SaveGame.BP_EBS_SaveGame_C.InitActorWithSaveID_BPI
// Size: 0x32(Inherited: 0x0) 
struct FInitActorWithSaveID_BPI
{
	struct AActor* Actor;  // 0x0(0x8)
	int32_t SaveID;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Success : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t LocalSaveID;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct AActor* LocalActor;  // 0x18(0x8)
	struct TScriptInterface<IBPI_EBS_SaveObject_C> K2Node_DynamicCast_AsBPI_EBS_Save_Object;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_SetSaveID_BPI_Success : 1;  // 0x31(0x1)

}; 
