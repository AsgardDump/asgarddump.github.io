#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_Ceiling_Triangle.BP_EBS_Building_Ceiling_Triangle_C.SetFloorNumberByTargetActor
// Size: 0x20(Inherited: 0x19) 
struct FSetFloorNumberByTargetActor : public FSetFloorNumberByTargetActor
{
	struct AActor* TargetActor;  // 0x0(0x8)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_SetFloorNumberByTargetActor_Success : 1;  // 0x9(0x1)
	struct ABP_EBS_Building_Wall_C* K2Node_DynamicCast_AsBP_EBS_Building_Wall;  // 0x10(0x8)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)

}; 
// Function BP_EBS_Building_Ceiling_Triangle.BP_EBS_Building_Ceiling_Triangle_C.CheckSupport
// Size: 0x45(Inherited: 0x80) 
struct FCheckSupport : public FCheckSupport
{
	char pad_128_1 : 7;  // 0x80(0x1)
	bool HasSupport : 1;  // 0x0(0x1)
	int32_t LocalCount;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x14(0x4)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> CallFunc_Get_Snapped_Objects_OverlappingObjects;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_179_1 : 7;  // 0xB3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x41(0x1)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x42(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool CallFunc_BuildingObjectInSocket_InSocket : 1;  // 0x43(0x1)
	char pad_182_1 : 7;  // 0xB6(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x44(0x1)

}; 
