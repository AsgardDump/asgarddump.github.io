#pragma once 
#include <BP_LobbyPod_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LobbyPod.BP_LobbyPod_C
// Size: 0x3E8(Inherited: 0x220) 
struct ABP_LobbyPod_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USkeletalMeshComponent* head;  // 0x228(0x8)
	struct USkeletalMeshComponent* Feet;  // 0x230(0x8)
	struct USkeletalMeshComponent* Bottom;  // 0x238(0x8)
	struct USkeletalMeshComponent* Torso;  // 0x240(0x8)
	struct USkeletalMeshComponent* Beard;  // 0x248(0x8)
	struct USkeletalMeshComponent* Eyes;  // 0x250(0x8)
	struct USkeletalMeshComponent* Eyebrows;  // 0x258(0x8)
	struct USkeletalMeshComponent* Hair;  // 0x260(0x8)
	struct UStaticMeshComponent* Shine Mesh;  // 0x268(0x8)
	struct UBoxComponent* Mouse Collision;  // 0x270(0x8)
	struct UPointLightComponent* PointLight;  // 0x278(0x8)
	struct UWidgetComponent* Invite Widget;  // 0x280(0x8)
	struct UWidgetComponent* Player Info;  // 0x288(0x8)
	struct USkeletalMeshComponent* CharacterMesh;  // 0x290(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x298(0x8)
	char ETimelineDirection TML_Actor_Rotation__Direction_3424D9D3430A31BAD5AF62BB10247159;  // 0x2A0(0x1)
	char pad_673[7];  // 0x2A1(0x7)
	struct UTimelineComponent* TML Actor Rotation;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Is Main Pod : 1;  // 0x2B0(0x1)
	char pad_689_1 : 7;  // 0x2B1(0x1)
	bool Is Occupied : 1;  // 0x2B1(0x1)
	char pad_690[6];  // 0x2B2(0x6)
	struct FString Player Unique ID;  // 0x2B8(0x10)
	float Turn Value;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)
	struct UMaterialInstanceDynamic* Shine Material;  // 0x2D0(0x8)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool Can Rotate Player : 1;  // 0x2D8(0x1)
	char pad_729[7];  // 0x2D9(0x7)
	struct FString Player Name;  // 0x2E0(0x10)
	struct UMaterialInstanceDynamic* Human Dynamic Material;  // 0x2F0(0x8)
	struct TArray<struct USceneComponent*> Holster References;  // 0x2F8(0x10)
	struct FS_PlayerSave Player Data;  // 0x308(0xE0)

	void Apply Armor(struct FS_PlayerArmor& Armor); // Function BP_LobbyPod.BP_LobbyPod_C.Apply Armor
	void Create Holster(struct FS_HolsterData Holster Data); // Function BP_LobbyPod.BP_LobbyPod_C.Create Holster
	void UserConstructionScript(); // Function BP_LobbyPod.BP_LobbyPod_C.UserConstructionScript
	void TML Actor Rotation__FinishedFunc(); // Function BP_LobbyPod.BP_LobbyPod_C.TML Actor Rotation__FinishedFunc
	void TML Actor Rotation__UpdateFunc(); // Function BP_LobbyPod.BP_LobbyPod_C.TML Actor Rotation__UpdateFunc
	void OnNotifyEnd_B08AD145445B84941A6F77BED20603E1(struct FName NotifyName); // Function BP_LobbyPod.BP_LobbyPod_C.OnNotifyEnd_B08AD145445B84941A6F77BED20603E1
	void OnNotifyBegin_B08AD145445B84941A6F77BED20603E1(struct FName NotifyName); // Function BP_LobbyPod.BP_LobbyPod_C.OnNotifyBegin_B08AD145445B84941A6F77BED20603E1
	void OnInterrupted_B08AD145445B84941A6F77BED20603E1(struct FName NotifyName); // Function BP_LobbyPod.BP_LobbyPod_C.OnInterrupted_B08AD145445B84941A6F77BED20603E1
	void OnBlendOut_B08AD145445B84941A6F77BED20603E1(struct FName NotifyName); // Function BP_LobbyPod.BP_LobbyPod_C.OnBlendOut_B08AD145445B84941A6F77BED20603E1
	void OnCompleted_B08AD145445B84941A6F77BED20603E1(struct FName NotifyName); // Function BP_LobbyPod.BP_LobbyPod_C.OnCompleted_B08AD145445B84941A6F77BED20603E1
	void Load Player Widget Information(struct FString Player Name, struct FString Unique ID); // Function BP_LobbyPod.BP_LobbyPod_C.Load Player Widget Information
	void Occupie Pod(bool Occupied); // Function BP_LobbyPod.BP_LobbyPod_C.Occupie Pod
	void Toggle Ready(bool Ready); // Function BP_LobbyPod.BP_LobbyPod_C.Toggle Ready
	void Load Pod(struct FString Player Name, struct FString Unique ID, bool Is Ready); // Function BP_LobbyPod.BP_LobbyPod_C.Load Pod
	void Remove Pod(); // Function BP_LobbyPod.BP_LobbyPod_C.Remove Pod
	void Toggle Pod Light(bool Toggle, struct FLinearColor Color); // Function BP_LobbyPod.BP_LobbyPod_C.Toggle Pod Light
	void Toggle Dance(struct UAnimMontage* Emote); // Function BP_LobbyPod.BP_LobbyPod_C.Toggle Dance
	void BndEvt__Mouse Collision_K2Node_ComponentBoundEvent_3_ComponentOnClickedSignature__DelegateSignature(struct UPrimitiveComponent* TouchedComponent, struct FKey ButtonPressed); // Function BP_LobbyPod.BP_LobbyPod_C.BndEvt__Mouse Collision_K2Node_ComponentBoundEvent_3_ComponentOnClickedSignature__DelegateSignature
	void Return Default Rotation(); // Function BP_LobbyPod.BP_LobbyPod_C.Return Default Rotation
	void Start Update Actor Rotation(); // Function BP_LobbyPod.BP_LobbyPod_C.Start Update Actor Rotation
	void Update Turn Value(float Mouse X); // Function BP_LobbyPod.BP_LobbyPod_C.Update Turn Value
	void ReceiveBeginPlay(); // Function BP_LobbyPod.BP_LobbyPod_C.ReceiveBeginPlay
	void Toggle Selected(bool Toggle); // Function BP_LobbyPod.BP_LobbyPod_C.Toggle Selected
	void Apply Customization(struct FS_PlayerCustomization Customization Data); // Function BP_LobbyPod.BP_LobbyPod_C.Apply Customization
	void Load Player Data(struct FS_PlayerSave Player Data); // Function BP_LobbyPod.BP_LobbyPod_C.Load Player Data
	void ExecuteUbergraph_BP_LobbyPod(int32_t EntryPoint); // Function BP_LobbyPod.BP_LobbyPod_C.ExecuteUbergraph_BP_LobbyPod
}; 



