#pragma once 
#include <BP_EBS_Building_BaseObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C
// Size: 0x479(Inherited: 0x220) 
struct ABP_EBS_Building_BaseObject_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct FDataTableRowHandle BuildingObjectHandle;  // 0x238(0x10)
	char E_EBS_BuildingType BuildingType;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct FSTR_EBS_BuildingObjectSettings BuildingObjectSettings;  // 0x250(0xF0)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool Built : 1;  // 0x340(0x1)
	char pad_833_1 : 7;  // 0x341(0x1)
	bool PlacedOnLandscape : 1;  // 0x341(0x1)
	char pad_834_1 : 7;  // 0x342(0x1)
	bool IsFloor : 1;  // 0x342(0x1)
	char pad_835[1];  // 0x343(0x1)
	struct FName SocketName;  // 0x344(0x8)
	float RotateAngle;  // 0x34C(0x4)
	float Durability;  // 0x350(0x4)
	float MaxDurability;  // 0x354(0x4)
	int32_t FloorNumber;  // 0x358(0x4)
	char pad_860[4];  // 0x35C(0x4)
	struct TMap<struct FName, struct FSTR_EBS_SocketTransforms> SocketTransforms;  // 0x360(0x50)
	int32_t SaveID;  // 0x3B0(0x4)
	char pad_948[4];  // 0x3B4(0x4)
	struct ABP_EBS_Building_BaseObject_C* ManualBuildTarget;  // 0x3B8(0x8)
	float ManualInputRotation;  // 0x3C0(0x4)
	char pad_964[4];  // 0x3C4(0x4)
	struct USoundBase* BuildSound;  // 0x3C8(0x8)
	struct USoundBase* DestructSound;  // 0x3D0(0x8)
	struct USoundBase* RepairSound;  // 0x3D8(0x8)
	struct USoundBase* UpgradeSound;  // 0x3E0(0x8)
	struct USoundBase* RotateSound;  // 0x3E8(0x8)
	struct TArray<struct FSTR_EBS_SnapSettings> SnapSettings;  // 0x3F0(0x10)
	struct TArray<char E_EBS_BuildingType> IgnoredBuildingTypes;  // 0x400(0x10)
	struct UStaticMesh* Static Mesh;  // 0x410(0x8)
	char pad_1048[8];  // 0x418(0x8)
	struct FS_Building Build Data;  // 0x420(0x50)
	struct APawn* Player;  // 0x470(0x8)
	char pad_1144_1 : 7;  // 0x478(0x1)
	bool IsPlacable : 1;  // 0x478(0x1)

	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetFormatedVariables_BPI
	void InitSaveID_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.InitSaveID_BPI
	void GetSaveID_BPI(int32_t& SaveID); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSaveID_BPI
	void SetSaveID_BPI(int32_t SaveID, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetSaveID_BPI
	void SaveData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SaveData_BPI
	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.LoadData_BPI
	void SetFloorActorHidden_BPI(bool NewHidden, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetFloorActorHidden_BPI
	void SetFloorNumber_BPI(int32_t FloorNumber, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetFloorNumber_BPI
	void GetFloorNumber_BPI(int32_t& FloorNumber); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetFloorNumber_BPI
	void SetMaxDurability_BPI(float Value, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetMaxDurability_BPI
	void ChangeDurability_BPI(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ChangeDurability_BPI
	void GetDurability_BPI(float& CurrentValue, float& MaxValue); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetDurability_BPI
	void Is Parental Cupboard(bool& Return, struct ABP_Cupboard_C*& Cupboard); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.Is Parental Cupboard
	void Find Cupboard(struct ABP_Cupboard_C*& Return); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.Find Cupboard
	void OnRep_BuildingObjectHandle(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.OnRep_BuildingObjectHandle
	void CompleteBuild(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteBuild
	void GetNearestSocketTransform(struct FVector Location, struct FName SocketName, struct FTransform& ResultTransform); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetNearestSocketTransform
	void GetSocketTransforms(struct FName SocketName, struct TArray<struct FTransform>& SocketTransforms); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSocketTransforms
	void MakeSocketTransformsPrimitive(struct UPrimitiveComponent* PrimitiveComponent, struct FName SocketName, int32_t Amount, struct TArray<struct FTransform>& Transforms); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.MakeSocketTransformsPrimitive
	void MakeSocketTransforms(struct FName SocketName, struct TArray<struct FTransform>& Transforms); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.MakeSocketTransforms
	void ManualRotate(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualRotate
	void ManualSnapAndRotatePrev(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualSnapAndRotatePrev
	void ManualSnapAndRotateNext(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualSnapAndRotateNext
	void ManualSnapToTarget(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ManualSnapToTarget
	void CompleteRotate(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRotate
	void CheckRotate(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckRotate
	void CompleteDestruction(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteDestruction
	void RemoveAttachedObjects(bool Destruct, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.RemoveAttachedObjects
	void CompleteRemove(struct APlayerController* PlayerController, bool Destruct, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRemove
	void CompleteUpgrade(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteUpgrade
	void CheckUpgradeRequirements(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckUpgradeRequirements
	void CheckUpgrade(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckUpgrade
	void CompleteRepair(struct APlayerController* PlayerController, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRepair
	void CheckRepairRequirements(struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckRepairRequirements
	void CheckRepair(struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckRepair
	void CheckOwnership(struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckOwnership
	void SetFloorNumberByTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetFloorNumberByTargetActor
	void CheckClaim(struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckClaim
	void DestroyBuildComponents(bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.DestroyBuildComponents
	void CreateSocketTransforms(bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CreateSocketTransforms
	void GetFloorWorldZ(float& ValueZ); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetFloorWorldZ
	void BuildingObjectInSocket(struct ABP_EBS_Building_BaseObject_C* TargetObject, bool& InSocket); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.BuildingObjectInSocket
	void GetSocketTransform(struct FName SocketName, int32_t Index, struct FTransform& Transform); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSocketTransform
	void GetNearestTransform(struct FVector Location, struct TArray<struct FTransform>& Transforms, struct FTransform& ResultTransform); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetNearestTransform
	void CheckSupport(bool& HasSupport); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckSupport
	void Get Snapped Objects(struct TArray<struct ABP_EBS_Building_BaseObject_C*>& OverlappingObjects); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.Get Snapped Objects
	void SetStartBuildCollisionResponse(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.SetStartBuildCollisionResponse
	void CheckActorCollisions(struct AActor* Actor, struct UPrimitiveComponent* BuildCollision, bool& NotBlocked); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckActorCollisions
	void CheckBuildCollisions(struct AActor* Actor, bool& NotBlocked); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckBuildCollisions
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.GetSnapTransform
	void CheckSnap(struct AActor* TargetActor, bool& CanBeSnapped); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckSnap
	void CheckBuildStatus(struct AActor* TargetActor, bool& CanBeBuilt); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckBuildStatus
	void CheckAndAttachToTarget(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CheckAndAttachToTarget
	void UserConstructionScript(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.UserConstructionScript
	void CompleteDestruction (Multicast)(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteDestruction (Multicast)
	void CompleteBuild (Multicast)(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteBuild (Multicast)
	void CompleteRepair (Multicast)(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRepair (Multicast)
	void CompleteUpgrade (Multicast)(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteUpgrade (Multicast)
	void CompleteRotate (Multicast)(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.CompleteRotate (Multicast)
	void ReceiveBeginPlay(); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ReceiveBeginPlay
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ReceiveAnyDamage
	void ExecuteUbergraph_BP_EBS_Building_BaseObject(int32_t EntryPoint); // Function BP_EBS_Building_BaseObject.BP_EBS_Building_BaseObject_C.ExecuteUbergraph_BP_EBS_Building_BaseObject
}; 



