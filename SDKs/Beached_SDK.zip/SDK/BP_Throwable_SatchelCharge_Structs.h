#pragma once 
#include "SDK.h" 
 
 
// Function BP_Throwable_SatchelCharge.BP_Throwable_SatchelCharge_C.ExecuteUbergraph_BP_Throwable_SatchelCharge
// Size: 0x240(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Throwable_SatchelCharge
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x20(0x30)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x50(0x8)
	float K2Node_Event_Damage;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x60(0x8)
	struct FVector K2Node_Event_HitLocation_2;  // 0x68(0xC)
	struct FVector K2Node_Event_HitNormal_2;  // 0x74(0xC)
	struct UPrimitiveComponent* K2Node_Event_HitComponent;  // 0x80(0x8)
	struct FName K2Node_Event_BoneName;  // 0x88(0x8)
	struct FVector K2Node_Event_ShotFromDirection;  // 0x90(0xC)
	char pad_156[4];  // 0x9C(0x4)
	struct AController* K2Node_Event_InstigatedBy;  // 0xA0(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0xA8(0x8)
	struct FHitResult K2Node_Event_HitInfo;  // 0xB0(0x8C)
	char pad_316[4];  // 0x13C(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x140(0x8)
	UDamageType* CallFunc_GetObjectClass_ReturnValue;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_NotEqual_ClassClass_ReturnValue : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct ABP_SatchelExplosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x160(0x1)
	char pad_353[7];  // 0x161(0x7)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0x168(0x8)
	struct AActor* K2Node_Event_Other;  // 0x170(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x180(0x1)
	char pad_385[3];  // 0x181(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0x184(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x190(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0x19C(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0x1A8(0x8C)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x234(0xC)

}; 
// Function BP_Throwable_SatchelCharge.BP_Throwable_SatchelCharge_C.ReceivePointDamage
// Size: 0xE4(Inherited: 0xE8) 
struct FReceivePointDamage : public FReceivePointDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct UPrimitiveComponent* HitComponent;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	struct FVector ShotFromDirection;  // 0x38(0xC)
	struct AController* InstigatedBy;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)
	struct FHitResult HitInfo;  // 0x58(0x8C)

}; 
// Function BP_Throwable_SatchelCharge.BP_Throwable_SatchelCharge_C.ReceiveHit
// Size: 0xCC(Inherited: 0xD0) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x8C)

}; 
