#pragma once 
#include <BP_EBS_Building_WindowFrame_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_WindowFrame.BP_EBS_Building_WindowFrame_C
// Size: 0x4F0(Inherited: 0x4E0) 
struct ABP_EBS_Building_WindowFrame_C : public ABP_EBS_Building_Wall_C
{
	struct USceneComponent* WindowSocket;  // 0x4E0(0x8)
	struct ABP_EBS_Building_Window_C* WindowReference;  // 0x4E8(0x8)

	void GetSocketTransform(struct FName SocketName, int32_t Index, struct FTransform& Transform); // Function BP_EBS_Building_WindowFrame.BP_EBS_Building_WindowFrame_C.GetSocketTransform
}; 



