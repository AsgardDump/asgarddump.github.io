#pragma once 
#include <BFL_Inventory_Structs.h>
 
 
 
// BlueprintGeneratedClass BFL_Inventory.BFL_Inventory_C
// Size: 0x28(Inherited: 0x28) 
struct UBFL_Inventory_C : public UBlueprintFunctionLibrary
{

	struct FString Generate Random Timestamp ID(struct FString NewParam, struct UObject* __WorldContext); // Function BFL_Inventory.BFL_Inventory_C.Generate Random Timestamp ID
	void Get Item Data from ID(struct FName Item ID, struct UObject* __WorldContext, bool& bIsValid, struct FS_InventoryItemData& Item Data); // Function BFL_Inventory.BFL_Inventory_C.Get Item Data from ID
}; 



