#pragma once 
#include <BP_GameInstance_UMSP_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GameInstance_UMSP.BP_GameInstance_UMSP_C
// Size: 0x278(Inherited: 0x228) 
struct UBP_GameInstance_UMSP_C : public UAdvancedFriendsGameInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x228(0x8)
	struct ABP_PlayerController_C* Target;  // 0x230(0x8)
	struct UBP_EBS_SaveGame_C* SaveData;  // 0x238(0x8)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> LoadedBuildingObjects;  // 0x240(0x10)
	struct TArray<struct UBP_EBS_SaveGame_C*> Build Saves;  // 0x250(0x10)
	struct UBP_EBS_SaveGame_C* GridBuildingsSave;  // 0x260(0x8)
	struct UBP_EBS_SaveGame_C* NewVar_1;  // 0x268(0x8)
	struct UObject* SaveDataOptimized;  // 0x270(0x8)

	void SavePlayerDataOptimized(struct FString Player ID, struct FS_PlayerSaveOptimized Save); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.SavePlayerDataOptimized
	void SavePlacables(struct FString Build ID, struct FS_BuildSave New Save, struct UBP_EBS_SaveGame_C* SaveGame, struct UBP_EBS_SaveGame_C*& SaveGameOut); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.SavePlacables
	void SaveGridBuildings(struct UBP_EBS_SaveGame_C* SaveGame, struct UBP_EBS_SaveGame_C*& SaveGameOut); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.SaveGridBuildings
	void Remove Vehicle Save(struct FString& Key); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Remove Vehicle Save
	void Add Vehicle Save(struct FString& Key, struct FS_VehicleSaveData& Value); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Add Vehicle Save
	bool Get Saved Data(struct FString Build ID, struct FS_BuildSave& Saved Data); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Get Saved Data
	void Save Existing Building(struct FString Build ID, struct FS_BuildSave New Save); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Existing Building
	void Remove Building(struct FString Build ID); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Remove Building
	void Add New Building(struct FS_BuildSave Build Data, struct FString& Build ID); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Add New Building
	void Save Player Data(struct FString Player ID, struct FS_PlayerSave& Save, int32_t Player Index); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Player Data
	void OnFailure_009CFF084103EAC43A8ED5A19E622B52(); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.OnFailure_009CFF084103EAC43A8ED5A19E622B52
	void OnSuccess_009CFF084103EAC43A8ED5A19E622B52(); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.OnSuccess_009CFF084103EAC43A8ED5A19E622B52
	void OnFailure_5A3B724246D49BADDB4834B41649D6B5(); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.OnFailure_5A3B724246D49BADDB4834B41649D6B5
	void OnSuccess_5A3B724246D49BADDB4834B41649D6B5(); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.OnSuccess_5A3B724246D49BADDB4834B41649D6B5
	void Completed_20386FB04A461883E6B3F39B0A6A3220(struct USaveGame* SaveGame, bool bSuccess); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Completed_20386FB04A461883E6B3F39B0A6A3220
	void Completed_DAADE8BF40EA586D5BEB91B0BE42B7A2(struct USaveGame* SaveGame, bool bSuccess); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Completed_DAADE8BF40EA586D5BEB91B0BE42B7A2
	void Completed_6C0182614574E20C8A02D58CF57A44AB(struct USaveGame* SaveGame, bool bSuccess); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Completed_6C0182614574E20C8A02D58CF57A44AB
	void Save Building(struct FString& Build ID, struct FS_BuildSave& New Save); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Building
	void Save Building Directly(struct FString& Build ID, struct FS_BuildSave& New Save); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Building Directly
	void OnSessionInviteAccepted(int32_t LocalPlayerNum, struct FBPUniqueNetId PersonInvited, struct FBlueprintSessionResult& SessionToJoin); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.OnSessionInviteAccepted
	void ReceiveInit(); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.ReceiveInit
	void Save Grid Buildings(); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.Save Grid Buildings
	void ExecuteUbergraph_BP_GameInstance_UMSP(int32_t EntryPoint); // Function BP_GameInstance_UMSP.BP_GameInstance_UMSP_C.ExecuteUbergraph_BP_GameInstance_UMSP
}; 



