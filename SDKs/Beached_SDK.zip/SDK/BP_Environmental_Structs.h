#pragma once 
#include "SDK.h" 
 
 
// Function BP_Environmental.BP_Environmental_C.ExecuteUbergraph_BP_Environmental
// Size: 0x169(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Environmental
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	float K2Node_Event_Damage_2;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UDamageType* K2Node_Event_DamageType_2;  // 0x10(0x8)
	struct FVector K2Node_Event_HitLocation;  // 0x18(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x24(0xC)
	struct UPrimitiveComponent* K2Node_Event_HitComponent;  // 0x30(0x8)
	struct FName K2Node_Event_BoneName;  // 0x38(0x8)
	struct FVector K2Node_Event_ShotFromDirection;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct AController* K2Node_Event_InstigatedBy_2;  // 0x50(0x8)
	struct AActor* K2Node_Event_DamageCauser_2;  // 0x58(0x8)
	struct FHitResult K2Node_Event_HitInfo;  // 0x60(0x8C)
	char pad_236_1 : 7;  // 0xEC(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xEC(0x1)
	char pad_237[3];  // 0xED(0x3)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0xF0(0x8)
	UDamageType* CallFunc_GetObjectClass_ReturnValue;  // 0xF8(0x8)
	struct TArray<UDamageType*> K2Node_MakeArray_Array;  // 0x100(0x10)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool Temp_bool_Variable : 1;  // 0x111(0x1)
	char pad_274[2];  // 0x112(0x2)
	float CallFunc_Map_Find_Value;  // 0x114(0x4)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x118(0x1)
	char pad_281[3];  // 0x119(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x11C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x120(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x124(0x4)
	struct UStaticMesh* K2Node_Select_Default;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_3 : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	float K2Node_Event_Damage;  // 0x134(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x138(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x140(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x148(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x150(0xC)
	char pad_348[4];  // 0x15C(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x168(0x1)

}; 
// Function BP_Environmental.BP_Environmental_C.ReceivePointDamage
// Size: 0xE4(Inherited: 0xE8) 
struct FReceivePointDamage : public FReceivePointDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct UPrimitiveComponent* HitComponent;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	struct FVector ShotFromDirection;  // 0x38(0xC)
	struct AController* InstigatedBy;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)
	struct FHitResult HitInfo;  // 0x58(0x8C)

}; 
// Function BP_Environmental.BP_Environmental_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function BP_Environmental.BP_Environmental_C.Drop Items
// Size: 0x6E(Inherited: 0x0) 
struct FDrop Items
{
	struct UBP_PlayerInventoryComponent_C* Inventory;  // 0x0(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	struct FS_DropItem CallFunc_Array_Get_Item;  // 0x14(0x14)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0x38(0x30)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_Add_Item_Success : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x6D(0x1)

}; 
// Function BP_Environmental.BP_Environmental_C.UserConstructionScript
// Size: 0xD(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FName Temp_name_Variable;  // 0x0(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0xC(0x1)

}; 
