#pragma once 
#include <BP_LargeWoodenBox_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LargeWoodenBox.BP_LargeWoodenBox_C
// Size: 0x4E8(Inherited: 0x4A8) 
struct ABP_LargeWoodenBox_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct UBP_ChestInventoryComponent_C* BP_ChestInventoryComponent;  // 0x4B0(0x8)
	float Animation_Alpha_7287121449EFB811328B1680DCD19437;  // 0x4B8(0x4)
	char ETimelineDirection Animation__Direction_7287121449EFB811328B1680DCD19437;  // 0x4BC(0x1)
	char pad_1213[3];  // 0x4BD(0x3)
	struct UTimelineComponent* Animation;  // 0x4C0(0x8)
	struct TArray<struct FS_InventoryItem> Inventory;  // 0x4C8(0x10)
	struct TArray<int32_t> L Slots to Update;  // 0x4D8(0x10)

	void Local Can Overlap(bool& Success); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Get Interaction Data
	void Animation__FinishedFunc(); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Animation__FinishedFunc
	void Animation__UpdateFunc(); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Animation__UpdateFunc
	void Local Overlap(bool Overlap); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Local Overlap
	void On Interacted(struct AController* Executor); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Toggle Selected
	void Toggle Chest(bool Toggle); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.Toggle Chest
	void ReceiveBeginPlay(); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.ReceiveBeginPlay
	void CheckForCollisionBeneath(); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.CheckForCollisionBeneath
	void ChestBroken(struct AActor* DestroyedActor); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.ChestBroken
	void CLIENT Reconstruct Inventory(); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.CLIENT Reconstruct Inventory
	void ExecuteUbergraph_BP_LargeWoodenBox(int32_t EntryPoint); // Function BP_LargeWoodenBox.BP_LargeWoodenBox_C.ExecuteUbergraph_BP_LargeWoodenBox
}; 



