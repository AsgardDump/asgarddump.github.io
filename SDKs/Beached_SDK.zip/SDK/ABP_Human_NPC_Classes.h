#pragma once 
#include <ABP_Human_NPC_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Human_NPC.ABP_Human_NPC_C
// Size: 0x910(Inherited: 0x2C0) 
struct UABP_Human_NPC_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x2F8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x400(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x508(0x20)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x528(0x48)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x570(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x590(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x5B8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x5E0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x608(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x630(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x6B0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x6E0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x760(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x790(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x810(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x840(0xB0)
	struct AActor* Looking Target;  // 0x8F0(0x8)
	struct FRotator Head Rotation;  // 0x8F8(0xC)
	struct FRotator Relative Target Rotation;  // 0x904(0xC)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Human_NPC.ABP_Human_NPC_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_58965303474E17EA54A4B4B5DB9B611A(); // Function ABP_Human_NPC.ABP_Human_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_58965303474E17EA54A4B4B5DB9B611A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_C0EF83BB4C15CE4A0FBB16B59782D44F(); // Function ABP_Human_NPC.ABP_Human_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_C0EF83BB4C15CE4A0FBB16B59782D44F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_3B0E54414FA84F5DDF3D7DAF1BD0FF50(); // Function ABP_Human_NPC.ABP_Human_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_3B0E54414FA84F5DDF3D7DAF1BD0FF50
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_8A574BFC4A2E154399ADC4A1CCB5E878(); // Function ABP_Human_NPC.ABP_Human_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Human_NPC_AnimGraphNode_TransitionResult_8A574BFC4A2E154399ADC4A1CCB5E878
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Human_NPC.ABP_Human_NPC_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_Human_NPC(int32_t EntryPoint); // Function ABP_Human_NPC.ABP_Human_NPC_C.ExecuteUbergraph_ABP_Human_NPC
}; 



