#pragma once 
#include "SDK.h" 
 
 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Apply Internal Damage
// Size: 0x4(Inherited: 0x0) 
struct FSERVER Apply Internal Damage
{
	float BaseDamage;  // 0x0(0x4)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Remove Holster
// Size: 0x10(Inherited: 0x0) 
struct FMULTICAST Remove Holster
{
	struct UStaticMesh* Holster Mesh;  // 0x0(0x8)
	AActor* Holster Class;  // 0x8(0x8)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.ExecuteUbergraph_BP_PlayerComponent
// Size: 0x143A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PlayerComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x1C(0xC)
	float CallFunc_BreakVector_X;  // 0x28(0x4)
	float CallFunc_BreakVector_Y;  // 0x2C(0x4)
	float CallFunc_BreakVector_Z;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x36(0x1)
	char pad_55[1];  // 0x37(0x1)
	struct FVector K2Node_CustomEvent_Hit_Location;  // 0x38(0xC)
	char pad_68[4];  // 0x44(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x48(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0x68(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x70(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_2;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	float CallFunc_Conv_BoolToFloat_ReturnValue;  // 0x9C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xA0(0x4)
	float CallFunc_Conv_BoolToFloat_ReturnValue_2;  // 0xA4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xA8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xB4(0xC)
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // 0xC0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xC8(0xC)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0xD4(0x4)
	float CallFunc_BreakVector_X_2;  // 0xD8(0x4)
	float CallFunc_BreakVector_Y_2;  // 0xDC(0x4)
	float CallFunc_BreakVector_Z_2;  // 0xE0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0xE4(0xC)
	float CallFunc_BreakVector_X_3;  // 0xF0(0x4)
	float CallFunc_BreakVector_Y_3;  // 0xF4(0x4)
	float CallFunc_BreakVector_Z_3;  // 0xF8(0x4)
	float CallFunc_BreakVector_X_4;  // 0xFC(0x4)
	float CallFunc_BreakVector_Y_4;  // 0x100(0x4)
	float CallFunc_BreakVector_Z_4;  // 0x104(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x108(0xC)
	char pad_276[4];  // 0x114(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_6;  // 0x118(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x128(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x129(0x1)
	char pad_298[2];  // 0x12A(0x2)
	float CallFunc_BreakVector_X_5;  // 0x12C(0x4)
	float CallFunc_BreakVector_Y_5;  // 0x130(0x4)
	float CallFunc_BreakVector_Z_5;  // 0x134(0x4)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_7;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x148(0x1)
	char pad_329[3];  // 0x149(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x14C(0x4)
	float CallFunc_BreakVector_X_6;  // 0x150(0x4)
	float CallFunc_BreakVector_Y_6;  // 0x154(0x4)
	float CallFunc_BreakVector_Z_6;  // 0x158(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x15C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x160(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x164(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x168(0x4)
	float CallFunc_BreakVector_X_7;  // 0x16C(0x4)
	float CallFunc_BreakVector_Y_7;  // 0x170(0x4)
	float CallFunc_BreakVector_Z_7;  // 0x174(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x178(0x4)
	float CallFunc_Abs_ReturnValue_2;  // 0x17C(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x180(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x184(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x188(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x18C(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x190(0x4)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x194(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_8;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x1A0(0x1)
	char pad_417[7];  // 0x1A1(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x1A8(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue : 1;  // 0x1B8(0x1)
	char pad_441[7];  // 0x1B9(0x7)
	struct FS_PlayerCustomization CallFunc_Load_Customization_Data_Customization_Data;  // 0x1C0(0x50)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool CallFunc_Load_Customization_Data_Valid : 1;  // 0x210(0x1)
	char pad_529_1 : 7;  // 0x211(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x211(0x1)
	char pad_530[6];  // 0x212(0x6)
	struct FS_PlayerCustomization K2Node_CustomEvent_Customization_Data_3;  // 0x218(0x50)
	struct FS_PlayerCustomization K2Node_CustomEvent_Customization_Data_2;  // 0x268(0x50)
	struct AActor* CallFunc_GetOwner_ReturnValue_9;  // 0x2B8(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_3;  // 0x2C0(0x10)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x2D0(0x1)
	char pad_721[3];  // 0x2D1(0x3)
	struct FVector K2Node_CustomEvent_Ragdoll_Location_3;  // 0x2D4(0xC)
	struct FVector K2Node_CustomEvent_Ragdoll_Location_2;  // 0x2E0(0xC)
	struct FVector K2Node_CustomEvent_Ragdoll_Location;  // 0x2EC(0xC)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool K2Node_CustomEvent_Toggle_2 : 1;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool K2Node_CustomEvent_Toggle : 1;  // 0x2F9(0x1)
	char pad_762_1 : 7;  // 0x2FA(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x2FA(0x1)
	char pad_763[5];  // 0x2FB(0x5)
	struct AActor* CallFunc_GetOwner_ReturnValue_10;  // 0x300(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_2;  // 0x308(0x8)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x310(0x1)
	char pad_785[7];  // 0x311(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_11;  // 0x318(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_4;  // 0x320(0x10)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x330(0x1)
	char pad_817[7];  // 0x331(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_12;  // 0x338(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_5;  // 0x340(0x10)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x350(0x1)
	char pad_849[3];  // 0x351(0x3)
	int32_t K2Node_CustomEvent_Level;  // 0x354(0x4)
	char pad_856_1 : 7;  // 0x358(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x358(0x1)
	char pad_857_1 : 7;  // 0x359(0x1)
	bool K2Node_CustomEvent_Is_Loaded : 1;  // 0x359(0x1)
	char pad_858[6];  // 0x35A(0x6)
	struct FS_HolsterData K2Node_CustomEvent_Holster_Data_4;  // 0x360(0x50)
	struct FS_HolsterData K2Node_CustomEvent_Holster_Data_3;  // 0x3B0(0x50)
	struct FS_HolsterData K2Node_CustomEvent_Holster_Data_2;  // 0x400(0x50)
	struct AActor* CallFunc_GetOwner_ReturnValue_13;  // 0x450(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue_2;  // 0x458(0xC)
	float CallFunc_BreakVector_X_8;  // 0x464(0x4)
	float CallFunc_BreakVector_Y_8;  // 0x468(0x4)
	float CallFunc_BreakVector_Z_8;  // 0x46C(0x4)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x470(0x1)
	char pad_1137[3];  // 0x471(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x474(0x4)
	char pad_1144_1 : 7;  // 0x478(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x478(0x1)
	char pad_1145[3];  // 0x479(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x47C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x480(0x4)
	char E_HolsterSockets K2Node_CustomEvent_Holster_Socket_3;  // 0x484(0x1)
	char pad_1157_1 : 7;  // 0x485(0x1)
	bool CallFunc_Destroy_Holster_Socket_Return : 1;  // 0x485(0x1)
	char E_HolsterSockets K2Node_CustomEvent_Holster_Socket_2;  // 0x486(0x1)
	char E_HolsterSockets K2Node_CustomEvent_Holster_Socket;  // 0x487(0x1)
	char pad_1160_1 : 7;  // 0x488(0x1)
	bool CallFunc_Destroy_Holster_Socket_Return_2 : 1;  // 0x488(0x1)
	char pad_1161_1 : 7;  // 0x489(0x1)
	bool CallFunc_Destroy_Holster_Socket_Return_3 : 1;  // 0x489(0x1)
	char pad_1162[6];  // 0x48A(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_14;  // 0x490(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_3;  // 0x498(0x8)
	char pad_1184_1 : 7;  // 0x4A0(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x4A0(0x1)
	char pad_1185_1 : 7;  // 0x4A1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x4A1(0x1)
	char pad_1186_1 : 7;  // 0x4A2(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x4A2(0x1)
	char pad_1187[1];  // 0x4A3(0x1)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x4A4(0x4)
	struct FHitResult K2Node_CustomEvent_Hit;  // 0x4A8(0x8C)
	char pad_1332[12];  // 0x534(0xC)
	struct FS_HolsterData CallFunc_Array_Get_Item;  // 0x540(0x50)
	float K2Node_CustomEvent_Fall_Velocity;  // 0x590(0x4)
	char pad_1428[4];  // 0x594(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_15;  // 0x598(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_16;  // 0x5A0(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_4;  // 0x5A8(0x8)
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x5B0(0x1)
	char pad_1457[3];  // 0x5B1(0x3)
	struct FVector CallFunc_GetVelocity_ReturnValue_3;  // 0x5B4(0xC)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x5C0(0x8)
	float CallFunc_BreakVector_X_9;  // 0x5C8(0x4)
	float CallFunc_BreakVector_Y_9;  // 0x5CC(0x4)
	float CallFunc_BreakVector_Z_9;  // 0x5D0(0x4)
	char pad_1492[4];  // 0x5D4(0x4)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_2;  // 0x5D8(0x8)
	float CallFunc_Abs_ReturnValue_3;  // 0x5E0(0x4)
	char pad_1508[4];  // 0x5E4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_17;  // 0x5E8(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x5F0(0x4)
	char pad_1524[4];  // 0x5F4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_18;  // 0x5F8(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x600(0x4)
	float CallFunc_FClamp_ReturnValue_3;  // 0x604(0x4)
	char pad_1544_1 : 7;  // 0x608(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x608(0x1)
	char pad_1545[3];  // 0x609(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x60C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x610(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x614(0x4)
	char pad_1560_1 : 7;  // 0x618(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x618(0x1)
	char pad_1561[3];  // 0x619(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x61C(0x4)
	float CallFunc_ApplyDamage_ReturnValue_2;  // 0x620(0x4)
	struct FS_PlayerArmor K2Node_CustomEvent_Armor_IDs;  // 0x624(0x28)
	char pad_1612[4];  // 0x64C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_19;  // 0x650(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_20;  // 0x658(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_6;  // 0x660(0x10)
	char pad_1648_1 : 7;  // 0x670(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x670(0x1)
	char pad_1649[7];  // 0x671(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_7;  // 0x678(0x10)
	char pad_1672_1 : 7;  // 0x688(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x688(0x1)
	char pad_1673[7];  // 0x689(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_8;  // 0x690(0x10)
	char pad_1696_1 : 7;  // 0x6A0(0x1)
	bool K2Node_DynamicCast_bSuccess_12 : 1;  // 0x6A0(0x1)
	char pad_1697[7];  // 0x6A1(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_9;  // 0x6A8(0x10)
	char pad_1720_1 : 7;  // 0x6B8(0x1)
	bool K2Node_DynamicCast_bSuccess_13 : 1;  // 0x6B8(0x1)
	char pad_1721[7];  // 0x6B9(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_10;  // 0x6C0(0x10)
	char pad_1744_1 : 7;  // 0x6D0(0x1)
	bool K2Node_DynamicCast_bSuccess_14 : 1;  // 0x6D0(0x1)
	char pad_1745[7];  // 0x6D1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_21;  // 0x6D8(0x8)
	char pad_1760_1 : 7;  // 0x6E0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x6E0(0x1)
	char pad_1761[7];  // 0x6E1(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_11;  // 0x6E8(0x10)
	char pad_1784_1 : 7;  // 0x6F8(0x1)
	bool K2Node_DynamicCast_bSuccess_15 : 1;  // 0x6F8(0x1)
	char pad_1785[7];  // 0x6F9(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_12;  // 0x700(0x10)
	char pad_1808_1 : 7;  // 0x710(0x1)
	bool K2Node_DynamicCast_bSuccess_16 : 1;  // 0x710(0x1)
	char pad_1809[7];  // 0x711(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_22;  // 0x718(0x8)
	struct TScriptInterface<IBPI_VehicleSystem_C> K2Node_DynamicCast_AsBPI_Vehicle_System;  // 0x720(0x10)
	char pad_1840_1 : 7;  // 0x730(0x1)
	bool K2Node_DynamicCast_bSuccess_17 : 1;  // 0x730(0x1)
	char pad_1841[7];  // 0x731(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_23;  // 0x738(0x8)
	struct FVector CallFunc_Passenger_DIsmount_Request_Dismount_Location;  // 0x740(0xC)
	char pad_1868[4];  // 0x74C(0x4)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_13;  // 0x750(0x10)
	char pad_1888_1 : 7;  // 0x760(0x1)
	bool K2Node_DynamicCast_bSuccess_18 : 1;  // 0x760(0x1)
	char pad_1889[7];  // 0x761(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_14;  // 0x768(0x10)
	char pad_1912_1 : 7;  // 0x778(0x1)
	bool K2Node_DynamicCast_bSuccess_19 : 1;  // 0x778(0x1)
	char pad_1913_1 : 7;  // 0x779(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x779(0x1)
	char pad_1914[6];  // 0x77A(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_24;  // 0x780(0x8)
	struct TScriptInterface<IBPI_VehicleSystem_C> K2Node_DynamicCast_AsBPI_Vehicle_System_2;  // 0x788(0x10)
	char pad_1944_1 : 7;  // 0x798(0x1)
	bool K2Node_DynamicCast_bSuccess_20 : 1;  // 0x798(0x1)
	char pad_1945[3];  // 0x799(0x3)
	struct FS_PlayerArmor K2Node_CustomEvent_PlayerArmor;  // 0x79C(0x28)
	struct FVector CallFunc_Passenger_DIsmount_Request_Dismount_Location_2;  // 0x7C4(0xC)
	char pad_2000_1 : 7;  // 0x7D0(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0x7D0(0x1)
	char pad_2001[15];  // 0x7D1(0xF)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0x7E0(0xE0)
	char pad_2240_1 : 7;  // 0x8C0(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x8C0(0x1)
	char pad_2241_1 : 7;  // 0x8C1(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid_2 : 1;  // 0x8C1(0x1)
	char pad_2242[14];  // 0x8C2(0xE)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data_2;  // 0x8D0(0xE0)
	char pad_2480_1 : 7;  // 0x9B0(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue_2 : 1;  // 0x9B0(0x1)
	char pad_2481_1 : 7;  // 0x9B1(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid_3 : 1;  // 0x9B1(0x1)
	char pad_2482[14];  // 0x9B2(0xE)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data_3;  // 0x9C0(0xE0)
	char pad_2720_1 : 7;  // 0xAA0(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue_3 : 1;  // 0xAA0(0x1)
	char pad_2721_1 : 7;  // 0xAA1(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid_4 : 1;  // 0xAA1(0x1)
	char pad_2722[14];  // 0xAA2(0xE)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data_4;  // 0xAB0(0xE0)
	char pad_2960_1 : 7;  // 0xB90(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue_4 : 1;  // 0xB90(0x1)
	char pad_2961_1 : 7;  // 0xB91(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid_5 : 1;  // 0xB91(0x1)
	char pad_2962[14];  // 0xB92(0xE)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data_5;  // 0xBA0(0xE0)
	char pad_3200_1 : 7;  // 0xC80(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue_5 : 1;  // 0xC80(0x1)
	char pad_3201_1 : 7;  // 0xC81(0x1)
	bool CallFunc_NotEqualExactly_VectorVector_ReturnValue : 1;  // 0xC81(0x1)
	char pad_3202[6];  // 0xC82(0x6)
	struct UStaticMesh* K2Node_CustomEvent_Holster_Mesh_4;  // 0xC88(0x8)
	AActor* K2Node_CustomEvent_Holster_Class_4;  // 0xC90(0x8)
	struct UStaticMesh* K2Node_CustomEvent_Holster_Mesh_3;  // 0xC98(0x8)
	AActor* K2Node_CustomEvent_Holster_Class_3;  // 0xCA0(0x8)
	char pad_3240_1 : 7;  // 0xCA8(0x1)
	bool CallFunc_Destroy_Holster_Return : 1;  // 0xCA8(0x1)
	char pad_3241_1 : 7;  // 0xCA9(0x1)
	bool CallFunc_Destroy_Holster_Return_2 : 1;  // 0xCA9(0x1)
	char pad_3242[6];  // 0xCAA(0x6)
	struct UStaticMesh* K2Node_CustomEvent_Holster_Mesh_2;  // 0xCB0(0x8)
	AActor* K2Node_CustomEvent_Holster_Class_2;  // 0xCB8(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_25;  // 0xCC0(0x8)
	char pad_3272_1 : 7;  // 0xCC8(0x1)
	bool CallFunc_Destroy_Holster_Return_3 : 1;  // 0xCC8(0x1)
	char pad_3273[7];  // 0xCC9(0x7)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_5;  // 0xCD0(0x8)
	char pad_3288_1 : 7;  // 0xCD8(0x1)
	bool K2Node_DynamicCast_bSuccess_21 : 1;  // 0xCD8(0x1)
	char pad_3289_1 : 7;  // 0xCD9(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0xCD9(0x1)
	char pad_3290[2];  // 0xCDA(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xCDC(0x10)
	char pad_3308[4];  // 0xCEC(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0xCF0(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xCF8(0x8)
	struct UBP_Player_ExperienceComponent_C* CallFunc_Get_Leveling_Component_Leveling_Component;  // 0xD00(0x8)
	char pad_3336_1 : 7;  // 0xD08(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xD08(0x1)
	char pad_3337[7];  // 0xD09(0x7)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0xD10(0x8)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue_2;  // 0xD18(0x8)
	struct UCameraModifier* CallFunc_AddNewCameraModifier_ReturnValue;  // 0xD20(0x8)
	struct UCameraModifier* CallFunc_FindCameraModifierByClass_ReturnValue;  // 0xD28(0x8)
	char pad_3376_1 : 7;  // 0xD30(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0xD30(0x1)
	char pad_3377[7];  // 0xD31(0x7)
	struct UCameraModifier* CallFunc_FindCameraModifierByClass_ReturnValue_2;  // 0xD38(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_26;  // 0xD40(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_6;  // 0xD48(0x8)
	char pad_3408_1 : 7;  // 0xD50(0x1)
	bool K2Node_DynamicCast_bSuccess_22 : 1;  // 0xD50(0x1)
	char pad_3409_1 : 7;  // 0xD51(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0xD51(0x1)
	char pad_3410[6];  // 0xD52(0x6)
	struct AController* CallFunc_GetController_ReturnValue_3;  // 0xD58(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0xD60(0x8)
	char pad_3432_1 : 7;  // 0xD68(0x1)
	bool K2Node_DynamicCast_bSuccess_23 : 1;  // 0xD68(0x1)
	char pad_3433[3];  // 0xD69(0x3)
	float K2Node_Event_DeltaSeconds;  // 0xD6C(0x4)
	struct FString CallFunc_Get_Player_Name_Name;  // 0xD70(0x10)
	struct FString CallFunc_Get_Player_Unique_ID_Unique_ID;  // 0xD80(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue_27;  // 0xD90(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_28;  // 0xD98(0x8)
	struct FName Temp_name_Variable;  // 0xDA0(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_7;  // 0xDA8(0x8)
	char pad_3504_1 : 7;  // 0xDB0(0x1)
	bool K2Node_DynamicCast_bSuccess_24 : 1;  // 0xDB0(0x1)
	char pad_3505[7];  // 0xDB1(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_15;  // 0xDB8(0x10)
	char pad_3528_1 : 7;  // 0xDC8(0x1)
	bool K2Node_DynamicCast_bSuccess_25 : 1;  // 0xDC8(0x1)
	char pad_3529[7];  // 0xDC9(0x7)
	struct FS_PlayerCustomization K2Node_CustomEvent_Customization_Data;  // 0xDD0(0x50)
	char pad_3616_1 : 7;  // 0xE20(0x1)
	bool K2Node_CustomEvent_Load_Customization : 1;  // 0xE20(0x1)
	char pad_3617[7];  // 0xE21(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0xE28(0x8)
	struct UBP_GameInstance_UMSP_C* K2Node_DynamicCast_AsBP_Game_Instance_UMSP;  // 0xE30(0x8)
	char pad_3640_1 : 7;  // 0xE38(0x1)
	bool K2Node_DynamicCast_bSuccess_26 : 1;  // 0xE38(0x1)
	char pad_3641[7];  // 0xE39(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_29;  // 0xE40(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_8;  // 0xE48(0x8)
	char pad_3664_1 : 7;  // 0xE50(0x1)
	bool K2Node_DynamicCast_bSuccess_27 : 1;  // 0xE50(0x1)
	char pad_3665_1 : 7;  // 0xE51(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0xE51(0x1)
	char pad_3666[6];  // 0xE52(0x6)
	struct AController* CallFunc_GetController_ReturnValue_4;  // 0xE58(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_2;  // 0xE60(0x8)
	char pad_3688_1 : 7;  // 0xE68(0x1)
	bool K2Node_DynamicCast_bSuccess_28 : 1;  // 0xE68(0x1)
	char pad_3689[7];  // 0xE69(0x7)
	struct FString CallFunc_Get_Player_Unique_ID_Unique_ID_2;  // 0xE70(0x10)
	struct TArray<struct FS_HolsterData> K2Node_CustomEvent_Holster_Data;  // 0xE80(0x10)
	struct FS_PlayerSave CallFunc_Map_Find_Value;  // 0xE90(0xE0)
	char pad_3952_1 : 7;  // 0xF70(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xF70(0x1)
	char pad_3953[15];  // 0xF71(0xF)
	struct FS_HolsterData CallFunc_Array_Get_Item_2;  // 0xF80(0x50)
	char pad_4048_1 : 7;  // 0xFD0(0x1)
	bool CallFunc_NotEqualExactly_VectorVector_ReturnValue_2 : 1;  // 0xFD0(0x1)
	char pad_4049[7];  // 0xFD1(0x7)
	struct FString CallFunc_Conv_VectorToString_ReturnValue;  // 0xFD8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0xFE8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xFEC(0x4)
	char pad_4080_1 : 7;  // 0xFF0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xFF0(0x1)
	char pad_4081_1 : 7;  // 0xFF1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xFF1(0x1)
	char pad_4082[2];  // 0xFF2(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xFF4(0x4)
	struct UStaticMesh* K2Node_CustomEvent_Holster_Mesh;  // 0xFF8(0x8)
	AActor* K2Node_CustomEvent_Holster_Class;  // 0x1000(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x1008(0x8)
	char pad_4112_1 : 7;  // 0x1010(0x1)
	bool CallFunc_Destroy_Holster_Return_4 : 1;  // 0x1010(0x1)
	char pad_4113[7];  // 0x1011(0x7)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x1018(0x8)
	char pad_4128_1 : 7;  // 0x1020(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x1020(0x1)
	char pad_4129_1 : 7;  // 0x1021(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1021(0x1)
	char pad_4130[2];  // 0x1022(0x2)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x1024(0x4)
	char pad_4136_1 : 7;  // 0x1028(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_4 : 1;  // 0x1028(0x1)
	char pad_4137_1 : 7;  // 0x1029(0x1)
	bool CallFunc_NotEqual_StrStr_ReturnValue : 1;  // 0x1029(0x1)
	char pad_4138[6];  // 0x102A(0x6)
	struct APlayerController* K2Node_CustomEvent_Player_Controller;  // 0x1030(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_30;  // 0x1038(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_9;  // 0x1040(0x8)
	char pad_4168_1 : 7;  // 0x1048(0x1)
	bool K2Node_DynamicCast_bSuccess_29 : 1;  // 0x1048(0x1)
	char pad_4169[7];  // 0x1049(0x7)
	struct AController* CallFunc_GetController_ReturnValue_5;  // 0x1050(0x8)
	struct USoundBase* K2Node_CustomEvent_Sound;  // 0x1058(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_3;  // 0x1060(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_31;  // 0x1068(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x1070(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x1078(0x8)
	struct FVector K2Node_CustomEvent_Location;  // 0x1080(0xC)
	char pad_4236[4];  // 0x108C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_32;  // 0x1090(0x8)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x1098(0x8C)
	char pad_4388_1 : 7;  // 0x1124(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x1124(0x1)
	char pad_4389[3];  // 0x1125(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue_33;  // 0x1128(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_10;  // 0x1130(0x8)
	char pad_4408_1 : 7;  // 0x1138(0x1)
	bool K2Node_DynamicCast_bSuccess_30 : 1;  // 0x1138(0x1)
	char pad_4409_1 : 7;  // 0x1139(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x1139(0x1)
	char pad_4410_1 : 7;  // 0x113A(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_5 : 1;  // 0x113A(0x1)
	char pad_4411[1];  // 0x113B(0x1)
	float CallFunc_Do_Water_Trace_Water_Deepness;  // 0x113C(0x4)
	struct FVector CallFunc_Do_Water_Trace_ImpactPoint;  // 0x1140(0xC)
	float CallFunc_BreakVector_X_10;  // 0x114C(0x4)
	float CallFunc_BreakVector_Y_10;  // 0x1150(0x4)
	float CallFunc_BreakVector_Z_10;  // 0x1154(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_4;  // 0x1158(0x4)
	float CallFunc_FInterpTo_Constant_ReturnValue;  // 0x115C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_3;  // 0x1160(0xC)
	char pad_4460[4];  // 0x116C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_34;  // 0x1170(0x8)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_2;  // 0x1178(0x8C)
	char pad_4612_1 : 7;  // 0x1204(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_2 : 1;  // 0x1204(0x1)
	char pad_4613[3];  // 0x1205(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x1208(0xC)
	char pad_4628[4];  // 0x1214(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_35;  // 0x1218(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x1220(0x8)
	char pad_4648_1 : 7;  // 0x1228(0x1)
	bool CallFunc_HasAuthority_ReturnValue_4 : 1;  // 0x1228(0x1)
	char pad_4649[7];  // 0x1229(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_36;  // 0x1230(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_16;  // 0x1238(0x10)
	char pad_4680_1 : 7;  // 0x1248(0x1)
	bool K2Node_DynamicCast_bSuccess_31 : 1;  // 0x1248(0x1)
	char pad_4681[7];  // 0x1249(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_17;  // 0x1250(0x10)
	char pad_4704_1 : 7;  // 0x1260(0x1)
	bool K2Node_DynamicCast_bSuccess_32 : 1;  // 0x1260(0x1)
	char pad_4705[7];  // 0x1261(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x1268(0x8)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character;  // 0x1270(0x8)
	float CallFunc_GetSquaredDistanceTo_ReturnValue;  // 0x1278(0x4)
	char pad_4732_1 : 7;  // 0x127C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0x127C(0x1)
	char pad_4733[3];  // 0x127D(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue_37;  // 0x1280(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_11;  // 0x1288(0x8)
	char pad_4752_1 : 7;  // 0x1290(0x1)
	bool K2Node_DynamicCast_bSuccess_33 : 1;  // 0x1290(0x1)
	char pad_4753_1 : 7;  // 0x1291(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_6 : 1;  // 0x1291(0x1)
	char pad_4754_1 : 7;  // 0x1292(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_4 : 1;  // 0x1292(0x1)
	char pad_4755_1 : 7;  // 0x1293(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_4 : 1;  // 0x1293(0x1)
	char pad_4756_1 : 7;  // 0x1294(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1294(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x1295(0x1)
	char pad_4758[2];  // 0x1296(0x2)
	struct FVector K2Node_CustomEvent_NewLocation;  // 0x1298(0xC)
	char pad_4772[4];  // 0x12A4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_38;  // 0x12A8(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_39;  // 0x12B0(0x8)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_3;  // 0x12B8(0x8C)
	char pad_4932_1 : 7;  // 0x1344(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_3 : 1;  // 0x1344(0x1)
	char pad_4933_1 : 7;  // 0x1345(0x1)
	bool CallFunc_HasAuthority_ReturnValue_5 : 1;  // 0x1345(0x1)
	char pad_4934[2];  // 0x1346(0x2)
	struct AActor* CallFunc_GetOwner_ReturnValue_40;  // 0x1348(0x8)
	char pad_4944_1 : 7;  // 0x1350(0x1)
	bool CallFunc_HasAuthority_ReturnValue_6 : 1;  // 0x1350(0x1)
	char pad_4945[7];  // 0x1351(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x1358(0x8)
	float K2Node_CustomEvent_BaseDamage;  // 0x1360(0x4)
	float CallFunc_ApplyDamage_ReturnValue_3;  // 0x1364(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_4;  // 0x1368(0xC)
	char pad_4980_1 : 7;  // 0x1374(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x1374(0x1)
	char pad_4981[3];  // 0x1375(0x3)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue_4;  // 0x1378(0x8)
	char pad_4992_1 : 7;  // 0x1380(0x1)
	bool CallFunc_Handled_Damage_Success : 1;  // 0x1380(0x1)
	char pad_4993[7];  // 0x1381(0x7)
	struct TArray<char> K2Node_CustomEvent_SessionAuthTicket;  // 0x1388(0x10)
	struct FString K2Node_CustomEvent_SteamID;  // 0x1398(0x10)
	char pad_5032_1 : 7;  // 0x13A8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x13A8(0x1)
	char pad_5033[7];  // 0x13A9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_41;  // 0x13B0(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_12;  // 0x13B8(0x8)
	char pad_5056_1 : 7;  // 0x13C0(0x1)
	bool K2Node_DynamicCast_bSuccess_34 : 1;  // 0x13C0(0x1)
	char pad_5057_1 : 7;  // 0x13C1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_7 : 1;  // 0x13C1(0x1)
	char pad_5058[6];  // 0x13C2(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_42;  // 0x13C8(0x8)
	char pad_5072_1 : 7;  // 0x13D0(0x1)
	bool CallFunc_HasAuthority_ReturnValue_7 : 1;  // 0x13D0(0x1)
	char pad_5073_1 : 7;  // 0x13D1(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x13D1(0x1)
	char pad_5074[6];  // 0x13D2(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_43;  // 0x13D8(0x8)
	char pad_5088_1 : 7;  // 0x13E0(0x1)
	bool CallFunc_HasAuthority_ReturnValue_8 : 1;  // 0x13E0(0x1)
	char pad_5089[7];  // 0x13E1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_44;  // 0x13E8(0x8)
	struct FVector CallFunc_MakeVector_ReturnValue_5;  // 0x13F0(0xC)
	char pad_5116[4];  // 0x13FC(0x4)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_13;  // 0x1400(0x8)
	char pad_5128_1 : 7;  // 0x1408(0x1)
	bool K2Node_DynamicCast_bSuccess_35 : 1;  // 0x1408(0x1)
	char pad_5129[3];  // 0x1409(0x3)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x140C(0xC)
	char pad_5144_1 : 7;  // 0x1418(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_8 : 1;  // 0x1418(0x1)
	char pad_5145[7];  // 0x1419(0x7)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue_2;  // 0x1420(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_45;  // 0x1428(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_14;  // 0x1430(0x8)
	char pad_5176_1 : 7;  // 0x1438(0x1)
	bool K2Node_DynamicCast_bSuccess_36 : 1;  // 0x1438(0x1)
	char pad_5177_1 : 7;  // 0x1439(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_9 : 1;  // 0x1439(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Load Player
// Size: 0x51(Inherited: 0x0) 
struct FSERVER Load Player
{
	struct FS_PlayerCustomization Customization Data;  // 0x0(0x50)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Load Customization : 1;  // 0x50(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.AuthenticateSteamClient
// Size: 0x20(Inherited: 0x0) 
struct FAuthenticateSteamClient
{
	struct TArray<char> SessionAuthTicket;  // 0x0(0x10)
	struct FString SteamID;  // 0x10(0x10)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Movement Mode
// Size: 0x1A(Inherited: 0x0) 
struct FOnRep_Movement Mode
{
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x0(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_On_Movement_Mode_Updated_Success : 1;  // 0x19(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Set Loaded
// Size: 0x1(Inherited: 0x0) 
struct FSet Loaded
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Is Loaded : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Set Location
// Size: 0xC(Inherited: 0x0) 
struct FMULTICAST Set Location
{
	struct FVector NewLocation;  // 0x0(0xC)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Play Consume Sound
// Size: 0x8(Inherited: 0x0) 
struct FPlay Consume Sound
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Set Customization Data
// Size: 0x50(Inherited: 0x0) 
struct FSet Customization Data
{
	struct FS_PlayerCustomization Customization Data;  // 0x0(0x50)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Remove Holster For all 
// Size: 0x10(Inherited: 0x0) 
struct FRemove Holster For all 
{
	struct UStaticMesh* Holster Mesh;  // 0x0(0x8)
	AActor* Holster Class;  // 0x8(0x8)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Set To Spawn Location
// Size: 0xC(Inherited: 0x0) 
struct FSet To Spawn Location
{
	struct FVector Location;  // 0x0(0xC)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Load Possession Data
// Size: 0x8(Inherited: 0x0) 
struct FLoad Possession Data
{
	struct APlayerController* Player Controller;  // 0x0(0x8)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Destroy Holster Socket
// Size: 0xC6(Inherited: 0x0) 
struct FDestroy Holster Socket
{
	char E_HolsterSockets Holster Socket;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Return : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t L Holster Index;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x18(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x38(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Remove_Holster_Component_Return : 1;  // 0x60(0x1)
	char pad_97[15];  // 0x61(0xF)
	struct FS_HolsterData CallFunc_Array_Get_Item_2;  // 0x70(0x50)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xC5(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Load Holsters
// Size: 0x10(Inherited: 0x0) 
struct FLoad Holsters
{
	struct TArray<struct FS_HolsterData> Holster Data;  // 0x0(0x10)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Toggle Aiming
// Size: 0x1(Inherited: 0x0) 
struct FToggle Aiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.On Landed
// Size: 0x8C(Inherited: 0x0) 
struct FOn Landed
{
	struct FHitResult Hit;  // 0x0(0x8C)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Set Ragdoll Location
// Size: 0xC(Inherited: 0x0) 
struct FMULTICAST Set Ragdoll Location
{
	struct FVector Ragdoll Location;  // 0x0(0xC)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Apply Armor
// Size: 0x28(Inherited: 0x0) 
struct FSERVER Apply Armor
{
	struct FS_PlayerArmor Armor IDs;  // 0x0(0x28)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Remove Holster
// Size: 0x10(Inherited: 0x0) 
struct FSERVER Remove Holster
{
	struct UStaticMesh* Holster Mesh;  // 0x0(0x8)
	AActor* Holster Class;  // 0x8(0x8)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Remove Holster
// Size: 0x10(Inherited: 0x0) 
struct FRemove Holster
{
	struct UStaticMesh* Holster Mesh;  // 0x0(0x8)
	AActor* Holster Class;  // 0x8(0x8)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Player Name
// Size: 0x19(Inherited: 0x0) 
struct FOnRep_Player Name
{
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x0(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Apply Armor
// Size: 0x28(Inherited: 0x0) 
struct FApply Armor
{
	struct FS_PlayerArmor PlayerArmor;  // 0x0(0x28)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER On Landed
// Size: 0x4(Inherited: 0x0) 
struct FSERVER On Landed
{
	float Fall Velocity;  // 0x0(0x4)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Remove Holster Socket
// Size: 0x1(Inherited: 0x0) 
struct FMULTICAST Remove Holster Socket
{
	char E_HolsterSockets Holster Socket;  // 0x0(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Add Holster
// Size: 0x50(Inherited: 0x0) 
struct FSERVER Add Holster
{
	struct FS_HolsterData Holster Data;  // 0x0(0x50)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Remove Holster Socket
// Size: 0x1(Inherited: 0x0) 
struct FSERVER Remove Holster Socket
{
	char E_HolsterSockets Holster Socket;  // 0x0(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Remove Holster Socket
// Size: 0x1(Inherited: 0x0) 
struct FRemove Holster Socket
{
	char E_HolsterSockets Holster Socket;  // 0x0(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.MULTICAST Add Holster
// Size: 0x50(Inherited: 0x0) 
struct FMULTICAST Add Holster
{
	struct FS_HolsterData Holster Data;  // 0x0(0x50)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Add Holster
// Size: 0x50(Inherited: 0x0) 
struct FAdd Holster
{
	struct FS_HolsterData Holster Data;  // 0x0(0x50)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Vehicle Attachment
// Size: 0x19(Inherited: 0x0) 
struct FOnRep_Vehicle Attachment
{
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x0(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Set Data
// Size: 0x4(Inherited: 0x0) 
struct FSet Data
{
	int32_t Level;  // 0x0(0x4)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Toggle Aiming
// Size: 0x1(Inherited: 0x0) 
struct FSERVER Toggle Aiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.SERVER Set Ragdoll Location
// Size: 0xC(Inherited: 0x0) 
struct FSERVER Set Ragdoll Location
{
	struct FVector Ragdoll Location;  // 0x0(0xC)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Set Ragdoll Location
// Size: 0xC(Inherited: 0x0) 
struct FSet Ragdoll Location
{
	struct FVector Ragdoll Location;  // 0x0(0xC)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Find Level Suffix
// Size: 0xDB(Inherited: 0x0) 
struct FFind Level Suffix
{
	int32_t Level;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Suffix;  // 0x8(0x18)
	struct FText L Current Suffix;  // 0x20(0x18)
	struct FS_Level L Current Array Element;  // 0x38(0x20)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x5C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x70(0x8)
	struct UBP_Player_ExperienceComponent_C* CallFunc_Get_Leveling_Component_Leveling_Component;  // 0x78(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x80(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FS_Level CallFunc_Array_Get_Item;  // 0x90(0x20)
	struct FS_Level CallFunc_Array_Get_Item_2;  // 0xB0(0x20)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xD5(0x1)
	char pad_214_1 : 7;  // 0xD6(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0xD6(0x1)
	char pad_215_1 : 7;  // 0xD7(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0xD7(0x1)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool Temp_bool_Variable : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool K2Node_Select_Default : 1;  // 0xDA(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Update Customization
// Size: 0x50(Inherited: 0x0) 
struct FUpdate Customization
{
	struct FS_PlayerCustomization Customization Data;  // 0x0(0x50)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.On Water Entered
// Size: 0xC(Inherited: 0x0) 
struct FOn Water Entered
{
	struct FVector Hit Location;  // 0x0(0xC)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Load Customization Data
// Size: 0x91(Inherited: 0x0) 
struct FLoad Customization Data
{
	struct FS_PlayerCustomization Customization Data;  // 0x0(0x50)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Valid : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString CallFunc_Get_Customization_Slot_Name_ReturnValue;  // 0x58(0x10)
	struct FString CallFunc_Get_Customization_Slot_Name_ReturnValue_2;  // 0x68(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct USAV_Customization_C* K2Node_DynamicCast_AsSAV_Customization;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Update Water Camera
// Size: 0xF9(Inherited: 0x0) 
struct FUpdate Water Camera
{
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x0(0x10)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x28(0x8)
	struct FRotator CallFunc_GetCameraRotation_ReturnValue;  // 0x30(0xC)
	struct FVector CallFunc_GetCameraLocation_ReturnValue;  // 0x3C(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x48(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x54(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x60(0xC)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x6C(0x8C)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0xF8(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Do Water Trace
// Size: 0x1AC(Inherited: 0x0) 
struct FDo Water Trace
{
	float Water Deepness;  // 0x0(0x4)
	struct FVector ImpactPoint;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Temp_float_Variable;  // 0x14(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x18(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x34(0xC)
	float CallFunc_BreakVector_X;  // 0x40(0x4)
	float CallFunc_BreakVector_Y;  // 0x44(0x4)
	float CallFunc_BreakVector_Z;  // 0x48(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x4C(0xC)
	float CallFunc_BreakVector_X_2;  // 0x58(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x5C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x68(0x10)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x78(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x7C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x80(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x8C(0xC)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x98(0x8C)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x124(0x1)
	char pad_293_1 : 7;  // 0x125(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x125(0x1)
	char pad_294_1 : 7;  // 0x126(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x126(0x1)
	char pad_295[1];  // 0x127(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x128(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x12C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x130(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x13C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x148(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x154(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x160(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x168(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x170(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x178(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x180(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x184(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x188(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x194(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1A0(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x1A4(0x4)
	float K2Node_Select_Default;  // 0x1A8(0x4)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Create Holster
// Size: 0x2D9(Inherited: 0x0) 
struct FCreate Holster
{
	struct FS_HolsterData Holster Data;  // 0x0(0x50)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Save : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t L Holster Index;  // 0x54(0x4)
	struct USceneComponent* L Holster Reference;  // 0x58(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x60(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x78(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8A(0x1)
	char pad_139_1 : 7;  // 0x8B(0x1)
	bool CallFunc_IsValidClass_ReturnValue_2 : 1;  // 0x8B(0x1)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x90(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x94(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x98(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0xA8(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct USkeletalMeshComponent* CallFunc_Get_Character_Mesh_Mesh;  // 0xC8(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0xD0(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_2;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct USceneComponent* CallFunc_Create_Child_Actor_Component_Return;  // 0xF0(0x8)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x100(0x8)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0x108(0x4)
	char pad_268_1 : 7;  // 0x10C(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	struct USkeletalMeshComponent* CallFunc_Get_Character_Mesh_Mesh_2;  // 0x110(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // 0x118(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_3;  // 0x120(0x10)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct USceneComponent* CallFunc_Create_Static_Mesh_Component_Return;  // 0x138(0x8)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult;  // 0x140(0x8C)
	char pad_460_1 : 7;  // 0x1CC(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x1CC(0x1)
	char pad_461_1 : 7;  // 0x1CD(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1CD(0x1)
	char pad_462[2];  // 0x1CE(0x2)
	struct AActor* CallFunc_GetOwner_ReturnValue_6;  // 0x1D0(0x8)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x1E0(0x1)
	char pad_481_1 : 7;  // 0x1E1(0x1)
	bool CallFunc_Remove_Holster_Component_Return : 1;  // 0x1E1(0x1)
	char pad_482_1 : 7;  // 0x1E2(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1E2(0x1)
	char pad_483[13];  // 0x1E3(0xD)
	struct FS_HolsterData CallFunc_Array_Get_Item_2;  // 0x1F0(0x50)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x240(0x4)
	char pad_580_1 : 7;  // 0x244(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0x244(0x1)
	char pad_581_1 : 7;  // 0x245(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x245(0x1)
	char pad_582_1 : 7;  // 0x246(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x246(0x1)
	char pad_583_1 : 7;  // 0x247(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x247(0x1)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x248(0x1)
	char pad_585_1 : 7;  // 0x249(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x249(0x1)
	char pad_586_1 : 7;  // 0x24A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x24A(0x1)
	char pad_587_1 : 7;  // 0x24B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x24B(0x1)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult_2;  // 0x24C(0x8C)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x2D8(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Destroy Holster
// Size: 0xD7(Inherited: 0x0) 
struct FDestroy Holster
{
	struct UStaticMesh* Holster Mesh;  // 0x0(0x8)
	AActor* Holster Class;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Return : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t L Holster Index;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x28(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x40(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Remove_Holster_Component_Return : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FS_HolsterData CallFunc_Array_Get_Item_2;  // 0x80(0x50)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0xD5(0x1)
	char pad_214_1 : 7;  // 0xD6(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xD6(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Can Emote
// Size: 0x2A(Inherited: 0x0) 
struct FCan Emote
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_VSize_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x29(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Get Character Mesh
// Size: 0x19(Inherited: 0x0) 
struct FGet Character Mesh
{
	struct USkeletalMeshComponent* Mesh;  // 0x0(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Level
// Size: 0x19(Inherited: 0x0) 
struct FOnRep_Level
{
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x0(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Player Armor
// Size: 0x114(Inherited: 0x0) 
struct FOnRep_Player Armor
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x24(0x8)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_Get_Item_Data_from_ID_bIsValid : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	struct FS_InventoryItemData CallFunc_Get_Item_Data_from_ID_Item_Data;  // 0x30(0xE0)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x110(0x4)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.OnRep_Player Unque ID
// Size: 0x19(Inherited: 0x0) 
struct FOnRep_Player Unque ID
{
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x0(0x8)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Update Oxygen
// Size: 0x38(Inherited: 0x0) 
struct FUpdate Oxygen
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x14(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x28(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_FClamp_ReturnValue_2;  // 0x34(0x4)

}; 
// Function BP_PlayerComponent.BP_PlayerComponent_C.Update In Vehicle Movement
// Size: 0x2A(Inherited: 0x0) 
struct FUpdate In Vehicle Movement
{
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0xC(0xC)
	struct FVector CallFunc_GetUpVector_ReturnValue_2;  // 0x18(0xC)
	float CallFunc_Dot_VectorVector_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x29(0x1)

}; 
