#pragma once 
#include <BP_NPC_Base_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_NPC_Base.BP_NPC_Base_C
// Size: 0x5B8(Inherited: 0x4C0) 
struct ABP_NPC_Base_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct USkeletalMeshComponent* Beard;  // 0x4C8(0x8)
	struct USkeletalMeshComponent* Eyes;  // 0x4D0(0x8)
	struct USkeletalMeshComponent* Eyebrows;  // 0x4D8(0x8)
	struct USkeletalMeshComponent* Backpack;  // 0x4E0(0x8)
	struct USkeletalMeshComponent* head;  // 0x4E8(0x8)
	struct USkeletalMeshComponent* Bottom;  // 0x4F0(0x8)
	struct USkeletalMeshComponent* Torso;  // 0x4F8(0x8)
	struct USkeletalMeshComponent* Feet;  // 0x500(0x8)
	struct UWidgetComponent* Nametag Widget;  // 0x508(0x8)
	struct FName NPC Name;  // 0x510(0x8)
	struct UDataTable* Dialogue Datatable;  // 0x518(0x8)
	struct FName Default Dialogue ID;  // 0x520(0x8)
	float Cached Actor Rotation;  // 0x528(0x4)
	float Cached Turn In Place Alpha;  // 0x52C(0x4)
	float Cached Control Rotation;  // 0x530(0x4)
	char pad_1332[4];  // 0x534(0x4)
	struct AActor* Looking Actor;  // 0x538(0x8)
	struct UMaterialInstanceDynamic* Human Dynamic Material;  // 0x540(0x8)
	struct USkeletalMesh* Head Mesh;  // 0x548(0x8)
	struct USkeletalMesh* Torso Mesh;  // 0x550(0x8)
	struct USkeletalMesh* Bottom Mesh;  // 0x558(0x8)
	struct USkeletalMesh* Feet Mesh;  // 0x560(0x8)
	struct USkeletalMesh* Eyebrows Mesh;  // 0x568(0x8)
	struct USkeletalMesh* Eyes Mesh;  // 0x570(0x8)
	struct USkeletalMesh* Beard Mesh;  // 0x578(0x8)
	struct USkeletalMesh* Backpack Mesh;  // 0x580(0x8)
	struct FLinearColor Skin Color;  // 0x588(0x10)
	struct FLinearColor Stubble Color;  // 0x598(0x10)
	struct FLinearColor Hair Color;  // 0x5A8(0x10)

	void On Question Answered(struct FName Unique ID, struct UBP_MissionComponent_C* Caller, bool& Success); // Function BP_NPC_Base.BP_NPC_Base_C.On Question Answered
	void Local Can Overlap(bool& Success); // Function BP_NPC_Base.BP_NPC_Base_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_NPC_Base.BP_NPC_Base_C.Get Interaction Data
	void Select Dialogue(struct UBP_MissionComponent_C* MissionComponent, struct FName& Dialogue ID); // Function BP_NPC_Base.BP_NPC_Base_C.Select Dialogue
	void UserConstructionScript(); // Function BP_NPC_Base.BP_NPC_Base_C.UserConstructionScript
	void On Interacted(struct AController* Executor); // Function BP_NPC_Base.BP_NPC_Base_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_NPC_Base.BP_NPC_Base_C.Toggle Selected
	void ReceiveTick(float DeltaSeconds); // Function BP_NPC_Base.BP_NPC_Base_C.ReceiveTick
	void Local Overlap(bool Overlap); // Function BP_NPC_Base.BP_NPC_Base_C.Local Overlap
	void ExecuteUbergraph_BP_NPC_Base(int32_t EntryPoint); // Function BP_NPC_Base.BP_NPC_Base_C.ExecuteUbergraph_BP_NPC_Base
}; 



