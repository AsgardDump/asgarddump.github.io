#pragma once 
#include <BP_PlayerController_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PlayerController.BP_PlayerController_C
// Size: 0x650(Inherited: 0x570) 
struct ABP_PlayerController_C : public APlayerController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x570(0x8)
	struct UBP_EBS_ResourcesComponent_C* ResourcesComponent;  // 0x578(0x8)
	struct UBP_EBS_InteractionComponent_C* InteractionComponent;  // 0x580(0x8)
	struct UBP_EBS_BuildingComponent_C* BP_EBS_Building_Component;  // 0x588(0x8)
	struct UBP_OnlineComponent_C* BP_OnlineComponent;  // 0x590(0x8)
	struct UBP_PlayerInventoryComponent_C* BP_PlayerInventoryComponent;  // 0x598(0x8)
	struct UBP_Player_ExperienceComponent_C* BP_Player_ExperienceComponent;  // 0x5A0(0x8)
	struct UBP_SkillTreeComponent_C* BPC_SkillTree;  // 0x5A8(0x8)
	struct UBP_MissionComponent_C* BP_MissionComponent;  // 0x5B0(0x8)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> LoadedBuildingObjects;  // 0x5B8(0x10)
	char E_EBS_ViewMode ViewMode;  // 0x5C8(0x1)
	char pad_1481[7];  // 0x5C9(0x7)
	struct FS_InventoryItem Array Element;  // 0x5D0(0x30)
	char pad_1536_1 : 7;  // 0x600(0x1)
	bool Shift Pressed : 1;  // 0x600(0x1)
	char pad_1537_1 : 7;  // 0x601(0x1)
	bool ShiftPressed : 1;  // 0x601(0x1)
	char pad_1538[6];  // 0x602(0x6)
	struct TArray<char> SessionAuthTicket;  // 0x608(0x10)
	struct FSteamTicketHandle Ticket Handle;  // 0x618(0x4)
	char pad_1564[4];  // 0x61C(0x4)
	struct FSteamID SteamID;  // 0x620(0x8)
	struct ABP_EBS_Building_CodeLock_C* NewVar_1;  // 0x628(0x8)
	struct USteamCoreVoice* SoundObj;  // 0x630(0x8)
	int32_t SampleRate;  // 0x638(0x4)
	char pad_1596[4];  // 0x63C(0x4)
	struct UBP_GameInstance_UMSP_C* Game Instance;  // 0x640(0x8)
	struct UBP_PlayerInventoryComponent_C* BP Player Inventory Component;  // 0x648(0x8)

	void CheckRequirements_BPI(struct FDataTableRowHandle Handle, bool& Success); // Function BP_PlayerController.BP_PlayerController_C.CheckRequirements_BPI
	void GetResources_BPI(struct TArray<struct FS_InventoryItem>& Resources); // Function BP_PlayerController.BP_PlayerController_C.GetResources_BPI
	void CheckResources_BPI(struct TArray<struct FS_InventoryItem>& Resources, bool& Result); // Function BP_PlayerController.BP_PlayerController_C.CheckResources_BPI
	void Get Chat Widget(struct UW_Chat_C*& Chat Widget Reference); // Function BP_PlayerController.BP_PlayerController_C.Get Chat Widget
	void RemoveResources(struct TArray<struct FS_InventoryItem>& Resources); // Function BP_PlayerController.BP_PlayerController_C.RemoveResources
	void CheckforResources(struct TArray<struct FS_InventoryItem>& Resources, bool& Result); // Function BP_PlayerController.BP_PlayerController_C.CheckforResources
	void CheckforBuildingResources(struct FS_InventoryItem Resource, bool& Result); // Function BP_PlayerController.BP_PlayerController_C.CheckforBuildingResources
	void ChangeDurability_BPI(char E_EBS_ChangeVariableOperation Operation, float Value, bool& Success); // Function BP_PlayerController.BP_PlayerController_C.ChangeDurability_BPI
	void SetMaxDurability_BPI(float Value, bool& Success); // Function BP_PlayerController.BP_PlayerController_C.SetMaxDurability_BPI
	void GetDurability_BPI(float& CurrentValue, float& MaxValue); // Function BP_PlayerController.BP_PlayerController_C.GetDurability_BPI
	void SetFloorNumber_BPI(int32_t FloorNumber, bool& Success); // Function BP_PlayerController.BP_PlayerController_C.SetFloorNumber_BPI
	void GetFloorNumber_BPI(int32_t& FloorNumber); // Function BP_PlayerController.BP_PlayerController_C.GetFloorNumber_BPI
	void SetFloorActorHidden_BPI(bool NewHidden, bool& Success); // Function BP_PlayerController.BP_PlayerController_C.SetFloorActorHidden_BPI
	void IsCanInteract_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, bool& Result); // Function BP_PlayerController.BP_PlayerController_C.IsCanInteract_BPI
	void GetInteractionObjectName_BPI(struct FText& Name); // Function BP_PlayerController.BP_PlayerController_C.GetInteractionObjectName_BPI
	void GetInteractionText_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, struct FText& InteractionText); // Function BP_PlayerController.BP_PlayerController_C.GetInteractionText_BPI
	void GetOwners_BPI(struct TArray<struct FString>& OwnerNames); // Function BP_PlayerController.BP_PlayerController_C.GetOwners_BPI
	void CheckPlayerIsOwner_BPI(struct APlayerController* PlayerController, bool& IsOwner); // Function BP_PlayerController.BP_PlayerController_C.CheckPlayerIsOwner_BPI
	void GetOwnershipInfo_BPI(bool& IsOwned, struct TArray<struct FString>& OwnerNames, float& OwnershipDistance); // Function BP_PlayerController.BP_PlayerController_C.GetOwnershipInfo_BPI
	void Remove Holster Component(struct USceneComponent* Component, bool& Return); // Function BP_PlayerController.BP_PlayerController_C.Remove Holster Component
	void Create Child Actor Component(AActor* Actor, struct USceneComponent*& Return); // Function BP_PlayerController.BP_PlayerController_C.Create Child Actor Component
	void Create Static Mesh Component(struct UStaticMesh* Mesh, struct USceneComponent*& Return); // Function BP_PlayerController.BP_PlayerController_C.Create Static Mesh Component
	void Get Hand IK Points(struct FVector& Hand IK L World Space, struct FVector& Hand IK R World Space); // Function BP_PlayerController.BP_PlayerController_C.Get Hand IK Points
	void Is Alive(bool& Is Alive); // Function BP_PlayerController.BP_PlayerController_C.Is Alive
	void Is Player Controlled(bool& Player Controlled); // Function BP_PlayerController.BP_PlayerController_C.Is Player Controlled
	void On Movement Mode Updated(char E_PlayerMovementMode Movement Mode, bool& Success); // Function BP_PlayerController.BP_PlayerController_C.On Movement Mode Updated
	void Can Toggle Menu(bool& Pass); // Function BP_PlayerController.BP_PlayerController_C.Can Toggle Menu
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_32(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_32
	void InpActEvt_R_K2Node_InputKeyEvent_31(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_R_K2Node_InputKeyEvent_31
	void InpActEvt_R_K2Node_InputKeyEvent_30(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_R_K2Node_InputKeyEvent_30
	void InpActEvt_Tab_K2Node_InputKeyEvent_29(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Tab_K2Node_InputKeyEvent_29
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_28(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_28
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_27(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_27
	void InpActEvt_M_K2Node_InputKeyEvent_26(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_M_K2Node_InputKeyEvent_26
	void InpActEvt_RightMouseButton_K2Node_InputKeyEvent_25(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_RightMouseButton_K2Node_InputKeyEvent_25
	void InpActEvt_RightMouseButton_K2Node_InputKeyEvent_24(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_RightMouseButton_K2Node_InputKeyEvent_24
	void InpActEvt_Enter_K2Node_InputKeyEvent_23(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Enter_K2Node_InputKeyEvent_23
	void InpActEvt_One_K2Node_InputKeyEvent_22(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_One_K2Node_InputKeyEvent_22
	void InpActEvt_Two_K2Node_InputKeyEvent_21(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Two_K2Node_InputKeyEvent_21
	void InpActEvt_Three_K2Node_InputKeyEvent_20(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Three_K2Node_InputKeyEvent_20
	void InpActEvt_Four_K2Node_InputKeyEvent_19(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Four_K2Node_InputKeyEvent_19
	void InpActEvt_Five_K2Node_InputKeyEvent_18(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Five_K2Node_InputKeyEvent_18
	void InpActEvt_Six_K2Node_InputKeyEvent_17(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Six_K2Node_InputKeyEvent_17
	void InpActEvt_Seven_K2Node_InputKeyEvent_16(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Seven_K2Node_InputKeyEvent_16
	void InpActEvt_Eight_K2Node_InputKeyEvent_15(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Eight_K2Node_InputKeyEvent_15
	void InpActEvt_R_K2Node_InputKeyEvent_14(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_R_K2Node_InputKeyEvent_14
	void InpActEvt_B_K2Node_InputKeyEvent_13(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_B_K2Node_InputKeyEvent_13
	void InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_12(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_12
	void InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_11(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_11
	void InpActEvt_Escape_K2Node_InputKeyEvent_10(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Escape_K2Node_InputKeyEvent_10
	void InpActEvt_X_K2Node_InputKeyEvent_9(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_X_K2Node_InputKeyEvent_9
	void InpActEvt_Delete_K2Node_InputKeyEvent_8(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Delete_K2Node_InputKeyEvent_8
	void InpActEvt_T_K2Node_InputKeyEvent_7(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_T_K2Node_InputKeyEvent_7
	void InpActEvt_T_K2Node_InputKeyEvent_6(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_T_K2Node_InputKeyEvent_6
	void InpActEvt_P_K2Node_InputKeyEvent_5(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_P_K2Node_InputKeyEvent_5
	void InpActEvt_I_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_I_K2Node_InputKeyEvent_4
	void InpActEvt_Ctrl+Alt_Delete_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_Ctrl+Alt_Delete_K2Node_InputKeyEvent_3
	void InpActEvt_V_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_V_K2Node_InputKeyEvent_2
	void InpActEvt_V_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_PlayerController.BP_PlayerController_C.InpActEvt_V_K2Node_InputKeyEvent_1
	void AddResource_BPI(struct FSTR_EBS_Resource Resource); // Function BP_PlayerController.BP_PlayerController_C.AddResource_BPI
	void AddResources_BPI(struct TArray<struct FSTR_EBS_Resource>& Resources); // Function BP_PlayerController.BP_PlayerController_C.AddResources_BPI
	void SetResources_BPI(struct TArray<struct FSTR_EBS_Resource>& Resources); // Function BP_PlayerController.BP_PlayerController_C.SetResources_BPI
	void On Weather Changed(struct FName Weather Name); // Function BP_PlayerController.BP_PlayerController_C.On Weather Changed
	void Toggle Raining(bool Toggle); // Function BP_PlayerController.BP_PlayerController_C.Toggle Raining
	void TryStartBuildObject_BPI(struct FDataTableRowHandle BuildingObjectHandle); // Function BP_PlayerController.BP_PlayerController_C.TryStartBuildObject_BPI
	void SetBuildingMode_BPI(char E_EBS_BuildingMode BuildingMode); // Function BP_PlayerController.BP_PlayerController_C.SetBuildingMode_BPI
	void UpdateBuildingList_BPI(struct FDataTableRowHandle BuildingListHandle); // Function BP_PlayerController.BP_PlayerController_C.UpdateBuildingList_BPI
	void OpenCodeLock_BPI(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.OpenCodeLock_BPI
	void UpdateCodeLock_BPI(struct ABP_EBS_Building_CodeLock_C* CodeLock, bool IsLocked, bool IsAuthorized, struct FString Password); // Function BP_PlayerController.BP_PlayerController_C.UpdateCodeLock_BPI
	void UpdateCodeLock (Client)(struct ABP_EBS_Building_CodeLock_C* CodeLock, bool IsLocked, bool IsAuthorized, struct FString Password); // Function BP_PlayerController.BP_PlayerController_C.UpdateCodeLock (Client)
	void CloseCodeLock_BPI(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.CloseCodeLock_BPI
	void CloseCodeLock (Server)(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.CloseCodeLock (Server)
	void OpenCodeLock (Server)(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.OpenCodeLock (Server)
	void ShowCodeLockWidget_BPI(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.ShowCodeLockWidget_BPI
	void ShowCodeLockWidget (Client)(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.ShowCodeLockWidget (Client)
	void HideCodeLockWidget_BPI(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.HideCodeLockWidget_BPI
	void HideCodeLockWidget (Client)(struct ABP_EBS_Building_CodeLock_C* CodeLock); // Function BP_PlayerController.BP_PlayerController_C.HideCodeLockWidget (Client)
	void TryToSetCodeLockPassword_BPI(struct ABP_EBS_Building_CodeLock_C* CodeLock, struct FString Password); // Function BP_PlayerController.BP_PlayerController_C.TryToSetCodeLockPassword_BPI
	void TryToSetCodeLockPassword (Server)(struct ABP_EBS_Building_CodeLock_C* CodeLock, struct FString Password); // Function BP_PlayerController.BP_PlayerController_C.TryToSetCodeLockPassword (Server)
	void CompleteRequirements_BPI(struct FDataTableRowHandle Handle); // Function BP_PlayerController.BP_PlayerController_C.CompleteRequirements_BPI
	void RemoveResources_BPI(struct TArray<struct FS_InventoryItem>& Resources); // Function BP_PlayerController.BP_PlayerController_C.RemoveResources_BPI
	void SetThirdPersonView(); // Function BP_PlayerController.BP_PlayerController_C.SetThirdPersonView
	void ChangeViewMode(); // Function BP_PlayerController.BP_PlayerController_C.ChangeViewMode
	void SaveBuildingObjects (Server)(); // Function BP_PlayerController.BP_PlayerController_C.SaveBuildingObjects (Server)
	void LoadBuildingObjects (Server)(); // Function BP_PlayerController.BP_PlayerController_C.LoadBuildingObjects (Server)
	void TryRotate_BPI(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_PlayerController.BP_PlayerController_C.TryRotate_BPI
	void TryRepair_BPI(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_PlayerController.BP_PlayerController_C.TryRepair_BPI
	void TryUpgrade_BPI(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_PlayerController.BP_PlayerController_C.TryUpgrade_BPI
	void TryRemove_BPI(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_PlayerController.BP_PlayerController_C.TryRemove_BPI
	void TryDestruct_BPI(struct ABP_EBS_Building_BaseObject_C* TargetObject); // Function BP_PlayerController.BP_PlayerController_C.TryDestruct_BPI
	void DamageActor (Server)(struct AActor* TargetActor, float Damage); // Function BP_PlayerController.BP_PlayerController_C.DamageActor (Server)
	void DamageTrace(); // Function BP_PlayerController.BP_PlayerController_C.DamageTrace
	void BndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_2_ActorComponentActivatedSignature__DelegateSignature(struct UActorComponent* Component, bool bReset); // Function BP_PlayerController.BP_PlayerController_C.BndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_2_ActorComponentActivatedSignature__DelegateSignature
	void BndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_3_ActorComponentDeactivateSignature__DelegateSignature(struct UActorComponent* Component); // Function BP_PlayerController.BP_PlayerController_C.BndEvt__BP_PlayerController_BP_EBS_Building_Component_K2Node_ComponentBoundEvent_3_ActorComponentDeactivateSignature__DelegateSignature
	void InpAxisKeyEvt_MouseWheelAxis_K2Node_InputAxisKeyEvent_1(float AxisValue); // Function BP_PlayerController.BP_PlayerController_C.InpAxisKeyEvt_MouseWheelAxis_K2Node_InputAxisKeyEvent_1
	void SERVER Skip Revive(); // Function BP_PlayerController.BP_PlayerController_C.SERVER Skip Revive
	void ReceiveBeginPlay(); // Function BP_PlayerController.BP_PlayerController_C.ReceiveBeginPlay
	void ReceivePossess(struct APawn* PossessedPawn); // Function BP_PlayerController.BP_PlayerController_C.ReceivePossess
	void ReceiveUnPossess(struct APawn* UnpossessedPawn); // Function BP_PlayerController.BP_PlayerController_C.ReceiveUnPossess
	void On Rain(bool Raining?); // Function BP_PlayerController.BP_PlayerController_C.On Rain
	void ServerAuthenticateSteamClient(struct TArray<char>& SessionAuthTicket, struct FString SteamID); // Function BP_PlayerController.BP_PlayerController_C.ServerAuthenticateSteamClient
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_PlayerController.BP_PlayerController_C.ReceiveEndPlay
	void InventoryReady(struct FSteamInventoryResultReady& Data); // Function BP_PlayerController.BP_PlayerController_C.InventoryReady
	void SkinBTNClicked(); // Function BP_PlayerController.BP_PlayerController_C.SkinBTNClicked
	void AuthenticateSteamClient(struct TArray<char>& SessionAuthTicket, struct FString SteamID); // Function BP_PlayerController.BP_PlayerController_C.AuthenticateSteamClient
	void ExecuteUbergraph_BP_PlayerController(int32_t EntryPoint); // Function BP_PlayerController.BP_PlayerController_C.ExecuteUbergraph_BP_PlayerController
}; 



