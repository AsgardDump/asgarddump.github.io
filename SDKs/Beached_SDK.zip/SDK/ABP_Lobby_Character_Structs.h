#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Lobby_Character.ABP_Lobby_Character_C.ExecuteUbergraph_ABP_Lobby_Character
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Lobby_Character
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function ABP_Lobby_Character.ABP_Lobby_Character_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
