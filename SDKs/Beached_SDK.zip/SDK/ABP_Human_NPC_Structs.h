#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Human_NPC.ABP_Human_NPC_C.ExecuteUbergraph_ABP_Human_NPC
// Size: 0xD0(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Human_NPC
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;  // 0x4(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x8(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0xC(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x18(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x24(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0x30(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x34(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x38(0x4)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_2;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	float K2Node_Event_DeltaTimeX;  // 0x44(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x48(0x8)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x50(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x54(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x60(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x6C(0xC)
	struct FRotator CallFunc_NormalizedDeltaRotator_ReturnValue;  // 0x78(0xC)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x84(0x4)
	float CallFunc_BreakRotator_Roll_3;  // 0x88(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x8C(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x90(0x4)
	struct FRotator CallFunc_RInterpTo_ReturnValue;  // 0x94(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0xA0(0xC)
	float CallFunc_FClamp_ReturnValue;  // 0xAC(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0xB0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xB4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0xB8(0xC)
	struct FRotator CallFunc_RInterpTo_ReturnValue_2;  // 0xC4(0xC)

}; 
// Function ABP_Human_NPC.ABP_Human_NPC_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_Human_NPC.ABP_Human_NPC_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
