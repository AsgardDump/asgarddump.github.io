#pragma once 
#include <BP_Holdable_RangeWeapon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C
// Size: 0x49D(Inherited: 0x30A) 
struct ABP_Holdable_RangeWeapon_C : public ABP_Holdable_C
{
	char pad_778[6];  // 0x30A(0x6)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct USpotLightComponent* Flashlight;  // 0x318(0x8)
	struct USceneComponent* Hand IK R;  // 0x320(0x8)
	struct USceneComponent* Hand IK L;  // 0x328(0x8)
	struct USceneComponent* Trigger;  // 0x330(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x338(0x8)
	float Damage;  // 0x340(0x4)
	float Random Damage Delta Multiplier;  // 0x344(0x4)
	struct USoundBase* Shot Sound;  // 0x348(0x8)
	int32_t Ammo Magazine Size;  // 0x350(0x4)
	int32_t Current Ammo;  // 0x354(0x4)
	struct UAnimMontage* Character Reload Montage;  // 0x358(0x8)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool Reloading : 1;  // 0x360(0x1)
	char pad_865[7];  // 0x361(0x7)
	struct FTimerHandle Auto Timer Handle;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool Automatic Firemode : 1;  // 0x370(0x1)
	char pad_881[3];  // 0x371(0x3)
	float Recoil Up Amount;  // 0x374(0x4)
	float Recoil Side Amount;  // 0x378(0x4)
	struct FName Ammo Item ID;  // 0x37C(0x8)
	float Shot Delay Time;  // 0x384(0x4)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool Shot Delay : 1;  // 0x388(0x1)
	char pad_905[7];  // 0x389(0x7)
	struct UAnimSequence* Weapon Reload Animation;  // 0x390(0x8)
	struct USoundBase* Click Sound;  // 0x398(0x8)
	struct UAnimMontage* Character Shot Montage;  // 0x3A0(0x8)
	struct UAnimSequence* Weapon Shot Animation;  // 0x3A8(0x8)
	float Minus Durability On Reload;  // 0x3B0(0x4)
	char pad_948_1 : 7;  // 0x3B4(0x1)
	bool Shooting Blocked : 1;  // 0x3B4(0x1)
	char pad_949_1 : 7;  // 0x3B5(0x1)
	bool Is Aiming : 1;  // 0x3B5(0x1)
	char pad_950_1 : 7;  // 0x3B6(0x1)
	bool Automatic Reload : 1;  // 0x3B6(0x1)
	char E_Firemode Firemode;  // 0x3B7(0x1)
	int32_t Shoot Counter;  // 0x3B8(0x4)
	char pad_956[4];  // 0x3BC(0x4)
	struct TSet<char E_WeaponAttachmentType> Allowed Attachments;  // 0x3C0(0x50)
	struct TMap<char E_WeaponAttachmentType, struct FS_AppliedWeaponAttachment> Applied Attachments;  // 0x410(0x50)
	struct TArray<struct UWidgetComponent*> Attached Widgets;  // 0x460(0x10)
	struct UCineCameraComponent* Attachment Camera;  // 0x470(0x8)
	char pad_1144_1 : 7;  // 0x478(0x1)
	bool Upgrade Mode : 1;  // 0x478(0x1)
	char pad_1145[7];  // 0x479(0x7)
	struct TArray<char> Replicated Applied Attachments;  // 0x480(0x10)
	char pad_1168_1 : 7;  // 0x490(0x1)
	bool Flashlight Toggle : 1;  // 0x490(0x1)
	char pad_1169[3];  // 0x491(0x3)
	struct FName Item ID;  // 0x494(0x8)
	char pad_1180_1 : 7;  // 0x49C(0x1)
	bool Exo : 1;  // 0x49C(0x1)

	void Can Toggle Menu(bool& Pass); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Can Toggle Menu
	void OnRep_Flashlight Toggle(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.OnRep_Flashlight Toggle
	void Broadcast Attachments(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Broadcast Attachments
	void OnRep_Replicated Applied Attachments(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.OnRep_Replicated Applied Attachments
	void Apply Attachment(struct FName& Attachment Item Name, bool& Success, char E_WeaponAttachmentType& OutputPin); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Apply Attachment
	void Toggle Upgrade Mode(bool Toggle); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Toggle Upgrade Mode
	void Load Attachments(struct TArray<char>& Attachment IDs); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Load Attachments
	void Hit Detection(struct TArray<struct FHitResult>& HIts, struct FVector End Trace, struct FHitResult& Surface Hit, struct FVector& Water Hit Location); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Hit Detection
	void Detect Shooting Block(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Detect Shooting Block
	float Get Damage(struct FHitResult& Hit); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Get Damage
	void Reload Ammo from Inventory(bool& Success, int32_t& Amount to Reload); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Reload Ammo from Inventory
	void Update Ammo in Inventory(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Update Ammo in Inventory
	void Apply Local Recoil(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Apply Local Recoil
	void Do Custom Shot Effects(bool Bullet Hit, struct FHitResult Hit , bool No Ammo, struct FVector Water Hit); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Do Custom Shot Effects
	void UserConstructionScript(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.UserConstructionScript
	void SERVER Shot Action(bool Hit, struct FHitResult Hit Result, struct FVector Water Hit); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.SERVER Shot Action
	void MULTICAST Shot Action(bool Hit, struct FHitResult Hit Result, bool No Ammo, struct FVector Water Hit); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.MULTICAST Shot Action
	void Aiming Action(bool Toggle); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Aiming Action
	void Primary Action(bool Pressed); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Primary Action
	void Do Shot Action(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Do Shot Action
	void Reload(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Reload
	void MULTICAST Reload(int32_t Current Ammo); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.MULTICAST Reload
	void Update Ammo(int32_t Current Ammo); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Update Ammo
	void ReceiveBeginPlay(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.ReceiveBeginPlay
	void ReceiveDestroyed(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.ReceiveDestroyed
	void Automatic Shoot(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Automatic Shoot
	void Change Firemode(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Change Firemode
	void On Bullet Shot(bool Hit, struct FHitResult Hit Result, struct FVector Water Hit); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.On Bullet Shot
	void Decrease Ammo(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Decrease Ammo
	void SERVER Decrease Ammo(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.SERVER Decrease Ammo
	void ReceiveTick(float DeltaSeconds); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.ReceiveTick
	void Burst Shoot(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Burst Shoot
	void Remove Attachment(char E_WeaponAttachmentType Attachment); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Remove Attachment
	void Add Attachment(int32_t IndexToTest); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Add Attachment
	void CLIENT Refresh Weapon Attachment(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.CLIENT Refresh Weapon Attachment
	void Toggle Flashlight(); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.Toggle Flashlight
	void SERVER Toggle FlashLight(bool Flashlight Toggle); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.SERVER Toggle FlashLight
	void HeadshotSound(struct FVector Location); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.HeadshotSound
	void ExecuteUbergraph_BP_Holdable_RangeWeapon(int32_t EntryPoint); // Function BP_Holdable_RangeWeapon.BP_Holdable_RangeWeapon_C.ExecuteUbergraph_BP_Holdable_RangeWeapon
}; 



