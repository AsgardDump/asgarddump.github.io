#pragma once 
#include "SDK.h" 
 
 
// Function BP_Throwable_Object.BP_Throwable_Object_C.On Water Hit
// Size: 0xC(Inherited: 0x0) 
struct FOn Water Hit
{
	struct FVector Location;  // 0x0(0xC)

}; 
// Function BP_Throwable_Object.BP_Throwable_Object_C.ExecuteUbergraph_BP_Throwable_Object
// Size: 0x221(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Throwable_Object
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x18(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x20(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x2C(0x8C)
	float K2Node_Event_DeltaSeconds;  // 0xB8(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xBC(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0xC8(0x10)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0xD8(0x10)
	struct FVector K2Node_CustomEvent_Location;  // 0xE8(0xC)
	struct FHitResult CallFunc_SphereTraceSingleForObjects_OutHit;  // 0xF4(0x8C)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_SphereTraceSingleForObjects_ReturnValue : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x190(0x1)
	char pad_401_1 : 7;  // 0x191(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x191(0x1)
	char pad_402[2];  // 0x192(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x194(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x198(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x19C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1A8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1B4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x1C0(0xC)
	char pad_460[4];  // 0x1CC(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x1D0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x1D8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x1E0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x1E8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x1F0(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x1F4(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x1F8(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x204(0xC)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0x210(0x8)
	struct ABP_Water_C* K2Node_DynamicCast_AsBP_Water;  // 0x218(0x8)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x220(0x1)

}; 
// Function BP_Throwable_Object.BP_Throwable_Object_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Throwable_Object.BP_Throwable_Object_C.BndEvt__BP_Throwable_Object_ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xB0(Inherited: 0x0) 
struct FBndEvt__BP_Throwable_Object_ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x8C)

}; 
