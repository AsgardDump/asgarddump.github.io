#pragma once 
#include <BP_Holdable_RangeWeapon_Pistol_Glock_Skin_3_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_Pistol_Glock_Skin_3.BP_Holdable_RangeWeapon_Pistol_Glock_Skin_2_C
// Size: 0x49D(Inherited: 0x49D) 
struct ABP_Holdable_RangeWeapon_Pistol_Glock_Skin_2_C : public ABP_Holdable_RangeWeapon_Pistol_C
{

}; 



