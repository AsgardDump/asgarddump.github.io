#pragma once 
#include <BP_Candle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Candle.BP_Candle_C
// Size: 0x4C0(Inherited: 0x4A8) 
struct ABP_Candle_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct UPointLightComponent* PointLight;  // 0x4B0(0x8)
	struct UParticleSystemComponent* P_CandleFire;  // 0x4B8(0x8)

	void ReceiveBeginPlay(); // Function BP_Candle.BP_Candle_C.ReceiveBeginPlay
	void CheckForCollisionBeneath(); // Function BP_Candle.BP_Candle_C.CheckForCollisionBeneath
	void ExecuteUbergraph_BP_Candle(int32_t EntryPoint); // Function BP_Candle.BP_Candle_C.ExecuteUbergraph_BP_Candle
}; 



