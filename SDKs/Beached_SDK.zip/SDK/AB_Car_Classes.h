#pragma once 
#include <AB_Car_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass AB_Car.AB_Car_C
// Size: 0xB98(Inherited: 0xA50) 
struct UAB_Car_C : public UVehicleAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA50(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0xA58(0x30)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0xA88(0x20)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;  // 0xAA8(0x10)
	struct FAnimNode_WheelHandler AnimGraphNode_WheelHandler;  // 0xAB8(0xE0)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function AB_Car.AB_Car_C.AnimGraph
	void ExecuteUbergraph_AB_Car(int32_t EntryPoint); // Function AB_Car.AB_Car_C.ExecuteUbergraph_AB_Car
}; 



