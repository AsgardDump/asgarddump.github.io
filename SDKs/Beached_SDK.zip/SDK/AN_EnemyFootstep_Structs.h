#pragma once 
#include "SDK.h" 
 
 
// Function AN_EnemyFootstep.AN_EnemyFootstep_C.Received_Notify
// Size: 0xAA(Inherited: 0x18) 
struct FReceived_Notify : public FReceived_Notify
{
	struct USkeletalMeshComponent* MeshComp;  // 0x0(0x8)
	struct UAnimSequenceBase* Animation;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AActor* L Owner;  // 0x18(0x8)
	struct FVector L Bone Location;  // 0x20(0xC)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x30(0x8)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x38(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x48(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x58(0x10)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x68(0x8)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x70(0x1)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue_2;  // 0x78(0x8)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x80(0xC)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x8C(0xC)
	struct TArray<struct FHitResult> CallFunc_LineTraceMultiForObjects_OutHits;  // 0x98(0x10)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_LineTraceMultiForObjects_ReturnValue : 1;  // 0xA8(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool CallFunc_Foliage_Hit_Filter_Foliage : 1;  // 0xA9(0x1)

}; 
// Function AN_EnemyFootstep.AN_EnemyFootstep_C.Foliage Hit Filter
// Size: 0xB4(Inherited: 0x0) 
struct FFoliage Hit Filter
{
	struct TArray<struct FHitResult> Hit;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Foliage : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool L Foliage Overlap : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x20(0x8C)
	char EPhysicalSurface CallFunc_GetSurfaceType_ReturnValue;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xAE(0x1)
	char pad_175[1];  // 0xAF(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB0(0x4)

}; 
