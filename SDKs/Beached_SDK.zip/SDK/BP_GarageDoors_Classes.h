#pragma once 
#include <BP_GarageDoors_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GarageDoors.BP_GarageDoors_C
// Size: 0x249(Inherited: 0x220) 
struct ABP_GarageDoors_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* Scene;  // 0x230(0x8)
	float Door_Animation_Alpha_A9043A4E43EC41587DB0349E3CD0B603;  // 0x238(0x4)
	char ETimelineDirection Door_Animation__Direction_A9043A4E43EC41587DB0349E3CD0B603;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* Door Animation;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool Door Status : 1;  // 0x248(0x1)

	void Local Can Overlap(bool& Success); // Function BP_GarageDoors.BP_GarageDoors_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_GarageDoors.BP_GarageDoors_C.Get Interaction Data
	void OnRep_Door Status(); // Function BP_GarageDoors.BP_GarageDoors_C.OnRep_Door Status
	void Door Animation__FinishedFunc(); // Function BP_GarageDoors.BP_GarageDoors_C.Door Animation__FinishedFunc
	void Door Animation__UpdateFunc(); // Function BP_GarageDoors.BP_GarageDoors_C.Door Animation__UpdateFunc
	void Local Overlap(bool Overlap); // Function BP_GarageDoors.BP_GarageDoors_C.Local Overlap
	void On Interacted(struct AController* Executor); // Function BP_GarageDoors.BP_GarageDoors_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_GarageDoors.BP_GarageDoors_C.Toggle Selected
	void Toggle Doors(bool Toggle); // Function BP_GarageDoors.BP_GarageDoors_C.Toggle Doors
	void Reset(); // Function BP_GarageDoors.BP_GarageDoors_C.Reset
	void ExecuteUbergraph_BP_GarageDoors(int32_t EntryPoint); // Function BP_GarageDoors.BP_GarageDoors_C.ExecuteUbergraph_BP_GarageDoors
}; 



