#pragma once 
#include <BP_PlayerInventoryComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C
// Size: 0x26B(Inherited: 0xCC) 
struct UBP_PlayerInventoryComponent_C : public UBP_MasterInventoryComponent_C
{
	char pad_204[4];  // 0xCC(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xD0(0x8)
	int32_t PlayerMaximum Health;  // 0xD8(0x4)
	int32_t Health;  // 0xDC(0x4)
	float Thirst;  // 0xE0(0x4)
	float Hunger;  // 0xE4(0x4)
	float Thirst Speed;  // 0xE8(0x4)
	float Hunger Speed;  // 0xEC(0x4)
	struct FTimerHandle Starving Timer;  // 0xF0(0x8)
	struct FTimerHandle Knockout Timer;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool Is Dead : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool Is Knocked : 1;  // 0x101(0x1)
	char pad_258[6];  // 0x102(0x6)
	struct UW_Knockout_C* Knockout Widget;  // 0x108(0x8)
	int32_t Revive Timeout;  // 0x110(0x4)
	int32_t Knockout Timeout;  // 0x114(0x4)
	int32_t Knocked Time;  // 0x118(0x4)
	int32_t Revive Time;  // 0x11C(0x4)
	struct AController* Reviving Player Reference;  // 0x120(0x8)
	struct FTimerHandle Revive Timer;  // 0x128(0x8)
	struct ABP_Holdable_C* Holdable Actor;  // 0x130(0x8)
	char E_LoadingScren Loading Screen Type;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct TArray<struct FS_Tip> Tips;  // 0x140(0x10)
	struct FText Custom Text;  // 0x150(0x18)
	float Stamina;  // 0x168(0x4)
	float Stamina Decrease Speed;  // 0x16C(0x4)
	float Stamina Increase Speed;  // 0x170(0x4)
	char pad_372[4];  // 0x174(0x4)
	struct AActor* Selected Actor;  // 0x178(0x8)
	struct FS_Crosshair Default Crosshair;  // 0x180(0x30)
	float Safe Fall Velocity;  // 0x1B0(0x4)
	float Fall Damage Multiplier;  // 0x1B4(0x4)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool Enable Stamina : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool Enable Hunger : 1;  // 0x1B9(0x1)
	char pad_442_1 : 7;  // 0x1BA(0x1)
	bool Enable Thirst : 1;  // 0x1BA(0x1)
	char pad_443[1];  // 0x1BB(0x1)
	int32_t Current Holdable Index;  // 0x1BC(0x4)
	float Interaction Distance;  // 0x1C0(0x4)
	struct FS_PlayerArmor Armor;  // 0x1C4(0x28)
	char pad_492[4];  // 0x1EC(0x4)
	struct UBP_MasterInventoryComponent_C* Current Opened Storage;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool Remove Inventory On Death : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct FString Player Name;  // 0x200(0x10)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool Add Initial Items After Death : 1;  // 0x210(0x1)
	char pad_529[7];  // 0x211(0x7)
	struct TArray<struct FS_InventoryItem> Starting Items;  // 0x218(0x10)
	struct ACharacter* Human Player Character;  // 0x228(0x8)
	struct TArray<struct AActor*> Overlaped Actors;  // 0x230(0x10)
	struct FTimerHandle Overlap Timer Handle;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool Lock Saving : 1;  // 0x248(0x1)
	char pad_585[3];  // 0x249(0x3)
	float StandingStill Thirst Speed;  // 0x24C(0x4)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool IsMoving : 1;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct TArray<struct FS_InventoryItem> Starting Items_1;  // 0x258(0x10)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool ShouldSpawnDeathBag : 1;  // 0x268(0x1)
	char pad_617_1 : 7;  // 0x269(0x1)
	bool ShouldSave? : 1;  // 0x269(0x1)
	char pad_618_1 : 7;  // 0x26A(0x1)
	bool AbleToEat? : 1;  // 0x26A(0x1)

	void BP_PlayerInventoryComponent_AutoGenFunc(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.BP_PlayerInventoryComponent_AutoGenFunc
	void AsyncSavePlayerData(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.AsyncSavePlayerData
	void InteractionOverlap (); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.InteractionOverlap 
	bool Is Controlled From Player(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Is Controlled From Player
	bool Is Hit Blocked(struct AActor* Causer); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Is Hit Blocked
	void Apply Armor Slots(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Apply Armor Slots
	void Request Remove Armor(char E_ArmorType Armor to Remove, int32_t Desired Index, struct UBP_MasterInventoryComponent_C*& Inventory Reference, bool& Success); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Request Remove Armor
	void Has space for Armor Drop(char E_ArmorType Dropping Armor Item, int32_t& Array Index); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Has space for Armor Drop
	void Local On Inventory Updated(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Local On Inventory Updated
	void Is Loaded(bool& Return); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Is Loaded
	void Repair Item(struct FName Crafting ID, struct UDataTable* Crafting Data Table, int32_t At Index, bool& Success); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Repair Item
	bool Has Durability(int32_t At Index); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Has Durability
	void Decerase Durability(int32_t At Index, float Minus Durability); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Decerase Durability
	bool Decerase Stamina(float Stamina Minus); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Decerase Stamina
	void Spawn Death Items(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Spawn Death Items
	void Split Stack(int32_t From Index, struct UBP_MasterInventoryComponent_C* From Inventory, int32_t To Index, struct UBP_MasterInventoryComponent_C* To Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Split Stack
	void OnRep_Armor(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.OnRep_Armor
	void Save Player Data(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Save Player Data
	void Add Item(struct FS_InventoryItem Item, bool& Success); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Add Item
	void Craft Item(struct FName Crafting ID, struct UDataTable* Crafting Data Table, bool& Success); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Craft Item
	void Calculate Armor Reduction(float&  100, float& Overall Temperature); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Calculate Armor Reduction
	void Find Item Amount(struct FName& Item ID, int32_t& Amount); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Find Item Amount
	void Swap Items(int32_t From Index, struct UBP_MasterInventoryComponent_C*& From Inventory, int32_t To Index, struct UBP_MasterInventoryComponent_C*& To Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Swap Items
	void Drop Item(int32_t At Index, int32_t Amount, struct UBP_MasterInventoryComponent_C*& From Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Drop Item
	void Remove Item(int32_t At Index, int32_t Amount, struct UBP_MasterInventoryComponent_C* From Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Remove Item
	void Use Item Call(int32_t At Index, struct UBP_MasterInventoryComponent_C* From Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Use Item Call
	void Create Inventory(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Create Inventory
	void Is Starving?(bool& Return); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Is Starving?
	void Spawn New Player(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Spawn New Player
	struct USkeletalMeshComponent* Get Object Attach Point(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Get Object Attach Point
	void Revive Player(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Revive Player
	void Revive Update(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Revive Update
	void Countdown Knockout(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Countdown Knockout
	void Consume Item(struct FS_Item_SurvivalProperties Survival Item Data); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Consume Item
	void Starving(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Starving
	void Handled Damage(float Damage, struct UDamageType* Damage Type, struct AController* Instigated By, struct AActor* Damage Causer, bool& Success); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Handled Damage
	void Start Revive Player(struct AController* Player To Revive); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Start Revive Player
	void CLIENT Toggle Revive(bool Toggle); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Toggle Revive
	void CLIENT Toggle Revived(bool Toggle); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Toggle Revived
	void Stop Revive Player(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Stop Revive Player
	void Toggle Revived(bool Toggle); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Toggle Revived
	void Stop Revive(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Stop Revive
	void Spawn Holdable(ABP_Holdable_C* Holdable Class, struct FS_InventoryItem Item Data); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Spawn Holdable
	void Set Widget Time(int32_t Time); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Set Widget Time
	void Toggle Dead Widget(bool Toggle, bool Play HUD Animation); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Toggle Dead Widget
	void Remove Holdable Object(bool Skip Frame); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Remove Holdable Object
	void CLIENT Remove Holdable Object(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Remove Holdable Object
	void Toggle Knockout Widget(bool Toggle, bool Play HUD Animation); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Toggle Knockout Widget
	void Interact(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Interact
	void SERVER Interact(struct AActor* Selected Actor); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Interact
	void CLIENT Handled Damage(int32_t Health); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Handled Damage
	void Dequip Holdable(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Dequip Holdable
	void SERVER Drop Item(int32_t At Index, int32_t Amount, struct UBP_MasterInventoryComponent_C*& From Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Drop Item
	void CLIENT Open Chest Inventory(struct UBP_MasterInventoryComponent_C*& Component, bool Open, struct TArray<struct FS_InventoryItem>& Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Open Chest Inventory
	void SERVER Drop Armor(char E_ArmorType Armor, int32_t Desired Index, struct UBP_MasterInventoryComponent_C* Inventory Reference); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Drop Armor
	void CLIENT Update Armor(struct FS_PlayerArmor Armor); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Update Armor
	void CLIENT Set Holdable Index(int32_t Holdable Index); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Set Holdable Index
	void SERVER Craft Item(struct FName Crafting ID, struct UDataTable* Crafting Data Table); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Craft Item
	void CLIENT Open Crafting(struct UDataTable* Crafting Data Table); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Open Crafting
	void CLIENT Update Crafting(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Update Crafting
	void On Player Dead(bool Knocked); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.On Player Dead
	void ReceiveBeginPlay(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.ReceiveBeginPlay
	void Check For Mission Progress(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Check For Mission Progress
	void SERVER Load Armor(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Load Armor
	void SERVER Clear Current Storage(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Clear Current Storage
	void Open Chest Inventory(struct UBP_MasterInventoryComponent_C*& Component, bool Open, struct TArray<struct FS_InventoryItem>& Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Open Chest Inventory
	void SERVER Split Stack(int32_t From Index, struct UBP_MasterInventoryComponent_C* From Inventory, int32_t To Index, struct UBP_MasterInventoryComponent_C* To Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Split Stack
	void Spawn Damage Widget(struct FVector Hit Location, float Damage, struct FName Hit Bone); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.Spawn Damage Widget
	void SERVER Repair Item(struct FName Crafting ID, struct UDataTable* Crafting Data Table, int32_t At Index); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Repair Item
	void CLIENT Open Repair Menu(struct UDataTable* Crafting Data Table); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Open Repair Menu
	void CLIENT Refresh Repair List(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Refresh Repair List
	void CLIENT Load Data(struct TArray<struct FS_InventoryItem>& Inventory); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Load Data
	void SERVER Load Data(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Load Data
	void ReceiveTick(float DeltaSeconds); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.ReceiveTick
	void CLIENT Set Used Item(int32_t At Index); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Set Used Item
	void CLIENT Reconstruct Inventory(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Reconstruct Inventory
	void CLIENT Open Vehicle Customization(struct AActor*& Vehicle Reference); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Open Vehicle Customization
	void SERVER Update Vehicle Color(struct ABP_Buggy_C* Vehicle, struct FVector Color); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SERVER Update Vehicle Color
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.ReceiveEndPlay
	void CLIENT Request Weapon Attachment Add(int32_t Inventory Index); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Request Weapon Attachment Add
	void CLIENT Request Weapon Attachment Removal(char E_WeaponAttachmentType Attachment); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.CLIENT Request Weapon Attachment Removal
	void SpawnPlayer(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.SpawnPlayer
	void ToggleLoading(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.ToggleLoading
	void ServerSpawnNewPlayer(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.ServerSpawnNewPlayer
	void ClientSpawnNewPlayer(); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.ClientSpawnNewPlayer
	void ExecuteUbergraph_BP_PlayerInventoryComponent(int32_t EntryPoint); // Function BP_PlayerInventoryComponent.BP_PlayerInventoryComponent_C.ExecuteUbergraph_BP_PlayerInventoryComponent
}; 



