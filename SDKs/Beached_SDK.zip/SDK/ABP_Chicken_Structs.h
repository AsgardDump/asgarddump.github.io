#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Chicken.ABP_Chicken_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_Chicken.ABP_Chicken_C.ExecuteUbergraph_ABP_Chicken
// Size: 0x24(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Chicken
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x8(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x10(0xC)
	float K2Node_Event_DeltaTimeX;  // 0x1C(0x4)
	float CallFunc_VSize_ReturnValue;  // 0x20(0x4)

}; 
// Function ABP_Chicken.ABP_Chicken_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
