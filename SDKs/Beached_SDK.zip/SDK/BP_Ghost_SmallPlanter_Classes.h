#pragma once 
#include <BP_Ghost_SmallPlanter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_SmallPlanter.BP_Ghost_SmallPlanter_C
// Size: 0x280(Inherited: 0x280) 
struct ABP_Ghost_SmallPlanter_C : public ABP_GhostActor_C
{

	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_SmallPlanter.BP_Ghost_SmallPlanter_C.Custom Condition Pass
}; 



