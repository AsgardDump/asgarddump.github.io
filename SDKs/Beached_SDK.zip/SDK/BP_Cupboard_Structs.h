#pragma once 
#include "SDK.h" 
 
 
// Function BP_Cupboard.BP_Cupboard_C.Add Building
// Size: 0x10(Inherited: 0x0) 
struct FAdd Building
{
	struct FString Building ID;  // 0x0(0x10)

}; 
// Function BP_Cupboard.BP_Cupboard_C.ExecuteUbergraph_BP_Cupboard
// Size: 0x2E8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Cupboard
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x40(0x10)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x50(0x8)
	struct ABP_StorageStash_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct AController* K2Node_Event_Executor;  // 0x68(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x70(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UBP_Player_ExperienceComponent_C* CallFunc_Get_Leveling_Component_Leveling_Component;  // 0x88(0x8)
	struct FSteamID CallFunc_GetSteamIdFromPlayerState_ReturnValue;  // 0x90(0x8)
	struct FString CallFunc_Get_Player_Unique_ID_Unique_ID;  // 0x98(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool K2Node_Event_Toggle : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct FString K2Node_CustomEvent_Building_ID_2;  // 0xB8(0x10)
	struct FString K2Node_CustomEvent_Building_ID;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0xDC(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xE4(0x1)
	char pad_229_1 : 7;  // 0xE5(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xE5(0x1)
	char pad_230_1 : 7;  // 0xE6(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xE6(0x1)
	char pad_231_1 : 7;  // 0xE7(0x1)
	bool K2Node_CustomEvent_Overlap : 1;  // 0xE7(0x1)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0xE8(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue_3;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xFC(0x1)
	char pad_253_1 : 7;  // 0xFD(0x1)
	bool Temp_bool_Variable : 1;  // 0xFD(0x1)
	char pad_254_1 : 7;  // 0xFE(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xFE(0x1)
	char pad_255[1];  // 0xFF(0x1)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x100(0xC)
	float CallFunc_BreakVector_X;  // 0x10C(0x4)
	float CallFunc_BreakVector_Y;  // 0x110(0x4)
	float CallFunc_BreakVector_Z;  // 0x114(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x118(0xC)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x124(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x128(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x134(0x8C)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0x1C8(0x30)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CallFunc_Has_Any_Items_in_Inventory_Has : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x200(0x8)
	struct FLinearColor Temp_struct_Variable;  // 0x208(0x10)
	struct FS_InventoryItem CallFunc_Array_Get_Item;  // 0x218(0x30)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x248(0x4)
	char pad_588[4];  // 0x24C(0x4)
	struct FS_Notification K2Node_MakeStruct_S_Notification;  // 0x250(0x20)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem_2;  // 0x270(0x30)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2A0(0x4)
	char pad_676_1 : 7;  // 0x2A4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2A4(0x1)
	char pad_677[3];  // 0x2A5(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2A8(0x4)
	struct FLinearColor Temp_struct_Variable_2;  // 0x2AC(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue_4;  // 0x2BC(0x4)
	struct FLinearColor K2Node_Select_Default;  // 0x2C0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x2D0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x2D4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x2D8(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x2E0(0x8)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Save Player List
// Size: 0x290(Inherited: 0x0) 
struct FSave Player List
{
	struct TArray<struct FS_InventoryItem> L Players;  // 0x0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)
	struct FString CallFunc_Array_Get_Item;  // 0x28(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x3C(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FS_InventoryItem K2Node_MakeStruct_S_InventoryItem;  // 0x48(0x30)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue_2;  // 0x80(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x88(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FS_BuildSave CallFunc_Get_Saved_Build_Data_Saved_Data;  // 0xA0(0xF0)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_Get_Saved_Build_Data_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[15];  // 0x191(0xF)
	struct FS_BuildSave K2Node_SetFieldsInStruct_StructOut;  // 0x1A0(0xF0)

}; 
// Function BP_Cupboard.BP_Cupboard_C.ChestBroken
// Size: 0x8(Inherited: 0x0) 
struct FChestBroken
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function BP_Cupboard.BP_Cupboard_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Set Building Overlap Color
// Size: 0x1(Inherited: 0x0) 
struct FSet Building Overlap Color
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Remove Building
// Size: 0x10(Inherited: 0x0) 
struct FRemove Building
{
	struct FString Building ID;  // 0x0(0x10)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Cupboard.BP_Cupboard_C.UserConstructionScript
// Size: 0x8(Inherited: 0x1C1) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Find Privilege Building
// Size: 0x19A(Inherited: 0x0) 
struct FFind Privilege Building
{
	struct TArray<struct AActor*> L Actor List;  // 0x0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x18(0x8)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x20(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x30(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x38(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x48(0xC)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FHitResult> CallFunc_SphereTraceMultiForObjects_OutHits;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_SphereTraceMultiForObjects_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x74(0x8C)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x101(0x1)
	char pad_258[2];  // 0x102(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x104(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x108(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x10C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x118(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x124(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x130(0xC)
	char pad_316[4];  // 0x13C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x140(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x148(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x150(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x158(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x160(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x164(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x168(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x174(0xC)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x180(0x4)
	char pad_388[4];  // 0x184(0x4)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue_2;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x190(0x1)
	char pad_401_1 : 7;  // 0x191(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x191(0x1)
	char pad_402[2];  // 0x192(0x2)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x194(0x4)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x198(0x1)
	char pad_409_1 : 7;  // 0x199(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x199(0x1)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Save Building List
// Size: 0x210(Inherited: 0x0) 
struct FSave Building List
{
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x0(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x8(0x8)
	struct AGM_Survival_C* K2Node_DynamicCast_AsGM_Survival;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FS_BuildSave CallFunc_Get_Saved_Build_Data_Saved_Data;  // 0x20(0xF0)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_Get_Saved_Build_Data_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[15];  // 0x111(0xF)
	struct FS_BuildSave K2Node_SetFieldsInStruct_StructOut;  // 0x120(0xF0)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_Cupboard.BP_Cupboard_C.Get Interaction Data
// Size: 0x18(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)

}; 
