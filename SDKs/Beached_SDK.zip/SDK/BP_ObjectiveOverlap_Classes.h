#pragma once 
#include <BP_ObjectiveOverlap_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ObjectiveOverlap.BP_ObjectiveOverlap_C
// Size: 0x298(Inherited: 0x290) 
struct ABP_ObjectiveOverlap_C : public ABP_CheckpointObjective_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)

	void Checkpoint Overlap(bool Overlaping?); // Function BP_ObjectiveOverlap.BP_ObjectiveOverlap_C.Checkpoint Overlap
	void ExecuteUbergraph_BP_ObjectiveOverlap(int32_t EntryPoint); // Function BP_ObjectiveOverlap.BP_ObjectiveOverlap_C.ExecuteUbergraph_BP_ObjectiveOverlap
}; 



