#pragma once 
#include <BP_Crafting_Master_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Crafting_Master.BP_Crafting_Master_C
// Size: 0x240(Inherited: 0x220) 
struct ABP_Crafting_Master_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct FName Name;  // 0x230(0x8)
	struct UDataTable* Crafting Data Table;  // 0x238(0x8)

	void Local Can Overlap(bool& Success); // Function BP_Crafting_Master.BP_Crafting_Master_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_Crafting_Master.BP_Crafting_Master_C.Get Interaction Data
	void On Interacted(struct AController* Executor); // Function BP_Crafting_Master.BP_Crafting_Master_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_Crafting_Master.BP_Crafting_Master_C.Toggle Selected
	void Local Overlap(bool Overlap); // Function BP_Crafting_Master.BP_Crafting_Master_C.Local Overlap
	void ExecuteUbergraph_BP_Crafting_Master(int32_t EntryPoint); // Function BP_Crafting_Master.BP_Crafting_Master_C.ExecuteUbergraph_BP_Crafting_Master
}; 



