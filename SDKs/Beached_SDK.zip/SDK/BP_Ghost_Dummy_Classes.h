#pragma once 
#include <BP_Ghost_Dummy_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_Dummy.BP_Ghost_Dummy_C
// Size: 0x280(Inherited: 0x280) 
struct ABP_Ghost_Dummy_C : public ABP_GhostActor_C
{

	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_Dummy.BP_Ghost_Dummy_C.Custom Condition Pass
}; 



