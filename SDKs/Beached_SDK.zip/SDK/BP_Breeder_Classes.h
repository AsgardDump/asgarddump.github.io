#pragma once 
#include <BP_Breeder_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Breeder.BP_Breeder_C
// Size: 0x25C(Inherited: 0x220) 
struct ABP_Breeder_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	ABP_AIBase_C* Animal to Spawn;  // 0x238(0x8)
	float Check Time ;  // 0x240(0x4)
	char pad_580[4];  // 0x244(0x4)
	struct TArray<struct AActor*> Spawned Animals;  // 0x248(0x10)
	int32_t Maximum Spawned Animals;  // 0x258(0x4)

	void Check Animal Validity(); // Function BP_Breeder.BP_Breeder_C.Check Animal Validity
	void Spawn New Animal(); // Function BP_Breeder.BP_Breeder_C.Spawn New Animal
	void ReceiveBeginPlay(); // Function BP_Breeder.BP_Breeder_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Breeder(int32_t EntryPoint); // Function BP_Breeder.BP_Breeder_C.ExecuteUbergraph_BP_Breeder
}; 



