#pragma once 
#include "SDK.h" 
 
 
// Function BP_SleepingBag.BP_SleepingBag_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_SleepingBag.BP_SleepingBag_C.Get Interaction Data
// Size: 0x18(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)

}; 
// Function BP_SleepingBag.BP_SleepingBag_C.ExecuteUbergraph_BP_SleepingBag
// Size: 0x3A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SleepingBag
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AController* K2Node_Event_Executor;  // 0x8(0x8)
	struct UBP_Player_ExperienceComponent_C* CallFunc_Get_Leveling_Component_Leveling_Component;  // 0x10(0x8)
	struct FS_Notification K2Node_MakeStruct_S_Notification;  // 0x18(0x20)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x39(0x1)

}; 
// Function BP_SleepingBag.BP_SleepingBag_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_SleepingBag.BP_SleepingBag_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_SleepingBag.BP_SleepingBag_C.Set New Respawn Point
// Size: 0x238(Inherited: 0x0) 
struct FSet New Respawn Point
{
	struct AActor* Controller;  // 0x0(0x8)
	struct UBP_BuildingComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x8(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x20(0x8)
	struct FString CallFunc_Get_Player_Unique_ID_Unique_ID;  // 0x28(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x38(0xC)
	char pad_68[4];  // 0x44(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x48(0x8)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x50(0xC)
	char pad_92[4];  // 0x5C(0x4)
	struct UBP_GameInstance_UMSP_C* K2Node_DynamicCast_AsBP_Game_Instance_UMSP;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FS_PlayerSave CallFunc_Map_Find_Value;  // 0x70(0xE0)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct FS_PlayerSave K2Node_SetFieldsInStruct_StructOut;  // 0x158(0xE0)

}; 
// Function BP_SleepingBag.BP_SleepingBag_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
