#pragma once 
#include "SDK.h" 
 
 
// Function BP_Ghost_WoodeHut.BP_Ghost_WoodeHut_C.Custom Rotation
// Size: 0x99(Inherited: 0x161) 
struct FCustom Rotation : public FCustom Rotation
{
	struct FHitResult Hit;  // 0x0(0x8C)
	struct FRotator Current Rotation;  // 0x8C(0xC)
	char pad_505_1 : 7;  // 0x1F9(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x98(0x1)

}; 
// Function BP_Ghost_WoodeHut.BP_Ghost_WoodeHut_C.Custom Condition Pass
// Size: 0x8E(Inherited: 0x112) 
struct FCustom Condition Pass : public FCustom Condition Pass
{
	struct FHitResult Hit;  // 0x0(0x8C)
	char pad_414_1 : 7;  // 0x19E(0x1)
	bool Return : 1;  // 0x8C(0x1)
	char pad_415_1 : 7;  // 0x19F(0x1)
	bool CallFunc_Custom_Condition_Pass_Return : 1;  // 0x8D(0x1)

}; 
