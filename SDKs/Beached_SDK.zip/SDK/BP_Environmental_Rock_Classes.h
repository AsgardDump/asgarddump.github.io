#pragma once 
#include <BP_Environmental_Rock_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Environmental_Rock.BP_Environmental_Rock_C
// Size: 0x2C1(Inherited: 0x2C1) 
struct ABP_Environmental_Rock_C : public ABP_Environmental_C
{

}; 



