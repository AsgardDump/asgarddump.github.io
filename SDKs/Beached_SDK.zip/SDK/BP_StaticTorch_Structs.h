#pragma once 
#include "SDK.h" 
 
 
// Function BP_StaticTorch.BP_StaticTorch_C.ExecuteUbergraph_BP_StaticTorch
// Size: 0xD9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_StaticTorch
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x8(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x18(0xC)
	float CallFunc_BreakVector_X;  // 0x24(0x4)
	float CallFunc_BreakVector_Y;  // 0x28(0x4)
	float CallFunc_BreakVector_Z;  // 0x2C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x30(0xC)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x3C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x40(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x4C(0x8C)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0xD8(0x1)

}; 
