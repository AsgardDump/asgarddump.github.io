#pragma once 
#include "SDK.h" 
 
 
// Function BP_CheckpointObjective.BP_CheckpointObjective_C.ExecuteUbergraph_BP_CheckpointObjective
// Size: 0xD8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CheckpointObjective
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x20(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x38(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x44(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x48(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x58(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent_2;  // 0x60(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x68(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool K2Node_CustomEvent_Overlaping_ : 1;  // 0x81(0x1)
	char pad_130[6];  // 0x82(0x6)
	struct UW_Marker_C* CallFunc_Array_Get_Item;  // 0x88(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x95(0x1)
	char pad_150[2];  // 0x96(0x2)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x98(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0xA0(0x8)
	float CallFunc_GetDistanceTo_ReturnValue_2;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct UW_Marker_C* CallFunc_Array_Get_Item_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0xC2(0x1)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0xC3(0x1)
	char pad_196[4];  // 0xC4(0x4)
	struct TArray<struct UW_Marker_C*> CallFunc_Add_Custom_Marker_Marker_Reference;  // 0xC8(0x10)

}; 
// Function BP_CheckpointObjective.BP_CheckpointObjective_C.UserConstructionScript
// Size: 0x48(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FS_TargetInformation K2Node_MakeStruct_S_TargetInformation;  // 0x0(0x48)

}; 
// Function BP_CheckpointObjective.BP_CheckpointObjective_C.Checkpoint Overlap
// Size: 0x1(Inherited: 0x0) 
struct FCheckpoint Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlaping? : 1;  // 0x0(0x1)

}; 
