#pragma once 
#include "SDK.h" 
 
 
// Function BP_MapData.BP_MapData_C.ExecuteUbergraph_BP_MapData
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MapData
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_MapData.BP_MapData_C.Update Player Vision
// Size: 0x5C(Inherited: 0x0) 
struct FUpdate Player Vision
{
	struct UMaterialInstanceDynamic* L Vision Material;  // 0x0(0x8)
	float CallFunc_BreakVector2D_X;  // 0x8(0x4)
	float CallFunc_BreakVector2D_Y;  // 0xC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x18(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x38(0x8)
	float CallFunc_BreakVector_X;  // 0x40(0x4)
	float CallFunc_BreakVector_Y;  // 0x44(0x4)
	float CallFunc_BreakVector_Z;  // 0x48(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x4C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x50(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x54(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x58(0x4)

}; 
// Function BP_MapData.BP_MapData_C.Construct Minimap
// Size: 0x58(Inherited: 0x0) 
struct FConstruct Minimap
{
	float CallFunc_BreakVector2D_X;  // 0x0(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x4(0x4)
	float CallFunc_BreakVector2D_X_2;  // 0x8(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0xC(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)
	float CallFunc_BreakVector2D_X_3;  // 0x18(0x4)
	float CallFunc_BreakVector2D_Y_3;  // 0x1C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x20(0x8)
	struct UTextureRenderTarget2D* CallFunc_CreateRenderTarget2D_ReturnValue;  // 0x28(0x8)
	float CallFunc_BreakVector2D_X_4;  // 0x30(0x4)
	float CallFunc_BreakVector2D_Y_4;  // 0x34(0x4)
	float CallFunc_BreakVector2D_X_5;  // 0x38(0x4)
	float CallFunc_BreakVector2D_Y_5;  // 0x3C(0x4)
	float CallFunc_BreakVector2D_X_6;  // 0x40(0x4)
	float CallFunc_BreakVector2D_Y_6;  // 0x44(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_3;  // 0x48(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_4;  // 0x50(0x8)

}; 
