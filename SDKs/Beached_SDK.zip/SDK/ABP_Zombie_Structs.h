#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Zombie.ABP_Zombie_C.ExecuteUbergraph_ABP_Zombie
// Size: 0x24(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Zombie
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaTimeX;  // 0x4(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x8(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float CallFunc_VSizeXY_ReturnValue;  // 0x20(0x4)

}; 
// Function ABP_Zombie.ABP_Zombie_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_Zombie.ABP_Zombie_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
