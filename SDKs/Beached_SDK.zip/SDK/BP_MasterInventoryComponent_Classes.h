#pragma once 
#include <BP_MasterInventoryComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MasterInventoryComponent.BP_MasterInventoryComponent_C
// Size: 0xCC(Inherited: 0xB0) 
struct UBP_MasterInventoryComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct TArray<struct FS_InventoryItem> Inventory;  // 0xB8(0x10)
	int32_t Inventory Size;  // 0xC8(0x4)

	void Find Free Space for Item Amount(struct FName Item ID, int32_t Amount, int32_t Limit Finder to Index, struct TArray<int32_t>& Exceptions, struct TArray<int32_t>& Found Indexes); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Find Free Space for Item Amount
	void Local On Inventory Updated(); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Local On Inventory Updated
	void Has Any Items in Inventory(bool& Has); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Has Any Items in Inventory
	void Find Free Space for Item(struct FName Item ID, int32_t Limit Finder to Index, struct TArray<int32_t>& Exceptions, int32_t& Found Space); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Find Free Space for Item
	void Save Player Data(); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Save Player Data
	void Find Item Indexes from ID(struct FName Item ID, struct TArray<int32_t>& Found Indexes); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Find Item Indexes from ID
	void Swap Items(int32_t From Index, struct UBP_MasterInventoryComponent_C*& From Inventory, int32_t To Index, struct UBP_MasterInventoryComponent_C*& To Inventory); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Swap Items
	void Use Item Call(int32_t At Index, struct UBP_MasterInventoryComponent_C* From Inventory); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Use Item Call
	void Is Caller Local(bool& Is Local); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Is Caller Local
	void Get Local Player Inventory UI(struct UW_Inventory_C*& W_Inventory); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Get Local Player Inventory UI
	void Find Free Space(struct TArray<int32_t>& Exceptions, int32_t& Array Index); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Find Free Space
	void Find Item by ID(struct FName& Item ID, int32_t& Array Index); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Find Item by ID
	void Remove Item(int32_t At Index, int32_t Amount, struct UBP_MasterInventoryComponent_C* From Inventory); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Remove Item
	void Add Item(struct FS_InventoryItem Item, bool& Success); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Add Item
	void Create Inventory(); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.Create Inventory
	void CLIENT Update Inventory and Slots(struct TArray<struct FS_InventoryItem>& Inventory, struct TArray<int32_t>& Indexes to Update); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.CLIENT Update Inventory and Slots
	void SERVER Use Item(int32_t At Index, struct UBP_MasterInventoryComponent_C* From Inventory); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.SERVER Use Item
	void SERVER Swap Items(int32_t From Index, struct UBP_MasterInventoryComponent_C* From Inventory, int32_t To Index, struct UBP_MasterInventoryComponent_C* To Inventory); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.SERVER Swap Items
	void ExecuteUbergraph_BP_MasterInventoryComponent(int32_t EntryPoint); // Function BP_MasterInventoryComponent.BP_MasterInventoryComponent_C.ExecuteUbergraph_BP_MasterInventoryComponent
}; 



