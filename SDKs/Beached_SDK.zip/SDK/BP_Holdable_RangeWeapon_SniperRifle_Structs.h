#pragma once 
#include "SDK.h" 
 
 
// Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.ExecuteUbergraph_BP_Holdable_RangeWeapon_SniperRifle
// Size: 0x20C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Holdable_RangeWeapon_SniperRifle
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UW_Scope_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FTransform Temp_struct_Variable;  // 0x20(0x30)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UCameraComponent* CallFunc_AddComponent_ReturnValue;  // 0x58(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x70(0x8)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x78(0x8C)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_Is_Owner_Local_ReturnValue : 1;  // 0x104(0x1)
	char pad_261_1 : 7;  // 0x105(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x105(0x1)
	char pad_262[2];  // 0x106(0x2)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x108(0x8)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x110(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x11C(0x8C)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_Is_Owner_Local_ReturnValue_2 : 1;  // 0x1A8(0x1)
	char pad_425[3];  // 0x1A9(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x1AC(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x1B0(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_5;  // 0x1B8(0x8)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character;  // 0x1C8(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_6;  // 0x1D0(0x8)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character_2;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_7;  // 0x1E8(0x8)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character_3;  // 0x1F0(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_8;  // 0x1F8(0x8)
	struct ACharacter* CallFunc_Get_Human_Player_Character_Human_Player_Character_4;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x208(0x1)
	char pad_521_1 : 7;  // 0x209(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x209(0x1)
	char pad_522_1 : 7;  // 0x20A(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x20A(0x1)
	char pad_523_1 : 7;  // 0x20B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20B(0x1)

}; 
// Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.Toggle Upgrade Mode
// Size: 0x4(Inherited: 0x29F) 
struct FToggle Upgrade Mode : public FToggle Upgrade Mode
{
	char pad_671_1 : 7;  // 0x29F(0x1)
	bool Toggle : 1;  // 0x0(0x1)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_673_1 : 7;  // 0x2A1(0x1)
	bool CallFunc_Is_Owner_Local_ReturnValue : 1;  // 0x2(0x1)
	char pad_674_1 : 7;  // 0x2A2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.Aiming Action
// Size: 0x1(Inherited: 0x1) 
struct FAiming Action : public FAiming Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
