#pragma once 
#include <BP_EBS_Building_DoorFrame_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C
// Size: 0x511(Inherited: 0x4E0) 
struct ABP_EBS_Building_DoorFrame_C : public ABP_EBS_Building_Wall_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4E0(0x8)
	struct USceneComponent* DoorSocket;  // 0x4E8(0x8)
	struct UArrowComponent* DoorAxis;  // 0x4F0(0x8)
	float OpenDoorTimeline_RotationZ_8DD5B5B24B509C63C69F3F841CE39035;  // 0x4F8(0x4)
	char ETimelineDirection OpenDoorTimeline__Direction_8DD5B5B24B509C63C69F3F841CE39035;  // 0x4FC(0x1)
	char pad_1277[3];  // 0x4FD(0x3)
	struct UTimelineComponent* OpenDoorTimeline;  // 0x500(0x8)
	struct ABP_EBS_Building_Door_C* DoorReference;  // 0x508(0x8)
	char pad_1296_1 : 7;  // 0x510(0x1)
	bool DoorIsOpened : 1;  // 0x510(0x1)

	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.GetFormatedVariables_BPI
	void GetSocketTransform(struct FName SocketName, int32_t Index, struct FTransform& Transform); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.GetSocketTransform
	void CloseDoor(); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.CloseDoor
	void OpenDoor(); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.OpenDoor
	void OnRep_DoorIsOpened(); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.OnRep_DoorIsOpened
	void OpenDoorTimeline__FinishedFunc(); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.OpenDoorTimeline__FinishedFunc
	void OpenDoorTimeline__UpdateFunc(); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.OpenDoorTimeline__UpdateFunc
	void PlayOpenDoor(); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.PlayOpenDoor
	void PlayCloseDoor(); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.PlayCloseDoor
	void ExecuteUbergraph_BP_EBS_Building_DoorFrame(int32_t EntryPoint); // Function BP_EBS_Building_DoorFrame.BP_EBS_Building_DoorFrame_C.ExecuteUbergraph_BP_EBS_Building_DoorFrame
}; 



