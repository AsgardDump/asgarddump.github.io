#pragma once 
#include "SDK.h" 
 
 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Inventory Component
// Size: 0x28(Inherited: 0x0) 
struct FGet Inventory Component
{
	struct AActor* Player Controller;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UBP_PlayerInventoryComponent_C* ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UBP_PlayerInventoryComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Player Class
// Size: 0x10(Inherited: 0x0) 
struct FGet Player Class
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	ACharacter* Player Class;  // 0x8(0x8)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Enemy Nametag
// Size: 0x21(Inherited: 0x0) 
struct FGet Enemy Nametag
{
	struct UObject* Object;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UWidgetComponent* Name Tag;  // 0x10(0x8)
	struct ABP_AIBase_C* K2Node_DynamicCast_AsBP_AIBase;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Mission Component
// Size: 0x28(Inherited: 0x0) 
struct FGet Mission Component
{
	struct AActor* Player;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UBP_MissionComponent_C* MissionComponent;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UBP_MissionComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Leveling Component
// Size: 0x28(Inherited: 0x0) 
struct FGet Leveling Component
{
	struct AActor* Object;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UBP_Player_ExperienceComponent_C* Leveling Component;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UBP_Player_ExperienceComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Skill Component
// Size: 0x28(Inherited: 0x0) 
struct FGet Skill Component
{
	struct AActor* Player;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UBP_SkillTreeComponent_C* ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UBP_SkillTreeComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Player Component
// Size: 0x28(Inherited: 0x0) 
struct FGet Player Component
{
	struct AActor* Character;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UBP_PlayerComponent_C* ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UBP_PlayerComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Option Slot Name
// Size: 0x28(Inherited: 0x0) 
struct FGet Option Slot Name
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_MakeLiteralString_ReturnValue;  // 0x18(0x10)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Customization Slot Name
// Size: 0x28(Inherited: 0x0) 
struct FGet Customization Slot Name
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_MakeLiteralString_ReturnValue;  // 0x18(0x10)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Is Current Level Saveable
// Size: 0x32(Inherited: 0x0) 
struct FIs Current Level Saveable
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x10(0x10)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BFL_UMSPack.BFL_UMSPack_C.Get Human Player Character
// Size: 0x29(Inherited: 0x0) 
struct FGet Human Player Character
{
	struct AActor* Controller;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct ACharacter* Human Player Character;  // 0x10(0x8)
	struct AActor* NewLocalVar_1;  // 0x18(0x8)
	struct ABP_PlayerController_C* K2Node_DynamicCast_AsBP_Player_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
