#pragma once 
#include "SDK.h" 
 
 
// Function BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C.ExecuteUbergraph_BP_Throwable_ImpulseNade
// Size: 0x239(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Throwable_ImpulseNade
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0x8(0x8)
	struct AActor* K2Node_Event_Other;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0x24(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x30(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0x3C(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0x48(0x8C)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xD8(0xC)
	char pad_228[12];  // 0xE4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xF0(0x30)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x128(0x8)
	float K2Node_Event_Damage;  // 0x130(0x4)
	char pad_308[4];  // 0x134(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x138(0x8)
	struct FVector K2Node_Event_HitLocation_2;  // 0x140(0xC)
	struct FVector K2Node_Event_HitNormal_2;  // 0x14C(0xC)
	struct UPrimitiveComponent* K2Node_Event_HitComponent;  // 0x158(0x8)
	struct FName K2Node_Event_BoneName;  // 0x160(0x8)
	struct FVector K2Node_Event_ShotFromDirection;  // 0x168(0xC)
	char pad_372[4];  // 0x174(0x4)
	struct AController* K2Node_Event_InstigatedBy;  // 0x178(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x180(0x8)
	struct FHitResult K2Node_Event_HitInfo;  // 0x188(0x8C)
	char pad_532[4];  // 0x214(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x218(0x8)
	UDamageType* CallFunc_GetObjectClass_ReturnValue;  // 0x220(0x8)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_NotEqual_ClassClass_ReturnValue : 1;  // 0x228(0x1)
	char pad_553[7];  // 0x229(0x7)
	struct ABP_ImpulseExplosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x238(0x1)

}; 
// Function BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C.ReceivePointDamage
// Size: 0xE4(Inherited: 0xE8) 
struct FReceivePointDamage : public FReceivePointDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct UPrimitiveComponent* HitComponent;  // 0x28(0x8)
	struct FName BoneName;  // 0x30(0x8)
	struct FVector ShotFromDirection;  // 0x38(0xC)
	struct AController* InstigatedBy;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)
	struct FHitResult HitInfo;  // 0x58(0x8C)

}; 
// Function BP_Throwable_ImpulseNade.BP_Throwable_ImpulseNade_C.ReceiveHit
// Size: 0xCC(Inherited: 0xD0) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x8C)

}; 
