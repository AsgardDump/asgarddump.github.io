#pragma once 
#include <BP_Holdable_Wrench_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_Wrench.BP_Holdable_Wrench_C
// Size: 0x3B8(Inherited: 0x30A) 
struct ABP_Holdable_Wrench_C : public ABP_Holdable_C
{
	char pad_778[6];  // 0x30A(0x6)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct FTimerHandle Timer;  // 0x318(0x8)
	struct FHitResult Hit;  // 0x320(0x8C)
	char pad_940[4];  // 0x3AC(0x4)
	struct UW_WrenchInformation_C* Repair Widget;  // 0x3B0(0x8)

	void ReceiveBeginPlay(); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.ReceiveTick
	void ReceiveDestroyed(); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.ReceiveDestroyed
	void Primary Action(bool Pressed); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.Primary Action
	void Toggle Time(bool Toggle); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.Toggle Time
	void Repair Building(); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.Repair Building
	void SERVER Destroy Building(struct AActor* Destroy Building); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.SERVER Destroy Building
	void SERVER Repair(struct AActor* Target); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.SERVER Repair
	void ExecuteUbergraph_BP_Holdable_Wrench(int32_t EntryPoint); // Function BP_Holdable_Wrench.BP_Holdable_Wrench_C.ExecuteUbergraph_BP_Holdable_Wrench
}; 



