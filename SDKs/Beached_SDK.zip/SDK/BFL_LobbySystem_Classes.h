#pragma once 
#include <BFL_LobbySystem_Structs.h>
 
 
 
// BlueprintGeneratedClass BFL_LobbySystem.BFL_LobbySystem_C
// Size: 0x28(Inherited: 0x28) 
struct UBFL_LobbySystem_C : public UBlueprintFunctionLibrary
{

	void Get Online Component(struct UObject* Player Controller, struct UObject* __WorldContext, struct UBP_OnlineComponent_C*& BP_OnlineComponent); // Function BFL_LobbySystem.BFL_LobbySystem_C.Get Online Component
	void Get Player Icon(struct FString Unique ID, struct UObject* __WorldContext, struct UTexture2D*& Icon); // Function BFL_LobbySystem.BFL_LobbySystem_C.Get Player Icon
	void Get Player Unique ID(struct APlayerController* Controller, struct UObject* __WorldContext, struct FString& Unique ID); // Function BFL_LobbySystem.BFL_LobbySystem_C.Get Player Unique ID
	void Get Player Name(struct APlayerController* Controller, struct UObject* __WorldContext, struct FString& Name); // Function BFL_LobbySystem.BFL_LobbySystem_C.Get Player Name
	void Get Lobby Component(struct UObject* Player Controller, struct UObject* __WorldContext, struct UBP_LobbyComponent_C*& BP_LobbyComponent); // Function BFL_LobbySystem.BFL_LobbySystem_C.Get Lobby Component
}; 



