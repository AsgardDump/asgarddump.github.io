#pragma once 
#include "SDK.h" 
 
 
// Function BP_ObjectiveOverlap.BP_ObjectiveOverlap_C.ExecuteUbergraph_BP_ObjectiveOverlap
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ObjectiveOverlap
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_Overlaping_ : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct UBP_MissionComponent_C* CallFunc_Get_Mission_Component_MissionComponent;  // 0x10(0x8)

}; 
// Function BP_ObjectiveOverlap.BP_ObjectiveOverlap_C.Checkpoint Overlap
// Size: 0x1(Inherited: 0x1) 
struct FCheckpoint Overlap : public FCheckpoint Overlap
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Overlaping? : 1;  // 0x0(0x1)

}; 
