#pragma once 
#include <ArchVisCharacter_Structs.h>
 
 
 
// Class ArchVisCharacter.ArchVisCharacter
// Size: 0x520(Inherited: 0x4C0) 
struct AArchVisCharacter : public ACharacter
{
	struct FString LookUpAxisName;  // 0x4B8(0x10)
	struct FString LookUpAtRateAxisName;  // 0x4C8(0x10)
	struct FString TurnAxisName;  // 0x4D8(0x10)
	struct FString TurnAtRateAxisName;  // 0x4E8(0x10)
	struct FString MoveForwardAxisName;  // 0x4F8(0x10)
	struct FString MoveRightAxisName;  // 0x508(0x10)
	float MouseSensitivityScale_Pitch;  // 0x518(0x4)
	float MouseSensitivityScale_Yaw;  // 0x51C(0x4)

}; 



// Class ArchVisCharacter.ArchVisCharMovementComponent
// Size: 0xB60(Inherited: 0xB10) 
struct UArchVisCharMovementComponent : public UCharacterMovementComponent
{
	struct FRotator RotationalAcceleration;  // 0xB10(0xC)
	struct FRotator RotationalDeceleration;  // 0xB1C(0xC)
	struct FRotator MaxRotationalVelocity;  // 0xB28(0xC)
	float MinPitch;  // 0xB34(0x4)
	float MaxPitch;  // 0xB38(0x4)
	float WalkingFriction;  // 0xB3C(0x4)
	float WalkingSpeed;  // 0xB40(0x4)
	float WalkingAcceleration;  // 0xB44(0x4)
	char pad_2888[24];  // 0xB48(0x18)

}; 



