#pragma once 
#include <BP_EBS_Building_Torch_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_Torch.BP_EBS_Building_Torch_C
// Size: 0x4D1(Inherited: 0x498) 
struct ABP_EBS_Building_Torch_C : public ABP_EBS_Building_WallObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x498(0x8)
	struct UBoxComponent* SupportChecker4;  // 0x4A0(0x8)
	struct UBoxComponent* SupportChecker3;  // 0x4A8(0x8)
	struct UBoxComponent* SupportChecker2;  // 0x4B0(0x8)
	struct UAudioComponent* Audio;  // 0x4B8(0x8)
	struct UPointLightComponent* PointLight;  // 0x4C0(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x4C8(0x8)
	char pad_1232_1 : 7;  // 0x4D0(0x1)
	bool IsTurnedOn : 1;  // 0x4D0(0x1)

	void IsCanInteract_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.IsCanInteract_BPI
	void GetInteractionObjectName_BPI(struct FText& Name); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.GetInteractionObjectName_BPI
	void GetInteractionText_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, struct FText& InteractionText); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.GetInteractionText_BPI
	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.GetFormatedVariables_BPI
	void OnRep_IsTurnedOn(); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.OnRep_IsTurnedOn
	void CompleteInteractionNotify_BPI(struct APlayerController* PlayerController, struct FName NotifyName); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.CompleteInteractionNotify_BPI
	void TryInteract_BPI(bool Released, struct FKey InteractionKey, struct APlayerController* PlayerController); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.TryInteract_BPI
	void ExecuteUbergraph_BP_EBS_Building_Torch(int32_t EntryPoint); // Function BP_EBS_Building_Torch.BP_EBS_Building_Torch_C.ExecuteUbergraph_BP_EBS_Building_Torch
}; 



