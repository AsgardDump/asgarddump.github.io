#pragma once 
#include <AN_EquipCall_Structs.h>
 
 
 
// BlueprintGeneratedClass AN_EquipCall.AN_EquipCall_C
// Size: 0x38(Inherited: 0x38) 
struct UAN_EquipCall_C : public UAnimNotify
{

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AN_EquipCall.AN_EquipCall_C.Received_Notify
}; 



