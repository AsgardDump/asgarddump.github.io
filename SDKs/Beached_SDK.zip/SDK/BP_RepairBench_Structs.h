#pragma once 
#include "SDK.h" 
 
 
// Function BP_RepairBench.BP_RepairBench_C.Get Interaction Data
// Size: 0x98(Inherited: 0x0) 
struct FGet Interaction Data
{
	struct FText Interaction Text;  // 0x0(0x18)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x18(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x30(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x70(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x80(0x18)

}; 
// Function BP_RepairBench.BP_RepairBench_C.Local Can Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Can Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)

}; 
// Function BP_RepairBench.BP_RepairBench_C.ExecuteUbergraph_BP_RepairBench
// Size: 0xF1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_RepairBench
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AController* K2Node_Event_Executor;  // 0x8(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool K2Node_Event_Overlap : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x20(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x30(0xC)
	float CallFunc_BreakVector_X;  // 0x3C(0x4)
	float CallFunc_BreakVector_Y;  // 0x40(0x4)
	float CallFunc_BreakVector_Z;  // 0x44(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x48(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x4C(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x58(0xC)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x64(0x8C)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0xF0(0x1)

}; 
// Function BP_RepairBench.BP_RepairBench_C.Local Overlap
// Size: 0x1(Inherited: 0x0) 
struct FLocal Overlap
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlap : 1;  // 0x0(0x1)

}; 
// Function BP_RepairBench.BP_RepairBench_C.Toggle Selected
// Size: 0x1(Inherited: 0x0) 
struct FToggle Selected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_RepairBench.BP_RepairBench_C.On Interacted
// Size: 0x8(Inherited: 0x0) 
struct FOn Interacted
{
	struct AController* Executor;  // 0x0(0x8)

}; 
