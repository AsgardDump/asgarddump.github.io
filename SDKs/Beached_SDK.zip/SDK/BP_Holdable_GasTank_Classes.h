#pragma once 
#include <BP_Holdable_GasTank_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_GasTank.BP_Holdable_GasTank_C
// Size: 0x328(Inherited: 0x30A) 
struct ABP_Holdable_GasTank_C : public ABP_Holdable_C
{
	char pad_778[6];  // 0x30A(0x6)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct AActor* Hit Actor;  // 0x318(0x8)
	struct UW_GasTank_C* Gas Widget;  // 0x320(0x8)

	void ReceiveTick(float DeltaSeconds); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.ReceiveBeginPlay
	void Primary Action(bool Pressed); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.Primary Action
	void ReceiveDestroyed(); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.ReceiveDestroyed
	void Aiming Action(bool Toggle); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.Aiming Action
	void SERVER Remove Fuel(struct UObject* Target); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.SERVER Remove Fuel
	void SERVER Add Fuel(struct UObject* Target); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.SERVER Add Fuel
	void ExecuteUbergraph_BP_Holdable_GasTank(int32_t EntryPoint); // Function BP_Holdable_GasTank.BP_Holdable_GasTank_C.ExecuteUbergraph_BP_Holdable_GasTank
}; 



