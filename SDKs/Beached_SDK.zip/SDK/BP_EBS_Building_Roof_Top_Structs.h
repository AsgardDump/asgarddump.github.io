#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_Roof_Top.BP_EBS_Building_Roof_Top_C.CheckRotate
// Size: 0x3A(Inherited: 0xA) 
struct FCheckRotate : public FCheckRotate
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_CheckRotate_Success : 1;  // 0x9(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> CallFunc_Get_Snapped_Objects_OverlappingObjects;  // 0x18(0x10)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x35(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x36(0x1)
	char pad_63_1 : 7;  // 0x3F(0x1)
	bool CallFunc_BuildingObjectInSocket_InSocket : 1;  // 0x37(0x1)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x38(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x39(0x1)

}; 
// Function BP_EBS_Building_Roof_Top.BP_EBS_Building_Roof_Top_C.CheckSupport
// Size: 0x43(Inherited: 0x80) 
struct FCheckSupport : public FCheckSupport
{
	char pad_128_1 : 7;  // 0x80(0x1)
	bool HasSupport : 1;  // 0x0(0x1)
	int32_t LocalCount;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x14(0x4)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	struct TArray<struct ABP_EBS_Building_BaseObject_C*> CallFunc_Get_Snapped_Objects_OverlappingObjects;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	struct ABP_EBS_Building_BaseObject_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_179_1 : 7;  // 0xB3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x41(0x1)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_BuildingObjectInSocket_InSocket : 1;  // 0x42(0x1)

}; 
// Function BP_EBS_Building_Roof_Top.BP_EBS_Building_Roof_Top_C.GetSnapTransform
// Size: 0x120(Inherited: 0x110) 
struct FGetSnapTransform : public FGetSnapTransform
{
	struct AActor* TargetActor;  // 0x0(0x8)
	float InputRotation;  // 0x8(0x4)
	struct FVector HitLocation;  // 0xC(0xC)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool GridMode : 1;  // 0x18(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool SnapNear : 1;  // 0x19(0x1)
	struct FTransform ReturnTransform;  // 0x20(0x30)
	struct FTransform CallFunc_GetSnapTransform_ReturnTransform;  // 0x50(0x30)
	struct ABP_EBS_Building_BaseObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Base_Object;  // 0x80(0x8)
	char pad_402_1 : 7;  // 0x192(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	struct FVector CallFunc_BreakTransform_Location;  // 0x8C(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x98(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0xA4(0xC)
	char pad_439_1 : 7;  // 0x1B7(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xB0(0x1)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xB1(0x1)
	float CallFunc_GetGlobalBuildingRotationStep_StepValue;  // 0xB4(0x4)
	char pad_445_1 : 7;  // 0x1BD(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xB8(0x1)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xBC(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0xC0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xC4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xC8(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xCC(0xC)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0xD8(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xF0(0x30)

}; 
