#pragma once 
#include "SDK.h" 
 
 
// Function BP_Throwable_Molotov.BP_Throwable_Molotov_C.ExecuteUbergraph_BP_Throwable_Molotov
// Size: 0x1A1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Throwable_Molotov
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x18(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x20(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x2C(0x8C)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xB8(0xC)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xC5(0x1)
	char pad_198[2];  // 0xC6(0x2)
	float CallFunc_BreakHitResult_Time;  // 0xC8(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xCC(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xD0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xDC(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xE8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xF4(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x100(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x108(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x110(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x118(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x120(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x124(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x128(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x134(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x140(0x30)
	float CallFunc_BreakVector_X;  // 0x170(0x4)
	float CallFunc_BreakVector_Y;  // 0x174(0x4)
	float CallFunc_BreakVector_Z;  // 0x178(0x4)
	char pad_380[4];  // 0x17C(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x180(0x8)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x188(0x1)
	char pad_393[7];  // 0x189(0x7)
	struct ABP_Fire_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x190(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1A0(0x1)

}; 
// Function BP_Throwable_Molotov.BP_Throwable_Molotov_C.BndEvt__ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xB0(Inherited: 0x0) 
struct FBndEvt__ObjectMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x8C)

}; 
