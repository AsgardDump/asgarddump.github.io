#pragma once 
#include "SDK.h" 
 
 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Get Throw Velocity
// Size: 0x3C(Inherited: 0x0) 
struct FGet Throw Velocity
{
	struct FVector ReturnValue;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x10(0x8)
	struct FRotator CallFunc_GetCameraRotation_ReturnValue;  // 0x18(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x30(0xC)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Primary Action
// Size: 0x1(Inherited: 0x1) 
struct FPrimary Action : public FPrimary Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Pressed : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Get Start Position
// Size: 0x78(Inherited: 0x0) 
struct FGet Start Position
{
	struct FVector ReturnValue;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x10(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x30(0xC)
	float CallFunc_GetScaledCapsuleHalfHeight_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x40(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x44(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x48(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x54(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x60(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x6C(0xC)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.ExecuteUbergraph_BP_Holdable_Throwable
// Size: 0x110(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Holdable_Throwable
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FVector K2Node_CustomEvent_Spawn_Location;  // 0x8(0xC)
	struct FVector K2Node_CustomEvent_Throw_Velocity;  // 0x14(0xC)
	struct FVector CallFunc_Get_Start_Position_ReturnValue;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x30(0x30)
	struct FVector CallFunc_Get_Throw_Velocity_ReturnValue;  // 0x60(0xC)
	char pad_108[4];  // 0x6C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x70(0x8)
	struct UBP_PlayerInventoryComponent_C* CallFunc_Get_Inventory_Component_ReturnValue;  // 0x78(0x8)
	struct AController* K2Node_DynamicCast_AsController;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_Event_Toggle : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)
	struct TScriptInterface<IBPI_Player_C> K2Node_DynamicCast_AsBPI_Player_2;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float K2Node_Event_DeltaSeconds;  // 0xCC(0x4)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct UBP_PlayerComponent_C* CallFunc_Get_Player_Component_ReturnValue;  // 0xD8(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	float CallFunc_PlayAnimMontage_ReturnValue;  // 0xEC(0x4)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_Event_Pressed : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0xF8(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x100(0x8)
	struct ABP_Throwable_Object_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x108(0x8)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Do Predictable Path
// Size: 0x320(Inherited: 0x0) 
struct FDo Predictable Path
{
	struct TArray<struct FVector> Hit Paths L;  // 0x0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[12];  // 0x14(0xC)
	struct FTransform Temp_struct_Variable;  // 0x20(0x30)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x50(0x8)
	struct FVector CallFunc_Get_Throw_Velocity_ReturnValue;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x68(0x10)
	struct FVector CallFunc_Get_Start_Position_ReturnValue;  // 0x78(0xC)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x84(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x88(0x4)
	int32_t Temp_int_Variable;  // 0x8C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x90(0x4)
	int32_t CallFunc_GetNumberOfSplinePoints_ReturnValue;  // 0x94(0x4)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Location;  // 0x98(0xC)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Tangent;  // 0xA4(0xC)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xB0(0x4)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Location_2;  // 0xB4(0xC)
	struct FVector CallFunc_GetLocationAndTangentAtSplinePoint_Tangent_2;  // 0xC0(0xC)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0xD0(0x4)
	char pad_212[12];  // 0xD4(0xC)
	struct FTransform Temp_struct_Variable_2;  // 0xE0(0x30)
	struct FVector CallFunc_Array_Get_Item;  // 0x110(0xC)
	char pad_284[4];  // 0x11C(0x4)
	struct USplineComponent* CallFunc_AddComponent_ReturnValue_2;  // 0x120(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x128(0x4)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x12C(0x1)
	char pad_301[3];  // 0x12D(0x3)
	struct FTransform Temp_struct_Variable_3;  // 0x130(0x30)
	struct USplineMeshComponent* CallFunc_AddComponent_ReturnValue_3;  // 0x160(0x8)
	struct FHitResult CallFunc_Blueprint_PredictProjectilePath_ByObjectType_OutHit;  // 0x168(0x8C)
	char pad_500[4];  // 0x1F4(0x4)
	struct TArray<struct FVector> CallFunc_Blueprint_PredictProjectilePath_ByObjectType_OutPathPositions;  // 0x1F8(0x10)
	struct FVector CallFunc_Blueprint_PredictProjectilePath_ByObjectType_OutLastTraceDestination;  // 0x208(0xC)
	char pad_532_1 : 7;  // 0x214(0x1)
	bool CallFunc_Blueprint_PredictProjectilePath_ByObjectType_ReturnValue : 1;  // 0x214(0x1)
	char pad_533_1 : 7;  // 0x215(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x215(0x1)
	char pad_534_1 : 7;  // 0x216(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x216(0x1)
	char pad_535[1];  // 0x217(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x218(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x21C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x220(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x22C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x238(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x244(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x250(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x258(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x260(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x268(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x270(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x274(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x278(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x284(0xC)
	struct FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult;  // 0x290(0x8C)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x31C(0x4)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Aiming Action
// Size: 0x1(Inherited: 0x1) 
struct FAiming Action : public FAiming Action
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Toggle : 1;  // 0x0(0x1)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.SERVER Throw Object
// Size: 0x18(Inherited: 0x0) 
struct FSERVER Throw Object
{
	struct FVector Spawn Location;  // 0x0(0xC)
	struct FVector Throw Velocity;  // 0xC(0xC)

}; 
// Function BP_Holdable_Throwable.BP_Holdable_Throwable_C.Clear All Components
// Size: 0x21(Inherited: 0x0) 
struct FClear All Components
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USplineMeshComponent* CallFunc_Array_Get_Item;  // 0x8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x20(0x1)

}; 
