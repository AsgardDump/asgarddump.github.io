#pragma once 
#include <BP_Holdable_RangeWeapon_Rifle_AK47_Skin_4_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_Rifle_AK47_Skin_4.BP_Holdable_RangeWeapon_Rifle_AK47_Skin_3_C
// Size: 0x49D(Inherited: 0x49D) 
struct ABP_Holdable_RangeWeapon_Rifle_AK47_Skin_3_C : public ABP_Holdable_RangeWeapon_Rifle_C
{

}; 



