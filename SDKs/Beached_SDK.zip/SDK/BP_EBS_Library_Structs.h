#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Library.BP_EBS_Library_C.ActorIsLandscape
// Size: 0x23(Inherited: 0x0) 
struct FActorIsLandscape
{
	struct AActor* Actor;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	AActor* CallFunc_GetObjectClass_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_ActorHasTag_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x22(0x1)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.ActorsHaveLandscape
// Size: 0x38(Inherited: 0x0) 
struct FActorsHaveLandscape
{
	struct TArray<struct AActor*> Actors;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Result : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_ActorIsLandscape_Result : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.BuildingObjectIsFloorPlaceable
// Size: 0x21(Inherited: 0x0) 
struct FBuildingObjectIsFloorPlaceable
{
	struct ABP_EBS_Building_BaseObject_C* BuildingObject;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ABP_EBS_Building_FloorObject_C* K2Node_DynamicCast_AsBP_EBS_Building_Floor_Object;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.IsValidHandle
// Size: 0x1B(Inherited: 0x0) 
struct FIsValidHandle
{
	struct FDataTableRowHandle Handle;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool IsValid : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalBuildingRotationStep
// Size: 0xC(Inherited: 0x0) 
struct FGetGlobalBuildingRotationStep
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	float StepValue;  // 0x8(0x4)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.NearlyEqualTransforms
// Size: 0xC9(Inherited: 0x0) 
struct FNearlyEqualTransforms
{
	struct FTransform Transform1;  // 0x0(0x30)
	struct FTransform Transform2;  // 0x30(0x30)
	float LocationError;  // 0x60(0x4)
	float RotationError;  // 0x64(0x4)
	float ScaleError;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct UObject* __WorldContext;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FVector CallFunc_BreakTransform_Location;  // 0x7C(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x88(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x94(0xC)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0xA0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0xAC(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0xB8(0xC)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue_2 : 1;  // 0xC5(0x1)
	char pad_198_1 : 7;  // 0xC6(0x1)
	bool CallFunc_EqualEqual_RotatorRotator_ReturnValue : 1;  // 0xC6(0x1)
	char pad_199_1 : 7;  // 0xC7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xC7(0x1)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xC8(0x1)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalBuildingHeightStep
// Size: 0xC(Inherited: 0x0) 
struct FGetGlobalBuildingHeightStep
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	float StepValue;  // 0x8(0x4)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalGridSettings
// Size: 0x18(Inherited: 0x0) 
struct FGetGlobalGridSettings
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	float GridFoundationOffset;  // 0x8(0x4)
	float GridFoundationOffsetZ;  // 0xC(0x4)
	float GridPropsOffset;  // 0x10(0x4)
	float GridCorrectOffset;  // 0x14(0x4)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.GetPlayerID
// Size: 0x30(Inherited: 0x0) 
struct FGetPlayerID
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FString PlayerId;  // 0x10(0x10)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x20(0x10)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalFloorNumberLimit
// Size: 0xC(Inherited: 0x0) 
struct FGetGlobalFloorNumberLimit
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	int32_t FloorNumberLimit;  // 0x8(0x4)

}; 
// Function BP_EBS_Library.BP_EBS_Library_C.GetGlobalDestructChunksLifeTime
// Size: 0xC(Inherited: 0x0) 
struct FGetGlobalDestructChunksLifeTime
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	float StepValue;  // 0x8(0x4)

}; 
