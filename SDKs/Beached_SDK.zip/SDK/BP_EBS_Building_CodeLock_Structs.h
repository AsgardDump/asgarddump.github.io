#pragma once 
#include "SDK.h" 
 
 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.ExecuteUbergraph_BP_EBS_Building_CodeLock
// Size: 0x44(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EBS_Building_CodeLock
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_Released : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FKey K2Node_Event_InteractionKey;  // 0x8(0x18)
	struct APlayerController* K2Node_Event_PlayerController;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_TryToOpenCodelock_Success : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x38(0xC)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryInteract_BPI
// Size: 0x28(Inherited: 0x28) 
struct FTryInteract_BPI : public FTryInteract_BPI
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Released : 1;  // 0x0(0x1)
	struct FKey InteractionKey;  // 0x8(0x18)
	struct APlayerController* PlayerController;  // 0x20(0x8)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryToSetPassword
// Size: 0x9D(Inherited: 0x0) 
struct FTryToSetPassword
{
	struct FString Password;  // 0x0(0x10)
	struct APlayerController* PlayerController;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString LocalNewPassword;  // 0x20(0x10)
	struct APlayerController* LocalPlayerController;  // 0x30(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_CheckAuthorizedPlayer_Result : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x40(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x44(0x4)
	struct APlayerController* CallFunc_Array_Get_Item;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_LockByPlayer_Success : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_CheckAuthorizedPlayer_Result_2 : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x6C(0x4)
	struct FString Temp_string_Variable;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool Temp_bool_Variable : 1;  // 0x81(0x1)
	char pad_130[6];  // 0x82(0x6)
	struct FString K2Node_Select_Default;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Unlock_Success : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Unlock_Success_2 : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x9A(0x1)
	char pad_155_1 : 7;  // 0x9B(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0x9B(0x1)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x9C(0x1)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryToOpenCodelock
// Size: 0x79(Inherited: 0x0) 
struct FTryToOpenCodelock
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerController* LocalPlayerController;  // 0x10(0x8)
	struct FString Temp_string_Variable;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player_2;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_CheckAuthorizedPlayer_Result : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FString K2Node_Select_Default;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x71(0x1)
	char pad_114[2];  // 0x72(0x2)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x78(0x1)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.CloseCodeLock
// Size: 0x1A(Inherited: 0x0) 
struct FCloseCodeLock
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct TScriptInterface<IBPI_EBS_Player_C> K2Node_DynamicCast_AsBPI_EBS_Player;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.TryToCreateCodeLockWidget
// Size: 0x71(Inherited: 0x0) 
struct FTryToCreateCodeLockWidget
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Success : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	struct TScriptInterface<IBPI_EBS_CodeLockWidget_C> K2Node_DynamicCast_AsBPI_EBS_Code_Lock_Widget;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TScriptInterface<IBPI_EBS_CodeLockWidget_C> K2Node_DynamicCast_AsBPI_EBS_Code_Lock_Widget_2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct UUserWidget* CallFunc_Create_ReturnValue;  // 0x48(0x8)
	struct TArray<struct UUserWidget*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x50(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct UUserWidget* CallFunc_Array_Get_Item;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.UpdateCodeLockWidget
// Size: 0x31(Inherited: 0x0) 
struct FUpdateCodeLockWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsLocked : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsAuthorized : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString Password;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TScriptInterface<IBPI_EBS_CodeLockWidget_C> K2Node_DynamicCast_AsBPI_EBS_Code_Lock_Widget;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.RemoveCodeLockWidget
// Size: 0x19(Inherited: 0x0) 
struct FRemoveCodeLockWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TScriptInterface<IBPI_EBS_CodeLockWidget_C> K2Node_DynamicCast_AsBPI_EBS_Code_Lock_Widget;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.IsCanInteract_BPI
// Size: 0x21(Inherited: 0x22) 
struct FIsCanInteract_BPI : public FIsCanInteract_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool Result : 1;  // 0x20(0x1)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.GetInteractionText_BPI
// Size: 0x38(Inherited: 0x39) 
struct FGetInteractionText_BPI : public FGetInteractionText_BPI
{
	struct FKey InteractionKey;  // 0x0(0x18)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	struct FText InteractionText;  // 0x20(0x18)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.GetFormatedVariables_BPI
// Size: 0x40(Inherited: 0x60) 
struct FGetFormatedVariables_BPI : public FGetFormatedVariables_BPI
{
	struct TArray<struct FString> FormatedVariables;  // 0x0(0x10)
	struct TArray<struct FString> CallFunc_GetFormatedVariables_BPI_FormatedVariables;  // 0x10(0x10)
	struct FString CallFunc_FormatStringVariableToString_FormatedVariable;  // 0x20(0x10)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x30(0x10)

}; 
// Function BP_EBS_Building_CodeLock.BP_EBS_Building_CodeLock_C.LoadData_BPI
// Size: 0x98(Inherited: 0xC5) 
struct FLoadData_BPI : public FLoadData_BPI
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_205_1 : 7;  // 0xCD(0x1)
	bool Success : 1;  // 0x8(0x1)
	struct TScriptInterface<IBPI_EBS_SaveGame_C> K2Node_DynamicCast_AsBPI_EBS_Save_Game;  // 0x10(0x10)
	char pad_222_1 : 7;  // 0xDE(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_223_1 : 7;  // 0xDF(0x1)
	bool CallFunc_LoadData_BPI_Success : 1;  // 0x21(0x1)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_GetActorSaveData_BPI_Success : 1;  // 0x22(0x1)
	struct FSTR_EBS_SaveData_Actor CallFunc_GetActorSaveData_BPI_SaveData;  // 0x30(0x50)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_GetFormatedVariableStringValue_Success : 1;  // 0x80(0x1)
	struct FString CallFunc_GetFormatedVariableStringValue_Value;  // 0x88(0x10)

}; 
