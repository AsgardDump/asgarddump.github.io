#pragma once 
#include <BP_EBS_Building_SmallWoodenBox_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C
// Size: 0x501(Inherited: 0x4A8) 
struct ABP_EBS_Building_SmallWoodenBox_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct UBP_ChestInventoryComponent_C* BP_ChestInventoryComponent;  // 0x4B0(0x8)
	struct UBoxComponent* SupportChecker4;  // 0x4B8(0x8)
	struct UBoxComponent* SupportChecker3;  // 0x4C0(0x8)
	struct UBoxComponent* SupportChecker2;  // 0x4C8(0x8)
	struct UAudioComponent* Audio;  // 0x4D0(0x8)
	struct UPointLightComponent* PointLight;  // 0x4D8(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x4E0(0x8)
	struct UBoxComponent* BuildCollision;  // 0x4E8(0x8)
	float Timeline_0_Alpha_6F3956F947A9C2DA1799E68A6E82E0F8;  // 0x4F0(0x4)
	char ETimelineDirection Timeline_0__Direction_6F3956F947A9C2DA1799E68A6E82E0F8;  // 0x4F4(0x1)
	char pad_1269[3];  // 0x4F5(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x4F8(0x8)
	char pad_1280_1 : 7;  // 0x500(0x1)
	bool IsTurnedOn : 1;  // 0x500(0x1)

	void Get Interaction Data(struct FText& Interaction Text); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Get Interaction Data
	void Local Can Overlap(bool& Success); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Local Can Overlap
	void IsCanInteract_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, bool& Result); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.IsCanInteract_BPI
	void GetInteractionObjectName_BPI(struct FText& Name); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.GetInteractionObjectName_BPI
	void GetInteractionText_BPI(struct FKey InteractionKey, struct APlayerController* PlayerController, struct FText& InteractionText); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.GetInteractionText_BPI
	void LoadData_BPI(struct USaveGame* SaveGame, bool& Success); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.LoadData_BPI
	void GetFormatedVariables_BPI(struct TArray<struct FString>& FormatedVariables); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.GetFormatedVariables_BPI
	void OnRep_TurnedOn(); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.OnRep_TurnedOn
	void Timeline_0__FinishedFunc(); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Timeline_0__UpdateFunc
	void CustomEvent(struct AController* Executor); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.CustomEvent
	void CustomEvent_2(bool Toggle); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.CustomEvent_2
	void Toggle Chest(bool Toggle); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Toggle Chest
	void CompleteInteractionNotify_BPI(struct APlayerController* PlayerController, struct FName NotifyName); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.CompleteInteractionNotify_BPI
	void TryInteract_BPI(bool Released, struct FKey InteractionKey, struct APlayerController* PlayerController); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.TryInteract_BPI
	void Local Overlap(bool Overlap); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Local Overlap
	void Toggle Selected(bool Toggle); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.Toggle Selected
	void On Interacted(struct AController* Executor); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.On Interacted
	void ExecuteUbergraph_BP_EBS_Building_SmallWoodenBox(int32_t EntryPoint); // Function BP_EBS_Building_SmallWoodenBox.BP_EBS_Building_SmallWoodenBox_C.ExecuteUbergraph_BP_EBS_Building_SmallWoodenBox
}; 



