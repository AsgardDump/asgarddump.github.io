#pragma once 
#include <BP_EBS_InteractionComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C
// Size: 0x1E0(Inherited: 0xB0) 
struct UBP_EBS_InteractionComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct APlayerController* PlayerController;  // 0xB8(0x8)
	struct ACharacter* PlayerCharacter;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool IsLocalPlayer : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool ManualInit : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool TraceByTick : 1;  // 0xCA(0x1)
	char pad_203_1 : 7;  // 0xCB(0x1)
	bool TraceToMouseMode : 1;  // 0xCB(0x1)
	float TraceDistance;  // 0xCC(0x4)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool TopDownViewMode : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	float TopDownTraceDistance;  // 0xD4(0x4)
	float InteractionRange;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)
	struct TMap<char E_EBS_InteractionType, struct UAnimMontage*> InteractionMontages;  // 0xE0(0x50)
	UUserWidget* InteractionWidgetClass;  // 0x130(0x8)
	struct AActor* TargetActor;  // 0x138(0x8)
	struct AActor* InteractionActor;  // 0x140(0x8)
	struct FMulticastInlineDelegate OnInteractionActorChanged;  // 0x148(0x10)
	struct FMulticastInlineDelegate OnTargetActorChanged;  // 0x158(0x10)
	char E_EBS_InteractionType InteractionStance;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct AActor* CurrentInteractionActor;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool ShouldUpdateRotation : 1;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	struct FRotator TargetRotation;  // 0x17C(0xC)
	struct FMulticastInlineDelegate OnInteractionNotify;  // 0x188(0x10)
	struct FMulticastInlineDelegate OnInteractionStanceChanged;  // 0x198(0x10)
	int32_t DisplayedFloor;  // 0x1A8(0x4)
	char pad_428[4];  // 0x1AC(0x4)
	struct UBP_EBS_InteractionComponent_C* CharacterInteractionComponent;  // 0x1B0(0x8)
	struct UUserWidget* InteractionWidget;  // 0x1B8(0x8)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool DebugMode : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	struct FText DebugInformation;  // 0x1C8(0x18)

	void UpdateProcess(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateProcess
	void ChangeDebugMode(bool DebugMode, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeDebugMode
	void GetDebugInformation(struct FText& DebugInformation); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetDebugInformation
	void PrintDebugInformation(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.PrintDebugInformation
	void GetInteractionStance(char E_EBS_InteractionType& InteractionStance); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetInteractionStance
	void ChangeInteractionWidget(UUserWidget* InteractionWidgetClass, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeInteractionWidget
	void BindCharacterInteractionStanceChanged(char E_EBS_InteractionType NewInteractionStance, char E_EBS_InteractionType PrevInteractionStance); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.BindCharacterInteractionStanceChanged
	void BindCharacterInteractionNotify(struct ACharacter* Character, struct AActor* InteractionActor, struct FName NotifyName); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.BindCharacterInteractionNotify
	void InitCharacterReferences(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.InitCharacterReferences
	void ResetFloorActorsVisibility(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ResetFloorActorsVisibility
	void UpdateFloorActorsVisibility(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateFloorActorsVisibility
	void ChangeTopDownView(bool TopDownViewMode, bool TraceToMouseMode, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeTopDownView
	void ChangeDisplayedFloor(char E_EBS_ChangeVariableOperation Operation, int32_t Value, bool UpdateVisibility, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeDisplayedFloor
	void CheckInitReferences(); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.CheckInitReferences
	void ChangeInteractionStance(char E_EBS_InteractionType NewInteractionStance, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeInteractionStance
	void CompleteInteractionNotify(struct FName NotifyName, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.CompleteInteractionNotify
	void UpdateCharacterRotation(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateCharacterRotation
	void StartRotateCharacter(struct FRotator TargetRotation, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.StartRotateCharacter
	void PlayInteractionMontage(char E_EBS_InteractionType InteractionType, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.PlayInteractionMontage
	void TryStartInteractonWithActor(struct AActor* TargetActor, char E_EBS_InteractionType InteractionType, bool RotateToTarget, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryStartInteractonWithActor
	void GetTargetActor(struct AActor*& TargetActor); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetTargetActor
	void SetTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.SetTargetActor
	void GetInteractionActor(struct AActor*& InteractionActor); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetInteractionActor
	void SetInteractionActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.SetInteractionActor
	void GetFloorIgnoringActors(int32_t FloorNumber, struct TArray<struct AActor*>& IgnoringActors); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetFloorIgnoringActors
	void GetTraceHitResult(struct FHitResult& HitResult); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.GetTraceHitResult
	void UpdateInteractionActor(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.UpdateInteractionActor
	void TryToCreateInteractionWidget(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryToCreateInteractionWidget
	void AutoInitComponent(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.AutoInitComponent
	void InitComponent(bool& Success); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.InitComponent
	void ReceiveTick(float DeltaSeconds); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ReceiveTick
	void TryInteract (Client)(bool Released, struct FKey InteractionKey); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryInteract (Client)
	void TryInteract (Server)(bool Released, struct FKey InteractionKey, struct AActor* InteractionActor); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.TryInteract (Server)
	void ReceiveBeginPlay(); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ReceiveBeginPlay
	void PlayInteractionMontage (Multicast)(struct UAnimMontage* AnimMontage); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.PlayInteractionMontage (Multicast)
	void StartRotateCharacter (Multicast)(struct FRotator TargetRotation); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.StartRotateCharacter (Multicast)
	void ChangeInteractionWidget (Client)(UUserWidget* InteractionWidgetClass); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ChangeInteractionWidget (Client)
	void ExecuteUbergraph_BP_EBS_InteractionComponent(int32_t EntryPoint); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.ExecuteUbergraph_BP_EBS_InteractionComponent
	void OnInteractionStanceChanged__DelegateSignature(char E_EBS_InteractionType NewInteractionStance, char E_EBS_InteractionType PrevInteractionStance); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnInteractionStanceChanged__DelegateSignature
	void OnInteractionNotify__DelegateSignature(struct ACharacter* Character, struct AActor* InteractionActor, struct FName NotifyName); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnInteractionNotify__DelegateSignature
	void OnTargetActorChanged__DelegateSignature(struct AActor* TargetActor); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnTargetActorChanged__DelegateSignature
	void OnInteractionActorChanged__DelegateSignature(struct AActor* InteractionActor); // Function BP_EBS_InteractionComponent.BP_EBS_InteractionComponent_C.OnInteractionActorChanged__DelegateSignature
}; 



