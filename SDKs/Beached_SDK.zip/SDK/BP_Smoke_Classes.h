#pragma once 
#include <BP_Smoke_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Smoke.BP_Smoke_C
// Size: 0x254(Inherited: 0x220) 
struct ABP_Smoke_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x228(0x8)
	float Animation_Fade_In_Fade_In_5526264E4C275B0BE6DFB686C3A91E7C;  // 0x230(0x4)
	char ETimelineDirection Animation_Fade_In__Direction_5526264E4C275B0BE6DFB686C3A91E7C;  // 0x234(0x1)
	char pad_565[3];  // 0x235(0x3)
	struct UTimelineComponent* Animation Fade In;  // 0x238(0x8)
	float Animation_Fade_Out_Animation_B7A0469743136DBD3F79899AF323396F;  // 0x240(0x4)
	char ETimelineDirection Animation_Fade_Out__Direction_B7A0469743136DBD3F79899AF323396F;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* Animation Fade Out;  // 0x248(0x8)
	float Smoke Life Time;  // 0x250(0x4)

	void Animation Fade Out__FinishedFunc(); // Function BP_Smoke.BP_Smoke_C.Animation Fade Out__FinishedFunc
	void Animation Fade Out__UpdateFunc(); // Function BP_Smoke.BP_Smoke_C.Animation Fade Out__UpdateFunc
	void Animation Fade In__FinishedFunc(); // Function BP_Smoke.BP_Smoke_C.Animation Fade In__FinishedFunc
	void Animation Fade In__UpdateFunc(); // Function BP_Smoke.BP_Smoke_C.Animation Fade In__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Smoke.BP_Smoke_C.ReceiveBeginPlay
	void MULTICAST Fire Disappear(); // Function BP_Smoke.BP_Smoke_C.MULTICAST Fire Disappear
	void ExecuteUbergraph_BP_Smoke(int32_t EntryPoint); // Function BP_Smoke.BP_Smoke_C.ExecuteUbergraph_BP_Smoke
}; 



