#pragma once 
#include <BP_Holdable_MeeleWeapon_Harvestable_Knife_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_MeeleWeapon_Harvestable_Knife.BP_Holdable_MeeleWeapon_Harvestable_Knife_C
// Size: 0x329(Inherited: 0x329) 
struct ABP_Holdable_MeeleWeapon_Harvestable_Knife_C : public ABP_Holdable_MeeleWeapon_Harvestable_C
{

}; 



