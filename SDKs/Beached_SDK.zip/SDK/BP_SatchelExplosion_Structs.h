#pragma once 
#include "SDK.h" 
 
 
// Function BP_SatchelExplosion.BP_SatchelExplosion_C.ExecuteUbergraph_BP_SatchelExplosion
// Size: 0x29(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SatchelExplosion
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UParticleSystemComponent* K2Node_ComponentBoundEvent_PSystem;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x14(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_SatchelExplosion.BP_SatchelExplosion_C.UserConstructionScript
// Size: 0x1C(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FVector CallFunc_GetActorScale3D_ReturnValue;  // 0x0(0xC)
	float CallFunc_BreakVector_X;  // 0xC(0x4)
	float CallFunc_BreakVector_Y;  // 0x10(0x4)
	float CallFunc_BreakVector_Z;  // 0x14(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x18(0x4)

}; 
// Function BP_SatchelExplosion.BP_SatchelExplosion_C.BndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__ParticleSystem_K2Node_ComponentBoundEvent_0_OnSystemFinished__DelegateSignature
{
	struct UParticleSystemComponent* PSystem;  // 0x0(0x8)

}; 
// Function BP_SatchelExplosion.BP_SatchelExplosion_C.Apply Explosion Damage
// Size: 0x329(Inherited: 0x0) 
struct FApply Explosion Damage
{
	struct TArray<struct AActor*> L ActorList;  // 0x0(0x10)
	struct FHitResult CallFunc_MakeHitResult_ReturnValue;  // 0x10(0x8C)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x9C(0xC)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0xB0(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xC4(0xC)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0xD0(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0xE0(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0xE8(0x8)
	struct AController* K2Node_DynamicCast_AsController;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0xFC(0x4)
	struct TArray<struct AActor*> Temp_object_Variable_2;  // 0x100(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x110(0xC)
	char pad_284[4];  // 0x11C(0x4)
	struct TArray<struct FHitResult> CallFunc_SphereTraceMulti_OutHits;  // 0x120(0x10)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_SphereTraceMulti_ReturnValue : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x134(0x4)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x13C(0x8C)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1C8(0x1)
	char pad_457_1 : 7;  // 0x1C9(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x1C9(0x1)
	char pad_458[2];  // 0x1CA(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x1CC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1D0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1D4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1E0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1EC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x1F8(0xC)
	char pad_516[4];  // 0x204(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x208(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x210(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x218(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x220(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x228(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x22C(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x230(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x23C(0xC)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool CallFunc_ActorHasTag_ReturnValue : 1;  // 0x248(0x1)
	char pad_585[3];  // 0x249(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x24C(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x258(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_5;  // 0x264(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x270(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x27C(0xC)
	float CallFunc_ApplyPointDamage_ReturnValue;  // 0x288(0x4)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x28C(0x8C)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x318(0x1)
	char pad_793_1 : 7;  // 0x319(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x319(0x1)
	char pad_794_1 : 7;  // 0x31A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x31A(0x1)
	char pad_795[1];  // 0x31B(0x1)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x31C(0x4)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x320(0x8)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x328(0x1)

}; 
