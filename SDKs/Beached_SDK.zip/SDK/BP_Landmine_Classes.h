#pragma once 
#include <BP_Landmine_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Landmine.BP_Landmine_C
// Size: 0x240(Inherited: 0x220) 
struct ABP_Landmine_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* Player Overlap;  // 0x228(0x8)
	struct UStaticMeshComponent* Cylinder;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)

	void ReceiveBeginPlay(); // Function BP_Landmine.BP_Landmine_C.ReceiveBeginPlay
	void ReceivePointDamage(float Damage, struct UDamageType* DamageType, struct FVector HitLocation, struct FVector HitNormal, struct UPrimitiveComponent* HitComponent, struct FName BoneName, struct FVector ShotFromDirection, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FHitResult& HitInfo); // Function BP_Landmine.BP_Landmine_C.ReceivePointDamage
	void BndEvt__BP_Landmine_Box_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Landmine.BP_Landmine_C.BndEvt__BP_Landmine_Box_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
	void ExecuteUbergraph_BP_Landmine(int32_t EntryPoint); // Function BP_Landmine.BP_Landmine_C.ExecuteUbergraph_BP_Landmine
}; 



