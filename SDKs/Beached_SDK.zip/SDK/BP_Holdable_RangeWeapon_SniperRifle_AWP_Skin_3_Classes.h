#pragma once 
#include <BP_Holdable_RangeWeapon_SniperRifle_AWP_Skin_3_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_SniperRifle_AWP_Skin_3.BP_Holdable_RangeWeapon_SniperRifle_AWP_Skin_2_C
// Size: 0x4C0(Inherited: 0x4C0) 
struct ABP_Holdable_RangeWeapon_SniperRifle_AWP_Skin_2_C : public ABP_Holdable_RangeWeapon_SniperRifle_C
{

}; 



