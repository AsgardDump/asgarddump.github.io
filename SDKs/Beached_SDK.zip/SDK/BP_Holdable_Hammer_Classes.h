#pragma once 
#include <BP_Holdable_Hammer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_Hammer.BP_Holdable_Hammer_C
// Size: 0x3C0(Inherited: 0x30A) 
struct ABP_Holdable_Hammer_C : public ABP_Holdable_C
{
	char pad_778[6];  // 0x30A(0x6)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct UW_HammerInformation_C* Widget;  // 0x318(0x8)
	struct FTimerHandle Timer;  // 0x320(0x8)
	struct FHitResult Hit;  // 0x328(0x8C)
	char pad_948_1 : 7;  // 0x3B4(0x1)
	bool IsHolding : 1;  // 0x3B4(0x1)
	char pad_949[3];  // 0x3B5(0x3)
	struct UBP_EBS_InteractionComponent_C* InteractionComponent;  // 0x3B8(0x8)

	void ReceiveBeginPlay(); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.ReceiveTick
	void ReceiveDestroyed(); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.ReceiveDestroyed
	void Primary Action(bool Pressed); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.Primary Action
	void Toggle Time(bool Toggle); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.Toggle Time
	void Destroy Building(); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.Destroy Building
	void SERVER Destroy Building(struct AActor* Destroy Building); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.SERVER Destroy Building
	void Aiming Action(bool Toggle); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.Aiming Action
	void Dequip Holdable(); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.Dequip Holdable
	void ExecuteUbergraph_BP_Holdable_Hammer(int32_t EntryPoint); // Function BP_Holdable_Hammer.BP_Holdable_Hammer_C.ExecuteUbergraph_BP_Holdable_Hammer
}; 



