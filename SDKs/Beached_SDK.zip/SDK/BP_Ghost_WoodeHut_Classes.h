#pragma once 
#include <BP_Ghost_WoodeHut_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ghost_WoodeHut.BP_Ghost_WoodeHut_C
// Size: 0x280(Inherited: 0x280) 
struct ABP_Ghost_WoodeHut_C : public ABP_GhostActor_C
{

	void Custom Rotation(struct FHitResult Hit, struct FRotator Current Rotation); // Function BP_Ghost_WoodeHut.BP_Ghost_WoodeHut_C.Custom Rotation
	void Custom Condition Pass(struct FHitResult Hit, bool& Return); // Function BP_Ghost_WoodeHut.BP_Ghost_WoodeHut_C.Custom Condition Pass
}; 



