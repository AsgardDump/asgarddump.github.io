#pragma once 
#include <BP_Cupboard_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Cupboard.BP_Cupboard_C
// Size: 0x528(Inherited: 0x4A8) 
struct ABP_Cupboard_C : public ABP_EBS_Building_FloorObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A8(0x8)
	struct UStaticMeshComponent* ZONE;  // 0x4B0(0x8)
	struct UBP_ChestInventoryComponent_C* BP_ChestInventoryComponent;  // 0x4B8(0x8)
	struct UBoxComponent* Box;  // 0x4C0(0x8)
	struct TArray<struct FString> Privilege Buildings;  // 0x4C8(0x10)
	struct TArray<struct FString> Privilege Players;  // 0x4D8(0x10)
	float Cupboard Distance;  // 0x4E8(0x4)
	char pad_1260[4];  // 0x4EC(0x4)
	struct UMaterialInstanceDynamic* Dynamic Zone Material;  // 0x4F0(0x8)
	struct TArray<struct AActor*> Overlapping Actors;  // 0x4F8(0x10)
	struct TArray<int32_t> L Slots to Update;  // 0x508(0x10)
	struct TArray<struct FS_InventoryItem> Inventory;  // 0x518(0x10)

	void Local Can Overlap(bool& Success); // Function BP_Cupboard.BP_Cupboard_C.Local Can Overlap
	void Get Interaction Data(struct FText& Interaction Text); // Function BP_Cupboard.BP_Cupboard_C.Get Interaction Data
	void Save Building List(); // Function BP_Cupboard.BP_Cupboard_C.Save Building List
	void Find Privilege Building(); // Function BP_Cupboard.BP_Cupboard_C.Find Privilege Building
	void Save Player List(); // Function BP_Cupboard.BP_Cupboard_C.Save Player List
	void UserConstructionScript(); // Function BP_Cupboard.BP_Cupboard_C.UserConstructionScript
	void Local Overlap(bool Overlap); // Function BP_Cupboard.BP_Cupboard_C.Local Overlap
	void On Interacted(struct AController* Executor); // Function BP_Cupboard.BP_Cupboard_C.On Interacted
	void Toggle Selected(bool Toggle); // Function BP_Cupboard.BP_Cupboard_C.Toggle Selected
	void Add Building(struct FString Building ID); // Function BP_Cupboard.BP_Cupboard_C.Add Building
	void Remove Building(struct FString Building ID); // Function BP_Cupboard.BP_Cupboard_C.Remove Building
	void ReceiveBeginPlay(); // Function BP_Cupboard.BP_Cupboard_C.ReceiveBeginPlay
	void Set Building Overlap Color(bool Overlap); // Function BP_Cupboard.BP_Cupboard_C.Set Building Overlap Color
	void CheckForCollisionBeneath(); // Function BP_Cupboard.BP_Cupboard_C.CheckForCollisionBeneath
	void ChestBroken(struct AActor* DestroyedActor); // Function BP_Cupboard.BP_Cupboard_C.ChestBroken
	void CLIENT Reconstruct Inventory(); // Function BP_Cupboard.BP_Cupboard_C.CLIENT Reconstruct Inventory
	void ExecuteUbergraph_BP_Cupboard(int32_t EntryPoint); // Function BP_Cupboard.BP_Cupboard_C.ExecuteUbergraph_BP_Cupboard
}; 



