#pragma once 
#include <ABP_Lobby_Character_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Lobby_Character.ABP_Lobby_Character_C
// Size: 0x3C4(Inherited: 0x2C0) 
struct UABP_Lobby_Character_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2F8(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x340(0x80)
	int32_t Dance Index;  // 0x3C0(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Lobby_Character.ABP_Lobby_Character_C.AnimGraph
	void ExecuteUbergraph_ABP_Lobby_Character(int32_t EntryPoint); // Function ABP_Lobby_Character.ABP_Lobby_Character_C.ExecuteUbergraph_ABP_Lobby_Character
}; 



