#pragma once 
#include "SDK.h" 
 
 
// Function BP_Animal_Chicken.BP_Animal_Chicken_C.ExecuteUbergraph_BP_Animal_Chicken
// Size: 0x79(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Animal_Chicken
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_Damage;  // 0x4(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x8(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x10(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x18(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UDT_Bullet_C* K2Node_DynamicCast_AsDT_Bullet;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct AController* K2Node_Event_NewController;  // 0x48(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x50(0xC)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool K2Node_CustomEvent_Melee : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue;  // 0x60(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x68(0x8)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_RunBehaviorTree_ReturnValue : 1;  // 0x78(0x1)

}; 
// Function BP_Animal_Chicken.BP_Animal_Chicken_C.MULTICAST On Damage
// Size: 0x1(Inherited: 0x0) 
struct FMULTICAST On Damage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Melee : 1;  // 0x0(0x1)

}; 
// Function BP_Animal_Chicken.BP_Animal_Chicken_C.ReceivePossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessed : public FReceivePossessed
{
	struct AController* NewController;  // 0x0(0x8)

}; 
// Function BP_Animal_Chicken.BP_Animal_Chicken_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
