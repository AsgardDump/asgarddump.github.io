#pragma once 
#include <BP_EBS_Building_RoofWall_Top_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EBS_Building_RoofWall_Top.BP_EBS_Building_RoofWall_Top_C
// Size: 0x4B8(Inherited: 0x479) 
struct ABP_EBS_Building_RoofWall_Top_C : public ABP_EBS_Building_BaseObject_C
{
	char pad_1145[7];  // 0x479(0x7)
	struct USceneComponent* RoofSocket4;  // 0x480(0x8)
	struct USceneComponent* RoofSocket3;  // 0x488(0x8)
	struct USceneComponent* RoofSocket2;  // 0x490(0x8)
	struct USceneComponent* RoofSocket1;  // 0x498(0x8)
	struct USceneComponent* RoofSockets;  // 0x4A0(0x8)
	struct UBoxComponent* BuildCollision;  // 0x4A8(0x8)
	struct USceneComponent* BuildComponents;  // 0x4B0(0x8)

	void SetFloorNumberByTargetActor(struct AActor* TargetActor, bool& Success); // Function BP_EBS_Building_RoofWall_Top.BP_EBS_Building_RoofWall_Top_C.SetFloorNumberByTargetActor
	void BuildingObjectInSocket(struct ABP_EBS_Building_BaseObject_C* TargetObject, bool& InSocket); // Function BP_EBS_Building_RoofWall_Top.BP_EBS_Building_RoofWall_Top_C.BuildingObjectInSocket
	void GetSnapTransform(struct AActor* TargetActor, float InputRotation, struct FVector HitLocation, bool GridMode, bool SnapNear, struct FTransform& ReturnTransform); // Function BP_EBS_Building_RoofWall_Top.BP_EBS_Building_RoofWall_Top_C.GetSnapTransform
}; 



