#pragma once 
#include "SDK.h" 
 
 
// Function BFL_Inventory.BFL_Inventory_C.Get Item Data from ID
// Size: 0x1E1(Inherited: 0x0) 
struct FGet Item Data from ID
{
	struct FName Item ID;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsValid : 1;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)
	struct FS_InventoryItemData Item Data;  // 0x20(0xE0)
	struct FS_InventoryItemData CallFunc_GetDataTableRowFromName_OutRow;  // 0x100(0xE0)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x1E0(0x1)

}; 
// Function BFL_Inventory.BFL_Inventory_C.Generate Random Timestamp ID
// Size: 0x68(Inherited: 0x0) 
struct FGenerate Random Timestamp ID
{
	struct FString NewParam;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FString ReturnValue;  // 0x18(0x10)
	struct FString L ID;  // 0x28(0x10)
	struct FGuid CallFunc_NewGuid_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Conv_GuidToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x58(0x10)

}; 
