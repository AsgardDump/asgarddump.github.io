#pragma once 
#include <BP_Holdable_RangeWeapon_SniperRifle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C
// Size: 0x4C0(Inherited: 0x49D) 
struct ABP_Holdable_RangeWeapon_SniperRifle_C : public ABP_Holdable_RangeWeapon_C
{
	char pad_1181[3];  // 0x49D(0x3)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4A0(0x8)
	struct USpringArmComponent* SpringArm;  // 0x4A8(0x8)
	struct UUserWidget* Scope Widget;  // 0x4B0(0x8)
	struct UCameraComponent* Aim Camera;  // 0x4B8(0x8)

	void Toggle Upgrade Mode(bool Toggle); // Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.Toggle Upgrade Mode
	void Change Firemode(); // Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.Change Firemode
	void ReceiveDestroyed(); // Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.ReceiveDestroyed
	void Aiming Action(bool Toggle); // Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.Aiming Action
	void ReceiveTick(float DeltaSeconds); // Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.ReceiveTick
	void ExecuteUbergraph_BP_Holdable_RangeWeapon_SniperRifle(int32_t EntryPoint); // Function BP_Holdable_RangeWeapon_SniperRifle.BP_Holdable_RangeWeapon_SniperRifle_C.ExecuteUbergraph_BP_Holdable_RangeWeapon_SniperRifle
}; 



