#pragma once 
#include <BP_GhostShards_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GhostShards.BP_GhostShards_C
// Size: 0x37C(Inherited: 0x220) 
struct ABP_GhostShards_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct UAudioComponent* Vacuum_CrystalLoop;  // 0x230(0x8)
	struct UParticleSystemComponent* IMP_C_M_02_Lightning1;  // 0x238(0x8)
	struct UParticleSystemComponent* IMP_C_M_02_Lightning;  // 0x240(0x8)
	struct UParticleSystemComponent* Par_Sonar_Impact_01;  // 0x248(0x8)
	struct UParticleSystemComponent* ParticleSystem5;  // 0x250(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x258(0x8)
	struct UParticleSystemComponent* ParticleSystem4;  // 0x260(0x8)
	struct UParticleSystemComponent* ParticleSystem3;  // 0x268(0x8)
	struct UParticleSystemComponent* ParticleSystem2;  // 0x270(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x278(0x8)
	float ScaleDownShards_Scale_6E9597D14B79DB08AB9C499B45D3EDC4;  // 0x280(0x4)
	char ETimelineDirection ScaleDownShards__Direction_6E9597D14B79DB08AB9C499B45D3EDC4;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct UTimelineComponent* ScaleDownShards;  // 0x288(0x8)
	struct UMaterialInstanceDynamic* GhostMaterial;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool VacuumStarted? : 1;  // 0x298(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	bool USE SMALL GHOST CHUNKS? : 1;  // 0x299(0x1)
	char pad_666[2];  // 0x29A(0x2)
	float ImpulseStrength;  // 0x29C(0x4)
	struct AMGH_PlayerState_C* Ghost Player State;  // 0x2A0(0x8)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Ghost was a Bot? : 1;  // 0x2A8(0x1)
	char pad_681[7];  // 0x2A9(0x7)
	struct AActor* My Owning Player State;  // 0x2B0(0x8)
	struct TArray<struct UStaticMeshComponent*> shards;  // 0x2B8(0x10)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool Vacuuming : 1;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)
	struct AActor* My_ResurrectableGhost;  // 0x2D0(0x8)
	int32_t ShardsCollected;  // 0x2D8(0x4)
	char pad_732_1 : 7;  // 0x2DC(0x1)
	bool BEING VACUUMED? : 1;  // 0x2DC(0x1)
	char pad_733[3];  // 0x2DD(0x3)
	struct ABP_Hunter_C* HUNTER VACUUMING?;  // 0x2E0(0x8)
	float VacuumSpeed;  // 0x2E8(0x4)
	float DistanceCutoff;  // 0x2EC(0x4)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool Red? : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct TArray<int32_t> Shards_ID;  // 0x2F8(0x10)
	float TheAlpha;  // 0x308(0x4)
	char pad_780_1 : 7;  // 0x30C(0x1)
	bool DO NOT DESTROY : 1;  // 0x30C(0x1)
	char pad_781_1 : 7;  // 0x30D(0x1)
	bool ShardsFadeOut? : 1;  // 0x30D(0x1)
	char pad_782_1 : 7;  // 0x30E(0x1)
	bool AlreadyVacuumedLocally : 1;  // 0x30E(0x1)
	char pad_783[1];  // 0x30F(0x1)
	struct TMap<struct UStaticMeshComponent*, float> LOSShards;  // 0x310(0x50)
	struct TArray<struct UStaticMeshComponent*> Shards Cached;  // 0x360(0x10)
	struct FVector Last Vector;  // 0x370(0xC)

	void UserConstructionScript(); // Function BP_GhostShards.BP_GhostShards_C.UserConstructionScript
	void ScaleDownShards__FinishedFunc(); // Function BP_GhostShards.BP_GhostShards_C.ScaleDownShards__FinishedFunc
	void ScaleDownShards__UpdateFunc(); // Function BP_GhostShards.BP_GhostShards_C.ScaleDownShards__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_GhostShards.BP_GhostShards_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_GhostShards.BP_GhostShards_C.ReceiveTick
	void VacuumStarted(); // Function BP_GhostShards.BP_GhostShards_C.VacuumStarted
	void ActivateParticleVacuum(bool  START!, struct FVector Vector, struct UVacuumTicker_C* Vacuum Ticker); // Function BP_GhostShards.BP_GhostShards_C.ActivateParticleVacuum
	void UpdateShardsCollected(int32_t Operation); // Function BP_GhostShards.BP_GhostShards_C.UpdateShardsCollected
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_GhostShards.BP_GhostShards_C.ReceiveEndPlay
	void LOS_Timer(); // Function BP_GhostShards.BP_GhostShards_C.LOS_Timer
	void ShardVacuumed(struct UStaticMeshComponent* Shard); // Function BP_GhostShards.BP_GhostShards_C.ShardVacuumed
	void Bind LOS Timer(); // Function BP_GhostShards.BP_GhostShards_C.Bind LOS Timer
	void ExecuteUbergraph_BP_GhostShards(int32_t EntryPoint); // Function BP_GhostShards.BP_GhostShards_C.ExecuteUbergraph_BP_GhostShards
}; 



