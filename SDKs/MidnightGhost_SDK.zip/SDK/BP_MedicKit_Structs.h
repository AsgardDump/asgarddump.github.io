#pragma once 
#include "SDK.h" 
 
 
// Function BP_MedicKit.BP_MedicKit_C.ReceiveHit
// Size: 0xC8(Inherited: 0xC8) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x88)

}; 
// Function BP_MedicKit.BP_MedicKit_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_MedicKit.BP_MedicKit_C.ExecuteUbergraph_BP_MedicKit
// Size: 0x45D(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MedicKit
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x30(0x8)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x38(0x8)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x40(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x48(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x58(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x60(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x70(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x78(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x88(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x90(0x10)
	struct FName Temp_name_Variable;  // 0xA0(0x8)
	float K2Node_Event_DeltaSeconds;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0xB0(0x8)
	struct AActor* K2Node_Event_Other;  // 0xB8(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0xCC(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0xD8(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0xE4(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0xF0(0x88)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x178(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x184(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x188(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x18C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x190(0xC)
	char pad_412[4];  // 0x19C(0x4)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x1A0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x1D0(0x8)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x1D8(0x1)
	char pad_473[7];  // 0x1D9(0x7)
	struct ABP_MedicKitInteract_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1E8(0x1)
	char pad_489[7];  // 0x1E9(0x7)
	struct ABP_Hunter_C* K2Node_CustomEvent_HealHunter;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1F8(0x1)
	char pad_505_1 : 7;  // 0x1F9(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x1F9(0x1)
	char pad_506_1 : 7;  // 0x1FA(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x1FA(0x1)
	char pad_507[5];  // 0x1FB(0x5)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x200(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x230(0x8)
	struct ABP_MedicKitDestroyed_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x248(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x250(0x8)
	struct UMedicBox_OnGround_AnimBP_C* K2Node_DynamicCast_AsMedic_Box_on_Ground_Anim_BP;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x260(0x1)
	char pad_609[7];  // 0x261(0x7)
	struct UMedicBox_OnGround_AnimBP_C* K2Node_DynamicCast_AsMedic_Box_on_Ground_Anim_BP_2;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x278(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x288(0x1)
	char pad_649[7];  // 0x289(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x290(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x2A4(0x4)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x2AA(0x1)
	char pad_683[1];  // 0x2AB(0x1)
	float CallFunc_Lerp_ReturnValue;  // 0x2AC(0x4)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x2B0(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x2BC(0x88)
	int32_t K2Node_CustomEvent_Damage;  // 0x344(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x348(0xC)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x354(0x4)
	char pad_856[8];  // 0x358(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x360(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_3;  // 0x390(0x8)
	char pad_920[8];  // 0x398(0x8)
	struct FTransform Temp_struct_Variable;  // 0x3A0(0x30)
	struct UProjectileMovementComponent* CallFunc_AddComponent_ReturnValue;  // 0x3D0(0x8)
	struct ABP_Sound_C* CallFunc_FinishSpawningActor_ReturnValue_3;  // 0x3D8(0x8)
	char pad_992_1 : 7;  // 0x3E0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // 0x3E0(0x1)
	char pad_993_1 : 7;  // 0x3E1(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x3E1(0x1)
	char pad_994_1 : 7;  // 0x3E2(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x3E2(0x1)
	char pad_995[5];  // 0x3E3(0x5)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x3E8(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x3F0(0x8)
	char pad_1016_1 : 7;  // 0x3F8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x3F8(0x1)
	char pad_1017[7];  // 0x3F9(0x7)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x400(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x408(0x8)
	struct UMiscIndicator_UI_C* K2Node_DynamicCast_AsMisc_Indicator_UI;  // 0x410(0x8)
	char pad_1048_1 : 7;  // 0x418(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x418(0x1)
	char pad_1049[7];  // 0x419(0x7)
	struct AMGH_PlayerState_C* K2Node_DynamicCast_AsMGH_Player_State;  // 0x420(0x8)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x428(0x1)
	char pad_1065_1 : 7;  // 0x429(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x429(0x1)
	char pad_1066[6];  // 0x42A(0x6)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0x430(0x8)
	struct UMedicBox_OnGround_AnimBP_C* K2Node_DynamicCast_AsMedic_Box_on_Ground_Anim_BP_3;  // 0x438(0x8)
	char pad_1088_1 : 7;  // 0x440(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x440(0x1)
	char pad_1089_1 : 7;  // 0x441(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x441(0x1)
	char pad_1090[6];  // 0x442(0x6)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x448(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x450(0xC)
	char pad_1116_1 : 7;  // 0x45C(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x45C(0x1)

}; 
// Function BP_MedicKit.BP_MedicKit_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_MedicKit.BP_MedicKit_C.Server_UseMedicKit
// Size: 0x8(Inherited: 0x0) 
struct FServer_UseMedicKit
{
	struct ABP_Hunter_C* HealHunter;  // 0x0(0x8)

}; 
// Function BP_MedicKit.BP_MedicKit_C.Server_DamageMedicKit
// Size: 0x4(Inherited: 0x0) 
struct FServer_DamageMedicKit
{
	int32_t Damage;  // 0x0(0x4)

}; 
// Function BP_MedicKit.BP_MedicKit_C.OnCompleted_6E999AC445D8D96C0D5DD89B359DC8D2
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_6E999AC445D8D96C0D5DD89B359DC8D2
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MedicKit.BP_MedicKit_C.OnBlendOut_6E999AC445D8D96C0D5DD89B359DC8D2
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_6E999AC445D8D96C0D5DD89B359DC8D2
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MedicKit.BP_MedicKit_C.OnInterrupted_6E999AC445D8D96C0D5DD89B359DC8D2
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_6E999AC445D8D96C0D5DD89B359DC8D2
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MedicKit.BP_MedicKit_C.OnNotifyBegin_6E999AC445D8D96C0D5DD89B359DC8D2
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_6E999AC445D8D96C0D5DD89B359DC8D2
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MedicKit.BP_MedicKit_C.OnNotifyEnd_6E999AC445D8D96C0D5DD89B359DC8D2
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_6E999AC445D8D96C0D5DD89B359DC8D2
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_MedicKit.BP_MedicKit_C.OnRep_HealingChargesRemaining
// Size: 0x11(Inherited: 0x0) 
struct FOnRep_HealingChargesRemaining
{
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x0(0x8)
	struct UMedicBox_OnGround_AnimBP_C* K2Node_DynamicCast_AsMedic_Box_on_Ground_Anim_BP;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
