#pragma once 
#include <BP_MusicCassette_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MusicCassette.BP_MusicCassette_C
// Size: 0x248(Inherited: 0x220) 
struct ABP_MusicCassette_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UChildActorComponent* ChildActor;  // 0x228(0x8)
	struct UStaticMeshComponent* Cassette;  // 0x230(0x8)
	char MGHMusicTracks MusicAssigned;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct ABP_CassetteInteract_C* MyInteract;  // 0x240(0x8)

	void ReceiveBeginPlay(); // Function BP_MusicCassette.BP_MusicCassette_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_MusicCassette.BP_MusicCassette_C.ReceiveEndPlay
	void InteractCassette_LocalClient_Int(struct AActor* ActivatedActor); // Function BP_MusicCassette.BP_MusicCassette_C.InteractCassette_LocalClient_Int
	void InteractCassette_All_Int(); // Function BP_MusicCassette.BP_MusicCassette_C.InteractCassette_All_Int
	void ExecuteUbergraph_BP_MusicCassette(int32_t EntryPoint); // Function BP_MusicCassette.BP_MusicCassette_C.ExecuteUbergraph_BP_MusicCassette
}; 



