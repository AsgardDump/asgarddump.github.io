#pragma once 
#include <BP_HUD_MainMenu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HUD_MainMenu.BP_HUD_MainMenu_C
// Size: 0x3AC(Inherited: 0x310) 
struct ABP_HUD_MainMenu_C : public AHUD
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x318(0x8)
	float Quickfade_NewTrack_0_1C99EB6440BD3AA4E9A54C91FCC56752;  // 0x320(0x4)
	char ETimelineDirection Quickfade__Direction_1C99EB6440BD3AA4E9A54C91FCC56752;  // 0x324(0x1)
	char pad_805[3];  // 0x325(0x3)
	struct UTimelineComponent* Quickfade;  // 0x328(0x8)
	struct UWB_ProMainMenu_C* WB_ProMainMenu;  // 0x330(0x8)
	struct UMGH_GameInstance_BP_C* MyGameInstance;  // 0x338(0x8)
	int32_t MaxPartySize;  // 0x340(0x4)
	char pad_836[4];  // 0x344(0x4)
	struct TArray<struct ABP_Hunter_Render_C*> MainMenuRenderHunters;  // 0x348(0x10)
	struct UBlackBGGameStart_UI_C* BlackBG;  // 0x358(0x8)
	struct UMediaSource* DesiredToolTipVideo;  // 0x360(0x8)
	struct UMediaPlayer* ToolTipMediaPlayer;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool ToolTipTriedToPlayButCouldn't : 1;  // 0x370(0x1)
	char pad_881[7];  // 0x371(0x7)
	struct UMediaSource* CurrentlyPlayingToolTipVideo;  // 0x378(0x8)
	struct FMulticastInlineDelegate OnToolTipReady;  // 0x380(0x10)
	float ToolTipTryDuration;  // 0x390(0x4)
	char pad_916[4];  // 0x394(0x4)
	struct TArray<float> FramerateSet;  // 0x398(0x10)
	int32_t NumFramerateCheck;  // 0x3A8(0x4)

	void GetGhostPossessAbilityUI(struct TScriptInterface<IGhostPossessAbilityUI_Interface_C>& Ghost Possess Ability UI Int); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.GetGhostPossessAbilityUI
	void GetProMainMenu_Int(struct UUserWidget*& WB Pro Main Menu); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.GetProMainMenu_Int
	void ToolTipSuccessfullyPlayed(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ToolTipSuccessfullyPlayed
	void CloseToolTipVideo(struct UMediaSource* SourceToolTipVideo); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.CloseToolTipVideo
	void SetToolTipVideo(struct UMediaSource* InToolTipVideo, struct FDelegate& Event, bool& PlayedVideo); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.SetToolTipVideo
	void ApplyFPSRate(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ApplyFPSRate
	void RefreshRenderHunters(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.RefreshRenderHunters
	void StartPartyHost(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.StartPartyHost
	void CacheMouseSettings(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.CacheMouseSettings
	void ApplyDefaultGFXSettings?(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ApplyDefaultGFXSettings?
	void CreateMainMenu(struct UWB_ProMainMenu_C*& WB_ProMainMenu); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.CreateMainMenu
	void Quickfade__FinishedFunc(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.Quickfade__FinishedFunc
	void Quickfade__UpdateFunc(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.Quickfade__UpdateFunc
	void ContinueAfterConfig(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueAfterConfig
	void ContinueFromIntro(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueFromIntro
	void FadeoutWidget(struct UWidget* Widget); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.FadeoutWidget
	void FadeoutBlackBG(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.FadeoutBlackBG
	void ContinueAfterRegion(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueAfterRegion
	void ContinueFromGamma(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueFromGamma
	void ContinueAfterAgreement(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueAfterAgreement
	void ResetRegion(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ResetRegion
	void RemoveAllWidgetsExceptParty(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.RemoveAllWidgetsExceptParty
	void On Tool Tip Video Failed to Play(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.On Tool Tip Video Failed to Play
	void CreateMiscError(struct FText ErrorText); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.CreateMiscError
	void ClearCustomizeWidget_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ClearCustomizeWidget_Int
	void CreateLevelUpUI_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.CreateLevelUpUI_Int
	void Apply Screen Percentage(float Value (Out of 100)); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.Apply Screen Percentage
	void ContinueAfterRegion_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueAfterRegion_Int
	void ContinueAfterAgreement_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueAfterAgreement_Int
	void ContinueAfterConfig_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ContinueAfterConfig_Int
	void ResetGamma_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ResetGamma_Int
	void RecreateMainMenu(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.RecreateMainMenu
	void ReceiveBeginPlay(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ReceiveBeginPlay
	void SetGhostPossessAbilityUIValue_Int(bool FULL); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.SetGhostPossessAbilityUIValue_Int
	void GhostPossessAbilityCooldownSetHold_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.GhostPossessAbilityCooldownSetHold_Int
	void PlayGhosts_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.PlayGhosts_Int
	void PlayHunters_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.PlayHunters_Int
	void ClearGhostAbilityUI_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ClearGhostAbilityUI_Int
	void ClearHunterUI_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ClearHunterUI_Int
	void TutorialNextStep_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.TutorialNextStep_Int
	void CreateMiscError_Int(struct FText Text); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.CreateMiscError_Int
	void SetProjectXUI_Int(struct UUserWidget* Widget); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.SetProjectXUI_Int
	void CreateDamageLog_Int(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.CreateDamageLog_Int
	void ExecuteUbergraph_BP_HUD_MainMenu(int32_t EntryPoint); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.ExecuteUbergraph_BP_HUD_MainMenu
	void OnToolTipReady__DelegateSignature(); // Function BP_HUD_MainMenu.BP_HUD_MainMenu_C.OnToolTipReady__DelegateSignature
}; 



