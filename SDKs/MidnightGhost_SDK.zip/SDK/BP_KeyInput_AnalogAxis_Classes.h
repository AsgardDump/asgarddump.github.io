#pragma once 
#include <BP_KeyInput_AnalogAxis_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KeyInput_AnalogAxis.BP_KeyInput_AnalogAxis_C
// Size: 0x68(Inherited: 0x68) 
struct UBP_KeyInput_AnalogAxis_C : public UBP_KeyInput_C
{

	void Key Input Current State(struct APlayerController* Controller, float& Axis Value, bool& Down, bool& Just Pressed, bool& Just Released); // Function BP_KeyInput_AnalogAxis.BP_KeyInput_AnalogAxis_C.Key Input Current State
}; 



