#pragma once 
#include <BP_Ectoplasm_Spew_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ectoplasm_Spew.BP_Ectoplasm_Spew_C
// Size: 0x2C2(Inherited: 0x2C2) 
struct ABP_Ectoplasm_Spew_C : public ABP_Ectoplasm_C
{

}; 



