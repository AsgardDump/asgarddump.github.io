#pragma once 
#include "SDK.h" 
 
 
// Function BP_C4Interact.BP_C4Interact_C.IsThisMyC4?
// Size: 0xD(Inherited: 0x0) 
struct FIsThisMyC4?
{
	struct ABP_Hunter_C* Hunter;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool YES : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xC(0x1)

}; 
// Function BP_C4Interact.BP_C4Interact_C.ExecuteUbergraph_BP_C4Interact
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_C4Interact
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_Controller;  // 0x8(0x8)

}; 
// Function BP_C4Interact.BP_C4Interact_C.PickUpC4
// Size: 0x8(Inherited: 0x0) 
struct FPickUpC4
{
	struct AMGH_PlayerController_BP_C* Controller;  // 0x0(0x8)

}; 
