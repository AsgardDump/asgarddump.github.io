#pragma once 
#include <BP_SaltCircle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SaltCircle.BP_SaltCircle_C
// Size: 0x5F1(Inherited: 0x220) 
struct ABP_SaltCircle_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UCapsuleComponent* Capsule;  // 0x228(0x8)
	struct UDecalComponent* Decal56;  // 0x230(0x8)
	struct UDecalComponent* Decal55;  // 0x238(0x8)
	struct UDecalComponent* Decal54;  // 0x240(0x8)
	struct UDecalComponent* Decal52;  // 0x248(0x8)
	struct UDecalComponent* Decal51;  // 0x250(0x8)
	struct UDecalComponent* Decal50;  // 0x258(0x8)
	struct UDecalComponent* Decal49;  // 0x260(0x8)
	struct UDecalComponent* Decal48;  // 0x268(0x8)
	struct UDecalComponent* Decal47;  // 0x270(0x8)
	struct UDecalComponent* Decal46;  // 0x278(0x8)
	struct UDecalComponent* Decal45;  // 0x280(0x8)
	struct UDecalComponent* Decal44;  // 0x288(0x8)
	struct UDecalComponent* Decal43;  // 0x290(0x8)
	struct UDecalComponent* Decal42;  // 0x298(0x8)
	struct UDecalComponent* Decal53;  // 0x2A0(0x8)
	struct UBoxComponent* Box28;  // 0x2A8(0x8)
	struct UBoxComponent* Box26;  // 0x2B0(0x8)
	struct UBoxComponent* Box24;  // 0x2B8(0x8)
	struct UBoxComponent* Box30;  // 0x2C0(0x8)
	struct UBoxComponent* Box29;  // 0x2C8(0x8)
	struct UStaticMeshComponent* SaltyCircleOutline;  // 0x2D0(0x8)
	struct UBoxComponent* Box23;  // 0x2D8(0x8)
	struct UBoxComponent* Box22;  // 0x2E0(0x8)
	struct UBoxComponent* Box21;  // 0x2E8(0x8)
	struct UBoxComponent* Box20;  // 0x2F0(0x8)
	struct UBoxComponent* Box19;  // 0x2F8(0x8)
	struct UBoxComponent* Box18;  // 0x300(0x8)
	struct UBoxComponent* Box17;  // 0x308(0x8)
	struct UBoxComponent* Box16;  // 0x310(0x8)
	struct UBoxComponent* Box15;  // 0x318(0x8)
	struct UBoxComponent* Box14;  // 0x320(0x8)
	struct UBoxComponent* Box13;  // 0x328(0x8)
	struct UBoxComponent* Box12;  // 0x330(0x8)
	struct UBoxComponent* Box11;  // 0x338(0x8)
	struct UBoxComponent* Box10;  // 0x340(0x8)
	struct UBoxComponent* Box9;  // 0x348(0x8)
	struct UBoxComponent* Box8;  // 0x350(0x8)
	struct UBoxComponent* Box7;  // 0x358(0x8)
	struct UBoxComponent* Box6;  // 0x360(0x8)
	struct UBoxComponent* Box5;  // 0x368(0x8)
	struct UBoxComponent* Box4;  // 0x370(0x8)
	struct UBoxComponent* Box3;  // 0x378(0x8)
	struct UBoxComponent* Box2;  // 0x380(0x8)
	struct UBoxComponent* Box1;  // 0x388(0x8)
	struct UBoxComponent* Box;  // 0x390(0x8)
	struct UDecalComponent* Decal41;  // 0x398(0x8)
	struct UDecalComponent* Decal40;  // 0x3A0(0x8)
	struct UDecalComponent* Decal39;  // 0x3A8(0x8)
	struct UDecalComponent* Decal38;  // 0x3B0(0x8)
	struct UDecalComponent* Decal37;  // 0x3B8(0x8)
	struct UDecalComponent* Decal36;  // 0x3C0(0x8)
	struct UDecalComponent* Decal35;  // 0x3C8(0x8)
	struct UDecalComponent* Decal34;  // 0x3D0(0x8)
	struct UStaticMeshComponent* SaltyCircleOutlineBase;  // 0x3D8(0x8)
	struct UDecalComponent* Decal32;  // 0x3E0(0x8)
	struct UDecalComponent* Decal31;  // 0x3E8(0x8)
	struct UDecalComponent* Decal30;  // 0x3F0(0x8)
	struct UDecalComponent* Decal29;  // 0x3F8(0x8)
	struct UDecalComponent* Decal28;  // 0x400(0x8)
	struct UDecalComponent* Decal27;  // 0x408(0x8)
	struct UDecalComponent* Decal26;  // 0x410(0x8)
	struct UDecalComponent* Decal25;  // 0x418(0x8)
	struct UDecalComponent* Decal24;  // 0x420(0x8)
	struct UDecalComponent* Decal23;  // 0x428(0x8)
	struct UDecalComponent* Decal22;  // 0x430(0x8)
	struct UDecalComponent* Decal21;  // 0x438(0x8)
	struct UDecalComponent* Decal20;  // 0x440(0x8)
	struct UDecalComponent* Decal19;  // 0x448(0x8)
	struct UDecalComponent* Decal18;  // 0x450(0x8)
	struct UDecalComponent* Decal17;  // 0x458(0x8)
	struct UDecalComponent* Decal16;  // 0x460(0x8)
	struct UDecalComponent* Decal15;  // 0x468(0x8)
	struct UDecalComponent* Decal14;  // 0x470(0x8)
	struct UDecalComponent* Decal13;  // 0x478(0x8)
	struct UDecalComponent* Decal12;  // 0x480(0x8)
	struct UDecalComponent* Decal11;  // 0x488(0x8)
	struct UDecalComponent* Decal10;  // 0x490(0x8)
	struct UDecalComponent* Decal9;  // 0x498(0x8)
	struct UDecalComponent* Decal8;  // 0x4A0(0x8)
	struct UDecalComponent* Decal7;  // 0x4A8(0x8)
	struct UDecalComponent* Decal6;  // 0x4B0(0x8)
	struct UDecalComponent* Decal5;  // 0x4B8(0x8)
	struct UDecalComponent* Decal4;  // 0x4C0(0x8)
	struct UDecalComponent* Decal3;  // 0x4C8(0x8)
	struct UDecalComponent* Decal2;  // 0x4D0(0x8)
	struct UDecalComponent* Decal1;  // 0x4D8(0x8)
	struct UDecalComponent* Decal;  // 0x4E0(0x8)
	struct UDecalComponent* Decal33;  // 0x4E8(0x8)
	struct USceneComponent* Scene;  // 0x4F0(0x8)
	struct UAudioComponent* SaltCircle_20s_V1;  // 0x4F8(0x8)
	struct UAudioComponent* SaltCircle_loop_V1;  // 0x500(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x508(0x8)
	float Hit_HitGlow_056532254D358D4E5952C7B98B280904;  // 0x510(0x4)
	char ETimelineDirection Hit__Direction_056532254D358D4E5952C7B98B280904;  // 0x514(0x1)
	char pad_1301[3];  // 0x515(0x3)
	struct UTimelineComponent* Hit;  // 0x518(0x8)
	float FadeOut_Fadeout_EAAC33B34B080687AC8945B6B629442E;  // 0x520(0x4)
	char ETimelineDirection FadeOut__Direction_EAAC33B34B080687AC8945B6B629442E;  // 0x524(0x1)
	char pad_1317[3];  // 0x525(0x3)
	struct UTimelineComponent* FadeOut;  // 0x528(0x8)
	struct AActor* HitActor;  // 0x530(0x8)
	struct FHitResult HitResult;  // 0x538(0x88)
	struct UMaterialInstanceDynamic* SaltCircleMaterialVFX;  // 0x5C0(0x8)
	struct TArray<struct UDecalComponent*> Decals;  // 0x5C8(0x10)
	struct UMaterialInstanceDynamic* SaltMaterial;  // 0x5D8(0x8)
	struct UMaterialInstanceDynamic* SaltCircleMaterialVFX_Base;  // 0x5E0(0x8)
	struct UMGH_GameInstance_BP_C* My Game Instance;  // 0x5E8(0x8)
	char pad_1520_1 : 7;  // 0x5F0(0x1)
	bool FadeQueuedUp? : 1;  // 0x5F0(0x1)

	void SetDecalMaterials(); // Function BP_SaltCircle.BP_SaltCircle_C.SetDecalMaterials
	void FadeOut__FinishedFunc(); // Function BP_SaltCircle.BP_SaltCircle_C.FadeOut__FinishedFunc
	void FadeOut__UpdateFunc(); // Function BP_SaltCircle.BP_SaltCircle_C.FadeOut__UpdateFunc
	void Hit__FinishedFunc(); // Function BP_SaltCircle.BP_SaltCircle_C.Hit__FinishedFunc
	void Hit__UpdateFunc(); // Function BP_SaltCircle.BP_SaltCircle_C.Hit__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_SaltCircle.BP_SaltCircle_C.ReceiveBeginPlay
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void BndEvt__Box1_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box1_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
	void BndEvt__Box2_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box2_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
	void BndEvt__Box3_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box3_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature
	void BndEvt__Box4_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box4_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature
	void BndEvt__Box5_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box5_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature
	void BndEvt__Box6_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box6_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
	void BndEvt__Box7_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box7_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature
	void BndEvt__Box8_K2Node_ComponentBoundEvent_8_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box8_K2Node_ComponentBoundEvent_8_ComponentHitSignature__DelegateSignature
	void BndEvt__Box9_K2Node_ComponentBoundEvent_9_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box9_K2Node_ComponentBoundEvent_9_ComponentHitSignature__DelegateSignature
	void BndEvt__Box10_K2Node_ComponentBoundEvent_10_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box10_K2Node_ComponentBoundEvent_10_ComponentHitSignature__DelegateSignature
	void BndEvt__Box11_K2Node_ComponentBoundEvent_11_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box11_K2Node_ComponentBoundEvent_11_ComponentHitSignature__DelegateSignature
	void BndEvt__Box12_K2Node_ComponentBoundEvent_12_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box12_K2Node_ComponentBoundEvent_12_ComponentHitSignature__DelegateSignature
	void BndEvt__Box13_K2Node_ComponentBoundEvent_13_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box13_K2Node_ComponentBoundEvent_13_ComponentHitSignature__DelegateSignature
	void BndEvt__Box14_K2Node_ComponentBoundEvent_14_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box14_K2Node_ComponentBoundEvent_14_ComponentHitSignature__DelegateSignature
	void BndEvt__Box15_K2Node_ComponentBoundEvent_15_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box15_K2Node_ComponentBoundEvent_15_ComponentHitSignature__DelegateSignature
	void Server_QueueUpFade(struct ABP_SaltCircle_C* Salt Circle); // Function BP_SaltCircle.BP_SaltCircle_C.Server_QueueUpFade
	void MC_QueueUpFade(struct ABP_SaltCircle_C* Salt Circle); // Function BP_SaltCircle.BP_SaltCircle_C.MC_QueueUpFade
	void Server_SpawnHitVFX(struct FVector Location); // Function BP_SaltCircle.BP_SaltCircle_C.Server_SpawnHitVFX
	void Server_HitMaterialVFX(struct ABP_SaltCircle_C* Salt Circle); // Function BP_SaltCircle.BP_SaltCircle_C.Server_HitMaterialVFX
	void MC_HitMaterialVFX(struct ABP_SaltCircle_C* Salt Circle); // Function BP_SaltCircle.BP_SaltCircle_C.MC_HitMaterialVFX
	void BndEvt__Box16_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box16_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void BndEvt__Box17_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box17_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
	void BndEvt__Box18_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box18_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
	void BndEvt__Box19_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box19_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature
	void BndEvt__Box20_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box20_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature
	void BndEvt__Box21_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box21_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature
	void BndEvt__Box22_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box22_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
	void BndEvt__Box23_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box23_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature
	void BndEvt__Box24_K2Node_ComponentBoundEvent_16_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box24_K2Node_ComponentBoundEvent_16_ComponentHitSignature__DelegateSignature
	void BndEvt__Box25_K2Node_ComponentBoundEvent_17_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box25_K2Node_ComponentBoundEvent_17_ComponentHitSignature__DelegateSignature
	void BndEvt__Box26_K2Node_ComponentBoundEvent_18_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box26_K2Node_ComponentBoundEvent_18_ComponentHitSignature__DelegateSignature
	void BndEvt__Box27_K2Node_ComponentBoundEvent_19_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box27_K2Node_ComponentBoundEvent_19_ComponentHitSignature__DelegateSignature
	void BndEvt__Box29_K2Node_ComponentBoundEvent_20_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box29_K2Node_ComponentBoundEvent_20_ComponentHitSignature__DelegateSignature
	void BndEvt__Box30_K2Node_ComponentBoundEvent_21_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box30_K2Node_ComponentBoundEvent_21_ComponentHitSignature__DelegateSignature
	void BndEvt__Box28_K2Node_ComponentBoundEvent_22_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box28_K2Node_ComponentBoundEvent_22_ComponentHitSignature__DelegateSignature
	void BndEvt__BP_SaltCircle_Capsule_K2Node_ComponentBoundEvent_23_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__BP_SaltCircle_Capsule_K2Node_ComponentBoundEvent_23_ComponentHitSignature__DelegateSignature
	void ExecuteUbergraph_BP_SaltCircle(int32_t EntryPoint); // Function BP_SaltCircle.BP_SaltCircle_C.ExecuteUbergraph_BP_SaltCircle
}; 



