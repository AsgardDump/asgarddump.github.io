#pragma once 
#include "SDK.h" 
 
 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappings_KeyboardMouse
// Size: 0xA0(Inherited: 0x0) 
struct FSaveAxisMappings_KeyboardMouse
{
	struct TMap<struct FName, struct FKey> Map;  // 0x0(0x50)
	struct UObject* __WorldContext;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USG_InputDefaults_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x98(0x8)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadTextureQuality
// Size: 0x32(Inherited: 0x0) 
struct FLoadTextureQuality
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t TextureQuality;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveActionMappings_Gamepad
// Size: 0xA0(Inherited: 0x0) 
struct FSaveActionMappings_Gamepad
{
	struct TMap<struct FName, struct FKey> Map;  // 0x0(0x50)
	struct UObject* __WorldContext;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USG_InputDefaults_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x98(0x8)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesInputDefaultsExist
// Size: 0x21(Inherited: 0x0) 
struct FDoesInputDefaultsExist
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString InputDefaults;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity01
// Size: 0x32(Inherited: 0x0) 
struct FLoad_Sensitivity01
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Sensitivity;  // 0xC(0x4)
	struct FString ControlSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappingScales_KeyboardMouse
// Size: 0x51(Inherited: 0x0) 
struct FLoadAxisMappingScales_KeyboardMouse
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<float> AxisMappingScales_KeyboardMouse;  // 0x10(0x10)
	struct USaveGame* SaveObject;  // 0x20(0x8)
	struct FString InputDefaults;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappings_Gamepad
// Size: 0xA0(Inherited: 0x0) 
struct FSaveAxisMappings_Gamepad
{
	struct TMap<struct FName, struct FKey> Map;  // 0x0(0x50)
	struct UObject* __WorldContext;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USG_InputDefaults_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x98(0x8)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveViewDistance
// Size: 0x59(Inherited: 0x0) 
struct FSaveViewDistance
{
	int32_t ViewDistanceQuality;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Subtitles
// Size: 0x59(Inherited: 0x0) 
struct FSave_Subtitles
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSubtitles : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString AudioSettings;  // 0x20(0x10)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_AudioSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveActionMappings_KeyboardMouse
// Size: 0xA0(Inherited: 0x0) 
struct FSaveActionMappings_KeyboardMouse
{
	struct TMap<struct FName, struct FKey> Map;  // 0x0(0x50)
	struct UObject* __WorldContext;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USG_InputDefaults_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x98(0x8)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadResolutionScale
// Size: 0x32(Inherited: 0x0) 
struct FLoadResolutionScale
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ResolutionScale;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadActionMappings_KeyboardMouse
// Size: 0x91(Inherited: 0x0) 
struct FLoadActionMappings_KeyboardMouse
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TMap<struct FName, struct FKey> ActionMappings_KeyboardMouse;  // 0x10(0x50)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_MusicOn
// Size: 0x32(Inherited: 0x0) 
struct FLoad_MusicOn
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bMusic : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString AudioSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SavePostProcessQuality
// Size: 0x59(Inherited: 0x0) 
struct FSavePostProcessQuality
{
	int32_t PostProcessQuality;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadActionMappings_Gamepad
// Size: 0x91(Inherited: 0x0) 
struct FLoadActionMappings_Gamepad
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TMap<struct FName, struct FKey> ActionMappings_Gamepad;  // 0x10(0x50)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappings_KeyboardMouse
// Size: 0x91(Inherited: 0x0) 
struct FLoadAxisMappings_KeyboardMouse
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TMap<struct FName, struct FKey> AxisMappings_KeyboardMouse;  // 0x10(0x50)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAAQuality
// Size: 0x59(Inherited: 0x0) 
struct FSaveAAQuality
{
	int32_t AAQuality;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappings_Gamepad
// Size: 0x91(Inherited: 0x0) 
struct FLoadAxisMappings_Gamepad
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TMap<struct FName, struct FKey> AxisMappings_Gamepad;  // 0x10(0x50)
	struct USaveGame* SaveObject;  // 0x60(0x8)
	struct FString InputDefaults;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x80(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x90(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadFoliageQuality
// Size: 0x32(Inherited: 0x0) 
struct FLoadFoliageQuality
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t FoliageQuality;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappingScales_KeyboardMouse
// Size: 0x60(Inherited: 0x0) 
struct FSaveAxisMappingScales_KeyboardMouse
{
	struct TArray<float> ScaleValues;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct USaveGame* SaveObject;  // 0x20(0x8)
	struct FString InputDefaults;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USG_InputDefaults_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x40(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x58(0x8)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity02
// Size: 0x59(Inherited: 0x0) 
struct FSave_Sensitivity02
{
	float Sensitivity;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString ControlSettings;  // 0x20(0x10)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_ControlSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappingScales_Gamepad
// Size: 0x60(Inherited: 0x0) 
struct FSaveAxisMappingScales_Gamepad
{
	struct TArray<float> Scales;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct USaveGame* SaveObject;  // 0x20(0x8)
	struct FString InputDefaults;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USG_InputDefaults_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x40(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x58(0x8)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.DeleteVideoSettingsSave
// Size: 0x22(Inherited: 0x0) 
struct FDeleteVideoSettingsSave
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString VideoSettings;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DeleteGameInSlot_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappingScales_Gamepad
// Size: 0x51(Inherited: 0x0) 
struct FLoadAxisMappingScales_Gamepad
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<float> AxisMappingScales_Gamepad;  // 0x10(0x10)
	struct USaveGame* SaveObject;  // 0x20(0x8)
	struct FString InputDefaults;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_DoesInputDefaultsExist_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	struct USG_InputDefaults_C* K2Node_DynamicCast_AsSG_Input_Defaults;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadWindowMode
// Size: 0x32(Inherited: 0x0) 
struct FLoadWindowMode
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char EWindowMode WindowMode;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadVisualEffectsQuality
// Size: 0x32(Inherited: 0x0) 
struct FLoadVisualEffectsQuality
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t VisualEffectsQuality;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveScreenResolution
// Size: 0x59(Inherited: 0x0) 
struct FSaveScreenResolution
{
	struct FIntPoint ScreenResolution;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_DialogueVolume
// Size: 0x32(Inherited: 0x0) 
struct FLoad_DialogueVolume
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float DialogueVolume;  // 0xC(0x4)
	struct FString AudioSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesVideoSettingsSaveExist
// Size: 0x21(Inherited: 0x0) 
struct FDoesVideoSettingsSaveExist
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString VideoSettings;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveWindowMode
// Size: 0x59(Inherited: 0x0) 
struct FSaveWindowMode
{
	char EWindowMode WindowMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadScreenResolution
// Size: 0x3A(Inherited: 0x0) 
struct FLoadScreenResolution
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FIntPoint ScreenResolution;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct FString VideoSettings;  // 0x18(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x28(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x39(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_MusicVolume
// Size: 0x32(Inherited: 0x0) 
struct FLoad_MusicVolume
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float MusicVolume;  // 0xC(0x4)
	struct FString AudioSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAndApplyGraphicSettings
// Size: 0x58(Inherited: 0x0) 
struct FLoadAndApplyGraphicSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool SetDefaultValues : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUseBenchmarkTest : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool BenchmarkTest : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DeleteVideoSettingsSave_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_LoadWindowMode_ReturnValue : 1;  // 0x21(0x1)
	char EWindowMode CallFunc_LoadWindowMode_WindowMode;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_LoadScreenResolution_ReturnValue : 1;  // 0x23(0x1)
	struct FIntPoint CallFunc_LoadScreenResolution_ScreenResolution;  // 0x24(0x8)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_DoesVideoSettingsSaveExist_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue_2;  // 0x30(0x8)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue_3;  // 0x38(0x8)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue_4;  // 0x40(0x8)
	struct FIntPoint CallFunc_GetDesktopResolution_ReturnValue;  // 0x48(0x8)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue_5;  // 0x50(0x8)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveResolutionScale
// Size: 0x59(Inherited: 0x0) 
struct FSaveResolutionScale
{
	float ResolutionScale;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveDynamicResolution
// Size: 0x59(Inherited: 0x0) 
struct FSaveDynamicResolution
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool DynamicResolution : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadDynamicResolution
// Size: 0x32(Inherited: 0x0) 
struct FLoadDynamicResolution
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool DynamicResolution : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_MasterVolume
// Size: 0x32(Inherited: 0x0) 
struct FLoad_MasterVolume
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float MasterVolume;  // 0xC(0x4)
	struct FString AudioSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveFrameRateLimit
// Size: 0x59(Inherited: 0x0) 
struct FSaveFrameRateLimit
{
	float FrameRateLimit;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_SoundEffectsVolume
// Size: 0x32(Inherited: 0x0) 
struct FLoad_SoundEffectsVolume
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float SoundEffectsVolume;  // 0xC(0x4)
	struct FString AudioSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadFrameRateLimit
// Size: 0x32(Inherited: 0x0) 
struct FLoadFrameRateLimit
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float FrameRateLimit;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveVsync
// Size: 0x59(Inherited: 0x0) 
struct FSaveVsync
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool VerticalSync : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadVsync
// Size: 0x32(Inherited: 0x0) 
struct FLoadVsync
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool VerticalSync : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAAQuality
// Size: 0x32(Inherited: 0x0) 
struct FLoadAAQuality
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t AAQuality;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveTextureQuality
// Size: 0x59(Inherited: 0x0) 
struct FSaveTextureQuality
{
	int32_t TextureQuality;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_MasterVolume
// Size: 0x59(Inherited: 0x0) 
struct FSave_MasterVolume
{
	float MasterVolume;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString AudioSettings;  // 0x20(0x10)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_AudioSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveShadowQuality
// Size: 0x59(Inherited: 0x0) 
struct FSaveShadowQuality
{
	int32_t ShadowQuality;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadShadowQuality
// Size: 0x32(Inherited: 0x0) 
struct FLoadShadowQuality
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t ShadowQuality;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveVisualEffectsQuality
// Size: 0x59(Inherited: 0x0) 
struct FSaveVisualEffectsQuality
{
	int32_t VisualEffectsQuality;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveFoliageQuality
// Size: 0x59(Inherited: 0x0) 
struct FSaveFoliageQuality
{
	int32_t FoliageQuality;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString VideoSettings;  // 0x20(0x10)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_VideoSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity01
// Size: 0x59(Inherited: 0x0) 
struct FSave_Sensitivity01
{
	float Sensitivity;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString ControlSettings;  // 0x20(0x10)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_ControlSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadViewDistance
// Size: 0x32(Inherited: 0x0) 
struct FLoadViewDistance
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t ViewDistanceQuality;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadPostProcessQuality
// Size: 0x32(Inherited: 0x0) 
struct FLoadPostProcessQuality
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t PostProcessQuality;  // 0xC(0x4)
	struct FString VideoSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_VideoSettings_C* K2Node_DynamicCast_AsSG_Video_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_OutputProfile
// Size: 0x59(Inherited: 0x0) 
struct FSave_OutputProfile
{
	int32_t OutputProfile;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString AudioSettings;  // 0x20(0x10)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_AudioSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_MusicVolume
// Size: 0x59(Inherited: 0x0) 
struct FSave_MusicVolume
{
	float MusicVolume;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString AudioSettings;  // 0x20(0x10)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_AudioSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_DialogueVolume
// Size: 0x59(Inherited: 0x0) 
struct FSave_DialogueVolume
{
	float DialogueVolume;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString AudioSettings;  // 0x20(0x10)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_AudioSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_OutputProfile
// Size: 0x32(Inherited: 0x0) 
struct FLoad_OutputProfile
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t OutputProfile;  // 0xC(0x4)
	struct FString AudioSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_SoundEffectsVolume
// Size: 0x59(Inherited: 0x0) 
struct FSave_SoundEffectsVolume
{
	float SoundEffectsVolume;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString AudioSettings;  // 0x20(0x10)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_AudioSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_MusicOn
// Size: 0x59(Inherited: 0x0) 
struct FSave_MusicOn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bMusic : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString AudioSettings;  // 0x20(0x10)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_AudioSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.DeleteControlSettingsSave
// Size: 0x22(Inherited: 0x0) 
struct FDeleteControlSettingsSave
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString ControlSettings;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DeleteGameInSlot_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Subtitles
// Size: 0x32(Inherited: 0x0) 
struct FLoad_Subtitles
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bSubtitles : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString AudioSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_AudioSettings_C* K2Node_DynamicCast_AsSG_Audio_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.FindVolume
// Size: 0x20(Inherited: 0x0) 
struct FFindVolume
{
	float Volume;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	float ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	float Temp_float_Variable;  // 0x18(0x4)
	float K2Node_Select_Default;  // 0x1C(0x4)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.DeleteAudioSettingsSave
// Size: 0x22(Inherited: 0x0) 
struct FDeleteAudioSettingsSave
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString AudioSettings;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DeleteGameInSlot_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesAudioSettingsSaveExist
// Size: 0x21(Inherited: 0x0) 
struct FDoesAudioSettingsSaveExist
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString AudioSettings;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesControlSettingsSaveExist
// Size: 0x21(Inherited: 0x0) 
struct FDoesControlSettingsSaveExist
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString ControlSettings;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity02
// Size: 0x32(Inherited: 0x0) 
struct FLoad_Sensitivity02
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Sensitivity;  // 0xC(0x4)
	struct FString ControlSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity03
// Size: 0x59(Inherited: 0x0) 
struct FSave_Sensitivity03
{
	float Sensitivity;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString ControlSettings;  // 0x20(0x10)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_ControlSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity03
// Size: 0x32(Inherited: 0x0) 
struct FLoad_Sensitivity03
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Sensitivity;  // 0xC(0x4)
	struct FString ControlSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity04
// Size: 0x59(Inherited: 0x0) 
struct FSave_Sensitivity04
{
	float Sensitivity;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString ControlSettings;  // 0x20(0x10)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_ControlSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity04
// Size: 0x32(Inherited: 0x0) 
struct FLoad_Sensitivity04
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Sensitivity;  // 0xC(0x4)
	struct FString ControlSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Invert_X
// Size: 0x59(Inherited: 0x0) 
struct FSave_Invert_X
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InvertX : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString ControlSettings;  // 0x20(0x10)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_ControlSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Invert_X
// Size: 0x32(Inherited: 0x0) 
struct FLoad_Invert_X
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Invert_X : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString ControlSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Invert_Y
// Size: 0x59(Inherited: 0x0) 
struct FSave_Invert_Y
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InvertY : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* Object;  // 0x18(0x8)
	struct FString ControlSettings;  // 0x20(0x10)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct USG_ControlSettings_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Invert_Y
// Size: 0x32(Inherited: 0x0) 
struct FLoad_Invert_Y
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Invert_Y : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString ControlSettings;  // 0x10(0x10)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x20(0x8)
	struct USG_ControlSettings_C* K2Node_DynamicCast_AsSG_Control_Settings;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAndApplyControlSettings
// Size: 0x18(Inherited: 0x0) 
struct FLoadAndApplyControlSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool SetDefaultValues : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Save_Sensitivity01_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Save_Sensitivity02_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_Save_Sensitivity03_ReturnValue : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_Save_Sensitivity04_ReturnValue : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Save_Invert_X_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_Save_Invert_Y_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_DeleteControlSettingsSave_ReturnValue : 1;  // 0x16(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool CallFunc_DoesControlSettingsSaveExist_ReturnValue : 1;  // 0x17(0x1)

}; 
