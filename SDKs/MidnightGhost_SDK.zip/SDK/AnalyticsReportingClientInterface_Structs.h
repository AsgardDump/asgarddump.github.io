#pragma once 
#include "SDK.h" 
 
 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Map Changed
// Size: 0x11(Inherited: 0x0) 
struct FReport Map Changed
{
	struct FString Map;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Tutorial Completed
// Size: 0x3(Inherited: 0x0) 
struct FReport Tutorial Completed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Ghost F, Hunters T : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Completed : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Result : 1;  // 0x2(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Match ID Changed
// Size: 0x11(Inherited: 0x0) 
struct FReport Match ID Changed
{
	struct FString Match ID;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Tutorial Step Advanced
// Size: 0x6(Inherited: 0x0) 
struct FReport Tutorial Step Advanced
{
	int32_t Step;  // 0x0(0x4)
	char Team Team;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Result : 1;  // 0x5(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Leave Lobby
// Size: 0x1(Inherited: 0x0) 
struct FReport Leave Lobby
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Login
// Size: 0x1(Inherited: 0x0) 
struct FReport Player Login
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Gameplay Round Ended
// Size: 0x39(Inherited: 0x0) 
struct FReport Gameplay Round Ended
{
	struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State;  // 0x0(0x10)
	char GameVictoryType Victory Type;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Winning Team GUID;  // 0x18(0x10)
	struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>> All Player States;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Result : 1;  // 0x38(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Match Ended
// Size: 0x1(Inherited: 0x0) 
struct FReport Match Ended
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Region Changed
// Size: 0x2(Inherited: 0x0) 
struct FReport Region Changed
{
	char MGH_Regions region;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Result : 1;  // 0x1(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Level Up
// Size: 0x5(Inherited: 0x0) 
struct FReport Player Level Up
{
	int32_t New Level;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Result : 1;  // 0x4(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Match Started
// Size: 0x21(Inherited: 0x0) 
struct FReport Match Started
{
	struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State;  // 0x0(0x10)
	struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>> All Player States;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Party Status Changed
// Size: 0x9(Inherited: 0x0) 
struct FReport Party Status Changed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Party Status : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Party Size;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Result : 1;  // 0x8(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Team Changed
// Size: 0x2(Inherited: 0x0) 
struct FReport Player Team Changed
{
	char Team Team;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Result : 1;  // 0x1(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Stats Loaded
// Size: 0x5(Inherited: 0x0) 
struct FReport Player Stats Loaded
{
	int32_t Player Level;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Result : 1;  // 0x4(0x1)

}; 
// Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.On Gameplay Timer Tick
// Size: 0x4(Inherited: 0x0) 
struct FOn Gameplay Timer Tick
{
	float DeltaTime;  // 0x0(0x4)

}; 
