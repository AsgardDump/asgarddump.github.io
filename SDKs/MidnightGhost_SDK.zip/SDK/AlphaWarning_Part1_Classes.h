#pragma once 
#include <AlphaWarning_Part1_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AlphaWarning_Part1.AlphaWarning_Part1_C
// Size: 0x260(Inherited: 0x260) 
struct UAlphaWarning_Part1_C : public UUserWidget
{

}; 



