#pragma once 
#include <BP_MedicKitDestroyed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MedicKitDestroyed.BP_MedicKitDestroyed_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_MedicKitDestroyed_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDestructibleComponent* OpenMedicKitMesh_DM;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void ReceiveBeginPlay(); // Function BP_MedicKitDestroyed.BP_MedicKitDestroyed_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_MedicKitDestroyed(int32_t EntryPoint); // Function BP_MedicKitDestroyed.BP_MedicKitDestroyed_C.ExecuteUbergraph_BP_MedicKitDestroyed
}; 



