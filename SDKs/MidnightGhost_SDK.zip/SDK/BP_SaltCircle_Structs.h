#pragma once 
#include "SDK.h" 
 
 
// Function BP_SaltCircle.BP_SaltCircle_C.ExecuteUbergraph_BP_SaltCircle
// Size: 0x17D8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SaltCircle
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x18(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x20(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x2C(0x88)
	int32_t Temp_int_Array_Index_Variable;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0xBA(0x1)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0xBB(0x1)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_32;  // 0xC0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_32;  // 0xC8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_32;  // 0xD0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_32;  // 0xD8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_32;  // 0xE4(0x88)
	char pad_364[4];  // 0x16C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_31;  // 0x170(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_31;  // 0x178(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_31;  // 0x180(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_31;  // 0x188(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_31;  // 0x194(0x88)
	char pad_540[4];  // 0x21C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_30;  // 0x220(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_30;  // 0x228(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_30;  // 0x230(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_30;  // 0x238(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_30;  // 0x244(0x88)
	char pad_716[4];  // 0x2CC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_29;  // 0x2D0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_29;  // 0x2D8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_29;  // 0x2E0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_29;  // 0x2E8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_29;  // 0x2F4(0x88)
	char pad_892[4];  // 0x37C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_28;  // 0x380(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_28;  // 0x388(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_28;  // 0x390(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_28;  // 0x398(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_28;  // 0x3A4(0x88)
	char pad_1068[4];  // 0x42C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_27;  // 0x430(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_27;  // 0x438(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_27;  // 0x440(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_27;  // 0x448(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_27;  // 0x454(0x88)
	char pad_1244[4];  // 0x4DC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_26;  // 0x4E0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_26;  // 0x4E8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_26;  // 0x4F0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_26;  // 0x4F8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_26;  // 0x504(0x88)
	char pad_1420[4];  // 0x58C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_25;  // 0x590(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_25;  // 0x598(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_25;  // 0x5A0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_25;  // 0x5A8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_25;  // 0x5B4(0x88)
	char pad_1596[4];  // 0x63C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_24;  // 0x640(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_24;  // 0x648(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_24;  // 0x650(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_24;  // 0x658(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_24;  // 0x664(0x88)
	char pad_1772[4];  // 0x6EC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_23;  // 0x6F0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_23;  // 0x6F8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_23;  // 0x700(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_23;  // 0x708(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_23;  // 0x714(0x88)
	char pad_1948[4];  // 0x79C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_22;  // 0x7A0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_22;  // 0x7A8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_22;  // 0x7B0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_22;  // 0x7B8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_22;  // 0x7C4(0x88)
	char pad_2124[4];  // 0x84C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_21;  // 0x850(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_21;  // 0x858(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_21;  // 0x860(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_21;  // 0x868(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_21;  // 0x874(0x88)
	char pad_2300[4];  // 0x8FC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_20;  // 0x900(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_20;  // 0x908(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_20;  // 0x910(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_20;  // 0x918(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_20;  // 0x924(0x88)
	char pad_2476[4];  // 0x9AC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_19;  // 0x9B0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_19;  // 0x9B8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_19;  // 0x9C0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_19;  // 0x9C8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_19;  // 0x9D4(0x88)
	char pad_2652[4];  // 0xA5C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_18;  // 0xA60(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_18;  // 0xA68(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_18;  // 0xA70(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_18;  // 0xA78(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_18;  // 0xA84(0x88)
	char pad_2828[4];  // 0xB0C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_17;  // 0xB10(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_17;  // 0xB18(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_17;  // 0xB20(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_17;  // 0xB28(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_17;  // 0xB34(0x88)
	char pad_3004_1 : 7;  // 0xBBC(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0xBBC(0x1)
	char pad_3005[3];  // 0xBBD(0x3)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0xBC0(0x8)
	char pad_3016_1 : 7;  // 0xBC8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xBC8(0x1)
	char pad_3017[3];  // 0xBC9(0x3)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0xBCC(0xC)
	float CallFunc_BreakVector_X;  // 0xBD8(0x4)
	float CallFunc_BreakVector_Y;  // 0xBDC(0x4)
	float CallFunc_BreakVector_Z;  // 0xBE0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xBE4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xBE8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xBEC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xBF0(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xBFC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0xC08(0xC)
	char pad_3092[4];  // 0xC14(0x4)
	struct ABP_SaltCircle_C* K2Node_CustomEvent_Salt_Circle_4;  // 0xC18(0x8)
	struct ABP_SaltCircle_C* K2Node_CustomEvent_Salt_Circle_3;  // 0xC20(0x8)
	struct FVector K2Node_CustomEvent_Location;  // 0xC28(0xC)
	char pad_3124[12];  // 0xC34(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xC40(0x30)
	char pad_3184_1 : 7;  // 0xC70(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xC70(0x1)
	char pad_3185_1 : 7;  // 0xC71(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xC71(0x1)
	char pad_3186[2];  // 0xC72(0x2)
	float CallFunc_BreakHitResult_Time;  // 0xC74(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xC78(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xC7C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xC88(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xC94(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xCA0(0xC)
	char pad_3244[4];  // 0xCAC(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xCB0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xCB8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0xCC0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0xCC8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0xCD0(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0xCD4(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xCD8(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0xCDC(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0xCE8(0xC)
	char pad_3316[4];  // 0xCF4(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xCF8(0x8)
	struct AFirelight_HitSalt_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xD00(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0xD08(0x8)
	struct ABP_SaltCircle_C* K2Node_CustomEvent_Salt_Circle_2;  // 0xD10(0x8)
	struct ABP_SaltCircle_C* K2Node_CustomEvent_Salt_Circle;  // 0xD18(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_16;  // 0xD20(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_16;  // 0xD28(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_16;  // 0xD30(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_16;  // 0xD38(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_16;  // 0xD44(0x88)
	char pad_3532[4];  // 0xDCC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_15;  // 0xDD0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_15;  // 0xDD8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_15;  // 0xDE0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_15;  // 0xDE8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_15;  // 0xDF4(0x88)
	char pad_3708[4];  // 0xE7C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_14;  // 0xE80(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_14;  // 0xE88(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_14;  // 0xE90(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_14;  // 0xE98(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_14;  // 0xEA4(0x88)
	char pad_3884[4];  // 0xF2C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_13;  // 0xF30(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_13;  // 0xF38(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_13;  // 0xF40(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_13;  // 0xF48(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_13;  // 0xF54(0x88)
	char pad_4060[4];  // 0xFDC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_12;  // 0xFE0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_12;  // 0xFE8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_12;  // 0xFF0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_12;  // 0xFF8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_12;  // 0x1004(0x88)
	char pad_4236[4];  // 0x108C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_11;  // 0x1090(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_11;  // 0x1098(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_11;  // 0x10A0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_11;  // 0x10A8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_11;  // 0x10B4(0x88)
	char pad_4412[4];  // 0x113C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_10;  // 0x1140(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_10;  // 0x1148(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_10;  // 0x1150(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_10;  // 0x1158(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_10;  // 0x1164(0x88)
	char pad_4588[4];  // 0x11EC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_9;  // 0x11F0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_9;  // 0x11F8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_9;  // 0x1200(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_9;  // 0x1208(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_9;  // 0x1214(0x88)
	char pad_4764[4];  // 0x129C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x12A0(0x8)
	struct UDecalComponent* CallFunc_Array_Get_Item;  // 0x12A8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x12B0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x12B4(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_3;  // 0x12B8(0x8)
	char pad_4800_1 : 7;  // 0x12C0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x12C0(0x1)
	char pad_4801[3];  // 0x12C1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x12C4(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x12C8(0x8)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP;  // 0x12D0(0x8)
	char pad_4824_1 : 7;  // 0x12D8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x12D8(0x1)
	char pad_4825_1 : 7;  // 0x12D9(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x12D9(0x1)
	char pad_4826[6];  // 0x12DA(0x6)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x12E0(0x8)
	struct AMGH_GameMode_C* K2Node_DynamicCast_AsMGH_Game_Mode;  // 0x12E8(0x8)
	char pad_4848_1 : 7;  // 0x12F0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x12F0(0x1)
	char pad_4849[7];  // 0x12F1(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_8;  // 0x12F8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_8;  // 0x1300(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_8;  // 0x1308(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_8;  // 0x1310(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_8;  // 0x131C(0x88)
	char pad_5028_1 : 7;  // 0x13A4(0x1)
	bool CallFunc_Get_Match_Info_Server_Waiting_for_Players_ : 1;  // 0x13A4(0x1)
	char pad_5029_1 : 7;  // 0x13A5(0x1)
	bool CallFunc_Get_Match_Info_Server_In_Countdown_Mode_ : 1;  // 0x13A5(0x1)
	char pad_5030_1 : 7;  // 0x13A6(0x1)
	bool CallFunc_Get_Match_Info_Server_Match_Started_ : 1;  // 0x13A6(0x1)
	char pad_5031_1 : 7;  // 0x13A7(0x1)
	bool CallFunc_Get_Match_Info_Server_Game_Over_ : 1;  // 0x13A7(0x1)
	char pad_5032_1 : 7;  // 0x13A8(0x1)
	bool CallFunc_Get_Match_Info_Server_Is_It_Midnight_ : 1;  // 0x13A8(0x1)
	char pad_5033[3];  // 0x13A9(0x3)
	int32_t CallFunc_Get_Match_Info_Server_Time_Remaining;  // 0x13AC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_7;  // 0x13B0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_7;  // 0x13B8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_7;  // 0x13C0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_7;  // 0x13C8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_7;  // 0x13D4(0x88)
	char pad_5212[4];  // 0x145C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_6;  // 0x1460(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_6;  // 0x1468(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_6;  // 0x1470(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_6;  // 0x1478(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_6;  // 0x1484(0x88)
	char pad_5388[4];  // 0x150C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_5;  // 0x1510(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_5;  // 0x1518(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_5;  // 0x1520(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_5;  // 0x1528(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_5;  // 0x1534(0x88)
	char pad_5564[4];  // 0x15BC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_4;  // 0x15C0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_4;  // 0x15C8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_4;  // 0x15D0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_4;  // 0x15D8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_4;  // 0x15E4(0x88)
	char pad_5740[4];  // 0x166C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_3;  // 0x1670(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_3;  // 0x1678(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_3;  // 0x1680(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_3;  // 0x1688(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_3;  // 0x1694(0x88)
	char pad_5916[4];  // 0x171C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_2;  // 0x1720(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x1728(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x1730(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_2;  // 0x1738(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_2;  // 0x1744(0x88)
	char pad_6092[4];  // 0x17CC(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x17D0(0x8)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box26_K2Node_ComponentBoundEvent_18_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box26_K2Node_ComponentBoundEvent_18_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box25_K2Node_ComponentBoundEvent_17_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box25_K2Node_ComponentBoundEvent_17_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box27_K2Node_ComponentBoundEvent_19_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box27_K2Node_ComponentBoundEvent_19_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box24_K2Node_ComponentBoundEvent_16_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box24_K2Node_ComponentBoundEvent_16_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__BP_SaltCircle_Capsule_K2Node_ComponentBoundEvent_23_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__BP_SaltCircle_Capsule_K2Node_ComponentBoundEvent_23_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box30_K2Node_ComponentBoundEvent_21_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box30_K2Node_ComponentBoundEvent_21_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box28_K2Node_ComponentBoundEvent_22_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box28_K2Node_ComponentBoundEvent_22_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box29_K2Node_ComponentBoundEvent_20_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box29_K2Node_ComponentBoundEvent_20_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box23_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box23_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box22_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box22_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box12_K2Node_ComponentBoundEvent_12_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box12_K2Node_ComponentBoundEvent_12_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box21_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box21_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.SetDecalMaterials
// Size: 0xE4(Inherited: 0x0) 
struct FSetDecalMaterials
{
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x4(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0x8(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_4;  // 0xC(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_5;  // 0x10(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_6;  // 0x14(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_7;  // 0x18(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_8;  // 0x1C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_9;  // 0x20(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_10;  // 0x24(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_11;  // 0x28(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_12;  // 0x2C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_13;  // 0x30(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_14;  // 0x34(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_15;  // 0x38(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_16;  // 0x3C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_17;  // 0x40(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_18;  // 0x44(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_19;  // 0x48(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_20;  // 0x4C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_21;  // 0x50(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_22;  // 0x54(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_23;  // 0x58(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_24;  // 0x5C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_25;  // 0x60(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_26;  // 0x64(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_27;  // 0x68(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_28;  // 0x6C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_29;  // 0x70(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_30;  // 0x74(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_31;  // 0x78(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_32;  // 0x7C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_33;  // 0x80(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_34;  // 0x84(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_35;  // 0x88(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_36;  // 0x8C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_37;  // 0x90(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_38;  // 0x94(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_39;  // 0x98(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_40;  // 0x9C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_41;  // 0xA0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_42;  // 0xA4(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_43;  // 0xA8(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_44;  // 0xAC(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_45;  // 0xB0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_46;  // 0xB4(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_47;  // 0xB8(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_48;  // 0xBC(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_49;  // 0xC0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_50;  // 0xC4(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_51;  // 0xC8(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_52;  // 0xCC(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_53;  // 0xD0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_54;  // 0xD4(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_55;  // 0xD8(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_56;  // 0xDC(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_57;  // 0xE0(0x4)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box20_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box20_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box17_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box17_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box19_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box19_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box18_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box18_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box16_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box16_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.MC_HitMaterialVFX
// Size: 0x8(Inherited: 0x0) 
struct FMC_HitMaterialVFX
{
	struct ABP_SaltCircle_C* Salt Circle;  // 0x0(0x8)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.Server_HitMaterialVFX
// Size: 0x8(Inherited: 0x0) 
struct FServer_HitMaterialVFX
{
	struct ABP_SaltCircle_C* Salt Circle;  // 0x0(0x8)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.Server_SpawnHitVFX
// Size: 0xC(Inherited: 0x0) 
struct FServer_SpawnHitVFX
{
	struct FVector Location;  // 0x0(0xC)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.MC_QueueUpFade
// Size: 0x8(Inherited: 0x0) 
struct FMC_QueueUpFade
{
	struct ABP_SaltCircle_C* Salt Circle;  // 0x0(0x8)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.Server_QueueUpFade
// Size: 0x8(Inherited: 0x0) 
struct FServer_QueueUpFade
{
	struct ABP_SaltCircle_C* Salt Circle;  // 0x0(0x8)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box5_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box5_K2Node_ComponentBoundEvent_5_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box9_K2Node_ComponentBoundEvent_9_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box9_K2Node_ComponentBoundEvent_9_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box15_K2Node_ComponentBoundEvent_15_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box15_K2Node_ComponentBoundEvent_15_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box1_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box1_K2Node_ComponentBoundEvent_1_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box11_K2Node_ComponentBoundEvent_11_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box11_K2Node_ComponentBoundEvent_11_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box14_K2Node_ComponentBoundEvent_14_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box14_K2Node_ComponentBoundEvent_14_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box13_K2Node_ComponentBoundEvent_13_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box13_K2Node_ComponentBoundEvent_13_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box10_K2Node_ComponentBoundEvent_10_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box10_K2Node_ComponentBoundEvent_10_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box8_K2Node_ComponentBoundEvent_8_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box8_K2Node_ComponentBoundEvent_8_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box3_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box3_K2Node_ComponentBoundEvent_3_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box7_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box7_K2Node_ComponentBoundEvent_7_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box6_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box6_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box4_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box4_K2Node_ComponentBoundEvent_4_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_SaltCircle.BP_SaltCircle_C.BndEvt__Box2_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Box2_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
