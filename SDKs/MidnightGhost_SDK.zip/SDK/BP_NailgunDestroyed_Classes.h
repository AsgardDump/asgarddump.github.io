#pragma once 
#include <BP_NailgunDestroyed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_NailgunDestroyed.BP_NailgunDestroyed_C
// Size: 0x268(Inherited: 0x220) 
struct ABP_NailgunDestroyed_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* P_Impact_Transform-noSp;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Fadeout_Interp_DE2A09AC415B6235CFD8279E672E3655;  // 0x238(0x4)
	char ETimelineDirection Fadeout__Direction_DE2A09AC415B6235CFD8279E672E3655;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* FadeOut;  // 0x240(0x8)
	struct TArray<struct UStaticMeshComponent*> shards;  // 0x248(0x10)
	struct UMaterialInstanceDynamic* Mtl;  // 0x258(0x8)
	char FrostbiteHitState FrostbiteHitState;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	int32_t FrostbiteHitLevel;  // 0x264(0x4)

	void UserConstructionScript(); // Function BP_NailgunDestroyed.BP_NailgunDestroyed_C.UserConstructionScript
	void FadeOut__FinishedFunc(); // Function BP_NailgunDestroyed.BP_NailgunDestroyed_C.FadeOut__FinishedFunc
	void FadeOut__UpdateFunc(); // Function BP_NailgunDestroyed.BP_NailgunDestroyed_C.FadeOut__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_NailgunDestroyed.BP_NailgunDestroyed_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_NailgunDestroyed(int32_t EntryPoint); // Function BP_NailgunDestroyed.BP_NailgunDestroyed_C.ExecuteUbergraph_BP_NailgunDestroyed
}; 



