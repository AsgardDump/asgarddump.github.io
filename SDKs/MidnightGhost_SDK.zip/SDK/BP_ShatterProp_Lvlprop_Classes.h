#pragma once 
#include <BP_ShatterProp_Lvlprop_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ShatterProp_Lvlprop.BP_ShatterProp_Lvlprop_C
// Size: 0x292(Inherited: 0x220) 
struct ABP_ShatterProp_Lvlprop_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDestructibleComponent* Destructible;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct UDestructibleMesh* DestructibleMesh;  // 0x238(0x8)
	struct FTransform MeshTransform_WORLD;  // 0x240(0x30)
	struct FVector Velocity;  // 0x270(0xC)
	float VelocityDividerDampener;  // 0x27C(0x4)
	float ImpulseStrength;  // 0x280(0x4)
	float Damage;  // 0x284(0x4)
	struct ALvlProp_C* LvlProp;  // 0x288(0x8)
	char SmashMaterialType Smash Material;  // 0x290(0x1)
	char Ghost_SizeClass Smash Size;  // 0x291(0x1)

	void ReceiveBeginPlay(); // Function BP_ShatterProp_Lvlprop.BP_ShatterProp_Lvlprop_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ShatterProp_Lvlprop(int32_t EntryPoint); // Function BP_ShatterProp_Lvlprop.BP_ShatterProp_Lvlprop_C.ExecuteUbergraph_BP_ShatterProp_Lvlprop
}; 



