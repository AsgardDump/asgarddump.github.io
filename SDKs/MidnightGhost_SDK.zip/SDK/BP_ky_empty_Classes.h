#pragma once 
#include <BP_ky_empty_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ky_empty.BP_ky_empty_C
// Size: 0x228(Inherited: 0x220) 
struct ABP_ky_empty_C : public AActor
{
	struct USceneComponent* DefaultSceneRoot;  // 0x220(0x8)

}; 



