#pragma once 
#include <BP_SabotagedLvlprop_Large_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SabotagedLvlprop_Large.BP_SabotagedLvlprop_Large_C
// Size: 0x291(Inherited: 0x291) 
struct ABP_SabotagedLvlprop_Large_C : public ABP_SabotagedLvlprop_C
{

}; 



