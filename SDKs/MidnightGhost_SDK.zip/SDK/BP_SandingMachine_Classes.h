#pragma once 
#include <BP_SandingMachine_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SandingMachine.BP_SandingMachine_C
// Size: 0x280(Inherited: 0x220) 
struct ABP_SandingMachine_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* P_ImpactSand1;  // 0x228(0x8)
	struct UParticleSystemComponent* P_ImpactSand;  // 0x230(0x8)
	struct UParticleSystemComponent* P_ImpactMetal;  // 0x238(0x8)
	struct UStaticMeshComponent* SM_SandingMachine_handle;  // 0x240(0x8)
	struct UStaticMeshComponent* SM_SandingMachine;  // 0x248(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x250(0x8)
	struct AActor* Responsible Actor;  // 0x258(0x8)
	struct AController* ResponsibleController;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool SandingMachineActive? : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct UMaterialInstanceDynamic* DMI_Handle;  // 0x270(0x8)
	struct UMaterialInstanceDynamic* DMI_SandPaper;  // 0x278(0x8)

	void ReceiveBeginPlay(); // Function BP_SandingMachine.BP_SandingMachine_C.ReceiveBeginPlay
	void Begin SandingMachine(struct AActor* ResponsibleActor); // Function BP_SandingMachine.BP_SandingMachine_C.Begin SandingMachine
	void Server Begin SandingMachine(struct AActor* Responsible Actor); // Function BP_SandingMachine.BP_SandingMachine_C.Server Begin SandingMachine
	void MC_Begin_SandingMachine(); // Function BP_SandingMachine.BP_SandingMachine_C.MC_Begin_SandingMachine
	void ExecuteUbergraph_BP_SandingMachine(int32_t EntryPoint); // Function BP_SandingMachine.BP_SandingMachine_C.ExecuteUbergraph_BP_SandingMachine
}; 



