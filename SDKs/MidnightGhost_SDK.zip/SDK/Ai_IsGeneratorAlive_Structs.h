#pragma once 
#include "SDK.h" 
 
 
// Function Ai_IsGeneratorAlive.Ai_IsGeneratorAlive_C.PerformConditionCheckAI
// Size: 0x2A(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x18(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x29(0x1)

}; 
