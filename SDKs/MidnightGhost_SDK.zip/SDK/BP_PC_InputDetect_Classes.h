#pragma once 
#include <BP_PC_InputDetect_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PC_InputDetect.BP_PC_InputDetect_C
// Size: 0x620(Inherited: 0x5E8) 
struct ABP_PC_InputDetect_C : public AVivoxPlayerController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x5E8(0x8)
	struct FKey LastPressedKey;  // 0x5F0(0x18)
	struct FKey AnyKey;  // 0x608(0x18)

	void FindRightInputType(struct FKey InputKey, struct FKey& LastPressedKey); // Function BP_PC_InputDetect.BP_PC_InputDetect_C.FindRightInputType
	bool GetIsMouseMoving(); // Function BP_PC_InputDetect.BP_PC_InputDetect_C.GetIsMouseMoving
	void InpActEvt_AnyKey_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_PC_InputDetect.BP_PC_InputDetect_C.InpActEvt_AnyKey_K2Node_InputKeyEvent_1
	void UpdateMouseCursor(); // Function BP_PC_InputDetect.BP_PC_InputDetect_C.UpdateMouseCursor
	void ExecuteUbergraph_BP_PC_InputDetect(int32_t EntryPoint); // Function BP_PC_InputDetect.BP_PC_InputDetect_C.ExecuteUbergraph_BP_PC_InputDetect
}; 



