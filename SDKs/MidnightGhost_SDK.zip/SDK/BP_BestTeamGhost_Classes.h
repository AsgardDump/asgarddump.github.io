#pragma once 
#include <BP_BestTeamGhost_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BestTeamGhost.BP_BestTeamGhost_C
// Size: 0x570(Inherited: 0x4C0) 
struct ABP_BestTeamGhost_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UParticleSystemComponent* P_SmokeWisp1-loop1;  // 0x4C8(0x8)
	struct UWidgetComponent* BestTeam_Nameplate;  // 0x4D0(0x8)
	struct UPointLightComponent* PointLight1;  // 0x4D8(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x4E0(0x8)
	struct FString Name;  // 0x4E8(0x10)
	char pad_1272[8];  // 0x4F8(0x8)
	struct FTransform XForm;  // 0x500(0x30)
	int32_t Player Level;  // 0x530(0x4)
	char pad_1332[4];  // 0x534(0x4)
	struct AMGH_PlayerState_C* Custom Player State;  // 0x538(0x8)
	char pad_1344_1 : 7;  // 0x540(0x1)
	bool Red Ghost? : 1;  // 0x540(0x1)
	char pad_1345[7];  // 0x541(0x7)
	struct TArray<struct UMaterialInstanceDynamic*> GhostMaterials;  // 0x548(0x10)
	char VictoryPoses Victory Pose;  // 0x558(0x1)
	char pad_1369[7];  // 0x559(0x7)
	struct TArray<struct AActor*> AllSpawnedEmoteProps;  // 0x560(0x10)

	void ReceiveBeginPlay(); // Function BP_BestTeamGhost.BP_BestTeamGhost_C.ReceiveBeginPlay
	void SpawnVictoryPosePropAttached(AActor* Prop Class, struct FName Socket Name, struct FTransform Offsets); // Function BP_BestTeamGhost.BP_BestTeamGhost_C.SpawnVictoryPosePropAttached
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_BestTeamGhost.BP_BestTeamGhost_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_BestTeamGhost(int32_t EntryPoint); // Function BP_BestTeamGhost.BP_BestTeamGhost_C.ExecuteUbergraph_BP_BestTeamGhost
}; 



