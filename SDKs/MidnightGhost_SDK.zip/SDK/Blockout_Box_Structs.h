#pragma once 
#include "SDK.h" 
 
 
// Function Blockout_Box.Blockout_Box_C.AddBlockoutBox
// Size: 0x89(Inherited: 0x0) 
struct FAddBlockoutBox
{
	struct FWalkableSlopeOverride K2Node_MakeStruct_WalkableSlopeOverride;  // 0x0(0x10)
	struct FWalkableSlopeOverride K2Node_MakeStruct_WalkableSlopeOverride_2;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x24(0x4)
	struct FWalkableSlopeOverride K2Node_Select_Default;  // 0x28(0x10)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x38(0xC)
	char pad_68[12];  // 0x44(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x50(0x30)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x88(0x1)

}; 
