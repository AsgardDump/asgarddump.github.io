#pragma once 
#include <BP_InfectionGhostDeath_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_InfectionGhostDeath.BP_InfectionGhostDeath_C
// Size: 0x298(Inherited: 0x220) 
struct ABP_InfectionGhostDeath_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* GhostDamaged-BiggerLessIntense;  // 0x228(0x8)
	struct UParticleSystemComponent* ParticleSystem7;  // 0x230(0x8)
	struct UParticleSystemComponent* ParticleSystem6;  // 0x238(0x8)
	struct UParticleSystemComponent* ParticleSystem5;  // 0x240(0x8)
	struct UParticleSystemComponent* ParticleSystem4;  // 0x248(0x8)
	struct UParticleSystemComponent* ParticleSystem3;  // 0x250(0x8)
	struct UParticleSystemComponent* GhostDamaged-Burst2;  // 0x258(0x8)
	struct UParticleSystemComponent* GhostDamaged-Burst;  // 0x260(0x8)
	struct UParticleSystemComponent* ParticleSystem2;  // 0x268(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x270(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x278(0x8)
	struct UParticleSystemComponent* GhostDamaged-Burst1;  // 0x280(0x8)
	struct UPointLightComponent* PointLight;  // 0x288(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x290(0x8)

	void ReceiveTick(float DeltaSeconds); // Function BP_InfectionGhostDeath.BP_InfectionGhostDeath_C.ReceiveTick
	void ExecuteUbergraph_BP_InfectionGhostDeath(int32_t EntryPoint); // Function BP_InfectionGhostDeath.BP_InfectionGhostDeath_C.ExecuteUbergraph_BP_InfectionGhostDeath
}; 



