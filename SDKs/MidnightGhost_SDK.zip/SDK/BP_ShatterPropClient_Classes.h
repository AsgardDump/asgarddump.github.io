#pragma once 
#include <BP_ShatterPropClient_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ShatterPropClient.BP_ShatterPropClient_C
// Size: 0x29F(Inherited: 0x220) 
struct ABP_ShatterPropClient_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDestructibleComponent* Destructible;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct UDestructibleMesh* DestructibleMesh;  // 0x238(0x8)
	struct FTransform MeshTransform_WORLD;  // 0x240(0x30)
	struct FVector Velocity;  // 0x270(0xC)
	float VelocityDividerDampener;  // 0x27C(0x4)
	struct AProp_C* Prop;  // 0x280(0x8)
	struct ABP_GhostEmergeShatter_C* My_GhostEmerge;  // 0x288(0x8)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool TEASER - LAMP? : 1;  // 0x290(0x1)
	char pad_657[3];  // 0x291(0x3)
	float ImpulseStrength;  // 0x294(0x4)
	float Damage;  // 0x298(0x4)
	char pad_668_1 : 7;  // 0x29C(0x1)
	bool NON-TEASER USAGE? : 1;  // 0x29C(0x1)
	char SmashMaterialType Smash Material;  // 0x29D(0x1)
	char Ghost_SizeClass Smash Size;  // 0x29E(0x1)

	void ReceiveBeginPlay(); // Function BP_ShatterPropClient.BP_ShatterPropClient_C.ReceiveBeginPlay
	void RezCleanup(); // Function BP_ShatterPropClient.BP_ShatterPropClient_C.RezCleanup
	void ExecuteUbergraph_BP_ShatterPropClient(int32_t EntryPoint); // Function BP_ShatterPropClient.BP_ShatterPropClient_C.ExecuteUbergraph_BP_ShatterPropClient
}; 



