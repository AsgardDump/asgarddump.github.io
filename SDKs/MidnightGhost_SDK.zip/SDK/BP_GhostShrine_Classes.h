#pragma once 
#include <BP_GhostShrine_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GhostShrine.BP_GhostShrine_C
// Size: 0x3B0(Inherited: 0x281) 
struct ABP_GhostShrine_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UStaticMeshComponent* Plane;  // 0x290(0x8)
	struct UStaticMeshComponent* S_Tube1;  // 0x298(0x8)
	struct UStaticMeshComponent* compass04;  // 0x2A0(0x8)
	struct UStaticMeshComponent* SM_CoralRocky004;  // 0x2A8(0x8)
	struct UStaticMeshComponent* compass03;  // 0x2B0(0x8)
	struct UStaticMeshComponent* scroll_9;  // 0x2B8(0x8)
	struct UStaticMeshComponent* SM_Book_16;  // 0x2C0(0x8)
	struct UStaticMeshComponent* Bone01;  // 0x2C8(0x8)
	struct UStaticMeshComponent* Bone03;  // 0x2D0(0x8)
	struct UStaticMeshComponent* rock02;  // 0x2D8(0x8)
	struct UStaticMeshComponent* skull;  // 0x2E0(0x8)
	struct UStaticMeshComponent* Bone02;  // 0x2E8(0x8)
	struct UStaticMeshComponent* SM_CoralRocky003;  // 0x2F0(0x8)
	struct UStaticMeshComponent* SM_Cup_02;  // 0x2F8(0x8)
	struct UStaticMeshComponent* beads_2;  // 0x300(0x8)
	struct UStaticMeshComponent* SM_Cup_c;  // 0x308(0x8)
	struct UStaticMeshComponent* SM_Chess_Piece_010;  // 0x310(0x8)
	struct UStaticMeshComponent* SM_Cup_c1;  // 0x318(0x8)
	struct UStaticMeshComponent* SM_FrameA;  // 0x320(0x8)
	struct UStaticMeshComponent* SM_FrameB;  // 0x328(0x8)
	struct UStaticMeshComponent* S_Tube;  // 0x330(0x8)
	struct UStaticMeshComponent* beads_4;  // 0x338(0x8)
	struct UStaticMeshComponent* beads;  // 0x340(0x8)
	struct UStaticMeshComponent* compass1;  // 0x348(0x8)
	struct UStaticMeshComponent* scroll_7;  // 0x350(0x8)
	struct UStaticMeshComponent* SM_Cup_01;  // 0x358(0x8)
	struct UStaticMeshComponent* scroll_8;  // 0x360(0x8)
	struct UStaticMeshComponent* rewde;  // 0x368(0x8)
	struct UWidgetComponent* ShrineIndicator_Component;  // 0x370(0x8)
	struct UBoxComponent* InteractOverlap;  // 0x378(0x8)
	struct UPointLightComponent* PointLight1;  // 0x380(0x8)
	struct UPointLightComponent* PointLight;  // 0x388(0x8)
	struct USpotLightComponent* SpotLight;  // 0x390(0x8)
	struct UStaticMeshComponent* SM_Gravestone03;  // 0x398(0x8)
	struct UStaticMeshComponent* SM_Gravestone02;  // 0x3A0(0x8)
	struct UShrineIndicator_UI_C* ShrineIndicator;  // 0x3A8(0x8)

	void ReceiveBeginPlay(); // Function BP_GhostShrine.BP_GhostShrine_C.ReceiveBeginPlay
	void InteractWithShrine(struct AMGH_PlayerController_BP_C* PC); // Function BP_GhostShrine.BP_GhostShrine_C.InteractWithShrine
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_GhostShrine.BP_GhostShrine_C.ReceiveEndPlay
	void ShrineIndicatorStartup(); // Function BP_GhostShrine.BP_GhostShrine_C.ShrineIndicatorStartup
	void ExecuteUbergraph_BP_GhostShrine(int32_t EntryPoint); // Function BP_GhostShrine.BP_GhostShrine_C.ExecuteUbergraph_BP_GhostShrine
}; 



