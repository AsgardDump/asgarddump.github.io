#pragma once 
#include <ActNatural_HEquippedData_Structs.h>
 
 
 
// BlueprintGeneratedClass ActNatural_HEquippedData.ActNatural_HEquippedData_C
// Size: 0x30(Inherited: 0x28) 
struct UActNatural_HEquippedData_C : public USaveGame
{
	char Hunter_Emotes Slot01_Emote;  // 0x28(0x1)
	char Hunter_Emotes Slot02_Emote;  // 0x29(0x1)
	char Hunter_Emotes Slot03_Emote;  // 0x2A(0x1)
	char pad_43[1];  // 0x2B(0x1)
	int32_t HunterSkinEquipped;  // 0x2C(0x4)

}; 



