#pragma once 
#include "SDK.h" 
 
 
// Function BP_BestTeamGhost.BP_BestTeamGhost_C.ExecuteUbergraph_BP_BestTeamGhost
// Size: 0x174(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BestTeamGhost
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBestTeam_Nameplate_UI_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString CallFunc_GetMGHPlayerName_Player_Name;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_SetupGhostMesh_Success : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct TArray<struct UMaterialInstanceDynamic*> CallFunc_SetupGhostMesh_Materials;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_SetupGhostMesh_Success_2 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TArray<struct UMaterialInstanceDynamic*> CallFunc_SetupGhostMesh_Materials_2;  // 0x58(0x10)
	struct FLinearColor K2Node_MakeStruct_LinearColor;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item;  // 0x80(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	AActor* K2Node_CustomEvent_Prop_Class;  // 0x90(0x8)
	struct FName K2Node_CustomEvent_Socket_Name;  // 0x98(0x8)
	struct FTransform K2Node_CustomEvent_Offsets;  // 0xA0(0x30)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct AActor* CallFunc_Array_Get_Item_2;  // 0xD8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xE0(0x4)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0xE8(0x4)
	int32_t CallFunc_Max_ReturnValue;  // 0xEC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xFC(0x1)
	char pad_253_1 : 7;  // 0xFD(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xFD(0x1)
	char pad_254[2];  // 0xFE(0x2)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x100(0x30)
	struct FTransform CallFunc_ComposeTransforms_ReturnValue;  // 0x130(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x160(0x8)
	struct AActor* CallFunc_FinishSpawningActor_ReturnValue;  // 0x168(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x170(0x4)

}; 
// Function BP_BestTeamGhost.BP_BestTeamGhost_C.SpawnVictoryPosePropAttached
// Size: 0x40(Inherited: 0x0) 
struct FSpawnVictoryPosePropAttached
{
	AActor* Prop Class;  // 0x0(0x8)
	struct FName Socket Name;  // 0x8(0x8)
	struct FTransform Offsets;  // 0x10(0x30)

}; 
// Function BP_BestTeamGhost.BP_BestTeamGhost_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
