#pragma once 
#include <BP_KeyInput_AnalogAxis_RemoveDelta_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KeyInput_AnalogAxis_RemoveDelta.BP_KeyInput_AnalogAxis_RemoveDelta_C
// Size: 0x68(Inherited: 0x68) 
struct UBP_KeyInput_AnalogAxis_RemoveDelta_C : public UBP_KeyInput_AnalogAxis_C
{

	void Key Input Current State(struct APlayerController* Controller, float& Axis Value, bool& Down, bool& Just Pressed, bool& Just Released); // Function BP_KeyInput_AnalogAxis_RemoveDelta.BP_KeyInput_AnalogAxis_RemoveDelta_C.Key Input Current State
}; 



