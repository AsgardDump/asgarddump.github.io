#pragma once 
#include <BP_ky_beam01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ky_beam01.BP_ky_beam01_C
// Size: 0x2D0(Inherited: 0x220) 
struct ABP_ky_beam01_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* Niagara_Beam;  // 0x228(0x8)
	struct UNiagaraComponent* Niagara_Idle;  // 0x230(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x238(0x8)
	struct USceneComponent* marker;  // 0x240(0x8)
	struct UParticleSystemComponent* fx;  // 0x248(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x250(0x8)
	float Timeline_0_size_value_B7F3A37F8F43A37D7083208098684A9E;  // 0x258(0x4)
	char ETimelineDirection Timeline_0__Direction_B7F3A37F8F43A37D7083208098684A9E;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool isNotLoop : 1;  // 0x268(0x1)
	char pad_617[3];  // 0x269(0x3)
	float Duration;  // 0x26C(0x4)
	struct FSlateColor Color;  // 0x270(0x28)
	struct FVector BeamEnd;  // 0x298(0xC)
	char pad_676[4];  // 0x2A4(0x4)
	struct AActor* beamStartTarget;  // 0x2A8(0x8)
	struct AActor* beamEndTarget;  // 0x2B0(0x8)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool isNotBeamShot : 1;  // 0x2B8(0x1)
	char pad_697[3];  // 0x2B9(0x3)
	float shotSpeed;  // 0x2BC(0x4)
	struct AActor* beamEndTargetBck;  // 0x2C0(0x8)
	struct USceneComponent* beamStartTargetComponent;  // 0x2C8(0x8)

	void UserConstructionScript(); // Function BP_ky_beam01.BP_ky_beam01_C.UserConstructionScript
	void Timeline_0__FinishedFunc(); // Function BP_ky_beam01.BP_ky_beam01_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_ky_beam01.BP_ky_beam01_C.Timeline_0__UpdateFunc
	void ReceiveTick(float DeltaSeconds); // Function BP_ky_beam01.BP_ky_beam01_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_ky_beam01.BP_ky_beam01_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ky_beam01(int32_t EntryPoint); // Function BP_ky_beam01.BP_ky_beam01_C.ExecuteUbergraph_BP_ky_beam01
}; 



