#pragma once 
#include <BestTeamCharacters_Structs.h>
 
 
 
// BlueprintGeneratedClass BestTeamCharacters.BestTeamCharacters_C
// Size: 0x28(Inherited: 0x28) 
struct UBestTeamCharacters_C : public UInterface
{

}; 



