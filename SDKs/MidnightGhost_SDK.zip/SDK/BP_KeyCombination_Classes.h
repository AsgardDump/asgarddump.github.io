#pragma once 
#include <BP_KeyCombination_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KeyCombination.BP_KeyCombination_C
// Size: 0x98(Inherited: 0x28) 
struct UBP_KeyCombination_C : public UObject
{
	struct FString Name;  // 0x28(0x10)
	struct TArray<struct UBP_KeyInput_C*> Key Inputs;  // 0x38(0x10)
	struct TArray<struct FSKeyInput> Default Combination;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool Can't Be None : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct TArray<struct UBP_KeyConflict_C*> Conflicting Mappings Blocked;  // 0x60(0x10)
	struct TArray<struct UBP_KeyConflict_C*> Conflicting Mappings Info;  // 0x70(0x10)
	struct FMulticastInlineDelegate Combination Updated;  // 0x80(0x10)
	struct UBP_KeyMapping_C* Parent Mapping;  // 0x90(0x8)

	void Get Key Combination Display Name(struct FString Separator, struct FString No Key Display, char EKeyCombinationDisplay Display Type, struct FString& Display Name); // Function BP_KeyCombination.BP_KeyCombination_C.Get Key Combination Display Name
	void Add Key Input(struct FSKeyInput InputPin, struct UBP_KeyInput_C*& Input); // Function BP_KeyCombination.BP_KeyCombination_C.Add Key Input
	void Equal All Keys(struct TArray<struct FSKeyInput>& Combination, bool& Result); // Function BP_KeyCombination.BP_KeyCombination_C.Equal All Keys
	void Equal All Conflicts(struct TArray<struct FSKeyConflict>& Conflicts, bool& Result); // Function BP_KeyCombination.BP_KeyCombination_C.Equal All Conflicts
	void Evaluate Blocking Combinations(struct APlayerController* Player Controller, bool& Is Active, bool& Just Pressed, bool& Just Released); // Function BP_KeyCombination.BP_KeyCombination_C.Evaluate Blocking Combinations
	void Clear Conflicting Combinations(); // Function BP_KeyCombination.BP_KeyCombination_C.Clear Conflicting Combinations
	void Add Conflicting Combination(struct UBP_KeyCombination_C* Conflicted Combination, char EKeyConflict Conflicted ); // Function BP_KeyCombination.BP_KeyCombination_C.Add Conflicting Combination
	void Detect Conflict(struct UBP_KeyCombination_C* Input Combination, char EKeyConflict& Conflict Type); // Function BP_KeyCombination.BP_KeyCombination_C.Detect Conflict
	void Replace Key Combination(struct TArray<struct FSKeyInput>& Key Combination); // Function BP_KeyCombination.BP_KeyCombination_C.Replace Key Combination
	void Load Key Combination(struct UBP_GameSettings_C* Game Settings, struct FString Action Name, struct FString Category, struct FString Name, bool Primary); // Function BP_KeyCombination.BP_KeyCombination_C.Load Key Combination
	void Save Key Combination(struct UBP_GameSettings_C* Game Settings, struct FSKeyActionSave& KeySave); // Function BP_KeyCombination.BP_KeyCombination_C.Save Key Combination
	void Key Combination Current State(struct APlayerController* Player Controller, bool Ignore Conflicts, float& Axis Value, bool& Is Active, bool& Just Pressed, bool& Just Released); // Function BP_KeyCombination.BP_KeyCombination_C.Key Combination Current State
	void Init Key Combination(struct FString Name, bool Can't Be None, struct TArray<struct FSKeyInput>& Key Combination, struct UBP_KeyCombination_C*& Combination); // Function BP_KeyCombination.BP_KeyCombination_C.Init Key Combination
	void Combination Updated__DelegateSignature(struct UBP_KeyCombination_C* Combination); // Function BP_KeyCombination.BP_KeyCombination_C.Combination Updated__DelegateSignature
}; 



