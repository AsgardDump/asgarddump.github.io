#pragma once 
#include "SDK.h" 
 
 
// Function BP_LightSwitchable.BP_LightSwitchable_C.TurnOnOff
// Size: 0x2(Inherited: 0x0) 
struct FTurnOnOff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool PlaySound? : 1;  // 0x1(0x1)

}; 
// Function BP_LightSwitchable.BP_LightSwitchable_C.ExecuteUbergraph_BP_LightSwitchable
// Size: 0x5A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LightSwitchable
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool K2Node_CustomEvent_Off_on_2 : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool K2Node_CustomEvent_Off_on : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool K2Node_CustomEvent_PlaySound_ : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x28(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x40(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x59(0x1)

}; 
// Function BP_LightSwitchable.BP_LightSwitchable_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_LightSwitchable.BP_LightSwitchable_C.MC_TurnOnOff
// Size: 0x1(Inherited: 0x0) 
struct FMC_TurnOnOff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)

}; 
