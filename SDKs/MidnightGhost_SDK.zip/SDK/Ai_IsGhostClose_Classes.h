#pragma once 
#include <Ai_IsGhostClose_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_IsGhostClose.Ai_IsGhostClose_C
// Size: 0x120(Inherited: 0xA0) 
struct UAi_IsGhostClose_C : public UBTDecorator_BlueprintBase
{
	struct FBlackboardKeySelector CheckFromActor;  // 0xA0(0x28)
	struct FBlackboardKeySelector IgnoreThisGhost;  // 0xC8(0x28)
	struct FBlackboardKeySelector OutClosestGhost;  // 0xF0(0x28)
	float MaxDistance;  // 0x118(0x4)
	float MinDistance;  // 0x11C(0x4)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_IsGhostClose.Ai_IsGhostClose_C.PerformConditionCheckAI
}; 



