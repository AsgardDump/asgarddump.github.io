#pragma once 
#include <BP_C4Interact_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_C4Interact.BP_C4Interact_C
// Size: 0x2A0(Inherited: 0x281) 
struct ABP_C4Interact_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UBoxComponent* Box;  // 0x290(0x8)
	struct ABP_C4Actor_C* MyC4;  // 0x298(0x8)

	void IsThisMyC4?(struct ABP_Hunter_C* Hunter, bool& YES); // Function BP_C4Interact.BP_C4Interact_C.IsThisMyC4?
	void PickUpC4(struct AMGH_PlayerController_BP_C* Controller); // Function BP_C4Interact.BP_C4Interact_C.PickUpC4
	void ExecuteUbergraph_BP_C4Interact(int32_t EntryPoint); // Function BP_C4Interact.BP_C4Interact_C.ExecuteUbergraph_BP_C4Interact
}; 



