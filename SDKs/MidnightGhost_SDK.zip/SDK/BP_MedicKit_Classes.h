#pragma once 
#include <BP_MedicKit_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MedicKit.BP_MedicKit_C
// Size: 0x2A6(Inherited: 0x220) 
struct ABP_MedicKit_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UWidgetComponent* MiscIndicator;  // 0x228(0x8)
	struct UBoxComponent* HitBox;  // 0x230(0x8)
	struct UPointLightComponent* PointLight;  // 0x238(0x8)
	struct UBoxComponent* Box;  // 0x240(0x8)
	struct USkeletalMeshComponent* MedicBox_Mesh;  // 0x248(0x8)
	float Timeline_0_Lerp_B2B5FFDC43E6D89001C0509F42C14300;  // 0x250(0x4)
	char ETimelineDirection Timeline_0__Direction_B2B5FFDC43E6D89001C0509F42C14300;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x258(0x8)
	struct UProjectileMovementComponent* Projectile;  // 0x260(0x8)
	struct ABP_Hunter_C* MyHunter;  // 0x268(0x8)
	struct FRotator OrigRotation;  // 0x270(0xC)
	char pad_636[4];  // 0x27C(0x4)
	struct ABP_MedicKitInteract_C* MyInteract;  // 0x280(0x8)
	int32_t HealingChargesRemaining;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)
	struct AMGH_PlayerState_C* MyHunterPlayerState;  // 0x290(0x8)
	struct ABP_MedicKit_C* ToRemove;  // 0x298(0x8)
	int32_t MedicKitHealth;  // 0x2A0(0x4)
	char pad_676_1 : 7;  // 0x2A4(0x1)
	bool Destroyed : 1;  // 0x2A4(0x1)
	char pad_677_1 : 7;  // 0x2A5(0x1)
	bool PickedUp : 1;  // 0x2A5(0x1)

	void OnRep_HealingChargesRemaining(); // Function BP_MedicKit.BP_MedicKit_C.OnRep_HealingChargesRemaining
	void Timeline_0__FinishedFunc(); // Function BP_MedicKit.BP_MedicKit_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_MedicKit.BP_MedicKit_C.Timeline_0__UpdateFunc
	void OnNotifyEnd_6E999AC445D8D96C0D5DD89B359DC8D2(struct FName NotifyName); // Function BP_MedicKit.BP_MedicKit_C.OnNotifyEnd_6E999AC445D8D96C0D5DD89B359DC8D2
	void OnNotifyBegin_6E999AC445D8D96C0D5DD89B359DC8D2(struct FName NotifyName); // Function BP_MedicKit.BP_MedicKit_C.OnNotifyBegin_6E999AC445D8D96C0D5DD89B359DC8D2
	void OnInterrupted_6E999AC445D8D96C0D5DD89B359DC8D2(struct FName NotifyName); // Function BP_MedicKit.BP_MedicKit_C.OnInterrupted_6E999AC445D8D96C0D5DD89B359DC8D2
	void OnBlendOut_6E999AC445D8D96C0D5DD89B359DC8D2(struct FName NotifyName); // Function BP_MedicKit.BP_MedicKit_C.OnBlendOut_6E999AC445D8D96C0D5DD89B359DC8D2
	void OnCompleted_6E999AC445D8D96C0D5DD89B359DC8D2(struct FName NotifyName); // Function BP_MedicKit.BP_MedicKit_C.OnCompleted_6E999AC445D8D96C0D5DD89B359DC8D2
	void ReceiveBeginPlay(); // Function BP_MedicKit.BP_MedicKit_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_MedicKit.BP_MedicKit_C.ReceiveTick
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_MedicKit.BP_MedicKit_C.ReceiveHit
	void InterpToRotation(); // Function BP_MedicKit.BP_MedicKit_C.InterpToRotation
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_MedicKit.BP_MedicKit_C.ReceiveEndPlay
	void Server_UseMedicKit(struct ABP_Hunter_C* HealHunter); // Function BP_MedicKit.BP_MedicKit_C.Server_UseMedicKit
	void EnableTick(); // Function BP_MedicKit.BP_MedicKit_C.EnableTick
	void ForceTick(); // Function BP_MedicKit.BP_MedicKit_C.ForceTick
	void Server_DamageMedicKit(int32_t Damage); // Function BP_MedicKit.BP_MedicKit_C.Server_DamageMedicKit
	void CheckIfDisplayMedicKitIndicator(); // Function BP_MedicKit.BP_MedicKit_C.CheckIfDisplayMedicKitIndicator
	void RecheckMedicIndicator(); // Function BP_MedicKit.BP_MedicKit_C.RecheckMedicIndicator
	void Server_PickedUpMedkit(); // Function BP_MedicKit.BP_MedicKit_C.Server_PickedUpMedkit
	void ExecuteUbergraph_BP_MedicKit(int32_t EntryPoint); // Function BP_MedicKit.BP_MedicKit_C.ExecuteUbergraph_BP_MedicKit
}; 



