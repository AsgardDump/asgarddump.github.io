#pragma once 
#include <BP_Generator_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Generator.BP_Generator_C
// Size: 0x490(Inherited: 0x281) 
struct ABP_Generator_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UBoxComponent* Blocking1;  // 0x290(0x8)
	struct USpotLightComponent* SpotLight;  // 0x298(0x8)
	struct UStaticMeshComponent* Radar1;  // 0x2A0(0x8)
	struct USkeletalMeshComponent* X;  // 0x2A8(0x8)
	struct USkeletalMeshComponent* Trap;  // 0x2B0(0x8)
	struct USkeletalMeshComponent* Hookshot;  // 0x2B8(0x8)
	struct UStaticMeshComponent* club;  // 0x2C0(0x8)
	struct UStaticMeshComponent* Clock;  // 0x2C8(0x8)
	struct USkeletalMeshComponent* SkeletalMesh1;  // 0x2D0(0x8)
	struct USkeletalMeshComponent* Sniper;  // 0x2D8(0x8)
	struct USkeletalMeshComponent* Sledge Hammer;  // 0x2E0(0x8)
	struct UStaticMeshComponent* Spectral Cannon;  // 0x2E8(0x8)
	struct UStaticMeshComponent* pathfinder;  // 0x2F0(0x8)
	struct UStaticMeshComponent* Radar;  // 0x2F8(0x8)
	struct USceneComponent* AllProps;  // 0x300(0x8)
	struct UBoxComponent* STOP HUNTERS FROM GETTING IN;  // 0x308(0x8)
	struct USceneComponent* ResurrectPoint;  // 0x310(0x8)
	struct UBoxComponent* Blocking;  // 0x318(0x8)
	struct UArrowComponent* Arrow22;  // 0x320(0x8)
	struct UArrowComponent* Arrow21;  // 0x328(0x8)
	struct UArrowComponent* Arrow20;  // 0x330(0x8)
	struct UArrowComponent* Arrow19;  // 0x338(0x8)
	struct UArrowComponent* Arrow18;  // 0x340(0x8)
	struct UArrowComponent* Arrow17;  // 0x348(0x8)
	struct UArrowComponent* Arrow16;  // 0x350(0x8)
	struct UArrowComponent* Arrow15;  // 0x358(0x8)
	struct UArrowComponent* Arrow14;  // 0x360(0x8)
	struct UArrowComponent* Arrow13;  // 0x368(0x8)
	struct UArrowComponent* Arrow12;  // 0x370(0x8)
	struct UArrowComponent* Arrow11;  // 0x378(0x8)
	struct UArrowComponent* Arrow10;  // 0x380(0x8)
	struct UArrowComponent* Arrow9;  // 0x388(0x8)
	struct UArrowComponent* Arrow8;  // 0x390(0x8)
	struct UArrowComponent* Arrow7;  // 0x398(0x8)
	struct UArrowComponent* Arrow6;  // 0x3A0(0x8)
	struct UArrowComponent* Arrow5;  // 0x3A8(0x8)
	struct UArrowComponent* Arrow4;  // 0x3B0(0x8)
	struct UArrowComponent* Arrow3;  // 0x3B8(0x8)
	struct UArrowComponent* Arrow2;  // 0x3C0(0x8)
	struct UArrowComponent* Arrow1;  // 0x3C8(0x8)
	struct UArrowComponent* Arrow;  // 0x3D0(0x8)
	struct USceneComponent* SpewEcto_Parent;  // 0x3D8(0x8)
	struct UBoxComponent* TableHitbox02;  // 0x3E0(0x8)
	struct UParticleSystemComponent* OnFire;  // 0x3E8(0x8)
	struct UBoxComponent* TableHitbox;  // 0x3F0(0x8)
	struct UStaticMeshComponent* GeneratorMesh;  // 0x3F8(0x8)
	struct UBoxComponent* CenterHitbox;  // 0x400(0x8)
	struct UWidgetComponent* BPGenerator_Widget;  // 0x408(0x8)
	struct UParticleSystemComponent* GeneratorParticles;  // 0x410(0x8)
	struct UStaticMeshComponent* SM_NYC_Deco_Exterior_Newsbox_High;  // 0x418(0x8)
	struct UBoxComponent* Box;  // 0x420(0x8)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool Destroyed : 1;  // 0x428(0x1)
	char pad_1065[7];  // 0x429(0x7)
	struct UAudioComponent* SoundPlaying;  // 0x430(0x8)
	float Health Remaining;  // 0x438(0x4)
	float Max Health;  // 0x43C(0x4)
	struct TArray<struct UArrowComponent*> AllMyArrows;  // 0x440(0x10)
	struct TArray<struct UStaticMeshComponent*> AllMyMeshes;  // 0x450(0x10)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool EdgeSelecting? : 1;  // 0x460(0x1)
	char pad_1121_1 : 7;  // 0x461(0x1)
	bool Sabotaged - Saboteur? : 1;  // 0x461(0x1)
	char pad_1122[6];  // 0x462(0x6)
	struct UParticleSystemComponent* Sabotage VFX 1;  // 0x468(0x8)
	struct UParticleSystemComponent* Sabotage VFX 2;  // 0x470(0x8)
	struct UAudioComponent* Sabotage Sound;  // 0x478(0x8)
	char pad_1152_1 : 7;  // 0x480(0x1)
	bool Infection_Deactivated : 1;  // 0x480(0x1)
	char pad_1153[7];  // 0x481(0x7)
	struct UGeneratorIndicator_UI_C* GenIndicator;  // 0x488(0x8)

	void IsDestroyed_Int(bool& Destroyed); // Function BP_Generator.BP_Generator_C.IsDestroyed_Int
	void GetHealth_Int(float& Health, float& Max); // Function BP_Generator.BP_Generator_C.GetHealth_Int
	void SetUpMeshes(); // Function BP_Generator.BP_Generator_C.SetUpMeshes
	void SetUpArrows(); // Function BP_Generator.BP_Generator_C.SetUpArrows
	void OnRep_Sabotaged?(); // Function BP_Generator.BP_Generator_C.OnRep_Sabotaged?
	void ReceiveBeginPlay(); // Function BP_Generator.BP_Generator_C.ReceiveBeginPlay
	void NR_Sabotage(struct ABP_Generator_C* BPGEN); // Function BP_Generator.BP_Generator_C.NR_Sabotage
	void Restart(); // Function BP_Generator.BP_Generator_C.Restart
	void SoundStillPlaying?(); // Function BP_Generator.BP_Generator_C.SoundStillPlaying?
	void Server_PlayAlert(struct ABP_Generator_C* BP_Generator, bool  Alert On); // Function BP_Generator.BP_Generator_C.Server_PlayAlert
	void MC_PlayAlert(struct ABP_Generator_C* BP_Generator, bool  Alert On); // Function BP_Generator.BP_Generator_C.MC_PlayAlert
	void DamageGenerator(float Damage, struct AProp_C* Who Done It, struct ABP_Generator_C* Generator, struct APawn* Who Done It (Pawn), bool Unfiltered Damage); // Function BP_Generator.BP_Generator_C.DamageGenerator
	void Server_SpewEctoplasms(); // Function BP_Generator.BP_Generator_C.Server_SpewEctoplasms
	void RemoveIndicatorUI(); // Function BP_Generator.BP_Generator_C.RemoveIndicatorUI
	void Random Sound(); // Function BP_Generator.BP_Generator_C.Random Sound
	void SetTimer(); // Function BP_Generator.BP_Generator_C.SetTimer
	void GeneratorEdgeSelect(bool  ON!); // Function BP_Generator.BP_Generator_C.GeneratorEdgeSelect
	void NR_SaboteurSabotage(); // Function BP_Generator.BP_Generator_C.NR_SaboteurSabotage
	void Server_SendGeneratorMessage(); // Function BP_Generator.BP_Generator_C.Server_SendGeneratorMessage
	void MC_SpewEctoplams(); // Function BP_Generator.BP_Generator_C.MC_SpewEctoplams
	void Server_GeneratorDestroyed(struct APawn* Who Done It); // Function BP_Generator.BP_Generator_C.Server_GeneratorDestroyed
	void SetHealth(float Health); // Function BP_Generator.BP_Generator_C.SetHealth
	void GeneratorIndicatorStartup(); // Function BP_Generator.BP_Generator_C.GeneratorIndicatorStartup
	void ExecuteUbergraph_BP_Generator(int32_t EntryPoint); // Function BP_Generator.BP_Generator_C.ExecuteUbergraph_BP_Generator
}; 



