#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget.BP_Gadget_C.SetHunterInterface
// Size: 0x10(Inherited: 0x0) 
struct FSetHunterInterface
{
	struct TScriptInterface<IHunterInterface_C> HunterInterface;  // 0x0(0x10)

}; 
// Function BP_Gadget.BP_Gadget_C.ExecuteUbergraph_BP_Gadget
// Size: 0xD8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_CustomEvent_Unhide_Hide : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool K2Node_CustomEvent_SkipAnimation : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool K2Node_CustomEvent_TickWhileHidden : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool K2Node_CustomEvent_NonLocallyControlledOrBot : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool K2Node_CustomEvent_ShouldInterrupt : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_2;  // 0x18(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor;  // 0x20(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_2;  // 0x28(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_3;  // 0x30(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_3;  // 0x38(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_4;  // 0x40(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_4;  // 0x48(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_5;  // 0x50(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_5;  // 0x58(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_6;  // 0x60(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_6;  // 0x68(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_7;  // 0x70(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_7;  // 0x78(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_8;  // 0x80(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_9;  // 0x88(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_8;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_CustomEvent_Sprinting : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool K2Node_CustomEvent_InAir : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool K2Node_CustomEvent_IsDead : 1;  // 0x9A(0x1)
	char pad_155[5];  // 0x9B(0x5)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_10;  // 0xA0(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_9;  // 0xA8(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_10;  // 0xB0(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_11;  // 0xB8(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_11;  // 0xC0(0x8)
	struct ABP_Gadget_FP_C* CallFunc_GetFPActor_FPActor_12;  // 0xC8(0x8)
	struct ABP_Gadget_TP_C* CallFunc_GetTPActor_TPActor_12;  // 0xD0(0x8)

}; 
// Function BP_Gadget.BP_Gadget_C.SetOwnerStates
// Size: 0x3(Inherited: 0x0) 
struct FSetOwnerStates
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Sprinting : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool InAir : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool IsDead : 1;  // 0x2(0x1)

}; 
// Function BP_Gadget.BP_Gadget_C.UpdateVisibility
// Size: 0x5(Inherited: 0x0) 
struct FUpdateVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hide : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool SkipAnimation : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool TickWhileHidden : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool NonLocallyControlledOrBot : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ShouldInterrupt : 1;  // 0x4(0x1)

}; 
// Function BP_Gadget.BP_Gadget_C.ChangeComponentTickSettings
// Size: 0xD(Inherited: 0x0) 
struct FChangeComponentTickSettings
{
	struct USkeletalMeshComponent* InputPin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Should tick : 1;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable;  // 0x9(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool Temp_bool_Variable : 1;  // 0xB(0x1)
	uint8_t  K2Node_Select_Default;  // 0xC(0x1)

}; 
// Function BP_Gadget.BP_Gadget_C.GetTPActor
// Size: 0x8(Inherited: 0x0) 
struct FGetTPActor
{
	struct ABP_Gadget_TP_C* TPActor;  // 0x0(0x8)

}; 
// Function BP_Gadget.BP_Gadget_C.GetMeshes
// Size: 0x10(Inherited: 0x0) 
struct FGetMeshes
{
	struct TArray<struct UMeshComponent*> AllMyMeshes;  // 0x0(0x10)

}; 
// Function BP_Gadget.BP_Gadget_C.GetFPActor
// Size: 0x8(Inherited: 0x0) 
struct FGetFPActor
{
	struct ABP_Gadget_FP_C* FPActor;  // 0x0(0x8)

}; 
// Function BP_Gadget.BP_Gadget_C.IsEquipped
// Size: 0x1(Inherited: 0x0) 
struct FIsEquipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Equipped : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget.BP_Gadget_C.GetGadgetType
// Size: 0x1(Inherited: 0x0) 
struct FGetGadgetType
{
	char HunterGadgets GadgetType;  // 0x0(0x1)

}; 
// Function BP_Gadget.BP_Gadget_C.GadgetErrorMessage
// Size: 0x24(Inherited: 0x0) 
struct FGadgetErrorMessage
{
	struct FText Text;  // 0x0(0x18)
	struct UErrorRedMessage_UI_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledHunter : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledBot : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x23(0x1)

}; 
// Function BP_Gadget.BP_Gadget_C.GetAmmoData
// Size: 0xC(Inherited: 0x0) 
struct FGetAmmoData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool GadgetUsesAmmo : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t MaxAmmo;  // 0x4(0x4)
	int32_t CurrentAmmo;  // 0x8(0x4)

}; 
// Function BP_Gadget.BP_Gadget_C.CanBeUnequipped
// Size: 0x1(Inherited: 0x0) 
struct FCanBeUnequipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanBeUnequipped : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget.BP_Gadget_C.GetUnequipDuration
// Size: 0x4(Inherited: 0x0) 
struct FGetUnequipDuration
{
	float Duration;  // 0x0(0x4)

}; 
