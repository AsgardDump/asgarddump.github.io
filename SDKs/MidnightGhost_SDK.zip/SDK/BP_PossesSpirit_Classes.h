#pragma once 
#include <BP_PossesSpirit_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PossesSpirit.BP_PossesSpirit_C
// Size: 0x6B0(Inherited: 0x4C0) 
struct ABP_PossesSpirit_C : public AMGH_PossessSpirit
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct USpotLightComponent* CamFollowLight;  // 0x4C8(0x8)
	struct USkeletalMeshComponent* Ghost_MainBody;  // 0x4D0(0x8)
	struct USceneComponent* BodyRotation;  // 0x4D8(0x8)
	struct UAIPerceptionStimuliSourceComponent* AIPerceptionStimuliSource;  // 0x4E0(0x8)
	struct USphereComponent* PingOverlap;  // 0x4E8(0x8)
	struct UStaticMeshComponent* Core;  // 0x4F0(0x8)
	struct USphereComponent* Sphere;  // 0x4F8(0x8)
	struct UParticleSystemComponent* ParticleSystem2;  // 0x500(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x508(0x8)
	struct UPointLightComponent* PointLight;  // 0x510(0x8)
	struct UCameraComponent* Camera;  // 0x518(0x8)
	struct USpringArmComponent* SpringArm;  // 0x520(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x528(0x8)
	AProp_C* S-PropClass;  // 0x530(0x8)
	struct AProp_C* S-RequestingProp;  // 0x538(0x8)
	struct ALvlProp_C* S-LvlProp;  // 0x540(0x8)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool BOT-CONTROLLED? : 1;  // 0x548(0x1)
	char GhostAbility S-PropSpec;  // 0x549(0x1)
	char pad_1354_1 : 7;  // 0x54A(0x1)
	bool S-DoorOpen? : 1;  // 0x54A(0x1)
	char pad_1355_1 : 7;  // 0x54B(0x1)
	bool S-ClosedOrOpenGate? : 1;  // 0x54B(0x1)
	char pad_1356_1 : 7;  // 0x54C(0x1)
	bool S-RedOverride? : 1;  // 0x54C(0x1)
	char pad_1357_1 : 7;  // 0x54D(0x1)
	bool Tutorial? : 1;  // 0x54D(0x1)
	char pad_1358[2];  // 0x54E(0x2)
	struct UObject* TUTORIAL-Controller;  // 0x550(0x8)
	struct AMGH_PlayerController_BP_C* NR_MyANPC;  // 0x558(0x8)
	float Old Prop Max Health;  // 0x560(0x4)
	float Old Prop Current Health;  // 0x564(0x4)
	float New Prop Max Health;  // 0x568(0x4)
	char pad_1388_1 : 7;  // 0x56C(0x1)
	bool Stored Been Hit? : 1;  // 0x56C(0x1)
	char pad_1389[3];  // 0x56D(0x3)
	struct FTransform Target Xform;  // 0x570(0x30)
	float Stored Radiation;  // 0x5A0(0x4)
	char GhostPerks S-PropPerk;  // 0x5A4(0x1)
	char pad_1445[3];  // 0x5A5(0x3)
	struct AMGH_PlayerController_BP_C* Backup PlayerController Reference;  // 0x5A8(0x8)
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool Wallmounted : 1;  // 0x5B0(0x1)
	char pad_1457[3];  // 0x5B1(0x3)
	struct FVector StoredHomeLocation;  // 0x5B4(0xC)
	struct TArray<struct ABP_Hunter_C*> CachedSniperHunters;  // 0x5C0(0x10)
	int32_t Stored Prop ID;  // 0x5D0(0x4)
	struct FVector EctoPlasmaLastPosition;  // 0x5D4(0xC)
	int32_t StoredFrostbite Level;  // 0x5E0(0x4)
	char pad_1508[4];  // 0x5E4(0x4)
	struct TArray<struct AActor*> My Misc Attached Actor Cached;  // 0x5E8(0x10)
	struct TArray<struct FVector> My Misc Attached Actor Offset;  // 0x5F8(0x10)
	struct AController* MyController;  // 0x608(0x8)
	float DeltaTimeX;  // 0x610(0x4)
	char pad_1556[4];  // 0x614(0x4)
	struct TArray<struct UMaterialInstanceDynamic*> GhostMaterials;  // 0x618(0x10)
	struct FVector StartPosition;  // 0x628(0xC)
	float MovementSpeed;  // 0x634(0x4)
	struct ALvlProp_C* TargetLvlprop;  // 0x638(0x8)
	float Stored Inherited Armor;  // 0x640(0x4)
	char pad_1604[4];  // 0x644(0x4)
	struct TArray<struct ABP_SniperDart_C*> AttachedDarts;  // 0x648(0x10)
	char pad_1624_1 : 7;  // 0x658(0x1)
	bool PoppedOut : 1;  // 0x658(0x1)
	char pad_1625_1 : 7;  // 0x659(0x1)
	bool InstaDamage? : 1;  // 0x659(0x1)
	char pad_1626[2];  // 0x65A(0x2)
	int32_t InstaDamageAmount;  // 0x65C(0x4)
	struct AActor* InstaDamageResponsible;  // 0x660(0x8)
	char DamageMethod InstaDamageMethod;  // 0x668(0x1)
	char pad_1641[3];  // 0x669(0x3)
	float Possess Form Health;  // 0x66C(0x4)
	float Possess Form Max Health;  // 0x670(0x4)
	int32_t Stored Burn Level;  // 0x674(0x4)
	struct AMGH_PlayerState_C* Stored Current Burner;  // 0x678(0x8)
	char pad_1664_1 : 7;  // 0x680(0x1)
	bool Stored Burning : 1;  // 0x680(0x1)
	char pad_1665_1 : 7;  // 0x681(0x1)
	bool GameOver : 1;  // 0x681(0x1)
	char pad_1666_1 : 7;  // 0x682(0x1)
	bool IsADoor : 1;  // 0x682(0x1)
	char pad_1667[5];  // 0x683(0x5)
	struct AProp_C* JustSpawnedProp;  // 0x688(0x8)
	struct AActor* MiscPossessActor;  // 0x690(0x8)
	struct FVector MiscCamOffset;  // 0x698(0xC)
	struct FRotator Mesh Rotator;  // 0x6A4(0xC)

	void GetHealthData(float& Health, float& Max Health); // Function BP_PossesSpirit.BP_PossesSpirit_C.GetHealthData
	void GetArmorData(float& Armor, float& MaxArmor); // Function BP_PossesSpirit.BP_PossesSpirit_C.GetArmorData
	void NeedsArmor(bool& Armor); // Function BP_PossesSpirit.BP_PossesSpirit_C.NeedsArmor
	void GetEctoBuildup(bool& Prop?, float& Radiation, bool& Sensitive?, bool& Midnight Form?); // Function BP_PossesSpirit.BP_PossesSpirit_C.GetEctoBuildup
	void Set Up Midnight Mtl(); // Function BP_PossesSpirit.BP_PossesSpirit_C.Set Up Midnight Mtl
	void Get Lvl Prop Cam Offset(struct ALvlProp_C* LvlProp, struct FVector& Location); // Function BP_PossesSpirit.BP_PossesSpirit_C.Get Lvl Prop Cam Offset
	void Get Lvl Prop Interp To Location(struct ALvlProp_C* LvlProp, struct FVector& Location); // Function BP_PossesSpirit.BP_PossesSpirit_C.Get Lvl Prop Interp To Location
	void UpdateMaterialVariables(struct FVector StartPoint, struct FVector Endpoint); // Function BP_PossesSpirit.BP_PossesSpirit_C.UpdateMaterialVariables
	void SetUpMaterialsArray(); // Function BP_PossesSpirit.BP_PossesSpirit_C.SetUpMaterialsArray
	void OnNotifyEnd_0FF9B6D04F43C4D77E19898000543F1C(struct FName NotifyName); // Function BP_PossesSpirit.BP_PossesSpirit_C.OnNotifyEnd_0FF9B6D04F43C4D77E19898000543F1C
	void OnNotifyBegin_0FF9B6D04F43C4D77E19898000543F1C(struct FName NotifyName); // Function BP_PossesSpirit.BP_PossesSpirit_C.OnNotifyBegin_0FF9B6D04F43C4D77E19898000543F1C
	void OnInterrupted_0FF9B6D04F43C4D77E19898000543F1C(struct FName NotifyName); // Function BP_PossesSpirit.BP_PossesSpirit_C.OnInterrupted_0FF9B6D04F43C4D77E19898000543F1C
	void OnBlendOut_0FF9B6D04F43C4D77E19898000543F1C(struct FName NotifyName); // Function BP_PossesSpirit.BP_PossesSpirit_C.OnBlendOut_0FF9B6D04F43C4D77E19898000543F1C
	void OnCompleted_0FF9B6D04F43C4D77E19898000543F1C(struct FName NotifyName); // Function BP_PossesSpirit.BP_PossesSpirit_C.OnCompleted_0FF9B6D04F43C4D77E19898000543F1C
	void Damage(float Amount, struct AActor* ResponsibleActor, char DamageMethod method, bool Capture?, bool Direct Hit?, struct FVector Location); // Function BP_PossesSpirit.BP_PossesSpirit_C.Damage
	void ReceiveTick(float DeltaSeconds); // Function BP_PossesSpirit.BP_PossesSpirit_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_PossesSpirit.BP_PossesSpirit_C.ReceiveBeginPlay
	void Server_Possess(AProp_C* PropClass, struct AProp_C* Requesting Prop, char GhostAbility Requesting P Class, struct ALvlProp_C* LvlProp, struct FRotator MeshRotator, struct FRotator Control Rotation, bool Door_Open?); // Function BP_PossesSpirit.BP_PossesSpirit_C.Server_Possess
	void OC_SpiritStartup(); // Function BP_PossesSpirit.BP_PossesSpirit_C.OC_SpiritStartup
	void Server_BotPossess(AProp_C* PropClass, struct AProp_C* Requesting Prop, char GhostAbility Requesting P Class, struct ALvlProp_C* LvlProp, struct FRotator MeshRotator, bool Red Override?); // Function BP_PossesSpirit.BP_PossesSpirit_C.Server_BotPossess
	void NR_SpawnEctoplasmTrail(struct ABP_PossesSpirit_C* Spriit); // Function BP_PossesSpirit.BP_PossesSpirit_C.NR_SpawnEctoplasmTrail
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_PossesSpirit.BP_PossesSpirit_C.ReceiveEndPlay
	void Client_DestroyLevelprop(); // Function BP_PossesSpirit.BP_PossesSpirit_C.Client_DestroyLevelprop
	void DropFootprint(); // Function BP_PossesSpirit.BP_PossesSpirit_C.DropFootprint
	void MC_AddPossessWobbleForce(struct AProp_C* SpawnedProp); // Function BP_PossesSpirit.BP_PossesSpirit_C.MC_AddPossessWobbleForce
	void Server_PossessSpiritTakeDamage(struct AActor* Responsible, char DamageMethod DamageMethod, int32_t Amount); // Function BP_PossesSpirit.BP_PossesSpirit_C.Server_PossessSpiritTakeDamage
	void OC_SpiritDamageTaken(struct AActor* Responsible, char DamageMethod DamageMethod, int32_t Amount, bool SkipDmgLog); // Function BP_PossesSpirit.BP_PossesSpirit_C.OC_SpiritDamageTaken
	void OC_PossessCancelled(); // Function BP_PossesSpirit.BP_PossesSpirit_C.OC_PossessCancelled
	void PossessEnd(); // Function BP_PossesSpirit.BP_PossesSpirit_C.PossessEnd
	void Server_PossessCancel(); // Function BP_PossesSpirit.BP_PossesSpirit_C.Server_PossessCancel
	void Server_DestroyMiscPossess(); // Function BP_PossesSpirit.BP_PossesSpirit_C.Server_DestroyMiscPossess
	void ExecuteUbergraph_BP_PossesSpirit(int32_t EntryPoint); // Function BP_PossesSpirit.BP_PossesSpirit_C.ExecuteUbergraph_BP_PossesSpirit
}; 



