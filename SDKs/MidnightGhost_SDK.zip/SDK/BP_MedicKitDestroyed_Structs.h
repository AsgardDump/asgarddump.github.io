#pragma once 
#include "SDK.h" 
 
 
// Function BP_MedicKitDestroyed.BP_MedicKitDestroyed_C.ExecuteUbergraph_BP_MedicKitDestroyed
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MedicKitDestroyed
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)

}; 
