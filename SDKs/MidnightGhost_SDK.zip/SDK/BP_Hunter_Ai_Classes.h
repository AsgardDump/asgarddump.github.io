#pragma once 
#include <BP_Hunter_Ai_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_Ai.BP_Hunter_Ai_C
// Size: 0x2690(Inherited: 0x2658) 
struct ABP_Hunter_Ai_C : public ABP_Hunter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2658(0x8)
	struct TArray<struct ATargetPoint*> PatrolPoints;  // 0x2660(0x10)
	char pad_9840_1 : 7;  // 0x2670(0x1)
	bool InheritName? : 1;  // 0x2670(0x1)
	char BotNames InheritedName;  // 0x2671(0x1)
	char pad_9842_1 : 7;  // 0x2672(0x1)
	bool Inherited Score? : 1;  // 0x2672(0x1)
	char pad_9843[1];  // 0x2673(0x1)
	int32_t Inherited Kills;  // 0x2674(0x4)
	int32_t Inherited Deaths;  // 0x2678(0x4)
	char pad_9852[4];  // 0x267C(0x4)
	struct TArray<struct AMGH_PlayerState_C*> CarriedShards;  // 0x2680(0x10)

	void BotChangeLoadoutAtGenerator(char HunterGadgets New Weapon, char HunterGadgets New Gadget, char HunterPerks New Perk, bool Van Switch?); // Function BP_Hunter_Ai.BP_Hunter_Ai_C.BotChangeLoadoutAtGenerator
	void HasMeleeWeaponEquipped(bool& NewParam); // Function BP_Hunter_Ai.BP_Hunter_Ai_C.HasMeleeWeaponEquipped
	void ReceiveBeginPlay(); // Function BP_Hunter_Ai.BP_Hunter_Ai_C.ReceiveBeginPlay
	void SetVacuumedShardsCarried(struct TArray<struct AMGH_PlayerState_C*>& shards); // Function BP_Hunter_Ai.BP_Hunter_Ai_C.SetVacuumedShardsCarried
	void K2_OnMovementModeChanged(char EMovementMode PrevMovementMode, char EMovementMode NewMovementMode, char PrevCustomMode, char NewCustomMode); // Function BP_Hunter_Ai.BP_Hunter_Ai_C.K2_OnMovementModeChanged
	void OnLanded(struct FHitResult& Hit); // Function BP_Hunter_Ai.BP_Hunter_Ai_C.OnLanded
	void ExecuteUbergraph_BP_Hunter_Ai(int32_t EntryPoint); // Function BP_Hunter_Ai.BP_Hunter_Ai_C.ExecuteUbergraph_BP_Hunter_Ai
}; 



