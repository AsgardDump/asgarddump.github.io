#pragma once 
#include <BP_NewSpray_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_NewSpray.BP_NewSpray_C
// Size: 0x270(Inherited: 0x220) 
struct ABP_NewSpray_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct UMaterialInterface* SprayTexture;  // 0x230(0x8)
	struct ACharacter* OwnerCharacter;  // 0x238(0x8)
	struct FMulticastInlineDelegate NewEventDispatcher_1;  // 0x240(0x10)
	char SpraySizes SpraySize;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct UDecalComponent* MyDecal;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool SteamAvatarSpray? : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool FirstRun : 1;  // 0x261(0x1)
	char pad_610_1 : 7;  // 0x262(0x1)
	bool DoubleDepth? : 1;  // 0x262(0x1)
	char pad_611[5];  // 0x263(0x5)
	struct UTexture2D* Local_ProfilePicture;  // 0x268(0x8)

	void OnFailure_A9E966C340683562F720408014C4FFA3(uint8_t  Result); // Function BP_NewSpray.BP_NewSpray_C.OnFailure_A9E966C340683562F720408014C4FFA3
	void OnSuccess_A9E966C340683562F720408014C4FFA3(struct FString ExternalAccountId); // Function BP_NewSpray.BP_NewSpray_C.OnSuccess_A9E966C340683562F720408014C4FFA3
	void ReceiveBeginPlay(); // Function BP_NewSpray.BP_NewSpray_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_NewSpray(int32_t EntryPoint); // Function BP_NewSpray.BP_NewSpray_C.ExecuteUbergraph_BP_NewSpray
	void NewEventDispatcher_0__DelegateSignature(); // Function BP_NewSpray.BP_NewSpray_C.NewEventDispatcher_0__DelegateSignature
}; 



