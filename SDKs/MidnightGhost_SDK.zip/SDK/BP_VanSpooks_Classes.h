#pragma once 
#include <BP_VanSpooks_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_VanSpooks.BP_VanSpooks_C
// Size: 0x239(Inherited: 0x220) 
struct ABP_VanSpooks_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* VanSpooks;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool Active : 1;  // 0x238(0x1)

	void Random Sound(); // Function BP_VanSpooks.BP_VanSpooks_C.Random Sound
	void ReceiveBeginPlay(); // Function BP_VanSpooks.BP_VanSpooks_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_VanSpooks(int32_t EntryPoint); // Function BP_VanSpooks.BP_VanSpooks_C.ExecuteUbergraph_BP_VanSpooks
}; 



