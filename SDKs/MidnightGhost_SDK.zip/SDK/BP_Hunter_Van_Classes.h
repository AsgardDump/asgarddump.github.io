#pragma once 
#include <BP_Hunter_Van_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_Van.BP_Hunter_Van_C
// Size: 0x2660(Inherited: 0x2658) 
struct ABP_Hunter_Van_C : public ABP_Hunter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2658(0x8)

	void ReceiveBeginPlay(); // Function BP_Hunter_Van.BP_Hunter_Van_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Hunter_Van(int32_t EntryPoint); // Function BP_Hunter_Van.BP_Hunter_Van_C.ExecuteUbergraph_BP_Hunter_Van
}; 



