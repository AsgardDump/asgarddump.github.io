#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget_FP_Pathfinder.BP_Gadget_FP_Pathfinder_C.ExecuteUbergraph_BP_Gadget_FP_Pathfinder
// Size: 0x2C0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget_FP_Pathfinder
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1C(0xC)
	char pad_40[8];  // 0x28(0x8)
	struct FTransform Temp_struct_Variable;  // 0x30(0x30)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x60(0x8)
	struct USceneCaptureComponent2D* CallFunc_AddComponent_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_Event_Unhide_Hide : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool K2Node_Event_SkipAnimation : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool K2Node_Event_TickWhileHidden : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool K2Node_Event_NonLocallyControlledOrBot : 1;  // 0x73(0x1)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool K2Node_Event_ShouldInterrupt : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x78(0x8)
	struct UPathfinder_FP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_FP_Anim_BP;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x8C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x90(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0xA8(0x8)
	struct UPathfinder_FP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_FP_Anim_BP_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0xC0(0x8)
	struct UPathfinder_FP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_FP_Anim_BP_3;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_4;  // 0xD8(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_5;  // 0xE0(0x8)
	struct UPathfinder_FP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_FP_Anim_BP_4;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct UPathfinder_FP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_FP_Anim_BP_5;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_6;  // 0x108(0x8)
	struct UPathfinder_FP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_FP_Anim_BP_6;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x120(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn_2;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_7;  // 0x138(0x8)
	struct UPathfinder_FP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_FP_Anim_BP_7;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x148(0x1)
	char pad_329[7];  // 0x149(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x159(0x1)
	char pad_346[6];  // 0x15A(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x160(0x8)
	struct TArray<struct UCameraComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x168(0x10)
	struct UCameraComponent* CallFunc_Array_Get_Item;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x180(0x1)
	char pad_385[3];  // 0x181(0x3)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x184(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x20C(0x88)
	char pad_660_1 : 7;  // 0x294(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x294(0x1)
	char pad_661_1 : 7;  // 0x295(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x295(0x1)
	char pad_662[2];  // 0x296(0x2)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x298(0x10)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x2AA(0x1)
	char pad_683[5];  // 0x2AB(0x5)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue_2;  // 0x2B0(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x2B8(0x8)

}; 
// Function BP_Gadget_FP_Pathfinder.BP_Gadget_FP_Pathfinder_C.GetComponents
// Size: 0x20(Inherited: 0x10) 
struct FGetComponents : public FGetComponents
{
	struct TArray<struct USceneComponent*> Components;  // 0x0(0x10)
	struct TArray<struct USceneComponent*> K2Node_MakeArray_Array;  // 0x10(0x10)

}; 
// Function BP_Gadget_FP_Pathfinder.BP_Gadget_FP_Pathfinder_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Gadget_FP_Pathfinder.BP_Gadget_FP_Pathfinder_C.GetSkeletalMesh
// Size: 0x8(Inherited: 0x8) 
struct FGetSkeletalMesh : public FGetSkeletalMesh
{
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x0(0x8)

}; 
// Function BP_Gadget_FP_Pathfinder.BP_Gadget_FP_Pathfinder_C.UpdateVisibility
// Size: 0x5(Inherited: 0x5) 
struct FUpdateVisibility : public FUpdateVisibility
{
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Hide : 1;  // 0x0(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool SkipAnimation : 1;  // 0x1(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool TickWhileHidden : 1;  // 0x2(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool NonLocallyControlledOrBot : 1;  // 0x3(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ShouldInterrupt : 1;  // 0x4(0x1)

}; 
