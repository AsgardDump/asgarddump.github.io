#pragma once 
#include <AN_SavedStats_Structs.h>
 
 
 
// BlueprintGeneratedClass AN_SavedStats.AN_SavedStats_C
// Size: 0x80(Inherited: 0x28) 
struct UAN_SavedStats_C : public USaveGame
{
	int32_t TotalGhostsDestroyed;  // 0x28(0x4)
	int32_t GamesWon_Ghost;  // 0x2C(0x4)
	int32_t GamesWon_Hunter;  // 0x30(0x4)
	int32_t Level;  // 0x34(0x4)
	int32_t EXPNeededForNextLevel;  // 0x38(0x4)
	int32_t EXPCurrent;  // 0x3C(0x4)
	struct FMapWinrateStruct Map Winrate Data;  // 0x40(0x3C)
	int32_t Matches Played;  // 0x7C(0x4)

}; 



