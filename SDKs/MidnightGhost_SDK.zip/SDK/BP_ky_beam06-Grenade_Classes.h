#pragma once 
#include <BP_ky_beam06-Grenade_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C
// Size: 0x304(Inherited: 0x2D0) 
struct ABP_ky_beam06-Grenade_C : public ABP_ky_beam01_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2D0(0x8)
	struct FLinearColor colorSub;  // 0x2D8(0x10)
	struct UAudioComponent* MyLaserSound1;  // 0x2E8(0x8)
	struct UAudioComponent* MyLaserSound2;  // 0x2F0(0x8)
	struct AActor* OwningActor;  // 0x2F8(0x8)
	float NEW_MaxDistance;  // 0x300(0x4)

	void LoS_Check(struct AActor* Origin, struct AActor* Target, bool& Line of Sight?); // Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.LoS_Check
	void UserConstructionScript(); // Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.UserConstructionScript
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.ReceiveEndPlay
	void ReceiveBeginPlay(); // Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.ReceiveTick
	void ExecuteUbergraph_BP_ky_beam06-Grenade(int32_t EntryPoint); // Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.ExecuteUbergraph_BP_ky_beam06-Grenade
}; 



