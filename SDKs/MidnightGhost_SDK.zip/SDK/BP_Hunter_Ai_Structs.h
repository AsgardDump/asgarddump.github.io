#pragma once 
#include "SDK.h" 
 
 
// Function BP_Hunter_Ai.BP_Hunter_Ai_C.ExecuteUbergraph_BP_Hunter_Ai
// Size: 0xF0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Hunter_Ai
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AMGH_PlayerState_C*> K2Node_CustomEvent_Shards;  // 0x8(0x10)
	struct AMGH_PlayerState_C* K2Node_DynamicCast_AsMGH_Player_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char EMovementMode K2Node_Event_PrevMovementMode;  // 0x21(0x1)
	char EMovementMode K2Node_Event_NewMovementMode;  // 0x22(0x1)
	char K2Node_Event_PrevCustomMode;  // 0x23(0x1)
	char K2Node_Event_NewCustomMode;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x28(0x8)
	struct AAIController* K2Node_DynamicCast_AsAIController;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FHitResult K2Node_Event_Hit;  // 0x3C(0x88)
	char pad_196[4];  // 0xC4(0x4)
	struct UPathFollowingComponent* CallFunc_GetPathFollowingComponent_ReturnValue;  // 0xC8(0x8)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0xD0(0x8)
	struct AAIController* K2Node_DynamicCast_AsAIController_2;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct UPathFollowingComponent* CallFunc_GetPathFollowingComponent_ReturnValue_2;  // 0xE8(0x8)

}; 
// Function BP_Hunter_Ai.BP_Hunter_Ai_C.BotChangeLoadoutAtGenerator
// Size: 0x4(Inherited: 0xA0) 
struct FBotChangeLoadoutAtGenerator : public FBotChangeLoadoutAtGenerator
{
	char HunterGadgets New Weapon;  // 0x0(0x1)
	char HunterGadgets New Gadget;  // 0x1(0x1)
	char HunterPerks New Perk;  // 0x2(0x1)
	char pad_163_1 : 7;  // 0xA3(0x1)
	bool Van Switch? : 1;  // 0x3(0x1)

}; 
// Function BP_Hunter_Ai.BP_Hunter_Ai_C.K2_OnMovementModeChanged
// Size: 0x4(Inherited: 0x4) 
struct FK2_OnMovementModeChanged : public FK2_OnMovementModeChanged
{
	char EMovementMode PrevMovementMode;  // 0x0(0x1)
	char EMovementMode NewMovementMode;  // 0x1(0x1)
	char PrevCustomMode;  // 0x2(0x1)
	char NewCustomMode;  // 0x3(0x1)

}; 
// Function BP_Hunter_Ai.BP_Hunter_Ai_C.OnLanded
// Size: 0x88(Inherited: 0x88) 
struct FOnLanded : public FOnLanded
{
	struct FHitResult Hit;  // 0x0(0x88)

}; 
// Function BP_Hunter_Ai.BP_Hunter_Ai_C.SetVacuumedShardsCarried
// Size: 0x10(Inherited: 0x0) 
struct FSetVacuumedShardsCarried
{
	struct TArray<struct AMGH_PlayerState_C*> shards;  // 0x0(0x10)

}; 
// Function BP_Hunter_Ai.BP_Hunter_Ai_C.HasMeleeWeaponEquipped
// Size: 0x4(Inherited: 0x0) 
struct FHasMeleeWeaponEquipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewParam : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x3(0x1)

}; 
