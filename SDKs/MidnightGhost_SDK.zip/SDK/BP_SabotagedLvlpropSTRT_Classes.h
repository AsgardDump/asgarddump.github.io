#pragma once 
#include <BP_SabotagedLvlpropSTRT_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SabotagedLvlpropSTRT.BP_SabotagedLvlpropSTRT_C
// Size: 0x270(Inherited: 0x220) 
struct ABP_SabotagedLvlpropSTRT_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* Niagara;  // 0x228(0x8)
	struct UParticleSystemComponent* P_SmokeVortexG;  // 0x230(0x8)
	struct UAudioComponent* Wraith_SabotageComplete;  // 0x238(0x8)
	struct UParticleSystemComponent* PS_Arcs_Omni;  // 0x240(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x248(0x8)
	struct TArray<struct ABP_Hunter_C*> Hunters Raycasted;  // 0x250(0x10)
	struct TArray<struct ABP_Trap_C*> Traps Raycasted;  // 0x260(0x10)

	void ReceiveBeginPlay(); // Function BP_SabotagedLvlpropSTRT.BP_SabotagedLvlpropSTRT_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_SabotagedLvlpropSTRT(int32_t EntryPoint); // Function BP_SabotagedLvlpropSTRT.BP_SabotagedLvlpropSTRT_C.ExecuteUbergraph_BP_SabotagedLvlpropSTRT
}; 



