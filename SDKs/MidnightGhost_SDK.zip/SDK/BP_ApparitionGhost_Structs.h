#pragma once 
#include "SDK.h" 
 
 
// Function BP_ApparitionGhost.BP_ApparitionGhost_C.EnemyPingable?
// Size: 0x3(Inherited: 0x0) 
struct FEnemyPingable?
{
	char Team My Team;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Pingable : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function BP_ApparitionGhost.BP_ApparitionGhost_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_ApparitionGhost.BP_ApparitionGhost_C.ExecuteUbergraph_BP_ApparitionGhost
// Size: 0x2B4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ApparitionGhost
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue;  // 0x8(0x10)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x24(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x2C(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x30(0x4)
	char pad_52[12];  // 0x34(0xC)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x40(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x70(0x8)
	struct ARnDGhostDissolve_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x78(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x80(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x8C(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x90(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x98(0x8)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0xA8(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0xC0(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0xD4(0x4)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0xE0(0x8)
	char CallFunc_MakeLiteralByte_ReturnValue_2;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0xEC(0x4)
	struct TArray<struct FName> CallFunc_GetAllSocketNames_ReturnValue;  // 0xF0(0x10)
	struct UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue;  // 0x100(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)
	struct UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue_2;  // 0x110(0x8)
	int32_t CallFunc_RandomInteger_ReturnValue;  // 0x118(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x11C(0x4)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x120(0xC)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x12C(0x4)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_SetupGhostMesh_Success : 1;  // 0x131(0x1)
	char pad_306[6];  // 0x132(0x6)
	struct TArray<struct UMaterialInstanceDynamic*> CallFunc_SetupGhostMesh_Materials;  // 0x138(0x10)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item;  // 0x148(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x150(0x4)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue_2;  // 0x154(0x10)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x164(0x1)
	char pad_357[3];  // 0x165(0x3)
	struct ACharacter* K2Node_CustomEvent_Owner;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_CustomEvent_Local : 1;  // 0x170(0x1)
	char pad_369[15];  // 0x171(0xF)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x180(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x1B0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x1BC(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x1C8(0xC)
	float CallFunc_BreakVector_X;  // 0x1D4(0x4)
	float CallFunc_BreakVector_Y;  // 0x1D8(0x4)
	float CallFunc_BreakVector_Z;  // 0x1DC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1E0(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x1E4(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x1F0(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x1FC(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x200(0x4)
	char pad_516[12];  // 0x204(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x210(0x30)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x240(0x4)
	char pad_580[4];  // 0x244(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x248(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_3;  // 0x250(0x8)
	struct ABP_EctoplasmTrail_LocalClient_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x258(0x8)
	struct ABP_EctoplasmTrail_C* CallFunc_FinishSpawningActor_ReturnValue_3;  // 0x260(0x8)
	float CallFunc_Vector_HeadingAngle_ReturnValue;  // 0x268(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x26C(0x4)
	float CallFunc_RadiansToDegrees_ReturnValue;  // 0x270(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x274(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item_2;  // 0x280(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x288(0x4)
	char pad_652_1 : 7;  // 0x28C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x28C(0x1)
	char pad_653_1 : 7;  // 0x28D(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x28D(0x1)
	char pad_654[2];  // 0x28E(0x2)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item_3;  // 0x290(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x298(0x4)
	struct FLinearColor CallFunc_K2_GetVectorParameterValue_ReturnValue;  // 0x29C(0x10)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x2AC(0x1)
	char pad_685[3];  // 0x2AD(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x2B0(0x4)

}; 
// Function BP_ApparitionGhost.BP_ApparitionGhost_C.NR_SpawnEctoplasmTrail
// Size: 0x9(Inherited: 0x0) 
struct FNR_SpawnEctoplasmTrail
{
	struct ACharacter* Owner;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Local : 1;  // 0x8(0x1)

}; 
// Function BP_ApparitionGhost.BP_ApparitionGhost_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_ApparitionGhost.BP_ApparitionGhost_C.CheckIfGoRed
// Size: 0x11(Inherited: 0x0) 
struct FCheckIfGoRed
{
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x0(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_ApparitionGhost.BP_ApparitionGhost_C.GetEctoBuildup
// Size: 0xA(Inherited: 0x0) 
struct FGetEctoBuildup
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Prop? : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Radiation;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Sensitive? : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Midnight Form? : 1;  // 0x9(0x1)

}; 
