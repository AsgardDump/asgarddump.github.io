#pragma once 
#include <BP_HunterVehicle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HunterVehicle.BP_HunterVehicle_C
// Size: 0x6FD(Inherited: 0x4C0) 
struct ABP_HunterVehicle_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UChildActorComponent* BoomboxActor;  // 0x4C8(0x8)
	struct USkeletalMeshComponent* Wheel01;  // 0x4D0(0x8)
	struct USkeletalMeshComponent* Wheel04;  // 0x4D8(0x8)
	struct USkeletalMeshComponent* Wheel03;  // 0x4E0(0x8)
	struct USkeletalMeshComponent* Wheel02;  // 0x4E8(0x8)
	struct USceneComponent* WheelRoot;  // 0x4F0(0x8)
	struct UAudioComponent* VanRadio;  // 0x4F8(0x8)
	struct UAudioComponent* Van_Engine;  // 0x500(0x8)
	struct UAudioComponent* Van_Ambience_Main;  // 0x508(0x8)
	struct USceneComponent* Seat07;  // 0x510(0x8)
	struct USpotLightComponent* Headlight2;  // 0x518(0x8)
	struct USpotLightComponent* Headlight1;  // 0x520(0x8)
	struct UAudioComponent* Van_Ambience_Equipment_01;  // 0x528(0x8)
	struct UArrowComponent* Forward;  // 0x530(0x8)
	struct UArrowComponent* NextBusSpawnPoint;  // 0x538(0x8)
	struct UArrowComponent* Backward;  // 0x540(0x8)
	struct USceneComponent* Seat06;  // 0x548(0x8)
	struct USceneComponent* Seat05;  // 0x550(0x8)
	struct USceneComponent* Seat04;  // 0x558(0x8)
	struct USceneComponent* Seat03;  // 0x560(0x8)
	struct USceneComponent* Seat02;  // 0x568(0x8)
	struct USceneComponent* Seat01;  // 0x570(0x8)
	struct USceneComponent* RootBody;  // 0x578(0x8)
	struct UAudioComponent* Van_Ambience_Equipment_02;  // 0x580(0x8)
	struct UAudioComponent* Van_Ambience_Suspension;  // 0x588(0x8)
	struct UAudioComponent* Van_Ambience_Shake;  // 0x590(0x8)
	float SlowDown_Slowdown_EE6ADB05426AF45288221185BE493A7C;  // 0x598(0x4)
	char ETimelineDirection SlowDown__Direction_EE6ADB05426AF45288221185BE493A7C;  // 0x59C(0x1)
	char pad_1437[3];  // 0x59D(0x3)
	struct UTimelineComponent* SlowDown;  // 0x5A0(0x8)
	int32_t SeatsAvailable?;  // 0x5A8(0x4)
	char pad_1452_1 : 7;  // 0x5AC(0x1)
	bool Full? : 1;  // 0x5AC(0x1)
	char pad_1453[3];  // 0x5AD(0x3)
	struct USceneComponent* NextSeatAvailable;  // 0x5B0(0x8)
	int32_t NextSeatAvailable-Number;  // 0x5B8(0x4)
	struct FRotator Target_Rotation;  // 0x5BC(0xC)
	struct FVector Target_Location;  // 0x5C8(0xC)
	char pad_1492_1 : 7;  // 0x5D4(0x1)
	bool Seat01-Filled : 1;  // 0x5D4(0x1)
	char pad_1493_1 : 7;  // 0x5D5(0x1)
	bool Seat02-Filled : 1;  // 0x5D5(0x1)
	char pad_1494_1 : 7;  // 0x5D6(0x1)
	bool Seat03-Filled : 1;  // 0x5D6(0x1)
	char pad_1495_1 : 7;  // 0x5D7(0x1)
	bool Seat04-Filled : 1;  // 0x5D7(0x1)
	char pad_1496_1 : 7;  // 0x5D8(0x1)
	bool Seat05-Filled : 1;  // 0x5D8(0x1)
	char pad_1497_1 : 7;  // 0x5D9(0x1)
	bool Seat06-Filled : 1;  // 0x5D9(0x1)
	char pad_1498[2];  // 0x5DA(0x2)
	struct FRotator NR_MyRotation;  // 0x5DC(0xC)
	struct ABP_VanStoppingPoint_C* StoppingPoint;  // 0x5E8(0x8)
	float LastScaleValue;  // 0x5F0(0x4)
	float VanCamSpeed;  // 0x5F4(0x4)
	int32_t Song Chosen;  // 0x5F8(0x4)
	float How Long Has Van Existed?;  // 0x5FC(0x4)
	struct FTimerHandle RandomSpookSounds;  // 0x600(0x8)
	char pad_1544_1 : 7;  // 0x608(0x1)
	bool Seat07-Filled : 1;  // 0x608(0x1)
	char GameModeTypeEnum GameMode;  // 0x609(0x1)
	char pad_1546_1 : 7;  // 0x60A(0x1)
	bool InterpSpeedDown : 1;  // 0x60A(0x1)
	char pad_1547[1];  // 0x60B(0x1)
	float Pre Max Walk Speed;  // 0x60C(0x4)
	struct TArray<int32_t> SeatAnimations;  // 0x610(0x10)
	struct FMulticastInlineDelegate RideInBumpAnimationEventDispatcher;  // 0x620(0x10)
	struct TArray<struct ABP_Hunter_C*> SeatedHunters;  // 0x630(0x10)
	struct TMap<char HunterGadgets, bool> GadgetHasVanIdle;  // 0x640(0x50)
	struct TArray<struct FVanIdleGadgetBooker> SeatAnimationGadgetBooker;  // 0x690(0x10)
	char pad_1696_1 : 7;  // 0x6A0(0x1)
	bool HasArrived : 1;  // 0x6A0(0x1)
	char pad_1697[3];  // 0x6A1(0x3)
	float Delta Seconds;  // 0x6A4(0x4)
	struct ABP_HunterVehicle_Path_C* PathToFollow;  // 0x6A8(0x8)
	float VanDistanceTraveled;  // 0x6B0(0x4)
	struct FVector CurrentPathLocation;  // 0x6B4(0xC)
	struct FRotator CurrentPathRotationLocal;  // 0x6C0(0xC)
	float VanTimeTravelled;  // 0x6CC(0x4)
	float VanTargetTravelTime;  // 0x6D0(0x4)
	char pad_1748_1 : 7;  // 0x6D4(0x1)
	bool PathInitiated : 1;  // 0x6D4(0x1)
	char pad_1749[3];  // 0x6D5(0x3)
	float CurrentVanSpeed;  // 0x6D8(0x4)
	struct FRotator CurrentPathRotationWorld;  // 0x6DC(0xC)
	int32_t LastPassedSplinePoint;  // 0x6E8(0x4)
	float SpeedMultBasedOnSlowDowns;  // 0x6EC(0x4)
	struct ULevelStreamingDynamic* RideInLevel;  // 0x6F0(0x8)
	char pad_1784_1 : 7;  // 0x6F8(0x1)
	bool RideInStreamingDisabled : 1;  // 0x6F8(0x1)
	char MGHMusicTracks CurrentBoomboxSong;  // 0x6F9(0x1)
	char pad_1786_1 : 7;  // 0x6FA(0x1)
	bool BoomboxSet : 1;  // 0x6FA(0x1)
	char pad_1787_1 : 7;  // 0x6FB(0x1)
	bool PlayingBoombox : 1;  // 0x6FB(0x1)
	char MGHMusicTracks PlayingBoomboxSong;  // 0x6FC(0x1)

	void GetVanMusicStatus_Int(bool& IsSongPlaying, char MGHMusicTracks& SongPlaying); // Function BP_HunterVehicle.BP_HunterVehicle_C.GetVanMusicStatus_Int
	void OnRep_CurrentBoomboxSong(); // Function BP_HunterVehicle.BP_HunterVehicle_C.OnRep_CurrentBoomboxSong
	void UnloadRideIn(); // Function BP_HunterVehicle.BP_HunterVehicle_C.UnloadRideIn
	void LoadRideIn(); // Function BP_HunterVehicle.BP_HunterVehicle_C.LoadRideIn
	void CalculateSpeedBoostBasedOnSlowDowns(float& SpeedBoost); // Function BP_HunterVehicle.BP_HunterVehicle_C.CalculateSpeedBoostBasedOnSlowDowns
	void MoveVanAlongPath(); // Function BP_HunterVehicle.BP_HunterVehicle_C.MoveVanAlongPath
	void CalculateTargetSpeed(float EndStoppingDistance, float& s); // Function BP_HunterVehicle.BP_HunterVehicle_C.CalculateTargetSpeed
	void InitiatePathMovement(); // Function BP_HunterVehicle.BP_HunterVehicle_C.InitiatePathMovement
	void HasArrivedFunction(); // Function BP_HunterVehicle.BP_HunterVehicle_C.HasArrivedFunction
	void IsSeatGadgetApproved?(int32_t Seat, bool& Approved); // Function BP_HunterVehicle.BP_HunterVehicle_C.IsSeatGadgetApproved?
	void GadgetBookerCleanUp(); // Function BP_HunterVehicle.BP_HunterVehicle_C.GadgetBookerCleanUp
	void TryToBookGadgetIdle(char HunterGadgets& gadget To Book, int32_t SeatToBook, struct ABP_Hunter_C* Hunter, bool& Success); // Function BP_HunterVehicle.BP_HunterVehicle_C.TryToBookGadgetIdle
	void GadgetIdleBooker(); // Function BP_HunterVehicle.BP_HunterVehicle_C.GadgetIdleBooker
	void AssignAnimationsToSeats(); // Function BP_HunterVehicle.BP_HunterVehicle_C.AssignAnimationsToSeats
	void ReturnSeat(int32_t SeatNumber, struct USceneComponent*& Seat); // Function BP_HunterVehicle.BP_HunterVehicle_C.ReturnSeat
	void UserConstructionScript(); // Function BP_HunterVehicle.BP_HunterVehicle_C.UserConstructionScript
	void SlowDown__FinishedFunc(); // Function BP_HunterVehicle.BP_HunterVehicle_C.SlowDown__FinishedFunc
	void SlowDown__UpdateFunc(); // Function BP_HunterVehicle.BP_HunterVehicle_C.SlowDown__UpdateFunc
	void Play Random Spook Sound(); // Function BP_HunterVehicle.BP_HunterVehicle_C.Play Random Spook Sound
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_HunterVehicle.BP_HunterVehicle_C.ReceiveEndPlay
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_HunterVehicle.BP_HunterVehicle_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void AssignSeatAnimationsEvent(); // Function BP_HunterVehicle.BP_HunterVehicle_C.AssignSeatAnimationsEvent
	void MC_RideInBumpAnimation(); // Function BP_HunterVehicle.BP_HunterVehicle_C.MC_RideInBumpAnimation
	void Server_RideInBumpAnimation(); // Function BP_HunterVehicle.BP_HunterVehicle_C.Server_RideInBumpAnimation
	void RideIn(bool Arrived); // Function BP_HunterVehicle.BP_HunterVehicle_C.RideIn
	void VanUpdateBoomboxSong_Int(char MGHMusicTracks Song); // Function BP_HunterVehicle.BP_HunterVehicle_C.VanUpdateBoomboxSong_Int
	void StartPlayingBoomboxSong(); // Function BP_HunterVehicle.BP_HunterVehicle_C.StartPlayingBoomboxSong
	void Errr(); // Function BP_HunterVehicle.BP_HunterVehicle_C.Errr
	void ForcePlayBoombox(); // Function BP_HunterVehicle.BP_HunterVehicle_C.ForcePlayBoombox
	void FadeOutVanSounds(); // Function BP_HunterVehicle.BP_HunterVehicle_C.FadeOutVanSounds
	void Startup(struct ABP_HunterVehicle_C* BP_Van); // Function BP_HunterVehicle.BP_HunterVehicle_C.Startup
	void ReceiveTick(float DeltaSeconds); // Function BP_HunterVehicle.BP_HunterVehicle_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_HunterVehicle.BP_HunterVehicle_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_HunterVehicle(int32_t EntryPoint); // Function BP_HunterVehicle.BP_HunterVehicle_C.ExecuteUbergraph_BP_HunterVehicle
	void RideInBumpAnimationEventDispatcher__DelegateSignature(); // Function BP_HunterVehicle.BP_HunterVehicle_C.RideInBumpAnimationEventDispatcher__DelegateSignature
}; 



