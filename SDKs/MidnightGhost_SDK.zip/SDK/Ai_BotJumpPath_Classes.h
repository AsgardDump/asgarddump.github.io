#pragma once 
#include <Ai_BotJumpPath_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_BotJumpPath.Ai_BotJumpPath_C
// Size: 0x26C(Inherited: 0x220) 
struct AAi_BotJumpPath_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct ACharacter* Character;  // 0x230(0x8)
	struct FVector Start;  // 0x238(0xC)
	struct FVector Destination;  // 0x244(0xC)
	struct FVector JumpPeak;  // 0x250(0xC)
	float SplineLength;  // 0x25C(0x4)
	struct USplineComponent* Spline;  // 0x260(0x8)
	float MinJumpHeight;  // 0x268(0x4)

	void ReceiveBeginPlay(); // Function Ai_BotJumpPath.Ai_BotJumpPath_C.ReceiveBeginPlay
	void DebugJumpPath(); // Function Ai_BotJumpPath.Ai_BotJumpPath_C.DebugJumpPath
	void ExecuteUbergraph_Ai_BotJumpPath(int32_t EntryPoint); // Function Ai_BotJumpPath.Ai_BotJumpPath_C.ExecuteUbergraph_Ai_BotJumpPath
}; 



