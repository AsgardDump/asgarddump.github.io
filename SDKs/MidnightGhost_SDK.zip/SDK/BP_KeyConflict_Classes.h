#pragma once 
#include <BP_KeyConflict_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KeyConflict.BP_KeyConflict_C
// Size: 0x31(Inherited: 0x28) 
struct UBP_KeyConflict_C : public UObject
{
	struct UBP_KeyCombination_C* Conflicting Combination;  // 0x28(0x8)
	char EKeyConflict Conflict Type;  // 0x30(0x1)

}; 



