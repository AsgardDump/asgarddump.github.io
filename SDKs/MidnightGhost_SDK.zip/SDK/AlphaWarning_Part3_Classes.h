#pragma once 
#include <AlphaWarning_Part3_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AlphaWarning_Part3.AlphaWarning_Part3_C
// Size: 0x260(Inherited: 0x260) 
struct UAlphaWarning_Part3_C : public UUserWidget
{

}; 



