#pragma once 
#include <BlueprintableOnlineBeacons_Structs.h>
 
 
 
// Class BlueprintableOnlineBeacons.OnlineBeaconBlueprint
// Size: 0x2C0(Inherited: 0x2B0) 
struct AOnlineBeaconBlueprint : public AOnlineBeaconClient
{
	char pad_688[16];  // 0x2B0(0x10)

	void OnNetworkFailure(char ENetworkFailure FailureType); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnNetworkFailure
	void OnDisconnected(uint8_t  Reason); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnDisconnected
	void OnConnectionStateChanged(uint8_t  From, uint8_t  To); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnConnectionStateChanged
	void OnConnectionFailureBlueprint(); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnConnectionFailureBlueprint
	void OnConnectedBlueprint(); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnConnectedBlueprint
	void OnClientDisconnected(struct AOnlineBeaconBlueprint* Client); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnClientDisconnected
	void OnClientConnected(struct AOnlineBeaconBlueprint* Client); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnClientConnected
	uint8_t  GetConnectionStateBlueprint(); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.GetConnectionStateBlueprint
	struct TArray<struct AOnlineBeaconBlueprint*> GetConnectedClients(); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.GetConnectedClients
	void DisconnectClient(struct AOnlineBeaconBlueprint* Client); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.DisconnectClient
	void Disconnect(); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.Disconnect
	bool ConnectBySession(struct FBlueprintSessionResult& session); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.ConnectBySession
	bool ConnectByIP(struct FString Address); // Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.ConnectByIP
}; 



// Class BlueprintableOnlineBeacons.OnlineBeaconHostObjectDynamic
// Size: 0x250(Inherited: 0x248) 
struct AOnlineBeaconHostObjectDynamic : public AOnlineBeaconHostObject
{
	struct UChildActorComponent* Relay;  // 0x248(0x8)

}; 



// Class BlueprintableOnlineBeacons.OnlineBeaconsSettings
// Size: 0x48(Inherited: 0x28) 
struct UOnlineBeaconsSettings : public UObject
{
	int32_t ListenPort;  // 0x28(0x4)
	float InitialTimeout;  // 0x2C(0x4)
	float Timeout;  // 0x30(0x4)
	struct FName NetDriverClass;  // 0x34(0x8)
	struct FName NetDriverFallbackClass;  // 0x3C(0x8)
	char pad_68[4];  // 0x44(0x4)

}; 



// Class BlueprintableOnlineBeacons.OnlineBeaconSubsystem
// Size: 0x88(Inherited: 0x30) 
struct UOnlineBeaconSubsystem : public UWorldSubsystem
{
	struct TMap<AOnlineBeaconClient*, struct AOnlineBeaconHostObjectDynamic*> HostingBeacons;  // 0x30(0x50)
	struct AOnlineBeaconHost* HostBeacon;  // 0x80(0x8)

	void StopHostingBeacons(struct TArray<AOnlineBeaconClient*> Classes); // Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StopHostingBeacons
	void StopHostingBeacon(AOnlineBeaconClient* Class); // Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StopHostingBeacon
	void StartHostingBeacons(struct TArray<AOnlineBeaconClient*> Classes); // Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StartHostingBeacons
	void StartHostingBeacon(AOnlineBeaconClient* Class); // Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StartHostingBeacon
	bool IsHostingBeacon(AOnlineBeaconClient* Class); // Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.IsHostingBeacon
	int32_t GetListenPort(); // Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.GetListenPort
}; 



