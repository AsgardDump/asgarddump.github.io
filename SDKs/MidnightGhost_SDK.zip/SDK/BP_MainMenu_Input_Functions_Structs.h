#pragma once 
#include "SDK.h" 
 
 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetInputType
// Size: 0x2A(Inherited: 0x0) 
struct FGetInputType
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	uint8_t  InputType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x10(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	uint8_t  CallFunc_GetInputType_Int_Type;  // 0x29(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.UnbindOnInputTypeSwitched
// Size: 0x29(Inherited: 0x0) 
struct FUnbindOnInputTypeSwitched
{
	struct FDelegate Event;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x18(0x8)
	struct UMGH_GameInstance* K2Node_DynamicCast_AsMGH_Game_Instance;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.SetShowMouse
// Size: 0x29(Inherited: 0x0) 
struct FSetShowMouse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ShowMouse : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x10(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.SetRightInputType
// Size: 0x59(Inherited: 0x0) 
struct FSetRightInputType
{
	struct FKey InputKey;  // 0x0(0x18)
	struct UObject* WorldContextObject;  // 0x18(0x8)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FKey LastPressed_Key;  // 0x28(0x18)
	struct FKey CallFunc_FindInputType_LastPressed_Key;  // 0x40(0x18)
	uint8_t  CallFunc_FindInputType_InputType;  // 0x58(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetShowMouse
// Size: 0x2A(Inherited: 0x0) 
struct FGetShowMouse
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bShowMouse : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x10(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_GetShowMouse_ShouldShowMouse : 1;  // 0x29(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.SetInputType
// Size: 0x31(Inherited: 0x0) 
struct FSetInputType
{
	uint8_t  InputType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* WorldContextObject;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x18(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.BindOnInputTypeSwitched
// Size: 0x29(Inherited: 0x0) 
struct FBindOnInputTypeSwitched
{
	struct FDelegate Event;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x18(0x8)
	struct UMGH_GameInstance* K2Node_DynamicCast_AsMGH_Game_Instance;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.FindInputType
// Size: 0x5D(Inherited: 0x0) 
struct FFindInputType
{
	struct FKey InputKey;  // 0x0(0x18)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FKey LastPressed_Key;  // 0x20(0x18)
	uint8_t  InputType;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bHasFound : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct FKey LastPressedKey;  // 0x40(0x18)
	uint8_t  Input_Type;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Key_IsGamepadKey_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_Key_IsMouseButton_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_Key_IsKeyboardKey_ReturnValue : 1;  // 0x5B(0x1)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x5C(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetPC_InputDetect
// Size: 0x21(Inherited: 0x0) 
struct FGetPC_InputDetect
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct ABP_PC_InputDetect_C* AsPC Input Detect;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	struct ABP_PC_InputDetect_C* K2Node_DynamicCast_AsBP_PC_Input_Detect;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetGamepadKeys
// Size: 0x28(Inherited: 0x0) 
struct FGetGamepadKeys
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct TArray<struct FKey> GamepadKeys;  // 0x8(0x10)
	struct TArray<struct FKey> K2Node_MakeArray_Array;  // 0x18(0x10)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetMouseKeys
// Size: 0x28(Inherited: 0x0) 
struct FGetMouseKeys
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct TArray<struct FKey> MouseKeys;  // 0x8(0x10)
	struct TArray<struct FKey> K2Node_MakeArray_Array;  // 0x18(0x10)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetVRControllerKeys
// Size: 0x28(Inherited: 0x0) 
struct FGetVRControllerKeys
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct TArray<struct FKey> Oculus VR Keys;  // 0x8(0x10)
	struct TArray<struct FKey> K2Node_MakeArray_Array;  // 0x18(0x10)

}; 
// Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetUIMouseInfo
// Size: 0x15(Inherited: 0x0) 
struct FGetUIMouseInfo
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ShouldShowMouseInUI : 1;  // 0x8(0x1)
	uint8_t  ShouldLockMouseInUI;  // 0x9(0x1)
	uint8_t  Temp_byte_Variable;  // 0xA(0x1)
	uint8_t  CallFunc_GetInputType_InputType;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xE(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Select_Default : 1;  // 0x10(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x11(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x12(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0x13(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x14(0x1)

}; 
