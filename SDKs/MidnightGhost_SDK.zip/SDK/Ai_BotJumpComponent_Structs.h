#pragma once 
#include "SDK.h" 
 
 
// Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.ExecuteUbergraph_Ai_BotJumpComponent
// Size: 0x169(Inherited: 0x0) 
struct FExecuteUbergraph_Ai_BotJumpComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1B(0x1)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_Lerp_ReturnValue;  // 0x34(0x4)
	struct FVector CallFunc_GetTangentAtDistanceAlongSpline_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x44(0xC)
	float CallFunc_BreakVector_X;  // 0x50(0x4)
	float CallFunc_BreakVector_Y;  // 0x54(0x4)
	float CallFunc_BreakVector_Z;  // 0x58(0x4)
	struct FVector CallFunc_GetLocationAtDistanceAlongSpline_ReturnValue;  // 0x5C(0xC)
	float CallFunc_Abs_ReturnValue;  // 0x68(0x4)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x6C(0x88)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0xF8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xFC(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x100(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x104(0x4)
	float CallFunc_GetSplineLength_ReturnValue;  // 0x108(0x4)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x10C(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x118(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x11C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x120(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x124(0x4)
	float CallFunc_FInterpTo_Constant_ReturnValue;  // 0x128(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x12C(0xC)
	float CallFunc_FClamp_ReturnValue_2;  // 0x138(0x4)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x13C(0x1)
	char pad_317[3];  // 0x13D(0x3)
	struct AAi_BotJumpPath_C* K2Node_CustomEvent_JumpPath;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x148(0x1)
	char pad_329[7];  // 0x149(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x158(0x1)
	char pad_345[7];  // 0x159(0x7)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x168(0x1)

}; 
// Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.StartNewJump
// Size: 0x8(Inherited: 0x0) 
struct FStartNewJump
{
	struct AAi_BotJumpPath_C* JumpPath;  // 0x0(0x8)

}; 
// Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
