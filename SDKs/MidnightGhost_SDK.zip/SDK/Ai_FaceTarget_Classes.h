#pragma once 
#include <Ai_FaceTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_FaceTarget.Ai_FaceTarget_C
// Size: 0xDC(Inherited: 0xA8) 
struct UAi_FaceTarget_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector FocusTarget;  // 0xB0(0x28)
	float FocusTime;  // 0xD8(0x4)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_FaceTarget.Ai_FaceTarget_C.ReceiveExecuteAI
	void ReceiveAbortAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_FaceTarget.Ai_FaceTarget_C.ReceiveAbortAI
	void ExecuteUbergraph_Ai_FaceTarget(int32_t EntryPoint); // Function Ai_FaceTarget.Ai_FaceTarget_C.ExecuteUbergraph_Ai_FaceTarget
}; 



