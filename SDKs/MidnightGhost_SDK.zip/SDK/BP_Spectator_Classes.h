#pragma once 
#include <BP_Spectator_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Spectator.BP_Spectator_C
// Size: 0x688(Inherited: 0x4C0) 
struct ABP_Spectator_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UCineCameraComponent* CineCamera;  // 0x4C8(0x8)
	struct USpringArmComponent* SpringArm;  // 0x4D0(0x8)
	struct UCameraComponent* Camera;  // 0x4D8(0x8)
	struct UCameraComponent* Camera1;  // 0x4E0(0x8)
	float Timeline_1_NewTrack_0_A1596269467888B68806D892402A582F;  // 0x4E8(0x4)
	char ETimelineDirection Timeline_1__Direction_A1596269467888B68806D892402A582F;  // 0x4EC(0x1)
	char pad_1261[3];  // 0x4ED(0x3)
	struct UTimelineComponent* Timeline_2;  // 0x4F0(0x8)
	float Timeline_0_NewTrack_0_5764C65649EA0913A1E685BD3138E79A;  // 0x4F8(0x4)
	char ETimelineDirection Timeline_0__Direction_5764C65649EA0913A1E685BD3138E79A;  // 0x4FC(0x1)
	char pad_1277[3];  // 0x4FD(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x500(0x8)
	float InterpDOF_On_NewTrack_0_AB5190C7442FAF10ADEC88A7407BB8A4;  // 0x508(0x4)
	char ETimelineDirection InterpDOF_On__Direction_AB5190C7442FAF10ADEC88A7407BB8A4;  // 0x50C(0x1)
	char pad_1293[3];  // 0x50D(0x3)
	struct UTimelineComponent* InterpDOF_On;  // 0x510(0x8)
	char HunterSpec MySelected_HS;  // 0x518(0x1)
	char pad_1305_1 : 7;  // 0x519(0x1)
	bool InterpingToTarget? : 1;  // 0x519(0x1)
	char pad_1306[6];  // 0x51A(0x6)
	struct AActor* SpectatingActor;  // 0x520(0x8)
	char pad_1320_1 : 7;  // 0x528(0x1)
	bool SpectateCameraMode : 1;  // 0x528(0x1)
	char pad_1321[3];  // 0x529(0x3)
	float InterpSpeed;  // 0x52C(0x4)
	struct USpectator_UI_C* My_SpectatorUI;  // 0x530(0x8)
	int32_t CurrentPlayerNumber;  // 0x538(0x4)
	char GhostAbility MySelected_GS;  // 0x53C(0x1)
	char pad_1341[3];  // 0x53D(0x3)
	float MaxPickupDistance;  // 0x540(0x4)
	char pad_1348[4];  // 0x544(0x4)
	struct ABP_Hunter_C* C_TLooked_Hunter;  // 0x548(0x8)
	struct ABP_Hunter_C* C_TSelected_Hunter;  // 0x550(0x8)
	struct TArray<struct ABP_Hunter_C*> C_AllSelected_Hunters;  // 0x558(0x10)
	struct AProp_C* C_TLooked_Prop;  // 0x568(0x8)
	struct AProp_C* C_TSelected_Prop;  // 0x570(0x8)
	struct TArray<struct AProp_C*> C_AllSelected_Props;  // 0x578(0x10)
	struct AMGH_PlayerState_C* Spectating_CPS;  // 0x588(0x8)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool SpectatingABot? : 1;  // 0x590(0x1)
	char pad_1425[7];  // 0x591(0x7)
	struct ACharacter* BotSpectatingChar;  // 0x598(0x8)
	struct FString SpectatingBotName;  // 0x5A0(0x10)
	struct TArray<struct AActor*> LocalAllPlayersNBots;  // 0x5B0(0x10)
	struct ALvlProp_C* LookAt_LvlProp;  // 0x5C0(0x8)
	struct ALvlProp_C* Last_LookAtLvlProp;  // 0x5C8(0x8)
	char pad_1488_1 : 7;  // 0x5D0(0x1)
	bool LookingAtLVLProp? : 1;  // 0x5D0(0x1)
	char pad_1489_1 : 7;  // 0x5D1(0x1)
	bool MiniHauntCooldown : 1;  // 0x5D1(0x1)
	char pad_1490[2];  // 0x5D2(0x2)
	float Backward Axis Value;  // 0x5D4(0x4)
	float Right Axis Value;  // 0x5D8(0x4)
	char GhostAbility Stored_GhostSpec;  // 0x5DC(0x1)
	char pad_1501[3];  // 0x5DD(0x3)
	struct FString SpectatedDisplayName;  // 0x5E0(0x10)
	char pad_1520_1 : 7;  // 0x5F0(0x1)
	bool Can't Move Local : 1;  // 0x5F0(0x1)
	char pad_1521[3];  // 0x5F1(0x3)
	float MovementScale;  // 0x5F4(0x4)
	float TargetFOV;  // 0x5F8(0x4)
	float FocalDistance;  // 0x5FC(0x4)
	float FocalRegion;  // 0x600(0x4)
	float DOFScale;  // 0x604(0x4)
	char EDepthOfFieldMethod DOFMethod;  // 0x608(0x1)
	char pad_1545[3];  // 0x609(0x3)
	float NearTransition;  // 0x60C(0x4)
	float FarTransition;  // 0x610(0x4)
	float MaxBokehSize;  // 0x614(0x4)
	float Left Alt Speed;  // 0x618(0x4)
	char pad_1564[4];  // 0x61C(0x4)
	struct TArray<struct AMGH_PlayerState_C*> AllPlayers_CPS;  // 0x620(0x10)
	struct TArray<struct AMGH_PlayerState_C*> Ghosts_CPS;  // 0x630(0x10)
	struct TArray<struct AMGH_PlayerState_C*> Hunters_CPS;  // 0x640(0x10)
	float MouseSensitivity;  // 0x650(0x4)
	float FOVSetting;  // 0x654(0x4)
	float MotionBlurSetting;  // 0x658(0x4)
	char pad_1628_1 : 7;  // 0x65C(0x1)
	bool MouseInvertX : 1;  // 0x65C(0x1)
	char pad_1629_1 : 7;  // 0x65D(0x1)
	bool MouseInvertY : 1;  // 0x65D(0x1)
	char pad_1630[2];  // 0x65E(0x2)
	float MouseInputDivider;  // 0x660(0x4)
	char pad_1636[4];  // 0x664(0x4)
	struct UDamageLog_UI_C* DamageLogUI;  // 0x668(0x8)
	char pad_1648_1 : 7;  // 0x670(0x1)
	bool DamageLogUp : 1;  // 0x670(0x1)
	char pad_1649[7];  // 0x671(0x7)
	struct UBP_MGH_Instance_C* InputGameInstance;  // 0x678(0x8)
	struct AMGH_PlayerState_C* MGH Player State;  // 0x680(0x8)

	void GetInterpTargetVector(struct FVector& Vector Target, bool& Close To 0,0,0?); // Function BP_Spectator.BP_Spectator_C.GetInterpTargetVector
	void GetMGHPlayerState(struct AMGH_PlayerState_C*& MGH Player State); // Function BP_Spectator.BP_Spectator_C.GetMGHPlayerState
	void GetMyTeam(char Team& Team); // Function BP_Spectator.BP_Spectator_C.GetMyTeam
	void LoadMouseSettings(); // Function BP_Spectator.BP_Spectator_C.LoadMouseSettings
	void Get All CPS(struct TArray<struct AMGH_PlayerState_C*>& All, struct TArray<struct AMGH_PlayerState_C*>& Ghosts, struct TArray<struct AMGH_PlayerState_C*>& Hunters); // Function BP_Spectator.BP_Spectator_C.Get All CPS
	void InterpDOF_On__FinishedFunc(); // Function BP_Spectator.BP_Spectator_C.InterpDOF_On__FinishedFunc
	void InterpDOF_On__UpdateFunc(); // Function BP_Spectator.BP_Spectator_C.InterpDOF_On__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_Spectator.BP_Spectator_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Spectator.BP_Spectator_C.Timeline_0__UpdateFunc
	void Timeline_1__FinishedFunc(); // Function BP_Spectator.BP_Spectator_C.Timeline_1__FinishedFunc
	void Timeline_1__UpdateFunc(); // Function BP_Spectator.BP_Spectator_C.Timeline_1__UpdateFunc
	void InpActEvt_NumPadZero_K2Node_InputKeyEvent_25(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_NumPadZero_K2Node_InputKeyEvent_25
	void InpActEvt_Right_K2Node_InputKeyEvent_24(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Right_K2Node_InputKeyEvent_24
	void InpActEvt_RightAlt_K2Node_InputKeyEvent_23(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_RightAlt_K2Node_InputKeyEvent_23
	void InpActEvt_RightAlt_K2Node_InputKeyEvent_22(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_RightAlt_K2Node_InputKeyEvent_22
	void InpActEvt_Primary Fire_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Primary Fire_K2Node_InputActionEvent_2
	void InpActEvt_Alternate Fire_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Alternate Fire_K2Node_InputActionEvent_1
	void InpActEvt_LeftShift_K2Node_InputKeyEvent_21(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftShift_K2Node_InputKeyEvent_21
	void InpActEvt_LeftShift_K2Node_InputKeyEvent_20(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftShift_K2Node_InputKeyEvent_20
	void InpActEvt_RightShift_K2Node_InputKeyEvent_19(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_RightShift_K2Node_InputKeyEvent_19
	void InpActEvt_RightShift_K2Node_InputKeyEvent_18(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_RightShift_K2Node_InputKeyEvent_18
	void InpActEvt_LeftAlt_K2Node_InputKeyEvent_17(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftAlt_K2Node_InputKeyEvent_17
	void InpActEvt_LeftAlt_K2Node_InputKeyEvent_16(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftAlt_K2Node_InputKeyEvent_16
	void InpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_15(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_15
	void InpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_14(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_14
	void InpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_13(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_13
	void InpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_12(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_12
	void InpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_11(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_11
	void InpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_10(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_10
	void InpActEvt_Ctrl_Six_K2Node_InputKeyEvent_9(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Six_K2Node_InputKeyEvent_9
	void InpActEvt_Ctrl_Six_K2Node_InputKeyEvent_8(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Six_K2Node_InputKeyEvent_8
	void InpActEvt_Ctrl_Five_K2Node_InputKeyEvent_7(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Five_K2Node_InputKeyEvent_7
	void InpActEvt_Ctrl_Five_K2Node_InputKeyEvent_6(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Five_K2Node_InputKeyEvent_6
	void InpActEvt_Ctrl_Four_K2Node_InputKeyEvent_5(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Four_K2Node_InputKeyEvent_5
	void InpActEvt_Ctrl_Four_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Four_K2Node_InputKeyEvent_4
	void InpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_3
	void InpActEvt_Three_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_Three_K2Node_InputKeyEvent_2
	void InpActEvt_R_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_Spectator.BP_Spectator_C.InpActEvt_R_K2Node_InputKeyEvent_1
	void ReceiveBeginPlay(); // Function BP_Spectator.BP_Spectator_C.ReceiveBeginPlay
	void Set_SelectedHunterClass(char HunterSpec SelectedHunterSpec, struct ABP_DefaultSpectator_C* BPFS); // Function BP_Spectator.BP_Spectator_C.Set_SelectedHunterClass
	void Server_TeleportToNextGhost(struct ABP_DefaultSpectator_C* BPFS, struct TArray<struct AProp_C*>& All Ghosts, int32_t Index); // Function BP_Spectator.BP_Spectator_C.Server_TeleportToNextGhost
	void ReceiveTick(float DeltaSeconds); // Function BP_Spectator.BP_Spectator_C.ReceiveTick
	void Set_SelectedGhostClass(char GhostAbility SelectedGhostSpec, struct ABP_DefaultSpectator_C* BPFS); // Function BP_Spectator.BP_Spectator_C.Set_SelectedGhostClass
	void Toggle_SpectatingLock(bool On); // Function BP_Spectator.BP_Spectator_C.Toggle_SpectatingLock
	void OC_AddTip(); // Function BP_Spectator.BP_Spectator_C.OC_AddTip
	void TurnOffSpectatingLock(); // Function BP_Spectator.BP_Spectator_C.TurnOffSpectatingLock
	void NextSpectate(); // Function BP_Spectator.BP_Spectator_C.NextSpectate
	void OC_Startup_Spectator(); // Function BP_Spectator.BP_Spectator_C.OC_Startup_Spectator
	void ScanningRoutine_Bind(); // Function BP_Spectator.BP_Spectator_C.ScanningRoutine_Bind
	void SelectionRoutine(); // Function BP_Spectator.BP_Spectator_C.SelectionRoutine
	void SetDOFData(float Focal Distance, float Focal Region, float DOFScale, float NearTransition, float FarTransition, float MaxBokehSize, float PostProcessBlend, int32_t DOFMethod 0-2, bool UseCineCam, float MinFStop, float MaxFStop, float ManualFocusDistance); // Function BP_Spectator.BP_Spectator_C.SetDOFData
	void Continue(); // Function BP_Spectator.BP_Spectator_C.Continue
	void StartSpectatingAuto(); // Function BP_Spectator.BP_Spectator_C.StartSpectatingAuto
	void InpAxisEvt_Spectator Move Upward_K2Node_InputAxisEvent_3(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Spectator Move Upward_K2Node_InputAxisEvent_3
	void InpAxisEvt_Spectator Move Downward_K2Node_InputAxisEvent_4(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Spectator Move Downward_K2Node_InputAxisEvent_4
	void SetMotionBlur(float MotionBlur); // Function BP_Spectator.BP_Spectator_C.SetMotionBlur
	void SetCameraFOV(float FOV); // Function BP_Spectator.BP_Spectator_C.SetCameraFOV
	void SetMouseInvertX(bool Invert?); // Function BP_Spectator.BP_Spectator_C.SetMouseInvertX
	void SetMouseInvertY(bool Invert?); // Function BP_Spectator.BP_Spectator_C.SetMouseInvertY
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_48(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_48
	void InpAxisEvt_Look_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Look_K2Node_InputAxisEvent_2
	void InpAxisEvt_Move Right_K2Node_InputAxisEvent_62(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Right_K2Node_InputAxisEvent_62
	void InpAxisEvt_Move Left_K2Node_InputAxisEvent_81(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Left_K2Node_InputAxisEvent_81
	void InpAxisEvt_Move Backward_K2Node_InputAxisEvent_25(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Backward_K2Node_InputAxisEvent_25
	void InpAxisEvt_Move Forward_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Forward_K2Node_InputAxisEvent_2
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Spectator.BP_Spectator_C.ReceiveEndPlay
	void AiDebugSelectWhoToSpectate(struct AMGH_PlayerState_C* MGH Player State); // Function BP_Spectator.BP_Spectator_C.AiDebugSelectWhoToSpectate
	void Update Constrain Aspect Ratio(); // Function BP_Spectator.BP_Spectator_C.Update Constrain Aspect Ratio
	void ExecuteUbergraph_BP_Spectator(int32_t EntryPoint); // Function BP_Spectator.BP_Spectator_C.ExecuteUbergraph_BP_Spectator
}; 



