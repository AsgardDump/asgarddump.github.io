#pragma once 
#include "SDK.h" 
 
 
// Function BackToGhostForm_UI.BackToGhostForm_UI_C.ExecuteUbergraph_BackToGhostForm_UI
// Size: 0x178(Inherited: 0x0) 
struct FExecuteUbergraph_BackToGhostForm_UI
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString Temp_string_Variable;  // 0x8(0x10)
	struct FString Temp_string_Variable_2;  // 0x18(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x34(0x4)
	int32_t Temp_int_Variable;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FString K2Node_Select_Default;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x58(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x60(0x10)
	struct TScriptInterface<IMGH_UIHelpersInterface_C> K2Node_DynamicCast_AsMGH_UIHelpers_Interface;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_Find_Keybind_String_Found_ : 1;  // 0x81(0x1)
	char pad_130[6];  // 0x82(0x6)
	struct FString CallFunc_Find_Keybind_String_Key__with_brackets_;  // 0x88(0x10)
	struct UTexture2D* CallFunc_Find_Keybind_String_Key_Image;  // 0x98(0x8)
	struct TScriptInterface<IMGH_UIHelpersInterface_C> K2Node_DynamicCast_AsMGH_UIHelpers_Interface_2;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_Is_UI_Disabled__Result : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)
	struct FString CallFunc_LeftChop_ReturnValue;  // 0xB8(0x10)
	struct FString CallFunc_RightChop_ReturnValue;  // 0xC8(0x10)
	struct TScriptInterface<IMGH_UIHelpersInterface_C> K2Node_DynamicCast_AsMGH_UIHelpers_Interface_3;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xE8(0x1)
	uint8_t  K2Node_CustomEvent_InputType;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool CallFunc_Get_Key_Prompt_UIs_Disabled__Disabled : 1;  // 0xEA(0x1)
	char pad_235_1 : 7;  // 0xEB(0x1)
	bool K2Node_CustomEvent_Visible : 1;  // 0xEB(0x1)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xEC(0x4)
	struct TArray<struct USW_ButtonPrompt_C*> K2Node_MakeArray_Array;  // 0xF0(0x10)
	struct USW_ButtonPrompt_C* CallFunc_Array_Get_Item;  // 0x100(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x108(0x4)
	char pad_268_1 : 7;  // 0x10C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x110(0x4)
	float Temp_float_Variable;  // 0x114(0x4)
	float Temp_float_Variable_2;  // 0x118(0x4)
	float K2Node_Select_Default_2;  // 0x11C(0x4)
	struct TArray<struct UTextBlock*> K2Node_MakeArray_Array_2;  // 0x120(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x130(0x4)
	char pad_308[4];  // 0x134(0x4)
	struct UTextBlock* CallFunc_Array_Get_Item_2;  // 0x138(0x8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x140(0x1)
	char pad_321[7];  // 0x141(0x7)
	struct FText CallFunc_GetText_ReturnValue;  // 0x148(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x160(0x18)

}; 
// Function BackToGhostForm_UI.BackToGhostForm_UI_C.SetKeyPromptsVisible
// Size: 0x1(Inherited: 0x0) 
struct FSetKeyPromptsVisible
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Visible : 1;  // 0x0(0x1)

}; 
// Function BackToGhostForm_UI.BackToGhostForm_UI_C.InputTypeSwitched
// Size: 0x1(Inherited: 0x0) 
struct FInputTypeSwitched
{
	uint8_t  InputType;  // 0x0(0x1)

}; 
// Function BackToGhostForm_UI.BackToGhostForm_UI_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
