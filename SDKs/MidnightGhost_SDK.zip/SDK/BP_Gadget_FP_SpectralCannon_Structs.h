#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.ExecuteUbergraph_BP_Gadget_FP_SpectralCannon
// Size: 0x119(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget_FP_SpectralCannon
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool K2Node_Event_Unhide_Hide : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_Event_SkipAnimation : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool K2Node_Event_TickWhileHidden : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool K2Node_Event_NonLocallyControlledOrBot : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool K2Node_Event_ShouldInterrupt : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x30(0x8)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0x48(0x8)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_3;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_4;  // 0x60(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_5;  // 0x68(0x8)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_4;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_5;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x90(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_6;  // 0x98(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_6;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0xC0(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn_2;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_7;  // 0xD8(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_8;  // 0xE0(0x8)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_7;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_8;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool K2Node_CustomEvent_SC_CancelledFire : 1;  // 0x101(0x1)
	char pad_258_1 : 7;  // 0x102(0x1)
	bool K2Node_CustomEvent_SC_Cooldown : 1;  // 0x102(0x1)
	char pad_259_1 : 7;  // 0x103(0x1)
	bool K2Node_CustomEvent_Chargeup_Ocurring : 1;  // 0x103(0x1)
	float K2Node_CustomEvent_Cannon_Battery_Level;  // 0x104(0x4)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_9;  // 0x108(0x8)
	struct USpectralCannon_FP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_FP_Anim_BP_9;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x118(0x1)

}; 
// Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.SetWeaponData
// Size: 0x8(Inherited: 0x0) 
struct FSetWeaponData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool SC CancelledFire : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool SC Cooldown : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Chargeup Ocurring : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float Cannon Battery Level;  // 0x4(0x4)

}; 
// Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.GetComponents
// Size: 0x20(Inherited: 0x10) 
struct FGetComponents : public FGetComponents
{
	struct TArray<struct USceneComponent*> Components;  // 0x0(0x10)
	struct TArray<struct USceneComponent*> K2Node_MakeArray_Array;  // 0x10(0x10)

}; 
// Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.GetSkeletalMesh
// Size: 0x8(Inherited: 0x8) 
struct FGetSkeletalMesh : public FGetSkeletalMesh
{
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x0(0x8)

}; 
// Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.UpdateVisibility
// Size: 0x5(Inherited: 0x5) 
struct FUpdateVisibility : public FUpdateVisibility
{
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Hide : 1;  // 0x0(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool SkipAnimation : 1;  // 0x1(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool TickWhileHidden : 1;  // 0x2(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool NonLocallyControlledOrBot : 1;  // 0x3(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ShouldInterrupt : 1;  // 0x4(0x1)

}; 
