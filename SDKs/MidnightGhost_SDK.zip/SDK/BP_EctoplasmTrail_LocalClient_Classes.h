#pragma once 
#include <BP_EctoplasmTrail_LocalClient_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EctoplasmTrail_LocalClient.BP_EctoplasmTrail_LocalClient_C
// Size: 0x2E8(Inherited: 0x2E8) 
struct ABP_EctoplasmTrail_LocalClient_C : public ABP_EctoplasmTrail_C
{

}; 



