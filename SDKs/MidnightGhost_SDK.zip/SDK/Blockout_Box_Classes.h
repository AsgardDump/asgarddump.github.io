#pragma once 
#include <Blockout_Box_Structs.h>
 
 
 
// BlueprintGeneratedClass Blockout_Box.Blockout_Box_C
// Size: 0x2B1(Inherited: 0x270) 
struct ABlockout_Box_C : public ABlockoutToolsParent
{
	struct FVector BoxSize;  // 0x270(0xC)
	char pad_636_1 : 7;  // 0x27C(0x1)
	bool bRoundSize : 1;  // 0x27C(0x1)
	char pad_637[3];  // 0x27D(0x3)
	struct UStaticMesh* BlockoutBoxMesh;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool bUseGrid : 1;  // 0x288(0x1)
	char pad_649[3];  // 0x289(0x3)
	struct FLinearColor Color;  // 0x28C(0x10)
	char pad_668_1 : 7;  // 0x29C(0x1)
	bool bUseTopColor : 1;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct FLinearColor TopColor;  // 0x2A0(0x10)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Unwalkable : 1;  // 0x2B0(0x1)

	void AddBlockoutBox(); // Function Blockout_Box.Blockout_Box_C.AddBlockoutBox
	void UserConstructionScript(); // Function Blockout_Box.Blockout_Box_C.UserConstructionScript
}; 



