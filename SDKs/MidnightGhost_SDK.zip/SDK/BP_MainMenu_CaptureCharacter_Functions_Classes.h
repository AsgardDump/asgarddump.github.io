#pragma once 
#include <BP_MainMenu_CaptureCharacter_Functions_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MainMenu_CaptureCharacter_Functions.BP_MainMenu_CaptureCharacter_Functions_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_MainMenu_CaptureCharacter_Functions_C : public UBlueprintFunctionLibrary
{

	void DestroyCaptureCharacter(struct UObject* __WorldContext); // Function BP_MainMenu_CaptureCharacter_Functions.BP_MainMenu_CaptureCharacter_Functions_C.DestroyCaptureCharacter
	bool IsCaptureCharacterExisting(struct UObject* __WorldContext); // Function BP_MainMenu_CaptureCharacter_Functions.BP_MainMenu_CaptureCharacter_Functions_C.IsCaptureCharacterExisting
}; 



