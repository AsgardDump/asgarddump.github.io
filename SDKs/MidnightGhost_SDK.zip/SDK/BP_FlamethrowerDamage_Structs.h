#pragma once 
#include "SDK.h" 
 
 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.ExecuteUbergraph_BP_FlamethrowerDamage
// Size: 0x548(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FlamethrowerDamage
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UObject* K2Node_CustomEvent_Object;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TScriptInterface<IMiscHitActorInterface_C> K2Node_DynamicCast_AsMisc_Hit_Actor_Interface;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct ABP_PossesSpirit_C* K2Node_DynamicCast_AsBP_Posses_Spirit;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ABP_ApparitionGhost_C* K2Node_DynamicCast_AsBP_Apparition_Ghost;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct ABP_SpiritAbility_C* K2Node_DynamicCast_AsBP_Spirit_Ability;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8C(0xC)
	struct AMGH_PlayerState_C* CallFunc_GetMGHPlayerState_MGHPlayerState;  // 0x98(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_3;  // 0xA0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_3;  // 0xA8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_3;  // 0xB0(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_3;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0xBD(0x1)
	char pad_190[2];  // 0xBE(0x2)
	float K2Node_Event_DeltaSeconds;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_4;  // 0xC8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_4;  // 0xD0(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_4;  // 0xD8(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_4;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep_3 : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult_3;  // 0xE8(0x88)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x170(0x1)
	char pad_369_1 : 7;  // 0x171(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x171(0x1)
	char pad_370[2];  // 0x172(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x174(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x178(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x17C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x188(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x194(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x1A0(0xC)
	char pad_428[4];  // 0x1AC(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x1B0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x1B8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x1C0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x1C8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x1D0(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x1D4(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x1D8(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x1DC(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x1E8(0xC)
	char pad_500[4];  // 0x1F4(0x4)
	struct AMGH_PlayerState_C* CallFunc_Get_MGH_Player_State_CPS;  // 0x1F8(0x8)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0x200(0x8)
	struct AActor* K2Node_Event_Other;  // 0x208(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x210(0x8)
	char pad_536_1 : 7;  // 0x218(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x218(0x1)
	char pad_537[3];  // 0x219(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0x21C(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x228(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0x234(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0x240(0x88)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x2C8(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x2CC(0x4)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x2D0(0x1)
	char pad_721[3];  // 0x2D1(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x2D4(0x4)
	int32_t CallFunc_Array_Find_ReturnValue_2;  // 0x2D8(0x4)
	char pad_732[4];  // 0x2DC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x2E0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x2E8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x2F0(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x2F8(0x4)
	char pad_764_1 : 7;  // 0x2FC(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep_2 : 1;  // 0x2FC(0x1)
	char pad_765[3];  // 0x2FD(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult_2;  // 0x300(0x88)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x388(0x1)
	char pad_905_1 : 7;  // 0x389(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_2 : 1;  // 0x389(0x1)
	char pad_906_1 : 7;  // 0x38A(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_2 : 1;  // 0x38A(0x1)
	char pad_907[1];  // 0x38B(0x1)
	float CallFunc_BreakHitResult_Time_2;  // 0x38C(0x4)
	float CallFunc_BreakHitResult_Distance_2;  // 0x390(0x4)
	struct FVector CallFunc_BreakHitResult_Location_2;  // 0x394(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_2;  // 0x3A0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_2;  // 0x3AC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_2;  // 0x3B8(0xC)
	char pad_964[4];  // 0x3C4(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_2;  // 0x3C8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_2;  // 0x3D0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_2;  // 0x3D8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_2;  // 0x3E0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_2;  // 0x3E8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_2;  // 0x3EC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_2;  // 0x3F0(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_2;  // 0x3F4(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_2;  // 0x400(0xC)
	char pad_1036[4];  // 0x40C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x410(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x418(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x420(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x428(0x4)
	char pad_1068_1 : 7;  // 0x42C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x42C(0x1)
	char pad_1069[3];  // 0x42D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x430(0x88)
	char pad_1208_1 : 7;  // 0x4B8(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_3 : 1;  // 0x4B8(0x1)
	char pad_1209_1 : 7;  // 0x4B9(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_3 : 1;  // 0x4B9(0x1)
	char pad_1210[2];  // 0x4BA(0x2)
	float CallFunc_BreakHitResult_Time_3;  // 0x4BC(0x4)
	float CallFunc_BreakHitResult_Distance_3;  // 0x4C0(0x4)
	struct FVector CallFunc_BreakHitResult_Location_3;  // 0x4C4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_3;  // 0x4D0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_3;  // 0x4DC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_3;  // 0x4E8(0xC)
	char pad_1268[4];  // 0x4F4(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_3;  // 0x4F8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_3;  // 0x500(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_3;  // 0x508(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_3;  // 0x510(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_3;  // 0x518(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_3;  // 0x51C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_3;  // 0x520(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_3;  // 0x524(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_3;  // 0x530(0xC)
	char pad_1340_1 : 7;  // 0x53C(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x53C(0x1)
	char pad_1341[3];  // 0x53D(0x3)
	struct AActor* K2Node_CustomEvent_Target;  // 0x540(0x8)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.SpawnImpactVFX
// Size: 0x8(Inherited: 0x0) 
struct FSpawnImpactVFX
{
	struct AActor* Target;  // 0x0(0x8)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Box_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Box_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Box1_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Box1_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.ReceiveHit
// Size: 0xC8(Inherited: 0xC8) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x88)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BeginOverlapDamage
// Size: 0x8(Inherited: 0x0) 
struct FBeginOverlapDamage
{
	struct UObject* Object;  // 0x0(0x8)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.UserConstructionScript
// Size: 0x20(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_GetMaxSpeed_ReturnValue;  // 0x4(0x4)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x8(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x14(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x18(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1C(0x4)

}; 
// Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.GetProjectileOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetProjectileOwner
{
	struct ABP_Hunter_C* Hunter;  // 0x0(0x8)

}; 
