#pragma once 
#include "SDK.h" 
 
 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.SetCancel
// Size: 0x1(Inherited: 0x0) 
struct FSetCancel
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Cancel? : 1;  // 0x0(0x1)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.ActivateWidget__DelegateSignature
// Size: 0x90(Inherited: 0x0) 
struct FActivateWidget__DelegateSignature
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FS_SPS_IconSettings Settings;  // 0x10(0x80)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.AttachTo
// Size: 0x8(Inherited: 0x0) 
struct FAttachTo
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.UpdateWidgetState__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FUpdateWidgetState__DelegateSignature
{
	char E_SPS_Icon_AnimationState New;  // 0x0(0x1)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.ExecuteUbergraph_BP_SPS_WidgetActor
// Size: 0x43C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SPS_WidgetActor
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x8(0x8)
	struct UWBP_SPS_Icon_C* K2Node_DynamicCast_AsWBP_SPS_Icon;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x24(0x4)
	struct FVector K2Node_CustomEvent_Location;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)
	struct FS_SPS_IconSettings K2Node_CustomEvent_Settings;  // 0x38(0x80)
	struct APlayerState* K2Node_CustomEvent_PS_Owner;  // 0xB8(0x8)
	struct APlayerController* K2Node_CustomEvent_PC;  // 0xC0(0x8)
	char PingTypeEnum K2Node_CustomEvent_Ping_Type;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xCA(0x1)
	char pad_203_1 : 7;  // 0xCB(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xCB(0x1)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0xD0(0x10)
	struct FString CallFunc_Conv_VectorToString_ReturnValue;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0xF4(0x88)
	char pad_380_1 : 7;  // 0x17C(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x17C(0x1)
	char pad_381_1 : 7;  // 0x17D(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x17D(0x1)
	char pad_382_1 : 7;  // 0x17E(0x1)
	bool K2Node_CustomEvent_FORCE : 1;  // 0x17E(0x1)
	char pad_383_1 : 7;  // 0x17F(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x17F(0x1)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x180(0x8)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x188(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x190(0xC)
	struct FIntPoint CallFunc_GetScreenResolution_ReturnValue;  // 0x19C(0x8)
	struct FVector2D CallFunc_ProjectWorldToScreen_ScreenPosition;  // 0x1A4(0x8)
	char pad_428_1 : 7;  // 0x1AC(0x1)
	bool CallFunc_ProjectWorldToScreen_ReturnValue : 1;  // 0x1AC(0x1)
	char pad_429[3];  // 0x1AD(0x3)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x1B0(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_2;  // 0x1B4(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x1B8(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x1BC(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_3;  // 0x1C0(0x4)
	float CallFunc_BreakVector2D_X;  // 0x1C4(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x1C8(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_3;  // 0x1CC(0x4)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x1D0(0x1)
	char pad_465_1 : 7;  // 0x1D1(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_2 : 1;  // 0x1D1(0x1)
	char pad_466_1 : 7;  // 0x1D2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1D2(0x1)
	char pad_467[5];  // 0x1D3(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x1D8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1E0(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x1F0(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x1F8(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x208(0x1)
	char pad_521_1 : 7;  // 0x209(0x1)
	bool CallFunc_IsLocalPlayerController_ReturnValue : 1;  // 0x209(0x1)
	char pad_522_1 : 7;  // 0x20A(0x1)
	bool K2Node_CustomEvent_Cancel_ : 1;  // 0x20A(0x1)
	char pad_523_1 : 7;  // 0x20B(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x20B(0x1)
	char pad_524_1 : 7;  // 0x20C(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x20C(0x1)
	char pad_525[3];  // 0x20D(0x3)
	struct AActor* K2Node_CustomEvent_Actor;  // 0x210(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue_2;  // 0x218(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x228(0x10)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x238(0x4)
	char pad_572_1 : 7;  // 0x23C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct FString CallFunc_GetDisplayName_ReturnValue_3;  // 0x240(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x250(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x260(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x270(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0x280(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x288(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x298(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x2A8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_7;  // 0x2B8(0x10)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x2C8(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue_4;  // 0x2D0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_8;  // 0x2E0(0x10)
	struct TScriptInterface<IPropAbilityCheckerInterface_C> K2Node_DynamicCast_AsProp_Ability_Checker_Interface;  // 0x2F0(0x10)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x308(0x8)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool CallFunc_IsPhantomActive__IsPhantomActive : 1;  // 0x310(0x1)
	char pad_785[7];  // 0x311(0x7)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface;  // 0x318(0x10)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x328(0x1)
	char GameModeTypeEnum CallFunc_GetGameMode_Int_GameMode;  // 0x329(0x1)
	char pad_810_1 : 7;  // 0x32A(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x32A(0x1)
	char pad_811[1];  // 0x32B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x32C(0x10)
	char pad_828[4];  // 0x33C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_3;  // 0x340(0x8)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x348(0x1)
	char pad_841[3];  // 0x349(0x3)
	struct FS_SPS_IconAppearanceSettings K2Node_MakeStruct_S_SPS_IconAppearanceSettings;  // 0x34C(0x1C)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0x368(0x1)
	char pad_873_1 : 7;  // 0x369(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_5 : 1;  // 0x369(0x1)
	char pad_874_1 : 7;  // 0x36A(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_6 : 1;  // 0x36A(0x1)
	char pad_875_1 : 7;  // 0x36B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_7 : 1;  // 0x36B(0x1)
	char pad_876[4];  // 0x36C(0x4)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x370(0x8)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x378(0x1)
	char pad_889_1 : 7;  // 0x379(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_8 : 1;  // 0x379(0x1)
	char pad_890_1 : 7;  // 0x37A(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x37A(0x1)
	char pad_891_1 : 7;  // 0x37B(0x1)
	bool CallFunc_TryFindNewAttachActor_OK : 1;  // 0x37B(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x37C(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x380(0x8)
	struct FS_SPS_IconAnimationSettings K2Node_MakeStruct_S_SPS_IconAnimationSettings;  // 0x388(0x18)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x3A0(0x10)
	char pad_944_1 : 7;  // 0x3B0(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x3B0(0x1)
	char pad_945[7];  // 0x3B1(0x7)
	struct FS_SPS_IconSettings K2Node_MakeStruct_S_SPS_IconSettings;  // 0x3B8(0x80)
	float CallFunc_GetCamcorderDuration_Int_Duration;  // 0x438(0x4)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.Deactivate
// Size: 0x1(Inherited: 0x0) 
struct FDeactivate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Force : 1;  // 0x0(0x1)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.Activate
// Size: 0xA1(Inherited: 0x0) 
struct FActivate
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FS_SPS_IconSettings Settings;  // 0x10(0x80)
	struct APlayerState* PS Owner;  // 0x90(0x8)
	struct APlayerController* PC;  // 0x98(0x8)
	char PingTypeEnum Ping Type;  // 0xA0(0x1)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.UpdateWidgetPhase
// Size: 0x1(Inherited: 0x0) 
struct FUpdateWidgetPhase
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x0(0x1)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.UpdateScreenLocation
// Size: 0x165(Inherited: 0x0) 
struct FUpdateScreenLocation
{
	struct FVector Location;  // 0x0(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0xC(0x88)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x95(0x1)
	char pad_150[2];  // 0x96(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x98(0xC)
	float CallFunc_GetActorTickInterval_ReturnValue;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	float CallFunc_GetActorTickInterval_ReturnValue_2;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_2 : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool CallFunc_IsWorldLocationOffScreen_IsOffscreen : 1;  // 0xB2(0x1)
	char pad_179_1 : 7;  // 0xB3(0x1)
	bool CallFunc_CalculateWorldLocationToEdgeScreenPosition_IsOffscreen : 1;  // 0xB3(0x1)
	struct FVector2D CallFunc_CalculateWorldLocationToEdgeScreenPosition_ScreenLocation;  // 0xB4(0x8)
	float CallFunc_CalculateWorldLocationToEdgeScreenPosition_Rotation;  // 0xBC(0x4)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_2;  // 0xC0(0x88)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_2 : 1;  // 0x148(0x1)
	char pad_329[3];  // 0x149(0x3)
	struct FVector CallFunc_DeprojectScreenToWorld_WorldPosition;  // 0x14C(0xC)
	struct FVector CallFunc_DeprojectScreenToWorld_WorldDirection;  // 0x158(0xC)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_DeprojectScreenToWorld_ReturnValue : 1;  // 0x164(0x1)

}; 
// Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.TryFindNewAttachActor
// Size: 0x1B(Inherited: 0x0) 
struct FTryFindNewAttachActor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool OK : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct TScriptInterface<IPropInterface_C> K2Node_DynamicCast_AsProp_Interface;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x1A(0x1)

}; 
