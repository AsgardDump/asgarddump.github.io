#pragma once 
#include <BP_Hunter_Render_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_Render.BP_Hunter_Render_C
// Size: 0x2675(Inherited: 0x2658) 
struct ABP_Hunter_Render_C : public ABP_Hunter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2658(0x8)
	struct FString My ID;  // 0x2660(0x10)
	char HunterSkins My Skin;  // 0x2670(0x1)
	char pad_9841_1 : 7;  // 0x2671(0x1)
	bool Assigned? : 1;  // 0x2671(0x1)
	char pad_9842_1 : 7;  // 0x2672(0x1)
	bool Shown? : 1;  // 0x2672(0x1)
	char pad_9843_1 : 7;  // 0x2673(0x1)
	bool In-Game? : 1;  // 0x2673(0x1)
	char pad_9844_1 : 7;  // 0x2674(0x1)
	bool DisableLoadingOfSkin? : 1;  // 0x2674(0x1)

	void AssignCorrectColors_1(char HunterSpec Spec, char HunterSkins Skin, struct FLinearColor& 1, struct FLinearColor& 2, struct FLinearColor& 3, struct FLinearColor& 4); // Function BP_Hunter_Render.BP_Hunter_Render_C.AssignCorrectColors_1
	void Do We Need To Update?(struct FString ID, char HunterSkins Skin, bool& Update?); // Function BP_Hunter_Render.BP_Hunter_Render_C.Do We Need To Update?
	void ReceiveBeginPlay(); // Function BP_Hunter_Render.BP_Hunter_Render_C.ReceiveBeginPlay
	void UpdatePlayerInfo(struct FString Name, char MGH_Platform Platform, struct FString PUID Str, char HunterSkins Hunter Skin, bool Force Update, bool PartyLeader?, char Title, int32_t Raw Level); // Function BP_Hunter_Render.BP_Hunter_Render_C.UpdatePlayerInfo
	void HideHunter(); // Function BP_Hunter_Render.BP_Hunter_Render_C.HideHunter
	void ResetSkin(); // Function BP_Hunter_Render.BP_Hunter_Render_C.ResetSkin
	void ShowHunter(); // Function BP_Hunter_Render.BP_Hunter_Render_C.ShowHunter
	void FixLowRes(bool Fix); // Function BP_Hunter_Render.BP_Hunter_Render_C.FixLowRes
	void DeferredLoadSkin(bool WasSuccessful); // Function BP_Hunter_Render.BP_Hunter_Render_C.DeferredLoadSkin
	void ExecuteUbergraph_BP_Hunter_Render(int32_t EntryPoint); // Function BP_Hunter_Render.BP_Hunter_Render_C.ExecuteUbergraph_BP_Hunter_Render
}; 



