#pragma once 
#include <AudioSaveGame_Structs.h>
 
 
 
// BlueprintGeneratedClass AudioSaveGame.AudioSaveGame_C
// Size: 0x48(Inherited: 0x28) 
struct UAudioSaveGame_C : public USaveGame
{
	float MasterVolume;  // 0x28(0x4)
	float VoiceChatVolume;  // 0x2C(0x4)
	float MusicVolume;  // 0x30(0x4)
	float AmbienceVolume;  // 0x34(0x4)
	float MicrophoneVolume;  // 0x38(0x4)
	float PingVolume;  // 0x3C(0x4)
	float MasterVolume_v2;  // 0x40(0x4)
	float DialogueVolume;  // 0x44(0x4)

}; 



