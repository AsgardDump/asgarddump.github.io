#pragma once 
#include <BP_LiquidXMotion_FlameThrower_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C
// Size: 0x3A0(Inherited: 0x220) 
struct ABP_LiquidXMotion_FlameThrower_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Sage;  // 0x228(0x8)
	struct UStaticMeshComponent* FirstBigCrystal;  // 0x230(0x8)
	struct USceneComponent* CrystalSpawn;  // 0x238(0x8)
	struct UStaticMeshComponent* S_LiquidXContainer;  // 0x240(0x8)
	char ETimelineDirection Visibilitything__Direction_CC421D7447CD535B5129EA8A4E8301F4;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct UTimelineComponent* Visibilitything;  // 0x250(0x8)
	float SpinCrystals_EmissiveGlow_2B90C6724D557F2558A024AB8565DC9E;  // 0x258(0x4)
	float SpinCrystals_ColorFade_2B90C6724D557F2558A024AB8565DC9E;  // 0x25C(0x4)
	float SpinCrystals_Spin_2B90C6724D557F2558A024AB8565DC9E;  // 0x260(0x4)
	char ETimelineDirection SpinCrystals__Direction_2B90C6724D557F2558A024AB8565DC9E;  // 0x264(0x1)
	char pad_613[3];  // 0x265(0x3)
	struct UTimelineComponent* SpinCrystals;  // 0x268(0x8)
	float FirstChunkANimation_SageToSide_EA6AF7D6422339755A468AADE1ABFCB6;  // 0x270(0x4)
	float FirstChunkANimation_HeightSage_EA6AF7D6422339755A468AADE1ABFCB6;  // 0x274(0x4)
	float FirstChunkANimation_ToSide_EA6AF7D6422339755A468AADE1ABFCB6;  // 0x278(0x4)
	float FirstChunkANimation_Height_EA6AF7D6422339755A468AADE1ABFCB6;  // 0x27C(0x4)
	char ETimelineDirection FirstChunkANimation__Direction_EA6AF7D6422339755A468AADE1ABFCB6;  // 0x280(0x1)
	char pad_641[7];  // 0x281(0x7)
	struct UTimelineComponent* FirstChunkANimation;  // 0x288(0x8)
	struct FVector LastPos;  // 0x290(0xC)
	struct FVector CurrentPos;  // 0x29C(0xC)
	float DeltaTime;  // 0x2A8(0x4)
	float Velocity;  // 0x2AC(0x4)
	float Liquid_CooldownX;  // 0x2B0(0x4)
	char pad_692[4];  // 0x2B4(0x4)
	struct UMaterialInstanceDynamic* LiquidXMaterialInstance;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool SimulatePhysics : 1;  // 0x2C0(0x1)
	char pad_705[3];  // 0x2C1(0x3)
	float VelocityX;  // 0x2C4(0x4)
	float VelocityY;  // 0x2C8(0x4)
	float VelocityRawRange;  // 0x2CC(0x4)
	float LiquidCooldownVelocity;  // 0x2D0(0x4)
	float Liquid_CooldownY;  // 0x2D4(0x4)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool CooldownXorY : 1;  // 0x2D8(0x1)
	char pad_729[3];  // 0x2D9(0x3)
	float CooldownThreshold;  // 0x2DC(0x4)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool DebugRawVelocity? : 1;  // 0x2E0(0x1)
	char pad_737[3];  // 0x2E1(0x3)
	float LiquidCooldownTime;  // 0x2E4(0x4)
	float Cooldown_AlternateAxisMotionMultiplier;  // 0x2E8(0x4)
	char pad_748_1 : 7;  // 0x2EC(0x1)
	bool IsFP : 1;  // 0x2EC(0x1)
	char pad_749[3];  // 0x2ED(0x3)
	struct ABP_Hunter_C* MyHunter;  // 0x2F0(0x8)
	float SmoothAmmo;  // 0x2F8(0x4)
	struct FRotator ActorRotLastFrame;  // 0x2FC(0xC)
	float TimeAlive;  // 0x308(0x4)
	float HeadingPhysVelocity;  // 0x30C(0x4)
	float HeadingPhysCurrent;  // 0x310(0x4)
	float HeadingDelta;  // 0x314(0x4)
	float HeadingDeltaSmooth;  // 0x318(0x4)
	char pad_796[4];  // 0x31C(0x4)
	struct UCurveFloat* CurveFalloff;  // 0x320(0x8)
	float PitchPhysVelocity;  // 0x328(0x4)
	float PitchPhysCurrent;  // 0x32C(0x4)
	float PitchDelta;  // 0x330(0x4)
	float Pitch;  // 0x334(0x4)
	float PitchLastFrame;  // 0x338(0x4)
	struct FVector TransPhysVelocity;  // 0x33C(0xC)
	struct FVector TransPhysCurrent;  // 0x348(0xC)
	float ShaderMixer;  // 0x354(0x4)
	float MixingPannerSpeed;  // 0x358(0x4)
	float FillHeightVar;  // 0x35C(0x4)
	float CachedAmmoPercentageForMixing;  // 0x360(0x4)
	struct FFloatSpringState Spring State Centrifugal;  // 0x364(0x8)
	struct FFloatSpringState Spring State Pitch;  // 0x36C(0x8)
	struct FVectorSpringState Spring StateTranslation;  // 0x374(0x18)
	char pad_908[4];  // 0x38C(0x4)
	struct UNiagaraComponent* CrystalSystem1;  // 0x390(0x8)
	struct UNiagaraComponent* CrystalSystem2;  // 0x398(0x8)

	void UserConstructionScript(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.UserConstructionScript
	void Visibilitything__FinishedFunc(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.Visibilitything__FinishedFunc
	void Visibilitything__UpdateFunc(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.Visibilitything__UpdateFunc
	void SpinCrystals__FinishedFunc(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.SpinCrystals__FinishedFunc
	void SpinCrystals__UpdateFunc(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.SpinCrystals__UpdateFunc
	void FirstChunkANimation__FinishedFunc(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.FirstChunkANimation__FinishedFunc
	void FirstChunkANimation__UpdateFunc(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.FirstChunkANimation__UpdateFunc
	void MixCrystals(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.MixCrystals
	void ReceiveBeginPlay(); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.ReceiveTick
	void ExecuteUbergraph_BP_LiquidXMotion_FlameThrower(int32_t EntryPoint); // Function BP_LiquidXMotion_FlameThrower.BP_LiquidXMotion_FlameThrower_C.ExecuteUbergraph_BP_LiquidXMotion_FlameThrower
}; 



