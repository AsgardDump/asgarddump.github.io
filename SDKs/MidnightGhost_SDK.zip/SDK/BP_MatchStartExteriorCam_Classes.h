#pragma once 
#include <BP_MatchStartExteriorCam_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MatchStartExteriorCam.BP_MatchStartExteriorCam_C
// Size: 0x2D9(Inherited: 0x280) 
struct ABP_MatchStartExteriorCam_C : public APawn
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UCameraComponent* Camera;  // 0x288(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x290(0x8)
	char pad_664[8];  // 0x298(0x8)
	struct FTransform TargetTransform;  // 0x2A0(0x30)
	int32_t Stored_HunterSkin;  // 0x2D0(0x4)
	char HunterWeapon Hunter Weapon;  // 0x2D4(0x1)
	char HunterSpec Hunter Spec;  // 0x2D5(0x1)
	char HunterGadgets Hunter Gadget 1;  // 0x2D6(0x1)
	char HunterGadgets Hunter Gadget 2;  // 0x2D7(0x1)
	char HunterPerks Hunter Perk;  // 0x2D8(0x1)

	void ReceiveTick(float DeltaSeconds); // Function BP_MatchStartExteriorCam.BP_MatchStartExteriorCam_C.ReceiveTick
	void OC_Startup(); // Function BP_MatchStartExteriorCam.BP_MatchStartExteriorCam_C.OC_Startup
	void ExecuteUbergraph_BP_MatchStartExteriorCam(int32_t EntryPoint); // Function BP_MatchStartExteriorCam.BP_MatchStartExteriorCam_C.ExecuteUbergraph_BP_MatchStartExteriorCam
}; 



