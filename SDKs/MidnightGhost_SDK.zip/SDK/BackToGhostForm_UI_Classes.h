#pragma once 
#include <BackToGhostForm_UI_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BackToGhostForm_UI.BackToGhostForm_UI_C
// Size: 0x288(Inherited: 0x260) 
struct UBackToGhostForm_UI_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UTextBlock* AbilityText;  // 0x268(0x8)
	struct USW_ButtonPrompt_C* SW_ButtonPrompt_Reorient;  // 0x270(0x8)
	struct USW_ButtonPrompt_C* SW_ButtonPrompt_ReturnGhost;  // 0x278(0x8)
	struct UTextBlock* TextBlock_1;  // 0x280(0x8)

	void PreConstruct(bool IsDesignTime); // Function BackToGhostForm_UI.BackToGhostForm_UI_C.PreConstruct
	void Construct(); // Function BackToGhostForm_UI.BackToGhostForm_UI_C.Construct
	void InputTypeSwitched(uint8_t  InputType); // Function BackToGhostForm_UI.BackToGhostForm_UI_C.InputTypeSwitched
	void SetKeyPromptsVisible(bool Visible); // Function BackToGhostForm_UI.BackToGhostForm_UI_C.SetKeyPromptsVisible
	void ExecuteUbergraph_BackToGhostForm_UI(int32_t EntryPoint); // Function BackToGhostForm_UI.BackToGhostForm_UI_C.ExecuteUbergraph_BackToGhostForm_UI
}; 



