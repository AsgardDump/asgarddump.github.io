#pragma once 
#include <BP_DestroyedSensor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DestroyedSensor.BP_DestroyedSensor_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_DestroyedSensor_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDestructibleComponent* Destructible;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void ReceiveBeginPlay(); // Function BP_DestroyedSensor.BP_DestroyedSensor_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_DestroyedSensor(int32_t EntryPoint); // Function BP_DestroyedSensor.BP_DestroyedSensor_C.ExecuteUbergraph_BP_DestroyedSensor
}; 



