#pragma once 
#include <BP_Hunter_Doppelganger_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C
// Size: 0x2680(Inherited: 0x2658) 
struct ABP_Hunter_Doppelganger_C : public ABP_Hunter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2658(0x8)
	struct UNiagaraComponent* NiagaraSpawn;  // 0x2660(0x8)
	struct UPointLightComponent* SpawnLight;  // 0x2668(0x8)
	float SpawnLightFadeOut_Lerp_C6262DEE4209BDDAEF0EED8AF9AC28D5;  // 0x2670(0x4)
	char ETimelineDirection SpawnLightFadeOut__Direction_C6262DEE4209BDDAEF0EED8AF9AC28D5;  // 0x2674(0x1)
	char pad_9845[3];  // 0x2675(0x3)
	struct UTimelineComponent* SpawnLightFadeOut;  // 0x2678(0x8)

	void GetEctoBuildup(bool& Prop?, float& Radiation, bool& Sensitive?, bool& Midnight Form?); // Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.GetEctoBuildup
	void UserConstructionScript(); // Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.UserConstructionScript
	void SpawnLightFadeOut__FinishedFunc(); // Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.SpawnLightFadeOut__FinishedFunc
	void SpawnLightFadeOut__UpdateFunc(); // Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.SpawnLightFadeOut__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_Hunter_Doppelganger(int32_t EntryPoint); // Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.ExecuteUbergraph_BP_Hunter_Doppelganger
}; 



