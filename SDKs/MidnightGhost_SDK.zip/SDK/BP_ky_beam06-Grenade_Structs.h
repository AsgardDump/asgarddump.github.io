#pragma once 
#include "SDK.h" 
 
 
// Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.ExecuteUbergraph_BP_ky_beam06-Grenade
// Size: 0x46(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ky_beam06-Grenade
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x20(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue_2;  // 0x38(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_LoS_Check_Line_of_Sight_ : 1;  // 0x45(0x1)

}; 
// Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.LoS_Check
// Size: 0x15E(Inherited: 0x0) 
struct FLoS_Check
{
	struct AActor* Origin;  // 0x0(0x8)
	struct AActor* Target;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Line of Sight? : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x14(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x30(0x10)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_2;  // 0x40(0x10)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x50(0x88)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xDA(0x1)
	char pad_219[1];  // 0xDB(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xDC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xE0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xE4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xF0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xFC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x108(0xC)
	char pad_276[4];  // 0x114(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x118(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x120(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x128(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x130(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x138(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x13C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x140(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x150(0xC)
	char pad_348_1 : 7;  // 0x15C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x15C(0x1)
	char pad_349_1 : 7;  // 0x15D(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x15D(0x1)

}; 
// Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_ky_beam06-Grenade.BP_ky_beam06-Grenade_C.UserConstructionScript
// Size: 0x8(Inherited: 0x18) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
