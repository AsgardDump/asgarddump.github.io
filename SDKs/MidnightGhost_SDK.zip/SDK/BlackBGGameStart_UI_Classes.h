#pragma once 
#include <BlackBGGameStart_UI_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BlackBGGameStart_UI.BlackBGGameStart_UI_C
// Size: 0x278(Inherited: 0x260) 
struct UBlackBGGameStart_UI_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* FadeOut;  // 0x268(0x8)
	struct UImage* bg;  // 0x270(0x8)

	void Fademeout(); // Function BlackBGGameStart_UI.BlackBGGameStart_UI_C.Fademeout
	void ExecuteUbergraph_BlackBGGameStart_UI(int32_t EntryPoint); // Function BlackBGGameStart_UI.BlackBGGameStart_UI_C.ExecuteUbergraph_BlackBGGameStart_UI
}; 



