#pragma once 
#include "SDK.h" 
 
 
// Function BP_ManorChandelier.BP_ManorChandelier_C.Server_TurnOnOff
// Size: 0x1(Inherited: 0x0) 
struct FServer_TurnOnOff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)

}; 
// Function BP_ManorChandelier.BP_ManorChandelier_C.ExecuteUbergraph_BP_ManorChandelier
// Size: 0xC2(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ManorChandelier
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_Off_on_3 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FLinearColor CallFunc_MakeColor_ReturnValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_CustomEvent_Off_on_2 : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct ABP_ManorChandelier_C* K2Node_CustomEvent_Chandolier;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_CustomEvent_Off_on : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_2;  // 0x2C(0x10)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_3;  // 0x3C(0x10)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_4;  // 0x4C(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x5C(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x74(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue_2;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x90(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0xA8(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0xC1(0x1)

}; 
// Function BP_ManorChandelier.BP_ManorChandelier_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_ManorChandelier.BP_ManorChandelier_C.OC_TurnOnOff
// Size: 0x9(Inherited: 0x0) 
struct FOC_TurnOnOff
{
	struct ABP_ManorChandelier_C* Chandolier;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool On : 1;  // 0x8(0x1)

}; 
// Function BP_ManorChandelier.BP_ManorChandelier_C.NR_TurnOnOff
// Size: 0x1(Inherited: 0x0) 
struct FNR_TurnOnOff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)

}; 
// Function BP_ManorChandelier.BP_ManorChandelier_C.UserConstructionScript
// Size: 0x28(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UMaterialInterface* Temp_object_Variable;  // 0x8(0x8)
	struct UMaterialInterface* Temp_object_Variable_2;  // 0x10(0x8)
	struct UMaterialInterface* K2Node_Select_Default;  // 0x18(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x20(0x8)

}; 
