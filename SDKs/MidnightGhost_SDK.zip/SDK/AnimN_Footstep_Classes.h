#pragma once 
#include <AnimN_Footstep_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimN_Footstep.AnimN_Footstep_C
// Size: 0x39(Inherited: 0x38) 
struct UAnimN_Footstep_C : public UAnimNotify
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool isLeftStep? : 1;  // 0x38(0x1)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimN_Footstep.AnimN_Footstep_C.Received_Notify
}; 



