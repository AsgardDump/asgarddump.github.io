#pragma once 
#include <BP_LevelAlterationController_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LevelAlterationController.BP_LevelAlterationController_C
// Size: 0x270(Inherited: 0x220) 
struct ABP_LevelAlterationController_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBillboardComponent* Billboard;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool Check Validity : 1;  // 0x230(0x1)
	char pad_561[3];  // 0x231(0x3)
	struct FName Current Level Filter;  // 0x234(0x8)
	int32_t MapLoadIndex;  // 0x23C(0x4)
	struct TArray<struct TSoftObjectPtr<UWorld>> Map Alt Sublevels;  // 0x240(0x10)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool Match Filter to current map : 1;  // 0x250(0x1)
	char pad_593[3];  // 0x251(0x3)
	int32_t Map Start Index;  // 0x254(0x4)
	int32_t Map End Index;  // 0x258(0x4)
	char pad_604[4];  // 0x25C(0x4)
	struct TArray<struct FTransform> ShrineTransforms;  // 0x260(0x10)

	void UserConstructionScript(); // Function BP_LevelAlterationController.BP_LevelAlterationController_C.UserConstructionScript
	void LoadLevel(int32_t load level index); // Function BP_LevelAlterationController.BP_LevelAlterationController_C.LoadLevel
	void Load_server(struct TSoftObjectPtr<UWorld> Level); // Function BP_LevelAlterationController.BP_LevelAlterationController_C.Load_server
	void Load_Client(struct TSoftObjectPtr<UWorld> Level); // Function BP_LevelAlterationController.BP_LevelAlterationController_C.Load_Client
	void ExecuteUbergraph_BP_LevelAlterationController(int32_t EntryPoint); // Function BP_LevelAlterationController.BP_LevelAlterationController_C.ExecuteUbergraph_BP_LevelAlterationController
}; 



