#pragma once 
#include "SDK.h" 
 
 
// Function BP_KeyAction.BP_KeyAction_C.Save Action
// Size: 0x7D(Inherited: 0x0) 
struct FSave Action
{
	struct UBP_GameSettings_C* Game Settings;  // 0x0(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FSKeyActionSave K2Node_MakeStruct_SKeyActionSave;  // 0x18(0x58)
	struct UBP_KeyMapping_C* CallFunc_Array_Get_Item;  // 0x70(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)

}; 
// Function BP_KeyAction.BP_KeyAction_C.Key Action Current State
// Size: 0x64(Inherited: 0x0) 
struct FKey Action Current State
{
	struct APlayerController* Player Controller;  // 0x0(0x8)
	float Action Axis Value;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Just Pressed : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool Just Released : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	float Action Value;  // 0x10(0x4)
	int32_t Times Just Released;  // 0x14(0x4)
	int32_t Times Just Pressed;  // 0x18(0x4)
	int32_t Active Mappings;  // 0x1C(0x4)
	int32_t Temp_int_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x2C(0x4)
	int32_t Temp_int_Variable_2;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x36(0x1)
	char pad_55_1 : 7;  // 0x37(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x37(0x1)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x3C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x40(0x4)
	int32_t Temp_int_Variable_3;  // 0x44(0x4)
	struct UBP_KeyMapping_C* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	float CallFunc_Key_Mapping_Current_State_Mapping_Value;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Key_Mapping_Current_State_Is_Active : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Key_Mapping_Current_State_Just_Pressed : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_Key_Mapping_Current_State_Just_Released : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x5B(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x5C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x60(0x4)

}; 
// Function BP_KeyAction.BP_KeyAction_C.Init Key Action
// Size: 0xFC(Inherited: 0x0) 
struct FInit Key Action
{
	struct FSKeyAction Key Action;  // 0x0(0x20)
	struct FString Action Name;  // 0x20(0x10)
	struct UBP_KeyAction_C* Action;  // 0x30(0x8)
	struct TArray<struct FString> CheckDuplicateMappingNames;  // 0x38(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FSKeyMapping CallFunc_Array_Get_Item;  // 0x50(0x38)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct FString CallFunc_ToLower_ReturnValue;  // 0x90(0x10)
	struct FString CallFunc_ToLower_ReturnValue_2;  // 0xA0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xB0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xC0(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xD4(0x1)
	char pad_213[3];  // 0xD5(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xD8(0x4)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct UBP_KeyMapping_C* CallFunc_SpawnObject_ReturnValue;  // 0xE8(0x8)
	struct UBP_KeyMapping_C* CallFunc_Init_Key_Mapping_Mapping;  // 0xF0(0x8)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0xF8(0x4)

}; 
// Function BP_KeyAction.BP_KeyAction_C.Load Action
// Size: 0x21(Inherited: 0x0) 
struct FLoad Action
{
	struct UBP_GameSettings_C* Game Settings;  // 0x0(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	struct UBP_KeyMapping_C* CallFunc_Array_Get_Item;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_KeyAction.BP_KeyAction_C.Get Mapping
// Size: 0x86(Inherited: 0x0) 
struct FGet Mapping
{
	struct FString Mapping Name;  // 0x0(0x10)
	struct UBP_KeyMapping_C* Mapping;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UBP_KeyMapping_C* Result;  // 0x20(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UBP_KeyMapping_C* CallFunc_Array_Get_Item;  // 0x78(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool CallFunc_EqualEqual_StriStri_ReturnValue : 1;  // 0x85(0x1)

}; 
