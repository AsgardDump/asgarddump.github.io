#pragma once 
#include <BP_ResurrectableGhost_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ResurrectableGhost.BP_ResurrectableGhost_C
// Size: 0x368(Inherited: 0x281) 
struct ABP_ResurrectableGhost_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UNiagaraComponent* NS_DeadGhostOrb;  // 0x290(0x8)
	struct UStaticMeshComponent* Orb;  // 0x298(0x8)
	struct UBoxComponent* SoulConsumeOverlap;  // 0x2A0(0x8)
	struct UWidgetComponent* RezWidget;  // 0x2A8(0x8)
	struct UParticleSystemComponent* ParticleSystem2;  // 0x2B0(0x8)
	struct UBoxComponent* ReviveOverlap;  // 0x2B8(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x2C0(0x8)
	struct UPointLightComponent* PointLight;  // 0x2C8(0x8)
	struct UStaticMeshComponent* Sphere_old;  // 0x2D0(0x8)
	struct USphereComponent* CollisionComponent;  // 0x2D8(0x8)
	float Flicker_Lerp_1B5E8A804AAC574FFA57B6BD6E931FE3;  // 0x2E0(0x4)
	char ETimelineDirection Flicker__Direction_1B5E8A804AAC574FFA57B6BD6E931FE3;  // 0x2E4(0x1)
	char pad_741[3];  // 0x2E5(0x3)
	struct UTimelineComponent* Flicker;  // 0x2E8(0x8)
	float FadeToBlue_Lerp_563FBAF846F50015D37EC7BB35CFF7E0;  // 0x2F0(0x4)
	char ETimelineDirection FadeToBlue__Direction_563FBAF846F50015D37EC7BB35CFF7E0;  // 0x2F4(0x1)
	char pad_757[3];  // 0x2F5(0x3)
	struct UTimelineComponent* FadeToBlue;  // 0x2F8(0x8)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool Ghost was a Bot? : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct AMGH_PlayerState_C* Ghost Player State;  // 0x308(0x8)
	struct AActor* My Owning Player State;  // 0x310(0x8)
	struct ABP_GhostShards_C* My Crystals;  // 0x318(0x8)
	struct UGhostRezzable_UI_C* Rez UI;  // 0x320(0x8)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool Disabled_1 : 1;  // 0x328(0x1)
	char pad_809[3];  // 0x329(0x3)
	struct FLinearColor InitialLightColor;  // 0x32C(0x10)
	float InitialLightIntensity;  // 0x33C(0x4)
	struct FLinearColor ResurrectLightColor;  // 0x340(0x10)
	struct AMGH_GameState_C* As MGH Game State;  // 0x350(0x8)
	float FallingVelocity;  // 0x358(0x4)
	struct FVector LandingSpot;  // 0x35C(0xC)

	void FindReviveOrbLandingSpot(bool& FoundSpot, struct FVector& Location); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.FindReviveOrbLandingSpot
	void FadeToBlue__FinishedFunc(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.FadeToBlue__FinishedFunc
	void FadeToBlue__UpdateFunc(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.FadeToBlue__UpdateFunc
	void Flicker__FinishedFunc(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.Flicker__FinishedFunc
	void Flicker__UpdateFunc(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.Flicker__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.ReceiveBeginPlay
	void RecheckResurrectable(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.RecheckResurrectable
	void Server_Resurrect(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.Server_Resurrect
	void Server_GhostBotRezzed(struct FTransform Rez XForm); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.Server_GhostBotRezzed
	void Hideme(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.Hideme
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.ReceiveEndPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.ReceiveTick
	void StartResurrectLight(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.StartResurrectLight
	void EndResurrectLight(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.EndResurrectLight
	void Set Rez Widget Hidden(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.Set Rez Widget Hidden
	void CheckMidnightEnsureNoRevive(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.CheckMidnightEnsureNoRevive
	void Server_FindRestingPoint(); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.Server_FindRestingPoint
	void MC_LerpOrbToLandingSpot(struct FVector Location); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.MC_LerpOrbToLandingSpot
	void ExecuteUbergraph_BP_ResurrectableGhost(int32_t EntryPoint); // Function BP_ResurrectableGhost.BP_ResurrectableGhost_C.ExecuteUbergraph_BP_ResurrectableGhost
}; 



