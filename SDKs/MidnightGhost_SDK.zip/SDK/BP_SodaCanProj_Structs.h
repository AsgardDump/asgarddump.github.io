#pragma once 
#include "SDK.h" 
 
 
// Function BP_SodaCanProj.BP_SodaCanProj_C.ExecuteUbergraph_BP_SodaCanProj
// Size: 0x168(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SodaCanProj
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x10(0x30)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x40(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x48(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x50(0x8)
	struct ASodaCanExplosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x58(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_CustomEvent_SkipDmg : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	struct FVector K2Node_CustomEvent_Hit_Normal;  // 0x6C(0xC)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0x78(0x8)
	struct AActor* K2Node_Event_Other;  // 0x80(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0x94(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0xA0(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0xAC(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0xB8(0x88)
	float K2Node_Event_DeltaSeconds;  // 0x140(0x4)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x144(0xC)
	struct FVector CallFunc_MirrorVectorByNormal_ReturnValue;  // 0x150(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x15C(0xC)

}; 
// Function BP_SodaCanProj.BP_SodaCanProj_C.PushLvlProp
// Size: 0x3C(Inherited: 0x0) 
struct FPushLvlProp
{
	struct ALvlProp_C* LvlProp;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0xC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x18(0xC)
	float CallFunc_BreakVector_X;  // 0x24(0x4)
	float CallFunc_BreakVector_Y;  // 0x28(0x4)
	float CallFunc_BreakVector_Z;  // 0x2C(0x4)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize;  // 0x30(0xC)

}; 
// Function BP_SodaCanProj.BP_SodaCanProj_C.HandleHit
// Size: 0x61(Inherited: 0x0) 
struct FHandleHit
{
	struct AActor* Hit Actor;  // 0x0(0x8)
	struct FVector HitNormal;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ABP_Trap_C* K2Node_DynamicCast_AsBP_Trap;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct ABP_Generator_C* K2Node_DynamicCast_AsBP_Generator;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct ABP_SaltCircle_C* K2Node_DynamicCast_AsBP_Salt_Circle;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x60(0x1)

}; 
// Function BP_SodaCanProj.BP_SodaCanProj_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_SodaCanProj.BP_SodaCanProj_C.Explode
// Size: 0x10(Inherited: 0x0) 
struct FExplode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool SkipDmg : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector Hit Normal;  // 0x4(0xC)

}; 
// Function BP_SodaCanProj.BP_SodaCanProj_C.ReceiveHit
// Size: 0xC8(Inherited: 0xC8) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x88)

}; 
// Function BP_SodaCanProj.BP_SodaCanProj_C.DamageGenerator
// Size: 0x34(Inherited: 0x0) 
struct FDamageGenerator
{
	struct ABP_Generator_C* Generator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float Temp_float_Variable;  // 0xC(0x4)
	float Temp_float_Variable_2;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	float Temp_float_Variable_3;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float K2Node_Select_Default;  // 0x2C(0x4)
	float K2Node_Select_Default_2;  // 0x30(0x4)

}; 
// Function BP_SodaCanProj.BP_SodaCanProj_C.DamageTrap
// Size: 0x9(Inherited: 0x0) 
struct FDamageTrap
{
	struct ABP_Trap_C* Trap;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x8(0x1)

}; 
