#pragma once 
#include <BP_PC_Chargeup_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PC_Chargeup.BP_PC_Chargeup_C
// Size: 0x258(Inherited: 0x220) 
struct ABP_PC_Chargeup_C : public AActor
{
	struct UParticleSystemComponent* P_SmallDistortion;  // 0x220(0x8)
	struct UParticleSystemComponent* P_ChargeUp;  // 0x228(0x8)
	struct UPointLightComponent* ChargeLight;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	struct ABP_Hunter_C* OwningHunter;  // 0x240(0x8)
	struct UAudioComponent* ChargingSound;  // 0x248(0x8)
	struct UAudioComponent* LoopingMaxEnergy;  // 0x250(0x8)

}; 



