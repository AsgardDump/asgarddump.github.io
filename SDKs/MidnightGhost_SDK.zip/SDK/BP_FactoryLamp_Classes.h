#pragma once 
#include <BP_FactoryLamp_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FactoryLamp.BP_FactoryLamp_C
// Size: 0x2AC(Inherited: 0x220) 
struct ABP_FactoryLamp_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Fluorescent_Lights_V01;  // 0x228(0x8)
	struct UPointLightComponent* PointLight;  // 0x230(0x8)
	struct UStaticMeshComponent* Cube;  // 0x238(0x8)
	struct USceneComponent* Spotlight position;  // 0x240(0x8)
	struct UStaticMeshComponent* Lamp__1_;  // 0x248(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x250(0x8)
	float Timeline_0_Brightness_6A51A1B6416702354540FFA50518199F;  // 0x258(0x4)
	char ETimelineDirection Timeline_0__Direction_6A51A1B6416702354540FFA50518199F;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x260(0x8)
	float Timeline_2_NewTrack_0_8DDD8F444D5A16C5A98B8390E34B17D5;  // 0x268(0x4)
	char ETimelineDirection Timeline_2__Direction_8DDD8F444D5A16C5A98B8390E34B17D5;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct UTimelineComponent* Timeline_3;  // 0x270(0x8)
	float Timeline_1_Multiplier_F1221D0C473469B589E3559650714662;  // 0x278(0x4)
	char ETimelineDirection Timeline_1__Direction_F1221D0C473469B589E3559650714662;  // 0x27C(0x1)
	char pad_637[3];  // 0x27D(0x3)
	struct UTimelineComponent* Timeline_2;  // 0x280(0x8)
	struct ASpotLight* My Spotlight;  // 0x288(0x8)
	struct FLinearColor Color;  // 0x290(0x10)
	float Intensity;  // 0x2A0(0x4)
	float Original Light Intensity;  // 0x2A4(0x4)
	float OriginalSpotlightIntensity;  // 0x2A8(0x4)

	void UserConstructionScript(); // Function BP_FactoryLamp.BP_FactoryLamp_C.UserConstructionScript
	void Timeline_1__FinishedFunc(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Timeline_1__FinishedFunc
	void Timeline_1__UpdateFunc(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Timeline_1__UpdateFunc
	void Timeline_2__FinishedFunc(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Timeline_2__FinishedFunc
	void Timeline_2__UpdateFunc(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Timeline_2__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Timeline_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_FactoryLamp.BP_FactoryLamp_C.ReceiveBeginPlay
	void Midnight(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Midnight
	void StopFlicker(); // Function BP_FactoryLamp.BP_FactoryLamp_C.StopFlicker
	void Infection(); // Function BP_FactoryLamp.BP_FactoryLamp_C.Infection
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_FactoryLamp.BP_FactoryLamp_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_FactoryLamp(int32_t EntryPoint); // Function BP_FactoryLamp.BP_FactoryLamp_C.ExecuteUbergraph_BP_FactoryLamp
}; 



