#pragma once 
#include <BP_GhostShards_Midnight_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GhostShards_Midnight.BP_GhostShards_Midnight_C
// Size: 0x388(Inherited: 0x37C) 
struct ABP_GhostShards_Midnight_C : public ABP_GhostShards_C
{
	char pad_892[4];  // 0x37C(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x380(0x8)

	void ReceiveBeginPlay(); // Function BP_GhostShards_Midnight.BP_GhostShards_Midnight_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_GhostShards_Midnight(int32_t EntryPoint); // Function BP_GhostShards_Midnight.BP_GhostShards_Midnight_C.ExecuteUbergraph_BP_GhostShards_Midnight
}; 



