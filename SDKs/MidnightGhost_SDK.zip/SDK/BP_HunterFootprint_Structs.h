#pragma once 
#include "SDK.h" 
 
 
// Function BP_HunterFootprint.BP_HunterFootprint_C.ExecuteUbergraph_BP_HunterFootprint
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HunterFootprint
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_Hidden_ : 1;  // 0x4(0x1)

}; 
// Function BP_HunterFootprint.BP_HunterFootprint_C.SetHidden?
// Size: 0x1(Inherited: 0x0) 
struct FSetHidden?
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hidden? : 1;  // 0x0(0x1)

}; 
// Function BP_HunterFootprint.BP_HunterFootprint_C.UserConstructionScript
// Size: 0xA8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Temp_float_Variable;  // 0x4(0x4)
	float Temp_float_Variable_2;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float Temp_float_Variable_3;  // 0x10(0x4)
	float Temp_float_Variable_4;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UMaterialInterface* Temp_object_Variable;  // 0x20(0x8)
	struct UMaterialInterface* Temp_object_Variable_2;  // 0x28(0x8)
	float K2Node_Select_Default;  // 0x30(0x4)
	float K2Node_Select_Default_2;  // 0x34(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x50(0xC)
	char pad_92[4];  // 0x5C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x60(0x30)
	struct UMaterialInterface* K2Node_Select_Default_3;  // 0x90(0x8)
	struct UDecalComponent* CallFunc_AddComponent_ReturnValue;  // 0x98(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0xA0(0x8)

}; 
