#pragma once 
#include "SDK.h" 
 
 
// Function BlackScreen_UI.BlackScreen_UI_C.ExecuteUbergraph_BlackScreen_UI
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BlackScreen_UI
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
