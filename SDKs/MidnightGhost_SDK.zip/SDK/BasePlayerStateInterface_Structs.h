#pragma once 
#include "SDK.h" 
 
 
// Function BasePlayerStateInterface.BasePlayerStateInterface_C.GetMGHPlayerName
// Size: 0x10(Inherited: 0x0) 
struct FGetMGHPlayerName
{
	struct FString MGHPlayerName;  // 0x0(0x10)

}; 
