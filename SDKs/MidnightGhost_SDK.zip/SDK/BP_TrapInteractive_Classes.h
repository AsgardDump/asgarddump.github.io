#pragma once 
#include <BP_TrapInteractive_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_TrapInteractive.BP_TrapInteractive_C
// Size: 0x2A0(Inherited: 0x281) 
struct ABP_TrapInteractive_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UBoxComponent* Box;  // 0x290(0x8)
	struct ABP_Trap_C* My_BPMotionSensor;  // 0x298(0x8)

	void ReceiveBeginPlay(); // Function BP_TrapInteractive.BP_TrapInteractive_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_TrapInteractive.BP_TrapInteractive_C.ReceiveTick
	void ExecuteUbergraph_BP_TrapInteractive(int32_t EntryPoint); // Function BP_TrapInteractive.BP_TrapInteractive_C.ExecuteUbergraph_BP_TrapInteractive
}; 



