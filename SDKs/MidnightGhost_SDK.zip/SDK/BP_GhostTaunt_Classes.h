#pragma once 
#include <BP_GhostTaunt_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GhostTaunt.BP_GhostTaunt_C
// Size: 0x241(Inherited: 0x220) 
struct ABP_GhostTaunt_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	char GhostTaunts Taunt;  // 0x230(0x1)
	char pad_561[7];  // 0x231(0x7)
	struct USoundBase* Sound;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool ModulatePitch? : 1;  // 0x240(0x1)

	void ReceiveBeginPlay(); // Function BP_GhostTaunt.BP_GhostTaunt_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_GhostTaunt(int32_t EntryPoint); // Function BP_GhostTaunt.BP_GhostTaunt_C.ExecuteUbergraph_BP_GhostTaunt
}; 



