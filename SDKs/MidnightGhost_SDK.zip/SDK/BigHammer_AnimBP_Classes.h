#pragma once 
#include <BigHammer_AnimBP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BigHammer_AnimBP.BigHammer_AnimBP_C
// Size: 0x559(Inherited: 0x2C0) 
struct UBigHammer_AnimBP_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x2F8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x320(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x348(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x3C8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x3F8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x478(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4A8(0xB0)
	char pad_1368_1 : 7;  // 0x558(0x1)
	bool Hammer? : 1;  // 0x558(0x1)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BigHammer_AnimBP.BigHammer_AnimBP_C.AnimGraph
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function BigHammer_AnimBP.BigHammer_AnimBP_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_BigHammer_AnimBP(int32_t EntryPoint); // Function BigHammer_AnimBP.BigHammer_AnimBP_C.ExecuteUbergraph_BigHammer_AnimBP
}; 



