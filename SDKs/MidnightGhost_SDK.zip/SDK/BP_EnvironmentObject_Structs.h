#pragma once 
#include "SDK.h" 
 
 
// Function BP_EnvironmentObject.BP_EnvironmentObject_C.CanIPickUp_Int
// Size: 0x9(Inherited: 0x0) 
struct FCanIPickUp_Int
{
	struct AActor* RequestingActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool OK : 1;  // 0x8(0x1)

}; 
// Function BP_EnvironmentObject.BP_EnvironmentObject_C.InteractEnvironment_Int
// Size: 0x8(Inherited: 0x0) 
struct FInteractEnvironment_Int
{
	struct AActor* ActivatingActor;  // 0x0(0x8)

}; 
// Function BP_EnvironmentObject.BP_EnvironmentObject_C.ExecuteUbergraph_BP_EnvironmentObject
// Size: 0x32(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EnvironmentObject
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AActor* K2Node_Event_ActivatingActor_2;  // 0x8(0x8)
	struct AActor* K2Node_Event_ActivatingActor;  // 0x10(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_Event_Controller;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_Alternate_ : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_AmICloseEnough__False_True : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x31(0x1)

}; 
// Function BP_EnvironmentObject.BP_EnvironmentObject_C.CanIInteract_Int
// Size: 0x20(Inherited: 0x0) 
struct FCanIInteract_Int
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool BlockInteract : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText ErrorMessage;  // 0x8(0x18)

}; 
// Function BP_EnvironmentObject.BP_EnvironmentObject_C.Interact_Interactive Object
// Size: 0x9(Inherited: 0x9) 
struct FInteract_Interactive Object : public FInteract_Interactive Object
{
	struct AMGH_PlayerController_BP_C* Controller;  // 0x0(0x8)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Alternate? : 1;  // 0x8(0x1)

}; 
// Function BP_EnvironmentObject.BP_EnvironmentObject_C.ServerEnvironmentInteract_Int
// Size: 0x8(Inherited: 0x0) 
struct FServerEnvironmentInteract_Int
{
	struct AActor* ActivatingActor;  // 0x0(0x8)

}; 
// Function BP_EnvironmentObject.BP_EnvironmentObject_C.getInteractData
// Size: 0x58(Inherited: 0x0) 
struct FgetInteractData
{
	struct FText interactionTextHUD;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool UseImageTextPrompt : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UTexture2D* ImageTextIcon;  // 0x20(0x8)
	struct FText ImageText1;  // 0x28(0x18)
	struct FText ImageText2;  // 0x40(0x18)

}; 
