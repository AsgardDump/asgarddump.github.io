#pragma once 
#include <AI_Spectator_Structs.h>
 
 
 
// BlueprintGeneratedClass AI_Spectator.AI_Spectator_C
// Size: 0x4C0(Inherited: 0x4C0) 
struct AAI_Spectator_C : public ACharacter
{

}; 



