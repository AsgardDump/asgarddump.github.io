#pragma once 
#include <BP_HunterVehicle_Path_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HunterVehicle_Path.BP_HunterVehicle_Path_C
// Size: 0x230(Inherited: 0x220) 
struct ABP_HunterVehicle_Path_C : public AActor
{
	struct USplineComponent* Spline;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)

}; 



