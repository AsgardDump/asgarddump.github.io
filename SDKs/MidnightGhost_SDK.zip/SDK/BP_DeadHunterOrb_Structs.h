#pragma once 
#include "SDK.h" 
 
 
// Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ExecuteUbergraph_BP_DeadHunterOrb
// Size: 0x299(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DeadHunterOrb
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x10(0x8)
	struct ABP_Spectator_C* K2Node_DynamicCast_AsBP_Spectator;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x38(0x8)
	struct TScriptInterface<IMGH_UIHelpersInterface_C> K2Node_DynamicCast_AsMGH_UIHelpers_Interface;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_Is_UI_Disabled__Result : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x58(0x8)
	struct UHunterRezzable_UI_C* K2Node_DynamicCast_AsHunter_Rezzable_UI;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x6C(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x78(0x88)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x108(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x118(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x119(0x1)
	char pad_282[6];  // 0x11A(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x120(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x13C(0x4)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x140(0x1)
	char pad_321_1 : 7;  // 0x141(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x141(0x1)
	char pad_322[2];  // 0x142(0x2)
	struct FVector CallFunc_GetSocketLocation_ReturnValue_2;  // 0x144(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x150(0xC)
	struct FVector CallFunc_VLerp_ReturnValue;  // 0x15C(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_2;  // 0x168(0x88)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_2 : 1;  // 0x1F0(0x1)
	char pad_497[3];  // 0x1F1(0x3)
	struct FLinearColor CallFunc_GetLightColor_ReturnValue;  // 0x1F4(0x10)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue;  // 0x204(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x214(0x4)
	char pad_536_1 : 7;  // 0x218(0x1)
	bool K2Node_CustomEvent_Start : 1;  // 0x218(0x1)
	char pad_537[3];  // 0x219(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x21C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x228(0xC)
	char pad_564[4];  // 0x234(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x238(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x248(0x1)
	char pad_585_1 : 7;  // 0x249(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x249(0x1)
	char pad_586_1 : 7;  // 0x24A(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x24A(0x1)
	char pad_587_1 : 7;  // 0x24B(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x24B(0x1)
	struct FVector CallFunc_GetSocketLocation_ReturnValue_3;  // 0x24C(0xC)
	struct FVector CallFunc_GetSocketLocation_ReturnValue_4;  // 0x258(0xC)
	char pad_612[4];  // 0x264(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x268(0x8)
	struct AMGH_PlayerState_C* K2Node_DynamicCast_AsMGH_Player_State;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x279(0x1)
	char pad_634[6];  // 0x27A(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x280(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x288(0x8)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x298(0x1)

}; 
// Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ConsumeSound
// Size: 0x1(Inherited: 0x0) 
struct FConsumeSound
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Start : 1;  // 0x0(0x1)

}; 
// Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
