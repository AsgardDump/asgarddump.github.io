#pragma once 
#include <Ai_GetLowestHealthHunter_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_GetLowestHealthHunter.Ai_GetLowestHealthHunter_C
// Size: 0xCC(Inherited: 0xA0) 
struct UAi_GetLowestHealthHunter_C : public UBTDecorator_BlueprintBase
{
	struct FBlackboardKeySelector OutLowestHealthHunter;  // 0xA0(0x28)
	float MaxHealth;  // 0xC8(0x4)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_GetLowestHealthHunter.Ai_GetLowestHealthHunter_C.PerformConditionCheckAI
}; 



