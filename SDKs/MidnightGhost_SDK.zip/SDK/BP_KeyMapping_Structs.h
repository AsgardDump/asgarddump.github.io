#pragma once 
#include "SDK.h" 
 
 
// Function BP_KeyMapping.BP_KeyMapping_C.Key Mapping Current State
// Size: 0x41(Inherited: 0x0) 
struct FKey Mapping Current State
{
	struct APlayerController* Player Controller;  // 0x0(0x8)
	float Mapping Value;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Is Active : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool Just Pressed : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool Just Released : 1;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)
	float Mapping Axis Value;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x14(0x4)
	float CallFunc_Key_Combination_Current_State_Axis_Value;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Key_Combination_Current_State_Is_Active : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_Key_Combination_Current_State_Just_Pressed : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_Key_Combination_Current_State_Just_Released : 1;  // 0x1E(0x1)
	char pad_31[1];  // 0x1F(0x1)
	float CallFunc_Key_Combination_Current_State_Axis_Value_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Key_Combination_Current_State_Is_Active_2 : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Key_Combination_Current_State_Just_Pressed_2 : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_Key_Combination_Current_State_Just_Released_2 : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool CallFunc_BooleanNOR_ReturnValue : 1;  // 0x27(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_BooleanNOR_ReturnValue_2 : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0x32(0x1)
	char pad_51[1];  // 0x33(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_BooleanOR_ReturnValue_5 : 1;  // 0x40(0x1)

}; 
// Function BP_KeyMapping.BP_KeyMapping_C.Init Key Mapping
// Size: 0x60(Inherited: 0x0) 
struct FInit Key Mapping
{
	struct FSKeyMapping Key Mapping;  // 0x0(0x38)
	struct UBP_KeyMapping_C* Mapping;  // 0x38(0x8)
	struct UBP_KeyCombination_C* CallFunc_SpawnObject_ReturnValue;  // 0x40(0x8)
	struct UBP_KeyCombination_C* CallFunc_Init_Key_Combination_Combination;  // 0x48(0x8)
	struct UBP_KeyCombination_C* CallFunc_SpawnObject_ReturnValue_2;  // 0x50(0x8)
	struct UBP_KeyCombination_C* CallFunc_Init_Key_Combination_Combination_2;  // 0x58(0x8)

}; 
// Function BP_KeyMapping.BP_KeyMapping_C.Save Key Mapping
// Size: 0x168(Inherited: 0x0) 
struct FSave Key Mapping
{
	struct UBP_GameSettings_C* Game Settings;  // 0x0(0x8)
	struct FSKeyActionSave KeySave;  // 0x8(0x58)
	struct FSKeyActionSave K2Node_Copy_ReturnValue;  // 0x60(0x58)
	struct FSKeyActionSave K2Node_SetFieldsInStruct_StructOut;  // 0xB8(0x58)
	struct FSKeyActionSave K2Node_SetFieldsInStruct_StructOut_2;  // 0x110(0x58)

}; 
// Function BP_KeyMapping.BP_KeyMapping_C.Load Key Mapping
// Size: 0x28(Inherited: 0x0) 
struct FLoad Key Mapping
{
	struct UBP_GameSettings_C* Game Settings;  // 0x0(0x8)
	struct FString Action Name;  // 0x8(0x10)
	struct FString Category;  // 0x18(0x10)

}; 
