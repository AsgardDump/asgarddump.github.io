#pragma once 
#include "SDK.h" 
 
 
// Function BP_LoggingFunctions.BP_LoggingFunctions_C.MGH Log
// Size: 0x71(Inherited: 0x0) 
struct FMGH Log
{
	struct FString Category;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Print To Log : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Error : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct UGameInstance* If Error, GameInstance;  // 0x28(0x8)
	struct UObject* __WorldContext;  // 0x30(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x70(0x1)

}; 
