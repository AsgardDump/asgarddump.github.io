#pragma once 
#include <Ai_IsGeneratorAlive_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_IsGeneratorAlive.Ai_IsGeneratorAlive_C
// Size: 0xA0(Inherited: 0xA0) 
struct UAi_IsGeneratorAlive_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_IsGeneratorAlive.Ai_IsGeneratorAlive_C.PerformConditionCheckAI
}; 



