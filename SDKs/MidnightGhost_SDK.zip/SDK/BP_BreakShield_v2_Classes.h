#pragma once 
#include <BP_BreakShield_v2_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BreakShield_v2.BP_BreakShield_v2_C
// Size: 0x239(Inherited: 0x220) 
struct ABP_BreakShield_v2_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDestructibleComponent* RiotShield_v2_staticmesh_DM;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool FP : 1;  // 0x238(0x1)

	void ReceiveBeginPlay(); // Function BP_BreakShield_v2.BP_BreakShield_v2_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_BreakShield_v2(int32_t EntryPoint); // Function BP_BreakShield_v2.BP_BreakShield_v2_C.ExecuteUbergraph_BP_BreakShield_v2
}; 



