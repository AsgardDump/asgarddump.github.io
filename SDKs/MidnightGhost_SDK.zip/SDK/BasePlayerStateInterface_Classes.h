#pragma once 
#include <BasePlayerStateInterface_Structs.h>
 
 
 
// BlueprintGeneratedClass BasePlayerStateInterface.BasePlayerStateInterface_C
// Size: 0x28(Inherited: 0x28) 
struct UBasePlayerStateInterface_C : public UInterface
{

	void GetMGHPlayerName(struct FString& MGHPlayerName); // Function BasePlayerStateInterface.BasePlayerStateInterface_C.GetMGHPlayerName
}; 



