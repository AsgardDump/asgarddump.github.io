#pragma once 
#include <AI_Spectator_Controller_Structs.h>
 
 
 
// BlueprintGeneratedClass AI_Spectator_Controller.AI_Spectator_Controller_C
// Size: 0x330(Inherited: 0x328) 
struct AAI_Spectator_Controller_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x328(0x8)

	void ReceiveBeginPlay(); // Function AI_Spectator_Controller.AI_Spectator_Controller_C.ReceiveBeginPlay
	void ExecuteUbergraph_AI_Spectator_Controller(int32_t EntryPoint); // Function AI_Spectator_Controller.AI_Spectator_Controller_C.ExecuteUbergraph_AI_Spectator_Controller
}; 



