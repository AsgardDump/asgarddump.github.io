#pragma once 
#include <BP_Trap_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Trap.BP_Trap_C
// Size: 0x628(Inherited: 0x4C0) 
struct ABP_Trap_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UNiagaraComponent* AoE_VFX;  // 0x4C8(0x8)
	struct UWidgetComponent* QuickHealthbar;  // 0x4D0(0x8)
	struct USphereComponent* GhostformOverlap;  // 0x4D8(0x8)
	struct UParticleSystemComponent* Sabotaged_Loop;  // 0x4E0(0x8)
	struct UBoxComponent* Box;  // 0x4E8(0x8)
	struct USceneComponent* VFX_Location;  // 0x4F0(0x8)
	struct USkeletalMeshComponent* trap_mesh;  // 0x4F8(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x500(0x8)
	struct UWidgetComponent* TrapIndicator;  // 0x508(0x8)
	struct UPointLightComponent* PointLight;  // 0x510(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x518(0x8)
	float RightYourself_NewTrack_0_670A32594657529C89A88B93965EB94B;  // 0x520(0x4)
	char ETimelineDirection RightYourself__Direction_670A32594657529C89A88B93965EB94B;  // 0x524(0x1)
	char pad_1317[3];  // 0x525(0x3)
	struct UTimelineComponent* RightYourself;  // 0x528(0x8)
	struct ABP_Hunter_C* WhoCreatedMe;  // 0x530(0x8)
	struct AProp_C* NearestProp;  // 0x538(0x8)
	float NearestPropDistance;  // 0x540(0x4)
	float Scanner_Closeness;  // 0x544(0x4)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool DETECTED : 1;  // 0x548(0x1)
	char pad_1353[3];  // 0x549(0x3)
	float DetectedLightIntensity;  // 0x54C(0x4)
	float IntensityTarget;  // 0x550(0x4)
	char pad_1364_1 : 7;  // 0x554(0x1)
	bool GoingBackward : 1;  // 0x554(0x1)
	char pad_1365[3];  // 0x555(0x3)
	struct TArray<struct ABP_ky_beam06_C*> MyBeams;  // 0x558(0x10)
	struct TArray<struct AProp_C*> PropsDetected;  // 0x568(0x10)
	struct AActor* OverlappedActor;  // 0x578(0x8)
	struct AActor* RemoveActor;  // 0x580(0x8)
	struct APlayerState* FakeHunterPlayerState;  // 0x588(0x8)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool DestroyedByRam? : 1;  // 0x590(0x1)
	char pad_1425_1 : 7;  // 0x591(0x1)
	bool Landed : 1;  // 0x591(0x1)
	char pad_1426[6];  // 0x592(0x6)
	struct AProp_C* NEW-OverlappedProp;  // 0x598(0x8)
	float NEW_MaxDistance;  // 0x5A0(0x4)
	char pad_1444[4];  // 0x5A4(0x4)
	struct ABP_ky_beam06_C* NEW_BeamSpawned;  // 0x5A8(0x8)
	struct AMGH_GameMode_C* ANGM;  // 0x5B0(0x8)
	char pad_1464_1 : 7;  // 0x5B8(0x1)
	bool TrapActivated : 1;  // 0x5B8(0x1)
	char pad_1465_1 : 7;  // 0x5B9(0x1)
	bool READY TO DAMAGE : 1;  // 0x5B9(0x1)
	char pad_1466[2];  // 0x5BA(0x2)
	float Trap Health;  // 0x5BC(0x4)
	char pad_1472_1 : 7;  // 0x5C0(0x1)
	bool TUTORIAL TRAP! : 1;  // 0x5C0(0x1)
	char pad_1473_1 : 7;  // 0x5C1(0x1)
	bool Disable Pickup? : 1;  // 0x5C1(0x1)
	char pad_1474_1 : 7;  // 0x5C2(0x1)
	bool SABOTAGED? : 1;  // 0x5C2(0x1)
	char pad_1475[5];  // 0x5C3(0x5)
	struct ABP_Hunter_C* SABOTAGED - Hurting Hunter;  // 0x5C8(0x8)
	struct AMGH_PlayerController_BP_C* SABOTAGED - Saboteur;  // 0x5D0(0x8)
	char pad_1496_1 : 7;  // 0x5D8(0x1)
	bool SABOTAGED? All : 1;  // 0x5D8(0x1)
	char pad_1497[7];  // 0x5D9(0x7)
	struct AActor* HitActor;  // 0x5E0(0x8)
	char pad_1512_1 : 7;  // 0x5E8(0x1)
	bool TrapOn : 1;  // 0x5E8(0x1)
	char pad_1513[7];  // 0x5E9(0x7)
	struct TArray<struct AActor*> OverlappedDmgActors;  // 0x5F0(0x10)
	char pad_1536_1 : 7;  // 0x600(0x1)
	bool NoSpeedCheckNext : 1;  // 0x600(0x1)
	char pad_1537[3];  // 0x601(0x3)
	float PropMaxSpeed;  // 0x604(0x4)
	struct AMGH_PlayerState_C* WhoCreatedMePlayerState;  // 0x608(0x8)
	char pad_1552_1 : 7;  // 0x610(0x1)
	bool GotPlayerState : 1;  // 0x610(0x1)
	char pad_1553[7];  // 0x611(0x7)
	struct AController* ControllerStored;  // 0x618(0x8)
	struct AProp_C* PropDetected;  // 0x620(0x8)

	void GetHealthMax(float& HealthCurrent, float& HealthMax); // Function BP_Trap.BP_Trap_C.GetHealthMax
	void OnRep_Trap Health(); // Function BP_Trap.BP_Trap_C.OnRep_Trap Health
	void CheckLoS_Hunter(struct AActor* Origin, struct AActor* Target, bool& Line of Sight?); // Function BP_Trap.BP_Trap_C.CheckLoS_Hunter
	void CheckLoS(struct AActor* Origin, struct AActor* Target, bool& Line of Sight?); // Function BP_Trap.BP_Trap_C.CheckLoS
	void RightYourself__FinishedFunc(); // Function BP_Trap.BP_Trap_C.RightYourself__FinishedFunc
	void RightYourself__UpdateFunc(); // Function BP_Trap.BP_Trap_C.RightYourself__UpdateFunc
	void NearestGhost(struct ABP_Hunter_C* BPPC_CreatedMe); // Function BP_Trap.BP_Trap_C.NearestGhost
	void Server_UpdateOverlapping(struct ABP_Hunter_C* BPPC, bool On, struct ABP_Trap_C* MotionSensor); // Function BP_Trap.BP_Trap_C.Server_UpdateOverlapping
	void Server_Update_PropDetectedStatus(struct AProp_C* Prop, bool On); // Function BP_Trap.BP_Trap_C.Server_Update_PropDetectedStatus
	void ReceiveBeginPlay(); // Function BP_Trap.BP_Trap_C.ReceiveBeginPlay
	void AdministerDamage(); // Function BP_Trap.BP_Trap_C.AdministerDamage
	void ReceiveTick(float DeltaSeconds); // Function BP_Trap.BP_Trap_C.ReceiveTick
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Trap.BP_Trap_C.ReceiveEndPlay
	void BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature(struct FHitResult& ImpactResult); // Function BP_Trap.BP_Trap_C.BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature
	void NR_UpdatePropDetectedStatus(struct AProp_C* Prop, bool IsOn); // Function BP_Trap.BP_Trap_C.NR_UpdatePropDetectedStatus
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Trap.BP_Trap_C.ReceiveHit
	void Server Damage Trap(float Damage); // Function BP_Trap.BP_Trap_C.Server Damage Trap
	void SaboteurSelected(bool  ON!); // Function BP_Trap.BP_Trap_C.SaboteurSelected
	void Server Was Sabotaged(struct AMGH_PlayerController_BP_C* Sabotuer); // Function BP_Trap.BP_Trap_C.Server Was Sabotaged
	void Server_UpdateHunterDetected_SABOT(struct ABP_Hunter_C* Hunter, bool On); // Function BP_Trap.BP_Trap_C.Server_UpdateHunterDetected_SABOT
	void MC_SabotagedVFX(); // Function BP_Trap.BP_Trap_C.MC_SabotagedVFX
	void SetSeeThroughWalls(bool See?); // Function BP_Trap.BP_Trap_C.SetSeeThroughWalls
	void BndEvt__GhostformOverlap_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Trap.BP_Trap_C.BndEvt__GhostformOverlap_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__GhostformOverlap_K2Node_ComponentBoundEvent_2_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_Trap.BP_Trap_C.BndEvt__GhostformOverlap_K2Node_ComponentBoundEvent_2_ComponentEndOverlapSignature__DelegateSignature
	void UpdateOverlapCheck(); // Function BP_Trap.BP_Trap_C.UpdateOverlapCheck
	void ForceTickDelayed(); // Function BP_Trap.BP_Trap_C.ForceTickDelayed
	void NR_UpdateHealthbar(); // Function BP_Trap.BP_Trap_C.NR_UpdateHealthbar
	void ExecuteUbergraph_BP_Trap(int32_t EntryPoint); // Function BP_Trap.BP_Trap_C.ExecuteUbergraph_BP_Trap
}; 



