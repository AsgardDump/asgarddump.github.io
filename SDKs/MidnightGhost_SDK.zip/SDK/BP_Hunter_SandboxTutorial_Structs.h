#pragma once 
#include "SDK.h" 
 
 
// Function BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C.InpActEvt_Ctrl+Alt_P_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl+Alt_P_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C.ExecuteUbergraph_BP_Hunter_SandboxTutorial
// Size: 0x30(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Hunter_SandboxTutorial
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AMGH_HUD_C* K2Node_CustomEvent_HUD;  // 0x28(0x8)

}; 
// Function BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C.SetUpHudRef
// Size: 0x8(Inherited: 0x0) 
struct FSetUpHudRef
{
	struct AMGH_HUD_C* HUD;  // 0x0(0x8)

}; 
