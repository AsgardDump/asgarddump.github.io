#pragma once 
#include <BestTeam_Nameplate_UI_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BestTeam_Nameplate_UI.BestTeam_Nameplate_UI_C
// Size: 0x398(Inherited: 0x260) 
struct UBestTeam_Nameplate_UI_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UTextBlock* Name;  // 0x268(0x8)
	struct UPlayerIcon_UI_C* PlayerIcon_UI;  // 0x270(0x8)
	struct UTextBlock* Tag;  // 0x278(0x8)
	float Distance;  // 0x280(0x4)
	char pad_644[4];  // 0x284(0x4)
	struct ABP_Hunter_C* MyHunter;  // 0x288(0x8)
	struct FSlateColor ChosenColor;  // 0x290(0x28)
	struct FSlateBrush ChosenIcon;  // 0x2B8(0x88)
	struct AProp_C* MyGhost;  // 0x340(0x8)
	struct UTexture2D* SteamIcon;  // 0x348(0x8)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool FirstRun : 1;  // 0x350(0x1)
	char pad_849[7];  // 0x351(0x7)
	struct UTexture2D* Icon;  // 0x358(0x8)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool Bamboozle? : 1;  // 0x360(0x1)
	char pad_865[7];  // 0x361(0x7)
	struct AMGH_PlayerState_C* Stolen CPS;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool IconSet : 1;  // 0x370(0x1)
	char pad_881[3];  // 0x371(0x3)
	float Distance_3;  // 0x374(0x4)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool TagEnabled? : 1;  // 0x378(0x1)
	char pad_889[3];  // 0x379(0x3)
	int32_t Player Level;  // 0x37C(0x4)
	struct AMGH_PlayerState_C* Player State;  // 0x380(0x8)
	struct FString Player Name;  // 0x388(0x10)

	void Construct(); // Function BestTeam_Nameplate_UI.BestTeam_Nameplate_UI_C.Construct
	void ExecuteUbergraph_BestTeam_Nameplate_UI(int32_t EntryPoint); // Function BestTeam_Nameplate_UI.BestTeam_Nameplate_UI_C.ExecuteUbergraph_BestTeam_Nameplate_UI
}; 



