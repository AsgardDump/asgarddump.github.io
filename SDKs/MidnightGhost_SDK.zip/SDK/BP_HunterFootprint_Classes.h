#pragma once 
#include <BP_HunterFootprint_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HunterFootprint.BP_HunterFootprint_C
// Size: 0x27B(Inherited: 0x220) 
struct ABP_HunterFootprint_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Sphere;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Timeline_0_Opacity_A952BCF041514FFD97684581F2ED74B6;  // 0x238(0x4)
	char ETimelineDirection Timeline_0__Direction_A952BCF041514FFD97684581F2ED74B6;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x240(0x8)
	float FadeoutSlow_Opacity_74F90C7F475F6E83507276A7E17DBA48;  // 0x248(0x4)
	char ETimelineDirection FadeoutSlow__Direction_74F90C7F475F6E83507276A7E17DBA48;  // 0x24C(0x1)
	char pad_589[3];  // 0x24D(0x3)
	struct UTimelineComponent* FadeoutSlow;  // 0x250(0x8)
	struct UDecalComponent* MyDecal;  // 0x258(0x8)
	struct UMaterialInstanceDynamic* EctoplasmTrailMaterialRef;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool Skip Fade Out? : 1;  // 0x268(0x1)
	char pad_617_1 : 7;  // 0x269(0x1)
	bool Fading Out! : 1;  // 0x269(0x1)
	char pad_618[6];  // 0x26A(0x6)
	struct UMaterialInterface* DecalMaterial;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool Faster Fadeout? : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool Local Hunter? : 1;  // 0x279(0x1)
	char pad_634_1 : 7;  // 0x27A(0x1)
	bool IsLeftFoot? : 1;  // 0x27A(0x1)

	void UserConstructionScript(); // Function BP_HunterFootprint.BP_HunterFootprint_C.UserConstructionScript
	void FadeoutSlow__FinishedFunc(); // Function BP_HunterFootprint.BP_HunterFootprint_C.FadeoutSlow__FinishedFunc
	void FadeoutSlow__UpdateFunc(); // Function BP_HunterFootprint.BP_HunterFootprint_C.FadeoutSlow__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_HunterFootprint.BP_HunterFootprint_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_HunterFootprint.BP_HunterFootprint_C.Timeline_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_HunterFootprint.BP_HunterFootprint_C.ReceiveBeginPlay
	void SetHidden?(bool Hidden?); // Function BP_HunterFootprint.BP_HunterFootprint_C.SetHidden?
	void Fadeout_Slow(); // Function BP_HunterFootprint.BP_HunterFootprint_C.Fadeout_Slow
	void Fadeout_Quicker(); // Function BP_HunterFootprint.BP_HunterFootprint_C.Fadeout_Quicker
	void ExecuteUbergraph_BP_HunterFootprint(int32_t EntryPoint); // Function BP_HunterFootprint.BP_HunterFootprint_C.ExecuteUbergraph_BP_HunterFootprint
}; 



