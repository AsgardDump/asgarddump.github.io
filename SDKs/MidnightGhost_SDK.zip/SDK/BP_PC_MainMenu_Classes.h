#pragma once 
#include <BP_PC_MainMenu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PC_MainMenu.BP_PC_MainMenu_C
// Size: 0x650(Inherited: 0x620) 
struct ABP_PC_MainMenu_C : public ABP_PC_InputDetect_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x620(0x8)
	struct USteamPartyComponent* SteamParty;  // 0x628(0x8)
	struct UW_PartyPanel_C* UI_PartyPanel;  // 0x630(0x8)
	struct UWB_ProMainMenu_C* ProMainMenu;  // 0x638(0x8)
	char pad_1600_1 : 7;  // 0x640(0x1)
	bool SkinUI : 1;  // 0x640(0x1)
	char pad_1601[7];  // 0x641(0x7)
	struct UMainMenu_SetCosmetics_UI_C* SkinUIRef;  // 0x648(0x8)

	void SpawnClientBeacon_Int(struct UObject*& ClientBeacon); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.SpawnClientBeacon_Int
	void GetProMainMenu(struct UWB_ProMainMenu_C*& ProMainMenu); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.GetProMainMenu
	void DestroyPartyPanel(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.DestroyPartyPanel
	void CreatePartyPanel(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.CreatePartyPanel
	void InpActEvt_NumPadZero_K2Node_InputKeyEvent_5(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_NumPadZero_K2Node_InputKeyEvent_5
	void InpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_4
	void InpActEvt_Ctrl_X_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Ctrl_X_K2Node_InputKeyEvent_3
	void InpActEvt_Enter_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Enter_K2Node_InputKeyEvent_2
	void InpActEvt_Open Pause Menu_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Open Pause Menu_K2Node_InputActionEvent_3
	void InpActEvt_AnyKey_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_AnyKey_K2Node_InputKeyEvent_1
	void InpActEvt_EOSPTT_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_EOSPTT_K2Node_InputActionEvent_2
	void InpActEvt_EOSPTT_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_EOSPTT_K2Node_InputActionEvent_1
	void UpdateInputMode(bool ShowMouseCursor, struct UWidget* InWidgetToFocus); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.UpdateInputMode
	void ReceiveBeginPlay(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.ReceiveBeginPlay
	void Begin(struct UW_PartyPanel_C* UI_PartyPanel); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.Begin
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_0_OnPlayerJoinedSteamPartyDelegate__DelegateSignature(struct ASteamBeaconPlayerState* InPlayerBeaconState); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_0_OnPlayerJoinedSteamPartyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_1_OnPlayerUpdateSteamPartyDelegate__DelegateSignature(struct ASteamBeaconPlayerState* InPlayerBeaconState); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_1_OnPlayerUpdateSteamPartyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_2_OnPlayerUpdateSteamPartyDelegate__DelegateSignature(struct ASteamBeaconPlayerState* InPlayerBeaconState); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_2_OnPlayerUpdateSteamPartyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_3_EmptyDelegate__DelegateSignature(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_3_EmptyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_4_OnPlayerUniqueIdSteamPartyDelegate__DelegateSignature(struct FUniqueNetIdRepl& InPlayerUniqueId); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_4_OnPlayerUniqueIdSteamPartyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_5_OnPlayerMessageSteamPartyDelegate__DelegateSignature(struct FPartyMessage InPartyMessage); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_5_OnPlayerMessageSteamPartyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_7_EmptyDelegate__DelegateSignature(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_7_EmptyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_8_EmptyDelegate__DelegateSignature(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_8_EmptyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_10_OnPlayerInviteReceivedSteamPartyDelegate__DelegateSignature(struct FUniqueNetIdRepl& InPlayerUniqueId, struct FString InFriendName); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_10_OnPlayerInviteReceivedSteamPartyDelegate__DelegateSignature
	void BndEvt__SteamParty_K2Node_ComponentBoundEvent_6_EmptyDelegate__DelegateSignature(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_6_EmptyDelegate__DelegateSignature
	void OnPreLoadMapSteamParty_Event_1(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.OnPreLoadMapSteamParty_Event_1
	void OnPreLoadMapSteamParty_Event_2(); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.OnPreLoadMapSteamParty_Event_2
	void ReceiveTick(float DeltaSeconds); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.ReceiveTick
	void InpAxisKeyEvt_MouseX_K2Node_InputAxisKeyEvent_1(float AxisValue); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpAxisKeyEvt_MouseX_K2Node_InputAxisKeyEvent_1
	void InpAxisKeyEvt_MouseY_K2Node_InputAxisKeyEvent_2(float AxisValue); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpAxisKeyEvt_MouseY_K2Node_InputAxisKeyEvent_2
	void ExecuteUbergraph_BP_PC_MainMenu(int32_t EntryPoint); // Function BP_PC_MainMenu.BP_PC_MainMenu_C.ExecuteUbergraph_BP_PC_MainMenu
}; 



