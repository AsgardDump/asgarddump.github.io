#pragma once 
#include "SDK.h" 
 
 
// Function BP_SniperDart.BP_SniperDart_C.ExecuteUbergraph_BP_SniperDart
// Size: 0xDC(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SniperDart
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x20(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x28(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_FInterpTo_Constant_ReturnValue;  // 0x34(0x4)
	char pad_56[8];  // 0x38(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x40(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x70(0x8)
	struct ABP_SniperDartExplosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x78(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x80(0xC)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8C(0x1)
	char pad_141_1 : 7;  // 0x8D(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x8D(0x1)
	char pad_142_1 : 7;  // 0x8E(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x8E(0x1)
	char pad_143_1 : 7;  // 0x8F(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x8F(0x1)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_Using_Prop_Health_V2__V2 : 1;  // 0x91(0x1)
	char pad_146[2];  // 0x92(0x2)
	int32_t CallFunc_Calculate_Hunter_Damage_Damage;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Calculate_Hunter_Damage_EffectiveHit : 1;  // 0x98(0x1)
	char HitmarkerType CallFunc_Calculate_Hunter_Damage_HitmarkerType;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	int32_t K2Node_Select_Default;  // 0x9C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0xA0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xA4(0xC)
	float CallFunc_DamageMethodModifier_Out_Damage;  // 0xB0(0x4)
	float CallFunc_BreakVector_X;  // 0xB4(0x4)
	float CallFunc_BreakVector_Y;  // 0xB8(0x4)
	float CallFunc_BreakVector_Z;  // 0xBC(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0xC0(0x4)
	struct FVector_NetQuantize10 K2Node_MakeStruct_Vector_NetQuantize10;  // 0xC4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0xD0(0xC)

}; 
// Function BP_SniperDart.BP_SniperDart_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
