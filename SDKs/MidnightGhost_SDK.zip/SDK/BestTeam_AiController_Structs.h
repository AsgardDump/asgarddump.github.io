#pragma once 
#include "SDK.h" 
 
 
// Function BestTeam_AiController.BestTeam_AiController_C.ExecuteUbergraph_BestTeam_AiController
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BestTeam_AiController
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
