#pragma once 
#include "SDK.h" 
 
 
// Function BP_RenderGhost.BP_RenderGhost_C.DeferredLoadSkin
// Size: 0x1(Inherited: 0x0) 
struct FDeferredLoadSkin
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool WasSuccessful : 1;  // 0x0(0x1)

}; 
// Function BP_RenderGhost.BP_RenderGhost_C.ExecuteUbergraph_BP_RenderGhost
// Size: 0xB0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_RenderGhost
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_WasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char GhostSkins K2Node_CustomEvent_EquippedGhostSkin;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_SetupGhostMesh_Success : 1;  // 0x36(0x1)
	char pad_55[1];  // 0x37(0x1)
	struct TArray<struct UMaterialInstanceDynamic*> CallFunc_SetupGhostMesh_Materials;  // 0x38(0x10)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x48(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x59(0x1)
	char pad_90[2];  // 0x5A(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x5C(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x60(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_SwitchString_CmpSuccess : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x90(0x8)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xA0(0x1)
	char GhostSkins CallFunc_Load_Equipped_Ghost_Skin_SkinEnum;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_Load_Equipped_Ghost_Skin_Successful : 1;  // 0xA2(0x1)
	char pad_163[5];  // 0xA3(0x5)
	struct UMGHOnlineStatsManager* CallFunc_GetOnlineStatsManager_ReturnValue;  // 0xA8(0x8)

}; 
// Function BP_RenderGhost.BP_RenderGhost_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_RenderGhost.BP_RenderGhost_C.SetSkin
// Size: 0x1(Inherited: 0x0) 
struct FSetSkin
{
	char GhostSkins EquippedGhostSkin;  // 0x0(0x1)

}; 
