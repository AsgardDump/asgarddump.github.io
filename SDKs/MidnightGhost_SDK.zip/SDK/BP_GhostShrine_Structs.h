#pragma once 
#include "SDK.h" 
 
 
// Function BP_GhostShrine.BP_GhostShrine_C.InteractWithShrine
// Size: 0x8(Inherited: 0x0) 
struct FInteractWithShrine
{
	struct AMGH_PlayerController_BP_C* PC;  // 0x0(0x8)

}; 
// Function BP_GhostShrine.BP_GhostShrine_C.ExecuteUbergraph_BP_GhostShrine
// Size: 0xE2(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GhostShrine
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UShrineIndicator_UI_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_PC;  // 0x18(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x20(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x38(0x8)
	char Team CallFunc_Get_Player_Team_Team;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x48(0x8)
	struct UShrineIndicator_UI_C* K2Node_DynamicCast_AsShrine_Indicator_UI;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x59(0x1)
	uint8_t  CallFunc_GetVisibility_ReturnValue;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x5B(0x1)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x70(0x10)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x80(0x8)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue_2;  // 0x88(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x99(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x9A(0x1)
	char pad_155[5];  // 0x9B(0x5)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0xA0(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct UUserWidget* CallFunc_GetWidget_ReturnValue;  // 0xB8(0x8)
	struct UShrineIndicator_UI_C* CallFunc_Create_ReturnValue_2;  // 0xC0(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0xC8(0x8)
	struct TScriptInterface<IMGH_UIHelpersInterface_C> K2Node_DynamicCast_AsMGH_UIHelpers_Interface;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_Is_UI_Disabled__Result : 1;  // 0xE1(0x1)

}; 
// Function BP_GhostShrine.BP_GhostShrine_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
