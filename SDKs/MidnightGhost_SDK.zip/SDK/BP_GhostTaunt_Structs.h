#pragma once 
#include "SDK.h" 
 
 
// Function BP_GhostTaunt.BP_GhostTaunt_C.ExecuteUbergraph_BP_GhostTaunt
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GhostTaunt
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USoundBase* CallFunc_GetTauntSoundForEnum_Sound;  // 0x8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)

}; 
