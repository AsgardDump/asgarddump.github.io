#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AdvancedSteamSessions.BPSteamWorkshopID
// Size: 0x8(Inherited: 0x0) 
struct FBPSteamWorkshopID
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetFriendSteamLevel
// Size: 0x28(Inherited: 0x0) 
struct FGetFriendSteamLevel
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	int32_t ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// DelegateFunction AdvancedSteamSessions.BlueprintGroupOfficerDetailsDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintGroupOfficerDetailsDelegate__DelegateSignature
{
	struct TArray<struct FBPSteamGroupOfficer> OfficerList;  // 0x0(0x10)

}; 
// ScriptStruct AdvancedSteamSessions.BPSteamGroupOfficer
// Size: 0x28(Inherited: 0x0) 
struct FBPSteamGroupOfficer
{
	struct FBPUniqueNetId OfficerUniqueNetID;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bIsOwner : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.IsSteamInBigPictureMode
// Size: 0x1(Inherited: 0x0) 
struct FIsSteamInBigPictureMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction AdvancedSteamSessions.BlueprintWorkshopDetailsDelegate__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FBlueprintWorkshopDetailsDelegate__DelegateSignature
{
	struct FBPSteamWorkshopItemDetails WorkShopDetails;  // 0x0(0x60)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.CreateSteamIDFromString
// Size: 0x30(Inherited: 0x0) 
struct FCreateSteamIDFromString
{
	struct FString SteamID64;  // 0x0(0x10)
	struct FBPUniqueNetId ReturnValue;  // 0x10(0x20)

}; 
// ScriptStruct AdvancedSteamSessions.BPSteamWorkshopItemDetails
// Size: 0x60(Inherited: 0x0) 
struct FBPSteamWorkshopItemDetails
{
	uint8_t  ResultOfRequest;  // 0x0(0x1)
	uint8_t  FileType;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t CreatorAppID;  // 0x4(0x4)
	int32_t ConsumerAppID;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Title;  // 0x10(0x10)
	struct FString Description;  // 0x20(0x10)
	struct FString ItemUrl;  // 0x30(0x10)
	int32_t VotesUp;  // 0x40(0x4)
	int32_t VotesDown;  // 0x44(0x4)
	float CalculatedScore;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bBanned : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool bAcceptedForUse : 1;  // 0x4D(0x1)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool bTagsTruncated : 1;  // 0x4E(0x1)
	char pad_79[1];  // 0x4F(0x1)
	struct FString CreatorSteamID;  // 0x50(0x10)

}; 
// ScriptStruct AdvancedSteamSessions.BPSteamGroupInfo
// Size: 0x50(Inherited: 0x0) 
struct FBPSteamGroupInfo
{
	struct FBPUniqueNetId GroupID;  // 0x0(0x20)
	struct FString GroupName;  // 0x20(0x10)
	struct FString GroupTag;  // 0x30(0x10)
	int32_t numOnline;  // 0x40(0x4)
	int32_t numInGame;  // 0x44(0x4)
	int32_t numChatting;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.BPToReplUniqueNetID
// Size: 0x48(Inherited: 0x0) 
struct FBPToReplUniqueNetID
{
	struct FBPUniqueNetId UniqueReplID;  // 0x0(0x20)
	struct FUniqueNetIdRepl ReturnValue;  // 0x20(0x28)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.FilterText
// Size: 0x50(Inherited: 0x0) 
struct FFilterText
{
	struct FString TextToFilter;  // 0x0(0x10)
	uint8_t  Context;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FBPUniqueNetId TextSourceID;  // 0x18(0x20)
	struct FString FilteredText;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetLocalSteamIDFromSteam
// Size: 0x20(Inherited: 0x0) 
struct FGetLocalSteamIDFromSteam
{
	struct FBPUniqueNetId ReturnValue;  // 0x0(0x20)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamFriendAvatar
// Size: 0x30(Inherited: 0x0) 
struct FGetSteamFriendAvatar
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	uint8_t  Result;  // 0x20(0x1)
	uint8_t  AvatarSize;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct UTexture2D* ReturnValue;  // 0x28(0x8)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamFriendGamePlayed
// Size: 0x28(Inherited: 0x0) 
struct FGetSteamFriendGamePlayed
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	uint8_t  Result;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t AppId;  // 0x24(0x4)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamGroups
// Size: 0x10(Inherited: 0x0) 
struct FGetSteamGroups
{
	struct TArray<struct FBPSteamGroupInfo> SteamGroups;  // 0x0(0x10)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamPersonaName
// Size: 0x30(Inherited: 0x0) 
struct FGetSteamPersonaName
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.InitTextFiltering
// Size: 0x1(Inherited: 0x0) 
struct FInitTextFiltering
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.IsOverlayEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsOverlayEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.OpenSteamUserOverlay
// Size: 0x28(Inherited: 0x0) 
struct FOpenSteamUserOverlay
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	uint8_t  DialogType;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.ReplToBPUniqueNetID
// Size: 0x48(Inherited: 0x0) 
struct FReplToBPUniqueNetID
{
	struct FUniqueNetIdRepl UniqueReplID;  // 0x0(0x28)
	struct FBPUniqueNetId ReturnValue;  // 0x28(0x20)

}; 
// Function AdvancedSteamSessions.SteamRequestGroupOfficersCallbackProxy.GetSteamGroupOfficerList
// Size: 0x30(Inherited: 0x0) 
struct FGetSteamGroupOfficerList
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FBPUniqueNetId GroupUniqueNetID;  // 0x8(0x20)
	struct USteamRequestGroupOfficersCallbackProxy* ReturnValue;  // 0x28(0x8)

}; 
// Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.RequestSteamFriendInfo
// Size: 0x28(Inherited: 0x0) 
struct FRequestSteamFriendInfo
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bRequireNameOnly : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function AdvancedSteamSessions.AdvancedSteamWorkshopLibrary.GetNumSubscribedWorkshopItems
// Size: 0x4(Inherited: 0x0) 
struct FGetNumSubscribedWorkshopItems
{
	int32_t NumberOfItems;  // 0x0(0x4)

}; 
// Function AdvancedSteamSessions.AdvancedSteamWorkshopLibrary.GetSubscribedWorkshopItems
// Size: 0x18(Inherited: 0x0) 
struct FGetSubscribedWorkshopItems
{
	int32_t NumberOfItems;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FBPSteamWorkshopID> ReturnValue;  // 0x8(0x10)

}; 
// Function AdvancedSteamSessions.SteamWSRequestUGCDetailsCallbackProxy.GetWorkshopItemDetails
// Size: 0x18(Inherited: 0x0) 
struct FGetWorkshopItemDetails
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FBPSteamWorkshopID WorkShopID;  // 0x8(0x8)
	struct USteamWSRequestUGCDetailsCallbackProxy* ReturnValue;  // 0x10(0x8)

}; 
