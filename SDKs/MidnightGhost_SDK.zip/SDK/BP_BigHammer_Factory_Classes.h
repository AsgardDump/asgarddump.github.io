#pragma once 
#include <BP_BigHammer_Factory_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BigHammer_Factory.BP_BigHammer_Factory_C
// Size: 0x2B0(Inherited: 0x220) 
struct ABP_BigHammer_Factory_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* HammerDamage;  // 0x228(0x8)
	struct UBoxComponent* HammerBlock;  // 0x230(0x8)
	struct UBoxComponent* Box6;  // 0x238(0x8)
	struct UBoxComponent* Box5;  // 0x240(0x8)
	struct UBoxComponent* Box4;  // 0x248(0x8)
	struct UBoxComponent* Box3;  // 0x250(0x8)
	struct UBoxComponent* Box2;  // 0x258(0x8)
	struct UBoxComponent* Box1;  // 0x260(0x8)
	struct UBoxComponent* Box;  // 0x268(0x8)
	struct USkeletalMeshComponent* Mesh;  // 0x270(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x278(0x8)
	struct TArray<struct APointLight*> Lights;  // 0x280(0x10)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool HammerActive? : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct AActor* ResponsibleActor;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool Damage? : 1;  // 0x2A0(0x1)
	char pad_673[7];  // 0x2A1(0x7)
	struct AController* Responsible Controller;  // 0x2A8(0x8)

	void SetLight(bool  ON); // Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.SetLight
	void BeginHammer(struct AActor* ResponsibleActor); // Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.BeginHammer
	void Server_BeginHammer(struct AActor* ResponsibleActor); // Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.Server_BeginHammer
	void MC_BeginHammer(); // Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.MC_BeginHammer
	void BndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.BndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void ExecuteUbergraph_BP_BigHammer_Factory(int32_t EntryPoint); // Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.ExecuteUbergraph_BP_BigHammer_Factory
}; 



