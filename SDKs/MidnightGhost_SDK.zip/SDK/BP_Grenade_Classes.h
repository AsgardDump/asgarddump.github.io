#pragma once 
#include <BP_Grenade_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Grenade.BP_Grenade_C
// Size: 0x368(Inherited: 0x220) 
struct ABP_Grenade_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* NS_RailSparks;  // 0x228(0x8)
	struct USkeletalMeshComponent* FP_Grenade;  // 0x230(0x8)
	struct UAudioComponent* PlasmaGrenade;  // 0x238(0x8)
	struct UPointLightComponent* PointLight;  // 0x240(0x8)
	struct USphereComponent* CollisionComponent;  // 0x248(0x8)
	float SlowToStop_Interperoni_9FB2326B48B8CF98744BBAB9358A7E35;  // 0x250(0x4)
	char ETimelineDirection SlowToStop__Direction_9FB2326B48B8CF98744BBAB9358A7E35;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* SlowToStop;  // 0x258(0x8)
	struct ABP_Hunter_C* WhoShotMe?;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool Active? : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct TArray<struct AProp_C*> PropsHit;  // 0x270(0x10)
	struct TArray<struct AProp_C*> PropsHit_Raycast;  // 0x280(0x10)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool AI-Bomb? : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct TArray<struct ABP_ky_beam06-Grenade_C*> Beams;  // 0x298(0x10)
	struct TArray<struct ABP_PlasmaBall_C*> PlasmaBalls;  // 0x2A8(0x10)
	struct TArray<struct AProp_C*> PropsHit_Raycast_Old;  // 0x2B8(0x10)
	struct UMaterialInstanceDynamic* GrenadeMaterial;  // 0x2C8(0x8)
	char GrenadeStatus GrenadeStatus;  // 0x2D0(0x1)
	char pad_721[3];  // 0x2D1(0x3)
	struct FLinearColor Target_NonFull_Color;  // 0x2D4(0x10)
	float TargetRedLightIntensity;  // 0x2E4(0x4)
	float FlashInterval;  // 0x2E8(0x4)
	char pad_748_1 : 7;  // 0x2EC(0x1)
	bool BeginMovingUpwards : 1;  // 0x2EC(0x1)
	char pad_749[3];  // 0x2ED(0x3)
	struct FVector NewLocationTarget;  // 0x2F0(0xC)
	float Velocity;  // 0x2FC(0x4)
	struct TArray<struct AProp_C*> PropsMovementLocked;  // 0x300(0x10)
	struct FTransform Revert;  // 0x310(0x30)
	struct UProjectileMovementComponent* Added Projectile;  // 0x340(0x8)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool Stuck? : 1;  // 0x348(0x1)
	char pad_841[7];  // 0x349(0x7)
	struct UMGH_GameInstance_BP_C* My Game Instance;  // 0x350(0x8)
	char pad_856_1 : 7;  // 0x358(0x1)
	bool Thrown? : 1;  // 0x358(0x1)
	char pad_857_1 : 7;  // 0x359(0x1)
	bool CheckThrown : 1;  // 0x359(0x1)
	char pad_858_1 : 7;  // 0x35A(0x1)
	bool Locally Controlled? : 1;  // 0x35A(0x1)
	char pad_859_1 : 7;  // 0x35B(0x1)
	bool Disable : 1;  // 0x35B(0x1)
	char pad_860_1 : 7;  // 0x35C(0x1)
	bool DamagedGhost : 1;  // 0x35C(0x1)
	char pad_861[3];  // 0x35D(0x3)
	struct UMaterialInstanceDynamic* GrenaMaterialLit;  // 0x360(0x8)

	void GetProjectileOwner(struct ABP_Hunter_C*& Hunter); // Function BP_Grenade.BP_Grenade_C.GetProjectileOwner
	void FindRaycastedProps(struct TArray<struct AProp_C*>& RaycastedProps (Already Set)); // Function BP_Grenade.BP_Grenade_C.FindRaycastedProps
	void CheckLoS(struct AProp_C* Prop, struct AProp_C*& PropVerified, bool& LoS?); // Function BP_Grenade.BP_Grenade_C.CheckLoS
	void SlowToStop__FinishedFunc(); // Function BP_Grenade.BP_Grenade_C.SlowToStop__FinishedFunc
	void SlowToStop__UpdateFunc(); // Function BP_Grenade.BP_Grenade_C.SlowToStop__UpdateFunc
	void SpawnImplosionVFX(struct FTransform XForm); // Function BP_Grenade.BP_Grenade_C.SpawnImplosionVFX
	void Server_SpawnPlasmaBall(struct FTransform XForm, struct ABP_Grenade_C* BP_NewGrenade, bool Found?); // Function BP_Grenade.BP_Grenade_C.Server_SpawnPlasmaBall
	void ReceiveBeginPlay(); // Function BP_Grenade.BP_Grenade_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Grenade.BP_Grenade_C.ReceiveTick
	void SetBlinkingLoop(); // Function BP_Grenade.BP_Grenade_C.SetBlinkingLoop
	void ActivateProjectile(struct FVector_NetQuantize10 Location, struct FRotator Rotation, bool Just Fall); // Function BP_Grenade.BP_Grenade_C.ActivateProjectile
	void MC_ActivateProjectile(struct FVector_NetQuantize10 Location, struct FRotator Rotation, bool Just Fall); // Function BP_Grenade.BP_Grenade_C.MC_ActivateProjectile
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Grenade.BP_Grenade_C.ReceiveEndPlay
	void ResetMaterial_nonFP(); // Function BP_Grenade.BP_Grenade_C.ResetMaterial_nonFP
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Grenade.BP_Grenade_C.ReceiveHit
	void ExecuteUbergraph_BP_Grenade(int32_t EntryPoint); // Function BP_Grenade.BP_Grenade_C.ExecuteUbergraph_BP_Grenade
}; 



