#pragma once 
#include "SDK.h" 
 
 
// Function BP_FirstVanSpawn.BP_FirstVanSpawn_C.ExecuteUbergraph_BP_FirstVanSpawn
// Size: 0x83(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FirstVanSpawn
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x8(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct TArray<struct ABP_VanStoppingPoint_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct ABP_VanStoppingPoint_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x50(0xC)
	char pad_92[4];  // 0x5C(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x60(0x8)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x68(0xC)
	char pad_116[4];  // 0x74(0x4)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x81(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x82(0x1)

}; 
// Function BP_FirstVanSpawn.BP_FirstVanSpawn_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
