#pragma once 
#include <BP_ShatterProp_Generic_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ShatterProp_Generic.BP_ShatterProp_Generic_C
// Size: 0x2A0(Inherited: 0x220) 
struct ABP_ShatterProp_Generic_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDestructibleComponent* Destructible;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct UDestructibleMesh* DestructibleMesh;  // 0x238(0x8)
	struct FTransform MeshTransform_WORLD;  // 0x240(0x30)
	struct FVector Velocity;  // 0x270(0xC)
	float VelocityDividerDampener;  // 0x27C(0x4)
	float ImpulseStrength;  // 0x280(0x4)
	float Damage;  // 0x284(0x4)
	char SmashMaterialType Smash Material;  // 0x288(0x1)
	char Ghost_SizeClass Smash Size;  // 0x289(0x1)
	char pad_650[6];  // 0x28A(0x6)
	AProp_C* Prop Class;  // 0x290(0x8)
	struct APropXFormHolder_C* MyXFormHolder;  // 0x298(0x8)

	void ReceiveBeginPlay(); // Function BP_ShatterProp_Generic.BP_ShatterProp_Generic_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ShatterProp_Generic(int32_t EntryPoint); // Function BP_ShatterProp_Generic.BP_ShatterProp_Generic_C.ExecuteUbergraph_BP_ShatterProp_Generic
}; 



