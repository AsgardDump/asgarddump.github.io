#pragma once 
#include "SDK.h" 
 
 
// Function BlackBGGameStart_UI.BlackBGGameStart_UI_C.ExecuteUbergraph_BlackBGGameStart_UI
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BlackBGGameStart_UI
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x8(0x8)

}; 
