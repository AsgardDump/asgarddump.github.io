#pragma once 
#include <BorkedActorHere_Structs.h>
 
 
 
// BlueprintGeneratedClass BorkedActorHere.BorkedActorHere_C
// Size: 0x230(Inherited: 0x220) 
struct ABorkedActorHere_C : public AActor
{
	struct UPointLightComponent* PointLight;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)

}; 



