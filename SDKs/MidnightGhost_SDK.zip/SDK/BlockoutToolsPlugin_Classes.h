#pragma once 
#include <BlockoutToolsPlugin_Structs.h>
 
 
 
// Class BlockoutToolsPlugin.BlockoutToolsParent
// Size: 0x270(Inherited: 0x220) 
struct ABlockoutToolsParent : public AActor
{
	struct USceneComponent* Root;  // 0x220(0x8)
	struct UBillboardComponent* Billboard;  // 0x228(0x8)
	struct UMaterialInterface* BlockoutGridParent;  // 0x230(0x8)
	struct UMaterialInstanceDynamic* BlockoutGridMID;  // 0x238(0x8)
	struct UMaterialInterface* BlockoutCurrentMaterial;  // 0x240(0x8)
	struct TArray<struct UStaticMeshComponent*> BlockoutMeshComponents;  // 0x248(0x10)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool bUseCustomMaterial : 1;  // 0x258(0x1)
	char pad_601[7];  // 0x259(0x7)
	struct UMaterialInterface* CustomMaterial;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool bBlockoutCastShadows : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)

	void BlockoutSetMaterial(bool bUseGrid, struct FLinearColor Color, bool bUseTopColor, struct FLinearColor TopColor); // Function BlockoutToolsPlugin.BlockoutToolsParent.BlockoutSetMaterial
}; 



