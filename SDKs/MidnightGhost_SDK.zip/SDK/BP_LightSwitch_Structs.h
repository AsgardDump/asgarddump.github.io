#pragma once 
#include "SDK.h" 
 
 
// Function BP_LightSwitch.BP_LightSwitch_C.ExecuteUbergraph_BP_LightSwitch
// Size: 0xA1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LightSwitch
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct USoundBase* Temp_object_Variable;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct USoundBase* Temp_object_Variable_2;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct TArray<struct ABP_LightSwitchable_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x28(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x3C(0x4)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_Player_Controller;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x50(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x54(0x4)
	struct ABP_LightSwitchable_C* CallFunc_Array_Get_Item;  // 0x58(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool K2Node_CustomEvent_Off_on : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct ABP_LightSwitchable_C* CallFunc_Array_Get_Item_2;  // 0x70(0x8)
	struct USoundBase* K2Node_Select_Default;  // 0x78(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x80(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x92(0x1)
	char pad_147[5];  // 0x93(0x5)
	struct ABP_LightSwitchable_C* CallFunc_Array_Get_Item_3;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xA0(0x1)

}; 
// Function BP_LightSwitch.BP_LightSwitch_C.LightSwitch_Interact
// Size: 0x8(Inherited: 0x0) 
struct FLightSwitch_Interact
{
	struct AMGH_PlayerController_BP_C* Player Controller;  // 0x0(0x8)

}; 
// Function BP_LightSwitch.BP_LightSwitch_C.MC_LightSwitch
// Size: 0x1(Inherited: 0x0) 
struct FMC_LightSwitch
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)

}; 
