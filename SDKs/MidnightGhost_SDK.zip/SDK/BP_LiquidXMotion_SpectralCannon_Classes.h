#pragma once 
#include <BP_LiquidXMotion_SpectralCannon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LiquidXMotion_SpectralCannon.BP_LiquidXMotion_SpectralCannon_C
// Size: 0x2C0(Inherited: 0x220) 
struct ABP_LiquidXMotion_SpectralCannon_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh_Liquid;  // 0x228(0x8)
	struct UMaterialInstanceDynamic* LiquidXMaterialInstance;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool IsFP : 1;  // 0x238(0x1)
	char pad_569[3];  // 0x239(0x3)
	float DeltaTime;  // 0x23C(0x4)
	float TimeAlive;  // 0x240(0x4)
	float FillHeightVar;  // 0x244(0x4)
	struct ABP_Hunter_C* MyHunter;  // 0x248(0x8)
	float HeadingPhysCurrent;  // 0x250(0x4)
	float HeadingDelta;  // 0x254(0x4)
	struct FFloatSpringState Spring State Centrifugal;  // 0x258(0x8)
	struct FVectorSpringState Spring StateTranslation;  // 0x260(0x18)
	struct FVector TransPhysCurrent;  // 0x278(0xC)
	float PitchPhysCurrent;  // 0x284(0x4)
	float PitchDelta;  // 0x288(0x4)
	struct FFloatSpringState Spring State Pitch;  // 0x28C(0x8)
	char pad_660[4];  // 0x294(0x4)
	struct UCurveFloat* CurveFalloff;  // 0x298(0x8)
	float Pitch;  // 0x2A0(0x4)
	float HeadingDeltaSmooth;  // 0x2A4(0x4)
	struct FRotator ActorRotLastFrame;  // 0x2A8(0xC)
	float PitchLastFrame;  // 0x2B4(0x4)
	struct UCurveFloat* FillCurve;  // 0x2B8(0x8)

	void UserConstructionScript(); // Function BP_LiquidXMotion_SpectralCannon.BP_LiquidXMotion_SpectralCannon_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_LiquidXMotion_SpectralCannon.BP_LiquidXMotion_SpectralCannon_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_LiquidXMotion_SpectralCannon.BP_LiquidXMotion_SpectralCannon_C.ReceiveTick
	void ExecuteUbergraph_BP_LiquidXMotion_SpectralCannon(int32_t EntryPoint); // Function BP_LiquidXMotion_SpectralCannon.BP_LiquidXMotion_SpectralCannon_C.ExecuteUbergraph_BP_LiquidXMotion_SpectralCannon
}; 



