#pragma once 
#include <BP_Miasma_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Miasma.BP_Miasma_C
// Size: 0x3CC(Inherited: 0x220) 
struct ABP_Miasma_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNavModifierComponent* NavModifier;  // 0x228(0x8)
	struct UPointLightComponent* MiasmaPurpleLight;  // 0x230(0x8)
	struct USceneComponent* Scene8;  // 0x238(0x8)
	struct USceneComponent* Scene7;  // 0x240(0x8)
	struct USceneComponent* Scene6;  // 0x248(0x8)
	struct USceneComponent* Scene5;  // 0x250(0x8)
	struct USceneComponent* Scene3;  // 0x258(0x8)
	struct USceneComponent* Scene2;  // 0x260(0x8)
	struct USceneComponent* Scene1;  // 0x268(0x8)
	struct USceneComponent* Scene;  // 0x270(0x8)
	struct UParticleSystemComponent* Emitter_Shockwave_Small_Var01_Strong1;  // 0x278(0x8)
	struct UParticleSystemComponent* Emitter_Fireball_Small_Raising_Var03_Narrow;  // 0x280(0x8)
	struct UParticleSystemComponent* Emitter_Sparks_Medium_Radial;  // 0x288(0x8)
	struct UParticleSystemComponent* Emitter_Shockwave_Small_Var01_Strong;  // 0x290(0x8)
	struct UParticleSystemComponent* Emitter_Shockwave_Medium_Var01_Medium;  // 0x298(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2A0(0x8)
	float Light_Lerp_32A0A83B4D891652451BE9A3C5D55154;  // 0x2A8(0x4)
	char ETimelineDirection Light__Direction_32A0A83B4D891652451BE9A3C5D55154;  // 0x2AC(0x1)
	char pad_685[3];  // 0x2AD(0x3)
	struct UTimelineComponent* Light;  // 0x2B0(0x8)
	float DmgOverlapScale_DamagePerTick_B78D10544F63E675FA8832B6FFBD8223;  // 0x2B8(0x4)
	char ETimelineDirection DmgOverlapScale__Direction_B78D10544F63E675FA8832B6FFBD8223;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct UTimelineComponent* DmgOverlapScale;  // 0x2C0(0x8)
	struct AController* My Ghost Player;  // 0x2C8(0x8)
	float DmgPerTick;  // 0x2D0(0x4)
	char pad_724_1 : 7;  // 0x2D4(0x1)
	bool RedDmg? : 1;  // 0x2D4(0x1)
	char pad_725[3];  // 0x2D5(0x3)
	struct TArray<struct ABP_MiasmaGrow_C*> MyMiasmaGrows;  // 0x2D8(0x10)
	struct TArray<struct AActor*> OverlappedDamageActorsMain;  // 0x2E8(0x10)
	struct TArray<struct USceneComponent*> Wave1;  // 0x2F8(0x10)
	struct TArray<struct FVector> Wave1Loc;  // 0x308(0x10)
	int32_t TotalSuccessful;  // 0x318(0x4)
	char pad_796[4];  // 0x31C(0x4)
	struct TArray<struct FVector> SpaceChecker_Instructions;  // 0x320(0x10)
	struct TArray<struct FVector> Wave2Loc;  // 0x330(0x10)
	struct TArray<struct FVector> Wave3Loc;  // 0x340(0x10)
	struct TArray<struct FVector> Wave4Loc;  // 0x350(0x10)
	struct TArray<struct FVector> Wave5Loc;  // 0x360(0x10)
	float LightInitialIntensity;  // 0x370(0x4)
	char pad_884[4];  // 0x374(0x4)
	struct TMap<struct AActor*, struct ABP_MiasmaGrow_C*> WhichMiasmaGrowForLOS?;  // 0x378(0x50)
	float GrowTime;  // 0x3C8(0x4)

	void Check LOS(struct AActor* Target, bool Generator, bool& bLocked); // Function BP_Miasma.BP_Miasma_C.Check LOS
	void GrowMiasma(struct TArray<struct FVector>& Array); // Function BP_Miasma.BP_Miasma_C.GrowMiasma
	void DmgOverlapScale__FinishedFunc(); // Function BP_Miasma.BP_Miasma_C.DmgOverlapScale__FinishedFunc
	void DmgOverlapScale__UpdateFunc(); // Function BP_Miasma.BP_Miasma_C.DmgOverlapScale__UpdateFunc
	void Light__FinishedFunc(); // Function BP_Miasma.BP_Miasma_C.Light__FinishedFunc
	void Light__UpdateFunc(); // Function BP_Miasma.BP_Miasma_C.Light__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Miasma.BP_Miasma_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Miasma.BP_Miasma_C.ReceiveTick
	void CalcTraceLocations(); // Function BP_Miasma.BP_Miasma_C.CalcTraceLocations
	void Server_MiasmaHitShield(struct ABP_Hunter_C* BPHunter); // Function BP_Miasma.BP_Miasma_C.Server_MiasmaHitShield
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Miasma.BP_Miasma_C.ReceiveEndPlay
	void ReceiveDestroyed(); // Function BP_Miasma.BP_Miasma_C.ReceiveDestroyed
	void ExecuteUbergraph_BP_Miasma(int32_t EntryPoint); // Function BP_Miasma.BP_Miasma_C.ExecuteUbergraph_BP_Miasma
}; 



