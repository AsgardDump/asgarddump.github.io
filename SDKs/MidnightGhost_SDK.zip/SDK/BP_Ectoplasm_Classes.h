#pragma once 
#include <BP_Ectoplasm_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ectoplasm.BP_Ectoplasm_C
// Size: 0x2C2(Inherited: 0x220) 
struct ABP_Ectoplasm_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* NS_HealthOrbSpawn;  // 0x228(0x8)
	struct UWidgetComponent* Widget;  // 0x230(0x8)
	struct UNiagaraComponent* NS_HealthOrb;  // 0x238(0x8)
	struct UStaticMeshComponent* OrbMesh_New;  // 0x240(0x8)
	struct USceneComponent* Scene;  // 0x248(0x8)
	struct UStaticMeshComponent* OrbMesh_old;  // 0x250(0x8)
	struct USphereComponent* Sphere1;  // 0x258(0x8)
	struct UParticleSystemComponent* ParticleSystem2;  // 0x260(0x8)
	struct UParticleSystemComponent* ParticleSystem3;  // 0x268(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x270(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x278(0x8)
	struct USphereComponent* Sphere2;  // 0x280(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x288(0x8)
	struct UPointLightComponent* PointLight;  // 0x290(0x8)
	float InterpTo0_NewTrack_1_094E1BB442908924996F4287418D18CA;  // 0x298(0x4)
	char ETimelineDirection InterpTo0__Direction_094E1BB442908924996F4287418D18CA;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct UTimelineComponent* InterpTo0;  // 0x2A0(0x8)
	struct UAudioComponent* LoopSound;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Need Movement Component? : 1;  // 0x2B0(0x1)
	char pad_689_1 : 7;  // 0x2B1(0x1)
	bool NoHidey : 1;  // 0x2B1(0x1)
	char pad_690[6];  // 0x2B2(0x6)
	struct AMGH_PlayerState_C* IFSPAWNED_WhoSpawned;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool WasSpawned? : 1;  // 0x2C0(0x1)
	char pad_705_1 : 7;  // 0x2C1(0x1)
	bool SaltWater : 1;  // 0x2C1(0x1)

	void UserConstructionScript(); // Function BP_Ectoplasm.BP_Ectoplasm_C.UserConstructionScript
	void InterpTo0__FinishedFunc(); // Function BP_Ectoplasm.BP_Ectoplasm_C.InterpTo0__FinishedFunc
	void InterpTo0__UpdateFunc(); // Function BP_Ectoplasm.BP_Ectoplasm_C.InterpTo0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Ectoplasm.BP_Ectoplasm_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Ectoplasm.BP_Ectoplasm_C.ReceiveTick
	void BndEvt__Sphere1_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_Ectoplasm.BP_Ectoplasm_C.BndEvt__Sphere1_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void UseHealingOrb(struct AProp_C* Prop, bool Skip Heal); // Function BP_Ectoplasm.BP_Ectoplasm_C.UseHealingOrb
	void MC_SetSoundOff(); // Function BP_Ectoplasm.BP_Ectoplasm_C.MC_SetSoundOff
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Ectoplasm.BP_Ectoplasm_C.ReceiveHit
	void Hideme(); // Function BP_Ectoplasm.BP_Ectoplasm_C.Hideme
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Ectoplasm.BP_Ectoplasm_C.ReceiveEndPlay
	void ReceiveDestroyed(); // Function BP_Ectoplasm.BP_Ectoplasm_C.ReceiveDestroyed
	void ExecuteUbergraph_BP_Ectoplasm(int32_t EntryPoint); // Function BP_Ectoplasm.BP_Ectoplasm_C.ExecuteUbergraph_BP_Ectoplasm
}; 



