#pragma once 
#include <BP_EnvironmentObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EnvironmentObject.BP_EnvironmentObject_C
// Size: 0x2D8(Inherited: 0x281) 
struct ABP_EnvironmentObject_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UTextRenderComponent* TextRender;  // 0x290(0x8)
	struct UStaticMeshComponent* Cube;  // 0x298(0x8)
	struct UBoxComponent* Box;  // 0x2A0(0x8)
	struct FText InteractionInformation;  // 0x2A8(0x18)
	struct FText Value;  // 0x2C0(0x18)

	void CanIInteract_Int(bool& BlockInteract, struct FText& ErrorMessage); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.CanIInteract_Int
	void CanIPickUp_Int(struct AActor* RequestingActor, bool& OK); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.CanIPickUp_Int
	void getInteractData(struct FText& interactionTextHUD, bool& UseImageTextPrompt, struct UTexture2D*& ImageTextIcon, struct FText& ImageText1, struct FText& ImageText2); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.getInteractData
	void UserConstructionScript(); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.UserConstructionScript
	void InteractEnvironment_Int(struct AActor* ActivatingActor); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.InteractEnvironment_Int
	void ServerEnvironmentInteract_Int(struct AActor* ActivatingActor); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.ServerEnvironmentInteract_Int
	void Interact_Interactive Object(struct AMGH_PlayerController_BP_C* Controller, bool Alternate?); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.Interact_Interactive Object
	void Server_Smart Interact(); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.Server_Smart Interact
	void MC_SmartInteraction(); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.MC_SmartInteraction
	void ExecuteUbergraph_BP_EnvironmentObject(int32_t EntryPoint); // Function BP_EnvironmentObject.BP_EnvironmentObject_C.ExecuteUbergraph_BP_EnvironmentObject
}; 



