#pragma once 
#include "SDK.h" 
 
 
// Function BP_PC_InputDetect.BP_PC_InputDetect_C.InpActEvt_AnyKey_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_AnyKey_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_InputDetect.BP_PC_InputDetect_C.ExecuteUbergraph_BP_PC_InputDetect
// Size: 0x6A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PC_InputDetect
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x8(0x8)
	struct FIntPoint CallFunc_GetDesktopResolution_ReturnValue;  // 0x10(0x8)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue_2;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_GetShowMouse_bShowMouse : 1;  // 0x20(0x1)
	uint8_t  CallFunc_GetInputType_InputType;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x23(0x1)
	char pad_36[4];  // 0x24(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x38(0x18)
	struct FKey CallFunc_FindRightInputType_LastPressedKey;  // 0x50(0x18)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0x69(0x1)

}; 
// Function BP_PC_InputDetect.BP_PC_InputDetect_C.FindRightInputType
// Size: 0x33(Inherited: 0x0) 
struct FFindRightInputType
{
	struct FKey InputKey;  // 0x0(0x18)
	struct FKey LastPressedKey;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Key_IsMouseButton_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Key_IsKeyboardKey_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_Key_IsGamepadKey_ReturnValue : 1;  // 0x32(0x1)

}; 
// Function BP_PC_InputDetect.BP_PC_InputDetect_C.GetIsMouseMoving
// Size: 0x13(Inherited: 0x0) 
struct FGetIsMouseMoving
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_GetInputMouseDelta_DeltaX;  // 0x4(0x4)
	float CallFunc_GetInputMouseDelta_DeltaY;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x12(0x1)

}; 
