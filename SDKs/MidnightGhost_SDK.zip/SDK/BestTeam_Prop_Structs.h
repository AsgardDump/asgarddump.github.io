#pragma once 
#include "SDK.h" 
 
 
// Function BestTeam_Prop.BestTeam_Prop_C.ExecuteUbergraph_BestTeam_Prop
// Size: 0x4E1(Inherited: 0x0) 
struct FExecuteUbergraph_BestTeam_Prop
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBestTeam_Nameplate_UI_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x40(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x4C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x58(0xC)
	char pad_100[12];  // 0x64(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0x70(0x30)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult;  // 0xA0(0x88)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult_2;  // 0x128(0x88)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult_3;  // 0x1B0(0x88)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult_4;  // 0x238(0x88)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)
	struct FString CallFunc_GetMGHPlayerName_Player_Name;  // 0x2C8(0x10)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x2D8(0x1)
	char pad_729[7];  // 0x2D9(0x7)
	struct TArray<struct APropXFormHolder_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x2E0(0x10)
	struct APropXFormHolder_C* CallFunc_Array_Get_Item;  // 0x2F0(0x8)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x2F9(0x1)
	char pad_762[6];  // 0x2FA(0x6)
	struct FXFormHolderStruc CallFunc_ReturnLvlpropXForms_XForm;  // 0x300(0x100)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x400(0xC)
	char pad_1036[4];  // 0x40C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue_3;  // 0x410(0x30)
	char pad_1088_1 : 7;  // 0x440(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x440(0x1)
	char pad_1089[3];  // 0x441(0x3)
	struct FHitResult CallFunc_K2_SetRelativeTransform_SweepHitResult_5;  // 0x444(0x88)
	char pad_1228[4];  // 0x4CC(0x4)
	AActor* CallFunc_GetUnpossessedClassForPossessed_ClassOut;  // 0x4D0(0x8)
	struct UStaticMesh* CallFunc_GetUnpossessedClassForPossessed_BaseMesh;  // 0x4D8(0x8)
	char pad_1248_1 : 7;  // 0x4E0(0x1)
	bool CallFunc_GetUnpossessedClassForPossessed_Found : 1;  // 0x4E0(0x1)

}; 
// Function BestTeam_Prop.BestTeam_Prop_C.DetermineSkelMesh
// Size: 0x1A(Inherited: 0x0) 
struct FDetermineSkelMesh
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Found? : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USkeletalMesh* Skel Mesh;  // 0x8(0x8)
	UObject* AnimBP;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_2 : 1;  // 0x19(0x1)

}; 
