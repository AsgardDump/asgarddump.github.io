#pragma once 
#include "SDK.h" 
 
 
// Function BP_BigMachine_Type1Panel.BP_BigMachine_Type1Panel_C.ExecuteUbergraph_BP_BigMachine_Type1Panel
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BigMachine_Type1Panel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_PC;  // 0x8(0x8)

}; 
// Function BP_BigMachine_Type1Panel.BP_BigMachine_Type1Panel_C.Smasher
// Size: 0x8(Inherited: 0x0) 
struct FSmasher
{
	struct AMGH_PlayerController_BP_C* PC;  // 0x0(0x8)

}; 
