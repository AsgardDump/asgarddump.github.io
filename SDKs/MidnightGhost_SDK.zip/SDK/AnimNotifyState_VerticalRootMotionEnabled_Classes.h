#pragma once 
#include <AnimNotifyState_VerticalRootMotionEnabled_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimNotifyState_VerticalRootMotionEnabled.AnimNotifyState_VerticalRootMotionEnabled_C
// Size: 0x30(Inherited: 0x30) 
struct UAnimNotifyState_VerticalRootMotionEnabled_C : public UAnimNotifyState
{

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_VerticalRootMotionEnabled.AnimNotifyState_VerticalRootMotionEnabled_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_VerticalRootMotionEnabled.AnimNotifyState_VerticalRootMotionEnabled_C.Received_NotifyBegin
}; 



