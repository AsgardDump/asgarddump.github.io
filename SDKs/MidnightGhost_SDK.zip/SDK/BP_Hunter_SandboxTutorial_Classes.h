#pragma once 
#include <BP_Hunter_SandboxTutorial_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C
// Size: 0x266A(Inherited: 0x2658) 
struct ABP_Hunter_SandboxTutorial_C : public ABP_Hunter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2658(0x8)
	struct AMGH_HUD_C* MyTutHud;  // 0x2660(0x8)
	char pad_9832_1 : 7;  // 0x2668(0x1)
	bool Switch2Weapon : 1;  // 0x2668(0x1)
	char pad_9833_1 : 7;  // 0x2669(0x1)
	bool SwitchOffWEAPON : 1;  // 0x2669(0x1)

	void InpActEvt_Ctrl+Alt_P_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C.InpActEvt_Ctrl+Alt_P_K2Node_InputKeyEvent_1
	void ReceiveBeginPlay(); // Function BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C.ReceiveBeginPlay
	void SetUpHudRef(struct AMGH_HUD_C* HUD); // Function BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C.SetUpHudRef
	void ExecuteUbergraph_BP_Hunter_SandboxTutorial(int32_t EntryPoint); // Function BP_Hunter_SandboxTutorial.BP_Hunter_SandboxTutorial_C.ExecuteUbergraph_BP_Hunter_SandboxTutorial
}; 



