#pragma once 
#include <AnimNotifyState_VictoryPose_AttachObject_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimNotifyState_VictoryPose_AttachObject.AnimNotifyState_VictoryPose_AttachObject_C
// Size: 0x70(Inherited: 0x30) 
struct UAnimNotifyState_VictoryPose_AttachObject_C : public UAnimNotifyState
{
	AActor* Prop To Spawn;  // 0x30(0x8)
	struct FName Socket Name;  // 0x38(0x8)
	struct FTransform Offsets;  // 0x40(0x30)

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_VictoryPose_AttachObject.AnimNotifyState_VictoryPose_AttachObject_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_VictoryPose_AttachObject.AnimNotifyState_VictoryPose_AttachObject_C.Received_NotifyBegin
}; 



