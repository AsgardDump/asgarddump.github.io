#pragma once 
#include "SDK.h" 
 
 
// Function BP_FlickeringLamp.BP_FlickeringLamp_C.ExecuteUbergraph_BP_FlickeringLamp
// Size: 0x1A8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FlickeringLamp
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool K2Node_CustomEvent_Off_on_3 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool K2Node_CustomEvent_Off_on_2 : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool K2Node_CustomEvent_Skip_Sound_ : 1;  // 0xF(0x1)
	struct ABP_FlickeringLamp_C* K2Node_CustomEvent_Light;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_CustomEvent_Off_on : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x1C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x24(0x4)
	struct FLinearColor CallFunc_MakeColor_ReturnValue;  // 0x28(0x10)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_2;  // 0x38(0x10)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x48(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x68(0x10)
	char pad_120[8];  // 0x78(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x80(0x30)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0xB0(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xB8(0x8)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors;  // 0xC0(0x10)
	struct ABP_FlickeringLampSOUND_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xD0(0x8)
	struct AActor* CallFunc_Array_Get_Item;  // 0xD8(0x8)
	struct ABP_FlickeringLampSOUND_C* K2Node_DynamicCast_AsBP_Flickering_Lamp_SOUND;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xEC(0x4)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	struct FName CallFunc_Conv_StringToName_ReturnValue_2;  // 0xF4(0x8)
	char pad_252[4];  // 0xFC(0x4)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x100(0x10)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	float CallFunc_MakeLiteralFloat_ReturnValue_2;  // 0x114(0x4)
	float CallFunc_MakeLiteralFloat_ReturnValue_3;  // 0x118(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x11C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x120(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x124(0x4)
	char pad_296[8];  // 0x128(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x130(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x160(0x8)
	struct ABP_Sound_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x168(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x170(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x174(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x178(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0x17C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x180(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x184(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x188(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_5;  // 0x18C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_5;  // 0x190(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_6;  // 0x194(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x198(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x19C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x1A0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x1A4(0x4)

}; 
// Function BP_FlickeringLamp.BP_FlickeringLamp_C.OC_SyncLights
// Size: 0x9(Inherited: 0x0) 
struct FOC_SyncLights
{
	struct ABP_FlickeringLamp_C* Light;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool On : 1;  // 0x8(0x1)

}; 
// Function BP_FlickeringLamp.BP_FlickeringLamp_C.NR_TurnOnOff
// Size: 0x2(Inherited: 0x0) 
struct FNR_TurnOnOff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Skip Sound? : 1;  // 0x1(0x1)

}; 
// Function BP_FlickeringLamp.BP_FlickeringLamp_C.UserConstructionScript
// Size: 0xC(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_FlickeringLamp.BP_FlickeringLamp_C.TurnOnOff
// Size: 0x1(Inherited: 0x0) 
struct FTurnOnOff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)

}; 
