#pragma once 
#include "SDK.h" 
 
 
// Function BP_MusicCassette.BP_MusicCassette_C.ExecuteUbergraph_BP_MusicCassette
// Size: 0x61(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MusicCassette
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct UStaticMesh* CallFunc_GetCassetteMeshForMusic_Mesh;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ABP_CassetteInteract_C* K2Node_DynamicCast_AsBP_Cassette_Interact;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AActor* K2Node_Event_ActivatedActor;  // 0x28(0x8)
	struct TScriptInterface<IMGHPlayerController_Interface_C> K2Node_DynamicCast_AsMGHPlayer_Controller_Interface;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x48(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x60(0x1)

}; 
// Function BP_MusicCassette.BP_MusicCassette_C.InteractCassette_LocalClient_Int
// Size: 0x8(Inherited: 0x0) 
struct FInteractCassette_LocalClient_Int
{
	struct AActor* ActivatedActor;  // 0x0(0x8)

}; 
// Function BP_MusicCassette.BP_MusicCassette_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
