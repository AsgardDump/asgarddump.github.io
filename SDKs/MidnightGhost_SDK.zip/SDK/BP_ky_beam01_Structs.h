#pragma once 
#include "SDK.h" 
 
 
// Function BP_ky_beam01.BP_ky_beam01_C.ExecuteUbergraph_BP_ky_beam01
// Size: 0x3B5(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ky_beam01
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	float CallFunc_BreakVector_X;  // 0x10(0x4)
	float CallFunc_BreakVector_Y;  // 0x14(0x4)
	float CallFunc_BreakVector_Z;  // 0x18(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x20(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x2C(0xC)
	char pad_56[8];  // 0x38(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x40(0x30)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x78(0x8)
	struct ABP_ky_empty_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	struct FVector CallFunc_GetActorScale3D_ReturnValue;  // 0x8C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x98(0xC)
	char pad_164[12];  // 0xA4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xB0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0xE0(0x8)
	struct FName CallFunc_Array_Get_Item;  // 0xE8(0x8)
	struct ABP_ky_empty_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xF9(0x1)
	char pad_250[2];  // 0xFA(0x2)
	struct FName CallFunc_Array_Get_Item_2;  // 0xFC(0x8)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x104(0x1)
	char pad_261_1 : 7;  // 0x105(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue_2 : 1;  // 0x105(0x1)
	char pad_262_1 : 7;  // 0x106(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x106(0x1)
	char pad_263_1 : 7;  // 0x107(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x107(0x1)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x110(0x30)
	struct FHitResult CallFunc_K2_SetActorTransform_SweepHitResult;  // 0x140(0x88)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool CallFunc_K2_SetActorTransform_ReturnValue : 1;  // 0x1C8(0x1)
	char pad_457[3];  // 0x1C9(0x3)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x1CC(0x88)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x254(0xC)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x264(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x270(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x27C(0xC)
	float K2Node_Event_DeltaSeconds;  // 0x288(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x28C(0xC)
	struct FHitResult CallFunc_K2_AddActorLocalOffset_SweepHitResult;  // 0x298(0x88)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x320(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x32C(0x88)
	char pad_948_1 : 7;  // 0x3B4(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x3B4(0x1)

}; 
// Function BP_ky_beam01.BP_ky_beam01_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_ky_beam01.BP_ky_beam01_C.UserConstructionScript
// Size: 0x18(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x0(0xC)
	struct FVector CallFunc_Conv_LinearColorToVector_ReturnValue;  // 0xC(0xC)

}; 
