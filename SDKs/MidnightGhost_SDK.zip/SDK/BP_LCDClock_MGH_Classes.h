#pragma once 
#include <BP_LCDClock_MGH_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LCDClock_MGH.BP_LCDClock_MGH_C
// Size: 0x304(Inherited: 0x220) 
struct ABP_LCDClock_MGH_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* HousingMesh;  // 0x228(0x8)
	struct UStaticMeshComponent* SM_LCDBack;  // 0x230(0x8)
	struct UStaticMeshComponent* MinB;  // 0x238(0x8)
	struct UStaticMeshComponent* MinA;  // 0x240(0x8)
	struct UStaticMeshComponent* HourB;  // 0x248(0x8)
	struct UStaticMeshComponent* HourA;  // 0x250(0x8)
	struct UStaticMeshComponent* SM_LCDColon;  // 0x258(0x8)
	struct USceneComponent* Scene;  // 0x260(0x8)
	int32_t HousingVariation;  // 0x268(0x4)
	char Enum_Material HousingMaterial;  // 0x26C(0x1)
	char pad_621_1 : 7;  // 0x26D(0x1)
	bool DisplayRealTime : 1;  // 0x26D(0x1)
	char pad_622[2];  // 0x26E(0x2)
	struct FLinearColor DisplayGlowColor;  // 0x270(0x10)
	float DisplayGlowBrightness;  // 0x280(0x4)
	float AgeHousing;  // 0x284(0x4)
	struct UMaterialInstanceDynamic* DynMatLCD;  // 0x288(0x8)
	float NormalMapStrengthValve;  // 0x290(0x4)
	float MetallicValve;  // 0x294(0x4)
	float ValveDesaturateTexture;  // 0x298(0x4)
	char Enum_ClockType 24Hour;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	int32_t CustomHours;  // 0x2A0(0x4)
	int32_t CustomMinutes;  // 0x2A4(0x4)
	int32_t CustomSeconds;  // 0x2A8(0x4)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool TickCustomTime : 1;  // 0x2AC(0x1)
	char pad_685[3];  // 0x2AD(0x3)
	float FadeOutTextureHousing;  // 0x2B0(0x4)
	float DesaturateTextureHousing;  // 0x2B4(0x4)
	float MetallicHousing;  // 0x2B8(0x4)
	float SpecularHousing;  // 0x2BC(0x4)
	float RoughnessHousing;  // 0x2C0(0x4)
	float NormalMapStrengthHousing;  // 0x2C4(0x4)
	struct FLinearColor TintHousing;  // 0x2C8(0x10)
	struct UMaterialInstanceDynamic* DynMatGlass;  // 0x2D8(0x8)
	struct UMaterialInstanceDynamic* DynMatHousing;  // 0x2E0(0x8)
	int32_t CustomTimeCacheHour;  // 0x2E8(0x4)
	int32_t CustomTimeCacheMinute;  // 0x2EC(0x4)
	float AgeGlass;  // 0x2F0(0x4)
	float OpacityGlass;  // 0x2F4(0x4)
	float RoughnessGlass;  // 0x2F8(0x4)
	float NormalMapStrengthGlass;  // 0x2FC(0x4)
	int32_t CustomTimeCacheSecond;  // 0x300(0x4)

	void GetCurrentClockTime(float& Hour, float& Minute, float& Second); // Function BP_LCDClock_MGH.BP_LCDClock_MGH_C.GetCurrentClockTime
	void UserConstructionScript(); // Function BP_LCDClock_MGH.BP_LCDClock_MGH_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_LCDClock_MGH.BP_LCDClock_MGH_C.ReceiveBeginPlay
	void ResetClock(); // Function BP_LCDClock_MGH.BP_LCDClock_MGH_C.ResetClock
	void ExecuteUbergraph_BP_LCDClock_MGH(int32_t EntryPoint); // Function BP_LCDClock_MGH.BP_LCDClock_MGH_C.ExecuteUbergraph_BP_LCDClock_MGH
}; 



