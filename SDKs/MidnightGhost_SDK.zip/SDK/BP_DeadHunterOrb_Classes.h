#pragma once 
#include <BP_DeadHunterOrb_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DeadHunterOrb.BP_DeadHunterOrb_C
// Size: 0x36A(Inherited: 0x281) 
struct ABP_DeadHunterOrb_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UPointLightComponent* PointLight;  // 0x290(0x8)
	struct UWidgetComponent* RezWidget;  // 0x298(0x8)
	struct UParticleSystemComponent* ParticleSystem2;  // 0x2A0(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x2A8(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x2B0(0x8)
	struct UStaticMeshComponent* Sphere;  // 0x2B8(0x8)
	struct USphereComponent* CollisionComponent;  // 0x2C0(0x8)
	char ETimelineDirection TL_RaiseRagdoll__Direction_48F0F74646EACCEC1C3CA2800748B208;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)
	struct UTimelineComponent* TL_RaiseRagdoll;  // 0x2D0(0x8)
	float Flicker_Lerp_5C71BEA94F8E30AD9E80F69BE348AD24;  // 0x2D8(0x4)
	char ETimelineDirection Flicker__Direction_5C71BEA94F8E30AD9E80F69BE348AD24;  // 0x2DC(0x1)
	char pad_733[3];  // 0x2DD(0x3)
	struct UTimelineComponent* Flicker;  // 0x2E0(0x8)
	float FadeToRed_Lerp_BB60CBA34EF87F81292829AC2E0501E1;  // 0x2E8(0x4)
	char ETimelineDirection FadeToRed__Direction_BB60CBA34EF87F81292829AC2E0501E1;  // 0x2EC(0x1)
	char pad_749[3];  // 0x2ED(0x3)
	struct UTimelineComponent* FadeToRed;  // 0x2F0(0x8)
	float InterpToHunter_Lerp_3A2A746E483685300F445FAE60854E99;  // 0x2F8(0x4)
	char ETimelineDirection InterpToHunter__Direction_3A2A746E483685300F445FAE60854E99;  // 0x2FC(0x1)
	char pad_765[3];  // 0x2FD(0x3)
	struct UTimelineComponent* InterpToHunter;  // 0x300(0x8)
	struct ABP_Hunter_C* MyHunter;  // 0x308(0x8)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool HunterHasBeenRezzed-WaitingOnKillcam : 1;  // 0x310(0x1)
	char pad_785_1 : 7;  // 0x311(0x1)
	bool Disabled_1 : 1;  // 0x311(0x1)
	char pad_786[6];  // 0x312(0x6)
	struct UHunterRezzable_UI_C* RezUI;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool FlyToCorpse? : 1;  // 0x320(0x1)
	char pad_801[3];  // 0x321(0x3)
	struct FVector StartingLocation;  // 0x324(0xC)
	struct FLinearColor OrigLightColor;  // 0x330(0x10)
	struct FLinearColor ConsumeLightColor;  // 0x340(0x10)
	float OrigLightIntensity;  // 0x350(0x4)
	char pad_852[4];  // 0x354(0x4)
	struct UAudioComponent* SoulStart;  // 0x358(0x8)
	struct UAudioComponent* SoulLoop;  // 0x360(0x8)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool RezPending? : 1;  // 0x368(0x1)
	char pad_873_1 : 7;  // 0x369(0x1)
	bool Consumed : 1;  // 0x369(0x1)

	void InterpToHunter__FinishedFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.InterpToHunter__FinishedFunc
	void InterpToHunter__UpdateFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.InterpToHunter__UpdateFunc
	void FadeToRed__FinishedFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.FadeToRed__FinishedFunc
	void FadeToRed__UpdateFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.FadeToRed__UpdateFunc
	void Flicker__FinishedFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.Flicker__FinishedFunc
	void Flicker__UpdateFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.Flicker__UpdateFunc
	void TL_RaiseRagdoll__FinishedFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.TL_RaiseRagdoll__FinishedFunc
	void TL_RaiseRagdoll__UpdateFunc(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.TL_RaiseRagdoll__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ReceiveEndPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ReceiveTick
	void AttachToHunter(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.AttachToHunter
	void ConsumeSoulStart(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ConsumeSoulStart
	void ConsumeSoulEnd(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ConsumeSoulEnd
	void ConsumeSound(bool Start); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ConsumeSound
	void RevivePending(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.RevivePending
	void Set Rez Widget to Hidden(); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.Set Rez Widget to Hidden
	void ExecuteUbergraph_BP_DeadHunterOrb(int32_t EntryPoint); // Function BP_DeadHunterOrb.BP_DeadHunterOrb_C.ExecuteUbergraph_BP_DeadHunterOrb
}; 



