#pragma once 
#include "SDK.h" 
 
 
// Function BP_SmasherPanel.BP_SmasherPanel_C.ExecuteUbergraph_BP_SmasherPanel
// Size: 0x11(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SmasherPanel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_PC;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_SmasherPanel.BP_SmasherPanel_C.Smasher
// Size: 0x8(Inherited: 0x0) 
struct FSmasher
{
	struct AMGH_PlayerController_BP_C* PC;  // 0x0(0x8)

}; 
