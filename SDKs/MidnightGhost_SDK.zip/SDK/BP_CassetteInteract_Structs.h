#pragma once 
#include "SDK.h" 
 
 
// Function BP_CassetteInteract.BP_CassetteInteract_C.ExecuteUbergraph_BP_CassetteInteract
// Size: 0x91(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CassetteInteract
{
	int32_t EntryPoint;  // 0x0(0x4)
	char MGHMusicTrackAlbums CallFunc_WhichGameSoundtrackMusicFrom_Game;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText CallFunc_MusicToText_Text;  // 0x8(0x18)
	struct FText CallFunc_MusicAlbumToText_Text;  // 0x20(0x18)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x38(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UTexture2D* CallFunc_GetMusicAlbumArt_Int_Art;  // 0x58(0x8)
	struct TScriptInterface<IMusicCassetteInterface_C> K2Node_DynamicCast_AsMusic_Cassette_Interface;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct AActor* K2Node_Event_ActivatingActor;  // 0x78(0x8)
	struct TScriptInterface<IMusicCassetteInterface_C> K2Node_DynamicCast_AsMusic_Cassette_Interface_2;  // 0x80(0x10)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x90(0x1)

}; 
// Function BP_CassetteInteract.BP_CassetteInteract_C.Interact_LocalClient_Implementation
// Size: 0x8(Inherited: 0x8) 
struct FInteract_LocalClient_Implementation : public FInteract_LocalClient_Implementation
{
	struct AActor* ActivatingActor;  // 0x0(0x8)

}; 
// Function BP_CassetteInteract.BP_CassetteInteract_C.CanIInteract_Int
// Size: 0x49(Inherited: 0x20) 
struct FCanIInteract_Int : public FCanIInteract_Int
{
	char pad_32_1 : 7;  // 0x20(0x1)
	bool BlockInteract : 1;  // 0x0(0x1)
	struct FText ErrorMessage;  // 0x8(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x20(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x30(0x18)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsMusicUnlocked_Unlocked : 1;  // 0x48(0x1)

}; 
// Function BP_CassetteInteract.BP_CassetteInteract_C.getInteractData
// Size: 0x58(Inherited: 0x58) 
struct FgetInteractData : public FgetInteractData
{
	struct FText interactionTextHUD;  // 0x0(0x18)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool UseImageTextPrompt : 1;  // 0x18(0x1)
	struct UTexture2D* ImageTextIcon;  // 0x20(0x8)
	struct FText ImageText1;  // 0x28(0x18)
	struct FText ImageText2;  // 0x40(0x18)

}; 
