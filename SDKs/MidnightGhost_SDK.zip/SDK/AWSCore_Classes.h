#pragma once 
#include <AWSCore_Structs.h>
 
 
 
// Class AWSCore.UUID
// Size: 0x28(Inherited: 0x28) 
struct UUUID : public UBlueprintFunctionLibrary
{

	struct FAWSUUID RandomUUID(); // Function AWSCore.UUID.RandomUUID
}; 



