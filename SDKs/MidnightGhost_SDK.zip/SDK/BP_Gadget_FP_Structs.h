#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget_FP.BP_Gadget_FP_C.HideFromGame
// Size: 0x1(Inherited: 0x0) 
struct FHideFromGame
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hidden : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_FP.BP_Gadget_FP_C.SetVisibility
// Size: 0x2(Inherited: 0x0) 
struct FSetVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Visible : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool PropagateToChildren : 1;  // 0x1(0x1)

}; 
// Function BP_Gadget_FP.BP_Gadget_FP_C.ExecuteUbergraph_BP_Gadget_FP
// Size: 0x23(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget_FP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_Unhide_Hide : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_CustomEvent_SkipAnimation : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool K2Node_CustomEvent_TickWhileHidden : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool K2Node_CustomEvent_NonLocallyControlledOrBot : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_CustomEvent_ShouldInterrupt : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool K2Node_CustomEvent_Hidden : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool K2Node_CustomEvent_Visible : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool K2Node_CustomEvent_PropagateToChildren : 1;  // 0xB(0x1)
	char pad_12[4];  // 0xC(0x4)
	struct USkeletalMeshComponent* CallFunc_GetSkeletalMesh_SkeletalMesh;  // 0x10(0x8)
	struct USkeletalMeshComponent* CallFunc_GetSkeletalMesh_SkeletalMesh_2;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_CustomEvent_Sprinting : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool K2Node_CustomEvent_InAir : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool K2Node_CustomEvent_IsDead : 1;  // 0x22(0x1)

}; 
// Function BP_Gadget_FP.BP_Gadget_FP_C.ChangeComponentTickSettings
// Size: 0xD(Inherited: 0x0) 
struct FChangeComponentTickSettings
{
	struct USkeletalMeshComponent* InputPin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Should tick : 1;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable;  // 0x9(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool Temp_bool_Variable : 1;  // 0xB(0x1)
	uint8_t  K2Node_Select_Default;  // 0xC(0x1)

}; 
// Function BP_Gadget_FP.BP_Gadget_FP_C.UpdateVisibility
// Size: 0x5(Inherited: 0x0) 
struct FUpdateVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hide : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool SkipAnimation : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool TickWhileHidden : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool NonLocallyControlledOrBot : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ShouldInterrupt : 1;  // 0x4(0x1)

}; 
// Function BP_Gadget_FP.BP_Gadget_FP_C.SetOwnerStates
// Size: 0x3(Inherited: 0x0) 
struct FSetOwnerStates
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Sprinting : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool InAir : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool IsDead : 1;  // 0x2(0x1)

}; 
// Function BP_Gadget_FP.BP_Gadget_FP_C.GetComponents
// Size: 0x10(Inherited: 0x0) 
struct FGetComponents
{
	struct TArray<struct USceneComponent*> Components;  // 0x0(0x10)

}; 
// Function BP_Gadget_FP.BP_Gadget_FP_C.GetSkeletalMesh
// Size: 0x8(Inherited: 0x0) 
struct FGetSkeletalMesh
{
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x0(0x8)

}; 
