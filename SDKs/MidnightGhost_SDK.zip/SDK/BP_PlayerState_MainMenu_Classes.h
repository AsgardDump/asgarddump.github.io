#pragma once 
#include <BP_PlayerState_MainMenu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PlayerState_MainMenu.BP_PlayerState_MainMenu_C
// Size: 0x330(Inherited: 0x320) 
struct ABP_PlayerState_MainMenu_C : public APlayerState
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x320(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x328(0x8)

	void GetMGHPlayerName(struct FString& MGHPlayerName); // Function BP_PlayerState_MainMenu.BP_PlayerState_MainMenu_C.GetMGHPlayerName
	void OC_JoinThisServer(struct FString IPPort, struct FString Player Session ID); // Function BP_PlayerState_MainMenu.BP_PlayerState_MainMenu_C.OC_JoinThisServer
	void ExecuteUbergraph_BP_PlayerState_MainMenu(int32_t EntryPoint); // Function BP_PlayerState_MainMenu.BP_PlayerState_MainMenu_C.ExecuteUbergraph_BP_PlayerState_MainMenu
}; 



