#pragma once 
#include "SDK.h" 
 
 
// Function BP_LevelAlterationController.BP_LevelAlterationController_C.ExecuteUbergraph_BP_LevelAlterationController
// Size: 0x205(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LevelAlterationController
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	int32_t K2Node_CustomEvent_load_level_index;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct TSoftObjectPtr<UWorld> K2Node_CustomEvent_Level_2;  // 0x48(0x28)
	struct TSoftObjectPtr<UWorld> K2Node_CustomEvent_Level;  // 0x70(0x28)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_LoadLevelInstanceBySoftObjectPtr_bOutSuccess : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct ULevelStreamingDynamic* CallFunc_LoadLevelInstanceBySoftObjectPtr_ReturnValue;  // 0xA0(0x8)
	struct TSoftObjectPtr<UWorld> CallFunc_Array_Get_Item;  // 0xA8(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct FString CallFunc_Conv_SoftObjectReferenceToString_ReturnValue;  // 0xD8(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0xE8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xF8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x108(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x118(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_LoadLevelInstanceBySoftObjectPtr_bOutSuccess_2 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct ULevelStreamingDynamic* CallFunc_LoadLevelInstanceBySoftObjectPtr_ReturnValue_2;  // 0x140(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x148(0x4)
	char pad_332_1 : 7;  // 0x14C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x14C(0x1)
	char pad_333[3];  // 0x14D(0x3)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x150(0x8)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface;  // 0x158(0x10)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct AActor* CallFunc_GetShrineActor_Int_Shrine;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_EqualEqual_TransformTransform_ReturnValue : 1;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	struct FHitResult CallFunc_K2_SetActorTransform_SweepHitResult;  // 0x17C(0x88)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool CallFunc_K2_SetActorTransform_ReturnValue : 1;  // 0x204(0x1)

}; 
// Function BP_LevelAlterationController.BP_LevelAlterationController_C.LoadLevel
// Size: 0x4(Inherited: 0x0) 
struct FLoadLevel
{
	int32_t load level index;  // 0x0(0x4)

}; 
// Function BP_LevelAlterationController.BP_LevelAlterationController_C.Load_Client
// Size: 0x28(Inherited: 0x0) 
struct FLoad_Client
{
	struct TSoftObjectPtr<UWorld> Level;  // 0x0(0x28)

}; 
// Function BP_LevelAlterationController.BP_LevelAlterationController_C.Load_server
// Size: 0x28(Inherited: 0x0) 
struct FLoad_server
{
	struct TSoftObjectPtr<UWorld> Level;  // 0x0(0x28)

}; 
// Function BP_LevelAlterationController.BP_LevelAlterationController_C.UserConstructionScript
// Size: 0x1D9(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FString CurrentLevel;  // 0x0(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x10(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_String__CombineStrings_Multi_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_String__CombineStrings_Multi_ReturnValue_2;  // 0x38(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_ReplaceCharactersExcept_ReturnValue;  // 0x60(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x78(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x88(0x4)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x8C(0x88)
	char pad_276_1 : 7;  // 0x114(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x114(0x1)
	char pad_277[3];  // 0x115(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x118(0x4)
	char pad_284[4];  // 0x11C(0x4)
	struct TSoftObjectPtr<UWorld> CallFunc_Array_Get_Item;  // 0x120(0x28)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x148(0x10)
	struct FPrimaryAssetId CallFunc_GetPrimaryAssetIdFromSoftObjectReference_ReturnValue;  // 0x158(0x10)
	struct FString CallFunc_String__CombineStrings_Multi_ReturnValue_3;  // 0x168(0x10)
	struct FString CallFunc_String__CombineStrings_Multi_ReturnValue_4;  // 0x178(0x10)
	struct FString CallFunc_Conv_NameToString_ReturnValue_2;  // 0x188(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue;  // 0x198(0x10)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_Contains_ReturnValue : 1;  // 0x1A8(0x1)
	char pad_425[7];  // 0x1A9(0x7)
	struct FString CallFunc_AppendMultiple_ReturnValue_2;  // 0x1B0(0x10)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_IsValidSoftObjectReference_ReturnValue : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	struct FString CallFunc_AppendMultiple_ReturnValue_3;  // 0x1C8(0x10)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1D8(0x1)

}; 
