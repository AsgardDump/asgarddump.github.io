#pragma once 
#include <BP_Gadget_SpectralCannon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C
// Size: 0x305(Inherited: 0x25C) 
struct ABP_Gadget_SpectralCannon_C : public ABP_Gadget_C
{
	char pad_604[4];  // 0x25C(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct FLinearColor Timeline_1_LightColor_CF3B94C44A9C8D4255B56B9D543C0684;  // 0x268(0x10)
	float Timeline_1_Intensity_CF3B94C44A9C8D4255B56B9D543C0684;  // 0x278(0x4)
	char ETimelineDirection Timeline_1__Direction_CF3B94C44A9C8D4255B56B9D543C0684;  // 0x27C(0x1)
	char pad_637[3];  // 0x27D(0x3)
	struct UTimelineComponent* Timeline_2;  // 0x280(0x8)
	struct FLinearColor Timeline_0_NewTrack_0_C2A944984A3077589EC6659766453FF3;  // 0x288(0x10)
	float Timeline_0_Intensity_C2A944984A3077589EC6659766453FF3;  // 0x298(0x4)
	char ETimelineDirection Timeline_0__Direction_C2A944984A3077589EC6659766453FF3;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x2A0(0x8)
	struct ABP_Gadget_TP_SpectralCannon_C* GadgetTP;  // 0x2A8(0x8)
	struct ABP_Gadget_FP_SpectralCannon_C* GadgetFP;  // 0x2B0(0x8)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool RnD-UseRechargingBattery? : 1;  // 0x2B8(0x1)
	char pad_697_1 : 7;  // 0x2B9(0x1)
	bool FP Reloading Spectral Cannon : 1;  // 0x2B9(0x1)
	char pad_698_1 : 7;  // 0x2BA(0x1)
	bool SpectralCannonCD? : 1;  // 0x2BA(0x1)
	char pad_699_1 : 7;  // 0x2BB(0x1)
	bool SpectralChargeup_Status : 1;  // 0x2BB(0x1)
	char pad_700_1 : 7;  // 0x2BC(0x1)
	bool WeaponFired : 1;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	int32_t SpectralChargeup_Amount;  // 0x2C0(0x4)
	float CannonBattery_Max;  // 0x2C4(0x4)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool SpectralCannon_Equipping : 1;  // 0x2C8(0x1)
	char pad_713_1 : 7;  // 0x2C9(0x1)
	bool Debug_BYPASS_BATTERY? : 1;  // 0x2C9(0x1)
	char pad_714[2];  // 0x2CA(0x2)
	float Cannon Battery Level;  // 0x2CC(0x4)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Spectral Cannon Cooldown? : 1;  // 0x2D0(0x1)
	char pad_721_1 : 7;  // 0x2D1(0x1)
	bool SpectralCannonChargeup : 1;  // 0x2D1(0x1)
	char pad_722[6];  // 0x2D2(0x6)
	struct USceneComponent* Cannon Turbine Location;  // 0x2D8(0x8)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool ANIM_BeamInPlay? : 1;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool ANIM_CancelFire : 1;  // 0x2E1(0x1)
	char pad_738_1 : 7;  // 0x2E2(0x1)
	bool ANIM Charging GC : 1;  // 0x2E2(0x1)
	char pad_739_1 : 7;  // 0x2E3(0x1)
	bool ANIM Captured Recently : 1;  // 0x2E3(0x1)
	char pad_740_1 : 7;  // 0x2E4(0x1)
	bool ANIM Equipped Recently : 1;  // 0x2E4(0x1)
	char pad_741[3];  // 0x2E5(0x3)
	struct UMaterialInstanceDynamic* SpecCan_TurbineGlow_Mtl_FP;  // 0x2E8(0x8)
	struct ABP_Sound_C* MyChargeupSound;  // 0x2F0(0x8)
	struct ABP_Sound_C* MyChargeupSound_Old;  // 0x2F8(0x8)
	float Hunter - Reload Speed Modifier;  // 0x300(0x4)
	char pad_772_1 : 7;  // 0x304(0x1)
	bool HoldingFire : 1;  // 0x304(0x1)

	void CanBeUnequipped(bool& CanBeUnequipped); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.CanBeUnequipped
	void GetAmmoData(bool& GadgetUsesAmmo, int32_t& MaxAmmo, int32_t& CurrentAmmo); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.GetAmmoData
	void Is Locally Controlled Hunter?(bool& Locally Controlled?, bool& Is a Locally Controlled Bot?); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Is Locally Controlled Hunter?
	void CalculateSpectralHitscan(bool& Hit?, struct FRotator& Rotation); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.CalculateSpectralHitscan
	void GetTPActor(struct ABP_Gadget_TP_C*& TPActor); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.GetTPActor
	void GetFPActor(struct ABP_Gadget_FP_C*& FPActor); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.GetFPActor
	void Timeline_0__FinishedFunc(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Timeline_0__UpdateFunc
	void Timeline_1__FinishedFunc(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Timeline_1__FinishedFunc
	void Timeline_1__UpdateFunc(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Timeline_1__UpdateFunc
	void OnNotifyEnd_406247964B18F7F3B0E3FB88601098FE(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_406247964B18F7F3B0E3FB88601098FE
	void OnNotifyBegin_406247964B18F7F3B0E3FB88601098FE(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_406247964B18F7F3B0E3FB88601098FE
	void OnInterrupted_406247964B18F7F3B0E3FB88601098FE(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_406247964B18F7F3B0E3FB88601098FE
	void OnBlendOut_406247964B18F7F3B0E3FB88601098FE(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_406247964B18F7F3B0E3FB88601098FE
	void OnCompleted_406247964B18F7F3B0E3FB88601098FE(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_406247964B18F7F3B0E3FB88601098FE
	void OnNotifyEnd_EDA6A85446EB1306FE1FD98C82D58E7C(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_EDA6A85446EB1306FE1FD98C82D58E7C
	void OnNotifyBegin_EDA6A85446EB1306FE1FD98C82D58E7C(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_EDA6A85446EB1306FE1FD98C82D58E7C
	void OnInterrupted_EDA6A85446EB1306FE1FD98C82D58E7C(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_EDA6A85446EB1306FE1FD98C82D58E7C
	void OnBlendOut_EDA6A85446EB1306FE1FD98C82D58E7C(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_EDA6A85446EB1306FE1FD98C82D58E7C
	void OnCompleted_EDA6A85446EB1306FE1FD98C82D58E7C(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_EDA6A85446EB1306FE1FD98C82D58E7C
	void OnNotifyEnd_6FB8135D4D0D52EFFF0A90B62CB4BD99(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_6FB8135D4D0D52EFFF0A90B62CB4BD99
	void OnNotifyBegin_6FB8135D4D0D52EFFF0A90B62CB4BD99(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_6FB8135D4D0D52EFFF0A90B62CB4BD99
	void OnInterrupted_6FB8135D4D0D52EFFF0A90B62CB4BD99(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_6FB8135D4D0D52EFFF0A90B62CB4BD99
	void OnBlendOut_6FB8135D4D0D52EFFF0A90B62CB4BD99(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_6FB8135D4D0D52EFFF0A90B62CB4BD99
	void OnCompleted_6FB8135D4D0D52EFFF0A90B62CB4BD99(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_6FB8135D4D0D52EFFF0A90B62CB4BD99
	void OnNotifyEnd_EF434191450523312DC50AAEB1C60A64(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_EF434191450523312DC50AAEB1C60A64
	void OnNotifyBegin_EF434191450523312DC50AAEB1C60A64(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_EF434191450523312DC50AAEB1C60A64
	void OnInterrupted_EF434191450523312DC50AAEB1C60A64(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_EF434191450523312DC50AAEB1C60A64
	void OnBlendOut_EF434191450523312DC50AAEB1C60A64(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_EF434191450523312DC50AAEB1C60A64
	void OnCompleted_EF434191450523312DC50AAEB1C60A64(struct FName NotifyName); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_EF434191450523312DC50AAEB1C60A64
	void ChargeCannonFire(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.ChargeCannonFire
	void SpectralCannon_BeginChargeup(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpectralCannon_BeginChargeup
	void SpectralCannon_StopChargeup(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpectralCannon_StopChargeup
	void SpectralCannon_ChargeupFire(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpectralCannon_ChargeupFire
	void FinishChargeup(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.FinishChargeup
	void Server_Cannon_TPAnim_Charging(bool ChargingGC); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_Charging
	void Server_Cannon_TPAnim_BeamInPlay(bool BeamInPlay?); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_BeamInPlay
	void Server_Cannon_TPAnim_CapturedRecently(bool CapturedRecently); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_CapturedRecently
	void MC_Cannon_Charging(bool ChargingGC); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_Charging
	void MC_Cannon_BeamInPlay(bool BeamInPlay?); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_BeamInPlay
	void MC_Cannon_CapturedRecently(bool CapturedRecently); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_CapturedRecently
	void Server_Cannon_TPAnim_Equipped(bool EquippedRecently); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_Equipped
	void MC_Cannon_Equipped(bool EquippedRecently); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_Equipped
	void SpectralCannon_FireSounds(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpectralCannon_FireSounds
	void Server_CannonWindDownSound(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_CannonWindDownSound
	void Server_CannonChargeupSound(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_CannonChargeupSound
	void SpectralCannon_NR_FirelightClient(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpectralCannon_NR_FirelightClient
	void OutOfBattery(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OutOfBattery
	void Server_TPAnim_CancelFire(bool CancelFire?); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_TPAnim_CancelFire
	void ReloadSpectralCannon(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.ReloadSpectralCannon
	void Server_ReloadSpectralCannon(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_ReloadSpectralCannon
	void MC_ReloadSpectralCannon(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_ReloadSpectralCannon
	void NR_ReloadSpectralCannonSounds(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.NR_ReloadSpectralCannonSounds
	void Fire(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Fire
	void StartHoldingFire(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.StartHoldingFire
	void StopHoldingFire(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.StopHoldingFire
	void ReceiveBeginPlay(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.ReceiveBeginPlay
	void Init(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Init
	void Equip(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Equip
	void FireSpectralCannonSalvo(struct FTransform XForm); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.FireSpectralCannonSalvo
	void SpectralCannonChargeupStart(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpectralCannonChargeupStart
	void NR_HandleSpectralCannonReload(float Operation); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.NR_HandleSpectralCannonReload
	void NR_SpawnSpectralCannonSalvo(struct FVector_NetQuantize10 Location, struct FRotator Rotator); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.NR_SpawnSpectralCannonSalvo
	void SpecCan_SpinUpEffects_FP(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpecCan_SpinUpEffects_FP
	void SpecCan_ReloadTurbineGlow_FP(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SpecCan_ReloadTurbineGlow_FP
	void SetupTurbineGlow(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SetupTurbineGlow
	void OC_Startup(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OC_Startup
	void NR_SpectralCannonReload(float Operation); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.NR_SpectralCannonReload
	void MC_SpawnSpectralCannonSalvo(struct FVector_NetQuantize10 Location, struct FRotator Rotator); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_SpawnSpectralCannonSalvo
	void Server_SpawnSpectralCannonSalvo(struct FVector_NetQuantize10 Location, struct FRotator Rotator); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_SpawnSpectralCannonSalvo
	void ReceiveTick(float DeltaSeconds); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.ReceiveTick
	void Reload(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Reload
	void SetFPWeaponData(bool SC CancelledFire, bool SC Cooldown, bool Chargeup Ocurring, float Cannon Battery Level); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SetFPWeaponData
	void PrintName(); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.PrintName
	void ExecuteUbergraph_BP_Gadget_SpectralCannon(int32_t EntryPoint); // Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.ExecuteUbergraph_BP_Gadget_SpectralCannon
}; 



