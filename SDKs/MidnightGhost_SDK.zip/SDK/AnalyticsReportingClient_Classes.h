#pragma once 
#include <AnalyticsReportingClient_Structs.h>
 
 
 
// BlueprintGeneratedClass AnalyticsReportingClient.AnalyticsReportingClient_C
// Size: 0x78(Inherited: 0x30) 
struct UAnalyticsReportingClient_C : public UInheritableObject
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)
	struct UDSTelemetry* Telemetry;  // 0x38(0x8)
	float Current Match Length in Seconds;  // 0x40(0x4)
	float Current Round Length In Seconds;  // 0x44(0x4)
	int32_t Match Round Counter;  // 0x48(0x4)
	int32_t Match Rounds Won Accumulator;  // 0x4C(0x4)
	int32_t Match Kills Accumulator;  // 0x50(0x4)
	int32_t Match Assists Accumulator;  // 0x54(0x4)
	int32_t Match Revives Accumulator;  // 0x58(0x4)
	int32_t Match Score Accumulator;  // 0x5C(0x4)
	int32_t Total Team Score Accumulator;  // 0x60(0x4)
	int32_t Total Opposing Team Score Accumulator;  // 0x64(0x4)
	int32_t FullGame Session Matches played;  // 0x68(0x4)
	float GameSessionLengthInSeconds;  // 0x6C(0x4)
	struct FTimerHandle Gameplay Time Tracker;  // 0x70(0x8)

	void Report Player Stats Loaded(int32_t Player Level, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Stats Loaded
	void Report Player Team Changed(char Team Team, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Team Changed
	void Report Party Status Changed(bool Party Status, int32_t Party Size, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Party Status Changed
	void Report Match Started(struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State, struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>>& All Player States, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Match Started
	void Report Player Level Up(int32_t New Level, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Level Up
	void Report Region Changed(char MGH_Regions region, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Region Changed
	void Report Match ID Changed(struct FString Match ID, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Match ID Changed
	void Report Player Login(bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Login
	void Report Match Ended(bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Match Ended
	void Report Gameplay Round Ended(struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State, char GameVictoryType Victory Type, struct FString Winning Team GUID, struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>>& All Player States, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Gameplay Round Ended
	void Report Leave Lobby(bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Leave Lobby
	void Report Tutorial Step Advanced(int32_t Step, char Team Team, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Tutorial Step Advanced
	void Report Tutorial Completed(bool Ghost F, Hunters T, bool Completed, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Tutorial Completed
	void Report Map Changed(struct FString Map, bool& Result); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Map Changed
	void Get Team Bots Amount(char Team Team, struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>>& Player States, int32_t& Amount of Bots); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Get Team Bots Amount
	void Get Team Median Level(char Team Team, struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>>& Player States, float& Team Median Level); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Get Team Median Level
	void Is Victory?(char Team Team, char GameVictoryType Victory Type, bool& Victory); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Is Victory?
	void Get Total Team Score(char Team Team, struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>>& Player States, int32_t& Team Score); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Get Total Team Score
	void Init(struct FString Build Tag, struct FString GameID, bool Player In Editor?); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Init
	void Reset Round Length Timer(); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.Reset Round Length Timer
	void On Gameplay Timer Tick(float DeltaTime); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.On Gameplay Timer Tick
	void ExecuteUbergraph_AnalyticsReportingClient(int32_t EntryPoint); // Function AnalyticsReportingClient.AnalyticsReportingClient_C.ExecuteUbergraph_AnalyticsReportingClient
}; 



