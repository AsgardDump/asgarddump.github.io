#pragma once 
#include "SDK.h" 
 
 
// Function BP_TutorialHauntShrine.BP_TutorialHauntShrine_C.ExecuteUbergraph_BP_TutorialHauntShrine
// Size: 0x81(Inherited: 0x0) 
struct FExecuteUbergraph_BP_TutorialHauntShrine
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMiscIndicator_UI_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x10(0x8)
	struct UMiscIndicator_UI_C* K2Node_DynamicCast_AsMisc_Indicator_UI;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x28(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x40(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue_2;  // 0x58(0x8)
	struct UMiscIndicator_UI_C* K2Node_DynamicCast_AsMisc_Indicator_UI_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue_3;  // 0x70(0x8)
	struct UMiscIndicator_UI_C* K2Node_DynamicCast_AsMisc_Indicator_UI_3;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x80(0x1)

}; 
// Function BP_TutorialHauntShrine.BP_TutorialHauntShrine_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
