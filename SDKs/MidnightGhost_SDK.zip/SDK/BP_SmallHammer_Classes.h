#pragma once 
#include <BP_SmallHammer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SmallHammer.BP_SmallHammer_C
// Size: 0x270(Inherited: 0x220) 
struct ABP_SmallHammer_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* HammerMovementCollision;  // 0x228(0x8)
	struct UBoxComponent* HammerDamage;  // 0x230(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x238(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool Damage : 1;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct FTimerHandle DmgTimer;  // 0x250(0x8)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool Reset : 1;  // 0x258(0x1)
	char pad_601[7];  // 0x259(0x7)
	struct TArray<struct ABP_Hunter_C*> HuntersInCamShakeRange;  // 0x260(0x10)

	void TriggerCameraShakes(); // Function BP_SmallHammer.BP_SmallHammer_C.TriggerCameraShakes
	void BndEvt__HammerDamage_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_SmallHammer.BP_SmallHammer_C.BndEvt__HammerDamage_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
	void DamageEnabled(); // Function BP_SmallHammer.BP_SmallHammer_C.DamageEnabled
	void ReceiveBeginPlay(); // Function BP_SmallHammer.BP_SmallHammer_C.ReceiveBeginPlay
	void Server_Reset(); // Function BP_SmallHammer.BP_SmallHammer_C.Server_Reset
	void MC_Reset(); // Function BP_SmallHammer.BP_SmallHammer_C.MC_Reset
	void DamageDisabled(); // Function BP_SmallHammer.BP_SmallHammer_C.DamageDisabled
	void ExecuteUbergraph_BP_SmallHammer(int32_t EntryPoint); // Function BP_SmallHammer.BP_SmallHammer_C.ExecuteUbergraph_BP_SmallHammer
}; 



