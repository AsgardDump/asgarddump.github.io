#pragma once 
#include <BP_ThrownPresentDestroyed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ThrownPresentDestroyed.BP_ThrownPresentDestroyed_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_ThrownPresentDestroyed_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDestructibleComponent* PresentMeshCentered_DM;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void ReceiveBeginPlay(); // Function BP_ThrownPresentDestroyed.BP_ThrownPresentDestroyed_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ThrownPresentDestroyed(int32_t EntryPoint); // Function BP_ThrownPresentDestroyed.BP_ThrownPresentDestroyed_C.ExecuteUbergraph_BP_ThrownPresentDestroyed
}; 



