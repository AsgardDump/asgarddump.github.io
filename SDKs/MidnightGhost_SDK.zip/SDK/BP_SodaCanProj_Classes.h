#pragma once 
#include <BP_SodaCanProj_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SodaCanProj.BP_SodaCanProj_C
// Size: 0x250(Inherited: 0x220) 
struct ABP_SodaCanProj_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USphereComponent* Sphere;  // 0x228(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_Sodacan;  // 0x238(0x8)
	struct AMGH_PlayerState_C* WhoFired;  // 0x240(0x8)
	struct ABP_Hunter_C* DirectHitHunter;  // 0x248(0x8)

	void DamageTrap(struct ABP_Trap_C* Trap); // Function BP_SodaCanProj.BP_SodaCanProj_C.DamageTrap
	void DamageGenerator(struct ABP_Generator_C* Generator); // Function BP_SodaCanProj.BP_SodaCanProj_C.DamageGenerator
	void PushLvlProp(struct ALvlProp_C* LvlProp); // Function BP_SodaCanProj.BP_SodaCanProj_C.PushLvlProp
	void HandleHit(struct AActor* Hit Actor, struct FVector HitNormal); // Function BP_SodaCanProj.BP_SodaCanProj_C.HandleHit
	void Explode(bool SkipDmg, struct FVector Hit Normal); // Function BP_SodaCanProj.BP_SodaCanProj_C.Explode
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SodaCanProj.BP_SodaCanProj_C.ReceiveHit
	void ReceiveTick(float DeltaSeconds); // Function BP_SodaCanProj.BP_SodaCanProj_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_SodaCanProj.BP_SodaCanProj_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_SodaCanProj(int32_t EntryPoint); // Function BP_SodaCanProj.BP_SodaCanProj_C.ExecuteUbergraph_BP_SodaCanProj
}; 



