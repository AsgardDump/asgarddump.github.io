#pragma once 
#include "SDK.h" 
 
 
// Function BotFuncs.BotFuncs_C.AbortBotJump
// Size: 0x22(Inherited: 0x0) 
struct FAbortBotJump
{
	struct AActor* Target;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x10(0x8)
	struct UAi_BotJumpComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x21(0x1)

}; 
