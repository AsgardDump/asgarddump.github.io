#pragma once 
#include "SDK.h" 
 
 
// Function BP_VanSpooks.BP_VanSpooks_C.ExecuteUbergraph_BP_VanSpooks
// Size: 0x51(Inherited: 0x0) 
struct FExecuteUbergraph_BP_VanSpooks
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x30(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x38(0x8)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)

}; 
