#pragma once 
#include "SDK.h" 
 
 
// Function BP_Hunter_Van.BP_Hunter_Van_C.ExecuteUbergraph_BP_Hunter_Van
// Size: 0x12(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Hunter_Van
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AMGH_GameState_C* CallFunc_Get_MGH_Game_State_MGH_Game_State;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x11(0x1)

}; 
