#pragma once 
#include <BP_CamCorderInteract_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CamCorderInteract.BP_CamCorderInteract_C
// Size: 0x2C0(Inherited: 0x2A8) 
struct ABP_CamCorderInteract_C : public ABP_interactiveObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)
	struct UBoxComponent* Box;  // 0x2B0(0x8)
	struct AActor* MyCamCorder;  // 0x2B8(0x8)

	void GetOwnerInfo_Int(struct AActor*& Owner); // Function BP_CamCorderInteract.BP_CamCorderInteract_C.GetOwnerInfo_Int
	void getInteractData(struct FText& interactionTextHUD, bool& UseImageTextPrompt, struct UTexture2D*& ImageTextIcon, struct FText& ImageText1, struct FText& ImageText2); // Function BP_CamCorderInteract.BP_CamCorderInteract_C.getInteractData
	void SetCameraCollide_Int(bool Collide); // Function BP_CamCorderInteract.BP_CamCorderInteract_C.SetCameraCollide_Int
	void Interact_Implementation(); // Function BP_CamCorderInteract.BP_CamCorderInteract_C.Interact_Implementation
	void SetOutlineVisibility_Int(bool Visible); // Function BP_CamCorderInteract.BP_CamCorderInteract_C.SetOutlineVisibility_Int
	void SetOwnerInfo_Int(struct AActor* Actor); // Function BP_CamCorderInteract.BP_CamCorderInteract_C.SetOwnerInfo_Int
	void ExecuteUbergraph_BP_CamCorderInteract(int32_t EntryPoint); // Function BP_CamCorderInteract.BP_CamCorderInteract_C.ExecuteUbergraph_BP_CamCorderInteract
}; 



