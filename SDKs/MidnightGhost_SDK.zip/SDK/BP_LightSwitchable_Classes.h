#pragma once 
#include <BP_LightSwitchable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LightSwitchable.BP_LightSwitchable_C
// Size: 0x2A8(Inherited: 0x220) 
struct ABP_LightSwitchable_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UPointLightComponent* PointLight-NR;  // 0x228(0x8)
	struct UPointLightComponent* PointLight;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float Timeline_0_NewTrack_0_AE6C03964BF709C3D0AC0EB5AFCA35A7;  // 0x240(0x4)
	char ETimelineDirection Timeline_0__Direction_AE6C03964BF709C3D0AC0EB5AFCA35A7;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x248(0x8)
	float FlickerOut_Multiplier_BB21897C415767D7C23ECDA3547D7CC9;  // 0x250(0x4)
	char ETimelineDirection FlickerOut__Direction_BB21897C415767D7C23ECDA3547D7CC9;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* FlickerOut;  // 0x258(0x8)
	float Set Light Intensity;  // 0x260(0x4)
	struct FLinearColor Set Color;  // 0x264(0x10)
	char pad_628[4];  // 0x274(0x4)
	struct FString SwitchTag;  // 0x278(0x10)
	float Set Atten Radius;  // 0x288(0x4)
	float Set Volume Scattering Intensity;  // 0x28C(0x4)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool on? : 1;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool DisableRoughness? : 1;  // 0x291(0x1)
	char pad_658[6];  // 0x292(0x6)
	struct UPointLightComponent* MyPointLight;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool Flipping Disabled? : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	float Original Light Intensity;  // 0x2A4(0x4)

	void On?(); // Function BP_LightSwitchable.BP_LightSwitchable_C.On?
	void UserConstructionScript(); // Function BP_LightSwitchable.BP_LightSwitchable_C.UserConstructionScript
	void FlickerOut__FinishedFunc(); // Function BP_LightSwitchable.BP_LightSwitchable_C.FlickerOut__FinishedFunc
	void FlickerOut__UpdateFunc(); // Function BP_LightSwitchable.BP_LightSwitchable_C.FlickerOut__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_LightSwitchable.BP_LightSwitchable_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_LightSwitchable.BP_LightSwitchable_C.Timeline_0__UpdateFunc
	void Midnight(); // Function BP_LightSwitchable.BP_LightSwitchable_C.Midnight
	void MC_TurnOnOff(bool On); // Function BP_LightSwitchable.BP_LightSwitchable_C.MC_TurnOnOff
	void TurnOnOff(bool On, bool PlaySound?); // Function BP_LightSwitchable.BP_LightSwitchable_C.TurnOnOff
	void Infection(); // Function BP_LightSwitchable.BP_LightSwitchable_C.Infection
	void ReceiveBeginPlay(); // Function BP_LightSwitchable.BP_LightSwitchable_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_LightSwitchable.BP_LightSwitchable_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_LightSwitchable(int32_t EntryPoint); // Function BP_LightSwitchable.BP_LightSwitchable_C.ExecuteUbergraph_BP_LightSwitchable
}; 



