#pragma once 
#include <BP_Hunter_ui_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_ui.BP_Hunter_ui_C
// Size: 0x2670(Inherited: 0x2658) 
struct ABP_Hunter_ui_C : public ABP_Hunter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2658(0x8)
	struct USkeletalMeshComponent* Backpack_UI;  // 0x2660(0x8)
	struct UStaticMeshComponent* BakedHKGC;  // 0x2668(0x8)

	void AssignCorrectColors_old(char HunterSpec Spec, char HunterSkins Skin, struct FLinearColor& 1, struct FLinearColor& 2, struct FLinearColor& 3, struct FLinearColor& 4); // Function BP_Hunter_ui.BP_Hunter_ui_C.AssignCorrectColors_old
	void ReceiveBeginPlay(); // Function BP_Hunter_ui.BP_Hunter_ui_C.ReceiveBeginPlay
	void UI_DestroyAllMeshAndReset(char HunterSkins NewSkin, char HunterSpec SpecColor, bool SetHidden, int32_t HeadTexture, int32_t HairModel, int32_t BeardModel); // Function BP_Hunter_ui.BP_Hunter_ui_C.UI_DestroyAllMeshAndReset
	void ResetToEquippedSkin(); // Function BP_Hunter_ui.BP_Hunter_ui_C.ResetToEquippedSkin
	void DeferredLoadSkins(bool WasSuccessful); // Function BP_Hunter_ui.BP_Hunter_ui_C.DeferredLoadSkins
	void ExecuteUbergraph_BP_Hunter_ui(int32_t EntryPoint); // Function BP_Hunter_ui.BP_Hunter_ui_C.ExecuteUbergraph_BP_Hunter_ui
}; 



