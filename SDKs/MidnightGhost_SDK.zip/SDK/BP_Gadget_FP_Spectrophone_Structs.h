#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget_FP_Spectrophone.BP_Gadget_FP_Spectrophone_C.ExecuteUbergraph_BP_Gadget_FP_Spectrophone
// Size: 0xC9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget_FP_Spectrophone
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x1B(0x1)
	char pad_28[4];  // 0x1C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_Event_Unhide_Hide : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool K2Node_Event_SkipAnimation : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_Event_TickWhileHidden : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool K2Node_Event_NonLocallyControlledOrBot : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool K2Node_Event_ShouldInterrupt : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x30(0x8)
	struct USpectroPhone_FP_AnimBP_C* K2Node_DynamicCast_AsSpectro_Phone_FP_Anim_BP;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue;  // 0x48(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x50(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0x58(0x8)
	struct USpectroPhone_FP_AnimBP_C* K2Node_DynamicCast_AsSpectro_Phone_FP_Anim_BP_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct USpectroPhone_FP_AnimBP_C* K2Node_DynamicCast_AsSpectro_Phone_FP_Anim_BP_3;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_4;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_Event_Sprinting : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool K2Node_Event_InAir : 1;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool K2Node_Event_IsDead : 1;  // 0x8A(0x1)
	char pad_139[5];  // 0x8B(0x5)
	struct USpectroPhone_FP_AnimBP_C* K2Node_DynamicCast_AsSpectro_Phone_FP_Anim_BP_4;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_5;  // 0xA0(0x8)
	struct USpectroPhone_FP_AnimBP_C* K2Node_DynamicCast_AsSpectro_Phone_FP_Anim_BP_5;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_6;  // 0xB8(0x8)
	struct USpectroPhone_FP_AnimBP_C* K2Node_DynamicCast_AsSpectro_Phone_FP_Anim_BP_6;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0xC8(0x1)

}; 
// Function BP_Gadget_FP_Spectrophone.BP_Gadget_FP_Spectrophone_C.GetSkeletalMesh
// Size: 0x8(Inherited: 0x8) 
struct FGetSkeletalMesh : public FGetSkeletalMesh
{
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x0(0x8)

}; 
// Function BP_Gadget_FP_Spectrophone.BP_Gadget_FP_Spectrophone_C.UpdateVisibility
// Size: 0x5(Inherited: 0x5) 
struct FUpdateVisibility : public FUpdateVisibility
{
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Hide : 1;  // 0x0(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool SkipAnimation : 1;  // 0x1(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool TickWhileHidden : 1;  // 0x2(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool NonLocallyControlledOrBot : 1;  // 0x3(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ShouldInterrupt : 1;  // 0x4(0x1)

}; 
// Function BP_Gadget_FP_Spectrophone.BP_Gadget_FP_Spectrophone_C.SetOwnerStates
// Size: 0x3(Inherited: 0x3) 
struct FSetOwnerStates : public FSetOwnerStates
{
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Sprinting : 1;  // 0x0(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool InAir : 1;  // 0x1(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool IsDead : 1;  // 0x2(0x1)

}; 
