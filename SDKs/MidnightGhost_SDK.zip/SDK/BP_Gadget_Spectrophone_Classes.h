#pragma once 
#include <BP_Gadget_Spectrophone_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C
// Size: 0x2E8(Inherited: 0x25C) 
struct ABP_Gadget_Spectrophone_C : public ABP_Gadget_C
{
	char pad_604[4];  // 0x25C(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	float Timeline_0_Timeliner_90CC8CE04362C253A4E25F88D1BFD4B0;  // 0x268(0x4)
	char ETimelineDirection Timeline_0__Direction_90CC8CE04362C253A4E25F88D1BFD4B0;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x270(0x8)
	struct UAudioComponent* SpectrophoneSound;  // 0x278(0x8)
	float SpectrophoneHits_Repl;  // 0x280(0x4)
	char pad_644[4];  // 0x284(0x4)
	struct TArray<struct AActor*> SpectrophonedActors;  // 0x288(0x10)
	struct TArray<struct AActor*> SpectrophonedActors_Sensitive;  // 0x298(0x10)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Spectrophone Equipped? : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool SpectroHitGhost : 1;  // 0x2A9(0x1)
	char pad_682[6];  // 0x2AA(0x6)
	struct TArray<float> SpectrophoneArray;  // 0x2B0(0x10)
	float SpectrophoneCloseness_Interpolated;  // 0x2C0(0x4)
	float SpectrophoneHits;  // 0x2C4(0x4)
	float SpectrophoneCloseness_Speed;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)
	struct ABP_Gadget_FP_Spectrophone_C* GadgetFP;  // 0x2D0(0x8)
	struct ABP_Gadget_TP_Spectrophone_C* GadgetTP;  // 0x2D8(0x8)
	struct UCameraComponent* Camera;  // 0x2E0(0x8)

	void GetTPActor(struct ABP_Gadget_TP_C*& TPActor); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.GetTPActor
	void GetFPActor(struct ABP_Gadget_FP_C*& FPActor); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.GetFPActor
	void RecentlyGotTrackingHit(bool Radar, bool pathfinder, bool Spectrophone); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.RecentlyGotTrackingHit
	void SpectrophoneFinalizeCalculations(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.SpectrophoneFinalizeCalculations
	void HandleSpectrophoneCalculations(struct AActor* HitActor); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.HandleSpectrophoneCalculations
	void OnRep_SpectrophoneHits_Repl(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.OnRep_SpectrophoneHits_Repl
	void Timeline_0__FinishedFunc(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.Timeline_0__UpdateFunc
	void SpawnSpectrophoneSound(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.SpawnSpectrophoneSound
	void Server_SpectrophoneSound(float Sound); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.Server_SpectrophoneSound
	void Spectrophone_InterpolatedLoop(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.Spectrophone_InterpolatedLoop
	void Spectrophone_Loop(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.Spectrophone_Loop
	void Init(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.Init
	void SpectrophoneLoopEvent(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.SpectrophoneLoopEvent
	void ReceiveBeginPlay(); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Gadget_Spectrophone(int32_t EntryPoint); // Function BP_Gadget_Spectrophone.BP_Gadget_Spectrophone_C.ExecuteUbergraph_BP_Gadget_Spectrophone
}; 



