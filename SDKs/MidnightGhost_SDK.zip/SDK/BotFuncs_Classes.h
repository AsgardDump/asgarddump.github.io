#pragma once 
#include <BotFuncs_Structs.h>
 
 
 
// BlueprintGeneratedClass BotFuncs.BotFuncs_C
// Size: 0x28(Inherited: 0x28) 
struct UBotFuncs_C : public UBlueprintFunctionLibrary
{

	void AbortBotJump(struct AActor* Target, struct UObject* __WorldContext); // Function BotFuncs.BotFuncs_C.AbortBotJump
}; 



