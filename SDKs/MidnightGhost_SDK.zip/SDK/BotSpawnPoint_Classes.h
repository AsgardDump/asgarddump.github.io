#pragma once 
#include <BotSpawnPoint_Structs.h>
 
 
 
// BlueprintGeneratedClass BotSpawnPoint.BotSpawnPoint_C
// Size: 0x230(Inherited: 0x220) 
struct ABotSpawnPoint_C : public AActor
{
	struct UBillboardComponent* Billboard;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)

}; 



