#pragma once 
#include <BP_CassetteInteract_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CassetteInteract.BP_CassetteInteract_C
// Size: 0x2C1(Inherited: 0x2A8) 
struct ABP_CassetteInteract_C : public ABP_interactiveObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)
	struct UBoxComponent* Box;  // 0x2B0(0x8)
	struct AActor* MyMusicCassette;  // 0x2B8(0x8)
	char MGHMusicTracks MusicAssigned;  // 0x2C0(0x1)

	void CanIInteract_Int(bool& BlockInteract, struct FText& ErrorMessage); // Function BP_CassetteInteract.BP_CassetteInteract_C.CanIInteract_Int
	void getInteractData(struct FText& interactionTextHUD, bool& UseImageTextPrompt, struct UTexture2D*& ImageTextIcon, struct FText& ImageText1, struct FText& ImageText2); // Function BP_CassetteInteract.BP_CassetteInteract_C.getInteractData
	void ReceiveBeginPlay(); // Function BP_CassetteInteract.BP_CassetteInteract_C.ReceiveBeginPlay
	void Interact_Implementation(); // Function BP_CassetteInteract.BP_CassetteInteract_C.Interact_Implementation
	void Interact_LocalClient_Implementation(struct AActor* ActivatingActor); // Function BP_CassetteInteract.BP_CassetteInteract_C.Interact_LocalClient_Implementation
	void VarsSet(); // Function BP_CassetteInteract.BP_CassetteInteract_C.VarsSet
	void ExecuteUbergraph_BP_CassetteInteract(int32_t EntryPoint); // Function BP_CassetteInteract.BP_CassetteInteract_C.ExecuteUbergraph_BP_CassetteInteract
}; 



