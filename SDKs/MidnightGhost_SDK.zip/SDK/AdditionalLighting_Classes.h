#pragma once 
#include <AdditionalLighting_Structs.h>
 
 
 
// BlueprintGeneratedClass AdditionalLighting.AdditionalLighting_C
// Size: 0x240(Inherited: 0x220) 
struct AAdditionalLighting_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct TArray<struct APointLight*> PointLights;  // 0x230(0x10)

	void Midnight(); // Function AdditionalLighting.AdditionalLighting_C.Midnight
	void Infection(); // Function AdditionalLighting.AdditionalLighting_C.Infection
	void ReceiveBeginPlay(); // Function AdditionalLighting.AdditionalLighting_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function AdditionalLighting.AdditionalLighting_C.ReceiveEndPlay
	void ExecuteUbergraph_AdditionalLighting(int32_t EntryPoint); // Function AdditionalLighting.AdditionalLighting_C.ExecuteUbergraph_AdditionalLighting
}; 



