#pragma once 
#include <BP_SPS_WidgetActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SPS_WidgetActor.BP_SPS_WidgetActor_C
// Size: 0x3B4(Inherited: 0x220) 
struct ABP_SPS_WidgetActor_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USphereComponent* Sphere;  // 0x228(0x8)
	struct UWidgetComponent* Widget;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool Active : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct UWBP_SPS_Icon_C* SmartPingWidget;  // 0x248(0x8)
	struct FMulticastInlineDelegate ActivateWidget;  // 0x250(0x10)
	struct FMulticastInlineDelegate DeactivateWidget;  // 0x260(0x10)
	struct FTimerHandle DeactivateTimer;  // 0x270(0x8)
	struct USmartPingSystem_C* SmartPingComponent;  // 0x278(0x8)
	struct FVector WorldLocation;  // 0x280(0xC)
	struct FVector ScreenToWorldLocation;  // 0x28C(0xC)
	struct APlayerController* PlayerController;  // 0x298(0x8)
	float ScreenRotation;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct FMulticastInlineDelegate UpdateWidgetState;  // 0x2A8(0x10)
	struct FS_SPS_IconSettings Settings;  // 0x2B8(0x80)
	struct UAudioComponent* HoldSound;  // 0x338(0x8)
	struct FTimerHandle PhaseTimer;  // 0x340(0x8)
	struct APlayerState* PS Owner;  // 0x348(0x8)
	struct TArray<struct ABP_SPS_WidgetActor_C*> My Actors;  // 0x350(0x10)
	float Time;  // 0x360(0x4)
	char pad_868_1 : 7;  // 0x364(0x1)
	bool Faded : 1;  // 0x364(0x1)
	char pad_869[3];  // 0x365(0x3)
	struct UPingInfo_C* PingInfo;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool CheckIsCenteredLocallyOwned : 1;  // 0x370(0x1)
	char pad_881[7];  // 0x371(0x7)
	struct AMGH_PlayerController_BP_C* My MGHPC;  // 0x378(0x8)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool CheckIsCenteredLocallyOwned_Set : 1;  // 0x380(0x1)
	char pad_897[7];  // 0x381(0x7)
	struct APlayerState* PlayerStateOwner_Center;  // 0x388(0x8)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool Attached : 1;  // 0x390(0x1)
	char pad_913_1 : 7;  // 0x391(0x1)
	bool HitWidgetActor : 1;  // 0x391(0x1)
	char pad_914_1 : 7;  // 0x392(0x1)
	bool AmiCancelled : 1;  // 0x392(0x1)
	char pad_915[5];  // 0x393(0x5)
	struct AActor* AttachToActor;  // 0x398(0x8)
	float SecondsRemainBeforeDetach;  // 0x3A0(0x4)
	char pad_932_1 : 7;  // 0x3A4(0x1)
	bool INFECTION_NOFADE : 1;  // 0x3A4(0x1)
	char PingTypeEnum Ping Type;  // 0x3A5(0x1)
	char pad_934_1 : 7;  // 0x3A6(0x1)
	bool Sticky Attach? : 1;  // 0x3A6(0x1)
	char pad_935[1];  // 0x3A7(0x1)
	struct APlayerState* Sticky Player State;  // 0x3A8(0x8)
	float CamcorderDuration;  // 0x3B0(0x4)

	void TryFindNewAttachActor(bool& OK); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.TryFindNewAttachActor
	void UpdateWidgetPhase(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.UpdateWidgetPhase
	void UpdateScreenLocation(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.UpdateScreenLocation
	void ReceiveBeginPlay(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.ReceiveTick
	void OnHold(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.OnHold
	void OnExit(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.OnExit
	void OnComplete(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.OnComplete
	void Activate(struct FVector Location, struct FS_SPS_IconSettings Settings, struct APlayerState* PS Owner, struct APlayerController* PC, char PingTypeEnum Ping Type); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.Activate
	void Deactivate(bool Force); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.Deactivate
	void CheckIsCentered(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.CheckIsCentered
	void CheckIsOwned(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.CheckIsOwned
	void SetCancel(bool Cancel?); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.SetCancel
	void Cancelled(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.Cancelled
	void AttachTo(struct AActor* Actor); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.AttachTo
	void TargetLost(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.TargetLost
	void Recache(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.Recache
	void ExecuteUbergraph_BP_SPS_WidgetActor(int32_t EntryPoint); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.ExecuteUbergraph_BP_SPS_WidgetActor
	void UpdateWidgetState__DelegateSignature(char E_SPS_Icon_AnimationState New); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.UpdateWidgetState__DelegateSignature
	void DeactivateWidget__DelegateSignature(); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.DeactivateWidget__DelegateSignature
	void ActivateWidget__DelegateSignature(struct FVector Location, struct FS_SPS_IconSettings Settings); // Function BP_SPS_WidgetActor.BP_SPS_WidgetActor_C.ActivateWidget__DelegateSignature
}; 



