#pragma once 
#include "SDK.h" 
 
 
// Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.SetLight
// Size: 0x54(Inherited: 0x0) 
struct FSetLight
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool  ON : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FLinearColor Temp_struct_Variable;  // 0x4(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x14(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x24(0x4)
	struct FLinearColor K2Node_Select_Default;  // 0x28(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct APointLight* CallFunc_Array_Get_Item;  // 0x40(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)

}; 
// Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.ExecuteUbergraph_BP_BigHammer_Factory
// Size: 0x160(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BigHammer_Factory
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AActor* K2Node_CustomEvent_ResponsibleActor_2;  // 0x18(0x8)
	struct AActor* K2Node_CustomEvent_ResponsibleActor;  // 0x20(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x38(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x40(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x48(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x50(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x60(0x88)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x100(0x1)
	char pad_257[3];  // 0x101(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x104(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x110(0xC)
	float CallFunc_BreakVector_X;  // 0x11C(0x4)
	float CallFunc_BreakVector_Y;  // 0x120(0x4)
	float CallFunc_BreakVector_Z;  // 0x124(0x4)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize;  // 0x134(0xC)
	struct TScriptInterface<IDamageInterface_C> K2Node_DynamicCast_AsDamage_Interface;  // 0x140(0x10)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x151(0x1)
	char pad_338[6];  // 0x152(0x6)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x158(0x8)

}; 
// Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.BndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.Server_BeginHammer
// Size: 0x8(Inherited: 0x0) 
struct FServer_BeginHammer
{
	struct AActor* ResponsibleActor;  // 0x0(0x8)

}; 
// Function BP_BigHammer_Factory.BP_BigHammer_Factory_C.BeginHammer
// Size: 0x8(Inherited: 0x0) 
struct FBeginHammer
{
	struct AActor* ResponsibleActor;  // 0x0(0x8)

}; 
