#pragma once 
#include <ActNatural_NCosmetEquipped_Structs.h>
 
 
 
// BlueprintGeneratedClass ActNatural_NCosmetEquipped.ActNatural_NCosmetEquipped_C
// Size: 0x31(Inherited: 0x28) 
struct UActNatural_NCosmetEquipped_C : public USaveGame
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28(0x8)
	char Sprays EquippedSpray;  // 0x30(0x1)

	void ExecuteUbergraph_ActNatural_NCosmetEquipped(int32_t EntryPoint); // Function ActNatural_NCosmetEquipped.ActNatural_NCosmetEquipped_C.ExecuteUbergraph_ActNatural_NCosmetEquipped
}; 



