#pragma once 
#include <BP_CannonballProj_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CannonballProj.BP_CannonballProj_C
// Size: 0x250(Inherited: 0x220) 
struct ABP_CannonballProj_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USphereComponent* Sphere;  // 0x228(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_Bomb_merged_2_c;  // 0x238(0x8)
	struct AMGH_PlayerState_C* WhoFired;  // 0x240(0x8)
	struct ABP_Hunter_C* DirectHitHunter;  // 0x248(0x8)

	void Explode(bool SkipDmg); // Function BP_CannonballProj.BP_CannonballProj_C.Explode
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_CannonballProj.BP_CannonballProj_C.ReceiveHit
	void ReceiveTick(float DeltaSeconds); // Function BP_CannonballProj.BP_CannonballProj_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_CannonballProj.BP_CannonballProj_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_CannonballProj(int32_t EntryPoint); // Function BP_CannonballProj.BP_CannonballProj_C.ExecuteUbergraph_BP_CannonballProj
}; 



