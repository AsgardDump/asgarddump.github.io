#pragma once 
#include "SDK.h" 
 
 
// Function AdditionalLighting.AdditionalLighting_C.ExecuteUbergraph_AdditionalLighting
// Size: 0x72(Inherited: 0x0) 
struct FExecuteUbergraph_AdditionalLighting
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x14(0x4)
	struct APointLight* CallFunc_Array_Get_Item;  // 0x18(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct APointLight* CallFunc_Array_Get_Item_2;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x40(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x58(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x71(0x1)

}; 
// Function AdditionalLighting.AdditionalLighting_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
