#pragma once 
#include <BP_HallucinateActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HallucinateActor.BP_HallucinateActor_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_HallucinateActor_C : public AActor
{
	struct UNiagaraComponent* NS_Hallucinate;  // 0x220(0x8)
	struct UCapsuleComponent* Capsule;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

}; 



