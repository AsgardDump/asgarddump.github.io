#pragma once 
#include "SDK.h" 
 
 
// Function BP_GhostShards_Midnight.BP_GhostShards_Midnight_C.ExecuteUbergraph_BP_GhostShards_Midnight
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GhostShards_Midnight
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
