#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AWSCore.AWSUUID
// Size: 0x10(Inherited: 0x0) 
struct FAWSUUID
{
	struct FString UUID;  // 0x0(0x10)

}; 
// ScriptStruct AWSCore.AWSClientConfiguration
// Size: 0xB8(Inherited: 0x0) 
struct FAWSClientConfiguration
{
	struct FString scheme;  // 0x0(0x10)
	struct FString region;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool useDualStack : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t maxConnections;  // 0x24(0x4)
	int32_t requestTimeoutMs;  // 0x28(0x4)
	int32_t connectTimeoutMs;  // 0x2C(0x4)
	struct FString endpointOverride;  // 0x30(0x10)
	struct FString proxyScheme;  // 0x40(0x10)
	struct FString proxyHost;  // 0x50(0x10)
	char proxyPort;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FString proxyUserName;  // 0x68(0x10)
	struct FString proxyPassword;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool verifySSL : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FString caPath;  // 0x90(0x10)
	struct FString caFile;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool followRedirects : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool disableExpectHeader : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool enableClockSkewAdjustment : 1;  // 0xB2(0x1)
	char pad_179[5];  // 0xB3(0x5)

}; 
// ScriptStruct AWSCore.AWSCredentials
// Size: 0x38(Inherited: 0x0) 
struct FAWSCredentials
{
	struct FString accessKeyId;  // 0x0(0x10)
	struct FString secretKey;  // 0x10(0x10)
	struct FString sessionToken;  // 0x20(0x10)
	struct FDateTime expiration;  // 0x30(0x8)

}; 
// Function AWSCore.UUID.RandomUUID
// Size: 0x10(Inherited: 0x0) 
struct FRandomUUID
{
	struct FAWSUUID ReturnValue;  // 0x0(0x10)

}; 
