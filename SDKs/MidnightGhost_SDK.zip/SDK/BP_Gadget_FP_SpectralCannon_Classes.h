#pragma once 
#include <BP_Gadget_FP_SpectralCannon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C
// Size: 0x268(Inherited: 0x233) 
struct ABP_Gadget_FP_SpectralCannon_C : public ABP_Gadget_FP_C
{
	char pad_563[5];  // 0x233(0x5)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct USceneComponent* FP_SpectralCannonNozzle;  // 0x240(0x8)
	struct UPointLightComponent* FP_InteractivePtLight;  // 0x248(0x8)
	struct UStaticMeshComponent* FP_GlowCylinder;  // 0x250(0x8)
	struct UStaticMeshComponent* FP_GlowCylinderParent;  // 0x258(0x8)
	struct USkeletalMeshComponent* FP_SpectralCannon;  // 0x260(0x8)

	void GetSkeletalMesh(struct USkeletalMeshComponent*& SkeletalMesh); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.GetSkeletalMesh
	void GetComponents(struct TArray<struct USceneComponent*>& Components); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.GetComponents
	void ReceiveBeginPlay(); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.ReceiveTick
	void UpdateVisibility(bool Hide, bool SkipAnimation, bool TickWhileHidden, bool NonLocallyControlledOrBot, bool ShouldInterrupt); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.UpdateVisibility
	void Unequip(); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.Unequip
	void FakeHolsterGadget(); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.FakeHolsterGadget
	void FakeDrawGadget(); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.FakeDrawGadget
	void Init(); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.Init
	void SetWeaponData(bool SC CancelledFire, bool SC Cooldown, bool Chargeup Ocurring, float Cannon Battery Level); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.SetWeaponData
	void Equip(); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.Equip
	void ExecuteUbergraph_BP_Gadget_FP_SpectralCannon(int32_t EntryPoint); // Function BP_Gadget_FP_SpectralCannon.BP_Gadget_FP_SpectralCannon_C.ExecuteUbergraph_BP_Gadget_FP_SpectralCannon
}; 



