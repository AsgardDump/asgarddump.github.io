#pragma once 
#include "SDK.h" 
 
 
// Function BP_MGH_Instance.BP_MGH_Instance_C.SetShowMouse
// Size: 0x1(Inherited: 0x1) 
struct FSetShowMouse : public FSetShowMouse
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool NewShowMouse : 1;  // 0x0(0x1)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.ExecuteUbergraph_BP_MGH_Instance
// Size: 0x214(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MGH_Instance
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct UUserWidget*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct UMGHOnlineLoginManager* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x20(0x8)
	struct UObject* K2Node_CustomEvent_Player_Character_or_Pawn;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	char ENetworkFailure K2Node_Event_FailureType;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool K2Node_Event_bIsServer : 1;  // 0x32(0x1)
	char pad_51[5];  // 0x33(0x5)
	struct ACharacter* CallFunc_FindPawnOrCharacter_AsCharacter;  // 0x38(0x8)
	struct APawn* CallFunc_FindPawnOrCharacter_AsPawn;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x49(0x1)
	char ETravelFailure K2Node_Event_FailureType_2;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x50(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x58(0x10)
	struct FLinearColor CallFunc_FindGradations_01;  // 0x68(0x10)
	struct FLinearColor CallFunc_FindGradations_02;  // 0x78(0x10)
	struct FLinearColor CallFunc_FindGradations_03;  // 0x88(0x10)
	struct FLinearColor CallFunc_FindGradations_04;  // 0x98(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0xA8(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xB8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xBC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct UUserWidget* CallFunc_Array_Get_Item;  // 0xC8(0x8)
	struct TScriptInterface<IBPi_ButtonSounds_C> K2Node_DynamicCast_AsBPi_Button_Sounds;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xE1(0x1)
	char pad_226_1 : 7;  // 0xE2(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0xE2(0x1)
	char pad_227_1 : 7;  // 0xE3(0x1)
	bool K2Node_Event_NewShowMouse : 1;  // 0xE3(0x1)
	char pad_228[4];  // 0xE4(0x4)
	struct FString K2Node_Event_Category;  // 0xE8(0x10)
	struct FString K2Node_Event_Error;  // 0xF8(0x10)
	uint8_t  K2Node_Event_Input;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct TArray<struct FCustomDimension> K2Node_MakeArray_Array;  // 0x110(0x10)
	struct TArray<struct FCustomMetric> K2Node_MakeArray_Array_2;  // 0x120(0x10)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_WorldType__InPIEWorld_ReturnValue : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x134(0x10)
	char pad_324[4];  // 0x144(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x148(0x8)
	struct UEnableCrossplatformFriendsAndInvitesPrompt_C* CallFunc_Create_ReturnValue;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_WorldType__InPIEWorld_ReturnValue_2 : 1;  // 0x158(0x1)
	char pad_345[7];  // 0x159(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x160(0x8)
	struct UEnableCrossplatformFriendsAndInvitesPrompt_C* CallFunc_Create_ReturnValue_2;  // 0x168(0x8)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x170(0x4)
	char pad_372[4];  // 0x174(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x180(0x1)
	char pad_385[3];  // 0x181(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x184(0x4)
	struct UMGHOnlineLoginManager* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x188(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x190(0x10)
	struct TArray<struct UUserWidget*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_2;  // 0x1A0(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x1B0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x1C0(0x4)
	char pad_452_1 : 7;  // 0x1C4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x1C4(0x1)
	char pad_453_1 : 7;  // 0x1C5(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_2 : 1;  // 0x1C5(0x1)
	char pad_454[2];  // 0x1C6(0x2)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct UMGHOnlineLoginManager* CallFunc_GetGameInstanceSubsystem_ReturnValue_3;  // 0x1D0(0x8)
	struct UUserWidget* CallFunc_Array_Get_Item_2;  // 0x1D8(0x8)
	struct TScriptInterface<IBPI_BaseColor_C> K2Node_DynamicCast_AsBPI_Base_Color;  // 0x1E0(0x10)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1F0(0x1)
	char pad_497_1 : 7;  // 0x1F1(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1F1(0x1)
	char pad_498_1 : 7;  // 0x1F2(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_2 : 1;  // 0x1F2(0x1)
	char pad_499[1];  // 0x1F3(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x1F4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x204(0x10)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.Report Log Error
// Size: 0x20(Inherited: 0x20) 
struct FReport Log Error : public FReport Log Error
{
	struct FString Category;  // 0x0(0x10)
	struct FString Error;  // 0x10(0x10)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.HandleNetworkError
// Size: 0x2(Inherited: 0x2) 
struct FHandleNetworkError : public FHandleNetworkError
{
	char ENetworkFailure FailureType;  // 0x0(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bIsServer : 1;  // 0x1(0x1)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.SetInputType_Int
// Size: 0x1(Inherited: 0x1) 
struct FSetInputType_Int : public FSetInputType_Int
{
	uint8_t  Input;  // 0x0(0x1)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.HandleTravelError
// Size: 0x1(Inherited: 0x1) 
struct FHandleTravelError : public FHandleTravelError
{
	char ETravelFailure FailureType;  // 0x0(0x1)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.HandlePauseMenu
// Size: 0x8(Inherited: 0x0) 
struct FHandlePauseMenu
{
	struct UObject* Player Character or Pawn;  // 0x0(0x8)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.SetInputType
// Size: 0x2(Inherited: 0x0) 
struct FSetInputType
{
	uint8_t  InputType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.FindPawnOrCharacter
// Size: 0x31(Inherited: 0x0) 
struct FFindPawnOrCharacter
{
	struct UObject* Object;  // 0x0(0x8)
	struct ACharacter* AsCharacter;  // 0x8(0x8)
	struct APawn* AsPawn;  // 0x10(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.FindGradations
// Size: 0xD0(Inherited: 0x0) 
struct FFindGradations
{
	struct FLinearColor In Color;  // 0x0(0x10)
	struct FLinearColor 01;  // 0x10(0x10)
	struct FLinearColor 02;  // 0x20(0x10)
	struct FLinearColor 03;  // 0x30(0x10)
	struct FLinearColor 04;  // 0x40(0x10)
	float CallFunc_BreakColor_R;  // 0x50(0x4)
	float CallFunc_BreakColor_G;  // 0x54(0x4)
	float CallFunc_BreakColor_B;  // 0x58(0x4)
	float CallFunc_BreakColor_A;  // 0x5C(0x4)
	float CallFunc_BreakColor_R_2;  // 0x60(0x4)
	float CallFunc_BreakColor_G_2;  // 0x64(0x4)
	float CallFunc_BreakColor_B_2;  // 0x68(0x4)
	float CallFunc_BreakColor_A_2;  // 0x6C(0x4)
	struct FLinearColor K2Node_MakeStruct_LinearColor;  // 0x70(0x10)
	struct FLinearColor K2Node_MakeStruct_LinearColor_2;  // 0x80(0x10)
	float CallFunc_BreakColor_R_3;  // 0x90(0x4)
	float CallFunc_BreakColor_G_3;  // 0x94(0x4)
	float CallFunc_BreakColor_B_3;  // 0x98(0x4)
	float CallFunc_BreakColor_A_3;  // 0x9C(0x4)
	float CallFunc_BreakColor_R_4;  // 0xA0(0x4)
	float CallFunc_BreakColor_G_4;  // 0xA4(0x4)
	float CallFunc_BreakColor_B_4;  // 0xA8(0x4)
	float CallFunc_BreakColor_A_4;  // 0xAC(0x4)
	struct FLinearColor K2Node_MakeStruct_LinearColor_3;  // 0xB0(0x10)
	struct FLinearColor K2Node_MakeStruct_LinearColor_4;  // 0xC0(0x10)

}; 
// Function BP_MGH_Instance.BP_MGH_Instance_C.GetInputType_Int
// Size: 0x1(Inherited: 0x1) 
struct FGetInputType_Int : public FGetInputType_Int
{
	uint8_t  Type;  // 0x0(0x1)

}; 
