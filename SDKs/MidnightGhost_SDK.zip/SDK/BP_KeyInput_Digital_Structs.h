#pragma once 
#include "SDK.h" 
 
 
// Function BP_KeyInput_Digital.BP_KeyInput_Digital_C.Key Input Current State
// Size: 0x18(Inherited: 0x9E) 
struct FKey Input Current State : public FKey Input Current State
{
	struct APlayerController* Controller;  // 0x0(0x8)
	float Axis Value;  // 0x8(0x4)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool Down : 1;  // 0xC(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool Just Pressed : 1;  // 0xD(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool Just Released : 1;  // 0xE(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool CallFunc_WasInputKeyJustReleased_ReturnValue : 1;  // 0xF(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue : 1;  // 0x10(0x1)
	char pad_175_1 : 7;  // 0xAF(0x1)
	bool CallFunc_WasInputKeyJustPressed_ReturnValue : 1;  // 0x11(0x1)
	float CallFunc_Conv_BoolToFloat_ReturnValue;  // 0x14(0x4)

}; 
