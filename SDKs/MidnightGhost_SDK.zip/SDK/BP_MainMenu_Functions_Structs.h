#pragma once 
#include "SDK.h" 
 
 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.FindPlayerStateForPUID
// Size: 0xCA(Inherited: 0x0) 
struct FFindPlayerStateForPUID
{
	struct FString Puid;  // 0x0(0x10)
	struct AGameStateBase* GameState;  // 0x10(0x8)
	struct UObject* __WorldContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Found : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> PlayerState;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool DidFound : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> ThisPS;  // 0x40(0x10)
	struct FString ThePUID;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_WorldType__InPIEWorld_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x64(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x68(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x6C(0x4)
	struct APlayerState* CallFunc_Array_Get_Item;  // 0x70(0x8)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> K2Node_DynamicCast_AsMGH_Player_State_Interface;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FString CallFunc_GetMGHPlayerName_Player_Name;  // 0x90(0x10)
	struct FString CallFunc_GetProductUserID_ProductUserID;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_IsEmpty_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UObject* CallFunc_Conv_InterfaceToObject_ReturnValue;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0xC9(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAnyKeybindingButtonFocus
// Size: 0x51(Inherited: 0x0) 
struct FHasAnyKeybindingButtonFocus
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool HasFocus : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bHasFocus : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	struct TArray<struct UWB_InputKeySelector_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	struct UWB_InputKeySelector_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_HasUserFocus_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x50(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnVideoBack
// Size: 0x28(Inherited: 0x0) 
struct FBindOnVideoBack
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FDelegate Event;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_Video_C* CallFunc_GetVideoOptions_WB_Options_Video;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnhoverAllNativeButtons
// Size: 0x48(Inherited: 0x0) 
struct FUnhoverAllNativeButtons
{
	struct UWB_NativeButton_C* Exception;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct TArray<struct UWB_NativeButton_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x2C(0x4)
	struct UWB_NativeButton_C* CallFunc_Array_Get_Item;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_GetIsEnabled_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x3A(0x1)
	char pad_59[1];  // 0x3B(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x44(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetMGHPlayerName
// Size: 0x48(Inherited: 0x0) 
struct FGetMGHPlayerName
{
	struct APlayerState* Player State;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FString Player Name;  // 0x10(0x10)
	struct TScriptInterface<IBasePlayerStateInterface_C> K2Node_DynamicCast_AsBase_Player_State_Interface;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_GetMGHPlayerName_MGHPlayerName;  // 0x38(0x10)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HandleResponsiveHovering
// Size: 0x20(Inherited: 0x0) 
struct FHandleResponsiveHovering
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bResponsiveHovering : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UWB_NativeButton_C* ButtonToFocus;  // 0x8(0x8)
	struct APlayerController* OwningPlayer;  // 0x10(0x8)
	struct UObject* __WorldContext;  // 0x18(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Get_WB_MainMenu
// Size: 0x49(Inherited: 0x0) 
struct FGet_WB_MainMenu
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UWB_ProMainMenu_C* WB_ProMainMenu;  // 0x10(0x8)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x18(0x8)
	struct TScriptInterface<IMainMenuHud_Interface_C> K2Node_DynamicCast_AsMain_Menu_Hud_Interface;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct UUserWidget* CallFunc_GetProMainMenu_Int_WB_Pro_Main_Menu;  // 0x38(0x8)
	struct UWB_ProMainMenu_C* K2Node_DynamicCast_AsWB_Pro_Main_Menu;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAnyProgressButtonFocus
// Size: 0x51(Inherited: 0x0) 
struct FHasAnyProgressButtonFocus
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool HasFocus : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bHasFocus : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	struct TArray<struct UWB_Progress_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	struct UWB_Progress_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_HasUserFocus_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x50(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAnyButtonFocus
// Size: 0x51(Inherited: 0x0) 
struct FHasAnyButtonFocus
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool HasFocus : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bHasFocus : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	struct TArray<struct UWB_NativeButton_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	struct UWB_NativeButton_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_HasUserFocus_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x50(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetCategoryColor
// Size: 0xB4(Inherited: 0x0) 
struct FGetCategoryColor
{
	char LoadoutCategoryTypes Category;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor CategoryColor;  // 0x10(0x10)
	char LoadoutCategoryTypes Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x24(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x34(0x10)
	struct FLinearColor Temp_struct_Variable_3;  // 0x44(0x10)
	struct FLinearColor Temp_struct_Variable_4;  // 0x54(0x10)
	struct FLinearColor Temp_struct_Variable_5;  // 0x64(0x10)
	struct FLinearColor Temp_struct_Variable_6;  // 0x74(0x10)
	struct FLinearColor Temp_struct_Variable_7;  // 0x84(0x10)
	struct FLinearColor Temp_struct_Variable_8;  // 0x94(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0xA4(0x10)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.CreateRequest
// Size: 0xC2(Inherited: 0x0) 
struct FCreateRequest
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShowOnlyOkButton : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUseCancelCountdown : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FText HeadText;  // 0x8(0x18)
	struct FText MessageText;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CUSTOM - LEAVE MATCH? : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UObject* __WorldContext;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UWB_Request_C* NewWidget;  // 0x50(0x8)
	struct UWB_Request_C* CallFunc_Create_ReturnValue;  // 0x58(0x8)
	struct TArray<struct UWB_Request_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x60(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct UWB_Request_C* CallFunc_Array_Get_Item;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool CallFunc_IsInViewport_ReturnValue : 1;  // 0x82(0x1)
	char pad_131[5];  // 0x83(0x5)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Temp_bool_Variable : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xA0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool K2Node_Select_Default : 1;  // 0xC1(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.SetupParameters
// Size: 0x39(Inherited: 0x0) 
struct FSetupParameters
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x8(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_2;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnConfirmRequest
// Size: 0x38(Inherited: 0x0) 
struct FBindOnConfirmRequest
{
	struct FDelegate Event;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct TArray<struct UWB_Request_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x18(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct UWB_Request_C* CallFunc_Array_Get_Item;  // 0x30(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetHealthForHunterPerk
// Size: 0x65(Inherited: 0x0) 
struct FGetHealthForHunterPerk
{
	char HunterPerks Perk;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	float MaxHealth;  // 0x10(0x4)
	float HP;  // 0x14(0x4)
	char HunterPerks Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float Temp_float_Variable;  // 0x1C(0x4)
	float Temp_float_Variable_2;  // 0x20(0x4)
	float Temp_float_Variable_3;  // 0x24(0x4)
	float Temp_float_Variable_4;  // 0x28(0x4)
	float Temp_float_Variable_5;  // 0x2C(0x4)
	float Temp_float_Variable_6;  // 0x30(0x4)
	float Temp_float_Variable_7;  // 0x34(0x4)
	float Temp_float_Variable_8;  // 0x38(0x4)
	float Temp_float_Variable_9;  // 0x3C(0x4)
	float Temp_float_Variable_10;  // 0x40(0x4)
	float Temp_float_Variable_11;  // 0x44(0x4)
	float Temp_float_Variable_12;  // 0x48(0x4)
	float Temp_float_Variable_13;  // 0x4C(0x4)
	float Temp_float_Variable_14;  // 0x50(0x4)
	float Temp_float_Variable_15;  // 0x54(0x4)
	float Temp_float_Variable_16;  // 0x58(0x4)
	float Temp_float_Variable_17;  // 0x5C(0x4)
	float K2Node_Select_Default;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x64(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnCancelRequest
// Size: 0x38(Inherited: 0x0) 
struct FBindOnCancelRequest
{
	struct FDelegate Event;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct TArray<struct UWB_Request_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x18(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct UWB_Request_C* CallFunc_Array_Get_Item;  // 0x30(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveRequest
// Size: 0x28(Inherited: 0x0) 
struct FRemoveRequest
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct TArray<struct UWB_Request_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x8(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct UWB_Request_C* CallFunc_Array_Get_Item;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetGameStatusUI
// Size: 0x1E8(Inherited: 0x0) 
struct FGetGameStatusUI
{
	struct TScriptInterface<IMGH_GameState_Interface_C> GameState;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FText Text;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_Variable : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_ArePlayersLoadingIn_Int_PlayersLoadingIn : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_HasEvacArrived_Int_EvacArrived : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_IsCountdownMode_Int_IsCountdownMode : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_IsWaitingForPlayers_Int_WaitingForPlayers : 1;  // 0x34(0x1)
	char GameModeTypeEnum CallFunc_GetGameMode_Int_GameMode;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_IsMidnight_Int_IsMidnight : 1;  // 0x36(0x1)
	char pad_55[1];  // 0x37(0x1)
	struct FText Temp_text_Variable;  // 0x38(0x18)
	struct FText Temp_text_Variable_2;  // 0x50(0x18)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FText K2Node_Select_Default;  // 0x70(0x18)
	struct FText Temp_text_Variable_3;  // 0x88(0x18)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FText Temp_text_Variable_4;  // 0xA8(0x18)
	struct FText Temp_text_Variable_5;  // 0xC0(0x18)
	char GameModeTypeEnum Temp_byte_Variable;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FText K2Node_Select_Default_2;  // 0xE0(0x18)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct FText Temp_text_Variable_6;  // 0x100(0x18)
	struct FText Temp_text_Variable_7;  // 0x118(0x18)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct FText K2Node_Select_Default_3;  // 0x138(0x18)
	struct FText Temp_text_Variable_8;  // 0x150(0x18)
	struct FText K2Node_Select_Default_4;  // 0x168(0x18)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct FText K2Node_Select_Default_5;  // 0x188(0x18)
	struct FText Temp_text_Variable_9;  // 0x1A0(0x18)
	struct FText K2Node_Select_Default_6;  // 0x1B8(0x18)
	struct FText K2Node_Select_Default_7;  // 0x1D0(0x18)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnbindOnConfirmRequest
// Size: 0x38(Inherited: 0x0) 
struct FUnbindOnConfirmRequest
{
	struct FDelegate Event;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct TArray<struct UWB_Request_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x18(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct UWB_Request_C* CallFunc_Array_Get_Item;  // 0x30(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnbindOnCancelRequest
// Size: 0x38(Inherited: 0x0) 
struct FUnbindOnCancelRequest
{
	struct FDelegate Event;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct TArray<struct UWB_Request_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x18(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct UWB_Request_C* CallFunc_Array_Get_Item;  // 0x30(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.CreateBackRequest
// Size: 0x3F(Inherited: 0x0) 
struct FCreateBackRequest
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UWB_UnappliedChanges_BackRequest_C* NewWidget;  // 0x10(0x8)
	struct UWB_UnappliedChanges_BackRequest_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)
	struct TArray<struct UWB_UnappliedChanges_BackRequest_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x20(0x10)
	struct UWB_UnappliedChanges_BackRequest_C* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_IsInViewport_ReturnValue : 1;  // 0x3E(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AddAudioUnappliedChanges
// Size: 0x24(Inherited: 0x0) 
struct FAddAudioUnappliedChanges
{
	char AudioVolumeType NewChange;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* PC;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UWB_Options_Audio_C* CallFunc_GetAudioOptions_WB_Options_Audio;  // 0x18(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Get_WB_PauseMenu
// Size: 0x41(Inherited: 0x0) 
struct FGet_WB_PauseMenu
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UWB_PauseMenu_C* WB_PauseMenu;  // 0x8(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	struct TScriptInterface<IMGHPlayerController_Interface_C> K2Node_DynamicCast_AsMGHPlayer_Controller_Interface;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UObject* CallFunc_GetPauseMenuObject_Int_PauseMenuObject;  // 0x30(0x8)
	struct UWB_PauseMenu_C* K2Node_DynamicCast_AsWB_Pause_Menu;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Seconds_To_MinuteSeconds
// Size: 0x1C0(Inherited: 0x0) 
struct FSeconds_To_MinuteSeconds
{
	float Seconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FString Minutes:Seconds;  // 0x10(0x10)
	float Minutes Out;  // 0x20(0x4)
	float Seconds Out;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x30(0x4)
	int32_t CallFunc_FFloor_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_FFloor_ReturnValue_2;  // 0x38(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x70(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x80(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_4;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xA8(0x10)
	struct FString K2Node_Select_Default;  // 0xB8(0x10)
	struct FString K2Node_Select_Default_2;  // 0xC8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xD8(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0xF0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x108(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x148(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x188(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x198(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x1B0(0x10)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AverageOfFloatArray
// Size: 0x50(Inherited: 0x0) 
struct FAverageOfFloatArray
{
	struct TArray<float> Floats;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float Average;  // 0x18(0x4)
	float Sum;  // 0x1C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x24(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x30(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	float CallFunc_Array_Get_Item;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x44(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x48(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x4C(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.DistanceBetweenActors
// Size: 0x4C(Inherited: 0x0) 
struct FDistanceBetweenActors
{
	struct AActor* Actor 1;  // 0x0(0x8)
	struct AActor* Actor 2;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float Distance;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Successful : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1D(0x1)
	char pad_30[2];  // 0x1E(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x20(0xC)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x30(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x3C(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x48(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnApplyDropdown
// Size: 0x28(Inherited: 0x0) 
struct FBindOnApplyDropdown
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FDelegate Event;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_Video_C* CallFunc_GetVideoOptions_WB_Options_Video;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnAudioBack
// Size: 0x28(Inherited: 0x0) 
struct FBindOnAudioBack
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FDelegate Event;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_Audio_C* CallFunc_GetAudioOptions_WB_Options_Audio;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnControlApply
// Size: 0x28(Inherited: 0x0) 
struct FBindOnControlApply
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FDelegate Event;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_Controls_C* CallFunc_GetControlOptions_WB_Options_Controls;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.MapStringFixer
// Size: 0x30(Inherited: 0x0) 
struct FMapStringFixer
{
	struct FString Map String In;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool To Display Name? : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct FString Map String Fixed;  // 0x20(0x10)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Matching Strings Remove
// Size: 0x106(Inherited: 0x0) 
struct FMatching Strings Remove
{
	struct TArray<struct FString> Base String Array;  // 0x0(0x10)
	struct TArray<struct FString> Strings to Remove;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Found : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct TArray<struct FString> Base Strings Filtered;  // 0x30(0x10)
	struct TArray<struct FString> Base Strings Removed;  // 0x40(0x10)
	struct TArray<struct FString> RemovedStrings;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool FoundBool : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct TArray<struct FString> FilteredStrings;  // 0x68(0x10)
	struct TArray<int32_t> MatchingIndexes;  // 0x78(0x10)
	struct TArray<struct FString> StringsToCheck;  // 0x88(0x10)
	struct TArray<struct FString> BaseStrings;  // 0x98(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0xA8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xAC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB0(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xBC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct FString CallFunc_Array_Get_Item;  // 0xC8(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0xD8(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0xDC(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_3;  // 0xE0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xE4(0x4)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct FString CallFunc_Array_Get_Item_2;  // 0xF0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x100(0x4)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x104(0x1)
	char pad_261_1 : 7;  // 0x105(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x105(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetVideoOptions
// Size: 0x29(Inherited: 0x0) 
struct FGetVideoOptions
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UWB_Options_Video_C* WB_Options_Video;  // 0x10(0x8)
	struct UWB_PauseMenu_C* CallFunc_Get_WB_PauseMenu_WB_PauseMenu;  // 0x18(0x8)
	struct UWB_ProMainMenu_C* CallFunc_Get_WB_MainMenu_WB_ProMainMenu;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.IsActorInFrontOfActor
// Size: 0xA4(Inherited: 0x0) 
struct FIsActorInFrontOfActor
{
	struct AActor* Actor A;  // 0x0(0x8)
	struct AActor* Actor B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Below Check Too? : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UObject* __WorldContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool In Front : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float DOT Product;  // 0x24(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x28(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x34(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x40(0xC)
	float CallFunc_BreakVector_X;  // 0x4C(0x4)
	float CallFunc_BreakVector_Y;  // 0x50(0x4)
	float CallFunc_BreakVector_Z;  // 0x54(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x58(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x64(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x70(0xC)
	float CallFunc_BreakVector_X_2;  // 0x7C(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x80(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x84(0x4)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x88(0xC)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	float CallFunc_Dot_VectorVector_ReturnValue;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x9C(0x1)
	char pad_157_1 : 7;  // 0x9D(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x9D(0x1)
	char pad_158_1 : 7;  // 0x9E(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x9E(0x1)
	char pad_159_1 : 7;  // 0x9F(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_2 : 1;  // 0x9F(0x1)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_3 : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xA2(0x1)
	char pad_163_1 : 7;  // 0xA3(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0xA3(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Add Video Unapplied Changes
// Size: 0x24(Inherited: 0x0) 
struct FAdd Video Unapplied Changes
{
	char EVideoSettings NewItem;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* PC;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UWB_Options_Video_C* CallFunc_GetVideoOptions_WB_Options_Video;  // 0x18(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.CalculateHunterHealth
// Size: 0x28(Inherited: 0x0) 
struct FCalculateHunterHealth
{
	char HunterPerks Hunter Perk;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Old Health;  // 0x4(0x4)
	float Old Max Health;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float Set Health;  // 0x18(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_GetHealthForHunterPerk_MaxHealth;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasVideoUnappliedChanges
// Size: 0x31(Inherited: 0x0) 
struct FHasVideoUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	char EVideoSettings ItemToFind;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UWB_Options_Video_C* CallFunc_GetVideoOptions_WB_Options_Video;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveControlUnappliedChanges
// Size: 0x26(Inherited: 0x0) 
struct FRemoveControlUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	char EControlSettings NewItem;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UWB_Options_Controls_C* CallFunc_GetControlOptions_WB_Options_Controls;  // 0x18(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x25(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetAudioOptions
// Size: 0x29(Inherited: 0x0) 
struct FGetAudioOptions
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UWB_Options_Audio_C* WB_Options_Audio;  // 0x10(0x8)
	struct UWB_PauseMenu_C* CallFunc_Get_WB_PauseMenu_WB_PauseMenu;  // 0x18(0x8)
	struct UWB_ProMainMenu_C* CallFunc_Get_WB_MainMenu_WB_ProMainMenu;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasKeyBindingUnappliedChanges
// Size: 0x39(Inherited: 0x0) 
struct FHasKeyBindingUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FString ItemToFind;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UWB_Options_KeyRebinding_C* CallFunc_GetKeyBindingOptions_WB_Options_KeyRebinding;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAudioUnappliedChanges
// Size: 0x31(Inherited: 0x0) 
struct FHasAudioUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	char AudioVolumeType ItemToFind;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UWB_Options_Audio_C* CallFunc_GetAudioOptions_WB_Options_Audio;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnAudioApply
// Size: 0x28(Inherited: 0x0) 
struct FBindOnAudioApply
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FDelegate Event;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_Audio_C* CallFunc_GetAudioOptions_WB_Options_Audio;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Calculate Matchmaking Level Modifier
// Size: 0x70(Inherited: 0x0) 
struct FCalculate Matchmaking Level Modifier
{
	int32_t PlayerLevel;  // 0x0(0x4)
	int32_t PlayerMultiplier;  // 0x4(0x4)
	int32_t PartyCount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	int32_t ModifiedLevel;  // 0x18(0x4)
	float ToAdd;  // 0x1C(0x4)
	float PartyScoreMultiplier;  // 0x20(0x4)
	int32_t Party Count Int;  // 0x24(0x4)
	float PlayerLevelSqrt;  // 0x28(0x4)
	int32_t AdjustedPlayerLevel;  // 0x2C(0x4)
	float ToAdjust;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool PositiveOrPenalty : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t Multiplier;  // 0x38(0x4)
	int32_t PlayerLevelStart;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x44(0x4)
	float CallFunc_Sqrt_ReturnValue;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x54(0x4)
	int32_t CallFunc_Clamp_ReturnValue_2;  // 0x58(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x5C(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x60(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x6C(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetControlOptions
// Size: 0x29(Inherited: 0x0) 
struct FGetControlOptions
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UWB_Options_Controls_C* WB_Options_Controls;  // 0x10(0x8)
	struct UWB_PauseMenu_C* CallFunc_Get_WB_PauseMenu_WB_PauseMenu;  // 0x18(0x8)
	struct UWB_ProMainMenu_C* CallFunc_Get_WB_MainMenu_WB_ProMainMenu;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AddControlUnappliedChanges
// Size: 0x24(Inherited: 0x0) 
struct FAddControlUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	char EControlSettings NewItem;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UWB_Options_Controls_C* CallFunc_GetControlOptions_WB_Options_Controls;  // 0x18(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasControlUnappliedChanges
// Size: 0x31(Inherited: 0x0) 
struct FHasControlUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	char EControlSettings NewItem;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UWB_Options_Controls_C* CallFunc_GetControlOptions_WB_Options_Controls;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetKeyBindingOptions
// Size: 0x20(Inherited: 0x0) 
struct FGetKeyBindingOptions
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UWB_Options_KeyRebinding_C* WB_Options_KeyRebinding;  // 0x10(0x8)
	struct UWB_Options_Controls_C* CallFunc_GetControlOptions_WB_Options_Controls;  // 0x18(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AddKeyBindingUnappliedChanges
// Size: 0x2C(Inherited: 0x0) 
struct FAddKeyBindingUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FString NewItem;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_KeyRebinding_C* CallFunc_GetKeyBindingOptions_WB_Options_KeyRebinding;  // 0x20(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x28(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnKeyBindingApply
// Size: 0x28(Inherited: 0x0) 
struct FBindOnKeyBindingApply
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FDelegate Event;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_KeyRebinding_C* CallFunc_GetKeyBindingOptions_WB_Options_KeyRebinding;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnControlBack
// Size: 0x28(Inherited: 0x0) 
struct FBindOnControlBack
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FDelegate Event;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_Controls_C* CallFunc_GetControlOptions_WB_Options_Controls;  // 0x20(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindAllBackRequest
// Size: 0x58(Inherited: 0x0) 
struct FBindAllBackRequest
{
	struct FDelegate OnBackApply;  // 0x0(0x10)
	struct FDelegate OnDiscardChanges;  // 0x10(0x10)
	struct FDelegate OnCancel;  // 0x20(0x10)
	struct UObject* __WorldContext;  // 0x30(0x8)
	struct TArray<struct UWB_UnappliedChanges_BackRequest_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x38(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct UWB_UnappliedChanges_BackRequest_C* CallFunc_Array_Get_Item;  // 0x50(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HunterIconRenderTranslate
// Size: 0x1B0(Inherited: 0x0) 
struct FHunterIconRenderTranslate
{
	char HunterGadgets InputPin;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Tooltip : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FVector2D ReturnValue;  // 0x10(0x8)
	char HunterGadgets Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector2D Temp_struct_Variable;  // 0x1C(0x8)
	struct FVector2D Temp_struct_Variable_2;  // 0x24(0x8)
	struct FVector2D Temp_struct_Variable_3;  // 0x2C(0x8)
	struct FVector2D Temp_struct_Variable_4;  // 0x34(0x8)
	struct FVector2D Temp_struct_Variable_5;  // 0x3C(0x8)
	struct FVector2D Temp_struct_Variable_6;  // 0x44(0x8)
	struct FVector2D Temp_struct_Variable_7;  // 0x4C(0x8)
	struct FVector2D Temp_struct_Variable_8;  // 0x54(0x8)
	struct FVector2D Temp_struct_Variable_9;  // 0x5C(0x8)
	struct FVector2D Temp_struct_Variable_10;  // 0x64(0x8)
	struct FVector2D Temp_struct_Variable_11;  // 0x6C(0x8)
	struct FVector2D Temp_struct_Variable_12;  // 0x74(0x8)
	struct FVector2D Temp_struct_Variable_13;  // 0x7C(0x8)
	struct FVector2D Temp_struct_Variable_14;  // 0x84(0x8)
	struct FVector2D Temp_struct_Variable_15;  // 0x8C(0x8)
	struct FVector2D Temp_struct_Variable_16;  // 0x94(0x8)
	struct FVector2D Temp_struct_Variable_17;  // 0x9C(0x8)
	struct FVector2D Temp_struct_Variable_18;  // 0xA4(0x8)
	struct FVector2D Temp_struct_Variable_19;  // 0xAC(0x8)
	struct FVector2D Temp_struct_Variable_20;  // 0xB4(0x8)
	struct FVector2D Temp_struct_Variable_21;  // 0xBC(0x8)
	struct FVector2D Temp_struct_Variable_22;  // 0xC4(0x8)
	struct FVector2D Temp_struct_Variable_23;  // 0xCC(0x8)
	struct FVector2D Temp_struct_Variable_24;  // 0xD4(0x8)
	char HunterGadgets Temp_byte_Variable_2;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	struct FVector2D K2Node_Select_Default;  // 0xE0(0x8)
	struct FVector2D Temp_struct_Variable_25;  // 0xE8(0x8)
	struct FVector2D Temp_struct_Variable_26;  // 0xF0(0x8)
	struct FVector2D Temp_struct_Variable_27;  // 0xF8(0x8)
	struct FVector2D Temp_struct_Variable_28;  // 0x100(0x8)
	struct FVector2D Temp_struct_Variable_29;  // 0x108(0x8)
	struct FVector2D Temp_struct_Variable_30;  // 0x110(0x8)
	struct FVector2D Temp_struct_Variable_31;  // 0x118(0x8)
	struct FVector2D Temp_struct_Variable_32;  // 0x120(0x8)
	struct FVector2D Temp_struct_Variable_33;  // 0x128(0x8)
	struct FVector2D Temp_struct_Variable_34;  // 0x130(0x8)
	struct FVector2D Temp_struct_Variable_35;  // 0x138(0x8)
	struct FVector2D Temp_struct_Variable_36;  // 0x140(0x8)
	struct FVector2D Temp_struct_Variable_37;  // 0x148(0x8)
	struct FVector2D Temp_struct_Variable_38;  // 0x150(0x8)
	struct FVector2D Temp_struct_Variable_39;  // 0x158(0x8)
	struct FVector2D Temp_struct_Variable_40;  // 0x160(0x8)
	struct FVector2D Temp_struct_Variable_41;  // 0x168(0x8)
	struct FVector2D Temp_struct_Variable_42;  // 0x170(0x8)
	struct FVector2D Temp_struct_Variable_43;  // 0x178(0x8)
	struct FVector2D Temp_struct_Variable_44;  // 0x180(0x8)
	struct FVector2D Temp_struct_Variable_45;  // 0x188(0x8)
	struct FVector2D Temp_struct_Variable_46;  // 0x190(0x8)
	struct FVector2D Temp_struct_Variable_47;  // 0x198(0x8)
	struct FVector2D Temp_struct_Variable_48;  // 0x1A0(0x8)
	struct FVector2D K2Node_Select_Default_2;  // 0x1A8(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveKeyBindingUnappliedChanges
// Size: 0x2E(Inherited: 0x0) 
struct FRemoveKeyBindingUnappliedChanges
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct FString NewItem;  // 0x8(0x10)
	struct UObject* __WorldContext;  // 0x18(0x8)
	struct UWB_Options_KeyRebinding_C* CallFunc_GetKeyBindingOptions_WB_Options_KeyRebinding;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x2D(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnbindAllBackRequest
// Size: 0x58(Inherited: 0x0) 
struct FUnbindAllBackRequest
{
	struct FDelegate OnBackApply;  // 0x0(0x10)
	struct FDelegate OnDiscardChanges;  // 0x10(0x10)
	struct FDelegate OnCancel;  // 0x20(0x10)
	struct UObject* __WorldContext;  // 0x30(0x8)
	struct TArray<struct UWB_UnappliedChanges_BackRequest_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x38(0x10)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct UWB_UnappliedChanges_BackRequest_C* CallFunc_Array_Get_Item;  // 0x50(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveAudioUnappliedChanges
// Size: 0x26(Inherited: 0x0) 
struct FRemoveAudioUnappliedChanges
{
	char AudioVolumeType NewChange;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* PC;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UWB_Options_Audio_C* CallFunc_GetAudioOptions_WB_Options_Audio;  // 0x18(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x25(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveVideoUnappliedChanges
// Size: 0x26(Inherited: 0x0) 
struct FRemoveVideoUnappliedChanges
{
	char EVideoSettings NewItem;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* PC;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UWB_Options_Video_C* CallFunc_GetVideoOptions_WB_Options_Video;  // 0x18(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x25(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.IsGadgetAWeapon?
// Size: 0x2B(Inherited: 0x0) 
struct FIsGadgetAWeapon?
{
	char HunterGadgets Gadget;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Weapon : 1;  // 0x10(0x1)
	char HunterGadgets Temp_byte_Variable;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Temp_bool_Variable : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x16(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x17(0x1)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_Variable_9 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool Temp_bool_Variable_10 : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Temp_bool_Variable_11 : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool Temp_bool_Variable_12 : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool Temp_bool_Variable_13 : 1;  // 0x1E(0x1)
	char pad_31_1 : 7;  // 0x1F(0x1)
	bool Temp_bool_Variable_14 : 1;  // 0x1F(0x1)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable_15 : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_Variable_16 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool Temp_bool_Variable_17 : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool Temp_bool_Variable_18 : 1;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Temp_bool_Variable_19 : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool Temp_bool_Variable_20 : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool Temp_bool_Variable_21 : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool Temp_bool_Variable_22 : 1;  // 0x27(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable_23 : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable_24 : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_Select_Default : 1;  // 0x2A(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetNetworkOptions
// Size: 0x21(Inherited: 0x0) 
struct FGetNetworkOptions
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UWB_Options_Network_C* WB_Options_Network;  // 0x10(0x8)
	struct UWB_ProMainMenu_C* CallFunc_Get_WB_MainMenu_WB_ProMainMenu;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.DistanceBetweenActors_ZDampened
// Size: 0x170(Inherited: 0x0) 
struct FDistanceBetweenActors_ZDampened
{
	struct AActor* Actor 1;  // 0x0(0x8)
	struct AActor* Actor 2;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float Distance;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Successful : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float Distance Z Dampened;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool LOSFailed? : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float Temp_float_Variable;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x30(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x40(0xC)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float CallFunc_BreakVector_X;  // 0x50(0x4)
	float CallFunc_BreakVector_Y;  // 0x54(0x4)
	float CallFunc_BreakVector_Z;  // 0x58(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x5C(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x68(0xC)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool Temp_bool_Variable : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	float CallFunc_BreakVector_X_2;  // 0x78(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x7C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x80(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x84(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x90(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x9C(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0xA0(0xC)
	float Temp_float_Variable_2;  // 0xAC(0x4)
	float CallFunc_VSize_ReturnValue_2;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xB5(0x1)
	char pad_182[2];  // 0xB6(0x2)
	float K2Node_Select_Default;  // 0xB8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xBC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_2;  // 0xC8(0x10)
	float Temp_float_Variable_3;  // 0xD8(0x4)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0xDC(0x88)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x164(0x1)
	char pad_357[3];  // 0x165(0x3)
	float K2Node_Select_Default_2;  // 0x168(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x16C(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HowMuchXPNeededToLevel?
// Size: 0x34(Inherited: 0x0) 
struct FHowMuchXPNeededToLevel?
{
	int32_t Current Level;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	int32_t XP Needed;  // 0x10(0x4)
	int32_t CallFunc_MakeLiteralInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Clamp_ReturnValue_2;  // 0x24(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2C(0x4)
	int32_t CallFunc_Clamp_ReturnValue_3;  // 0x30(0x4)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HunterIconRenderScale
// Size: 0x1DC(Inherited: 0x0) 
struct FHunterIconRenderScale
{
	char HunterGadgets InputPin;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Tooltip : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FVector2D ReturnValue;  // 0x10(0x8)
	struct FVector2D Temp_struct_Variable;  // 0x18(0x8)
	char HunterGadgets Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FVector2D Temp_struct_Variable_2;  // 0x24(0x8)
	struct FVector2D Temp_struct_Variable_3;  // 0x2C(0x8)
	struct FVector2D Temp_struct_Variable_4;  // 0x34(0x8)
	struct FVector2D Temp_struct_Variable_5;  // 0x3C(0x8)
	struct FVector2D Temp_struct_Variable_6;  // 0x44(0x8)
	struct FVector2D Temp_struct_Variable_7;  // 0x4C(0x8)
	struct FVector2D Temp_struct_Variable_8;  // 0x54(0x8)
	struct FVector2D Temp_struct_Variable_9;  // 0x5C(0x8)
	struct FVector2D Temp_struct_Variable_10;  // 0x64(0x8)
	struct FVector2D Temp_struct_Variable_11;  // 0x6C(0x8)
	struct FVector2D Temp_struct_Variable_12;  // 0x74(0x8)
	struct FVector2D Temp_struct_Variable_13;  // 0x7C(0x8)
	struct FVector2D Temp_struct_Variable_14;  // 0x84(0x8)
	struct FVector2D Temp_struct_Variable_15;  // 0x8C(0x8)
	struct FVector2D Temp_struct_Variable_16;  // 0x94(0x8)
	struct FVector2D Temp_struct_Variable_17;  // 0x9C(0x8)
	struct FVector2D Temp_struct_Variable_18;  // 0xA4(0x8)
	struct FVector2D Temp_struct_Variable_19;  // 0xAC(0x8)
	struct FVector2D Temp_struct_Variable_20;  // 0xB4(0x8)
	struct FVector2D Temp_struct_Variable_21;  // 0xBC(0x8)
	struct FVector2D Temp_struct_Variable_22;  // 0xC4(0x8)
	struct FVector2D Temp_struct_Variable_23;  // 0xCC(0x8)
	struct FVector2D Temp_struct_Variable_24;  // 0xD4(0x8)
	struct FVector2D Temp_struct_Variable_25;  // 0xDC(0x8)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool Temp_bool_Variable : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	struct FVector2D Temp_struct_Variable_26;  // 0xE8(0x8)
	struct FVector2D K2Node_Select_Default;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_EqualEqual_Vector2DVector2D_ReturnValue : 1;  // 0xF8(0x1)
	char HunterGadgets Temp_byte_Variable_2;  // 0xF9(0x1)
	char pad_250[2];  // 0xFA(0x2)
	struct FVector2D Temp_struct_Variable_27;  // 0xFC(0x8)
	struct FVector2D Temp_struct_Variable_28;  // 0x104(0x8)
	struct FVector2D Temp_struct_Variable_29;  // 0x10C(0x8)
	struct FVector2D Temp_struct_Variable_30;  // 0x114(0x8)
	struct FVector2D Temp_struct_Variable_31;  // 0x11C(0x8)
	struct FVector2D Temp_struct_Variable_32;  // 0x124(0x8)
	struct FVector2D Temp_struct_Variable_33;  // 0x12C(0x8)
	struct FVector2D Temp_struct_Variable_34;  // 0x134(0x8)
	struct FVector2D Temp_struct_Variable_35;  // 0x13C(0x8)
	struct FVector2D Temp_struct_Variable_36;  // 0x144(0x8)
	struct FVector2D Temp_struct_Variable_37;  // 0x14C(0x8)
	struct FVector2D Temp_struct_Variable_38;  // 0x154(0x8)
	struct FVector2D Temp_struct_Variable_39;  // 0x15C(0x8)
	struct FVector2D Temp_struct_Variable_40;  // 0x164(0x8)
	struct FVector2D Temp_struct_Variable_41;  // 0x16C(0x8)
	struct FVector2D Temp_struct_Variable_42;  // 0x174(0x8)
	struct FVector2D Temp_struct_Variable_43;  // 0x17C(0x8)
	struct FVector2D Temp_struct_Variable_44;  // 0x184(0x8)
	struct FVector2D Temp_struct_Variable_45;  // 0x18C(0x8)
	struct FVector2D Temp_struct_Variable_46;  // 0x194(0x8)
	struct FVector2D Temp_struct_Variable_47;  // 0x19C(0x8)
	struct FVector2D Temp_struct_Variable_48;  // 0x1A4(0x8)
	struct FVector2D Temp_struct_Variable_49;  // 0x1AC(0x8)
	struct FVector2D Temp_struct_Variable_50;  // 0x1B4(0x8)
	char pad_444_1 : 7;  // 0x1BC(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x1BC(0x1)
	char pad_445[3];  // 0x1BD(0x3)
	struct FVector2D K2Node_Select_Default_2;  // 0x1C0(0x8)
	struct FVector2D K2Node_Select_Default_3;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_EqualEqual_Vector2DVector2D_ReturnValue_2 : 1;  // 0x1D0(0x1)
	char pad_465[3];  // 0x1D1(0x3)
	struct FVector2D K2Node_Select_Default_4;  // 0x1D4(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Ghost Ability Render Scale
// Size: 0xB4(Inherited: 0x0) 
struct FGhost Ability Render Scale
{
	char GhostAbility Ability;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FVector2D ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector2D Temp_struct_Variable;  // 0x1C(0x8)
	char GhostAbility Temp_byte_Variable;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FVector2D Temp_struct_Variable_2;  // 0x28(0x8)
	struct FVector2D Temp_struct_Variable_3;  // 0x30(0x8)
	struct FVector2D Temp_struct_Variable_4;  // 0x38(0x8)
	struct FVector2D Temp_struct_Variable_5;  // 0x40(0x8)
	struct FVector2D Temp_struct_Variable_6;  // 0x48(0x8)
	struct FVector2D Temp_struct_Variable_7;  // 0x50(0x8)
	struct FVector2D Temp_struct_Variable_8;  // 0x58(0x8)
	struct FVector2D Temp_struct_Variable_9;  // 0x60(0x8)
	struct FVector2D Temp_struct_Variable_10;  // 0x68(0x8)
	struct FVector2D Temp_struct_Variable_11;  // 0x70(0x8)
	struct FVector2D Temp_struct_Variable_12;  // 0x78(0x8)
	struct FVector2D Temp_struct_Variable_13;  // 0x80(0x8)
	struct FVector2D Temp_struct_Variable_14;  // 0x88(0x8)
	struct FVector2D Temp_struct_Variable_15;  // 0x90(0x8)
	struct FVector2D Temp_struct_Variable_16;  // 0x98(0x8)
	struct FVector2D K2Node_Select_Default;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_EqualEqual_Vector2DVector2D_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	struct FVector2D K2Node_Select_Default_2;  // 0xAC(0x8)

}; 
// Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AverageOfIntArray
// Size: 0x50(Inherited: 0x0) 
struct FAverageOfIntArray
{
	struct TArray<int32_t> IntArray;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	float Average;  // 0x18(0x4)
	float Sum;  // 0x1C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x24(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x2C(0x4)
	int32_t CallFunc_Array_Get_Item;  // 0x30(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x44(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x48(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x4C(0x4)

}; 
