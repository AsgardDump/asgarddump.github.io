#pragma once 
#include <BP_FirstVanSpawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FirstVanSpawn.BP_FirstVanSpawn_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_FirstVanSpawn_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UArrowComponent* Direction;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void ReceiveBeginPlay(); // Function BP_FirstVanSpawn.BP_FirstVanSpawn_C.ReceiveBeginPlay
	void OrientAtVanStoppingPoint(); // Function BP_FirstVanSpawn.BP_FirstVanSpawn_C.OrientAtVanStoppingPoint
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_FirstVanSpawn.BP_FirstVanSpawn_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_FirstVanSpawn(int32_t EntryPoint); // Function BP_FirstVanSpawn.BP_FirstVanSpawn_C.ExecuteUbergraph_BP_FirstVanSpawn
}; 



