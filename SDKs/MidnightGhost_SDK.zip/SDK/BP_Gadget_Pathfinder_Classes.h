#pragma once 
#include <BP_Gadget_Pathfinder_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C
// Size: 0x290(Inherited: 0x25C) 
struct ABP_Gadget_Pathfinder_C : public ABP_Gadget_C
{
	char pad_604[4];  // 0x25C(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	float FadeInEctoTrails_Value_3CECF5454E6896D7767A2DB2EA6AE7A3;  // 0x268(0x4)
	char ETimelineDirection FadeInEctoTrails__Direction_3CECF5454E6896D7767A2DB2EA6AE7A3;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct UTimelineComponent* FadeInEctoTrails;  // 0x270(0x8)
	struct ABP_Gadget_TP_Pathfinder_C* GadgetTP;  // 0x278(0x8)
	struct ABP_Gadget_FP_Pathfinder_C* GadgetFP;  // 0x280(0x8)
	struct USceneCaptureComponent2D* SceneCaptureComponent;  // 0x288(0x8)

	void GetTPActor(struct ABP_Gadget_TP_C*& TPActor); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.GetTPActor
	void GetFPActor(struct ABP_Gadget_FP_C*& FPActor); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.GetFPActor
	void FadeInEctoTrails__FinishedFunc(); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.FadeInEctoTrails__FinishedFunc
	void FadeInEctoTrails__UpdateFunc(); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.FadeInEctoTrails__UpdateFunc
	void Equip(); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.Equip
	void Unequip(); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.Unequip
	void ReceiveBeginPlay(); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.ReceiveBeginPlay
	void OC_Startup(); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.OC_Startup
	void ExecuteUbergraph_BP_Gadget_Pathfinder(int32_t EntryPoint); // Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.ExecuteUbergraph_BP_Gadget_Pathfinder
}; 



