#pragma once 
#include "SDK.h" 
 
 
// Function BP_GhostEmergeShatter.BP_GhostEmergeShatter_C.ExecuteUbergraph_BP_GhostEmergeShatter
// Size: 0xC(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GhostEmergeShatter
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GhostEmergeShatter.BP_GhostEmergeShatter_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
