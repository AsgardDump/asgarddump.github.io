#pragma once 
#include "SDK.h" 
 
 
// Function BP_BreakShield_v2.BP_BreakShield_v2_C.ExecuteUbergraph_BP_BreakShield_v2
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BreakShield_v2
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x10(0xC)

}; 
