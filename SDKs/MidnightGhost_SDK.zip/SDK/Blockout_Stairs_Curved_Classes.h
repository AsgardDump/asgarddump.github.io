#pragma once 
#include <Blockout_Stairs_Curved_Structs.h>
 
 
 
// BlueprintGeneratedClass Blockout_Stairs_Curved.Blockout_Stairs_Curved_C
// Size: 0x2C8(Inherited: 0x270) 
struct ABlockout_Stairs_Curved_C : public ABlockoutToolsParent
{
	int32_t NumberOfSteps;  // 0x270(0x4)
	float StairsAngle;  // 0x274(0x4)
	float StairsHeight;  // 0x278(0x4)
	float InnerRadius;  // 0x27C(0x4)
	float StepWidth;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool bRoundSize : 1;  // 0x284(0x1)
	char EBlockoutStairsType StairsType;  // 0x285(0x1)
	char pad_646[2];  // 0x286(0x2)
	float StepHeight;  // 0x288(0x4)
	float StepWidthSum;  // 0x28C(0x4)
	struct FVector2D StartSize;  // 0x290(0x8)
	struct FVector2D EndSize;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool bUseGrid : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	struct FLinearColor Color;  // 0x2A4(0x10)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool bUseTopColor : 1;  // 0x2B4(0x1)
	char pad_693[3];  // 0x2B5(0x3)
	struct FLinearColor TopColor;  // 0x2B8(0x10)

	void SetupStepSizes(); // Function Blockout_Stairs_Curved.Blockout_Stairs_Curved_C.SetupStepSizes
	void AddBlockoutStairsCurved(); // Function Blockout_Stairs_Curved.Blockout_Stairs_Curved_C.AddBlockoutStairsCurved
	void UserConstructionScript(); // Function Blockout_Stairs_Curved.Blockout_Stairs_Curved_C.UserConstructionScript
}; 



