#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget_TP_SpectralCannon.BP_Gadget_TP_SpectralCannon_C.ExecuteUbergraph_BP_Gadget_TP_SpectralCannon
// Size: 0x4C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget_TP_SpectralCannon
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_Unhide_Hide : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_Event_SkipAnimation : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool K2Node_Event_TickWhileHidden : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool K2Node_Event_NonLocallyControlledOrBot : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_Event_ShouldInterrupt : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString CallFunc_SelectString_ReturnValue;  // 0x10(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue_2;  // 0x30(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x40(0xC)

}; 
// Function BP_Gadget_TP_SpectralCannon.BP_Gadget_TP_SpectralCannon_C.GetSkeletalMesh
// Size: 0x8(Inherited: 0x8) 
struct FGetSkeletalMesh : public FGetSkeletalMesh
{
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x0(0x8)

}; 
// Function BP_Gadget_TP_SpectralCannon.BP_Gadget_TP_SpectralCannon_C.UpdateVisibility
// Size: 0x5(Inherited: 0x5) 
struct FUpdateVisibility : public FUpdateVisibility
{
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Hide : 1;  // 0x0(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool SkipAnimation : 1;  // 0x1(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool TickWhileHidden : 1;  // 0x2(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool NonLocallyControlledOrBot : 1;  // 0x3(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ShouldInterrupt : 1;  // 0x4(0x1)

}; 
// Function BP_Gadget_TP_SpectralCannon.BP_Gadget_TP_SpectralCannon_C.GetComponents
// Size: 0x20(Inherited: 0x10) 
struct FGetComponents : public FGetComponents
{
	struct TArray<struct USceneComponent*> Components;  // 0x0(0x10)
	struct TArray<struct USceneComponent*> K2Node_MakeArray_Array;  // 0x10(0x10)

}; 
