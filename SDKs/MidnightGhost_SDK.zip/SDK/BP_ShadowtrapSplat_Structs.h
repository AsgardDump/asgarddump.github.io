#pragma once 
#include "SDK.h" 
 
 
// Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.ExecuteUbergraph_BP_ShadowtrapSplat
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ShadowtrapSplat
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_Hidden_ : 1;  // 0x4(0x1)

}; 
// Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.SetHidden?
// Size: 0x1(Inherited: 0x0) 
struct FSetHidden?
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hidden? : 1;  // 0x0(0x1)

}; 
// Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.UserConstructionScript
// Size: 0x40(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x0(0x30)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x30(0x8)
	struct UDecalComponent* CallFunc_AddComponent_ReturnValue;  // 0x38(0x8)

}; 
// Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.CheckOwnerDistance?
// Size: 0x2D(Inherited: 0x0) 
struct FCheckOwnerDistance?
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool  OK : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x10(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x1C(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x2C(0x1)

}; 
