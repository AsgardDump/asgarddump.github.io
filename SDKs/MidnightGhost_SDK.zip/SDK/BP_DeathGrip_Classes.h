#pragma once 
#include <BP_DeathGrip_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DeathGrip.BP_DeathGrip_C
// Size: 0x370(Inherited: 0x220) 
struct ABP_DeathGrip_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAIPerceptionStimuliSourceComponent* AIPerceptionStimuliSource;  // 0x228(0x8)
	struct UStaticMeshComponent* SM_Chunk_4;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_Chunk_2;  // 0x238(0x8)
	struct UNiagaraComponent* NS_DeathGrip_Idle;  // 0x240(0x8)
	struct UStaticMeshComponent* Plane;  // 0x248(0x8)
	struct UStaticMeshComponent* SM_Chunk_7;  // 0x250(0x8)
	struct UStaticMeshComponent* SM_Chunk_6;  // 0x258(0x8)
	struct UStaticMeshComponent* SM_Chunk_5;  // 0x260(0x8)
	struct UStaticMeshComponent* SM_Chunk_3;  // 0x268(0x8)
	struct USkeletalMeshComponent* DeathGrip_Mesh_05;  // 0x270(0x8)
	struct USkeletalMeshComponent* DeathGrip_Mesh_04;  // 0x278(0x8)
	struct USkeletalMeshComponent* DeathGrip_Mesh_03;  // 0x280(0x8)
	struct USkeletalMeshComponent* DeathGrip_Mesh_02;  // 0x288(0x8)
	struct USkeletalMeshComponent* DeathGrip_Mesh_01;  // 0x290(0x8)
	struct USphereComponent* DamageSphere;  // 0x298(0x8)
	struct USceneComponent* TeleportHere;  // 0x2A0(0x8)
	struct UStaticMeshComponent* SM_MannequinChild_LArm_MannequinChild_LArm_002;  // 0x2A8(0x8)
	struct USceneComponent* ArmsRoot;  // 0x2B0(0x8)
	struct UStaticMeshComponent* SM_MannequinChild_LArm_MannequinChild_LArm_005;  // 0x2B8(0x8)
	struct UStaticMeshComponent* SM_MannequinChild_LArm_MannequinChild_LArm_004;  // 0x2C0(0x8)
	struct UStaticMeshComponent* SM_MannequinChild_LArm_MannequinChild_LArm_003;  // 0x2C8(0x8)
	struct UAudioComponent* GhostTrap_Place_V01;  // 0x2D0(0x8)
	struct UWidgetComponent* ShadowtrapWidget;  // 0x2D8(0x8)
	struct UPointLightComponent* PointLight;  // 0x2E0(0x8)
	struct UParticleSystemComponent* Par_WhirlCopterRibbon;  // 0x2E8(0x8)
	struct UCapsuleComponent* ActivateRadius;  // 0x2F0(0x8)
	struct UParticleSystemComponent* Par_VoltCore_01;  // 0x2F8(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x300(0x8)
	float ArmsRaise_RelativeY_D37F660143753BC65E1220B8A4E40174;  // 0x308(0x4)
	char ETimelineDirection ArmsRaise__Direction_D37F660143753BC65E1220B8A4E40174;  // 0x30C(0x1)
	char pad_781[3];  // 0x30D(0x3)
	struct UTimelineComponent* ArmsRaise;  // 0x310(0x8)
	float Lightfade_Fade_9BDE44C540F854F8F61BC6A1A2D0B8D2;  // 0x318(0x4)
	char ETimelineDirection Lightfade__Direction_9BDE44C540F854F8F61BC6A1A2D0B8D2;  // 0x31C(0x1)
	char pad_797[3];  // 0x31D(0x3)
	struct UTimelineComponent* Lightfade;  // 0x320(0x8)
	float SpawnVFXScale_Scale_1B47AD7A46C758A44504EA8C50121E0A;  // 0x328(0x4)
	char ETimelineDirection SpawnVFXScale__Direction_1B47AD7A46C758A44504EA8C50121E0A;  // 0x32C(0x1)
	char pad_813[3];  // 0x32D(0x3)
	struct UTimelineComponent* SpawnVFXScale;  // 0x330(0x8)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool Activated? : 1;  // 0x338(0x1)
	char pad_825[7];  // 0x339(0x7)
	struct ABP_Hunter_C* SnaredHunter;  // 0x340(0x8)
	float TrapHP;  // 0x348(0x4)
	char pad_844[4];  // 0x34C(0x4)
	struct AMGH_PlayerState_C* LocalPS;  // 0x350(0x8)
	struct AMGH_PlayerState_C* GhostPS;  // 0x358(0x8)
	struct ABP_ShadowtrapSplat_C* ShadowtrapSplat;  // 0x360(0x8)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool TrappedHunter? : 1;  // 0x368(0x1)
	char pad_873_1 : 7;  // 0x369(0x1)
	bool ActivatedAnim : 1;  // 0x369(0x1)
	char pad_874_1 : 7;  // 0x36A(0x1)
	bool Disabled : 1;  // 0x36A(0x1)
	char pad_875[1];  // 0x36B(0x1)
	float ExpirationTime;  // 0x36C(0x4)

	void SetArmsCollectiveMaterials(bool IsMidnight); // Function BP_DeathGrip.BP_DeathGrip_C.SetArmsCollectiveMaterials
	void SetArmsMaterials(struct UPrimitiveComponent* Mesh, bool Midnight); // Function BP_DeathGrip.BP_DeathGrip_C.SetArmsMaterials
	void Trap Owner Message(struct FText Text, bool Activated?); // Function BP_DeathGrip.BP_DeathGrip_C.Trap Owner Message
	void GetLocalPlayerstate(struct AMGH_PlayerState_C*& PlayerState); // Function BP_DeathGrip.BP_DeathGrip_C.GetLocalPlayerstate
	void SpawnVFXScale__FinishedFunc(); // Function BP_DeathGrip.BP_DeathGrip_C.SpawnVFXScale__FinishedFunc
	void SpawnVFXScale__UpdateFunc(); // Function BP_DeathGrip.BP_DeathGrip_C.SpawnVFXScale__UpdateFunc
	void Lightfade__FinishedFunc(); // Function BP_DeathGrip.BP_DeathGrip_C.Lightfade__FinishedFunc
	void Lightfade__UpdateFunc(); // Function BP_DeathGrip.BP_DeathGrip_C.Lightfade__UpdateFunc
	void ArmsRaise__FinishedFunc(); // Function BP_DeathGrip.BP_DeathGrip_C.ArmsRaise__FinishedFunc
	void ArmsRaise__UpdateFunc(); // Function BP_DeathGrip.BP_DeathGrip_C.ArmsRaise__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_DeathGrip.BP_DeathGrip_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_DeathGrip.BP_DeathGrip_C.ReceiveTick
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_DeathGrip.BP_DeathGrip_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void MiscHit(float Damage, struct AMGH_PlayerState_C* PS Responsible); // Function BP_DeathGrip.BP_DeathGrip_C.MiscHit
	void Server_TrapDestroyed(); // Function BP_DeathGrip.BP_DeathGrip_C.Server_TrapDestroyed
	void Server_HunterShadowtrapped(struct ABP_Hunter_C* BPHunter); // Function BP_DeathGrip.BP_DeathGrip_C.Server_HunterShadowtrapped
	void Server_TrapDamaged(float Damage, struct AMGH_PlayerState_C* PlayerState); // Function BP_DeathGrip.BP_DeathGrip_C.Server_TrapDamaged
	void HandleWidgetVisibility(); // Function BP_DeathGrip.BP_DeathGrip_C.HandleWidgetVisibility
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_DeathGrip.BP_DeathGrip_C.ReceiveEndPlay
	void MC_PlayHitSounds(); // Function BP_DeathGrip.BP_DeathGrip_C.MC_PlayHitSounds
	void MC_ActivateTrapVFX(); // Function BP_DeathGrip.BP_DeathGrip_C.MC_ActivateTrapVFX
	void ForceDestroyTrap(); // Function BP_DeathGrip.BP_DeathGrip_C.ForceDestroyTrap
	void TrapExpired(); // Function BP_DeathGrip.BP_DeathGrip_C.TrapExpired
	void ExecuteUbergraph_BP_DeathGrip(int32_t EntryPoint); // Function BP_DeathGrip.BP_DeathGrip_C.ExecuteUbergraph_BP_DeathGrip
}; 



