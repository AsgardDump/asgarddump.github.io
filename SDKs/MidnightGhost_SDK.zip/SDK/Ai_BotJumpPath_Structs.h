#pragma once 
#include "SDK.h" 
 
 
// Function Ai_BotJumpPath.Ai_BotJumpPath_C.ExecuteUbergraph_Ai_BotJumpPath
// Size: 0x16C(Inherited: 0x0) 
struct FExecuteUbergraph_Ai_BotJumpPath
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	struct USplineComponent* CallFunc_AddComponent_ReturnValue;  // 0x40(0x8)
	struct FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult;  // 0x48(0x88)
	float CallFunc_BreakVector_X;  // 0xD0(0x4)
	float CallFunc_BreakVector_Y;  // 0xD4(0x4)
	float CallFunc_BreakVector_Z;  // 0xD8(0x4)
	float CallFunc_BreakVector_X_2;  // 0xDC(0x4)
	float CallFunc_BreakVector_Y_2;  // 0xE0(0x4)
	float CallFunc_BreakVector_Z_2;  // 0xE4(0x4)
	float CallFunc_FMin_ReturnValue;  // 0xE8(0x4)
	float CallFunc_GetMaxJumpHeight_ReturnValue;  // 0xEC(0x4)
	float CallFunc_FMax_ReturnValue;  // 0xF0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xF4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xF8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0xFC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x100(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x104(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x108(0xC)
	struct FVector CallFunc_GetLocationAtSplinePoint_ReturnValue;  // 0x114(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x120(0xC)
	struct FVector CallFunc_GetLocationAtSplinePoint_ReturnValue_2;  // 0x12C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x138(0xC)
	struct FVector CallFunc_GetLocationAtSplinePoint_ReturnValue_3;  // 0x144(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x150(0x4)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x154(0x1)
	char pad_341[3];  // 0x155(0x3)
	float CallFunc_FMax_ReturnValue_2;  // 0x158(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x15C(0xC)
	float CallFunc_GetSplineLength_ReturnValue;  // 0x168(0x4)

}; 
