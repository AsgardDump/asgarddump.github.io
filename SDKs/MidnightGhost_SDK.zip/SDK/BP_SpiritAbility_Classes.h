#pragma once 
#include <BP_SpiritAbility_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SpiritAbility.BP_SpiritAbility_C
// Size: 0x628(Inherited: 0x4C0) 
struct ABP_SpiritAbility_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct USpotLightComponent* CamFollowLight;  // 0x4C8(0x8)
	struct USpringArmComponent* SpringArm;  // 0x4D0(0x8)
	struct UVerticalSpringArmComponent* VerticalSpringArm;  // 0x4D8(0x8)
	struct UNiagaraComponent* NS_SpiritDripping;  // 0x4E0(0x8)
	struct UPointLightComponent* Ghostlight_1;  // 0x4E8(0x8)
	struct UNiagaraComponent* Trail_Hip_02;  // 0x4F0(0x8)
	struct UNiagaraComponent* Trail_Hip_01;  // 0x4F8(0x8)
	struct USkeletalMeshComponent* Ghost_MainBody;  // 0x500(0x8)
	struct USkeletalMeshComponent* SkeletalMeshProxyNeededForAnimation;  // 0x508(0x8)
	struct UNiagaraComponent* Trail_Right Elbow;  // 0x510(0x8)
	struct UNiagaraComponent* Trail_Left Elbow;  // 0x518(0x8)
	struct USceneComponent* BodyRotation;  // 0x520(0x8)
	struct UWidgetComponent* Widget_Nameplate_Ghost;  // 0x528(0x8)
	struct USphereComponent* PingOverlap;  // 0x530(0x8)
	struct UCameraComponent* Camera;  // 0x538(0x8)
	struct AProp_C* S-RequestingProp;  // 0x540(0x8)
	struct AMGH_PlayerController_BP_C* NR_MyANPC;  // 0x548(0x8)
	float Old Prop Max Health;  // 0x550(0x4)
	float Old Prop Current Health;  // 0x554(0x4)
	char pad_1368[8];  // 0x558(0x8)
	struct FTransform Target Xform;  // 0x560(0x30)
	AProp_C* S-GhostClass;  // 0x590(0x8)
	char GhostPerks S-PropPerk;  // 0x598(0x1)
	char GhostAbility S-Prop Spec;  // 0x599(0x1)
	char pad_1434_1 : 7;  // 0x59A(0x1)
	bool S-Red? : 1;  // 0x59A(0x1)
	char pad_1435[1];  // 0x59B(0x1)
	float MotionBlurSetting;  // 0x59C(0x4)
	float FOVSetting;  // 0x5A0(0x4)
	char pad_1444_1 : 7;  // 0x5A4(0x1)
	bool MouseInvertX : 1;  // 0x5A4(0x1)
	char pad_1445_1 : 7;  // 0x5A5(0x1)
	bool MouseInvertY : 1;  // 0x5A5(0x1)
	char pad_1446[2];  // 0x5A6(0x2)
	float MouseSensitivity;  // 0x5A8(0x4)
	float Stored Radiation;  // 0x5AC(0x4)
	float Half Height Checker;  // 0x5B0(0x4)
	float Radius Checker;  // 0x5B4(0x4)
	struct FVector This Transform;  // 0x5B8(0xC)
	char pad_1476[4];  // 0x5C4(0x4)
	struct TArray<struct FVector> AssignedCoordinates;  // 0x5C8(0x10)
	struct TArray<struct FVector> AllSpaceCheckers;  // 0x5D8(0x10)
	char SmashMaterialType SmashMaterial;  // 0x5E8(0x1)
	char Ghost_SizeClass SmashSize;  // 0x5E9(0x1)
	char pad_1514[6];  // 0x5EA(0x6)
	struct UBP_MGH_Instance_C* InputGameInstance;  // 0x5F0(0x8)
	float InheritedArmor;  // 0x5F8(0x4)
	char pad_1532[4];  // 0x5FC(0x4)
	struct TArray<struct ABP_SniperDart_C*> AttachedDarts;  // 0x600(0x10)
	struct TArray<struct ABP_Hunter_C*> CachedSniperHunters;  // 0x610(0x10)
	char pad_1568_1 : 7;  // 0x620(0x1)
	bool Am I A Bot Ghost? : 1;  // 0x620(0x1)
	char pad_1569[3];  // 0x621(0x3)
	float GamepadSensitivity;  // 0x624(0x4)

	void NeedsArmor(bool& Armor); // Function BP_SpiritAbility.BP_SpiritAbility_C.NeedsArmor
	void GetArmorData(float& Armor, float& MaxArmor); // Function BP_SpiritAbility.BP_SpiritAbility_C.GetArmorData
	void GetHealthData(float& Health, float& Max Health); // Function BP_SpiritAbility.BP_SpiritAbility_C.GetHealthData
	void GetEctoBuildup(bool& Prop?, float& Radiation, bool& Sensitive?, bool& Midnight Form?); // Function BP_SpiritAbility.BP_SpiritAbility_C.GetEctoBuildup
	void OnRep_S-RequestingProp(); // Function BP_SpiritAbility.BP_SpiritAbility_C.OnRep_S-RequestingProp
	void SetMaterialParameters(struct UPrimitiveComponent* SekeletalMesh, bool Midnight); // Function BP_SpiritAbility.BP_SpiritAbility_C.SetMaterialParameters
	void SpiritSpaceChecker(bool& Space?); // Function BP_SpiritAbility.BP_SpiritAbility_C.SpiritSpaceChecker
	void SpawnSpaceCheckers(struct FVector Modifier (1x)_, float Multiplier_); // Function BP_SpiritAbility.BP_SpiritAbility_C.SpawnSpaceCheckers
	void Space Checker(struct FVector& Transform, bool& Ghost Form?); // Function BP_SpiritAbility.BP_SpiritAbility_C.Space Checker
	void Load Mouse Settings(); // Function BP_SpiritAbility.BP_SpiritAbility_C.Load Mouse Settings
	void UserConstructionScript(); // Function BP_SpiritAbility.BP_SpiritAbility_C.UserConstructionScript
	void InpAxisEvt_Spectator Move Downward_K2Node_InputAxisEvent_4(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Spectator Move Downward_K2Node_InputAxisEvent_4
	void ReceiveBeginPlay(); // Function BP_SpiritAbility.BP_SpiritAbility_C.ReceiveBeginPlay
	void Server_ReturnToGhost(struct FRotator Control Rotation); // Function BP_SpiritAbility.BP_SpiritAbility_C.Server_ReturnToGhost
	void InpAxisEvt_Spectator Move Upward_K2Node_InputAxisEvent_3(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Spectator Move Upward_K2Node_InputAxisEvent_3
	void InpAxisEvt_Move Backward_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Move Backward_K2Node_InputAxisEvent_2
	void InpAxisEvt_Move Forward_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Move Forward_K2Node_InputAxisEvent_1
	void Client_DestroyLevelprop(); // Function BP_SpiritAbility.BP_SpiritAbility_C.Client_DestroyLevelprop
	void InpAxisEvt_Move Right_K2Node_InputAxisEvent_62(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Move Right_K2Node_InputAxisEvent_62
	void InpAxisEvt_Move Left_K2Node_InputAxisEvent_81(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Move Left_K2Node_InputAxisEvent_81
	void OC_SpiritStartup(); // Function BP_SpiritAbility.BP_SpiritAbility_C.OC_SpiritStartup
	void SetMotionBlur(float MotionBlur); // Function BP_SpiritAbility.BP_SpiritAbility_C.SetMotionBlur
	void SetCameraFOV(float FOV); // Function BP_SpiritAbility.BP_SpiritAbility_C.SetCameraFOV
	void SetMouseInvertX(bool Invert?); // Function BP_SpiritAbility.BP_SpiritAbility_C.SetMouseInvertX
	void SetMouseInvertY(bool Invert?); // Function BP_SpiritAbility.BP_SpiritAbility_C.SetMouseInvertY
	void MC_SpawnShatterprop(AProp_C* Ghost Class); // Function BP_SpiritAbility.BP_SpiritAbility_C.MC_SpawnShatterprop
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_48(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_48
	void InpAxisEvt_Look_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_SpiritAbility.BP_SpiritAbility_C.InpAxisEvt_Look_K2Node_InputAxisEvent_2
	void SetUpNameplate(); // Function BP_SpiritAbility.BP_SpiritAbility_C.SetUpNameplate
	void CamHeightSet(); // Function BP_SpiritAbility.BP_SpiritAbility_C.CamHeightSet
	void ExecuteUbergraph_BP_SpiritAbility(int32_t EntryPoint); // Function BP_SpiritAbility.BP_SpiritAbility_C.ExecuteUbergraph_BP_SpiritAbility
}; 



