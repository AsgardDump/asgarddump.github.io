#pragma once 
#include "SDK.h" 
 
 
// Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.ExecuteUbergraph_BP_BoomboxInteractVan
// Size: 0x528(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BoomboxInteractVan
{
	int32_t EntryPoint;  // 0x0(0x4)
	char MGHMusicTrackAlbums CallFunc_WhichGameSoundtrackMusicFrom_Game;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText CallFunc_MusicToText_Text;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x28(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x68(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xA8(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0xB8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xC8(0x18)
	struct FText CallFunc_Format_ReturnValue_2;  // 0xE0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0xF8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x138(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_3;  // 0x178(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_4;  // 0x188(0x10)
	struct FText CallFunc_Format_ReturnValue_3;  // 0x198(0x18)
	struct FText CallFunc_Format_ReturnValue_4;  // 0x1B0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5;  // 0x1C8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_6;  // 0x208(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_7;  // 0x248(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_5;  // 0x288(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_6;  // 0x298(0x10)
	struct FText CallFunc_Format_ReturnValue_5;  // 0x2A8(0x18)
	struct FText CallFunc_Format_ReturnValue_6;  // 0x2C0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_8;  // 0x2D8(0x40)
	struct FText CallFunc_MusicAlbumToText_Text;  // 0x318(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_7;  // 0x330(0x10)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_9;  // 0x340(0x40)
	struct FText CallFunc_Format_ReturnValue_7;  // 0x380(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_8;  // 0x398(0x10)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool Temp_bool_Variable : 1;  // 0x3A8(0x1)
	char pad_937[7];  // 0x3A9(0x7)
	struct FText CallFunc_Format_ReturnValue_8;  // 0x3B0(0x18)
	int32_t Temp_int_Array_Index_Variable;  // 0x3C8(0x4)
	char pad_972[4];  // 0x3CC(0x4)
	struct FText K2Node_Select_Default;  // 0x3D0(0x18)
	struct FString CallFunc_BuildString_Int_ReturnValue;  // 0x3E8(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x3F8(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x400(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x404(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x408(0x4)
	int32_t Temp_int_Variable;  // 0x40C(0x4)
	struct FString CallFunc_BuildString_Int_ReturnValue_2;  // 0x410(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue_2;  // 0x420(0x8)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x428(0x1)
	char pad_1065_1 : 7;  // 0x429(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x429(0x1)
	char pad_1066[6];  // 0x42A(0x6)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x430(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x438(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_3;  // 0x440(0x8)
	struct TArray<float> K2Node_MakeArray_Array_9;  // 0x448(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x458(0x4)
	char pad_1116[4];  // 0x45C(0x4)
	struct TArray<float> CallFunc_GetMagnitudeForFrequencies_Magnitudes;  // 0x460(0x10)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x470(0x1)
	char pad_1137[3];  // 0x471(0x3)
	float CallFunc_Array_Get_Item;  // 0x474(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x478(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x47C(0x4)
	float CallFunc_MultiplyMultiply_FloatFloat_ReturnValue;  // 0x480(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x484(0x4)
	char pad_1160_1 : 7;  // 0x488(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x488(0x1)
	char pad_1161[3];  // 0x489(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x48C(0x4)
	struct AActor* K2Node_Event_ActivatingActor;  // 0x490(0x8)
	struct TScriptInterface<IMGHPlayerController_Interface_C> K2Node_DynamicCast_AsMGHPlayer_Controller_Interface;  // 0x498(0x10)
	char pad_1192_1 : 7;  // 0x4A8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x4A8(0x1)
	char pad_1193[7];  // 0x4A9(0x7)
	struct TScriptInterface<IVanInterface_C> K2Node_DynamicCast_AsVan_Interface;  // 0x4B0(0x10)
	char pad_1216_1 : 7;  // 0x4C0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x4C0(0x1)
	char pad_1217_1 : 7;  // 0x4C1(0x1)
	bool CallFunc_GetVanMusicStatus_Int_IsSongPlaying : 1;  // 0x4C1(0x1)
	char MGHMusicTracks CallFunc_GetVanMusicStatus_Int_SongPlaying;  // 0x4C2(0x1)
	char pad_1219[5];  // 0x4C3(0x5)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x4C8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4D0(0x10)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x4E0(0x10)
	char pad_1264_1 : 7;  // 0x4F0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x4F0(0x1)
	char pad_1265[7];  // 0x4F1(0x7)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x4F8(0x8)
	struct UTexture2D* CallFunc_GetMusicAlbumArt_Int_Art;  // 0x500(0x8)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x508(0x4)
	char pad_1292[4];  // 0x50C(0x4)
	struct FText K2Node_Select_Default_2;  // 0x510(0x18)

}; 
// Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.Interact_LocalClient_Implementation
// Size: 0x8(Inherited: 0x8) 
struct FInteract_LocalClient_Implementation : public FInteract_LocalClient_Implementation
{
	struct AActor* ActivatingActor;  // 0x0(0x8)

}; 
// Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.getInteractData
// Size: 0x90(Inherited: 0x58) 
struct FgetInteractData : public FgetInteractData
{
	struct FText interactionTextHUD;  // 0x0(0x18)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool UseImageTextPrompt : 1;  // 0x18(0x1)
	struct UTexture2D* ImageTextIcon;  // 0x20(0x8)
	struct FText ImageText1;  // 0x28(0x18)
	struct FText ImageText2;  // 0x40(0x18)
	struct FText CallFunc_MusicToText_Text;  // 0x58(0x18)
	char MGHMusicTrackAlbums CallFunc_WhichGameSoundtrackMusicFrom_Game;  // 0x70(0x1)
	struct FText CallFunc_MusicAlbumToText_Text;  // 0x78(0x18)

}; 
// Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.CanIInteract_Int
// Size: 0x20(Inherited: 0x20) 
struct FCanIInteract_Int : public FCanIInteract_Int
{
	char pad_32_1 : 7;  // 0x20(0x1)
	bool BlockInteract : 1;  // 0x0(0x1)
	struct FText ErrorMessage;  // 0x8(0x18)

}; 
// Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.CanIPickUp_Int
// Size: 0x9(Inherited: 0x1A) 
struct FCanIPickUp_Int : public FCanIPickUp_Int
{
	struct AActor* RequestingActor;  // 0x0(0x8)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool OK : 1;  // 0x8(0x1)

}; 
