#pragma once 
#include "SDK.h" 
 
 
// Function BlockoutToolsPlugin.BlockoutToolsParent.BlockoutSetMaterial
// Size: 0x28(Inherited: 0x0) 
struct FBlockoutSetMaterial
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseGrid : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FLinearColor Color;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bUseTopColor : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FLinearColor TopColor;  // 0x18(0x10)

}; 
