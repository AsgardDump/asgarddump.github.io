#pragma once 
#include "SDK.h" 
 
 
// Function BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C.ExecuteUbergraph_BP_ShadowtrapDestroyed
// Size: 0x39(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ShadowtrapDestroyed
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue;  // 0x4(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	struct UStaticMeshComponent* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2C(0xC)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C.UserConstructionScript
// Size: 0xAC(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x8(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x10(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x14(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_5;  // 0x18(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_6;  // 0x1C(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_7;  // 0x20(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x30(0xC)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x3C(0x4)
	int32_t Temp_int_Variable;  // 0x40(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x44(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_8;  // 0x48(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_9;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x54(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x60(0xC)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x6C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x70(0x30)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0xA0(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xA8(0x4)

}; 
