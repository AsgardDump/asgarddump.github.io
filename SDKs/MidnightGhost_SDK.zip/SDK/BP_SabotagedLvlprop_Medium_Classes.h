#pragma once 
#include <BP_SabotagedLvlprop_Medium_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SabotagedLvlprop_Medium.BP_SabotagedLvlprop_Medium_C
// Size: 0x291(Inherited: 0x291) 
struct ABP_SabotagedLvlprop_Medium_C : public ABP_SabotagedLvlprop_C
{

}; 



