#pragma once 
#include <BP_CamCorderActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CamCorderActor.BP_CamCorderActor_C
// Size: 0x300(Inherited: 0x220) 
struct ABP_CamCorderActor_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USpotLightComponent* SpotLight;  // 0x228(0x8)
	struct USceneComponent* LensLocation;  // 0x230(0x8)
	struct UStaticMeshComponent* Shape_NarrowCapsule1;  // 0x238(0x8)
	struct UStaticMeshComponent* Sphere;  // 0x240(0x8)
	struct UWidgetComponent* GadgetIndicator;  // 0x248(0x8)
	struct UBoxComponent* HitBox;  // 0x250(0x8)
	struct USceneComponent* TraceStart;  // 0x258(0x8)
	struct UStaticMeshComponent* Cone;  // 0x260(0x8)
	struct UChildActorComponent* ChildActor;  // 0x268(0x8)
	struct UBoxComponent* Box1;  // 0x270(0x8)
	struct USkeletalMeshComponent* trap_mesh;  // 0x278(0x8)
	float Timeline_0_Opacity_59731BEA486389CD1E4F17ABAF0B34A2;  // 0x280(0x4)
	char ETimelineDirection Timeline_0__Direction_59731BEA486389CD1E4F17ABAF0B34A2;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x288(0x8)
	float RedLightFlash_Brightness_32971AFD491948CAF390398B7A842031;  // 0x290(0x4)
	char ETimelineDirection RedLightFlash__Direction_32971AFD491948CAF390398B7A842031;  // 0x294(0x1)
	char pad_661[3];  // 0x295(0x3)
	struct UTimelineComponent* RedLightFlash;  // 0x298(0x8)
	float TimelineVFX_Opacity_B9669C1B4AFDE6464C5701A30614D9B6;  // 0x2A0(0x4)
	char ETimelineDirection TimelineVFX__Direction_B9669C1B4AFDE6464C5701A30614D9B6;  // 0x2A4(0x1)
	char pad_677[3];  // 0x2A5(0x3)
	struct UTimelineComponent* TimelineVFX;  // 0x2A8(0x8)
	float RightSelf_Lerp_FD997E0A4C949F25C19F25BC6E135E0E;  // 0x2B0(0x4)
	char ETimelineDirection RightSelf__Direction_FD997E0A4C949F25C19F25BC6E135E0E;  // 0x2B4(0x1)
	char pad_693[3];  // 0x2B5(0x3)
	struct UTimelineComponent* RightSelf;  // 0x2B8(0x8)
	struct UProjectileMovementComponent* Projectile;  // 0x2C0(0x8)
	struct ACharacter* OwnerHunter;  // 0x2C8(0x8)
	struct FRotator StartRot;  // 0x2D0(0xC)
	float Health;  // 0x2DC(0x4)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool Activated : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)
	struct UMaterialInstanceDynamic* VFXMTL;  // 0x2E8(0x8)
	struct UAudioComponent* IdleSound;  // 0x2F0(0x8)
	struct APlayerState* Owning Hunter Player State;  // 0x2F8(0x8)

	void GetOwnerInfo_Int(struct AActor*& Owner); // Function BP_CamCorderActor.BP_CamCorderActor_C.GetOwnerInfo_Int
	void RightSelf__FinishedFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.RightSelf__FinishedFunc
	void RightSelf__UpdateFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.RightSelf__UpdateFunc
	void TimelineVFX__FinishedFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.TimelineVFX__FinishedFunc
	void TimelineVFX__UpdateFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.TimelineVFX__UpdateFunc
	void RedLightFlash__FinishedFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.RedLightFlash__FinishedFunc
	void RedLightFlash__UpdateFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.RedLightFlash__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_CamCorderActor.BP_CamCorderActor_C.Timeline_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_CamCorderActor.BP_CamCorderActor_C.ReceiveBeginPlay
	void PickedUp_Int(); // Function BP_CamCorderActor.BP_CamCorderActor_C.PickedUp_Int
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_CamCorderActor.BP_CamCorderActor_C.ReceiveHit
	void ActivateCamCorderLogic(); // Function BP_CamCorderActor.BP_CamCorderActor_C.ActivateCamCorderLogic
	void CheckForGhosts(); // Function BP_CamCorderActor.BP_CamCorderActor_C.CheckForGhosts
	void DamageByGhost(float Damage, struct AActor* ResponsibleActor); // Function BP_CamCorderActor.BP_CamCorderActor_C.DamageByGhost
	void ServerDamageByGhost(float Damage, struct AActor* ResponsibleActor); // Function BP_CamCorderActor.BP_CamCorderActor_C.ServerDamageByGhost
	void Server_DestroyCamCorder(); // Function BP_CamCorderActor.BP_CamCorderActor_C.Server_DestroyCamCorder
	void SetOutlineVisibility_Int(bool Visible); // Function BP_CamCorderActor.BP_CamCorderActor_C.SetOutlineVisibility_Int
	void SetOwnerInfo_Int(struct AActor* Actor); // Function BP_CamCorderActor.BP_CamCorderActor_C.SetOwnerInfo_Int
	void HandleTrapIndicatorVisibility(); // Function BP_CamCorderActor.BP_CamCorderActor_C.HandleTrapIndicatorVisibility
	void SetGadgetActivated_Int(); // Function BP_CamCorderActor.BP_CamCorderActor_C.SetGadgetActivated_Int
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_CamCorderActor.BP_CamCorderActor_C.ReceiveEndPlay
	void SetCameraCollide_Int(bool Collide); // Function BP_CamCorderActor.BP_CamCorderActor_C.SetCameraCollide_Int
	void ActivateCamCorderVFX(); // Function BP_CamCorderActor.BP_CamCorderActor_C.ActivateCamCorderVFX
	void GhostDetected_Int(); // Function BP_CamCorderActor.BP_CamCorderActor_C.GhostDetected_Int
	void ExecuteUbergraph_BP_CamCorderActor(int32_t EntryPoint); // Function BP_CamCorderActor.BP_CamCorderActor_C.ExecuteUbergraph_BP_CamCorderActor
}; 



