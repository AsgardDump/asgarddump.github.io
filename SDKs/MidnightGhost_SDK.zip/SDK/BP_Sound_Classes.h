#pragma once 
#include <BP_Sound_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Sound.BP_Sound_C
// Size: 0x263(Inherited: 0x220) 
struct ABP_Sound_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Audio;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct USoundBase* Sound;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool OverrideVolume? : 1;  // 0x240(0x1)
	char pad_577[3];  // 0x241(0x3)
	float OverrideVolume;  // 0x244(0x4)
	struct USoundAttenuation* Attenuation;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool RandomizePitch? : 1;  // 0x250(0x1)
	char pad_593[3];  // 0x251(0x3)
	float DelayBeforeExplode;  // 0x254(0x4)
	struct UAudioComponent* MySpawnedSound;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool Mute Init'd : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool REPLICATE? : 1;  // 0x261(0x1)
	char pad_610_1 : 7;  // 0x262(0x1)
	bool Bigger Attenuation? : 1;  // 0x262(0x1)

	void OnRep_REPLICATE?(); // Function BP_Sound.BP_Sound_C.OnRep_REPLICATE?
	void ReceiveBeginPlay(); // Function BP_Sound.BP_Sound_C.ReceiveBeginPlay
	void Server_Mute(); // Function BP_Sound.BP_Sound_C.Server_Mute
	void MC_Mute(); // Function BP_Sound.BP_Sound_C.MC_Mute
	void Server_AttachToActor(struct AActor* ParentActor, struct ABP_Sound_C* BP Sound); // Function BP_Sound.BP_Sound_C.Server_AttachToActor
	void MC_AttachToActor(struct AActor* ParentActor, struct ABP_Sound_C* BP Sound); // Function BP_Sound.BP_Sound_C.MC_AttachToActor
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Sound.BP_Sound_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_Sound(int32_t EntryPoint); // Function BP_Sound.BP_Sound_C.ExecuteUbergraph_BP_Sound
}; 



