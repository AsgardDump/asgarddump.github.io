#pragma once 
#include <BP_GhostEmergeShatterRed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GhostEmergeShatterRed.BP_GhostEmergeShatterRed_C
// Size: 0x281(Inherited: 0x281) 
struct ABP_GhostEmergeShatterRed_C : public ABP_GhostEmergeShatter_C
{

}; 



