#pragma once 
#include "SDK.h" 
 
 
// Function BP_MansionSconce.BP_MansionSconce_C.ExecuteUbergraph_BP_MansionSconce
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MansionSconce
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue;  // 0x4(0x10)
	float K2Node_Event_FlutterIntensity;  // 0x14(0x4)
	float K2Node_Event_PercentDone;  // 0x18(0x4)
	float K2Node_Event_RedIntensityDivider;  // 0x1C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x20(0x8)

}; 
// Function BP_MansionSconce.BP_MansionSconce_C.GoMidnight
// Size: 0x4(Inherited: 0x0) 
struct FGoMidnight
{
	float RedIntensityDivider;  // 0x0(0x4)

}; 
// Function BP_MansionSconce.BP_MansionSconce_C.FadeBackRed
// Size: 0x4(Inherited: 0x0) 
struct FFadeBackRed
{
	float PercentDone;  // 0x0(0x4)

}; 
// Function BP_MansionSconce.BP_MansionSconce_C.PreMidnightFlutter
// Size: 0x4(Inherited: 0x0) 
struct FPreMidnightFlutter
{
	float FlutterIntensity;  // 0x0(0x4)

}; 
