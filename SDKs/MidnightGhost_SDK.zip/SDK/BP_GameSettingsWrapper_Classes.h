#pragma once 
#include <BP_GameSettingsWrapper_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GameSettingsWrapper.BP_GameSettingsWrapper_C
// Size: 0x38(Inherited: 0x28) 
struct UBP_GameSettingsWrapper_C : public UObject
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28(0x8)
	struct UBP_GameSettings_C* Game Settings;  // 0x30(0x8)

	void ExecuteUbergraph_BP_GameSettingsWrapper(int32_t EntryPoint); // Function BP_GameSettingsWrapper.BP_GameSettingsWrapper_C.ExecuteUbergraph_BP_GameSettingsWrapper
}; 



