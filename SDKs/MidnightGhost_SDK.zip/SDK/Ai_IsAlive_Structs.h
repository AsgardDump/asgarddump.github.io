#pragma once 
#include "SDK.h" 
 
 
// Function Ai_IsAlive.Ai_IsAlive_C.PerformConditionCheckAI
// Size: 0x43(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct ABP_SpiritAbility_C* K2Node_DynamicCast_AsBP_Spirit_Ability;  // 0x18(0x8)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x28(0x8)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x38(0x8)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x40(0x1)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x41(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x42(0x1)

}; 
