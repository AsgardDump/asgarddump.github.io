#pragma once 
#include <BP_ProgressionSystem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ProgressionSystem.BP_ProgressionSystem_C
// Size: 0x332(Inherited: 0x28) 
struct UBP_ProgressionSystem_C : public UMGH_ProgressionSystem
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28(0x8)
	struct TMap<char HunterSkins, int32_t> HunterSkinCost;  // 0x30(0x50)
	struct TMap<char HunterGadgets, int32_t> HunterWeaponUnlockData;  // 0x80(0x50)
	struct TMap<char HunterGadgets, int32_t> HunterGadgetUnlockData;  // 0xD0(0x50)
	struct TMap<char HunterPerks, int32_t> HunterPerkUnlockData;  // 0x120(0x50)
	struct TMap<char GhostAbility, int32_t> GhostAbilityUnlockData;  // 0x170(0x50)
	struct TMap<char GhostHaunts, int32_t> GhostHauntUnlockData;  // 0x1C0(0x50)
	struct TMap<char GhostPerks, int32_t> GhostPerkUnlockData;  // 0x210(0x50)
	struct TMap<char HunterSkins, struct FName> HunterSkinEnumToNameMap;  // 0x260(0x50)
	int32_t HighestLevelOfUnlocks;  // 0x2B0(0x4)
	int32_t PreviousGhostShardCount;  // 0x2B4(0x4)
	struct UMGH_V2_GearUnlocked_C* MGHGearUnlocked;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool UseV2GearUnlocks? : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)
	struct UGameInstance* Game Instance;  // 0x2C8(0x8)
	struct TArray<char MGHMusicTracks> AllAvailableMusicTracks;  // 0x2D0(0x10)
	struct TMap<char MGHMusicTrackAlbums, struct UTexture2D*> MusicAlbumArt;  // 0x2E0(0x50)
	char EHatTypes CachedEquippedHat;  // 0x330(0x1)
	char pad_817_1 : 7;  // 0x331(0x1)
	bool EquippedHatCached : 1;  // 0x331(0x1)

	void GetHatEquipped(char EHatTypes& Hat); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.GetHatEquipped
	void SetHatEquipped(char EHatTypes Hat); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SetHatEquipped
	void UnlockAchievementCheck(char LoadoutTypes Loadout Type, char HunterGadgets If WEAPON, char HunterGadgets IF GADGET, char HunterPerks IF HUNTER PERK, char GhostAbility IF ABILITY, char GhostHaunts IF HAUNT, char GhostPerks If GHOST PERK); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.UnlockAchievementCheck
	void V2_IsGearUnlocked?(char LoadoutTypes Loadout Type, char HunterGadgets If WEAPON, char HunterGadgets IF GADGET, char HunterPerks IF HUNTER PERK, char GhostAbility IF ABILITY, char GhostHaunts IF HAUNT, char GhostPerks If GHOST PERK, struct UGameInstance* GameInstance, bool& Unlocked, int32_t& Cost); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.V2_IsGearUnlocked?
	void V2_GetUnlockCost(char LoadoutTypes Loadout Type, char HunterGadgets If WEAPON, char HunterGadgets IF GADGET, char HunterPerks IF HUNTER PERK, char GhostAbility IF ABILITY, char GhostHaunts IF HAUNT, char GhostPerks If GHOST PERK, struct UGameInstance* GameInstance, int32_t& Cost); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.V2_GetUnlockCost
	void V2_UnlockThisGear(char LoadoutTypes Loadout Type, char HunterGadgets If WEAPON, char HunterGadgets IF GADGET, char HunterPerks IF HUNTER PERK, char GhostAbility IF ABILITY, char GhostHaunts IF HAUNT, char GhostPerks If GHOST PERK, struct UGameInstance* GameInstance); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.V2_UnlockThisGear
	void V2_PurchaseUnlockGear(char LoadoutTypes Loadout Type, char HunterGadgets If WEAPON, char HunterGadgets IF GADGET, char HunterPerks IF HUNTER PERK, char GhostAbility IF ABILITY, char GhostHaunts IF HAUNT, char GhostPerks If GHOST PERK, struct UGameInstance* GameInstance); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.V2_PurchaseUnlockGear
	void AreThereProgressionUnlocks?(int32_t PlayerLevel, bool& Unlocks?); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AreThereProgressionUnlocks?
	void CanIAffordThisCosmetic(int32_t Cost, struct UGameInstance* GameInstance, bool& Can Afford); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.CanIAffordThisCosmetic
	void Subtract GhostShards(struct UGameInstance* GameInstance, int32_t Subtracted Shards); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.Subtract GhostShards
	void FindUnlocksAtLevel(int32_t Level, struct TArray<char HunterGadgets>& WeapUnlocks, struct TArray<char HunterGadgets>& GadgetUnlocks, struct TArray<char HunterPerks>& HPerkUnlocks, struct TArray<char GhostAbility>& AbilUnlocks, struct TArray<char GhostHaunts>& HauntUnlocks, struct TArray<char GhostPerks>& GPerkUnlocks); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.FindUnlocksAtLevel
	void AddGhostShards(struct UGameInstance* GameInstance, int32_t Added Shards); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddGhostShards
	void SortHunterEquipment(struct TArray<struct FHunterLoadoutDataStroc>& UnsortedHunterEquipment, struct TArray<struct FHunterLoadoutDataStroc>& SortedHunterEquipment1); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SortHunterEquipment
	void SortGhostAbility(struct TArray<struct FGhostSpecDataStruct>& UnsortedGhostSpecs, struct TArray<struct FGhostSpecDataStruct>& SortedGhostSpecs1); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SortGhostAbility
	void SortHunterWeapons(struct TArray<struct FHunterLoadoutDataStroc>& UnsortedHunterWeapons, struct TArray<struct FHunterLoadoutDataStroc>& SortedHunterWeapons1); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SortHunterWeapons
	void SortGhostPerks(struct TArray<struct FGhostPerkDataStruc>& UnsortedGhostPerks, struct TArray<struct FGhostPerkDataStruc>& SortedGhostPerks1); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SortGhostPerks
	void SortGhostHaunts(struct TArray<struct FGhostHauntData_Struc>& UnsortedGhostHaunts, struct TArray<struct FGhostHauntData_Struc>& SortedGhostHaunts1); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SortGhostHaunts
	void SortHunterPerks(struct TArray<struct FHunterLoadoutDataStroc>& UnsortedHunterPerks, struct TArray<struct FHunterLoadoutDataStroc>& SortedHunterPerks1); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SortHunterPerks
	void AddLevelUnlocks(int32_t Level, struct TArray<char HunterGadgets>& Hunter Weapons, struct TArray<char HunterGadgets>& Hunter Gadgets, struct TArray<char HunterPerks>& Hunter Perks, struct TArray<char GhostAbility>& Ghost Abilities, struct TArray<char GhostHaunts>& Ghost Haunts, struct TArray<char GhostPerks>& Ghost Perks); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddLevelUnlocks
	void Get Hunter Skin Cost(char HunterSkins Hunter Skin, int32_t& Cost); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.Get Hunter Skin Cost
	void SortLoadoutBasedOnUnlock(struct TArray<struct FHunterLoadoutDataStroc>& HunterEquipment, struct TArray<struct FHunterLoadoutDataStroc>& HunterPerks, struct TArray<struct FHunterLoadoutDataStroc>& HunterWeaponsOnly, struct TArray<struct FGhostSpecDataStruct>& Ghost Specs, struct TArray<struct FGhostPerkDataStruc>& Ghost Perks, struct TArray<struct FGhostHauntData_Struc>& Ghost Haunts, struct TArray<struct FHunterLoadoutDataStroc>& HunterEquipmentSorted, struct TArray<struct FHunterLoadoutDataStroc>& HunterPerksSorted, struct TArray<struct FHunterLoadoutDataStroc>& HunterWeaponsOnlySorted, struct TArray<struct FGhostSpecDataStruct>& Ghost SpecsSorted, struct TArray<struct FGhostPerkDataStruc>& Ghost PerksSorted, struct TArray<struct FGhostHauntData_Struc>& Ghost HauntsSorted); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SortLoadoutBasedOnUnlock
	void GetCurrentGhostShards(struct UGameInstance* GameInstance, bool RequestFromServer, int32_t& Ghost Shards); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.GetCurrentGhostShards
	void IsGhostPerkUnlocked?(int32_t Level, char GhostPerks Ghost Perk, struct UGameInstance* GameInstance, bool CheckIfBanned, struct AGameStateBase* GameState, bool& Unlocked, int32_t& Required Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.IsGhostPerkUnlocked?
	void IsHauntUnlocked?(int32_t Level, char GhostHaunts Haunt, struct UGameInstance* GameInstance, bool Check If Banned, struct AGameStateBase* GameState, bool& Unlocked, int32_t& Required Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.IsHauntUnlocked?
	void IsAbilityUnlocked?(int32_t Level, char GhostAbility Ability, struct UGameInstance* GameInstance, bool CheckIfBanned, struct AGameStateBase* GameState, bool& Unlocked, int32_t& Required Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.IsAbilityUnlocked?
	void IsHunterPerkUnlocked?(int32_t Level, char HunterPerks Hunter Perk, struct UGameInstance* GameInstance, bool CheckIfBanned, struct AGameStateBase* GameState, bool& Unlocked, int32_t& Required Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.IsHunterPerkUnlocked?
	void IsGadgetUnlocked?(int32_t Level, char HunterGadgets Gadget, struct UGameInstance* GameInstance, bool Check If Banned, struct AGameStateBase* GameState, bool& Unlocked, int32_t& Required Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.IsGadgetUnlocked?
	void IsWeaponUnlocked?(int32_t Level, char HunterGadgets Weapon, struct UGameInstance* GameInstance, bool Check If Banned, struct AGameStateBase* For Check GameState, bool& Unlocked, int32_t& Required Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.IsWeaponUnlocked?
	void GetCurrentLevel(struct UGameInstance* GameInstance, int32_t& Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.GetCurrentLevel
	void GetLevelUpUnlocks(int32_t Level, struct TArray<struct FProgressionUnlockData>& Unlocks); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.GetLevelUpUnlocks
	void IsLoadoutOptionUnlocked?(int32_t CurrentLevel, char LoadoutTypes Loadout Type, char HunterGadgets If WEAPON, char HunterGadgets IF GADGET, char HunterPerks IF HUNTER PERK, char GhostAbility IF ABILITY, char GhostHaunts IF HAUNT, char GhostPerks If GHOST PERK, struct UGameInstance* GameInstance, bool& Unlocked, int32_t& Required Level); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.IsLoadoutOptionUnlocked?
	void AddGhostPerkUnlock(int32_t Level Unlock, char GhostPerks Perk); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddGhostPerkUnlock
	void AddGhostHauntUnlock(int32_t Level Unlock, char GhostHaunts Haunt); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddGhostHauntUnlock
	void AddGhostAbilityUnlock(int32_t Level Unlock, char GhostAbility Ability); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddGhostAbilityUnlock
	void AddHunterPerkUnlock(int32_t Level Unlock, char HunterPerks Perk); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddHunterPerkUnlock
	void AddHunterGadgetUnlock(int32_t Level Unlock, char HunterGadgets Gadget); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddHunterGadgetUnlock
	void AddHunterWeaponUnlock(int32_t Level Unlock, char HunterGadgets Weapon); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.AddHunterWeaponUnlock
	void PopulateProgressionRequirements(); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.PopulateProgressionRequirements
	void SetGameInstanceRef(struct UGameInstance* GameInstance); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.SetGameInstanceRef
	void ExecuteUbergraph_BP_ProgressionSystem(int32_t EntryPoint); // Function BP_ProgressionSystem.BP_ProgressionSystem_C.ExecuteUbergraph_BP_ProgressionSystem
}; 



