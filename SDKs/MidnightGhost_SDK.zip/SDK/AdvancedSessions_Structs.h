#pragma once 
#include "SDK.h" 
 
 
// Function AdvancedSessions.AdvancedSessionsLibrary.BanPlayer
// Size: 0x30(Inherited: 0x0) 
struct FBanPlayer
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerToBan;  // 0x8(0x8)
	struct FText BanReason;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function AdvancedSessions.AdvancedFriendsLibrary.GetStoredRecentPlayersList
// Size: 0x30(Inherited: 0x0) 
struct FGetStoredRecentPlayersList
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	struct TArray<struct FBPOnlineRecentPlayer> PlayersList;  // 0x20(0x10)

}; 
// ScriptStruct AdvancedSessions.BPFriendInfo
// Size: 0x68(Inherited: 0x0) 
struct FBPFriendInfo
{
	struct FString DisplayName;  // 0x0(0x10)
	struct FString RealName;  // 0x10(0x10)
	uint8_t  OnlineState;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FBPUniqueNetId UniqueNetId;  // 0x28(0x20)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bIsPlayingSameGame : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FBPFriendPresenceInfo PresenceInfo;  // 0x50(0x18)

}; 
// Function AdvancedSessions.AdvancedExternalUILibrary.ShowAccountUpgradeUI
// Size: 0x28(Inherited: 0x0) 
struct FShowAccountUpgradeUI
{
	struct FBPUniqueNetId PlayerRequestingAccountUpgradeUI;  // 0x0(0x20)
	uint8_t  Result;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// DelegateFunction AdvancedSessions.BlueprintGetFriendsListDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintGetFriendsListDelegate__DelegateSignature
{
	struct TArray<struct FBPFriendInfo> Results;  // 0x0(0x10)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.RegisterRemoteTalker
// Size: 0x28(Inherited: 0x0) 
struct FRegisterRemoteTalker
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// DelegateFunction AdvancedSessions.BlueprintFindFriendSessionDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintFindFriendSessionDelegate__DelegateSignature
{
	struct TArray<struct FBlueprintSessionResult> SessionInfo;  // 0x0(0x10)

}; 
// ScriptStruct AdvancedSessions.BPUniqueNetId
// Size: 0x20(Inherited: 0x0) 
struct FBPUniqueNetId
{
	char pad_0[32];  // 0x0(0x20)

}; 
// DelegateFunction AdvancedSessions.BlueprintGetUserPrivilegeDelegate__DelegateSignature
// Size: 0x2(Inherited: 0x0) 
struct FBlueprintGetUserPrivilegeDelegate__DelegateSignature
{
	uint8_t  QueriedPrivilege;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool HadPrivilege : 1;  // 0x1(0x1)

}; 
// ScriptStruct AdvancedSessions.BPUserOnlineAccount
// Size: 0x10(Inherited: 0x0) 
struct FBPUserOnlineAccount
{
	char pad_0[16];  // 0x0(0x10)

}; 
// Function AdvancedSessions.FindFriendSessionCallbackProxy.FindFriendSession
// Size: 0x38(Inherited: 0x0) 
struct FFindFriendSession
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct FBPUniqueNetId FriendUniqueNetId;  // 0x10(0x20)
	struct UFindFriendSessionCallbackProxy* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct AdvancedSessions.BPFriendPresenceInfo
// Size: 0x18(Inherited: 0x0) 
struct FBPFriendPresenceInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsOnline : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bIsPlaying : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bIsPlayingThisGame : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bIsJoinable : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bHasVoiceSupport : 1;  // 0x4(0x1)
	uint8_t  PresenceState;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FString StatusString;  // 0x8(0x10)

}; 
// DelegateFunction AdvancedSessions.BlueprintGetRecentPlayersDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintGetRecentPlayersDelegate__DelegateSignature
{
	struct TArray<struct FBPOnlineRecentPlayer> Results;  // 0x0(0x10)

}; 
// ScriptStruct AdvancedSessions.BPOnlineRecentPlayer
// Size: 0x50(Inherited: 0x40) 
struct FBPOnlineRecentPlayer : public FBPOnlineUser
{
	struct FString LastSeen;  // 0x40(0x10)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyKey
// Size: 0x28(Inherited: 0x0) 
struct FGetSessionPropertyKey
{
	struct FSessionPropertyKeyPair SessionProperty;  // 0x0(0x20)
	struct FName ReturnValue;  // 0x20(0x8)

}; 
// ScriptStruct AdvancedSessions.BPOnlineUser
// Size: 0x40(Inherited: 0x0) 
struct FBPOnlineUser
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	struct FString DisplayName;  // 0x20(0x10)
	struct FString RealName;  // 0x30(0x10)

}; 
// Function AdvancedSessions.AdvancedFriendsLibrary.IsAFriend
// Size: 0x30(Inherited: 0x0) 
struct FIsAFriend
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FBPUniqueNetId UniqueNetId;  // 0x8(0x20)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool IsFriend : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct AdvancedSessions.SessionsSearchSetting
// Size: 0x28(Inherited: 0x0) 
struct FSessionsSearchSetting
{
	char pad_0[40];  // 0x0(0x28)

}; 
// ScriptStruct AdvancedSessions.SessionPropertyKeyPair
// Size: 0x20(Inherited: 0x0) 
struct FSessionPropertyKeyPair
{
	char pad_0[32];  // 0x0(0x20)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.FindSessionPropertyIndexByName
// Size: 0x20(Inherited: 0x0) 
struct FFindSessionPropertyIndexByName
{
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x0(0x10)
	struct FName SettingName;  // 0x10(0x8)
	uint8_t  Result;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t OutIndex;  // 0x1C(0x4)

}; 
// Function AdvancedSessions.AdvancedFriendsLibrary.GetFriend
// Size: 0x90(Inherited: 0x0) 
struct FGetFriend
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FBPUniqueNetId FriendUniqueNetId;  // 0x8(0x20)
	struct FBPFriendInfo Friend;  // 0x28(0x68)

}; 
// Function AdvancedSessions.AdvancedExternalUILibrary.ShowFriendsUI
// Size: 0x10(Inherited: 0x0) 
struct FShowFriendsUI
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccount
// Size: 0x38(Inherited: 0x0) 
struct FGetUserAccount
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	struct FBPUserOnlineAccount AccountInfo;  // 0x20(0x10)
	uint8_t  Result;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AdvancedSessions.AdvancedExternalUILibrary.ShowInviteUI
// Size: 0x10(Inherited: 0x0) 
struct FShowInviteUI
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AdvancedSessions.FindSessionsCallbackProxyAdvanced.FindSessionsAdvanced
// Size: 0x38(Inherited: 0x0) 
struct FFindSessionsAdvanced
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	int32_t MaxResults;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bUseLAN : 1;  // 0x14(0x1)
	uint8_t  ServerTypeToSearch;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct TArray<struct FSessionsSearchSetting> Filters;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEmptyServersOnly : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bNonEmptyServersOnly : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bSecureServersOnly : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bSearchLobbies : 1;  // 0x2B(0x1)
	int32_t MinSlotsAvailable;  // 0x2C(0x4)
	struct UFindSessionsCallbackProxyAdvanced* ReturnValue;  // 0x30(0x8)

}; 
// Function AdvancedSessions.AdvancedExternalUILibrary.ShowLeaderBoardUI
// Size: 0x18(Inherited: 0x0) 
struct FShowLeaderBoardUI
{
	struct FString LeaderboardName;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AdvancedSessions.AdvancedExternalUILibrary.ShowProfileUI
// Size: 0x48(Inherited: 0x0) 
struct FShowProfileUI
{
	struct FBPUniqueNetId PlayerViewingProfile;  // 0x0(0x20)
	struct FBPUniqueNetId PlayerToViewProfileOf;  // 0x20(0x20)
	uint8_t  Result;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetCurrentSessionID_AsString
// Size: 0x18(Inherited: 0x0) 
struct FGetCurrentSessionID_AsString
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString SessionId;  // 0x8(0x10)

}; 
// Function AdvancedSessions.AdvancedFriendsLibrary.GetStoredFriendsList
// Size: 0x18(Inherited: 0x0) 
struct FGetStoredFriendsList
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct TArray<struct FBPFriendInfo> FriendsList;  // 0x8(0x10)

}; 
// Function AdvancedSessions.AdvancedExternalUILibrary.ShowWebURLUI
// Size: 0x40(Inherited: 0x0) 
struct FShowWebURLUI
{
	struct FString URLToShow;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FString> AllowedDomains;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEmbedded : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bShowBackground : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bShowCloseButton : 1;  // 0x2A(0x1)
	char pad_43[1];  // 0x2B(0x1)
	int32_t OffsetX;  // 0x2C(0x4)
	int32_t OffsetY;  // 0x30(0x4)
	int32_t SizeX;  // 0x34(0x4)
	int32_t SizeY;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function AdvancedSessions.AdvancedFriendsInterface.OnPlayerLoginChanged
// Size: 0x4(Inherited: 0x0) 
struct FOnPlayerLoginChanged
{
	int32_t PlayerNum;  // 0x0(0x4)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetExtraSettings
// Size: 0x118(Inherited: 0x0) 
struct FGetExtraSettings
{
	struct FBlueprintSessionResult SessionResult;  // 0x0(0x108)
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x108(0x10)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.AddOrModifyExtraSettings
// Size: 0x30(Inherited: 0x0) 
struct FAddOrModifyExtraSettings
{
	struct TArray<struct FSessionPropertyKeyPair> SettingsArray;  // 0x0(0x10)
	struct TArray<struct FSessionPropertyKeyPair> NewOrChangedSettings;  // 0x10(0x10)
	struct TArray<struct FSessionPropertyKeyPair> ModifiedSettingsArray;  // 0x20(0x10)

}; 
// Function AdvancedSessions.AdvancedFriendsInterface.OnPlayerLoginStatusChanged
// Size: 0x28(Inherited: 0x0) 
struct FOnPlayerLoginStatusChanged
{
	uint8_t  PreviousStatus;  // 0x0(0x1)
	uint8_t  NewStatus;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FBPUniqueNetId PlayerUniqueNetID;  // 0x8(0x20)

}; 
// Function AdvancedSessions.AdvancedFriendsGameInstance.OnPlayerTalkingStateChanged
// Size: 0x28(Inherited: 0x0) 
struct FOnPlayerTalkingStateChanged
{
	struct FBPUniqueNetId PlayerId;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bIsTalking : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetCurrentUniqueBuildID
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentUniqueBuildID
{
	int32_t UniqueBuildId;  // 0x0(0x4)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.StartNetworkedVoice
// Size: 0x1(Inherited: 0x0) 
struct FStartNetworkedVoice
{
	char LocalPlayerNum;  // 0x0(0x1)

}; 
// Function AdvancedSessions.AdvancedFriendsInterface.OnSessionInviteAccepted
// Size: 0x128(Inherited: 0x0) 
struct FOnSessionInviteAccepted
{
	struct FBPUniqueNetId PersonInvited;  // 0x0(0x20)
	struct FBlueprintSessionResult SearchResult;  // 0x20(0x108)

}; 
// Function AdvancedSessions.AdvancedFriendsInterface.OnSessionInviteReceived
// Size: 0x128(Inherited: 0x0) 
struct FOnSessionInviteReceived
{
	struct FBPUniqueNetId PersonInviting;  // 0x0(0x20)
	struct FBlueprintSessionResult SearchResult;  // 0x20(0x108)

}; 
// Function AdvancedSessions.AdvancedFriendsInterface.OnPlayerVoiceStateChanged
// Size: 0x28(Inherited: 0x0) 
struct FOnPlayerVoiceStateChanged
{
	struct FBPUniqueNetId PlayerId;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bIsTalking : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AdvancedSessions.AdvancedFriendsLibrary.SendSessionInviteToFriend
// Size: 0x30(Inherited: 0x0) 
struct FSendSessionInviteToFriend
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FBPUniqueNetId FriendUniqueNetId;  // 0x8(0x20)
	uint8_t  Result;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionState
// Size: 0x10(Inherited: 0x0) 
struct FGetSessionState
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	uint8_t  SessionState;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.EqualEqual_UNetIDUnetID
// Size: 0x48(Inherited: 0x0) 
struct FEqualEqual_UNetIDUnetID
{
	struct FBPUniqueNetId A;  // 0x0(0x20)
	struct FBPUniqueNetId B;  // 0x20(0x20)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyString
// Size: 0x38(Inherited: 0x0) 
struct FMakeLiteralSessionPropertyString
{
	struct FName Key;  // 0x0(0x8)
	struct FString Value;  // 0x8(0x10)
	struct FSessionPropertyKeyPair ReturnValue;  // 0x18(0x20)

}; 
// Function AdvancedSessions.AdvancedFriendsLibrary.SendSessionInviteToFriends
// Size: 0x20(Inherited: 0x0) 
struct FSendSessionInviteToFriends
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct TArray<struct FBPUniqueNetId> Friends;  // 0x8(0x10)
	uint8_t  Result;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetAllUserAccounts
// Size: 0x18(Inherited: 0x0) 
struct FGetAllUserAccounts
{
	struct TArray<struct FBPUserOnlineAccount> AccountInfos;  // 0x0(0x10)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetLoginStatus
// Size: 0x28(Inherited: 0x0) 
struct FGetLoginStatus
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	uint8_t  LoginStatus;  // 0x20(0x1)
	uint8_t  Result;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetUniqueBuildID
// Size: 0x110(Inherited: 0x0) 
struct FGetUniqueBuildID
{
	struct FBlueprintSessionResult SessionResult;  // 0x0(0x108)
	int32_t UniqueBuildId;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetPlayerAuthToken
// Size: 0x20(Inherited: 0x0) 
struct FGetPlayerAuthToken
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FString AuthToken;  // 0x8(0x10)
	uint8_t  Result;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetUniqueNetID
// Size: 0x28(Inherited: 0x0) 
struct FGetUniqueNetID
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FBPUniqueNetId UniqueNetId;  // 0x8(0x20)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetPlayerNickname
// Size: 0x30(Inherited: 0x0) 
struct FGetPlayerNickname
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	struct FString PlayerNickname;  // 0x20(0x10)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountAccessToken
// Size: 0x20(Inherited: 0x0) 
struct FGetUserAccountAccessToken
{
	struct FBPUserOnlineAccount AccountInfo;  // 0x0(0x10)
	struct FString AccessToken;  // 0x10(0x10)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountAttribute
// Size: 0x38(Inherited: 0x0) 
struct FGetUserAccountAttribute
{
	struct FBPUserOnlineAccount AccountInfo;  // 0x0(0x10)
	struct FString AttributeName;  // 0x10(0x10)
	struct FString AttributeValue;  // 0x20(0x10)
	uint8_t  Result;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountAuthAttribute
// Size: 0x38(Inherited: 0x0) 
struct FGetUserAccountAuthAttribute
{
	struct FBPUserOnlineAccount AccountInfo;  // 0x0(0x10)
	struct FString AttributeName;  // 0x10(0x10)
	struct FString AuthAttribute;  // 0x20(0x10)
	uint8_t  Result;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountDisplayName
// Size: 0x20(Inherited: 0x0) 
struct FGetUserAccountDisplayName
{
	struct FBPUserOnlineAccount AccountInfo;  // 0x0(0x10)
	struct FString DisplayName;  // 0x10(0x10)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetUserAccountRealName
// Size: 0x20(Inherited: 0x0) 
struct FGetUserAccountRealName
{
	struct FBPUserOnlineAccount AccountInfo;  // 0x0(0x10)
	struct FString Username;  // 0x10(0x10)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.GetUserId
// Size: 0x30(Inherited: 0x0) 
struct FGetUserId
{
	struct FBPUserOnlineAccount AccountInfo;  // 0x0(0x10)
	struct FBPUniqueNetId UniqueNetId;  // 0x10(0x20)

}; 
// Function AdvancedSessions.AdvancedIdentityLibrary.SetUserAccountAttribute
// Size: 0x38(Inherited: 0x0) 
struct FSetUserAccountAttribute
{
	struct FBPUserOnlineAccount AccountInfo;  // 0x0(0x10)
	struct FString AttributeName;  // 0x10(0x10)
	struct FString NewAttributeValue;  // 0x20(0x10)
	uint8_t  Result;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyString
// Size: 0x30(Inherited: 0x0) 
struct FGetSessionPropertyString
{
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x0(0x10)
	struct FName SettingName;  // 0x10(0x8)
	uint8_t  SearchResult;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString SettingValue;  // 0x20(0x10)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetPlayerName
// Size: 0x18(Inherited: 0x0) 
struct FGetPlayerName
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FString PlayerName;  // 0x8(0x10)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.FindSessionPropertyByName
// Size: 0x40(Inherited: 0x0) 
struct FFindSessionPropertyByName
{
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x0(0x10)
	struct FName SettingsName;  // 0x10(0x8)
	uint8_t  Result;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FSessionPropertyKeyPair OutProperty;  // 0x20(0x20)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetNetPlayerIndex
// Size: 0x10(Inherited: 0x0) 
struct FGetNetPlayerIndex
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	int32_t NetPlayerIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetNumberOfNetworkPlayers
// Size: 0x10(Inherited: 0x0) 
struct FGetNumberOfNetworkPlayers
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t NumNetPlayers;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionID_AsString
// Size: 0x118(Inherited: 0x0) 
struct FGetSessionID_AsString
{
	struct FBlueprintSessionResult SessionResult;  // 0x0(0x108)
	struct FString SessionId;  // 0x108(0x10)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyBool
// Size: 0x20(Inherited: 0x0) 
struct FGetSessionPropertyBool
{
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x0(0x10)
	struct FName SettingName;  // 0x10(0x8)
	uint8_t  SearchResult;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool SettingValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyFloat
// Size: 0x20(Inherited: 0x0) 
struct FGetSessionPropertyFloat
{
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x0(0x10)
	struct FName SettingName;  // 0x10(0x8)
	uint8_t  SearchResult;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float SettingValue;  // 0x1C(0x4)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyByte
// Size: 0x20(Inherited: 0x0) 
struct FGetSessionPropertyByte
{
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x0(0x10)
	struct FName SettingName;  // 0x10(0x8)
	uint8_t  SearchResult;  // 0x18(0x1)
	char SettingValue;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionPropertyInt
// Size: 0x20(Inherited: 0x0) 
struct FGetSessionPropertyInt
{
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x0(0x10)
	struct FName SettingName;  // 0x10(0x8)
	uint8_t  SearchResult;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t SettingValue;  // 0x1C(0x4)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetSessionSettings
// Size: 0x38(Inherited: 0x0) 
struct FGetSessionSettings
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t NumConnections;  // 0x8(0x4)
	int32_t NumPrivateConnections;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsLan : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bIsDedicated : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool bAllowInvites : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool bAllowJoinInProgress : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bIsAnticheatEnabled : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t BuildUniqueID;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x20(0x10)
	uint8_t  Result;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.GetUniqueNetIDFromPlayerState
// Size: 0x28(Inherited: 0x0) 
struct FGetUniqueNetIDFromPlayerState
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct FBPUniqueNetId UniqueNetId;  // 0x8(0x20)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.HasOnlineSubsystem
// Size: 0xC(Inherited: 0x0) 
struct FHasOnlineSubsystem
{
	struct FName SubSystemName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.IsPlayerInSession
// Size: 0x30(Inherited: 0x0) 
struct FIsPlayerInSession
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FBPUniqueNetId PlayerToCheck;  // 0x8(0x20)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bIsInSession : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyBool
// Size: 0x30(Inherited: 0x0) 
struct FMakeLiteralSessionPropertyBool
{
	struct FName Key;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FSessionPropertyKeyPair ReturnValue;  // 0x10(0x20)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.IsValidSession
// Size: 0x110(Inherited: 0x0) 
struct FIsValidSession
{
	struct FBlueprintSessionResult SessionResult;  // 0x0(0x108)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool ReturnValue : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.IsValidUniqueNetID
// Size: 0x28(Inherited: 0x0) 
struct FIsValidUniqueNetID
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.KickPlayer
// Size: 0x30(Inherited: 0x0) 
struct FKickPlayer
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerToKick;  // 0x8(0x8)
	struct FText KickReason;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyByte
// Size: 0x30(Inherited: 0x0) 
struct FMakeLiteralSessionPropertyByte
{
	struct FName Key;  // 0x0(0x8)
	char Value;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FSessionPropertyKeyPair ReturnValue;  // 0x10(0x20)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyFloat
// Size: 0x30(Inherited: 0x0) 
struct FMakeLiteralSessionPropertyFloat
{
	struct FName Key;  // 0x0(0x8)
	float Value;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FSessionPropertyKeyPair ReturnValue;  // 0x10(0x20)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionPropertyInt
// Size: 0x30(Inherited: 0x0) 
struct FMakeLiteralSessionPropertyInt
{
	struct FName Key;  // 0x0(0x8)
	int32_t Value;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FSessionPropertyKeyPair ReturnValue;  // 0x10(0x20)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.MakeLiteralSessionSearchProperty
// Size: 0x50(Inherited: 0x0) 
struct FMakeLiteralSessionSearchProperty
{
	struct FSessionPropertyKeyPair SessionSearchProperty;  // 0x0(0x20)
	uint8_t  ComparisonOp;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FSessionsSearchSetting ReturnValue;  // 0x28(0x28)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.SetPlayerName
// Size: 0x18(Inherited: 0x0) 
struct FSetPlayerName
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FString PlayerName;  // 0x8(0x10)

}; 
// Function AdvancedSessions.AdvancedSessionsLibrary.UniqueNetIdToString
// Size: 0x30(Inherited: 0x0) 
struct FUniqueNetIdToString
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	struct FString String;  // 0x20(0x10)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.GetNumLocalTalkers
// Size: 0x4(Inherited: 0x0) 
struct FGetNumLocalTalkers
{
	int32_t NumLocalTalkers;  // 0x0(0x4)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.IsHeadsetPresent
// Size: 0x2(Inherited: 0x0) 
struct FIsHeadsetPresent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHasHeadset : 1;  // 0x0(0x1)
	char LocalPlayerNum;  // 0x1(0x1)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.IsLocalPlayerTalking
// Size: 0x2(Inherited: 0x0) 
struct FIsLocalPlayerTalking
{
	char LocalPlayerNum;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.IsPlayerMuted
// Size: 0x30(Inherited: 0x0) 
struct FIsPlayerMuted
{
	char LocalUserNumChecking;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FBPUniqueNetId UniqueNetId;  // 0x8(0x20)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.IsRemotePlayerTalking
// Size: 0x28(Inherited: 0x0) 
struct FIsRemotePlayerTalking
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.MuteRemoteTalker
// Size: 0x30(Inherited: 0x0) 
struct FMuteRemoteTalker
{
	char LocalUserNum;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FBPUniqueNetId UniqueNetId;  // 0x8(0x20)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bIsSystemWide : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.RegisterLocalTalker
// Size: 0x2(Inherited: 0x0) 
struct FRegisterLocalTalker
{
	char LocalPlayerNum;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.StopNetworkedVoice
// Size: 0x1(Inherited: 0x0) 
struct FStopNetworkedVoice
{
	char LocalPlayerNum;  // 0x0(0x1)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.UnMuteRemoteTalker
// Size: 0x30(Inherited: 0x0) 
struct FUnMuteRemoteTalker
{
	char LocalUserNum;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FBPUniqueNetId UniqueNetId;  // 0x8(0x20)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bIsSystemWide : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.UnRegisterLocalTalker
// Size: 0x1(Inherited: 0x0) 
struct FUnRegisterLocalTalker
{
	char LocalPlayerNum;  // 0x0(0x1)

}; 
// Function AdvancedSessions.AdvancedVoiceLibrary.UnRegisterRemoteTalker
// Size: 0x28(Inherited: 0x0) 
struct FUnRegisterRemoteTalker
{
	struct FBPUniqueNetId UniqueNetId;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function AdvancedSessions.CancelFindSessionsCallbackProxy.CancelFindSessions
// Size: 0x18(Inherited: 0x0) 
struct FCancelFindSessions
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct UCancelFindSessionsCallbackProxy* ReturnValue;  // 0x10(0x8)

}; 
// Function AdvancedSessions.CreateSessionCallbackProxyAdvanced.CreateAdvancedSession
// Size: 0x40(Inherited: 0x0) 
struct FCreateAdvancedSession
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x8(0x10)
	struct APlayerController* PlayerController;  // 0x18(0x8)
	int32_t PublicConnections;  // 0x20(0x4)
	int32_t PrivateConnections;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bUseLAN : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bAllowInvites : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bIsDedicatedServer : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bUsePresence : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bUseLobbiesIfAvailable : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool bAllowJoinViaPresence : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool bAllowJoinViaPresenceFriendsOnly : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool bAntiCheatProtected : 1;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bUsesStats : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bShouldAdvertise : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct UCreateSessionCallbackProxyAdvanced* ReturnValue;  // 0x38(0x8)

}; 
// Function AdvancedSessions.EndSessionCallbackProxy.EndSession
// Size: 0x18(Inherited: 0x0) 
struct FEndSession
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct UEndSessionCallbackProxy* ReturnValue;  // 0x10(0x8)

}; 
// Function AdvancedSessions.FindSessionsCallbackProxyAdvanced.FilterSessionResults
// Size: 0x30(Inherited: 0x0) 
struct FFilterSessionResults
{
	struct TArray<struct FBlueprintSessionResult> SessionResults;  // 0x0(0x10)
	struct TArray<struct FSessionsSearchSetting> Filters;  // 0x10(0x10)
	struct TArray<struct FBlueprintSessionResult> FilteredResults;  // 0x20(0x10)

}; 
// Function AdvancedSessions.GetFriendsCallbackProxy.GetAndStoreFriendsList
// Size: 0x18(Inherited: 0x0) 
struct FGetAndStoreFriendsList
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct UGetFriendsCallbackProxy* ReturnValue;  // 0x10(0x8)

}; 
// Function AdvancedSessions.GetRecentPlayersCallbackProxy.GetAndStoreRecentPlayersList
// Size: 0x30(Inherited: 0x0) 
struct FGetAndStoreRecentPlayersList
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FBPUniqueNetId UniqueNetId;  // 0x8(0x20)
	struct UGetRecentPlayersCallbackProxy* ReturnValue;  // 0x28(0x8)

}; 
// Function AdvancedSessions.GetUserPrivilegeCallbackProxy.GetUserPrivilege
// Size: 0x38(Inherited: 0x0) 
struct FGetUserPrivilege
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	uint8_t  PrivilegeToCheck;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FBPUniqueNetId PlayerUniqueNetID;  // 0x10(0x20)
	struct UGetUserPrivilegeCallbackProxy* ReturnValue;  // 0x30(0x8)

}; 
// Function AdvancedSessions.LoginUserCallbackProxy.LoginUser
// Size: 0x38(Inherited: 0x0) 
struct FLoginUser
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct FString UserId;  // 0x10(0x10)
	struct FString UserToken;  // 0x20(0x10)
	struct ULoginUserCallbackProxy* ReturnValue;  // 0x30(0x8)

}; 
// Function AdvancedSessions.LogoutUserCallbackProxy.LogoutUser
// Size: 0x18(Inherited: 0x0) 
struct FLogoutUser
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct ULogoutUserCallbackProxy* ReturnValue;  // 0x10(0x8)

}; 
// Function AdvancedSessions.SendFriendInviteCallbackProxy.SendFriendInvite
// Size: 0x38(Inherited: 0x0) 
struct FSendFriendInvite
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct FBPUniqueNetId UniqueNetIDInvited;  // 0x10(0x20)
	struct USendFriendInviteCallbackProxy* ReturnValue;  // 0x30(0x8)

}; 
// Function AdvancedSessions.UpdateSessionCallbackProxyAdvanced.UpdateSession
// Size: 0x30(Inherited: 0x0) 
struct FUpdateSession
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<struct FSessionPropertyKeyPair> ExtraSettings;  // 0x8(0x10)
	int32_t PublicConnections;  // 0x18(0x4)
	int32_t PrivateConnections;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bUseLAN : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bAllowInvites : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool bAllowJoinInProgress : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool bRefreshOnlineData : 1;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bIsDedicatedServer : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct UUpdateSessionCallbackProxyAdvanced* ReturnValue;  // 0x28(0x8)

}; 
