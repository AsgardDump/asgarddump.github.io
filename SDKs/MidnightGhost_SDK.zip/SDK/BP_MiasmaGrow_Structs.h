#pragma once 
#include "SDK.h" 
 
 
// Function BP_MiasmaGrow.BP_MiasmaGrow_C.ExecuteUbergraph_BP_MiasmaGrow
// Size: 0x1A8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MiasmaGrow
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x4(0xC)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x18(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct ABP_Trap_C* K2Node_DynamicCast_AsBP_Trap;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x58(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x60(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x68(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x78(0x88)
	struct ABP_Generator_C* K2Node_DynamicCast_AsBP_Generator;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x10C(0x4)
	struct ABP_MedicKit_C* K2Node_DynamicCast_AsBP_Medic_Kit;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct ABP_C4Actor_C* K2Node_DynamicCast_AsBP_C4Actor;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct ABP_Trap_C* K2Node_DynamicCast_AsBP_Trap_2;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter_2;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x148(0x1)
	char pad_329[7];  // 0x149(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x150(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x158(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x160(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x168(0x4)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x16C(0x1)
	char pad_365[3];  // 0x16D(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x170(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_3;  // 0x174(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_4;  // 0x178(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_5;  // 0x17C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x180(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x184(0xC)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0x190(0x8)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x198(0x1)
	char pad_409[3];  // 0x199(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x19C(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_6;  // 0x1A0(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue_7;  // 0x1A4(0x4)

}; 
// Function BP_MiasmaGrow.BP_MiasmaGrow_C.BndEvt__DmgOverlap_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__DmgOverlap_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_MiasmaGrow.BP_MiasmaGrow_C.BndEvt__DmgOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__DmgOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
