#pragma once 
#include <AlphaAgreementInterface_Structs.h>
 
 
 
// BlueprintGeneratedClass AlphaAgreementInterface.AlphaAgreementInterface_C
// Size: 0x28(Inherited: 0x28) 
struct UAlphaAgreementInterface_C : public UInterface
{

	void IAgreeContinue_Int(); // Function AlphaAgreementInterface.AlphaAgreementInterface_C.IAgreeContinue_Int
}; 



