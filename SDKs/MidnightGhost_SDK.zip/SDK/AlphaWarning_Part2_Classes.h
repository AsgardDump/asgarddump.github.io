#pragma once 
#include <AlphaWarning_Part2_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AlphaWarning_Part2.AlphaWarning_Part2_C
// Size: 0x260(Inherited: 0x260) 
struct UAlphaWarning_Part2_C : public UUserWidget
{

}; 



