#pragma once 
#include <BP_SniperDart_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SniperDart.BP_SniperDart_C
// Size: 0x268(Inherited: 0x220) 
struct ABP_SniperDart_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UPointLightComponent* BlinkyLight;  // 0x228(0x8)
	struct UStaticMeshComponent* Cylinder;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	struct AProp_C* HitGhostRef;  // 0x240(0x8)
	float TargetRedLightIntensity;  // 0x248(0x4)
	float FlashInterval;  // 0x24C(0x4)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool StruckGhost? : 1;  // 0x250(0x1)
	char pad_593_1 : 7;  // 0x251(0x1)
	bool StruckLvlprop? : 1;  // 0x251(0x1)
	char pad_594[6];  // 0x252(0x6)
	struct ALvlProp_C* HitLvlpropRef;  // 0x258(0x8)
	struct ABP_Hunter_C* ResponsibleHunter;  // 0x260(0x8)

	void ReceiveBeginPlay(); // Function BP_SniperDart.BP_SniperDart_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_SniperDart.BP_SniperDart_C.ReceiveTick
	void SetBlinkingLoop(); // Function BP_SniperDart.BP_SniperDart_C.SetBlinkingLoop
	void Explode(); // Function BP_SniperDart.BP_SniperDart_C.Explode
	void Damage(); // Function BP_SniperDart.BP_SniperDart_C.Damage
	void ExecuteUbergraph_BP_SniperDart(int32_t EntryPoint); // Function BP_SniperDart.BP_SniperDart_C.ExecuteUbergraph_BP_SniperDart
}; 



