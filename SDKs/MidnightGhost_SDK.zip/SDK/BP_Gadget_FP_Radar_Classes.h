#pragma once 
#include <BP_Gadget_FP_Radar_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C
// Size: 0x260(Inherited: 0x233) 
struct ABP_Gadget_FP_Radar_C : public ABP_Gadget_FP_C
{
	char pad_563[5];  // 0x233(0x5)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct USkeletalMeshComponent* FP_Radar;  // 0x240(0x8)
	struct UAudioComponent* RadarIdle;  // 0x248(0x8)
	struct UPointLightComponent* Radarlite_FP;  // 0x250(0x8)
	struct UMaterialInstanceDynamic* Radar_Mtl_FP;  // 0x258(0x8)

	void GetSkeletalMesh(struct USkeletalMeshComponent*& SkeletalMesh); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.GetSkeletalMesh
	void GetComponents(struct TArray<struct USceneComponent*>& Components); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.GetComponents
	void ReceiveBeginPlay(); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.ReceiveTick
	void OC_Startup(); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.OC_Startup
	void ShowRadarLight(); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.ShowRadarLight
	void UpdateVisibility(bool Hide, bool SkipAnimation, bool TickWhileHidden, bool NonLocallyControlledOrBot, bool ShouldInterrupt); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.UpdateVisibility
	void Unequip(); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.Unequip
	void FakeHolsterGadget(); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.FakeHolsterGadget
	void FakeDrawGadget(); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.FakeDrawGadget
	void Init(); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.Init
	void SetWeaponData(float RadarCloseness, bool ForceMaximumGeiger, bool RadarActivated); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.SetWeaponData
	void ExecuteUbergraph_BP_Gadget_FP_Radar(int32_t EntryPoint); // Function BP_Gadget_FP_Radar.BP_Gadget_FP_Radar_C.ExecuteUbergraph_BP_Gadget_FP_Radar
}; 



