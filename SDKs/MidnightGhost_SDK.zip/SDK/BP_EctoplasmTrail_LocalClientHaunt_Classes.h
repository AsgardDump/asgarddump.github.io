#pragma once 
#include <BP_EctoplasmTrail_LocalClientHaunt_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EctoplasmTrail_LocalClientHaunt.BP_EctoplasmTrail_LocalClientHaunt_C
// Size: 0x2E8(Inherited: 0x2E8) 
struct ABP_EctoplasmTrail_LocalClientHaunt_C : public ABP_EctoplasmTrail_C
{

}; 



