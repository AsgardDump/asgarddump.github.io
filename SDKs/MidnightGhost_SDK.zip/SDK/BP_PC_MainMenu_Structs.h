#pragma once 
#include "SDK.h" 
 
 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.ExecuteUbergraph_BP_PC_MainMenu
// Size: 0x3F1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PC_MainMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x8(0x8)
	struct UUserWidget* CallFunc_CreateDebugConditionsUI_ReturnValue;  // 0x10(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_CustomEvent_ShowMouseCursor : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct UWidget* K2Node_CustomEvent_InWidgetToFocus;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Temp_bool_Variable : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4C(0x10)
	char pad_92[4];  // 0x5C(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_2;  // 0x60(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_IsWidgetOfClassInViewport_ReturnValue : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct TArray<struct UMGH_BaseIntro_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x80(0x10)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_3;  // 0x90(0x8)
	struct UMGH_BaseIntro_UI_C* CallFunc_Array_Get_Item;  // 0x98(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_2;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xB4(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_4;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_CanDebug_Int_Yes_No : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_3;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct UW_PartyPanel_C* K2Node_Event_UI_PartyPanel;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_CanDebug_Int_Yes_No_2 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct ASteamBeaconPlayerState* K2Node_ComponentBoundEvent_InPlayerBeaconState_3;  // 0xF0(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_5;  // 0xF8(0x8)
	struct USteamBeaconGISubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x100(0x8)
	struct USteamBeaconGameInstance* K2Node_DynamicCast_AsSteam_Beacon_Game_Instance;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x111(0x1)
	char pad_274[6];  // 0x112(0x6)
	struct ASteamBeaconPlayerState* K2Node_ComponentBoundEvent_InPlayerBeaconState_2;  // 0x118(0x8)
	struct ASteamBeaconPlayerState* K2Node_ComponentBoundEvent_InPlayerBeaconState;  // 0x120(0x8)
	struct FUniqueNetIdRepl K2Node_ComponentBoundEvent_InPlayerUniqueId_2;  // 0x128(0x28)
	struct FPartyMessage K2Node_ComponentBoundEvent_InPartyMessage;  // 0x150(0x80)
	struct FUniqueNetIdRepl K2Node_ComponentBoundEvent_InPlayerUniqueId;  // 0x1D0(0x28)
	struct FString K2Node_ComponentBoundEvent_InFriendName;  // 0x1F8(0x10)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x208(0x1)
	char pad_521[3];  // 0x209(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20C(0x10)
	char pad_540_1 : 7;  // 0x21C(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x21C(0x1)
	char pad_541_1 : 7;  // 0x21D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x21D(0x1)
	char pad_542_1 : 7;  // 0x21E(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x21E(0x1)
	char pad_543_1 : 7;  // 0x21F(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x21F(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x220(0x4)
	char pad_548_1 : 7;  // 0x224(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x224(0x1)
	char pad_549[3];  // 0x225(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x228(0x4)
	char pad_556[4];  // 0x22C(0x4)
	struct UWB_ProMainMenu_C* CallFunc_GetProMainMenu_ProMainMenu;  // 0x230(0x8)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x238(0x18)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_6;  // 0x250(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_4;  // 0x258(0x10)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x270(0x18)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool CallFunc_IsQuittingJoiningParty_Int_IsQuittingJoiningParty : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x289(0x1)
	char pad_650[6];  // 0x28A(0x6)
	struct FKey K2Node_InputKeyEvent_Key_4;  // 0x290(0x18)
	float K2Node_Event_DeltaSeconds;  // 0x2A8(0x4)
	char pad_684[4];  // 0x2AC(0x4)
	struct FKey K2Node_InputKeyEvent_Key_5;  // 0x2B0(0x18)
	float K2Node_InputAxisKeyEvent_AxisValue_2;  // 0x2C8(0x4)
	char pad_716_1 : 7;  // 0x2CC(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x2CC(0x1)
	char pad_717[3];  // 0x2CD(0x3)
	float K2Node_InputAxisKeyEvent_AxisValue;  // 0x2D0(0x4)
	char pad_724_1 : 7;  // 0x2D4(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue_2 : 1;  // 0x2D4(0x1)
	char pad_725[3];  // 0x2D5(0x3)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_7;  // 0x2D8(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_5;  // 0x2E0(0x10)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_8;  // 0x2F8(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_6;  // 0x300(0x10)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x310(0x1)
	char pad_785[7];  // 0x311(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_9;  // 0x318(0x8)
	struct FString CallFunc_GetLobbyRTCRoomName_Int_RTCRoomName;  // 0x320(0x10)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_7;  // 0x330(0x10)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x340(0x1)
	char pad_833[7];  // 0x341(0x7)
	struct UUserWidget* CallFunc_CreateBeginUIDebug_Ref;  // 0x348(0x8)
	struct FString CallFunc_GetLobbyRTCRoomName_Int_RTCRoomName_2;  // 0x350(0x10)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x360(0x18)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x378(0x1)
	char pad_889[7];  // 0x379(0x7)
	struct FKey CallFunc_FindRightInputType_LastPressedKey;  // 0x380(0x18)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x398(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_2;  // 0x399(0x1)
	char pad_922[6];  // 0x39A(0x6)
	struct FKey Temp_struct_Variable;  // 0x3A0(0x18)
	struct FKey K2Node_InputActionEvent_Key;  // 0x3B8(0x18)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x3D0(0x18)
	struct UWB_ProMainMenu_C* CallFunc_GetProMainMenu_ProMainMenu_2;  // 0x3E8(0x8)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x3F0(0x1)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_AnyKey_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x18) 
struct FInpActEvt_AnyKey_K2Node_InputKeyEvent_1 : public FInpActEvt_AnyKey_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpAxisKeyEvt_MouseY_K2Node_InputAxisKeyEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisKeyEvt_MouseY_K2Node_InputAxisKeyEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_4_OnPlayerUniqueIdSteamPartyDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FBndEvt__SteamParty_K2Node_ComponentBoundEvent_4_OnPlayerUniqueIdSteamPartyDelegate__DelegateSignature
{
	struct FUniqueNetIdRepl InPlayerUniqueId;  // 0x0(0x28)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpAxisKeyEvt_MouseX_K2Node_InputAxisKeyEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisKeyEvt_MouseX_K2Node_InputAxisKeyEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.UpdateInputMode
// Size: 0x10(Inherited: 0x0) 
struct FUpdateInputMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ShowMouseCursor : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UWidget* InWidgetToFocus;  // 0x8(0x8)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_10_OnPlayerInviteReceivedSteamPartyDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FBndEvt__SteamParty_K2Node_ComponentBoundEvent_10_OnPlayerInviteReceivedSteamPartyDelegate__DelegateSignature
{
	struct FUniqueNetIdRepl InPlayerUniqueId;  // 0x0(0x28)
	struct FString InFriendName;  // 0x28(0x10)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_5_OnPlayerMessageSteamPartyDelegate__DelegateSignature
// Size: 0x80(Inherited: 0x0) 
struct FBndEvt__SteamParty_K2Node_ComponentBoundEvent_5_OnPlayerMessageSteamPartyDelegate__DelegateSignature
{
	struct FPartyMessage InPartyMessage;  // 0x0(0x80)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_2_OnPlayerUpdateSteamPartyDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__SteamParty_K2Node_ComponentBoundEvent_2_OnPlayerUpdateSteamPartyDelegate__DelegateSignature
{
	struct ASteamBeaconPlayerState* InPlayerBeaconState;  // 0x0(0x8)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_1_OnPlayerUpdateSteamPartyDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__SteamParty_K2Node_ComponentBoundEvent_1_OnPlayerUpdateSteamPartyDelegate__DelegateSignature
{
	struct ASteamBeaconPlayerState* InPlayerBeaconState;  // 0x0(0x8)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.BndEvt__SteamParty_K2Node_ComponentBoundEvent_0_OnPlayerJoinedSteamPartyDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__SteamParty_K2Node_ComponentBoundEvent_0_OnPlayerJoinedSteamPartyDelegate__DelegateSignature
{
	struct ASteamBeaconPlayerState* InPlayerBeaconState;  // 0x0(0x8)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.Begin
// Size: 0x8(Inherited: 0x0) 
struct FBegin
{
	struct UW_PartyPanel_C* UI_PartyPanel;  // 0x0(0x8)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_EOSPTT_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EOSPTT_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_EOSPTT_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EOSPTT_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Open Pause Menu_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Open Pause Menu_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Enter_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Enter_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Ctrl_X_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_X_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.InpActEvt_NumPadZero_K2Node_InputKeyEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_NumPadZero_K2Node_InputKeyEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.GetProMainMenu
// Size: 0x29(Inherited: 0x0) 
struct FGetProMainMenu
{
	struct UWB_ProMainMenu_C* ProMainMenu;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct UWB_ProMainMenu_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x10(0x10)
	struct UWB_ProMainMenu_C* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)

}; 
// Function BP_PC_MainMenu.BP_PC_MainMenu_C.SpawnClientBeacon_Int
// Size: 0x70(Inherited: 0x0) 
struct FSpawnClientBeacon_Int
{
	struct UObject* ClientBeacon;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct AMGH_Beacon_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x48(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x60(0x10)

}; 
