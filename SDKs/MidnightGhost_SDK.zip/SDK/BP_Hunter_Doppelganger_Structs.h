#pragma once 
#include "SDK.h" 
 
 
// Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.GetEctoBuildup
// Size: 0xA(Inherited: 0x0) 
struct FGetEctoBuildup
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Prop? : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Radiation;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Sensitive? : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Midnight Form? : 1;  // 0x9(0x1)

}; 
// Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.ExecuteUbergraph_BP_Hunter_Doppelganger
// Size: 0x50(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Hunter_Doppelganger
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct AFirelight_SpawnHClone_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x48(0x8)

}; 
// Function BP_Hunter_Doppelganger.BP_Hunter_Doppelganger_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
