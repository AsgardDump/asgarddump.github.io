#pragma once 
#include "SDK.h" 
 
 
// Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.UserConstructionScript
// Size: 0x1E0(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UTexture* Temp_object_Variable;  // 0x8(0x8)
	struct UTexture* Temp_object_Variable_2;  // 0x10(0x8)
	struct UTexture* Temp_object_Variable_3;  // 0x18(0x8)
	struct UTexture* Temp_object_Variable_4;  // 0x20(0x8)
	struct UTexture* Temp_object_Variable_5;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_Variable : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x34(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x44(0x10)
	char Ghost_SizeClass Temp_byte_Variable;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x58(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x5C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x60(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x64(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x68(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x74(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x80(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_5;  // 0x84(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_6;  // 0x88(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_3;  // 0x8C(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x98(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_7;  // 0x9C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_4;  // 0xA0(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue_8;  // 0xAC(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0xB0(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_5;  // 0xB4(0xC)
	struct UTexture* K2Node_Select_Default;  // 0xC0(0x8)
	struct FLinearColor K2Node_Select_Default_2;  // 0xC8(0x10)
	struct UDecalComponent* CallFunc_AddComponent_ReturnValue;  // 0xD8(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0xE0(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xE8(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0xF4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x100(0x30)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0x130(0x30)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0x160(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue_9;  // 0x16C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_6;  // 0x170(0xC)
	char pad_380[4];  // 0x17C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue_3;  // 0x180(0x30)
	struct FTransform K2Node_Select_Default_3;  // 0x1B0(0x30)

}; 
// Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.ExecuteUbergraph_BP_EctoplasmTrail
// Size: 0x79(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EctoplasmTrail
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_Hidden_ : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x8(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x20(0x8)
	struct ABP_EctoplasmTrail_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x3C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	struct FVector CallFunc_BreakTransform_Location;  // 0x48(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x54(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x60(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x6C(0xC)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue_2 : 1;  // 0x78(0x1)

}; 
// Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.SetHidden?
// Size: 0x1(Inherited: 0x0) 
struct FSetHidden?
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hidden? : 1;  // 0x0(0x1)

}; 
// Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.CheckOwnerDistance?
// Size: 0x2D(Inherited: 0x0) 
struct FCheckOwnerDistance?
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool  OK : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x10(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x1C(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x2C(0x1)

}; 
