#pragma once 
#include "SDK.h" 
 
 
// Function BP_LightSwitch_WH.BP_LightSwitch_WH_C.ExecuteUbergraph_BP_LightSwitch_WH
// Size: 0x59(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LightSwitch_WH
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UMiscIndicator_UI_C* K2Node_DynamicCast_AsMisc_Indicator_UI;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_PC;  // 0x28(0x8)
	struct TArray<struct ABP_FlickeringLamp_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x30(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct ABP_FlickeringLamp_C* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_LightSwitch_WH.BP_LightSwitch_WH_C.WHLightSwitch_Interact
// Size: 0x8(Inherited: 0x0) 
struct FWHLightSwitch_Interact
{
	struct AMGH_PlayerController_BP_C* PC;  // 0x0(0x8)

}; 
