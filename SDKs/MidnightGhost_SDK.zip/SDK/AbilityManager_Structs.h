#pragma once 
#include "SDK.h" 
 
 
// Function AbilityManager.AbilityManager_C. White Message!
// Size: 0x18(Inherited: 0x0) 
struct F White Message!
{
	struct FText Message;  // 0x0(0x18)

}; 
