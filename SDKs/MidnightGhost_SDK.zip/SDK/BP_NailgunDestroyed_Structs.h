#pragma once 
#include "SDK.h" 
 
 
// Function BP_NailgunDestroyed.BP_NailgunDestroyed_C.ExecuteUbergraph_BP_NailgunDestroyed
// Size: 0x7C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_NailgunDestroyed
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x14(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue;  // 0x20(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UStaticMeshComponent* CallFunc_Array_Get_Item;  // 0x38(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x50(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x58(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_3;  // 0x60(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_4;  // 0x68(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x70(0xC)

}; 
// Function BP_NailgunDestroyed.BP_NailgunDestroyed_C.UserConstructionScript
// Size: 0xAC(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x18(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x1C(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x20(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_5;  // 0x24(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_6;  // 0x28(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x38(0xC)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x44(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x48(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_7;  // 0x4C(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_8;  // 0x50(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_9;  // 0x54(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x58(0xC)
	char pad_100[12];  // 0x64(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x70(0x30)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0xA0(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xA8(0x4)

}; 
