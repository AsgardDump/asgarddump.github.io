#pragma once 
#include <BlockoutToolsFunctions_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockoutToolsFunctions.BlockoutToolsFunctions_C
// Size: 0x28(Inherited: 0x28) 
struct UBlockoutToolsFunctions_C : public UBlueprintFunctionLibrary
{

	void BlockoutRoundVector2D(bool RoundSize, struct FVector2D& Vector, struct UObject* __WorldContext); // Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundVector2D
	void BlockoutRoundVector(bool RoundSize, struct FVector& Vector, struct UObject* __WorldContext); // Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundVector
	void BlockoutRoundFloat(bool RoundSize, float& Float, struct UObject* __WorldContext); // Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundFloat
	void BlockoutSetMaterial_D(struct UMeshComponent* StaticMesh, struct UMaterialInterface* BlockoutMaterial, bool UseGrid, struct FLinearColor Color, bool UseTopColor, struct FLinearColor TopColor, struct UObject* __WorldContext); // Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutSetMaterial_D
	void BlockoutRoundVariables_D(bool RoundSize, float InFloat, struct FVector InVector, struct FVector2D InVector2D, struct UObject* __WorldContext, float& OutFloat, struct FVector& OutVector, struct FVector2D& OutVector2D); // Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundVariables_D
}; 



