#pragma once 
#include <BP_MainMenu_Input_Functions_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_MainMenu_Input_Functions_C : public UBlueprintFunctionLibrary
{

	void GetUIMouseInfo(struct UObject* __WorldContext, bool& ShouldShowMouseInUI, uint8_t & ShouldLockMouseInUI); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetUIMouseInfo
	void GetVRControllerKeys(struct UObject* __WorldContext, struct TArray<struct FKey>& Oculus VR Keys); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetVRControllerKeys
	void GetMouseKeys(struct UObject* __WorldContext, struct TArray<struct FKey>& MouseKeys); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetMouseKeys
	void GetGamepadKeys(struct UObject* __WorldContext, struct TArray<struct FKey>& GamepadKeys); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetGamepadKeys
	void GetPC_InputDetect(struct UObject* __WorldContext, struct ABP_PC_InputDetect_C*& AsPC Input Detect); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetPC_InputDetect
	void SetRightInputType(struct FKey& InputKey, struct UObject* WorldContextObject, struct UObject* __WorldContext, struct FKey& LastPressed_Key); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.SetRightInputType
	void FindInputType(struct FKey& InputKey, struct UObject* __WorldContext, struct FKey& LastPressed_Key, uint8_t & InputType); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.FindInputType
	void GetShowMouse(struct UObject* __WorldContext, bool& bShowMouse); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetShowMouse
	void SetShowMouse(bool ShowMouse, struct UObject* __WorldContext); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.SetShowMouse
	void UnbindOnInputTypeSwitched(struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.UnbindOnInputTypeSwitched
	void BindOnInputTypeSwitched(struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.BindOnInputTypeSwitched
	void SetInputType(uint8_t  InputType, struct UObject* WorldContextObject, struct UObject* __WorldContext); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.SetInputType
	void GetInputType(struct UObject* __WorldContext, uint8_t & InputType); // Function BP_MainMenu_Input_Functions.BP_MainMenu_Input_Functions_C.GetInputType
}; 



