#pragma once 
#include <BP_KeyInput_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KeyInput.BP_KeyInput_C
// Size: 0x68(Inherited: 0x28) 
struct UBP_KeyInput_C : public UObject
{
	struct FKey Key Input;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Analog Use Negative Axis : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float Analog Previous Axis Value;  // 0x44(0x4)
	float Analog Current Axis Value;  // 0x48(0x4)
	float World Delta Seconds;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Input is Using Delta : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString Display Name;  // 0x58(0x10)

	void Generate Display Name(); // Function BP_KeyInput.BP_KeyInput_C.Generate Display Name
	void Save Key Input(struct UBP_GameSettings_C* Game Settings, struct FSKeyActionSave& KeySave); // Function BP_KeyInput.BP_KeyInput_C.Save Key Input
	void Update Analog Axis Value(float World Delta Seconds, struct APlayerController* Player Controller); // Function BP_KeyInput.BP_KeyInput_C.Update Analog Axis Value
	void Key Input Current State(struct APlayerController* Controller, float& Axis Value, bool& Down, bool& Just Pressed, bool& Just Released); // Function BP_KeyInput.BP_KeyInput_C.Key Input Current State
	void Init Key Input(struct FSKeyInput Key Input, struct UBP_KeyInput_C*& Input); // Function BP_KeyInput.BP_KeyInput_C.Init Key Input
}; 



