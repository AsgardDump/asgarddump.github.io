#pragma once 
#include <AttachedFollowActor_Structs.h>
 
 
 
// BlueprintGeneratedClass AttachedFollowActor.AttachedFollowActor_C
// Size: 0x241(Inherited: 0x220) 
struct AAttachedFollowActor_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct AProp_C* MyProp;  // 0x230(0x8)
	struct ABP_Hunter_C* HunterAttach;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool Reeling? : 1;  // 0x240(0x1)

	void ReceiveBeginPlay(); // Function AttachedFollowActor.AttachedFollowActor_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function AttachedFollowActor.AttachedFollowActor_C.ReceiveTick
	void StartReeling(); // Function AttachedFollowActor.AttachedFollowActor_C.StartReeling
	void StopReeling(); // Function AttachedFollowActor.AttachedFollowActor_C.StopReeling
	void ExecuteUbergraph_AttachedFollowActor(int32_t EntryPoint); // Function AttachedFollowActor.AttachedFollowActor_C.ExecuteUbergraph_AttachedFollowActor
}; 



