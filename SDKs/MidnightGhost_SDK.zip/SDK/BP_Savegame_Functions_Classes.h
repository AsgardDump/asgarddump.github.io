#pragma once 
#include <BP_Savegame_Functions_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Savegame_Functions.BP_Savegame_Functions_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_Savegame_Functions_C : public UBlueprintFunctionLibrary
{

	void LoadAndApplyControlSettings(bool SetDefaultValues, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAndApplyControlSettings
	bool Load_Invert_Y(struct UObject* __WorldContext, bool& Invert_Y); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Invert_Y
	bool Save_Invert_Y(bool InvertY, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Invert_Y
	bool Load_Invert_X(struct UObject* __WorldContext, bool& Invert_X); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Invert_X
	bool Save_Invert_X(bool InvertX, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Invert_X
	bool Load_Sensitivity04(struct UObject* __WorldContext, float& Sensitivity); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity04
	bool Save_Sensitivity04(float Sensitivity, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity04
	bool Load_Sensitivity03(struct UObject* __WorldContext, float& Sensitivity); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity03
	bool Save_Sensitivity03(float Sensitivity, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity03
	bool Load_Sensitivity02(struct UObject* __WorldContext, float& Sensitivity); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity02
	bool Save_Sensitivity02(float Sensitivity, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity02
	bool Load_Sensitivity01(struct UObject* __WorldContext, float& Sensitivity); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Sensitivity01
	bool Save_Sensitivity01(float Sensitivity, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Sensitivity01
	bool DoesControlSettingsSaveExist(struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesControlSettingsSaveExist
	bool DeleteControlSettingsSave(struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.DeleteControlSettingsSave
	float FindVolume(float Volume, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.FindVolume
	bool DoesAudioSettingsSaveExist(struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesAudioSettingsSaveExist
	bool DeleteAudioSettingsSave(struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.DeleteAudioSettingsSave
	bool Load_Subtitles(struct UObject* __WorldContext, bool& bSubtitles); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_Subtitles
	bool Save_Subtitles(bool bSubtitles, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_Subtitles
	bool Load_MusicOn(struct UObject* __WorldContext, bool& bMusic); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_MusicOn
	bool Save_MusicOn(bool bMusic, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_MusicOn
	bool Load_OutputProfile(struct UObject* __WorldContext, int32_t& OutputProfile); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_OutputProfile
	bool Save_OutputProfile(int32_t OutputProfile, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_OutputProfile
	bool Load_SoundEffectsVolume(struct UObject* __WorldContext, float& SoundEffectsVolume); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_SoundEffectsVolume
	bool Save_SoundEffectsVolume(float SoundEffectsVolume, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_SoundEffectsVolume
	bool Load_DialogueVolume(struct UObject* __WorldContext, float& DialogueVolume); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_DialogueVolume
	bool Save_DialogueVolume(float DialogueVolume, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_DialogueVolume
	bool Load_MusicVolume(struct UObject* __WorldContext, float& MusicVolume); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_MusicVolume
	bool Save_MusicVolume(float MusicVolume, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_MusicVolume
	bool Load_MasterVolume(struct UObject* __WorldContext, float& MasterVolume); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Load_MasterVolume
	bool Save_MasterVolume(float MasterVolume, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.Save_MasterVolume
	bool LoadPostProcessQuality(struct UObject* __WorldContext, int32_t& PostProcessQuality); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadPostProcessQuality
	bool SavePostProcessQuality(int32_t PostProcessQuality, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SavePostProcessQuality
	bool LoadViewDistance(struct UObject* __WorldContext, int32_t& ViewDistanceQuality); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadViewDistance
	bool SaveViewDistance(int32_t ViewDistanceQuality, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveViewDistance
	bool LoadFoliageQuality(struct UObject* __WorldContext, int32_t& FoliageQuality); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadFoliageQuality
	bool SaveFoliageQuality(int32_t FoliageQuality, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveFoliageQuality
	bool LoadAAQuality(struct UObject* __WorldContext, int32_t& AAQuality); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAAQuality
	bool SaveAAQuality(int32_t AAQuality, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAAQuality
	bool LoadVisualEffectsQuality(struct UObject* __WorldContext, int32_t& VisualEffectsQuality); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadVisualEffectsQuality
	bool SaveVisualEffectsQuality(int32_t VisualEffectsQuality, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveVisualEffectsQuality
	bool LoadShadowQuality(struct UObject* __WorldContext, int32_t& ShadowQuality); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadShadowQuality
	bool SaveShadowQuality(int32_t ShadowQuality, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveShadowQuality
	bool LoadTextureQuality(struct UObject* __WorldContext, int32_t& TextureQuality); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadTextureQuality
	bool SaveTextureQuality(int32_t TextureQuality, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveTextureQuality
	bool LoadVsync(struct UObject* __WorldContext, bool& VerticalSync); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadVsync
	bool SaveVsync(bool VerticalSync, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveVsync
	bool LoadFrameRateLimit(struct UObject* __WorldContext, float& FrameRateLimit); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadFrameRateLimit
	bool SaveFrameRateLimit(float FrameRateLimit, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveFrameRateLimit
	bool LoadDynamicResolution(struct UObject* __WorldContext, bool& DynamicResolution); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadDynamicResolution
	bool SaveDynamicResolution(bool DynamicResolution, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveDynamicResolution
	bool LoadResolutionScale(struct UObject* __WorldContext, float& ResolutionScale); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadResolutionScale
	bool SaveResolutionScale(float ResolutionScale, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveResolutionScale
	void LoadAndApplyGraphicSettings(bool SetDefaultValues, bool bUseBenchmarkTest, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAndApplyGraphicSettings
	bool LoadWindowMode(struct UObject* __WorldContext, char EWindowMode& WindowMode); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadWindowMode
	bool SaveWindowMode(char EWindowMode WindowMode, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveWindowMode
	bool DeleteVideoSettingsSave(struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.DeleteVideoSettingsSave
	bool LoadScreenResolution(struct UObject* __WorldContext, struct FIntPoint& ScreenResolution); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadScreenResolution
	bool DoesVideoSettingsSaveExist(struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesVideoSettingsSaveExist
	bool SaveScreenResolution(struct FIntPoint ScreenResolution, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveScreenResolution
	bool LoadAxisMappingScales_Gamepad(struct UObject* __WorldContext, struct TArray<float>& AxisMappingScales_Gamepad); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappingScales_Gamepad
	bool LoadAxisMappingScales_KeyboardMouse(struct UObject* __WorldContext, struct TArray<float>& AxisMappingScales_KeyboardMouse); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappingScales_KeyboardMouse
	bool SaveAxisMappingScales_Gamepad(struct TArray<float>& Scales, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappingScales_Gamepad
	bool SaveAxisMappingScales_KeyboardMouse(struct TArray<float>& ScaleValues, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappingScales_KeyboardMouse
	bool LoadAxisMappings_Gamepad(struct UObject* __WorldContext, struct TMap<struct FName, struct FKey>& AxisMappings_Gamepad); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappings_Gamepad
	bool LoadAxisMappings_KeyboardMouse(struct UObject* __WorldContext, struct TMap<struct FName, struct FKey>& AxisMappings_KeyboardMouse); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadAxisMappings_KeyboardMouse
	bool LoadActionMappings_Gamepad(struct UObject* __WorldContext, struct TMap<struct FName, struct FKey>& ActionMappings_Gamepad); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadActionMappings_Gamepad
	bool SaveAxisMappings_Gamepad(struct TMap<struct FName, struct FKey> Map, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappings_Gamepad
	bool SaveAxisMappings_KeyboardMouse(struct TMap<struct FName, struct FKey> Map, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveAxisMappings_KeyboardMouse
	bool SaveActionMappings_Gamepad(struct TMap<struct FName, struct FKey> Map, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveActionMappings_Gamepad
	bool LoadActionMappings_KeyboardMouse(struct UObject* __WorldContext, struct TMap<struct FName, struct FKey>& ActionMappings_KeyboardMouse); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.LoadActionMappings_KeyboardMouse
	bool SaveActionMappings_KeyboardMouse(struct TMap<struct FName, struct FKey> Map, struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.SaveActionMappings_KeyboardMouse
	bool DoesInputDefaultsExist(struct UObject* __WorldContext); // Function BP_Savegame_Functions.BP_Savegame_Functions_C.DoesInputDefaultsExist
}; 



