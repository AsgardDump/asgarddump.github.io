#pragma once 
#include <ApparitionGhost_AIController_Structs.h>
 
 
 
// BlueprintGeneratedClass ApparitionGhost_AIController.ApparitionGhost_AIController_C
// Size: 0x354(Inherited: 0x328) 
struct AApparitionGhost_AIController_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x328(0x8)
	float ForceMove_Yep_4466A1C74AEDA6EB1D556ABAE6C71B92;  // 0x330(0x4)
	char ETimelineDirection ForceMove__Direction_4466A1C74AEDA6EB1D556ABAE6C71B92;  // 0x334(0x1)
	char pad_821[3];  // 0x335(0x3)
	struct UTimelineComponent* ForceMove;  // 0x338(0x8)
	struct APropXFormHolder_C* NavmeshHolder;  // 0x340(0x8)
	struct FVector Target;  // 0x348(0xC)

	void SetUpNavmeshHolder(); // Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.SetUpNavmeshHolder
	void ForceMove__FinishedFunc(); // Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.ForceMove__FinishedFunc
	void ForceMove__UpdateFunc(); // Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.ForceMove__UpdateFunc
	void OnFail_6E4EC364475E0CE6EF1CCC93D5491BE1(char EPathFollowingResult MovementResult); // Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.OnFail_6E4EC364475E0CE6EF1CCC93D5491BE1
	void OnSuccess_6E4EC364475E0CE6EF1CCC93D5491BE1(char EPathFollowingResult MovementResult); // Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.OnSuccess_6E4EC364475E0CE6EF1CCC93D5491BE1
	void ReceiveBeginPlay(); // Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.ReceiveBeginPlay
	void ExecuteUbergraph_ApparitionGhost_AIController(int32_t EntryPoint); // Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.ExecuteUbergraph_ApparitionGhost_AIController
}; 



