#pragma once 
#include <BP_Hunter_Ai_Van_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_Ai_Van.BP_Hunter_Ai_Van_C
// Size: 0x2698(Inherited: 0x2690) 
struct ABP_Hunter_Ai_Van_C : public ABP_Hunter_Ai_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2690(0x8)

	void ReceiveBeginPlay(); // Function BP_Hunter_Ai_Van.BP_Hunter_Ai_Van_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Hunter_Ai_Van(int32_t EntryPoint); // Function BP_Hunter_Ai_Van.BP_Hunter_Ai_Van_C.ExecuteUbergraph_BP_Hunter_Ai_Van
}; 



