#pragma once 
#include <Ai_IsAlive_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_IsAlive.Ai_IsAlive_C
// Size: 0xA0(Inherited: 0xA0) 
struct UAi_IsAlive_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_IsAlive.Ai_IsAlive_C.PerformConditionCheckAI
}; 



