#pragma once 
#include <BP_Gadget_TP_Radar_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_TP_Radar.BP_Gadget_TP_Radar_C
// Size: 0x250(Inherited: 0x233) 
struct ABP_Gadget_TP_Radar_C : public ABP_Gadget_TP_C
{
	char pad_563[5];  // 0x233(0x5)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UPointLightComponent* radarlite_THRP;  // 0x240(0x8)
	struct USkeletalMeshComponent* TP_Radar;  // 0x248(0x8)

	void GetSkeletalMesh(struct USkeletalMeshComponent*& SkeletalMesh); // Function BP_Gadget_TP_Radar.BP_Gadget_TP_Radar_C.GetSkeletalMesh
	void GetComponents(struct TArray<struct USceneComponent*>& Components); // Function BP_Gadget_TP_Radar.BP_Gadget_TP_Radar_C.GetComponents
	void UpdateVisibility(bool Hide, bool SkipAnimation, bool TickWhileHidden, bool NonLocallyControlledOrBot, bool ShouldInterrupt); // Function BP_Gadget_TP_Radar.BP_Gadget_TP_Radar_C.UpdateVisibility
	void ExecuteUbergraph_BP_Gadget_TP_Radar(int32_t EntryPoint); // Function BP_Gadget_TP_Radar.BP_Gadget_TP_Radar_C.ExecuteUbergraph_BP_Gadget_TP_Radar
}; 



