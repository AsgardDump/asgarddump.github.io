#pragma once 
#include <BP_Gadget_TP_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_TP.BP_Gadget_TP_C
// Size: 0x233(Inherited: 0x220) 
struct ABP_Gadget_TP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool Sprinting : 1;  // 0x230(0x1)
	char pad_561_1 : 7;  // 0x231(0x1)
	bool In Air : 1;  // 0x231(0x1)
	char pad_562_1 : 7;  // 0x232(0x1)
	bool Is Dead : 1;  // 0x232(0x1)

	void GetSkeletalMesh(struct USkeletalMeshComponent*& SkeletalMesh); // Function BP_Gadget_TP.BP_Gadget_TP_C.GetSkeletalMesh
	void GetComponents(struct TArray<struct USceneComponent*>& Components); // Function BP_Gadget_TP.BP_Gadget_TP_C.GetComponents
	void ChangeComponentTickSettings(struct USkeletalMeshComponent* InputPin, bool Should tick); // Function BP_Gadget_TP.BP_Gadget_TP_C.ChangeComponentTickSettings
	void OC_Startup(); // Function BP_Gadget_TP.BP_Gadget_TP_C.OC_Startup
	void UpdateVisibility(bool Hide, bool SkipAnimation, bool TickWhileHidden, bool NonLocallyControlledOrBot, bool ShouldInterrupt); // Function BP_Gadget_TP.BP_Gadget_TP_C.UpdateVisibility
	void Unequip(); // Function BP_Gadget_TP.BP_Gadget_TP_C.Unequip
	void FakeHolsterGadget(); // Function BP_Gadget_TP.BP_Gadget_TP_C.FakeHolsterGadget
	void FakeDrawGadget(); // Function BP_Gadget_TP.BP_Gadget_TP_C.FakeDrawGadget
	void Init(); // Function BP_Gadget_TP.BP_Gadget_TP_C.Init
	void Equip(); // Function BP_Gadget_TP.BP_Gadget_TP_C.Equip
	void HideFromGame(bool Hidden); // Function BP_Gadget_TP.BP_Gadget_TP_C.HideFromGame
	void SetVisibility(bool Visible, bool PropagateToChildren); // Function BP_Gadget_TP.BP_Gadget_TP_C.SetVisibility
	void SetOwnerStates(bool Sprinting, bool InAir, bool IsDead); // Function BP_Gadget_TP.BP_Gadget_TP_C.SetOwnerStates
	void Fire(); // Function BP_Gadget_TP.BP_Gadget_TP_C.Fire
	void StartHoldingFire(); // Function BP_Gadget_TP.BP_Gadget_TP_C.StartHoldingFire
	void StopHoldingFire(); // Function BP_Gadget_TP.BP_Gadget_TP_C.StopHoldingFire
	void ExecuteUbergraph_BP_Gadget_TP(int32_t EntryPoint); // Function BP_Gadget_TP.BP_Gadget_TP_C.ExecuteUbergraph_BP_Gadget_TP
}; 



