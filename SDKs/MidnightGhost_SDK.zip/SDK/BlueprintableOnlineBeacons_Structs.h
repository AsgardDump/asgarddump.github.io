#pragma once 
#include "SDK.h" 
 
 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.ConnectByIP
// Size: 0x18(Inherited: 0x0) 
struct FConnectByIP
{
	struct FString Address;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnClientDisconnected
// Size: 0x8(Inherited: 0x0) 
struct FOnClientDisconnected
{
	struct AOnlineBeaconBlueprint* Client;  // 0x0(0x8)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.DisconnectClient
// Size: 0x8(Inherited: 0x0) 
struct FDisconnectClient
{
	struct AOnlineBeaconBlueprint* Client;  // 0x0(0x8)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnNetworkFailure
// Size: 0x1(Inherited: 0x0) 
struct FOnNetworkFailure
{
	char ENetworkFailure FailureType;  // 0x0(0x1)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.ConnectBySession
// Size: 0x110(Inherited: 0x0) 
struct FConnectBySession
{
	struct FBlueprintSessionResult session;  // 0x0(0x108)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool ReturnValue : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.GetConnectedClients
// Size: 0x10(Inherited: 0x0) 
struct FGetConnectedClients
{
	struct TArray<struct AOnlineBeaconBlueprint*> ReturnValue;  // 0x0(0x10)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnConnectionStateChanged
// Size: 0x2(Inherited: 0x0) 
struct FOnConnectionStateChanged
{
	uint8_t  From;  // 0x0(0x1)
	uint8_t  To;  // 0x1(0x1)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.GetConnectionStateBlueprint
// Size: 0x1(Inherited: 0x0) 
struct FGetConnectionStateBlueprint
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnClientConnected
// Size: 0x8(Inherited: 0x0) 
struct FOnClientConnected
{
	struct AOnlineBeaconBlueprint* Client;  // 0x0(0x8)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StartHostingBeacon
// Size: 0x8(Inherited: 0x0) 
struct FStartHostingBeacon
{
	AOnlineBeaconClient* Class;  // 0x0(0x8)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconBlueprint.OnDisconnected
// Size: 0x1(Inherited: 0x0) 
struct FOnDisconnected
{
	uint8_t  Reason;  // 0x0(0x1)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.GetListenPort
// Size: 0x4(Inherited: 0x0) 
struct FGetListenPort
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.IsHostingBeacon
// Size: 0x10(Inherited: 0x0) 
struct FIsHostingBeacon
{
	AOnlineBeaconClient* Class;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StartHostingBeacons
// Size: 0x10(Inherited: 0x0) 
struct FStartHostingBeacons
{
	struct TArray<AOnlineBeaconClient*> Classes;  // 0x0(0x10)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StopHostingBeacon
// Size: 0x8(Inherited: 0x0) 
struct FStopHostingBeacon
{
	AOnlineBeaconClient* Class;  // 0x0(0x8)

}; 
// Function BlueprintableOnlineBeacons.OnlineBeaconSubsystem.StopHostingBeacons
// Size: 0x10(Inherited: 0x0) 
struct FStopHostingBeacons
{
	struct TArray<AOnlineBeaconClient*> Classes;  // 0x0(0x10)

}; 
