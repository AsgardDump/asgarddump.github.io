#pragma once 
#include "SDK.h" 
 
 
// Function BP_LightBulbA.BP_LightBulbA_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_LightBulbA.BP_LightBulbA_C.ExecuteUbergraph_BP_LightBulbA
// Size: 0x42(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LightBulbA
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xC(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x28(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x41(0x1)

}; 
