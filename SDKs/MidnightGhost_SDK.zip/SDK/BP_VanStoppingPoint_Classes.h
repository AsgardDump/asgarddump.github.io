#pragma once 
#include <BP_VanStoppingPoint_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_VanStoppingPoint.BP_VanStoppingPoint_C
// Size: 0x230(Inherited: 0x220) 
struct ABP_VanStoppingPoint_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)

	void ReceiveBeginPlay(); // Function BP_VanStoppingPoint.BP_VanStoppingPoint_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_VanStoppingPoint.BP_VanStoppingPoint_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_VanStoppingPoint(int32_t EntryPoint); // Function BP_VanStoppingPoint.BP_VanStoppingPoint_C.ExecuteUbergraph_BP_VanStoppingPoint
}; 



