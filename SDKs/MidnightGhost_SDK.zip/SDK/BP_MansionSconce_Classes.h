#pragma once 
#include <BP_MansionSconce_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MansionSconce.BP_MansionSconce_C
// Size: 0x250(Inherited: 0x220) 
struct ABP_MansionSconce_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* SM_LightSconce;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Timeline_0_PercentDone_9C1C958742E87421034844855386DA8D;  // 0x238(0x4)
	char ETimelineDirection Timeline_0__Direction_9C1C958742E87421034844855386DA8D;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x240(0x8)
	struct UMaterialInstanceDynamic* RedMtl;  // 0x248(0x8)

	void Timeline_0__FinishedFunc(); // Function BP_MansionSconce.BP_MansionSconce_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_MansionSconce.BP_MansionSconce_C.Timeline_0__UpdateFunc
	void PreMidnightFlutter(float FlutterIntensity); // Function BP_MansionSconce.BP_MansionSconce_C.PreMidnightFlutter
	void FadeBackRed(float PercentDone); // Function BP_MansionSconce.BP_MansionSconce_C.FadeBackRed
	void ResetIntensity(); // Function BP_MansionSconce.BP_MansionSconce_C.ResetIntensity
	void GoMidnight(float RedIntensityDivider); // Function BP_MansionSconce.BP_MansionSconce_C.GoMidnight
	void InitDynamicMtl(); // Function BP_MansionSconce.BP_MansionSconce_C.InitDynamicMtl
	void ExecuteUbergraph_BP_MansionSconce(int32_t EntryPoint); // Function BP_MansionSconce.BP_MansionSconce_C.ExecuteUbergraph_BP_MansionSconce
}; 



