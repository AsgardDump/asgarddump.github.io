#pragma once 
#include "SDK.h" 
 
 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftShift_K2Node_InputKeyEvent_21
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftShift_K2Node_InputKeyEvent_21
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Backward_K2Node_InputAxisEvent_25
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Move Backward_K2Node_InputAxisEvent_25
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Look_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Look_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_48
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Turn_K2Node_InputAxisEvent_48
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.ExecuteUbergraph_BP_Spectator
// Size: 0x1581(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Spectator
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputKeyEvent_Key_5;  // 0x8(0x18)
	struct FKey K2Node_InputKeyEvent_Key_4;  // 0x20(0x18)
	struct FKey Temp_struct_Variable;  // 0x38(0x18)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x50(0x18)
	int32_t Temp_int_Variable;  // 0x68(0x4)
	char EDepthOfFieldMethod Temp_byte_Variable;  // 0x6C(0x1)
	char EDepthOfFieldMethod Temp_byte_Variable_2;  // 0x6D(0x1)
	char EDepthOfFieldMethod Temp_byte_Variable_3;  // 0x6E(0x1)
	char pad_111[1];  // 0x6F(0x1)
	struct USpectator_UI_C* CallFunc_Create_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool Temp_bool_Variable : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x7A(0x1)
	char pad_123[5];  // 0x7B(0x5)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x80(0x18)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x98(0x18)
	struct UDamageLog_UI_C* CallFunc_Create_ReturnValue_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UDamageLog_UI_C* CallFunc_Create_ReturnValue_3;  // 0xC0(0x8)
	char Team Temp_byte_Variable_4;  // 0xC8(0x1)
	char EDepthOfFieldMethod Temp_byte_Variable_5;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0xCA(0x1)
	char pad_203_1 : 7;  // 0xCB(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0xCB(0x1)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xD0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xD4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xD8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xDC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct FKey Temp_struct_Variable_2;  // 0xE8(0x18)
	struct FKey K2Node_InputKeyEvent_Key_17;  // 0x100(0x18)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x118(0x4)
	char pad_284[4];  // 0x11C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_6;  // 0x120(0x18)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x138(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x13C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x140(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x144(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x148(0x4)
	char pad_332[4];  // 0x14C(0x4)
	struct FKey Temp_struct_Variable_3;  // 0x150(0x18)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0x168(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x16C(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x170(0x4)
	char pad_372[4];  // 0x174(0x4)
	struct FKey K2Node_InputKeyEvent_Key_7;  // 0x178(0x18)
	struct FKey K2Node_InputKeyEvent_Key_18;  // 0x190(0x18)
	int32_t Temp_int_Loop_Counter_Variable_6;  // 0x1A8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0x1AC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_7;  // 0x1B0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_7;  // 0x1B4(0x4)
	int32_t Temp_int_Array_Index_Variable_5;  // 0x1B8(0x4)
	int32_t Temp_int_Array_Index_Variable_6;  // 0x1BC(0x4)
	struct FKey Temp_struct_Variable_4;  // 0x1C0(0x18)
	struct FKey K2Node_InputKeyEvent_Key_19;  // 0x1D8(0x18)
	int32_t Temp_int_Loop_Counter_Variable_8;  // 0x1F0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_8;  // 0x1F4(0x4)
	int32_t Temp_int_Array_Index_Variable_7;  // 0x1F8(0x4)
	char pad_508[4];  // 0x1FC(0x4)
	struct FKey K2Node_InputKeyEvent_Key_8;  // 0x200(0x18)
	int32_t Temp_int_Loop_Counter_Variable_9;  // 0x218(0x4)
	char pad_540[4];  // 0x21C(0x4)
	struct FKey Temp_struct_Variable_5;  // 0x220(0x18)
	int32_t CallFunc_Add_IntInt_ReturnValue_9;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_20;  // 0x240(0x18)
	int32_t Temp_int_Array_Index_Variable_8;  // 0x258(0x4)
	int32_t Temp_int_Loop_Counter_Variable_10;  // 0x25C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_10;  // 0x260(0x4)
	int32_t Temp_int_Array_Index_Variable_9;  // 0x264(0x4)
	struct FKey K2Node_InputKeyEvent_Key_9;  // 0x268(0x18)
	struct FKey K2Node_InputKeyEvent_Key_21;  // 0x280(0x18)
	struct FKey K2Node_InputActionEvent_Key;  // 0x298(0x18)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x2B0(0x18)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	int32_t Temp_int_Array_Index_Variable_10;  // 0x2CC(0x4)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x2D0(0x1)
	char pad_721[7];  // 0x2D1(0x7)
	struct FKey Temp_struct_Variable_6;  // 0x2D8(0x18)
	char HunterSpec K2Node_CustomEvent_SelectedHunterSpec;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct ABP_DefaultSpectator_C* K2Node_CustomEvent_BPFS_3;  // 0x2F8(0x8)
	struct FKey K2Node_InputKeyEvent_Key_22;  // 0x300(0x18)
	struct FKey Temp_struct_Variable_7;  // 0x318(0x18)
	struct ABP_DefaultSpectator_C* K2Node_CustomEvent_BPFS_2;  // 0x330(0x8)
	struct TArray<struct AProp_C*> K2Node_CustomEvent_All_Ghosts;  // 0x338(0x10)
	int32_t K2Node_CustomEvent_Index;  // 0x348(0x4)
	char pad_844[4];  // 0x34C(0x4)
	struct FKey K2Node_InputKeyEvent_Key_10;  // 0x350(0x18)
	struct AProp_C* CallFunc_Array_Get_Item;  // 0x368(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x370(0x8)
	struct FVector CallFunc_BreakTransform_Location;  // 0x378(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x384(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x390(0xC)
	char pad_924[4];  // 0x39C(0x4)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x3A0(0x8)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x3A8(0x1)
	char pad_937[3];  // 0x3A9(0x3)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x3AC(0x88)
	char pad_1076_1 : 7;  // 0x434(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x434(0x1)
	char pad_1077[3];  // 0x435(0x3)
	int32_t Temp_int_Array_Index_Variable_11;  // 0x438(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x43C(0x4)
	char GhostAbility K2Node_CustomEvent_SelectedGhostSpec;  // 0x440(0x1)
	char pad_1089[7];  // 0x441(0x7)
	struct ABP_DefaultSpectator_C* K2Node_CustomEvent_BPFS;  // 0x448(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_11;  // 0x450(0x4)
	char pad_1108[4];  // 0x454(0x4)
	struct FKey K2Node_InputKeyEvent_Key_23;  // 0x458(0x18)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool K2Node_CustomEvent_Off_on : 1;  // 0x470(0x1)
	char pad_1137[3];  // 0x471(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x474(0xC)
	char pad_1152_1 : 7;  // 0x480(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x480(0x1)
	char pad_1153[7];  // 0x481(0x7)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x488(0x10)
	char pad_1176_1 : 7;  // 0x498(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x498(0x1)
	char pad_1177[7];  // 0x499(0x7)
	struct TArray<struct UTip_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x4A0(0x10)
	struct TArray<struct UTip_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_2;  // 0x4B0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4C0(0x4)
	char pad_1220[4];  // 0x4C4(0x4)
	struct UTip_UI_C* CallFunc_Array_Get_Item_2;  // 0x4C8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x4D0(0x4)
	int32_t Temp_int_Loop_Counter_Variable_11;  // 0x4D4(0x4)
	struct UTip_UI_C* CallFunc_Create_ReturnValue_4;  // 0x4D8(0x8)
	char pad_1248_1 : 7;  // 0x4E0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4E0(0x1)
	char pad_1249[3];  // 0x4E1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_12;  // 0x4E4(0x4)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x4E8(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_2;  // 0x4F0(0x8)
	char pad_1272_1 : 7;  // 0x4F8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x4F8(0x1)
	char pad_1273[7];  // 0x4F9(0x7)
	struct AController* CallFunc_GetController_ReturnValue_3;  // 0x500(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x508(0x8)
	char pad_1296_1 : 7;  // 0x510(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x510(0x1)
	char pad_1297[3];  // 0x511(0x3)
	int32_t Temp_int_Loop_Counter_Variable_12;  // 0x514(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_13;  // 0x518(0x4)
	char pad_1308[4];  // 0x51C(0x4)
	struct TArray<struct USpectator_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_3;  // 0x520(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x530(0x4)
	char pad_1332_1 : 7;  // 0x534(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x534(0x1)
	char pad_1333[3];  // 0x535(0x3)
	struct AController* CallFunc_GetController_ReturnValue_4;  // 0x538(0x8)
	struct FKey K2Node_InputKeyEvent_Key_24;  // 0x540(0x18)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP_2;  // 0x558(0x8)
	char pad_1376_1 : 7;  // 0x560(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x560(0x1)
	char pad_1377[7];  // 0x561(0x7)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x568(0x10)
	struct FKey K2Node_InputKeyEvent_Key_25;  // 0x578(0x18)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x590(0x1)
	char pad_1425_1 : 7;  // 0x591(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x591(0x1)
	char pad_1426[6];  // 0x592(0x6)
	struct FKey K2Node_InputKeyEvent_Key_11;  // 0x598(0x18)
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x5B0(0x1)
	char pad_1457[3];  // 0x5B1(0x3)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x5B4(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x5C0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x5CC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x5D8(0xC)
	char pad_1508_1 : 7;  // 0x5E4(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x5E4(0x1)
	char pad_1509[3];  // 0x5E5(0x3)
	struct TArray<struct UEquipmentIcons_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_4;  // 0x5E8(0x10)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_2;  // 0x5F8(0x10)
	struct UEquipmentIcons_UI_C* CallFunc_Array_Get_Item_3;  // 0x608(0x8)
	struct FHitResult CallFunc_CapsuleTraceSingleForObjects_OutHit;  // 0x610(0x88)
	char pad_1688_1 : 7;  // 0x698(0x1)
	bool CallFunc_CapsuleTraceSingleForObjects_ReturnValue : 1;  // 0x698(0x1)
	char pad_1689_1 : 7;  // 0x699(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x699(0x1)
	char pad_1690_1 : 7;  // 0x69A(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x69A(0x1)
	char pad_1691[1];  // 0x69B(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x69C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x6A0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x6A4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x6B0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x6BC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x6C8(0xC)
	char pad_1748[4];  // 0x6D4(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x6D8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x6E0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x6E8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x6F0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x6F8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x6FC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x700(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x704(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x710(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x71C(0x4)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0x720(0x8)
	char pad_1832_1 : 7;  // 0x728(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x728(0x1)
	char pad_1833_1 : 7;  // 0x729(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x729(0x1)
	char pad_1834_1 : 7;  // 0x72A(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x72A(0x1)
	char pad_1835[5];  // 0x72B(0x5)
	struct TArray<struct ALvlProp_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x730(0x10)
	struct ALvlProp_C* CallFunc_Array_Get_Item_4;  // 0x740(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x748(0x4)
	char pad_1868_1 : 7;  // 0x74C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x74C(0x1)
	char pad_1869[3];  // 0x74D(0x3)
	int32_t Temp_int_Array_Index_Variable_12;  // 0x750(0x4)
	char pad_1876[4];  // 0x754(0x4)
	struct TArray<struct UCosmeticActionsInput_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_5;  // 0x758(0x10)
	struct UTip_UI_C* CallFunc_Array_Get_Item_5;  // 0x768(0x8)
	struct UCosmeticActionsInput_UI_C* CallFunc_Array_Get_Item_6;  // 0x770(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_6;  // 0x778(0x4)
	char pad_1916_1 : 7;  // 0x77C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0x77C(0x1)
	char pad_1917[3];  // 0x77D(0x3)
	struct TArray<struct UInteract_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_6;  // 0x780(0x10)
	struct AController* CallFunc_GetController_ReturnValue_5;  // 0x790(0x8)
	struct UInteract_UI_C* CallFunc_Array_Get_Item_7;  // 0x798(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP_3;  // 0x7A0(0x8)
	char pad_1960_1 : 7;  // 0x7A8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x7A8(0x1)
	char pad_1961[3];  // 0x7A9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_7;  // 0x7AC(0x4)
	char pad_1968_1 : 7;  // 0x7B0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_6 : 1;  // 0x7B0(0x1)
	char pad_1969[7];  // 0x7B1(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x7B8(0x8)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP;  // 0x7C0(0x8)
	char pad_1992_1 : 7;  // 0x7C8(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x7C8(0x1)
	char pad_1993_1 : 7;  // 0x7C9(0x1)
	bool CallFunc_CheckIfCanDebug_No___Yes : 1;  // 0x7C9(0x1)
	char pad_1994[2];  // 0x7CA(0x2)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x7CC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x7D0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x7D4(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x7D8(0x4)
	float K2Node_CustomEvent_Focal_Distance;  // 0x7DC(0x4)
	float K2Node_CustomEvent_Focal_Region;  // 0x7E0(0x4)
	float K2Node_CustomEvent_DOFScale;  // 0x7E4(0x4)
	float K2Node_CustomEvent_NearTransition;  // 0x7E8(0x4)
	float K2Node_CustomEvent_FarTransition;  // 0x7EC(0x4)
	float K2Node_CustomEvent_MaxBokehSize;  // 0x7F0(0x4)
	float K2Node_CustomEvent_PostProcessBlend;  // 0x7F4(0x4)
	int32_t K2Node_CustomEvent_DOFMethod_0_3;  // 0x7F8(0x4)
	char pad_2044_1 : 7;  // 0x7FC(0x1)
	bool K2Node_CustomEvent_UseCineCam : 1;  // 0x7FC(0x1)
	char pad_2045[3];  // 0x7FD(0x3)
	float K2Node_CustomEvent_MinFSTOP;  // 0x800(0x4)
	float K2Node_CustomEvent_MaxFSTOP;  // 0x804(0x4)
	float K2Node_CustomEvent_ManualFocusDistance;  // 0x808(0x4)
	char pad_2060_1 : 7;  // 0x80C(0x1)
	bool K2Node_Select_Default : 1;  // 0x80C(0x1)
	char EDepthOfFieldMethod K2Node_Select_Default_2;  // 0x80D(0x1)
	char pad_2062[2];  // 0x80E(0x2)
	struct TArray<struct UGhostRez_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_7;  // 0x810(0x10)
	struct UGhostRez_UI_C* CallFunc_Array_Get_Item_8;  // 0x820(0x8)
	char pad_2088[8];  // 0x828(0x8)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings;  // 0x830(0x560)
	int32_t CallFunc_Array_Length_ReturnValue_8;  // 0xD90(0x4)
	char pad_3476[4];  // 0xD94(0x4)
	struct TArray<struct ABP_ResurrectableGhost_C*> CallFunc_GetAllActorsOfClass_OutActors_2;  // 0xD98(0x10)
	char pad_3496_1 : 7;  // 0xDA8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_7 : 1;  // 0xDA8(0x1)
	char pad_3497[7];  // 0xDA9(0x7)
	struct ABP_ResurrectableGhost_C* CallFunc_Array_Get_Item_9;  // 0xDB0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_9;  // 0xDB8(0x4)
	char pad_3516_1 : 7;  // 0xDBC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_8 : 1;  // 0xDBC(0x1)
	char pad_3517[3];  // 0xDBD(0x3)
	struct TArray<struct UHunterRez_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_8;  // 0xDC0(0x10)
	int32_t Temp_int_Loop_Counter_Variable_13;  // 0xDD0(0x4)
	char pad_3540[4];  // 0xDD4(0x4)
	struct UHunterRez_UI_C* CallFunc_Array_Get_Item_10;  // 0xDD8(0x8)
	char pad_3552_1 : 7;  // 0xDE0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_9 : 1;  // 0xDE0(0x1)
	char pad_3553[3];  // 0xDE1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_14;  // 0xDE4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_10;  // 0xDE8(0x4)
	char pad_3564[4];  // 0xDEC(0x4)
	struct TArray<struct USoulConsume_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_9;  // 0xDF0(0x10)
	char pad_3584_1 : 7;  // 0xE00(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_10 : 1;  // 0xE00(0x1)
	char pad_3585[7];  // 0xE01(0x7)
	struct USoulConsume_UI_C* CallFunc_Array_Get_Item_11;  // 0xE08(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_11;  // 0xE10(0x4)
	char pad_3604[4];  // 0xE14(0x4)
	struct FText Temp_text_Variable;  // 0xE18(0x18)
	char pad_3632_1 : 7;  // 0xE30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_11 : 1;  // 0xE30(0x1)
	char pad_3633[7];  // 0xE31(0x7)
	struct TArray<struct UGhostPossessAbility_UI_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_10;  // 0xE38(0x10)
	struct FKey Temp_struct_Variable_8;  // 0xE48(0x18)
	struct UGhostPossessAbility_UI_C* CallFunc_Array_Get_Item_12;  // 0xE60(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_12;  // 0xE68(0x4)
	char pad_3692_1 : 7;  // 0xE6C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_12 : 1;  // 0xE6C(0x1)
	char pad_3693[3];  // 0xE6D(0x3)
	struct TArray<struct AMGH_PlayerState_C*> CallFunc_Get_All_CPS_All;  // 0xE70(0x10)
	struct TArray<struct AMGH_PlayerState_C*> CallFunc_Get_All_CPS_Ghosts;  // 0xE80(0x10)
	struct TArray<struct AMGH_PlayerState_C*> CallFunc_Get_All_CPS_Hunters;  // 0xE90(0x10)
	struct FKey K2Node_InputKeyEvent_Key_12;  // 0xEA0(0x18)
	int32_t Temp_int_Array_Index_Variable_13;  // 0xEB8(0x4)
	char pad_3772[4];  // 0xEBC(0x4)
	struct USpectator_UI_C* CallFunc_Array_Get_Item_13;  // 0xEC0(0x8)
	char pad_3784_1 : 7;  // 0xEC8(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0xEC8(0x1)
	char pad_3785[7];  // 0xEC9(0x7)
	struct AController* CallFunc_GetController_ReturnValue_6;  // 0xED0(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP_4;  // 0xED8(0x8)
	char pad_3808_1 : 7;  // 0xEE0(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0xEE0(0x1)
	char pad_3809[7];  // 0xEE1(0x7)
	struct FString CallFunc_GetMGHPlayerName_Player_Name;  // 0xEE8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xEF8(0x18)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0xF10(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xF20(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0xF30(0x18)
	struct FText K2Node_Select_Default_3;  // 0xF48(0x18)
	struct FKey K2Node_InputKeyEvent_Key_13;  // 0xF60(0x18)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0xF78(0xC)
	float CallFunc_BreakRotator_Roll;  // 0xF84(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0xF88(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xF8C(0x4)
	float CallFunc_BreakRotator_Roll_2;  // 0xF90(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0xF94(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0xF98(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xF9C(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0xFA8(0xC)
	char pad_4020[4];  // 0xFB4(0x4)
	struct AController* CallFunc_GetController_ReturnValue_7;  // 0xFB8(0x8)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0xFC0(0x88)
	float K2Node_InputAxisEvent_AxisValue_8;  // 0x1048(0x4)
	float CallFunc_BreakRotator_Roll_3;  // 0x104C(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x1050(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x1054(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x1058(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0x105C(0xC)
	float K2Node_InputAxisEvent_AxisValue_7;  // 0x1068(0x4)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x106C(0x88)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x10F4(0x4)
	struct FVector CallFunc_GetActorUpVector_ReturnValue;  // 0x10F8(0xC)
	struct FVector CallFunc_GetActorUpVector_ReturnValue_2;  // 0x1104(0xC)
	float K2Node_CustomEvent_MotionBlur;  // 0x1110(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x1114(0xC)
	float K2Node_CustomEvent_FOV;  // 0x1120(0x4)
	char pad_4388_1 : 7;  // 0x1124(0x1)
	bool K2Node_CustomEvent_Invert__2 : 1;  // 0x1124(0x1)
	char pad_4389_1 : 7;  // 0x1125(0x1)
	bool K2Node_CustomEvent_Invert_ : 1;  // 0x1125(0x1)
	char pad_4390[2];  // 0x1126(0x2)
	float K2Node_InputAxisEvent_AxisValue_6;  // 0x1128(0x4)
	float K2Node_InputAxisEvent_AxisValue_5;  // 0x112C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x1130(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x1134(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x1138(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x113C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x1140(0x4)
	float K2Node_Select_Default_4;  // 0x1144(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_3;  // 0x1148(0x4)
	char pad_4428[4];  // 0x114C(0x4)
	struct AController* CallFunc_GetController_ReturnValue_8;  // 0x1150(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_2;  // 0x1158(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP_5;  // 0x1160(0x8)
	char pad_4456_1 : 7;  // 0x1168(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x1168(0x1)
	char pad_4457[7];  // 0x1169(0x7)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP_2;  // 0x1170(0x8)
	char pad_4472_1 : 7;  // 0x1178(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x1178(0x1)
	char pad_4473[7];  // 0x1179(0x7)
	struct TScriptInterface<IPropInterface_C> K2Node_DynamicCast_AsProp_Interface;  // 0x1180(0x10)
	char pad_4496_1 : 7;  // 0x1190(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x1190(0x1)
	char pad_4497_1 : 7;  // 0x1191(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_2 : 1;  // 0x1191(0x1)
	char pad_4498[6];  // 0x1192(0x6)
	struct FKey Temp_struct_Variable_9;  // 0x1198(0x18)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_3;  // 0x11B0(0x8)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP_3;  // 0x11B8(0x8)
	char pad_4544_1 : 7;  // 0x11C0(0x1)
	bool K2Node_DynamicCast_bSuccess_12 : 1;  // 0x11C0(0x1)
	char pad_4545[3];  // 0x11C1(0x3)
	float K2Node_InputAxisEvent_AxisValue_4;  // 0x11C4(0x4)
	float K2Node_InputAxisEvent_AxisValue_3;  // 0x11C8(0x4)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x11CC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0x11D0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_9;  // 0x11D4(0x4)
	float K2Node_InputAxisEvent_AxisValue;  // 0x11D8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_10;  // 0x11DC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_11;  // 0x11E0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x11E4(0x4)
	struct FVector CallFunc_GetActorRightVector_ReturnValue;  // 0x11E8(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x11F4(0xC)
	struct TArray<struct AProp_C*> CallFunc_GetAllActorsOfClass_OutActors_3;  // 0x1200(0x10)
	struct AProp_C* CallFunc_Array_Get_Item_14;  // 0x1210(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_13;  // 0x1218(0x4)
	char pad_4636_1 : 7;  // 0x121C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_13 : 1;  // 0x121C(0x1)
	char pad_4637[3];  // 0x121D(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1220(0xC)
	char pad_4652[4];  // 0x122C(0x4)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x1230(0x8)
	struct FVector CallFunc_GetCameraLocation_ReturnValue;  // 0x1238(0xC)
	float CallFunc_BreakVector_X;  // 0x1244(0x4)
	float CallFunc_BreakVector_Y;  // 0x1248(0x4)
	float CallFunc_BreakVector_Z;  // 0x124C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1250(0x4)
	char pad_4692_1 : 7;  // 0x1254(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x1254(0x1)
	char pad_4693[3];  // 0x1255(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x1258(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x1264(0xC)
	struct FVector CallFunc_Conv_RotatorToVector_ReturnValue;  // 0x1270(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x127C(0xC)
	char pad_4744_1 : 7;  // 0x1288(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x1288(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x1289(0x1)
	char pad_4746_1 : 7;  // 0x128A(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x128A(0x1)
	char pad_4747[5];  // 0x128B(0x5)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_4;  // 0x1290(0x8)
	struct UBP_MGH_Instance_C* K2Node_DynamicCast_AsBP_MGH_Instance;  // 0x1298(0x8)
	char pad_4768_1 : 7;  // 0x12A0(0x1)
	bool K2Node_DynamicCast_bSuccess_13 : 1;  // 0x12A0(0x1)
	char pad_4769_1 : 7;  // 0x12A1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x12A1(0x1)
	char pad_4770[2];  // 0x12A2(0x2)
	float K2Node_Select_Default_5;  // 0x12A4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_12;  // 0x12A8(0x4)
	char pad_4780_1 : 7;  // 0x12AC(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x12AC(0x1)
	char pad_4781[3];  // 0x12AD(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_13;  // 0x12B0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_14;  // 0x12B4(0x4)
	float K2Node_Select_Default_6;  // 0x12B8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x12BC(0x4)
	char Team CallFunc_GetMyTeam_Team;  // 0x12C0(0x1)
	char Team CallFunc_GetMyTeam_Team_2;  // 0x12C1(0x1)
	char pad_4802_1 : 7;  // 0x12C2(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x12C2(0x1)
	char Team CallFunc_GetMyTeam_Team_3;  // 0x12C3(0x1)
	char pad_4804[4];  // 0x12C4(0x4)
	struct TArray<struct AMGH_PlayerState_C*> K2Node_Select_Default_7;  // 0x12C8(0x10)
	char pad_4824_1 : 7;  // 0x12D8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x12D8(0x1)
	char pad_4825[7];  // 0x12D9(0x7)
	struct AMGH_PlayerState_C* CallFunc_Array_Get_Item_15;  // 0x12E0(0x8)
	struct AMGH_PlayerState_C* CallFunc_Array_Get_Item_16;  // 0x12E8(0x8)
	char pad_4848_1 : 7;  // 0x12F0(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x12F0(0x1)
	char pad_4849_1 : 7;  // 0x12F1(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x12F1(0x1)
	char Team CallFunc_GetMyTeam_Team_4;  // 0x12F2(0x1)
	char Team CallFunc_GetMyTeam_Team_5;  // 0x12F3(0x1)
	char pad_4852_1 : 7;  // 0x12F4(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_3 : 1;  // 0x12F4(0x1)
	char pad_4853_1 : 7;  // 0x12F5(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x12F5(0x1)
	char pad_4854[2];  // 0x12F6(0x2)
	struct FKey K2Node_InputKeyEvent_Key_14;  // 0x12F8(0x18)
	char Team CallFunc_GetMyTeam_Team_6;  // 0x1310(0x1)
	char pad_4881[7];  // 0x1311(0x7)
	struct AController* CallFunc_GetController_ReturnValue_9;  // 0x1318(0x8)
	char pad_4896_1 : 7;  // 0x1320(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_4 : 1;  // 0x1320(0x1)
	char pad_4897[7];  // 0x1321(0x7)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP_6;  // 0x1328(0x8)
	char pad_4912_1 : 7;  // 0x1330(0x1)
	bool K2Node_DynamicCast_bSuccess_14 : 1;  // 0x1330(0x1)
	char pad_4913[7];  // 0x1331(0x7)
	struct AController* CallFunc_GetController_ReturnValue_10;  // 0x1338(0x8)
	struct AMGH_HUD_C* CallFunc_Get_MGH_Hud_MGH_HUD;  // 0x1340(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP_7;  // 0x1348(0x8)
	char pad_4944_1 : 7;  // 0x1350(0x1)
	bool K2Node_DynamicCast_bSuccess_15 : 1;  // 0x1350(0x1)
	char pad_4945_1 : 7;  // 0x1351(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x1351(0x1)
	char pad_4946[2];  // 0x1352(0x2)
	struct FVector CallFunc_GetInterpTargetVector_Vector_Target;  // 0x1354(0xC)
	char pad_4960_1 : 7;  // 0x1360(0x1)
	bool CallFunc_GetInterpTargetVector_Close_To_0_0_0_ : 1;  // 0x1360(0x1)
	char pad_4961_1 : 7;  // 0x1361(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1361(0x1)
	char pad_4962[2];  // 0x1362(0x2)
	struct FVector CallFunc_VInterpTo_ReturnValue;  // 0x1364(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_2;  // 0x1370(0x88)
	char pad_5112_1 : 7;  // 0x13F8(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_2 : 1;  // 0x13F8(0x1)
	char pad_5113[7];  // 0x13F9(0x7)
	struct FCameraFocusSettings K2Node_MakeStruct_CameraFocusSettings;  // 0x1400(0x58)
	struct FCameraLensSettings K2Node_MakeStruct_CameraLensSettings;  // 0x1458(0x18)
	struct FKey K2Node_InputKeyEvent_Key_15;  // 0x1470(0x18)
	struct FKey Temp_struct_Variable_10;  // 0x1488(0x18)
	struct FKey K2Node_InputKeyEvent_Key_16;  // 0x14A0(0x18)
	struct AMGH_PlayerState_C* K2Node_CustomEvent_MGH_Player_State;  // 0x14B8(0x8)
	char pad_5312_1 : 7;  // 0x14C0(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0x14C0(0x1)
	char pad_5313[15];  // 0x14C1(0xF)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x14D0(0x30)
	struct UCineCameraComponent* CallFunc_AddComponent_ReturnValue;  // 0x1500(0x8)
	struct AController* CallFunc_GetController_ReturnValue_11;  // 0x1508(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_15;  // 0x1510(0x4)
	char pad_5396[4];  // 0x1514(0x4)
	struct TScriptInterface<IMGHPlayerController_Interface_C> K2Node_DynamicCast_AsMGHPlayer_Controller_Interface;  // 0x1518(0x10)
	char pad_5416_1 : 7;  // 0x1528(0x1)
	bool K2Node_DynamicCast_bSuccess_16 : 1;  // 0x1528(0x1)
	char pad_5417[3];  // 0x1529(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_4;  // 0x152C(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_16;  // 0x1538(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_5;  // 0x153C(0xC)
	struct UUserWidget* CallFunc_CreateBeginUIDebug_Ref;  // 0x1548(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x1550(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x1558(0x8)
	char pad_5472_1 : 7;  // 0x1560(0x1)
	bool K2Node_DynamicCast_bSuccess_17 : 1;  // 0x1560(0x1)
	char pad_5473[7];  // 0x1561(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x1568(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x1570(0x8)
	char pad_5496_1 : 7;  // 0x1578(0x1)
	bool K2Node_DynamicCast_bSuccess_18 : 1;  // 0x1578(0x1)
	char pad_5497[3];  // 0x1579(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x157C(0x4)
	char pad_5504_1 : 7;  // 0x1580(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x1580(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.Get All CPS
// Size: 0xA5(Inherited: 0x0) 
struct FGet All CPS
{
	struct TArray<struct AMGH_PlayerState_C*> All;  // 0x0(0x10)
	struct TArray<struct AMGH_PlayerState_C*> Ghosts;  // 0x10(0x10)
	struct TArray<struct AMGH_PlayerState_C*> Hunters;  // 0x20(0x10)
	struct TArray<struct AMGH_PlayerState_C*> AllPlayers;  // 0x30(0x10)
	struct TArray<struct AMGH_PlayerState_C*> HunterPlayers;  // 0x40(0x10)
	struct TArray<struct AMGH_PlayerState_C*> GhostPlayers;  // 0x50(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x60(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x64(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x70(0x8)
	struct TArray<struct AMGH_PlayerState_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x78(0x10)
	struct AMGH_PlayerState_C* CallFunc_Array_Get_Item;  // 0x88(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x95(0x1)
	char pad_150[2];  // 0x96(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x98(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x9C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xA4(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_R_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_R_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.AiDebugSelectWhoToSpectate
// Size: 0x8(Inherited: 0x0) 
struct FAiDebugSelectWhoToSpectate
{
	struct AMGH_PlayerState_C* MGH Player State;  // 0x0(0x8)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_RightAlt_K2Node_InputKeyEvent_22
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RightAlt_K2Node_InputKeyEvent_22
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Forward_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Move Forward_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Left_K2Node_InputAxisEvent_81
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Move Left_K2Node_InputAxisEvent_81
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Move Right_K2Node_InputAxisEvent_62
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Move Right_K2Node_InputAxisEvent_62
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.SetMouseInvertY
// Size: 0x1(Inherited: 0x0) 
struct FSetMouseInvertY
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Invert? : 1;  // 0x0(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.SetMouseInvertX
// Size: 0x1(Inherited: 0x0) 
struct FSetMouseInvertX
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Invert? : 1;  // 0x0(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.SetCameraFOV
// Size: 0x4(Inherited: 0x0) 
struct FSetCameraFOV
{
	float FOV;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.SetMotionBlur
// Size: 0x4(Inherited: 0x0) 
struct FSetMotionBlur
{
	float MotionBlur;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Spectator Move Downward_K2Node_InputAxisEvent_4
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Spectator Move Downward_K2Node_InputAxisEvent_4
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Five_K2Node_InputKeyEvent_7
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Five_K2Node_InputKeyEvent_7
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpAxisEvt_Spectator Move Upward_K2Node_InputAxisEvent_3
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Spectator Move Upward_K2Node_InputAxisEvent_3
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Six_K2Node_InputKeyEvent_9
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Six_K2Node_InputKeyEvent_9
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.SetDOFData
// Size: 0x30(Inherited: 0x0) 
struct FSetDOFData
{
	float Focal Distance;  // 0x0(0x4)
	float Focal Region;  // 0x4(0x4)
	float DOFScale;  // 0x8(0x4)
	float NearTransition;  // 0xC(0x4)
	float FarTransition;  // 0x10(0x4)
	float MaxBokehSize;  // 0x14(0x4)
	float PostProcessBlend;  // 0x18(0x4)
	int32_t DOFMethod 0-2;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool UseCineCam : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float MinFStop;  // 0x24(0x4)
	float MaxFStop;  // 0x28(0x4)
	float ManualFocusDistance;  // 0x2C(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.GetMGHPlayerState
// Size: 0x19(Inherited: 0x0) 
struct FGetMGHPlayerState
{
	struct AMGH_PlayerState_C* MGH Player State;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AMGH_PlayerState_C* K2Node_DynamicCast_AsMGH_Player_State;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_RightAlt_K2Node_InputKeyEvent_23
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RightAlt_K2Node_InputKeyEvent_23
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.Toggle_SpectatingLock
// Size: 0x1(Inherited: 0x0) 
struct FToggle_SpectatingLock
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool On : 1;  // 0x0(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.Set_SelectedGhostClass
// Size: 0x10(Inherited: 0x0) 
struct FSet_SelectedGhostClass
{
	char GhostAbility SelectedGhostSpec;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_DefaultSpectator_C* BPFS;  // 0x8(0x8)

}; 
// Function BP_Spectator.BP_Spectator_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_10
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_10
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.Server_TeleportToNextGhost
// Size: 0x1C(Inherited: 0x0) 
struct FServer_TeleportToNextGhost
{
	struct ABP_DefaultSpectator_C* BPFS;  // 0x0(0x8)
	struct TArray<struct AProp_C*> All Ghosts;  // 0x8(0x10)
	int32_t Index;  // 0x18(0x4)

}; 
// Function BP_Spectator.BP_Spectator_C.Set_SelectedHunterClass
// Size: 0x10(Inherited: 0x0) 
struct FSet_SelectedHunterClass
{
	char HunterSpec SelectedHunterSpec;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_DefaultSpectator_C* BPFS;  // 0x8(0x8)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Three_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Three_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Nine_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Four_K2Node_InputKeyEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Four_K2Node_InputKeyEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Four_K2Node_InputKeyEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Four_K2Node_InputKeyEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.LoadMouseSettings
// Size: 0xB1(Inherited: 0x0) 
struct FLoadMouseSettings
{
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x0(0x8)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USaveGame* CallFunc_MGH_LoadFromSlot_Loaded_Game;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_MGH_LoadFromSlot_Successful : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct USaveGame* CallFunc_MGH_LoadFromSlot_Loaded_Game_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_MGH_LoadFromSlot_Successful_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct USettingsSliders_C* K2Node_DynamicCast_AsSettings_Sliders;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct USettingsSliders_C* K2Node_DynamicCast_AsSettings_Sliders_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct USaveGame* CallFunc_MGH_LoadFromSlot_Loaded_Game_3;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_MGH_LoadFromSlot_Successful_3 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct USaveGame* CallFunc_MGH_LoadFromSlot_Loaded_Game_4;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_MGH_LoadFromSlot_Successful_4 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct USettingsSliders_C* K2Node_DynamicCast_AsSettings_Sliders_3;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct USettingsSliders_C* K2Node_DynamicCast_AsSettings_Sliders_4;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct USaveGame* CallFunc_MGH_LoadFromSlot_Loaded_Game_5;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_MGH_LoadFromSlot_Successful_5 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct USettingsSliders_C* K2Node_DynamicCast_AsSettings_Sliders_5;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0xB0(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Five_K2Node_InputKeyEvent_6
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Five_K2Node_InputKeyEvent_6
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_Six_K2Node_InputKeyEvent_8
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_Six_K2Node_InputKeyEvent_8
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_11
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_NumPadSix_K2Node_InputKeyEvent_11
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_12
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_12
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_13
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_NumPadFour_K2Node_InputKeyEvent_13
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_14
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_14
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_15
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Ctrl_NumPadFive_K2Node_InputKeyEvent_15
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftAlt_K2Node_InputKeyEvent_16
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftAlt_K2Node_InputKeyEvent_16
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftAlt_K2Node_InputKeyEvent_17
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftAlt_K2Node_InputKeyEvent_17
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_RightShift_K2Node_InputKeyEvent_18
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RightShift_K2Node_InputKeyEvent_18
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_RightShift_K2Node_InputKeyEvent_19
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RightShift_K2Node_InputKeyEvent_19
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_LeftShift_K2Node_InputKeyEvent_20
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftShift_K2Node_InputKeyEvent_20
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Alternate Fire_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Alternate Fire_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Primary Fire_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Primary Fire_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.GetInterpTargetVector
// Size: 0x49(Inherited: 0x0) 
struct FGetInterpTargetVector
{
	struct FVector Vector Target;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Close To 0,0,0? : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FVector VectTarget;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1E(0x1)
	char pad_31[1];  // 0x1F(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x20(0xC)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct AProp_Door01_C* K2Node_DynamicCast_AsProp_Door_01;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x3C(0xC)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x48(0x1)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_Right_K2Node_InputKeyEvent_24
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Right_K2Node_InputKeyEvent_24
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.InpActEvt_NumPadZero_K2Node_InputKeyEvent_25
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_NumPadZero_K2Node_InputKeyEvent_25
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Spectator.BP_Spectator_C.GetMyTeam
// Size: 0x11(Inherited: 0x0) 
struct FGetMyTeam
{
	char Team Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AMGH_PlayerState_C* CallFunc_GetMGHPlayerState_MGH_Player_State;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)

}; 
