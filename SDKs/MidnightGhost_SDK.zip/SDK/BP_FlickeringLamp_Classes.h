#pragma once 
#include <BP_FlickeringLamp_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlickeringLamp.BP_FlickeringLamp_C
// Size: 0x328(Inherited: 0x220) 
struct ABP_FlickeringLamp_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USpotLightComponent* SpotLight_B;  // 0x228(0x8)
	struct USpotLightComponent* SpotLight_A;  // 0x230(0x8)
	struct UPointLightComponent* PointLight;  // 0x238(0x8)
	struct UStaticMeshComponent* StaticMesh1;  // 0x240(0x8)
	struct UStaticMeshComponent* Sphere;  // 0x248(0x8)
	struct UCableComponent* Cable;  // 0x250(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x258(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x260(0x8)
	float Timeline_1_NewTrack_0_D29951AF4A2A0A5150D56B919157812A;  // 0x268(0x4)
	char ETimelineDirection Timeline_1__Direction_D29951AF4A2A0A5150D56B919157812A;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct UTimelineComponent* Timeline_2;  // 0x270(0x8)
	float Timeline_0_Multiplier_397D35A14F38DCC9447E56B94DF13071;  // 0x278(0x4)
	char ETimelineDirection Timeline_0__Direction_397D35A14F38DCC9447E56B94DF13071;  // 0x27C(0x1)
	char pad_637[3];  // 0x27D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x280(0x8)
	float Flicker04_Brightness_1E801A064E94E36448645FBF9589F3E9;  // 0x288(0x4)
	char ETimelineDirection Flicker04__Direction_1E801A064E94E36448645FBF9589F3E9;  // 0x28C(0x1)
	char pad_653[3];  // 0x28D(0x3)
	struct UTimelineComponent* Flicker04;  // 0x290(0x8)
	float Flicker03_Brightness_2143C7524A5C13E735579FB773B1FBCF;  // 0x298(0x4)
	char ETimelineDirection Flicker03__Direction_2143C7524A5C13E735579FB773B1FBCF;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct UTimelineComponent* Flicker03;  // 0x2A0(0x8)
	float Flicker02_Brightness_01DC59084E9EE6AF06AFB384C2AA82FD;  // 0x2A8(0x4)
	char ETimelineDirection Flicker02__Direction_01DC59084E9EE6AF06AFB384C2AA82FD;  // 0x2AC(0x1)
	char pad_685[3];  // 0x2AD(0x3)
	struct UTimelineComponent* Flicker02;  // 0x2B0(0x8)
	float Flicker01_Brightness_9B61875C40365B2C00BF0E847B318372;  // 0x2B8(0x4)
	char ETimelineDirection Flicker01__Direction_9B61875C40365B2C00BF0E847B318372;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct UTimelineComponent* Flicker01;  // 0x2C0(0x8)
	float Flicker_Brightness_864E36C3415645D18F778F879DFA32B5;  // 0x2C8(0x4)
	char ETimelineDirection Flicker__Direction_864E36C3415645D18F778F879DFA32B5;  // 0x2CC(0x1)
	char pad_717[3];  // 0x2CD(0x3)
	struct UTimelineComponent* Flicker;  // 0x2D0(0x8)
	struct ASpotLight* Spotlight_01;  // 0x2D8(0x8)
	struct ASpotLight* Spotlight_02;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool HookedUpSpotlights? : 1;  // 0x2E8(0x1)
	char pad_745_1 : 7;  // 0x2E9(0x1)
	bool Flicker? : 1;  // 0x2E9(0x1)
	char pad_746[2];  // 0x2EA(0x2)
	int32_t RandomFlicker;  // 0x2EC(0x4)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool on? : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct UAudioComponent* Sound;  // 0x2F8(0x8)
	struct UMaterialInstanceDynamic* LightBulbsMtl;  // 0x300(0x8)
	struct ABP_FlickeringLampSOUND_C* MySound;  // 0x308(0x8)
	float Original Light Intensity;  // 0x310(0x4)
	char pad_788_1 : 7;  // 0x314(0x1)
	bool Flipping Disabled? : 1;  // 0x314(0x1)
	char pad_789[3];  // 0x315(0x3)
	struct FLinearColor Set Color;  // 0x318(0x10)

	void UserConstructionScript(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.UserConstructionScript
	void Flicker03__FinishedFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker03__FinishedFunc
	void Flicker03__UpdateFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker03__UpdateFunc
	void Flicker01__FinishedFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker01__FinishedFunc
	void Flicker01__UpdateFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker01__UpdateFunc
	void Flicker04__FinishedFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker04__FinishedFunc
	void Flicker04__UpdateFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker04__UpdateFunc
	void Flicker02__FinishedFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker02__FinishedFunc
	void Flicker02__UpdateFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker02__UpdateFunc
	void Flicker__FinishedFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker__FinishedFunc
	void Flicker__UpdateFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Flicker__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Timeline_0__UpdateFunc
	void Timeline_1__FinishedFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Timeline_1__FinishedFunc
	void Timeline_1__UpdateFunc(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Timeline_1__UpdateFunc
	void TurnOnOff(bool On); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.TurnOnOff
	void NR_TurnOnOff(bool On, bool Skip Sound?); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.NR_TurnOnOff
	void SpawnSound(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.SpawnSound
	void OC_SyncLights(struct ABP_FlickeringLamp_C* Light, bool On); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.OC_SyncLights
	void DestroySound(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.DestroySound
	void ReceiveBeginPlay(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.ReceiveBeginPlay
	void Midnight(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.Midnight
	void StopFlicker(); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.StopFlicker
	void ExecuteUbergraph_BP_FlickeringLamp(int32_t EntryPoint); // Function BP_FlickeringLamp.BP_FlickeringLamp_C.ExecuteUbergraph_BP_FlickeringLamp
}; 



