#pragma once 
#include <AudioModulation_Structs.h>
 
 
 
// Class AudioModulation.AudioModulationSettings
// Size: 0x48(Inherited: 0x38) 
struct UAudioModulationSettings : public UDeveloperSettings
{
	struct TArray<struct FSoftObjectPath> Parameters;  // 0x38(0x10)

}; 



// Class AudioModulation.SoundControlBusMix
// Size: 0x40(Inherited: 0x28) 
struct USoundControlBusMix : public UObject
{
	uint32_t ProfileIndex;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct FSoundControlBusMixStage> MixStages;  // 0x30(0x10)

	void SoloMix(); // Function AudioModulation.SoundControlBusMix.SoloMix
	void SaveMixToProfile(); // Function AudioModulation.SoundControlBusMix.SaveMixToProfile
	void LoadMixFromProfile(); // Function AudioModulation.SoundControlBusMix.LoadMixFromProfile
	void DeactivateMix(); // Function AudioModulation.SoundControlBusMix.DeactivateMix
	void DeactivateAllMixes(); // Function AudioModulation.SoundControlBusMix.DeactivateAllMixes
	void ActivateMix(); // Function AudioModulation.SoundControlBusMix.ActivateMix
}; 



// Class AudioModulation.AudioModulationStatics
// Size: 0x28(Inherited: 0x28) 
struct UAudioModulationStatics : public UBlueprintFunctionLibrary
{

	void UpdateModulator(struct UObject* WorldContextObject, struct USoundModulatorBase* Modulator); // Function AudioModulation.AudioModulationStatics.UpdateModulator
	void UpdateMixFromObject(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMixFromObject
	void UpdateMixByFilter(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, struct FString AddressFilter, USoundModulationParameter* ParamClassFilter, struct USoundModulationParameter* ParamFilter, float Value, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMixByFilter
	void UpdateMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, struct TArray<struct FSoundControlBusMixStage> Stages, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMix
	void SaveMixToProfile(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, int32_t ProfileIndex); // Function AudioModulation.AudioModulationStatics.SaveMixToProfile
	struct TArray<struct FSoundControlBusMixStage> LoadMixFromProfile(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, bool bActivate, int32_t ProfileIndex); // Function AudioModulation.AudioModulationStatics.LoadMixFromProfile
	void DeactivateGenerator(struct UObject* WorldContextObject, struct USoundModulationGenerator* Generator); // Function AudioModulation.AudioModulationStatics.DeactivateGenerator
	void DeactivateBusMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix); // Function AudioModulation.AudioModulationStatics.DeactivateBusMix
	void DeactivateBus(struct UObject* WorldContextObject, struct USoundControlBus* Bus); // Function AudioModulation.AudioModulationStatics.DeactivateBus
	struct FSoundControlBusMixStage CreateBusMixStage(struct UObject* WorldContextObject, struct USoundControlBus* Bus, float Value, float AttackTime, float ReleaseTime); // Function AudioModulation.AudioModulationStatics.CreateBusMixStage
	struct USoundControlBusMix* CreateBusMix(struct UObject* WorldContextObject, struct FName Name, struct TArray<struct FSoundControlBusMixStage> Stages, bool Activate); // Function AudioModulation.AudioModulationStatics.CreateBusMix
	struct USoundControlBus* CreateBus(struct UObject* WorldContextObject, struct FName Name, struct USoundModulationParameter* Parameter, bool Activate); // Function AudioModulation.AudioModulationStatics.CreateBus
	void ActivateGenerator(struct UObject* WorldContextObject, struct USoundModulationGenerator* Generator); // Function AudioModulation.AudioModulationStatics.ActivateGenerator
	void ActivateBusMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix); // Function AudioModulation.AudioModulationStatics.ActivateBusMix
	void ActivateBus(struct UObject* WorldContextObject, struct USoundControlBus* Bus); // Function AudioModulation.AudioModulationStatics.ActivateBus
}; 



// Class AudioModulation.SoundModulationGeneratorLFO
// Size: 0x40(Inherited: 0x28) 
struct USoundModulationGeneratorLFO : public USoundModulationGenerator
{
	struct FSoundModulationLFOParams Params;  // 0x28(0x14)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class AudioModulation.AudioModulationStyle
// Size: 0x28(Inherited: 0x28) 
struct UAudioModulationStyle : public UBlueprintFunctionLibrary
{

	struct FColor GetPatchColor(); // Function AudioModulation.AudioModulationStyle.GetPatchColor
	struct FColor GetParameterColor(); // Function AudioModulation.AudioModulationStyle.GetParameterColor
	struct FColor GetModulationGeneratorColor(); // Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor
	struct FColor GetControlBusMixColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusMixColor
	struct FColor GetControlBusColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusColor
}; 



// Class AudioModulation.SoundModulationGenerator
// Size: 0x28(Inherited: 0x28) 
struct USoundModulationGenerator : public USoundModulatorBase
{

}; 



// Class AudioModulation.SoundControlBus
// Size: 0x58(Inherited: 0x28) 
struct USoundControlBus : public USoundModulatorBase
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bBypass : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString Address;  // 0x30(0x10)
	struct TArray<struct USoundModulationGenerator*> Generators;  // 0x40(0x10)
	struct USoundModulationParameter* Parameter;  // 0x50(0x8)

}; 



// Class AudioModulation.SoundModulationGeneratorEnvelopeFollower
// Size: 0x48(Inherited: 0x28) 
struct USoundModulationGeneratorEnvelopeFollower : public USoundModulationGenerator
{
	struct FEnvelopeFollowerGeneratorParams Params;  // 0x28(0x20)

}; 



// Class AudioModulation.SoundModulationParameter
// Size: 0x30(Inherited: 0x28) 
struct USoundModulationParameter : public UObject
{
	struct FSoundModulationParameterSettings Settings;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 



// Class AudioModulation.SoundModulationPatch
// Size: 0x48(Inherited: 0x28) 
struct USoundModulationPatch : public USoundModulatorBase
{
	struct FSoundControlModulationPatch PatchSettings;  // 0x28(0x20)

}; 



// Class AudioModulation.SoundModulationParameterScaled
// Size: 0x38(Inherited: 0x30) 
struct USoundModulationParameterScaled : public USoundModulationParameter
{
	float UnitMin;  // 0x30(0x4)
	float UnitMax;  // 0x34(0x4)

}; 



// Class AudioModulation.SoundModulationParameterFrequencyBase
// Size: 0x30(Inherited: 0x30) 
struct USoundModulationParameterFrequencyBase : public USoundModulationParameter
{

}; 



// Class AudioModulation.SoundModulationParameterFrequency
// Size: 0x38(Inherited: 0x30) 
struct USoundModulationParameterFrequency : public USoundModulationParameterFrequencyBase
{
	float UnitMin;  // 0x30(0x4)
	float UnitMax;  // 0x34(0x4)

}; 



// Class AudioModulation.SoundModulationParameterFilterFrequency
// Size: 0x30(Inherited: 0x30) 
struct USoundModulationParameterFilterFrequency : public USoundModulationParameterFrequencyBase
{

}; 



// Class AudioModulation.SoundModulationParameterLPFFrequency
// Size: 0x30(Inherited: 0x30) 
struct USoundModulationParameterLPFFrequency : public USoundModulationParameterFilterFrequency
{

}; 



// Class AudioModulation.SoundModulationParameterHPFFrequency
// Size: 0x30(Inherited: 0x30) 
struct USoundModulationParameterHPFFrequency : public USoundModulationParameterFilterFrequency
{

}; 



// Class AudioModulation.SoundModulationParameterBipolar
// Size: 0x38(Inherited: 0x30) 
struct USoundModulationParameterBipolar : public USoundModulationParameter
{
	float UnitRange;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 



// Class AudioModulation.SoundModulationParameterVolume
// Size: 0x38(Inherited: 0x30) 
struct USoundModulationParameterVolume : public USoundModulationParameter
{
	float MinVolume;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 



