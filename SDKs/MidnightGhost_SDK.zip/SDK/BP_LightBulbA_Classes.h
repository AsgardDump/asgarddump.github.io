#pragma once 
#include <BP_LightBulbA_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LightBulbA.BP_LightBulbA_C
// Size: 0x284(Inherited: 0x220) 
struct ABP_LightBulbA_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USpotLightComponent* SpotLight;  // 0x228(0x8)
	struct UPointLightComponent* PointLight;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_LightCeiling;  // 0x238(0x8)
	float Timeline_1_NewTrack_0_5E9637FE46D50083724953A7FE6E7B65;  // 0x240(0x4)
	char ETimelineDirection Timeline_1__Direction_5E9637FE46D50083724953A7FE6E7B65;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* Timeline_2;  // 0x248(0x8)
	float Timeline_0_Multiplier_1041BF85469BF607CB6D5FB3DA947551;  // 0x250(0x4)
	char ETimelineDirection Timeline_0__Direction_1041BF85469BF607CB6D5FB3DA947551;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool IsActive : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	float LightIntensity;  // 0x264(0x4)
	float OrigIntensity;  // 0x268(0x4)
	char pad_620_1 : 7;  // 0x26C(0x1)
	bool Flipping Disabled? : 1;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct FLinearColor Set Color;  // 0x270(0x10)
	float Original Light Intensity;  // 0x280(0x4)

	void UserConstructionScript(); // Function BP_LightBulbA.BP_LightBulbA_C.UserConstructionScript
	void Timeline_0__FinishedFunc(); // Function BP_LightBulbA.BP_LightBulbA_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_LightBulbA.BP_LightBulbA_C.Timeline_0__UpdateFunc
	void Timeline_1__FinishedFunc(); // Function BP_LightBulbA.BP_LightBulbA_C.Timeline_1__FinishedFunc
	void Timeline_1__UpdateFunc(); // Function BP_LightBulbA.BP_LightBulbA_C.Timeline_1__UpdateFunc
	void Midnight(); // Function BP_LightBulbA.BP_LightBulbA_C.Midnight
	void Infection(); // Function BP_LightBulbA.BP_LightBulbA_C.Infection
	void ReceiveBeginPlay(); // Function BP_LightBulbA.BP_LightBulbA_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_LightBulbA.BP_LightBulbA_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_LightBulbA(int32_t EntryPoint); // Function BP_LightBulbA.BP_LightBulbA_C.ExecuteUbergraph_BP_LightBulbA
}; 



