#pragma once 
#include <BP_Hunter_Dummy_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_Dummy.BP_Hunter_Dummy_C
// Size: 0x2658(Inherited: 0x2658) 
struct ABP_Hunter_Dummy_C : public ABP_Hunter_C
{

}; 



