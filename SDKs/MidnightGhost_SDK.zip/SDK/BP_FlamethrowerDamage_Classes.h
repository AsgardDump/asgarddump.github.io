#pragma once 
#include <BP_FlamethrowerDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlamethrowerDamage.BP_FlamethrowerDamage_C
// Size: 0x284(Inherited: 0x220) 
struct ABP_FlamethrowerDamage_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* Box1;  // 0x228(0x8)
	struct UBoxComponent* Box;  // 0x230(0x8)
	struct UCapsuleComponent* Capsule;  // 0x238(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x240(0x8)
	struct TArray<struct AActor*> ActorsToDamage;  // 0x248(0x10)
	struct ABP_Hunter_C* MyHunter;  // 0x258(0x8)
	struct TArray<struct AMGH_PlayerState_C*> DamagedPlayerStates;  // 0x260(0x10)
	struct AActor* OverlapActor;  // 0x270(0x8)
	struct FVector Impact Point;  // 0x278(0xC)

	void GetProjectileOwner(struct ABP_Hunter_C*& Hunter); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.GetProjectileOwner
	void UserConstructionScript(); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.UserConstructionScript
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void ReceiveBeginPlay(); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.ReceiveBeginPlay
	void BeginOverlapDamage(struct UObject* Object); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BeginOverlapDamage
	void ReceiveTick(float DeltaSeconds); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.ReceiveTick
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.ReceiveHit
	void BndEvt__Box_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Box_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Box1_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.BndEvt__Box1_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
	void SpawnImpactVFX(struct AActor* Target); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.SpawnImpactVFX
	void ExecuteUbergraph_BP_FlamethrowerDamage(int32_t EntryPoint); // Function BP_FlamethrowerDamage.BP_FlamethrowerDamage_C.ExecuteUbergraph_BP_FlamethrowerDamage
}; 



