#pragma once 
#include <BP_PresentThrow_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PresentThrow.BP_PresentThrow_C
// Size: 0x269(Inherited: 0x220) 
struct ABP_PresentThrow_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USmoothSync* SmoothSync;  // 0x228(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x230(0x8)
	struct UBoxComponent* Box;  // 0x238(0x8)
	struct UStaticMeshComponent* SM_Bomb_merged_2_c;  // 0x240(0x8)
	struct AMGH_PlayerState_C* WhoFired;  // 0x248(0x8)
	struct ABP_Hunter_C* DirectHitHunter;  // 0x250(0x8)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool StopRotate : 1;  // 0x258(0x1)
	char pad_601_1 : 7;  // 0x259(0x1)
	bool NeedsProjectileEtc : 1;  // 0x259(0x1)
	char pad_602[6];  // 0x25A(0x6)
	struct UNiagaraComponent* FlyingEffect;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool Headshot : 1;  // 0x268(0x1)

	void GetOwnerInfo_Int(struct AActor*& Owner); // Function BP_PresentThrow.BP_PresentThrow_C.GetOwnerInfo_Int
	void SetOwnerInfo_Int(struct AActor* Actor); // Function BP_PresentThrow.BP_PresentThrow_C.SetOwnerInfo_Int
	void ReceiveBeginPlay(); // Function BP_PresentThrow.BP_PresentThrow_C.ReceiveBeginPlay
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_PresentThrow.BP_PresentThrow_C.ReceiveHit
	void Explode(bool SkipDmg); // Function BP_PresentThrow.BP_PresentThrow_C.Explode
	void SetOutlineVisibility_Int(bool Visible); // Function BP_PresentThrow.BP_PresentThrow_C.SetOutlineVisibility_Int
	void SetCameraCollide_Int(bool Collide); // Function BP_PresentThrow.BP_PresentThrow_C.SetCameraCollide_Int
	void ReceiveTick(float DeltaSeconds); // Function BP_PresentThrow.BP_PresentThrow_C.ReceiveTick
	void MiscHit(float Damage, struct AMGH_PlayerState_C* PS Responsible); // Function BP_PresentThrow.BP_PresentThrow_C.MiscHit
	void Server_DestroyPresent(); // Function BP_PresentThrow.BP_PresentThrow_C.Server_DestroyPresent
	void MC_DestroyPresent(struct FVector_NetQuantize Loc); // Function BP_PresentThrow.BP_PresentThrow_C.MC_DestroyPresent
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_PresentThrow.BP_PresentThrow_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_PresentThrow(int32_t EntryPoint); // Function BP_PresentThrow.BP_PresentThrow_C.ExecuteUbergraph_BP_PresentThrow
}; 



