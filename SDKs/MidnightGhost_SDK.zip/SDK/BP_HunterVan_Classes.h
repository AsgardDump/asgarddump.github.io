#pragma once 
#include <BP_HunterVan_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HunterVan.BP_HunterVan_C
// Size: 0x7A0(Inherited: 0x6FD) 
struct ABP_HunterVan_C : public ABP_HunterVehicle_C
{
	char pad_1789[3];  // 0x6FD(0x3)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x700(0x8)
	struct USkeletalMeshComponent* Driver;  // 0x708(0x8)
	struct UChildActorComponent* Clock;  // 0x710(0x8)
	struct UChildActorComponent* VanActor;  // 0x718(0x8)
	struct FVector backWheelsLocation;  // 0x720(0xC)
	struct FVector W1PosLastFrame;  // 0x72C(0xC)
	struct FVector W2PosLastFrame;  // 0x738(0xC)
	struct FVector W3PosLastFrame;  // 0x744(0xC)
	struct FVector W4PosLastFrame;  // 0x750(0xC)
	struct FVector ActorLocationLastFrame;  // 0x75C(0xC)
	struct FVector ProcAnimVelocity;  // 0x768(0xC)
	struct FVector ProcAnimVelocitySlow;  // 0x774(0xC)
	struct FVector AccelDeaccel;  // 0x780(0xC)
	struct FVector AccelDeaccelClampedSpringed;  // 0x78C(0xC)
	struct AActor* Target;  // 0x798(0x8)

	void AnimateWheels(); // Function BP_HunterVan.BP_HunterVan_C.AnimateWheels
	void CalculateWheelPlaneNormal(struct FVector w1, struct FVector w2, struct FVector W3, struct FVector w4, struct FRotator& RootRotation, struct FVector& Vector); // Function BP_HunterVan.BP_HunterVan_C.CalculateWheelPlaneNormal
	void RayCastWheel(struct USceneComponent* Wheel, struct FVector& WishedLocation); // Function BP_HunterVan.BP_HunterVan_C.RayCastWheel
	void RayCastAllWheelsWishedLocation(struct FVector& Wheel1, struct FVector& Wheel2, struct FVector& Wheel3, struct FVector& Wheel4); // Function BP_HunterVan.BP_HunterVan_C.RayCastAllWheelsWishedLocation
	void AlignCarToPath(); // Function BP_HunterVan.BP_HunterVan_C.AlignCarToPath
	void InitiatePathMovement(); // Function BP_HunterVan.BP_HunterVan_C.InitiatePathMovement
	void HasArrivedFunction(); // Function BP_HunterVan.BP_HunterVan_C.HasArrivedFunction
	void ReceiveBeginPlay(); // Function BP_HunterVan.BP_HunterVan_C.ReceiveBeginPlay
	void MC_RideInBumpAnimation(); // Function BP_HunterVan.BP_HunterVan_C.MC_RideInBumpAnimation
	void ReceiveTick(float DeltaSeconds); // Function BP_HunterVan.BP_HunterVan_C.ReceiveTick
	void ExecuteUbergraph_BP_HunterVan(int32_t EntryPoint); // Function BP_HunterVan.BP_HunterVan_C.ExecuteUbergraph_BP_HunterVan
}; 



