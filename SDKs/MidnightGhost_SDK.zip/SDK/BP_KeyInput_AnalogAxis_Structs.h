#pragma once 
#include "SDK.h" 
 
 
// Function BP_KeyInput_AnalogAxis.BP_KeyInput_AnalogAxis_C.Key Input Current State
// Size: 0x2D(Inherited: 0x9E) 
struct FKey Input Current State : public FKey Input Current State
{
	struct APlayerController* Controller;  // 0x0(0x8)
	float Axis Value;  // 0x8(0x4)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool Down : 1;  // 0xC(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool Just Pressed : 1;  // 0xD(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool Just Released : 1;  // 0xE(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0xF(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x10(0x1)
	float CallFunc_GetInputAnalogKeyState_ReturnValue;  // 0x14(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x18(0x4)
	float CallFunc_FMin_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x20(0x4)
	float CallFunc_SelectFloat_ReturnValue;  // 0x24(0x4)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x29(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2A(0x1)
	char pad_198_1 : 7;  // 0xC6(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_3 : 1;  // 0x2B(0x1)
	char pad_199_1 : 7;  // 0xC7(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x2C(0x1)

}; 
