#pragma once 
#include "SDK.h" 
 
 
// Function BP_CannonballProj.BP_CannonballProj_C.ExecuteUbergraph_BP_CannonballProj
// Size: 0x334(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CannonballProj
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x18(0x8)
	float Temp_float_Variable;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float Temp_float_Variable_2;  // 0x28(0x4)
	float Temp_float_Variable_3;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_CustomEvent_SkipDmg : 1;  // 0x30(0x1)
	char pad_49[15];  // 0x31(0xF)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x40(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x70(0x8)
	struct ACannonballExplosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x78(0x8)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x80(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x8C(0xC)
	float CallFunc_BreakVector_X;  // 0x98(0x4)
	float CallFunc_BreakVector_Y;  // 0x9C(0x4)
	float CallFunc_BreakVector_Z;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_IsServer_ReturnValue_2 : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize;  // 0xA8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xB4(0xC)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_IsServer_ReturnValue_3 : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xD4(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xE0(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0xE4(0xC)
	float K2Node_Select_Default;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0xF8(0x8)
	struct AActor* K2Node_Event_Other;  // 0x100(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0x114(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x120(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0x12C(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0x138(0x88)
	float K2Node_Select_Default_2;  // 0x1C0(0x4)
	char pad_452[4];  // 0x1C4(0x4)
	struct ABP_Trap_C* K2Node_DynamicCast_AsBP_Trap;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1D0(0x1)
	char pad_465[7];  // 0x1D1(0x7)
	struct ABP_Generator_C* K2Node_DynamicCast_AsBP_Generator;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct ABP_SaltCircle_C* K2Node_DynamicCast_AsBP_Salt_Circle;  // 0x1E8(0x8)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1F0(0x1)
	char pad_497[7];  // 0x1F1(0x7)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x1F8(0x8)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x200(0x1)
	char pad_513[7];  // 0x201(0x7)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0x208(0x8)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x210(0x1)
	char pad_529[3];  // 0x211(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x214(0x4)
	struct FRotator CallFunc_Multiply_RotatorFloat_ReturnValue;  // 0x218(0xC)
	struct FHitResult CallFunc_K2_AddRelativeRotation_SweepHitResult;  // 0x224(0x88)
	struct FHitResult CallFunc_K2_AddRelativeRotation_SweepHitResult_2;  // 0x2AC(0x88)

}; 
// Function BP_CannonballProj.BP_CannonballProj_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_CannonballProj.BP_CannonballProj_C.Explode
// Size: 0x1(Inherited: 0x0) 
struct FExplode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool SkipDmg : 1;  // 0x0(0x1)

}; 
// Function BP_CannonballProj.BP_CannonballProj_C.ReceiveHit
// Size: 0xC8(Inherited: 0xC8) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x88)

}; 
