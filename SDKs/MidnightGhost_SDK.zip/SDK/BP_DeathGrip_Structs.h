#pragma once 
#include "SDK.h" 
 
 
// Function BP_DeathGrip.BP_DeathGrip_C.SetArmsMaterials
// Size: 0x18(Inherited: 0x0) 
struct FSetArmsMaterials
{
	struct UPrimitiveComponent* Mesh;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Midnight : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.MiscHit
// Size: 0x10(Inherited: 0x0) 
struct FMiscHit
{
	float Damage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AMGH_PlayerState_C* PS Responsible;  // 0x8(0x8)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.ExecuteUbergraph_BP_DeathGrip
// Size: 0x529(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DeathGrip
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool Temp_bool_IsClosed_Variable_4 : 1;  // 0x27(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x2C(0xC)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x44(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x48(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x50(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x58(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x68(0x88)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float K2Node_Event_Damage;  // 0xFC(0x4)
	struct AMGH_PlayerState_C* K2Node_Event_PS_Responsible;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x110(0x8)
	struct ABP_Hunter_C* K2Node_CustomEvent_BPHunter;  // 0x118(0x8)
	float K2Node_CustomEvent_Damage;  // 0x120(0x4)
	char pad_292[4];  // 0x124(0x4)
	struct AMGH_PlayerState_C* K2Node_CustomEvent_PlayerState;  // 0x128(0x8)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter_2;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x13C(0x4)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x140(0x1)
	char pad_321[7];  // 0x141(0x7)
	struct AMGH_PlayerState_C* CallFunc_GetLocalPlayerstate_PlayerState;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x151(0x1)
	char pad_338_1 : 7;  // 0x152(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x152(0x1)
	char pad_339_1 : 7;  // 0x153(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x153(0x1)
	char pad_340[4];  // 0x154(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x158(0x8)
	struct UShadowtrapIndicator_UI_C* K2Node_DynamicCast_AsShadowtrap_Indicator_UI;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x168(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x169(0x1)
	char pad_362[6];  // 0x16A(0x6)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x170(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x1A0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1A8(0xC)
	char pad_436[4];  // 0x1B4(0x4)
	struct ABP_ShadowtrapDestroyed_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x1B8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1C0(0xC)
	char pad_460_1 : 7;  // 0x1CC(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x1CC(0x1)
	char pad_461_1 : 7;  // 0x1CD(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_4 : 1;  // 0x1CD(0x1)
	char pad_462[2];  // 0x1CE(0x2)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x1D0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x208(0x1)
	char pad_521[7];  // 0x209(0x7)
	struct ABP_ShadowtrapSplat_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x210(0x8)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x218(0x88)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x2A0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x2AC(0xC)
	float CallFunc_BreakVector_X;  // 0x2B8(0x4)
	float CallFunc_BreakVector_Y;  // 0x2BC(0x4)
	float CallFunc_BreakVector_Z;  // 0x2C0(0x4)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize;  // 0x2C4(0xC)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Temp_bool_IsClosed_Variable_5 : 1;  // 0x2D0(0x1)
	char pad_721[3];  // 0x2D1(0x3)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x2D4(0x88)
	char pad_860_1 : 7;  // 0x35C(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x35C(0x1)
	char pad_861[3];  // 0x35D(0x3)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x360(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x370(0x1)
	char pad_881[7];  // 0x371(0x7)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x378(0x10)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_5 : 1;  // 0x388(0x1)
	char pad_905[7];  // 0x389(0x7)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_2;  // 0x390(0x10)
	struct FHitResult CallFunc_CapsuleTraceSingleForObjects_OutHit;  // 0x3A0(0x88)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool CallFunc_CapsuleTraceSingleForObjects_ReturnValue : 1;  // 0x428(0x1)
	char pad_1065[7];  // 0x429(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x430(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x438(0x8)
	char pad_1088_1 : 7;  // 0x440(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x440(0x1)
	char pad_1089[7];  // 0x441(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_3;  // 0x448(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_3;  // 0x450(0x8)
	char pad_1112_1 : 7;  // 0x458(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x458(0x1)
	char pad_1113[3];  // 0x459(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x45C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x460(0x4)
	char pad_1124_1 : 7;  // 0x464(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x464(0x1)
	char pad_1125_1 : 7;  // 0x465(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue_2 : 1;  // 0x465(0x1)
	char pad_1126[2];  // 0x466(0x2)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x468(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x470(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x478(0x8)
	char pad_1152_1 : 7;  // 0x480(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x480(0x1)
	char pad_1153[3];  // 0x481(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_3;  // 0x484(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x490(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x49C(0xC)
	char pad_1192_1 : 7;  // 0x4A8(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x4A8(0x1)
	char pad_1193[3];  // 0x4A9(0x3)
	float CallFunc_VSize_ReturnValue;  // 0x4AC(0x4)
	char pad_1200_1 : 7;  // 0x4B0(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4B0(0x1)
	char pad_1201[7];  // 0x4B1(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x4B8(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x4C0(0x8)
	struct UDeathGrip_AnimBP_C* K2Node_DynamicCast_AsDeath_Grip_Anim_BP;  // 0x4C8(0x8)
	char pad_1232_1 : 7;  // 0x4D0(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x4D0(0x1)
	char pad_1233[7];  // 0x4D1(0x7)
	struct UDeathGrip_AnimBP_C* K2Node_DynamicCast_AsDeath_Grip_Anim_BP_2;  // 0x4D8(0x8)
	char pad_1248_1 : 7;  // 0x4E0(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x4E0(0x1)
	char pad_1249[7];  // 0x4E1(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0x4E8(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_4;  // 0x4F0(0x8)
	struct UDeathGrip_AnimBP_C* K2Node_DynamicCast_AsDeath_Grip_Anim_BP_3;  // 0x4F8(0x8)
	char pad_1280_1 : 7;  // 0x500(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x500(0x1)
	char pad_1281[7];  // 0x501(0x7)
	struct UDeathGrip_AnimBP_C* K2Node_DynamicCast_AsDeath_Grip_Anim_BP_4;  // 0x508(0x8)
	char pad_1296_1 : 7;  // 0x510(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x510(0x1)
	char pad_1297_1 : 7;  // 0x511(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_6 : 1;  // 0x511(0x1)
	char pad_1298_1 : 7;  // 0x512(0x1)
	bool Temp_bool_IsClosed_Variable_6 : 1;  // 0x512(0x1)
	char pad_1299[5];  // 0x513(0x5)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_5;  // 0x518(0x8)
	struct UDeathGrip_AnimBP_C* K2Node_DynamicCast_AsDeath_Grip_Anim_BP_5;  // 0x520(0x8)
	char pad_1320_1 : 7;  // 0x528(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x528(0x1)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.Server_TrapDamaged
// Size: 0x10(Inherited: 0x0) 
struct FServer_TrapDamaged
{
	float Damage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AMGH_PlayerState_C* PlayerState;  // 0x8(0x8)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.Server_HunterShadowtrapped
// Size: 0x8(Inherited: 0x0) 
struct FServer_HunterShadowtrapped
{
	struct ABP_Hunter_C* BPHunter;  // 0x0(0x8)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.GetLocalPlayerstate
// Size: 0x21(Inherited: 0x0) 
struct FGetLocalPlayerstate
{
	struct AMGH_PlayerState_C* PlayerState;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x10(0x8)
	struct AMGH_PlayerState_C* K2Node_DynamicCast_AsMGH_Player_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.Trap Owner Message
// Size: 0x41(Inherited: 0x0) 
struct FTrap Owner Message
{
	struct FText Text;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Activated? : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x20(0x10)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x30(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)

}; 
// Function BP_DeathGrip.BP_DeathGrip_C.SetArmsCollectiveMaterials
// Size: 0x1(Inherited: 0x0) 
struct FSetArmsCollectiveMaterials
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsMidnight : 1;  // 0x0(0x1)

}; 
