#pragma once 
#include <BP_MedicKitInteract_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MedicKitInteract.BP_MedicKitInteract_C
// Size: 0x2A0(Inherited: 0x281) 
struct ABP_MedicKitInteract_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UBoxComponent* Box;  // 0x290(0x8)
	struct ABP_MedicKit_C* MyMedicKit;  // 0x298(0x8)

	void IsThisMyMedicKit(struct ABP_Hunter_C* Hunter, bool& YES); // Function BP_MedicKitInteract.BP_MedicKitInteract_C.IsThisMyMedicKit
	void UseMedicKit(struct AMGH_PlayerController_BP_C* Controller); // Function BP_MedicKitInteract.BP_MedicKitInteract_C.UseMedicKit
	void ExecuteUbergraph_BP_MedicKitInteract(int32_t EntryPoint); // Function BP_MedicKitInteract.BP_MedicKitInteract_C.ExecuteUbergraph_BP_MedicKitInteract
}; 



