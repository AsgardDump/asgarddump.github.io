#pragma once 
#include <AutoSettings_Structs.h>
 
 
 
// Class AutoSettings.WindowModeValueMask
// Size: 0x28(Inherited: 0x28) 
struct UWindowModeValueMask : public USettingValueMask
{

}; 



// Class AutoSettings.RadioSelectSetting
// Size: 0x2E0(Inherited: 0x2D0) 
struct URadioSelectSetting : public USelectSetting
{
	URadioButton* RadioButtonClass;  // 0x2D0(0x8)
	struct URadioSelect* RadioSelect;  // 0x2D8(0x8)

	void RadioSelectionChanged(struct FString Value); // Function AutoSettings.RadioSelectSetting.RadioSelectionChanged
}; 



// Class AutoSettings.AxisLabel
// Size: 0x2A8(Inherited: 0x290) 
struct UAxisLabel : public UInputLabel
{
	struct FName AxisName;  // 0x290(0x8)
	float Scale;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	struct UKeyLabel* KeyLabel;  // 0x2A0(0x8)

}; 



// Class AutoSettings.AxisMapping
// Size: 0x2B0(Inherited: 0x298) 
struct UAxisMapping : public UInputMapping
{
	struct FName AxisName;  // 0x298(0x8)
	float Scale;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct UAxisLabel* AxisLabel;  // 0x2A8(0x8)

}; 



// Class AutoSettings.InputMapping
// Size: 0x298(Inherited: 0x260) 
struct UInputMapping : public UUserWidget
{
	int32_t MappingGroup;  // 0x260(0x4)
	struct FGameplayTag KeyGroup;  // 0x264(0x8)
	char pad_620[4];  // 0x26C(0x4)
	struct FGameplayTagContainer IconTags;  // 0x270(0x20)
	struct UBindCaptureButton* BindCaptureButton;  // 0x290(0x8)

	void UpdateMapping(); // Function AutoSettings.InputMapping.UpdateMapping
	void UpdateLabel(); // Function AutoSettings.InputMapping.UpdateLabel
	void ChordCaptured(struct FInputChord InChord); // Function AutoSettings.InputMapping.ChordCaptured
	void BindChord(struct FInputChord InChord); // Function AutoSettings.InputMapping.BindChord
}; 



// Class AutoSettings.InputLabel
// Size: 0x290(Inherited: 0x260) 
struct UInputLabel : public UUserWidget
{
	int32_t MappingGroup;  // 0x260(0x4)
	struct FGameplayTag KeyGroup;  // 0x264(0x8)
	char pad_620_1 : 7;  // 0x26C(0x1)
	bool bUsePlayerKeyGroup : 1;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct FGameplayTagContainer IconTags;  // 0x270(0x20)

	void UpdateLabel(); // Function AutoSettings.InputLabel.UpdateLabel
	void MappingsChanged(struct APlayerController* Player); // Function AutoSettings.InputLabel.MappingsChanged
}; 



// Class AutoSettings.ActionLabel
// Size: 0x2F8(Inherited: 0x290) 
struct UActionLabel : public UInputLabel
{
	struct FName ActionName;  // 0x290(0x8)
	UKeyLabel* KeyLabelWidgetClass;  // 0x298(0x8)
	UWidget* KeySeparatorWidgetClass;  // 0x2A0(0x8)
	struct UPanelWidget* KeyContainer;  // 0x2A8(0x8)
	char pad_688[72];  // 0x2B0(0x48)

}; 



// Class AutoSettings.BindCaptureButton
// Size: 0x290(Inherited: 0x260) 
struct UBindCaptureButton : public UUserWidget
{
	struct FGameplayTag KeyGroup;  // 0x260(0x8)
	UBindCapturePrompt* BindCapturePromptClass;  // 0x268(0x8)
	int32_t CapturePromptZOrder;  // 0x270(0x4)
	char pad_628[20];  // 0x274(0x14)
	struct UBindCapturePrompt* Prompt;  // 0x288(0x8)

	struct UBindCapturePrompt* StartCapture(); // Function AutoSettings.BindCaptureButton.StartCapture
	void InitializePrompt(struct UBindCapturePrompt* PromptWidget); // Function AutoSettings.BindCaptureButton.InitializePrompt
	void ChordCaptured(struct FInputChord Chord); // Function AutoSettings.BindCaptureButton.ChordCaptured
}; 



// Class AutoSettings.ActionMapping
// Size: 0x2A8(Inherited: 0x298) 
struct UActionMapping : public UInputMapping
{
	struct FName ActionName;  // 0x298(0x8)
	struct UActionLabel* ActionLabel;  // 0x2A0(0x8)

}; 



// Class AutoSettings.AutoSettingsConfig
// Size: 0x150(Inherited: 0x28) 
struct UAutoSettingsConfig : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bAutoInitializePlayerInputOverrides : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool AllowModifierKeys : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct FText ShiftModifierOverrideText;  // 0x30(0x18)
	struct FText CtrlModifierOverrideText;  // 0x48(0x18)
	struct FText AltModifierOverrideText;  // 0x60(0x18)
	struct FText CmdModifierOverrideText;  // 0x78(0x18)
	struct TArray<struct FInputMappingPreset> InputPresets;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool AllowMultipleBindingsPerKey : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct TArray<struct FMappingGroupLink> MappingGroupLinks;  // 0xA8(0x10)
	struct TArray<struct FName> BlacklistedActions;  // 0xB8(0x10)
	struct TArray<struct FName> BlacklistedAxes;  // 0xC8(0x10)
	struct TArray<struct FKeyIconSet> KeyIconSets;  // 0xD8(0x10)
	struct TArray<struct FKeyFriendlyName> KeyFriendlyNames;  // 0xE8(0x10)
	struct TArray<struct FKeyGroup> KeyGroups;  // 0xF8(0x10)
	struct TArray<struct FKey> AllowedKeys;  // 0x108(0x10)
	struct TArray<struct FKey> DisallowedKeys;  // 0x118(0x10)
	struct TArray<struct FKey> BindingEscapeKeys;  // 0x128(0x10)
	float MouseMoveCaptureDistance;  // 0x138(0x4)
	char pad_316[4];  // 0x13C(0x4)
	struct TArray<struct FAxisAssociation> AxisAssociations;  // 0x140(0x10)

	struct FGameplayTag GetKeyGroupStatic(struct FKey Key); // Function AutoSettings.AutoSettingsConfig.GetKeyGroupStatic
	struct FText GetKeyFriendlyNameStatic(struct FKey Key); // Function AutoSettings.AutoSettingsConfig.GetKeyFriendlyNameStatic
}; 



// Class AutoSettings.SettingValueMask
// Size: 0x28(Inherited: 0x28) 
struct USettingValueMask : public UObject
{

	struct FString RecombineValues(struct FString SettingValue, struct FString ConsoleValue); // Function AutoSettings.SettingValueMask.RecombineValues
	struct FString MaskValue(struct FString ConsoleValue); // Function AutoSettings.SettingValueMask.MaskValue
}; 



// Class AutoSettings.AutoSettingsPlayer
// Size: 0x28(Inherited: 0x28) 
struct UAutoSettingsPlayer : public UInterface
{

	void SaveInputMappings(struct FPlayerInputMappings InputMappings); // Function AutoSettings.AutoSettingsPlayer.SaveInputMappings
	struct FString GetUniquePlayerIdentifier(); // Function AutoSettings.AutoSettingsPlayer.GetUniquePlayerIdentifier
	bool GetInputMappings(struct FPlayerInputMappings& InputMappings); // Function AutoSettings.AutoSettingsPlayer.GetInputMappings
	struct FInputMappingPreset GetDefaultInputMappingPreset(); // Function AutoSettings.AutoSettingsPlayer.GetDefaultInputMappingPreset
}; 



// Class AutoSettings.AutoSettingWidget
// Size: 0x2B0(Inherited: 0x260) 
struct UAutoSettingWidget : public UUserWidget
{
	struct FName CVarName;  // 0x260(0x8)
	USettingValueMask* ValueMask;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool bAutoSave : 1;  // 0x270(0x1)
	char pad_625_1 : 7;  // 0x271(0x1)
	bool bAutoApply : 1;  // 0x271(0x1)
	char pad_626[6];  // 0x272(0x6)
	struct FGameplayTagContainer SettingTags;  // 0x278(0x20)
	struct FString CurrentValue;  // 0x298(0x10)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool bHasUnappliedChange : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool bHasUnsavedChange : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool bUpdatingSettingSelection : 1;  // 0x2AA(0x1)
	char pad_683[5];  // 0x2AB(0x5)

	void UpdateSelection(struct FString Value); // Function AutoSettings.AutoSettingWidget.UpdateSelection
	void Save(); // Function AutoSettings.AutoSettingWidget.Save
	bool HasUnsavedChange(); // Function AutoSettings.AutoSettingWidget.HasUnsavedChange
	bool HasUnappliedChange(); // Function AutoSettings.AutoSettingWidget.HasUnappliedChange
	void Cancel(); // Function AutoSettings.AutoSettingWidget.Cancel
	void ApplySettingValue(struct FString Value, bool bSaveIfPossible); // Function AutoSettings.AutoSettingWidget.ApplySettingValue
	void Apply(); // Function AutoSettings.AutoSettingWidget.Apply
}; 



// Class AutoSettings.BindCapturePrompt
// Size: 0x2C0(Inherited: 0x260) 
struct UBindCapturePrompt : public UUserWidget
{
	char pad_608_1 : 7;  // 0x260(0x1)
	bool bIgnoreGameViewportInputWhileCapturing : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool bRestrictKeyGroup : 1;  // 0x261(0x1)
	uint8_t  CaptureMode;  // 0x262(0x1)
	char pad_611[1];  // 0x263(0x1)
	struct FGameplayTag KeyGroup;  // 0x264(0x8)
	char pad_620[4];  // 0x26C(0x4)
	struct FMulticastInlineDelegate OnChordCaptured;  // 0x270(0x10)
	struct FMulticastInlineDelegate OnChordRejected;  // 0x280(0x10)
	struct FMulticastInlineDelegate OnCapturePromptClosed;  // 0x290(0x10)
	struct TArray<struct FKey> KeysDown;  // 0x2A0(0x10)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool PreviousIgnoreInput : 1;  // 0x2B0(0x1)
	char pad_689[3];  // 0x2B1(0x3)
	struct FVector2D AccumulatedMouseDelta;  // 0x2B4(0x8)
	char pad_700[4];  // 0x2BC(0x4)

	bool IsKeyAllowed(struct FKey PrimaryKey); // Function AutoSettings.BindCapturePrompt.IsKeyAllowed
	struct FGameplayTag GetKeyGroup(); // Function AutoSettings.BindCapturePrompt.GetKeyGroup
	void Cancel(); // Function AutoSettings.BindCapturePrompt.Cancel
}; 



// Class AutoSettings.ToggleSetting
// Size: 0x2B0(Inherited: 0x2B0) 
struct UToggleSetting : public UAutoSettingWidget
{

	void UpdateToggleState(bool State); // Function AutoSettings.ToggleSetting.UpdateToggleState
	void ToggleStateUpdated(bool State); // Function AutoSettings.ToggleSetting.ToggleStateUpdated
}; 



// Class AutoSettings.CheckBoxSetting
// Size: 0x2B8(Inherited: 0x2B0) 
struct UCheckBoxSetting : public UToggleSetting
{
	struct UCheckBox* CheckBox;  // 0x2B0(0x8)

	void CheckBoxStateChanged(bool IsChecked); // Function AutoSettings.CheckBoxSetting.CheckBoxStateChanged
}; 



// Class AutoSettings.SelectSetting
// Size: 0x2D0(Inherited: 0x2B0) 
struct USelectSetting : public UAutoSettingWidget
{
	struct TArray<struct FSettingOption> Options;  // 0x2B0(0x10)
	USettingOptionFactory* OptionFactory;  // 0x2C0(0x8)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool bUpdatingSettingOptions : 1;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)

	void UpdateOptions(struct TArray<struct FSettingOption>& InOptions); // Function AutoSettings.SelectSetting.UpdateOptions
}; 



// Class AutoSettings.ComboBoxSetting
// Size: 0x2D8(Inherited: 0x2D0) 
struct UComboBoxSetting : public USelectSetting
{
	struct UComboBoxString* ComboBox;  // 0x2D0(0x8)

	void ComboBoxSelectionChanged(struct FString SelectedItem, char ESelectInfo SelectionType); // Function AutoSettings.ComboBoxSetting.ComboBoxSelectionChanged
}; 



// Class AutoSettings.Spinner
// Size: 0x290(Inherited: 0x260) 
struct USpinner : public UUserWidget
{
	struct TArray<struct FSettingOption> Options;  // 0x260(0x10)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool bAllowWrapping : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)
	struct FMulticastInlineDelegate SelectionChangedEvent;  // 0x278(0x10)
	char pad_648[8];  // 0x288(0x8)

	void SelectValue(struct FString Value); // Function AutoSettings.Spinner.SelectValue
	void SelectIndex(int32_t Index); // Function AutoSettings.Spinner.SelectIndex
	void Previous(); // Function AutoSettings.Spinner.Previous
	void Next(); // Function AutoSettings.Spinner.Next
	bool HasValidPrevious(); // Function AutoSettings.Spinner.HasValidPrevious
	bool HasValidNext(); // Function AutoSettings.Spinner.HasValidNext
	struct FSettingOption GetCurrentOption(); // Function AutoSettings.Spinner.GetCurrentOption
	int32_t GetCurrentIndex(); // Function AutoSettings.Spinner.GetCurrentIndex
}; 



// Class AutoSettings.ConsoleUtils
// Size: 0x28(Inherited: 0x28) 
struct UConsoleUtils : public UBlueprintFunctionLibrary
{

	void SetStringCVar(struct FName Name, struct FString Value); // Function AutoSettings.ConsoleUtils.SetStringCVar
	void SetIntCVar(struct FName Name, int32_t Value); // Function AutoSettings.ConsoleUtils.SetIntCVar
	void SetFloatCVar(struct FName Name, float Value); // Function AutoSettings.ConsoleUtils.SetFloatCVar
	void SetBoolCVar(struct FName Name, bool Value); // Function AutoSettings.ConsoleUtils.SetBoolCVar
	bool IsCVarRegistered(struct FName Name); // Function AutoSettings.ConsoleUtils.IsCVarRegistered
	struct FString GetStringCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetStringCVar
	int32_t GetIntCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetIntCVar
	float GetFloatCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetFloatCVar
	bool GetBoolCVar(struct FName Name); // Function AutoSettings.ConsoleUtils.GetBoolCVar
}; 



// Class AutoSettings.NativeSliderSetting
// Size: 0x2C8(Inherited: 0x2B8) 
struct UNativeSliderSetting : public USliderSetting
{
	struct USlider* Slider;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool bMouseCaptureInProgress : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)

	void SliderValueChanged(float NewValue); // Function AutoSettings.NativeSliderSetting.SliderValueChanged
	void SliderMouseCaptureEnd(); // Function AutoSettings.NativeSliderSetting.SliderMouseCaptureEnd
	void SliderMouseCaptureBegin(); // Function AutoSettings.NativeSliderSetting.SliderMouseCaptureBegin
}; 



// Class AutoSettings.CVarChangeListener
// Size: 0x80(Inherited: 0x28) 
struct UCVarChangeListener : public UObject
{
	char pad_40[88];  // 0x28(0x58)

}; 



// Class AutoSettings.CVarChangeListenerManager
// Size: 0x78(Inherited: 0x28) 
struct UCVarChangeListenerManager : public UObject
{
	struct TMap<struct FName, struct UCVarChangeListener*> Listeners;  // 0x28(0x50)

	void AddStringCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddStringCVarCallbackStatic
	void AddIntCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddIntCVarCallbackStatic
	void AddFloatCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddFloatCVarCallbackStatic
	void AddBoolCVarCallbackStatic(struct FName Name, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.CVarChangeListenerManager.AddBoolCVarCallbackStatic
}; 



// Class AutoSettings.GlobalKeyIconTagManager
// Size: 0x58(Inherited: 0x28) 
struct UGlobalKeyIconTagManager : public UObject
{
	struct FMulticastInlineDelegate OnGlobalKeyIconTagsModified;  // 0x28(0x10)
	struct FGameplayTagContainer GlobalKeyIconTags;  // 0x38(0x20)

	void SetGlobalKeyIconTags(struct FGameplayTagContainer InGlobalIconTags); // Function AutoSettings.GlobalKeyIconTagManager.SetGlobalKeyIconTags
	struct UTexture* GetIconForKey(struct FKey InKey, struct FGameplayTagContainer IconTags); // Function AutoSettings.GlobalKeyIconTagManager.GetIconForKey
}; 



// Class AutoSettings.InputMappingManager
// Size: 0x60(Inherited: 0x28) 
struct UInputMappingManager : public UObject
{
	char pad_40[24];  // 0x28(0x18)
	struct TArray<struct FPlayerInputMappings> PlayerInputOverrides;  // 0x40(0x10)
	struct TArray<struct APlayerController*> RegisteredPlayerControllers;  // 0x50(0x10)

	void SetPlayerKeyGroupStatic(struct APlayerController* Player, struct FGameplayTag KeyGroup); // Function AutoSettings.InputMappingManager.SetPlayerKeyGroupStatic
	void SetPlayerInputPresetStatic(struct APlayerController* Player, struct FInputMappingPreset Preset, bool bIsCustomized); // Function AutoSettings.InputMappingManager.SetPlayerInputPresetStatic
	void SetPlayerInputPresetByTag(struct APlayerController* Player, struct FGameplayTag PresetTag); // Function AutoSettings.InputMappingManager.SetPlayerInputPresetByTag
	void OnRegisteredPlayerControllerDestroyed(struct AActor* DestroyedActor); // Function AutoSettings.InputMappingManager.OnRegisteredPlayerControllerDestroyed
	bool InitializePlayerInputOverridesStatic(struct APlayerController* Player); // Function AutoSettings.InputMappingManager.InitializePlayerInputOverridesStatic
	struct FPlayerInputMappings GetPlayerInputMappingsStatic(struct APlayerController* Player); // Function AutoSettings.InputMappingManager.GetPlayerInputMappingsStatic
	struct TArray<struct FInputMappingPreset> GetDefaultInputPresets(); // Function AutoSettings.InputMappingManager.GetDefaultInputPresets
	void AddPlayerAxisOverrideStatic(struct APlayerController* Player, struct FInputAxisKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettings.InputMappingManager.AddPlayerAxisOverrideStatic
	void AddPlayerAxisOverride(struct APlayerController* Player, struct FInputAxisKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettings.InputMappingManager.AddPlayerAxisOverride
	void AddPlayerActionOverrideStatic(struct APlayerController* Player, struct FInputActionKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettings.InputMappingManager.AddPlayerActionOverrideStatic
	void AddPlayerActionOverride(struct APlayerController* Player, struct FInputActionKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettings.InputMappingManager.AddPlayerActionOverride
}; 



// Class AutoSettings.KeyLabel
// Size: 0x2C8(Inherited: 0x260) 
struct UKeyLabel : public UUserWidget
{
	struct FText KeyInvalidText;  // 0x260(0x18)
	struct FText LabelOverride;  // 0x278(0x18)
	struct FKey Key;  // 0x290(0x18)
	struct FGameplayTagContainer IconTags;  // 0x2A8(0x20)

	void UpdateKeyLabel(); // Function AutoSettings.KeyLabel.UpdateKeyLabel
	void OnGlobalKeyIconTagsModified(); // Function AutoSettings.KeyLabel.OnGlobalKeyIconTagsModified
	bool HasValidKey(); // Function AutoSettings.KeyLabel.HasValidKey
	bool HasIcon(); // Function AutoSettings.KeyLabel.HasIcon
	uint8_t  GetIconVisibility(); // Function AutoSettings.KeyLabel.GetIconVisibility
	struct FSlateBrush GetIconBrush(); // Function AutoSettings.KeyLabel.GetIconBrush
	struct UTexture* GetIcon(); // Function AutoSettings.KeyLabel.GetIcon
	uint8_t  GetDisplayNameVisibility(); // Function AutoSettings.KeyLabel.GetDisplayNameVisibility
	struct FText GetDisplayName(); // Function AutoSettings.KeyLabel.GetDisplayName
}; 



// Class AutoSettings.ResolutionStringUtils
// Size: 0x28(Inherited: 0x28) 
struct UResolutionStringUtils : public UBlueprintFunctionLibrary
{

}; 



// Class AutoSettings.SliderSetting
// Size: 0x2B8(Inherited: 0x2B0) 
struct USliderSetting : public UAutoSettingWidget
{
	float LeftValue;  // 0x2B0(0x4)
	float RightValue;  // 0x2B4(0x4)

	void UpdateSliderValue(float NormalizedValue, float RawValue); // Function AutoSettings.SliderSetting.UpdateSliderValue
	void SliderValueUpdated(float NormalizedValue); // Function AutoSettings.SliderSetting.SliderValueUpdated
	bool ShouldSaveCurrentValue(); // Function AutoSettings.SliderSetting.ShouldSaveCurrentValue
	void OnSliderValueUpdated(float NormalizedValue, float RawValue); // Function AutoSettings.SliderSetting.OnSliderValueUpdated
}; 



// Class AutoSettings.RadioButton
// Size: 0x2A0(Inherited: 0x260) 
struct URadioButton : public UUserWidget
{
	struct FMulticastInlineDelegate OnSelected;  // 0x260(0x10)
	struct FText Label;  // 0x270(0x18)
	struct FString Value;  // 0x288(0x10)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool Selected : 1;  // 0x298(0x1)
	char pad_665[7];  // 0x299(0x7)

	void UpdateSelected(bool InSelected); // Function AutoSettings.RadioButton.UpdateSelected
	void UpdateLabel(struct FText& InLabel); // Function AutoSettings.RadioButton.UpdateLabel
	void TriggerSelection(); // Function AutoSettings.RadioButton.TriggerSelection
	void SetValue(struct FString InValue); // Function AutoSettings.RadioButton.SetValue
	void SetSelected(bool InSelected); // Function AutoSettings.RadioButton.SetSelected
	void SetLabel(struct FText InLabel); // Function AutoSettings.RadioButton.SetLabel
	struct FString GetValue(); // Function AutoSettings.RadioButton.GetValue
	bool GetSelected(); // Function AutoSettings.RadioButton.GetSelected
	struct FText GetLabel(); // Function AutoSettings.RadioButton.GetLabel
}; 



// Class AutoSettings.RadioSelect
// Size: 0x2A0(Inherited: 0x260) 
struct URadioSelect : public UUserWidget
{
	struct TArray<struct FSettingOption> Options;  // 0x260(0x10)
	URadioButton* RadioButtonClass;  // 0x270(0x8)
	struct FMulticastInlineDelegate SelectionChangedEvent;  // 0x278(0x10)
	struct UPanelWidget* ButtonContainer;  // 0x288(0x8)
	struct TArray<struct URadioButton*> RadioButtons;  // 0x290(0x10)

	void SetOptions(struct TArray<struct FSettingOption> InOptions); // Function AutoSettings.RadioSelect.SetOptions
	void Select(struct FString Value); // Function AutoSettings.RadioSelect.Select
	void ButtonSelected(struct FString Value); // Function AutoSettings.RadioSelect.ButtonSelected
}; 



// Class AutoSettings.SettingOptionFactory
// Size: 0x28(Inherited: 0x28) 
struct USettingOptionFactory : public UObject
{

	struct TArray<struct FSettingOption> ConstructOptions(); // Function AutoSettings.SettingOptionFactory.ConstructOptions
}; 



// Class AutoSettings.ResolutionOptionFactory
// Size: 0x28(Inherited: 0x28) 
struct UResolutionOptionFactory : public USettingOptionFactory
{

}; 



// Class AutoSettings.ResolutionValueMask
// Size: 0x28(Inherited: 0x28) 
struct UResolutionValueMask : public USettingValueMask
{

}; 



// Class AutoSettings.SettingContainerUtils
// Size: 0x28(Inherited: 0x28) 
struct USettingContainerUtils : public UBlueprintFunctionLibrary
{

	void SaveChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.SaveChildSettings
	struct TArray<struct UAutoSettingWidget*> GetChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.GetChildSettings
	bool DoesAnyChildSettingHaveUnsavedChange(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnsavedChange
	bool DoesAnyChildSettingHaveUnappliedChange(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnappliedChange
	void CancelChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.CancelChildSettings
	void ApplyChildSettings(struct UUserWidget* UserWidget, struct UWidget* Parent); // Function AutoSettings.SettingContainerUtils.ApplyChildSettings
}; 



// Class AutoSettings.SettingsManager
// Size: 0x68(Inherited: 0x28) 
struct USettingsManager : public UObject
{
	struct FMulticastInlineDelegate OnSettingSaved;  // 0x28(0x10)
	struct FString IniName;  // 0x38(0x10)
	struct FString IniFilename;  // 0x48(0x10)
	struct FString SectionName;  // 0x58(0x10)

	void SaveSettingStatic(struct FAutoSettingData SettingData); // Function AutoSettings.SettingsManager.SaveSettingStatic
	void RegisterStringCVarSettingWithCallback(struct FName Name, struct FString DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterStringCVarSettingWithCallback
	void RegisterStringCVarSetting(struct FName Name, struct FString DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterStringCVarSetting
	void RegisterIntCVarSettingWithCallback(struct FName Name, int32_t DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterIntCVarSettingWithCallback
	void RegisterIntCVarSetting(struct FName Name, int32_t DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterIntCVarSetting
	void RegisterFloatCVarSettingWithCallback(struct FName Name, float DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterFloatCVarSettingWithCallback
	void RegisterFloatCVarSetting(struct FName Name, float DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterFloatCVarSetting
	void RegisterBoolCVarSettingWithCallback(struct FName Name, bool DefaultValue, struct FString Help, struct FDelegate ChangedCallback, bool CallbackImmediately); // Function AutoSettings.SettingsManager.RegisterBoolCVarSettingWithCallback
	void RegisterBoolCVarSetting(struct FName Name, bool DefaultValue, struct FString Help); // Function AutoSettings.SettingsManager.RegisterBoolCVarSetting
	struct FString GetValue(struct FName Key, bool bPreferConfigValue); // Function AutoSettings.SettingsManager.GetValue
	struct FString GetInitialValue(struct FName Key); // Function AutoSettings.SettingsManager.GetInitialValue
	void AutoDetectSettingsStatic(float& ResolutionQuality, int32_t& ViewDistanceQuality, int32_t& AntiAliasingQuality, int32_t& ShadowQuality, int32_t& PostProcessQuality, int32_t& TextureQuality, int32_t& EffectsQuality, int32_t& FoliageQuality, int32_t& ShadingQuality, float& CPUBenchmarkResults, float& GPUBenchmarkResults, struct TArray<float>& CPUBenchmarkSteps, struct TArray<float>& GPUBenchmarkSteps); // Function AutoSettings.SettingsManager.AutoDetectSettingsStatic
	void ApplySettingStatic(struct FAutoSettingData SettingData); // Function AutoSettings.SettingsManager.ApplySettingStatic
}; 



// Class AutoSettings.SpinnerSetting
// Size: 0x2D8(Inherited: 0x2D0) 
struct USpinnerSetting : public USelectSetting
{
	struct USpinner* Spinner;  // 0x2D0(0x8)

	void SpinnerSelectionChanged(struct FString Value); // Function AutoSettings.SpinnerSetting.SpinnerSelectionChanged
}; 



