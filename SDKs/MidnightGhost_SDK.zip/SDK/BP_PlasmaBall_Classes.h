#pragma once 
#include <BP_PlasmaBall_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PlasmaBall.BP_PlasmaBall_C
// Size: 0x36C(Inherited: 0x220) 
struct ABP_PlasmaBall_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* Niagara;  // 0x228(0x8)
	struct UParticleSystemComponent* Distortion;  // 0x230(0x8)
	struct UParticleSystemComponent* Sparks_07_EndFX;  // 0x238(0x8)
	struct USceneComponent* Sparks_07_EndScene;  // 0x240(0x8)
	struct UStaticMeshComponent* Sparks_07;  // 0x248(0x8)
	struct UParticleSystemComponent* Sparks_06_EndFX;  // 0x250(0x8)
	struct USceneComponent* Sparks_06_EndScene;  // 0x258(0x8)
	struct UStaticMeshComponent* Sparks_06;  // 0x260(0x8)
	struct UParticleSystemComponent* Sparks_05_EndFX;  // 0x268(0x8)
	struct USceneComponent* Sparks_05_EndScene;  // 0x270(0x8)
	struct UStaticMeshComponent* Sparks_05;  // 0x278(0x8)
	struct UParticleSystemComponent* Sparks_04_EndFX;  // 0x280(0x8)
	struct UParticleSystemComponent* NonInteractive_VFX;  // 0x288(0x8)
	struct USceneComponent* Sparks_04_EndScene;  // 0x290(0x8)
	struct USceneComponent* Sparks_02_EndScene;  // 0x298(0x8)
	struct UParticleSystemComponent* Sparks_03_EndFX;  // 0x2A0(0x8)
	struct USceneComponent* Sparks_03_EndScene;  // 0x2A8(0x8)
	struct UStaticMeshComponent* Sparks_03;  // 0x2B0(0x8)
	struct UParticleSystemComponent* Sparks_02_EndFX;  // 0x2B8(0x8)
	struct UStaticMeshComponent* Sparks_04;  // 0x2C0(0x8)
	struct UParticleSystemComponent* Sparks_02_EndVFX;  // 0x2C8(0x8)
	struct USceneComponent* Sparks_01_EndScene;  // 0x2D0(0x8)
	struct UStaticMeshComponent* Sparks_01;  // 0x2D8(0x8)
	struct UStaticMeshComponent* Core;  // 0x2E0(0x8)
	struct UStaticMeshComponent* Sparks_02;  // 0x2E8(0x8)
	struct USceneComponent* Old;  // 0x2F0(0x8)
	struct UPointLightComponent* CenterLight;  // 0x2F8(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool Found? : 1;  // 0x308(0x1)
	char pad_777_1 : 7;  // 0x309(0x1)
	bool Attached? : 1;  // 0x309(0x1)
	char pad_778[6];  // 0x30A(0x6)
	struct TArray<struct FPlasmaBallTendril> Tendrils;  // 0x310(0x10)
	struct FLinearColor TargetLightColor;  // 0x320(0x10)
	float TargetIntensity;  // 0x330(0x4)
	float MaxRandom;  // 0x334(0x4)
	float Scale;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct UAudioComponent* Crackle;  // 0x340(0x8)
	struct UMaterialInstanceDynamic* Sparks Mtl;  // 0x348(0x8)
	struct FLinearColor TargetColor;  // 0x350(0x10)
	struct UMaterialInstanceDynamic* Core Mtl;  // 0x360(0x8)
	float CoreIntensity;  // 0x368(0x4)

	void ReceiveTick(float DeltaSeconds); // Function BP_PlasmaBall.BP_PlasmaBall_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_PlasmaBall.BP_PlasmaBall_C.ReceiveBeginPlay
	void LightTargets(); // Function BP_PlasmaBall.BP_PlasmaBall_C.LightTargets
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_PlasmaBall.BP_PlasmaBall_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_PlasmaBall(int32_t EntryPoint); // Function BP_PlasmaBall.BP_PlasmaBall_C.ExecuteUbergraph_BP_PlasmaBall
}; 



