#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct AlreadyAssignedTeamInfo.AlreadyAssignedTeamInfo
// Size: 0x20(Inherited: 0x0) 
struct FAlreadyAssignedTeamInfo
{
	struct FString LobbyID_2_194A591E48A304F683754AAF80FF7A52;  // 0x0(0x10)
	struct FString LobbyLeaderID_4_7AA8064A4201996F246B98A86A5B1A1A;  // 0x10(0x10)

}; 
