#pragma once 
#include <BP_LightSwitch_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LightSwitch.BP_LightSwitch_C
// Size: 0x2E8(Inherited: 0x281) 
struct ABP_LightSwitch_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UTextRenderComponent* TextRender;  // 0x290(0x8)
	struct UBoxComponent* Box;  // 0x298(0x8)
	struct UStaticMeshComponent* Cube;  // 0x2A0(0x8)
	struct FString SwitchTag;  // 0x2A8(0x10)
	struct TArray<struct ABP_LightSwitchable_C*> MyLights;  // 0x2B8(0x10)
	struct APlayerController* ControlledPC;  // 0x2C8(0x8)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Active : 1;  // 0x2D0(0x1)
	char pad_721[7];  // 0x2D1(0x7)
	struct AActor* EndOverlapACTOR;  // 0x2D8(0x8)
	struct ABP_ManorChandelier_C* My_Chandolier;  // 0x2E0(0x8)

	void ReceiveBeginPlay(); // Function BP_LightSwitch.BP_LightSwitch_C.ReceiveBeginPlay
	void Server_LightSwitch(); // Function BP_LightSwitch.BP_LightSwitch_C.Server_LightSwitch
	void LightSwitch_Interact(struct AMGH_PlayerController_BP_C* Player Controller); // Function BP_LightSwitch.BP_LightSwitch_C.LightSwitch_Interact
	void MC_LightSwitch(bool On); // Function BP_LightSwitch.BP_LightSwitch_C.MC_LightSwitch
	void ExecuteUbergraph_BP_LightSwitch(int32_t EntryPoint); // Function BP_LightSwitch.BP_LightSwitch_C.ExecuteUbergraph_BP_LightSwitch
}; 



