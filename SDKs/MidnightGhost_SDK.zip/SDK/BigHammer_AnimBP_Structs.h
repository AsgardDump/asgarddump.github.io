#pragma once 
#include "SDK.h" 
 
 
// Function BigHammer_AnimBP.BigHammer_AnimBP_C.ExecuteUbergraph_BigHammer_AnimBP
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_BigHammer_AnimBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x8(0x8)
	struct ABP_BigHammer_Factory_C* K2Node_DynamicCast_AsBP_Big_Hammer_Factory;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float K2Node_Event_DeltaTimeX;  // 0x1C(0x4)

}; 
// Function BigHammer_AnimBP.BigHammer_AnimBP_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function BigHammer_AnimBP.BigHammer_AnimBP_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
