#pragma once 
#include <BP_KeyMapping_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KeyMapping.BP_KeyMapping_C
// Size: 0x58(Inherited: 0x28) 
struct UBP_KeyMapping_C : public UObject
{
	struct FString Name;  // 0x28(0x10)
	float Scale;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UBP_KeyCombination_C* Primary Combination;  // 0x40(0x8)
	struct UBP_KeyCombination_C* Secondary Combination;  // 0x48(0x8)
	struct UBP_KeyAction_C* Parent Action;  // 0x50(0x8)

	void Revert To Default KeyMapping(); // Function BP_KeyMapping.BP_KeyMapping_C.Revert To Default KeyMapping
	void Load Key Mapping(struct UBP_GameSettings_C* Game Settings, struct FString Action Name, struct FString Category); // Function BP_KeyMapping.BP_KeyMapping_C.Load Key Mapping
	void Save Key Mapping(struct UBP_GameSettings_C* Game Settings, struct FSKeyActionSave& KeySave); // Function BP_KeyMapping.BP_KeyMapping_C.Save Key Mapping
	void Key Mapping Current State(struct APlayerController* Player Controller, float& Mapping Value, bool& Is Active, bool& Just Pressed, bool& Just Released); // Function BP_KeyMapping.BP_KeyMapping_C.Key Mapping Current State
	void Init Key Mapping(struct FSKeyMapping Key Mapping, struct UBP_KeyMapping_C*& Mapping); // Function BP_KeyMapping.BP_KeyMapping_C.Init Key Mapping
}; 



