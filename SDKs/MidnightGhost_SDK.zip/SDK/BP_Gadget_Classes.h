#pragma once 
#include <BP_Gadget_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget.BP_Gadget_C
// Size: 0x25C(Inherited: 0x220) 
struct ABP_Gadget_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct TArray<struct UMeshComponent*> AllMyMeshes;  // 0x230(0x10)
	struct TScriptInterface<IHunterInterface_C> HunterInterface;  // 0x240(0x10)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool Equipped : 1;  // 0x250(0x1)
	char pad_593_1 : 7;  // 0x251(0x1)
	bool Sprinting : 1;  // 0x251(0x1)
	char pad_594_1 : 7;  // 0x252(0x1)
	bool In Air : 1;  // 0x252(0x1)
	char pad_595_1 : 7;  // 0x253(0x1)
	bool Is Dead : 1;  // 0x253(0x1)
	char HunterGadgets MyGadgetType;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	float UnequipDuration;  // 0x258(0x4)

	void GetUnequipDuration(float& Duration); // Function BP_Gadget.BP_Gadget_C.GetUnequipDuration
	void CanBeUnequipped(bool& CanBeUnequipped); // Function BP_Gadget.BP_Gadget_C.CanBeUnequipped
	void GetAmmoData(bool& GadgetUsesAmmo, int32_t& MaxAmmo, int32_t& CurrentAmmo); // Function BP_Gadget.BP_Gadget_C.GetAmmoData
	void GadgetErrorMessage(struct FText Text); // Function BP_Gadget.BP_Gadget_C.GadgetErrorMessage
	void GetGadgetType(char HunterGadgets& GadgetType); // Function BP_Gadget.BP_Gadget_C.GetGadgetType
	void IsEquipped(bool& Equipped); // Function BP_Gadget.BP_Gadget_C.IsEquipped
	void ChangeComponentTickSettings(struct USkeletalMeshComponent* InputPin, bool Should tick); // Function BP_Gadget.BP_Gadget_C.ChangeComponentTickSettings
	void SetHunterInterface(struct TScriptInterface<IHunterInterface_C> HunterInterface); // Function BP_Gadget.BP_Gadget_C.SetHunterInterface
	void GetTPActor(struct ABP_Gadget_TP_C*& TPActor); // Function BP_Gadget.BP_Gadget_C.GetTPActor
	void GetFPActor(struct ABP_Gadget_FP_C*& FPActor); // Function BP_Gadget.BP_Gadget_C.GetFPActor
	void GetMeshes(struct TArray<struct UMeshComponent*>& AllMyMeshes); // Function BP_Gadget.BP_Gadget_C.GetMeshes
	void FakeHolsterGadget(); // Function BP_Gadget.BP_Gadget_C.FakeHolsterGadget
	void FakeDrawGadget(); // Function BP_Gadget.BP_Gadget_C.FakeDrawGadget
	void SwitchToGadget(); // Function BP_Gadget.BP_Gadget_C.SwitchToGadget
	void UpdateVisibility(bool Hide, bool SkipAnimation, bool TickWhileHidden, bool NonLocallyControlledOrBot, bool ShouldInterrupt); // Function BP_Gadget.BP_Gadget_C.UpdateVisibility
	void Reload(); // Function BP_Gadget.BP_Gadget_C.Reload
	void Unequip(); // Function BP_Gadget.BP_Gadget_C.Unequip
	void OC_Startup(); // Function BP_Gadget.BP_Gadget_C.OC_Startup
	void Init(); // Function BP_Gadget.BP_Gadget_C.Init
	void Equip(); // Function BP_Gadget.BP_Gadget_C.Equip
	void ReceiveDestroyed(); // Function BP_Gadget.BP_Gadget_C.ReceiveDestroyed
	void SetOwnerStates(bool Sprinting, bool InAir, bool IsDead); // Function BP_Gadget.BP_Gadget_C.SetOwnerStates
	void Fire(); // Function BP_Gadget.BP_Gadget_C.Fire
	void StartHoldingFire(); // Function BP_Gadget.BP_Gadget_C.StartHoldingFire
	void StopHoldingFire(); // Function BP_Gadget.BP_Gadget_C.StopHoldingFire
	void ExecuteUbergraph_BP_Gadget(int32_t EntryPoint); // Function BP_Gadget.BP_Gadget_C.ExecuteUbergraph_BP_Gadget
}; 



