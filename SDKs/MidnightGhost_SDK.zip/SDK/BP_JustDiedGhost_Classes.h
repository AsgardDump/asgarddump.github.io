#pragma once 
#include <BP_JustDiedGhost_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_JustDiedGhost.BP_JustDiedGhost_C
// Size: 0x4D8(Inherited: 0x4C0) 
struct ABP_JustDiedGhost_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct USphereComponent* PingOverlap;  // 0x4C8(0x8)
	struct UCameraComponent* Camera1;  // 0x4D0(0x8)

	void ReceiveBeginPlay(); // Function BP_JustDiedGhost.BP_JustDiedGhost_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_JustDiedGhost(int32_t EntryPoint); // Function BP_JustDiedGhost.BP_JustDiedGhost_C.ExecuteUbergraph_BP_JustDiedGhost
}; 



