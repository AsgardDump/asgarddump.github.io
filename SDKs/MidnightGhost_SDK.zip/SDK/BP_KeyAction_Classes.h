#pragma once 
#include <BP_KeyAction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KeyAction.BP_KeyAction_C
// Size: 0x58(Inherited: 0x28) 
struct UBP_KeyAction_C : public UObject
{
	struct FString Action Name;  // 0x28(0x10)
	struct FString Category;  // 0x38(0x10)
	struct TArray<struct UBP_KeyMapping_C*> Key Mappings;  // 0x48(0x10)

	void Get Mapping(struct FString Mapping Name, struct UBP_KeyMapping_C*& Mapping, bool& Success); // Function BP_KeyAction.BP_KeyAction_C.Get Mapping
	void Load Action(struct UBP_GameSettings_C* Game Settings); // Function BP_KeyAction.BP_KeyAction_C.Load Action
	void Save Action(struct UBP_GameSettings_C* Game Settings); // Function BP_KeyAction.BP_KeyAction_C.Save Action
	void Key Action Current State(struct APlayerController* Player Controller, float& Action Axis Value, bool& Just Pressed, bool& Just Released); // Function BP_KeyAction.BP_KeyAction_C.Key Action Current State
	void Init Key Action(struct FSKeyAction Key Action, struct FString Action Name, struct UBP_KeyAction_C*& Action); // Function BP_KeyAction.BP_KeyAction_C.Init Key Action
}; 



