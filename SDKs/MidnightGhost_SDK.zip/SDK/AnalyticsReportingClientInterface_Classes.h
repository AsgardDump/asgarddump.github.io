#pragma once 
#include <AnalyticsReportingClientInterface_Structs.h>
 
 
 
// BlueprintGeneratedClass AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C
// Size: 0x28(Inherited: 0x28) 
struct UAnalyticsReportingClientInterface_C : public UInterface
{

	void On Gameplay Timer Tick(float DeltaTime); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.On Gameplay Timer Tick
	void Reset Round Length Timer(); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Reset Round Length Timer
	void Report Player Stats Loaded(int32_t Player Level, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Stats Loaded
	void Report Player Team Changed(char Team Team, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Team Changed
	void Report Party Status Changed(bool Party Status, int32_t Party Size, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Party Status Changed
	void Report Match Started(struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State, struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>>& All Player States, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Match Started
	void Report Player Level Up(int32_t New Level, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Level Up
	void Report Region Changed(char MGH_Regions region, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Region Changed
	void Report Match ID Changed(struct FString Match ID, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Match ID Changed
	void Report Player Login(bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Player Login
	void Report Match Ended(bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Match Ended
	void Report Gameplay Round Ended(struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State, char GameVictoryType Victory Type, struct FString Winning Team GUID, struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>>& All Player States, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Gameplay Round Ended
	void Report Leave Lobby(bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Leave Lobby
	void Report Tutorial Step Advanced(int32_t Step, char Team Team, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Tutorial Step Advanced
	void Report Tutorial Completed(bool Ghost F, Hunters T, bool Completed, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Tutorial Completed
	void Report Map Changed(struct FString Map, bool& Result); // Function AnalyticsReportingClientInterface.AnalyticsReportingClientInterface_C.Report Map Changed
}; 



