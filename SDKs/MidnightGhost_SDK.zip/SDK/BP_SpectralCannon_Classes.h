#pragma once 
#include <BP_SpectralCannon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SpectralCannon.BP_SpectralCannon_C
// Size: 0x352(Inherited: 0x220) 
struct ABP_SpectralCannon_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* TurbineLocation;  // 0x228(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x230(0x8)
	struct USphereComponent* THRP_Fire;  // 0x238(0x8)
	struct UParticleSystemComponent* PS_GPBAR_Souls_Vacuum;  // 0x240(0x8)
	struct USceneComponent* VacuumNull;  // 0x248(0x8)
	struct USphereComponent* Vacuum;  // 0x250(0x8)
	struct UStaticMeshComponent* GlowCylinder;  // 0x258(0x8)
	struct UStaticMeshComponent* GlowCylinderParent;  // 0x260(0x8)
	struct UPointLightComponent* InteractivePtLight;  // 0x268(0x8)
	struct USphereComponent* MuzzleFlashLoc;  // 0x270(0x8)
	struct USphereComponent* BeamParticleEnd;  // 0x278(0x8)
	struct USphereComponent* BeamCableAttach;  // 0x280(0x8)
	struct USphereComponent* NozzleLocation;  // 0x288(0x8)
	struct USkeletalMeshComponent* Hammerhead_SkelMesh;  // 0x290(0x8)
	struct USceneComponent* Scene;  // 0x298(0x8)
	struct FLinearColor Timeline_1_NewTrack_0_2A3376C6463C24DCEFB04D95A90447B3;  // 0x2A0(0x10)
	float Timeline_1_Intensity_2A3376C6463C24DCEFB04D95A90447B3;  // 0x2B0(0x4)
	char ETimelineDirection Timeline_1__Direction_2A3376C6463C24DCEFB04D95A90447B3;  // 0x2B4(0x1)
	char pad_693[3];  // 0x2B5(0x3)
	struct UTimelineComponent* Timeline_2;  // 0x2B8(0x8)
	float ChainsawAnimBP_Set_Playrate_67F67DA442C9A3CD267CCFB52F799395;  // 0x2C0(0x4)
	char ETimelineDirection ChainsawAnimBP_Set__Direction_67F67DA442C9A3CD267CCFB52F799395;  // 0x2C4(0x1)
	char pad_709[3];  // 0x2C5(0x3)
	struct UTimelineComponent* ChainsawAnimBP_Set;  // 0x2C8(0x8)
	struct UMaterialInstanceDynamic* LightMaterial;  // 0x2D0(0x8)
	struct ABP_Hunter_C* OwningHunter;  // 0x2D8(0x8)
	struct FLinearColor Material Emissive;  // 0x2E0(0x10)
	struct FLinearColor Interactive Light;  // 0x2F0(0x10)
	struct UMaterialInstanceDynamic* Chainsaw_Material;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool PlayingChains? : 1;  // 0x308(0x1)
	char pad_777_1 : 7;  // 0x309(0x1)
	bool Reversed? : 1;  // 0x309(0x1)
	char pad_778[2];  // 0x30A(0x2)
	float PlayRate;  // 0x30C(0x4)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool Third Person? : 1;  // 0x310(0x1)
	char pad_785[7];  // 0x311(0x7)
	struct UMaterialInstanceDynamic* RotationGlowMtl;  // 0x318(0x8)
	struct FLinearColor LightColorInterpCurrent;  // 0x320(0x10)
	struct FLinearColor InteractiveLightColorCurrent;  // 0x330(0x10)
	struct FLinearColor CurrentVacuumColor;  // 0x340(0x10)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool ForceVacuum? : 1;  // 0x350(0x1)
	char pad_849_1 : 7;  // 0x351(0x1)
	bool SpinUpForStartup? : 1;  // 0x351(0x1)

	void UserConstructionScript(); // Function BP_SpectralCannon.BP_SpectralCannon_C.UserConstructionScript
	void ChainsawAnimBP_Set__FinishedFunc(); // Function BP_SpectralCannon.BP_SpectralCannon_C.ChainsawAnimBP_Set__FinishedFunc
	void ChainsawAnimBP_Set__UpdateFunc(); // Function BP_SpectralCannon.BP_SpectralCannon_C.ChainsawAnimBP_Set__UpdateFunc
	void Timeline_1__FinishedFunc(); // Function BP_SpectralCannon.BP_SpectralCannon_C.Timeline_1__FinishedFunc
	void Timeline_1__UpdateFunc(); // Function BP_SpectralCannon.BP_SpectralCannon_C.Timeline_1__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_SpectralCannon.BP_SpectralCannon_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_SpectralCannon.BP_SpectralCannon_C.ReceiveTick
	void SetLightColor(struct ABP_SpectralCannon_C* BeamRifle, struct FLinearColor Color Emissive, struct FLinearColor InteractiveLight); // Function BP_SpectralCannon.BP_SpectralCannon_C.SetLightColor
	void MC_SetLightColor(struct ABP_SpectralCannon_C* BeamRifle, struct FLinearColor Color Emissive, struct FLinearColor Interactive Light); // Function BP_SpectralCannon.BP_SpectralCannon_C.MC_SetLightColor
	void Start_Chains(); // Function BP_SpectralCannon.BP_SpectralCannon_C.Start_Chains
	void Stop_Chains(); // Function BP_SpectralCannon.BP_SpectralCannon_C.Stop_Chains
	void SetFirstPerson(struct ABP_Hunter_C* Hunter); // Function BP_SpectralCannon.BP_SpectralCannon_C.SetFirstPerson
	void HideUnhideVacuum(bool Hide?); // Function BP_SpectralCannon.BP_SpectralCannon_C.HideUnhideVacuum
	void PullStringColor(); // Function BP_SpectralCannon.BP_SpectralCannon_C.PullStringColor
	void Server_PullStringColor(); // Function BP_SpectralCannon.BP_SpectralCannon_C.Server_PullStringColor
	void Spinup(); // Function BP_SpectralCannon.BP_SpectralCannon_C.Spinup
	void FailedStart(); // Function BP_SpectralCannon.BP_SpectralCannon_C.FailedStart
	void ExecuteUbergraph_BP_SpectralCannon(int32_t EntryPoint); // Function BP_SpectralCannon.BP_SpectralCannon_C.ExecuteUbergraph_BP_SpectralCannon
}; 



