#pragma once 
#include <AbilityManager_Structs.h>
 
 
 
// BlueprintGeneratedClass AbilityManager.AbilityManager_C
// Size: 0xB0(Inherited: 0xB0) 
struct UAbilityManager_C : public UActorComponent
{

	void  White Message!(struct FText Message); // Function AbilityManager.AbilityManager_C. White Message!
}; 



