#pragma once 
#include "SDK.h" 
 
 
// Function BP_SandingMachine.BP_SandingMachine_C.ExecuteUbergraph_BP_SandingMachine
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SandingMachine
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x18(0x8)
	struct AActor* K2Node_CustomEvent_ResponsibleActor;  // 0x20(0x8)
	struct AActor* K2Node_CustomEvent_Responsible_Actor;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x38(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x40(0x8)

}; 
// Function BP_SandingMachine.BP_SandingMachine_C.Server Begin SandingMachine
// Size: 0x8(Inherited: 0x0) 
struct FServer Begin SandingMachine
{
	struct AActor* Responsible Actor;  // 0x0(0x8)

}; 
// Function BP_SandingMachine.BP_SandingMachine_C.Begin SandingMachine
// Size: 0x8(Inherited: 0x0) 
struct FBegin SandingMachine
{
	struct AActor* ResponsibleActor;  // 0x0(0x8)

}; 
