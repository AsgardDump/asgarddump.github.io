#pragma once 
#include <BP_MiasmaGrow_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MiasmaGrow.BP_MiasmaGrow_C
// Size: 0x269(Inherited: 0x220) 
struct ABP_MiasmaGrow_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* MiasmaSmall;  // 0x228(0x8)
	struct USphereComponent* DmgOverlap;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float GrowDmgVolume_Grow_CBE95E104AEC54768EF0D89BFD957DF6;  // 0x240(0x4)
	char ETimelineDirection GrowDmgVolume__Direction_CBE95E104AEC54768EF0D89BFD957DF6;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* GrowDmgVolume;  // 0x248(0x8)
	struct ABP_Miasma_C* My_MiasmaBase;  // 0x250(0x8)
	struct TArray<struct AActor*> OverlappedDamageActors;  // 0x258(0x10)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool Done : 1;  // 0x268(0x1)

	void GrowDmgVolume__FinishedFunc(); // Function BP_MiasmaGrow.BP_MiasmaGrow_C.GrowDmgVolume__FinishedFunc
	void GrowDmgVolume__UpdateFunc(); // Function BP_MiasmaGrow.BP_MiasmaGrow_C.GrowDmgVolume__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_MiasmaGrow.BP_MiasmaGrow_C.ReceiveBeginPlay
	void BndEvt__DmgOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_MiasmaGrow.BP_MiasmaGrow_C.BndEvt__DmgOverlap_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__DmgOverlap_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_MiasmaGrow.BP_MiasmaGrow_C.BndEvt__DmgOverlap_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void ExecuteUbergraph_BP_MiasmaGrow(int32_t EntryPoint); // Function BP_MiasmaGrow.BP_MiasmaGrow_C.ExecuteUbergraph_BP_MiasmaGrow
}; 



