#pragma once 
#include "SDK.h" 
 
 
// Function BP_FactoryLamp.BP_FactoryLamp_C.UserConstructionScript
// Size: 0x96(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x0(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0xC(0x88)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x95(0x1)

}; 
// Function BP_FactoryLamp.BP_FactoryLamp_C.ExecuteUbergraph_BP_FactoryLamp
// Size: 0x62(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FactoryLamp
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x14(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x18(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x2C(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x30(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x48(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x61(0x1)

}; 
// Function BP_FactoryLamp.BP_FactoryLamp_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
