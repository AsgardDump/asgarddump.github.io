#pragma once 
#include "SDK.h" 
 
 
// Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutSetMaterial_D
// Size: 0x6C(Inherited: 0x0) 
struct FBlockoutSetMaterial_D
{
	struct UMeshComponent* StaticMesh;  // 0x0(0x8)
	struct UMaterialInterface* BlockoutMaterial;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool UseGrid : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Color;  // 0x14(0x10)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool UseTopColor : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FLinearColor TopColor;  // 0x28(0x10)
	struct UObject* __WorldContext;  // 0x38(0x8)
	float Temp_float_Variable;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x48(0x8)
	float Temp_float_Variable_2;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool Temp_bool_Variable : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	float Temp_float_Variable_3;  // 0x58(0x4)
	float K2Node_Select_Default;  // 0x5C(0x4)
	float Temp_float_Variable_4;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	float K2Node_Select_Default_2;  // 0x68(0x4)

}; 
// Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundVariables_D
// Size: 0xB8(Inherited: 0x0) 
struct FBlockoutRoundVariables_D
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool RoundSize : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float InFloat;  // 0x4(0x4)
	struct FVector InVector;  // 0x8(0xC)
	struct FVector2D InVector2D;  // 0x14(0x8)
	char pad_28[4];  // 0x1C(0x4)
	struct UObject* __WorldContext;  // 0x20(0x8)
	float OutFloat;  // 0x28(0x4)
	struct FVector OutVector;  // 0x2C(0xC)
	struct FVector2D OutVector2D;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Temp_bool_Variable : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_BreakVector2D_X;  // 0x44(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x48(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Round_ReturnValue_2;  // 0x50(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x54(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x58(0x4)
	float CallFunc_BreakVector_X;  // 0x5C(0x4)
	float CallFunc_BreakVector_Y;  // 0x60(0x4)
	float CallFunc_BreakVector_Z;  // 0x64(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x68(0x8)
	int32_t CallFunc_Round_ReturnValue_3;  // 0x70(0x4)
	int32_t CallFunc_Round_ReturnValue_4;  // 0x74(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_3;  // 0x78(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_4;  // 0x7C(0x4)
	int32_t CallFunc_Round_ReturnValue_5;  // 0x80(0x4)
	int32_t CallFunc_Round_ReturnValue_6;  // 0x84(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_5;  // 0x88(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_6;  // 0x8C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x90(0xC)
	float K2Node_Select_Default;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xA1(0x1)
	char pad_162[2];  // 0xA2(0x2)
	struct FVector K2Node_Select_Default_2;  // 0xA4(0xC)
	struct FVector2D K2Node_Select_Default_3;  // 0xB0(0x8)

}; 
// Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundFloat
// Size: 0x20(Inherited: 0x0) 
struct FBlockoutRoundFloat
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool RoundSize : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Float;  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Round_ReturnValue;  // 0x14(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x18(0x4)
	float K2Node_Select_Default;  // 0x1C(0x4)

}; 
// Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundVector
// Size: 0x58(Inherited: 0x0) 
struct FBlockoutRoundVector
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool RoundSize : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector Vector;  // 0x4(0xC)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_BreakVector_X;  // 0x1C(0x4)
	float CallFunc_BreakVector_Y;  // 0x20(0x4)
	float CallFunc_BreakVector_Z;  // 0x24(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0x28(0x4)
	int32_t CallFunc_Round_ReturnValue_2;  // 0x2C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x30(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x34(0x4)
	int32_t CallFunc_Round_ReturnValue_3;  // 0x38(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_3;  // 0x3C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x40(0xC)
	struct FVector K2Node_Select_Default;  // 0x4C(0xC)

}; 
// Function BlockoutToolsFunctions.BlockoutToolsFunctions_C.BlockoutRoundVector2D
// Size: 0x2C(Inherited: 0x0) 
struct FBlockoutRoundVector2D
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool RoundSize : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector2D Vector;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector2D CallFunc_ToRounded2D_ReturnValue;  // 0x1C(0x8)
	struct FVector2D K2Node_Select_Default;  // 0x24(0x8)

}; 
