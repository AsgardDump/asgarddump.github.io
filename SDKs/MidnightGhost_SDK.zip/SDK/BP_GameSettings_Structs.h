#pragma once 
#include "SDK.h" 
 
 
// Function BP_GameSettings.BP_GameSettings_C.Create Clone
// Size: 0x22(Inherited: 0x0) 
struct FCreate Clone
{
	struct UBP_GameSettings_C* Cloned Game Settings;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_DeleteGameInSlot_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct USaveGame* CallFunc_LoadGameFromSlot_ReturnValue;  // 0x10(0x8)
	struct UBP_GameSettings_C* K2Node_DynamicCast_AsBP_Game_Settings;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Anti Aliasing Quality
// Size: 0x28(Inherited: 0x0) 
struct FSet Anti Aliasing Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Get_Anti_Aliasing_Quality_Value;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString CallFunc_Get_Anti_Aliasing_Quality_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Look Horizontal Invert
// Size: 0x1(Inherited: 0x0) 
struct FGet Look Horizontal Invert
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Anti Aliasing Quality
// Size: 0x69(Inherited: 0x0) 
struct FModify Anti Aliasing Quality
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	int32_t CallFunc_Get_Anti_Aliasing_Quality_Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CallFunc_Get_Anti_Aliasing_Quality_Formatted;  // 0x20(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x68(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Apply Screen Settings
// Size: 0x62(Inherited: 0x0) 
struct FApply Screen Settings
{
	char EWindowMode CallFunc_Get_Screen_Mode_Screen_Mode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString CallFunc_Get_Screen_Mode_Command;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x18(0x1)
	char EWindowMode CallFunc_Get_Screen_Mode_Screen_Mode_2;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FString CallFunc_Get_Screen_Mode_Command_2;  // 0x20(0x10)
	struct FSVideoResolution CallFunc_Get_Screen_Resolution_Resolution;  // 0x30(0x8)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x38(0x8)
	struct FIntPoint K2Node_MakeStruct_IntPoint;  // 0x40(0x8)
	char EWindowMode CallFunc_Get_Screen_Mode_Screen_Mode_3;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString CallFunc_Get_Screen_Mode_Command_3;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x61(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Update Audio Emittor
// Size: 0x30(Inherited: 0x0) 
struct FUpdate Audio Emittor
{
	struct FSAudioUpdateStruct Emittor;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Is Valid : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Temp_float_Variable;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float Temp_float_Variable_2;  // 0x1C(0x4)
	char EAudioType Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float K2Node_Select_Default;  // 0x24(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x2C(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Gain Intensity
// Size: 0x14(Inherited: 0x0) 
struct FSet Gain Intensity
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Result;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)
	float CallFunc_Get_Gain_Intensity_Value;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Post Process Quality
// Size: 0x24(Inherited: 0x0) 
struct FSet Post Process Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Get_Post_Process_Quality_Value;  // 0xC(0x4)
	struct FString CallFunc_Get_Post_Process_Quality_Formatted;  // 0x10(0x10)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Gamma Intensity
// Size: 0x4(Inherited: 0x0) 
struct FGet Gamma Intensity
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Gain Intensity
// Size: 0x8(Inherited: 0x0) 
struct FModify Gain Intensity
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Gain_Intensity_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set View Distance
// Size: 0x14(Inherited: 0x0) 
struct FSet View Distance
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Result;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)
	float CallFunc_Get_View_Distance_Value;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Post Process Quality
// Size: 0x69(Inherited: 0x0) 
struct FModify Post Process Quality
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	int32_t CallFunc_Get_Post_Process_Quality_Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CallFunc_Get_Post_Process_Quality_Formatted;  // 0x20(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x68(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Look Vertical Sensitivity
// Size: 0x4(Inherited: 0x0) 
struct FGet Look Vertical Sensitivity
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Post Process Quality
// Size: 0x28(Inherited: 0x0) 
struct FGet Post Process Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Formatted;  // 0x8(0x10)
	struct FString CallFunc_Get_Text_Format_Quality_Level_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Text Format Quality Level
// Size: 0x70(Inherited: 0x0) 
struct FGet Text Format Quality Level
{
	int32_t Quality Level;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Formatted;  // 0x8(0x10)
	int32_t Temp_int_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Temp_string_Variable;  // 0x20(0x10)
	struct FString Temp_string_Variable_2;  // 0x30(0x10)
	struct FString Temp_string_Variable_3;  // 0x40(0x10)
	struct FString Temp_string_Variable_4;  // 0x50(0x10)
	struct FString K2Node_Select_Default;  // 0x60(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Anti Aliasing Quality
// Size: 0x28(Inherited: 0x0) 
struct FGet Anti Aliasing Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Formatted;  // 0x8(0x10)
	struct FString CallFunc_Get_Text_Format_Quality_Level_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify All Video Settings
// Size: 0x1(Inherited: 0x0) 
struct FModify All Video Settings
{
	char EModifySetting Modify;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Save Key Actions
// Size: 0x1D(Inherited: 0x0) 
struct FSave Key Actions
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UBP_KeyAction_C* CallFunc_Array_Get_Item;  // 0x10(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1C(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Volume Music
// Size: 0x4(Inherited: 0x0) 
struct FGet Volume Music
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Shadow Quality
// Size: 0x69(Inherited: 0x0) 
struct FModify Shadow Quality
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	int32_t CallFunc_Get_Shadow_Quality_Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CallFunc_Get_Shadow_Quality_Formatted;  // 0x20(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x68(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Shadow Quality
// Size: 0x28(Inherited: 0x0) 
struct FSet Shadow Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Get_Shadow_Quality_Value;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString CallFunc_Get_Shadow_Quality_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Shadow Quality
// Size: 0x28(Inherited: 0x0) 
struct FGet Shadow Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Formatted;  // 0x8(0x10)
	struct FString CallFunc_Get_Text_Format_Quality_Level_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Texture Quality
// Size: 0x69(Inherited: 0x0) 
struct FModify Texture Quality
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x18(0x18)
	int32_t CallFunc_Get_Texture_Quality_Value;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString CallFunc_Get_Texture_Quality_Formatted;  // 0x38(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x68(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Effect Quality
// Size: 0x69(Inherited: 0x0) 
struct FModify Effect Quality
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x18(0x18)
	int32_t CallFunc_Get_Effect_Quality_Value;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString CallFunc_Get_Effect_Quality_Formatted;  // 0x38(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x68(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Motion Blur Strength
// Size: 0x4(Inherited: 0x0) 
struct FGet Motion Blur Strength
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Texture Quality
// Size: 0x28(Inherited: 0x0) 
struct FSet Texture Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Get_Texture_Quality_Value;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString CallFunc_Get_Texture_Quality_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Effect Quality
// Size: 0x28(Inherited: 0x0) 
struct FSet Effect Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Get_Effect_Quality_Value;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString CallFunc_Get_Effect_Quality_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Resolution Scale
// Size: 0x14(Inherited: 0x0) 
struct FSet Resolution Scale
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Get_Resolution_Scale_Value;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Effect
// Size: 0x8(Inherited: 0x0) 
struct FModify Audio Multiplier Effect
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Audio_Multiplier_Effect_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Texture Quality
// Size: 0x28(Inherited: 0x0) 
struct FGet Texture Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Formatted;  // 0x8(0x10)
	struct FString CallFunc_Get_Text_Format_Quality_Level_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Look Horizontal Sensitivity
// Size: 0x8(Inherited: 0x0) 
struct FSet Look Horizontal Sensitivity
{
	float Set Value;  // 0x0(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Effect Quality
// Size: 0x28(Inherited: 0x0) 
struct FGet Effect Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Formatted;  // 0x8(0x10)
	struct FString CallFunc_Get_Text_Format_Quality_Level_Formatted;  // 0x18(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify View Distance
// Size: 0x51(Inherited: 0x0) 
struct FModify View Distance
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x18(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x50(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Gamma Intensity
// Size: 0x8(Inherited: 0x0) 
struct FModify Gamma Intensity
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Gamma_Intensity_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get View Distance
// Size: 0x4(Inherited: 0x0) 
struct FGet View Distance
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Field Of View
// Size: 0x8C(Inherited: 0x0) 
struct FModify Field Of View
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct UCameraComponent*> Non Valid Cameras;  // 0x8(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x24(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x2C(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UCameraComponent* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	struct UCameraComponent* CallFunc_Array_Get_Item_2;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x50(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x60(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x78(0x10)
	float CallFunc_Get_Field_Of_View_Value;  // 0x88(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Field Of View
// Size: 0x14(Inherited: 0x0) 
struct FSet Field Of View
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Result;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)
	float CallFunc_Get_Field_Of_View_Value;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Look Horizontal Sensitivity
// Size: 0x8(Inherited: 0x0) 
struct FModify Look Horizontal Sensitivity
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Look_Horizontal_Sensitivity_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Motion Blur Strength
// Size: 0x14(Inherited: 0x0) 
struct FSet Motion Blur Strength
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Result;  // 0x8(0x4)
	float CallFunc_Get_Motion_Blur_Strength_Value;  // 0xC(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Field Of View
// Size: 0x4(Inherited: 0x0) 
struct FGet Field Of View
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Add Field Of View Control To Camera
// Size: 0xC(Inherited: 0x0) 
struct FAdd Field Of View Control To Camera
{
	struct UCameraComponent* Camera;  // 0x0(0x8)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Remove Field Of View Control From Camera
// Size: 0x9(Inherited: 0x0) 
struct FRemove Field Of View Control From Camera
{
	struct UCameraComponent* Camera;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Master
// Size: 0x8(Inherited: 0x0) 
struct FModify Audio Multiplier Master
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Audio_Multiplier_Master_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Vsync
// Size: 0x6A(Inherited: 0x0) 
struct FModify Vsync
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Temp_string_Variable;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString Temp_string_Variable_2;  // 0x20(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Temp_bool_Variable : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString K2Node_Select_Default;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Get_Vsync_Value : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x69(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Master
// Size: 0xC(Inherited: 0x0) 
struct FSet Audio Multiplier Master
{
	float Set Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Vsync
// Size: 0x4(Inherited: 0x0) 
struct FSet Vsync
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Apply : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Result : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Get_Vsync_Value : 1;  // 0x3(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Init Key Bindings
// Size: 0x94(Inherited: 0x0) 
struct FInit Key Bindings
{
	struct TArray<struct FString> CheckDuplicateMappingNames;  // 0x0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UObject* CallFunc_Conv_InterfaceToObject_ReturnValue;  // 0x20(0x8)
	struct UBP_KeyAction_C* CallFunc_SpawnObject_ReturnValue;  // 0x28(0x8)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x44(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FSKeyAction CallFunc_GetDataTableRowFromName_OutRow;  // 0x50(0x20)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x78(0x10)
	struct UBP_KeyAction_C* CallFunc_Init_Key_Action_Action;  // 0x88(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x90(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Vsync
// Size: 0x1(Inherited: 0x0) 
struct FGet Vsync
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Bloom Intensity
// Size: 0x8(Inherited: 0x0) 
struct FModify Bloom Intensity
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Bloom_Intensity_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Bloom Intensity
// Size: 0x14(Inherited: 0x0) 
struct FSet Bloom Intensity
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Result;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)
	float CallFunc_Get_Bloom_Intensity_Value;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Bloom Intensity
// Size: 0x4(Inherited: 0x0) 
struct FGet Bloom Intensity
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get My Custom Checkbox
// Size: 0x1(Inherited: 0x0) 
struct FGet My Custom Checkbox
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Gamma Intensity
// Size: 0x14(Inherited: 0x0) 
struct FSet Gamma Intensity
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Result;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)
	float CallFunc_Get_Gamma_Intensity_Value;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Gain Intensity
// Size: 0x4(Inherited: 0x0) 
struct FGet Gain Intensity
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Screen Resolution
// Size: 0xC(Inherited: 0x0) 
struct FModify Screen Resolution
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FSVideoResolution CallFunc_Get_Screen_Resolution_Resolution;  // 0x4(0x8)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Foliage Quality
// Size: 0x69(Inherited: 0x0) 
struct FModify Foliage Quality
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	int32_t CallFunc_Get_Foliage_Quality_Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CallFunc_Get_Foliage_Quality_Formatted;  // 0x20(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x68(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Motion Blur Strength
// Size: 0x55(Inherited: 0x0) 
struct FModify Motion Blur Strength
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x18(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x40(0x10)
	float CallFunc_Get_Motion_Blur_Strength_Value;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x54(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Screen Resolution
// Size: 0x1C(Inherited: 0x0) 
struct FSet Screen Resolution
{
	struct FSVideoResolution Resolution;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Apply : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FSVideoResolution Result;  // 0xC(0x8)
	struct FSVideoResolution CallFunc_Get_Screen_Resolution_Resolution;  // 0x14(0x8)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Look Vertical Invert
// Size: 0x1(Inherited: 0x0) 
struct FSet Look Vertical Invert
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Set Value : 1;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Screen Mode
// Size: 0x18(Inherited: 0x0) 
struct FSet Screen Mode
{
	char EWindowMode Screen Mode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Apply : 1;  // 0x1(0x1)
	char EWindowMode Result;  // 0x2(0x1)
	char EWindowMode CallFunc_Get_Screen_Mode_Screen_Mode;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_Get_Screen_Mode_Command;  // 0x8(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Look Horizontal Sensitivity
// Size: 0x4(Inherited: 0x0) 
struct FGet Look Horizontal Sensitivity
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Screen Resolution
// Size: 0x10(Inherited: 0x0) 
struct FGet Screen Resolution
{
	struct FSVideoResolution Resolution;  // 0x0(0x8)
	struct FSVideoResolution K2Node_MakeStruct_SVideoResolution;  // 0x8(0x8)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Screen Mode
// Size: 0x60(Inherited: 0x0) 
struct FGet Screen Mode
{
	char EWindowMode Screen Mode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Command;  // 0x8(0x10)
	char EWindowMode Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString Temp_string_Variable;  // 0x20(0x10)
	struct FString Temp_string_Variable_2;  // 0x30(0x10)
	struct FString Temp_string_Variable_3;  // 0x40(0x10)
	struct FString K2Node_Select_Default;  // 0x50(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Screen Mode
// Size: 0x18(Inherited: 0x0) 
struct FModify Screen Mode
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char EWindowMode CallFunc_Get_Screen_Mode_Screen_Mode;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FString CallFunc_Get_Screen_Mode_Command;  // 0x8(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Look Vertical Sensitivity
// Size: 0x8(Inherited: 0x0) 
struct FModify Look Vertical Sensitivity
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Look_Vertical_Sensitivity_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Look Vertical Sensitivity
// Size: 0x8(Inherited: 0x0) 
struct FSet Look Vertical Sensitivity
{
	float Set Value;  // 0x0(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Look Horizontal Invert
// Size: 0x3(Inherited: 0x0) 
struct FModify Look Horizontal Invert
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Get_Look_Horizontal_Invert_Value : 1;  // 0x2(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Look Horizontal Invert
// Size: 0x1(Inherited: 0x0) 
struct FSet Look Horizontal Invert
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Set Value : 1;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Look Vertical Invert
// Size: 0x3(Inherited: 0x0) 
struct FModify Look Vertical Invert
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Get_Look_Vertical_Invert_Value : 1;  // 0x2(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Look Vertical Invert
// Size: 0x1(Inherited: 0x0) 
struct FGet Look Vertical Invert
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Master
// Size: 0x4(Inherited: 0x0) 
struct FGet Audio Multiplier Master
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Apply Audio Settings
// Size: 0xEC(Inherited: 0x0) 
struct FApply Audio Settings
{
	char EAudioType Audio Channel;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FSAudioUpdateStruct> Non Valid Audio Emittors;  // 0x8(0x10)
	char EAudioType Volume Channel;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x1C(0x4)
	struct TArray<struct FSAudioUpdateStruct> K2Node_MakeArray_Array;  // 0x20(0x10)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x30(0x4)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x34(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_2;  // 0x35(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_3;  // 0x36(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_4;  // 0x37(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_5;  // 0x38(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_6;  // 0x39(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_7;  // 0x3A(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_8;  // 0x3B(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_9;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FSAudioUpdateStruct CallFunc_Array_Get_Item;  // 0x40(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Update_Audio_Emittor_Is_Valid : 1;  // 0x54(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_10;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	struct FSAudioUpdateStruct CallFunc_Array_Get_Item_2;  // 0x58(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x70(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x80(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x90(0x10)
	char CallFunc_MakeLiteralByte_ReturnValue_11;  // 0xA0(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_12;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_Update_Audio_Channel__ : 1;  // 0xA2(0x1)
	char pad_163[1];  // 0xA3(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xA4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xB5(0x1)
	char pad_182_1 : 7;  // 0xB6(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xB6(0x1)
	char pad_183_1 : 7;  // 0xB7(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0xB7(0x1)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Update_Audio_Channel___2 : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0xBA(0x1)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool CallFunc_Update_Audio_Channel___3 : 1;  // 0xBB(0x1)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_Update_Audio_Channel___4 : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool CallFunc_Update_Audio_Channel___5 : 1;  // 0xBD(0x1)
	char pad_190[2];  // 0xBE(0x2)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_Update_Audio_Channel___6 : 1;  // 0xC4(0x1)
	char pad_197_1 : 7;  // 0xC5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xC5(0x1)
	char pad_198[2];  // 0xC6(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_5 : 1;  // 0xCC(0x1)
	char pad_205_1 : 7;  // 0xCD(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_6 : 1;  // 0xCD(0x1)
	char pad_206_1 : 7;  // 0xCE(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0xCE(0x1)
	char pad_207[1];  // 0xCF(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xD0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0xD4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0xD8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0xDC(0x4)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_7 : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_8 : 1;  // 0xE1(0x1)
	char pad_226_1 : 7;  // 0xE2(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0xE2(0x1)
	char pad_227_1 : 7;  // 0xE3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_9 : 1;  // 0xE3(0x1)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_10 : 1;  // 0xE4(0x1)
	char pad_229_1 : 7;  // 0xE5(0x1)
	bool CallFunc_BooleanOR_ReturnValue_5 : 1;  // 0xE5(0x1)
	char pad_230_1 : 7;  // 0xE6(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_11 : 1;  // 0xE6(0x1)
	char pad_231_1 : 7;  // 0xE7(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_12 : 1;  // 0xE7(0x1)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_BooleanOR_ReturnValue_6 : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_13 : 1;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_14 : 1;  // 0xEA(0x1)
	char pad_235_1 : 7;  // 0xEB(0x1)
	bool CallFunc_BooleanOR_ReturnValue_7 : 1;  // 0xEB(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Slider
// Size: 0x8(Inherited: 0x0) 
struct FModify My Custom Slider
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_My_Custom_Slider_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Add Volume Control
// Size: 0x28(Inherited: 0x0) 
struct FAdd Volume Control
{
	struct UAudioComponent* Audio Emittor;  // 0x0(0x8)
	char EAudioType Audio Channel;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FSAudioUpdateStruct K2Node_MakeStruct_SAudioUpdateStruct;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Update_Audio_Emittor_Is_Valid : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x24(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Volume Master
// Size: 0x4(Inherited: 0x0) 
struct FGet Volume Master
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Music
// Size: 0x8(Inherited: 0x0) 
struct FModify Audio Multiplier Music
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Audio_Multiplier_Music_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Music
// Size: 0xC(Inherited: 0x0) 
struct FSet Audio Multiplier Music
{
	float Set Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Music
// Size: 0x4(Inherited: 0x0) 
struct FGet Audio Multiplier Music
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Voice
// Size: 0x8(Inherited: 0x0) 
struct FModify Audio Multiplier Voice
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Audio_Multiplier_Voice_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Voice
// Size: 0xC(Inherited: 0x0) 
struct FSet Audio Multiplier Voice
{
	float Set Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Voice
// Size: 0x4(Inherited: 0x0) 
struct FGet Audio Multiplier Voice
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Volume Voice
// Size: 0x4(Inherited: 0x0) 
struct FGet Volume Voice
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Effect
// Size: 0xC(Inherited: 0x0) 
struct FSet Audio Multiplier Effect
{
	float Set Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Effect
// Size: 0x4(Inherited: 0x0) 
struct FGet Audio Multiplier Effect
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Volume Effect
// Size: 0x4(Inherited: 0x0) 
struct FGet Volume Effect
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Ambient
// Size: 0x8(Inherited: 0x0) 
struct FModify Audio Multiplier Ambient
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Audio_Multiplier_Ambient_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Ambient
// Size: 0xC(Inherited: 0x0) 
struct FSet Audio Multiplier Ambient
{
	float Set Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Ambient
// Size: 0x4(Inherited: 0x0) 
struct FGet Audio Multiplier Ambient
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Volume Ambient
// Size: 0x4(Inherited: 0x0) 
struct FGet Volume Ambient
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Look Sensitivity Combined Y
// Size: 0x30(Inherited: 0x0) 
struct FGet Look Sensitivity Combined Y
{
	float Input Axis Y;  // 0x0(0x4)
	float World Delta;  // 0x4(0x4)
	float Vertical Y;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)
	float Temp_float_Variable;  // 0x14(0x4)
	float Temp_float_Variable_2;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Get_Look_Vertical_Invert_Value : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float CallFunc_Get_Look_Vertical_Sensitivity_Value;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x24(0x4)
	float K2Node_Select_Default;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x2C(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify All Look Settings
// Size: 0x1(Inherited: 0x0) 
struct FModify All Look Settings
{
	char EModifySetting Modify;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify All Audio Settings
// Size: 0x1(Inherited: 0x0) 
struct FModify All Audio Settings
{
	char EModifySetting Modify;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify All Settings
// Size: 0x1(Inherited: 0x0) 
struct FModify All Settings
{
	char EModifySetting Modify;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Saved Key Inputs
// Size: 0x10(Inherited: 0x0) 
struct FGet Saved Key Inputs
{
	struct TArray<struct FSKeyActionSave> Saved Key Inputs;  // 0x0(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Save All Settings
// Size: 0x10(Inherited: 0x0) 
struct FSave All Settings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_SaveGameToSlot_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UBP_GameSettings_C* CallFunc_Create_Clone_Cloned_Game_Settings;  // 0x8(0x8)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Prepeare Previus Settings State
// Size: 0x8(Inherited: 0x0) 
struct FPrepeare Previus Settings State
{
	struct UBP_GameSettings_C* CallFunc_Create_Clone_Cloned_Game_Settings;  // 0x0(0x8)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Resolution Scale
// Size: 0x59(Inherited: 0x0) 
struct FModify Resolution Scale
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x18(0x18)
	int32_t CallFunc_Get_Resolution_Scale_Value;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Run_Console_Command__ : 1;  // 0x58(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Resolution Scale
// Size: 0x4(Inherited: 0x0) 
struct FGet Resolution Scale
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify All MyCustom Settings
// Size: 0x1(Inherited: 0x0) 
struct FModify All MyCustom Settings
{
	char EModifySetting Modify;  // 0x0(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Checkbox
// Size: 0x3(Inherited: 0x0) 
struct FModify My Custom Checkbox
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Get_My_Custom_Checkbox_Value : 1;  // 0x2(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set My Custom Checkbox
// Size: 0x4(Inherited: 0x0) 
struct FSet My Custom Checkbox
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Apply : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Result : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Get_My_Custom_Checkbox_Value : 1;  // 0x3(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set My Custom Slider
// Size: 0x14(Inherited: 0x0) 
struct FSet My Custom Slider
{
	float Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Result;  // 0x8(0x4)
	float CallFunc_Get_My_Custom_Slider_Value;  // 0xC(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x10(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Save ini Settings
// Size: 0xC8(Inherited: 0x0) 
struct FSave ini Settings
{
	int32_t CallFunc_Get_Foliage_Quality_Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_Get_Foliage_Quality_Formatted;  // 0x8(0x10)
	int32_t CallFunc_Get_Resolution_Scale_Value;  // 0x18(0x4)
	char EWindowMode CallFunc_Get_Screen_Mode_Screen_Mode;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FString CallFunc_Get_Screen_Mode_Command;  // 0x20(0x10)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Get_Vsync_Value : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FSVideoResolution CallFunc_Get_Screen_Resolution_Resolution;  // 0x38(0x8)
	int32_t CallFunc_Get_Post_Process_Quality_Value;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString CallFunc_Get_Post_Process_Quality_Formatted;  // 0x48(0x10)
	int32_t CallFunc_Get_Effect_Quality_Value;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_Get_Effect_Quality_Formatted;  // 0x60(0x10)
	struct FIntPoint K2Node_MakeStruct_IntPoint;  // 0x70(0x8)
	int32_t CallFunc_Get_Texture_Quality_Value;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FString CallFunc_Get_Texture_Quality_Formatted;  // 0x80(0x10)
	int32_t CallFunc_Get_Shadow_Quality_Value;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FString CallFunc_Get_Shadow_Quality_Formatted;  // 0x98(0x10)
	int32_t CallFunc_Get_Anti_Aliasing_Quality_Value;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct FString CallFunc_Get_Anti_Aliasing_Quality_Formatted;  // 0xB0(0x10)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0xC0(0x8)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get My Custom Slider
// Size: 0x4(Inherited: 0x0) 
struct FGet My Custom Slider
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Radiobox
// Size: 0x8(Inherited: 0x0) 
struct FModify My Custom Radiobox
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t CallFunc_Get_My_Custom_Radiobox_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set My Custom Radiobox
// Size: 0x10(Inherited: 0x0) 
struct FSet My Custom Radiobox
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Get_My_Custom_Radiobox_Value;  // 0xC(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get My Custom Radiobox
// Size: 0x4(Inherited: 0x0) 
struct FGet My Custom Radiobox
{
	int32_t Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Combobox
// Size: 0x18(Inherited: 0x0) 
struct FModify My Custom Combobox
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_Get_My_Custom_Combobox_Value;  // 0x8(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set My Custom Combobox
// Size: 0x38(Inherited: 0x0) 
struct FSet My Custom Combobox
{
	struct FString Value;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Apply : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Result;  // 0x18(0x10)
	struct FString CallFunc_Get_My_Custom_Combobox_Value;  // 0x28(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get My Custom Combobox
// Size: 0x10(Inherited: 0x0) 
struct FGet My Custom Combobox
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Look Sensitivity Combined X
// Size: 0x30(Inherited: 0x0) 
struct FGet Look Sensitivity Combined X
{
	float Input Axis X;  // 0x0(0x4)
	float World Delta;  // 0x4(0x4)
	float Horizontal X;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)
	float Temp_float_Variable;  // 0x14(0x4)
	float Temp_float_Variable_2;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Get_Look_Horizontal_Invert_Value : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float CallFunc_Get_Look_Horizontal_Sensitivity_Value;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x24(0x4)
	float K2Node_Select_Default;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x2C(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Delete Settings Save File
// Size: 0x100(Inherited: 0x0) 
struct FDelete Settings Save File
{
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x0(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DeleteGameInSlot_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x70(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x80(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x90(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_7;  // 0xA0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_8;  // 0xB0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_9;  // 0xC0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_10;  // 0xD0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_11;  // 0xE0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_12;  // 0xF0(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Update Actions Input State
// Size: 0x31(Inherited: 0x0) 
struct FUpdate Actions Input State
{
	float Real Time Seconds;  // 0x0(0x4)
	float World Delta Seconds;  // 0x4(0x4)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UBP_KeyInput_C* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Fill Float Axis Inputs List
// Size: 0x81(Inherited: 0x0) 
struct FFill Float Axis Inputs List
{
	int32_t Temp_int_Loop_Counter_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x24(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x2C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UBP_KeyAction_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UBP_KeyMapping_C* CallFunc_Array_Get_Item_2;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct UBP_KeyInput_C* CallFunc_Array_Get_Item_3;  // 0x58(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x60(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_Key_IsAxis1D_ReturnValue : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x6C(0x4)
	struct UBP_KeyInput_C* CallFunc_Array_Get_Item_4;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Key_IsAxis1D_ReturnValue_2 : 1;  // 0x80(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Key Action
// Size: 0x64(Inherited: 0x0) 
struct FGet Key Action
{
	struct FString Input Action Name;  // 0x0(0x10)
	struct UBP_KeyAction_C* Input Action;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Success : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x20(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x38(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct UBP_KeyAction_C* CallFunc_Array_Get_Item;  // 0x50(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_EqualEqual_StriStri_ReturnValue : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Store Key Input
// Size: 0x5C(Inherited: 0x0) 
struct FStore Key Input
{
	struct FSKeyActionSave KeySave;  // 0x0(0x58)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x58(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Load Key Actions
// Size: 0x19(Inherited: 0x0) 
struct FLoad Key Actions
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC(0x4)
	struct UBP_KeyAction_C* CallFunc_Array_Get_Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Keybindings
// Size: 0xB4(Inherited: 0x0) 
struct FModify Keybindings
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x24(0x4)
	struct UBP_KeyAction_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct UBP_KeyMapping_C* CallFunc_Array_Get_Item_2;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x40(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FSKeyActionSave CallFunc_Array_Get_Item_3;  // 0x50(0x58)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xB0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Generate Keybinding Conflicts
// Size: 0xB9(Inherited: 0x0) 
struct FGenerate Keybinding Conflicts
{
	int32_t Found Conflicts;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FSKeyConflict> Conflicting Mappings;  // 0x8(0x10)
	struct TArray<struct UBP_KeyCombination_C*> Combinations;  // 0x18(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x2C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x30(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FSKeyConflict CallFunc_Array_Get_Item;  // 0x40(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x54(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct TArray<struct UBP_KeyCombination_C*> CallFunc_Get_All_Combinations_Combinations;  // 0x60(0x10)
	struct UBP_KeyCombination_C* CallFunc_Array_Get_Item_2;  // 0x70(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_Equal_All_Conflicts_Result : 1;  // 0x7D(0x1)
	char pad_126[2];  // 0x7E(0x2)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x88(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x8C(0x4)
	struct UBP_KeyCombination_C* CallFunc_Array_Get_Item_3;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x98(0x1)
	char EKeyConflict CallFunc_Detect_Conflict_Conflict_Type;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)
	struct FSKeyConflict K2Node_MakeStruct_SKeyConflict;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0xB8(0x1)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get All Combinations
// Size: 0x60(Inherited: 0x0) 
struct FGet All Combinations
{
	struct TArray<struct UBP_KeyCombination_C*> Combinations;  // 0x0(0x10)
	struct TArray<struct UBP_KeyCombination_C*> Input Combinations;  // 0x10(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x24(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x2C(0x4)
	struct UBP_KeyAction_C* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct UBP_KeyMapping_C* CallFunc_Array_Get_Item_2;  // 0x40(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x48(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x4C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x58(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x5C(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Game Settings Interface
// Size: 0x10(Inherited: 0x0) 
struct FSet Game Settings Interface
{
	struct TScriptInterface<IBPI_GameSettingsInterface_C> Game Settings Interface;  // 0x0(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Save File Name
// Size: 0x10(Inherited: 0x0) 
struct FSet Save File Name
{
	struct FString Save File Name;  // 0x0(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Save File User Index
// Size: 0x4(Inherited: 0x0) 
struct FSet Save File User Index
{
	int32_t Save File User Index;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get All Key Actions
// Size: 0x10(Inherited: 0x0) 
struct FGet All Key Actions
{
	struct TArray<struct UBP_KeyAction_C*> Key Actions;  // 0x0(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Init Save Game Settings
// Size: 0x10(Inherited: 0x0) 
struct FInit Save Game Settings
{
	struct TScriptInterface<IBPI_GameSettingsInterface_C> Game Settings Interface;  // 0x0(0x10)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Load ini Settings
// Size: 0x78(Inherited: 0x0) 
struct FLoad ini Settings
{
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x0(0x8)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleNormalized;  // 0x8(0x4)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleValue;  // 0xC(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MinScaleValue;  // 0x10(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MaxScaleValue;  // 0x14(0x4)
	char EWindowMode CallFunc_GetFullscreenMode_ReturnValue;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Round_ReturnValue;  // 0x1C(0x4)
	char EWindowMode CallFunc_Set_Screen_Mode_Result;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Set_Resolution_Scale_Result;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsVSyncEnabled_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_GetFoliageQuality_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Set_Vsync_Result : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Set_Foliage_Quality_Result;  // 0x34(0x4)
	struct FIntPoint CallFunc_GetScreenResolution_ReturnValue;  // 0x38(0x8)
	int32_t CallFunc_GetPostProcessingQuality_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_Set_Post_Process_Quality_Result;  // 0x44(0x4)
	struct FSVideoResolution K2Node_MakeStruct_SVideoResolution;  // 0x48(0x8)
	int32_t CallFunc_GetVisualEffectQuality_ReturnValue;  // 0x50(0x4)
	struct FSVideoResolution CallFunc_Set_Screen_Resolution_Result;  // 0x54(0x8)
	int32_t CallFunc_Set_Effect_Quality_Result;  // 0x5C(0x4)
	int32_t CallFunc_GetTextureQuality_ReturnValue;  // 0x60(0x4)
	int32_t CallFunc_GetShadowQuality_ReturnValue;  // 0x64(0x4)
	int32_t CallFunc_Set_Texture_Quality_Result;  // 0x68(0x4)
	int32_t CallFunc_Set_Shadow_Quality_Result;  // 0x6C(0x4)
	int32_t CallFunc_GetAntiAliasingQuality_ReturnValue;  // 0x70(0x4)
	int32_t CallFunc_Set_Anti_Aliasing_Quality_Result;  // 0x74(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier UI
// Size: 0x8(Inherited: 0x0) 
struct FModify Audio Multiplier UI
{
	char EModifySetting Modify;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Get_Audio_Multiplier_UI_Value;  // 0x4(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier UI
// Size: 0xC(Inherited: 0x0) 
struct FSet Audio Multiplier UI
{
	float Set Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier UI
// Size: 0x4(Inherited: 0x0) 
struct FGet Audio Multiplier UI
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Volume UI
// Size: 0x4(Inherited: 0x0) 
struct FGet Volume UI
{
	float Value;  // 0x0(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Set Foliage Quality
// Size: 0x24(Inherited: 0x0) 
struct FSet Foliage Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Apply : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Result;  // 0x8(0x4)
	int32_t CallFunc_Get_Foliage_Quality_Value;  // 0xC(0x4)
	struct FString CallFunc_Get_Foliage_Quality_Formatted;  // 0x10(0x10)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_GameSettings.BP_GameSettings_C.Get Foliage Quality
// Size: 0x28(Inherited: 0x0) 
struct FGet Foliage Quality
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Formatted;  // 0x8(0x10)
	struct FString CallFunc_Get_Text_Format_Quality_Level_Formatted;  // 0x18(0x10)

}; 
