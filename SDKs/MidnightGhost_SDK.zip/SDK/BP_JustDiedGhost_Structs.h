#pragma once 
#include "SDK.h" 
 
 
// Function BP_JustDiedGhost.BP_JustDiedGhost_C.ExecuteUbergraph_BP_JustDiedGhost
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_JustDiedGhost
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
