#pragma once 
#include <BP_HunterSpawnPoint_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HunterSpawnPoint.BP_HunterSpawnPoint_C
// Size: 0x228(Inherited: 0x220) 
struct ABP_HunterSpawnPoint_C : public AActor
{
	struct UBillboardComponent* Billboard;  // 0x220(0x8)

}; 



