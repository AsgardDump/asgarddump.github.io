#pragma once 
#include "SDK.h" 
 
 
// Function BP_CaptureActor.BP_CaptureActor_C.ExecuteUbergraph_BP_CaptureActor
// Size: 0x9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CaptureActor
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_CustomEvent_bActive : 1;  // 0x8(0x1)

}; 
// Function BP_CaptureActor.BP_CaptureActor_C.UpdateCaptureCharacter
// Size: 0x1(Inherited: 0x0) 
struct FUpdateCaptureCharacter
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)

}; 
