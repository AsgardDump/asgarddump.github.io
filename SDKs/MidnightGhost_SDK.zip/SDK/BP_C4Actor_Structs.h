#pragma once 
#include "SDK.h" 
 
 
// Function BP_C4Actor.BP_C4Actor_C.InterpToRotation
// Size: 0xC(Inherited: 0x0) 
struct FInterpToRotation
{
	struct FRotator Rotator;  // 0x0(0xC)

}; 
// Function BP_C4Actor.BP_C4Actor_C.ExecuteUbergraph_BP_C4Actor
// Size: 0x731(Inherited: 0x0) 
struct FExecuteUbergraph_BP_C4Actor
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	struct UProjectileMovementComponent* CallFunc_AddComponent_ReturnValue;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FTransform Temp_struct_Variable_2;  // 0x50(0x30)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x80(0x8)
	struct UProjectileMovementComponent* CallFunc_AddComponent_ReturnValue_2;  // 0x88(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue_2;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x9C(0x4)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0xA0(0x8)
	struct AActor* K2Node_Event_Other;  // 0xA8(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0xBC(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0xC8(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0xD4(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0xE0(0x88)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x168(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x174(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x180(0xC)
	char pad_396[4];  // 0x18C(0x4)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0x190(0x8)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x198(0x1)
	char pad_409[7];  // 0x199(0x7)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x1A9(0x1)
	char pad_426_1 : 7;  // 0x1AA(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1AA(0x1)
	char pad_427[5];  // 0x1AB(0x5)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled_ : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot_ : 1;  // 0x1B9(0x1)
	char pad_442[6];  // 0x1BA(0x6)
	struct AProp_C* K2Node_CustomEvent_Prop_2;  // 0x1C0(0x8)
	struct FVector_NetQuantize K2Node_CustomEvent_Offset_4;  // 0x1C8(0xC)
	char pad_468_1 : 7;  // 0x1D4(0x1)
	bool K2Node_CustomEvent_Delay : 1;  // 0x1D4(0x1)
	char pad_469[3];  // 0x1D5(0x3)
	struct AProp_C* K2Node_CustomEvent_Prop;  // 0x1D8(0x8)
	struct FVector_NetQuantize K2Node_CustomEvent_Offset_3;  // 0x1E0(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1EC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x1F8(0xC)
	char pad_516[4];  // 0x204(0x4)
	struct USkeletalMeshComponent* CallFunc_Array_Get_Item;  // 0x208(0x8)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x210(0x88)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x298(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x299(0x1)
	char pad_666_1 : 7;  // 0x29A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x29A(0x1)
	char pad_667_1 : 7;  // 0x29B(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x29B(0x1)
	char pad_668[4];  // 0x29C(0x4)
	struct ALvlProp_C* K2Node_CustomEvent_Lvlprop_2;  // 0x2A0(0x8)
	struct FVector_NetQuantize K2Node_CustomEvent_Offset_2;  // 0x2A8(0xC)
	char pad_692[4];  // 0x2B4(0x4)
	struct ALvlProp_C* K2Node_CustomEvent_Lvlprop;  // 0x2B8(0x8)
	struct FVector_NetQuantize K2Node_CustomEvent_Offset;  // 0x2C0(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x2CC(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x2D8(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_2;  // 0x2E4(0x88)
	char pad_876_1 : 7;  // 0x36C(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_2 : 1;  // 0x36C(0x1)
	char pad_877[3];  // 0x36D(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x370(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x37C(0xC)
	float CallFunc_BreakVector_X;  // 0x388(0x4)
	float CallFunc_BreakVector_Y;  // 0x38C(0x4)
	float CallFunc_BreakVector_Z;  // 0x390(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x394(0x4)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize;  // 0x398(0xC)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x3A4(0x4)
	char pad_936[8];  // 0x3A8(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x3B0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x3E0(0x8)
	struct ABP_C4Explosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x3E8(0x8)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x3F0(0x1)
	char pad_1009_1 : 7;  // 0x3F1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x3F1(0x1)
	char pad_1010_1 : 7;  // 0x3F2(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x3F2(0x1)
	char pad_1011_1 : 7;  // 0x3F3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x3F3(0x1)
	char pad_1012_1 : 7;  // 0x3F4(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x3F4(0x1)
	char pad_1013[3];  // 0x3F5(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x3F8(0xC)
	char pad_1028[4];  // 0x404(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x408(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_Controller_2;  // 0x410(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x418(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_Controller;  // 0x420(0x8)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x428(0x8)
	char pad_1072_1 : 7;  // 0x430(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x430(0x1)
	char pad_1073[15];  // 0x431(0xF)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x440(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x470(0x8)
	struct ABP_C4Interact_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x478(0x8)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x480(0x1)
	char pad_1153_1 : 7;  // 0x481(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x481(0x1)
	char pad_1154_1 : 7;  // 0x482(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x482(0x1)
	char pad_1155[1];  // 0x483(0x1)
	struct FRotator K2Node_CustomEvent_Rotator;  // 0x484(0xC)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x490(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x49C(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x4A8(0x88)
	struct FVector_NetQuantize K2Node_CustomEvent_Location_2;  // 0x530(0xC)
	struct FVector_NetQuantize K2Node_CustomEvent_Location;  // 0x53C(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_5;  // 0x548(0xC)
	struct FVector CallFunc_VLerp_ReturnValue;  // 0x554(0xC)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x560(0x8)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_3;  // 0x568(0x88)
	char pad_1520_1 : 7;  // 0x5F0(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_3 : 1;  // 0x5F0(0x1)
	char pad_1521[7];  // 0x5F1(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x5F8(0x8)
	char pad_1536_1 : 7;  // 0x600(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x600(0x1)
	char pad_1537_1 : 7;  // 0x601(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled__2 : 1;  // 0x601(0x1)
	char pad_1538_1 : 7;  // 0x602(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot__2 : 1;  // 0x602(0x1)
	char pad_1539[1];  // 0x603(0x1)
	int32_t K2Node_CustomEvent_Damage;  // 0x604(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_6;  // 0x608(0xC)
	char pad_1556[12];  // 0x614(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x620(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_3;  // 0x650(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x658(0x4)
	char pad_1628[4];  // 0x65C(0x4)
	struct ABP_Sound_C* CallFunc_FinishSpawningActor_ReturnValue_3;  // 0x660(0x8)
	char pad_1640[8];  // 0x668(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue_3;  // 0x670(0x30)
	char pad_1696_1 : 7;  // 0x6A0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x6A0(0x1)
	char pad_1697[7];  // 0x6A1(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_4;  // 0x6A8(0x8)
	struct ABP_C4Destroyed_C* CallFunc_FinishSpawningActor_ReturnValue_4;  // 0x6B0(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x6B8(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x6C0(0x8)
	char pad_1736_1 : 7;  // 0x6C8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x6C8(0x1)
	char pad_1737[7];  // 0x6C9(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x6D0(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State;  // 0x6D8(0x8)
	char pad_1760_1 : 7;  // 0x6E0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x6E0(0x1)
	char pad_1761[7];  // 0x6E1(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x6E8(0x8)
	struct AMGH_GameState_C* K2Node_DynamicCast_AsMGH_Game_State_2;  // 0x6F0(0x8)
	char pad_1784_1 : 7;  // 0x6F8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x6F8(0x1)
	char pad_1785[3];  // 0x6F9(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue_3;  // 0x6FC(0x4)
	char pad_1792_1 : 7;  // 0x700(0x1)
	bool K2Node_CustomEvent_See_ : 1;  // 0x700(0x1)
	char pad_1793_1 : 7;  // 0x701(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x701(0x1)
	char pad_1794[2];  // 0x702(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x704(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x710(0x8)
	char pad_1816_1 : 7;  // 0x718(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x718(0x1)
	char pad_1817[7];  // 0x719(0x7)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x720(0x10)
	char pad_1840_1 : 7;  // 0x730(0x1)
	bool K2Node_SwitchString_CmpSuccess : 1;  // 0x730(0x1)

}; 
// Function BP_C4Actor.BP_C4Actor_C.Server_PickUpC4
// Size: 0x8(Inherited: 0x0) 
struct FServer_PickUpC4
{
	struct AMGH_PlayerController_BP_C* Controller;  // 0x0(0x8)

}; 
// Function BP_C4Actor.BP_C4Actor_C.SetSeeThroughWalls
// Size: 0x1(Inherited: 0x0) 
struct FSetSeeThroughWalls
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool See? : 1;  // 0x0(0x1)

}; 
// Function BP_C4Actor.BP_C4Actor_C.Server_DamageC4
// Size: 0x4(Inherited: 0x0) 
struct FServer_DamageC4
{
	int32_t Damage;  // 0x0(0x4)

}; 
// Function BP_C4Actor.BP_C4Actor_C.PickUpC4
// Size: 0x8(Inherited: 0x0) 
struct FPickUpC4
{
	struct AMGH_PlayerController_BP_C* Controller;  // 0x0(0x8)

}; 
// Function BP_C4Actor.BP_C4Actor_C.Server_AttachToProp
// Size: 0x15(Inherited: 0x0) 
struct FServer_AttachToProp
{
	struct AProp_C* Prop;  // 0x0(0x8)
	struct FVector_NetQuantize Offset;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Delay : 1;  // 0x14(0x1)

}; 
// Function BP_C4Actor.BP_C4Actor_C.MC_InterpToLocation
// Size: 0xC(Inherited: 0x0) 
struct FMC_InterpToLocation
{
	struct FVector_NetQuantize Location;  // 0x0(0xC)

}; 
// Function BP_C4Actor.BP_C4Actor_C.Server_InterpToLocation
// Size: 0xC(Inherited: 0x0) 
struct FServer_InterpToLocation
{
	struct FVector_NetQuantize Location;  // 0x0(0xC)

}; 
// Function BP_C4Actor.BP_C4Actor_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_C4Actor.BP_C4Actor_C.MC_AttachToLvlprop
// Size: 0x14(Inherited: 0x0) 
struct FMC_AttachToLvlprop
{
	struct ALvlProp_C* LvlProp;  // 0x0(0x8)
	struct FVector_NetQuantize Offset;  // 0x8(0xC)

}; 
// Function BP_C4Actor.BP_C4Actor_C.Server_AttachToLvlprop
// Size: 0x14(Inherited: 0x0) 
struct FServer_AttachToLvlprop
{
	struct ALvlProp_C* LvlProp;  // 0x0(0x8)
	struct FVector_NetQuantize Offset;  // 0x8(0xC)

}; 
// Function BP_C4Actor.BP_C4Actor_C.MC_AttachToProp
// Size: 0x14(Inherited: 0x0) 
struct FMC_AttachToProp
{
	struct AProp_C* Prop;  // 0x0(0x8)
	struct FVector_NetQuantize Offset;  // 0x8(0xC)

}; 
// Function BP_C4Actor.BP_C4Actor_C.ReceiveHit
// Size: 0xC8(Inherited: 0xC8) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x88)

}; 
// Function BP_C4Actor.BP_C4Actor_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_C4Actor.BP_C4Actor_C.GetProjectileOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetProjectileOwner
{
	struct ABP_Hunter_C* Hunter;  // 0x0(0x8)

}; 
