#pragma once 
#include "SDK.h" 
 
 
// Function BP_PlayerState_MainMenu.BP_PlayerState_MainMenu_C.ExecuteUbergraph_BP_PlayerState_MainMenu
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PlayerState_MainMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString K2Node_CustomEvent_IPPort;  // 0x8(0x10)
	struct FString K2Node_CustomEvent_Player_Session_ID;  // 0x18(0x10)

}; 
// Function BP_PlayerState_MainMenu.BP_PlayerState_MainMenu_C.GetMGHPlayerName
// Size: 0x1BA(Inherited: 0x0) 
struct FGetMGHPlayerName
{
	struct FString MGHPlayerName;  // 0x0(0x10)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> K2Node_DynamicCast_AsMGH_Player_State_Interface;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> K2Node_DynamicCast_AsMGH_Player_State_Interface_2;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_GetStreamerID_Int_StreamerID;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_GetAnonymousID_Int_IsAnonymous_ : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t CallFunc_GetAnonymousID_Int_ID;  // 0x44(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x48(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x88(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x98(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xB0(0x40)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0xF0(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x100(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x110(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0x128(0x10)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x138(0x8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x140(0x1)
	char pad_321[7];  // 0x141(0x7)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x148(0x10)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_GetStreamerMode_Int_StreamerMode : 1;  // 0x159(0x1)
	char pad_346[6];  // 0x15A(0x6)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_2;  // 0x160(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_2;  // 0x168(0x10)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x180(0x10)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_3;  // 0x190(0x8)
	struct FString CallFunc_ChatProfanityFilter_Int_Filtered;  // 0x198(0x10)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_3;  // 0x1A8(0x10)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool CallFunc_GetPAXEastBuild_Int_PAXEast : 1;  // 0x1B9(0x1)

}; 
// Function BP_PlayerState_MainMenu.BP_PlayerState_MainMenu_C.OC_JoinThisServer
// Size: 0x20(Inherited: 0x0) 
struct FOC_JoinThisServer
{
	struct FString IPPort;  // 0x0(0x10)
	struct FString Player Session ID;  // 0x10(0x10)

}; 
