#pragma once 
#include <BP_BoomboxInteractVan_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BoomboxInteractVan.BP_BoomboxInteractVan_C
// Size: 0x300(Inherited: 0x2A8) 
struct ABP_BoomboxInteractVan_C : public ABP_interactiveObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)
	struct UPointLightComponent* PointLight;  // 0x2B0(0x8)
	struct UBoxComponent* Box;  // 0x2B8(0x8)
	struct UStaticMeshComponent* StaticMesh1_1;  // 0x2C0(0x8)
	struct UMaterialInstanceDynamic* BoomboxMaterial;  // 0x2C8(0x8)
	struct UMaterialInstanceDynamic* Tape Material;  // 0x2D0(0x8)
	struct UMaterialInstanceDynamic* DMI_Graph;  // 0x2D8(0x8)
	float RepeatTimeBoomBox;  // 0x2E0(0x4)
	char pad_740_1 : 7;  // 0x2E4(0x1)
	bool MusicIsPlaying : 1;  // 0x2E4(0x1)
	char pad_741[3];  // 0x2E5(0x3)
	struct AActor* MyVan;  // 0x2E8(0x8)
	char MGHMusicTracks Song Playing;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct UTexture2D* Art;  // 0x2F8(0x8)

	void getInteractData(struct FText& interactionTextHUD, bool& UseImageTextPrompt, struct UTexture2D*& ImageTextIcon, struct FText& ImageText1, struct FText& ImageText2); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.getInteractData
	void CanIInteract_Int(bool& BlockInteract, struct FText& ErrorMessage); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.CanIInteract_Int
	void CanIPickUp_Int(struct AActor* RequestingActor, bool& OK); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.CanIPickUp_Int
	void ReceiveBeginPlay(); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.ReceiveBeginPlay
	void UpdateBoomboxMaterial(); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.UpdateBoomboxMaterial
	void Interact_Implementation(); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.Interact_Implementation
	void Interact_LocalClient_Implementation(struct AActor* ActivatingActor); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.Interact_LocalClient_Implementation
	void ExecuteUbergraph_BP_BoomboxInteractVan(int32_t EntryPoint); // Function BP_BoomboxInteractVan.BP_BoomboxInteractVan_C.ExecuteUbergraph_BP_BoomboxInteractVan
}; 



