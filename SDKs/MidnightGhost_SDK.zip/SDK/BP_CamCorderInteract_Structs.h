#pragma once 
#include "SDK.h" 
 
 
// Function BP_CamCorderInteract.BP_CamCorderInteract_C.ExecuteUbergraph_BP_CamCorderInteract
// Size: 0x58(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CamCorderInteract
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TScriptInterface<IMiscPossessableProp_C> K2Node_DynamicCast_AsMisc_Possessable_Prop;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool K2Node_Event_Collide : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool K2Node_Event_Visible : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	struct TScriptInterface<ICamCorderInterface_C> K2Node_DynamicCast_AsCam_Corder_Interface;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TScriptInterface<IMiscPossessableProp_C> K2Node_DynamicCast_AsMisc_Possessable_Prop_2;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AActor* K2Node_Event_Actor;  // 0x50(0x8)

}; 
// Function BP_CamCorderInteract.BP_CamCorderInteract_C.SetOwnerInfo_Int
// Size: 0x8(Inherited: 0x0) 
struct FSetOwnerInfo_Int
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function BP_CamCorderInteract.BP_CamCorderInteract_C.SetOutlineVisibility_Int
// Size: 0x1(Inherited: 0x0) 
struct FSetOutlineVisibility_Int
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Visible : 1;  // 0x0(0x1)

}; 
// Function BP_CamCorderInteract.BP_CamCorderInteract_C.getInteractData
// Size: 0x58(Inherited: 0x58) 
struct FgetInteractData : public FgetInteractData
{
	struct FText interactionTextHUD;  // 0x0(0x18)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool UseImageTextPrompt : 1;  // 0x18(0x1)
	struct UTexture2D* ImageTextIcon;  // 0x20(0x8)
	struct FText ImageText1;  // 0x28(0x18)
	struct FText ImageText2;  // 0x40(0x18)

}; 
// Function BP_CamCorderInteract.BP_CamCorderInteract_C.GetOwnerInfo_Int
// Size: 0x28(Inherited: 0x0) 
struct FGetOwnerInfo_Int
{
	struct AActor* Owner;  // 0x0(0x8)
	struct TScriptInterface<IMiscPossessableProp_C> K2Node_DynamicCast_AsMisc_Possessable_Prop;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AActor* CallFunc_GetOwnerInfo_Int_Owner;  // 0x20(0x8)

}; 
// Function BP_CamCorderInteract.BP_CamCorderInteract_C.SetCameraCollide_Int
// Size: 0x1(Inherited: 0x0) 
struct FSetCameraCollide_Int
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Collide : 1;  // 0x0(0x1)

}; 
