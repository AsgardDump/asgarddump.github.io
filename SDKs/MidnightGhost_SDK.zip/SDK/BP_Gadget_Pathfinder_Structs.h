#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.ExecuteUbergraph_BP_Gadget_Pathfinder
// Size: 0xAD(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget_Pathfinder
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledHunter : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledBot : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledHunter_2 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledBot_2 : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xB(0x1)
	char pad_12[4];  // 0xC(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x18(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x20(0x30)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x60(0x8)
	struct ABP_Gadget_TP_Pathfinder_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x68(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x70(0x8)
	struct UHunter_ThirdPerson_AnimBP_C* K2Node_DynamicCast_AsHunter_Third_Person_Anim_BP;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x88(0x8)
	struct ABP_Gadget_FP_Pathfinder_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x90(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x98(0x8)
	struct UPathfinder_TP_AnimBP_C* K2Node_DynamicCast_AsPathfinder_TP_Anim_BP;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledHunter_3 : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledBot_3 : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0xAC(0x1)

}; 
// Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.GetFPActor
// Size: 0x8(Inherited: 0x8) 
struct FGetFPActor : public FGetFPActor
{
	struct ABP_Gadget_FP_C* FPActor;  // 0x0(0x8)

}; 
// Function BP_Gadget_Pathfinder.BP_Gadget_Pathfinder_C.GetTPActor
// Size: 0x8(Inherited: 0x8) 
struct FGetTPActor : public FGetTPActor
{
	struct ABP_Gadget_TP_C* TPActor;  // 0x0(0x8)

}; 
