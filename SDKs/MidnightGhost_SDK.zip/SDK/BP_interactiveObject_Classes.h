#pragma once 
#include <BP_InteractiveObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_InteractiveObject.BP_interactiveObject_C
// Size: 0x281(Inherited: 0x220) 
struct ABP_interactiveObject_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	float MaxDistance;  // 0x230(0x4)
	char pad_564_1 : 7;  // 0x234(0x1)
	bool FactoryHammer? : 1;  // 0x234(0x1)
	char pad_565_1 : 7;  // 0x235(0x1)
	bool GhostShrine? : 1;  // 0x235(0x1)
	char pad_566_1 : 7;  // 0x236(0x1)
	bool C4? : 1;  // 0x236(0x1)
	char pad_567_1 : 7;  // 0x237(0x1)
	bool Tutorial_RedShrine? : 1;  // 0x237(0x1)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool Tutorial_LimboShrine? : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct FTransform XForm;  // 0x240(0x30)
	struct FRotator ControlRotation;  // 0x270(0xC)
	char pad_636_1 : 7;  // 0x27C(0x1)
	bool Tutorial_Shrine? : 1;  // 0x27C(0x1)
	char pad_637_1 : 7;  // 0x27D(0x1)
	bool Tutorial_Shrine_RedLight? : 1;  // 0x27D(0x1)
	char pad_638_1 : 7;  // 0x27E(0x1)
	bool Disabled : 1;  // 0x27E(0x1)
	char pad_639_1 : 7;  // 0x27F(0x1)
	bool IsMedicKit : 1;  // 0x27F(0x1)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool SandingMachine? : 1;  // 0x280(0x1)

	void IsThisMyGadget?(struct ABP_Hunter_C* Hunter, bool& YES); // Function BP_InteractiveObject.BP_interactiveObject_C.IsThisMyGadget?
	void MedicKit_GetHealChargesRemaining(int32_t& Remaining); // Function BP_InteractiveObject.BP_interactiveObject_C.MedicKit_GetHealChargesRemaining
	void AmICloseEnough?(struct AActor* Start Point, bool& True); // Function BP_InteractiveObject.BP_interactiveObject_C.AmICloseEnough?
	void MC_Interact(); // Function BP_InteractiveObject.BP_interactiveObject_C.MC_Interact
	void Interact_Interactive Object(struct AMGH_PlayerController_BP_C* Controller, bool Alternate?); // Function BP_InteractiveObject.BP_interactiveObject_C.Interact_Interactive Object
	void ExecuteUbergraph_BP_interactiveObject(int32_t EntryPoint); // Function BP_InteractiveObject.BP_interactiveObject_C.ExecuteUbergraph_BP_interactiveObject
}; 



