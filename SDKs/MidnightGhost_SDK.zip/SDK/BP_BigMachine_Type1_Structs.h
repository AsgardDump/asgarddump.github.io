#pragma once 
#include "SDK.h" 
 
 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.BndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.ExecuteUbergraph_BP_BigMachine_Type1
// Size: 0x260(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BigMachine_Type1
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x14(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x18(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x28(0x8)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x30(0x8)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x38(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x40(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x50(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x58(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x68(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x70(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x80(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x88(0x10)
	struct FName Temp_name_Variable;  // 0x98(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0xA8(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0xB0(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xB8(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xBC(0x4)
	struct AActor* K2Node_CustomEvent_ResponsibleActor_2;  // 0xC0(0x8)
	struct AActor* K2Node_CustomEvent_ResponsibleActor;  // 0xC8(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_CustomEvent_Active : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xF9(0x1)
	char pad_250[6];  // 0xFA(0x6)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_3;  // 0x100(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_4;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x118(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x120(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x128(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x130(0x4)
	char pad_308_1 : 7;  // 0x134(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x134(0x1)
	char pad_309[3];  // 0x135(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x138(0x88)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x1C0(0x8)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1C8(0x1)
	char pad_457[3];  // 0x1C9(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1CC(0xC)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x1E8(0x8)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1F0(0x1)
	char pad_497[3];  // 0x1F1(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1F4(0xC)
	struct TScriptInterface<IDamageInterface_C> K2Node_DynamicCast_AsDamage_Interface;  // 0x200(0x10)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x210(0x1)
	char pad_529[3];  // 0x211(0x3)
	float CallFunc_BreakVector_X;  // 0x214(0x4)
	float CallFunc_BreakVector_Y;  // 0x218(0x4)
	float CallFunc_BreakVector_Z;  // 0x21C(0x4)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize;  // 0x220(0xC)
	char pad_556[4];  // 0x22C(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x230(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x238(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x240(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x250(0x1)
	char pad_593_1 : 7;  // 0x251(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x251(0x1)
	char pad_594[2];  // 0x252(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x254(0xC)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.MC_BeginHammer
// Size: 0x1(Inherited: 0x0) 
struct FMC_BeginHammer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Active : 1;  // 0x0(0x1)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnBlendOut_67E18769446B4C9EE1D7A4B8123D802D
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_67E18769446B4C9EE1D7A4B8123D802D
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.Server_BeginHammer
// Size: 0x8(Inherited: 0x0) 
struct FServer_BeginHammer
{
	struct AActor* ResponsibleActor;  // 0x0(0x8)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.BeginHammer
// Size: 0x8(Inherited: 0x0) 
struct FBeginHammer
{
	struct AActor* ResponsibleActor;  // 0x0(0x8)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnCompleted_67E18769446B4C9EE1D7A4B8123D802D
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_67E18769446B4C9EE1D7A4B8123D802D
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnInterrupted_67E18769446B4C9EE1D7A4B8123D802D
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_67E18769446B4C9EE1D7A4B8123D802D
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnNotifyBegin_67E18769446B4C9EE1D7A4B8123D802D
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_67E18769446B4C9EE1D7A4B8123D802D
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnNotifyEnd_67E18769446B4C9EE1D7A4B8123D802D
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_67E18769446B4C9EE1D7A4B8123D802D
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.TriggerCameraShakes
// Size: 0xA0(Inherited: 0x0) 
struct FTriggerCameraShakes
{
	float HunterShakeMult;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x8(0x8)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x20(0x8)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x48(0x8)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue_3;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x5C(0xC)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x6C(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue_2;  // 0x80(0x8)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x88(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct UCameraShakeBase* CallFunc_StartCameraShakeFromSource_ReturnValue;  // 0x98(0x8)

}; 
