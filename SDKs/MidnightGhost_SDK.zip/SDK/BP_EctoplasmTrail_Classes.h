#pragma once 
#include <BP_EctoplasmTrail_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EctoplasmTrail.BP_EctoplasmTrail_C
// Size: 0x2E8(Inherited: 0x220) 
struct ABP_EctoplasmTrail_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Sphere;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Timeline_0_Opacity_55C0BF7C4F52AB58630D8C83005A5375;  // 0x238(0x4)
	char ETimelineDirection Timeline_0__Direction_55C0BF7C4F52AB58630D8C83005A5375;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x240(0x8)
	float FadeInMaterial_Opacity_2FA1214F47ED7C557570DFA59F04281C;  // 0x248(0x4)
	char ETimelineDirection FadeInMaterial__Direction_2FA1214F47ED7C557570DFA59F04281C;  // 0x24C(0x1)
	char pad_589[3];  // 0x24D(0x3)
	struct UTimelineComponent* FadeInMaterial;  // 0x250(0x8)
	float FadeoutMaterial_Opacity_4FFC3B614B7EC8ABB33CB38857DE1D50;  // 0x258(0x4)
	char ETimelineDirection FadeoutMaterial__Direction_4FFC3B614B7EC8ABB33CB38857DE1D50;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct UTimelineComponent* FadeoutMaterial;  // 0x260(0x8)
	float FadeoutSlow_Opacity_7E746A1E4712AE46EC61D586DEF04B5D;  // 0x268(0x4)
	char ETimelineDirection FadeoutSlow__Direction_7E746A1E4712AE46EC61D586DEF04B5D;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct UTimelineComponent* FadeoutSlow;  // 0x270(0x8)
	struct ACharacter* OwnerCharacter;  // 0x278(0x8)
	struct UDecalComponent* MyDecal;  // 0x280(0x8)
	struct UMaterialInstanceDynamic* EctoplasmTrailMaterialRef;  // 0x288(0x8)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool Skip Fade Out? : 1;  // 0x290(0x1)
	char Ghost_SizeClass Size Class;  // 0x291(0x1)
	char pad_658_1 : 7;  // 0x292(0x1)
	bool Fading Out! : 1;  // 0x292(0x1)
	char pad_659[1];  // 0x293(0x1)
	float Direction;  // 0x294(0x4)
	float Length;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	struct UMaterialInterface* DecalMaterial;  // 0x2A0(0x8)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Corrupted? : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool CorruptedLvlprop? : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool Local : 1;  // 0x2AA(0x1)
	char pad_683[1];  // 0x2AB(0x1)
	float Freshness;  // 0x2AC(0x4)
	struct FTransform MyOriginalTransform;  // 0x2B0(0x30)
	struct ABP_EctoplasmTrail_C* RemoveTrail;  // 0x2E0(0x8)

	void CheckOwnerDistance?(bool&  OK); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.CheckOwnerDistance?
	void UserConstructionScript(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.UserConstructionScript
	void FadeoutMaterial__FinishedFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeoutMaterial__FinishedFunc
	void FadeoutMaterial__UpdateFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeoutMaterial__UpdateFunc
	void FadeoutSlow__FinishedFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeoutSlow__FinishedFunc
	void FadeoutSlow__UpdateFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeoutSlow__UpdateFunc
	void FadeInMaterial__FinishedFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeInMaterial__FinishedFunc
	void FadeInMaterial__UpdateFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeInMaterial__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.Timeline_0__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.ReceiveBeginPlay
	void FadeOut(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeOut
	void SetHidden?(bool Hidden?); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.SetHidden?
	void Fadeout_Slow(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.Fadeout_Slow
	void FadeIn(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.FadeIn
	void Corruption_Fadeout(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.Corruption_Fadeout
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.ReceiveEndPlay
	void ReceiveDestroyed(); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.ReceiveDestroyed
	void ExecuteUbergraph_BP_EctoplasmTrail(int32_t EntryPoint); // Function BP_EctoplasmTrail.BP_EctoplasmTrail_C.ExecuteUbergraph_BP_EctoplasmTrail
}; 



