#pragma once 
#include "SDK.h" 
 
 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.ExecuteUbergraph_BP_Gadget_SpectralCannon
// Size: 0xA80(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Gadget_SpectralCannon
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName K2Node_CustomEvent_NotifyName_20;  // 0x4(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	struct FName K2Node_CustomEvent_NotifyName_19;  // 0x1C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	struct FName K2Node_CustomEvent_NotifyName_18;  // 0x34(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x3C(0x10)
	struct FName K2Node_CustomEvent_NotifyName_17;  // 0x4C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x54(0x10)
	struct FName K2Node_CustomEvent_NotifyName_16;  // 0x64(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x6C(0x10)
	struct FName Temp_name_Variable;  // 0x7C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x84(0x10)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	struct FName K2Node_CustomEvent_NotifyName_15;  // 0x98(0x8)
	struct FName K2Node_CustomEvent_NotifyName_14;  // 0xA0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0xA8(0x10)
	struct FName K2Node_CustomEvent_NotifyName_13;  // 0xB8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0xC0(0x10)
	struct FName K2Node_CustomEvent_NotifyName_12;  // 0xD0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0xD8(0x10)
	struct FName K2Node_CustomEvent_NotifyName_11;  // 0xE8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10;  // 0xF0(0x10)
	struct FName Temp_name_Variable_2;  // 0x100(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11;  // 0x108(0x10)
	struct FName K2Node_CustomEvent_NotifyName_10;  // 0x118(0x8)
	struct FName K2Node_CustomEvent_NotifyName_9;  // 0x120(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12;  // 0x128(0x10)
	struct FName K2Node_CustomEvent_NotifyName_8;  // 0x138(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13;  // 0x140(0x10)
	struct FName K2Node_CustomEvent_NotifyName_7;  // 0x150(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14;  // 0x158(0x10)
	struct FName K2Node_CustomEvent_NotifyName_6;  // 0x168(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15;  // 0x170(0x10)
	struct FName Temp_name_Variable_3;  // 0x180(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16;  // 0x188(0x10)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x198(0x8)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x1A0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_17;  // 0x1A8(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x1B8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_18;  // 0x1C0(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x1D0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_19;  // 0x1D8(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x1E8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_20;  // 0x1F0(0x10)
	struct FName Temp_name_Variable_4;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool Temp_bool_Variable : 1;  // 0x208(0x1)
	char pad_521_1 : 7;  // 0x209(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x209(0x1)
	char pad_522_1 : 7;  // 0x20A(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x20A(0x1)
	char pad_523_1 : 7;  // 0x20B(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20B(0x1)
	char pad_524_1 : 7;  // 0x20C(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x20C(0x1)
	char pad_525[3];  // 0x20D(0x3)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x210(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue;  // 0x220(0x10)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x230(0x1)
	char pad_561_1 : 7;  // 0x231(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x231(0x1)
	char pad_562_1 : 7;  // 0x232(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x232(0x1)
	char pad_563_1 : 7;  // 0x233(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x233(0x1)
	char pad_564[12];  // 0x234(0xC)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x240(0x30)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x270(0x1)
	char pad_625_1 : 7;  // 0x271(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x271(0x1)
	char pad_626_1 : 7;  // 0x272(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x272(0x1)
	char pad_627_1 : 7;  // 0x273(0x1)
	bool K2Node_CustomEvent_ChargingGC_2 : 1;  // 0x273(0x1)
	char pad_628_1 : 7;  // 0x274(0x1)
	bool K2Node_CustomEvent_BeamInPlay__2 : 1;  // 0x274(0x1)
	char pad_629_1 : 7;  // 0x275(0x1)
	bool K2Node_CustomEvent_CapturedRecently_2 : 1;  // 0x275(0x1)
	char pad_630_1 : 7;  // 0x276(0x1)
	bool K2Node_CustomEvent_ChargingGC : 1;  // 0x276(0x1)
	char pad_631_1 : 7;  // 0x277(0x1)
	bool K2Node_CustomEvent_BeamInPlay_ : 1;  // 0x277(0x1)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool K2Node_CustomEvent_CapturedRecently : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool K2Node_CustomEvent_EquippedRecently_2 : 1;  // 0x279(0x1)
	char pad_634_1 : 7;  // 0x27A(0x1)
	bool K2Node_CustomEvent_EquippedRecently : 1;  // 0x27A(0x1)
	char pad_635[5];  // 0x27B(0x5)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x280(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x2B0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x2BC(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x2C8(0xC)
	char pad_724[12];  // 0x2D4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x2E0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x310(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x318(0x8)
	struct ABP_Sound_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x320(0x8)
	struct ABP_Sound_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x328(0x8)
	struct FText Temp_text_Variable;  // 0x330(0x18)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x348(0x1)
	char pad_841_1 : 7;  // 0x349(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x349(0x1)
	char pad_842_1 : 7;  // 0x34A(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x34A(0x1)
	char pad_843_1 : 7;  // 0x34B(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x34B(0x1)
	char pad_844_1 : 7;  // 0x34C(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled_ : 1;  // 0x34C(0x1)
	char pad_845_1 : 7;  // 0x34D(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot_ : 1;  // 0x34D(0x1)
	char pad_846_1 : 7;  // 0x34E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x34E(0x1)
	char pad_847_1 : 7;  // 0x34F(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x34F(0x1)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x350(0x8)
	char pad_856_1 : 7;  // 0x358(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled__2 : 1;  // 0x358(0x1)
	char pad_857_1 : 7;  // 0x359(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot__2 : 1;  // 0x359(0x1)
	char pad_858_1 : 7;  // 0x35A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x35A(0x1)
	char pad_859_1 : 7;  // 0x35B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x35B(0x1)
	char pad_860[4];  // 0x35C(0x4)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue_2;  // 0x360(0x30)
	struct FTransform K2Node_Select_Default;  // 0x390(0x30)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x3C0(0x8)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x3C8(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x3D4(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x3E0(0xC)
	char pad_1004[4];  // 0x3EC(0x4)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x3F0(0x8)
	char pad_1016[8];  // 0x3F8(0x8)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue_3;  // 0x400(0x30)
	char pad_1072_1 : 7;  // 0x430(0x1)
	bool K2Node_CustomEvent_CancelFire_ : 1;  // 0x430(0x1)
	char pad_1073[3];  // 0x431(0x3)
	struct FVector CallFunc_BreakTransform_Location_3;  // 0x434(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_3;  // 0x440(0xC)
	struct FVector CallFunc_BreakTransform_Scale_3;  // 0x44C(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x458(0x8)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled__3 : 1;  // 0x460(0x1)
	char pad_1121_1 : 7;  // 0x461(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot__3 : 1;  // 0x461(0x1)
	char pad_1122_1 : 7;  // 0x462(0x1)
	bool CallFunc_CalculateSpectralHitscan_Hit_ : 1;  // 0x462(0x1)
	char pad_1123[1];  // 0x463(0x1)
	struct FRotator CallFunc_CalculateSpectralHitscan_Rotation;  // 0x464(0xC)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x470(0x1)
	char pad_1137_1 : 7;  // 0x471(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled__4 : 1;  // 0x471(0x1)
	char pad_1138_1 : 7;  // 0x472(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot__4 : 1;  // 0x472(0x1)
	char pad_1139_1 : 7;  // 0x473(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x473(0x1)
	char pad_1140[4];  // 0x474(0x4)
	struct USceneComponent* K2Node_Select_Default_2;  // 0x478(0x8)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue_4;  // 0x480(0x30)
	struct FVector CallFunc_BreakTransform_Location_4;  // 0x4B0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_4;  // 0x4BC(0xC)
	struct FVector CallFunc_BreakTransform_Scale_4;  // 0x4C8(0xC)
	char pad_1236[12];  // 0x4D4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0x4E0(0x30)
	struct FVector CallFunc_BreakTransform_Location_5;  // 0x510(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_5;  // 0x51C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_5;  // 0x528(0xC)
	float CallFunc_BreakVector_X;  // 0x534(0x4)
	float CallFunc_BreakVector_Y;  // 0x538(0x4)
	float CallFunc_BreakVector_Z;  // 0x53C(0x4)
	struct FVector_NetQuantize100 K2Node_MakeStruct_Vector_NetQuantize100;  // 0x540(0xC)
	char pad_1356[4];  // 0x54C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue_3;  // 0x550(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_3;  // 0x580(0x8)
	char pad_1416_1 : 7;  // 0x588(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled__5 : 1;  // 0x588(0x1)
	char pad_1417_1 : 7;  // 0x589(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot__5 : 1;  // 0x589(0x1)
	char pad_1418[6];  // 0x58A(0x6)
	struct AFirelight_Clientside_C* CallFunc_FinishSpawningActor_ReturnValue_3;  // 0x590(0x8)
	struct USceneComponent* K2Node_Select_Default_3;  // 0x598(0x8)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue_5;  // 0x5A0(0x30)
	struct FVector CallFunc_BreakTransform_Location_6;  // 0x5D0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_6;  // 0x5DC(0xC)
	struct FVector CallFunc_BreakTransform_Scale_6;  // 0x5E8(0xC)
	char pad_1524[12];  // 0x5F4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_4;  // 0x600(0x30)
	char pad_1584_1 : 7;  // 0x630(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Locally_Controlled__6 : 1;  // 0x630(0x1)
	char pad_1585_1 : 7;  // 0x631(0x1)
	bool CallFunc_Is_Locally_Controlled_Hunter__Is_a_Locally_Controlled_Bot__6 : 1;  // 0x631(0x1)
	char pad_1586[6];  // 0x632(0x6)
	struct USceneComponent* K2Node_Select_Default_4;  // 0x638(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue_2;  // 0x640(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x648(0xC)
	char pad_1620[4];  // 0x654(0x4)
	struct USceneComponent* CallFunc_GetAttachParent_ReturnValue;  // 0x658(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x660(0x8)
	struct USkeletalMeshComponent* K2Node_DynamicCast_AsSkeletal_Mesh_Component;  // 0x668(0x8)
	char pad_1648_1 : 7;  // 0x670(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x670(0x1)
	char pad_1649[7];  // 0x671(0x7)
	struct USkeletalMeshComponent* CallFunc_GetSkeletalMesh_SkeletalMesh;  // 0x678(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x680(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue_2;  // 0x688(0x8)
	char pad_1680_1 : 7;  // 0x690(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x690(0x1)
	char pad_1681_1 : 7;  // 0x691(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x691(0x1)
	char pad_1682[6];  // 0x692(0x6)
	struct USkeletalMeshComponent* CallFunc_GetSkeletalMesh_SkeletalMesh_2;  // 0x698(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x6A0(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue_3;  // 0x6A8(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x6B0(0x8)
	char pad_1720_1 : 7;  // 0x6B8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x6B8(0x1)
	char pad_1721[7];  // 0x6B9(0x7)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue_4;  // 0x6C0(0x8)
	char pad_1736_1 : 7;  // 0x6C8(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x6C8(0x1)
	char pad_1737_1 : 7;  // 0x6C9(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x6C9(0x1)
	char pad_1738[6];  // 0x6CA(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0x6D0(0x8)
	char pad_1752[8];  // 0x6D8(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x6E0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_4;  // 0x710(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_5;  // 0x718(0x8)
	struct ABP_Gadget_TP_SpectralCannon_C* CallFunc_FinishSpawningActor_ReturnValue_4;  // 0x720(0x8)
	struct ABP_Gadget_FP_SpectralCannon_C* CallFunc_FinishSpawningActor_ReturnValue_5;  // 0x728(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // 0x730(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter_2;  // 0x738(0x8)
	char pad_1856_1 : 7;  // 0x740(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x740(0x1)
	char pad_1857[7];  // 0x741(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x748(0x8)
	struct USpectralCannon_TP_AnimBP_C* K2Node_DynamicCast_AsSpectral_Cannon_TP_Anim_BP;  // 0x750(0x8)
	char pad_1880_1 : 7;  // 0x758(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x758(0x1)
	char pad_1881[7];  // 0x759(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x760(0x8)
	struct UHunter_ThirdPerson_AnimBP_C* K2Node_DynamicCast_AsHunter_Third_Person_Anim_BP;  // 0x768(0x8)
	char pad_1904_1 : 7;  // 0x770(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x770(0x1)
	char pad_1905[7];  // 0x771(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_6;  // 0x778(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue_3;  // 0x780(0x8)
	struct TArray<struct UCameraComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x788(0x10)
	struct UCameraComponent* CallFunc_Array_Get_Item;  // 0x798(0x8)
	char pad_1952_1 : 7;  // 0x7A0(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x7A0(0x1)
	char pad_1953_1 : 7;  // 0x7A1(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x7A1(0x1)
	char pad_1954[6];  // 0x7A2(0x6)
	struct USceneComponent* K2Node_Select_Default_5;  // 0x7A8(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x7B0(0xC)
	char pad_1980[4];  // 0x7BC(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x7C0(0x8)
	char pad_1992[8];  // 0x7C8(0x8)
	struct FTransform K2Node_CustomEvent_XForm;  // 0x7D0(0x30)
	struct FVector CallFunc_BreakTransform_Location_7;  // 0x800(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_7;  // 0x80C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_7;  // 0x818(0xC)
	float CallFunc_BreakVector_X_2;  // 0x824(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x828(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x82C(0x4)
	struct FVector_NetQuantize10 K2Node_MakeStruct_Vector_NetQuantize10;  // 0x830(0xC)
	char pad_2108[4];  // 0x83C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_7;  // 0x840(0x8)
	struct USceneComponent* K2Node_Select_Default_6;  // 0x848(0x8)
	char pad_2128_1 : 7;  // 0x850(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledHunter : 1;  // 0x850(0x1)
	char pad_2129_1 : 7;  // 0x851(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledBot : 1;  // 0x851(0x1)
	char pad_2130[14];  // 0x852(0xE)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue_6;  // 0x860(0x30)
	struct FVector CallFunc_BreakTransform_Location_8;  // 0x890(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_8;  // 0x89C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_8;  // 0x8A8(0xC)
	char pad_2228[12];  // 0x8B4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_5;  // 0x8C0(0x30)
	float K2Node_CustomEvent_Operation_2;  // 0x8F0(0x4)
	struct FVector_NetQuantize10 K2Node_CustomEvent_Location_3;  // 0x8F4(0xC)
	struct FRotator K2Node_CustomEvent_Rotator_3;  // 0x900(0xC)
	float CallFunc_BreakVector_X_3;  // 0x90C(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x910(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x914(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x918(0xC)
	char pad_2340[12];  // 0x924(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue_6;  // 0x930(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_6;  // 0x960(0x8)
	struct ABP_SpectralCannonSalvo_C* CallFunc_FinishSpawningActor_ReturnValue_6;  // 0x968(0x8)
	char pad_2416_1 : 7;  // 0x970(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x970(0x1)
	char pad_2417[7];  // 0x971(0x7)
	struct FText Temp_text_Variable_2;  // 0x978(0x18)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x990(0x8)
	struct FText K2Node_Select_Default_7;  // 0x998(0x18)
	char pad_2480_1 : 7;  // 0x9B0(0x1)
	bool CallFunc_IsEquipped_Equipped : 1;  // 0x9B0(0x1)
	char pad_2481[3];  // 0x9B1(0x3)
	float K2Node_CustomEvent_Operation;  // 0x9B4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x9B8(0x4)
	char pad_2492_1 : 7;  // 0x9BC(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_3 : 1;  // 0x9BC(0x1)
	char pad_2493[3];  // 0x9BD(0x3)
	float CallFunc_Abs_ReturnValue;  // 0x9C0(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x9C4(0x4)
	struct FVector_NetQuantize10 K2Node_CustomEvent_Location_2;  // 0x9C8(0xC)
	struct FRotator K2Node_CustomEvent_Rotator_2;  // 0x9D4(0xC)
	float CallFunc_BreakVector_X_4;  // 0x9E0(0x4)
	float CallFunc_BreakVector_Y_4;  // 0x9E4(0x4)
	float CallFunc_BreakVector_Z_4;  // 0x9E8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x9EC(0xC)
	char pad_2552[8];  // 0x9F8(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue_7;  // 0xA00(0x30)
	char pad_2608_1 : 7;  // 0xA30(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_4 : 1;  // 0xA30(0x1)
	char pad_2609[7];  // 0xA31(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_7;  // 0xA38(0x8)
	struct ABP_SpectralCannonSalvo_C* CallFunc_FinishSpawningActor_ReturnValue_7;  // 0xA40(0x8)
	struct FVector_NetQuantize10 K2Node_CustomEvent_Location;  // 0xA48(0xC)
	struct FRotator K2Node_CustomEvent_Rotator;  // 0xA54(0xC)
	float K2Node_Event_DeltaSeconds;  // 0xA60(0x4)
	char pad_2660_1 : 7;  // 0xA64(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0xA64(0x1)
	char pad_2661_1 : 7;  // 0xA65(0x1)
	bool K2Node_CustomEvent_SC_CancelledFire : 1;  // 0xA65(0x1)
	char pad_2662_1 : 7;  // 0xA66(0x1)
	bool K2Node_CustomEvent_SC_Cooldown : 1;  // 0xA66(0x1)
	char pad_2663_1 : 7;  // 0xA67(0x1)
	bool K2Node_CustomEvent_Chargeup_Ocurring : 1;  // 0xA67(0x1)
	float K2Node_CustomEvent_Cannon_Battery_Level;  // 0xA68(0x4)
	char pad_2668_1 : 7;  // 0xA6C(0x1)
	bool CallFunc_IsEquipped_Equipped_2 : 1;  // 0xA6C(0x1)
	char pad_2669[3];  // 0xA6D(0x3)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0xA70(0x10)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.CalculateSpectralHitscan
// Size: 0x288(Inherited: 0x0) 
struct FCalculateSpectralHitscan
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hit? : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FRotator Rotation;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool LocallyControlledBot : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool LocallyControlledHunter : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Temp_bool_Variable : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct TArray<struct UCameraComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledHunter : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledBot : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct UCameraComponent* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x50(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x5C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x68(0xC)
	char pad_116[4];  // 0x74(0x4)
	struct USceneComponent* K2Node_Select_Default;  // 0x78(0x8)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x80(0x10)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x90(0x30)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue_2;  // 0xC0(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0xF0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0xFC(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x108(0xC)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x114(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x120(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x12C(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_2;  // 0x138(0x10)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x148(0x88)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x1D0(0x1)
	char pad_465_1 : 7;  // 0x1D1(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1D1(0x1)
	char pad_466_1 : 7;  // 0x1D2(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x1D2(0x1)
	char pad_467[1];  // 0x1D3(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x1D4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1D8(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1DC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1E8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1F4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x200(0xC)
	char pad_524[4];  // 0x20C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x210(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x218(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x220(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x228(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x230(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x234(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x238(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x23C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x248(0xC)
	char pad_596[4];  // 0x254(0x4)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x258(0x10)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x268(0xC)
	char pad_628[4];  // 0x274(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x278(0x10)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_Equipped
// Size: 0x1(Inherited: 0x0) 
struct FMC_Cannon_Equipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool EquippedRecently : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.SetFPWeaponData
// Size: 0x8(Inherited: 0x0) 
struct FSetFPWeaponData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool SC CancelledFire : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool SC Cooldown : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Chargeup Ocurring : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float Cannon Battery Level;  // 0x4(0x4)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_406247964B18F7F3B0E3FB88601098FE
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_406247964B18F7F3B0E3FB88601098FE
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.NR_SpectralCannonReload
// Size: 0x4(Inherited: 0x0) 
struct FNR_SpectralCannonReload
{
	float Operation;  // 0x0(0x4)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_SpawnSpectralCannonSalvo
// Size: 0x18(Inherited: 0x0) 
struct FServer_SpawnSpectralCannonSalvo
{
	struct FVector_NetQuantize10 Location;  // 0x0(0xC)
	struct FRotator Rotator;  // 0xC(0xC)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_6FB8135D4D0D52EFFF0A90B62CB4BD99
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_6FB8135D4D0D52EFFF0A90B62CB4BD99
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.NR_SpawnSpectralCannonSalvo
// Size: 0x18(Inherited: 0x0) 
struct FNR_SpawnSpectralCannonSalvo
{
	struct FVector_NetQuantize10 Location;  // 0x0(0xC)
	struct FRotator Rotator;  // 0xC(0xC)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_SpawnSpectralCannonSalvo
// Size: 0x18(Inherited: 0x0) 
struct FMC_SpawnSpectralCannonSalvo
{
	struct FVector_NetQuantize10 Location;  // 0x0(0xC)
	struct FRotator Rotator;  // 0xC(0xC)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.NR_HandleSpectralCannonReload
// Size: 0x4(Inherited: 0x0) 
struct FNR_HandleSpectralCannonReload
{
	float Operation;  // 0x0(0x4)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.FireSpectralCannonSalvo
// Size: 0x30(Inherited: 0x0) 
struct FFireSpectralCannonSalvo
{
	struct FTransform XForm;  // 0x0(0x30)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_TPAnim_CancelFire
// Size: 0x1(Inherited: 0x0) 
struct FServer_TPAnim_CancelFire
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CancelFire? : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_EDA6A85446EB1306FE1FD98C82D58E7C
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_EDA6A85446EB1306FE1FD98C82D58E7C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_Equipped
// Size: 0x1(Inherited: 0x0) 
struct FServer_Cannon_TPAnim_Equipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool EquippedRecently : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_EDA6A85446EB1306FE1FD98C82D58E7C
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_EDA6A85446EB1306FE1FD98C82D58E7C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_CapturedRecently
// Size: 0x1(Inherited: 0x0) 
struct FMC_Cannon_CapturedRecently
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CapturedRecently : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_BeamInPlay
// Size: 0x1(Inherited: 0x0) 
struct FMC_Cannon_BeamInPlay
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool BeamInPlay? : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_EDA6A85446EB1306FE1FD98C82D58E7C
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_EDA6A85446EB1306FE1FD98C82D58E7C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.MC_Cannon_Charging
// Size: 0x1(Inherited: 0x0) 
struct FMC_Cannon_Charging
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ChargingGC : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_CapturedRecently
// Size: 0x1(Inherited: 0x0) 
struct FServer_Cannon_TPAnim_CapturedRecently
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CapturedRecently : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_BeamInPlay
// Size: 0x1(Inherited: 0x0) 
struct FServer_Cannon_TPAnim_BeamInPlay
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool BeamInPlay? : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_EF434191450523312DC50AAEB1C60A64
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_EF434191450523312DC50AAEB1C60A64
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Server_Cannon_TPAnim_Charging
// Size: 0x1(Inherited: 0x0) 
struct FServer_Cannon_TPAnim_Charging
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ChargingGC : 1;  // 0x0(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_EF434191450523312DC50AAEB1C60A64
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_EF434191450523312DC50AAEB1C60A64
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_EF434191450523312DC50AAEB1C60A64
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_EF434191450523312DC50AAEB1C60A64
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_EF434191450523312DC50AAEB1C60A64
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_EF434191450523312DC50AAEB1C60A64
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_EF434191450523312DC50AAEB1C60A64
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_EF434191450523312DC50AAEB1C60A64
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_6FB8135D4D0D52EFFF0A90B62CB4BD99
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_6FB8135D4D0D52EFFF0A90B62CB4BD99
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnBlendOut_6FB8135D4D0D52EFFF0A90B62CB4BD99
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_6FB8135D4D0D52EFFF0A90B62CB4BD99
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_EDA6A85446EB1306FE1FD98C82D58E7C
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_EDA6A85446EB1306FE1FD98C82D58E7C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_6FB8135D4D0D52EFFF0A90B62CB4BD99
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_6FB8135D4D0D52EFFF0A90B62CB4BD99
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_6FB8135D4D0D52EFFF0A90B62CB4BD99
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_6FB8135D4D0D52EFFF0A90B62CB4BD99
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_EDA6A85446EB1306FE1FD98C82D58E7C
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_EDA6A85446EB1306FE1FD98C82D58E7C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnCompleted_406247964B18F7F3B0E3FB88601098FE
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_406247964B18F7F3B0E3FB88601098FE
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnInterrupted_406247964B18F7F3B0E3FB88601098FE
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_406247964B18F7F3B0E3FB88601098FE
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyBegin_406247964B18F7F3B0E3FB88601098FE
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_406247964B18F7F3B0E3FB88601098FE
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.OnNotifyEnd_406247964B18F7F3B0E3FB88601098FE
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_406247964B18F7F3B0E3FB88601098FE
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.CanBeUnequipped
// Size: 0x2(Inherited: 0x1) 
struct FCanBeUnequipped : public FCanBeUnequipped
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CanBeUnequipped : 1;  // 0x0(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.GetFPActor
// Size: 0x8(Inherited: 0x8) 
struct FGetFPActor : public FGetFPActor
{
	struct ABP_Gadget_FP_C* FPActor;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.GetTPActor
// Size: 0x8(Inherited: 0x8) 
struct FGetTPActor : public FGetTPActor
{
	struct ABP_Gadget_TP_C* TPActor;  // 0x0(0x8)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.Is Locally Controlled Hunter?
// Size: 0x4(Inherited: 0x0) 
struct FIs Locally Controlled Hunter?
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Locally Controlled? : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Is a Locally Controlled Bot? : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledHunter : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_IsLocallyControlledHunter_Int_LocallyControlledBot : 1;  // 0x3(0x1)

}; 
// Function BP_Gadget_SpectralCannon.BP_Gadget_SpectralCannon_C.GetAmmoData
// Size: 0x14(Inherited: 0xC) 
struct FGetAmmoData : public FGetAmmoData
{
	char pad_12_1 : 7;  // 0xC(0x1)
	bool GadgetUsesAmmo : 1;  // 0x0(0x1)
	int32_t MaxAmmo;  // 0x4(0x4)
	int32_t CurrentAmmo;  // 0x8(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x10(0x4)

}; 
