#pragma once 
#include "SDK.h" 
 
 
// Function BP_MiscPossessFunctions.BP_MiscPossessFunctions_C.GetUnpossessedClassForPossessed
// Size: 0x4A(Inherited: 0x0) 
struct FGetUnpossessedClassForPossessed
{
	AActor* ClassIn;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	AActor* ClassOut;  // 0x10(0x8)
	struct UStaticMesh* BaseMesh;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Found : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FName Temp_name_Variable;  // 0x24(0x8)
	struct FName Temp_name_Variable_2;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct FName> Temp_name_Variable_3;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x49(0x1)

}; 
// Function BP_MiscPossessFunctions.BP_MiscPossessFunctions_C.GetPossessedClassForUnpossessed
// Size: 0x4A(Inherited: 0x0) 
struct FGetPossessedClassForUnpossessed
{
	AActor* ClassIn;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	AActor* Class;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Found : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FVector CamOffset;  // 0x1C(0xC)
	struct FName Temp_name_Variable;  // 0x28(0x8)
	struct FName Temp_name_Variable_2;  // 0x30(0x8)
	struct TArray<struct FName> Temp_name_Variable_3;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x49(0x1)

}; 
