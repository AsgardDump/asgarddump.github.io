#pragma once 
#include <BP_Hunter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter.BP_Hunter_C
// Size: 0x2658(Inherited: 0x4D0) 
struct ABP_Hunter_C : public AHunterMaster
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4D0(0x8)
	struct UPhotoModeComponent_C* PhotoModeComponent;  // 0x4D8(0x8)
	struct USceneComponent* CamCorderSpawnPoint;  // 0x4E0(0x8)
	struct USkeletalMeshComponent* TP_CamCorder;  // 0x4E8(0x8)
	struct USkeletalMeshComponent* FP_CamCorder;  // 0x4F0(0x8)
	struct UParticleSystemComponent* Ghostsmasher_TP_VFX3;  // 0x4F8(0x8)
	struct UNiagaraComponent* TP_OverheatVFX;  // 0x500(0x8)
	struct UNiagaraComponent* FP_OverheatVFX;  // 0x508(0x8)
	struct UParticleSystemComponent* Ghostsmasher_FP_VFX2;  // 0x510(0x8)
	struct USkeletalMeshComponent* TP_GhostSmasher2.0;  // 0x518(0x8)
	struct USkeletalMeshComponent* FP_GhostSmasher2.0;  // 0x520(0x8)
	struct UStaticMeshComponent* TP_GhostSmasherBuckler;  // 0x528(0x8)
	struct UStaticMeshComponent* FP_GhostSmasherBuckler;  // 0x530(0x8)
	struct UStaticMeshComponent* TP_MedicBox_Bandage;  // 0x538(0x8)
	struct UStaticMeshComponent* FP_MedicBox_Bandage;  // 0x540(0x8)
	struct USkeletalMeshComponent* TP_MedicBox;  // 0x548(0x8)
	struct UAIPerceptionStimuliSourceComponent* AIPerceptionStimuliSource;  // 0x550(0x8)
	struct UArrowComponent* TP_FlamethrowerNozzle;  // 0x558(0x8)
	struct UNiagaraComponent* RiotShieldOverheat_TP;  // 0x560(0x8)
	struct UNiagaraComponent* RiotShieldOverheatVFX;  // 0x568(0x8)
	struct USkeletalMeshComponent* TP_FlameThrower;  // 0x570(0x8)
	struct USkeletalMeshComponent* FP_FlameThrower;  // 0x578(0x8)
	struct USkeletalMeshComponent* FP_MedicBox;  // 0x580(0x8)
	struct UBoxComponent* TP_RiotShieldCollision;  // 0x588(0x8)
	struct USceneComponent* ChestLOSShield;  // 0x590(0x8)
	struct UWidgetComponent* ShieldHealthBar;  // 0x598(0x8)
	struct USkeletalMeshComponent* TP_RiotShield;  // 0x5A0(0x8)
	struct USkeletalMeshComponent* FP_RiotShield;  // 0x5A8(0x8)
	struct UPointLightComponent* DefibRezLight;  // 0x5B0(0x8)
	struct USkeletalMeshComponent* SK_EyeMesh;  // 0x5B8(0x8)
	struct USkeletalMeshComponent* TP_Trap;  // 0x5C0(0x8)
	struct USkeletalMeshComponent* FP_Trap;  // 0x5C8(0x8)
	struct UWidgetComponent* QuickHealthbar;  // 0x5D0(0x8)
	struct USkeletalMeshComponent* TP_Defib;  // 0x5D8(0x8)
	struct USkeletalMeshComponent* FP_C4;  // 0x5E0(0x8)
	struct USkeletalMeshComponent* TP_C4;  // 0x5E8(0x8)
	struct USkeletalMeshComponent* FP_Defib;  // 0x5F0(0x8)
	struct USphereComponent* TP_Pathfinder_SceneCaptureNull;  // 0x5F8(0x8)
	struct UAudioComponent* PathFinder_Idle;  // 0x600(0x8)
	struct USkeletalMeshComponent* TP_Pathfinder;  // 0x608(0x8)
	struct USphereComponent* FP_Pathfinder_SceneCaptureNull;  // 0x610(0x8)
	struct USkeletalMeshComponent* FP_Pathfinder;  // 0x618(0x8)
	struct USkeletalMeshComponent* TP_Grenade;  // 0x620(0x8)
	struct USkeletalMeshComponent* FP_Grenade;  // 0x628(0x8)
	struct USceneComponent* GhostsmasherTPTracePoint;  // 0x630(0x8)
	struct USceneComponent* SledgehammerTPTracePoint;  // 0x638(0x8)
	struct USceneComponent* TP_NailgunNozzle;  // 0x640(0x8)
	struct USkeletalMeshComponent* TP_Nailgun;  // 0x648(0x8)
	struct USceneComponent* FP_NailgunNozzle;  // 0x650(0x8)
	struct USkeletalMeshComponent* FP_Nailgun;  // 0x658(0x8)
	struct USceneComponent* TP_ProjectX_Overheat;  // 0x660(0x8)
	struct USceneComponent* TP_ProjectX_Nozzle;  // 0x668(0x8)
	struct USkeletalMeshComponent* TP_ProjectX;  // 0x670(0x8)
	struct UStaticMeshComponent* FP_HarpoonMesh;  // 0x678(0x8)
	struct USkeletalMeshComponent* FP_HarpoonBazooka;  // 0x680(0x8)
	struct UPointLightComponent* FP_ProjectXBuildup;  // 0x688(0x8)
	struct USkeletalMeshComponent* FP_ProjectX;  // 0x690(0x8)
	struct UPointLightComponent* TP_InteractivePtLight;  // 0x698(0x8)
	struct UStaticMeshComponent* TP_GlowCylinder;  // 0x6A0(0x8)
	struct UStaticMeshComponent* TP_GlowCylinderParent;  // 0x6A8(0x8)
	struct USceneComponent* TP_SpectralCannonNozzle;  // 0x6B0(0x8)
	struct USkeletalMeshComponent* TP_SpectralCannon;  // 0x6B8(0x8)
	struct USkeletalMeshComponent* TP_SpectroPhone;  // 0x6C0(0x8)
	struct USkeletalMeshComponent* FP_SpectroPhone;  // 0x6C8(0x8)
	struct UPointLightComponent* FP_InteractivePtLight;  // 0x6D0(0x8)
	struct UStaticMeshComponent* FP_GlowCylinderParent;  // 0x6D8(0x8)
	struct UStaticMeshComponent* FP_GlowCylinder;  // 0x6E0(0x8)
	struct USceneComponent* FP_SpectralCannonNozzle;  // 0x6E8(0x8)
	struct USkeletalMeshComponent* FP_SpectralCannon;  // 0x6F0(0x8)
	struct UVacuumTicker_C* VacuumTicker;  // 0x6F8(0x8)
	struct USceneComponent* TP_VacuumNozzle;  // 0x700(0x8)
	struct USceneComponent* FP_VacuumNozzle;  // 0x708(0x8)
	struct UParticleSystemComponent* Ghostsmasher_TP_VFX;  // 0x710(0x8)
	struct USkeletalMeshComponent* TP_GhostSmasher;  // 0x718(0x8)
	struct UParticleSystemComponent* Ghostsmasher_FP_VFX;  // 0x720(0x8)
	struct USkeletalMeshComponent* FP_GhostSmasher;  // 0x728(0x8)
	struct UArrowComponent* TP_SaltShotgunArrow;  // 0x730(0x8)
	struct USceneComponent* TP_SaltShotgunNozzle;  // 0x738(0x8)
	struct UArrowComponent* FP_SaltShotgunDirection;  // 0x740(0x8)
	struct USceneComponent* FP_SaltShotgunNozzle;  // 0x748(0x8)
	struct USkeletalMeshComponent* TP_SaltShotgun;  // 0x750(0x8)
	struct USkeletalMeshComponent* FP_SaltShotgun;  // 0x758(0x8)
	struct USkeletalMeshComponent* TP_Sledgehammer;  // 0x760(0x8)
	struct USkeletalMeshComponent* SledgeHammerSkel_FP;  // 0x768(0x8)
	struct USkeletalMeshComponent* TP_Vacuum;  // 0x770(0x8)
	struct USkeletalMeshComponent* FP_Vacuum;  // 0x778(0x8)
	struct USkeletalMeshComponent* FP_Sniper;  // 0x780(0x8)
	struct UCameraComponent* Camera;  // 0x788(0x8)
	struct USpringArmComponent* SpringArm_FP;  // 0x790(0x8)
	struct UCameraComponent* Camera_FP_Animated;  // 0x798(0x8)
	struct USceneComponent* FP_GrappleAttachPoint;  // 0x7A0(0x8)
	struct USceneComponent* GrappleFirePoint;  // 0x7A8(0x8)
	struct USceneComponent* TP_GrappleAttach;  // 0x7B0(0x8)
	struct USkeletalMeshComponent* TP_Hook;  // 0x7B8(0x8)
	struct USkeletalMeshComponent* FP_Hook;  // 0x7C0(0x8)
	struct USceneComponent* SniperFirePoint_TP;  // 0x7C8(0x8)
	struct UWidgetComponent* Nameplate_Widget_H;  // 0x7D0(0x8)
	struct UStaticMeshComponent* Sniper_fanHeat_mesh;  // 0x7D8(0x8)
	struct USceneComponent* SniperFirePoint_FP;  // 0x7E0(0x8)
	struct USkeletalMeshComponent* TP_Sniper;  // 0x7E8(0x8)
	struct USceneComponent* PunchDirection;  // 0x7F0(0x8)
	struct URectLightComponent* SizzleRect;  // 0x7F8(0x8)
	struct UPointLightComponent* SizzleLight;  // 0x800(0x8)
	struct USceneComponent* TP_AttachToHarpoonCablev3;  // 0x808(0x8)
	struct USceneComponent* TP_AttachToHarpoonCablev2;  // 0x810(0x8)
	struct USceneComponent* TP_AttachToHarpoonCable;  // 0x818(0x8)
	struct UStaticMeshComponent* TP_HarpoonMesh;  // 0x820(0x8)
	struct USkeletalMeshComponent* TP_Harpoon;  // 0x828(0x8)
	struct USpotLightComponent* HunterAlwaysLight_TP;  // 0x830(0x8)
	struct USpotLightComponent* HunterAlwaysLight_FP;  // 0x838(0x8)
	struct USceneComponent* HarpoonReelToHere;  // 0x840(0x8)
	struct USceneComponent* ReturnPoint;  // 0x848(0x8)
	struct USceneComponent* HarpoonFirePoint;  // 0x850(0x8)
	struct USceneComponent* HBazooka_FP_Null;  // 0x858(0x8)
	struct UConveyorBeltHandler_C* ConveyorBeltHandler;  // 0x860(0x8)
	struct UCleanUpUnusedHunters_C* CleanUpUnusedHunters;  // 0x868(0x8)
	struct UProjectXFireRate_C* ProjectXFireRate;  // 0x870(0x8)
	struct USphereComponent* FP_ProjectX_VFX_Root;  // 0x878(0x8)
	struct UCrouchComp_C* CrouchComp;  // 0x880(0x8)
	struct USphereComponent* FlybyOverlap;  // 0x888(0x8)
	struct USceneComponent* SabotVFXLoc;  // 0x890(0x8)
	struct UArrowComponent* GrenadeThrowpoint;  // 0x898(0x8)
	struct USphereComponent* Trap_Direction;  // 0x8A0(0x8)
	struct USceneComponent* RiotShield_TP_Null;  // 0x8A8(0x8)
	struct UStaticMeshComponent* RiotShield_TP_Mesh;  // 0x8B0(0x8)
	struct UStaticMeshComponent* RiotShield_FP_Mesh;  // 0x8B8(0x8)
	struct USceneComponent* RiotShield_FP_Null;  // 0x8C0(0x8)
	struct UAudioComponent* MeleeLoop;  // 0x8C8(0x8)
	struct USkeletalMeshComponent* Backpack;  // 0x8D0(0x8)
	struct UStaticMeshComponent* Battery_5;  // 0x8D8(0x8)
	struct UStaticMeshComponent* Battery_4;  // 0x8E0(0x8)
	struct UStaticMeshComponent* Battery_3;  // 0x8E8(0x8)
	struct USceneComponent* Battery_Null;  // 0x8F0(0x8)
	struct UHunterVanClientTick_C* HunterVanClientTick;  // 0x8F8(0x8)
	struct USceneComponent* LeftHandNull;  // 0x900(0x8)
	struct USphereComponent* FP_Nozzle;  // 0x908(0x8)
	struct USkeletalMeshComponent* FirstPerson_Hands;  // 0x910(0x8)
	struct USceneComponent* KillcamFollowPoint;  // 0x918(0x8)
	struct UHunterRaycastDetectionComponent_C* HunterRaycastComp;  // 0x920(0x8)
	struct USceneComponent* AssumeTheChokePosition;  // 0x928(0x8)
	struct UArrowComponent* BehindDirection;  // 0x930(0x8)
	struct USceneComponent* BehindSceneStarter;  // 0x938(0x8)
	struct UHunterAnalyticsManager_C* HunterAnalyticsManager;  // 0x940(0x8)
	struct UBoxComponent* HeadHitbox;  // 0x948(0x8)
	struct UCapsuleComponent* ChestHitbox;  // 0x950(0x8)
	struct UArrowComponent* DownArrow;  // 0x958(0x8)
	struct USphereComponent* SceneCapture_Loop_Null;  // 0x960(0x8)
	struct USphereComponent* SeeThroughCam_FP_null;  // 0x968(0x8)
	struct USpotLightComponent* SpotLight_ThirdPerson;  // 0x970(0x8)
	struct USphereComponent* Spotlight_THRP_null;  // 0x978(0x8)
	struct USpotLightComponent* SpotLight_FirstPerson;  // 0x980(0x8)
	struct USphereComponent* SpotLight_FP_null;  // 0x988(0x8)
	struct UStaticMeshComponent* RegFlashlite_THRP;  // 0x990(0x8)
	struct USphereComponent* RegFlashlite_THRP_null;  // 0x998(0x8)
	struct UStaticMeshComponent* RegFlashlite_FP;  // 0x9A0(0x8)
	struct USphereComponent* REGFLASHLITE_FP_null;  // 0x9A8(0x8)
	struct USphereComponent* Grenade_FP_Throwpoint_null;  // 0x9B0(0x8)
	struct UStaticMeshComponent* Grenade_TP;  // 0x9B8(0x8)
	struct USphereComponent* Grenade_THRP_null;  // 0x9C0(0x8)
	struct UStaticMeshComponent* Grenade_FP;  // 0x9C8(0x8)
	struct USphereComponent* Grenade_FP_null02;  // 0x9D0(0x8)
	struct USceneComponent* Grenade_FP_null;  // 0x9D8(0x8)
	struct USkeletalMeshComponent* PDA_FP;  // 0x9E0(0x8)
	struct USphereComponent* PDA_FP_null;  // 0x9E8(0x8)
	struct UMotionSensorComponent_C* MotionSensorComponent;  // 0x9F0(0x8)
	struct USceneComponent* AlternateDropArrow;  // 0x9F8(0x8)
	struct UCameraComponent* ThirdPersonCam;  // 0xA00(0x8)
	struct USpringArmComponent* SpringArm;  // 0xA08(0x8)
	struct USphereComponent* CamLocation;  // 0xA10(0x8)
	float TimelineOpacity_PostProcessOpacity_1B4089D3425BD08686B92DBAF72D55F1;  // 0xA18(0x4)
	float TimelineOpacity_Opacity_1B4089D3425BD08686B92DBAF72D55F1;  // 0xA1C(0x4)
	char ETimelineDirection TimelineOpacity__Direction_1B4089D3425BD08686B92DBAF72D55F1;  // 0xA20(0x1)
	char pad_2593[7];  // 0xA21(0x7)
	struct UTimelineComponent* TimelineOpacity;  // 0xA28(0x8)
	float TineLineDistance_Distance_E714C427442ED3B49735C3B9F91D8ADB;  // 0xA30(0x4)
	char ETimelineDirection TineLineDistance__Direction_E714C427442ED3B49735C3B9F91D8ADB;  // 0xA34(0x1)
	char pad_2613[3];  // 0xA35(0x3)
	struct UTimelineComponent* TineLineDistance;  // 0xA38(0x8)
	float EquipmentChangeCDSlow_30sec_BF50CD3B4F3A1CD74C7AB89990FFCF4D;  // 0xA40(0x4)
	char ETimelineDirection EquipmentChangeCDSlow__Direction_BF50CD3B4F3A1CD74C7AB89990FFCF4D;  // 0xA44(0x1)
	char pad_2629[3];  // 0xA45(0x3)
	struct UTimelineComponent* EquipmentChangeCDSlow;  // 0xA48(0x8)
	float Timeline_9_NewTrack_0_6216C8BE4C096CC6028ACD8E8A12E40D;  // 0xA50(0x4)
	char ETimelineDirection Timeline_9__Direction_6216C8BE4C096CC6028ACD8E8A12E40D;  // 0xA54(0x1)
	char pad_2645[3];  // 0xA55(0x3)
	struct UTimelineComponent* Timeline_10;  // 0xA58(0x8)
	float FPGhostSmasherBucklerLerp_Progress_ED186FBB456E614498800DAB87F9F7D2;  // 0xA60(0x4)
	char ETimelineDirection FPGhostSmasherBucklerLerp__Direction_ED186FBB456E614498800DAB87F9F7D2;  // 0xA64(0x1)
	char pad_2661[3];  // 0xA65(0x3)
	struct UTimelineComponent* FPGhostSmasherBucklerLerp;  // 0xA68(0x8)
	float GrapplingHookCDShort_PercentComplete_DC9FFA984D89BC5A6247C78FDCDE0095;  // 0xA70(0x4)
	char ETimelineDirection GrapplingHookCDShort__Direction_DC9FFA984D89BC5A6247C78FDCDE0095;  // 0xA74(0x1)
	char pad_2677[3];  // 0xA75(0x3)
	struct UTimelineComponent* GrapplingHookCDShort;  // 0xA78(0x8)
	float DefibRevive_RezTime_52295BD04111C711D6075DBA9D0C59C0;  // 0xA80(0x4)
	char ETimelineDirection DefibRevive__Direction_52295BD04111C711D6075DBA9D0C59C0;  // 0xA84(0x1)
	char pad_2693[3];  // 0xA85(0x3)
	struct UTimelineComponent* DefibRevive;  // 0xA88(0x8)
	float VaultSecondPart_Progress_03051F1C45C6F0547B509089306DF4E8;  // 0xA90(0x4)
	char ETimelineDirection VaultSecondPart__Direction_03051F1C45C6F0547B509089306DF4E8;  // 0xA94(0x1)
	char pad_2709[3];  // 0xA95(0x3)
	struct UTimelineComponent* VaultSecondPart;  // 0xA98(0x8)
	float VaultFirstpart_Progress_8AF26A364DAA43F174E4BE93D4BBD9F3;  // 0xAA0(0x4)
	char ETimelineDirection VaultFirstpart__Direction_8AF26A364DAA43F174E4BE93D4BBD9F3;  // 0xAA4(0x1)
	char pad_2725[3];  // 0xAA5(0x3)
	struct UTimelineComponent* VaultFirstPart;  // 0xAA8(0x8)
	float PathFinderTarailRenderTransition_Value_724FF5624B2D3D6D2B019FAF260C9E42;  // 0xAB0(0x4)
	char ETimelineDirection PathFinderTarailRenderTransition__Direction_724FF5624B2D3D6D2B019FAF260C9E42;  // 0xAB4(0x1)
	char pad_2741[3];  // 0xAB5(0x3)
	struct UTimelineComponent* PathFinderTarailRenderTransition;  // 0xAB8(0x8)
	struct FVector SniperMonitorTimeline_ASCIISwitcherTrack_7AADC9EB43A88F23E9F16583D063B156;  // 0xAC0(0xC)
	char ETimelineDirection SniperMonitorTimeline__Direction_7AADC9EB43A88F23E9F16583D063B156;  // 0xACC(0x1)
	char pad_2765[3];  // 0xACD(0x3)
	struct UTimelineComponent* SniperMonitorTimeline;  // 0xAD0(0x8)
	float EquipmentChangeCD_8sec_726225C84339193228F674BEA1F334DE;  // 0xAD8(0x4)
	char ETimelineDirection EquipmentChangeCD__Direction_726225C84339193228F674BEA1F334DE;  // 0xADC(0x1)
	char pad_2781[3];  // 0xADD(0x3)
	struct UTimelineComponent* EquipmentChangeCD;  // 0xAE0(0x8)
	float Timeline_8_NewTrack_0_94C186A543D01C0D889A6DB0B958FE6A;  // 0xAE8(0x4)
	char ETimelineDirection Timeline_8__Direction_94C186A543D01C0D889A6DB0B958FE6A;  // 0xAEC(0x1)
	char pad_2797[3];  // 0xAED(0x3)
	struct UTimelineComponent* Timeline_9;  // 0xAF0(0x8)
	float Timeline_RiotEmissive_NewTrack_0_4018FF4043F4E245DB8139AB6C109912;  // 0xAF8(0x4)
	char ETimelineDirection Timeline_RiotEmissive__Direction_4018FF4043F4E245DB8139AB6C109912;  // 0xAFC(0x1)
	char pad_2813[3];  // 0xAFD(0x3)
	struct UTimelineComponent* Timeline_RiotEmissive;  // 0xB00(0x8)
	float Bandage_ServerDelay_2p2Seconds_2_2_sec_D5D554134E01A5FC13A26CB1D900C897;  // 0xB08(0x4)
	char ETimelineDirection Bandage_ServerDelay_2p2Seconds__Direction_D5D554134E01A5FC13A26CB1D900C897;  // 0xB0C(0x1)
	char pad_2829[3];  // 0xB0D(0x3)
	struct UTimelineComponent* Bandage_ServerDelay_2p2Seconds;  // 0xB10(0x8)
	float Bandage_Delay3_HalfSec_0_5sec_4071C5CB4721B4E61FDA10A4EA663992;  // 0xB18(0x4)
	char ETimelineDirection Bandage_Delay3_HalfSec__Direction_4071C5CB4721B4E61FDA10A4EA663992;  // 0xB1C(0x1)
	char pad_2845[3];  // 0xB1D(0x3)
	struct UTimelineComponent* Bandage_Delay3_HalfSec;  // 0xB20(0x8)
	float Bandage_Delay2_1_HalfSec_1_5sec_33D00F5347559C2DDE8B42954EA7D823;  // 0xB28(0x4)
	char ETimelineDirection Bandage_Delay2_1_HalfSec__Direction_33D00F5347559C2DDE8B42954EA7D823;  // 0xB2C(0x1)
	char pad_2861[3];  // 0xB2D(0x3)
	struct UTimelineComponent* Bandage_Delay2_1+HalfSec;  // 0xB30(0x8)
	float Bandage_Delay1_Halfsec_0_5sec_EA916E784573D9B12F1405B93700B84E;  // 0xB38(0x4)
	char ETimelineDirection Bandage_Delay1_Halfsec__Direction_EA916E784573D9B12F1405B93700B84E;  // 0xB3C(0x1)
	char pad_2877[3];  // 0xB3D(0x3)
	struct UTimelineComponent* Bandage_Delay1_Halfsec;  // 0xB40(0x8)
	float RampSpeedUI_PercentComplete_9B181C4E46B13CE3B7756EB86AE283DD;  // 0xB48(0x4)
	float RampSpeedUI_LerpPercent_9B181C4E46B13CE3B7756EB86AE283DD;  // 0xB4C(0x4)
	char ETimelineDirection RampSpeedUI__Direction_9B181C4E46B13CE3B7756EB86AE283DD;  // 0xB50(0x1)
	char pad_2897[7];  // 0xB51(0x7)
	struct UTimelineComponent* RampSpeedUI;  // 0xB58(0x8)
	float Timeline_7_NewTrack_0_1B82F0844AB056B7FE12499D9D226D9C;  // 0xB60(0x4)
	char ETimelineDirection Timeline_7__Direction_1B82F0844AB056B7FE12499D9D226D9C;  // 0xB64(0x1)
	char pad_2917[3];  // 0xB65(0x3)
	struct UTimelineComponent* Timeline_8;  // 0xB68(0x8)
	struct FLinearColor SpecCannon_reload_TurbineGlow_LightColor_2C63D3EE4CF263E1E765CD94BED84850;  // 0xB70(0x10)
	float SpecCannon_reload_TurbineGlow_Intensity_2C63D3EE4CF263E1E765CD94BED84850;  // 0xB80(0x4)
	char ETimelineDirection SpecCannon_reload_TurbineGlow__Direction_2C63D3EE4CF263E1E765CD94BED84850;  // 0xB84(0x1)
	char pad_2949[3];  // 0xB85(0x3)
	struct UTimelineComponent* SpecCannon_reload_TurbineGlow;  // 0xB88(0x8)
	float Timeline_5_NewTrack_0_E9C95D6347570DA9C35D9B8672379DE6;  // 0xB90(0x4)
	char ETimelineDirection Timeline_5__Direction_E9C95D6347570DA9C35D9B8672379DE6;  // 0xB94(0x1)
	char pad_2965[3];  // 0xB95(0x3)
	struct UTimelineComponent* Timeline_6;  // 0xB98(0x8)
	float Timeline_4_NewTrack_0_E72E7CC64939C63E4D15259CA778E2F7;  // 0xBA0(0x4)
	char ETimelineDirection Timeline_4__Direction_E72E7CC64939C63E4D15259CA778E2F7;  // 0xBA4(0x1)
	char pad_2981[3];  // 0xBA5(0x3)
	struct UTimelineComponent* Timeline_5;  // 0xBA8(0x8)
	struct FVector ExtraResGravity_Downforce_7984639F4B462B76325A869A7968C8E9;  // 0xBB0(0xC)
	char ETimelineDirection ExtraResGravity__Direction_7984639F4B462B76325A869A7968C8E9;  // 0xBBC(0x1)
	char pad_3005[3];  // 0xBBD(0x3)
	struct UTimelineComponent* ExtraResGravity;  // 0xBC0(0x8)
	float DefibRezLightTimeline_Lerp_F8581FEC4A3033AD7FD996B0C78E2BA6;  // 0xBC8(0x4)
	char ETimelineDirection DefibRezLightTimeline__Direction_F8581FEC4A3033AD7FD996B0C78E2BA6;  // 0xBCC(0x1)
	char pad_3021[3];  // 0xBCD(0x3)
	struct UTimelineComponent* DefibRezLightTimeline;  // 0xBD0(0x8)
	float InterpolatedLoop_Timeliner_83362D9143E9CA9E374A8288ED9648A8;  // 0xBD8(0x4)
	char ETimelineDirection InterpolatedLoop__Direction_83362D9143E9CA9E374A8288ED9648A8;  // 0xBDC(0x1)
	char pad_3037[3];  // 0xBDD(0x3)
	struct UTimelineComponent* InterpolatedLoop;  // 0xBE0(0x8)
	float JumpReduction_Time_385D3F3B4123FDFFB796D38A4B02B6A0;  // 0xBE8(0x4)
	char ETimelineDirection JumpReduction__Direction_385D3F3B4123FDFFB796D38A4B02B6A0;  // 0xBEC(0x1)
	char pad_3053[3];  // 0xBED(0x3)
	struct UTimelineComponent* JumpReduction;  // 0xBF0(0x8)
	float OceanSlowedTl_Time_77FA9C984CBC2DD75B24A8A7A3418430;  // 0xBF8(0x4)
	char ETimelineDirection OceanSlowedTl__Direction_77FA9C984CBC2DD75B24A8A7A3418430;  // 0xBFC(0x1)
	char pad_3069[3];  // 0xBFD(0x3)
	struct UTimelineComponent* OceanSlowedTl;  // 0xC00(0x8)
	struct FLinearColor SpectralCannonSpinUp_NewTrack_0_5C00000E49DFCC4AFE3D3A9274D72704;  // 0xC08(0x10)
	float SpectralCannonSpinUp_Intensity_5C00000E49DFCC4AFE3D3A9274D72704;  // 0xC18(0x4)
	char ETimelineDirection SpectralCannonSpinUp__Direction_5C00000E49DFCC4AFE3D3A9274D72704;  // 0xC1C(0x1)
	char pad_3101[3];  // 0xC1D(0x3)
	struct UTimelineComponent* SpectralCannonSpinUp;  // 0xC20(0x8)
	float Timeline_0_NewTrack_0_9911529441CB811B4A298792A0FFA7CD;  // 0xC28(0x4)
	char ETimelineDirection Timeline_0__Direction_9911529441CB811B4A298792A0FFA7CD;  // 0xC2C(0x1)
	char pad_3117[3];  // 0xC2D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0xC30(0x8)
	float Timeline_6_NewTrack_0_EF1786EA47E336C73FFB398509400865;  // 0xC38(0x4)
	char ETimelineDirection Timeline_6__Direction_EF1786EA47E336C73FFB398509400865;  // 0xC3C(0x1)
	char pad_3133[3];  // 0xC3D(0x3)
	struct UTimelineComponent* Timeline_7;  // 0xC40(0x8)
	float GrapplingHookCD_PercentComplete_2359DCE34CE4399A56C142B0F7159157;  // 0xC48(0x4)
	char ETimelineDirection GrapplingHookCD__Direction_2359DCE34CE4399A56C142B0F7159157;  // 0xC4C(0x1)
	char pad_3149[3];  // 0xC4D(0x3)
	struct UTimelineComponent* GrapplingHookCD;  // 0xC50(0x8)
	float StartSniper_Scope_In_BE4DE1BC43D268191F006DBB89F2D3EA;  // 0xC58(0x4)
	char ETimelineDirection StartSniper__Direction_BE4DE1BC43D268191F006DBB89F2D3EA;  // 0xC5C(0x1)
	char pad_3165[3];  // 0xC5D(0x3)
	struct UTimelineComponent* StartSniper;  // 0xC60(0x8)
	float Wait_NewTrack_0_EEA148D04511A4BE442891909B1D3480;  // 0xC68(0x4)
	char ETimelineDirection Wait__Direction_EEA148D04511A4BE442891909B1D3480;  // 0xC6C(0x1)
	char pad_3181[3];  // 0xC6D(0x3)
	struct UTimelineComponent* Wait;  // 0xC70(0x8)
	float RampUp_NewTrack_0_BD1C05E7482EA34891F43E9C4737F9DC;  // 0xC78(0x4)
	char ETimelineDirection RampUp__Direction_BD1C05E7482EA34891F43E9C4737F9DC;  // 0xC7C(0x1)
	char pad_3197[3];  // 0xC7D(0x3)
	struct UTimelineComponent* RampUp;  // 0xC80(0x8)
	float RampDown_NewTrack_0_E0D5DD004E1C2F365CDC9199DEDCE9C0;  // 0xC88(0x4)
	char ETimelineDirection RampDown__Direction_E0D5DD004E1C2F365CDC9199DEDCE9C0;  // 0xC8C(0x1)
	char pad_3213[3];  // 0xC8D(0x3)
	struct UTimelineComponent* RampDown;  // 0xC90(0x8)
	float Timeline_3_Salt_Time_Remaining_B582C1E040A34752AD1831B5EC3C01BE;  // 0xC98(0x4)
	char ETimelineDirection Timeline_3__Direction_B582C1E040A34752AD1831B5EC3C01BE;  // 0xC9C(0x1)
	char pad_3229[3];  // 0xC9D(0x3)
	struct UTimelineComponent* Timeline_4;  // 0xCA0(0x8)
	float CrouchInterp_NewTrack_0_BB6224FE4FE308C26983E8BB2E1BA5E6;  // 0xCA8(0x4)
	char ETimelineDirection CrouchInterp__Direction_BB6224FE4FE308C26983E8BB2E1BA5E6;  // 0xCAC(0x1)
	char pad_3245[3];  // 0xCAD(0x3)
	struct UTimelineComponent* CrouchInterp;  // 0xCB0(0x8)
	float BaseTurnRate;  // 0xCB8(0x4)
	float BaseLookUpRate;  // 0xCBC(0x4)
	struct UMaterialInstanceDynamic* Head Texture Loc;  // 0xCC0(0x8)
	struct USkeletalMeshComponent* Head Loc;  // 0xCC8(0x8)
	struct USkeletalMeshComponent* Body Loc;  // 0xCD0(0x8)
	struct USkeletalMeshComponent* Hair Loc;  // 0xCD8(0x8)
	struct USkeletalMeshComponent* Beard Loc;  // 0xCE0(0x8)
	struct USkeletalMeshComponent* Brows Loc;  // 0xCE8(0x8)
	struct USkeletalMeshComponent* Eye Loc;  // 0xCF0(0x8)
	struct USkeletalMeshComponent* EyeLashes Loc;  // 0xCF8(0x8)
	struct UMaterialInstanceDynamic* Body Texture Loc;  // 0xD00(0x8)
	struct UMaterialInstanceDynamic* Hair Texture Loc;  // 0xD08(0x8)
	struct UMaterialInstanceDynamic* Cloth Texture Loc;  // 0xD10(0x8)
	struct USkeletalMeshComponent* Cloth 1 Loc;  // 0xD18(0x8)
	struct USkeletalMeshComponent* Cloth 2 Loc;  // 0xD20(0x8)
	struct USkeletalMeshComponent* Cloth 3 Loc;  // 0xD28(0x8)
	struct USkeletalMeshComponent* Cloth 4 Loc;  // 0xD30(0x8)
	struct USkeletalMeshComponent* Cloth 5 Loc;  // 0xD38(0x8)
	struct USkeletalMeshComponent* Cloth 6 Loc;  // 0xD40(0x8)
	struct USkeletalMeshComponent* Cloth 7 Loc;  // 0xD48(0x8)
	char pad_3408_1 : 7;  // 0xD50(0x1)
	bool Reset to default Bioworker : 1;  // 0xD50(0x1)
	char pad_3409_1 : 7;  // 0xD51(0x1)
	bool Reset to default Doctor1 : 1;  // 0xD51(0x1)
	char pad_3410_1 : 7;  // 0xD52(0x1)
	bool Reset to default Doctor2 : 1;  // 0xD52(0x1)
	char pad_3411_1 : 7;  // 0xD53(0x1)
	bool Reset to default Security1 : 1;  // 0xD53(0x1)
	char pad_3412_1 : 7;  // 0xD54(0x1)
	bool Reset to default Security2 : 1;  // 0xD54(0x1)
	char pad_3413_1 : 7;  // 0xD55(0x1)
	bool Reset to default Suit : 1;  // 0xD55(0x1)
	char pad_3414_1 : 7;  // 0xD56(0x1)
	bool Reset to default Worker : 1;  // 0xD56(0x1)
	char pad_3415[1];  // 0xD57(0x1)
	int32_t Cloth Var;  // 0xD58(0x4)
	char pad_3420_1 : 7;  // 0xD5C(0x1)
	bool Add badge 1 : 1;  // 0xD5C(0x1)
	char pad_3421_1 : 7;  // 0xD5D(0x1)
	bool Add badge 2 : 1;  // 0xD5D(0x1)
	char pad_3422_1 : 7;  // 0xD5E(0x1)
	bool Add item 1 : 1;  // 0xD5E(0x1)
	char pad_3423_1 : 7;  // 0xD5F(0x1)
	bool Add item 2 : 1;  // 0xD5F(0x1)
	char pad_3424_1 : 7;  // 0xD60(0x1)
	bool cap : 1;  // 0xD60(0x1)
	char pad_3425[3];  // 0xD61(0x3)
	int32_t Head Model Var;  // 0xD64(0x4)
	int32_t Head Texture Var;  // 0xD68(0x4)
	int32_t Hair Model Var;  // 0xD6C(0x4)
	int32_t Beard Model Var;  // 0xD70(0x4)
	int32_t Additional Normal Var;  // 0xD74(0x4)
	char pad_3448_1 : 7;  // 0xD78(0x1)
	bool Off : 1;  // 0xD78(0x1)
	char pad_3449_1 : 7;  // 0xD79(0x1)
	bool Off : 1;  // 0xD79(0x1)
	char pad_3450_1 : 7;  // 0xD7A(0x1)
	bool Off : 1;  // 0xD7A(0x1)
	char pad_3451_1 : 7;  // 0xD7B(0x1)
	bool reset to default : 1;  // 0xD7B(0x1)
	struct FLinearColor Diffuse color 1;  // 0xD7C(0x10)
	float Core Darkness 1;  // 0xD8C(0x4)
	float Edge Bridghtness 1;  // 0xD90(0x4)
	float Power 1;  // 0xD94(0x4)
	struct UTexture2D* Detail 1 Pattern;  // 0xD98(0x8)
	float Detail 1 str;  // 0xDA0(0x4)
	float Detail 1 tilling;  // 0xDA4(0x4)
	struct FLinearColor Diffuse Color 2;  // 0xDA8(0x10)
	float Core Darkness 2;  // 0xDB8(0x4)
	float Edge Bridghtness 2;  // 0xDBC(0x4)
	float Power 2;  // 0xDC0(0x4)
	char pad_3524[4];  // 0xDC4(0x4)
	struct UTexture2D* Detail 2 Pattern;  // 0xDC8(0x8)
	float Detail  2 str;  // 0xDD0(0x4)
	float Detail 2 tilling;  // 0xDD4(0x4)
	struct FLinearColor Diffuse Color 3;  // 0xDD8(0x10)
	float Core Darkness 3;  // 0xDE8(0x4)
	float Edge Bridghtness 3;  // 0xDEC(0x4)
	float Power 3;  // 0xDF0(0x4)
	char pad_3572[4];  // 0xDF4(0x4)
	struct UTexture2D* Detail 3 Pattern;  // 0xDF8(0x8)
	float Detail 3 str;  // 0xE00(0x4)
	float Detail 3 tilling;  // 0xE04(0x4)
	struct FLinearColor Diffuse color 4;  // 0xE08(0x10)
	float Core Darkness 4;  // 0xE18(0x4)
	float Edge Bridghtness 4;  // 0xE1C(0x4)
	float Power 4;  // 0xE20(0x4)
	char pad_3620[4];  // 0xE24(0x4)
	struct UTexture2D* Detail 4 Pattern;  // 0xE28(0x8)
	float Detail 4 str;  // 0xE30(0x4)
	float Detail 4 tilling;  // 0xE34(0x4)
	float Roughness;  // 0xE38(0x4)
	float Specular;  // 0xE3C(0x4)
	struct FLinearColor Dirt Color;  // 0xE40(0x10)
	float Dirt Roughness;  // 0xE50(0x4)
	float Dirt Str;  // 0xE54(0x4)
	struct FLinearColor Fresnel Color 1;  // 0xE58(0x10)
	float Fresnel Exponent 1;  // 0xE68(0x4)
	struct FLinearColor Fresnel Color 2;  // 0xE6C(0x10)
	float Fresnel Exponent 2;  // 0xE7C(0x4)
	struct FLinearColor Fresnel Color 3;  // 0xE80(0x10)
	float Fresnel Exponent 3;  // 0xE90(0x4)
	struct FLinearColor Skin color;  // 0xE94(0x10)
	struct FLinearColor Skin Fresnel Color;  // 0xEA4(0x10)
	float Skin Fresnel Exp;  // 0xEB4(0x4)
	float Skin Specular;  // 0xEB8(0x4)
	float Skin Roughness;  // 0xEBC(0x4)
	float Hair Mask on face str;  // 0xEC0(0x4)
	float Beard Mask on face str;  // 0xEC4(0x4)
	float Skin Contrast;  // 0xEC8(0x4)
	float Skin Desaturation;  // 0xECC(0x4)
	float Skin Detail Intensity;  // 0xED0(0x4)
	float Skin Detail Scale;  // 0xED4(0x4)
	float Skin Subsurface Add;  // 0xED8(0x4)
	float Skin Subsurface Power;  // 0xEDC(0x4)
	struct FLinearColor Skin color 2;  // 0xEE0(0x10)
	struct UTexture2D* Face Signs;  // 0xEF0(0x8)
	float Face signs str;  // 0xEF8(0x4)
	struct FLinearColor Eye Color;  // 0xEFC(0x10)
	float Eye IrisDepth;  // 0xF0C(0x4)
	float Cornea Mix;  // 0xF10(0x4)
	float Cornea Normal Flatten;  // 0xF14(0x4)
	float Cornea Roughness;  // 0xF18(0x4)
	float Cornea Specular;  // 0xF1C(0x4)
	float HDR str;  // 0xF20(0x4)
	int32_t Hair Diffuse texture;  // 0xF24(0x4)
	struct FLinearColor Hair Color;  // 0xF28(0x10)
	struct FLinearColor Hair Root Color;  // 0xF38(0x10)
	char pad_3912_1 : 7;  // 0xF48(0x1)
	bool Multiply color : 1;  // 0xF48(0x1)
	char pad_3913[3];  // 0xF49(0x3)
	struct FLinearColor Hair Fresnel Color;  // 0xF4C(0x10)
	float Hair Contrast;  // 0xF5C(0x4)
	float Hair Desaturation;  // 0xF60(0x4)
	float Hair FuzzyCoreDarkness;  // 0xF64(0x4)
	float Hair FuzzyEdgeBrightness;  // 0xF68(0x4)
	float Hair FuzzyPower;  // 0xF6C(0x4)
	float Hair Opacity Str;  // 0xF70(0x4)
	float Hair Root Contrast;  // 0xF74(0x4)
	float Hair Roughness;  // 0xF78(0x4)
	float Hair Specular;  // 0xF7C(0x4)
	float Hair Scatter;  // 0xF80(0x4)
	float Hair TangentMapStr;  // 0xF84(0x4)
	char pad_3976_1 : 7;  // 0xF88(0x1)
	bool Add Glass : 1;  // 0xF88(0x1)
	char pad_3977[3];  // 0xF89(0x3)
	int32_t Glass Var;  // 0xF8C(0x4)
	char pad_3984_1 : 7;  // 0xF90(0x1)
	bool Disable APEX Cloth : 1;  // 0xF90(0x1)
	char pad_3985_1 : 7;  // 0xF91(0x1)
	bool Reset to default Body : 1;  // 0xF91(0x1)
	char pad_3986[6];  // 0xF92(0x6)
	struct USkeletalMeshComponent* Item 1 Loc;  // 0xF98(0x8)
	struct USkeletalMeshComponent* Item 2 Loc;  // 0xFA0(0x8)
	struct USkeletalMeshComponent* Item 3 Loc;  // 0xFA8(0x8)
	float Additional Normal Intensity;  // 0xFB0(0x4)
	float BodyMorph01;  // 0xFB4(0x4)
	float BodyMorph02;  // 0xFB8(0x4)
	float BodyMorph03;  // 0xFBC(0x4)
	float BodyMorph04;  // 0xFC0(0x4)
	char pad_4036[4];  // 0xFC4(0x4)
	struct TArray<struct USkeletalMeshComponent*> AllMyMeshes;  // 0xFC8(0x10)
	float MaxDistanceHitscan;  // 0xFD8(0x4)
	float Pitch;  // 0xFDC(0x4)
	float MaxPickupDistance;  // 0xFE0(0x4)
	char pad_4068[4];  // 0xFE4(0x4)
	struct AProp_C* LookAtProp;  // 0xFE8(0x8)
	struct AProp_C* Last_LookAtProp;  // 0xFF0(0x8)
	char pad_4088_1 : 7;  // 0xFF8(0x1)
	bool LookingAtProp : 1;  // 0xFF8(0x1)
	char pad_4089[7];  // 0xFF9(0x7)
	struct TArray<struct AProp_C*> Last_5_lookedAt;  // 0x1000(0x10)
	struct UStaticMeshComponent* PropSM;  // 0x1010(0x8)
	char pad_4120_1 : 7;  // 0x1018(0x1)
	bool SpectralCannonEquipped : 1;  // 0x1018(0x1)
	char pad_4121[3];  // 0x1019(0x3)
	float Health;  // 0x101C(0x4)
	struct FRotator WorldRotationDrop;  // 0x1020(0xC)
	char pad_4140[4];  // 0x102C(0x4)
	AProp_C* ClassDrop;  // 0x1030(0x8)
	int32_t Ref Pickup Rot Code;  // 0x1038(0x4)
	float MaxHealth;  // 0x103C(0x4)
	struct UBlackScreen_UI_C* BlackScreen_UI;  // 0x1040(0x8)
	char HunterSpec Hunter_Spec;  // 0x1048(0x1)
	char pad_4169[3];  // 0x1049(0x3)
	float AmmoRemainingInClip;  // 0x104C(0x4)
	float MaxAmmoInClip;  // 0x1050(0x4)
	float AmmoRemainingInBackpack;  // 0x1054(0x4)
	char pad_4184_1 : 7;  // 0x1058(0x1)
	bool Reloading? : 1;  // 0x1058(0x1)
	char pad_4185[7];  // 0x1059(0x7)
	struct USpotLightComponent* Visible;  // 0x1060(0x8)
	char pad_4200_1 : 7;  // 0x1068(0x1)
	bool Punching? : 1;  // 0x1068(0x1)
	char pad_4201[3];  // 0x1069(0x3)
	float MaxDistanceMelee;  // 0x106C(0x4)
	struct FString PlayerName_StoredInBPPC;  // 0x1070(0x10)
	float Trap_AmmoRemainingInClip;  // 0x1080(0x4)
	float Trap_MaxAmmoInClip;  // 0x1084(0x4)
	float Trap_AmmoRemainingInBackpack;  // 0x1088(0x4)
	char pad_4236_1 : 7;  // 0x108C(0x1)
	bool AmmoBoxEquipped : 1;  // 0x108C(0x1)
	char pad_4237[3];  // 0x108D(0x3)
	struct UHealth_UI_C* Health_UI_Ref;  // 0x1090(0x8)
	float Stored_Health;  // 0x1098(0x4)
	float Stored_MaxHealth;  // 0x109C(0x4)
	char pad_4256_1 : 7;  // 0x10A0(0x1)
	bool TrapEquipped : 1;  // 0x10A0(0x1)
	char pad_4257[3];  // 0x10A1(0x3)
	float Trap_MS_RemainingInClip;  // 0x10A4(0x4)
	float Trap_MS_MaxInClip;  // 0x10A8(0x4)
	float Trap_MS_RemainingInBP;  // 0x10AC(0x4)
	char pad_4272_1 : 7;  // 0x10B0(0x1)
	bool CurrentlyOverlappingMyTrap : 1;  // 0x10B0(0x1)
	char pad_4273[7];  // 0x10B1(0x7)
	struct ABP_Trap_C* OverlappedSensor;  // 0x10B8(0x8)
	char pad_4288_1 : 7;  // 0x10C0(0x1)
	bool Ghost_Trapped! : 1;  // 0x10C0(0x1)
	char pad_4289_1 : 7;  // 0x10C1(0x1)
	bool GrenadeEquipped? : 1;  // 0x10C1(0x1)
	char pad_4290[2];  // 0x10C2(0x2)
	float GrenadesRemaining;  // 0x10C4(0x4)
	float GrenadesRemainingInClip;  // 0x10C8(0x4)
	char pad_4300_1 : 7;  // 0x10CC(0x1)
	bool Disable_Replication : 1;  // 0x10CC(0x1)
	char pad_4301[3];  // 0x10CD(0x3)
	struct AMGH_HUD_C* MGH HUD;  // 0x10D0(0x8)
	char pad_4312_1 : 7;  // 0x10D8(0x1)
	bool RightClicking? : 1;  // 0x10D8(0x1)
	char pad_4313_1 : 7;  // 0x10D9(0x1)
	bool SwitchingEquipment? : 1;  // 0x10D9(0x1)
	char pad_4314[2];  // 0x10DA(0x2)
	float SwitchEquipmentDelay;  // 0x10DC(0x4)
	char pad_4320_1 : 7;  // 0x10E0(0x1)
	bool RightClicking_Local : 1;  // 0x10E0(0x1)
	char pad_4321[7];  // 0x10E1(0x7)
	struct TArray<float> Teammates_Distances;  // 0x10E8(0x10)
	struct TArray<struct ABP_Hunter_C*> Teammates_Ref;  // 0x10F8(0x10)
	char pad_4360_1 : 7;  // 0x1108(0x1)
	bool Crouching : 1;  // 0x1108(0x1)
	char pad_4361[3];  // 0x1109(0x3)
	float CameraHeightTarget;  // 0x110C(0x4)
	int32_t NumberKills;  // 0x1110(0x4)
	char Hunter_Emotes CurrentEmote;  // 0x1114(0x1)
	char pad_4373[3];  // 0x1115(0x3)
	struct FRotator Stored_ControlRotation;  // 0x1118(0xC)
	char pad_4388_1 : 7;  // 0x1124(0x1)
	bool Global_InTutorialMode? : 1;  // 0x1124(0x1)
	char pad_4389_1 : 7;  // 0x1125(0x1)
	bool Tutorial_DisabledSelection : 1;  // 0x1125(0x1)
	char pad_4390_1 : 7;  // 0x1126(0x1)
	bool Tutorial_OnlyPickupChair01 : 1;  // 0x1126(0x1)
	char pad_4391[1];  // 0x1127(0x1)
	struct TArray<struct FName> Stored_OldTags;  // 0x1128(0x10)
	char pad_4408_1 : 7;  // 0x1138(0x1)
	bool Tutorial_ReadyForRadar : 1;  // 0x1138(0x1)
	char pad_4409_1 : 7;  // 0x1139(0x1)
	bool Tutorial_DisableFire : 1;  // 0x1139(0x1)
	char pad_4410_1 : 7;  // 0x113A(0x1)
	bool Tutorial_ReadyToSwitchToWeapon : 1;  // 0x113A(0x1)
	char pad_4411_1 : 7;  // 0x113B(0x1)
	bool Tutorial_DisableSwitchToWeapon : 1;  // 0x113B(0x1)
	char pad_4412_1 : 7;  // 0x113C(0x1)
	bool Tutorial_AmICurrentlyInATutorial : 1;  // 0x113C(0x1)
	char pad_4413_1 : 7;  // 0x113D(0x1)
	bool Tutorial_DisableSwitchToFists : 1;  // 0x113D(0x1)
	char pad_4414_1 : 7;  // 0x113E(0x1)
	bool Tutorial_DisablePunch : 1;  // 0x113E(0x1)
	char pad_4415_1 : 7;  // 0x113F(0x1)
	bool Tutorial_SwitchToFistsPROMPT : 1;  // 0x113F(0x1)
	char pad_4416_1 : 7;  // 0x1140(0x1)
	bool Tutorial_PunchPROMPT : 1;  // 0x1140(0x1)
	char pad_4417_1 : 7;  // 0x1141(0x1)
	bool Tutorial_DisableFlashlight : 1;  // 0x1141(0x1)
	char pad_4418_1 : 7;  // 0x1142(0x1)
	bool FlashlightOn? : 1;  // 0x1142(0x1)
	char pad_4419_1 : 7;  // 0x1143(0x1)
	bool Tutorial_DisableSwitchToScanner : 1;  // 0x1143(0x1)
	char pad_4420[4];  // 0x1144(0x4)
	struct TArray<struct AProp_C*> Array_AIGhosts;  // 0x1148(0x10)
	float Yaw;  // 0x1158(0x4)
	struct FVector Ai_StoredNextLocation;  // 0x115C(0xC)
	struct FVector AI_StoredNextLookAtLocation;  // 0x1168(0xC)
	char pad_4468_1 : 7;  // 0x1174(0x1)
	bool HideGun_HandsDown : 1;  // 0x1174(0x1)
	char pad_4469_1 : 7;  // 0x1175(0x1)
	bool HideGun_TurnOffToGoBack : 1;  // 0x1175(0x1)
	char pad_4470_1 : 7;  // 0x1176(0x1)
	bool Tutorial_BugFixDisableFire : 1;  // 0x1176(0x1)
	char pad_4471_1 : 7;  // 0x1177(0x1)
	bool Stunned : 1;  // 0x1177(0x1)
	char pad_4472_1 : 7;  // 0x1178(0x1)
	bool Stunned_Local : 1;  // 0x1178(0x1)
	char pad_4473_1 : 7;  // 0x1179(0x1)
	bool Died? : 1;  // 0x1179(0x1)
	char pad_4474[2];  // 0x117A(0x2)
	struct FRotator Stored_PickupHomeRotator;  // 0x117C(0xC)
	struct FVector Stored_PickupHomeVector;  // 0x1188(0xC)
	int32_t NumberDeaths;  // 0x1194(0x4)
	char pad_4504_1 : 7;  // 0x1198(0x1)
	bool FOV_Zooming? : 1;  // 0x1198(0x1)
	char pad_4505[7];  // 0x1199(0x7)
	struct AFirelight_SabotagedH_C* My_SabotageSparks;  // 0x11A0(0x8)
	char HunterWeapon EquippedWeapon;  // 0x11A8(0x1)
	char pad_4521_1 : 7;  // 0x11A9(0x1)
	bool HoldingLeftClick? : 1;  // 0x11A9(0x1)
	char pad_4522_1 : 7;  // 0x11AA(0x1)
	bool BeamCreated? : 1;  // 0x11AA(0x1)
	char pad_4523[5];  // 0x11AB(0x5)
	struct UParticleSystemComponent* MyBeam;  // 0x11B0(0x8)
	char pad_4536_1 : 7;  // 0x11B8(0x1)
	bool FlameCreated? : 1;  // 0x11B8(0x1)
	char pad_4537[7];  // 0x11B9(0x7)
	struct UParticleSystemComponent* My Flame;  // 0x11C0(0x8)
	struct FHitResult RecentHit;  // 0x11C8(0x88)
	char pad_4688_1 : 7;  // 0x1250(0x1)
	bool Flame_AttemptSecondaryTrace : 1;  // 0x1250(0x1)
	char pad_4689[3];  // 0x1251(0x3)
	struct FVector Pickup_DropArrowVector;  // 0x1254(0xC)
	char pad_4704_1 : 7;  // 0x1260(0x1)
	bool Flashlight_on_LOCAL : 1;  // 0x1260(0x1)
	char pad_4705_1 : 7;  // 0x1261(0x1)
	bool Tutorial_T_Disabled? : 1;  // 0x1261(0x1)
	char pad_4706_1 : 7;  // 0x1262(0x1)
	bool Tutorial_NextT_WillDisable : 1;  // 0x1262(0x1)
	char pad_4707_1 : 7;  // 0x1263(0x1)
	bool AmI_ABOT? : 1;  // 0x1263(0x1)
	char pad_4708_1 : 7;  // 0x1264(0x1)
	bool AI_HoldFire : 1;  // 0x1264(0x1)
	char pad_4709_1 : 7;  // 0x1265(0x1)
	bool AI_OutOfAmmo : 1;  // 0x1265(0x1)
	char pad_4710_1 : 7;  // 0x1266(0x1)
	bool IsADoppelganger? : 1;  // 0x1266(0x1)
	char pad_4711[1];  // 0x1267(0x1)
	struct FString StolenName;  // 0x1268(0x10)
	struct UCameraComponent* ActiveCamera;  // 0x1278(0x8)
	struct AMGH_PlayerState_C* Stolen_PlayerState;  // 0x1280(0x8)
	struct TArray<struct ABP_Hunter_C*> MyTeammatesLocal;  // 0x1288(0x10)
	struct TArray<struct FHunterNameplateStruct> TeammatesDistances;  // 0x1298(0x10)
	struct ABP_PC_Chargeup_C* My_Chargeup;  // 0x12A8(0x8)
	char pad_4784_1 : 7;  // 0x12B0(0x1)
	bool ChargingUp? : 1;  // 0x12B0(0x1)
	char pad_4785[3];  // 0x12B1(0x3)
	float ChargeUpFactor;  // 0x12B4(0x4)
	char pad_4792_1 : 7;  // 0x12B8(0x1)
	bool First Or Third Person Camera? : 1;  // 0x12B8(0x1)
	char pad_4793[7];  // 0x12B9(0x7)
	struct ALvlProp_C* Last_LookAtLvlProp;  // 0x12C0(0x8)
	struct ALvlProp_C* LookAt_LvlProp;  // 0x12C8(0x8)
	char pad_4816_1 : 7;  // 0x12D0(0x1)
	bool LookingAtLVLProp? : 1;  // 0x12D0(0x1)
	char pad_4817_1 : 7;  // 0x12D1(0x1)
	bool PathfinderEquipped : 1;  // 0x12D1(0x1)
	char pad_4818_1 : 7;  // 0x12D2(0x1)
	bool OverlappingHunterRes : 1;  // 0x12D2(0x1)
	char pad_4819[5];  // 0x12D3(0x5)
	struct UHunterRez_UI_C* My_HunterRez;  // 0x12D8(0x8)
	struct UBoxComponent* My_RezCollision;  // 0x12E0(0x8)
	struct ABP_Hunter_C* OverlappingDeadHunter;  // 0x12E8(0x8)
	struct AMGH_PlayerController_BP_C* MGH_PlayerController_Stored;  // 0x12F0(0x8)
	struct ABP_DeadHunterOrb_C* My_DeadHunterOrb;  // 0x12F8(0x8)
	char pad_4864_1 : 7;  // 0x1300(0x1)
	bool Resurrectable? : 1;  // 0x1300(0x1)
	char pad_4865_1 : 7;  // 0x1301(0x1)
	bool BeingRezzed? : 1;  // 0x1301(0x1)
	char pad_4866[2];  // 0x1302(0x2)
	struct FVector Resurrect_StoredOrbLocation;  // 0x1304(0xC)
	char pad_4880_1 : 7;  // 0x1310(0x1)
	bool OC_CameraLockToBody? : 1;  // 0x1310(0x1)
	char pad_4881_1 : 7;  // 0x1311(0x1)
	bool Van_Sitting : 1;  // 0x1311(0x1)
	char pad_4882_1 : 7;  // 0x1312(0x1)
	bool Van_Sitting_Local : 1;  // 0x1312(0x1)
	char pad_4883[1];  // 0x1313(0x1)
	int32_t Van_AssignedSeat;  // 0x1314(0x4)
	struct ABP_HunterVehicle_C* Van_AssignedVan;  // 0x1318(0x8)
	struct AMGH_PlayerController_BP_C* Van_ClearerANPC;  // 0x1320(0x8)
	float Radar_Battery;  // 0x1328(0x4)
	char pad_4908[4];  // 0x132C(0x4)
	struct UObject* FlashlightCharge_UI;  // 0x1330(0x8)
	char pad_4920_1 : 7;  // 0x1338(0x1)
	bool WeaponFired : 1;  // 0x1338(0x1)
	char pad_4921[7];  // 0x1339(0x7)
	struct TArray<struct ABP_EctoplasmTrail_C*> My_EctoTrails;  // 0x1340(0x10)
	char pad_4944_1 : 7;  // 0x1350(0x1)
	bool GrenadeThrownLocal : 1;  // 0x1350(0x1)
	char pad_4945_1 : 7;  // 0x1351(0x1)
	bool GrenadeThrownReplicated : 1;  // 0x1351(0x1)
	char pad_4946_1 : 7;  // 0x1352(0x1)
	bool SwitchingEquipment_Local : 1;  // 0x1352(0x1)
	char pad_4947_1 : 7;  // 0x1353(0x1)
	bool SpectralChargeup_Status : 1;  // 0x1353(0x1)
	int32_t SpectralChargeup_Amount;  // 0x1354(0x4)
	struct ABP_Sound_C* MyChargeupSound;  // 0x1358(0x8)
	char pad_4960_1 : 7;  // 0x1360(0x1)
	bool FlashlightButtonHeld? : 1;  // 0x1360(0x1)
	char pad_4961_1 : 7;  // 0x1361(0x1)
	bool FlashlightButtonHeld?_local : 1;  // 0x1361(0x1)
	char pad_4962_1 : 7;  // 0x1362(0x1)
	bool SpectralCannonChargeup : 1;  // 0x1362(0x1)
	char pad_4963[5];  // 0x1363(0x5)
	struct USceneCaptureComponent2D* MySceneCapture2D;  // 0x1368(0x8)
	struct FHitResult LoopHitResult;  // 0x1370(0x88)
	float Salt Time Remaining;  // 0x13F8(0x4)
	char pad_5116[4];  // 0x13FC(0x4)
	struct ABP_interactiveObject_C* My_InteractedObject;  // 0x1400(0x8)
	char pad_5128_1 : 7;  // 0x1408(0x1)
	bool LookingAtGenerator : 1;  // 0x1408(0x1)
	char pad_5129_1 : 7;  // 0x1409(0x1)
	bool LookingAtReviveOrb : 1;  // 0x1409(0x1)
	char pad_5130_1 : 7;  // 0x140A(0x1)
	bool RezUI_Enabled : 1;  // 0x140A(0x1)
	char pad_5131[1];  // 0x140B(0x1)
	float Right Axis Value;  // 0x140C(0x4)
	float Backward Axis Value;  // 0x1410(0x4)
	char pad_5140[4];  // 0x1414(0x4)
	struct FString LastVisHitInfo;  // 0x1418(0x10)
	char HunterGadgets Primary Slot Gadget;  // 0x1428(0x1)
	char HunterGadgets Secondary Slot Gadget;  // 0x1429(0x1)
	char HunterPerks Equipped Perk;  // 0x142A(0x1)
	char pad_5163_1 : 7;  // 0x142B(0x1)
	bool Primary Slot Equipped? : 1;  // 0x142B(0x1)
	char pad_5164_1 : 7;  // 0x142C(0x1)
	bool Secondary Slot Equipped? : 1;  // 0x142C(0x1)
	char pad_5165_1 : 7;  // 0x142D(0x1)
	bool Quick Equip Change : 1;  // 0x142D(0x1)
	char pad_5166_1 : 7;  // 0x142E(0x1)
	bool Sprinting : 1;  // 0x142E(0x1)
	char pad_5167_1 : 7;  // 0x142F(0x1)
	bool Cooking Grenade? : 1;  // 0x142F(0x1)
	float Cooking Grenade Time Remaining;  // 0x1430(0x4)
	char pad_5172[4];  // 0x1434(0x4)
	struct ABP_Grenade_C* My_Grenade;  // 0x1438(0x8)
	struct UStaticMeshComponent* GrenadeAttachMesh;  // 0x1440(0x8)
	char pad_5192_1 : 7;  // 0x1448(0x1)
	bool DEBUG_AutoWalkFire? : 1;  // 0x1448(0x1)
	char pad_5193_1 : 7;  // 0x1449(0x1)
	bool LookingAtGennyTable? : 1;  // 0x1449(0x1)
	char pad_5194_1 : 7;  // 0x144A(0x1)
	bool ChangedEquipment? : 1;  // 0x144A(0x1)
	char pad_5195_1 : 7;  // 0x144B(0x1)
	bool Holding Fire? : 1;  // 0x144B(0x1)
	char pad_5196_1 : 7;  // 0x144C(0x1)
	bool Override Clothes Color? : 1;  // 0x144C(0x1)
	char pad_5197[3];  // 0x144D(0x3)
	struct FLinearColor Override PRIMARY COLOR;  // 0x1450(0x10)
	struct FLinearColor Override SECONDARY COLOR;  // 0x1460(0x10)
	char pad_5232_1 : 7;  // 0x1470(0x1)
	bool CanThrowGrenade? : 1;  // 0x1470(0x1)
	char pad_5233_1 : 7;  // 0x1471(0x1)
	bool NightvisionEquipped? : 1;  // 0x1471(0x1)
	char pad_5234_1 : 7;  // 0x1472(0x1)
	bool DisableType : 1;  // 0x1472(0x1)
	char pad_5235[1];  // 0x1473(0x1)
	float Cannon Battery Level;  // 0x1474(0x4)
	float CannonBattery_Max;  // 0x1478(0x4)
	char pad_5244_1 : 7;  // 0x147C(0x1)
	bool Adjusted Battery Recently? : 1;  // 0x147C(0x1)
	char pad_5245_1 : 7;  // 0x147D(0x1)
	bool Captured Recently? : 1;  // 0x147D(0x1)
	char pad_5246_1 : 7;  // 0x147E(0x1)
	bool Spectral Cannon Cooldown? : 1;  // 0x147E(0x1)
	char pad_5247[1];  // 0x147F(0x1)
	struct ABP_Sound_C* MyChargeupSound_Old;  // 0x1480(0x8)
	char pad_5256_1 : 7;  // 0x1488(0x1)
	bool Trap Cooldown? : 1;  // 0x1488(0x1)
	char pad_5257_1 : 7;  // 0x1489(0x1)
	bool Ghostcatcher Init'd (ANALYTICS) : 1;  // 0x1489(0x1)
	char pad_5258_1 : 7;  // 0x148A(0x1)
	bool Ghostcatcher Hit Ghost (ANALYTICS) : 1;  // 0x148A(0x1)
	char pad_5259_1 : 7;  // 0x148B(0x1)
	bool HasMoved? : 1;  // 0x148B(0x1)
	char pad_5260_1 : 7;  // 0x148C(0x1)
	bool HasMoved?_local : 1;  // 0x148C(0x1)
	char pad_5261[3];  // 0x148D(0x3)
	struct FTransform LockToThisXForm;  // 0x1490(0x30)
	char pad_5312_1 : 7;  // 0x14C0(0x1)
	bool CookingNadeLocal : 1;  // 0x14C0(0x1)
	char pad_5313_1 : 7;  // 0x14C1(0x1)
	bool ClearedReleaseNade : 1;  // 0x14C1(0x1)
	char pad_5314_1 : 7;  // 0x14C2(0x1)
	bool AmmoReplenishCooldown : 1;  // 0x14C2(0x1)
	char pad_5315_1 : 7;  // 0x14C3(0x1)
	bool EquipmentChangeCooldown : 1;  // 0x14C3(0x1)
	char pad_5316[4];  // 0x14C4(0x4)
	struct USphereComponent* FPNozzle-FromGC;  // 0x14C8(0x8)
	char pad_5328_1 : 7;  // 0x14D0(0x1)
	bool ANIM_BeamInPlay? : 1;  // 0x14D0(0x1)
	char pad_5329_1 : 7;  // 0x14D1(0x1)
	bool ANIM_CancelFire : 1;  // 0x14D1(0x1)
	char pad_5330_1 : 7;  // 0x14D2(0x1)
	bool DEBUG InfiniBeam? : 1;  // 0x14D2(0x1)
	char pad_5331_1 : 7;  // 0x14D3(0x1)
	bool Captured Recently LOCAL : 1;  // 0x14D3(0x1)
	char pad_5332_1 : 7;  // 0x14D4(0x1)
	bool TPANIM_ChargingSpectralCannon : 1;  // 0x14D4(0x1)
	char pad_5333_1 : 7;  // 0x14D5(0x1)
	bool TPANIM_SpectralCannonInPlay : 1;  // 0x14D5(0x1)
	char pad_5334_1 : 7;  // 0x14D6(0x1)
	bool TPANIM_SpectralCannonCapturedRecently : 1;  // 0x14D6(0x1)
	char pad_5335_1 : 7;  // 0x14D7(0x1)
	bool TPANIM_CancelFire : 1;  // 0x14D7(0x1)
	char pad_5336_1 : 7;  // 0x14D8(0x1)
	bool TPANIM_Cannon_RecentlyEquipped : 1;  // 0x14D8(0x1)
	char pad_5337_1 : 7;  // 0x14D9(0x1)
	bool ForceMaximimGeiger? : 1;  // 0x14D9(0x1)
	char pad_5338_1 : 7;  // 0x14DA(0x1)
	bool VacuumTickerInitd : 1;  // 0x14DA(0x1)
	char pad_5339_1 : 7;  // 0x14DB(0x1)
	bool ANIM Vacuuming? : 1;  // 0x14DB(0x1)
	char pad_5340_1 : 7;  // 0x14DC(0x1)
	bool TPANIM Vacuuming? : 1;  // 0x14DC(0x1)
	char pad_5341_1 : 7;  // 0x14DD(0x1)
	bool Debug_BYPASS_BATTERY? : 1;  // 0x14DD(0x1)
	char pad_5342[2];  // 0x14DE(0x2)
	float MouseSensitivity;  // 0x14E0(0x4)
	float FOVSetting;  // 0x14E4(0x4)
	float MotionBlurSetting;  // 0x14E8(0x4)
	char pad_5356_1 : 7;  // 0x14EC(0x1)
	bool MouseInvertX : 1;  // 0x14EC(0x1)
	char pad_5357_1 : 7;  // 0x14ED(0x1)
	bool MouseInvertY : 1;  // 0x14ED(0x1)
	char pad_5358_1 : 7;  // 0x14EE(0x1)
	bool Cancelled Fire : 1;  // 0x14EE(0x1)
	char pad_5359[1];  // 0x14EF(0x1)
	struct UVacuumIndicator_UI_C* My_VacuumIndicator;  // 0x14F0(0x8)
	char pad_5368_1 : 7;  // 0x14F8(0x1)
	bool TPAnim_Sprinting : 1;  // 0x14F8(0x1)
	char pad_5369[7];  // 0x14F9(0x7)
	struct FTransform DropXForm;  // 0x1500(0x30)
	struct USceneComponent* Cannon Turbine Location;  // 0x1530(0x8)
	struct USceneComponent* Vacuum Nozzle Location;  // 0x1538(0x8)
	struct UObject* CLIENT_CannonFire;  // 0x1540(0x8)
	struct UObject* My HBOT Controller;  // 0x1548(0x8)
	char pad_5456_1 : 7;  // 0x1550(0x1)
	bool Tutorial Lock Movement : 1;  // 0x1550(0x1)
	char pad_5457_1 : 7;  // 0x1551(0x1)
	bool Tutorial_LockPrimaryEquipment : 1;  // 0x1551(0x1)
	char pad_5458_1 : 7;  // 0x1552(0x1)
	bool Tutorial_SuccessfullySwitchToRadar : 1;  // 0x1552(0x1)
	char pad_5459_1 : 7;  // 0x1553(0x1)
	bool Tutorial_ReadyToFindGhost : 1;  // 0x1553(0x1)
	char pad_5460_1 : 7;  // 0x1554(0x1)
	bool Tutorial_ReadyToFireWeapon : 1;  // 0x1554(0x1)
	char pad_5461_1 : 7;  // 0x1555(0x1)
	bool Tutorial_DisableVacuum : 1;  // 0x1555(0x1)
	char pad_5462_1 : 7;  // 0x1556(0x1)
	bool Tutorial_ReadyToVacuum : 1;  // 0x1556(0x1)
	char pad_5463_1 : 7;  // 0x1557(0x1)
	bool Tutorial_PrimaryFireNextStepTutorial : 1;  // 0x1557(0x1)
	char pad_5464_1 : 7;  // 0x1558(0x1)
	bool Tutorial_ReadyToDestroyGhost : 1;  // 0x1558(0x1)
	char pad_5465_1 : 7;  // 0x1559(0x1)
	bool Tutorial_DisableGhostDamage : 1;  // 0x1559(0x1)
	char pad_5466_1 : 7;  // 0x155A(0x1)
	bool RnD-UseRechargingBattery? : 1;  // 0x155A(0x1)
	char pad_5467_1 : 7;  // 0x155B(0x1)
	bool SpectralRecharging : 1;  // 0x155B(0x1)
	char pad_5468_1 : 7;  // 0x155C(0x1)
	bool RnD-FiredRecently? : 1;  // 0x155C(0x1)
	char pad_5469[3];  // 0x155D(0x3)
	struct UAudioComponent* ReloadingHunterBatterySound;  // 0x1560(0x8)
	char pad_5480_1 : 7;  // 0x1568(0x1)
	bool Ghostsmasher Equipped? Local : 1;  // 0x1568(0x1)
	char pad_5481_1 : 7;  // 0x1569(0x1)
	bool Ghostsmasher Attack Cooldown : 1;  // 0x1569(0x1)
	char pad_5482_1 : 7;  // 0x156A(0x1)
	bool Ghostsmasher Equipped : 1;  // 0x156A(0x1)
	char pad_5483_1 : 7;  // 0x156B(0x1)
	bool Ghostsmasher Attacked? Local : 1;  // 0x156B(0x1)
	char pad_5484[4];  // 0x156C(0x4)
	struct TArray<struct AProp_C*> MeleeStruckGhosts;  // 0x1570(0x10)
	char pad_5504_1 : 7;  // 0x1580(0x1)
	bool Ghostsmasher Attacked? : 1;  // 0x1580(0x1)
	char pad_5505_1 : 7;  // 0x1581(0x1)
	bool Shield Equipped? : 1;  // 0x1581(0x1)
	char pad_5506_1 : 7;  // 0x1582(0x1)
	bool Shield Equipped? Local : 1;  // 0x1582(0x1)
	char pad_5507[5];  // 0x1583(0x5)
	struct AActor* Shield_OverlapActor;  // 0x1588(0x8)
	struct FHitResult Shield Overlap Sweep;  // 0x1590(0x88)
	struct AMGH_PlayerState_C* Hunter Player State Stored;  // 0x1618(0x8)
	struct TArray<struct ALvlProp_C*> Melee Struck Lvlprops;  // 0x1620(0x10)
	char pad_5680_1 : 7;  // 0x1630(0x1)
	bool Shield Attack? : 1;  // 0x1630(0x1)
	char pad_5681_1 : 7;  // 0x1631(0x1)
	bool Shield Attack? Local : 1;  // 0x1631(0x1)
	char pad_5682_1 : 7;  // 0x1632(0x1)
	bool Shield Attack Cooldown : 1;  // 0x1632(0x1)
	char pad_5683_1 : 7;  // 0x1633(0x1)
	bool Debug_GODMODE? : 1;  // 0x1633(0x1)
	char pad_5684[4];  // 0x1634(0x4)
	struct TArray<struct ABP_Hunter_C*> Hunter Souls Carrying;  // 0x1638(0x10)
	char pad_5704_1 : 7;  // 0x1648(0x1)
	bool Has Revive Orbs? : 1;  // 0x1648(0x1)
	char pad_5705_1 : 7;  // 0x1649(0x1)
	bool Looking At Genny - Revive Orbs : 1;  // 0x1649(0x1)
	char pad_5706_1 : 7;  // 0x164A(0x1)
	bool Reviving Hunter Orbs : 1;  // 0x164A(0x1)
	char pad_5707[5];  // 0x164B(0x5)
	struct ABP_Generator_C* Generator;  // 0x1650(0x8)
	char pad_5720_1 : 7;  // 0x1658(0x1)
	bool TUTORIAL Ready to GeneratorSwitch : 1;  // 0x1658(0x1)
	char pad_5721_1 : 7;  // 0x1659(0x1)
	bool TUTORIAL - GeneratorSwitchOnlyOneGadget : 1;  // 0x1659(0x1)
	char LoadoutCategoryTypes TUTORIAL - GeneratorSwitchOnlyCategoryThis;  // 0x165A(0x1)
	char HunterGadgets TUTORIAL - GeneratorSwitchOnlyOneGadgetThis;  // 0x165B(0x1)
	char pad_5724_1 : 7;  // 0x165C(0x1)
	bool TUTORIAL Ready for Generator Overlap : 1;  // 0x165C(0x1)
	char pad_5725_1 : 7;  // 0x165D(0x1)
	bool Tutorial_GadgetOverviewReady : 1;  // 0x165D(0x1)
	char pad_5726_1 : 7;  // 0x165E(0x1)
	bool Tutorial_ReadyForPathfinderFight : 1;  // 0x165E(0x1)
	char pad_5727_1 : 7;  // 0x165F(0x1)
	bool Tutorial_ReadyForPathfinderFight_3 : 1;  // 0x165F(0x1)
	char pad_5728_1 : 7;  // 0x1660(0x1)
	bool Tutorial_PlacedTrapCloseEnough : 1;  // 0x1660(0x1)
	char pad_5729_1 : 7;  // 0x1661(0x1)
	bool Tutorial_ReadyForTrapThrow : 1;  // 0x1661(0x1)
	char pad_5730_1 : 7;  // 0x1662(0x1)
	bool Tutorial_ReadyForTrapWatch : 1;  // 0x1662(0x1)
	char pad_5731_1 : 7;  // 0x1663(0x1)
	bool Tutorial_ReadyForShieldBash : 1;  // 0x1663(0x1)
	char pad_5732_1 : 7;  // 0x1664(0x1)
	bool Tutorial_ReadyForLvlpropSmash : 1;  // 0x1664(0x1)
	char pad_5733_1 : 7;  // 0x1665(0x1)
	bool Tutorial_ReadyForThrowGrenade : 1;  // 0x1665(0x1)
	char pad_5734_1 : 7;  // 0x1666(0x1)
	bool GTutorial_ReadyForBedroom1 : 1;  // 0x1666(0x1)
	char pad_5735_1 : 7;  // 0x1667(0x1)
	bool GTutorial_ReadyForBedroom2 : 1;  // 0x1667(0x1)
	char pad_5736_1 : 7;  // 0x1668(0x1)
	bool GTutorial_ReadyForChase1 : 1;  // 0x1668(0x1)
	char pad_5737_1 : 7;  // 0x1669(0x1)
	bool GTutorial_ReadyForChase2 : 1;  // 0x1669(0x1)
	char HunterGadgets JoinSync;  // 0x166A(0x1)
	char pad_5739_1 : 7;  // 0x166B(0x1)
	bool Shield Broken? : 1;  // 0x166B(0x1)
	char pad_5740_1 : 7;  // 0x166C(0x1)
	bool ThrowingTrap? : 1;  // 0x166C(0x1)
	char pad_5741_1 : 7;  // 0x166D(0x1)
	bool A Killcam Hunter? : 1;  // 0x166D(0x1)
	char pad_5742_1 : 7;  // 0x166E(0x1)
	bool Game Over? : 1;  // 0x166E(0x1)
	char pad_5743[1];  // 0x166F(0x1)
	struct TArray<struct ABP_Hunter_C*> Melee Hit Hunters Already;  // 0x1670(0x10)
	struct UObject* Got Sabotaged UI;  // 0x1680(0x8)
	char pad_5768_1 : 7;  // 0x1688(0x1)
	bool Local Sabotaged? : 1;  // 0x1688(0x1)
	char pad_5769_1 : 7;  // 0x1689(0x1)
	bool Sabotage Trapped? : 1;  // 0x1689(0x1)
	char pad_5770_1 : 7;  // 0x168A(0x1)
	bool Defib Equipped? : 1;  // 0x168A(0x1)
	char pad_5771[5];  // 0x168B(0x5)
	struct UParticleSystemComponent* Sabotage VFX 2;  // 0x1690(0x8)
	struct UParticleSystemComponent* Sabotage VFX 1;  // 0x1698(0x8)
	float Default Walk Speed;  // 0x16A0(0x4)
	char pad_5796_1 : 7;  // 0x16A4(0x1)
	bool Trap Speed Set? : 1;  // 0x16A4(0x1)
	char pad_5797_1 : 7;  // 0x16A5(0x1)
	bool Sprint Disabled : 1;  // 0x16A5(0x1)
	char pad_5798_1 : 7;  // 0x16A6(0x1)
	bool Hunter Is Sabotaged : 1;  // 0x16A6(0x1)
	char pad_5799[1];  // 0x16A7(0x1)
	struct UAudioComponent* Sabotage Sound;  // 0x16A8(0x8)
	char pad_5808_1 : 7;  // 0x16B0(0x1)
	bool Picked Up Prop? : 1;  // 0x16B0(0x1)
	char pad_5809[3];  // 0x16B1(0x3)
	int32_t Weapon Power Level;  // 0x16B4(0x4)
	int32_t Gadget Power Level;  // 0x16B8(0x4)
	char pad_5820_1 : 7;  // 0x16BC(0x1)
	bool Dead Ghost Nearby? : 1;  // 0x16BC(0x1)
	char pad_5821_1 : 7;  // 0x16BD(0x1)
	bool Dead Ghost Distance : 1;  // 0x16BD(0x1)
	char pad_5822_1 : 7;  // 0x16BE(0x1)
	bool Slowed : 1;  // 0x16BE(0x1)
	char pad_5823_1 : 7;  // 0x16BF(0x1)
	bool Juggernaut Damage? : 1;  // 0x16BF(0x1)
	char pad_5824_1 : 7;  // 0x16C0(0x1)
	bool Struck One Levelprop Already? : 1;  // 0x16C0(0x1)
	char pad_5825_1 : 7;  // 0x16C1(0x1)
	bool Defib Rub Local : 1;  // 0x16C1(0x1)
	char pad_5826_1 : 7;  // 0x16C2(0x1)
	bool Project X Equipped? : 1;  // 0x16C2(0x1)
	char pad_5827[5];  // 0x16C3(0x5)
	struct FTimerHandle Fire Event;  // 0x16C8(0x8)
	char pad_5840_1 : 7;  // 0x16D0(0x1)
	bool Defib Zap Local : 1;  // 0x16D0(0x1)
	char pad_5841[7];  // 0x16D1(0x7)
	struct UAudioComponent* Defib Sounds;  // 0x16D8(0x8)
	char pad_5856_1 : 7;  // 0x16E0(0x1)
	bool Project X Chargeup? : 1;  // 0x16E0(0x1)
	char pad_5857[7];  // 0x16E1(0x7)
	struct UAudioComponent* Project X Chargeup;  // 0x16E8(0x8)
	char pad_5872_1 : 7;  // 0x16F0(0x1)
	bool Project X Fire : 1;  // 0x16F0(0x1)
	char pad_5873[7];  // 0x16F1(0x7)
	struct UAudioComponent* Project X Engine;  // 0x16F8(0x8)
	char pad_5888_1 : 7;  // 0x1700(0x1)
	bool Project X Overheated? : 1;  // 0x1700(0x1)
	char pad_5889[3];  // 0x1701(0x3)
	int32_t Project X Heat Levels?;  // 0x1704(0x4)
	struct UProjectX_UI_C* Project X UI;  // 0x1708(0x8)
	char pad_5904_1 : 7;  // 0x1710(0x1)
	bool Project X Pitch Repl? : 1;  // 0x1710(0x1)
	char pad_5905[3];  // 0x1711(0x3)
	float X Fire Speed;  // 0x1714(0x4)
	struct FRotator Fire Rotator;  // 0x1718(0xC)
	float Fire Randomization;  // 0x1724(0x4)
	char pad_5928_1 : 7;  // 0x1728(0x1)
	bool Project X Winding Down? : 1;  // 0x1728(0x1)
	char HunterGadgets Switch To Loadout?;  // 0x1729(0x1)
	char pad_5930[6];  // 0x172A(0x6)
	struct UMaterialInstanceDynamic* X FP Card Mtl;  // 0x1730(0x8)
	char pad_5944_1 : 7;  // 0x1738(0x1)
	bool Project X Cooling? : 1;  // 0x1738(0x1)
	char pad_5945[7];  // 0x1739(0x7)
	struct UParticleSystemComponent* Overheat Particles;  // 0x1740(0x8)
	struct UAudioComponent* Overheat Sound;  // 0x1748(0x8)
	char pad_5968_1 : 7;  // 0x1750(0x1)
	bool Hunter Push Cooldown : 1;  // 0x1750(0x1)
	char pad_5969[3];  // 0x1751(0x3)
	int32_t Available Upgrade Points;  // 0x1754(0x4)
	int32_t Equipped Weapon Power Level;  // 0x1758(0x4)
	float Default Sprint Speed;  // 0x175C(0x4)
	float WeaponAttachInterpSpeed;  // 0x1760(0x4)
	float SwitchToWeaponAttachDelay;  // 0x1764(0x4)
	float Tutorial BeamRifleLocationZ;  // 0x1768(0x4)
	char pad_5996_1 : 7;  // 0x176C(0x1)
	bool ForceSYNC : 1;  // 0x176C(0x1)
	char pad_5997_1 : 7;  // 0x176D(0x1)
	bool DisableJump : 1;  // 0x176D(0x1)
	char pad_5998_1 : 7;  // 0x176E(0x1)
	bool UI Actor? : 1;  // 0x176E(0x1)
	char pad_5999_1 : 7;  // 0x176F(0x1)
	bool FP Sync : 1;  // 0x176F(0x1)
	float JDmgReduceDivider;  // 0x1770(0x4)
	char pad_6004[4];  // 0x1774(0x4)
	struct UMGH_GameInstance_BP_C* MGH Game Instance;  // 0x1778(0x8)
	struct USkeletalMeshComponent* Spectator Temp Arms;  // 0x1780(0x8)
	char pad_6024_1 : 7;  // 0x1788(0x1)
	bool WeaponSwitchedOff : 1;  // 0x1788(0x1)
	char pad_6025[7];  // 0x1789(0x7)
	struct AMGH_GameState_C* MGH Game State;  // 0x1790(0x8)
	struct AActor* ConveyorActor;  // 0x1798(0x8)
	int32_t LatestDamage;  // 0x17A0(0x4)
	char pad_6052_1 : 7;  // 0x17A4(0x1)
	bool WasEffectiveHit? : 1;  // 0x17A4(0x1)
	char pad_6053_1 : 7;  // 0x17A5(0x1)
	bool OnConveyor? : 1;  // 0x17A5(0x1)
	char pad_6054[2];  // 0x17A6(0x2)
	struct FTimerHandle DebugFootprintTimer;  // 0x17A8(0x8)
	struct AConveyorParentActor_C* ConveyorParent;  // 0x17B0(0x8)
	char pad_6072_1 : 7;  // 0x17B8(0x1)
	bool Render Hunter? : 1;  // 0x17B8(0x1)
	char pad_6073[7];  // 0x17B9(0x7)
	struct UPointLightComponent* MaskLightLoc;  // 0x17C0(0x8)
	char pad_6088_1 : 7;  // 0x17C8(0x1)
	bool HarpoonBazooka Equipped? : 1;  // 0x17C8(0x1)
	char pad_6089_1 : 7;  // 0x17C9(0x1)
	bool Re-Visible FP Components : 1;  // 0x17C9(0x1)
	char pad_6090_1 : 7;  // 0x17CA(0x1)
	bool Hide FP Components : 1;  // 0x17CA(0x1)
	char pad_6091_1 : 7;  // 0x17CB(0x1)
	bool Harpoon Cooldown? : 1;  // 0x17CB(0x1)
	char pad_6092[4];  // 0x17CC(0x4)
	struct AHarpoonProjectile_C* LastHarpoon;  // 0x17D0(0x8)
	char pad_6104_1 : 7;  // 0x17D8(0x1)
	bool Harpoon Fired? : 1;  // 0x17D8(0x1)
	char pad_6105_1 : 7;  // 0x17D9(0x1)
	bool Harpoon Hit Nothing? : 1;  // 0x17D9(0x1)
	char pad_6106_1 : 7;  // 0x17DA(0x1)
	bool Harpoon Hit Ghost? : 1;  // 0x17DA(0x1)
	char pad_6107[5];  // 0x17DB(0x5)
	struct AProp_C* Harpoon Hit Ghost Ref;  // 0x17E0(0x8)
	char pad_6120_1 : 7;  // 0x17E8(0x1)
	bool Harpoon Fired? Anim : 1;  // 0x17E8(0x1)
	char pad_6121_1 : 7;  // 0x17E9(0x1)
	bool Harpoon Reeling Ghost? : 1;  // 0x17E9(0x1)
	char pad_6122_1 : 7;  // 0x17EA(0x1)
	bool New_Flashlight_On : 1;  // 0x17EA(0x1)
	char pad_6123_1 : 7;  // 0x17EB(0x1)
	bool Harpoon Equipping : 1;  // 0x17EB(0x1)
	char pad_6124_1 : 7;  // 0x17EC(0x1)
	bool Harpoon DeEquipping? : 1;  // 0x17EC(0x1)
	char pad_6125[3];  // 0x17ED(0x3)
	struct UHarpoonChainStrength_UI_C* Harpoon UI;  // 0x17F0(0x8)
	float Harpoon Strength;  // 0x17F8(0x4)
	char pad_6140_1 : 7;  // 0x17FC(0x1)
	bool DontDeleteHarpoon : 1;  // 0x17FC(0x1)
	char pad_6141_1 : 7;  // 0x17FD(0x1)
	bool HarpoonReeling? : 1;  // 0x17FD(0x1)
	char pad_6142[2];  // 0x17FE(0x2)
	float HarpoonInterpSpeed;  // 0x1800(0x4)
	char pad_6148_1 : 7;  // 0x1804(0x1)
	bool HarpoonManagerBroken : 1;  // 0x1804(0x1)
	char pad_6149[3];  // 0x1805(0x3)
	int32_t HarpoonStrength_Replicated;  // 0x1808(0x4)
	char pad_6156_1 : 7;  // 0x180C(0x1)
	bool HarpoonBreakFast : 1;  // 0x180C(0x1)
	char pad_6157_1 : 7;  // 0x180D(0x1)
	bool Harpoon Fired?_TPAnim : 1;  // 0x180D(0x1)
	char pad_6158[2];  // 0x180E(0x2)
	struct UAudioComponent* HarpoonRetractSound;  // 0x1810(0x8)
	struct UAudioComponent* HarpoonElectricityLoop (Harpoon);  // 0x1818(0x8)
	struct UAudioComponent* HarpoonElectricityLoop (Weapon);  // 0x1820(0x8)
	struct UAudioComponent* Harpoon Reel Sound (Hunter);  // 0x1828(0x8)
	struct UAudioComponent* Harpoon Reel Sound (Ghost);  // 0x1830(0x8)
	char pad_6200_1 : 7;  // 0x1838(0x1)
	bool Harpoon Break Overheat? : 1;  // 0x1838(0x1)
	char pad_6201_1 : 7;  // 0x1839(0x1)
	bool Harpoon Currently Retracting? : 1;  // 0x1839(0x1)
	char pad_6202_1 : 7;  // 0x183A(0x1)
	bool DoppleAttack? Local : 1;  // 0x183A(0x1)
	char pad_6203_1 : 7;  // 0x183B(0x1)
	bool DoppleAttack? : 1;  // 0x183B(0x1)
	char pad_6204_1 : 7;  // 0x183C(0x1)
	bool DoppleAttackCD? : 1;  // 0x183C(0x1)
	char pad_6205[3];  // 0x183D(0x3)
	struct TArray<struct AActor*> AlreadyConsideredForHit;  // 0x1840(0x10)
	char pad_6224_1 : 7;  // 0x1850(0x1)
	bool HitSaltCircle : 1;  // 0x1850(0x1)
	char pad_6225_1 : 7;  // 0x1851(0x1)
	bool Damage_Slow : 1;  // 0x1851(0x1)
	char pad_6226_1 : 7;  // 0x1852(0x1)
	bool Harpoon Break Overheat? Extra : 1;  // 0x1852(0x1)
	char pad_6227[1];  // 0x1853(0x1)
	float EscapePercentage;  // 0x1854(0x4)
	struct UInfection_EvacProgress_UI_C* InfectionEvacUI;  // 0x1858(0x8)
	char pad_6240_1 : 7;  // 0x1860(0x1)
	bool Infection_Evacuated? : 1;  // 0x1860(0x1)
	char pad_6241_1 : 7;  // 0x1861(0x1)
	bool SledgehammerEquipped : 1;  // 0x1861(0x1)
	char pad_6242_1 : 7;  // 0x1862(0x1)
	bool SledgehammerAttacking_TP : 1;  // 0x1862(0x1)
	char pad_6243_1 : 7;  // 0x1863(0x1)
	bool SledgehammerAttacking_FP : 1;  // 0x1863(0x1)
	char pad_6244_1 : 7;  // 0x1864(0x1)
	bool SledgehammerCooldown : 1;  // 0x1864(0x1)
	char HunterGadgets Previous Gadget Equipped;  // 0x1865(0x1)
	char pad_6246[2];  // 0x1866(0x2)
	struct AHarpoonRetractHandler_v02_C* RetractActor;  // 0x1868(0x8)
	char pad_6256_1 : 7;  // 0x1870(0x1)
	bool SprintHeld : 1;  // 0x1870(0x1)
	char pad_6257_1 : 7;  // 0x1871(0x1)
	bool SniperEquipped : 1;  // 0x1871(0x1)
	char pad_6258[2];  // 0x1872(0x2)
	int32_t SniperShotsRemaining;  // 0x1874(0x4)
	char pad_6264_1 : 7;  // 0x1878(0x1)
	bool SniperReloading_FP : 1;  // 0x1878(0x1)
	char pad_6265[3];  // 0x1879(0x3)
	int32_t SniperShotsMax;  // 0x187C(0x4)
	struct UStaticMeshComponent* NewVar_1;  // 0x1880(0x8)
	char pad_6280_1 : 7;  // 0x1888(0x1)
	bool GrapplingHookEquipped : 1;  // 0x1888(0x1)
	char pad_6281_1 : 7;  // 0x1889(0x1)
	bool GrapplingHookFired : 1;  // 0x1889(0x1)
	char pad_6282[6];  // 0x188A(0x6)
	struct AGrapplingHook_Projectile_C* LastGrapple;  // 0x1890(0x8)
	struct UGrapplingHook_UI_C* GrapplingHookUI;  // 0x1898(0x8)
	char pad_6304_1 : 7;  // 0x18A0(0x1)
	bool GrapplingHookCooldown : 1;  // 0x18A0(0x1)
	char pad_6305_1 : 7;  // 0x18A1(0x1)
	bool SniperFired : 1;  // 0x18A1(0x1)
	char pad_6306_1 : 7;  // 0x18A2(0x1)
	bool SniperZoomOn : 1;  // 0x18A2(0x1)
	char pad_6307[5];  // 0x18A3(0x5)
	struct USniperOverlay_UI_C* SniperOverlayUI;  // 0x18A8(0x8)
	struct UMaterialInstanceDynamic* FP_SniperHeatWaveMat;  // 0x18B0(0x8)
	char pad_6328_1 : 7;  // 0x18B8(0x1)
	bool Harpoon Not Yet Struck : 1;  // 0x18B8(0x1)
	char pad_6329_1 : 7;  // 0x18B9(0x1)
	bool GrapplingHookNotYetStruck : 1;  // 0x18B9(0x1)
	char pad_6330_1 : 7;  // 0x18BA(0x1)
	bool SniperBoltActioning_FP : 1;  // 0x18BA(0x1)
	char pad_6331[5];  // 0x18BB(0x5)
	struct TArray<struct ABP_SniperDart_C*> CachedDarts;  // 0x18C0(0x10)
	struct TArray<struct ABP_SniperDart_C*> CachedDarts_Prop;  // 0x18D0(0x10)
	char pad_6368_1 : 7;  // 0x18E0(0x1)
	bool AlternateFireHeld? : 1;  // 0x18E0(0x1)
	char pad_6369_1 : 7;  // 0x18E1(0x1)
	bool SniperFired_TPAnim : 1;  // 0x18E1(0x1)
	char pad_6370_1 : 7;  // 0x18E2(0x1)
	bool SniperReloading_TPAnim : 1;  // 0x18E2(0x1)
	char pad_6371_1 : 7;  // 0x18E3(0x1)
	bool SniperZoomed_TPAnim : 1;  // 0x18E3(0x1)
	char pad_6372[4];  // 0x18E4(0x4)
	struct FTimerHandle PerceptionLoopTimer;  // 0x18E8(0x8)
	char pad_6384_1 : 7;  // 0x18F0(0x1)
	bool SniperDrawing : 1;  // 0x18F0(0x1)
	char pad_6385_1 : 7;  // 0x18F1(0x1)
	bool SniperHolstering : 1;  // 0x18F1(0x1)
	char pad_6386[2];  // 0x18F2(0x2)
	float SniperSensMultiplier;  // 0x18F4(0x4)
	struct UCurveFloat* MeleeWalkSpeedCurve;  // 0x18F8(0x8)
	float LastPunchTime;  // 0x1900(0x4)
	int32_t TargetYaw;  // 0x1904(0x4)
	float DoppleGangerCachedMaxSpeed;  // 0x1908(0x4)
	char pad_6412[4];  // 0x190C(0x4)
	struct UGhostAttackAbility_UI_C* DoppelAttackUI;  // 0x1910(0x8)
	char pad_6424_1 : 7;  // 0x1918(0x1)
	bool Crouching? : 1;  // 0x1918(0x1)
	char pad_6425[3];  // 0x1919(0x3)
	float GrappleCoolDown;  // 0x191C(0x4)
	char pad_6432_1 : 7;  // 0x1920(0x1)
	bool GrapplingHookDrawing : 1;  // 0x1920(0x1)
	char pad_6433_1 : 7;  // 0x1921(0x1)
	bool GrapplingHookHolstering : 1;  // 0x1921(0x1)
	char pad_6434_1 : 7;  // 0x1922(0x1)
	bool Vacuuming? : 1;  // 0x1922(0x1)
	char pad_6435_1 : 7;  // 0x1923(0x1)
	bool PrimaryFireHeld : 1;  // 0x1923(0x1)
	char pad_6436[4];  // 0x1924(0x4)
	struct UAudioComponent* GrappleHookRechargeSound;  // 0x1928(0x8)
	struct TMap<char HunterGadgets, bool> ShouldUseNewFPSetupIndex;  // 0x1930(0x50)
	char pad_6528_1 : 7;  // 0x1980(0x1)
	bool NewFPSetupActive : 1;  // 0x1980(0x1)
	char pad_6529[7];  // 0x1981(0x7)
	struct USkeletalMeshComponent* ActiveWepGadgetFP;  // 0x1988(0x8)
	char HunterGadgets CurrentEquipment;  // 0x1990(0x1)
	char pad_6545_1 : 7;  // 0x1991(0x1)
	bool VacuumEquipped? : 1;  // 0x1991(0x1)
	char pad_6546[6];  // 0x1992(0x6)
	struct TMap<char HunterGadgets, bool> ShouldUseNewTPSetupIndex;  // 0x1998(0x50)
	char pad_6632_1 : 7;  // 0x19E8(0x1)
	bool NewTPSetupActive : 1;  // 0x19E8(0x1)
	char pad_6633[7];  // 0x19E9(0x7)
	struct FTransform HunterRezXform;  // 0x19F0(0x30)
	struct USkeletalMeshComponent* ActiveWepGadgetTP;  // 0x1A20(0x8)
	char pad_6696_1 : 7;  // 0x1A28(0x1)
	bool VacuumDrawing : 1;  // 0x1A28(0x1)
	char pad_6697_1 : 7;  // 0x1A29(0x1)
	bool VacuumHolstering : 1;  // 0x1A29(0x1)
	char pad_6698[6];  // 0x1A2A(0x6)
	struct UNiagaraComponent* Vacuum_Container_Effect;  // 0x1A30(0x8)
	int32_t SledgeHammerAttackVariation;  // 0x1A38(0x4)
	char pad_6716_1 : 7;  // 0x1A3C(0x1)
	bool Grappling Hook Fired TP : 1;  // 0x1A3C(0x1)
	char pad_6717_1 : 7;  // 0x1A3D(0x1)
	bool Grappling Hook Cooldown TP : 1;  // 0x1A3D(0x1)
	char pad_6718_1 : 7;  // 0x1A3E(0x1)
	bool SaltShotgunEquipped? : 1;  // 0x1A3E(0x1)
	char pad_6719[1];  // 0x1A3F(0x1)
	float ShotgunMaxRange;  // 0x1A40(0x4)
	int32_t ShotgunAmmoRemaining;  // 0x1A44(0x4)
	char pad_6728_1 : 7;  // 0x1A48(0x1)
	bool ShotgunReloading : 1;  // 0x1A48(0x1)
	char pad_6729_1 : 7;  // 0x1A49(0x1)
	bool Shotgun Fired TP : 1;  // 0x1A49(0x1)
	char pad_6730_1 : 7;  // 0x1A4A(0x1)
	bool STutorial_ReadyForGenerator : 1;  // 0x1A4A(0x1)
	char pad_6731_1 : 7;  // 0x1A4B(0x1)
	bool STutorial_ReadyForShards : 1;  // 0x1A4B(0x1)
	char pad_6732_1 : 7;  // 0x1A4C(0x1)
	bool STutorial_ReadyToSwitchToVacuum : 1;  // 0x1A4C(0x1)
	char pad_6733_1 : 7;  // 0x1A4D(0x1)
	bool STutorial_RespawnAsTutorial : 1;  // 0x1A4D(0x1)
	char pad_6734_1 : 7;  // 0x1A4E(0x1)
	bool Shotgun Reloading TP : 1;  // 0x1A4E(0x1)
	char pad_6735_1 : 7;  // 0x1A4F(0x1)
	bool Shotgun_FiredRecently : 1;  // 0x1A4F(0x1)
	char pad_6736_1 : 7;  // 0x1A50(0x1)
	bool Spectrophone Equipped? : 1;  // 0x1A50(0x1)
	char pad_6737[7];  // 0x1A51(0x7)
	struct UMaterialInstanceDynamic* SpecCan_TurbineGlow_Mtl_FP;  // 0x1A58(0x8)
	float SpectrophoneHits;  // 0x1A60(0x4)
	char pad_6756[4];  // 0x1A64(0x4)
	struct UAudioComponent* SpectrophoneSound;  // 0x1A68(0x8)
	float SpectrophoneHits_Repl;  // 0x1A70(0x4)
	char pad_6772_1 : 7;  // 0x1A74(0x1)
	bool SpectroHitGhost : 1;  // 0x1A74(0x1)
	char pad_6773_1 : 7;  // 0x1A75(0x1)
	bool OceanSlowed : 1;  // 0x1A75(0x1)
	char pad_6774[2];  // 0x1A76(0x2)
	struct UMaterialInstanceDynamic* SpectrophoneIndicatorMaterial;  // 0x1A78(0x8)
	struct TArray<float> SpectrophoneArray;  // 0x1A80(0x10)
	float SpectrophoneCloseness_Interpolated;  // 0x1A90(0x4)
	float SpectrophoneCloseness_Speed;  // 0x1A94(0x4)
	struct TArray<struct AActor*> SpectrophonedActors;  // 0x1A98(0x10)
	struct UNiagaraComponent* SpectroPhoneDistortionEffect;  // 0x1AA8(0x8)
	char pad_6832_1 : 7;  // 0x1AB0(0x1)
	bool DeathGripped : 1;  // 0x1AB0(0x1)
	char pad_6833[7];  // 0x1AB1(0x7)
	struct UYouGotShadowtrapped_UI_C* Shadowtrapped UI;  // 0x1AB8(0x8)
	struct FTimerHandle HealingAuraTimer;  // 0x1AC0(0x8)
	char pad_6856_1 : 7;  // 0x1AC8(0x1)
	bool Chilled : 1;  // 0x1AC8(0x1)
	char pad_6857_1 : 7;  // 0x1AC9(0x1)
	bool HarpoonHitGhostAnim : 1;  // 0x1AC9(0x1)
	char pad_6858_1 : 7;  // 0x1ACA(0x1)
	bool HarpoonHitNothingAnim : 1;  // 0x1ACA(0x1)
	char pad_6859_1 : 7;  // 0x1ACB(0x1)
	bool HarpoonHitGhostAnim_TP : 1;  // 0x1ACB(0x1)
	char pad_6860_1 : 7;  // 0x1ACC(0x1)
	bool HarpoonHitNothingAnim_TP : 1;  // 0x1ACC(0x1)
	char pad_6861_1 : 7;  // 0x1ACD(0x1)
	bool Harpoon Currently Retracting?_TP : 1;  // 0x1ACD(0x1)
	char pad_6862_1 : 7;  // 0x1ACE(0x1)
	bool DummyHunter : 1;  // 0x1ACE(0x1)
	char pad_6863[1];  // 0x1ACF(0x1)
	int32_t ShotgunAmmoMax;  // 0x1AD0(0x4)
	char pad_6868_1 : 7;  // 0x1AD4(0x1)
	bool Nailgun Equipped? : 1;  // 0x1AD4(0x1)
	char pad_6869_1 : 7;  // 0x1AD5(0x1)
	bool Tutorial_Don't Equip Primary : 1;  // 0x1AD5(0x1)
	char pad_6870_1 : 7;  // 0x1AD6(0x1)
	bool Tutorial_NoFireAtAll : 1;  // 0x1AD6(0x1)
	char pad_6871[1];  // 0x1AD7(0x1)
	float Hunter - Reload Speed Modifier;  // 0x1AD8(0x4)
	float Hunter - Change Equipment Speed Modifier;  // 0x1ADC(0x4)
	struct UNiagaraComponent* HealingAura_Target_VFX;  // 0x1AE0(0x8)
	int32_t Project X Max Heat Level;  // 0x1AE8(0x4)
	char pad_6892_1 : 7;  // 0x1AEC(0x1)
	bool Firing Nailgun? : 1;  // 0x1AEC(0x1)
	char pad_6893[3];  // 0x1AED(0x3)
	struct UUI_HealingAura_SreenGlow_C* UI_HealingAura_ScreenGlow;  // 0x1AF0(0x8)
	int32_t NailGunAmmo;  // 0x1AF8(0x4)
	char pad_6908_1 : 7;  // 0x1AFC(0x1)
	bool FP Reloading Nail Gun : 1;  // 0x1AFC(0x1)
	char pad_6909[3];  // 0x1AFD(0x3)
	int32_t NailGunMaxAmmo;  // 0x1B00(0x4)
	char pad_6916[4];  // 0x1B04(0x4)
	struct UNiagaraComponent* NailgunColdAirEffect;  // 0x1B08(0x8)
	struct UNiagaraComponent* NailgunMuzzleEffect;  // 0x1B10(0x8)
	char pad_6936_1 : 7;  // 0x1B18(0x1)
	bool Firing Nailgun? TP : 1;  // 0x1B18(0x1)
	char HunterGadgets HandleUIGadget;  // 0x1B19(0x1)
	char pad_6938[6];  // 0x1B1A(0x6)
	struct TArray<struct AActor*> SpectrophonedActors_Sensitive;  // 0x1B20(0x10)
	struct UNiagaraComponent* HealingAura_OwnerVFX;  // 0x1B30(0x8)
	char pad_6968_1 : 7;  // 0x1B38(0x1)
	bool Grenade_Equipping : 1;  // 0x1B38(0x1)
	char pad_6969_1 : 7;  // 0x1B39(0x1)
	bool C4 Equipped? : 1;  // 0x1B39(0x1)
	char pad_6970_1 : 7;  // 0x1B3A(0x1)
	bool Tutorial_NoWeaponUIs : 1;  // 0x1B3A(0x1)
	char pad_6971[5];  // 0x1B3B(0x5)
	struct TArray<struct AMGH_PlayerState_C*> Stored_VacuumedPlayerStates;  // 0x1B40(0x10)
	char pad_6992_1 : 7;  // 0x1B50(0x1)
	bool C4_BombInHands : 1;  // 0x1B50(0x1)
	char pad_6993_1 : 7;  // 0x1B51(0x1)
	bool PickupBomb : 1;  // 0x1B51(0x1)
	char pad_6994_1 : 7;  // 0x1B52(0x1)
	bool PlantBomb : 1;  // 0x1B52(0x1)
	char pad_6995_1 : 7;  // 0x1B53(0x1)
	bool DetonateBomb : 1;  // 0x1B53(0x1)
	char pad_6996_1 : 7;  // 0x1B54(0x1)
	bool Defib Rub Remote : 1;  // 0x1B54(0x1)
	char pad_6997_1 : 7;  // 0x1B55(0x1)
	bool Defib Zap Remote : 1;  // 0x1B55(0x1)
	char pad_6998_1 : 7;  // 0x1B56(0x1)
	bool HeldDownProjectX? : 1;  // 0x1B56(0x1)
	char pad_6999[1];  // 0x1B57(0x1)
	int32_t C4_AmmoRemaining-;  // 0x1B58(0x4)
	int32_t C4_AmmoMax-;  // 0x1B5C(0x4)
	float GrenadesAmmoMax;  // 0x1B60(0x4)
	char pad_7012_1 : 7;  // 0x1B64(0x1)
	bool C4_PlantingBomb : 1;  // 0x1B64(0x1)
	char pad_7013_1 : 7;  // 0x1B65(0x1)
	bool C4_ReadyToDetonate : 1;  // 0x1B65(0x1)
	char pad_7014_1 : 7;  // 0x1B66(0x1)
	bool C4BombInHandsTP : 1;  // 0x1B66(0x1)
	char pad_7015[1];  // 0x1B67(0x1)
	struct UBP_MGH_Instance_C* InputGameInstance;  // 0x1B68(0x8)
	int32_t Grenades_AmmoCount-;  // 0x1B70(0x4)
	int32_t Grenades_AmmoMax-;  // 0x1B74(0x4)
	char pad_7032_1 : 7;  // 0x1B78(0x1)
	bool C4_Equipping : 1;  // 0x1B78(0x1)
	char pad_7033[3];  // 0x1B79(0x3)
	int32_t TrapCurrentAmmo-;  // 0x1B7C(0x4)
	int32_t TrapMaxAmmo-;  // 0x1B80(0x4)
	float ProjectXOverheatTime;  // 0x1B84(0x4)
	char pad_7048_1 : 7;  // 0x1B88(0x1)
	bool STutorial_ReadyForChair : 1;  // 0x1B88(0x1)
	char pad_7049_1 : 7;  // 0x1B89(0x1)
	bool Revived : 1;  // 0x1B89(0x1)
	char pad_7050[2];  // 0x1B8A(0x2)
	float Slow Walk Divider;  // 0x1B8C(0x4)
	int32_t MiasmaSlowCount;  // 0x1B90(0x4)
	char pad_7060[4];  // 0x1B94(0x4)
	struct ABP_HunterHasYourShards_C* HasYourShards;  // 0x1B98(0x8)
	struct TArray<struct UPrimitiveComponent*> WeaponGadgetMeshes;  // 0x1BA0(0x10)
	struct TArray<struct AActor*> MeleeStruckActors;  // 0x1BB0(0x10)
	char pad_7104_1 : 7;  // 0x1BC0(0x1)
	bool Shadowtrapped_Replicated : 1;  // 0x1BC0(0x1)
	char pad_7105_1 : 7;  // 0x1BC1(0x1)
	bool EmoteIsActive : 1;  // 0x1BC1(0x1)
	char pad_7106_1 : 7;  // 0x1BC2(0x1)
	bool EmoteInterruptBlend : 1;  // 0x1BC2(0x1)
	char Hunter_Emotes EquipedEmote;  // 0x1BC3(0x1)
	char pad_7108[4];  // 0x1BC4(0x4)
	struct TArray<struct AActor*> AllSpawnedEmoteProps;  // 0x1BC8(0x10)
	char pad_7128_1 : 7;  // 0x1BD8(0x1)
	bool SpectralCannonCD? : 1;  // 0x1BD8(0x1)
	char pad_7129_1 : 7;  // 0x1BD9(0x1)
	bool RiotShieldEquipped : 1;  // 0x1BD9(0x1)
	char pad_7130_1 : 7;  // 0x1BDA(0x1)
	bool MedicKitEquipped : 1;  // 0x1BDA(0x1)
	char pad_7131[1];  // 0x1BDB(0x1)
	int32_t RiotShieldHPMax;  // 0x1BDC(0x4)
	float RiotShieldHPCurrent_Float;  // 0x1BE0(0x4)
	char pad_7140_1 : 7;  // 0x1BE4(0x1)
	bool DEBUG_KeepShieldUp? : 1;  // 0x1BE4(0x1)
	char pad_7141_1 : 7;  // 0x1BE5(0x1)
	bool RiotShieldUpOrDown : 1;  // 0x1BE5(0x1)
	char pad_7142[2];  // 0x1BE6(0x2)
	float RiotShield_HeldSpeedDivider;  // 0x1BE8(0x4)
	char pad_7148_1 : 7;  // 0x1BEC(0x1)
	bool AddedEOSVoiceNotify : 1;  // 0x1BEC(0x1)
	char pad_7149_1 : 7;  // 0x1BED(0x1)
	bool Shield Overheated? : 1;  // 0x1BED(0x1)
	char pad_7150[2];  // 0x1BEE(0x2)
	struct UShieldHealthbar_FirstPerson_UI_C* ShieldHealthbarUI;  // 0x1BF0(0x8)
	char pad_7160_1 : 7;  // 0x1BF8(0x1)
	bool Shield Held Up? Replicated : 1;  // 0x1BF8(0x1)
	char pad_7161_1 : 7;  // 0x1BF9(0x1)
	bool FP Reloading Spectral Cannon : 1;  // 0x1BF9(0x1)
	char pad_7162[2];  // 0x1BFA(0x2)
	int32_t MedicKit_AmmoRemaining;  // 0x1BFC(0x4)
	int32_t MedicKit_AmmoMax;  // 0x1C00(0x4)
	char pad_7172_1 : 7;  // 0x1C04(0x1)
	bool MedicKitCooldown : 1;  // 0x1C04(0x1)
	char pad_7173_1 : 7;  // 0x1C05(0x1)
	bool UsingBandage : 1;  // 0x1C05(0x1)
	char pad_7174[2];  // 0x1C06(0x2)
	struct UHunterProgressBar_UI_C* BandagingUI;  // 0x1C08(0x8)
	char pad_7184_1 : 7;  // 0x1C10(0x1)
	bool CancelingBandage : 1;  // 0x1C10(0x1)
	char pad_7185[7];  // 0x1C11(0x7)
	struct TArray<struct ABP_C4Actor_C*> MyC4Actors;  // 0x1C18(0x10)
	char pad_7208_1 : 7;  // 0x1C28(0x1)
	bool MedicKitDeployedOnGround : 1;  // 0x1C28(0x1)
	char pad_7209_1 : 7;  // 0x1C29(0x1)
	bool LookingAtMyMedkit : 1;  // 0x1C29(0x1)
	char pad_7210[2];  // 0x1C2A(0x2)
	int32_t MedicKit_ChargesRemaining;  // 0x1C2C(0x4)
	int32_t MedicKit_ChargesMax;  // 0x1C30(0x4)
	char pad_7220_1 : 7;  // 0x1C34(0x1)
	bool DirectMedkit - LookingAtHurtHunter : 1;  // 0x1C34(0x1)
	char pad_7221_1 : 7;  // 0x1C35(0x1)
	bool DirectMedkit - HealingHurtHunter : 1;  // 0x1C35(0x1)
	char pad_7222[2];  // 0x1C36(0x2)
	struct ABP_Hunter_C* DirectMedkit - HunterLookedAt;  // 0x1C38(0x8)
	struct ABP_Hunter_C* MedicKitHunterToHeal;  // 0x1C40(0x8)
	char pad_7240_1 : 7;  // 0x1C48(0x1)
	bool BeingHealed? : 1;  // 0x1C48(0x1)
	char pad_7241_1 : 7;  // 0x1C49(0x1)
	bool SpectralCannon_Equipping : 1;  // 0x1C49(0x1)
	char pad_7242[6];  // 0x1C4A(0x6)
	struct UMaterialInstanceDynamic* FP_RiotShieldMaterial;  // 0x1C50(0x8)
	struct UMaterialInstanceDynamic* TP_RiotShieldMaterial;  // 0x1C58(0x8)
	char pad_7264_1 : 7;  // 0x1C60(0x1)
	bool C4_ClosePhone : 1;  // 0x1C60(0x1)
	char pad_7265_1 : 7;  // 0x1C61(0x1)
	bool StartWithGadget? : 1;  // 0x1C61(0x1)
	char HunterGadgets CurrentlyEquippedGadget;  // 0x1C62(0x1)
	char pad_7267_1 : 7;  // 0x1C63(0x1)
	bool Flamethrower Equipped : 1;  // 0x1C63(0x1)
	char pad_7268_1 : 7;  // 0x1C64(0x1)
	bool FlameThrowerReloadFP : 1;  // 0x1C64(0x1)
	char pad_7269[3];  // 0x1C65(0x3)
	struct TMap<struct ABP_EctoplasmTrail_C*, float> EctoplasmTrailsInRadius;  // 0x1C68(0x50)
	struct ABP_LiquidXMotion_FlameThrower_C* FlameThrowerLiquid_FP;  // 0x1CB8(0x8)
	struct ABP_LiquidXMotion_FlameThrower_C* FlameThrowerLiquid_TP;  // 0x1CC0(0x8)
	struct UAudioComponent* FlamethrowerSound;  // 0x1CC8(0x8)
	int32_t FlamethrowerAmmo;  // 0x1CD0(0x4)
	int32_t FlamethrowerAmmoMax;  // 0x1CD4(0x4)
	char pad_7384_1 : 7;  // 0x1CD8(0x1)
	bool FP_FlamethrowerFlameActive : 1;  // 0x1CD8(0x1)
	char pad_7385_1 : 7;  // 0x1CD9(0x1)
	bool FiringFlamethrower? : 1;  // 0x1CD9(0x1)
	char pad_7386_1 : 7;  // 0x1CDA(0x1)
	bool InSaltWater : 1;  // 0x1CDA(0x1)
	char pad_7387[5];  // 0x1CDB(0x5)
	struct UNiagaraComponent* FlameThrowerVFX;  // 0x1CE0(0x8)
	char pad_7400_1 : 7;  // 0x1CE8(0x1)
	bool Doppelganger_SpawnedRecently : 1;  // 0x1CE8(0x1)
	char pad_7401_1 : 7;  // 0x1CE9(0x1)
	bool Doppelganger_HasAttacked : 1;  // 0x1CE9(0x1)
	char pad_7402[2];  // 0x1CEA(0x2)
	float Possess Range;  // 0x1CEC(0x4)
	struct ALvlProp_C* InteractedLvlprop;  // 0x1CF0(0x8)
	char pad_7416_1 : 7;  // 0x1CF8(0x1)
	bool MedKit_RefreshingBox : 1;  // 0x1CF8(0x1)
	char pad_7417_1 : 7;  // 0x1CF9(0x1)
	bool FiringFlamethrower?_TP : 1;  // 0x1CF9(0x1)
	char pad_7418[2];  // 0x1CFA(0x2)
	struct FVector DamageTraceTarget;  // 0x1CFC(0xC)
	char pad_7432_1 : 7;  // 0x1D08(0x1)
	bool MedKit_ThrowingBox : 1;  // 0x1D08(0x1)
	char pad_7433[3];  // 0x1D09(0x3)
	float SaltShotgunReloadMultiplier;  // 0x1D0C(0x4)
	float EquipmentChangeTimeRemaining;  // 0x1D10(0x4)
	struct FVector StartLocation;  // 0x1D14(0xC)
	float Duration;  // 0x1D20(0x4)
	float CachedGravity Scale;  // 0x1D24(0x4)
	float HighestLedgeHeight;  // 0x1D28(0x4)
	struct FHitResult HitLedge;  // 0x1D2C(0x88)
	char pad_7604_1 : 7;  // 0x1DB4(0x1)
	bool DoneWithHunterTips : 1;  // 0x1DB4(0x1)
	char pad_7605_1 : 7;  // 0x1DB5(0x1)
	bool Should Use OldGrapplingLaunch System : 1;  // 0x1DB5(0x1)
	char pad_7606[2];  // 0x1DB6(0x2)
	struct FHitResult GrapplePlacement;  // 0x1DB8(0x88)
	struct UAudioComponent* FlamethrowerRiser;  // 0x1E40(0x8)
	struct ABP_LiquidXMotion_SpectralCannon_C* SpectralCannonLiquid_FP;  // 0x1E48(0x8)
	struct ABP_LiquidXMotion_SpectralCannon_C* SpectralCannonLiquid_TP;  // 0x1E50(0x8)
	struct UMaterialInstanceDynamic* TP_SniperDynamicMaterial;  // 0x1E58(0x8)
	struct UMaterialInstanceDynamic* FP_SniperDynamicMaterial;  // 0x1E60(0x8)
	char pad_7784_1 : 7;  // 0x1E68(0x1)
	bool IsVaulting : 1;  // 0x1E68(0x1)
	char pad_7785_1 : 7;  // 0x1E69(0x1)
	bool JumpHeld : 1;  // 0x1E69(0x1)
	char pad_7786[2];  // 0x1E6A(0x2)
	float CachedVaultVelocity;  // 0x1E6C(0x4)
	char pad_7792_1 : 7;  // 0x1E70(0x1)
	bool VaultCoolDown : 1;  // 0x1E70(0x1)
	char pad_7793_1 : 7;  // 0x1E71(0x1)
	bool IsVaultingHigh : 1;  // 0x1E71(0x1)
	char pad_7794[2];  // 0x1E72(0x2)
	float LastVaultTime;  // 0x1E74(0x4)
	struct FVector VaultLerpPositionStart;  // 0x1E78(0xC)
	struct FVector VaultLerpPositionEnd;  // 0x1E84(0xC)
	char pad_7824_1 : 7;  // 0x1E90(0x1)
	bool GhostsmasherEquipping : 1;  // 0x1E90(0x1)
	char pad_7825[7];  // 0x1E91(0x7)
	struct ABP_Hunter_C* CurrentlyRezzingHunter;  // 0x1E98(0x8)
	struct FMulticastInlineDelegate On Spectral Cannon Fired;  // 0x1EA0(0x10)
	struct FMulticastInlineDelegate On Salt Shotgun Fired;  // 0x1EB0(0x10)
	struct FMulticastInlineDelegate On Nailgun Fired;  // 0x1EC0(0x10)
	struct FMulticastInlineDelegate On Sniper Fired;  // 0x1ED0(0x10)
	struct FMulticastInlineDelegate On Harpoon Fired;  // 0x1EE0(0x10)
	struct FMulticastInlineDelegate On Sledgehammer Fired;  // 0x1EF0(0x10)
	struct FMulticastInlineDelegate On Shield Bash Fired;  // 0x1F00(0x10)
	struct FMulticastInlineDelegate On Grenade Thrown;  // 0x1F10(0x10)
	struct FMulticastInlineDelegate On Ghostsmasher Fired;  // 0x1F20(0x10)
	struct FMulticastInlineDelegate On Trap Thrown;  // 0x1F30(0x10)
	struct FMulticastInlineDelegate On C4 Thrown;  // 0x1F40(0x10)
	struct FMulticastInlineDelegate On C4 Detonated;  // 0x1F50(0x10)
	struct FMulticastInlineDelegate On Riot Shield Fired;  // 0x1F60(0x10)
	struct FMulticastInlineDelegate On Medkit Thrown;  // 0x1F70(0x10)
	struct FMulticastInlineDelegate On Flamethrower Fired;  // 0x1F80(0x10)
	ABP_GhostShards_C* Yep;  // 0x1F90(0x8)
	int32_t TrailerWeaponSwitching_CurrentSwitch;  // 0x1F98(0x4)
	float TrailerWeaponSwitching_TimeBetweenSwitches;  // 0x1F9C(0x4)
	char pad_8096_1 : 7;  // 0x1FA0(0x1)
	bool TrailerWeaponSwitching_SkipTPAnim : 1;  // 0x1FA0(0x1)
	char pad_8097_1 : 7;  // 0x1FA1(0x1)
	bool Ghostsmasher 2 Equipped : 1;  // 0x1FA1(0x1)
	char pad_8098_1 : 7;  // 0x1FA2(0x1)
	bool GhostsmasherShieldUp : 1;  // 0x1FA2(0x1)
	char pad_8099[5];  // 0x1FA3(0x5)
	struct FMulticastInlineDelegate On ProjectX Fired;  // 0x1FA8(0x10)
	struct FMulticastInlineDelegate On Grappling Hook Fired;  // 0x1FB8(0x10)
	struct FRotator VanRideLastRotation;  // 0x1FC8(0xC)
	float ProjectXOverheatTimeLocal;  // 0x1FD4(0x4)
	float Hunter Gadget Count Multiplier;  // 0x1FD8(0x4)
	float GamepadSensitivity;  // 0x1FDC(0x4)
	float SniperGamepadSensMultiplier;  // 0x1FE0(0x4)
	char pad_8164_1 : 7;  // 0x1FE4(0x1)
	bool Tutorial_DisableGeneratorInteractWidget : 1;  // 0x1FE4(0x1)
	char pad_8165_1 : 7;  // 0x1FE5(0x1)
	bool CurrentlyInterpScoping : 1;  // 0x1FE5(0x1)
	char pad_8166[2];  // 0x1FE6(0x2)
	struct TArray<struct AProp_C*> Hit Ghosts;  // 0x1FE8(0x10)
	int32_t Hit Ghost Index;  // 0x1FF8(0x4)
	char pad_8188[4];  // 0x1FFC(0x4)
	struct TArray<struct AProp_C*> Hit Ghosts Hitmarker;  // 0x2000(0x10)
	int32_t Hit Ghost Index Hitmarker;  // 0x2010(0x4)
	char pad_8212_1 : 7;  // 0x2014(0x1)
	bool EnableSledgeHammerCharge : 1;  // 0x2014(0x1)
	char pad_8213_1 : 7;  // 0x2015(0x1)
	bool SledgeHammerCharging : 1;  // 0x2015(0x1)
	char pad_8214_1 : 7;  // 0x2016(0x1)
	bool SledgeHammerMinChargeReached : 1;  // 0x2016(0x1)
	char pad_8215[1];  // 0x2017(0x1)
	float SledgeHammerChargeStartTime;  // 0x2018(0x4)
	char pad_8220_1 : 7;  // 0x201C(0x1)
	bool Ghostsmasher2Equipping : 1;  // 0x201C(0x1)
	char pad_8221[3];  // 0x201D(0x3)
	int32_t HitGhostCounterVFX;  // 0x2020(0x4)
	char pad_8228[4];  // 0x2024(0x4)
	struct UMaterialInstanceDynamic* FP_Smasher_Material;  // 0x2028(0x8)
	struct UMaterialInstanceDynamic* TP_Smasher_Material;  // 0x2030(0x8)
	struct UMaterialInstanceDynamic* FP_Buckler_Material;  // 0x2038(0x8)
	struct UMaterialInstanceDynamic* TP_Buckler_Material;  // 0x2040(0x8)
	char pad_8264_1 : 7;  // 0x2048(0x1)
	bool SledgeHammer_WorldStaticHit : 1;  // 0x2048(0x1)
	char pad_8265[7];  // 0x2049(0x7)
	struct UAudioComponent* SledgeChargeupSound;  // 0x2050(0x8)
	char pad_8280_1 : 7;  // 0x2058(0x1)
	bool RecentlyRadarHit : 1;  // 0x2058(0x1)
	char pad_8281_1 : 7;  // 0x2059(0x1)
	bool RecentlySpectrophoneHit : 1;  // 0x2059(0x1)
	char pad_8282_1 : 7;  // 0x205A(0x1)
	bool RecentlyPathfinderUsed : 1;  // 0x205A(0x1)
	char pad_8283[1];  // 0x205B(0x1)
	float RadiationOfNearestGhost;  // 0x205C(0x4)
	char pad_8288_1 : 7;  // 0x2060(0x1)
	bool IsOnMovingGround : 1;  // 0x2060(0x1)
	char pad_8289_1 : 7;  // 0x2061(0x1)
	bool IsHoldingMovementRepl : 1;  // 0x2061(0x1)
	char pad_8290_1 : 7;  // 0x2062(0x1)
	bool IsHoldingMovementLocal : 1;  // 0x2062(0x1)
	char pad_8291[1];  // 0x2063(0x1)
	float ForwardValue;  // 0x2064(0x4)
	float BackwardValue;  // 0x2068(0x4)
	float RightValue;  // 0x206C(0x4)
	float LeftValue;  // 0x2070(0x4)
	int32_t LimitedAmmoInBackpack_Primary;  // 0x2074(0x4)
	int32_t LimitedAmmoInBackpack_Secondary;  // 0x2078(0x4)
	char pad_8316_1 : 7;  // 0x207C(0x1)
	bool UseLimitedAmmo : 1;  // 0x207C(0x1)
	char pad_8317_1 : 7;  // 0x207D(0x1)
	bool TrackingGadgetWeaker : 1;  // 0x207D(0x1)
	char pad_8318_1 : 7;  // 0x207E(0x1)
	bool CamCorder Equipped : 1;  // 0x207E(0x1)
	char pad_8319[1];  // 0x207F(0x1)
	struct UMaterialInstanceDynamic* FullScreenEffectMaterial;  // 0x2080(0x8)
	char pad_8328[8];  // 0x2088(0x8)
	struct FPostProcessSettings Post Processing Settings;  // 0x2090(0x560)
	struct AActor* GenericInteractObject;  // 0x25F0(0x8)
	int32_t Camcorder Ammo Current;  // 0x25F8(0x4)
	int32_t Camcorder Ammo Max;  // 0x25FC(0x4)
	char pad_9728_1 : 7;  // 0x2600(0x1)
	bool CamcorderBusy : 1;  // 0x2600(0x1)
	char pad_9729_1 : 7;  // 0x2601(0x1)
	bool RecentlyRamHit : 1;  // 0x2601(0x1)
	char pad_9730_1 : 7;  // 0x2602(0x1)
	bool HarpoonTickEnabled : 1;  // 0x2602(0x1)
	char pad_9731_1 : 7;  // 0x2603(0x1)
	bool DisableSmartInteract : 1;  // 0x2603(0x1)
	char pad_9732[4];  // 0x2604(0x4)
	struct ABP_Gadget_C* CurrentGadget;  // 0x2608(0x8)
	struct ABP_Gadget_C* PrimaryGadget;  // 0x2610(0x8)
	struct ABP_Gadget_C* SecondaryGadget;  // 0x2618(0x8)
	struct ABP_Trap_C* SpawnedTrap;  // 0x2620(0x8)
	char pad_9768_1 : 7;  // 0x2628(0x1)
	bool CamcorderIsUnarmed : 1;  // 0x2628(0x1)
	char pad_9769_1 : 7;  // 0x2629(0x1)
	bool Replicated_CamcorderHandsEmpty : 1;  // 0x2629(0x1)
	char Hunter_Emotes EmoteToPlay;  // 0x262A(0x1)
	char pad_9771_1 : 7;  // 0x262B(0x1)
	bool Incapacitated : 1;  // 0x262B(0x1)
	char pad_9772[4];  // 0x262C(0x4)
	struct AActor* Prop That Grabbed You;  // 0x2630(0x8)
	struct FTimerHandle CheckPropGrabbedStillValidLoop;  // 0x2638(0x8)
	struct UIncapacitated_UI_C* IncapacitatedUI;  // 0x2640(0x8)
	char pad_9800_1 : 7;  // 0x2648(0x1)
	bool ForceThirdPersonWeaponModels : 1;  // 0x2648(0x1)
	char pad_9801_1 : 7;  // 0x2649(0x1)
	bool InPhotoMode : 1;  // 0x2649(0x1)
	char EHatTypes CachedEquippedHat;  // 0x264A(0x1)
	char pad_9803[5];  // 0x264B(0x5)
	struct UStaticMeshComponent* HatMesh;  // 0x2650(0x8)

	void CheckIncapacitated_Int(bool& Incapacitated); // Function BP_Hunter.BP_Hunter_C.CheckIncapacitated_Int
	void GetMeshRootPosition_Int(struct FVector& MeshRootPosition); // Function BP_Hunter.BP_Hunter_C.GetMeshRootPosition_Int
	void GetSaltTimeRemaining_Int(float& Remaining); // Function BP_Hunter.BP_Hunter_C.GetSaltTimeRemaining_Int
	void GetGlobalInTutorialMode_Int(bool& GlobalInTutorialMode); // Function BP_Hunter.BP_Hunter_C.GetGlobalInTutorialMode_Int
	void IsCrouched_Int(bool& IsCrouched); // Function BP_Hunter.BP_Hunter_C.IsCrouched_Int
	void IsLocallyControlledHunter_Int(bool& LocallyControlledHunter, bool& LocallyControlledBot); // Function BP_Hunter.BP_Hunter_C.IsLocallyControlledHunter_Int
	void GetForceMaximumGeiger_Int(bool& ForceMaximumGeiger); // Function BP_Hunter.BP_Hunter_C.GetForceMaximumGeiger_Int
	void IsSprinting_Int(bool& Sprinting?); // Function BP_Hunter.BP_Hunter_C.IsSprinting_Int
	void GetTrapCurrentAmmo_Int(int32_t& TrapCurrentAmmo); // Function BP_Hunter.BP_Hunter_C.GetTrapCurrentAmmo_Int
	void GetCharacterMovement_Int(struct UCharacterMovementComponent*& CharacterMovement); // Function BP_Hunter.BP_Hunter_C.GetCharacterMovement_Int
	void IsADoppelGanger_Int(bool& Is a Doppelganger?); // Function BP_Hunter.BP_Hunter_C.IsADoppelGanger_Int
	void IsDead_Int(bool& Died?); // Function BP_Hunter.BP_Hunter_C.IsDead_Int
	void GetRiotShieldHPMax(float& HP, int32_t& Max); // Function BP_Hunter.BP_Hunter_C.GetRiotShieldHPMax
	void GetOverlappingDeadHunter_Int(struct AActor*& OverlappedHunter, bool& OverlappingHunterRes); // Function BP_Hunter.BP_Hunter_C.GetOverlappingDeadHunter_Int
	void GetHunterPlayerStateStored_Int(struct APlayerState*& PlayerState); // Function BP_Hunter.BP_Hunter_C.GetHunterPlayerStateStored_Int
	void GetDied_Int(bool& Died); // Function BP_Hunter.BP_Hunter_C.GetDied_Int
	void NeedsArmor(bool& Armor); // Function BP_Hunter.BP_Hunter_C.NeedsArmor
	void GetArmorData(float& Armor, float& MaxArmor); // Function BP_Hunter.BP_Hunter_C.GetArmorData
	void GetHealthData(float& Health, float& Max Health); // Function BP_Hunter.BP_Hunter_C.GetHealthData
	void GetFireSpeed(float& FireSpeed); // Function BP_Hunter.BP_Hunter_C.GetFireSpeed
	void GetNozzleComponent(struct USceneComponent*& SceneComponent); // Function BP_Hunter.BP_Hunter_C.GetNozzleComponent
	void ConfigureAttachment(struct AActor*& Parent); // Function BP_Hunter.BP_Hunter_C.ConfigureAttachment
	void GetArrow(struct UArrowComponent*& CurrentArrow, struct UPrimitiveComponent*& CurrentOverlap); // Function BP_Hunter.BP_Hunter_C.GetArrow
	void NeedBlockPing?(bool& bLock); // Function BP_Hunter.BP_Hunter_C.NeedBlockPing?
	void SetSkin(); // Function BP_Hunter.BP_Hunter_C.SetSkin
	void HandleHatEquipped(bool Render Hunter); // Function BP_Hunter.BP_Hunter_C.HandleHatEquipped
	void Ai_SetPitchCheckInFront(struct AActor* Target, bool Skip "Am I In Front" Check, bool& OK to Fire); // Function BP_Hunter.BP_Hunter_C.Ai_SetPitchCheckInFront
	void CreateGadgetActor(char HunterGadgets GadgetToCreate, struct ABP_Gadget_C*& GadgetActor); // Function BP_Hunter.BP_Hunter_C.CreateGadgetActor
	void OutOfAmmoMessage(); // Function BP_Hunter.BP_Hunter_C.OutOfAmmoMessage
	void ErrorMessage(struct FText Text); // Function BP_Hunter.BP_Hunter_C.ErrorMessage
	void Limited Ammo Get Backpack Remaining(bool& OK, int32_t& Remaining); // Function BP_Hunter.BP_Hunter_C.Limited Ammo Get Backpack Remaining
	void ReduceLimitedAmmoBy(int32_t Reduce); // Function BP_Hunter.BP_Hunter_C.ReduceLimitedAmmoBy
	void LimitedAmmoReloadAttempt(char HunterGadgets Gadget, bool& ReloadSuccess, int32_t& AmmoToSet); // Function BP_Hunter.BP_Hunter_C.LimitedAmmoReloadAttempt
	void GetHunterGadgetLimitedMaxAmmo(char HunterGadgets Gadget, int32_t& MaxAmmo); // Function BP_Hunter.BP_Hunter_C.GetHunterGadgetLimitedMaxAmmo
	void ErrorMessage_Time(struct FText Text, float TimeOnScreen); // Function BP_Hunter.BP_Hunter_C.ErrorMessage_Time
	void ControllerFollowRotatingGround(float Turn Rate); // Function BP_Hunter.BP_Hunter_C.ControllerFollowRotatingGround
	void SledgeHammerHitTrace(bool TraceOnlyWorldStatic, struct TArray<struct FHitResult>& OutHits); // Function BP_Hunter.BP_Hunter_C.SledgeHammerHitTrace
	void SledgeHammerInterruptCleanUp(); // Function BP_Hunter.BP_Hunter_C.SledgeHammerInterruptCleanUp
	float SledgeHammerCalculateChargeDamageMult(); // Function BP_Hunter.BP_Hunter_C.SledgeHammerCalculateChargeDamageMult
	void GetChainLightningSegmentDelay(float& Delay); // Function BP_Hunter.BP_Hunter_C.GetChainLightningSegmentDelay
	void TestVisualizeChainLightning(struct AProp_C* Start Ghost, struct TArray<struct AProp_C*>& Chained Ghosts); // Function BP_Hunter.BP_Hunter_C.TestVisualizeChainLightning
	void Chain Lightning Damage Delay Calc(int32_t Count, struct AProp_C* HitProp, int32_t& Damage, char HitmarkerType& HitmarkerType); // Function BP_Hunter.BP_Hunter_C.Chain Lightning Damage Delay Calc
	void GetChainLightningProps(struct AProp_C* Exclude, struct TArray<struct AProp_C*>& Hit Ghosts (In Order)); // Function BP_Hunter.BP_Hunter_C.GetChainLightningProps
	void GetCommonReloadTexts(struct FText& AlreadyReloading, struct FText& AmmoFull, struct FText& Busy); // Function BP_Hunter.BP_Hunter_C.GetCommonReloadTexts
	void SetupFPSkin(struct USkeletalMesh* Skin Mesh); // Function BP_Hunter.BP_Hunter_C.SetupFPSkin
	void CanRedGhostSeeMe?(struct AProp_C* Ghost To Check, bool& CanSeeMe); // Function BP_Hunter.BP_Hunter_C.CanRedGhostSeeMe?
	void ProjectPointToNavigation(struct FVector LocationStart, bool& Found, struct FVector& Location); // Function BP_Hunter.BP_Hunter_C.ProjectPointToNavigation
	void ShouldAttackDoppelganger?(bool& Attack); // Function BP_Hunter.BP_Hunter_C.ShouldAttackDoppelganger?
	void GetAllNearbyEctoplasmTrails(float Radius Cutoff, float Freshness Cutoff, struct TMap<struct ABP_EctoplasmTrail_C*, float>& Distance Map); // Function BP_Hunter.BP_Hunter_C.GetAllNearbyEctoplasmTrails
	void MedKit_FP_UpdateBandages(bool HideExtaBandage, bool ForceFullBox); // Function BP_Hunter.BP_Hunter_C.MedKit_FP_UpdateBandages
	void isHunterHealthFull?(struct ABP_Hunter_C* BP Hunter, bool& FULL); // Function BP_Hunter.BP_Hunter_C.isHunterHealthFull?
	void CheckAllC4Valid(); // Function BP_Hunter.BP_Hunter_C.CheckAllC4Valid
	void SetHunterHealth(float NewParam); // Function BP_Hunter.BP_Hunter_C.SetHunterHealth
	void IsHealthAlreadyFull?(bool& FULL); // Function BP_Hunter.BP_Hunter_C.IsHealthAlreadyFull?
	void SetSceneComponentVisibility(struct USceneComponent* SceneComponent, bool Visibility); // Function BP_Hunter.BP_Hunter_C.SetSceneComponentVisibility
	void SetMeshesVisibility(struct TArray<struct USkeletalMeshComponent*>& Meshes, bool Visible); // Function BP_Hunter.BP_Hunter_C.SetMeshesVisibility
	void HandleOffset(struct USkeletalMeshComponent* SkelMesh); // Function BP_Hunter.BP_Hunter_C.HandleOffset
	void Down(bool Bring Up, bool  TP(false)); // Function BP_Hunter.BP_Hunter_C.Down
	void DeSpawnEmotePropAttached(); // Function BP_Hunter.BP_Hunter_C.DeSpawnEmotePropAttached
	void SpawnEmotePropAttached(AActor* Prop Class, struct FName Socket Name, struct FTransform Offsets); // Function BP_Hunter.BP_Hunter_C.SpawnEmotePropAttached
	void PopulateAllMyMeshes(); // Function BP_Hunter.BP_Hunter_C.PopulateAllMyMeshes
	void Hide Gadget(char HunterGadgets HunterGadgetEnum, bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.Hide Gadget
	void EndEmoteMode(); // Function BP_Hunter.BP_Hunter_C.EndEmoteMode
	void InitiateEmoteMode(bool PhotoMode); // Function BP_Hunter.BP_Hunter_C.InitiateEmoteMode
	void Using Prop Health V2?(bool& v2); // Function BP_Hunter.BP_Hunter_C.Using Prop Health V2?
	void CalculateProjectXHitscan(bool& Hit?, struct FRotator& Rotation); // Function BP_Hunter.BP_Hunter_C.CalculateProjectXHitscan
	void DoesSkinNeedExtraSteps?(int32_t SkinID, bool& NeedsSteps); // Function BP_Hunter.BP_Hunter_C.DoesSkinNeedExtraSteps?
	void Get Optimal Revive Position(struct ACharacter* Dead Hunter, bool& Is Spot Accaeptable?, struct FVector& SpawnLocation, struct FRotator& SpawnRotation, bool& GetUpFromBack); // Function BP_Hunter.BP_Hunter_C.Get Optimal Revive Position
	void SetClothesVisible(); // Function BP_Hunter.BP_Hunter_C.SetClothesVisible
	void ChangeComponentTickSettings(struct USkeletalMeshComponent* InputPin, bool Should tick); // Function BP_Hunter.BP_Hunter_C.ChangeComponentTickSettings
	void CheckIfNeedEyeMesh(); // Function BP_Hunter.BP_Hunter_C.CheckIfNeedEyeMesh
	void LineOfSightToLocation(struct FVector Start, struct FVector End, bool& OK?, struct FVector& Here); // Function BP_Hunter.BP_Hunter_C.LineOfSightToLocation
	void BotChangeLoadoutAtGenerator(char HunterGadgets New Weapon, char HunterGadgets New Gadget, char HunterPerks New Perk, bool Van Switch?); // Function BP_Hunter.BP_Hunter_C.BotChangeLoadoutAtGenerator
	void CalculateNailgunHitscan(bool& Hit?, struct FRotator& Rotation); // Function BP_Hunter.BP_Hunter_C.CalculateNailgunHitscan
	void ClearAllLocs(); // Function BP_Hunter.BP_Hunter_C.ClearAllLocs
	void ShotgunVFX_RemoteOnly(); // Function BP_Hunter.BP_Hunter_C.ShotgunVFX_RemoteOnly
	void SpectrophoneFinalizeCalculations(); // Function BP_Hunter.BP_Hunter_C.SpectrophoneFinalizeCalculations
	void HandleSpectrophoneCalculations(struct AActor* HitActor); // Function BP_Hunter.BP_Hunter_C.HandleSpectrophoneCalculations
	void OnRep_SpectrophoneHits_Repl(); // Function BP_Hunter.BP_Hunter_C.OnRep_SpectrophoneHits_Repl
	void ShotgunTraceDamage(); // Function BP_Hunter.BP_Hunter_C.ShotgunTraceDamage
	void Hunter Revive Capsule Trace(struct FTransform Start, bool& IsSpotAcceptable?); // Function BP_Hunter.BP_Hunter_C.Hunter Revive Capsule Trace
	void SniperFlybySound(struct FVector Sound Location); // Function BP_Hunter.BP_Hunter_C.SniperFlybySound
	void CalculateGrappleTrajectory(struct FVector& Location, struct FRotator& Rotation, struct FHitResult& OutHit); // Function BP_Hunter.BP_Hunter_C.CalculateGrappleTrajectory
	void Sprinting?(bool& Sprinting); // Function BP_Hunter.BP_Hunter_C.Sprinting?
	void OnRep_SniperReloading_TPAnim(); // Function BP_Hunter.BP_Hunter_C.OnRep_SniperReloading_TPAnim
	void OnRep_SniperReloading_FP(); // Function BP_Hunter.BP_Hunter_C.OnRep_SniperReloading_FP
	void Get MGH Hud(struct AMGH_HUD_C*& MGH HUD); // Function BP_Hunter.BP_Hunter_C.Get MGH Hud
	void OnRep_SniperFired(); // Function BP_Hunter.BP_Hunter_C.OnRep_SniperFired
	void OnRep_SniperFired_TPAnim(); // Function BP_Hunter.BP_Hunter_C.OnRep_SniperFired_TPAnim
	void CalculateSpectralHitscan(bool& Hit?, struct FRotator& Rotation); // Function BP_Hunter.BP_Hunter_C.CalculateSpectralHitscan
	void CalculateSniperHitscan(struct AActor*& Hit Actor, bool& Hit?, struct FRotator& Rotation, struct FVector& HitLocation, struct FVector_NetQuantize& HitOffset, bool& Deflected, struct FVector& DeflectedLocation, struct FRotator& DeflectedRotation, struct FVector& CustomStartLocation); // Function BP_Hunter.BP_Hunter_C.CalculateSniperHitscan
	void HandleGadgetEquipped(char HunterGadgets New Gadget); // Function BP_Hunter.BP_Hunter_C.HandleGadgetEquipped
	void Handle Gadget Visibility(char HunterGadgets New Gadget); // Function BP_Hunter.BP_Hunter_C.Handle Gadget Visibility
	void CalculateHarpoonTrajectory(struct FVector& Location, struct FRotator& Rotation); // Function BP_Hunter.BP_Hunter_C.CalculateHarpoonTrajectory
	void CheckIfNeedEyes(int32_t Skin, bool& Needs Eyes?); // Function BP_Hunter.BP_Hunter_C.CheckIfNeedEyes
	void AssignCorrectColors(char HunterSpec Spec(Depricated), int32_t Cloth ID, struct FLinearColor& 1, struct FLinearColor& 2, struct FLinearColor& 3, struct FLinearColor& 4); // Function BP_Hunter.BP_Hunter_C.AssignCorrectColors
	void CheckIfNeedBackpack(); // Function BP_Hunter.BP_Hunter_C.CheckIfNeedBackpack
	void ConvertToRenderHunter(); // Function BP_Hunter.BP_Hunter_C.ConvertToRenderHunter
	void SetOnConveyorState(bool Set); // Function BP_Hunter.BP_Hunter_C.SetOnConveyorState
	void DestroyConveyorParent(); // Function BP_Hunter.BP_Hunter_C.DestroyConveyorParent
	void DamageNumbers(float IncomingDamage, struct FVector DamageLocation, bool Headshot, char HitmarkerType HitmarkerType); // Function BP_Hunter.BP_Hunter_C.DamageNumbers
	void SpectralPhysicalDamage(bool Hit Ghost Form?, int32_t Damage, Rank 0, char DamageMethod method, int32_t& Damage, bool& Effective Hit); // Function BP_Hunter.BP_Hunter_C.SpectralPhysicalDamage
	void Calculate Hunter Damage(char DamageMethod Damage Method, struct AProp_C* Hit Prop, bool Force Ghost Damage?, int32_t& Damage, bool& EffectiveHit, char HitmarkerType& HitmarkerType); // Function BP_Hunter.BP_Hunter_C.Calculate Hunter Damage
	void Get MGH Player Controller(struct AMGH_PlayerController_BP_C*& MGH Player Controller); // Function BP_Hunter.BP_Hunter_C.Get MGH Player Controller
	void Get MGH Game State(struct AMGH_GameState_C*& MGH Game State); // Function BP_Hunter.BP_Hunter_C.Get MGH Game State
	void GetMGHGameInstance(struct UMGH_GameInstance_BP_C*& GameInstance); // Function BP_Hunter.BP_Hunter_C.GetMGHGameInstance
	void Is Locally Controlled Hunter?(bool& Locally Controlled?, bool& Is a Locally Controlled Bot?); // Function BP_Hunter.BP_Hunter_C.Is Locally Controlled Hunter?
	void MeleeIdleSoundLoop(bool On); // Function BP_Hunter.BP_Hunter_C.MeleeIdleSoundLoop
	void Set LOD Overrides(); // Function BP_Hunter.BP_Hunter_C.Set LOD Overrides
	void LoadSliderSettings(); // Function BP_Hunter.BP_Hunter_C.LoadSliderSettings
	void DoppelgangerGhostNearby?(bool&  YES, struct ABP_Hunter_C*& IF YES, THIS ONE); // Function BP_Hunter.BP_Hunter_C.DoppelgangerGhostNearby?
	void CalculateSpringArmOffset(struct AActor* Killer, struct FVector& Spring Arm Offset); // Function BP_Hunter.BP_Hunter_C.CalculateSpringArmOffset
	void DEBUG_CheckIfLeftoverProp&Destroy(struct AProp_C* Prop, bool& Destroyed?); // Function BP_Hunter.BP_Hunter_C.DEBUG_CheckIfLeftoverProp&Destroy
	void Get Key from Action Name(struct FString Action Name (Must be Exact), struct FString& Key (with brackets), struct UTexture2D*& Key Image); // Function BP_Hunter.BP_Hunter_C.Get Key from Action Name
	void Get MGH Player State(struct AMGH_PlayerState_C*& CPS); // Function BP_Hunter.BP_Hunter_C.Get MGH Player State
	void ConstructionScript_Function(); // Function BP_Hunter.BP_Hunter_C.ConstructionScript_Function
	void SetPitch(); // Function BP_Hunter.BP_Hunter_C.SetPitch
	void UserConstructionScript(); // Function BP_Hunter.BP_Hunter_C.UserConstructionScript
	void TineLineDistance__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.TineLineDistance__FinishedFunc
	void TineLineDistance__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.TineLineDistance__UpdateFunc
	void TimelineOpacity__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.TimelineOpacity__FinishedFunc
	void TimelineOpacity__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.TimelineOpacity__UpdateFunc
	void JumpReduction__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.JumpReduction__FinishedFunc
	void JumpReduction__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.JumpReduction__UpdateFunc
	void OceanSlowedTl__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.OceanSlowedTl__FinishedFunc
	void OceanSlowedTl__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.OceanSlowedTl__UpdateFunc
	void Timeline_3__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_3__FinishedFunc
	void Timeline_3__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_3__UpdateFunc
	void CrouchInterp__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.CrouchInterp__FinishedFunc
	void CrouchInterp__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.CrouchInterp__UpdateFunc
	void PathFinderTarailRenderTransition__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.PathFinderTarailRenderTransition__FinishedFunc
	void PathFinderTarailRenderTransition__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.PathFinderTarailRenderTransition__UpdateFunc
	void VaultSecondPart__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.VaultSecondPart__FinishedFunc
	void VaultSecondPart__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.VaultSecondPart__UpdateFunc
	void VaultFirstPart__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.VaultFirstPart__FinishedFunc
	void VaultFirstPart__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.VaultFirstPart__UpdateFunc
	void EquipmentChangeCDSlow__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.EquipmentChangeCDSlow__FinishedFunc
	void EquipmentChangeCDSlow__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.EquipmentChangeCDSlow__UpdateFunc
	void EquipmentChangeCD__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.EquipmentChangeCD__FinishedFunc
	void EquipmentChangeCD__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.EquipmentChangeCD__UpdateFunc
	void SniperMonitorTimeline__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.SniperMonitorTimeline__FinishedFunc
	void SniperMonitorTimeline__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.SniperMonitorTimeline__UpdateFunc
	void InterpolatedLoop__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.InterpolatedLoop__FinishedFunc
	void InterpolatedLoop__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.InterpolatedLoop__UpdateFunc
	void StartSniper__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.StartSniper__FinishedFunc
	void StartSniper__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.StartSniper__UpdateFunc
	void FPGhostSmasherBucklerLerp__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.FPGhostSmasherBucklerLerp__FinishedFunc
	void FPGhostSmasherBucklerLerp__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.FPGhostSmasherBucklerLerp__UpdateFunc
	void SpecCannon_reload_TurbineGlow__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.SpecCannon_reload_TurbineGlow__FinishedFunc
	void SpecCannon_reload_TurbineGlow__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.SpecCannon_reload_TurbineGlow__UpdateFunc
	void SpectralCannonSpinUp__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.SpectralCannonSpinUp__FinishedFunc
	void SpectralCannonSpinUp__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.SpectralCannonSpinUp__UpdateFunc
	void GrapplingHookCDShort__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.GrapplingHookCDShort__FinishedFunc
	void GrapplingHookCDShort__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.GrapplingHookCDShort__UpdateFunc
	void GrapplingHookCD__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.GrapplingHookCD__FinishedFunc
	void GrapplingHookCD__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.GrapplingHookCD__UpdateFunc
	void Bandage_ServerDelay_2p2Seconds__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_ServerDelay_2p2Seconds__FinishedFunc
	void Bandage_ServerDelay_2p2Seconds__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_ServerDelay_2p2Seconds__UpdateFunc
	void Bandage_Delay3_HalfSec__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_Delay3_HalfSec__FinishedFunc
	void Bandage_Delay3_HalfSec__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_Delay3_HalfSec__UpdateFunc
	void Bandage_Delay2_1+HalfSec__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_Delay2_1+HalfSec__FinishedFunc
	void Bandage_Delay2_1+HalfSec__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_Delay2_1+HalfSec__UpdateFunc
	void Bandage_Delay1_Halfsec__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_Delay1_Halfsec__FinishedFunc
	void Bandage_Delay1_Halfsec__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Bandage_Delay1_Halfsec__UpdateFunc
	void RampSpeedUI__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.RampSpeedUI__FinishedFunc
	void RampSpeedUI__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.RampSpeedUI__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_0__UpdateFunc
	void Timeline_6__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_6__FinishedFunc
	void Timeline_6__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_6__UpdateFunc
	void DefibRevive__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.DefibRevive__FinishedFunc
	void DefibRevive__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.DefibRevive__UpdateFunc
	void Timeline_7__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_7__FinishedFunc
	void Timeline_7__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_7__UpdateFunc
	void Timeline_5__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_5__FinishedFunc
	void Timeline_5__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_5__UpdateFunc
	void Timeline_4__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_4__FinishedFunc
	void Timeline_4__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_4__UpdateFunc
	void ExtraResGravity__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.ExtraResGravity__FinishedFunc
	void ExtraResGravity__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.ExtraResGravity__UpdateFunc
	void DefibRezLightTimeline__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.DefibRezLightTimeline__FinishedFunc
	void DefibRezLightTimeline__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.DefibRezLightTimeline__UpdateFunc
	void Wait__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Wait__FinishedFunc
	void Wait__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Wait__UpdateFunc
	void RampUp__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.RampUp__FinishedFunc
	void RampUp__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.RampUp__UpdateFunc
	void RampDown__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.RampDown__FinishedFunc
	void RampDown__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.RampDown__UpdateFunc
	void Timeline_RiotEmissive__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_RiotEmissive__FinishedFunc
	void Timeline_RiotEmissive__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_RiotEmissive__UpdateFunc
	void Timeline_8__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_8__FinishedFunc
	void Timeline_8__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_8__UpdateFunc
	void Timeline_9__FinishedFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_9__FinishedFunc
	void Timeline_9__UpdateFunc(); // Function BP_Hunter.BP_Hunter_C.Timeline_9__UpdateFunc
	void OnNotifyEnd_B2D8864E44601081761850AA36F3A6A9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_B2D8864E44601081761850AA36F3A6A9
	void OnNotifyBegin_B2D8864E44601081761850AA36F3A6A9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_B2D8864E44601081761850AA36F3A6A9
	void OnInterrupted_B2D8864E44601081761850AA36F3A6A9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_B2D8864E44601081761850AA36F3A6A9
	void OnBlendOut_B2D8864E44601081761850AA36F3A6A9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_B2D8864E44601081761850AA36F3A6A9
	void OnCompleted_B2D8864E44601081761850AA36F3A6A9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_B2D8864E44601081761850AA36F3A6A9
	void InpActEvt_Emote_K2Node_InputActionEvent_18(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Emote_K2Node_InputActionEvent_18
	void OnNotifyEnd_D3A85A2040AB3EA900D2C2A0BE6C15AA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D3A85A2040AB3EA900D2C2A0BE6C15AA
	void OnNotifyBegin_D3A85A2040AB3EA900D2C2A0BE6C15AA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D3A85A2040AB3EA900D2C2A0BE6C15AA
	void OnInterrupted_D3A85A2040AB3EA900D2C2A0BE6C15AA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D3A85A2040AB3EA900D2C2A0BE6C15AA
	void OnBlendOut_D3A85A2040AB3EA900D2C2A0BE6C15AA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D3A85A2040AB3EA900D2C2A0BE6C15AA
	void OnCompleted_D3A85A2040AB3EA900D2C2A0BE6C15AA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D3A85A2040AB3EA900D2C2A0BE6C15AA
	void OnNotifyEnd_C846FAEA4CE411FB0515299CFA32FF2A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_C846FAEA4CE411FB0515299CFA32FF2A
	void OnNotifyBegin_C846FAEA4CE411FB0515299CFA32FF2A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_C846FAEA4CE411FB0515299CFA32FF2A
	void OnInterrupted_C846FAEA4CE411FB0515299CFA32FF2A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_C846FAEA4CE411FB0515299CFA32FF2A
	void OnBlendOut_C846FAEA4CE411FB0515299CFA32FF2A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_C846FAEA4CE411FB0515299CFA32FF2A
	void OnCompleted_C846FAEA4CE411FB0515299CFA32FF2A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_C846FAEA4CE411FB0515299CFA32FF2A
	void OnNotifyEnd_51B45D40490EF61B9C898EAF92DE7399(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_51B45D40490EF61B9C898EAF92DE7399
	void OnNotifyBegin_51B45D40490EF61B9C898EAF92DE7399(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_51B45D40490EF61B9C898EAF92DE7399
	void OnInterrupted_51B45D40490EF61B9C898EAF92DE7399(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_51B45D40490EF61B9C898EAF92DE7399
	void OnBlendOut_51B45D40490EF61B9C898EAF92DE7399(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_51B45D40490EF61B9C898EAF92DE7399
	void OnCompleted_51B45D40490EF61B9C898EAF92DE7399(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_51B45D40490EF61B9C898EAF92DE7399
	void OnNotifyEnd_7DCD44554AB7C1F04C9F67A57862745B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_7DCD44554AB7C1F04C9F67A57862745B
	void OnNotifyBegin_7DCD44554AB7C1F04C9F67A57862745B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_7DCD44554AB7C1F04C9F67A57862745B
	void OnInterrupted_7DCD44554AB7C1F04C9F67A57862745B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_7DCD44554AB7C1F04C9F67A57862745B
	void OnBlendOut_7DCD44554AB7C1F04C9F67A57862745B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_7DCD44554AB7C1F04C9F67A57862745B
	void OnCompleted_7DCD44554AB7C1F04C9F67A57862745B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_7DCD44554AB7C1F04C9F67A57862745B
	void InpActEvt_Reload Weapon_K2Node_InputActionEvent_17(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Reload Weapon_K2Node_InputActionEvent_17
	void InpActEvt_Hunter Flashlight_K2Node_InputActionEvent_16(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Hunter Flashlight_K2Node_InputActionEvent_16
	void InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_9(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_9
	void InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_8(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_8
	void InpActEvt_Interact_K2Node_InputActionEvent_15(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Interact_K2Node_InputActionEvent_15
	void InpActEvt_Crouch_K2Node_InputActionEvent_14(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Crouch_K2Node_InputActionEvent_14
	void InpActEvt_Crouch_K2Node_InputActionEvent_13(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Crouch_K2Node_InputActionEvent_13
	void InpActEvt_Primary Equipment_K2Node_InputActionEvent_12(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Primary Equipment_K2Node_InputActionEvent_12
	void InpActEvt_Primary Weapon_K2Node_InputActionEvent_11(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Primary Weapon_K2Node_InputActionEvent_11
	void InpActEvt_Jump_K2Node_InputActionEvent_10(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Jump_K2Node_InputActionEvent_10
	void InpActEvt_Jump_K2Node_InputActionEvent_9(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Jump_K2Node_InputActionEvent_9
	void OnNotifyEnd_3AB1DBA340ACEB34BABD849DC238AD32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_3AB1DBA340ACEB34BABD849DC238AD32
	void OnNotifyBegin_3AB1DBA340ACEB34BABD849DC238AD32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_3AB1DBA340ACEB34BABD849DC238AD32
	void OnInterrupted_3AB1DBA340ACEB34BABD849DC238AD32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_3AB1DBA340ACEB34BABD849DC238AD32
	void OnBlendOut_3AB1DBA340ACEB34BABD849DC238AD32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_3AB1DBA340ACEB34BABD849DC238AD32
	void OnCompleted_3AB1DBA340ACEB34BABD849DC238AD32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_3AB1DBA340ACEB34BABD849DC238AD32
	void OnNotifyEnd_FC87973E435311E43657C6AC82765026(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_FC87973E435311E43657C6AC82765026
	void OnNotifyBegin_FC87973E435311E43657C6AC82765026(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_FC87973E435311E43657C6AC82765026
	void OnInterrupted_FC87973E435311E43657C6AC82765026(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_FC87973E435311E43657C6AC82765026
	void OnBlendOut_FC87973E435311E43657C6AC82765026(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_FC87973E435311E43657C6AC82765026
	void OnCompleted_FC87973E435311E43657C6AC82765026(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_FC87973E435311E43657C6AC82765026
	void OnNotifyEnd_435751F044F58E8DBD709ABAAEA2DD45(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_435751F044F58E8DBD709ABAAEA2DD45
	void OnNotifyBegin_435751F044F58E8DBD709ABAAEA2DD45(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_435751F044F58E8DBD709ABAAEA2DD45
	void OnInterrupted_435751F044F58E8DBD709ABAAEA2DD45(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_435751F044F58E8DBD709ABAAEA2DD45
	void OnBlendOut_435751F044F58E8DBD709ABAAEA2DD45(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_435751F044F58E8DBD709ABAAEA2DD45
	void OnCompleted_435751F044F58E8DBD709ABAAEA2DD45(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_435751F044F58E8DBD709ABAAEA2DD45
	void OnNotifyEnd_CE8E410849FBDAD2F9A2639AB919C546(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_CE8E410849FBDAD2F9A2639AB919C546
	void OnNotifyBegin_CE8E410849FBDAD2F9A2639AB919C546(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_CE8E410849FBDAD2F9A2639AB919C546
	void OnInterrupted_CE8E410849FBDAD2F9A2639AB919C546(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_CE8E410849FBDAD2F9A2639AB919C546
	void OnBlendOut_CE8E410849FBDAD2F9A2639AB919C546(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_CE8E410849FBDAD2F9A2639AB919C546
	void OnCompleted_CE8E410849FBDAD2F9A2639AB919C546(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_CE8E410849FBDAD2F9A2639AB919C546
	void OnNotifyEnd_39F4850646CD7F1AD1794296385A2F70(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_39F4850646CD7F1AD1794296385A2F70
	void OnNotifyBegin_39F4850646CD7F1AD1794296385A2F70(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_39F4850646CD7F1AD1794296385A2F70
	void OnInterrupted_39F4850646CD7F1AD1794296385A2F70(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_39F4850646CD7F1AD1794296385A2F70
	void OnBlendOut_39F4850646CD7F1AD1794296385A2F70(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_39F4850646CD7F1AD1794296385A2F70
	void OnCompleted_39F4850646CD7F1AD1794296385A2F70(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_39F4850646CD7F1AD1794296385A2F70
	void OnNotifyEnd_226F8ECF45C8CE13251FB0A82DC9A1A3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_226F8ECF45C8CE13251FB0A82DC9A1A3
	void OnNotifyBegin_226F8ECF45C8CE13251FB0A82DC9A1A3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_226F8ECF45C8CE13251FB0A82DC9A1A3
	void OnInterrupted_226F8ECF45C8CE13251FB0A82DC9A1A3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_226F8ECF45C8CE13251FB0A82DC9A1A3
	void OnBlendOut_226F8ECF45C8CE13251FB0A82DC9A1A3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_226F8ECF45C8CE13251FB0A82DC9A1A3
	void OnCompleted_226F8ECF45C8CE13251FB0A82DC9A1A3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_226F8ECF45C8CE13251FB0A82DC9A1A3
	void OnNotifyEnd_C3E3794B433214E0ED21A1888CD0EF83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_C3E3794B433214E0ED21A1888CD0EF83
	void OnNotifyBegin_C3E3794B433214E0ED21A1888CD0EF83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_C3E3794B433214E0ED21A1888CD0EF83
	void OnInterrupted_C3E3794B433214E0ED21A1888CD0EF83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_C3E3794B433214E0ED21A1888CD0EF83
	void OnBlendOut_C3E3794B433214E0ED21A1888CD0EF83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_C3E3794B433214E0ED21A1888CD0EF83
	void OnCompleted_C3E3794B433214E0ED21A1888CD0EF83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_C3E3794B433214E0ED21A1888CD0EF83
	void OnNotifyEnd_187DBF834625A205E8E97D9F5C4DFB32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_187DBF834625A205E8E97D9F5C4DFB32
	void OnNotifyBegin_187DBF834625A205E8E97D9F5C4DFB32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_187DBF834625A205E8E97D9F5C4DFB32
	void OnInterrupted_187DBF834625A205E8E97D9F5C4DFB32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_187DBF834625A205E8E97D9F5C4DFB32
	void OnBlendOut_187DBF834625A205E8E97D9F5C4DFB32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_187DBF834625A205E8E97D9F5C4DFB32
	void OnCompleted_187DBF834625A205E8E97D9F5C4DFB32(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_187DBF834625A205E8E97D9F5C4DFB32
	void InpActEvt_Ghost Transform_K2Node_InputActionEvent_8(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Ghost Transform_K2Node_InputActionEvent_8
	void Finished_26E8F6274BB3ADFEFFF630ADD6800F0E(); // Function BP_Hunter.BP_Hunter_C.Finished_26E8F6274BB3ADFEFFF630ADD6800F0E
	void InpActEvt_Alternate Fire_K2Node_InputActionEvent_7(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Alternate Fire_K2Node_InputActionEvent_7
	void InpActEvt_Alternate Fire_K2Node_InputActionEvent_6(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Alternate Fire_K2Node_InputActionEvent_6
	void InpActEvt_Primary Fire_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Primary Fire_K2Node_InputActionEvent_5
	void InpActEvt_Primary Fire_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Primary Fire_K2Node_InputActionEvent_4
	void OnNotifyEnd_9D338B3F41BD2BBACB476983205533F9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_9D338B3F41BD2BBACB476983205533F9
	void OnNotifyBegin_9D338B3F41BD2BBACB476983205533F9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_9D338B3F41BD2BBACB476983205533F9
	void OnInterrupted_9D338B3F41BD2BBACB476983205533F9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_9D338B3F41BD2BBACB476983205533F9
	void OnBlendOut_9D338B3F41BD2BBACB476983205533F9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_9D338B3F41BD2BBACB476983205533F9
	void OnCompleted_9D338B3F41BD2BBACB476983205533F9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_9D338B3F41BD2BBACB476983205533F9
	void OnNotifyEnd_6F015C5240CAE9A6196C3B902BAA5F47(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_6F015C5240CAE9A6196C3B902BAA5F47
	void OnNotifyBegin_6F015C5240CAE9A6196C3B902BAA5F47(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_6F015C5240CAE9A6196C3B902BAA5F47
	void OnInterrupted_6F015C5240CAE9A6196C3B902BAA5F47(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_6F015C5240CAE9A6196C3B902BAA5F47
	void OnBlendOut_6F015C5240CAE9A6196C3B902BAA5F47(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_6F015C5240CAE9A6196C3B902BAA5F47
	void OnCompleted_6F015C5240CAE9A6196C3B902BAA5F47(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_6F015C5240CAE9A6196C3B902BAA5F47
	void OnNotifyEnd_FEA16A414C4BC0F50559B9AAE9301215(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_FEA16A414C4BC0F50559B9AAE9301215
	void OnNotifyBegin_FEA16A414C4BC0F50559B9AAE9301215(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_FEA16A414C4BC0F50559B9AAE9301215
	void OnInterrupted_FEA16A414C4BC0F50559B9AAE9301215(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_FEA16A414C4BC0F50559B9AAE9301215
	void OnBlendOut_FEA16A414C4BC0F50559B9AAE9301215(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_FEA16A414C4BC0F50559B9AAE9301215
	void OnCompleted_FEA16A414C4BC0F50559B9AAE9301215(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_FEA16A414C4BC0F50559B9AAE9301215
	void OnNotifyEnd_C854F6EB4E7A57A6B97EF7BFBEAEB97C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_C854F6EB4E7A57A6B97EF7BFBEAEB97C
	void OnNotifyBegin_C854F6EB4E7A57A6B97EF7BFBEAEB97C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_C854F6EB4E7A57A6B97EF7BFBEAEB97C
	void OnInterrupted_C854F6EB4E7A57A6B97EF7BFBEAEB97C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_C854F6EB4E7A57A6B97EF7BFBEAEB97C
	void OnBlendOut_C854F6EB4E7A57A6B97EF7BFBEAEB97C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_C854F6EB4E7A57A6B97EF7BFBEAEB97C
	void OnCompleted_C854F6EB4E7A57A6B97EF7BFBEAEB97C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_C854F6EB4E7A57A6B97EF7BFBEAEB97C
	void OnNotifyEnd_60AD0D7243AE08FF5F2A0C86A3D17E56(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_60AD0D7243AE08FF5F2A0C86A3D17E56
	void OnNotifyBegin_60AD0D7243AE08FF5F2A0C86A3D17E56(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_60AD0D7243AE08FF5F2A0C86A3D17E56
	void OnInterrupted_60AD0D7243AE08FF5F2A0C86A3D17E56(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_60AD0D7243AE08FF5F2A0C86A3D17E56
	void OnBlendOut_60AD0D7243AE08FF5F2A0C86A3D17E56(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_60AD0D7243AE08FF5F2A0C86A3D17E56
	void OnCompleted_60AD0D7243AE08FF5F2A0C86A3D17E56(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_60AD0D7243AE08FF5F2A0C86A3D17E56
	void OnNotifyEnd_B893E981495CA7ADD6C0ED85FD001956(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_B893E981495CA7ADD6C0ED85FD001956
	void OnNotifyBegin_B893E981495CA7ADD6C0ED85FD001956(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_B893E981495CA7ADD6C0ED85FD001956
	void OnInterrupted_B893E981495CA7ADD6C0ED85FD001956(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_B893E981495CA7ADD6C0ED85FD001956
	void OnBlendOut_B893E981495CA7ADD6C0ED85FD001956(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_B893E981495CA7ADD6C0ED85FD001956
	void OnCompleted_B893E981495CA7ADD6C0ED85FD001956(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_B893E981495CA7ADD6C0ED85FD001956
	void OnNotifyEnd_C92DBBFA4CAB54E046955B8BCF8FEB83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_C92DBBFA4CAB54E046955B8BCF8FEB83
	void OnNotifyBegin_C92DBBFA4CAB54E046955B8BCF8FEB83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_C92DBBFA4CAB54E046955B8BCF8FEB83
	void OnInterrupted_C92DBBFA4CAB54E046955B8BCF8FEB83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_C92DBBFA4CAB54E046955B8BCF8FEB83
	void OnBlendOut_C92DBBFA4CAB54E046955B8BCF8FEB83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_C92DBBFA4CAB54E046955B8BCF8FEB83
	void OnCompleted_C92DBBFA4CAB54E046955B8BCF8FEB83(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_C92DBBFA4CAB54E046955B8BCF8FEB83
	void OnNotifyEnd_0E63DE554D7B5F0EE896BABD60CC3EA0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_0E63DE554D7B5F0EE896BABD60CC3EA0
	void OnNotifyBegin_0E63DE554D7B5F0EE896BABD60CC3EA0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_0E63DE554D7B5F0EE896BABD60CC3EA0
	void OnInterrupted_0E63DE554D7B5F0EE896BABD60CC3EA0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_0E63DE554D7B5F0EE896BABD60CC3EA0
	void OnBlendOut_0E63DE554D7B5F0EE896BABD60CC3EA0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_0E63DE554D7B5F0EE896BABD60CC3EA0
	void OnCompleted_0E63DE554D7B5F0EE896BABD60CC3EA0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_0E63DE554D7B5F0EE896BABD60CC3EA0
	void OnNotifyEnd_EC030CAA407C3F106C2E3680F44CC329(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_EC030CAA407C3F106C2E3680F44CC329
	void OnNotifyBegin_EC030CAA407C3F106C2E3680F44CC329(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_EC030CAA407C3F106C2E3680F44CC329
	void OnInterrupted_EC030CAA407C3F106C2E3680F44CC329(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_EC030CAA407C3F106C2E3680F44CC329
	void OnBlendOut_EC030CAA407C3F106C2E3680F44CC329(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_EC030CAA407C3F106C2E3680F44CC329
	void OnCompleted_EC030CAA407C3F106C2E3680F44CC329(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_EC030CAA407C3F106C2E3680F44CC329
	void OnNotifyEnd_D72C57E240083E640AD265AB09630D2F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D72C57E240083E640AD265AB09630D2F
	void OnNotifyBegin_D72C57E240083E640AD265AB09630D2F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D72C57E240083E640AD265AB09630D2F
	void OnInterrupted_D72C57E240083E640AD265AB09630D2F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D72C57E240083E640AD265AB09630D2F
	void OnBlendOut_D72C57E240083E640AD265AB09630D2F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D72C57E240083E640AD265AB09630D2F
	void OnCompleted_D72C57E240083E640AD265AB09630D2F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D72C57E240083E640AD265AB09630D2F
	void OnNotifyEnd_DBFD65DE47B4F48B6F61DD90D132F667(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_DBFD65DE47B4F48B6F61DD90D132F667
	void OnNotifyBegin_DBFD65DE47B4F48B6F61DD90D132F667(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_DBFD65DE47B4F48B6F61DD90D132F667
	void OnInterrupted_DBFD65DE47B4F48B6F61DD90D132F667(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_DBFD65DE47B4F48B6F61DD90D132F667
	void OnBlendOut_DBFD65DE47B4F48B6F61DD90D132F667(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_DBFD65DE47B4F48B6F61DD90D132F667
	void OnCompleted_DBFD65DE47B4F48B6F61DD90D132F667(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_DBFD65DE47B4F48B6F61DD90D132F667
	void OnNotifyEnd_B0798AAE4DECF06B796DF68E5A0524F4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_B0798AAE4DECF06B796DF68E5A0524F4
	void OnNotifyBegin_B0798AAE4DECF06B796DF68E5A0524F4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_B0798AAE4DECF06B796DF68E5A0524F4
	void OnInterrupted_B0798AAE4DECF06B796DF68E5A0524F4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_B0798AAE4DECF06B796DF68E5A0524F4
	void OnBlendOut_B0798AAE4DECF06B796DF68E5A0524F4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_B0798AAE4DECF06B796DF68E5A0524F4
	void OnCompleted_B0798AAE4DECF06B796DF68E5A0524F4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_B0798AAE4DECF06B796DF68E5A0524F4
	void OnNotifyEnd_0702FAEE4620019F0EC476BF686670F2(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_0702FAEE4620019F0EC476BF686670F2
	void OnNotifyBegin_0702FAEE4620019F0EC476BF686670F2(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_0702FAEE4620019F0EC476BF686670F2
	void OnInterrupted_0702FAEE4620019F0EC476BF686670F2(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_0702FAEE4620019F0EC476BF686670F2
	void OnBlendOut_0702FAEE4620019F0EC476BF686670F2(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_0702FAEE4620019F0EC476BF686670F2
	void OnCompleted_0702FAEE4620019F0EC476BF686670F2(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_0702FAEE4620019F0EC476BF686670F2
	void OnNotifyEnd_46B213234D7D9E9CBB8E7AAF8B23C393(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_46B213234D7D9E9CBB8E7AAF8B23C393
	void OnNotifyBegin_46B213234D7D9E9CBB8E7AAF8B23C393(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_46B213234D7D9E9CBB8E7AAF8B23C393
	void OnInterrupted_46B213234D7D9E9CBB8E7AAF8B23C393(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_46B213234D7D9E9CBB8E7AAF8B23C393
	void OnBlendOut_46B213234D7D9E9CBB8E7AAF8B23C393(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_46B213234D7D9E9CBB8E7AAF8B23C393
	void OnCompleted_46B213234D7D9E9CBB8E7AAF8B23C393(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_46B213234D7D9E9CBB8E7AAF8B23C393
	void OnNotifyEnd_9D2B157C43665C36BA495B95EBC5D879(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_9D2B157C43665C36BA495B95EBC5D879
	void OnNotifyBegin_9D2B157C43665C36BA495B95EBC5D879(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_9D2B157C43665C36BA495B95EBC5D879
	void OnInterrupted_9D2B157C43665C36BA495B95EBC5D879(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_9D2B157C43665C36BA495B95EBC5D879
	void OnBlendOut_9D2B157C43665C36BA495B95EBC5D879(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_9D2B157C43665C36BA495B95EBC5D879
	void OnCompleted_9D2B157C43665C36BA495B95EBC5D879(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_9D2B157C43665C36BA495B95EBC5D879
	void OnNotifyEnd_2FF7F9D74AF66D6C5E39E6B193E9E4A4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_2FF7F9D74AF66D6C5E39E6B193E9E4A4
	void OnNotifyBegin_2FF7F9D74AF66D6C5E39E6B193E9E4A4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_2FF7F9D74AF66D6C5E39E6B193E9E4A4
	void OnInterrupted_2FF7F9D74AF66D6C5E39E6B193E9E4A4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_2FF7F9D74AF66D6C5E39E6B193E9E4A4
	void OnBlendOut_2FF7F9D74AF66D6C5E39E6B193E9E4A4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_2FF7F9D74AF66D6C5E39E6B193E9E4A4
	void OnCompleted_2FF7F9D74AF66D6C5E39E6B193E9E4A4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_2FF7F9D74AF66D6C5E39E6B193E9E4A4
	void OnNotifyEnd_827AC5D14C3100BC4E801194BD9C0567(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_827AC5D14C3100BC4E801194BD9C0567
	void OnNotifyBegin_827AC5D14C3100BC4E801194BD9C0567(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_827AC5D14C3100BC4E801194BD9C0567
	void OnInterrupted_827AC5D14C3100BC4E801194BD9C0567(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_827AC5D14C3100BC4E801194BD9C0567
	void OnBlendOut_827AC5D14C3100BC4E801194BD9C0567(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_827AC5D14C3100BC4E801194BD9C0567
	void OnCompleted_827AC5D14C3100BC4E801194BD9C0567(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_827AC5D14C3100BC4E801194BD9C0567
	void OnNotifyEnd_D32729E844DEA1D1F3140C8F75BE6869(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D32729E844DEA1D1F3140C8F75BE6869
	void OnNotifyBegin_D32729E844DEA1D1F3140C8F75BE6869(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D32729E844DEA1D1F3140C8F75BE6869
	void OnInterrupted_D32729E844DEA1D1F3140C8F75BE6869(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D32729E844DEA1D1F3140C8F75BE6869
	void OnBlendOut_D32729E844DEA1D1F3140C8F75BE6869(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D32729E844DEA1D1F3140C8F75BE6869
	void OnCompleted_D32729E844DEA1D1F3140C8F75BE6869(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D32729E844DEA1D1F3140C8F75BE6869
	void InpActEvt_Nine_K2Node_InputKeyEvent_7(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Nine_K2Node_InputKeyEvent_7
	void OnNotifyEnd_5A7D97294F84BFC06944CF90CF82D0DD(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_5A7D97294F84BFC06944CF90CF82D0DD
	void OnNotifyBegin_5A7D97294F84BFC06944CF90CF82D0DD(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_5A7D97294F84BFC06944CF90CF82D0DD
	void OnInterrupted_5A7D97294F84BFC06944CF90CF82D0DD(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_5A7D97294F84BFC06944CF90CF82D0DD
	void OnBlendOut_5A7D97294F84BFC06944CF90CF82D0DD(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_5A7D97294F84BFC06944CF90CF82D0DD
	void OnCompleted_5A7D97294F84BFC06944CF90CF82D0DD(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_5A7D97294F84BFC06944CF90CF82D0DD
	void OnNotifyEnd_8408C6AC4AE0186983B5EA8116C5B8E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_8408C6AC4AE0186983B5EA8116C5B8E3
	void OnNotifyBegin_8408C6AC4AE0186983B5EA8116C5B8E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_8408C6AC4AE0186983B5EA8116C5B8E3
	void OnInterrupted_8408C6AC4AE0186983B5EA8116C5B8E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_8408C6AC4AE0186983B5EA8116C5B8E3
	void OnBlendOut_8408C6AC4AE0186983B5EA8116C5B8E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_8408C6AC4AE0186983B5EA8116C5B8E3
	void OnCompleted_8408C6AC4AE0186983B5EA8116C5B8E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_8408C6AC4AE0186983B5EA8116C5B8E3
	void OnNotifyEnd_FE97E1114029EFC2EA48C6BF91287872(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_FE97E1114029EFC2EA48C6BF91287872
	void OnNotifyBegin_FE97E1114029EFC2EA48C6BF91287872(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_FE97E1114029EFC2EA48C6BF91287872
	void OnInterrupted_FE97E1114029EFC2EA48C6BF91287872(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_FE97E1114029EFC2EA48C6BF91287872
	void OnBlendOut_FE97E1114029EFC2EA48C6BF91287872(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_FE97E1114029EFC2EA48C6BF91287872
	void OnCompleted_FE97E1114029EFC2EA48C6BF91287872(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_FE97E1114029EFC2EA48C6BF91287872
	void OnNotifyEnd_7136F30E42F3C23DB70EA0961D681FE9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_7136F30E42F3C23DB70EA0961D681FE9
	void OnNotifyBegin_7136F30E42F3C23DB70EA0961D681FE9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_7136F30E42F3C23DB70EA0961D681FE9
	void OnInterrupted_7136F30E42F3C23DB70EA0961D681FE9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_7136F30E42F3C23DB70EA0961D681FE9
	void OnBlendOut_7136F30E42F3C23DB70EA0961D681FE9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_7136F30E42F3C23DB70EA0961D681FE9
	void OnCompleted_7136F30E42F3C23DB70EA0961D681FE9(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_7136F30E42F3C23DB70EA0961D681FE9
	void OnNotifyEnd_69A275D34838AC79C544648ECE79A67A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_69A275D34838AC79C544648ECE79A67A
	void OnNotifyBegin_69A275D34838AC79C544648ECE79A67A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_69A275D34838AC79C544648ECE79A67A
	void OnInterrupted_69A275D34838AC79C544648ECE79A67A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_69A275D34838AC79C544648ECE79A67A
	void OnBlendOut_69A275D34838AC79C544648ECE79A67A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_69A275D34838AC79C544648ECE79A67A
	void OnCompleted_69A275D34838AC79C544648ECE79A67A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_69A275D34838AC79C544648ECE79A67A
	void OnNotifyEnd_F240AE7542B228EDAF9C8A8AA2CC0FA1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_F240AE7542B228EDAF9C8A8AA2CC0FA1
	void OnNotifyBegin_F240AE7542B228EDAF9C8A8AA2CC0FA1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_F240AE7542B228EDAF9C8A8AA2CC0FA1
	void OnInterrupted_F240AE7542B228EDAF9C8A8AA2CC0FA1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_F240AE7542B228EDAF9C8A8AA2CC0FA1
	void OnBlendOut_F240AE7542B228EDAF9C8A8AA2CC0FA1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_F240AE7542B228EDAF9C8A8AA2CC0FA1
	void OnCompleted_F240AE7542B228EDAF9C8A8AA2CC0FA1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_F240AE7542B228EDAF9C8A8AA2CC0FA1
	void OnNotifyEnd_828A1A754DA769A2817697A0BBE553C8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_828A1A754DA769A2817697A0BBE553C8
	void OnNotifyBegin_828A1A754DA769A2817697A0BBE553C8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_828A1A754DA769A2817697A0BBE553C8
	void OnInterrupted_828A1A754DA769A2817697A0BBE553C8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_828A1A754DA769A2817697A0BBE553C8
	void OnBlendOut_828A1A754DA769A2817697A0BBE553C8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_828A1A754DA769A2817697A0BBE553C8
	void OnCompleted_828A1A754DA769A2817697A0BBE553C8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_828A1A754DA769A2817697A0BBE553C8
	void OnNotifyEnd_A1F68B0A451B0192B48D79A29D0784E6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_A1F68B0A451B0192B48D79A29D0784E6
	void OnNotifyBegin_A1F68B0A451B0192B48D79A29D0784E6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_A1F68B0A451B0192B48D79A29D0784E6
	void OnInterrupted_A1F68B0A451B0192B48D79A29D0784E6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_A1F68B0A451B0192B48D79A29D0784E6
	void OnBlendOut_A1F68B0A451B0192B48D79A29D0784E6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_A1F68B0A451B0192B48D79A29D0784E6
	void OnCompleted_A1F68B0A451B0192B48D79A29D0784E6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_A1F68B0A451B0192B48D79A29D0784E6
	void OnNotifyEnd_230B4F754CD3FDED1CB8EA88AE7BAF7C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_230B4F754CD3FDED1CB8EA88AE7BAF7C
	void OnNotifyBegin_230B4F754CD3FDED1CB8EA88AE7BAF7C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_230B4F754CD3FDED1CB8EA88AE7BAF7C
	void OnInterrupted_230B4F754CD3FDED1CB8EA88AE7BAF7C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_230B4F754CD3FDED1CB8EA88AE7BAF7C
	void OnBlendOut_230B4F754CD3FDED1CB8EA88AE7BAF7C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_230B4F754CD3FDED1CB8EA88AE7BAF7C
	void OnCompleted_230B4F754CD3FDED1CB8EA88AE7BAF7C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_230B4F754CD3FDED1CB8EA88AE7BAF7C
	void OnNotifyEnd_5F565F70432B389DCF464AB4909AE558(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_5F565F70432B389DCF464AB4909AE558
	void OnNotifyBegin_5F565F70432B389DCF464AB4909AE558(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_5F565F70432B389DCF464AB4909AE558
	void OnInterrupted_5F565F70432B389DCF464AB4909AE558(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_5F565F70432B389DCF464AB4909AE558
	void OnBlendOut_5F565F70432B389DCF464AB4909AE558(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_5F565F70432B389DCF464AB4909AE558
	void OnCompleted_5F565F70432B389DCF464AB4909AE558(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_5F565F70432B389DCF464AB4909AE558
	void OnNotifyEnd_5FF0BAFF47155F0DA8830280177857E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_5FF0BAFF47155F0DA8830280177857E3
	void OnNotifyBegin_5FF0BAFF47155F0DA8830280177857E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_5FF0BAFF47155F0DA8830280177857E3
	void OnInterrupted_5FF0BAFF47155F0DA8830280177857E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_5FF0BAFF47155F0DA8830280177857E3
	void OnBlendOut_5FF0BAFF47155F0DA8830280177857E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_5FF0BAFF47155F0DA8830280177857E3
	void OnCompleted_5FF0BAFF47155F0DA8830280177857E3(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_5FF0BAFF47155F0DA8830280177857E3
	void OnNotifyEnd_FDAF069E41BB375A56F8618C7801A8D7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_FDAF069E41BB375A56F8618C7801A8D7
	void OnNotifyBegin_FDAF069E41BB375A56F8618C7801A8D7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_FDAF069E41BB375A56F8618C7801A8D7
	void OnInterrupted_FDAF069E41BB375A56F8618C7801A8D7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_FDAF069E41BB375A56F8618C7801A8D7
	void OnBlendOut_FDAF069E41BB375A56F8618C7801A8D7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_FDAF069E41BB375A56F8618C7801A8D7
	void OnCompleted_FDAF069E41BB375A56F8618C7801A8D7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_FDAF069E41BB375A56F8618C7801A8D7
	void OnNotifyEnd_93F5DC934059DCEE88373D8CB9E38805(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_93F5DC934059DCEE88373D8CB9E38805
	void OnNotifyBegin_93F5DC934059DCEE88373D8CB9E38805(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_93F5DC934059DCEE88373D8CB9E38805
	void OnInterrupted_93F5DC934059DCEE88373D8CB9E38805(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_93F5DC934059DCEE88373D8CB9E38805
	void OnBlendOut_93F5DC934059DCEE88373D8CB9E38805(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_93F5DC934059DCEE88373D8CB9E38805
	void OnCompleted_93F5DC934059DCEE88373D8CB9E38805(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_93F5DC934059DCEE88373D8CB9E38805
	void OnNotifyEnd_DF4A86B04E7C6BD8941F38BF2D58D90B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_DF4A86B04E7C6BD8941F38BF2D58D90B
	void OnNotifyBegin_DF4A86B04E7C6BD8941F38BF2D58D90B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_DF4A86B04E7C6BD8941F38BF2D58D90B
	void OnInterrupted_DF4A86B04E7C6BD8941F38BF2D58D90B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_DF4A86B04E7C6BD8941F38BF2D58D90B
	void OnBlendOut_DF4A86B04E7C6BD8941F38BF2D58D90B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_DF4A86B04E7C6BD8941F38BF2D58D90B
	void OnCompleted_DF4A86B04E7C6BD8941F38BF2D58D90B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_DF4A86B04E7C6BD8941F38BF2D58D90B
	void OnNotifyEnd_EB3452E64AB2F1247C154B884F52143C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_EB3452E64AB2F1247C154B884F52143C
	void OnNotifyBegin_EB3452E64AB2F1247C154B884F52143C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_EB3452E64AB2F1247C154B884F52143C
	void OnInterrupted_EB3452E64AB2F1247C154B884F52143C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_EB3452E64AB2F1247C154B884F52143C
	void OnBlendOut_EB3452E64AB2F1247C154B884F52143C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_EB3452E64AB2F1247C154B884F52143C
	void OnCompleted_EB3452E64AB2F1247C154B884F52143C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_EB3452E64AB2F1247C154B884F52143C
	void OnNotifyEnd_67A316D74C1AB12F84D82C9652E6352B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_67A316D74C1AB12F84D82C9652E6352B
	void OnNotifyBegin_67A316D74C1AB12F84D82C9652E6352B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_67A316D74C1AB12F84D82C9652E6352B
	void OnInterrupted_67A316D74C1AB12F84D82C9652E6352B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_67A316D74C1AB12F84D82C9652E6352B
	void OnBlendOut_67A316D74C1AB12F84D82C9652E6352B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_67A316D74C1AB12F84D82C9652E6352B
	void OnCompleted_67A316D74C1AB12F84D82C9652E6352B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_67A316D74C1AB12F84D82C9652E6352B
	void OnNotifyEnd_C44FD5B24AE20B8EA1CE5D821E2DA497(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_C44FD5B24AE20B8EA1CE5D821E2DA497
	void OnNotifyBegin_C44FD5B24AE20B8EA1CE5D821E2DA497(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_C44FD5B24AE20B8EA1CE5D821E2DA497
	void OnInterrupted_C44FD5B24AE20B8EA1CE5D821E2DA497(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_C44FD5B24AE20B8EA1CE5D821E2DA497
	void OnBlendOut_C44FD5B24AE20B8EA1CE5D821E2DA497(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_C44FD5B24AE20B8EA1CE5D821E2DA497
	void OnCompleted_C44FD5B24AE20B8EA1CE5D821E2DA497(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_C44FD5B24AE20B8EA1CE5D821E2DA497
	void OnNotifyEnd_58A831404BF113E5BC3497B010CFE7FA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_58A831404BF113E5BC3497B010CFE7FA
	void OnNotifyBegin_58A831404BF113E5BC3497B010CFE7FA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_58A831404BF113E5BC3497B010CFE7FA
	void OnInterrupted_58A831404BF113E5BC3497B010CFE7FA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_58A831404BF113E5BC3497B010CFE7FA
	void OnBlendOut_58A831404BF113E5BC3497B010CFE7FA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_58A831404BF113E5BC3497B010CFE7FA
	void OnCompleted_58A831404BF113E5BC3497B010CFE7FA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_58A831404BF113E5BC3497B010CFE7FA
	void OnNotifyEnd_CC3039B747B8263BC80CA888495C585C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_CC3039B747B8263BC80CA888495C585C
	void OnNotifyBegin_CC3039B747B8263BC80CA888495C585C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_CC3039B747B8263BC80CA888495C585C
	void OnInterrupted_CC3039B747B8263BC80CA888495C585C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_CC3039B747B8263BC80CA888495C585C
	void OnBlendOut_CC3039B747B8263BC80CA888495C585C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_CC3039B747B8263BC80CA888495C585C
	void OnCompleted_CC3039B747B8263BC80CA888495C585C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_CC3039B747B8263BC80CA888495C585C
	void OnNotifyEnd_65C6E0BE44C6C2D469D8A79CA0A66365(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_65C6E0BE44C6C2D469D8A79CA0A66365
	void OnNotifyBegin_65C6E0BE44C6C2D469D8A79CA0A66365(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_65C6E0BE44C6C2D469D8A79CA0A66365
	void OnInterrupted_65C6E0BE44C6C2D469D8A79CA0A66365(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_65C6E0BE44C6C2D469D8A79CA0A66365
	void OnBlendOut_65C6E0BE44C6C2D469D8A79CA0A66365(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_65C6E0BE44C6C2D469D8A79CA0A66365
	void OnCompleted_65C6E0BE44C6C2D469D8A79CA0A66365(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_65C6E0BE44C6C2D469D8A79CA0A66365
	void OnNotifyEnd_1A2F43804DD08C24A47976A67E09D230(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_1A2F43804DD08C24A47976A67E09D230
	void OnNotifyBegin_1A2F43804DD08C24A47976A67E09D230(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_1A2F43804DD08C24A47976A67E09D230
	void OnInterrupted_1A2F43804DD08C24A47976A67E09D230(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_1A2F43804DD08C24A47976A67E09D230
	void OnBlendOut_1A2F43804DD08C24A47976A67E09D230(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_1A2F43804DD08C24A47976A67E09D230
	void OnCompleted_1A2F43804DD08C24A47976A67E09D230(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_1A2F43804DD08C24A47976A67E09D230
	void OnNotifyEnd_7A04C93B45DEAE87DE0330A17693B7FC(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_7A04C93B45DEAE87DE0330A17693B7FC
	void OnNotifyBegin_7A04C93B45DEAE87DE0330A17693B7FC(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_7A04C93B45DEAE87DE0330A17693B7FC
	void OnInterrupted_7A04C93B45DEAE87DE0330A17693B7FC(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_7A04C93B45DEAE87DE0330A17693B7FC
	void OnBlendOut_7A04C93B45DEAE87DE0330A17693B7FC(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_7A04C93B45DEAE87DE0330A17693B7FC
	void OnCompleted_7A04C93B45DEAE87DE0330A17693B7FC(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_7A04C93B45DEAE87DE0330A17693B7FC
	void OnNotifyEnd_7D9E2F3545D089514267DCAA6D608281(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_7D9E2F3545D089514267DCAA6D608281
	void OnNotifyBegin_7D9E2F3545D089514267DCAA6D608281(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_7D9E2F3545D089514267DCAA6D608281
	void OnInterrupted_7D9E2F3545D089514267DCAA6D608281(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_7D9E2F3545D089514267DCAA6D608281
	void OnBlendOut_7D9E2F3545D089514267DCAA6D608281(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_7D9E2F3545D089514267DCAA6D608281
	void OnCompleted_7D9E2F3545D089514267DCAA6D608281(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_7D9E2F3545D089514267DCAA6D608281
	void OnNotifyEnd_47FA9DDA4821FD57F852F3824648A7F0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_47FA9DDA4821FD57F852F3824648A7F0
	void OnNotifyBegin_47FA9DDA4821FD57F852F3824648A7F0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_47FA9DDA4821FD57F852F3824648A7F0
	void OnInterrupted_47FA9DDA4821FD57F852F3824648A7F0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_47FA9DDA4821FD57F852F3824648A7F0
	void OnBlendOut_47FA9DDA4821FD57F852F3824648A7F0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_47FA9DDA4821FD57F852F3824648A7F0
	void OnCompleted_47FA9DDA4821FD57F852F3824648A7F0(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_47FA9DDA4821FD57F852F3824648A7F0
	void OnNotifyEnd_A5E1801C44441AD284C420A482E351B4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_A5E1801C44441AD284C420A482E351B4
	void OnNotifyBegin_A5E1801C44441AD284C420A482E351B4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_A5E1801C44441AD284C420A482E351B4
	void OnInterrupted_A5E1801C44441AD284C420A482E351B4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_A5E1801C44441AD284C420A482E351B4
	void OnBlendOut_A5E1801C44441AD284C420A482E351B4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_A5E1801C44441AD284C420A482E351B4
	void OnCompleted_A5E1801C44441AD284C420A482E351B4(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_A5E1801C44441AD284C420A482E351B4
	void OnNotifyEnd_F8F4F4C942ED21356FF2D0AC95575063(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_F8F4F4C942ED21356FF2D0AC95575063
	void OnNotifyBegin_F8F4F4C942ED21356FF2D0AC95575063(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_F8F4F4C942ED21356FF2D0AC95575063
	void OnInterrupted_F8F4F4C942ED21356FF2D0AC95575063(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_F8F4F4C942ED21356FF2D0AC95575063
	void OnBlendOut_F8F4F4C942ED21356FF2D0AC95575063(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_F8F4F4C942ED21356FF2D0AC95575063
	void OnCompleted_F8F4F4C942ED21356FF2D0AC95575063(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_F8F4F4C942ED21356FF2D0AC95575063
	void OnNotifyEnd_BF654CCB499587E3A2977E85E1FB0F0F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_BF654CCB499587E3A2977E85E1FB0F0F
	void OnNotifyBegin_BF654CCB499587E3A2977E85E1FB0F0F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_BF654CCB499587E3A2977E85E1FB0F0F
	void OnInterrupted_BF654CCB499587E3A2977E85E1FB0F0F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_BF654CCB499587E3A2977E85E1FB0F0F
	void OnBlendOut_BF654CCB499587E3A2977E85E1FB0F0F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_BF654CCB499587E3A2977E85E1FB0F0F
	void OnCompleted_BF654CCB499587E3A2977E85E1FB0F0F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_BF654CCB499587E3A2977E85E1FB0F0F
	void OnNotifyEnd_FFEF28C54B375F004CE337990880FCEF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_FFEF28C54B375F004CE337990880FCEF
	void OnNotifyBegin_FFEF28C54B375F004CE337990880FCEF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_FFEF28C54B375F004CE337990880FCEF
	void OnInterrupted_FFEF28C54B375F004CE337990880FCEF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_FFEF28C54B375F004CE337990880FCEF
	void OnBlendOut_FFEF28C54B375F004CE337990880FCEF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_FFEF28C54B375F004CE337990880FCEF
	void OnCompleted_FFEF28C54B375F004CE337990880FCEF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_FFEF28C54B375F004CE337990880FCEF
	void OnNotifyEnd_EA49D0BA47B97681641F53BFFD8C37FB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_EA49D0BA47B97681641F53BFFD8C37FB
	void OnNotifyBegin_EA49D0BA47B97681641F53BFFD8C37FB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_EA49D0BA47B97681641F53BFFD8C37FB
	void OnInterrupted_EA49D0BA47B97681641F53BFFD8C37FB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_EA49D0BA47B97681641F53BFFD8C37FB
	void OnBlendOut_EA49D0BA47B97681641F53BFFD8C37FB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_EA49D0BA47B97681641F53BFFD8C37FB
	void OnCompleted_EA49D0BA47B97681641F53BFFD8C37FB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_EA49D0BA47B97681641F53BFFD8C37FB
	void OnNotifyEnd_295A6FA24031F85EC407EAA817F56D7A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_295A6FA24031F85EC407EAA817F56D7A
	void OnNotifyBegin_295A6FA24031F85EC407EAA817F56D7A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_295A6FA24031F85EC407EAA817F56D7A
	void OnInterrupted_295A6FA24031F85EC407EAA817F56D7A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_295A6FA24031F85EC407EAA817F56D7A
	void OnBlendOut_295A6FA24031F85EC407EAA817F56D7A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_295A6FA24031F85EC407EAA817F56D7A
	void OnCompleted_295A6FA24031F85EC407EAA817F56D7A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_295A6FA24031F85EC407EAA817F56D7A
	void OnNotifyEnd_D74A09384751D471F9EB3FB177B42473(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D74A09384751D471F9EB3FB177B42473
	void OnNotifyBegin_D74A09384751D471F9EB3FB177B42473(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D74A09384751D471F9EB3FB177B42473
	void OnInterrupted_D74A09384751D471F9EB3FB177B42473(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D74A09384751D471F9EB3FB177B42473
	void OnBlendOut_D74A09384751D471F9EB3FB177B42473(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D74A09384751D471F9EB3FB177B42473
	void OnCompleted_D74A09384751D471F9EB3FB177B42473(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D74A09384751D471F9EB3FB177B42473
	void OnNotifyEnd_D3C149F34A9900B7BB6F0B95A0FE6441(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D3C149F34A9900B7BB6F0B95A0FE6441
	void OnNotifyBegin_D3C149F34A9900B7BB6F0B95A0FE6441(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D3C149F34A9900B7BB6F0B95A0FE6441
	void OnInterrupted_D3C149F34A9900B7BB6F0B95A0FE6441(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D3C149F34A9900B7BB6F0B95A0FE6441
	void OnBlendOut_D3C149F34A9900B7BB6F0B95A0FE6441(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D3C149F34A9900B7BB6F0B95A0FE6441
	void OnCompleted_D3C149F34A9900B7BB6F0B95A0FE6441(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D3C149F34A9900B7BB6F0B95A0FE6441
	void OnNotifyEnd_D26DC77543EE3553DB22A4B9BE52040B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D26DC77543EE3553DB22A4B9BE52040B
	void OnNotifyBegin_D26DC77543EE3553DB22A4B9BE52040B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D26DC77543EE3553DB22A4B9BE52040B
	void OnInterrupted_D26DC77543EE3553DB22A4B9BE52040B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D26DC77543EE3553DB22A4B9BE52040B
	void OnBlendOut_D26DC77543EE3553DB22A4B9BE52040B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D26DC77543EE3553DB22A4B9BE52040B
	void OnCompleted_D26DC77543EE3553DB22A4B9BE52040B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D26DC77543EE3553DB22A4B9BE52040B
	void OnNotifyEnd_B1139CE24EB14116F48A8B8029485683(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_B1139CE24EB14116F48A8B8029485683
	void OnNotifyBegin_B1139CE24EB14116F48A8B8029485683(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_B1139CE24EB14116F48A8B8029485683
	void OnInterrupted_B1139CE24EB14116F48A8B8029485683(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_B1139CE24EB14116F48A8B8029485683
	void OnBlendOut_B1139CE24EB14116F48A8B8029485683(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_B1139CE24EB14116F48A8B8029485683
	void OnCompleted_B1139CE24EB14116F48A8B8029485683(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_B1139CE24EB14116F48A8B8029485683
	void OnNotifyEnd_FFA2097F429F37282A5E5AAA9D734C3D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_FFA2097F429F37282A5E5AAA9D734C3D
	void OnNotifyBegin_FFA2097F429F37282A5E5AAA9D734C3D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_FFA2097F429F37282A5E5AAA9D734C3D
	void OnInterrupted_FFA2097F429F37282A5E5AAA9D734C3D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_FFA2097F429F37282A5E5AAA9D734C3D
	void OnBlendOut_FFA2097F429F37282A5E5AAA9D734C3D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_FFA2097F429F37282A5E5AAA9D734C3D
	void OnCompleted_FFA2097F429F37282A5E5AAA9D734C3D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_FFA2097F429F37282A5E5AAA9D734C3D
	void OnNotifyEnd_8CF32E644FFA62359AD9F09975AD3A89(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_8CF32E644FFA62359AD9F09975AD3A89
	void OnNotifyBegin_8CF32E644FFA62359AD9F09975AD3A89(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_8CF32E644FFA62359AD9F09975AD3A89
	void OnInterrupted_8CF32E644FFA62359AD9F09975AD3A89(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_8CF32E644FFA62359AD9F09975AD3A89
	void OnBlendOut_8CF32E644FFA62359AD9F09975AD3A89(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_8CF32E644FFA62359AD9F09975AD3A89
	void OnCompleted_8CF32E644FFA62359AD9F09975AD3A89(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_8CF32E644FFA62359AD9F09975AD3A89
	void OnNotifyEnd_23CAF4D944CE6D656BBE9E838BB9478B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_23CAF4D944CE6D656BBE9E838BB9478B
	void OnNotifyBegin_23CAF4D944CE6D656BBE9E838BB9478B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_23CAF4D944CE6D656BBE9E838BB9478B
	void OnInterrupted_23CAF4D944CE6D656BBE9E838BB9478B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_23CAF4D944CE6D656BBE9E838BB9478B
	void OnBlendOut_23CAF4D944CE6D656BBE9E838BB9478B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_23CAF4D944CE6D656BBE9E838BB9478B
	void OnCompleted_23CAF4D944CE6D656BBE9E838BB9478B(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_23CAF4D944CE6D656BBE9E838BB9478B
	void OnNotifyEnd_FE9C0BFE472101A2C46976A6E325D9E5(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_FE9C0BFE472101A2C46976A6E325D9E5
	void OnNotifyBegin_FE9C0BFE472101A2C46976A6E325D9E5(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_FE9C0BFE472101A2C46976A6E325D9E5
	void OnInterrupted_FE9C0BFE472101A2C46976A6E325D9E5(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_FE9C0BFE472101A2C46976A6E325D9E5
	void OnBlendOut_FE9C0BFE472101A2C46976A6E325D9E5(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_FE9C0BFE472101A2C46976A6E325D9E5
	void OnCompleted_FE9C0BFE472101A2C46976A6E325D9E5(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_FE9C0BFE472101A2C46976A6E325D9E5
	void OnNotifyEnd_0451BCA24BBBAF5C49F8E2A90EF5A846(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_0451BCA24BBBAF5C49F8E2A90EF5A846
	void OnNotifyBegin_0451BCA24BBBAF5C49F8E2A90EF5A846(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_0451BCA24BBBAF5C49F8E2A90EF5A846
	void OnInterrupted_0451BCA24BBBAF5C49F8E2A90EF5A846(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_0451BCA24BBBAF5C49F8E2A90EF5A846
	void OnBlendOut_0451BCA24BBBAF5C49F8E2A90EF5A846(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_0451BCA24BBBAF5C49F8E2A90EF5A846
	void OnCompleted_0451BCA24BBBAF5C49F8E2A90EF5A846(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_0451BCA24BBBAF5C49F8E2A90EF5A846
	void OnNotifyEnd_D630254342147B53DE4449AE0036F463(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D630254342147B53DE4449AE0036F463
	void OnNotifyBegin_D630254342147B53DE4449AE0036F463(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D630254342147B53DE4449AE0036F463
	void OnInterrupted_D630254342147B53DE4449AE0036F463(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D630254342147B53DE4449AE0036F463
	void OnBlendOut_D630254342147B53DE4449AE0036F463(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D630254342147B53DE4449AE0036F463
	void OnCompleted_D630254342147B53DE4449AE0036F463(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D630254342147B53DE4449AE0036F463
	void OnNotifyEnd_A4AEFB3A40ECCA50E2FEC18A6FB631B7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_A4AEFB3A40ECCA50E2FEC18A6FB631B7
	void OnNotifyBegin_A4AEFB3A40ECCA50E2FEC18A6FB631B7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_A4AEFB3A40ECCA50E2FEC18A6FB631B7
	void OnInterrupted_A4AEFB3A40ECCA50E2FEC18A6FB631B7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_A4AEFB3A40ECCA50E2FEC18A6FB631B7
	void OnBlendOut_A4AEFB3A40ECCA50E2FEC18A6FB631B7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_A4AEFB3A40ECCA50E2FEC18A6FB631B7
	void OnCompleted_A4AEFB3A40ECCA50E2FEC18A6FB631B7(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_A4AEFB3A40ECCA50E2FEC18A6FB631B7
	void OnNotifyEnd_636C3B0D42413949BEC9B5B10D85B87D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_636C3B0D42413949BEC9B5B10D85B87D
	void OnNotifyBegin_636C3B0D42413949BEC9B5B10D85B87D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_636C3B0D42413949BEC9B5B10D85B87D
	void OnInterrupted_636C3B0D42413949BEC9B5B10D85B87D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_636C3B0D42413949BEC9B5B10D85B87D
	void OnBlendOut_636C3B0D42413949BEC9B5B10D85B87D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_636C3B0D42413949BEC9B5B10D85B87D
	void OnCompleted_636C3B0D42413949BEC9B5B10D85B87D(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_636C3B0D42413949BEC9B5B10D85B87D
	void OnNotifyEnd_449B2FAA496C1773F05F4A8FB87E81D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_449B2FAA496C1773F05F4A8FB87E81D8
	void OnNotifyBegin_449B2FAA496C1773F05F4A8FB87E81D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_449B2FAA496C1773F05F4A8FB87E81D8
	void OnInterrupted_449B2FAA496C1773F05F4A8FB87E81D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_449B2FAA496C1773F05F4A8FB87E81D8
	void OnBlendOut_449B2FAA496C1773F05F4A8FB87E81D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_449B2FAA496C1773F05F4A8FB87E81D8
	void OnCompleted_449B2FAA496C1773F05F4A8FB87E81D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_449B2FAA496C1773F05F4A8FB87E81D8
	void OnNotifyEnd_004F3C3841E31B4025CAC3A740A1E014(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_004F3C3841E31B4025CAC3A740A1E014
	void OnNotifyBegin_004F3C3841E31B4025CAC3A740A1E014(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_004F3C3841E31B4025CAC3A740A1E014
	void OnInterrupted_004F3C3841E31B4025CAC3A740A1E014(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_004F3C3841E31B4025CAC3A740A1E014
	void OnBlendOut_004F3C3841E31B4025CAC3A740A1E014(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_004F3C3841E31B4025CAC3A740A1E014
	void OnCompleted_004F3C3841E31B4025CAC3A740A1E014(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_004F3C3841E31B4025CAC3A740A1E014
	void OnNotifyEnd_ABDF0BB940234A2342CA259B09F13804(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_ABDF0BB940234A2342CA259B09F13804
	void OnNotifyBegin_ABDF0BB940234A2342CA259B09F13804(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_ABDF0BB940234A2342CA259B09F13804
	void OnInterrupted_ABDF0BB940234A2342CA259B09F13804(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_ABDF0BB940234A2342CA259B09F13804
	void OnBlendOut_ABDF0BB940234A2342CA259B09F13804(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_ABDF0BB940234A2342CA259B09F13804
	void OnCompleted_ABDF0BB940234A2342CA259B09F13804(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_ABDF0BB940234A2342CA259B09F13804
	void OnNotifyEnd_A7A52E1D4E9B9CE18781ECAA68780875(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_A7A52E1D4E9B9CE18781ECAA68780875
	void OnNotifyBegin_A7A52E1D4E9B9CE18781ECAA68780875(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_A7A52E1D4E9B9CE18781ECAA68780875
	void OnInterrupted_A7A52E1D4E9B9CE18781ECAA68780875(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_A7A52E1D4E9B9CE18781ECAA68780875
	void OnBlendOut_A7A52E1D4E9B9CE18781ECAA68780875(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_A7A52E1D4E9B9CE18781ECAA68780875
	void OnCompleted_A7A52E1D4E9B9CE18781ECAA68780875(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_A7A52E1D4E9B9CE18781ECAA68780875
	void OnNotifyEnd_190693E441B6B08CD2872594842A320F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_190693E441B6B08CD2872594842A320F
	void OnNotifyBegin_190693E441B6B08CD2872594842A320F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_190693E441B6B08CD2872594842A320F
	void OnInterrupted_190693E441B6B08CD2872594842A320F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_190693E441B6B08CD2872594842A320F
	void OnBlendOut_190693E441B6B08CD2872594842A320F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_190693E441B6B08CD2872594842A320F
	void OnCompleted_190693E441B6B08CD2872594842A320F(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_190693E441B6B08CD2872594842A320F
	void OnNotifyEnd_332CD0764766D981C5184FB0B62EB954(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_332CD0764766D981C5184FB0B62EB954
	void OnNotifyBegin_332CD0764766D981C5184FB0B62EB954(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_332CD0764766D981C5184FB0B62EB954
	void OnInterrupted_332CD0764766D981C5184FB0B62EB954(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_332CD0764766D981C5184FB0B62EB954
	void OnBlendOut_332CD0764766D981C5184FB0B62EB954(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_332CD0764766D981C5184FB0B62EB954
	void OnCompleted_332CD0764766D981C5184FB0B62EB954(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_332CD0764766D981C5184FB0B62EB954
	void OnNotifyEnd_4D2E2DB8411D5EC5F5DF4F86C81B3F41(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_4D2E2DB8411D5EC5F5DF4F86C81B3F41
	void OnNotifyBegin_4D2E2DB8411D5EC5F5DF4F86C81B3F41(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_4D2E2DB8411D5EC5F5DF4F86C81B3F41
	void OnInterrupted_4D2E2DB8411D5EC5F5DF4F86C81B3F41(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_4D2E2DB8411D5EC5F5DF4F86C81B3F41
	void OnBlendOut_4D2E2DB8411D5EC5F5DF4F86C81B3F41(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_4D2E2DB8411D5EC5F5DF4F86C81B3F41
	void OnCompleted_4D2E2DB8411D5EC5F5DF4F86C81B3F41(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_4D2E2DB8411D5EC5F5DF4F86C81B3F41
	void OnNotifyEnd_C278A5424348C67B37741F867943462E(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_C278A5424348C67B37741F867943462E
	void OnNotifyBegin_C278A5424348C67B37741F867943462E(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_C278A5424348C67B37741F867943462E
	void OnInterrupted_C278A5424348C67B37741F867943462E(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_C278A5424348C67B37741F867943462E
	void OnBlendOut_C278A5424348C67B37741F867943462E(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_C278A5424348C67B37741F867943462E
	void OnCompleted_C278A5424348C67B37741F867943462E(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_C278A5424348C67B37741F867943462E
	void OnNotifyEnd_6608D1E9419D6C0EA555ADA269743DBA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_6608D1E9419D6C0EA555ADA269743DBA
	void OnNotifyBegin_6608D1E9419D6C0EA555ADA269743DBA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_6608D1E9419D6C0EA555ADA269743DBA
	void OnInterrupted_6608D1E9419D6C0EA555ADA269743DBA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_6608D1E9419D6C0EA555ADA269743DBA
	void OnBlendOut_6608D1E9419D6C0EA555ADA269743DBA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_6608D1E9419D6C0EA555ADA269743DBA
	void OnCompleted_6608D1E9419D6C0EA555ADA269743DBA(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_6608D1E9419D6C0EA555ADA269743DBA
	void OnNotifyEnd_3973928C4E3F042C8DAB0CAEF700C3C1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_3973928C4E3F042C8DAB0CAEF700C3C1
	void OnNotifyBegin_3973928C4E3F042C8DAB0CAEF700C3C1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_3973928C4E3F042C8DAB0CAEF700C3C1
	void OnInterrupted_3973928C4E3F042C8DAB0CAEF700C3C1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_3973928C4E3F042C8DAB0CAEF700C3C1
	void OnBlendOut_3973928C4E3F042C8DAB0CAEF700C3C1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_3973928C4E3F042C8DAB0CAEF700C3C1
	void OnCompleted_3973928C4E3F042C8DAB0CAEF700C3C1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_3973928C4E3F042C8DAB0CAEF700C3C1
	void OnNotifyEnd_AB840EE543E87C2AB397589B544D0BEB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_AB840EE543E87C2AB397589B544D0BEB
	void OnNotifyBegin_AB840EE543E87C2AB397589B544D0BEB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_AB840EE543E87C2AB397589B544D0BEB
	void OnInterrupted_AB840EE543E87C2AB397589B544D0BEB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_AB840EE543E87C2AB397589B544D0BEB
	void OnBlendOut_AB840EE543E87C2AB397589B544D0BEB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_AB840EE543E87C2AB397589B544D0BEB
	void OnCompleted_AB840EE543E87C2AB397589B544D0BEB(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_AB840EE543E87C2AB397589B544D0BEB
	void OnNotifyEnd_F2ECCA8C478E0E296A3AC18008E21414(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_F2ECCA8C478E0E296A3AC18008E21414
	void OnNotifyBegin_F2ECCA8C478E0E296A3AC18008E21414(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_F2ECCA8C478E0E296A3AC18008E21414
	void OnInterrupted_F2ECCA8C478E0E296A3AC18008E21414(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_F2ECCA8C478E0E296A3AC18008E21414
	void OnBlendOut_F2ECCA8C478E0E296A3AC18008E21414(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_F2ECCA8C478E0E296A3AC18008E21414
	void OnCompleted_F2ECCA8C478E0E296A3AC18008E21414(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_F2ECCA8C478E0E296A3AC18008E21414
	void OnNotifyEnd_7981FDEC4328B74EA96F5DB3D578C85C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_7981FDEC4328B74EA96F5DB3D578C85C
	void OnNotifyBegin_7981FDEC4328B74EA96F5DB3D578C85C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_7981FDEC4328B74EA96F5DB3D578C85C
	void OnInterrupted_7981FDEC4328B74EA96F5DB3D578C85C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_7981FDEC4328B74EA96F5DB3D578C85C
	void OnBlendOut_7981FDEC4328B74EA96F5DB3D578C85C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_7981FDEC4328B74EA96F5DB3D578C85C
	void OnCompleted_7981FDEC4328B74EA96F5DB3D578C85C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_7981FDEC4328B74EA96F5DB3D578C85C
	void OnNotifyEnd_7C83ED444E0D3F007049B8A33DCCE4F6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_7C83ED444E0D3F007049B8A33DCCE4F6
	void OnNotifyBegin_7C83ED444E0D3F007049B8A33DCCE4F6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_7C83ED444E0D3F007049B8A33DCCE4F6
	void OnInterrupted_7C83ED444E0D3F007049B8A33DCCE4F6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_7C83ED444E0D3F007049B8A33DCCE4F6
	void OnBlendOut_7C83ED444E0D3F007049B8A33DCCE4F6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_7C83ED444E0D3F007049B8A33DCCE4F6
	void OnCompleted_7C83ED444E0D3F007049B8A33DCCE4F6(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_7C83ED444E0D3F007049B8A33DCCE4F6
	void OnNotifyEnd_3D743938408663BDA62AF991CCB7CCFF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_3D743938408663BDA62AF991CCB7CCFF
	void OnNotifyBegin_3D743938408663BDA62AF991CCB7CCFF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_3D743938408663BDA62AF991CCB7CCFF
	void OnInterrupted_3D743938408663BDA62AF991CCB7CCFF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_3D743938408663BDA62AF991CCB7CCFF
	void OnBlendOut_3D743938408663BDA62AF991CCB7CCFF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_3D743938408663BDA62AF991CCB7CCFF
	void OnCompleted_3D743938408663BDA62AF991CCB7CCFF(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_3D743938408663BDA62AF991CCB7CCFF
	void OnNotifyEnd_D444624748350EBB507E96AEBBE518A8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_D444624748350EBB507E96AEBBE518A8
	void OnNotifyBegin_D444624748350EBB507E96AEBBE518A8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_D444624748350EBB507E96AEBBE518A8
	void OnInterrupted_D444624748350EBB507E96AEBBE518A8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_D444624748350EBB507E96AEBBE518A8
	void OnBlendOut_D444624748350EBB507E96AEBBE518A8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_D444624748350EBB507E96AEBBE518A8
	void OnCompleted_D444624748350EBB507E96AEBBE518A8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_D444624748350EBB507E96AEBBE518A8
	void InpActEvt_Ghost Ram_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Ghost Ram_K2Node_InputActionEvent_3
	void InpActEvt_Sprint_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Sprint_K2Node_InputActionEvent_2
	void InpActEvt_Sprint_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Sprint_K2Node_InputActionEvent_1
	void OnNotifyEnd_DD9FB5984829CD7BC452DB90AFDCE5F1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_DD9FB5984829CD7BC452DB90AFDCE5F1
	void OnNotifyBegin_DD9FB5984829CD7BC452DB90AFDCE5F1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_DD9FB5984829CD7BC452DB90AFDCE5F1
	void OnInterrupted_DD9FB5984829CD7BC452DB90AFDCE5F1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_DD9FB5984829CD7BC452DB90AFDCE5F1
	void OnBlendOut_DD9FB5984829CD7BC452DB90AFDCE5F1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_DD9FB5984829CD7BC452DB90AFDCE5F1
	void OnCompleted_DD9FB5984829CD7BC452DB90AFDCE5F1(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_DD9FB5984829CD7BC452DB90AFDCE5F1
	void OnNotifyEnd_F344F5564650F9A358E886BBE9247A66(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_F344F5564650F9A358E886BBE9247A66
	void OnNotifyBegin_F344F5564650F9A358E886BBE9247A66(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_F344F5564650F9A358E886BBE9247A66
	void OnInterrupted_F344F5564650F9A358E886BBE9247A66(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_F344F5564650F9A358E886BBE9247A66
	void OnBlendOut_F344F5564650F9A358E886BBE9247A66(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_F344F5564650F9A358E886BBE9247A66
	void OnCompleted_F344F5564650F9A358E886BBE9247A66(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_F344F5564650F9A358E886BBE9247A66
	void InpActEvt_Shift_J_K2Node_InputKeyEvent_6(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Shift_J_K2Node_InputKeyEvent_6
	void InpActEvt_Ctrl_J_K2Node_InputKeyEvent_5(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Ctrl_J_K2Node_InputKeyEvent_5
	void OnNotifyEnd_73C17AA04D9AA360FCA9BA984C41B28A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_73C17AA04D9AA360FCA9BA984C41B28A
	void OnNotifyBegin_73C17AA04D9AA360FCA9BA984C41B28A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_73C17AA04D9AA360FCA9BA984C41B28A
	void OnInterrupted_73C17AA04D9AA360FCA9BA984C41B28A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_73C17AA04D9AA360FCA9BA984C41B28A
	void OnBlendOut_73C17AA04D9AA360FCA9BA984C41B28A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_73C17AA04D9AA360FCA9BA984C41B28A
	void OnCompleted_73C17AA04D9AA360FCA9BA984C41B28A(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_73C17AA04D9AA360FCA9BA984C41B28A
	void OnNotifyEnd_19BC64D6415ACA92CE6B5BB1455B7C51(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_19BC64D6415ACA92CE6B5BB1455B7C51
	void OnNotifyBegin_19BC64D6415ACA92CE6B5BB1455B7C51(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_19BC64D6415ACA92CE6B5BB1455B7C51
	void OnInterrupted_19BC64D6415ACA92CE6B5BB1455B7C51(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_19BC64D6415ACA92CE6B5BB1455B7C51
	void OnBlendOut_19BC64D6415ACA92CE6B5BB1455B7C51(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_19BC64D6415ACA92CE6B5BB1455B7C51
	void OnCompleted_19BC64D6415ACA92CE6B5BB1455B7C51(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_19BC64D6415ACA92CE6B5BB1455B7C51
	void OnNotifyEnd_459F95784FD7D4D31155C39A9E5DE200(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_459F95784FD7D4D31155C39A9E5DE200
	void OnNotifyBegin_459F95784FD7D4D31155C39A9E5DE200(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_459F95784FD7D4D31155C39A9E5DE200
	void OnInterrupted_459F95784FD7D4D31155C39A9E5DE200(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_459F95784FD7D4D31155C39A9E5DE200
	void OnBlendOut_459F95784FD7D4D31155C39A9E5DE200(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_459F95784FD7D4D31155C39A9E5DE200
	void OnCompleted_459F95784FD7D4D31155C39A9E5DE200(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_459F95784FD7D4D31155C39A9E5DE200
	void OnNotifyEnd_3E3B467048B437FE9C4044B2DC145040(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_3E3B467048B437FE9C4044B2DC145040
	void OnNotifyBegin_3E3B467048B437FE9C4044B2DC145040(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_3E3B467048B437FE9C4044B2DC145040
	void OnInterrupted_3E3B467048B437FE9C4044B2DC145040(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_3E3B467048B437FE9C4044B2DC145040
	void OnBlendOut_3E3B467048B437FE9C4044B2DC145040(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_3E3B467048B437FE9C4044B2DC145040
	void OnCompleted_3E3B467048B437FE9C4044B2DC145040(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_3E3B467048B437FE9C4044B2DC145040
	void OnNotifyEnd_6BB7A501402CB09A8F44B6A513B8794C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_6BB7A501402CB09A8F44B6A513B8794C
	void OnNotifyBegin_6BB7A501402CB09A8F44B6A513B8794C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_6BB7A501402CB09A8F44B6A513B8794C
	void OnInterrupted_6BB7A501402CB09A8F44B6A513B8794C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_6BB7A501402CB09A8F44B6A513B8794C
	void OnBlendOut_6BB7A501402CB09A8F44B6A513B8794C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_6BB7A501402CB09A8F44B6A513B8794C
	void OnCompleted_6BB7A501402CB09A8F44B6A513B8794C(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_6BB7A501402CB09A8F44B6A513B8794C
	void OnNotifyEnd_960E19F9486A9CDA509FF6BC78A975D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyEnd_960E19F9486A9CDA509FF6BC78A975D8
	void OnNotifyBegin_960E19F9486A9CDA509FF6BC78A975D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnNotifyBegin_960E19F9486A9CDA509FF6BC78A975D8
	void OnInterrupted_960E19F9486A9CDA509FF6BC78A975D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnInterrupted_960E19F9486A9CDA509FF6BC78A975D8
	void OnBlendOut_960E19F9486A9CDA509FF6BC78A975D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnBlendOut_960E19F9486A9CDA509FF6BC78A975D8
	void OnCompleted_960E19F9486A9CDA509FF6BC78A975D8(struct FName NotifyName); // Function BP_Hunter.BP_Hunter_C.OnCompleted_960E19F9486A9CDA509FF6BC78A975D8
	void InpActEvt_Ctrl_G_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Ctrl_G_K2Node_InputKeyEvent_4
	void InpActEvt_Alt_Divide_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Alt_Divide_K2Node_InputKeyEvent_3
	void InpActEvt_Ctrl_Divide_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Ctrl_Divide_K2Node_InputKeyEvent_2
	void InpActEvt_Zero_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_Hunter.BP_Hunter_C.InpActEvt_Zero_K2Node_InputKeyEvent_1
	void ConfigureLevelprop(); // Function BP_Hunter.BP_Hunter_C.ConfigureLevelprop
	void Damage(float Amount, struct AActor* ResponsibleActor, char DamageMethod method, bool Capture?, bool Direct Hit?, struct FVector Location); // Function BP_Hunter.BP_Hunter_C.Damage
	void NRSuccessfulRevive_Int(struct AActor* DeadHunter, struct AActor* GoodSamaritan); // Function BP_Hunter.BP_Hunter_C.NRSuccessfulRevive_Int
	void ClearMyHunterRez_UI(); // Function BP_Hunter.BP_Hunter_C.ClearMyHunterRez_UI
	void InterruptDefibRevive_UI(); // Function BP_Hunter.BP_Hunter_C.InterruptDefibRevive_UI
	void FindAndRemoveMyTrap_Int(struct AActor* Trap); // Function BP_Hunter.BP_Hunter_C.FindAndRemoveMyTrap_Int
	void UIInteract_Int(); // Function BP_Hunter.BP_Hunter_C.UIInteract_Int
	void HitFaceFullscreenEffect_Int(struct UMaterialInstance* FullScreenMaterial); // Function BP_Hunter.BP_Hunter_C.HitFaceFullscreenEffect_Int
	void OC_HitFaceFullscreenEffect(struct UMaterialInstance* Screen Effect Material); // Function BP_Hunter.BP_Hunter_C.OC_HitFaceFullscreenEffect
	void ReceiveDestroyed(); // Function BP_Hunter.BP_Hunter_C.ReceiveDestroyed
	void OCHitmarkers_Hunter_Int(); // Function BP_Hunter.BP_Hunter_C.OCHitmarkers_Hunter_Int
	void RamHitCooldownSet(); // Function BP_Hunter.BP_Hunter_C.RamHitCooldownSet
	void Server_BeenSantaGrabbed(struct AActor* PropThatGrabbedYou); // Function BP_Hunter.BP_Hunter_C.Server_BeenSantaGrabbed
	void OC_BeenSantaGrabbed(); // Function BP_Hunter.BP_Hunter_C.OC_BeenSantaGrabbed
	void MC_BeenSantaGrabbed(struct AActor* Prop); // Function BP_Hunter.BP_Hunter_C.MC_BeenSantaGrabbed
	void Server_SantaGrabDetach(struct AActor* PropThatGrabbedYou, bool NeedSafeTransform, struct FVector_NetQuantize SafeTransform); // Function BP_Hunter.BP_Hunter_C.Server_SantaGrabDetach
	void MC_SantaGrabDetached(struct AActor* PropThatGrabbedYou, bool NeedSafeTransform, struct FVector_NetQuantize SafeTransform); // Function BP_Hunter.BP_Hunter_C.MC_SantaGrabDetached
	void CheckPropGrabbedStillValid(); // Function BP_Hunter.BP_Hunter_C.CheckPropGrabbedStillValid
	void TryEndIncapacitate(); // Function BP_Hunter.BP_Hunter_C.TryEndIncapacitate
	void InterruptEmoteIfEmoteActive(); // Function BP_Hunter.BP_Hunter_C.InterruptEmoteIfEmoteActive
	void IncapacitatedError(); // Function BP_Hunter.BP_Hunter_C.IncapacitatedError
	void PlaySpecificEmote(char Hunter_Emotes Emote); // Function BP_Hunter.BP_Hunter_C.PlaySpecificEmote
	void Switch_Generic(char HunterGadgets NewGadget); // Function BP_Hunter.BP_Hunter_C.Switch_Generic
	void PlayInteractAnimation(); // Function BP_Hunter.BP_Hunter_C.PlayInteractAnimation
	void CheckCamcorderEmptyHands(); // Function BP_Hunter.BP_Hunter_C.CheckCamcorderEmptyHands
	void Switch_CamCorder(); // Function BP_Hunter.BP_Hunter_C.Switch_CamCorder
	void UnequipCamCorder(); // Function BP_Hunter.BP_Hunter_C.UnequipCamCorder
	void NR_CamCorderVisibility(bool  Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_CamCorderVisibility
	void HandleSetHoldingMovement(bool HoldingMovement); // Function BP_Hunter.BP_Hunter_C.HandleSetHoldingMovement
	void Server_SetHoldingMovement(bool Movement); // Function BP_Hunter.BP_Hunter_C.Server_SetHoldingMovement
	void InterruptEmoteUI(bool BlendOut); // Function BP_Hunter.BP_Hunter_C.InterruptEmoteUI
	void NR_GhostSmasher2Visibility(bool  Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_GhostSmasher2Visibility
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Hunter.BP_Hunter_C.ReceiveHit
	void NR_PathfinderTrailRenderForceActivate(bool Active?); // Function BP_Hunter.BP_Hunter_C.NR_PathfinderTrailRenderForceActivate
	void VictoryPose_fromUI_stop(); // Function BP_Hunter.BP_Hunter_C.VictoryPose_fromUI_stop
	void VictoryPose_fromUI(char VictoryPoses VictoryPose); // Function BP_Hunter.BP_Hunter_C.VictoryPose_fromUI
	void Switch_Ghostsmasher2(); // Function BP_Hunter.BP_Hunter_C.Switch_Ghostsmasher2
	void UnequipGhostSmasher2(); // Function BP_Hunter.BP_Hunter_C.UnequipGhostSmasher2
	void BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Hunter.BP_Hunter_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void UnequipFlameThrower(); // Function BP_Hunter.BP_Hunter_C.UnequipFlameThrower
	void NR_FlameThrowerVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_FlameThrowerVisibility
	void Switch Flamethrower(); // Function BP_Hunter.BP_Hunter_C.Switch Flamethrower
	void Hunter_SetFlashlightState(bool On?); // Function BP_Hunter.BP_Hunter_C.Hunter_SetFlashlightState
	void UnequipMedicBox(); // Function BP_Hunter.BP_Hunter_C.UnequipMedicBox
	void NR_MedicBoxVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_MedicBoxVisibility
	void Emote_fromUI(char Hunter_Emotes Emote, bool MainMenu?); // Function BP_Hunter.BP_Hunter_C.Emote_fromUI
	void UnequipRiotShield(); // Function BP_Hunter.BP_Hunter_C.UnequipRiotShield
	void Switch Medic Kit(); // Function BP_Hunter.BP_Hunter_C.Switch Medic Kit
	void Switch Riot Shield(); // Function BP_Hunter.BP_Hunter_C.Switch Riot Shield
	void MC_InterruptEmote(bool BlendOut); // Function BP_Hunter.BP_Hunter_C.MC_InterruptEmote
	void Server_InterruptEmote(bool BlendOut); // Function BP_Hunter.BP_Hunter_C.Server_InterruptEmote
	void InterruptEmote(bool BlendOut); // Function BP_Hunter.BP_Hunter_C.InterruptEmote
	void MC_StartEmote(char Hunter_Emotes Emote To Play); // Function BP_Hunter.BP_Hunter_C.MC_StartEmote
	void Server_StartEmote(char Hunter_Emotes Emote To Play); // Function BP_Hunter.BP_Hunter_C.Server_StartEmote
	void StartEmote(); // Function BP_Hunter.BP_Hunter_C.StartEmote
	void UIInteract(); // Function BP_Hunter.BP_Hunter_C.UIInteract
	void UnequipTrap(); // Function BP_Hunter.BP_Hunter_C.UnequipTrap
	void C4SHideBomb(); // Function BP_Hunter.BP_Hunter_C.C4SHideBomb
	void C4HideDetonator(); // Function BP_Hunter.BP_Hunter_C.C4HideDetonator
	void UnequipC4(); // Function BP_Hunter.BP_Hunter_C.UnequipC4
	void C4ShowBomb(); // Function BP_Hunter.BP_Hunter_C.C4ShowBomb
	void C4ShowDetonator(); // Function BP_Hunter.BP_Hunter_C.C4ShowDetonator
	void UnequipDefib(); // Function BP_Hunter.BP_Hunter_C.UnequipDefib
	void NR_C4Visibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_C4Visibility
	void Switch C4(); // Function BP_Hunter.BP_Hunter_C.Switch C4
	void UnequipPathfinder(); // Function BP_Hunter.BP_Hunter_C.UnequipPathfinder
	void UnequipGrenade(); // Function BP_Hunter.BP_Hunter_C.UnequipGrenade
	void UnequipNailgun(); // Function BP_Hunter.BP_Hunter_C.UnequipNailgun
	void NR_NailgunVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_NailgunVisibility
	void Switch Nailgun(); // Function BP_Hunter.BP_Hunter_C.Switch Nailgun
	void OC_Shadowtrapped(struct FVector_NetQuantize TP Location); // Function BP_Hunter.BP_Hunter_C.OC_Shadowtrapped
	void OC_FreedFromShadowtrap(); // Function BP_Hunter.BP_Hunter_C.OC_FreedFromShadowtrap
	void UnequipProjectX(); // Function BP_Hunter.BP_Hunter_C.UnequipProjectX
	void Hunter_FreedFromShadowtrap(); // Function BP_Hunter.BP_Hunter_C.Hunter_FreedFromShadowtrap
	void Hunter_Shadowtrapped(); // Function BP_Hunter.BP_Hunter_C.Hunter_Shadowtrapped
	void OC_JumpReduced(); // Function BP_Hunter.BP_Hunter_C.OC_JumpReduced
	void HunterWaterDamageUI(); // Function BP_Hunter.BP_Hunter_C.HunterWaterDamageUI
	void Hunter_OceanSlowed(); // Function BP_Hunter.BP_Hunter_C.Hunter_OceanSlowed
	void UnequipSpectroPhone(); // Function BP_Hunter.BP_Hunter_C.UnequipSpectroPhone
	void UnequipSpectralCannon(); // Function BP_Hunter.BP_Hunter_C.UnequipSpectralCannon
	void NR_SpectrophoneVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_SpectrophoneVisibility
	void Switch Spectrophone(); // Function BP_Hunter.BP_Hunter_C.Switch Spectrophone
	void FakeDrawFP(); // Function BP_Hunter.BP_Hunter_C.FakeDrawFP
	void FakeHolsterFP(); // Function BP_Hunter.BP_Hunter_C.FakeHolsterFP
	void UnequipGhostSmasher(); // Function BP_Hunter.BP_Hunter_C.UnequipGhostSmasher
	void UnequipSaltShotgun(); // Function BP_Hunter.BP_Hunter_C.UnequipSaltShotgun
	void UnequipVacuum(); // Function BP_Hunter.BP_Hunter_C.UnequipVacuum
	void Switch_SaltShotgun(); // Function BP_Hunter.BP_Hunter_C.Switch_SaltShotgun
	void NR_ShotgunVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_ShotgunVisibility
	void UnequipSledgeHammer(); // Function BP_Hunter.BP_Hunter_C.UnequipSledgeHammer
	void NR_VacuumVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_VacuumVisibility
	void Switch_Vacuum(); // Function BP_Hunter.BP_Hunter_C.Switch_Vacuum
	void UnequipGrapplingHook(); // Function BP_Hunter.BP_Hunter_C.UnequipGrapplingHook
	void UnequipSniper(); // Function BP_Hunter.BP_Hunter_C.UnequipSniper
	void NR_SwitchToGadget(char HunterGadgets Hunter Gadget); // Function BP_Hunter.BP_Hunter_C.NR_SwitchToGadget
	void NR_GrappleVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_GrappleVisibility
	void Switch_Grapple(); // Function BP_Hunter.BP_Hunter_C.Switch_Grapple
	void NR_SniperVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_SniperVisibility
	void Switch_Sniper(); // Function BP_Hunter.BP_Hunter_C.Switch_Sniper
	void Input_SwitchToGadget(char HunterGadgets Gadget, bool SkipVisibility); // Function BP_Hunter.BP_Hunter_C.Input_SwitchToGadget
	void Switch_SpectralCannon(); // Function BP_Hunter.BP_Hunter_C.Switch_SpectralCannon
	void Switch_Pathfinder(); // Function BP_Hunter.BP_Hunter_C.Switch_Pathfinder
	void Switch_Trap(); // Function BP_Hunter.BP_Hunter_C.Switch_Trap
	void Switch_Grenade(); // Function BP_Hunter.BP_Hunter_C.Switch_Grenade
	void Switch_Ghostsmasher(); // Function BP_Hunter.BP_Hunter_C.Switch_Ghostsmasher
	void Switch_Shield(); // Function BP_Hunter.BP_Hunter_C.Switch_Shield
	void Switch_Defib(); // Function BP_Hunter.BP_Hunter_C.Switch_Defib
	void Switch_ProjectX(); // Function BP_Hunter.BP_Hunter_C.Switch_ProjectX
	void Switch_HarpoonBazooka(); // Function BP_Hunter.BP_Hunter_C.Switch_HarpoonBazooka
	void Switch_Sledgehammer(); // Function BP_Hunter.BP_Hunter_C.Switch_Sledgehammer
	void SwitchOffShield(); // Function BP_Hunter.BP_Hunter_C.SwitchOffShield
	void SwitchToShield(); // Function BP_Hunter.BP_Hunter_C.SwitchToShield
	void UnequipHarpoonBazooka(); // Function BP_Hunter.BP_Hunter_C.UnequipHarpoonBazooka
	void NR_SledgehammerVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_SledgehammerVisibility
	void MC_HideNewFlashlight(); // Function BP_Hunter.BP_Hunter_C.MC_HideNewFlashlight
	void MC_ShowNewFlashlight(); // Function BP_Hunter.BP_Hunter_C.MC_ShowNewFlashlight
	void Server_HideNewFlashlight(); // Function BP_Hunter.BP_Hunter_C.Server_HideNewFlashlight
	void Server_ShowNewFlashlight(); // Function BP_Hunter.BP_Hunter_C.Server_ShowNewFlashlight
	void ShowHideFlashlight(bool Show); // Function BP_Hunter.BP_Hunter_C.ShowHideFlashlight
	void PushLevelprop(struct ALvlProp_C* LvlProp, float Multi); // Function BP_Hunter.BP_Hunter_C.PushLevelprop
	void NR_HarpoonVisibility(bool  Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_HarpoonVisibility
	void Server_OnConveyor(bool OnConveyor?); // Function BP_Hunter.BP_Hunter_C.Server_OnConveyor
	void SetOnConveyor(); // Function BP_Hunter.BP_Hunter_C.SetOnConveyor
	void ClearArrow(); // Function BP_Hunter.BP_Hunter_C.ClearArrow
	void SetArrow(struct UArrowComponent* Arrow, struct UPrimitiveComponent* Overlap); // Function BP_Hunter.BP_Hunter_C.SetArrow
	void Server_EnableInput(struct AMGH_PlayerController_BP_C* NPC, struct ABP_Hunter_C* BPPC); // Function BP_Hunter.BP_Hunter_C.Server_EnableInput
	void SetHasMoved(); // Function BP_Hunter.BP_Hunter_C.SetHasMoved
	void Server_SetHasMoved(); // Function BP_Hunter.BP_Hunter_C.Server_SetHasMoved
	void Server_UpdateSwitchingEqStatus(); // Function BP_Hunter.BP_Hunter_C.Server_UpdateSwitchingEqStatus
	void Server_PushLvlprop(struct ALvlProp_C* LvlProp, float Multi); // Function BP_Hunter.BP_Hunter_C.Server_PushLvlprop
	void LMB_Zap(); // Function BP_Hunter.BP_Hunter_C.LMB_Zap
	void NR_ProjectXVisibility(bool  Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_ProjectXVisibility
	void NR_DefibVisibility(bool  Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_DefibVisibility
	void NR_RiotShieldVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_RiotShieldVisibility
	void NR_GhostsmasherVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_GhostsmasherVisibility
	void MC_SwitchToGadget(char HunterGadgets Hunter Gadget); // Function BP_Hunter.BP_Hunter_C.MC_SwitchToGadget
	void Server_SwitchToGadget(char HunterGadgets Hunter Gadget); // Function BP_Hunter.BP_Hunter_C.Server_SwitchToGadget
	void OC_SaltCircleUI(); // Function BP_Hunter.BP_Hunter_C.OC_SaltCircleUI
	void CrouchCameraInterp(bool  Crouch); // Function BP_Hunter.BP_Hunter_C.CrouchCameraInterp
	void NR_PathfinderVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_PathfinderVisibility
	void InpAxisEvt_Move Forward_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_Hunter.BP_Hunter_C.InpAxisEvt_Move Forward_K2Node_InputAxisEvent_1
	void SetMouseInvertY(bool Invert?); // Function BP_Hunter.BP_Hunter_C.SetMouseInvertY
	void SetMouseInvertX(bool Invert?); // Function BP_Hunter.BP_Hunter_C.SetMouseInvertX
	void SetMotionBlur(float MotionBlur); // Function BP_Hunter.BP_Hunter_C.SetMotionBlur
	void SetCameraFOV(float FOV); // Function BP_Hunter.BP_Hunter_C.SetCameraFOV
	void FORCE_SwitchToEq02(); // Function BP_Hunter.BP_Hunter_C.FORCE_SwitchToEq02
	void FORCE_SwitchToEq01(); // Function BP_Hunter.BP_Hunter_C.FORCE_SwitchToEq01
	void Loadout_SwitchToEq01(bool Quick?); // Function BP_Hunter.BP_Hunter_C.Loadout_SwitchToEq01
	void Loadout_ForceSwitchToEq02(bool Quick); // Function BP_Hunter.BP_Hunter_C.Loadout_ForceSwitchToEq02
	void InpAxisEvt_Move Backward_K2Node_InputAxisEvent_25(float AxisValue); // Function BP_Hunter.BP_Hunter_C.InpAxisEvt_Move Backward_K2Node_InputAxisEvent_25
	void InpAxisEvt_Move Left_K2Node_InputAxisEvent_81(float AxisValue); // Function BP_Hunter.BP_Hunter_C.InpAxisEvt_Move Left_K2Node_InputAxisEvent_81
	void InpAxisEvt_Move Right_K2Node_InputAxisEvent_62(float AxisValue); // Function BP_Hunter.BP_Hunter_C.InpAxisEvt_Move Right_K2Node_InputAxisEvent_62
	void NR_GrenadeVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_GrenadeVisibility
	void NR_LocalSwitchingEquipment(); // Function BP_Hunter.BP_Hunter_C.NR_LocalSwitchingEquipment
	void NR_SpectralCannon_Visibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_SpectralCannon_Visibility
	void Server_SetBeingRezzed?(struct ABP_Hunter_C* Hunter, bool BeingRezzed); // Function BP_Hunter.BP_Hunter_C.Server_SetBeingRezzed?
	void Server_ToggleHunterCam(bool  Go First, struct ABP_Hunter_C* Hunter); // Function BP_Hunter.BP_Hunter_C.Server_ToggleHunterCam
	void InpAxisEvt_Look_K2Node_InputAxisEvent_19(float AxisValue); // Function BP_Hunter.BP_Hunter_C.InpAxisEvt_Look_K2Node_InputAxisEvent_19
	void Input_SwitchToWeapon(); // Function BP_Hunter.BP_Hunter_C.Input_SwitchToWeapon
	void Input_SwitchToEquipment(); // Function BP_Hunter.BP_Hunter_C.Input_SwitchToEquipment
	void MC_UpdateLControl(bool On); // Function BP_Hunter.BP_Hunter_C.MC_UpdateLControl
	void Server_UpdateLControl(bool On); // Function BP_Hunter.BP_Hunter_C.Server_UpdateLControl
	void Server_DestroyActor(struct AActor* Actor); // Function BP_Hunter.BP_Hunter_C.Server_DestroyActor
	void NR Pickup Trap(); // Function BP_Hunter.BP_Hunter_C.NR Pickup Trap
	void NR_TrapVisibility(bool Hide, bool Skip Animation, bool Tick While Hidden); // Function BP_Hunter.BP_Hunter_C.NR_TrapVisibility
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_158(float AxisValue); // Function BP_Hunter.BP_Hunter_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_158
	void PrimaryWeaponVisibilitySync(); // Function BP_Hunter.BP_Hunter_C.PrimaryWeaponVisibilitySync
	void ResetHunterWeaponUI(); // Function BP_Hunter.BP_Hunter_C.ResetHunterWeaponUI
	void MC_InteractAnimation(); // Function BP_Hunter.BP_Hunter_C.MC_InteractAnimation
	void Server_InteractAnimation(); // Function BP_Hunter.BP_Hunter_C.Server_InteractAnimation
	void Stop Vaulting Montage(); // Function BP_Hunter.BP_Hunter_C.Stop Vaulting Montage
	void MC_VaultAnimTP(); // Function BP_Hunter.BP_Hunter_C.MC_VaultAnimTP
	void Server_VaultAnimTP(); // Function BP_Hunter.BP_Hunter_C.Server_VaultAnimTP
	void StopVault(); // Function BP_Hunter.BP_Hunter_C.StopVault
	void Update Constrain Aspect Ratio(); // Function BP_Hunter.BP_Hunter_C.Update Constrain Aspect Ratio
	void EndPhotoMode_Int(); // Function BP_Hunter.BP_Hunter_C.EndPhotoMode_Int
	void StartPhotoMode_Int(); // Function BP_Hunter.BP_Hunter_C.StartPhotoMode_Int
	void DeglowLvlpropAndWidget(); // Function BP_Hunter.BP_Hunter_C.DeglowLvlpropAndWidget
	void DeglowLvlprops(); // Function BP_Hunter.BP_Hunter_C.DeglowLvlprops
	void CheckGhostlyReach(); // Function BP_Hunter.BP_Hunter_C.CheckGhostlyReach
	void ScanningRoutine(); // Function BP_Hunter.BP_Hunter_C.ScanningRoutine
	void BindDoppelgangerLookLoop(); // Function BP_Hunter.BP_Hunter_C.BindDoppelgangerLookLoop
	void PathfinderDetectionLoop(); // Function BP_Hunter.BP_Hunter_C.PathfinderDetectionLoop
	void StartBotPathfinderLoop(); // Function BP_Hunter.BP_Hunter_C.StartBotPathfinderLoop
	void ClearHunterHasShards(); // Function BP_Hunter.BP_Hunter_C.ClearHunterHasShards
	void HunterHasShards(); // Function BP_Hunter.BP_Hunter_C.HunterHasShards
	void MC_HealingAuraHealedVFX(); // Function BP_Hunter.BP_Hunter_C.MC_HealingAuraHealedVFX
	void AddHealthAura(float AddHealth); // Function BP_Hunter.BP_Hunter_C.AddHealthAura
	void HealingAuraLoop(); // Function BP_Hunter.BP_Hunter_C.HealingAuraLoop
	void SetUpHealingAura(); // Function BP_Hunter.BP_Hunter_C.SetUpHealingAura
	void SpectrophoneLoopEvent(); // Function BP_Hunter.BP_Hunter_C.SpectrophoneLoopEvent
	void PerceptionLoop(); // Function BP_Hunter.BP_Hunter_C.PerceptionLoop
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Hunter.BP_Hunter_C.ReceiveEndPlay
	void Set Up Gadget Perk Loops(); // Function BP_Hunter.BP_Hunter_C.Set Up Gadget Perk Loops
	void NR_SetColor(struct ABP_Hunter_C* BPPC, struct FLinearColor NewColor 1, struct FLinearColor NewColor 2, struct FLinearColor NewColor 3, struct FLinearColor NewColor 4); // Function BP_Hunter.BP_Hunter_C.NR_SetColor
	void MC_EnsureThrpGunVisible(struct ABP_Hunter_C* BPHunter); // Function BP_Hunter.BP_Hunter_C.MC_EnsureThrpGunVisible
	void Server_EnsureTHRPGunVisible(struct ABP_Hunter_C* BPHunter); // Function BP_Hunter.BP_Hunter_C.Server_EnsureTHRPGunVisible
	void NC_HideFlashlights(struct ABP_Hunter_C* BP_Hunter, bool Visibility?); // Function BP_Hunter.BP_Hunter_C.NC_HideFlashlights
	void Server_HideFlashlights(struct ABP_Hunter_C* BP_Hunter, bool Visibility?); // Function BP_Hunter.BP_Hunter_C.Server_HideFlashlights
	void OC_SetFirstPersonCamera(); // Function BP_Hunter.BP_Hunter_C.OC_SetFirstPersonCamera
	void OC_SetThirdPersonCamera(); // Function BP_Hunter.BP_Hunter_C.OC_SetThirdPersonCamera
	void OC_GhostHunterCloneSetup(struct FRotator Rotator, struct ABP_Hunter_C* Who Am I Copying); // Function BP_Hunter.BP_Hunter_C.OC_GhostHunterCloneSetup
	void Bind_TimerDetector(); // Function BP_Hunter.BP_Hunter_C.Bind_TimerDetector
	void OC_HunterStartup(); // Function BP_Hunter.BP_Hunter_C.OC_HunterStartup
	void ReceiveBeginPlay(); // Function BP_Hunter.BP_Hunter_C.ReceiveBeginPlay
	void EquipDefaultEquipment(); // Function BP_Hunter.BP_Hunter_C.EquipDefaultEquipment
	void PrintSceneCaptureOffset(); // Function BP_Hunter.BP_Hunter_C.PrintSceneCaptureOffset
	void PrintOffset(); // Function BP_Hunter.BP_Hunter_C.PrintOffset
	void ClearLvlpropPropSelection(); // Function BP_Hunter.BP_Hunter_C.ClearLvlpropPropSelection
	void ReceiveTick(float DeltaSeconds); // Function BP_Hunter.BP_Hunter_C.ReceiveTick
	void K2_OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // Function BP_Hunter.BP_Hunter_C.K2_OnEndCrouch
	void Spectrophone_InterpolatedLoop(); // Function BP_Hunter.BP_Hunter_C.Spectrophone_InterpolatedLoop
	void SetUpSpectrophoneIndicator(); // Function BP_Hunter.BP_Hunter_C.SetUpSpectrophoneIndicator
	void Server_SpectrophoneSound(float Sound); // Function BP_Hunter.BP_Hunter_C.Server_SpectrophoneSound
	void SpawnSpectrophoneSound(); // Function BP_Hunter.BP_Hunter_C.SpawnSpectrophoneSound
	void Spectrophone_Loop(); // Function BP_Hunter.BP_Hunter_C.Spectrophone_Loop
	void ContinueDeadOrbInteract(); // Function BP_Hunter.BP_Hunter_C.ContinueDeadOrbInteract
	void ClearInteractiveHighlights(); // Function BP_Hunter.BP_Hunter_C.ClearInteractiveHighlights
	void DEBUG_DisableEdgeHighlight(bool Enabled?); // Function BP_Hunter.BP_Hunter_C.DEBUG_DisableEdgeHighlight
	void NR_SpawnEctoplasmTrail(bool Tagged?, struct ACharacter* Owner); // Function BP_Hunter.BP_Hunter_C.NR_SpawnEctoplasmTrail
	void ForceSpawnEctoTrail(); // Function BP_Hunter.BP_Hunter_C.ForceSpawnEctoTrail
	void NR_RequestFadeout(struct ABP_EctoplasmTrail_C* Trail); // Function BP_Hunter.BP_Hunter_C.NR_RequestFadeout
	void OC_AddToTrailList(struct ABP_EctoplasmTrail_C* NewEctoplasmTrail); // Function BP_Hunter.BP_Hunter_C.OC_AddToTrailList
	void SpawnEctoplasmTrail(); // Function BP_Hunter.BP_Hunter_C.SpawnEctoplasmTrail
	void Bind_EctoplasmTrailDrop(); // Function BP_Hunter.BP_Hunter_C.Bind_EctoplasmTrailDrop
	void PropPickupSelectionLoop(); // Function BP_Hunter.BP_Hunter_C.PropPickupSelectionLoop
	void NR_AngeredGhostMessage(); // Function BP_Hunter.BP_Hunter_C.NR_AngeredGhostMessage
	void OC_VacuumSuccess(); // Function BP_Hunter.BP_Hunter_C.OC_VacuumSuccess
	void OC_VacuumCompleted(struct ABP_GhostShards_C* Ghost Shards); // Function BP_Hunter.BP_Hunter_C.OC_VacuumCompleted
	void Server_AddBurnToLvlprop(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.Server_AddBurnToLvlprop
	void NR_AddBurnToLvlprop(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.NR_AddBurnToLvlprop
	void Server_AddBurnToProp(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.Server_AddBurnToProp
	void NR_AddBurnToProp(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.NR_AddBurnToProp
	void AI Bot Primary Fire Released(); // Function BP_Hunter.BP_Hunter_C.AI Bot Primary Fire Released
	void AI Bot Primary Fire Pressed(); // Function BP_Hunter.BP_Hunter_C.AI Bot Primary Fire Pressed
	void Server_HitPossessSpirit(struct ABP_PossesSpirit_C* PossessSpirit, char DamageMethod method, int32_t Amount); // Function BP_Hunter.BP_Hunter_C.Server_HitPossessSpirit
	void Server_HitTricksterProp(struct AProp_C* TricksterProp); // Function BP_Hunter.BP_Hunter_C.Server_HitTricksterProp
	void NR_HitTricksterProp(struct AProp_C* TricksterProp); // Function BP_Hunter.BP_Hunter_C.NR_HitTricksterProp
	void NR_HitPossessSpirit(struct ABP_PossesSpirit_C* PossessSpirit, char DamageMethod method, bool OC Needed?); // Function BP_Hunter.BP_Hunter_C.NR_HitPossessSpirit
	void CheckWeaponHeldLoop(); // Function BP_Hunter.BP_Hunter_C.CheckWeaponHeldLoop
	void BindWeapon_CheckHeldLoop(); // Function BP_Hunter.BP_Hunter_C.BindWeapon_CheckHeldLoop
	void SwingAgain(); // Function BP_Hunter.BP_Hunter_C.SwingAgain
	void Server_AddFrostbiteLvlprop(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.Server_AddFrostbiteLvlprop
	void NR_AddFrostbiteLvlprop(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.NR_AddFrostbiteLvlprop
	void Server_AddFrostbite(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.Server_AddFrostbite
	void NR_AddFrostbite(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.NR_AddFrostbite
	void VacuumCompletedInterface(struct ABP_GhostShards_C* GhostShards); // Function BP_Hunter.BP_Hunter_C.VacuumCompletedInterface
	void NR_AddHitmarkers_DamageNumbers(bool Direct Hit?, struct AActor* ActorDamaged, int32_t Damage, bool UseLocation?, struct FVector Location, char HitmarkerType HitmarkerType); // Function BP_Hunter.BP_Hunter_C.NR_AddHitmarkers_DamageNumbers
	void Server_HitApparition(struct ABP_ApparitionGhost_C* Apparition); // Function BP_Hunter.BP_Hunter_C.Server_HitApparition
	void NR_HitApparition(struct ABP_ApparitionGhost_C* Apparition); // Function BP_Hunter.BP_Hunter_C.NR_HitApparition
	void Server_SetNotVacuuming(); // Function BP_Hunter.BP_Hunter_C.Server_SetNotVacuuming
	void Server_SetVacuuming(); // Function BP_Hunter.BP_Hunter_C.Server_SetVacuuming
	void Server_SniperZoomEnd(); // Function BP_Hunter.BP_Hunter_C.Server_SniperZoomEnd
	void Server_SniperZoomStart(); // Function BP_Hunter.BP_Hunter_C.Server_SniperZoomStart
	void OC_AddHitmarkers_DamageNumbers(bool Direct Hit?, struct AActor* ActorDamaged, int32_t Damage, char HitmarkerType HitmarkerType); // Function BP_Hunter.BP_Hunter_C.OC_AddHitmarkers_DamageNumbers
	void SniperZoomEnd(); // Function BP_Hunter.BP_Hunter_C.SniperZoomEnd
	void SniperZoomStart(); // Function BP_Hunter.BP_Hunter_C.SniperZoomStart
	void NR_Hitmarkers(bool Direct Hit?); // Function BP_Hunter.BP_Hunter_C.NR_Hitmarkers
	void OC_AddHitmarkers(bool Direct Hit?); // Function BP_Hunter.BP_Hunter_C.OC_AddHitmarkers
	void Ai_StartFiring(); // Function BP_Hunter.BP_Hunter_C.Ai_StartFiring
	void MC_HarpoonBreak(bool Fast); // Function BP_Hunter.BP_Hunter_C.MC_HarpoonBreak
	void Server_AddScore(struct ABP_Hunter_C* BP Hunter, int32_t +Kills, int32_t +Deaths); // Function BP_Hunter.BP_Hunter_C.Server_AddScore
	void Server_NewHitmarkers(struct ABP_Hunter_C* BP Hunter, bool Direct Hit?); // Function BP_Hunter.BP_Hunter_C.Server_NewHitmarkers
	void Server_HitSpiritForm(struct ABP_SpiritAbility_C* Spirit Form); // Function BP_Hunter.BP_Hunter_C.Server_HitSpiritForm
	void NR_HitSpiritForm(struct ABP_SpiritAbility_C* Spirit Form); // Function BP_Hunter.BP_Hunter_C.NR_HitSpiritForm
	void Server_DestroyLvlProp(struct ALvlProp_C* LvlProp, float Damage, struct FVector_NetQuantize Location); // Function BP_Hunter.BP_Hunter_C.Server_DestroyLvlProp
	void NR_HitLvlprop(struct ALvlProp_C* LvlProp, float Damage, struct FVector_NetQuantize Location); // Function BP_Hunter.BP_Hunter_C.NR_HitLvlprop
	void NR_StopVacuum(); // Function BP_Hunter.BP_Hunter_C.NR_StopVacuum
	void Server_AddUpgradePoint(); // Function BP_Hunter.BP_Hunter_C.Server_AddUpgradePoint
	void NR_AddUpgradePoint(); // Function BP_Hunter.BP_Hunter_C.NR_AddUpgradePoint
	void OC_StopVacuum(); // Function BP_Hunter.BP_Hunter_C.OC_StopVacuum
	void NR_ReportDamageGhost(int32_t Damage Applied, struct FVector_NetQuantize10 Damage Location, struct AProp_C* Prop Damaged, bool Direct Hit?, bool Melee?, char DamageMethod method); // Function BP_Hunter.BP_Hunter_C.NR_ReportDamageGhost
	void Server_DamageGhost(int32_t Damage Applied, struct FVector_NetQuantize10 Damage Location, struct AProp_C* Prop Damaged, bool Direct Hit?, bool Melee?, bool Skip Sound, char DamageMethod method); // Function BP_Hunter.BP_Hunter_C.Server_DamageGhost
	void Server_VacuumSuccessful(struct ABP_GhostShards_C* CrystalShards); // Function BP_Hunter.BP_Hunter_C.Server_VacuumSuccessful
	void Server_StartStopVacuum(bool  START?); // Function BP_Hunter.BP_Hunter_C.Server_StartStopVacuum
	void Server_InitVacuumTicker(); // Function BP_Hunter.BP_Hunter_C.Server_InitVacuumTicker
	void StopVacuum(); // Function BP_Hunter.BP_Hunter_C.StopVacuum
	void NR_HandleSpectralCannonReload(struct ABP_Hunter_C* BP Hunter, float Operation); // Function BP_Hunter.BP_Hunter_C.NR_HandleSpectralCannonReload
	void NR_SpectralCannonReload(float Operation); // Function BP_Hunter.BP_Hunter_C.NR_SpectralCannonReload
	void FORCE_PrimaryReleased(); // Function BP_Hunter.BP_Hunter_C.FORCE_PrimaryReleased
	void FORCE_PrimaryPressed(); // Function BP_Hunter.BP_Hunter_C.FORCE_PrimaryPressed
	void Server_DestroyedConfirmed(struct ABP_Hunter_C* Hunter, struct AMGH_PlayerState_C* DestroyedPlayer); // Function BP_Hunter.BP_Hunter_C.Server_DestroyedConfirmed
	void Server_DamageGhostSimplified(struct UObject* ObjectTarget, float Damage Amount, struct AActor* Responsible Actor, char DamageMethod method, bool Capture?); // Function BP_Hunter.BP_Hunter_C.Server_DamageGhostSimplified
	void Vacuum(bool LessErrors); // Function BP_Hunter.BP_Hunter_C.Vacuum
	void AI_Fire(); // Function BP_Hunter.BP_Hunter_C.AI_Fire
	void Server_SetSimPhysics(struct ALvlProp_C* LvlProp, struct UPrimitiveComponent* TGT, struct FVector Origin); // Function BP_Hunter.BP_Hunter_C.Server_SetSimPhysics
	void ForceThrowGrenade(); // Function BP_Hunter.BP_Hunter_C.ForceThrowGrenade
	void ThrowGrenadeAnimationServer(); // Function BP_Hunter.BP_Hunter_C.ThrowGrenadeAnimationServer
	void ThrowGrenadeAnimationTP(); // Function BP_Hunter.BP_Hunter_C.ThrowGrenadeAnimationTP
	void MC_SetGrenadeThrown(); // Function BP_Hunter.BP_Hunter_C.MC_SetGrenadeThrown
	void ThrowGrenadeAnimation(); // Function BP_Hunter.BP_Hunter_C.ThrowGrenadeAnimation
	void ForceDropGrenade(); // Function BP_Hunter.BP_Hunter_C.ForceDropGrenade
	void NR_NeedReloadGrenade?(); // Function BP_Hunter.BP_Hunter_C.NR_NeedReloadGrenade?
	void OC_CheckIfNeedToReloadGL(); // Function BP_Hunter.BP_Hunter_C.OC_CheckIfNeedToReloadGL
	void ForceReleaseGrenade(); // Function BP_Hunter.BP_Hunter_C.ForceReleaseGrenade
	void ThrowGrenade(); // Function BP_Hunter.BP_Hunter_C.ThrowGrenade
	void OC_AttachGrenade(struct ABP_Grenade_C* Grenade); // Function BP_Hunter.BP_Hunter_C.OC_AttachGrenade
	void NR_ReloadGrenadeLauncher(); // Function BP_Hunter.BP_Hunter_C.NR_ReloadGrenadeLauncher
	void Reload_GrenadeLauncher(); // Function BP_Hunter.BP_Hunter_C.Reload_GrenadeLauncher
	void Server_SpawnGrenade(struct ABP_Hunter_C* BPPC_Instigator, struct FTransform XForm); // Function BP_Hunter.BP_Hunter_C.Server_SpawnGrenade
	void Server_SetCookingNade(bool  YES); // Function BP_Hunter.BP_Hunter_C.Server_SetCookingNade
	void OC_ClearedToReleaseNade(); // Function BP_Hunter.BP_Hunter_C.OC_ClearedToReleaseNade
	void OC_SetCanGrenade(); // Function BP_Hunter.BP_Hunter_C.OC_SetCanGrenade
	void Server_ActivateProjectile(struct FVector_NetQuantize10 Location, struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.Server_ActivateProjectile
	void BeginThrowingGrenade(); // Function BP_Hunter.BP_Hunter_C.BeginThrowingGrenade
	void StartCookingGrenade(); // Function BP_Hunter.BP_Hunter_C.StartCookingGrenade
	void Server_SetGrenadeThrown(); // Function BP_Hunter.BP_Hunter_C.Server_SetGrenadeThrown
	void NR_ChainLightningEffect(struct AProp_C* Direct Hit Ghost, struct TArray<struct AProp_C*>& Chain Hit Ghosts); // Function BP_Hunter.BP_Hunter_C.NR_ChainLightningEffect
	void MC_ChainLightningEffect(struct AProp_C* Direct Hit Ghost, struct TArray<struct AProp_C*>& Chain Hit Ghosts); // Function BP_Hunter.BP_Hunter_C.MC_ChainLightningEffect
	void Server_MeleeChainLightning(struct AProp_C* Direct Hit Ghost, struct TArray<struct AProp_C*>& Chain Hit Ghosts); // Function BP_Hunter.BP_Hunter_C.Server_MeleeChainLightning
	void MeleeChainLightning(struct AProp_C* Direct Hit Ghost); // Function BP_Hunter.BP_Hunter_C.MeleeChainLightning
	void MC_GhostSmasher_Shield_Toggle(bool Shield Up); // Function BP_Hunter.BP_Hunter_C.MC_GhostSmasher_Shield_Toggle
	void Server_GhostSmasher_Shield_Toggle(bool Shield Up); // Function BP_Hunter.BP_Hunter_C.Server_GhostSmasher_Shield_Toggle
	void GhostSmasher_Shield_Toggle(bool ShieldUp); // Function BP_Hunter.BP_Hunter_C.GhostSmasher_Shield_Toggle
	void Server_LvlpropHitGhostSmasher(struct FVector_NetQuantize10 Hit Location, struct FVector_NetQuantize10 Hit Normal); // Function BP_Hunter.BP_Hunter_C.Server_LvlpropHitGhostSmasher
	void NR_PlayGhostsmasherSwingSound(); // Function BP_Hunter.BP_Hunter_C.NR_PlayGhostsmasherSwingSound
	void TryMeleeSwing(); // Function BP_Hunter.BP_Hunter_C.TryMeleeSwing
	void Server_MeleeAttackCancelled(); // Function BP_Hunter.BP_Hunter_C.Server_MeleeAttackCancelled
	void Server_HitHunterAsSuperDoppel(struct ABP_Hunter_C* BP Hunter); // Function BP_Hunter.BP_Hunter_C.Server_HitHunterAsSuperDoppel
	void Server_LvlpropHitChunks(struct FVector_NetQuantize10 Hit Location, struct FVector_NetQuantize10 Hit Normal); // Function BP_Hunter.BP_Hunter_C.Server_LvlpropHitChunks
	void MC_PlayMeleeSound(); // Function BP_Hunter.BP_Hunter_C.MC_PlayMeleeSound
	void Server_SetMeleeAttacking?(); // Function BP_Hunter.BP_Hunter_C.Server_SetMeleeAttacking?
	void MC_MeleeDamageVFX(struct FVector_NetQuantize10 Location, struct AActor* Attach To, struct FVector_NetQuantize10 HitNormal); // Function BP_Hunter.BP_Hunter_C.MC_MeleeDamageVFX
	void Server_MeleeDamageVFX(struct FVector_NetQuantize10 Location, struct AActor* Attach To, struct FVector_NetQuantize10 HitNormal); // Function BP_Hunter.BP_Hunter_C.Server_MeleeDamageVFX
	void Server_DamageGenerator(struct AProp_C* Who Done It (Prop), struct APawn* Who Done It (Pawn), struct ABP_Generator_C* BP Generator, float Damage); // Function BP_Hunter.BP_Hunter_C.Server_DamageGenerator
	void MC_SetVisibility(struct USceneComponent* Scene Component, bool  Visible); // Function BP_Hunter.BP_Hunter_C.MC_SetVisibility
	void MC_PunchHitSound(bool Hit, struct FVector Vector, struct ABP_Hunter_C* BPPC, bool Quiet?); // Function BP_Hunter.BP_Hunter_C.MC_PunchHitSound
	void MC_Trap_TP_ThrowPickupAnim(bool  Pickup(False)); // Function BP_Hunter.BP_Hunter_C.MC_Trap_TP_ThrowPickupAnim
	void Server_Trap_TP_ThrowPickupAnim(bool  Pickup(False)); // Function BP_Hunter.BP_Hunter_C.Server_Trap_TP_ThrowPickupAnim
	void MC_Set_trap_ammo(float New Value); // Function BP_Hunter.BP_Hunter_C.MC_Set_trap_ammo
	void Server_Set_trap_ammo(float New Value); // Function BP_Hunter.BP_Hunter_C.Server_Set_trap_ammo
	void Server_SpawnMotionSensor(struct ABP_Hunter_C* BPPC_Owner, struct FTransform XForm); // Function BP_Hunter.BP_Hunter_C.Server_SpawnMotionSensor
	void TryThrowTrap(); // Function BP_Hunter.BP_Hunter_C.TryThrowTrap
	void MC_SpawnTrapSounds(); // Function BP_Hunter.BP_Hunter_C.MC_SpawnTrapSounds
	void Server_SpawnTrapSounds(); // Function BP_Hunter.BP_Hunter_C.Server_SpawnTrapSounds
	void ThrowTrap(); // Function BP_Hunter.BP_Hunter_C.ThrowTrap
	void NR_ReloadSpectralCannonSounds(); // Function BP_Hunter.BP_Hunter_C.NR_ReloadSpectralCannonSounds
	void MC_ReloadSpectralCannon(); // Function BP_Hunter.BP_Hunter_C.MC_ReloadSpectralCannon
	void Server_ReloadSpectralCannon(); // Function BP_Hunter.BP_Hunter_C.Server_ReloadSpectralCannon
	void SpecCan_ReloadTurbineGlow_FP(); // Function BP_Hunter.BP_Hunter_C.SpecCan_ReloadTurbineGlow_FP
	void ReloadSpectralCannon(); // Function BP_Hunter.BP_Hunter_C.ReloadSpectralCannon
	void SpectralCannonChargeupStart(); // Function BP_Hunter.BP_Hunter_C.SpectralCannonChargeupStart
	void SpecCan_SpinUpEffects_FP(); // Function BP_Hunter.BP_Hunter_C.SpecCan_SpinUpEffects_FP
	void SpectralCannon_NR_FirelightClient(); // Function BP_Hunter.BP_Hunter_C.SpectralCannon_NR_FirelightClient
	void Server_CannonChargeupSound(); // Function BP_Hunter.BP_Hunter_C.Server_CannonChargeupSound
	void Server_CannonWindDownSound(); // Function BP_Hunter.BP_Hunter_C.Server_CannonWindDownSound
	void SpectralCannon_FireSounds(); // Function BP_Hunter.BP_Hunter_C.SpectralCannon_FireSounds
	void MC_Cannon_Equipped(bool EquippedRecently); // Function BP_Hunter.BP_Hunter_C.MC_Cannon_Equipped
	void Server_Cannon_TPAnim_Equipped(bool EquippedRecently); // Function BP_Hunter.BP_Hunter_C.Server_Cannon_TPAnim_Equipped
	void MC_Cannon_CapturedRecently(bool CapturedRecently); // Function BP_Hunter.BP_Hunter_C.MC_Cannon_CapturedRecently
	void MC_Cannon_BeamInPlay(bool BeamInPlay?); // Function BP_Hunter.BP_Hunter_C.MC_Cannon_BeamInPlay
	void MC_Cannon_Charging(bool ChargingGC); // Function BP_Hunter.BP_Hunter_C.MC_Cannon_Charging
	void Server_TPAnim_CancelFire(bool CancelFire?, struct ABP_Hunter_C* Hunter); // Function BP_Hunter.BP_Hunter_C.Server_TPAnim_CancelFire
	void Server_Cannon_TPAnim_CapturedRecently(bool CapturedRecently); // Function BP_Hunter.BP_Hunter_C.Server_Cannon_TPAnim_CapturedRecently
	void Server_Cannon_TPAnim_BeamInPlay(bool BeamInPlay?); // Function BP_Hunter.BP_Hunter_C.Server_Cannon_TPAnim_BeamInPlay
	void Server_Cannon_TPAnim_Charging(bool ChargingGC); // Function BP_Hunter.BP_Hunter_C.Server_Cannon_TPAnim_Charging
	void FinishChargeup(); // Function BP_Hunter.BP_Hunter_C.FinishChargeup
	void SpectralCannon_ChargeupFire(); // Function BP_Hunter.BP_Hunter_C.SpectralCannon_ChargeupFire
	void SpectralCannon_StopChargeup(); // Function BP_Hunter.BP_Hunter_C.SpectralCannon_StopChargeup
	void SpectralCannon_BeginChargeup(); // Function BP_Hunter.BP_Hunter_C.SpectralCannon_BeginChargeup
	void ChargeCannonFire(); // Function BP_Hunter.BP_Hunter_C.ChargeCannonFire
	void OutOfBattery(); // Function BP_Hunter.BP_Hunter_C.OutOfBattery
	void NR_SpawnSpectralCannonSalvo(struct FVector_NetQuantize10 Location, struct FRotator Rotator); // Function BP_Hunter.BP_Hunter_C.NR_SpawnSpectralCannonSalvo
	void MC_SpawnSpectralCannonSalvo(struct FVector_NetQuantize10 Location, struct FRotator Rotator); // Function BP_Hunter.BP_Hunter_C.MC_SpawnSpectralCannonSalvo
	void Server_SpawnSpectralCannonSalvo(struct FVector_NetQuantize10 Location, struct FRotator Rotator); // Function BP_Hunter.BP_Hunter_C.Server_SpawnSpectralCannonSalvo
	void FireSpectralCannonSalvo(struct FTransform XForm); // Function BP_Hunter.BP_Hunter_C.FireSpectralCannonSalvo
	void Server_EndXOverheat(); // Function BP_Hunter.BP_Hunter_C.Server_EndXOverheat
	void MC_EndXOverheat(); // Function BP_Hunter.BP_Hunter_C.MC_EndXOverheat
	void TriggerProjectXOverheatAnim(); // Function BP_Hunter.BP_Hunter_C.TriggerProjectXOverheatAnim
	void FireXSalvo(); // Function BP_Hunter.BP_Hunter_C.FireXSalvo
	void X Cool Off(); // Function BP_Hunter.BP_Hunter_C.X Cool Off
	void Glow Intensity Update(); // Function BP_Hunter.BP_Hunter_C.Glow Intensity Update
	void NR_DefaultXSpeed(); // Function BP_Hunter.BP_Hunter_C.NR_DefaultXSpeed
	void NR_FiringXSpeed(); // Function BP_Hunter.BP_Hunter_C.NR_FiringXSpeed
	void NR Fire X Salvo(struct FRotator Rotator); // Function BP_Hunter.BP_Hunter_C.NR Fire X Salvo
	void MC Fire X Salvo(struct FRotator Rotator); // Function BP_Hunter.BP_Hunter_C.MC Fire X Salvo
	void Server Fire X Salvo(struct FRotator Rotator); // Function BP_Hunter.BP_Hunter_C.Server Fire X Salvo
	void MC Overheated X(); // Function BP_Hunter.BP_Hunter_C.MC Overheated X
	void Server Overheated X(); // Function BP_Hunter.BP_Hunter_C.Server Overheated X
	void Overheat_X(); // Function BP_Hunter.BP_Hunter_C.Overheat_X
	void MC X Jam(); // Function BP_Hunter.BP_Hunter_C.MC X Jam
	void Server X Jam(); // Function BP_Hunter.BP_Hunter_C.Server X Jam
	void Server Fire X(); // Function BP_Hunter.BP_Hunter_C.Server Fire X
	void MC Fire X(); // Function BP_Hunter.BP_Hunter_C.MC Fire X
	void MC Stop Firing X(); // Function BP_Hunter.BP_Hunter_C.MC Stop Firing X
	void Server Stop Firing X(); // Function BP_Hunter.BP_Hunter_C.Server Stop Firing X
	void StopFiring_X(); // Function BP_Hunter.BP_Hunter_C.StopFiring_X
	void MC Interrupt X Chargeup(); // Function BP_Hunter.BP_Hunter_C.MC Interrupt X Chargeup
	void Server Interrupt X Chargeup(); // Function BP_Hunter.BP_Hunter_C.Server Interrupt X Chargeup
	void CancelChargeup_X(); // Function BP_Hunter.BP_Hunter_C.CancelChargeup_X
	void MC Start X Chargeup(); // Function BP_Hunter.BP_Hunter_C.MC Start X Chargeup
	void Server Start X Chargeup(); // Function BP_Hunter.BP_Hunter_C.Server Start X Chargeup
	void BeginChargeup_X(); // Function BP_Hunter.BP_Hunter_C.BeginChargeup_X
	void NR_SledgeHammer_PickFPFeedbackAnim(); // Function BP_Hunter.BP_Hunter_C.NR_SledgeHammer_PickFPFeedbackAnim
	void MC_SledgeHammerInterruptCleanUpTP(); // Function BP_Hunter.BP_Hunter_C.MC_SledgeHammerInterruptCleanUpTP
	void Server_SledgeHammerInterruptCleanUpTP(); // Function BP_Hunter.BP_Hunter_C.Server_SledgeHammerInterruptCleanUpTP
	void MC_SledgeHammerTPAnim(bool Attack); // Function BP_Hunter.BP_Hunter_C.MC_SledgeHammerTPAnim
	void Server_SledgeHammerTPAnim(bool Attack); // Function BP_Hunter.BP_Hunter_C.Server_SledgeHammerTPAnim
	void ForceSledgeHammerInput(); // Function BP_Hunter.BP_Hunter_C.ForceSledgeHammerInput
	void NR_TryToSwingSledgeHammer(); // Function BP_Hunter.BP_Hunter_C.NR_TryToSwingSledgeHammer
	void SledgehammerScan(); // Function BP_Hunter.BP_Hunter_C.SledgehammerScan
	void Server_SledgehammerAttacking(); // Function BP_Hunter.BP_Hunter_C.Server_SledgehammerAttacking
	void TickHarpoon(float DeltaTime); // Function BP_Hunter.BP_Hunter_C.TickHarpoon
	void PlayHarpoonReloadSound(); // Function BP_Hunter.BP_Hunter_C.PlayHarpoonReloadSound
	void MC_HarpoonRetractVFX(); // Function BP_Hunter.BP_Hunter_C.MC_HarpoonRetractVFX
	void Server_HarpoonRetractVFX(); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonRetractVFX
	void MC_HarpoonVFXMuzzle(); // Function BP_Hunter.BP_Hunter_C.MC_HarpoonVFXMuzzle
	void Server_HarpoonVFXMuzzle(); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonVFXMuzzle
	void ForceHarpoonFire(); // Function BP_Hunter.BP_Hunter_C.ForceHarpoonFire
	void Harpoon Currently Retracting TP OFF(); // Function BP_Hunter.BP_Hunter_C.Harpoon Currently Retracting TP OFF
	void Harpoon Currently Retracting TP ON(); // Function BP_Hunter.BP_Hunter_C.Harpoon Currently Retracting TP ON
	void SetHarpoonHitNothingAnim_TP_OFF(); // Function BP_Hunter.BP_Hunter_C.SetHarpoonHitNothingAnim_TP_OFF
	void SetHarpoonHitNothingAnim_TP(); // Function BP_Hunter.BP_Hunter_C.SetHarpoonHitNothingAnim_TP
	void SetHarpoonHitGhostAnimTP(); // Function BP_Hunter.BP_Hunter_C.SetHarpoonHitGhostAnimTP
	void HarpoonHitNothing(); // Function BP_Hunter.BP_Hunter_C.HarpoonHitNothing
	void SetHarpoonHitNothingAnim(); // Function BP_Hunter.BP_Hunter_C.SetHarpoonHitNothingAnim
	void SetHarpoonHitGhostAnim(); // Function BP_Hunter.BP_Hunter_C.SetHarpoonHitGhostAnim
	void OC_ForceRetract(); // Function BP_Hunter.BP_Hunter_C.OC_ForceRetract
	void MC_HarpoonHitLvlprop_NoAttach(); // Function BP_Hunter.BP_Hunter_C.MC_HarpoonHitLvlprop_NoAttach
	void Server_HarpoonHitLvlprop_NoAttach(); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonHitLvlprop_NoAttach
	void MC_DestroyHarpoon(); // Function BP_Hunter.BP_Hunter_C.MC_DestroyHarpoon
	void NR_SpawnHarpoon(struct FVector_NetQuantize Location, struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.NR_SpawnHarpoon
	void MC_SpawnHarpoon(struct FVector_NetQuantize Location, struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.MC_SpawnHarpoon
	void HarpoonBreakOverheatCD(); // Function BP_Hunter.BP_Hunter_C.HarpoonBreakOverheatCD
	void MC_StopReel(struct AProp_C* Ghost); // Function BP_Hunter.BP_Hunter_C.MC_StopReel
	void MC_StartReel(struct AProp_C* Ghost); // Function BP_Hunter.BP_Hunter_C.MC_StartReel
	void OC_HarpoonGotTooFarAway(); // Function BP_Hunter.BP_Hunter_C.OC_HarpoonGotTooFarAway
	void Server_HarpoonGotTooFarAway(); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonGotTooFarAway
	void Harpoon_ElectricityDamage(struct AProp_C* Ghost, struct AHarpoonProjectile_C* Harpoon, float Damage); // Function BP_Hunter.BP_Hunter_C.Harpoon_ElectricityDamage
	void OC_ForceHarpoonBreak(); // Function BP_Hunter.BP_Hunter_C.OC_ForceHarpoonBreak
	void MC_SetTPHarpoonVisible(); // Function BP_Hunter.BP_Hunter_C.MC_SetTPHarpoonVisible
	void Server_SetTPHarpoonVisible(); // Function BP_Hunter.BP_Hunter_C.Server_SetTPHarpoonVisible
	void Server_DestroyHarpoonTooFar(struct AHarpoonProjectile_C* Harpoon); // Function BP_Hunter.BP_Hunter_C.Server_DestroyHarpoonTooFar
	void HarpoonGotTooFarAway(struct AHarpoonProjectile_C* Harpoon); // Function BP_Hunter.BP_Hunter_C.HarpoonGotTooFarAway
	void Server_UpdateHarpoonStrength(int32_t Strength); // Function BP_Hunter.BP_Hunter_C.Server_UpdateHarpoonStrength
	void HarpoonHitDoorGhost(struct AProp_C* Hit Ghost, struct FVector HitLocation); // Function BP_Hunter.BP_Hunter_C.HarpoonHitDoorGhost
	void ReelingSetHarpoonHandler(bool ReelingSet); // Function BP_Hunter.BP_Hunter_C.ReelingSetHarpoonHandler
	void StunnedHarpoonHandler(); // Function BP_Hunter.BP_Hunter_C.StunnedHarpoonHandler
	void BreakDontDeleteHarpoonHandler(bool Fast); // Function BP_Hunter.BP_Hunter_C.BreakDontDeleteHarpoonHandler
	void BreakHarpoonHandler(bool Fast); // Function BP_Hunter.BP_Hunter_C.BreakHarpoonHandler
	void HarpoonHandlerInit(); // Function BP_Hunter.BP_Hunter_C.HarpoonHandlerInit
	void OC_HarpoonBreakForce(struct AProp_C* Ghost); // Function BP_Hunter.BP_Hunter_C.OC_HarpoonBreakForce
	void Server_HarpoonBreakForce(struct AProp_C* Ghost); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonBreakForce
	void HarpoonAlreadyHarpooned(); // Function BP_Hunter.BP_Hunter_C.HarpoonAlreadyHarpooned
	void Server_HarpoonHitLvlprop(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonHitLvlprop
	void HarpoonHitLvlprop(struct AHarpoonProjectile_C* Harpoon, struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.HarpoonHitLvlprop
	void MC_AttachToLvlprop(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.MC_AttachToLvlprop
	void HarpoonBackToOrient(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.HarpoonBackToOrient
	void MC_HarpoonBackToOrient(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.MC_HarpoonBackToOrient
	void Server_HarpoonBackToOrient(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonBackToOrient
	void MC_AttachToHarpoon(struct AProp_C* AttachToProp, struct FVector_NetQuantize HitOffset); // Function BP_Hunter.BP_Hunter_C.MC_AttachToHarpoon
	void MC_RetractHarpoon(bool Fast?); // Function BP_Hunter.BP_Hunter_C.MC_RetractHarpoon
	void Server_RetractHarpoon(bool Fast); // Function BP_Hunter.BP_Hunter_C.Server_RetractHarpoon
	void RetractHarpoon(bool Fast); // Function BP_Hunter.BP_Hunter_C.RetractHarpoon
	void DestroyHarpoon(); // Function BP_Hunter.BP_Hunter_C.DestroyHarpoon
	void Server_SpawnHarpoon(struct FVector_NetQuantize Location, struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.Server_SpawnHarpoon
	void Server_HarpoonBreak(struct AProp_C* Ghost, bool Don'tDeleteHarpoon, bool Fast); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonBreak
	void HarpoonChainBreak(bool Don't Delete Harpoon, bool Fast); // Function BP_Hunter.BP_Hunter_C.HarpoonChainBreak
	void Server-HarpoonReelStop(struct AProp_C* Ghost); // Function BP_Hunter.BP_Hunter_C.Server-HarpoonReelStop
	void Server_HarpoonReelStart(struct AProp_C* Ghost); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonReelStart
	void HarpoonReelStop(); // Function BP_Hunter.BP_Hunter_C.HarpoonReelStop
	void HarpoonReelStart(); // Function BP_Hunter.BP_Hunter_C.HarpoonReelStart
	void HarpoonFired_Animations(); // Function BP_Hunter.BP_Hunter_C.HarpoonFired_Animations
	void Server_HarpoonHitGhost(struct AProp_C* Ghost, struct FVector_NetQuantize Hit Offset); // Function BP_Hunter.BP_Hunter_C.Server_HarpoonHitGhost
	void HarpoonHitGhost(struct AProp_C* Hit Ghost, struct AHarpoonProjectile_C* Harpoon, struct FVector HitLocation); // Function BP_Hunter.BP_Hunter_C.HarpoonHitGhost
	void HarpoonRetracted(); // Function BP_Hunter.BP_Hunter_C.HarpoonRetracted
	void MC_SniperDeflectedVFX(struct FVector_NetQuantize Location, struct FRotator Rotation, bool UseCustomStartPoint, struct FVector_NetQuantize CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.MC_SniperDeflectedVFX
	void Server_SniperDeflectedVFX(struct FVector_NetQuantize Location, struct FRotator Rotation, bool UseCustomStartPoint, struct FVector_NetQuantize CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.Server_SniperDeflectedVFX
	void ForceFireSniper(); // Function BP_Hunter.BP_Hunter_C.ForceFireSniper
	void MC_SniperVFX_HitPossessSpirit(struct ABP_PossesSpirit_C* PossessSpirit, struct FRotator Rotation, struct FVector_NetQuantize HitLocation, struct FVector_NetQuantize HitOffset); // Function BP_Hunter.BP_Hunter_C.MC_SniperVFX_HitPossessSpirit
	void Server_SniperVFX_HitPossessSpirit(struct ABP_PossesSpirit_C* PossessSpirit, struct FRotator Rotation, struct FVector_NetQuantize HitLocation, struct FVector_NetQuantize HitOffset); // Function BP_Hunter.BP_Hunter_C.Server_SniperVFX_HitPossessSpirit
	void MC_CacheSniperDarts_Spirit(struct ABP_SpiritAbility_C* BP Spirit Ability); // Function BP_Hunter.BP_Hunter_C.MC_CacheSniperDarts_Spirit
	void RefillAmmoSniper(); // Function BP_Hunter.BP_Hunter_C.RefillAmmoSniper
	void Server_SniperReloadAnim(); // Function BP_Hunter.BP_Hunter_C.Server_SniperReloadAnim
	void Server_SniperFiredAnim(); // Function BP_Hunter.BP_Hunter_C.Server_SniperFiredAnim
	void MC_AttachCachedDartsToLvlprop(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.MC_AttachCachedDartsToLvlprop
	void MC_CacheSniperDartsProp(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.MC_CacheSniperDartsProp
	void MC_AttachCachedDartsToProp(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.MC_AttachCachedDartsToProp
	void MC_CacheSniperDarts(struct ALvlProp_C* LvlProp, struct ABP_PossesSpirit_C* PossessSpirit); // Function BP_Hunter.BP_Hunter_C.MC_CacheSniperDarts
	void MC_SniperVFX_Attach(struct FRotator Rotation, struct FVector_NetQuantize HitLocation, struct AActor* HitActor, struct FVector_NetQuantize HitOffset, bool UseCustomStartPoint, struct FVector_NetQuantize CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.MC_SniperVFX_Attach
	void SniperHeatWaveVFX(); // Function BP_Hunter.BP_Hunter_C.SniperHeatWaveVFX
	void SniperFiredAnim(); // Function BP_Hunter.BP_Hunter_C.SniperFiredAnim
	void ReloadSniper(); // Function BP_Hunter.BP_Hunter_C.ReloadSniper
	void SniperDart(struct AActor* HitActor, struct FVector_NetQuantize Hit Offset, struct FRotator Rotation, struct FVector (NotProp)Location); // Function BP_Hunter.BP_Hunter_C.SniperDart
	void Server_SniperVFX_HitLvlprop(struct ALvlProp_C* LvlProp, struct FRotator Rotation, struct FVector_NetQuantize HitLocation, bool UseCustomStartPoint, struct FVector_NetQuantize CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.Server_SniperVFX_HitLvlprop
	void Server_SniperVFX_HitProp(struct AProp_C* Prop, struct FRotator Rotation, struct FVector_NetQuantize HitLocation, struct FVector_NetQuantize HitOffset, bool UseCustomStartPoint, struct FVector_NetQuantize CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.Server_SniperVFX_HitProp
	void SniperVFX(struct FRotator Rotation, struct FVector Hit Location, bool UseCustomStartPoint, struct FVector CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.SniperVFX
	void MC_SniperVFX(struct FRotator Rotation, struct FVector_NetQuantize HitLocation, bool UseCustomStartPoint, struct FVector_NetQuantize CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.MC_SniperVFX
	void Server_SniperVFX(struct FRotator Rotation, struct FVector_NetQuantize HitLocation, bool UseCustomStartPoint, struct FVector_NetQuantize CustomStartPoint); // Function BP_Hunter.BP_Hunter_C.Server_SniperVFX
	void HitSkyboxError(); // Function BP_Hunter.BP_Hunter_C.HitSkyboxError
	void StartGrappleMovement(); // Function BP_Hunter.BP_Hunter_C.StartGrappleMovement
	void ServerCustomGrapplingMovement(struct FVector StartLocation, struct FVector EndLocation); // Function BP_Hunter.BP_Hunter_C.ServerCustomGrapplingMovement
	void CustomGrapplingMovement(struct FVector StartLocation, struct FVector EndLocation); // Function BP_Hunter.BP_Hunter_C.CustomGrapplingMovement
	void Server_SetGrapplingHookCooldown(bool Cooldown); // Function BP_Hunter.BP_Hunter_C.Server_SetGrapplingHookCooldown
	void Server_SetGrapplingHookFired(bool Fired); // Function BP_Hunter.BP_Hunter_C.Server_SetGrapplingHookFired
	void TP_RetractGrappleSounds(); // Function BP_Hunter.BP_Hunter_C.TP_RetractGrappleSounds
	void GrappleGotTooFar(); // Function BP_Hunter.BP_Hunter_C.GrappleGotTooFar
	void MC_DestroyGrapple(); // Function BP_Hunter.BP_Hunter_C.MC_DestroyGrapple
	void Server_DestroyGrapple(); // Function BP_Hunter.BP_Hunter_C.Server_DestroyGrapple
	void MC_RetractGrapple(); // Function BP_Hunter.BP_Hunter_C.MC_RetractGrapple
	void Server_RetractGrapple(); // Function BP_Hunter.BP_Hunter_C.Server_RetractGrapple
	void MC_SpawnGrapplingHook(struct FVector_NetQuantize Location, struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.MC_SpawnGrapplingHook
	void Server_SpawnGrapplingHook(struct FVector_NetQuantize Location, struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.Server_SpawnGrapplingHook
	void GrappleRetracted(bool NoCD); // Function BP_Hunter.BP_Hunter_C.GrappleRetracted
	void HandleGrappled(bool NoCD); // Function BP_Hunter.BP_Hunter_C.HandleGrappled
	void NR_SpawnGrapplingHook(struct FVector_NetQuantize Location, struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.NR_SpawnGrapplingHook
	void Server_ShotgunPossessDamage(struct TArray<struct FShotgunPossessSpiritDamage>& PossessDamage); // Function BP_Hunter.BP_Hunter_C.Server_ShotgunPossessDamage
	void NR_ShotgunPossessDamage(struct TArray<struct FShotgunPossessSpiritDamage>& PossessDamage); // Function BP_Hunter.BP_Hunter_C.NR_ShotgunPossessDamage
	void MC_ShotgunReload(); // Function BP_Hunter.BP_Hunter_C.MC_ShotgunReload
	void Server_ShotgunReload(); // Function BP_Hunter.BP_Hunter_C.Server_ShotgunReload
	void SaltShotgunVFX(); // Function BP_Hunter.BP_Hunter_C.SaltShotgunVFX
	void MC_ShotgunFired(); // Function BP_Hunter.BP_Hunter_C.MC_ShotgunFired
	void Server_ShotgunFired(); // Function BP_Hunter.BP_Hunter_C.Server_ShotgunFired
	void ReloadShotgun(); // Function BP_Hunter.BP_Hunter_C.ReloadShotgun
	void NR_ReportShotgunDamage(struct TArray<struct FShotgunPropDamage>& PropsDamaged); // Function BP_Hunter.BP_Hunter_C.NR_ReportShotgunDamage
	void Server_ShotgunLvlpropDamage(struct TArray<struct FShotgunLvlpropDamage>& LvlpropDmg); // Function BP_Hunter.BP_Hunter_C.Server_ShotgunLvlpropDamage
	void Server_ShotgunDamage(struct TArray<struct FShotgunPropDamage>& PropsDamaged); // Function BP_Hunter.BP_Hunter_C.Server_ShotgunDamage
	void ForceNailgunFire(); // Function BP_Hunter.BP_Hunter_C.ForceNailgunFire
	void MC_ReloadNailgun(); // Function BP_Hunter.BP_Hunter_C.MC_ReloadNailgun
	void Server_ReloadNailgun(); // Function BP_Hunter.BP_Hunter_C.Server_ReloadNailgun
	void NailgunMuzzleFlash(); // Function BP_Hunter.BP_Hunter_C.NailgunMuzzleFlash
	void NailgunReloadVFX(); // Function BP_Hunter.BP_Hunter_C.NailgunReloadVFX
	void ReloadNailgun(); // Function BP_Hunter.BP_Hunter_C.ReloadNailgun
	void MC_FireNailgunProjectile(struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.MC_FireNailgunProjectile
	void Server_FireNailgunProjectile(struct FRotator Rotation); // Function BP_Hunter.BP_Hunter_C.Server_FireNailgunProjectile
	void NR_FireNailgunProjectile(struct FTransform XForm); // Function BP_Hunter.BP_Hunter_C.NR_FireNailgunProjectile
	void ForceSpawnC4(struct FVector_NetQuantize Location, struct FRotator Rotator, bool Fall); // Function BP_Hunter.BP_Hunter_C.ForceSpawnC4
	void NR_DetonateC4s(); // Function BP_Hunter.BP_Hunter_C.NR_DetonateC4s
	void OutOfC4Message(); // Function BP_Hunter.BP_Hunter_C.OutOfC4Message
	void NR_BombWasDestroyed(); // Function BP_Hunter.BP_Hunter_C.NR_BombWasDestroyed
	void OC_PickUpC4(); // Function BP_Hunter.BP_Hunter_C.OC_PickUpC4
	void C4_TP_BombInHands_MultiCast(bool IsInHands, bool Phone Closed); // Function BP_Hunter.BP_Hunter_C.C4_TP_BombInHands_MultiCast
	void C4_TP_BombInHands(bool IsInHands, bool PhoneClosed); // Function BP_Hunter.BP_Hunter_C.C4_TP_BombInHands
	void Server_DetonateC4(); // Function BP_Hunter.BP_Hunter_C.Server_DetonateC4
	void DetonateC4(); // Function BP_Hunter.BP_Hunter_C.DetonateC4
	void Server_SpawnC4(struct FVector_NetQuantize Location, struct FRotator Rotator, bool Fall); // Function BP_Hunter.BP_Hunter_C.Server_SpawnC4
	void SpawnC4(); // Function BP_Hunter.BP_Hunter_C.SpawnC4
	void MC_TPAttackAnimationDown(); // Function BP_Hunter.BP_Hunter_C.MC_TPAttackAnimationDown
	void MC_TPAttackAnimationUp(); // Function BP_Hunter.BP_Hunter_C.MC_TPAttackAnimationUp
	void TPAttackAnimationDown(); // Function BP_Hunter.BP_Hunter_C.TPAttackAnimationDown
	void TPAttackAnimationUp(); // Function BP_Hunter.BP_Hunter_C.TPAttackAnimationUp
	void HandleRiotShieldCollision(bool Bring Up); // Function BP_Hunter.BP_Hunter_C.HandleRiotShieldCollision
	void Down(bool Bring Up); // Function BP_Hunter.BP_Hunter_C.Down
	void Down(bool Bring Up); // Function BP_Hunter.BP_Hunter_C.Down
	void Down(bool BringUp); // Function BP_Hunter.BP_Hunter_C.Down
	void SpawnMedKit(int32_t HealingChargesRemaining, struct FTransform SpawnTransform); // Function BP_Hunter.BP_Hunter_C.SpawnMedKit
	void ForceSpawnMedKit(int32_t ChargesRemaining, struct FTransform SpawnTransform); // Function BP_Hunter.BP_Hunter_C.ForceSpawnMedKit
	void MC_MedicBox_SyncTP_OOA(int32_t Charges, bool CheckVisibility); // Function BP_Hunter.BP_Hunter_C.MC_MedicBox_SyncTP_OOA
	void Server_MedicBox_SyncTP_OOA(int32_t Charges, bool Check Visibility); // Function BP_Hunter.BP_Hunter_C.Server_MedicBox_SyncTP_OOA
	void MedicBox_SyncTP_OOA(bool CheckVisibility); // Function BP_Hunter.BP_Hunter_C.MedicBox_SyncTP_OOA
	void BringOutFreschMedkit(); // Function BP_Hunter.BP_Hunter_C.BringOutFreschMedkit
	void MedicKit_RemoveBandage(); // Function BP_Hunter.BP_Hunter_C.MedicKit_RemoveBandage
	void MedicKit_AttachBandage(bool FirstPerson, int32_t What Bone, bool SelfHeal); // Function BP_Hunter.BP_Hunter_C.MedicKit_AttachBandage
	void Server_DeliverHealScore(struct ABP_Hunter_C* HealedPlayer, struct ABP_Hunter_C* HealerPlayer); // Function BP_Hunter.BP_Hunter_C.Server_DeliverHealScore
	void OC_MedicHealingInterrupted(); // Function BP_Hunter.BP_Hunter_C.OC_MedicHealingInterrupted
	void Server_CancelMedicHeal(struct ABP_Hunter_C* BPHunter); // Function BP_Hunter.BP_Hunter_C.Server_CancelMedicHeal
	void OC_IAMBeingMedicHealed(); // Function BP_Hunter.BP_Hunter_C.OC_IAMBeingMedicHealed
	void Server_DirectMedicHealThisHunter(struct ABP_Hunter_C* BPHunter, struct ABP_Hunter_C* HunterHealing, bool HealingOtherHunter); // Function BP_Hunter.BP_Hunter_C.Server_DirectMedicHealThisHunter
	void NR_StartMedkitHealThisHunter(struct ABP_Hunter_C* Hunter, bool DifferentHunter?, bool Self Direct Heal?); // Function BP_Hunter.BP_Hunter_C.NR_StartMedkitHealThisHunter
	void Server_MedkitHealThisHunter(struct ABP_Hunter_C* Hunter, bool HealingOtherHunter); // Function BP_Hunter.BP_Hunter_C.Server_MedkitHealThisHunter
	void Throw Medic Kit On Ground(); // Function BP_Hunter.BP_Hunter_C.Throw Medic Kit On Ground
	void NR_PlayPickupMedkitBoxAnimations(); // Function BP_Hunter.BP_Hunter_C.NR_PlayPickupMedkitBoxAnimations
	void Server_PickUpMedicKit(struct ABP_MedicKit_C* MedicKit); // Function BP_Hunter.BP_Hunter_C.Server_PickUpMedicKit
	void PickUpMedkitBox(struct ABP_MedicKit_C* Medic Kit); // Function BP_Hunter.BP_Hunter_C.PickUpMedkitBox
	void MC_BandageCompleteSounds(); // Function BP_Hunter.BP_Hunter_C.MC_BandageCompleteSounds
	void Server_HandleCancelMedicHeal(); // Function BP_Hunter.BP_Hunter_C.Server_HandleCancelMedicHeal
	void HandleMedicKitCancel(bool Interrupted); // Function BP_Hunter.BP_Hunter_C.HandleMedicKitCancel
	void CancelBandageDelays(); // Function BP_Hunter.BP_Hunter_C.CancelBandageDelays
	void NR_CancelHealing(); // Function BP_Hunter.BP_Hunter_C.NR_CancelHealing
	void MC_UsingBandageSounds(); // Function BP_Hunter.BP_Hunter_C.MC_UsingBandageSounds
	void HandleFPBandaging(struct ABP_Hunter_C* Hunter To Heal, bool Direct Healing Other Hunter, bool Self Direct Heal); // Function BP_Hunter.BP_Hunter_C.HandleFPBandaging
	void Server_UseMedicKitWrapper(struct ABP_MedicKit_C* MedicKit); // Function BP_Hunter.BP_Hunter_C.Server_UseMedicKitWrapper
	void UseMedicKitInteract(struct ABP_MedicKit_C* MedicKit); // Function BP_Hunter.BP_Hunter_C.UseMedicKitInteract
	void AlreadyFullHealthMessage(); // Function BP_Hunter.BP_Hunter_C.AlreadyFullHealthMessage
	void OC_HunterUseMedicKit(); // Function BP_Hunter.BP_Hunter_C.OC_HunterUseMedicKit
	void OutOfMedicKitMessage(); // Function BP_Hunter.BP_Hunter_C.OutOfMedicKitMessage
	void Server_HandleMedicKitHeal(struct ABP_MedicKit_C* Medic Kit (If Kit), struct ABP_Hunter_C* Hunter Healing); // Function BP_Hunter.BP_Hunter_C.Server_HandleMedicKitHeal
	void Server_SpawnMedicKit(int32_t ChargesRemaining); // Function BP_Hunter.BP_Hunter_C.Server_SpawnMedicKit
	void ThrowMedicKit(int32_t ChargesRemaining); // Function BP_Hunter.BP_Hunter_C.ThrowMedicKit
	void MC_MedicBox_HealOtherAnim(bool Cancel); // Function BP_Hunter.BP_Hunter_C.MC_MedicBox_HealOtherAnim
	void Server_MedicBox_HealOtherAnim(bool Cancel); // Function BP_Hunter.BP_Hunter_C.Server_MedicBox_HealOtherAnim
	void MC_MedicBox_HealSelf(bool Cancel); // Function BP_Hunter.BP_Hunter_C.MC_MedicBox_HealSelf
	void Server_MedicBox_HealSelf(bool Cancel); // Function BP_Hunter.BP_Hunter_C.Server_MedicBox_HealSelf
	void MC_MedicBox_Throw_TP(); // Function BP_Hunter.BP_Hunter_C.MC_MedicBox_Throw_TP
	void Server_MedicBox_Throw_TP(); // Function BP_Hunter.BP_Hunter_C.Server_MedicBox_Throw_TP
	void PlayFlamethrowerReloadSound(); // Function BP_Hunter.BP_Hunter_C.PlayFlamethrowerReloadSound
	void MC_FlamethrowerReload(); // Function BP_Hunter.BP_Hunter_C.MC_FlamethrowerReload
	void Server_FlamethrowerReload(); // Function BP_Hunter.BP_Hunter_C.Server_FlamethrowerReload
	void SpawnFlamethrowerHitVFX(struct FVector Location); // Function BP_Hunter.BP_Hunter_C.SpawnFlamethrowerHitVFX
	void MC_SpawnFlamethrowerHitVFX(struct FVector_NetQuantize Location); // Function BP_Hunter.BP_Hunter_C.MC_SpawnFlamethrowerHitVFX
	void Server_SpawnFlamethrowerHitVFX(struct FVector_NetQuantize Location); // Function BP_Hunter.BP_Hunter_C.Server_SpawnFlamethrowerHitVFX
	void NR_HandleSpawnFlamethrowerHitVFX(struct FVector Location); // Function BP_Hunter.BP_Hunter_C.NR_HandleSpawnFlamethrowerHitVFX
	void ForceFireFlamethrower(); // Function BP_Hunter.BP_Hunter_C.ForceFireFlamethrower
	void NR_SpawnFlameVFX(bool Start); // Function BP_Hunter.BP_Hunter_C.NR_SpawnFlameVFX
	void MC_SpawnFlameVFX(bool Start); // Function BP_Hunter.BP_Hunter_C.MC_SpawnFlameVFX
	void Server_SpawnFlameVFX(bool Start); // Function BP_Hunter.BP_Hunter_C.Server_SpawnFlameVFX
	void SpawnFlameVFX(bool Start); // Function BP_Hunter.BP_Hunter_C.SpawnFlameVFX
	void ReloadFlameThrower(); // Function BP_Hunter.BP_Hunter_C.ReloadFlameThrower
	void Server_CamcorderUpdateReplicatedVariable(bool Replicated Camcorder Hands Empty); // Function BP_Hunter.BP_Hunter_C.Server_CamcorderUpdateReplicatedVariable
	void CamcorderUpdateReplicatedVariable(); // Function BP_Hunter.BP_Hunter_C.CamcorderUpdateReplicatedVariable
	void OC_CamcorderDestroyed(); // Function BP_Hunter.BP_Hunter_C.OC_CamcorderDestroyed
	void OCCamcorderDestroyed_Int(); // Function BP_Hunter.BP_Hunter_C.OCCamcorderDestroyed_Int
	void MC_GhostDetectedCamcorderSound(struct AActor* Actor); // Function BP_Hunter.BP_Hunter_C.MC_GhostDetectedCamcorderSound
	void OC_CamcorderGhostDetected(struct AActor* CamCorder); // Function BP_Hunter.BP_Hunter_C.OC_CamcorderGhostDetected
	void Server_CamCorderGhostDetected(struct AActor* Ghost, struct AActor* CamCorder); // Function BP_Hunter.BP_Hunter_C.Server_CamCorderGhostDetected
	void CamcorderDetectedGhost_Int(struct AActor* Ghost, struct AActor* CamCorder); // Function BP_Hunter.BP_Hunter_C.CamcorderDetectedGhost_Int
	void Server_DestroyCamCorder(struct AActor* Actor); // Function BP_Hunter.BP_Hunter_C.Server_DestroyCamCorder
	void PickedUpCamcorder_Int(struct AActor* Actor); // Function BP_Hunter.BP_Hunter_C.PickedUpCamcorder_Int
	void Server_SpawnCamCorder(struct FVector_NetQuantize Location, struct FRotator Rotator); // Function BP_Hunter.BP_Hunter_C.Server_SpawnCamCorder
	void MC_Camcorder_Throw_TP(); // Function BP_Hunter.BP_Hunter_C.MC_Camcorder_Throw_TP
	void Server_Camcorder_Throw_TP(); // Function BP_Hunter.BP_Hunter_C.Server_Camcorder_Throw_TP
	void MC_Camcorder_Pickup_TP(); // Function BP_Hunter.BP_Hunter_C.MC_Camcorder_Pickup_TP
	void Server_Camcorder_Pickup_TP(); // Function BP_Hunter.BP_Hunter_C.Server_Camcorder_Pickup_TP
	void Server_SprintEnergyRaise(); // Function BP_Hunter.BP_Hunter_C.Server_SprintEnergyRaise
	void SprintEnergyRaise(); // Function BP_Hunter.BP_Hunter_C.SprintEnergyRaise
	void OC_DamageChallenge(char MGH_InMatchChallenges Challenge); // Function BP_Hunter.BP_Hunter_C.OC_DamageChallenge
	void OC_BreakGhostOutOfProp(); // Function BP_Hunter.BP_Hunter_C.OC_BreakGhostOutOfProp
	void Slingshot_VFX(bool MidnightForm, struct FVector Location); // Function BP_Hunter.BP_Hunter_C.Slingshot_VFX
	void MC_SlingshotVFX_Hit(struct FVector Location, bool MidnightForm); // Function BP_Hunter.BP_Hunter_C.MC_SlingshotVFX_Hit
	void Server_SlingshotVFX_Hit(struct FVector Location, bool MidnightForm); // Function BP_Hunter.BP_Hunter_C.Server_SlingshotVFX_Hit
	void DoppelgangerCheckIfAttackButtonHeld(); // Function BP_Hunter.BP_Hunter_C.DoppelgangerCheckIfAttackButtonHeld
	void DoppelgangerAttackAgain(); // Function BP_Hunter.BP_Hunter_C.DoppelgangerAttackAgain
	void Server_DoppelHasAttacked(); // Function BP_Hunter.BP_Hunter_C.Server_DoppelHasAttacked
	void NR_HitShield(struct ABP_Hunter_C* BP Hunter); // Function BP_Hunter.BP_Hunter_C.NR_HitShield
	void OC_ReportTrappedData(); // Function BP_Hunter.BP_Hunter_C.OC_ReportTrappedData
	void ReportTrappedData(); // Function BP_Hunter.BP_Hunter_C.ReportTrappedData
	void StartSprinting(); // Function BP_Hunter.BP_Hunter_C.StartSprinting
	void StopSprinting(); // Function BP_Hunter.BP_Hunter_C.StopSprinting
	void NR_UpdateYaw(int32_t Yaw); // Function BP_Hunter.BP_Hunter_C.NR_UpdateYaw
	void Server_UpdateYawTarget(int32_t Yaw); // Function BP_Hunter.BP_Hunter_C.Server_UpdateYawTarget
	void MC_UpdateYawTarget(int32_t Yaw); // Function BP_Hunter.BP_Hunter_C.MC_UpdateYawTarget
	void NR_InterpToControlRotation(int32_t Yaw); // Function BP_Hunter.BP_Hunter_C.NR_InterpToControlRotation
	void Server_InterpToThisYaw(int32_t Yaw); // Function BP_Hunter.BP_Hunter_C.Server_InterpToThisYaw
	void MC_InterpToControlRotation(int32_t Yaw); // Function BP_Hunter.BP_Hunter_C.MC_InterpToControlRotation
	void DoppleGangerAlternateAttack(); // Function BP_Hunter.BP_Hunter_C.DoppleGangerAlternateAttack
	void DopplegangerHandleAlternateAttack(); // Function BP_Hunter.BP_Hunter_C.DopplegangerHandleAlternateAttack
	void MC_FullyHideHunter(); // Function BP_Hunter.BP_Hunter_C.MC_FullyHideHunter
	void MC End Defib(); // Function BP_Hunter.BP_Hunter_C.MC End Defib
	void Server End Defib(); // Function BP_Hunter.BP_Hunter_C.Server End Defib
	void MC_StartDefib(); // Function BP_Hunter.BP_Hunter_C.MC_StartDefib
	void Server Start Defib(); // Function BP_Hunter.BP_Hunter_C.Server Start Defib
	void Server_ClearVanSeat(struct ABP_Hunter_C* Clearer, bool Switch Classes In Van?); // Function BP_Hunter.BP_Hunter_C.Server_ClearVanSeat
	void Server_CloseOpenDoor(struct ALvlProp_C* LvlProp); // Function BP_Hunter.BP_Hunter_C.Server_CloseOpenDoor
	void Infection_LeftEscape(); // Function BP_Hunter.BP_Hunter_C.Infection_LeftEscape
	void MC_InfectionEscaped(); // Function BP_Hunter.BP_Hunter_C.MC_InfectionEscaped
	void Server_InfectionEscaped(); // Function BP_Hunter.BP_Hunter_C.Server_InfectionEscaped
	void Infection_AddEscapePoints(); // Function BP_Hunter.BP_Hunter_C.Infection_AddEscapePoints
	void Server_DestroyedTrap(struct ABP_Trap_C* Trap, float Damage); // Function BP_Hunter.BP_Hunter_C.Server_DestroyedTrap
	void Server_GHOSTApplyGeneratorDamage(struct ABP_Generator_C* Generator); // Function BP_Hunter.BP_Hunter_C.Server_GHOSTApplyGeneratorDamage
	void Server_GHOSTApplyPunchDamage(struct ABP_Hunter_C* BP Hunter); // Function BP_Hunter.BP_Hunter_C.Server_GHOSTApplyPunchDamage
	void NR Apply Damage(struct AActor* Hit Actor); // Function BP_Hunter.BP_Hunter_C.NR Apply Damage
	void InitPunch(); // Function BP_Hunter.BP_Hunter_C.InitPunch
	void MC_PunchSound(); // Function BP_Hunter.BP_Hunter_C.MC_PunchSound
	void Server_DoppleAttack(); // Function BP_Hunter.BP_Hunter_C.Server_DoppleAttack
	void MC_SetOrientToMovement(bool Controller Desired?); // Function BP_Hunter.BP_Hunter_C.MC_SetOrientToMovement
	void Server_SetOrientToMovement(bool ControllerDesired?); // Function BP_Hunter.BP_Hunter_C.Server_SetOrientToMovement
	void SetHunterCollisionChannel(); // Function BP_Hunter.BP_Hunter_C.SetHunterCollisionChannel
	void Server_PlaySoundH(struct USoundBase* Sound, struct FVector Location, float Volume, bool Scanner Crackle?); // Function BP_Hunter.BP_Hunter_C.Server_PlaySoundH
	void MC_SetHunterHealth(float Health, bool Set Max Health?, float Max Health); // Function BP_Hunter.BP_Hunter_C.MC_SetHunterHealth
	void Server_SetHunterHealth(float Health, bool Set Max Health?, float Max Health); // Function BP_Hunter.BP_Hunter_C.Server_SetHunterHealth
	void Server Set Weapon Power Level(int32_t Power Level); // Function BP_Hunter.BP_Hunter_C.Server Set Weapon Power Level
	void Server_SetHunterNotSprint(); // Function BP_Hunter.BP_Hunter_C.Server_SetHunterNotSprint
	void Server_SetHunterSprint(); // Function BP_Hunter.BP_Hunter_C.Server_SetHunterSprint
	void MC_DebugSetSprintSpeed(float Speed); // Function BP_Hunter.BP_Hunter_C.MC_DebugSetSprintSpeed
	void Server_DEBUGSetSprintSpeed(float Speed); // Function BP_Hunter.BP_Hunter_C.Server_DEBUGSetSprintSpeed
	void MC_SetHunterNotSprint(); // Function BP_Hunter.BP_Hunter_C.MC_SetHunterNotSprint
	void MC_SetHunterSprint(); // Function BP_Hunter.BP_Hunter_C.MC_SetHunterSprint
	void Server_SetTPAnimSprint(bool Sprinting?); // Function BP_Hunter.BP_Hunter_C.Server_SetTPAnimSprint
	void Hunter_SetFirstPerson(); // Function BP_Hunter.BP_Hunter_C.Hunter_SetFirstPerson
	void Hunter_SetThirdPerson(); // Function BP_Hunter.BP_Hunter_C.Hunter_SetThirdPerson
	void MC_UnhideAllCannon(); // Function BP_Hunter.BP_Hunter_C.MC_UnhideAllCannon
	void Server_DoppUnhideCannon(); // Function BP_Hunter.BP_Hunter_C.Server_DoppUnhideCannon
	void MC_HideAllCannon(); // Function BP_Hunter.BP_Hunter_C.MC_HideAllCannon
	void Server_DoppHideCannon(); // Function BP_Hunter.BP_Hunter_C.Server_DoppHideCannon
	void Server_HideAllGadgTP(); // Function BP_Hunter.BP_Hunter_C.Server_HideAllGadgTP
	void HideAllFPGadgets(); // Function BP_Hunter.BP_Hunter_C.HideAllFPGadgets
	void Server_SpawnResupplySound(); // Function BP_Hunter.BP_Hunter_C.Server_SpawnResupplySound
	void OC_SetFirstPerson(); // Function BP_Hunter.BP_Hunter_C.OC_SetFirstPerson
	void ThirdPerson_Emote(); // Function BP_Hunter.BP_Hunter_C.ThirdPerson_Emote
	void OC_SetFirstPersonCameraTakedown(); // Function BP_Hunter.BP_Hunter_C.OC_SetFirstPersonCameraTakedown
	void Death_ThirdPerson(); // Function BP_Hunter.BP_Hunter_C.Death_ThirdPerson
	void NR_Re-equip(); // Function BP_Hunter.BP_Hunter_C.NR_Re-equip
	void MC_HideAllTP(); // Function BP_Hunter.BP_Hunter_C.MC_HideAllTP
	void OC_Re-equip(); // Function BP_Hunter.BP_Hunter_C.OC_Re-equip
	void Server_Re-equip(struct ABP_Hunter_C* BP Hunter, bool  Hide); // Function BP_Hunter.BP_Hunter_C.Server_Re-equip
	void MC_SetWEq(bool On, struct ABP_Hunter_C* BP Hunter); // Function BP_Hunter.BP_Hunter_C.MC_SetWEq
	void Server_SetWeaponEquipped(bool On, struct ABP_Hunter_C* BP Hunter); // Function BP_Hunter.BP_Hunter_C.Server_SetWeaponEquipped
	void ReplenishAmmo(char HunterWeapon Weapon); // Function BP_Hunter.BP_Hunter_C.ReplenishAmmo
	void UI_ShowGuns(); // Function BP_Hunter.BP_Hunter_C.UI_ShowGuns
	void SetThirdPersonCam_OC(); // Function BP_Hunter.BP_Hunter_C.SetThirdPersonCam_OC
	void Server_BackToFirstPersonClient(struct ABP_Hunter_C* BPPC); // Function BP_Hunter.BP_Hunter_C.Server_BackToFirstPersonClient
	void MC_SetControlRotation(bool On); // Function BP_Hunter.BP_Hunter_C.MC_SetControlRotation
	void Server_SetControlRotation(bool On); // Function BP_Hunter.BP_Hunter_C.Server_SetControlRotation
	void SetFirstPersonCamera(bool Takedown?); // Function BP_Hunter.BP_Hunter_C.SetFirstPersonCamera
	void SetThirdPersonCamera(bool Chokeout?); // Function BP_Hunter.BP_Hunter_C.SetThirdPersonCamera
	void Server_SetEmote(char Hunter_Emotes Specific); // Function BP_Hunter.BP_Hunter_C.Server_SetEmote
	void RestoreMigrationDeadHunter(bool Has Resurrectable Orb?); // Function BP_Hunter.BP_Hunter_C.RestoreMigrationDeadHunter
	void NR_ReportFakeHitHunter(struct ABP_Hunter_C* Hunter Fake); // Function BP_Hunter.BP_Hunter_C.NR_ReportFakeHitHunter
	void MigrationDeadHunterStartupUI(); // Function BP_Hunter.BP_Hunter_C.MigrationDeadHunterStartupUI
	void CheckRecentTrackingHit(); // Function BP_Hunter.BP_Hunter_C.CheckRecentTrackingHit
	void RecentlyGotTrackingHit(bool Radar, bool pathfinder, bool Spectrophone); // Function BP_Hunter.BP_Hunter_C.RecentlyGotTrackingHit
	void GhostEnergyIncrease(char MGH_EnergyType EnergyType, float Multiplier); // Function BP_Hunter.BP_Hunter_C.GhostEnergyIncrease
	void NR_UpdateGhostsmasherShield(); // Function BP_Hunter.BP_Hunter_C.NR_UpdateGhostsmasherShield
	void UpdateGhostsmasherShieldHeal(); // Function BP_Hunter.BP_Hunter_C.UpdateGhostsmasherShieldHeal
	void OC_RespawnHunter(); // Function BP_Hunter.BP_Hunter_C.OC_RespawnHunter
	void InterruptDefibRevive(); // Function BP_Hunter.BP_Hunter_C.InterruptDefibRevive
	void StartDefibRevive(struct ABP_Hunter_C* DeadHunter); // Function BP_Hunter.BP_Hunter_C.StartDefibRevive
	void HealMedkitTip(); // Function BP_Hunter.BP_Hunter_C.HealMedkitTip
	void NR_HitFakeHunter(struct ABP_Hunter_C* Doppelganger); // Function BP_Hunter.BP_Hunter_C.NR_HitFakeHunter
	void MC_StopRiotShieldGlow(); // Function BP_Hunter.BP_Hunter_C.MC_StopRiotShieldGlow
	void StopRiotShieldEmissive(); // Function BP_Hunter.BP_Hunter_C.StopRiotShieldEmissive
	void OC_ForkliftLaunch(struct FVector_NetQuantize Velocity, bool Override); // Function BP_Hunter.BP_Hunter_C.OC_ForkliftLaunch
	void Server_ForkliftLaunch(struct FVector_NetQuantize Velocity, bool Override); // Function BP_Hunter.BP_Hunter_C.Server_ForkliftLaunch
	void MC_Riotshield_TP_Overheat_VFX(bool Activate); // Function BP_Hunter.BP_Hunter_C.MC_Riotshield_TP_Overheat_VFX
	void StopRiotShieldHeal(); // Function BP_Hunter.BP_Hunter_C.StopRiotShieldHeal
	void Server_RiotShieldHeal(); // Function BP_Hunter.BP_Hunter_C.Server_RiotShieldHeal
	void OC_OverheatRiotShield(); // Function BP_Hunter.BP_Hunter_C.OC_OverheatRiotShield
	void MC_RiotShieldHit(bool Break); // Function BP_Hunter.BP_Hunter_C.MC_RiotShieldHit
	void MC_BreakRiotShield(); // Function BP_Hunter.BP_Hunter_C.MC_BreakRiotShield
	void Server_BreakRiotShield(struct AProp_C* Prop); // Function BP_Hunter.BP_Hunter_C.Server_BreakRiotShield
	void OC_RiotShieldStruck(bool Broke, float CurrentFloat); // Function BP_Hunter.BP_Hunter_C.OC_RiotShieldStruck
	void Server_RiotShieldHit(struct AProp_C* Prop Who Hit, bool Custom Damage, float Damage); // Function BP_Hunter.BP_Hunter_C.Server_RiotShieldHit
	void MC_HideHunterOrb(struct ABP_Hunter_C* Hunter); // Function BP_Hunter.BP_Hunter_C.MC_HideHunterOrb
	void Server_HideHunterOrb(struct ABP_Hunter_C* Hunter); // Function BP_Hunter.BP_Hunter_C.Server_HideHunterOrb
	void ExtraRessGravity(struct ABP_Hunter_C* TargetHunter); // Function BP_Hunter.BP_Hunter_C.ExtraRessGravity
	void ReviveShockRagdoll(struct ABP_Hunter_C* TargetHunter); // Function BP_Hunter.BP_Hunter_C.ReviveShockRagdoll
	void MC_ReviveShockRagdoll(struct ABP_Hunter_C* TargetHunter); // Function BP_Hunter.BP_Hunter_C.MC_ReviveShockRagdoll
	void Server_ReviveShockRagdoll(struct ABP_Hunter_C* TargetHunter); // Function BP_Hunter.BP_Hunter_C.Server_ReviveShockRagdoll
	void MC_TriggerGetupAnimation(struct ABP_Hunter_C* TargetHunter, struct FVector_NetQuantize Location, struct FRotator Rotation, bool Back); // Function BP_Hunter.BP_Hunter_C.MC_TriggerGetupAnimation
	void Server_TriggerGetupAnimation(struct ABP_Hunter_C* TargetHunter, struct FVector_NetQuantize Location, struct FRotator Rotation, bool Back); // Function BP_Hunter.BP_Hunter_C.Server_TriggerGetupAnimation
	void OC_Knockback(struct FVector Velocity); // Function BP_Hunter.BP_Hunter_C.OC_Knockback
	void MC_PlayWraithBurnSounds(); // Function BP_Hunter.BP_Hunter_C.MC_PlayWraithBurnSounds
	void Server_PlayWraithBurnSounds(); // Function BP_Hunter.BP_Hunter_C.Server_PlayWraithBurnSounds
	void MC_Defib_ReviveZapAnimation(); // Function BP_Hunter.BP_Hunter_C.MC_Defib_ReviveZapAnimation
	void Server_SpawnGhostShardsIVacuumed(); // Function BP_Hunter.BP_Hunter_C.Server_SpawnGhostShardsIVacuumed
	void Tutorial_DestroyIn10Sec(); // Function BP_Hunter.BP_Hunter_C.Tutorial_DestroyIn10Sec
	void MC_SaltWaterDamageSound(); // Function BP_Hunter.BP_Hunter_C.MC_SaltWaterDamageSound
	void Server_SaltWaterDamageSound(); // Function BP_Hunter.BP_Hunter_C.Server_SaltWaterDamageSound
	void MC_DamageNameplateFlash(bool Heal); // Function BP_Hunter.BP_Hunter_C.MC_DamageNameplateFlash
	void Server_RevivePending(struct ABP_Hunter_C* Dead Hunter, bool Pending, struct ABP_Hunter_C* Good samaritan); // Function BP_Hunter.BP_Hunter_C.Server_RevivePending
	void Infection_BotHunterBecomeGhost(); // Function BP_Hunter.BP_Hunter_C.Infection_BotHunterBecomeGhost
	void Damaged_Slow(bool Miasma Stacking?); // Function BP_Hunter.BP_Hunter_C.Damaged_Slow
	void MC_PlayMiasmaBurnSounds(); // Function BP_Hunter.BP_Hunter_C.MC_PlayMiasmaBurnSounds
	void Server_PlayMiasmaBurnSounds(); // Function BP_Hunter.BP_Hunter_C.Server_PlayMiasmaBurnSounds
	void OC_LaunchThisHunter(struct FVector_NetQuantize Velocity, bool Override, bool Double); // Function BP_Hunter.BP_Hunter_C.OC_LaunchThisHunter
	void Server_LaunchThisHunter(struct FVector_NetQuantize Velocity, bool Override, bool Double); // Function BP_Hunter.BP_Hunter_C.Server_LaunchThisHunter
	void Server_LaunchCharacter(struct FVector Velocity, struct ACharacter* Character); // Function BP_Hunter.BP_Hunter_C.Server_LaunchCharacter
	void Server_HitFakeHunter(struct ABP_Hunter_C* HunterFake); // Function BP_Hunter.BP_Hunter_C.Server_HitFakeHunter
	void Server_ZKilled(struct ABP_Hunter_C* Hunter); // Function BP_Hunter.BP_Hunter_C.Server_ZKilled
	void OC_DamageEvents(bool No Slow?, bool LessBlur, bool Stacking Slow?, struct APawn* Pawn, struct FVector_NetQuantize Damage Location, char DamageMethod DamageMethod, float Amount); // Function BP_Hunter.BP_Hunter_C.OC_DamageEvents
	void AddAssistPool(struct APawn* Pawn); // Function BP_Hunter.BP_Hunter_C.AddAssistPool
	void DeliverAssistPoints(struct APawn* Pawn); // Function BP_Hunter.BP_Hunter_C.DeliverAssistPoints
	void DeadOnBeginPlay(); // Function BP_Hunter.BP_Hunter_C.DeadOnBeginPlay
	void MC_HunterChilled(); // Function BP_Hunter.BP_Hunter_C.MC_HunterChilled
	void Server_HunterChilled(); // Function BP_Hunter.BP_Hunter_C.Server_HunterChilled
	void Server_ResetDefaultSpeed(); // Function BP_Hunter.BP_Hunter_C.Server_ResetDefaultSpeed
	void MC_ResetDefaultSpeed(); // Function BP_Hunter.BP_Hunter_C.MC_ResetDefaultSpeed
	void Server_SetTrappedSpeed(); // Function BP_Hunter.BP_Hunter_C.Server_SetTrappedSpeed
	void MC_SetTrappedSpeed(); // Function BP_Hunter.BP_Hunter_C.MC_SetTrappedSpeed
	void OC_RedDamageOverlay(); // Function BP_Hunter.BP_Hunter_C.OC_RedDamageOverlay
	void Server_DamageFromGhostWrapper(struct ABP_Hunter_C* BP Hunter, struct FVector Location); // Function BP_Hunter.BP_Hunter_C.Server_DamageFromGhostWrapper
	void NR Friendly Fire(struct ABP_Hunter_C* Hit Hunter, struct FVector Location); // Function BP_Hunter.BP_Hunter_C.NR Friendly Fire
	void Server_ReviveAllSouls(); // Function BP_Hunter.BP_Hunter_C.Server_ReviveAllSouls
	void NR_ReviveAllHunters(); // Function BP_Hunter.BP_Hunter_C.NR_ReviveAllHunters
	void Server_AddHunterSoulToBag(struct ABP_Hunter_C* Dead Hunter); // Function BP_Hunter.BP_Hunter_C.Server_AddHunterSoulToBag
	void NR_SimulatePhysics(struct ABP_Hunter_C* Hunter, struct FVector Vector Hit, struct FVector Location Hit); // Function BP_Hunter.BP_Hunter_C.NR_SimulatePhysics
	void Server_SoulConsumed(struct AProp_C* Prop Who Consumed, struct ABP_DeadHunterOrb_C* Dead Hunter Orb); // Function BP_Hunter.BP_Hunter_C.Server_SoulConsumed
	void NR_SuspendClothSim(struct ABP_Hunter_C* Hunter); // Function BP_Hunter.BP_Hunter_C.NR_SuspendClothSim
	void OC_DeathCleanup(struct AActor* Responsible, char DamageMethod method); // Function BP_Hunter.BP_Hunter_C.OC_DeathCleanup
	void Server_ResurrectHunter(struct ABP_Hunter_C* Hunter, struct ACharacter* Good samaritan); // Function BP_Hunter.BP_Hunter_C.Server_ResurrectHunter
	void NR_SuccessfulRevive(struct ABP_Hunter_C* Dead Hunter, struct ABP_Hunter_C* GoodSamaritan); // Function BP_Hunter.BP_Hunter_C.NR_SuccessfulRevive
	void OC_OverlapResurrection(struct ABP_Hunter_C* Dead Hunter, bool  Begin); // Function BP_Hunter.BP_Hunter_C.OC_OverlapResurrection
	void Server_OverlapResurrection(struct ABP_Hunter_C* Hunter Overlapped, struct ABP_Hunter_C* Dead Hunter, bool  Begin Overlap?); // Function BP_Hunter.BP_Hunter_C.Server_OverlapResurrection
	void MC_DestroyNameplate(struct ABP_Hunter_C* Hunter, bool  Visibile); // Function BP_Hunter.BP_Hunter_C.MC_DestroyNameplate
	void MC_Ragdoll(struct FVector_NetQuantize10 Vector Hit Q, struct FVector_NetQuantize10 Location Hit Q); // Function BP_Hunter.BP_Hunter_C.MC_Ragdoll
	void Server_SetSimulatePhysics(struct FVector_NetQuantize10 Vector Hit Q, struct FVector_NetQuantize10 Location Hit Q); // Function BP_Hunter.BP_Hunter_C.Server_SetSimulatePhysics
	void Server_ReceiveDamageFromGhost(float Amount, struct APawn* Responsible, struct FVector Location, bool Headshot?, struct FVector Velocity, bool Skip Impulse?, char DamageMethod method, bool NoSound, bool Cannot Be Fatal, bool No Slow?, bool LessBlur); // Function BP_Hunter.BP_Hunter_C.Server_ReceiveDamageFromGhost
	void Server_HunterDeath(struct APawn* WhoDoneIt, bool Headshot?, struct FVector Hit Velocity, char DamageMethod method, struct FVector Hit Location); // Function BP_Hunter.BP_Hunter_C.Server_HunterDeath
	void MC_TrailerWeaponSwitching(float TimeBetweenSwitches, bool Skip Anim); // Function BP_Hunter.BP_Hunter_C.MC_TrailerWeaponSwitching
	void Server_TrailerWeaponSwitching(float TimeBetweenSwitches, bool Skip Anim); // Function BP_Hunter.BP_Hunter_C.Server_TrailerWeaponSwitching
	void TrailerWeaponSwitching(float TimeBetweenSwitches, bool Skip Anim); // Function BP_Hunter.BP_Hunter_C.TrailerWeaponSwitching
	void ResetToDefaultSkin_Main(); // Function BP_Hunter.BP_Hunter_C.ResetToDefaultSkin_Main
	void DestroyClothLocs(); // Function BP_Hunter.BP_Hunter_C.DestroyClothLocs
	void ResetSkin_Main(); // Function BP_Hunter.BP_Hunter_C.ResetSkin_Main
	void UI_DestroyAllMeshAndReset_Main(char HunterSkins NewSkin, bool SetHidden, int32_t HeadTexture, int32_t HairModel, int32_t BeardModel); // Function BP_Hunter.BP_Hunter_C.UI_DestroyAllMeshAndReset_Main
	void MC_ResetSkinDebug(int32_t SkinID); // Function BP_Hunter.BP_Hunter_C.MC_ResetSkinDebug
	void Server_ResetSkinDebug(int32_t SkinID); // Function BP_Hunter.BP_Hunter_C.Server_ResetSkinDebug
	void Server_KillAllHuntersTest(); // Function BP_Hunter.BP_Hunter_C.Server_KillAllHuntersTest
	void PrintCantShootDebug(); // Function BP_Hunter.BP_Hunter_C.PrintCantShootDebug
	void DebugFootprints(); // Function BP_Hunter.BP_Hunter_C.DebugFootprints
	void StopDebugFootprints(); // Function BP_Hunter.BP_Hunter_C.StopDebugFootprints
	void StartDebugFootprints(); // Function BP_Hunter.BP_Hunter_C.StartDebugFootprints
	void MC_ForceMaxGeiger(bool MaxGeiger?, struct ABP_Hunter_C* BP Hunter); // Function BP_Hunter.BP_Hunter_C.MC_ForceMaxGeiger
	void Server_DEBUGForceMaximimGeiger(bool MaxGeiger?, struct ABP_Hunter_C* BP Hunter); // Function BP_Hunter.BP_Hunter_C.Server_DEBUGForceMaximimGeiger
	void Server_SetGodMode(); // Function BP_Hunter.BP_Hunter_C.Server_SetGodMode
	void OC_MakeHunterWalkAndFire(bool On, float Delay Before Fire); // Function BP_Hunter.BP_Hunter_C.OC_MakeHunterWalkAndFire
	void Server_MakeHunterWalkAndFire(struct ABP_Hunter_C* BP Hunter, bool On, float Delay Before Fire); // Function BP_Hunter.BP_Hunter_C.Server_MakeHunterWalkAndFire
	void ExecuteUbergraph_BP_Hunter(int32_t EntryPoint); // Function BP_Hunter.BP_Hunter_C.ExecuteUbergraph_BP_Hunter
	void On Grappling Hook Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Grappling Hook Fired__DelegateSignature
	void On ProjectX Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On ProjectX Fired__DelegateSignature
	void On Flamethrower Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Flamethrower Fired__DelegateSignature
	void On Medkit Thrown__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Medkit Thrown__DelegateSignature
	void On Riot Shield Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Riot Shield Fired__DelegateSignature
	void On C4 Detonated__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On C4 Detonated__DelegateSignature
	void On C4 Thrown__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On C4 Thrown__DelegateSignature
	void On Trap Thrown__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Trap Thrown__DelegateSignature
	void On Ghostsmasher Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Ghostsmasher Fired__DelegateSignature
	void On Grenade Thrown__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Grenade Thrown__DelegateSignature
	void On Shield Bash Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Shield Bash Fired__DelegateSignature
	void On Sledgehammer Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Sledgehammer Fired__DelegateSignature
	void On Harpoon Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Harpoon Fired__DelegateSignature
	void On Sniper Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Sniper Fired__DelegateSignature
	void On Nailgun Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Nailgun Fired__DelegateSignature
	void On Salt Shotgun Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Salt Shotgun Fired__DelegateSignature
	void On Spectral Cannon Fired__DelegateSignature(); // Function BP_Hunter.BP_Hunter_C.On Spectral Cannon Fired__DelegateSignature
}; 



