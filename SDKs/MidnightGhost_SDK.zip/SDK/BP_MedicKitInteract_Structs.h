#pragma once 
#include "SDK.h" 
 
 
// Function BP_MedicKitInteract.BP_MedicKitInteract_C.ExecuteUbergraph_BP_MedicKitInteract
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MedicKitInteract
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AMGH_PlayerController_BP_C* K2Node_CustomEvent_Controller;  // 0x8(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x10(0x8)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_MedicKitInteract.BP_MedicKitInteract_C.UseMedicKit
// Size: 0x8(Inherited: 0x0) 
struct FUseMedicKit
{
	struct AMGH_PlayerController_BP_C* Controller;  // 0x0(0x8)

}; 
// Function BP_MedicKitInteract.BP_MedicKitInteract_C.IsThisMyMedicKit
// Size: 0xD(Inherited: 0x0) 
struct FIsThisMyMedicKit
{
	struct ABP_Hunter_C* Hunter;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool YES : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xC(0x1)

}; 
