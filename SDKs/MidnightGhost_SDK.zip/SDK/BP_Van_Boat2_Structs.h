#pragma once 
#include "SDK.h" 
 
 
// Function BP_Van_Boat2.BP_Van_Boat2_C.ExecuteUbergraph_BP_Van_Boat2
// Size: 0x1C0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Van_Boat2
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x10(0xC)
	float CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_DegSin_ReturnValue;  // 0x28(0x4)
	float CallFunc_DegCos_ReturnValue;  // 0x2C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x30(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x34(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x38(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x44(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x48(0x4)
	struct FRotator CallFunc_NormalizedDeltaRotator_ReturnValue;  // 0x4C(0xC)
	float CallFunc_FInterpTo_ReturnValue;  // 0x58(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x5C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x60(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x64(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_2;  // 0x68(0x4)
	float CallFunc_FInterpTo_ReturnValue_2;  // 0x6C(0x4)
	float CallFunc_FInterpTo_ReturnValue_3;  // 0x70(0x4)
	struct FVector CallFunc_Divide_VectorFloat_ReturnValue;  // 0x74(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x80(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x84(0x4)
	float CallFunc_GetGameTimeInSeconds_ReturnValue_2;  // 0x88(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x8C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x90(0x4)
	float CallFunc_DegCos_ReturnValue_2;  // 0x94(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x98(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0x9C(0x4)
	float CallFunc_DegSin_ReturnValue_2;  // 0xA0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_9;  // 0xA4(0x4)
	float CallFunc_Abs_ReturnValue;  // 0xA8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_10;  // 0xAC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_11;  // 0xB0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xB4(0x4)
	float CallFunc_FInterpTo_ReturnValue_4;  // 0xB8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xBC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xC0(0xC)
	struct FVector CallFunc_VLerp_ReturnValue;  // 0xCC(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xD8(0xC)
	float CallFunc_FInterpTo_ReturnValue_5;  // 0xE4(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xE8(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xF4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_12;  // 0xF8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0xFC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_13;  // 0x100(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x104(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x110(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocationAndRotation_SweepHitResult;  // 0x11C(0x88)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x1A4(0x1)
	char pad_421[3];  // 0x1A5(0x3)
	struct FRotator CallFunc_RInterpTo_ReturnValue;  // 0x1A8(0xC)
	char pad_436_1 : 7;  // 0x1B4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1B4(0x1)
	char pad_437_1 : 7;  // 0x1B5(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x1B5(0x1)
	char pad_438[2];  // 0x1B6(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x1B8(0x4)
	char pad_444_1 : 7;  // 0x1BC(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x1BC(0x1)
	char pad_445_1 : 7;  // 0x1BD(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x1BD(0x1)
	char pad_446_1 : 7;  // 0x1BE(0x1)
	bool CallFunc_IsActive_ReturnValue : 1;  // 0x1BE(0x1)
	char pad_447_1 : 7;  // 0x1BF(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1BF(0x1)

}; 
// Function BP_Van_Boat2.BP_Van_Boat2_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Van_Boat2.BP_Van_Boat2_C.InitiatePathMovement
// Size: 0xC(Inherited: 0xC1) 
struct FInitiatePathMovement : public FInitiatePathMovement
{
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x0(0xC)

}; 
