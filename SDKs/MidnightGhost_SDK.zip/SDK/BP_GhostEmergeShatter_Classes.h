#pragma once 
#include <BP_GhostEmergeShatter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GhostEmergeShatter.BP_GhostEmergeShatter_C
// Size: 0x281(Inherited: 0x220) 
struct ABP_GhostEmergeShatter_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* GhostDamaged-BiggerLessIntense;  // 0x228(0x8)
	struct UParticleSystemComponent* ParticleSystem4;  // 0x230(0x8)
	struct UParticleSystemComponent* ParticleSystem3;  // 0x238(0x8)
	struct UParticleSystemComponent* GhostDamaged-Burst2;  // 0x240(0x8)
	struct UParticleSystemComponent* GhostDamaged-Burst;  // 0x248(0x8)
	struct UParticleSystemComponent* GhostDamaged-Burst1;  // 0x250(0x8)
	struct UPointLightComponent* PointLight;  // 0x258(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x260(0x8)
	struct UMaterialInstanceDynamic* GhostMaterial;  // 0x268(0x8)
	struct ABP_GhostShards_C* My_EmergeShatter;  // 0x270(0x8)
	struct AActor* My Owning Player State Emerge;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool Red? : 1;  // 0x280(0x1)

	void ReceiveBeginPlay(); // Function BP_GhostEmergeShatter.BP_GhostEmergeShatter_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_GhostEmergeShatter.BP_GhostEmergeShatter_C.ReceiveTick
	void ExecuteUbergraph_BP_GhostEmergeShatter(int32_t EntryPoint); // Function BP_GhostEmergeShatter.BP_GhostEmergeShatter_C.ExecuteUbergraph_BP_GhostEmergeShatter
}; 



