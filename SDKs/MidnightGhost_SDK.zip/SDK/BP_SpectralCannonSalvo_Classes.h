#pragma once 
#include <BP_SpectralCannonSalvo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C
// Size: 0x27D(Inherited: 0x220) 
struct ABP_SpectralCannonSalvo_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Audio;  // 0x228(0x8)
	struct UParticleSystemComponent* Par_Blaster_5;  // 0x230(0x8)
	struct USphereComponent* BIGGER;  // 0x238(0x8)
	struct UPointLightComponent* PointLight;  // 0x240(0x8)
	struct UProjectileMovementComponent* Projectile;  // 0x248(0x8)
	struct USphereComponent* CollisionComponent;  // 0x250(0x8)
	struct ABP_Hunter_C* WhoShotMe?;  // 0x258(0x8)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool HitAnything? : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool Direct Hit? : 1;  // 0x261(0x1)
	char pad_610[6];  // 0x262(0x6)
	struct AActor* Hit Actor;  // 0x268(0x8)
	struct FVector Hit Location;  // 0x270(0xC)
	char pad_636_1 : 7;  // 0x27C(0x1)
	bool Betrayal? : 1;  // 0x27C(0x1)

	void GetProjectileOwner(struct ABP_Hunter_C*& Hunter); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.GetProjectileOwner
	void Splash Damage Line of Sight(struct AProp_C* Prop to Check, bool&  GO!); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.Splash Damage Line of Sight
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.ReceiveHit
	void Server_SpawnParticles(struct FVector Location); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.Server_SpawnParticles
	void MC_SpawnParticles(struct FVector Location); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.MC_SpawnParticles
	void SpectralCannonSalvoVFX(); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.SpectralCannonSalvoVFX
	void ReceiveBeginPlay(); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.ReceiveBeginPlay
	void Server_Hitmarkers(struct ABP_Hunter_C* Hunter, bool Direct Hit?); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.Server_Hitmarkers
	void Death(); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.Death
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.ReceiveEndPlay
	void Server_DamageProp(int32_t Damage Applied, struct FVector_NetQuantize10 Damage Location, struct AProp_C* Prop Damaged, struct AActor* Responsible, bool Direct Hit?); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.Server_DamageProp
	void BndEvt__CollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.BndEvt__CollisionComponent_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__BIGGER_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.BndEvt__BIGGER_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
	void ExecuteUbergraph_BP_SpectralCannonSalvo(int32_t EntryPoint); // Function BP_SpectralCannonSalvo.BP_SpectralCannonSalvo_C.ExecuteUbergraph_BP_SpectralCannonSalvo
}; 



