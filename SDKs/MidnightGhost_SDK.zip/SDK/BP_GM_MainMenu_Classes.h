#pragma once 
#include <BP_GM_MainMenu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GM_MainMenu.BP_GM_MainMenu_C
// Size: 0x2C8(Inherited: 0x2C0) 
struct ABP_GM_MainMenu_C : public AMGH_BaseGameModeBase
{
	struct USceneComponent* DefaultSceneRoot;  // 0x2C0(0x8)

}; 



