#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AudioModulation.SoundControlBusMixStage
// Size: 0x28(Inherited: 0x0) 
struct FSoundControlBusMixStage
{
	struct USoundControlBus* Bus;  // 0x0(0x8)
	struct FSoundModulationMixValue Value;  // 0x8(0x20)

}; 
// Function AudioModulation.AudioModulationStatics.CreateBusMix
// Size: 0x30(Inherited: 0x0) 
struct FCreateBusMix
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName Name;  // 0x8(0x8)
	struct TArray<struct FSoundControlBusMixStage> Stages;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Activate : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct USoundControlBusMix* ReturnValue;  // 0x28(0x8)

}; 
// ScriptStruct AudioModulation.SoundControlModulationInput
// Size: 0xA0(Inherited: 0x0) 
struct FSoundControlModulationInput
{
	char bSampleAndHold : 1;  // 0x0(0x1)
	char pad_0_1 : 7;  // 0x0(0x1)
	char pad_1[8];  // 0x1(0x8)
	struct FSoundModulationTransform Transform;  // 0x8(0x90)
	struct USoundControlBus* Bus;  // 0x98(0x8)

}; 
// ScriptStruct AudioModulation.SoundModulationMixValue
// Size: 0x20(Inherited: 0x0) 
struct FSoundModulationMixValue
{
	float TargetValue;  // 0x0(0x4)
	float AttackTime;  // 0x4(0x4)
	float ReleaseTime;  // 0x8(0x4)
	char pad_12[20];  // 0xC(0x14)

}; 
// Function AudioModulation.AudioModulationStatics.UpdateMix
// Size: 0x28(Inherited: 0x0) 
struct FUpdateMix
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBusMix* Mix;  // 0x8(0x8)
	struct TArray<struct FSoundControlBusMixStage> Stages;  // 0x10(0x10)
	float FadeTime;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct AudioModulation.SoundModulationTransform
// Size: 0x90(Inherited: 0x0) 
struct FSoundModulationTransform
{
	uint8_t  Curve;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Scalar;  // 0x4(0x4)
	struct FRichCurve CurveCustom;  // 0x8(0x80)
	struct UCurveFloat* CurveShared;  // 0x88(0x8)

}; 
// ScriptStruct AudioModulation.EnvelopeFollowerGeneratorParams
// Size: 0x20(Inherited: 0x0) 
struct FEnvelopeFollowerGeneratorParams
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bBypass : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bInvert : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UAudioBus* AudioBus;  // 0x8(0x8)
	float Gain;  // 0x10(0x4)
	float AttackTime;  // 0x14(0x4)
	float ReleaseTime;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct AudioModulation.SoundModulationLFOParams
// Size: 0x14(Inherited: 0x0) 
struct FSoundModulationLFOParams
{
	uint8_t  Shape;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Amplitude;  // 0x4(0x4)
	float Frequency;  // 0x8(0x4)
	float Offset;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bLooping : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bBypass : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)

}; 
// Function AudioModulation.AudioModulationStatics.ActivateBusMix
// Size: 0x10(Inherited: 0x0) 
struct FActivateBusMix
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBusMix* Mix;  // 0x8(0x8)

}; 
// ScriptStruct AudioModulation.SoundModulationParameterSettings
// Size: 0x4(Inherited: 0x0) 
struct FSoundModulationParameterSettings
{
	float ValueNormalized;  // 0x0(0x4)

}; 
// ScriptStruct AudioModulation.SoundControlModulationPatch
// Size: 0x20(Inherited: 0x0) 
struct FSoundControlModulationPatch
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bBypass : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USoundModulationParameter* OutputParameter;  // 0x8(0x8)
	struct TArray<struct FSoundControlModulationInput> Inputs;  // 0x10(0x10)

}; 
// Function AudioModulation.AudioModulationStatics.ActivateBus
// Size: 0x10(Inherited: 0x0) 
struct FActivateBus
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBus* Bus;  // 0x8(0x8)

}; 
// Function AudioModulation.AudioModulationStatics.ActivateGenerator
// Size: 0x10(Inherited: 0x0) 
struct FActivateGenerator
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundModulationGenerator* Generator;  // 0x8(0x8)

}; 
// Function AudioModulation.AudioModulationStatics.CreateBus
// Size: 0x28(Inherited: 0x0) 
struct FCreateBus
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName Name;  // 0x8(0x8)
	struct USoundModulationParameter* Parameter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Activate : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct USoundControlBus* ReturnValue;  // 0x20(0x8)

}; 
// Function AudioModulation.AudioModulationStatics.UpdateMixByFilter
// Size: 0x38(Inherited: 0x0) 
struct FUpdateMixByFilter
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBusMix* Mix;  // 0x8(0x8)
	struct FString AddressFilter;  // 0x10(0x10)
	USoundModulationParameter* ParamClassFilter;  // 0x20(0x8)
	struct USoundModulationParameter* ParamFilter;  // 0x28(0x8)
	float Value;  // 0x30(0x4)
	float FadeTime;  // 0x34(0x4)

}; 
// Function AudioModulation.AudioModulationStatics.CreateBusMixStage
// Size: 0x48(Inherited: 0x0) 
struct FCreateBusMixStage
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBus* Bus;  // 0x8(0x8)
	float Value;  // 0x10(0x4)
	float AttackTime;  // 0x14(0x4)
	float ReleaseTime;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FSoundControlBusMixStage ReturnValue;  // 0x20(0x28)

}; 
// Function AudioModulation.AudioModulationStatics.DeactivateBus
// Size: 0x10(Inherited: 0x0) 
struct FDeactivateBus
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBus* Bus;  // 0x8(0x8)

}; 
// Function AudioModulation.AudioModulationStatics.DeactivateBusMix
// Size: 0x10(Inherited: 0x0) 
struct FDeactivateBusMix
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBusMix* Mix;  // 0x8(0x8)

}; 
// Function AudioModulation.AudioModulationStatics.DeactivateGenerator
// Size: 0x10(Inherited: 0x0) 
struct FDeactivateGenerator
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundModulationGenerator* Generator;  // 0x8(0x8)

}; 
// Function AudioModulation.AudioModulationStatics.LoadMixFromProfile
// Size: 0x28(Inherited: 0x0) 
struct FLoadMixFromProfile
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBusMix* Mix;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bActivate : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ProfileIndex;  // 0x14(0x4)
	struct TArray<struct FSoundControlBusMixStage> ReturnValue;  // 0x18(0x10)

}; 
// Function AudioModulation.AudioModulationStatics.SaveMixToProfile
// Size: 0x18(Inherited: 0x0) 
struct FSaveMixToProfile
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBusMix* Mix;  // 0x8(0x8)
	int32_t ProfileIndex;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AudioModulation.AudioModulationStatics.UpdateMixFromObject
// Size: 0x18(Inherited: 0x0) 
struct FUpdateMixFromObject
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundControlBusMix* Mix;  // 0x8(0x8)
	float FadeTime;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor
// Size: 0x4(Inherited: 0x0) 
struct FGetModulationGeneratorColor
{
	struct FColor ReturnValue;  // 0x0(0x4)

}; 
// Function AudioModulation.AudioModulationStatics.UpdateModulator
// Size: 0x10(Inherited: 0x0) 
struct FUpdateModulator
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct USoundModulatorBase* Modulator;  // 0x8(0x8)

}; 
// Function AudioModulation.AudioModulationStyle.GetControlBusColor
// Size: 0x4(Inherited: 0x0) 
struct FGetControlBusColor
{
	struct FColor ReturnValue;  // 0x0(0x4)

}; 
// Function AudioModulation.AudioModulationStyle.GetControlBusMixColor
// Size: 0x4(Inherited: 0x0) 
struct FGetControlBusMixColor
{
	struct FColor ReturnValue;  // 0x0(0x4)

}; 
// Function AudioModulation.AudioModulationStyle.GetParameterColor
// Size: 0x4(Inherited: 0x0) 
struct FGetParameterColor
{
	struct FColor ReturnValue;  // 0x0(0x4)

}; 
// Function AudioModulation.AudioModulationStyle.GetPatchColor
// Size: 0x4(Inherited: 0x0) 
struct FGetPatchColor
{
	struct FColor ReturnValue;  // 0x0(0x4)

}; 
