#pragma once 
#include <Ai_SomethingHappend_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_SomethingHappend.Ai_SomethingHappend_C
// Size: 0xD9(Inherited: 0xA8) 
struct UAi_SomethingHappend_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector TargetActor;  // 0xB0(0x28)
	char Ai_Happenings What Happend;  // 0xD8(0x1)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_SomethingHappend.Ai_SomethingHappend_C.ReceiveExecuteAI
	void ExecuteUbergraph_Ai_SomethingHappend(int32_t EntryPoint); // Function Ai_SomethingHappend.Ai_SomethingHappend_C.ExecuteUbergraph_Ai_SomethingHappend
}; 



