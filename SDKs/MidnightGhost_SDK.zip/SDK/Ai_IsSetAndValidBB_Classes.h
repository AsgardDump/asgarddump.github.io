#pragma once 
#include <Ai_IsSetAndValidBB_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_IsSetAndValidBB.Ai_IsSetAndValidBB_C
// Size: 0xC8(Inherited: 0xA0) 
struct UAi_IsSetAndValidBB_C : public UBTDecorator_BlueprintBase
{
	struct FBlackboardKeySelector BBToCheck;  // 0xA0(0x28)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_IsSetAndValidBB.Ai_IsSetAndValidBB_C.PerformConditionCheckAI
}; 



