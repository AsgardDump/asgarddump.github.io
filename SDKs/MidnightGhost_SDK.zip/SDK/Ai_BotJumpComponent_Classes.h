#pragma once 
#include <Ai_BotJumpComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_BotJumpComponent.Ai_BotJumpComponent_C
// Size: 0xF0(Inherited: 0xB0) 
struct UAi_BotJumpComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool OngoingJump : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	float JumpProgress;  // 0xBC(0x4)
	struct ACharacter* ControlledCharacter;  // 0xC0(0x8)
	float InitialSpeedBoost;  // 0xC8(0x4)
	float ZTangentSpeedBoost;  // 0xCC(0x4)
	float JumpSpeed;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct AAi_BotJumpPath_C* JumpPath;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool FaceJumpDirection : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct AAIController* AIController;  // 0xE8(0x8)

	void JumpFinished(); // Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.JumpFinished
	void ClearBotJump(); // Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.ClearBotJump
	void ReceiveTick(float DeltaSeconds); // Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.ReceiveTick
	void StartNewJump(struct AAi_BotJumpPath_C* JumpPath); // Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.StartNewJump
	void ExecuteUbergraph_Ai_BotJumpComponent(int32_t EntryPoint); // Function Ai_BotJumpComponent.Ai_BotJumpComponent_C.ExecuteUbergraph_Ai_BotJumpComponent
}; 



