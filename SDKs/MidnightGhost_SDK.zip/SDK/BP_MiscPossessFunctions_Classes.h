#pragma once 
#include <BP_MiscPossessFunctions_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MiscPossessFunctions.BP_MiscPossessFunctions_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_MiscPossessFunctions_C : public UBlueprintFunctionLibrary
{

	void GetPossessedClassForUnpossessed(AActor* ClassIn, struct UObject* __WorldContext, AActor*& Class, bool& Found, struct FVector& CamOffset); // Function BP_MiscPossessFunctions.BP_MiscPossessFunctions_C.GetPossessedClassForUnpossessed
	void GetUnpossessedClassForPossessed(AActor* ClassIn, struct UObject* __WorldContext, AActor*& ClassOut, struct UStaticMesh*& BaseMesh, bool& Found); // Function BP_MiscPossessFunctions.BP_MiscPossessFunctions_C.GetUnpossessedClassForPossessed
}; 



