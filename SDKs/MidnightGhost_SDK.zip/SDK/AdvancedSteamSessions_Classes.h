#pragma once 
#include <AdvancedSteamSessions_Structs.h>
 
 
 
// Class AdvancedSteamSessions.AdvancedSteamFriendsLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedSteamFriendsLibrary : public UBlueprintFunctionLibrary
{

	bool RequestSteamFriendInfo(struct FBPUniqueNetId UniqueNetId, bool bRequireNameOnly); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.RequestSteamFriendInfo
	struct FBPUniqueNetId ReplToBPUniqueNetID(struct FUniqueNetIdRepl UniqueReplID); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.ReplToBPUniqueNetID
	bool OpenSteamUserOverlay(struct FBPUniqueNetId UniqueNetId, uint8_t  DialogType); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.OpenSteamUserOverlay
	bool IsSteamInBigPictureMode(); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.IsSteamInBigPictureMode
	bool IsOverlayEnabled(); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.IsOverlayEnabled
	bool InitTextFiltering(); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.InitTextFiltering
	struct FString GetSteamPersonaName(struct FBPUniqueNetId UniqueNetId); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamPersonaName
	void GetSteamGroups(struct TArray<struct FBPSteamGroupInfo>& SteamGroups); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamGroups
	void GetSteamFriendGamePlayed(struct FBPUniqueNetId UniqueNetId, uint8_t & Result, int32_t& AppId); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamFriendGamePlayed
	struct UTexture2D* GetSteamFriendAvatar(struct FBPUniqueNetId UniqueNetId, uint8_t & Result, uint8_t  AvatarSize); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetSteamFriendAvatar
	struct FBPUniqueNetId GetLocalSteamIDFromSteam(); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetLocalSteamIDFromSteam
	int32_t GetFriendSteamLevel(struct FBPUniqueNetId UniqueNetId); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.GetFriendSteamLevel
	bool FilterText(struct FString TextToFilter, uint8_t  Context, struct FBPUniqueNetId TextSourceID, struct FString& FilteredText); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.FilterText
	struct FBPUniqueNetId CreateSteamIDFromString(struct FString SteamID64); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.CreateSteamIDFromString
	struct FUniqueNetIdRepl BPToReplUniqueNetID(struct FBPUniqueNetId UniqueReplID); // Function AdvancedSteamSessions.AdvancedSteamFriendsLibrary.BPToReplUniqueNetID
}; 



// Class AdvancedSteamSessions.AdvancedSteamWorkshopLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAdvancedSteamWorkshopLibrary : public UBlueprintFunctionLibrary
{

	struct TArray<struct FBPSteamWorkshopID> GetSubscribedWorkshopItems(int32_t& NumberOfItems); // Function AdvancedSteamSessions.AdvancedSteamWorkshopLibrary.GetSubscribedWorkshopItems
	void GetNumSubscribedWorkshopItems(int32_t& NumberOfItems); // Function AdvancedSteamSessions.AdvancedSteamWorkshopLibrary.GetNumSubscribedWorkshopItems
}; 



// Class AdvancedSteamSessions.SteamRequestGroupOfficersCallbackProxy
// Size: 0xA0(Inherited: 0x30) 
struct USteamRequestGroupOfficersCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[80];  // 0x50(0x50)

	struct USteamRequestGroupOfficersCallbackProxy* GetSteamGroupOfficerList(struct UObject* WorldContextObject, struct FBPUniqueNetId GroupUniqueNetID); // Function AdvancedSteamSessions.SteamRequestGroupOfficersCallbackProxy.GetSteamGroupOfficerList
}; 



// Class AdvancedSteamSessions.SteamWSRequestUGCDetailsCallbackProxy
// Size: 0x88(Inherited: 0x30) 
struct USteamWSRequestUGCDetailsCallbackProxy : public UOnlineBlueprintCallProxyBase
{
	struct FMulticastInlineDelegate OnSuccess;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x40(0x10)
	char pad_80[56];  // 0x50(0x38)

	struct USteamWSRequestUGCDetailsCallbackProxy* GetWorkshopItemDetails(struct UObject* WorldContextObject, struct FBPSteamWorkshopID WorkShopID); // Function AdvancedSteamSessions.SteamWSRequestUGCDetailsCallbackProxy.GetWorkshopItemDetails
}; 



