#pragma once 
#include "SDK.h" 
 
 
// Function BP_DefaultSpectator.BP_DefaultSpectator_C.ExecuteUbergraph_BP_DefaultSpectator
// Size: 0xB9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DefaultSpectator
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUserWidget* CallFunc_CreateBeginUIDebug_Ref;  // 0x8(0x8)
	char Team Temp_byte_Variable;  // 0x10(0x1)
	char Team Temp_byte_Variable_2;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x18(0x18)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x30(0x18)
	char GhostAbility K2Node_CustomEvent_SelectedGhostSpec;  // 0x48(0x1)
	char Spectator_Form K2Node_CustomEvent_ProposedTeam;  // 0x49(0x1)
	char HunterSpec K2Node_CustomEvent_SelectedHunterSpec;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x50(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x68(0x8)
	char Team Temp_byte_Variable_3;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_CheckIfCanDebug_No___Yes : 1;  // 0x81(0x1)
	char Spectator_Form Temp_byte_Variable_4;  // 0x82(0x1)
	char pad_131_1 : 7;  // 0x83(0x1)
	bool Temp_bool_Variable : 1;  // 0x83(0x1)
	char Team K2Node_Select_Default;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x85(0x1)
	char pad_134[2];  // 0x86(0x2)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x88(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x98(0x10)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0xA8(0x8)
	struct AMGH_PlayerController_BP_C* K2Node_DynamicCast_AsMGH_Player_Controller_BP_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xB8(0x1)

}; 
// Function BP_DefaultSpectator.BP_DefaultSpectator_C.Set_SelectedHunterClass
// Size: 0x1(Inherited: 0x0) 
struct FSet_SelectedHunterClass
{
	char HunterSpec SelectedHunterSpec;  // 0x0(0x1)

}; 
// Function BP_DefaultSpectator.BP_DefaultSpectator_C.Set_SelectedGhostClass
// Size: 0x1(Inherited: 0x0) 
struct FSet_SelectedGhostClass
{
	char GhostAbility SelectedGhostSpec;  // 0x0(0x1)

}; 
// Function BP_DefaultSpectator.BP_DefaultSpectator_C.Server_SetMyProposedTeam
// Size: 0x1(Inherited: 0x0) 
struct FServer_SetMyProposedTeam
{
	char Spectator_Form ProposedTeam;  // 0x0(0x1)

}; 
// Function BP_DefaultSpectator.BP_DefaultSpectator_C.InpActEvt_Tab_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Tab_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_DefaultSpectator.BP_DefaultSpectator_C.InpActEvt_NumPadZero_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_NumPadZero_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
