#pragma once 
#include "SDK.h" 
 
 
// Function AttachedFollowActor.AttachedFollowActor_C.ExecuteUbergraph_AttachedFollowActor
// Size: 0x1A5(Inherited: 0x0) 
struct FExecuteUbergraph_AttachedFollowActor
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	char Ghost_SizeClass Temp_byte_Variable;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x18(0x88)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	float Temp_float_Variable;  // 0xA4(0x4)
	float Temp_float_Variable_2;  // 0xA8(0x4)
	float Temp_float_Variable_3;  // 0xAC(0x4)
	float Temp_float_Variable_4;  // 0xB0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	float K2Node_Select_Default;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xC4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0xD0(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0xDC(0xC)
	struct FVector CallFunc_Conv_RotatorToVector_ReturnValue;  // 0xE8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0xF4(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x100(0xC)
	float K2Node_Select_Default_2;  // 0x10C(0x4)
	struct FVector CallFunc_VInterpTo_ReturnValue;  // 0x110(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult_2;  // 0x11C(0x88)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue_2 : 1;  // 0x1A4(0x1)

}; 
// Function AttachedFollowActor.AttachedFollowActor_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
