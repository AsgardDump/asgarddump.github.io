#pragma once 
#include <BlackScreen_UI_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BlackScreen_UI.BlackScreen_UI_C
// Size: 0x268(Inherited: 0x260) 
struct UBlackScreen_UI_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)

	void Construct(); // Function BlackScreen_UI.BlackScreen_UI_C.Construct
	void ExecuteUbergraph_BlackScreen_UI(int32_t EntryPoint); // Function BlackScreen_UI.BlackScreen_UI_C.ExecuteUbergraph_BlackScreen_UI
}; 



