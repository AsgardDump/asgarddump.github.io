#pragma once 
#include <BP_Keybinding_Functions_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Keybinding_Functions.BP_Keybinding_Functions_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_Keybinding_Functions_C : public UBlueprintFunctionLibrary
{

	void CheckIsGamepadKeyInUse(struct FKey Key, char KeyBindingCategory KeyCategory, struct TArray<struct UWB_KeybindingButton_C*>& AllKeybindingWidgets, struct UWB_KeybindingButton_C* KeyBindingWidgetChecking, struct UObject* __WorldContext, bool& IsReserved, struct UWB_KeybindingButton_C*& SameKeyWidget); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.CheckIsGamepadKeyInUse
	void CheckIsKeyboardKeyInUse(struct FKey Key, char KeyBindingCategory KeyCategory, struct TArray<struct UWB_KeybindingButton_C*>& AllKeybindingWidgets, struct UWB_KeybindingButton_C* KeyBindingWidgetChecking, struct UObject* __WorldContext, bool& IsReserved, struct UWB_KeybindingButton_C*& SameKeyWidget); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.CheckIsKeyboardKeyInUse
	void CheckIsKeyInUse(struct FKey Key, char KeyBindingCategory KeyCategory, struct TArray<struct UWB_KeybindingButton_C*>& AllKeybindingWidgets, struct UObject* __WorldContext, bool& IsReserved, struct FName& MappingName); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.CheckIsKeyInUse
	bool FindAxisMappingKeyboardKeyByName(struct FName& ItemToFind, struct UObject* __WorldContext, struct FKey& Key, float& Scale); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.FindAxisMappingKeyboardKeyByName
	bool FindAxisMappingGamepadKeyByName(struct FName& ItemToFind, struct UObject* __WorldContext, struct FKey& Key, float& Scale); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.FindAxisMappingGamepadKeyByName
	bool FindActionMappingKeyboardKeyByName(struct FName& ItemToFind, struct UObject* __WorldContext, struct FKey& Key); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.FindActionMappingKeyboardKeyByName
	bool FindActionMappingGamepadKeyByName(struct FName& ItemToFind, struct UObject* __WorldContext, struct FKey& Key); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.FindActionMappingGamepadKeyByName
	void IsMouseKey(struct FKey Key, struct UObject* __WorldContext, bool& bIsMouseKey); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.IsMouseKey
	void IsKeyboardKey(struct FKey Key, struct UObject* __WorldContext, bool& bIsKeyboardKey); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.IsKeyboardKey
	void IsGamepadKey(struct FKey Key, struct UObject* __WorldContext, bool& bIsGamepadKey); // Function BP_Keybinding_Functions.BP_Keybinding_Functions_C.IsGamepadKey
}; 



