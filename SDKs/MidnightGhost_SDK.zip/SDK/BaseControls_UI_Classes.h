#pragma once 
#include <BaseControls_UI_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BaseControls_UI.BaseControls_UI_C
// Size: 0x2A0(Inherited: 0x260) 
struct UBaseControls_UI_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* FadeIn;  // 0x268(0x8)
	struct UCanvasPanel* CanvasPanel_1;  // 0x270(0x8)
	struct UImage* Image;  // 0x278(0x8)
	struct UImage* Image_2;  // 0x280(0x8)
	struct UImage* Image_3;  // 0x288(0x8)
	struct UImage* Image_4;  // 0x290(0x8)
	struct UImage* Image_51;  // 0x298(0x8)

	void Construct(); // Function BaseControls_UI.BaseControls_UI_C.Construct
	void FadeOut(); // Function BaseControls_UI.BaseControls_UI_C.FadeOut
	void ExecuteUbergraph_BaseControls_UI(int32_t EntryPoint); // Function BaseControls_UI.BaseControls_UI_C.ExecuteUbergraph_BaseControls_UI
}; 



