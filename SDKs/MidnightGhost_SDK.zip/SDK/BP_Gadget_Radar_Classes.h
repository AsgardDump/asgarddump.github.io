#pragma once 
#include <BP_Gadget_Radar_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Gadget_Radar.BP_Gadget_Radar_C
// Size: 0x2C8(Inherited: 0x25C) 
struct ABP_Gadget_Radar_C : public ABP_Gadget_C
{
	char pad_604[4];  // 0x25C(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct URadarTickSoundController_C* RadarTickSoundController;  // 0x268(0x8)
	struct ABP_Gadget_TP_Radar_C* GadgetTP;  // 0x270(0x8)
	struct ABP_Gadget_FP_Radar_C* GadgetFP;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool ReadyForRadarSound : 1;  // 0x280(0x1)
	char pad_641[3];  // 0x281(0x3)
	float RadarDistance;  // 0x284(0x4)
	float RadiationOfNearestGhost;  // 0x288(0x4)
	char pad_652_1 : 7;  // 0x28C(0x1)
	bool ForceZeroRadarReading : 1;  // 0x28C(0x1)
	char pad_653[3];  // 0x28D(0x3)
	float Radar_Closeness;  // 0x290(0x4)
	char pad_660_1 : 7;  // 0x294(0x1)
	bool ForceMaximimGeiger? : 1;  // 0x294(0x1)
	char pad_661_1 : 7;  // 0x295(0x1)
	bool Radar_Activated : 1;  // 0x295(0x1)
	char pad_662_1 : 7;  // 0x296(0x1)
	bool RadarLightOn : 1;  // 0x296(0x1)
	char pad_663[1];  // 0x297(0x1)
	struct UMaterialInstanceDynamic* Radar_Mtl_FP;  // 0x298(0x8)
	float NearestGhostDistance;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct AActor* NearestGhostActor;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Dead Ghost Nearby? : 1;  // 0x2B0(0x1)
	char pad_689_1 : 7;  // 0x2B1(0x1)
	bool RadarEquippped : 1;  // 0x2B1(0x1)
	char pad_690[2];  // 0x2B2(0x2)
	float RadarLightOffTimer;  // 0x2B4(0x4)
	float ClosestDistance;  // 0x2B8(0x4)
	char pad_700[4];  // 0x2BC(0x4)
	struct AActor* ClosestActor;  // 0x2C0(0x8)

	void RecentlyGotTrackingHit(bool Radar, bool pathfinder, bool Spectrophone); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.RecentlyGotTrackingHit
	void GetNearestRadarGhostActivity(bool& Found?, struct AActor*& Actor, float& Distance); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.GetNearestRadarGhostActivity
	void GetTPActor(struct ABP_Gadget_TP_C*& TPActor); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.GetTPActor
	void GetFPActor(struct ABP_Gadget_FP_C*& FPActor); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.GetFPActor
	void ReceiveBeginPlay(); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.ReceiveBeginPlay
	void RadarClosenessLoop(); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.RadarClosenessLoop
	void WarmerOrColder(bool NoSound); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.WarmerOrColder
	void Init(); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.Init
	void NearestGhostLoop(); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.NearestGhostLoop
	void UpdateVisibility(bool Hide, bool SkipAnimation, bool TickWhileHidden, bool NonLocallyControlledOrBot, bool ShouldInterrupt); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.UpdateVisibility
	void ExecuteUbergraph_BP_Gadget_Radar(int32_t EntryPoint); // Function BP_Gadget_Radar.BP_Gadget_Radar_C.ExecuteUbergraph_BP_Gadget_Radar
}; 



