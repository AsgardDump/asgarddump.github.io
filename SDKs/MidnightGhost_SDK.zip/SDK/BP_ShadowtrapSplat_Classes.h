#pragma once 
#include <BP_ShadowtrapSplat_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ShadowtrapSplat.BP_ShadowtrapSplat_C
// Size: 0x2A0(Inherited: 0x220) 
struct ABP_ShadowtrapSplat_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Sphere;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Timeline_0_Opacity_30C25382446275FDA125B597A7BCA815;  // 0x238(0x4)
	char ETimelineDirection Timeline_0__Direction_30C25382446275FDA125B597A7BCA815;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x240(0x8)
	float FadeInMaterial_Opacity_73A266614D7C6C6D07204194741AAE93;  // 0x248(0x4)
	char ETimelineDirection FadeInMaterial__Direction_73A266614D7C6C6D07204194741AAE93;  // 0x24C(0x1)
	char pad_589[3];  // 0x24D(0x3)
	struct UTimelineComponent* FadeInMaterial;  // 0x250(0x8)
	float FadeoutMaterial_Opacity_88EA030648F63245466A219388797469;  // 0x258(0x4)
	char ETimelineDirection FadeoutMaterial__Direction_88EA030648F63245466A219388797469;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct UTimelineComponent* FadeoutMaterial;  // 0x260(0x8)
	float FadeoutSlow_Opacity_5CA8273A4FD4C5F697DCCD827C843759;  // 0x268(0x4)
	char ETimelineDirection FadeoutSlow__Direction_5CA8273A4FD4C5F697DCCD827C843759;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct UTimelineComponent* FadeoutSlow;  // 0x270(0x8)
	struct UDecalComponent* MyDecal;  // 0x278(0x8)
	struct UMaterialInstanceDynamic* EctoplasmTrailMaterialRef;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool Skip Fade Out? : 1;  // 0x288(0x1)
	char Ghost_SizeClass Size Class;  // 0x289(0x1)
	char pad_650_1 : 7;  // 0x28A(0x1)
	bool Fading Out! : 1;  // 0x28A(0x1)
	char pad_651[5];  // 0x28B(0x5)
	struct UMaterialInterface* DecalMaterial;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool Corrupted? : 1;  // 0x298(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	bool Local : 1;  // 0x299(0x1)
	char pad_666[2];  // 0x29A(0x2)
	float Freshness;  // 0x29C(0x4)

	void CheckOwnerDistance?(bool&  OK); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.CheckOwnerDistance?
	void UserConstructionScript(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.UserConstructionScript
	void FadeoutMaterial__FinishedFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeoutMaterial__FinishedFunc
	void FadeoutMaterial__UpdateFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeoutMaterial__UpdateFunc
	void FadeoutSlow__FinishedFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeoutSlow__FinishedFunc
	void FadeoutSlow__UpdateFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeoutSlow__UpdateFunc
	void FadeInMaterial__FinishedFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeInMaterial__FinishedFunc
	void FadeInMaterial__UpdateFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeInMaterial__UpdateFunc
	void Timeline_0__FinishedFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.Timeline_0__UpdateFunc
	void SetHidden?(bool Hidden?); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.SetHidden?
	void FadeOut(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeOut
	void ReceiveBeginPlay(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.ReceiveBeginPlay
	void Fadeout_Slow(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.Fadeout_Slow
	void FadeIn(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.FadeIn
	void Corruption_Fadeout(); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.Corruption_Fadeout
	void ExecuteUbergraph_BP_ShadowtrapSplat(int32_t EntryPoint); // Function BP_ShadowtrapSplat.BP_ShadowtrapSplat_C.ExecuteUbergraph_BP_ShadowtrapSplat
}; 



