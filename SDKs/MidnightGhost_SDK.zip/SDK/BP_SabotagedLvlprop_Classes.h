#pragma once 
#include <BP_SabotagedLvlprop_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SabotagedLvlprop.BP_SabotagedLvlprop_C
// Size: 0x291(Inherited: 0x220) 
struct ABP_SabotagedLvlprop_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* Niagara;  // 0x228(0x8)
	struct USphereComponent* OverlapSphere;  // 0x230(0x8)
	struct UParticleSystemComponent* Explosion;  // 0x238(0x8)
	struct UParticleSystemComponent* PS_Arcs_Omni1;  // 0x240(0x8)
	struct UParticleSystemComponent* PS_Arcs_Omni;  // 0x248(0x8)
	struct UAudioComponent* implosion01;  // 0x250(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x258(0x8)
	struct TArray<struct ABP_Hunter_C*> Hunters Raycasted;  // 0x260(0x10)
	struct AMGH_PlayerState_C* Who Sabotaged;  // 0x270(0x8)
	struct TArray<float> Hunters Raycasted Distances;  // 0x278(0x10)
	float DamageDivider;  // 0x288(0x4)
	float DamageRange;  // 0x28C(0x4)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool Door? : 1;  // 0x290(0x1)

	void CheckLoS(struct AActor* Origin, struct AActor* Target, bool& Line of Sight?); // Function BP_SabotagedLvlprop.BP_SabotagedLvlprop_C.CheckLoS
	void ReceiveBeginPlay(); // Function BP_SabotagedLvlprop.BP_SabotagedLvlprop_C.ReceiveBeginPlay
	void Server_CorruptionHitShield(struct ABP_Hunter_C* BPHunter); // Function BP_SabotagedLvlprop.BP_SabotagedLvlprop_C.Server_CorruptionHitShield
	void ExecuteUbergraph_BP_SabotagedLvlprop(int32_t EntryPoint); // Function BP_SabotagedLvlprop.BP_SabotagedLvlprop_C.ExecuteUbergraph_BP_SabotagedLvlprop
}; 



