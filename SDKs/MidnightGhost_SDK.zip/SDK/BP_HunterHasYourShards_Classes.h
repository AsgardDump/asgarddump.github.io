#pragma once 
#include <BP_HunterHasYourShards_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HunterHasYourShards.BP_HunterHasYourShards_C
// Size: 0x258(Inherited: 0x220) 
struct ABP_HunterHasYourShards_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UWidgetComponent* Widget;  // 0x228(0x8)
	struct UParticleSystemComponent* P_SmokeWisp1-loop1;  // 0x230(0x8)
	struct UParticleSystemComponent* P_SmokeWisp1-loop;  // 0x238(0x8)
	struct UPointLightComponent* PointLight;  // 0x240(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x248(0x8)
	struct ABP_Hunter_C* MyOwner;  // 0x250(0x8)

	void ReceiveBeginPlay(); // Function BP_HunterHasYourShards.BP_HunterHasYourShards_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_HunterHasYourShards.BP_HunterHasYourShards_C.ReceiveTick
	void ExecuteUbergraph_BP_HunterHasYourShards(int32_t EntryPoint); // Function BP_HunterHasYourShards.BP_HunterHasYourShards_C.ExecuteUbergraph_BP_HunterHasYourShards
}; 



