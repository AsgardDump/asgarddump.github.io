#pragma once 
#include <BestTeam_AiController_Structs.h>
 
 
 
// BlueprintGeneratedClass BestTeam_AiController.BestTeam_AiController_C
// Size: 0x330(Inherited: 0x328) 
struct ABestTeam_AiController_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x328(0x8)

	void ReceiveBeginPlay(); // Function BestTeam_AiController.BestTeam_AiController_C.ReceiveBeginPlay
	void ExecuteUbergraph_BestTeam_AiController(int32_t EntryPoint); // Function BestTeam_AiController.BestTeam_AiController_C.ExecuteUbergraph_BestTeam_AiController
}; 



