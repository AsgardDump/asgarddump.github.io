#pragma once 
#include "SDK.h" 
 
 
// Function BP_KeyInput_AnalogAxis_RemoveDelta.BP_KeyInput_AnalogAxis_RemoveDelta_C.Key Input Current State
// Size: 0x24(Inherited: 0x2D) 
struct FKey Input Current State : public FKey Input Current State
{
	struct APlayerController* Controller;  // 0x0(0x8)
	float Axis Value;  // 0x8(0x4)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool Down : 1;  // 0xC(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool Just Pressed : 1;  // 0xD(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool Just Released : 1;  // 0xE(0x1)
	float CallFunc_Key_Input_Current_State_Axis_Value;  // 0x10(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Key_Input_Current_State_Down : 1;  // 0x14(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Key_Input_Current_State_Just_Pressed : 1;  // 0x15(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_Key_Input_Current_State_Just_Released : 1;  // 0x16(0x1)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x18(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x20(0x4)

}; 
