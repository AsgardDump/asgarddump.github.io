#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction AutoSettings.IntCVarChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FIntCVarChangedEvent__DelegateSignature
{
	int32_t NewValue;  // 0x0(0x4)

}; 
// Function AutoSettings.AutoSettingsPlayer.GetDefaultInputMappingPreset
// Size: 0x20(Inherited: 0x0) 
struct FGetDefaultInputMappingPreset
{
	struct FInputMappingPreset ReturnValue;  // 0x0(0x20)

}; 
// DelegateFunction AutoSettings.FloatCVarChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FFloatCVarChangedEvent__DelegateSignature
{
	float NewValue;  // 0x0(0x4)

}; 
// Function AutoSettings.InputMappingManager.AddPlayerAxisOverride
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerAxisOverride
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputAxisKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// ScriptStruct AutoSettings.KeyFriendlyName
// Size: 0x30(Inherited: 0x0) 
struct FKeyFriendlyName
{
	struct FKey Key;  // 0x0(0x18)
	struct FText FriendlyName;  // 0x18(0x18)

}; 
// DelegateFunction AutoSettings.BoolCVarChangedEvent__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBoolCVarChangedEvent__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction AutoSettings.IntCVarChangedSignature__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FIntCVarChangedSignature__DelegateSignature
{
	int32_t NewValue;  // 0x0(0x4)

}; 
// DelegateFunction AutoSettings.StringCVarChangedEvent__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FStringCVarChangedEvent__DelegateSignature
{
	struct FString NewValue;  // 0x0(0x10)

}; 
// Function AutoSettings.AutoSettingWidget.HasUnsavedChange
// Size: 0x1(Inherited: 0x0) 
struct FHasUnsavedChange
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction AutoSettings.FloatCVarChangedSignature__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FFloatCVarChangedSignature__DelegateSignature
{
	float NewValue;  // 0x0(0x4)

}; 
// ScriptStruct AutoSettings.SettingOption
// Size: 0x28(Inherited: 0x0) 
struct FSettingOption
{
	struct FText Label;  // 0x0(0x18)
	struct FString Value;  // 0x18(0x10)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddStringCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddStringCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function AutoSettings.KeyLabel.GetIconBrush
// Size: 0x88(Inherited: 0x0) 
struct FGetIconBrush
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)

}; 
// Function AutoSettings.AutoSettingWidget.ApplySettingValue
// Size: 0x18(Inherited: 0x0) 
struct FApplySettingValue
{
	struct FString Value;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bSaveIfPossible : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.InputLabel.MappingsChanged
// Size: 0x8(Inherited: 0x0) 
struct FMappingsChanged
{
	struct APlayerController* Player;  // 0x0(0x8)

}; 
// DelegateFunction AutoSettings.BoolCVarChangedSignature__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBoolCVarChangedSignature__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction AutoSettings.StringCVarChangedSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FStringCVarChangedSignature__DelegateSignature
{
	struct FString NewValue;  // 0x0(0x10)

}; 
// DelegateFunction AutoSettings.MappingsChangedEvent__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FMappingsChangedEvent__DelegateSignature
{
	struct APlayerController* Player;  // 0x0(0x8)

}; 
// Function AutoSettings.KeyLabel.GetIcon
// Size: 0x8(Inherited: 0x0) 
struct FGetIcon
{
	struct UTexture* ReturnValue;  // 0x0(0x8)

}; 
// DelegateFunction AutoSettings.ChordRejectedEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FChordRejectedEvent__DelegateSignature
{
	struct FInputChord CapturedChord;  // 0x0(0x20)

}; 
// DelegateFunction AutoSettings.ChordCapturedEvent__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FChordCapturedEvent__DelegateSignature
{
	struct FInputChord CapturedChord;  // 0x0(0x20)

}; 
// DelegateFunction AutoSettings.CapturePromptClosedEvent__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCapturePromptClosedEvent__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// DelegateFunction AutoSettings.SettingSavedSignature__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FSettingSavedSignature__DelegateSignature
{
	struct FAutoSettingData SettingData;  // 0x0(0x38)

}; 
// ScriptStruct AutoSettings.AutoSettingData
// Size: 0x38(Inherited: 0x0) 
struct FAutoSettingData
{
	struct FName Key;  // 0x0(0x8)
	struct FString Value;  // 0x8(0x10)
	struct FGameplayTagContainer Tags;  // 0x18(0x20)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddIntCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddIntCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// ScriptStruct AutoSettings.KeyScale
// Size: 0x20(Inherited: 0x0) 
struct FKeyScale
{
	struct FKey Key;  // 0x0(0x18)
	float Scale;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function AutoSettings.SettingContainerUtils.ApplyChildSettings
// Size: 0x10(Inherited: 0x0) 
struct FApplyChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)

}; 
// DelegateFunction AutoSettings.RadioSelectedSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FRadioSelectedSignature__DelegateSignature
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddFloatCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddFloatCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// DelegateFunction AutoSettings.SpinnerSelectionChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FSpinnerSelectionChanged__DelegateSignature
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.AutoSettingsPlayer.SaveInputMappings
// Size: 0x40(Inherited: 0x0) 
struct FSaveInputMappings
{
	struct FPlayerInputMappings InputMappings;  // 0x0(0x40)

}; 
// ScriptStruct AutoSettings.AxisAssociation
// Size: 0x28(Inherited: 0x0) 
struct FAxisAssociation
{
	struct FKey AnalogKey;  // 0x0(0x18)
	struct TArray<struct FKeyScale> BooleanKeys;  // 0x18(0x10)

}; 
// ScriptStruct AutoSettings.MappingGroupLink
// Size: 0x10(Inherited: 0x0) 
struct FMappingGroupLink
{
	struct TArray<int32_t> MappingGroups;  // 0x0(0x10)

}; 
// ScriptStruct AutoSettings.KeyGroup
// Size: 0x20(Inherited: 0x0) 
struct FKeyGroup
{
	struct FGameplayTag KeyGroupTag;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bUseGamepadKeys : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bUseNonGamepadKeys : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct TArray<struct FKey> Keys;  // 0x10(0x10)

}; 
// ScriptStruct AutoSettings.KeyIconSet
// Size: 0x30(Inherited: 0x0) 
struct FKeyIconSet
{
	struct FGameplayTagContainer Tags;  // 0x0(0x20)
	struct TArray<struct FKeyIconPair> Icons;  // 0x20(0x10)

}; 
// ScriptStruct AutoSettings.KeyIconPair
// Size: 0x20(Inherited: 0x0) 
struct FKeyIconPair
{
	struct FKey Key;  // 0x0(0x18)
	struct UTexture* Icon;  // 0x18(0x8)

}; 
// ScriptStruct AutoSettings.ConfigAxisKeyMapping
// Size: 0x28(Inherited: 0x28) 
struct FConfigAxisKeyMapping : public FInputAxisKeyMapping
{

}; 
// ScriptStruct AutoSettings.InputMappingPreset
// Size: 0x20(Inherited: 0x0) 
struct FInputMappingPreset
{
	struct FGameplayTag PresetTag;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bUseDefaultMappings : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct FInputMappingGroup> MappingGroups;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingValueMask.MaskValue
// Size: 0x20(Inherited: 0x0) 
struct FMaskValue
{
	struct FString ConsoleValue;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct AutoSettings.InputMappingGroup
// Size: 0x20(Inherited: 0x0) 
struct FInputMappingGroup
{
	struct TArray<struct FConfigActionKeyMapping> ActionMappings;  // 0x0(0x10)
	struct TArray<struct FConfigAxisKeyMapping> AxisMappings;  // 0x10(0x10)

}; 
// Function AutoSettings.ConsoleUtils.SetStringCVar
// Size: 0x18(Inherited: 0x0) 
struct FSetStringCVar
{
	struct FName Name;  // 0x0(0x8)
	struct FString Value;  // 0x8(0x10)

}; 
// ScriptStruct AutoSettings.ConfigActionKeyMapping
// Size: 0x28(Inherited: 0x28) 
struct FConfigActionKeyMapping : public FInputActionKeyMapping
{

}; 
// Function AutoSettings.ComboBoxSetting.ComboBoxSelectionChanged
// Size: 0x18(Inherited: 0x0) 
struct FComboBoxSelectionChanged
{
	struct FString SelectedItem;  // 0x0(0x10)
	char ESelectInfo SelectionType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.ConsoleUtils.IsCVarRegistered
// Size: 0xC(Inherited: 0x0) 
struct FIsCVarRegistered
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AutoSettings.CheckBoxSetting.CheckBoxStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FCheckBoxStateChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsChecked : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.InputMappingManager.AddPlayerActionOverride
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerActionOverride
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputActionKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// ScriptStruct AutoSettings.PlayerInputMappings
// Size: 0x40(Inherited: 0x0) 
struct FPlayerInputMappings
{
	struct FString PlayerId;  // 0x0(0x10)
	int32_t PlayerIndex;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Custom : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FInputMappingPreset Preset;  // 0x18(0x20)
	struct FGameplayTag PlayerKeyGroup;  // 0x38(0x8)

}; 
// Function AutoSettings.InputMapping.BindChord
// Size: 0x20(Inherited: 0x0) 
struct FBindChord
{
	struct FInputChord InChord;  // 0x0(0x20)

}; 
// Function AutoSettings.BindCaptureButton.ChordCaptured
// Size: 0x20(Inherited: 0x0) 
struct FChordCaptured
{
	struct FInputChord Chord;  // 0x0(0x20)

}; 
// Function AutoSettings.AutoSettingsConfig.GetKeyFriendlyNameStatic
// Size: 0x30(Inherited: 0x0) 
struct FGetKeyFriendlyNameStatic
{
	struct FKey Key;  // 0x0(0x18)
	struct FText ReturnValue;  // 0x18(0x18)

}; 
// Function AutoSettings.AutoSettingsConfig.GetKeyGroupStatic
// Size: 0x20(Inherited: 0x0) 
struct FGetKeyGroupStatic
{
	struct FKey Key;  // 0x0(0x18)
	struct FGameplayTag ReturnValue;  // 0x18(0x8)

}; 
// Function AutoSettings.ConsoleUtils.GetIntCVar
// Size: 0xC(Inherited: 0x0) 
struct FGetIntCVar
{
	struct FName Name;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function AutoSettings.AutoSettingsPlayer.GetInputMappings
// Size: 0x48(Inherited: 0x0) 
struct FGetInputMappings
{
	struct FPlayerInputMappings InputMappings;  // 0x0(0x40)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function AutoSettings.RadioButton.UpdateLabel
// Size: 0x18(Inherited: 0x0) 
struct FUpdateLabel
{
	struct FText InLabel;  // 0x0(0x18)

}; 
// Function AutoSettings.AutoSettingsPlayer.GetUniquePlayerIdentifier
// Size: 0x10(Inherited: 0x0) 
struct FGetUniquePlayerIdentifier
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function AutoSettings.AutoSettingWidget.HasUnappliedChange
// Size: 0x1(Inherited: 0x0) 
struct FHasUnappliedChange
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.AutoSettingWidget.UpdateSelection
// Size: 0x10(Inherited: 0x0) 
struct FUpdateSelection
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.ConsoleUtils.GetFloatCVar
// Size: 0xC(Inherited: 0x0) 
struct FGetFloatCVar
{
	struct FName Name;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)

}; 
// Function AutoSettings.BindCaptureButton.InitializePrompt
// Size: 0x8(Inherited: 0x0) 
struct FInitializePrompt
{
	struct UBindCapturePrompt* PromptWidget;  // 0x0(0x8)

}; 
// Function AutoSettings.BindCaptureButton.StartCapture
// Size: 0x8(Inherited: 0x0) 
struct FStartCapture
{
	struct UBindCapturePrompt* ReturnValue;  // 0x0(0x8)

}; 
// Function AutoSettings.ConsoleUtils.GetBoolCVar
// Size: 0xC(Inherited: 0x0) 
struct FGetBoolCVar
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AutoSettings.BindCapturePrompt.GetKeyGroup
// Size: 0x8(Inherited: 0x0) 
struct FGetKeyGroup
{
	struct FGameplayTag ReturnValue;  // 0x0(0x8)

}; 
// Function AutoSettings.BindCapturePrompt.IsKeyAllowed
// Size: 0x20(Inherited: 0x0) 
struct FIsKeyAllowed
{
	struct FKey PrimaryKey;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function AutoSettings.InputMappingManager.AddPlayerActionOverrideStatic
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerActionOverrideStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputActionKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function AutoSettings.ToggleSetting.ToggleStateUpdated
// Size: 0x1(Inherited: 0x0) 
struct FToggleStateUpdated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool State : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.ConsoleUtils.SetBoolCVar
// Size: 0xC(Inherited: 0x0) 
struct FSetBoolCVar
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AutoSettings.ToggleSetting.UpdateToggleState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateToggleState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool State : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SelectSetting.UpdateOptions
// Size: 0x10(Inherited: 0x0) 
struct FUpdateOptions
{
	struct TArray<struct FSettingOption> InOptions;  // 0x0(0x10)

}; 
// Function AutoSettings.ConsoleUtils.GetStringCVar
// Size: 0x18(Inherited: 0x0) 
struct FGetStringCVar
{
	struct FName Name;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function AutoSettings.ConsoleUtils.SetFloatCVar
// Size: 0xC(Inherited: 0x0) 
struct FSetFloatCVar
{
	struct FName Name;  // 0x0(0x8)
	float Value;  // 0x8(0x4)

}; 
// Function AutoSettings.ConsoleUtils.SetIntCVar
// Size: 0xC(Inherited: 0x0) 
struct FSetIntCVar
{
	struct FName Name;  // 0x0(0x8)
	int32_t Value;  // 0x8(0x4)

}; 
// Function AutoSettings.SettingsManager.ApplySettingStatic
// Size: 0x38(Inherited: 0x0) 
struct FApplySettingStatic
{
	struct FAutoSettingData SettingData;  // 0x0(0x38)

}; 
// Function AutoSettings.CVarChangeListenerManager.AddBoolCVarCallbackStatic
// Size: 0x1C(Inherited: 0x0) 
struct FAddBoolCVarCallbackStatic
{
	struct FName Name;  // 0x0(0x8)
	struct FDelegate ChangedCallback;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallbackImmediately : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function AutoSettings.GlobalKeyIconTagManager.GetIconForKey
// Size: 0x40(Inherited: 0x0) 
struct FGetIconForKey
{
	struct FKey InKey;  // 0x0(0x18)
	struct FGameplayTagContainer IconTags;  // 0x18(0x20)
	struct UTexture* ReturnValue;  // 0x38(0x8)

}; 
// Function AutoSettings.GlobalKeyIconTagManager.SetGlobalKeyIconTags
// Size: 0x20(Inherited: 0x0) 
struct FSetGlobalKeyIconTags
{
	struct FGameplayTagContainer InGlobalIconTags;  // 0x0(0x20)

}; 
// Function AutoSettings.InputMappingManager.AddPlayerAxisOverrideStatic
// Size: 0x38(Inherited: 0x0) 
struct FAddPlayerAxisOverrideStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputAxisKeyMapping NewMapping;  // 0x8(0x28)
	int32_t MappingGroup;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAnyKeyGroup : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function AutoSettings.InputMappingManager.OnRegisteredPlayerControllerDestroyed
// Size: 0x8(Inherited: 0x0) 
struct FOnRegisteredPlayerControllerDestroyed
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function AutoSettings.InputMappingManager.GetDefaultInputPresets
// Size: 0x10(Inherited: 0x0) 
struct FGetDefaultInputPresets
{
	struct TArray<struct FInputMappingPreset> ReturnValue;  // 0x0(0x10)

}; 
// Function AutoSettings.InputMappingManager.GetPlayerInputMappingsStatic
// Size: 0x48(Inherited: 0x0) 
struct FGetPlayerInputMappingsStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FPlayerInputMappings ReturnValue;  // 0x8(0x40)

}; 
// Function AutoSettings.InputMappingManager.InitializePlayerInputOverridesStatic
// Size: 0x10(Inherited: 0x0) 
struct FInitializePlayerInputOverridesStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function AutoSettings.InputMappingManager.SetPlayerInputPresetByTag
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayerInputPresetByTag
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FGameplayTag PresetTag;  // 0x8(0x8)

}; 
// Function AutoSettings.InputMappingManager.SetPlayerInputPresetStatic
// Size: 0x30(Inherited: 0x0) 
struct FSetPlayerInputPresetStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FInputMappingPreset Preset;  // 0x8(0x20)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bIsCustomized : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function AutoSettings.InputMappingManager.SetPlayerKeyGroupStatic
// Size: 0x10(Inherited: 0x0) 
struct FSetPlayerKeyGroupStatic
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FGameplayTag KeyGroup;  // 0x8(0x8)

}; 
// Function AutoSettings.KeyLabel.GetDisplayName
// Size: 0x18(Inherited: 0x0) 
struct FGetDisplayName
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function AutoSettings.KeyLabel.GetDisplayNameVisibility
// Size: 0x1(Inherited: 0x0) 
struct FGetDisplayNameVisibility
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function AutoSettings.KeyLabel.GetIconVisibility
// Size: 0x1(Inherited: 0x0) 
struct FGetIconVisibility
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function AutoSettings.KeyLabel.HasIcon
// Size: 0x1(Inherited: 0x0) 
struct FHasIcon
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.KeyLabel.HasValidKey
// Size: 0x1(Inherited: 0x0) 
struct FHasValidKey
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SliderSetting.OnSliderValueUpdated
// Size: 0x8(Inherited: 0x0) 
struct FOnSliderValueUpdated
{
	float NormalizedValue;  // 0x0(0x4)
	float RawValue;  // 0x4(0x4)

}; 
// Function AutoSettings.SliderSetting.ShouldSaveCurrentValue
// Size: 0x1(Inherited: 0x0) 
struct FShouldSaveCurrentValue
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SliderSetting.SliderValueUpdated
// Size: 0x4(Inherited: 0x0) 
struct FSliderValueUpdated
{
	float NormalizedValue;  // 0x0(0x4)

}; 
// Function AutoSettings.SliderSetting.UpdateSliderValue
// Size: 0x8(Inherited: 0x0) 
struct FUpdateSliderValue
{
	float NormalizedValue;  // 0x0(0x4)
	float RawValue;  // 0x4(0x4)

}; 
// Function AutoSettings.NativeSliderSetting.SliderValueChanged
// Size: 0x4(Inherited: 0x0) 
struct FSliderValueChanged
{
	float NewValue;  // 0x0(0x4)

}; 
// Function AutoSettings.RadioButton.GetLabel
// Size: 0x18(Inherited: 0x0) 
struct FGetLabel
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function AutoSettings.RadioButton.GetSelected
// Size: 0x1(Inherited: 0x0) 
struct FGetSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.SettingsManager.GetValue
// Size: 0x20(Inherited: 0x0) 
struct FGetValue
{
	struct FName Key;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bPreferConfigValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function AutoSettings.RadioButton.SetLabel
// Size: 0x18(Inherited: 0x0) 
struct FSetLabel
{
	struct FText InLabel;  // 0x0(0x18)

}; 
// Function AutoSettings.RadioButton.SetSelected
// Size: 0x1(Inherited: 0x0) 
struct FSetSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InSelected : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.RadioButton.SetValue
// Size: 0x10(Inherited: 0x0) 
struct FSetValue
{
	struct FString InValue;  // 0x0(0x10)

}; 
// Function AutoSettings.RadioButton.UpdateSelected
// Size: 0x1(Inherited: 0x0) 
struct FUpdateSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InSelected : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.RadioSelect.ButtonSelected
// Size: 0x10(Inherited: 0x0) 
struct FButtonSelected
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.RadioSelect.Select
// Size: 0x10(Inherited: 0x0) 
struct FSelect
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.RadioSelect.SetOptions
// Size: 0x10(Inherited: 0x0) 
struct FSetOptions
{
	struct TArray<struct FSettingOption> InOptions;  // 0x0(0x10)

}; 
// Function AutoSettings.RadioSelectSetting.RadioSelectionChanged
// Size: 0x10(Inherited: 0x0) 
struct FRadioSelectionChanged
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.SettingOptionFactory.ConstructOptions
// Size: 0x10(Inherited: 0x0) 
struct FConstructOptions
{
	struct TArray<struct FSettingOption> ReturnValue;  // 0x0(0x10)

}; 
// Function AutoSettings.SettingValueMask.RecombineValues
// Size: 0x30(Inherited: 0x0) 
struct FRecombineValues
{
	struct FString SettingValue;  // 0x0(0x10)
	struct FString ConsoleValue;  // 0x10(0x10)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function AutoSettings.SettingContainerUtils.CancelChildSettings
// Size: 0x10(Inherited: 0x0) 
struct FCancelChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)

}; 
// Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnappliedChange
// Size: 0x18(Inherited: 0x0) 
struct FDoesAnyChildSettingHaveUnappliedChange
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.SettingContainerUtils.DoesAnyChildSettingHaveUnsavedChange
// Size: 0x18(Inherited: 0x0) 
struct FDoesAnyChildSettingHaveUnsavedChange
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function AutoSettings.SettingContainerUtils.GetChildSettings
// Size: 0x20(Inherited: 0x0) 
struct FGetChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)
	struct TArray<struct UAutoSettingWidget*> ReturnValue;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingContainerUtils.SaveChildSettings
// Size: 0x10(Inherited: 0x0) 
struct FSaveChildSettings
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UWidget* Parent;  // 0x8(0x8)

}; 
// Function AutoSettings.SettingsManager.AutoDetectSettingsStatic
// Size: 0x50(Inherited: 0x0) 
struct FAutoDetectSettingsStatic
{
	float ResolutionQuality;  // 0x0(0x4)
	int32_t ViewDistanceQuality;  // 0x4(0x4)
	int32_t AntiAliasingQuality;  // 0x8(0x4)
	int32_t ShadowQuality;  // 0xC(0x4)
	int32_t PostProcessQuality;  // 0x10(0x4)
	int32_t TextureQuality;  // 0x14(0x4)
	int32_t EffectsQuality;  // 0x18(0x4)
	int32_t FoliageQuality;  // 0x1C(0x4)
	int32_t ShadingQuality;  // 0x20(0x4)
	float CPUBenchmarkResults;  // 0x24(0x4)
	float GPUBenchmarkResults;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<float> CPUBenchmarkSteps;  // 0x30(0x10)
	struct TArray<float> GPUBenchmarkSteps;  // 0x40(0x10)

}; 
// Function AutoSettings.SettingsManager.GetInitialValue
// Size: 0x18(Inherited: 0x0) 
struct FGetInitialValue
{
	struct FName Key;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterBoolCVarSetting
// Size: 0x20(Inherited: 0x0) 
struct FRegisterBoolCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool DefaultValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Help;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterBoolCVarSettingWithCallback
// Size: 0x38(Inherited: 0x0) 
struct FRegisterBoolCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool DefaultValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Help;  // 0x10(0x10)
	struct FDelegate ChangedCallback;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallbackImmediately : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AutoSettings.SettingsManager.RegisterFloatCVarSetting
// Size: 0x20(Inherited: 0x0) 
struct FRegisterFloatCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	float DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterFloatCVarSettingWithCallback
// Size: 0x38(Inherited: 0x0) 
struct FRegisterFloatCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	float DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)
	struct FDelegate ChangedCallback;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallbackImmediately : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AutoSettings.SettingsManager.RegisterIntCVarSetting
// Size: 0x20(Inherited: 0x0) 
struct FRegisterIntCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	int32_t DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterIntCVarSettingWithCallback
// Size: 0x38(Inherited: 0x0) 
struct FRegisterIntCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	int32_t DefaultValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Help;  // 0x10(0x10)
	struct FDelegate ChangedCallback;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallbackImmediately : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function AutoSettings.SettingsManager.RegisterStringCVarSetting
// Size: 0x28(Inherited: 0x0) 
struct FRegisterStringCVarSetting
{
	struct FName Name;  // 0x0(0x8)
	struct FString DefaultValue;  // 0x8(0x10)
	struct FString Help;  // 0x18(0x10)

}; 
// Function AutoSettings.SettingsManager.RegisterStringCVarSettingWithCallback
// Size: 0x40(Inherited: 0x0) 
struct FRegisterStringCVarSettingWithCallback
{
	struct FName Name;  // 0x0(0x8)
	struct FString DefaultValue;  // 0x8(0x10)
	struct FString Help;  // 0x18(0x10)
	struct FDelegate ChangedCallback;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallbackImmediately : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function AutoSettings.SettingsManager.SaveSettingStatic
// Size: 0x38(Inherited: 0x0) 
struct FSaveSettingStatic
{
	struct FAutoSettingData SettingData;  // 0x0(0x38)

}; 
// Function AutoSettings.Spinner.GetCurrentIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function AutoSettings.Spinner.GetCurrentOption
// Size: 0x28(Inherited: 0x0) 
struct FGetCurrentOption
{
	struct FSettingOption ReturnValue;  // 0x0(0x28)

}; 
// Function AutoSettings.Spinner.HasValidNext
// Size: 0x1(Inherited: 0x0) 
struct FHasValidNext
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.Spinner.HasValidPrevious
// Size: 0x1(Inherited: 0x0) 
struct FHasValidPrevious
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AutoSettings.Spinner.SelectIndex
// Size: 0x4(Inherited: 0x0) 
struct FSelectIndex
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function AutoSettings.Spinner.SelectValue
// Size: 0x10(Inherited: 0x0) 
struct FSelectValue
{
	struct FString Value;  // 0x0(0x10)

}; 
// Function AutoSettings.SpinnerSetting.SpinnerSelectionChanged
// Size: 0x10(Inherited: 0x0) 
struct FSpinnerSelectionChanged
{
	struct FString Value;  // 0x0(0x10)

}; 
