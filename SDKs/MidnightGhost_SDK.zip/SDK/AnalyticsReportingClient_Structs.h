#pragma once 
#include "SDK.h" 
 
 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Get Team Median Level
// Size: 0x60(Inherited: 0x0) 
struct FGet Team Median Level
{
	char Team Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>> Player States;  // 0x8(0x10)
	float Team Median Level;  // 0x18(0x4)
	int32_t TEMP Total team members;  // 0x1C(0x4)
	int32_t TEMP Total team level;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> CallFunc_Array_Get_Item;  // 0x30(0x10)
	int32_t CallFunc_GetPlayerLevel_Int_PlayerLevel;  // 0x40(0x4)
	char Team CallFunc_GetTeam_Int_Team;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x45(0x1)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x48(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x4C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x50(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x54(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x58(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x5C(0x4)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.ExecuteUbergraph_AnalyticsReportingClient
// Size: 0x6C(Inherited: 0x0) 
struct FExecuteUbergraph_AnalyticsReportingClient
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString Temp_string_Variable;  // 0x8(0x10)
	struct UDSTelemetry* CallFunc_CreateTelemetry_ReturnValue;  // 0x18(0x8)
	struct FString K2Node_CustomEvent_Build_Tag;  // 0x20(0x10)
	struct FString K2Node_CustomEvent_GameID;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_CustomEvent_Player_In_Editor_ : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString K2Node_Select_Default;  // 0x48(0x10)
	float K2Node_Event_DeltaTime;  // 0x58(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_Start_ReturnValue : 1;  // 0x61(0x1)
	char pad_98[2];  // 0x62(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x64(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x68(0x4)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Is Victory?
// Size: 0x6(Inherited: 0x0) 
struct FIs Victory?
{
	char Team Team;  // 0x0(0x1)
	char GameVictoryType Victory Type;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Victory : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_3 : 1;  // 0x5(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Get Team Bots Amount
// Size: 0xE0(Inherited: 0x0) 
struct FGet Team Bots Amount
{
	char Team Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>> Player States;  // 0x8(0x10)
	int32_t Amount of Bots;  // 0x18(0x4)
	int32_t TEMP Bots Amount;  // 0x1C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x24(0x4)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x38(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x48(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4C(0x4)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> CallFunc_Array_Get_Item;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsABot_IsABot : 1;  // 0x60(0x1)
	char Team CallFunc_GetTeam_Int_Team;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x62(0x1)
	char pad_99_1 : 7;  // 0x63(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x63(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x64(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x68(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x80(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x90(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0xA0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0xB0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0xC0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0xD0(0x10)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.On Gameplay Timer Tick
// Size: 0x4(Inherited: 0x0) 
struct FOn Gameplay Timer Tick
{
	float DeltaTime;  // 0x0(0x4)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Init
// Size: 0x21(Inherited: 0x0) 
struct FInit
{
	struct FString Build Tag;  // 0x0(0x10)
	struct FString GameID;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Player In Editor? : 1;  // 0x20(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Get Total Team Score
// Size: 0x50(Inherited: 0x0) 
struct FGet Total Team Score
{
	char Team Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>> Player States;  // 0x8(0x10)
	int32_t Team Score;  // 0x18(0x4)
	int32_t TEMP Team Score;  // 0x1C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x24(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TScriptInterface<IMGH_PlayerStateInterface_C> CallFunc_Array_Get_Item;  // 0x30(0x10)
	int32_t CallFunc_GetTotalScore_Int_TotalScore;  // 0x40(0x4)
	char Team CallFunc_GetTeam_Int_Team;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x45(0x1)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x48(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x4C(0x4)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Map Changed
// Size: 0x13(Inherited: 0x0) 
struct FReport Map Changed
{
	struct FString Map;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_SetStateString_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x12(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Tutorial Completed
// Size: 0x22(Inherited: 0x0) 
struct FReport Tutorial Completed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Ghost F, Hunters T : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Completed : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Result : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct UDJSONObject* Temp Telemetry Event JSON Data;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_AddStringField_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_AddStringField_ReturnValue_2 : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct UDJSONObject* CallFunc_CreateJSONObject_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_AddFloatField_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_SubmitJSONObject_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Tutorial Step Advanced
// Size: 0x6(Inherited: 0x0) 
struct FReport Tutorial Step Advanced
{
	int32_t Step;  // 0x0(0x4)
	char Team Team;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Result : 1;  // 0x5(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Leave Lobby
// Size: 0x5(Inherited: 0x0) 
struct FReport Leave Lobby
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_SetStateString_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_SetStateString_ReturnValue_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_SetStateString_ReturnValue_3 : 1;  // 0x4(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Gameplay Round Ended
// Size: 0xC1(Inherited: 0x0) 
struct FReport Gameplay Round Ended
{
	struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State;  // 0x0(0x10)
	char GameVictoryType Victory Type;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Winning Team GUID;  // 0x18(0x10)
	struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>> All Player States;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Result : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UDJSONObject* Temp Telemetry Event JSON Data;  // 0x40(0x8)
	struct UDJSONObject* Temp Telemetry Event JSON Data;  // 0x48(0x8)
	int32_t CallFunc_Get_Total_Team_Score_Team_Score;  // 0x50(0x4)
	int32_t CallFunc_Get_Total_Team_Score_Team_Score_2;  // 0x54(0x4)
	int32_t CallFunc_Get_Total_Team_Score_Team_Score_3;  // 0x58(0x4)
	int32_t CallFunc_Get_Total_Team_Score_Team_Score_4;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Is_Victory__Victory : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_GetMatchRevives_Int_Revives;  // 0x64(0x4)
	int32_t CallFunc_GetMatchAssists_Int_Assists;  // 0x68(0x4)
	int32_t CallFunc_GetMatchKills_Int_Kills;  // 0x6C(0x4)
	int32_t CallFunc_GetTotalScore_Int_TotalScore;  // 0x70(0x4)
	char Team CallFunc_GetTeam_Int_Team;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x75(0x1)
	char pad_118_1 : 7;  // 0x76(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x76(0x1)
	char pad_119_1 : 7;  // 0x77(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x77(0x1)
	int32_t CallFunc_Get_Total_Team_Score_Team_Score_5;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Is_Victory__Victory_2 : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_AddIntegerField_ReturnValue : 1;  // 0x7D(0x1)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_2 : 1;  // 0x7E(0x1)
	char pad_127_1 : 7;  // 0x7F(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_3 : 1;  // 0x7F(0x1)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_4 : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_5 : 1;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_6 : 1;  // 0x82(0x1)
	char pad_131_1 : 7;  // 0x83(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_7 : 1;  // 0x83(0x1)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_8 : 1;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool CallFunc_AddStringField_ReturnValue : 1;  // 0x85(0x1)
	char pad_134_1 : 7;  // 0x86(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_9 : 1;  // 0x86(0x1)
	char pad_135_1 : 7;  // 0x87(0x1)
	bool CallFunc_AddStringField_ReturnValue_2 : 1;  // 0x87(0x1)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_AddStringField_ReturnValue_3 : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x90(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x94(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x98(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_AddFloatField_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0xA4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_7;  // 0xA8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_8;  // 0xAC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_9;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct UDJSONObject* CallFunc_CreateJSONObject_ReturnValue;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_SubmitJSONObject_ReturnValue : 1;  // 0xC0(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Match Ended
// Size: 0x29(Inherited: 0x0) 
struct FReport Match Ended
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UDJSONObject* Temp Telemetry Event JSON Data;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_AddStringField_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_AddStringField_ReturnValue_2 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_AddStringField_ReturnValue_3 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_AddIntegerField_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_2 : 1;  // 0x16(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool CallFunc_AddFloatField_ReturnValue : 1;  // 0x17(0x1)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_3 : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_4 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_5 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_6 : 1;  // 0x1B(0x1)
	char pad_28[4];  // 0x1C(0x4)
	struct UDJSONObject* CallFunc_CreateJSONObject_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_SubmitJSONObject_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Login
// Size: 0xA8(Inherited: 0x0) 
struct FReport Player Login
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UDJSONObject* Temp Telemetry Event JSON Data;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString CallFunc_GetCPUBrand_ReturnValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_AddStringField_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_SubmitJSONObject_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FIntPoint CallFunc_GetScreenResolution_ReturnValue;  // 0x3C(0x8)
	char pad_68[4];  // 0x44(0x4)
	struct FString CallFunc_Conv_IntPointToString_ReturnValue;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_AddStringField_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FString CallFunc_GetDefaultLanguage_ReturnValue;  // 0x60(0x10)
	struct FString CallFunc_GetCurrentLanguage_ReturnValue;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_AddStringField_ReturnValue_3 : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_AddStringField_ReturnValue_4 : 1;  // 0x81(0x1)
	char pad_130[6];  // 0x82(0x6)
	struct FString CallFunc_Victory_GetGPUBrand_ReturnValue;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_AddStringField_ReturnValue_5 : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct UDJSONObject* CallFunc_CreateJSONObject_ReturnValue;  // 0xA0(0x8)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Match ID Changed
// Size: 0x13(Inherited: 0x0) 
struct FReport Match ID Changed
{
	struct FString Match ID;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Result : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_SetStateString_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x12(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Region Changed
// Size: 0x1A(Inherited: 0x0) 
struct FReport Region Changed
{
	char MGH_Regions region;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Result : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_SetStateString_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Level Up
// Size: 0x7(Inherited: 0x0) 
struct FReport Player Level Up
{
	int32_t New Level;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Result : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_SetStateInteger_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x6(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Match Started
// Size: 0xC8(Inherited: 0x0) 
struct FReport Match Started
{
	struct TScriptInterface<IMGH_PlayerStateInterface_C> Player State;  // 0x0(0x10)
	struct TArray<struct TScriptInterface<IMGH_PlayerStateInterface_C>> All Player States;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Result : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UDJSONObject* Temp Telemetry Event JSON Data;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_AddIntegerField_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_AddFloatField_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	int32_t CallFunc_Get_Team_Bots_Amount_Amount_of_Bots;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_2 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_Get_Team_Bots_Amount_Amount_of_Bots_2;  // 0x7C(0x4)
	float CallFunc_Get_Team_Median_Level_Team_Median_Level;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_3 : 1;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool CallFunc_AddFloatField_ReturnValue_2 : 1;  // 0x85(0x1)
	char pad_134[2];  // 0x86(0x2)
	float CallFunc_Get_Team_Median_Level_Team_Median_Level_2;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct FString CallFunc_GetTeamGUID_Int_TeamGUID;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_AddFloatField_ReturnValue_3 : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_AddStringField_ReturnValue : 1;  // 0xA1(0x1)
	char Team CallFunc_GetTeam_Int_Team;  // 0xA2(0x1)
	char pad_163_1 : 7;  // 0xA3(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xA3(0x1)
	int32_t CallFunc_Get_Team_Bots_Amount_Amount_of_Bots_3;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_AddIntegerField_ReturnValue_4 : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	float CallFunc_Get_Team_Median_Level_Team_Median_Level_3;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_AddFloatField_ReturnValue_4 : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_SubmitJSONObject_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UDJSONObject* CallFunc_CreateJSONObject_ReturnValue;  // 0xC0(0x8)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Party Status Changed
// Size: 0xB(Inherited: 0x0) 
struct FReport Party Status Changed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Party Status : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Party Size;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Result : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_SetStateBoolean_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Team Changed
// Size: 0x7(Inherited: 0x0) 
struct FReport Player Team Changed
{
	char Team Team;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Result : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_SetStateString_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_SetStateString_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_SetStateString_ReturnValue_3 : 1;  // 0x6(0x1)

}; 
// Function AnalyticsReportingClient.AnalyticsReportingClient_C.Report Player Stats Loaded
// Size: 0x7(Inherited: 0x0) 
struct FReport Player Stats Loaded
{
	int32_t Player Level;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Result : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_SetStateInteger_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x6(0x1)

}; 
