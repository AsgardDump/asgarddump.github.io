#pragma once 
#include "SDK.h" 
 
 
// Function BP_Sound.BP_Sound_C.MC_AttachToActor
// Size: 0x10(Inherited: 0x0) 
struct FMC_AttachToActor
{
	struct AActor* ParentActor;  // 0x0(0x8)
	struct ABP_Sound_C* BP Sound;  // 0x8(0x8)

}; 
// Function BP_Sound.BP_Sound_C.ExecuteUbergraph_BP_Sound
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Sound
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USoundAttenuation* Temp_object_Variable;  // 0x8(0x8)
	struct USoundAttenuation* Temp_object_Variable_2;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	struct AActor* K2Node_CustomEvent_ParentActor_2;  // 0x20(0x8)
	struct ABP_Sound_C* K2Node_CustomEvent_BP_Sound_2;  // 0x28(0x8)
	struct AActor* K2Node_CustomEvent_ParentActor;  // 0x30(0x8)
	struct ABP_Sound_C* K2Node_CustomEvent_BP_Sound;  // 0x38(0x8)
	struct USoundAttenuation* K2Node_Select_Default;  // 0x40(0x8)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x60(0x10)

}; 
// Function BP_Sound.BP_Sound_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_Sound.BP_Sound_C.Server_AttachToActor
// Size: 0x10(Inherited: 0x0) 
struct FServer_AttachToActor
{
	struct AActor* ParentActor;  // 0x0(0x8)
	struct ABP_Sound_C* BP Sound;  // 0x8(0x8)

}; 
