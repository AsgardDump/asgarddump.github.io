#pragma once 
#include <BP_C4Explosion_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_C4Explosion.BP_C4Explosion_C
// Size: 0x28A(Inherited: 0x220) 
struct ABP_C4Explosion_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UPointLightComponent* PointLight;  // 0x228(0x8)
	struct UParticleSystemComponent* Pfx_Explosion_Large_Radial_Var04;  // 0x230(0x8)
	struct USphereComponent* Sphere;  // 0x238(0x8)
	struct UParticleSystemComponent* Pfx_Explosion_Large_Radial_Var03;  // 0x240(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x248(0x8)
	float Fadedown_BRIGHTNESS_8DB638124E7D1DD3426241A7237F0813;  // 0x250(0x4)
	char ETimelineDirection Fadedown__Direction_8DB638124E7D1DD3426241A7237F0813;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* Fadedown;  // 0x258(0x8)
	struct ABP_Hunter_C* WhoFired;  // 0x260(0x8)
	struct AProp_C* AttachedToProp;  // 0x268(0x8)
	float DamageMaxRange;  // 0x270(0x4)
	char pad_628[4];  // 0x274(0x4)
	struct TArray<struct AActor*> Overlapping Actors;  // 0x278(0x10)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool SecondBlast : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool DamagedGhost : 1;  // 0x289(0x1)

	void CheckLoS(struct FVector Start, struct FVector End, struct AActor* ActorTarget, bool& OK); // Function BP_C4Explosion.BP_C4Explosion_C.CheckLoS
	void Fadedown__FinishedFunc(); // Function BP_C4Explosion.BP_C4Explosion_C.Fadedown__FinishedFunc
	void Fadedown__UpdateFunc(); // Function BP_C4Explosion.BP_C4Explosion_C.Fadedown__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_C4Explosion.BP_C4Explosion_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_C4Explosion(int32_t EntryPoint); // Function BP_C4Explosion.BP_C4Explosion_C.ExecuteUbergraph_BP_C4Explosion
}; 



