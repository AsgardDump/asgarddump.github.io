#pragma once 
#include <BP_LightSwitch_WH_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LightSwitch_WH.BP_LightSwitch_WH_C
// Size: 0x2B0(Inherited: 0x281) 
struct ABP_LightSwitch_WH_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UWidgetComponent* Widget;  // 0x290(0x8)
	struct UTextRenderComponent* TextRender;  // 0x298(0x8)
	struct UBoxComponent* Box;  // 0x2A0(0x8)
	struct UStaticMeshComponent* Cube;  // 0x2A8(0x8)

	void MC_LightSwitch(); // Function BP_LightSwitch_WH.BP_LightSwitch_WH_C.MC_LightSwitch
	void WHLightSwitch_Interact(struct AMGH_PlayerController_BP_C* PC); // Function BP_LightSwitch_WH.BP_LightSwitch_WH_C.WHLightSwitch_Interact
	void LightSwitch(); // Function BP_LightSwitch_WH.BP_LightSwitch_WH_C.LightSwitch
	void ReceiveBeginPlay(); // Function BP_LightSwitch_WH.BP_LightSwitch_WH_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_LightSwitch_WH(int32_t EntryPoint); // Function BP_LightSwitch_WH.BP_LightSwitch_WH_C.ExecuteUbergraph_BP_LightSwitch_WH
}; 



