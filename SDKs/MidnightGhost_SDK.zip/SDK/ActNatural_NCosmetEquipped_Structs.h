#pragma once 
#include "SDK.h" 
 
 
// Function ActNatural_NCosmetEquipped.ActNatural_NCosmetEquipped_C.ExecuteUbergraph_ActNatural_NCosmetEquipped
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ActNatural_NCosmetEquipped
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
