#pragma once 
#include <BP_SabotagedLvlprop_Small_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SabotagedLvlprop_Small.BP_SabotagedLvlprop_Small_C
// Size: 0x291(Inherited: 0x291) 
struct ABP_SabotagedLvlprop_Small_C : public ABP_SabotagedLvlprop_C
{

}; 



