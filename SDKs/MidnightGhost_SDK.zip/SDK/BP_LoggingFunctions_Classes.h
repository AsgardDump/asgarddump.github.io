#pragma once 
#include <BP_LoggingFunctions_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LoggingFunctions.BP_LoggingFunctions_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_LoggingFunctions_C : public UBlueprintFunctionLibrary
{

	void MGH Log(struct FString Category, struct FString Message, bool Print To Log, bool Error, struct UGameInstance* If Error, GameInstance, struct UObject* __WorldContext); // Function BP_LoggingFunctions.BP_LoggingFunctions_C.MGH Log
}; 



