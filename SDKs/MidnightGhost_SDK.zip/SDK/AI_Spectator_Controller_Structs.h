#pragma once 
#include "SDK.h" 
 
 
// Function AI_Spectator_Controller.AI_Spectator_Controller_C.ExecuteUbergraph_AI_Spectator_Controller
// Size: 0x11(Inherited: 0x0) 
struct FExecuteUbergraph_AI_Spectator_Controller
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AMGH_PlayerState_C* K2Node_DynamicCast_AsMGH_Player_State;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
