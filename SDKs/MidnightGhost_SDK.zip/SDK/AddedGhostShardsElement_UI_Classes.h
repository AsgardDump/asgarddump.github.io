#pragma once 
#include <AddedGhostShardsElement_UI_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AddedGhostShardsElement_UI.AddedGhostShardsElement_UI_C
// Size: 0x2E0(Inherited: 0x260) 
struct UAddedGhostShardsElement_UI_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* NewFadeIn;  // 0x268(0x8)
	struct UWidgetAnimation* FadeInUp;  // 0x270(0x8)
	struct UTextBlock* ADDEDGHOSTSHARDS;  // 0x278(0x8)
	struct UTextBlock* ADDEDGHOSTSHARDSPT2;  // 0x280(0x8)
	struct UTextBlock* ADDEDGHOSTSHARDSPT2_2;  // 0x288(0x8)
	struct UImage* Image;  // 0x290(0x8)
	struct UImage* Image_2;  // 0x298(0x8)
	struct UImage* Image_3;  // 0x2A0(0x8)
	struct UImage* Image_4;  // 0x2A8(0x8)
	struct UImage* Image_5;  // 0x2B0(0x8)
	struct UImage* Image_6;  // 0x2B8(0x8)
	struct UImage* Image_45;  // 0x2C0(0x8)
	struct UImage* Image_64;  // 0x2C8(0x8)
	struct UTextBlock* TOTALGHOSTSHARDS;  // 0x2D0(0x8)
	struct UVerticalBox* VerticalBox_113;  // 0x2D8(0x8)

	struct UWidget* Get_CanvasPanel_0_ToolTipWidget_1(); // Function AddedGhostShardsElement_UI.AddedGhostShardsElement_UI_C.Get_CanvasPanel_0_ToolTipWidget_1
	void LoadGhostShards(float DelayBeforeStart); // Function AddedGhostShardsElement_UI.AddedGhostShardsElement_UI_C.LoadGhostShards
	void ExecuteUbergraph_AddedGhostShardsElement_UI(int32_t EntryPoint); // Function AddedGhostShardsElement_UI.AddedGhostShardsElement_UI_C.ExecuteUbergraph_AddedGhostShardsElement_UI
}; 



