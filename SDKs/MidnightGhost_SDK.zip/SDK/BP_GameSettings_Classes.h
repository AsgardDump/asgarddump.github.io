#pragma once 
#include <BP_GameSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GameSettings.BP_GameSettings_C
// Size: 0x155(Inherited: 0x28) 
struct UBP_GameSettings_C : public USaveGame
{
	float Look Horizontal Sensitivity;  // 0x28(0x4)
	float Look Vertical Sensitivity;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Look Horizontal Invert : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Look Vertical Invert : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct TScriptInterface<IBPI_GameSettingsInterface_C> Game Settings Interface;  // 0x38(0x10)
	struct FString Save File Name;  // 0x48(0x10)
	int32_t Save File User Index;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct TArray<struct FSAudioUpdateStruct> AudioEmittors;  // 0x60(0x10)
	float Audio Multiplier Master;  // 0x70(0x4)
	float Audio Multiplier Music;  // 0x74(0x4)
	float Audio Multiplier Voice;  // 0x78(0x4)
	float Audio Multiplier Effect;  // 0x7C(0x4)
	float Audio Multiplier Ambient;  // 0x80(0x4)
	float Audio Multiplier UI;  // 0x84(0x4)
	float Volume Master;  // 0x88(0x4)
	float Volume Music;  // 0x8C(0x4)
	float Volume Voice;  // 0x90(0x4)
	float Volume Effect;  // 0x94(0x4)
	float Volume Ambient;  // 0x98(0x4)
	int32_t Video X Resolution;  // 0x9C(0x4)
	int32_t Video Y Resolution;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct TArray<struct UCameraComponent*> Camera List;  // 0xA8(0x10)
	char EWindowMode Screen Mode;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t Resolution Scale Quality;  // 0xBC(0x4)
	float View Distance Scale;  // 0xC0(0x4)
	int32_t Anti Aliasing Quality;  // 0xC4(0x4)
	int32_t Post Processing Quality;  // 0xC8(0x4)
	int32_t Shadow Quality;  // 0xCC(0x4)
	int32_t Texture Quality;  // 0xD0(0x4)
	int32_t Effect Quality;  // 0xD4(0x4)
	int32_t Foliage Quality;  // 0xD8(0x4)
	float Field Of View FOV;  // 0xDC(0x4)
	float Motion Blur Strength;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool VSync Enabled : 1;  // 0xE4(0x1)
	char pad_229_1 : 7;  // 0xE5(0x1)
	bool My Custom Checkbox : 1;  // 0xE5(0x1)
	char pad_230[2];  // 0xE6(0x2)
	int32_t My Custom RadioBox;  // 0xE8(0x4)
	float My Custom Slider;  // 0xEC(0x4)
	float Bloom Intensity;  // 0xF0(0x4)
	float Gamma Intensity;  // 0xF4(0x4)
	float Gain Intensity;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct UBP_GameSettings_C* Previous Setting State;  // 0x100(0x8)
	struct FString My Custom Combobox;  // 0x108(0x10)
	float Current Frame Time;  // 0x118(0x4)
	char pad_284[4];  // 0x11C(0x4)
	struct TArray<struct UBP_KeyAction_C*> Key Actions;  // 0x120(0x10)
	struct TArray<struct UBP_KeyInput_C*> Input Float Axis List;  // 0x130(0x10)
	struct TArray<struct FSKeyActionSave> Saved Key Inputs;  // 0x140(0x10)
	float Volume UI;  // 0x150(0x4)
	char EWindowMode Old ScreenMode State;  // 0x154(0x1)

	void Get Foliage Quality(int32_t& Value, struct FString& Formatted); // Function BP_GameSettings.BP_GameSettings_C.Get Foliage Quality
	void Set Foliage Quality(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Foliage Quality
	void Modify Foliage Quality(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Foliage Quality
	void Get Volume UI(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Volume UI
	void Get Audio Multiplier UI(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier UI
	void Set Audio Multiplier UI(float Set Value, bool Apply); // Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier UI
	void Modify Audio Multiplier UI(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier UI
	void Save ini Settings(); // Function BP_GameSettings.BP_GameSettings_C.Save ini Settings
	void Load ini Settings(); // Function BP_GameSettings.BP_GameSettings_C.Load ini Settings
	void Init Save Game Settings(struct TScriptInterface<IBPI_GameSettingsInterface_C> Game Settings Interface); // Function BP_GameSettings.BP_GameSettings_C.Init Save Game Settings
	void Get Saved Key Inputs(struct TArray<struct FSKeyActionSave>& Saved Key Inputs); // Function BP_GameSettings.BP_GameSettings_C.Get Saved Key Inputs
	void Get All Key Actions(struct TArray<struct UBP_KeyAction_C*>& Key Actions); // Function BP_GameSettings.BP_GameSettings_C.Get All Key Actions
	void Set Save File User Index(int32_t Save File User Index); // Function BP_GameSettings.BP_GameSettings_C.Set Save File User Index
	void Set Save File Name(struct FString Save File Name); // Function BP_GameSettings.BP_GameSettings_C.Set Save File Name
	void Set Game Settings Interface(struct TScriptInterface<IBPI_GameSettingsInterface_C> Game Settings Interface); // Function BP_GameSettings.BP_GameSettings_C.Set Game Settings Interface
	void Get All Combinations(struct TArray<struct UBP_KeyCombination_C*>& Combinations); // Function BP_GameSettings.BP_GameSettings_C.Get All Combinations
	void Generate Keybinding Conflicts(); // Function BP_GameSettings.BP_GameSettings_C.Generate Keybinding Conflicts
	void Modify Keybindings(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Keybindings
	void Load Key Actions(); // Function BP_GameSettings.BP_GameSettings_C.Load Key Actions
	void Save Key Actions(); // Function BP_GameSettings.BP_GameSettings_C.Save Key Actions
	void Store Key Input(struct FSKeyActionSave& KeySave); // Function BP_GameSettings.BP_GameSettings_C.Store Key Input
	void Get Key Action(struct FString Input Action Name, struct UBP_KeyAction_C*& Input Action, bool& Success); // Function BP_GameSettings.BP_GameSettings_C.Get Key Action
	void Fill Float Axis Inputs List(); // Function BP_GameSettings.BP_GameSettings_C.Fill Float Axis Inputs List
	void Init Key Bindings(); // Function BP_GameSettings.BP_GameSettings_C.Init Key Bindings
	void Update Actions Input State(float Real Time Seconds, float World Delta Seconds, struct APlayerController* PlayerController); // Function BP_GameSettings.BP_GameSettings_C.Update Actions Input State
	void Delete Settings Save File(); // Function BP_GameSettings.BP_GameSettings_C.Delete Settings Save File
	void Get Look Sensitivity Combined X(float Input Axis X, float World Delta, float& Horizontal X); // Function BP_GameSettings.BP_GameSettings_C.Get Look Sensitivity Combined X
	void Get My Custom Combobox(struct FString& Value); // Function BP_GameSettings.BP_GameSettings_C.Get My Custom Combobox
	void Set My Custom Combobox(struct FString Value, bool Apply, struct FString& Result); // Function BP_GameSettings.BP_GameSettings_C.Set My Custom Combobox
	void Modify My Custom Combobox(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Combobox
	void Get My Custom Radiobox(int32_t& Value); // Function BP_GameSettings.BP_GameSettings_C.Get My Custom Radiobox
	void Set My Custom Radiobox(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set My Custom Radiobox
	void Modify My Custom Radiobox(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Radiobox
	void Get My Custom Slider(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get My Custom Slider
	void Set My Custom Slider(float Value, bool Apply, float& Result); // Function BP_GameSettings.BP_GameSettings_C.Set My Custom Slider
	void Modify My Custom Slider(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Slider
	void Get My Custom Checkbox(bool& Value); // Function BP_GameSettings.BP_GameSettings_C.Get My Custom Checkbox
	void Set My Custom Checkbox(bool Value, bool Apply, bool& Result); // Function BP_GameSettings.BP_GameSettings_C.Set My Custom Checkbox
	void Modify My Custom Checkbox(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify My Custom Checkbox
	void Modify All MyCustom Settings(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify All MyCustom Settings
	void Get Resolution Scale(int32_t& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Resolution Scale
	void Set Resolution Scale(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Resolution Scale
	void Modify Resolution Scale(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Resolution Scale
	void Prepeare Previus Settings State(); // Function BP_GameSettings.BP_GameSettings_C.Prepeare Previus Settings State
	void Save All Settings(); // Function BP_GameSettings.BP_GameSettings_C.Save All Settings
	void Modify All Settings(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify All Settings
	void Modify All Audio Settings(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify All Audio Settings
	void Modify All Look Settings(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify All Look Settings
	void Get Look Sensitivity Combined Y(float Input Axis Y, float World Delta, float& Vertical Y); // Function BP_GameSettings.BP_GameSettings_C.Get Look Sensitivity Combined Y
	void Get Volume Ambient(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Volume Ambient
	void Get Audio Multiplier Ambient(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Ambient
	void Set Audio Multiplier Ambient(float Set Value, bool Apply); // Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Ambient
	void Modify Audio Multiplier Ambient(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Ambient
	void Get Volume Effect(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Volume Effect
	void Get Audio Multiplier Effect(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Effect
	void Set Audio Multiplier Effect(float Set Value, bool Apply); // Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Effect
	void Modify Audio Multiplier Effect(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Effect
	void Get Volume Voice(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Volume Voice
	void Get Audio Multiplier Voice(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Voice
	void Set Audio Multiplier Voice(float Set Value, bool Apply); // Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Voice
	void Modify Audio Multiplier Voice(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Voice
	void Get Volume Music(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Volume Music
	void Get Audio Multiplier Music(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Music
	void Set Audio Multiplier Music(float Set Value, bool Apply); // Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Music
	void Modify Audio Multiplier Music(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Music
	void Get Volume Master(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Volume Master
	void Add Volume Control(struct UAudioComponent* Audio Emittor, char EAudioType Audio Channel); // Function BP_GameSettings.BP_GameSettings_C.Add Volume Control
	void Apply Audio Settings(char EAudioType Audio Channel); // Function BP_GameSettings.BP_GameSettings_C.Apply Audio Settings
	void Get Audio Multiplier Master(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Audio Multiplier Master
	void Set Audio Multiplier Master(float Set Value, bool Apply); // Function BP_GameSettings.BP_GameSettings_C.Set Audio Multiplier Master
	void Modify Audio Multiplier Master(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Audio Multiplier Master
	void Get Look Vertical Invert(bool& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Look Vertical Invert
	void Set Look Vertical Invert(bool Set Value); // Function BP_GameSettings.BP_GameSettings_C.Set Look Vertical Invert
	void Modify Look Vertical Invert(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Look Vertical Invert
	void Get Look Horizontal Invert(bool& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Look Horizontal Invert
	void Set Look Horizontal Invert(bool Set Value); // Function BP_GameSettings.BP_GameSettings_C.Set Look Horizontal Invert
	void Modify Look Horizontal Invert(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Look Horizontal Invert
	void Get Look Vertical Sensitivity(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Look Vertical Sensitivity
	void Set Look Vertical Sensitivity(float Set Value); // Function BP_GameSettings.BP_GameSettings_C.Set Look Vertical Sensitivity
	void Modify Look Vertical Sensitivity(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Look Vertical Sensitivity
	void Get Look Horizontal Sensitivity(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Look Horizontal Sensitivity
	void Set Look Horizontal Sensitivity(float Set Value); // Function BP_GameSettings.BP_GameSettings_C.Set Look Horizontal Sensitivity
	void Modify Look Horizontal Sensitivity(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Look Horizontal Sensitivity
	void Apply Screen Settings(); // Function BP_GameSettings.BP_GameSettings_C.Apply Screen Settings
	void Modify Screen Mode(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Screen Mode
	void Get Screen Mode(char EWindowMode& Screen Mode, struct FString& Command); // Function BP_GameSettings.BP_GameSettings_C.Get Screen Mode
	void Get Screen Resolution(struct FSVideoResolution& Resolution); // Function BP_GameSettings.BP_GameSettings_C.Get Screen Resolution
	void Set Screen Mode(char EWindowMode Screen Mode, bool Apply, char EWindowMode& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Screen Mode
	void Set Screen Resolution(struct FSVideoResolution Resolution, bool Apply, struct FSVideoResolution& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Screen Resolution
	void Modify Screen Resolution(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Screen Resolution
	void Get Motion Blur Strength(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Motion Blur Strength
	void Set Motion Blur Strength(float Value, bool Apply, float& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Motion Blur Strength
	void Modify Motion Blur Strength(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Motion Blur Strength
	void Get Gain Intensity(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Gain Intensity
	void Set Gain Intensity(float Value, bool Apply, float& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Gain Intensity
	void Modify Gain Intensity(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Gain Intensity
	void Get Gamma Intensity(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Gamma Intensity
	void Set Gamma Intensity(float Value, bool Apply, float& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Gamma Intensity
	void Modify Gamma Intensity(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Gamma Intensity
	void Get Bloom Intensity(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Bloom Intensity
	void Set Bloom Intensity(float Value, bool Apply, float& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Bloom Intensity
	void Modify Bloom Intensity(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Bloom Intensity
	void Get Vsync(bool& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Vsync
	void Set Vsync(bool Value, bool Apply, bool& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Vsync
	void Modify Vsync(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Vsync
	void Remove Field Of View Control From Camera(struct UCameraComponent* Camera); // Function BP_GameSettings.BP_GameSettings_C.Remove Field Of View Control From Camera
	void Add Field Of View Control To Camera(struct UCameraComponent* Camera); // Function BP_GameSettings.BP_GameSettings_C.Add Field Of View Control To Camera
	void Get Field Of View(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get Field Of View
	void Set Field Of View(float Value, bool Apply, float& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Field Of View
	void Modify Field Of View(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Field Of View
	void Get View Distance(float& Value); // Function BP_GameSettings.BP_GameSettings_C.Get View Distance
	void Set View Distance(float Value, bool Apply, float& Result); // Function BP_GameSettings.BP_GameSettings_C.Set View Distance
	void Modify View Distance(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify View Distance
	void Get Effect Quality(int32_t& Value, struct FString& Formatted); // Function BP_GameSettings.BP_GameSettings_C.Get Effect Quality
	void Set Effect Quality(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Effect Quality
	void Modify Effect Quality(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Effect Quality
	void Get Texture Quality(int32_t& Value, struct FString& Formatted); // Function BP_GameSettings.BP_GameSettings_C.Get Texture Quality
	void Set Texture Quality(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Texture Quality
	void Modify Texture Quality(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Texture Quality
	void Get Shadow Quality(int32_t& Value, struct FString& Formatted); // Function BP_GameSettings.BP_GameSettings_C.Get Shadow Quality
	void Set Shadow Quality(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Shadow Quality
	void Modify Shadow Quality(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Shadow Quality
	void Modify All Video Settings(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify All Video Settings
	void Get Anti Aliasing Quality(int32_t& Value, struct FString& Formatted); // Function BP_GameSettings.BP_GameSettings_C.Get Anti Aliasing Quality
	void Set Anti Aliasing Quality(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Anti Aliasing Quality
	void Modify Anti Aliasing Quality(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Anti Aliasing Quality
	void Get Text Format Quality Level(int32_t Quality Level, struct FString& Formatted); // Function BP_GameSettings.BP_GameSettings_C.Get Text Format Quality Level
	void Get Post Process Quality(int32_t& Value, struct FString& Formatted); // Function BP_GameSettings.BP_GameSettings_C.Get Post Process Quality
	void Set Post Process Quality(int32_t Value, bool Apply, int32_t& Result); // Function BP_GameSettings.BP_GameSettings_C.Set Post Process Quality
	void Modify Post Process Quality(char EModifySetting Modify); // Function BP_GameSettings.BP_GameSettings_C.Modify Post Process Quality
	void Update Audio Emittor(struct FSAudioUpdateStruct Emittor, bool& Is Valid); // Function BP_GameSettings.BP_GameSettings_C.Update Audio Emittor
	void Create Clone(struct UBP_GameSettings_C*& Cloned Game Settings); // Function BP_GameSettings.BP_GameSettings_C.Create Clone
}; 



