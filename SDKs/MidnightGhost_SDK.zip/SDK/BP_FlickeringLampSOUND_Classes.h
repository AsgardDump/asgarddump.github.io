#pragma once 
#include <BP_FlickeringLampSOUND_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlickeringLampSOUND.BP_FlickeringLampSOUND_C
// Size: 0x230(Inherited: 0x220) 
struct ABP_FlickeringLampSOUND_C : public AActor
{
	struct UAudioComponent* FlickeringLights;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)

}; 



