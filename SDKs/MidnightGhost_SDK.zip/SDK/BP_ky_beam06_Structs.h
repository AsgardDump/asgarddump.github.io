#pragma once 
#include "SDK.h" 
 
 
// Function BP_ky_beam06.BP_ky_beam06_C.UserConstructionScript
// Size: 0x8(Inherited: 0x18) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_ky_beam06.BP_ky_beam06_C.ExecuteUbergraph_BP_ky_beam06
// Size: 0x99(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ky_beam06
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x48(0x8)
	struct ABP_Sound_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x50(0x8)
	struct ABP_Sound_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x58(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x60(0xC)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x7C(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue_2;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x91(0x1)
	char pad_146[2];  // 0x92(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x98(0x1)

}; 
// Function BP_ky_beam06.BP_ky_beam06_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_ky_beam06.BP_ky_beam06_C.LoS_Check
// Size: 0x169(Inherited: 0x0) 
struct FLoS_Check
{
	struct AActor* Origin;  // 0x0(0x8)
	struct AActor* Target;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Line of Sight? : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x14(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x30(0x10)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_2;  // 0x40(0x10)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x50(0x88)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xDA(0x1)
	char pad_219[1];  // 0xDB(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xDC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xE0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xE4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xF0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xFC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x108(0xC)
	char pad_276[4];  // 0x114(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x118(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x120(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x128(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x130(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x138(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x13C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x140(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x150(0xC)
	char pad_348[4];  // 0x15C(0x4)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x168(0x1)

}; 
// Function BP_ky_beam06.BP_ky_beam06_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
