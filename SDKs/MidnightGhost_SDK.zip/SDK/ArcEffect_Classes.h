#pragma once 
#include <ArcEffect_Structs.h>
 
 
 
// BlueprintGeneratedClass ArcEffect.ArcEffect_C
// Size: 0x2B2(Inherited: 0x220) 
struct AArcEffect_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* Cylinder;  // 0x228(0x8)
	struct UStaticMeshComponent* ArcEndpoint;  // 0x230(0x8)
	struct UArrowComponent* ArcDirection;  // 0x238(0x8)
	struct USplineComponent* Spline;  // 0x240(0x8)
	struct USceneComponent* Scene;  // 0x248(0x8)
	struct TArray<struct USplineMeshComponent*> SplineMeshes;  // 0x250(0x10)
	struct USplineComponent* ArcSpline;  // 0x260(0x8)
	struct TArray<struct UMaterialInstanceDynamic*> SplineMaterial;  // 0x268(0x10)
	struct FLinearColor TargetColor;  // 0x278(0x10)
	struct FLinearColor CurrentColor;  // 0x288(0x10)
	struct AProp_C* PropThatOwnsMe;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool Telekinesis : 1;  // 0x2A0(0x1)
	char pad_673[7];  // 0x2A1(0x7)
	struct AMGH_GameState_C* GameState;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool 0Collision : 1;  // 0x2B0(0x1)
	char pad_689_1 : 7;  // 0x2B1(0x1)
	bool IsNonSlingshotAiming : 1;  // 0x2B1(0x1)

	void UpdateArcEndpoint(struct FVector NewLocation); // Function ArcEffect.ArcEffect_C.UpdateArcEndpoint
	void UpdateArcSpline(struct TArray<struct FVector>& SplinePoints, bool Force Hit Hunter Team Status?, bool HitHunterTeam); // Function ArcEffect.ArcEffect_C.UpdateArcSpline
	void ClearArc(); // Function ArcEffect.ArcEffect_C.ClearArc
	void ReceiveBeginPlay(); // Function ArcEffect.ArcEffect_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function ArcEffect.ArcEffect_C.ReceiveEndPlay
	void ExecuteUbergraph_ArcEffect(int32_t EntryPoint); // Function ArcEffect.ArcEffect_C.ExecuteUbergraph_ArcEffect
}; 



