#pragma once 
#include "SDK.h" 
 
 
// Function BP_PresentThrow.BP_PresentThrow_C.SetOutlineVisibility_Int
// Size: 0x1(Inherited: 0x0) 
struct FSetOutlineVisibility_Int
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Visible : 1;  // 0x0(0x1)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.ExecuteUbergraph_BP_PresentThrow
// Size: 0x409(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PresentThrow
{
	int32_t EntryPoint;  // 0x0(0x4)
	float Temp_float_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable : 1;  // 0x8(0x1)
	char ECollisionResponse Temp_byte_Variable;  // 0x9(0x1)
	char ECollisionResponse Temp_byte_Variable_2;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	float Temp_float_Variable_2;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct AActor* K2Node_Event_Actor;  // 0x18(0x8)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0x20(0x8)
	struct AActor* K2Node_Event_Other;  // 0x28(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FVector K2Node_Event_HitLocation;  // 0x3C(0xC)
	struct FVector K2Node_Event_HitNormal;  // 0x48(0xC)
	struct FVector K2Node_Event_NormalImpulse;  // 0x54(0xC)
	struct FHitResult K2Node_Event_Hit;  // 0x60(0x88)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_CustomEvent_SkipDmg : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_ComponentHasTag_ReturnValue : 1;  // 0xE9(0x1)
	char pad_234[6];  // 0xEA(0x6)
	struct ABP_Trap_C* K2Node_DynamicCast_AsBP_Trap;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct ABP_Generator_C* K2Node_DynamicCast_AsBP_Generator;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct ABP_SaltCircle_C* K2Node_DynamicCast_AsBP_Salt_Circle;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct ABP_Hunter_C* K2Node_DynamicCast_AsBP_Hunter;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct ALvlProp_C* K2Node_DynamicCast_AsLvl_Prop;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x13C(0xC)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x148(0x1)
	char pad_329[3];  // 0x149(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x14C(0xC)
	float CallFunc_BreakVector_X;  // 0x158(0x4)
	float CallFunc_BreakVector_Y;  // 0x15C(0x4)
	float CallFunc_BreakVector_Z;  // 0x160(0x4)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize;  // 0x164(0xC)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_IsServer_ReturnValue_2 : 1;  // 0x170(0x1)
	char pad_369_1 : 7;  // 0x171(0x1)
	bool CallFunc_IsServer_ReturnValue_3 : 1;  // 0x171(0x1)
	char pad_370[6];  // 0x172(0x6)
	struct AProp_C* K2Node_DynamicCast_AsProp;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue;  // 0x188(0x8)
	float K2Node_Select_Default;  // 0x190(0x4)
	char pad_404_1 : 7;  // 0x194(0x1)
	bool K2Node_Event_Visible : 1;  // 0x194(0x1)
	char pad_405_1 : 7;  // 0x195(0x1)
	bool K2Node_Event_Collide : 1;  // 0x195(0x1)
	char ECollisionResponse K2Node_Select_Default_2;  // 0x196(0x1)
	char pad_407_1 : 7;  // 0x197(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x197(0x1)
	float K2Node_Event_DeltaSeconds;  // 0x198(0x4)
	struct FHitResult CallFunc_K2_AddActorLocalRotation_SweepHitResult;  // 0x19C(0x88)
	char pad_548_1 : 7;  // 0x224(0x1)
	bool CallFunc_IsServer_ReturnValue_4 : 1;  // 0x224(0x1)
	char pad_549[3];  // 0x225(0x3)
	float K2Node_Event_Damage;  // 0x228(0x4)
	char pad_556[4];  // 0x22C(0x4)
	struct AMGH_PlayerState_C* K2Node_Event_PS_Responsible;  // 0x230(0x8)
	struct FVector_NetQuantize K2Node_CustomEvent_Loc;  // 0x238(0xC)
	float Temp_float_Variable_3;  // 0x244(0x4)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x248(0x1)
	char pad_585_1 : 7;  // 0x249(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x249(0x1)
	char pad_586_1 : 7;  // 0x24A(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0x24A(0x1)
	char pad_587[5];  // 0x24B(0x5)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x250(0x30)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool CallFunc_IsServer_ReturnValue_5 : 1;  // 0x280(0x1)
	char pad_641[7];  // 0x281(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x288(0x8)
	struct AThrownPresentExplosion_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x298(0x1)
	char pad_665[3];  // 0x299(0x3)
	float K2Node_Select_Default_3;  // 0x29C(0x4)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x2A4(0xC)
	struct FVector CallFunc_Vector_GetAbs_ReturnValue;  // 0x2B0(0xC)
	float CallFunc_BreakVector_X_2;  // 0x2BC(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x2C0(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x2C4(0x4)
	struct UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue_2;  // 0x2C8(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2D0(0x4)
	char pad_724[12];  // 0x2D4(0xC)
	struct FTransform CallFunc_GetTransform_ReturnValue_2;  // 0x2E0(0x30)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x310(0x4)
	struct FVector CallFunc_BreakTransform_Location;  // 0x314(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x320(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x32C(0xC)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x338(0x1)
	char pad_825[7];  // 0x339(0x7)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x340(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x370(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x378(0xC)
	char pad_900[4];  // 0x384(0x4)
	struct ABP_ThrownPresentDestroyed_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x388(0x8)
	float CallFunc_BreakVector_X_3;  // 0x390(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x394(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x398(0x4)
	struct FVector_NetQuantize K2Node_MakeStruct_Vector_NetQuantize_2;  // 0x39C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x3A8(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x3B4(0xC)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x3C0(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x3C8(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x3D0(0x8)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface;  // 0x3D8(0x10)
	char pad_1000_1 : 7;  // 0x3E8(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x3E8(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x3E9(0x1)
	char pad_1002[6];  // 0x3EA(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x3F0(0x8)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface_2;  // 0x3F8(0x10)
	char pad_1032_1 : 7;  // 0x408(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x408(0x1)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.ReceiveHit
// Size: 0xC8(Inherited: 0xC8) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x1C(0xC)
	struct FVector HitNormal;  // 0x28(0xC)
	struct FVector NormalImpulse;  // 0x34(0xC)
	struct FHitResult Hit;  // 0x40(0x88)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.Explode
// Size: 0x1(Inherited: 0x0) 
struct FExplode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool SkipDmg : 1;  // 0x0(0x1)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.MiscHit
// Size: 0x10(Inherited: 0x0) 
struct FMiscHit
{
	float Damage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AMGH_PlayerState_C* PS Responsible;  // 0x8(0x8)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.MC_DestroyPresent
// Size: 0xC(Inherited: 0x0) 
struct FMC_DestroyPresent
{
	struct FVector_NetQuantize Loc;  // 0x0(0xC)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.SetCameraCollide_Int
// Size: 0x1(Inherited: 0x0) 
struct FSetCameraCollide_Int
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Collide : 1;  // 0x0(0x1)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.SetOwnerInfo_Int
// Size: 0x8(Inherited: 0x0) 
struct FSetOwnerInfo_Int
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function BP_PresentThrow.BP_PresentThrow_C.GetOwnerInfo_Int
// Size: 0x8(Inherited: 0x0) 
struct FGetOwnerInfo_Int
{
	struct AActor* Owner;  // 0x0(0x8)

}; 
