#pragma once 
#include <BP_TutorialRedShrine_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_TutorialRedShrine.BP_TutorialRedShrine_C
// Size: 0x309(Inherited: 0x281) 
struct ABP_TutorialRedShrine_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x290(0x8)
	struct UStaticMeshComponent* Candle;  // 0x298(0x8)
	struct UStaticMeshComponent* Manuscript_02;  // 0x2A0(0x8)
	struct UStaticMeshComponent* SM_Candle02_lit2;  // 0x2A8(0x8)
	struct UStaticMeshComponent* SM_Candle03_lit1;  // 0x2B0(0x8)
	struct UStaticMeshComponent* SM_Candle02_lit1;  // 0x2B8(0x8)
	struct UStaticMeshComponent* SM_Candle02_lit;  // 0x2C0(0x8)
	struct UStaticMeshComponent* SM_Gravestone06;  // 0x2C8(0x8)
	struct UStaticMeshComponent* SM_Candle03_lit;  // 0x2D0(0x8)
	struct UWidgetComponent* Widget;  // 0x2D8(0x8)
	struct UBoxComponent* InteractOverlap;  // 0x2E0(0x8)
	struct UPointLightComponent* PointLight1;  // 0x2E8(0x8)
	struct UPointLightComponent* PointLight;  // 0x2F0(0x8)
	struct USpotLightComponent* SpotLight;  // 0x2F8(0x8)
	struct UShrineIndicator_UI_C* ShrineIndicator;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool RedLight? : 1;  // 0x308(0x1)

	void ActivateRedShrine(); // Function BP_TutorialRedShrine.BP_TutorialRedShrine_C.ActivateRedShrine
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_TutorialRedShrine.BP_TutorialRedShrine_C.ReceiveEndPlay
	void MakeVisible(); // Function BP_TutorialRedShrine.BP_TutorialRedShrine_C.MakeVisible
	void CreateMiscWidget(); // Function BP_TutorialRedShrine.BP_TutorialRedShrine_C.CreateMiscWidget
	void ReceiveBeginPlay(); // Function BP_TutorialRedShrine.BP_TutorialRedShrine_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_TutorialRedShrine(int32_t EntryPoint); // Function BP_TutorialRedShrine.BP_TutorialRedShrine_C.ExecuteUbergraph_BP_TutorialRedShrine
}; 



