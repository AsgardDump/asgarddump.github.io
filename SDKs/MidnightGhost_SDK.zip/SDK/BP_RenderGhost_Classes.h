#pragma once 
#include <BP_RenderGhost_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RenderGhost.BP_RenderGhost_C
// Size: 0x4F8(Inherited: 0x4C0) 
struct ABP_RenderGhost_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UNiagaraComponent* NS_GhostBody_Smoke;  // 0x4C8(0x8)
	struct UPointLightComponent* PointLight1;  // 0x4D0(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x4D8(0x8)
	char GhostSkins EquippedGhostSkin;  // 0x4E0(0x1)
	char pad_1249[7];  // 0x4E1(0x7)
	struct TArray<struct UMaterialInstanceDynamic*> Materials;  // 0x4E8(0x10)

	void ReceiveBeginPlay(); // Function BP_RenderGhost.BP_RenderGhost_C.ReceiveBeginPlay
	void SetSkin(char GhostSkins EquippedGhostSkin); // Function BP_RenderGhost.BP_RenderGhost_C.SetSkin
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_RenderGhost.BP_RenderGhost_C.ReceiveEndPlay
	void DeferredLoadSkin(bool WasSuccessful); // Function BP_RenderGhost.BP_RenderGhost_C.DeferredLoadSkin
	void ExecuteUbergraph_BP_RenderGhost(int32_t EntryPoint); // Function BP_RenderGhost.BP_RenderGhost_C.ExecuteUbergraph_BP_RenderGhost
}; 



