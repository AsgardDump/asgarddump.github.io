#pragma once 
#include "SDK.h" 
 
 
// Function BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C.ExecuteUbergraph_BP_Hunter_Render_BTeam
// Size: 0x104(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Hunter_Render_BTeam
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	struct UBestTeam_Nameplate_UI_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_GetMGHPlayerName_Player_Name;  // 0x30(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x40(0x10)
	struct FString CallFunc_GetMGHPlayerName_Player_Name_2;  // 0x50(0x10)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x60(0x10)
	AActor* K2Node_CustomEvent_Prop_Class;  // 0x70(0x8)
	struct FName K2Node_CustomEvent_Socket_Name;  // 0x78(0x8)
	struct FTransform K2Node_CustomEvent_Offsets;  // 0x80(0x30)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xB0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0xD8(0x10)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct AActor* CallFunc_Array_Get_Item;  // 0xF0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xF8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0xFC(0x4)
	int32_t CallFunc_Max_ReturnValue;  // 0x100(0x4)

}; 
// Function BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C.SpawnVictoryPosePropAttached
// Size: 0x40(Inherited: 0x0) 
struct FSpawnVictoryPosePropAttached
{
	AActor* Prop Class;  // 0x0(0x8)
	struct FName Socket Name;  // 0x8(0x8)
	struct FTransform Offsets;  // 0x10(0x30)

}; 
