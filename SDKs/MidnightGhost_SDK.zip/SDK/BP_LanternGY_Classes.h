#pragma once 
#include <BP_LanternGY_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LanternGY.BP_LanternGY_C
// Size: 0x250(Inherited: 0x220) 
struct ABP_LanternGY_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* SM_Ship_Lantern;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Timeline_0_PercentDone_720D07B3443C1F4BE6599480EDA701C2;  // 0x238(0x4)
	char ETimelineDirection Timeline_0__Direction_720D07B3443C1F4BE6599480EDA701C2;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x240(0x8)
	struct UMaterialInstanceDynamic* RedMtl;  // 0x248(0x8)

	void Timeline_0__FinishedFunc(); // Function BP_LanternGY.BP_LanternGY_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_LanternGY.BP_LanternGY_C.Timeline_0__UpdateFunc
	void PreMidnightFlutter(float FlutterIntensity); // Function BP_LanternGY.BP_LanternGY_C.PreMidnightFlutter
	void FadeBackRed(float PercentDone); // Function BP_LanternGY.BP_LanternGY_C.FadeBackRed
	void ResetIntensity(); // Function BP_LanternGY.BP_LanternGY_C.ResetIntensity
	void GoMidnight(float RedIntensityDivider); // Function BP_LanternGY.BP_LanternGY_C.GoMidnight
	void InitDynamicMtl(); // Function BP_LanternGY.BP_LanternGY_C.InitDynamicMtl
	void ExecuteUbergraph_BP_LanternGY(int32_t EntryPoint); // Function BP_LanternGY.BP_LanternGY_C.ExecuteUbergraph_BP_LanternGY
}; 



