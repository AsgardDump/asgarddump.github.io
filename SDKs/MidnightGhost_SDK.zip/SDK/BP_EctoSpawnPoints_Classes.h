#pragma once 
#include <BP_EctoSpawnPoints_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EctoSpawnPoints.BP_EctoSpawnPoints_C
// Size: 0x248(Inherited: 0x220) 
struct ABP_EctoSpawnPoints_C : public AActor
{
	struct UBillboardComponent* Billboard;  // 0x220(0x8)
	struct ABP_Ectoplasm_C* MyHealthOrb;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool OnlySpawnInCertainAlterations : 1;  // 0x230(0x1)
	char pad_561[7];  // 0x231(0x7)
	struct TArray<int32_t> CertainAlterations;  // 0x238(0x10)

}; 



