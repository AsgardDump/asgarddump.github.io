#pragma once 
#include <BP_Hunter_Render_BTeam_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C
// Size: 0x26D1(Inherited: 0x2675) 
struct ABP_Hunter_Render_BTeam_C : public ABP_Hunter_Render_C
{
	char pad_9845[3];  // 0x2675(0x3)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2678(0x8)
	struct UWidgetComponent* BestTeam_Nameplate;  // 0x2680(0x8)
	int32_t Player Level;  // 0x2688(0x4)
	char pad_9868[4];  // 0x268C(0x4)
	struct AMGH_PlayerState_C* Custom Player State;  // 0x2690(0x8)
	char pad_9880[8];  // 0x2698(0x8)
	struct FTransform SpawnPoint;  // 0x26A0(0x30)
	char VictoryPoses VictoryPoseChosen;  // 0x26D0(0x1)

	void ReceiveBeginPlay(); // Function BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C.ReceiveBeginPlay
	void SpawnVictoryPosePropAttached(AActor* Prop Class, struct FName Socket Name, struct FTransform Offsets); // Function BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C.SpawnVictoryPosePropAttached
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_Hunter_Render_BTeam(int32_t EntryPoint); // Function BP_Hunter_Render_BTeam.BP_Hunter_Render_BTeam_C.ExecuteUbergraph_BP_Hunter_Render_BTeam
}; 



