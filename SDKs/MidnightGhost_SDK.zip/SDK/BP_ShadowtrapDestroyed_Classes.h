#pragma once 
#include <BP_ShadowtrapDestroyed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C
// Size: 0x268(Inherited: 0x220) 
struct ABP_ShadowtrapDestroyed_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Prop_Glass_Break_01;  // 0x228(0x8)
	struct UParticleSystemComponent* P_Impact_Transform-noSp;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float Fadeout_Interp_9FB25CD542F84FD45869AE839CE40B4C;  // 0x240(0x4)
	char ETimelineDirection Fadeout__Direction_9FB25CD542F84FD45869AE839CE40B4C;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* FadeOut;  // 0x248(0x8)
	struct TArray<struct UStaticMeshComponent*> shards;  // 0x250(0x10)
	struct UMaterialInstanceDynamic* Mtl;  // 0x260(0x8)

	void UserConstructionScript(); // Function BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C.UserConstructionScript
	void FadeOut__FinishedFunc(); // Function BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C.FadeOut__FinishedFunc
	void FadeOut__UpdateFunc(); // Function BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C.FadeOut__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_ShadowtrapDestroyed(int32_t EntryPoint); // Function BP_ShadowtrapDestroyed.BP_ShadowtrapDestroyed_C.ExecuteUbergraph_BP_ShadowtrapDestroyed
}; 



