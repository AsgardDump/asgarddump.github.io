#pragma once 
#include "SDK.h" 
 
 
// Function BP_SpectralCannon.BP_SpectralCannon_C.HideUnhideVacuum
// Size: 0x1(Inherited: 0x0) 
struct FHideUnhideVacuum
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Hide? : 1;  // 0x0(0x1)

}; 
// Function BP_SpectralCannon.BP_SpectralCannon_C.ExecuteUbergraph_BP_SpectralCannon
// Size: 0x111(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SpectralCannon
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	float K2Node_Event_DeltaSeconds;  // 0xC(0x4)
	struct ABP_SpectralCannon_C* K2Node_CustomEvent_BeamRifle_2;  // 0x10(0x8)
	struct FLinearColor K2Node_CustomEvent_Color_Emissive_2;  // 0x18(0x10)
	struct FLinearColor K2Node_CustomEvent_InteractiveLight;  // 0x28(0x10)
	struct ABP_SpectralCannon_C* K2Node_CustomEvent_BeamRifle;  // 0x38(0x8)
	struct FLinearColor K2Node_CustomEvent_Color_Emissive;  // 0x40(0x10)
	struct FLinearColor K2Node_CustomEvent_Interactive_Light;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x61(0x1)
	char pad_98[2];  // 0x62(0x2)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x64(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x68(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x6C(0x4)
	struct FLinearColor CallFunc_MakeColor_ReturnValue;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct ABP_Hunter_C* K2Node_CustomEvent_Hunter;  // 0x88(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x90(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x98(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xA0(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xA4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0xA8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0xAC(0x4)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_2;  // 0xB0(0x10)
	struct FLinearColor CallFunc_CInterpTo_ReturnValue;  // 0xC0(0x10)
	struct FLinearColor CallFunc_CInterpTo_ReturnValue_2;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_CustomEvent_Hide_ : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xE1(0x1)
	char pad_226[2];  // 0xE2(0x2)
	struct FLinearColor CallFunc_CInterpTo_ReturnValue_3;  // 0xE4(0x10)
	char pad_244[4];  // 0xF4(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0xF8(0x8)
	struct UMGH_GameInstance_BP_C* K2Node_DynamicCast_AsMGH_Game_Instance_BP;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	int32_t CallFunc_Return_Shadow_Settings_Shadow_Setting;  // 0x10C(0x4)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x110(0x1)

}; 
// Function BP_SpectralCannon.BP_SpectralCannon_C.SetFirstPerson
// Size: 0x8(Inherited: 0x0) 
struct FSetFirstPerson
{
	struct ABP_Hunter_C* Hunter;  // 0x0(0x8)

}; 
// Function BP_SpectralCannon.BP_SpectralCannon_C.MC_SetLightColor
// Size: 0x28(Inherited: 0x0) 
struct FMC_SetLightColor
{
	struct ABP_SpectralCannon_C* BeamRifle;  // 0x0(0x8)
	struct FLinearColor Color Emissive;  // 0x8(0x10)
	struct FLinearColor Interactive Light;  // 0x18(0x10)

}; 
// Function BP_SpectralCannon.BP_SpectralCannon_C.SetLightColor
// Size: 0x28(Inherited: 0x0) 
struct FSetLightColor
{
	struct ABP_SpectralCannon_C* BeamRifle;  // 0x0(0x8)
	struct FLinearColor Color Emissive;  // 0x8(0x10)
	struct FLinearColor InteractiveLight;  // 0x18(0x10)

}; 
// Function BP_SpectralCannon.BP_SpectralCannon_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
