#pragma once 
#include <BP_MGH_Instance_Interface_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MGH_Instance_Interface.BP_MGH_Instance_Interface_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_MGH_Instance_Interface_C : public UInterface
{

}; 



