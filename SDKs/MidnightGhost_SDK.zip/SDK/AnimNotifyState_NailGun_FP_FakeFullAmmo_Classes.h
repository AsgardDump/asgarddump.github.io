#pragma once 
#include <AnimNotifyState_NailGun_FP_FakeFullAmmo_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimNotifyState_NailGun_FP_FakeFullAmmo.AnimNotifyState_NailGun_FP_FakeFullAmmo_C
// Size: 0x30(Inherited: 0x30) 
struct UAnimNotifyState_NailGun_FP_FakeFullAmmo_C : public UAnimNotifyState
{

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_NailGun_FP_FakeFullAmmo.AnimNotifyState_NailGun_FP_FakeFullAmmo_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_NailGun_FP_FakeFullAmmo.AnimNotifyState_NailGun_FP_FakeFullAmmo_C.Received_NotifyBegin
}; 



