#pragma once 
#include <BP_SmasherPanel_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SmasherPanel.BP_SmasherPanel_C
// Size: 0x2A0(Inherited: 0x281) 
struct ABP_SmasherPanel_C : public ABP_interactiveObject_C
{
	char pad_641[7];  // 0x281(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x288(0x8)
	struct UBoxComponent* Box;  // 0x290(0x8)
	struct ABP_BigHammer_Factory_C* MySmasher;  // 0x298(0x8)

	void Smasher(struct AMGH_PlayerController_BP_C* PC); // Function BP_SmasherPanel.BP_SmasherPanel_C.Smasher
	void ExecuteUbergraph_BP_SmasherPanel(int32_t EntryPoint); // Function BP_SmasherPanel.BP_SmasherPanel_C.ExecuteUbergraph_BP_SmasherPanel
}; 



