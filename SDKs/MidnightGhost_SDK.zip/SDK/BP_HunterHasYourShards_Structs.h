#pragma once 
#include "SDK.h" 
 
 
// Function BP_HunterHasYourShards.BP_HunterHasYourShards_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_HunterHasYourShards.BP_HunterHasYourShards_C.ExecuteUbergraph_BP_HunterHasYourShards
// Size: 0x34(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HunterHasYourShards
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMiscIndicator_UI_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FText Temp_text_Variable;  // 0x18(0x18)
	float K2Node_Event_DeltaSeconds;  // 0x30(0x4)

}; 
