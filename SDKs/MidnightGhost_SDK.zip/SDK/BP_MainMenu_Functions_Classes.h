#pragma once 
#include <BP_MainMenu_Functions_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MainMenu_Functions.BP_MainMenu_Functions_C
// Size: 0x28(Inherited: 0x28) 
struct UBP_MainMenu_Functions_C : public UBlueprintFunctionLibrary
{

	void GetGameStatusUI(struct TScriptInterface<IMGH_GameState_Interface_C> GameState, struct UObject* __WorldContext, struct FText& Text); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetGameStatusUI
	void AverageOfIntArray(struct TArray<int32_t>& IntArray, struct UObject* __WorldContext, float& Average); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AverageOfIntArray
	void Calculate Matchmaking Level Modifier(int32_t PlayerLevel, int32_t PlayerMultiplier, int32_t PartyCount, struct UObject* __WorldContext, int32_t& ModifiedLevel); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Calculate Matchmaking Level Modifier
	struct FVector2D Ghost Ability Render Scale(char GhostAbility Ability, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Ghost Ability Render Scale
	struct FVector2D HunterIconRenderTranslate(char HunterGadgets InputPin, bool Tooltip, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HunterIconRenderTranslate
	struct FVector2D HunterIconRenderScale(char HunterGadgets InputPin, bool Tooltip, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HunterIconRenderScale
	void GetCategoryColor(char LoadoutCategoryTypes Category, struct UObject* __WorldContext, struct FLinearColor& CategoryColor); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetCategoryColor
	void HowMuchXPNeededToLevel?(int32_t Current Level, struct UObject* __WorldContext, int32_t& XP Needed); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HowMuchXPNeededToLevel?
	void DistanceBetweenActors_ZDampened(struct AActor* Actor 1, struct AActor* Actor 2, struct UObject* __WorldContext, float& Distance, bool& Successful, float& Distance Z Dampened); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.DistanceBetweenActors_ZDampened
	void FindPlayerStateForPUID(struct FString Puid, struct AGameStateBase* GameState, struct UObject* __WorldContext, bool& Found, struct TScriptInterface<IMGH_PlayerStateInterface_C>& PlayerState); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.FindPlayerStateForPUID
	void GetNetworkOptions(struct APlayerController* PC, struct UObject* __WorldContext, struct UWB_Options_Network_C*& WB_Options_Network); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetNetworkOptions
	void GetHealthForHunterPerk(char HunterPerks Perk, struct UObject* __WorldContext, float& MaxHealth); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetHealthForHunterPerk
	void CalculateHunterHealth(char HunterPerks Hunter Perk, float Old Health, float Old Max Health, struct UObject* __WorldContext, float& Set Health); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.CalculateHunterHealth
	void IsActorInFrontOfActor(struct AActor* Actor A, struct AActor* Actor B, bool Below Check Too?, struct UObject* __WorldContext, bool& In Front, float& DOT Product); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.IsActorInFrontOfActor
	void IsGadgetAWeapon?(char HunterGadgets Gadget, struct UObject* __WorldContext, bool& Weapon); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.IsGadgetAWeapon?
	void BindOnApplyDropdown(struct APlayerController* PC, struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnApplyDropdown
	void RemoveKeyBindingUnappliedChanges(struct APlayerController* PC, struct FString NewItem, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveKeyBindingUnappliedChanges
	void RemoveVideoUnappliedChanges(char EVideoSettings NewItem, struct APlayerController* PC, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveVideoUnappliedChanges
	void RemoveControlUnappliedChanges(struct APlayerController* PC, char EControlSettings NewItem, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveControlUnappliedChanges
	void RemoveAudioUnappliedChanges(char AudioVolumeType NewChange, struct APlayerController* PC, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveAudioUnappliedChanges
	void Matching Strings Remove(struct TArray<struct FString>& Base String Array, struct TArray<struct FString>& Strings to Remove, struct UObject* __WorldContext, bool& Found, struct TArray<struct FString>& Base Strings Filtered, struct TArray<struct FString>& Base Strings Removed); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Matching Strings Remove
	void UnbindAllBackRequest(struct FDelegate& OnBackApply, struct FDelegate& OnDiscardChanges, struct FDelegate& OnCancel, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnbindAllBackRequest
	void BindAllBackRequest(struct FDelegate& OnBackApply, struct FDelegate& OnDiscardChanges, struct FDelegate& OnCancel, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindAllBackRequest
	bool CreateBackRequest(struct UObject* __WorldContext, struct UWB_UnappliedChanges_BackRequest_C*& NewWidget); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.CreateBackRequest
	void BindOnControlBack(struct APlayerController* PC, struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnControlBack
	void BindOnAudioBack(struct APlayerController* PC, struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnAudioBack
	void BindOnVideoBack(struct APlayerController* PC, struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnVideoBack
	void BindOnKeyBindingApply(struct APlayerController* PC, struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnKeyBindingApply
	bool HasKeyBindingUnappliedChanges(struct APlayerController* PC, struct FString ItemToFind, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasKeyBindingUnappliedChanges
	void AddKeyBindingUnappliedChanges(struct APlayerController* PC, struct FString NewItem, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AddKeyBindingUnappliedChanges
	void GetKeyBindingOptions(struct APlayerController* PC, struct UObject* __WorldContext, struct UWB_Options_KeyRebinding_C*& WB_Options_KeyRebinding); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetKeyBindingOptions
	void BindOnControlApply(struct APlayerController* PC, struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnControlApply
	bool HasControlUnappliedChanges(struct APlayerController* PC, char EControlSettings NewItem, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasControlUnappliedChanges
	void AddControlUnappliedChanges(struct APlayerController* PC, char EControlSettings NewItem, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AddControlUnappliedChanges
	void GetControlOptions(struct APlayerController* PC, struct UObject* __WorldContext, struct UWB_Options_Controls_C*& WB_Options_Controls); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetControlOptions
	void BindOnAudioApply(struct APlayerController* PC, struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnAudioApply
	bool HasAudioUnappliedChanges(struct APlayerController* PC, char AudioVolumeType ItemToFind, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAudioUnappliedChanges
	void AddAudioUnappliedChanges(char AudioVolumeType NewChange, struct APlayerController* PC, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AddAudioUnappliedChanges
	void GetAudioOptions(struct APlayerController* PC, struct UObject* __WorldContext, struct UWB_Options_Audio_C*& WB_Options_Audio); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetAudioOptions
	bool HasVideoUnappliedChanges(struct APlayerController* PC, char EVideoSettings ItemToFind, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasVideoUnappliedChanges
	void Add Video Unapplied Changes(char EVideoSettings NewItem, struct APlayerController* PC, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Add Video Unapplied Changes
	void GetVideoOptions(struct APlayerController* PC, struct UObject* __WorldContext, struct UWB_Options_Video_C*& WB_Options_Video); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetVideoOptions
	void MapStringFixer(struct FString Map String In, bool To Display Name?, struct UObject* __WorldContext, struct FString& Map String Fixed); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.MapStringFixer
	void DistanceBetweenActors(struct AActor* Actor 1, struct AActor* Actor 2, struct UObject* __WorldContext, float& Distance, bool& Successful); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.DistanceBetweenActors
	void AverageOfFloatArray(struct TArray<float>& Floats, struct UObject* __WorldContext, float& Average); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.AverageOfFloatArray
	void Seconds_To_MinuteSeconds(float Seconds, struct UObject* __WorldContext, struct FString& Minutes:Seconds, float& Minutes Out, float& Seconds Out); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Seconds_To_MinuteSeconds
	void GetMGHPlayerName(struct APlayerState* Player State, struct UObject* __WorldContext, struct FString& Player Name); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.GetMGHPlayerName
	void SetupParameters(struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.SetupParameters
	void Get_WB_PauseMenu(struct UObject* __WorldContext, struct UWB_PauseMenu_C*& WB_PauseMenu); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Get_WB_PauseMenu
	void UnbindOnCancelRequest(struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnbindOnCancelRequest
	void UnbindOnConfirmRequest(struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnbindOnConfirmRequest
	void RemoveRequest(struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.RemoveRequest
	void BindOnCancelRequest(struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnCancelRequest
	void BindOnConfirmRequest(struct FDelegate& Event, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.BindOnConfirmRequest
	bool CreateRequest(bool bShowOnlyOkButton, bool bUseCancelCountdown, struct FText HeadText, struct FText MessageText, bool CUSTOM - LEAVE MATCH?, struct UObject* __WorldContext, struct UWB_Request_C*& NewWidget); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.CreateRequest
	void HasAnyKeybindingButtonFocus(struct UObject* __WorldContext, bool& HasFocus); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAnyKeybindingButtonFocus
	void HasAnyProgressButtonFocus(struct UObject* __WorldContext, bool& HasFocus); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAnyProgressButtonFocus
	void HasAnyButtonFocus(struct UObject* __WorldContext, bool& HasFocus); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HasAnyButtonFocus
	void Get_WB_MainMenu(struct APlayerController* PC, struct UObject* __WorldContext, struct UWB_ProMainMenu_C*& WB_ProMainMenu); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.Get_WB_MainMenu
	void HandleResponsiveHovering(bool bResponsiveHovering, struct UWB_NativeButton_C* ButtonToFocus, struct APlayerController* OwningPlayer, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.HandleResponsiveHovering
	void UnhoverAllNativeButtons(struct UWB_NativeButton_C* Exception, struct UObject* __WorldContext); // Function BP_MainMenu_Functions.BP_MainMenu_Functions_C.UnhoverAllNativeButtons
}; 



