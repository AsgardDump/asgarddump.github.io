#pragma once 
#include "SDK.h" 
 
 
// Function BP_ky_beam06-Sabotage.BP_ky_beam06-Sabotage_C.ExecuteUbergraph_BP_ky_beam06-Sabotage
// Size: 0x51(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ky_beam06-Sabotage
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x20(0xC)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x30(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x38(0xC)
	char pad_68[4];  // 0x44(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x50(0x1)

}; 
// Function BP_ky_beam06-Sabotage.BP_ky_beam06-Sabotage_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_ky_beam06-Sabotage.BP_ky_beam06-Sabotage_C.UserConstructionScript
// Size: 0x8(Inherited: 0x18) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
