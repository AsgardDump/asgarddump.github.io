#pragma once 
#include "SDK.h" 
 
 
// Function BP_HunterVehicle.BP_HunterVehicle_C.VanUpdateBoomboxSong_Int
// Size: 0x1(Inherited: 0x0) 
struct FVanUpdateBoomboxSong_Int
{
	char MGHMusicTracks Song;  // 0x0(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.ExecuteUbergraph_BP_HunterVehicle
// Size: 0x340(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HunterVehicle
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_MakeLiteralFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xC(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x10(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x14(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x18(0x8)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x3C(0xC)
	float CallFunc_BreakVector_X;  // 0x48(0x4)
	float CallFunc_BreakVector_Y;  // 0x4C(0x4)
	float CallFunc_BreakVector_Z;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x58(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface_2;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x7C(0x4)
	char GameModeTypeEnum CallFunc_GetGameMode_Int_GameMode;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x84(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x88(0xC)
	char pad_148[4];  // 0x94(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x98(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xA0(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xA8(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0xB0(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0xBC(0x88)
	char pad_324[4];  // 0x144(0x4)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x148(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x158(0x10)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x168(0x1)
	char pad_361_1 : 7;  // 0x169(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x169(0x1)
	char pad_362_1 : 7;  // 0x16A(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x16A(0x1)
	char pad_363_1 : 7;  // 0x16B(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x16B(0x1)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x16C(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool K2Node_CustomEvent_Arrived : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_3;  // 0x180(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x188(0x4)
	char pad_396[4];  // 0x18C(0x4)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface_3;  // 0x190(0x10)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1A0(0x1)
	char pad_417[7];  // 0x1A1(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_4;  // 0x1A8(0x8)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface_4;  // 0x1B0(0x10)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1C0(0x1)
	char MGHMusicTracks K2Node_Event_Song;  // 0x1C1(0x1)
	char pad_450[2];  // 0x1C2(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x1C4(0xC)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1D0(0x1)
	char pad_465[7];  // 0x1D1(0x7)
	struct USoundBase* CallFunc_GetMusicForMusicTitleEnum_Sound;  // 0x1D8(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x1E0(0x4)
	char pad_484[4];  // 0x1E4(0x4)
	struct ABP_BoomboxInteractVan_C* K2Node_DynamicCast_AsBP_Boombox_Interact_Van;  // 0x1E8(0x8)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x1F0(0x1)
	char pad_497_1 : 7;  // 0x1F1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x1F1(0x1)
	uint8_t  CallFunc_GetPlayState_ReturnValue;  // 0x1F2(0x1)
	char pad_499[5];  // 0x1F3(0x5)
	struct FString CallFunc_GetDisplayName_ReturnValue_2;  // 0x1F8(0x10)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x208(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x218(0x10)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_IsPlaying_ReturnValue : 1;  // 0x228(0x1)
	char pad_553[7];  // 0x229(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x230(0x10)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_5;  // 0x248(0x8)
	struct TScriptInterface<IMGH_GameState_Interface_C> K2Node_DynamicCast_AsMGH_Game_State_Interface_5;  // 0x250(0x10)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x261(0x1)
	char pad_610[2];  // 0x262(0x2)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x264(0x4)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct TArray<struct ABP_VanStoppingPoint_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x270(0x10)
	struct ABP_HunterVehicle_C* K2Node_CustomEvent_BP_Van;  // 0x280(0x8)
	struct ABP_VanStoppingPoint_C* CallFunc_Array_Get_Item;  // 0x288(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x290(0x4)
	char pad_660_1 : 7;  // 0x294(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x294(0x1)
	char pad_661_1 : 7;  // 0x295(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_4 : 1;  // 0x295(0x1)
	char pad_662[2];  // 0x296(0x2)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x298(0x4)
	char pad_668_1 : 7;  // 0x29C(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x2A0(0x10)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x2B0(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x2BC(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue_2;  // 0x2C0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x2D0(0x10)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x2E8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x2F8(0x10)
	float CallFunc_CalculateTargetSpeed_TargetSpeed_cm_s;  // 0x308(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x30C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x310(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x320(0x8)
	float CallFunc_GetSplineLength_ReturnValue;  // 0x328(0x4)
	char pad_812_1 : 7;  // 0x32C(0x1)
	bool Temp_bool_IsClosed_Variable_4 : 1;  // 0x32C(0x1)
	char pad_813_1 : 7;  // 0x32D(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x32D(0x1)
	char pad_814[2];  // 0x32E(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue_5;  // 0x330(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x334(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_6;  // 0x338(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x33C(0x4)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.Startup
// Size: 0x8(Inherited: 0x0) 
struct FStartup
{
	struct ABP_HunterVehicle_C* BP_Van;  // 0x0(0x8)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.RideIn
// Size: 0x1(Inherited: 0x0) 
struct FRideIn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Arrived : 1;  // 0x0(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.BndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__CapsuleComponent_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.ReturnSeat
// Size: 0x11(Inherited: 0x0) 
struct FReturnSeat
{
	int32_t SeatNumber;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USceneComponent* Seat;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.AssignAnimationsToSeats
// Size: 0x21(Inherited: 0x0) 
struct FAssignAnimationsToSeats
{
	int32_t AnimRoll;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool KeepLookingFOrFreeAnim : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Variable_2;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	int32_t CallFunc_RandomInteger_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_MakeLiteralInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.GadgetIdleBooker
// Size: 0x24(Inherited: 0x0) 
struct FGadgetIdleBooker
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsSeatGadgetApproved__Approved : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct ABP_Hunter_C* CallFunc_Array_Get_Item;  // 0x10(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_TryToBookGadgetIdle_Success : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_TryToBookGadgetIdle_Success_2 : 1;  // 0x1E(0x1)
	char pad_31_1 : 7;  // 0x1F(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1F(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.TryToBookGadgetIdle
// Size: 0x50(Inherited: 0x0) 
struct FTryToBookGadgetIdle
{
	char HunterGadgets gadget To Book;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t SeatToBook;  // 0x4(0x4)
	struct ABP_Hunter_C* Hunter;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	struct FVanIdleGadgetBooker K2Node_MakeStruct_VanIdleGadgetBooker;  // 0x18(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FVanIdleGadgetBooker CallFunc_Array_Get_Item;  // 0x30(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_Map_Find_Value : 1;  // 0x4D(0x1)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x4E(0x1)
	char pad_79_1 : 7;  // 0x4F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x4F(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.GadgetBookerCleanUp
// Size: 0x36(Inherited: 0x0) 
struct FGadgetBookerCleanUp
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FVanIdleGadgetBooker K2Node_MakeStruct_VanIdleGadgetBooker;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct ABP_Hunter_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x35(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.IsSeatGadgetApproved?
// Size: 0x11(Inherited: 0x0) 
struct FIsSeatGadgetApproved?
{
	int32_t Seat;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Approved : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct ABP_Van_Boat2_C* K2Node_DynamicCast_AsBP_Van_Boat_3;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.InitiatePathMovement
// Size: 0xC1(Inherited: 0x0) 
struct FInitiatePathMovement
{
	char GameModeTypeEnum Temp_byte_Variable;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Temp_float_Variable;  // 0x4(0x4)
	float Temp_float_Variable_2;  // 0x8(0x4)
	float Temp_float_Variable_3;  // 0xC(0x4)
	float Temp_float_Variable_4;  // 0x10(0x4)
	float Temp_float_Variable_5;  // 0x14(0x4)
	float CallFunc_CalculateSpeedBoostBasedOnSlowDowns_SpeedBoost;  // 0x18(0x4)
	float K2Node_Select_Default;  // 0x1C(0x4)
	struct FVector CallFunc_GetLocationAtTime_ReturnValue;  // 0x20(0xC)
	struct FRotator CallFunc_GetRotationAtTime_ReturnValue;  // 0x2C(0xC)
	struct FHitResult CallFunc_K2_SetActorLocationAndRotation_SweepHitResult;  // 0x38(0x88)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_K2_SetActorLocationAndRotation_ReturnValue : 1;  // 0xC0(0x1)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.CalculateTargetSpeed
// Size: 0x60(Inherited: 0x0) 
struct FCalculateTargetSpeed
{
	float EndStoppingDistance;  // 0x0(0x4)
	float s;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetRollAtSplinePoint_ReturnValue;  // 0xC(0x4)
	float CallFunc_GetRollAtSplinePoint_ReturnValue_2;  // 0x10(0x4)
	float CallFunc_GetDistanceAlongSplineAtSplinePoint_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_GetDistanceAlongSplineAtSplinePoint_ReturnValue_2;  // 0x20(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x28(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x30(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x34(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x38(0x4)
	float CallFunc_GetSplineLength_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_4;  // 0x40(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x44(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_2;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x50(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x54(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_5;  // 0x58(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x5C(0x4)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.MoveVanAlongPath
// Size: 0xCC(Inherited: 0x0) 
struct FMoveVanAlongPath
{
	struct FHitResult CallFunc_K2_SetActorLocationAndRotation_SweepHitResult;  // 0x0(0x88)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_K2_SetActorLocationAndRotation_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8C(0x4)
	int32_t CallFunc_GetNumberOfSplinePoints_ReturnValue;  // 0x90(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x94(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x98(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x9C(0x4)
	float CallFunc_GetDistanceAlongSplineAtSplinePoint_ReturnValue;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	struct FVector CallFunc_GetLocationAtDistanceAlongSpline_ReturnValue;  // 0xA8(0xC)
	struct FRotator CallFunc_GetRotationAtDistanceAlongSpline_ReturnValue;  // 0xB4(0xC)
	struct FRotator CallFunc_GetRotationAtDistanceAlongSpline_ReturnValue_2;  // 0xC0(0xC)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.CalculateSpeedBoostBasedOnSlowDowns
// Size: 0x50(Inherited: 0x0) 
struct FCalculateSpeedBoostBasedOnSlowDowns
{
	float SpeedBoost;  // 0x0(0x4)
	float TotalAdjustedLength;  // 0x4(0x4)
	float CallFunc_GetSplineLength_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_GetNumberOfSplinePoints_ReturnValue;  // 0xC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t Temp_int_Variable;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	float CallFunc_GetDistanceAlongSplineAtSplinePoint_ReturnValue;  // 0x20(0x4)
	float CallFunc_GetDistanceAlongSplineAtSplinePoint_ReturnValue_2;  // 0x24(0x4)
	float CallFunc_GetRollAtSplinePoint_ReturnValue;  // 0x28(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_GetRollAtSplinePoint_ReturnValue_2;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x38(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x3C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x40(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x44(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x48(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x4C(0x4)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.LoadRideIn
// Size: 0x30(Inherited: 0x0) 
struct FLoadRideIn
{
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_LoadLevelInstance_bOutSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ULevelStreamingDynamic* CallFunc_LoadLevelInstance_ReturnValue;  // 0x28(0x8)

}; 
// Function BP_HunterVehicle.BP_HunterVehicle_C.GetVanMusicStatus_Int
// Size: 0x2(Inherited: 0x0) 
struct FGetVanMusicStatus_Int
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsSongPlaying : 1;  // 0x0(0x1)
	char MGHMusicTracks SongPlaying;  // 0x1(0x1)

}; 
