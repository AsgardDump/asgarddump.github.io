#pragma once 
#include "SDK.h" 
 
 
// Function BP_MainMenu_CaptureCharacter_Functions.BP_MainMenu_CaptureCharacter_Functions_C.IsCaptureCharacterExisting
// Size: 0x21(Inherited: 0x0) 
struct FIsCaptureCharacterExisting
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct ABP_CaptureActor_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_MainMenu_CaptureCharacter_Functions.BP_MainMenu_CaptureCharacter_Functions_C.DestroyCaptureCharacter
// Size: 0x38(Inherited: 0x0) 
struct FDestroyCaptureCharacter
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct TArray<struct ABP_CaptureActor_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x8(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	struct ABP_CaptureActor_C* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)

}; 
