#pragma once 
#include <BP_ManorChandelier_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ManorChandelier.BP_ManorChandelier_C
// Size: 0x242(Inherited: 0x220) 
struct ABP_ManorChandelier_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct UMaterialInstanceDynamic* M_Glow_Inst2;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool on? : 1;  // 0x240(0x1)
	char pad_577_1 : 7;  // 0x241(0x1)
	bool Halloween? : 1;  // 0x241(0x1)

	void UserConstructionScript(); // Function BP_ManorChandelier.BP_ManorChandelier_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_ManorChandelier.BP_ManorChandelier_C.ReceiveBeginPlay
	void NR_TurnOnOff(bool On); // Function BP_ManorChandelier.BP_ManorChandelier_C.NR_TurnOnOff
	void Server_TurnOnOff(bool On); // Function BP_ManorChandelier.BP_ManorChandelier_C.Server_TurnOnOff
	void OC_TurnOnOff(struct ABP_ManorChandelier_C* Chandolier, bool On); // Function BP_ManorChandelier.BP_ManorChandelier_C.OC_TurnOnOff
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_ManorChandelier.BP_ManorChandelier_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_ManorChandelier(int32_t EntryPoint); // Function BP_ManorChandelier.BP_ManorChandelier_C.ExecuteUbergraph_BP_ManorChandelier
}; 



