#pragma once 
#include <BP_DeadGhost_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DeadGhost.BP_DeadGhost_C
// Size: 0x688(Inherited: 0x4C0) 
struct ABP_DeadGhost_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct USpotLightComponent* CamFollowLight;  // 0x4C8(0x8)
	struct USphereComponent* ChillOverlap;  // 0x4D0(0x8)
	struct USphereComponent* PingOverlap;  // 0x4D8(0x8)
	struct USceneComponent* HealthSpawnPt;  // 0x4E0(0x8)
	struct ULimboCrouchComponent_C* LimboCrouchComponent;  // 0x4E8(0x8)
	struct UWidgetComponent* Widget_Nameplate_G;  // 0x4F0(0x8)
	struct USkeletalMeshComponent* Ghost_MainBody;  // 0x4F8(0x8)
	struct UCameraComponent* FollowCamera;  // 0x500(0x8)
	struct USpringArmComponent* SpringArm;  // 0x508(0x8)
	float VaultSecondPart_Progress_07CA379E492502D5460BFB9333C769C3;  // 0x510(0x4)
	char ETimelineDirection VaultSecondPart__Direction_07CA379E492502D5460BFB9333C769C3;  // 0x514(0x1)
	char pad_1301[3];  // 0x515(0x3)
	struct UTimelineComponent* VaultSecondPart;  // 0x518(0x8)
	float VaultFirstPart_Progress_ADE9414C45C0AE8CD4610CB06081351F;  // 0x520(0x4)
	char ETimelineDirection VaultFirstPart__Direction_ADE9414C45C0AE8CD4610CB06081351F;  // 0x524(0x1)
	char pad_1317[3];  // 0x525(0x3)
	struct UTimelineComponent* VaultFirstPart;  // 0x528(0x8)
	float MouseSensitivity;  // 0x530(0x4)
	float FOVSetting;  // 0x534(0x4)
	float MotionBlurSetting;  // 0x538(0x4)
	char pad_1340_1 : 7;  // 0x53C(0x1)
	bool MouseInvertX : 1;  // 0x53C(0x1)
	char pad_1341_1 : 7;  // 0x53D(0x1)
	bool MouseInvertY : 1;  // 0x53D(0x1)
	char pad_1342[2];  // 0x53E(0x2)
	float Backward Axis Value;  // 0x540(0x4)
	float Right Axis Value;  // 0x544(0x4)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool MIDNIGHT - GO TO YOUR BODY : 1;  // 0x548(0x1)
	char pad_1353[7];  // 0x549(0x7)
	struct UObject* YouDiedHere!;  // 0x550(0x8)
	struct UGhostAbility_UI_C* E Abilities;  // 0x558(0x8)
	struct AMGH_PlayerController_BP_C* MGHPlayerController;  // 0x560(0x8)
	char pad_1384_1 : 7;  // 0x568(0x1)
	bool Radar Sensitive? : 1;  // 0x568(0x1)
	char pad_1385_1 : 7;  // 0x569(0x1)
	bool Spawning Footprints? : 1;  // 0x569(0x1)
	char pad_1386[6];  // 0x56A(0x6)
	struct UAudioComponent* LimboLoop;  // 0x570(0x8)
	char pad_1400_1 : 7;  // 0x578(0x1)
	bool G Crouching : 1;  // 0x578(0x1)
	char pad_1401[7];  // 0x579(0x7)
	struct UGhostHauntTicker_C* Ticker;  // 0x580(0x8)
	struct ALvlProp_C* Last_LookAtLvlProp;  // 0x588(0x8)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool LookingAtLVLProp? : 1;  // 0x590(0x1)
	char pad_1425[7];  // 0x591(0x7)
	struct ALvlProp_C* LookAt_LvlProp;  // 0x598(0x8)
	struct FTimerHandle Timer;  // 0x5A0(0x8)
	struct FTimerHandle ShrineInteract;  // 0x5A8(0x8)
	struct AMGH_PlayerController_BP_C* MyPlayerController;  // 0x5B0(0x8)
	char pad_1464_1 : 7;  // 0x5B8(0x1)
	bool LookingAtShrine : 1;  // 0x5B8(0x1)
	char pad_1465[7];  // 0x5B9(0x7)
	struct ABP_GhostShrine_C* ShrineLookedAt;  // 0x5C0(0x8)
	struct AMGH_PlayerState_C* MGHPlayerState;  // 0x5C8(0x8)
	struct FVector EctoPlasmaLastPosition;  // 0x5D0(0xC)
	char pad_1500_1 : 7;  // 0x5DC(0x1)
	bool DamageLogUp : 1;  // 0x5DC(0x1)
	char pad_1501[3];  // 0x5DD(0x3)
	struct UDamageLog_UI_C* DamageLogUI;  // 0x5E0(0x8)
	struct UDeadGhost_UI_C* DeadGhostUI;  // 0x5E8(0x8)
	struct AColdSpotActor_C* ColdSpotActor;  // 0x5F0(0x8)
	struct ABP_Ectoplasm_C* My Ectoplasm;  // 0x5F8(0x8)
	int32_t HuntersChilled;  // 0x600(0x4)
	char pad_1540[4];  // 0x604(0x4)
	struct UBP_MGH_Instance_C* InputGameInstance;  // 0x608(0x8)
	int32_t Sound ID;  // 0x610(0x4)
	char pad_1556[4];  // 0x614(0x4)
	struct ABP_HallucinateActor_C* HallucinateActor;  // 0x618(0x8)
	char pad_1568_1 : 7;  // 0x620(0x1)
	bool LookingAtHauntShrine : 1;  // 0x620(0x1)
	char pad_1569[7];  // 0x621(0x7)
	struct ABP_TutorialHauntShrine_C* HauntShrineLookedAt;  // 0x628(0x8)
	char pad_1584_1 : 7;  // 0x630(0x1)
	bool DisableDeadGhostUI : 1;  // 0x630(0x1)
	char pad_1585_1 : 7;  // 0x631(0x1)
	bool TUTORIAL_ShowFormTip : 1;  // 0x631(0x1)
	char pad_1586[6];  // 0x632(0x6)
	struct TArray<struct UMaterialInstanceDynamic*> GhostMaterials;  // 0x638(0x10)
	char pad_1608_1 : 7;  // 0x648(0x1)
	bool VaultCoolDown : 1;  // 0x648(0x1)
	char pad_1609_1 : 7;  // 0x649(0x1)
	bool JumpHeld : 1;  // 0x649(0x1)
	char pad_1610_1 : 7;  // 0x64A(0x1)
	bool IsVaulting : 1;  // 0x64A(0x1)
	char pad_1611[1];  // 0x64B(0x1)
	float CachedVaultVelocity;  // 0x64C(0x4)
	struct FVector VaultLerpPositionStart;  // 0x650(0xC)
	struct FVector VaultLerpPositionEnd;  // 0x65C(0xC)
	float LastVaultTime;  // 0x668(0x4)
	float GamepadSensitivity;  // 0x66C(0x4)
	char pad_1648_1 : 7;  // 0x670(0x1)
	bool Emote Is Active : 1;  // 0x670(0x1)
	char Hunter_Emotes EquipedEmote;  // 0x671(0x1)
	char pad_1650[6];  // 0x672(0x6)
	struct TArray<struct AActor*> AllSpawnedEmoteProps;  // 0x678(0x10)

	void NeedBlockPing?(bool& bLock); // Function BP_DeadGhost.BP_DeadGhost_C.NeedBlockPing?
	void GetEctoBuildup(bool& Prop?, float& Radiation, bool& Sensitive?, bool& Midnight Form?); // Function BP_DeadGhost.BP_DeadGhost_C.GetEctoBuildup
	void Trace Down Check Footstep(); // Function BP_DeadGhost.BP_DeadGhost_C.Trace Down Check Footstep
	void DeSpawnEmotePrpAttached(); // Function BP_DeadGhost.BP_DeadGhost_C.DeSpawnEmotePrpAttached
	void Spawn Emote Prop Attached(AActor* Prop Class, struct FName Socket Name, struct FTransform Offsets); // Function BP_DeadGhost.BP_DeadGhost_C.Spawn Emote Prop Attached
	void GetMGHGameInstance(struct UMGH_GameInstance_BP_C*& Game Instance); // Function BP_DeadGhost.BP_DeadGhost_C.GetMGHGameInstance
	void IsABot?(bool& Bot); // Function BP_DeadGhost.BP_DeadGhost_C.IsABot?
	void SetWavyScreenVFX(int32_t PostProcess); // Function BP_DeadGhost.BP_DeadGhost_C.SetWavyScreenVFX
	void WhoVacuumedMe(); // Function BP_DeadGhost.BP_DeadGhost_C.WhoVacuumedMe
	void Get MGH Player State(struct AMGH_PlayerState_C*& MGHPlayerState); // Function BP_DeadGhost.BP_DeadGhost_C.Get MGH Player State
	void Get MGH Player Controller(struct AMGH_PlayerController_BP_C*& MGHPlayerController); // Function BP_DeadGhost.BP_DeadGhost_C.Get MGH Player Controller
	void Load Mouse Settings(); // Function BP_DeadGhost.BP_DeadGhost_C.Load Mouse Settings
	void VaultSecondPart__FinishedFunc(); // Function BP_DeadGhost.BP_DeadGhost_C.VaultSecondPart__FinishedFunc
	void VaultSecondPart__UpdateFunc(); // Function BP_DeadGhost.BP_DeadGhost_C.VaultSecondPart__UpdateFunc
	void VaultFirstPart__FinishedFunc(); // Function BP_DeadGhost.BP_DeadGhost_C.VaultFirstPart__FinishedFunc
	void VaultFirstPart__UpdateFunc(); // Function BP_DeadGhost.BP_DeadGhost_C.VaultFirstPart__UpdateFunc
	void InpActEvt_Jump_K2Node_InputActionEvent_6(struct FKey Key); // Function BP_DeadGhost.BP_DeadGhost_C.InpActEvt_Jump_K2Node_InputActionEvent_6
	void InpActEvt_Jump_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_DeadGhost.BP_DeadGhost_C.InpActEvt_Jump_K2Node_InputActionEvent_5
	void InpActEvt_Crouch_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_DeadGhost.BP_DeadGhost_C.InpActEvt_Crouch_K2Node_InputActionEvent_4
	void InpActEvt_Crouch_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_DeadGhost.BP_DeadGhost_C.InpActEvt_Crouch_K2Node_InputActionEvent_3
	void InpActEvt_Interact_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_DeadGhost.BP_DeadGhost_C.InpActEvt_Interact_K2Node_InputActionEvent_2
	void InpActEvt_R_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_DeadGhost.BP_DeadGhost_C.InpActEvt_R_K2Node_InputKeyEvent_1
	void InpActEvt_Emote_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_DeadGhost.BP_DeadGhost_C.InpActEvt_Emote_K2Node_InputActionEvent_1
	void OnNotifyEnd_701ADBF145761AD3CA97EBACE6B84A2F(struct FName NotifyName); // Function BP_DeadGhost.BP_DeadGhost_C.OnNotifyEnd_701ADBF145761AD3CA97EBACE6B84A2F
	void OnNotifyBegin_701ADBF145761AD3CA97EBACE6B84A2F(struct FName NotifyName); // Function BP_DeadGhost.BP_DeadGhost_C.OnNotifyBegin_701ADBF145761AD3CA97EBACE6B84A2F
	void OnInterrupted_701ADBF145761AD3CA97EBACE6B84A2F(struct FName NotifyName); // Function BP_DeadGhost.BP_DeadGhost_C.OnInterrupted_701ADBF145761AD3CA97EBACE6B84A2F
	void OnBlendOut_701ADBF145761AD3CA97EBACE6B84A2F(struct FName NotifyName); // Function BP_DeadGhost.BP_DeadGhost_C.OnBlendOut_701ADBF145761AD3CA97EBACE6B84A2F
	void OnCompleted_701ADBF145761AD3CA97EBACE6B84A2F(struct FName NotifyName); // Function BP_DeadGhost.BP_DeadGhost_C.OnCompleted_701ADBF145761AD3CA97EBACE6B84A2F
	void ReceiveBeginPlay(); // Function BP_DeadGhost.BP_DeadGhost_C.ReceiveBeginPlay
	void OC_DeadGhostStartup(); // Function BP_DeadGhost.BP_DeadGhost_C.OC_DeadGhostStartup
	void UnhideMeToGhosts(); // Function BP_DeadGhost.BP_DeadGhost_C.UnhideMeToGhosts
	void SetMotionBlur(float MotionBlur); // Function BP_DeadGhost.BP_DeadGhost_C.SetMotionBlur
	void SetCameraFOV(float FOV); // Function BP_DeadGhost.BP_DeadGhost_C.SetCameraFOV
	void SetMouseInvertX(bool Invert?); // Function BP_DeadGhost.BP_DeadGhost_C.SetMouseInvertX
	void SetMouseInvertY(bool Invert?); // Function BP_DeadGhost.BP_DeadGhost_C.SetMouseInvertY
	void InpAxisEvt_Move Backward_K2Node_InputAxisEvent_25(float AxisValue); // Function BP_DeadGhost.BP_DeadGhost_C.InpAxisEvt_Move Backward_K2Node_InputAxisEvent_25
	void InpAxisEvt_Move Forward_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_DeadGhost.BP_DeadGhost_C.InpAxisEvt_Move Forward_K2Node_InputAxisEvent_1
	void InpAxisEvt_Move Right_K2Node_InputAxisEvent_62(float AxisValue); // Function BP_DeadGhost.BP_DeadGhost_C.InpAxisEvt_Move Right_K2Node_InputAxisEvent_62
	void InpAxisEvt_Move Left_K2Node_InputAxisEvent_81(float AxisValue); // Function BP_DeadGhost.BP_DeadGhost_C.InpAxisEvt_Move Left_K2Node_InputAxisEvent_81
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_48(float AxisValue); // Function BP_DeadGhost.BP_DeadGhost_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_48
	void InpAxisEvt_Look_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_DeadGhost.BP_DeadGhost_C.InpAxisEvt_Look_K2Node_InputAxisEvent_2
	void NR_RespawnMeAtMidnight(); // Function BP_DeadGhost.BP_DeadGhost_C.NR_RespawnMeAtMidnight
	void OC_ReadyForMidnightRespawn(); // Function BP_DeadGhost.BP_DeadGhost_C.OC_ReadyForMidnightRespawn
	void NR Use Ability(char GhostHaunts Haunt Equipped, struct AMGH_PlayerController_BP_C* PC); // Function BP_DeadGhost.BP_DeadGhost_C.NR Use Ability
	void Server_SpawnRadarActivity(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_SpawnRadarActivity
	void MC_SpawnRadarActivity(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_SpawnRadarActivity
	void Server_SpawnFootprints(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_SpawnFootprints
	void MC_SpawnFootprints(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_SpawnFootprints
	void Bind_EctoplasmTrailDrop(); // Function BP_DeadGhost.BP_DeadGhost_C.Bind_EctoplasmTrailDrop
	void ReceiveTick(float DeltaSeconds); // Function BP_DeadGhost.BP_DeadGhost_C.ReceiveTick
	void Server_SpawnEctoplasmTrail(bool Local); // Function BP_DeadGhost.BP_DeadGhost_C.Server_SpawnEctoplasmTrail
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_DeadGhost.BP_DeadGhost_C.ReceiveEndPlay
	void NR_ChilledHunter(struct ABP_Hunter_C* Hunter); // Function BP_DeadGhost.BP_DeadGhost_C.NR_ChilledHunter
	void Server_PlsChillThisHunter(struct ABP_Hunter_C* Hunter); // Function BP_DeadGhost.BP_DeadGhost_C.Server_PlsChillThisHunter
	void Server_GhostCrouch(bool  On); // Function BP_DeadGhost.BP_DeadGhost_C.Server_GhostCrouch
	void MC_GhostCrouch(bool  On); // Function BP_DeadGhost.BP_DeadGhost_C.MC_GhostCrouch
	void Bind_HauntPush(); // Function BP_DeadGhost.BP_DeadGhost_C.Bind_HauntPush
	void HauntPushTicker(); // Function BP_DeadGhost.BP_DeadGhost_C.HauntPushTicker
	void Server_PushProp(struct ALvlProp_C* LvlProp, struct FVector_NetQuantize Velocity); // Function BP_DeadGhost.BP_DeadGhost_C.Server_PushProp
	void EndMediumPhase(); // Function BP_DeadGhost.BP_DeadGhost_C.EndMediumPhase
	void EnsureRespawn(); // Function BP_DeadGhost.BP_DeadGhost_C.EnsureRespawn
	void NR_MidnightRespawn(); // Function BP_DeadGhost.BP_DeadGhost_C.NR_MidnightRespawn
	void InteractWithShrine(); // Function BP_DeadGhost.BP_DeadGhost_C.InteractWithShrine
	void ResetHaunt(); // Function BP_DeadGhost.BP_DeadGhost_C.ResetHaunt
	void SetUpHaunt(); // Function BP_DeadGhost.BP_DeadGhost_C.SetUpHaunt
	void PerceptionLoop(); // Function BP_DeadGhost.BP_DeadGhost_C.PerceptionLoop
	void SpawnColdSpotVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.SpawnColdSpotVFX
	void Server_SpawnColdSpotVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_SpawnColdSpotVFX
	void MC_SpawnColdSpotVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_SpawnColdSpotVFX
	void Server_SpawnHealthOrb(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_SpawnHealthOrb
	void NR_SpawnChillVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.NR_SpawnChillVFX
	void Server_SpawnChillVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_SpawnChillVFX
	void MC_SpawnChillVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_SpawnChillVFX
	void Server Shove Hunters(struct ABP_Hunter_C* Hunter); // Function BP_DeadGhost.BP_DeadGhost_C.Server Shove Hunters
	void NR_SpawnShoveVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.NR_SpawnShoveVFX
	void Server_ShoveVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_ShoveVFX
	void MC_ShoveVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_ShoveVFX
	void SpawnHallucinate(); // Function BP_DeadGhost.BP_DeadGhost_C.SpawnHallucinate
	void Server_SpawnHallucinate(int32_t SoundID); // Function BP_DeadGhost.BP_DeadGhost_C.Server_SpawnHallucinate
	void MC_SpawnHallucinate(int32_t SoundID); // Function BP_DeadGhost.BP_DeadGhost_C.MC_SpawnHallucinate
	void MakeVisibile(); // Function BP_DeadGhost.BP_DeadGhost_C.MakeVisibile
	void MC_RecheckNametags(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_RecheckNametags
	void FalseTrailVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.FalseTrailVFX
	void MC_FalseTrailVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_FalseTrailVFX
	void Server_FalseTrailVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_FalseTrailVFX
	void PushObjectVFX(struct ALvlProp_C* LvlProp); // Function BP_DeadGhost.BP_DeadGhost_C.PushObjectVFX
	void MC_PushObjectVFX(struct ALvlProp_C* Lvl Prop); // Function BP_DeadGhost.BP_DeadGhost_C.MC_PushObjectVFX
	void Server_PushObjectVFX(struct ALvlProp_C* Lvl Prop); // Function BP_DeadGhost.BP_DeadGhost_C.Server_PushObjectVFX
	void MC_ShoveHunter_VFX(struct ABP_Hunter_C* Hunter); // Function BP_DeadGhost.BP_DeadGhost_C.MC_ShoveHunter_VFX
	void MediumVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.MediumVFX
	void Server_MediumVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_MediumVFX
	void MC_MediumVFX(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_MediumVFX
	void PushObject_ForceSelectLvlprop(bool LookingAtLVLProp?, struct ALvlProp_C* LvlProp); // Function BP_DeadGhost.BP_DeadGhost_C.PushObject_ForceSelectLvlprop
	void StartEmote(); // Function BP_DeadGhost.BP_DeadGhost_C.StartEmote
	void Server_StartEmote(char Hunter_Emotes Emote To Play); // Function BP_DeadGhost.BP_DeadGhost_C.Server_StartEmote
	void MC_StartEmote(char Hunter_Emotes Emote To Play); // Function BP_DeadGhost.BP_DeadGhost_C.MC_StartEmote
	void InterruptEmote(); // Function BP_DeadGhost.BP_DeadGhost_C.InterruptEmote
	void Server_InterruptEmote(); // Function BP_DeadGhost.BP_DeadGhost_C.Server_InterruptEmote
	void MC_InterruptEmote(); // Function BP_DeadGhost.BP_DeadGhost_C.MC_InterruptEmote
	void HauntPushTicker_Int(); // Function BP_DeadGhost.BP_DeadGhost_C.HauntPushTicker_Int
	void EndMediumPhase_Int(); // Function BP_DeadGhost.BP_DeadGhost_C.EndMediumPhase_Int
	void ForceSpawnHealthOrb(struct FTransform SpawnTransform); // Function BP_DeadGhost.BP_DeadGhost_C.ForceSpawnHealthOrb
	void K2_OnMovementModeChanged(char EMovementMode PrevMovementMode, char EMovementMode NewMovementMode, char PrevCustomMode, char NewCustomMode); // Function BP_DeadGhost.BP_DeadGhost_C.K2_OnMovementModeChanged
	void StopVault(); // Function BP_DeadGhost.BP_DeadGhost_C.StopVault
	void ExecuteUbergraph_BP_DeadGhost(int32_t EntryPoint); // Function BP_DeadGhost.BP_DeadGhost_C.ExecuteUbergraph_BP_DeadGhost
}; 



