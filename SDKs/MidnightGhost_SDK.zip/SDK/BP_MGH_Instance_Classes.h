#pragma once 
#include <BP_MGH_Instance_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MGH_Instance.BP_MGH_Instance_C
// Size: 0x28F0(Inherited: 0x28A8) 
struct UBP_MGH_Instance_C : public UMGH_GameInstance_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28A8(0x8)
	char pad_10416_1 : 7;  // 0x28B0(0x1)
	bool bShowMouse : 1;  // 0x28B0(0x1)
	uint8_t  InputType;  // 0x28B1(0x1)
	char pad_10418_1 : 7;  // 0x28B2(0x1)
	bool bPauseMenuActive : 1;  // 0x28B2(0x1)
	char pad_10419[5];  // 0x28B3(0x5)
	struct UWB_PauseMenu_C* WB_PauseMenu;  // 0x28B8(0x8)
	struct UObject* PlayerCharacter;  // 0x28C0(0x8)
	char pad_10440_1 : 7;  // 0x28C8(0x1)
	bool bUseBaseColor : 1;  // 0x28C8(0x1)
	char pad_10441[3];  // 0x28C9(0x3)
	struct FLinearColor BaseColor;  // 0x28CC(0x10)
	char pad_10460_1 : 7;  // 0x28DC(0x1)
	bool bUseButtonSounds : 1;  // 0x28DC(0x1)
	char pad_10461[3];  // 0x28DD(0x3)
	struct USoundBase* ButtonSound_Hovered;  // 0x28E0(0x8)
	struct USoundBase* ButtonSound_Clicked;  // 0x28E8(0x8)

	void GetInputType_Int(uint8_t & Type); // Function BP_MGH_Instance.BP_MGH_Instance_C.GetInputType_Int
	void FindGradations(struct FLinearColor In Color, struct FLinearColor& 01, struct FLinearColor& 02, struct FLinearColor& 03, struct FLinearColor& 04); // Function BP_MGH_Instance.BP_MGH_Instance_C.FindGradations
	void FindPawnOrCharacter(struct UObject* Object, struct ACharacter*& AsCharacter, struct APawn*& AsPawn); // Function BP_MGH_Instance.BP_MGH_Instance_C.FindPawnOrCharacter
	void SetInputType(uint8_t  InputType); // Function BP_MGH_Instance.BP_MGH_Instance_C.SetInputType
	void ReceiveInit(); // Function BP_MGH_Instance.BP_MGH_Instance_C.ReceiveInit
	void HandleTravelError(char ETravelFailure FailureType); // Function BP_MGH_Instance.BP_MGH_Instance_C.HandleTravelError
	void HandleNetworkError(char ENetworkFailure FailureType, bool bIsServer); // Function BP_MGH_Instance.BP_MGH_Instance_C.HandleNetworkError
	void HandlePauseMenu(struct UObject* Player Character or Pawn); // Function BP_MGH_Instance.BP_MGH_Instance_C.HandlePauseMenu
	void ReceiveShutdown(); // Function BP_MGH_Instance.BP_MGH_Instance_C.ReceiveShutdown
	void SetShowMouse(bool NewShowMouse); // Function BP_MGH_Instance.BP_MGH_Instance_C.SetShowMouse
	void UpdateBaseColor(); // Function BP_MGH_Instance.BP_MGH_Instance_C.UpdateBaseColor
	void UpdateButtonSounds(); // Function BP_MGH_Instance.BP_MGH_Instance_C.UpdateButtonSounds
	void Report Log Error(struct FString Category, struct FString Error); // Function BP_MGH_Instance.BP_MGH_Instance_C.Report Log Error
	void SetInputType_Int(uint8_t  Input); // Function BP_MGH_Instance.BP_MGH_Instance_C.SetInputType_Int
	void UpdateBaseColor_Int_2(); // Function BP_MGH_Instance.BP_MGH_Instance_C.UpdateBaseColor_Int_2
	void CustomEvent(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent
	void CustomEvent_2(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent_2
	void CustomEvent_3(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent_3
	void CustomEvent_4(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent_4
	void CustomEvent_5(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent_5
	void CustomEvent_6(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent_6
	void CustomEvent_7(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent_7
	void CustomEvent_8(); // Function BP_MGH_Instance.BP_MGH_Instance_C.CustomEvent_8
	void ExecuteUbergraph_BP_MGH_Instance(int32_t EntryPoint); // Function BP_MGH_Instance.BP_MGH_Instance_C.ExecuteUbergraph_BP_MGH_Instance
}; 



