#pragma once 
#include <Ai_GetRandomHunter_Structs.h>
 
 
 
// BlueprintGeneratedClass Ai_GetRandomHunter.Ai_GetRandomHunter_C
// Size: 0xD8(Inherited: 0xA8) 
struct UAi_GetRandomHunter_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector OutHunter;  // 0xB0(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Ai_GetRandomHunter.Ai_GetRandomHunter_C.ReceiveExecuteAI
	void ExecuteUbergraph_Ai_GetRandomHunter(int32_t EntryPoint); // Function Ai_GetRandomHunter.Ai_GetRandomHunter_C.ExecuteUbergraph_Ai_GetRandomHunter
}; 



