#pragma once 
#include "SDK.h" 
 
 
// Function Ai_IsGhostClose.Ai_IsGhostClose_C.PerformConditionCheckAI
// Size: 0x69(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x18(0x8)
	struct APropMaster* K2Node_DynamicCast_AsProp_Master;  // 0x20(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue_2;  // 0x30(0x8)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x3C(0xC)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x48(0x8)
	struct AMGH_GameMode_C* K2Node_DynamicCast_AsMGH_Game_Mode;  // 0x50(0x8)
	char pad_95_1 : 7;  // 0x5F(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	struct APropMaster* CallFunc_GetClosestAliveGhost_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x68(0x1)

}; 
