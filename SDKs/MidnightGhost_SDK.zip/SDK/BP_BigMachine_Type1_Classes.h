#pragma once 
#include <BP_BigMachine_Type1_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BigMachine_Type1.BP_BigMachine_Type1_C
// Size: 0x321(Inherited: 0x220) 
struct ABP_BigMachine_Type1_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* SM_CollisionCylinder1;  // 0x228(0x8)
	struct UStaticMeshComponent* CollisionCube;  // 0x230(0x8)
	struct UStaticMeshComponent* SM_CollisionCylinder;  // 0x238(0x8)
	struct USkeletalMeshComponent* SkeletalMesh_PressWeight;  // 0x240(0x8)
	struct UParticleSystemComponent* P_ImpactSteam1;  // 0x248(0x8)
	struct UParticleSystemComponent* P_ImpactTile;  // 0x250(0x8)
	struct UBoxComponent* HammerDamage;  // 0x258(0x8)
	struct UParticleSystemComponent* P_ImpactSteam;  // 0x260(0x8)
	struct UStaticMeshComponent* SM_ventwheel_No2_BigMachine1;  // 0x268(0x8)
	struct UStaticMeshComponent* SM_smallPipes_BigMachine;  // 0x270(0x8)
	struct UStaticMeshComponent* SM_InstrumentPanel_BigMachine;  // 0x278(0x8)
	struct UStaticMeshComponent* SM_ButtonBigMachine;  // 0x280(0x8)
	struct UStaticMeshComponent* SM_ventwheel_No2_BigMachine;  // 0x288(0x8)
	struct UStaticMeshComponent* SM_Lights_BigMachine;  // 0x290(0x8)
	struct UStaticMeshComponent* SM_cogWheel2;  // 0x298(0x8)
	struct UStaticMeshComponent* SM_cogWheel;  // 0x2A0(0x8)
	struct UStaticMeshComponent* BaseMachine;  // 0x2A8(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2B0(0x8)
	float Timeline_1_ReduceSpeed_1C20C2D54BF921A6D010C1B37D2363D0;  // 0x2B8(0x4)
	char ETimelineDirection Timeline_1__Direction_1C20C2D54BF921A6D010C1B37D2363D0;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct UTimelineComponent* Timeline_2;  // 0x2C0(0x8)
	float Timeline_0_CogMovement_6635C38A463C12C4AFF353B6C47BA933;  // 0x2C8(0x4)
	char ETimelineDirection Timeline_0__Direction_6635C38A463C12C4AFF353B6C47BA933;  // 0x2CC(0x1)
	char pad_717[3];  // 0x2CD(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x2D0(0x8)
	struct UMaterialInstanceDynamic* DMI_LightLamps;  // 0x2D8(0x8)
	float LightStrength;  // 0x2E0(0x4)
	char pad_740[4];  // 0x2E4(0x4)
	struct UMaterialInstanceDynamic* DMI_InstrumentLight;  // 0x2E8(0x8)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool HammerActive? : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct AActor* ResponsibleActor;  // 0x2F8(0x8)
	struct AController* Responsible Controller;  // 0x300(0x8)
	struct UMaterialInstanceDynamic* DMI_Cog1;  // 0x308(0x8)
	struct UMaterialInstanceDynamic* DMI_Cog2;  // 0x310(0x8)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool HammerCanDamage? : 1;  // 0x318(0x1)
	char pad_793[3];  // 0x319(0x3)
	float CurrentAngle;  // 0x31C(0x4)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool Stopped : 1;  // 0x320(0x1)

	void TriggerCameraShakes(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.TriggerCameraShakes
	void Timeline_0__FinishedFunc(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.Timeline_0__UpdateFunc
	void Timeline_1__FinishedFunc(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.Timeline_1__FinishedFunc
	void Timeline_1__UpdateFunc(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.Timeline_1__UpdateFunc
	void OnNotifyEnd_67E18769446B4C9EE1D7A4B8123D802D(struct FName NotifyName); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnNotifyEnd_67E18769446B4C9EE1D7A4B8123D802D
	void OnNotifyBegin_67E18769446B4C9EE1D7A4B8123D802D(struct FName NotifyName); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnNotifyBegin_67E18769446B4C9EE1D7A4B8123D802D
	void OnInterrupted_67E18769446B4C9EE1D7A4B8123D802D(struct FName NotifyName); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnInterrupted_67E18769446B4C9EE1D7A4B8123D802D
	void OnBlendOut_67E18769446B4C9EE1D7A4B8123D802D(struct FName NotifyName); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnBlendOut_67E18769446B4C9EE1D7A4B8123D802D
	void OnCompleted_67E18769446B4C9EE1D7A4B8123D802D(struct FName NotifyName); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.OnCompleted_67E18769446B4C9EE1D7A4B8123D802D
	void PressGoingDown(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.PressGoingDown
	void ReceiveBeginPlay(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.ReceiveBeginPlay
	void BeginHammer(struct AActor* ResponsibleActor); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.BeginHammer
	void Server_BeginHammer(struct AActor* ResponsibleActor); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.Server_BeginHammer
	void MC_BeginHammer(bool Active); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.MC_BeginHammer
	void HammerHit(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.HammerHit
	void BndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.BndEvt__HammerDamage_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void Server_Reset(); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.Server_Reset
	void ExecuteUbergraph_BP_BigMachine_Type1(int32_t EntryPoint); // Function BP_BigMachine_Type1.BP_BigMachine_Type1_C.ExecuteUbergraph_BP_BigMachine_Type1
}; 



