#pragma once 
#include <BP_C4Actor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_C4Actor.BP_C4Actor_C
// Size: 0x2F5(Inherited: 0x220) 
struct ABP_C4Actor_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* HitBox;  // 0x228(0x8)
	struct UWidgetComponent* C4Indicator;  // 0x230(0x8)
	struct UPointLightComponent* DefaultLight;  // 0x238(0x8)
	struct UPointLightComponent* ExplodeWarningLight;  // 0x240(0x8)
	struct UBoxComponent* Box;  // 0x248(0x8)
	struct UStaticMeshComponent* C4Only;  // 0x250(0x8)
	float InterpTo_Lerp_84F0AA68432F94FD6B6C7086531C9692;  // 0x258(0x4)
	char ETimelineDirection InterpTo__Direction_84F0AA68432F94FD6B6C7086531C9692;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct UTimelineComponent* InterpTo;  // 0x260(0x8)
	float Interp2Rotation_Lerp_487CCC7B49B4E0910DF2908BFA5A9314;  // 0x268(0x4)
	char ETimelineDirection Interp2Rotation__Direction_487CCC7B49B4E0910DF2908BFA5A9314;  // 0x26C(0x1)
	char pad_621[3];  // 0x26D(0x3)
	struct UTimelineComponent* Interp2Rotation;  // 0x270(0x8)
	float ReadyToDetonate_Light_A11BBE8F4DB697DC1A3800A0FFBB8F07;  // 0x278(0x4)
	char ETimelineDirection ReadyToDetonate__Direction_A11BBE8F4DB697DC1A3800A0FFBB8F07;  // 0x27C(0x1)
	char pad_637[3];  // 0x27D(0x3)
	struct UTimelineComponent* ReadyToDetonate;  // 0x280(0x8)
	float ExplodeFlash_Light_3F8FA0ED4220504D4BA9A2B656E7DC09;  // 0x288(0x4)
	char ETimelineDirection ExplodeFlash__Direction_3F8FA0ED4220504D4BA9A2B656E7DC09;  // 0x28C(0x1)
	char pad_653[3];  // 0x28D(0x3)
	struct UTimelineComponent* ExplodeFlash;  // 0x290(0x8)
	float Interp_Float_471112FE4A8C5C48690609B89F958844;  // 0x298(0x4)
	char ETimelineDirection Interp__Direction_471112FE4A8C5C48690609B89F958844;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct UTimelineComponent* Interp;  // 0x2A0(0x8)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool Fall : 1;  // 0x2A8(0x1)
	char pad_681[7];  // 0x2A9(0x7)
	struct UProjectileMovementComponent* Projectile;  // 0x2B0(0x8)
	struct ABP_Hunter_C* MyHunter;  // 0x2B8(0x8)
	struct UMaterialInstanceDynamic* FPMtl;  // 0x2C0(0x8)
	struct AProp_C* AttachedToProp;  // 0x2C8(0x8)
	struct ABP_C4Interact_C* MyInteract;  // 0x2D0(0x8)
	struct FRotator OrigRotation;  // 0x2D8(0xC)
	struct FVector StartLoc;  // 0x2E4(0xC)
	int32_t C4Health;  // 0x2F0(0x4)
	char pad_756_1 : 7;  // 0x2F4(0x1)
	bool Destroyed : 1;  // 0x2F4(0x1)

	void GetProjectileOwner(struct ABP_Hunter_C*& Hunter); // Function BP_C4Actor.BP_C4Actor_C.GetProjectileOwner
	void Interp__FinishedFunc(); // Function BP_C4Actor.BP_C4Actor_C.Interp__FinishedFunc
	void Interp__UpdateFunc(); // Function BP_C4Actor.BP_C4Actor_C.Interp__UpdateFunc
	void ExplodeFlash__FinishedFunc(); // Function BP_C4Actor.BP_C4Actor_C.ExplodeFlash__FinishedFunc
	void ExplodeFlash__UpdateFunc(); // Function BP_C4Actor.BP_C4Actor_C.ExplodeFlash__UpdateFunc
	void ReadyToDetonate__FinishedFunc(); // Function BP_C4Actor.BP_C4Actor_C.ReadyToDetonate__FinishedFunc
	void ReadyToDetonate__UpdateFunc(); // Function BP_C4Actor.BP_C4Actor_C.ReadyToDetonate__UpdateFunc
	void Interp2Rotation__FinishedFunc(); // Function BP_C4Actor.BP_C4Actor_C.Interp2Rotation__FinishedFunc
	void Interp2Rotation__UpdateFunc(); // Function BP_C4Actor.BP_C4Actor_C.Interp2Rotation__UpdateFunc
	void InterpTo__FinishedFunc(); // Function BP_C4Actor.BP_C4Actor_C.InterpTo__FinishedFunc
	void InterpTo__UpdateFunc(); // Function BP_C4Actor.BP_C4Actor_C.InterpTo__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_C4Actor.BP_C4Actor_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_C4Actor.BP_C4Actor_C.ReceiveTick
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_C4Actor.BP_C4Actor_C.ReceiveHit
	void Server_Detonate(); // Function BP_C4Actor.BP_C4Actor_C.Server_Detonate
	void Server_AttachToProp(struct AProp_C* Prop, struct FVector_NetQuantize Offset, bool Delay); // Function BP_C4Actor.BP_C4Actor_C.Server_AttachToProp
	void MC_AttachToProp(struct AProp_C* Prop, struct FVector_NetQuantize Offset); // Function BP_C4Actor.BP_C4Actor_C.MC_AttachToProp
	void Server_AttachToLvlprop(struct ALvlProp_C* LvlProp, struct FVector_NetQuantize Offset); // Function BP_C4Actor.BP_C4Actor_C.Server_AttachToLvlprop
	void MC_AttachToLvlprop(struct ALvlProp_C* LvlProp, struct FVector_NetQuantize Offset); // Function BP_C4Actor.BP_C4Actor_C.MC_AttachToLvlprop
	void MC_DetonateLight(); // Function BP_C4Actor.BP_C4Actor_C.MC_DetonateLight
	void Server_PickUpC4(struct AMGH_PlayerController_BP_C* Controller); // Function BP_C4Actor.BP_C4Actor_C.Server_PickUpC4
	void PickUpC4(struct AMGH_PlayerController_BP_C* Controller); // Function BP_C4Actor.BP_C4Actor_C.PickUpC4
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_C4Actor.BP_C4Actor_C.ReceiveEndPlay
	void MC_PlaceLight(); // Function BP_C4Actor.BP_C4Actor_C.MC_PlaceLight
	void InterpToRotation(struct FRotator Rotator); // Function BP_C4Actor.BP_C4Actor_C.InterpToRotation
	void Server_InterpToLocation(struct FVector_NetQuantize Location); // Function BP_C4Actor.BP_C4Actor_C.Server_InterpToLocation
	void MC_InterpToLocation(struct FVector_NetQuantize Location); // Function BP_C4Actor.BP_C4Actor_C.MC_InterpToLocation
	void CheckWidgetVisibility(); // Function BP_C4Actor.BP_C4Actor_C.CheckWidgetVisibility
	void Server_DamageC4(int32_t Damage); // Function BP_C4Actor.BP_C4Actor_C.Server_DamageC4
	void SetSeeThroughWalls(bool See?); // Function BP_C4Actor.BP_C4Actor_C.SetSeeThroughWalls
	void ExecuteUbergraph_BP_C4Actor(int32_t EntryPoint); // Function BP_C4Actor.BP_C4Actor_C.ExecuteUbergraph_BP_C4Actor
}; 



