#pragma once 
#include "SDK.h" 
 
 
// Function BaseControls_UI.BaseControls_UI_C.ExecuteUbergraph_BaseControls_UI
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_BaseControls_UI
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x18(0x8)

}; 
