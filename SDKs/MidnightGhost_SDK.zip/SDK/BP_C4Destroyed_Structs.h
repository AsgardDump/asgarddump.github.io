#pragma once 
#include "SDK.h" 
 
 
// Function BP_C4Destroyed.BP_C4Destroyed_C.ExecuteUbergraph_BP_C4Destroyed
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_C4Destroyed
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)

}; 
