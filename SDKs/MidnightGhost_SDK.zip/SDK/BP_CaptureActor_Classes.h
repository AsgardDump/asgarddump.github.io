#pragma once 
#include <BP_CaptureActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CaptureActor.BP_CaptureActor_C
// Size: 0x298(Inherited: 0x220) 
struct ABP_CaptureActor_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USkeletalMeshComponent* Lashe;  // 0x228(0x8)
	struct USkeletalMeshComponent* NBACKPACK;  // 0x230(0x8)
	struct USkeletalMeshComponent* Eyes;  // 0x238(0x8)
	struct USkeletalMeshComponent* Head;  // 0x240(0x8)
	struct UPointLightComponent* PointLight3;  // 0x248(0x8)
	struct UPointLightComponent* PointLight2;  // 0x250(0x8)
	struct USpotLightComponent* SpotLight;  // 0x258(0x8)
	struct UPointLightComponent* PointLight;  // 0x260(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x268(0x8)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D;  // 0x270(0x8)
	struct UCameraComponent* Camera;  // 0x278(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x280(0x8)
	float FOV_Anim_FOV_2E9F08174AFC9D8AB650BA99D945E3D4;  // 0x288(0x4)
	char ETimelineDirection FOV_Anim__Direction_2E9F08174AFC9D8AB650BA99D945E3D4;  // 0x28C(0x1)
	char pad_653[3];  // 0x28D(0x3)
	struct UTimelineComponent* FOV_Anim;  // 0x290(0x8)

	void FOV_Anim__FinishedFunc(); // Function BP_CaptureActor.BP_CaptureActor_C.FOV_Anim__FinishedFunc
	void FOV_Anim__UpdateFunc(); // Function BP_CaptureActor.BP_CaptureActor_C.FOV_Anim__UpdateFunc
	void UpdateCaptureCharacter(bool bActive); // Function BP_CaptureActor.BP_CaptureActor_C.UpdateCaptureCharacter
	void ExecuteUbergraph_BP_CaptureActor(int32_t EntryPoint); // Function BP_CaptureActor.BP_CaptureActor_C.ExecuteUbergraph_BP_CaptureActor
}; 



