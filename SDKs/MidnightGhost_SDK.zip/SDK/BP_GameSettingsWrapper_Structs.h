#pragma once 
#include "SDK.h" 
 
 
// Function BP_GameSettingsWrapper.BP_GameSettingsWrapper_C.ExecuteUbergraph_BP_GameSettingsWrapper
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GameSettingsWrapper
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
