#pragma once 
#include "SDK.h" 
 
 
// Function BP_InfectionGhostDeath.BP_InfectionGhostDeath_C.ExecuteUbergraph_BP_InfectionGhostDeath
// Size: 0xD(Inherited: 0x0) 
struct FExecuteUbergraph_BP_InfectionGhostDeath
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0xC(0x1)

}; 
// Function BP_InfectionGhostDeath.BP_InfectionGhostDeath_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
