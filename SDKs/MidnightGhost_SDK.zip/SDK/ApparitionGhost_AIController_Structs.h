#pragma once 
#include "SDK.h" 
 
 
// Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.OnFail_6E4EC364475E0CE6EF1CCC93D5491BE1
// Size: 0x1(Inherited: 0x0) 
struct FOnFail_6E4EC364475E0CE6EF1CCC93D5491BE1
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
// Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.ExecuteUbergraph_ApparitionGhost_AIController
// Size: 0xDC(Inherited: 0x0) 
struct FExecuteUbergraph_ApparitionGhost_AIController
{
	int32_t EntryPoint;  // 0x0(0x4)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult_2;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	char EPathFollowingResult K2Node_CustomEvent_MovementResult;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1C(0x10)
	char EPathFollowingResult Temp_byte_Variable;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x30(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_K2_GetRandomPointInNavigableRadius_RandomLocation;  // 0x44(0xC)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_K2_GetRandomPointInNavigableRadius_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UAIAsyncTaskBlueprintProxy* CallFunc_CreateMoveToProxyObject_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x68(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x70(0xC)
	float CallFunc_VSizeXY_ReturnValue;  // 0x7C(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_3;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_4;  // 0x90(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x98(0x4)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x9C(0xC)
	float CallFunc_BreakRotator_Roll;  // 0xA8(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0xAC(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xB0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xB4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xB8(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xC4(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xD0(0xC)

}; 
// Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.OnSuccess_6E4EC364475E0CE6EF1CCC93D5491BE1
// Size: 0x1(Inherited: 0x0) 
struct FOnSuccess_6E4EC364475E0CE6EF1CCC93D5491BE1
{
	char EPathFollowingResult MovementResult;  // 0x0(0x1)

}; 
// Function ApparitionGhost_AIController.ApparitionGhost_AIController_C.SetUpNavmeshHolder
// Size: 0x12(Inherited: 0x0) 
struct FSetUpNavmeshHolder
{
	struct AMGH_WorldSettings* CallFunc_GetWorldSettings_ReturnValue;  // 0x0(0x8)
	struct APropXFormHolder_C* K2Node_DynamicCast_AsProp_XForm_Holder;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)

}; 
