#pragma once 
#include <ABP_Cannon_Pirate_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Cannon_Pirate.ABP_Cannon_Pirate_C
// Size: 0x984(Inherited: 0x2C0) 
struct UABP_Cannon_Pirate_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;  // 0x2F8(0x50)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x348(0x48)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x390(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x498(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x4B8(0x20)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x4D8(0x50)
	struct FAnimNode_ApplyMeshSpaceAdditive AnimGraphNode_ApplyMeshSpaceAdditive;  // 0x528(0xD0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x5F8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x700(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x808(0x108)
	struct AProp_Cannon_C* MyPropCannonBP;  // 0x910(0x8)
	struct FVector FR_LastFrame;  // 0x918(0xC)
	struct FVector FL_LastFrame;  // 0x924(0xC)
	struct FVector BR_LastFrame;  // 0x930(0xC)
	struct FVector BL_LastFrame;  // 0x93C(0xC)
	struct FRotator FR_rot;  // 0x948(0xC)
	struct FRotator FL_Rot;  // 0x954(0xC)
	struct FRotator BR_Rot;  // 0x960(0xC)
	struct FRotator BL_Rot;  // 0x96C(0xC)
	float OnGroundMultiply;  // 0x978(0x4)
	float Delta Time X;  // 0x97C(0x4)
	float WalkAnimProg;  // 0x980(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Cannon_Pirate.ABP_Cannon_Pirate_C.AnimGraph
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Cannon_Pirate.ABP_Cannon_Pirate_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_Cannon_Pirate(int32_t EntryPoint); // Function ABP_Cannon_Pirate.ABP_Cannon_Pirate_C.ExecuteUbergraph_ABP_Cannon_Pirate
}; 



