#pragma once 
#include <BestTeam_Prop_Structs.h>
 
 
 
// BlueprintGeneratedClass BestTeam_Prop.BestTeam_Prop_C
// Size: 0x634(Inherited: 0x4C0) 
struct ABestTeam_Prop_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UWidgetComponent* BestTeam_Nameplate;  // 0x4C8(0x8)
	struct UBoxComponent* Gate-DoorBlocker;  // 0x4D0(0x8)
	struct UBoxComponent* Gate-RagdollCollision;  // 0x4D8(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x4E0(0x8)
	struct UTextRenderComponent* RnDTest;  // 0x4E8(0x8)
	struct UStaticMeshComponent* SecondMesh;  // 0x4F0(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x4F8(0x8)
	struct USceneComponent* RotNull_Null;  // 0x500(0x8)
	struct USceneComponent* MeshNull;  // 0x508(0x8)
	struct UStaticMesh* PropMeshInput;  // 0x510(0x8)
	AProp_C* PropClass;  // 0x518(0x8)
	struct FTransform PropMesh_RelativeXForm;  // 0x520(0x30)
	struct FTransform RotNull_RelativeXForm;  // 0x550(0x30)
	struct UStaticMesh* PropMeshInput_SecondMesh;  // 0x580(0x8)
	char pad_1416_1 : 7;  // 0x588(0x1)
	bool SecondMesh? : 1;  // 0x588(0x1)
	char pad_1417[7];  // 0x589(0x7)
	struct FTransform 2NDMESH_RelativeWXForm;  // 0x590(0x30)
	struct USceneCaptureComponent2D* MyCamera;  // 0x5C0(0x8)
	char pad_1480_1 : 7;  // 0x5C8(0x1)
	bool Skel Mesh? : 1;  // 0x5C8(0x1)
	char pad_1481[7];  // 0x5C9(0x7)
	UObject* Skel_AnimBP;  // 0x5D0(0x8)
	struct USkeletalMesh* SkelMesh;  // 0x5D8(0x8)
	float BT_CapsuleHalfHeight;  // 0x5E0(0x4)
	float BT_CapsuleRadius;  // 0x5E4(0x4)
	int32_t Player Level;  // 0x5E8(0x4)
	char pad_1516[4];  // 0x5EC(0x4)
	struct AMGH_PlayerState_C* Custom Player State;  // 0x5F0(0x8)
	char pad_1528[8];  // 0x5F8(0x8)
	struct FTransform Nameplate_RelativeXForm;  // 0x600(0x30)
	float Nameplate_RelativeZ;  // 0x630(0x4)

	void DetermineSkelMesh(bool& Found?, struct USkeletalMesh*& Skel Mesh, UObject*& AnimBP); // Function BestTeam_Prop.BestTeam_Prop_C.DetermineSkelMesh
	void UserConstructionScript(); // Function BestTeam_Prop.BestTeam_Prop_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BestTeam_Prop.BestTeam_Prop_C.ReceiveBeginPlay
	void ExecuteUbergraph_BestTeam_Prop(int32_t EntryPoint); // Function BestTeam_Prop.BestTeam_Prop_C.ExecuteUbergraph_BestTeam_Prop
}; 



