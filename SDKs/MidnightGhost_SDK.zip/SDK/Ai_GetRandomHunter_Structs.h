#pragma once 
#include "SDK.h" 
 
 
// Function Ai_GetRandomHunter.Ai_GetRandomHunter_C.ExecuteUbergraph_Ai_GetRandomHunter
// Size: 0x31(Inherited: 0x0) 
struct FExecuteUbergraph_Ai_GetRandomHunter
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct AMGH_AiController_BP_C* K2Node_DynamicCast_AsMGH_Ai_Controller_BP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ABP_Hunter_C* CallFunc_GetRandomAliveHunter_BPHunter;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function Ai_GetRandomHunter.Ai_GetRandomHunter_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
