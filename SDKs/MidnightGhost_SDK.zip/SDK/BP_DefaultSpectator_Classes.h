#pragma once 
#include <BP_DefaultSpectator_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DefaultSpectator.BP_DefaultSpectator_C
// Size: 0x500(Inherited: 0x4C0) 
struct ABP_DefaultSpectator_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UCameraComponent* Camera;  // 0x4C8(0x8)
	char Spectator_Form My_SpectatorForm;  // 0x4D0(0x1)
	char HunterSpec MySelected_HS;  // 0x4D1(0x1)
	char Spectator_Form My_ProposedTeam ;  // 0x4D2(0x1)
	char pad_1235_1 : 7;  // 0x4D3(0x1)
	bool InterpingToProp? : 1;  // 0x4D3(0x1)
	char pad_1236_1 : 7;  // 0x4D4(0x1)
	bool SpectateCameraMode : 1;  // 0x4D4(0x1)
	char GhostAbility MySelected_GS;  // 0x4D5(0x1)
	char pad_1238[2];  // 0x4D6(0x2)
	struct ABP_Hunter_C* C_TLooked_Hunter;  // 0x4D8(0x8)
	struct ABP_Hunter_C* C_TSelected_Hunter;  // 0x4E0(0x8)
	char pad_1256_1 : 7;  // 0x4E8(0x1)
	bool Picked Team Yet? : 1;  // 0x4E8(0x1)
	char pad_1257[7];  // 0x4E9(0x7)
	struct FString Player Session ID;  // 0x4F0(0x10)

	void InpActEvt_NumPadZero_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_DefaultSpectator.BP_DefaultSpectator_C.InpActEvt_NumPadZero_K2Node_InputKeyEvent_2
	void InpActEvt_Tab_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_DefaultSpectator.BP_DefaultSpectator_C.InpActEvt_Tab_K2Node_InputKeyEvent_1
	void OC_SpectatorStartup(); // Function BP_DefaultSpectator.BP_DefaultSpectator_C.OC_SpectatorStartup
	void Set_SelectedGhostClass(char GhostAbility SelectedGhostSpec); // Function BP_DefaultSpectator.BP_DefaultSpectator_C.Set_SelectedGhostClass
	void Server_SetMyProposedTeam(char Spectator_Form ProposedTeam); // Function BP_DefaultSpectator.BP_DefaultSpectator_C.Server_SetMyProposedTeam
	void Set_SelectedHunterClass(char HunterSpec SelectedHunterSpec); // Function BP_DefaultSpectator.BP_DefaultSpectator_C.Set_SelectedHunterClass
	void ExecuteUbergraph_BP_DefaultSpectator(int32_t EntryPoint); // Function BP_DefaultSpectator.BP_DefaultSpectator_C.ExecuteUbergraph_BP_DefaultSpectator
}; 



