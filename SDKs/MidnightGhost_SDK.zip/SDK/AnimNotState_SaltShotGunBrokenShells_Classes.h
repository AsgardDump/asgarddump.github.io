#pragma once 
#include <AnimNotState_SaltShotGunBrokenShells_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimNotState_SaltShotGunBrokenShells.AnimNotState_SaltShotGunBrokenShells_C
// Size: 0x30(Inherited: 0x30) 
struct UAnimNotState_SaltShotGunBrokenShells_C : public UAnimNotifyState
{

	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotState_SaltShotGunBrokenShells.AnimNotState_SaltShotGunBrokenShells_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotState_SaltShotGunBrokenShells.AnimNotState_SaltShotGunBrokenShells_C.Received_NotifyBegin
}; 



