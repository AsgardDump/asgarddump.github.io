#pragma once 
#include <BP_ApparitionGhost_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ApparitionGhost.BP_ApparitionGhost_C
// Size: 0x56C(Inherited: 0x4C0) 
struct ABP_ApparitionGhost_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct UAIPerceptionStimuliSourceComponent* AIPerceptionStimuliSource;  // 0x4C8(0x8)
	struct UNiagaraComponent* NS_GhostBody_Lightning;  // 0x4D0(0x8)
	struct UNiagaraComponent* NS_GhostBody_Smoke;  // 0x4D8(0x8)
	struct UNiagaraComponent* NS_GhostBody_Drip;  // 0x4E0(0x8)
	struct UParticleSystemComponent* P_SmokeWisp1-loop;  // 0x4E8(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x4F0(0x8)
	struct UPointLightComponent* PointLight1;  // 0x4F8(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x500(0x8)
	float FadeoutLight_Light_20CAA4324A24EA9DE540D69EE7DB4756;  // 0x508(0x4)
	char ETimelineDirection FadeoutLight__Direction_20CAA4324A24EA9DE540D69EE7DB4756;  // 0x50C(0x1)
	char pad_1293[3];  // 0x50D(0x3)
	struct UTimelineComponent* FadeoutLight;  // 0x510(0x8)
	float GoRed_Percent_858DE8704CB2A0FB59C20AAD531057A1;  // 0x518(0x4)
	char ETimelineDirection GoRed__Direction_858DE8704CB2A0FB59C20AAD531057A1;  // 0x51C(0x1)
	char pad_1309[3];  // 0x51D(0x3)
	struct UTimelineComponent* GoRed;  // 0x520(0x8)
	struct UAudioComponent* SoundLoop;  // 0x528(0x8)
	struct UMaterialInstanceDynamic* GoRedGhostMtl;  // 0x530(0x8)
	char pad_1336_1 : 7;  // 0x538(0x1)
	bool Red? : 1;  // 0x538(0x1)
	char GhostSkins MyOwnersSkin;  // 0x539(0x1)
	char pad_1338[6];  // 0x53A(0x6)
	struct TArray<struct UMaterialInstanceDynamic*> GhostMaterials;  // 0x540(0x10)
	struct TArray<struct FLinearColor> GhostMaterialsStartTint;  // 0x550(0x10)
	struct FVector EctoPlasmaLastPosition;  // 0x560(0xC)

	void EnemyPingable?(char Team My Team, bool& Pingable); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.EnemyPingable?
	void GetEctoBuildup(bool& Prop?, float& Radiation, bool& Sensitive?, bool& Midnight Form?); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.GetEctoBuildup
	void CheckIfGoRed(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.CheckIfGoRed
	void GoRed__FinishedFunc(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.GoRed__FinishedFunc
	void GoRed__UpdateFunc(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.GoRed__UpdateFunc
	void FadeoutLight__FinishedFunc(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.FadeoutLight__FinishedFunc
	void FadeoutLight__UpdateFunc(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.FadeoutLight__UpdateFunc
	void Server_FadeAway(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.Server_FadeAway
	void MC_FadeAway(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.MC_FadeAway
	void ReceiveBeginPlay(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.ReceiveEndPlay
	void MakeGhostRed(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.MakeGhostRed
	void Server_GoRed(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.Server_GoRed
	void MC_GoRed(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.MC_GoRed
	void LightningVFXLoop(); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.LightningVFXLoop
	void NR_SpawnEctoplasmTrail(struct ACharacter* Owner, bool Local); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.NR_SpawnEctoplasmTrail
	void ReceiveTick(float DeltaSeconds); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.ReceiveTick
	void ExecuteUbergraph_BP_ApparitionGhost(int32_t EntryPoint); // Function BP_ApparitionGhost.BP_ApparitionGhost_C.ExecuteUbergraph_BP_ApparitionGhost
}; 



