#pragma once 
#include "SDK.h" 
 
 
// Function AddedGhostShardsElement_UI.AddedGhostShardsElement_UI_C.ExecuteUbergraph_AddedGhostShardsElement_UI
// Size: 0x200(Inherited: 0x0) 
struct FExecuteUbergraph_AddedGhostShardsElement_UI
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_ShardMultiplierCalculation_OutShards;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_ShardMultiplierCalculation_IsMultiplied : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t CallFunc_ShardMultiplierCalculation_Multiplier;  // 0xC(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x10(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x50(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x60(0x18)
	float K2Node_CustomEvent_DelayBeforeStart;  // 0x78(0x4)
	int32_t Temp_int_Variable;  // 0x7C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x80(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x84(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x88(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_2;  // 0xA8(0x8)
	struct UMGH_ProgressionSystem* CallFunc_GetProgressionSubsystem_Int_ProgressionSubsystem;  // 0xB0(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_3;  // 0xB8(0x8)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_2;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct UBP_ProgressionSystem_C* K2Node_DynamicCast_AsBP_Progression_System;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_GetGameOverProgressionInfo_Int_Stored_Level_Up_ : 1;  // 0xE1(0x1)
	char pad_226[2];  // 0xE2(0x2)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Starting_XP;  // 0xE4(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Starting_MAX_XP;  // 0xE8(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Prev_Level;  // 0xEC(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_New_Level;  // 0xF0(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Ending_XP;  // 0xF4(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Ending_MAX_XP;  // 0xF8(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_How_Many_Shards_Added;  // 0xFC(0x4)
	char VictoryType CallFunc_GetGameOverProgressionInfo_Int_Stored_Match_Victory_Type;  // 0x100(0x1)
	char pad_257[3];  // 0x101(0x3)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Added_XP;  // 0x104(0x4)
	int32_t CallFunc_GetCurrentGhostShards_Ghost_Shards;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x110(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x128(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x168(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x178(0x18)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_4;  // 0x190(0x8)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x198(0x18)
	struct TScriptInterface<IMGH_GameInstance_Interface_C> K2Node_DynamicCast_AsMGH_Game_Instance_Interface_3;  // 0x1B0(0x10)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1C0(0x1)
	char pad_449_1 : 7;  // 0x1C1(0x1)
	bool CallFunc_GetGameOverProgressionInfo_Int_Stored_Level_Up__2 : 1;  // 0x1C1(0x1)
	char pad_450[2];  // 0x1C2(0x2)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Starting_XP_2;  // 0x1C4(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Starting_MAX_XP_2;  // 0x1C8(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Prev_Level_2;  // 0x1CC(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_New_Level_2;  // 0x1D0(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Ending_XP_2;  // 0x1D4(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Ending_MAX_XP_2;  // 0x1D8(0x4)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_How_Many_Shards_Added_2;  // 0x1DC(0x4)
	char VictoryType CallFunc_GetGameOverProgressionInfo_Int_Stored_Match_Victory_Type_2;  // 0x1E0(0x1)
	char pad_481[3];  // 0x1E1(0x3)
	int32_t CallFunc_GetGameOverProgressionInfo_Int_Stored_Added_XP_2;  // 0x1E4(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x1E8(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x1EC(0x4)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x1F0(0x1)
	char pad_497[7];  // 0x1F1(0x7)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x1F8(0x8)

}; 
// Function AddedGhostShardsElement_UI.AddedGhostShardsElement_UI_C.Get_CanvasPanel_0_ToolTipWidget_1
// Size: 0x10(Inherited: 0x0) 
struct FGet_CanvasPanel_0_ToolTipWidget_1
{
	struct UWidget* ReturnValue;  // 0x0(0x8)
	struct UCategoryTooltip_v02_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)

}; 
// Function AddedGhostShardsElement_UI.AddedGhostShardsElement_UI_C.LoadGhostShards
// Size: 0x4(Inherited: 0x0) 
struct FLoadGhostShards
{
	float DelayBeforeStart;  // 0x0(0x4)

}; 
