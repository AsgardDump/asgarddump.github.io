#pragma once 
#include <Chonk_EnemyMortar_PrimaryDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_EnemyMortar_PrimaryDamage.Chonk_EnemyMortar_PrimaryDamage_C
// Size: 0x818(Inherited: 0x818) 
struct UChonk_EnemyMortar_PrimaryDamage_C : public UORGameplayEffect
{

}; 



