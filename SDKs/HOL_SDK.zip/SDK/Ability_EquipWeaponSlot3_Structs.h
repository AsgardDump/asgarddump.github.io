#pragma once 
#include "SDK.h" 
 
 
// Function Ability_EquipWeaponSlot3.Ability_EquipWeaponSlot3_C.ExecuteUbergraph_Ability_EquipWeaponSlot3
// Size: 0x16(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_EquipWeaponSlot3
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AORCharacter* CallFunc_GetOwningCharacter_Character;  // 0x8(0x8)
	struct FGameplayAbilitySpecHandle CallFunc_ActivateAbility_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x15(0x1)

}; 
// Function Ability_EquipWeaponSlot3.Ability_EquipWeaponSlot3_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
