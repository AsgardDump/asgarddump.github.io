#pragma once 
#include "SDK.h" 
 
 
// Function AltReload_FireLoop_BP.AltReload_FireLoop_BP_C.CanFire
// Size: 0x15(Inherited: 0x1) 
struct FCanFire : public FCanFire
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_CanFire_ReturnValue : 1;  // 0x1(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct APlayerCharacter_BP_C* CallFunc_GetORPlayer_PlayerCharacter;  // 0x8(0x8)
	int32_t CallFunc_GetCurrencyCount_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x14(0x1)

}; 
