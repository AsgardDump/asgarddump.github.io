#pragma once 
#include <BTT_LogValues_Structs.h>
 
 
 
// BlueprintGeneratedClass BTT_LogValues.BTT_LogValues_C
// Size: 0xE9(Inherited: 0xA8) 
struct UBTT_LogValues_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector ValueToPrint;  // 0xB0(0x28)
	struct FString Label;  // 0xD8(0x10)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool PrintToScreen : 1;  // 0xE8(0x1)

	void ReceiveExecute(struct AActor* OwnerActor); // Function BTT_LogValues.BTT_LogValues_C.ReceiveExecute
	void ExecuteUbergraph_BTT_LogValues(int32_t EntryPoint); // Function BTT_LogValues.BTT_LogValues_C.ExecuteUbergraph_BTT_LogValues
}; 



