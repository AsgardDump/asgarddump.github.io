#pragma once 
#include <ArmorPlatedMyte_RemovePlate_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ArmorPlatedMyte_RemovePlate_GA.ArmorPlatedMyte_RemovePlate_GA_C
// Size: 0x400(Inherited: 0x3F8) 
struct UArmorPlatedMyte_RemovePlate_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)

	void K2_ActivateAbility(); // Function ArmorPlatedMyte_RemovePlate_GA.ArmorPlatedMyte_RemovePlate_GA_C.K2_ActivateAbility
	void ExecuteUbergraph_ArmorPlatedMyte_RemovePlate_GA(int32_t EntryPoint); // Function ArmorPlatedMyte_RemovePlate_GA.ArmorPlatedMyte_RemovePlate_GA_C.ExecuteUbergraph_ArmorPlatedMyte_RemovePlate_GA
}; 



