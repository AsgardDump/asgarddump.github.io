#pragma once 
#include "SDK.h" 
 
 
// Function BlimNPCV2_ABP.BlimNPCV2_ABP_C.ExecuteUbergraph_BlimNPCV2_ABP
// Size: 0x106(Inherited: 0x0) 
struct FExecuteUbergraph_BlimNPCV2_ABP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* K2Node_Event_Killer;  // 0x8(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0x10(0x90)
	struct FGameplayTagContainer K2Node_Event_DamageTags;  // 0xA0(0x20)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC1(0x1)
	char pad_194[2];  // 0xC2(0x2)
	float CallFunc_Montage_Play_ReturnValue;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue_2 : 1;  // 0xC9(0x1)
	char pad_202_1 : 7;  // 0xCA(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0xCA(0x1)
	char pad_203[5];  // 0xCB(0x5)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0xD0(0x8)
	struct AORNPCCustomizableCharacter_BP_C* K2Node_DynamicCast_AsORNPCCustomizable_Character_BP;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xE4(0x10)
	char pad_244[4];  // 0xF4(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x101(0x1)
	char pad_258_1 : 7;  // 0x102(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x102(0x1)
	char pad_259_1 : 7;  // 0x103(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x103(0x1)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x104(0x1)
	char pad_261_1 : 7;  // 0x105(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x105(0x1)

}; 
// Function BlimNPCV2_ABP.BlimNPCV2_ABP_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function BlimNPCV2_ABP.BlimNPCV2_ABP_C.K2_OwnerDiedEventFired
// Size: 0xB8(Inherited: 0xB8) 
struct FK2_OwnerDiedEventFired : public FK2_OwnerDiedEventFired
{
	struct UObject* Killer;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	struct FGameplayTagContainer DamageTags;  // 0x98(0x20)

}; 
// Function BlimNPCV2_ABP.BlimNPCV2_ABP_C.TrySetIdleOverride
// Size: 0x33(Inherited: 0x1) 
struct FTrySetIdleOverride : public FTrySetIdleOverride
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x8(0x8)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x10(0x8)
	struct ABaseSkelMeshCustomizableNPC_BP_C* K2Node_DynamicCast_AsBase_Skel_Mesh_Customizable_NPC_BP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AORNPCCustomizableCharacter_BP_C* K2Node_DynamicCast_AsORNPCCustomizable_Character_BP;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x32(0x1)

}; 
