#pragma once 
#include <Chonk_EnemyWeap_HurricaneMortar_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_EnemyWeap_HurricaneMortar_BP.Chonk_EnemyWeap_HurricaneMortar_BP_C
// Size: 0x458(Inherited: 0x450) 
struct AChonk_EnemyWeap_HurricaneMortar_BP_C : public AORFireableInventoryItem
{
	struct USceneComponent* DefaultSceneRoot;  // 0x450(0x8)

}; 



