#pragma once 
#include <ApplyMinionStemCells_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass ApplyMinionStemCells_GE.ApplyMinionStemCells_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UApplyMinionStemCells_GE_C : public UAddLifeSpan_GE_C
{

}; 



