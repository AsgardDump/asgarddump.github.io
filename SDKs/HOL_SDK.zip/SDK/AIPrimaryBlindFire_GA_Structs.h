#pragma once 
#include "SDK.h" 
 
 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.GetCoverCornerType
// Size: 0x5A(Inherited: 0x0) 
struct FGetCoverCornerType
{
	uint8_t  CoverCornerType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FGameplayAbilityActorInfo CallFunc_GetActorInfo_ReturnValue;  // 0x8(0x48)
	struct AORAIController* CallFunc_GetOwningORAIController_ReturnValue;  // 0x50(0x8)
	uint8_t  CallFunc_GetCornerCoverType_ReturnValue;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x59(0x1)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnBlendOut_C0F530694A22E5D9ED67E6ADD3B32677
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_C0F530694A22E5D9ED67E6ADD3B32677
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.GetBlindFireMontageToPlay
// Size: 0x79(Inherited: 0x0) 
struct FGetBlindFireMontageToPlay
{
	struct UAnimMontage* ReturnValue;  // 0x0(0x8)
	uint8_t  CallFunc_GetCoverCornerType_CoverCornerType;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_RandomInteger_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FGameplayAbilityActorInfo CallFunc_GetActorInfo_ReturnValue;  // 0x18(0x48)
	struct AORAIController* CallFunc_GetOwningORAIController_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)
	uint8_t  CallFunc_GetCoverType_ReturnValue;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x6A(0x1)
	char pad_107[5];  // 0x6B(0x5)
	struct UAnimMontage* CallFunc_Map_Find_Value;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x78(0x1)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.EnableDamageEventBind
// Size: 0x51(Inherited: 0x0) 
struct FEnableDamageEventBind
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x18(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue_2;  // 0x40(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnNotifyEnd_C0F530694A22E5D9ED67E6ADD3B32677
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_C0F530694A22E5D9ED67E6ADD3B32677
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnInterrupted_C0F530694A22E5D9ED67E6ADD3B32677
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_C0F530694A22E5D9ED67E6ADD3B32677
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnNotifyBegin_C0F530694A22E5D9ED67E6ADD3B32677
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_C0F530694A22E5D9ED67E6ADD3B32677
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnCompleted_C0F530694A22E5D9ED67E6ADD3B32677
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_C0F530694A22E5D9ED67E6ADD3B32677
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnDamageTaken
// Size: 0xC8(Inherited: 0x0) 
struct FOnDamageTaken
{
	struct UObject* Damager;  // 0x0(0x8)
	struct AORCharacter* Damaged;  // 0x8(0x8)
	struct FHitResult HitResult;  // 0x10(0x90)
	float Damage;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA8(0x20)

}; 
// Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.ExecuteUbergraph_AIPrimaryBlindFire_GA
// Size: 0x1DC(Inherited: 0x0) 
struct FExecuteUbergraph_AIPrimaryBlindFire_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x4(0x8)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0xC(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x24(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x2C(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x3C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x44(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x54(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x5C(0x10)
	struct FName Temp_name_Variable;  // 0x6C(0x8)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	struct FGameplayAbilityActorInfo CallFunc_GetActorInfo_ReturnValue;  // 0x78(0x48)
	struct AORAIController* CallFunc_GetOwningORAIController_ReturnValue;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_K2_CommitAbility_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC9(0x1)
	char pad_202[6];  // 0xCA(0x6)
	struct UAnimMontage* CallFunc_GetBlindFireMontageToPlay_ReturnValue;  // 0xD0(0x8)
	struct USkeletalMeshComponent* CallFunc_GetOwningComponentFromActorInfo_ReturnValue;  // 0xD8(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0xE0(0x8)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0xE8(0x8)
	struct FActiveGameplayEffectHandle CallFunc_ApplyGameplayEffect_ReturnValue;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct UObject* K2Node_CustomEvent_Damager;  // 0x100(0x8)
	struct AORCharacter* K2Node_CustomEvent_Damaged;  // 0x108(0x8)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x110(0x90)
	float K2Node_CustomEvent_Damage;  // 0x1A0(0x4)
	char pad_420[4];  // 0x1A4(0x4)
	struct FGameplayTagContainer K2Node_CustomEvent_DamageTags;  // 0x1A8(0x20)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x1C8(0x1)
	char pad_457_1 : 7;  // 0x1C9(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x1C9(0x1)
	char pad_458[2];  // 0x1CA(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x1CC(0x10)

}; 
