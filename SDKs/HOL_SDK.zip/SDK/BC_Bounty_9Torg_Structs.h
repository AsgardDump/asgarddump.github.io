#pragma once 
#include "SDK.h" 
 
 
// Function BC_Bounty_9Torg.BC_Bounty_9Torg_C.ExecuteUbergraph_BC_Bounty_9Torg
// Size: 0x2C(Inherited: 0x0) 
struct FExecuteUbergraph_BC_Bounty_9Torg
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGameplayTag CallFunc_MakeLiteralGameplayTag_ReturnValue;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_CompleteMission_ReturnValue : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_StartMission_ReturnValue : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct UORAchievementSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x10(0x8)
	struct UORAchievementSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x18(0x8)
	struct APlayerCharacter_BP_C* CallFunc_GetORPlayer_PlayerCharacter;  // 0x20(0x8)
	int32_t CallFunc_AddCurrency_ReturnValue;  // 0x28(0x4)

}; 
