#pragma once 
#include "SDK.h" 
 
 
// Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity
// Size: 0x10(Inherited: 0x0) 
struct FGetVisualFidelity
{
	struct UAnimationCompressionLibraryDatabase* DatabaseAsset;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity
// Size: 0x30(Inherited: 0x0) 
struct FSetVisualFidelity
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FLatentActionInfo LatentInfo;  // 0x8(0x18)
	struct UAnimationCompressionLibraryDatabase* DatabaseAsset;  // 0x20(0x8)
	uint8_t  Result;  // 0x28(0x1)
	uint8_t  VisualFidelity;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
