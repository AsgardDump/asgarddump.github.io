#pragma once 
#include "SDK.h" 
 
 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.CharacterDied
// Size: 0x10(Inherited: 0x0) 
struct FCharacterDied
{
	struct AORAICharacter* Victim;  // 0x0(0x8)
	struct UObject* Killer;  // 0x8(0x8)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.HandleStaggerFXCustomSettings
// Size: 0x8(Inherited: 0x0) 
struct FHandleStaggerFXCustomSettings
{
	struct UNiagaraComponent* StaggerFXInstance;  // 0x0(0x8)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.ExecuteUbergraph_BaseAICharacter_Stagger_GA
// Size: 0x2B5(Inherited: 0x0) 
struct FExecuteUbergraph_BaseAICharacter_Stagger_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct FActiveGameplayEffectHandle K2Node_CustomEvent_ActiveEffectHandle;  // 0x18(0x8)
	struct FGameplayEffectSpecHandle K2Node_CustomEvent_EffectSpecHandle;  // 0x20(0x10)
	struct FGameplayEffectSpecHandle Temp_struct_Variable;  // 0x30(0x10)
	struct FActiveGameplayEffectHandle Temp_struct_Variable_2;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x4C(0x10)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x5C(0x90)
	float K2Node_CustomEvent_DeltaTime;  // 0xEC(0x4)
	float K2Node_CustomEvent_TotalElapsed;  // 0xF0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0xF4(0x10)
	float Temp_float_Variable;  // 0x104(0x4)
	float Temp_float_Variable_2;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)
	struct FGameplayEffectSpecHandle Temp_struct_Variable_3;  // 0x110(0x10)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	struct FName Temp_wildcard_Return_Value_Variable;  // 0x124(0x8)
	struct FActiveGameplayEffectHandle K2Node_CustomEvent_ActiveEffectHandle_2;  // 0x12C(0x8)
	char pad_308[4];  // 0x134(0x4)
	struct FGameplayEffectSpecHandle K2Node_CustomEvent_EffectSpecHandle_2;  // 0x138(0x10)
	struct UAbilitySystemComponent* CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;  // 0x148(0x8)
	struct UORAbilityTask_WaitGameplayEffectApplied* CallFunc_ListenForGameplayEffectApplied_ReturnValue;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x159(0x1)
	char pad_346_1 : 7;  // 0x15A(0x1)
	bool CallFunc_K2_CommitAbility_ReturnValue : 1;  // 0x15A(0x1)
	char pad_347[1];  // 0x15B(0x1)
	struct FGameplayTag CallFunc_GetSpeakerTag_ReturnValue;  // 0x15C(0x8)
	char pad_356[4];  // 0x164(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x168(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x180(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x1B0(0x8)
	struct AStagger_Melee_Interact_Prompt_BP_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x1B8(0x8)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x1C0(0x1)
	char pad_449[3];  // 0x1C1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x1C4(0x10)
	char pad_468[4];  // 0x1D4(0x4)
	struct UAbilitySystemComponent* CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue_2;  // 0x1D8(0x8)
	struct UORAbilityTask_WaitGameplayEffectApplied* CallFunc_ListenForGameplayEffectApplied_ReturnValue_2;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x1E8(0x1)
	char pad_489_1 : 7;  // 0x1E9(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x1E9(0x1)
	char pad_490[2];  // 0x1EA(0x2)
	struct FActiveGameplayEffectHandle Temp_struct_Variable_4;  // 0x1EC(0x8)
	struct FName CallFunc_Array_Get_Item;  // 0x1F4(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1FC(0x4)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x200(0x1)
	char pad_513[7];  // 0x201(0x7)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue_2;  // 0x208(0x8)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x210(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter_2;  // 0x218(0x8)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x220(0x1)
	char pad_545[7];  // 0x221(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool CallFunc_IsValidAndAlive_IsAliveAndWell : 1;  // 0x230(0x1)
	char CallFunc_GetValueAsEnum_ReturnValue;  // 0x231(0x1)
	char pad_562[2];  // 0x232(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x234(0x10)
	char pad_580[4];  // 0x244(0x4)
	struct AORAICharacter* K2Node_CustomEvent_Victim;  // 0x248(0x8)
	struct UObject* K2Node_CustomEvent_Killer;  // 0x250(0x8)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x258(0x1)
	char pad_601[3];  // 0x259(0x3)
	struct FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToOwner_ReturnValue;  // 0x25C(0x8)
	int32_t CallFunc_RemoveGameplayEffects_ReturnValue;  // 0x264(0x4)
	struct UORAbilityTask_TimedTick* CallFunc_TimedTick_ReturnValue;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool CallFunc_IsVisibleInPlayerCamera_ReturnValue : 1;  // 0x280(0x1)
	char pad_641[3];  // 0x281(0x3)
	float CallFunc_GetSquaredDistanceTo_ReturnValue;  // 0x284(0x4)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x289(0x1)
	char pad_650_1 : 7;  // 0x28A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x28A(0x1)
	char pad_651[1];  // 0x28B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x28C(0x10)
	char pad_668[4];  // 0x29C(0x4)
	struct ANarrativeDirector_BP_C* CallFunc_GetNarrativeDirectorBP_NarrativeDirector;  // 0x2A0(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x2A8(0x8)
	float CallFunc_GetMiscTableValue_Value;  // 0x2B0(0x4)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x2B4(0x1)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnEffectApplied_4B30CE0F4EA8886D752C7A844956F762
// Size: 0x18(Inherited: 0x0) 
struct FOnEffectApplied_4B30CE0F4EA8886D752C7A844956F762
{
	struct FActiveGameplayEffectHandle ActiveEffectHandle;  // 0x0(0x8)
	struct FGameplayEffectSpecHandle EffectSpecHandle;  // 0x8(0x10)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnTick_E6EFFAD846C9B0FEBC64EB8734803303
// Size: 0x8(Inherited: 0x0) 
struct FOnTick_E6EFFAD846C9B0FEBC64EB8734803303
{
	float DeltaTime;  // 0x0(0x4)
	float TotalElapsed;  // 0x4(0x4)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnEffectApplied_65F2657D4CC203E18217CF988A825D0B
// Size: 0x18(Inherited: 0x0) 
struct FOnEffectApplied_65F2657D4CC203E18217CF988A825D0B
{
	struct FActiveGameplayEffectHandle ActiveEffectHandle;  // 0x0(0x8)
	struct FGameplayEffectSpecHandle EffectSpecHandle;  // 0x8(0x10)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetStaggeredFXEnabled
// Size: 0x20(Inherited: 0x0) 
struct FSetStaggeredFXEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UNiagaraComponent* CallFunc_SpawnSystemAttached_ReturnValue;  // 0x18(0x8)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetAIStatusEffect
// Size: 0x20(Inherited: 0x0) 
struct FSetAIStatusEffect
{
	uint8_t  NewStatusEffect;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x18(0x8)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetOverrideSocket
// Size: 0x11(Inherited: 0x0) 
struct FSetOverrideSocket
{
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.ClearOverrideSocket
// Size: 0x1(Inherited: 0x0) 
struct FClearOverrideSocket
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x0(0x1)

}; 
