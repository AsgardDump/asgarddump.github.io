#pragma once 
#include <AbilityStateLayer_ALI_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass AbilityStateLayer_ALI.AbilityStateLayer_ALI_C
// Size: 0x28(Inherited: 0x28) 
struct UAbilityStateLayer_ALI_C : public UAnimLayerInterface
{

	void AbilityStateLayer(struct FPoseLink InPose, struct FPoseLink& AbilityStateLayer); // Function AbilityStateLayer_ALI.AbilityStateLayer_ALI_C.AbilityStateLayer
}; 



