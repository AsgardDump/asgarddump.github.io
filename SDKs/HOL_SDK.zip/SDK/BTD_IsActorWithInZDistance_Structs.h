#pragma once 
#include "SDK.h" 
 
 
// Function BTD_IsActorWithInZDistance.BTD_IsActorWithInZDistance_C.PerformConditionCheckAI
// Size: 0x5D(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x14(0xC)
	float CallFunc_BreakVector_X;  // 0x20(0x4)
	float CallFunc_BreakVector_Y;  // 0x24(0x4)
	float CallFunc_BreakVector_Z;  // 0x28(0x4)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x30(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x38(0xC)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x44(0x1)
	float CallFunc_BreakVector_X_2;  // 0x48(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x4C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x50(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x54(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x58(0x4)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x5C(0x1)

}; 
