#pragma once 
#include <Ability_PlayerDash_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_PlayerDash_BP.Ability_PlayerDash_BP_C
// Size: 0x424(Inherited: 0x408) 
struct UAbility_PlayerDash_BP_C : public UORGameplayAbility_PlayerDash
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x408(0x8)
	struct UMaterialInstanceDynamic* ParamMat;  // 0x410(0x8)
	float DistortionStart;  // 0x418(0x4)
	float BrightnessStart;  // 0x41C(0x4)
	float Duration;  // 0x420(0x4)

	void K2_ActivateAbility(); // Function Ability_PlayerDash_BP.Ability_PlayerDash_BP_C.K2_ActivateAbility
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_PlayerDash_BP.Ability_PlayerDash_BP_C.K2_OnEndAbility
	void ExecuteUbergraph_Ability_PlayerDash_BP(int32_t EntryPoint); // Function Ability_PlayerDash_BP.Ability_PlayerDash_BP_C.ExecuteUbergraph_Ability_PlayerDash_BP
}; 



