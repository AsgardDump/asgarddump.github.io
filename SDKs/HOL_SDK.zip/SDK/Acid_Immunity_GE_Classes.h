#pragma once 
#include <Acid_Immunity_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass Acid_Immunity_GE.Acid_Immunity_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UAcid_Immunity_GE_C : public UORGameplayEffect
{

}; 



