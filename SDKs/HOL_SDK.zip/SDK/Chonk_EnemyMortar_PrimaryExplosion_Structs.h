#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_EnemyMortar_PrimaryExplosion.Chonk_EnemyMortar_PrimaryExplosion_C.ExecuteUbergraph_Chonk_EnemyMortar_PrimaryExplosion
// Size: 0xA2(Inherited: 0x0) 
struct FExecuteUbergraph_Chonk_EnemyMortar_PrimaryExplosion
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	struct FHitResult CallFunc_FindFloor_OutHitResult;  // 0x10(0x90)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_FindFloor_bDidHit : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0xA1(0x1)

}; 
