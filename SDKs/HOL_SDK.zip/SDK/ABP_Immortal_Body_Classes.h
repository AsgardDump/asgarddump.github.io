#pragma once 
#include <ABP_Immortal_Body_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Immortal_Body.ABP_Immortal_Body_C
// Size: 0x2618(Inherited: 0x880) 
struct UABP_Immortal_Body_C : public UOR3PAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x880(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x888(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;  // 0x8B8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;  // 0x8E0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x908(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9;  // 0x988(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x9B8(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8;  // 0xA38(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_4;  // 0xA68(0xB0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_6;  // 0xB18(0x158)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;  // 0xC70(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;  // 0xC98(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // 0xCC0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0xCE8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0xD10(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7;  // 0xD90(0x30)
	struct FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot_3;  // 0xDC0(0x90)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6;  // 0xE50(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2;  // 0xE80(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5;  // 0xF68(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_3;  // 0xF98(0xB0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_5;  // 0x1048(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_11;  // 0x11A0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_10;  // 0x11C8(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3;  // 0x11F0(0xC0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // 0x12B0(0x158)
	struct FAnimNode_Slot AnimGraphNode_Slot_4;  // 0x1408(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_9;  // 0x1450(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x1478(0xC0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0x1538(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_8;  // 0x1690(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_5;  // 0x16B8(0xA0)
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // 0x1758(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x17A0(0xC0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7;  // 0x1860(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6;  // 0x1888(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x18B0(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // 0x1A08(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x1A30(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x1A58(0x28)
	struct FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot_2;  // 0x1A80(0x90)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0x1B10(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x1B40(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x1BC0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2;  // 0x1BF0(0xB0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_4;  // 0x1CA0(0xA0)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x1D40(0x28)
	struct FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot;  // 0x1D68(0x90)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x1DF8(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x1E28(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x1F10(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x1F40(0xB0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x1FF0(0xA0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x2090(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x2130(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x2158(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x21A0(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x21C8(0x48)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x2210(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x22B0(0x28)
	struct FAnimNode_SquanchDismember AnimGraphNode_SquanchDismember;  // 0x22D8(0xD0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x23A8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x23C8(0x20)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x23E8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x2540(0x28)
	char pad_9576_1 : 7;  // 0x2568(0x1)
	bool IsDead : 1;  // 0x2568(0x1)
	char pad_9577_1 : 7;  // 0x2569(0x1)
	bool IsOnlyHead : 1;  // 0x2569(0x1)
	char pad_9578_1 : 7;  // 0x256A(0x1)
	bool IsHeadAttached : 1;  // 0x256A(0x1)
	char pad_9579_1 : 7;  // 0x256B(0x1)
	bool IsRecharging : 1;  // 0x256B(0x1)
	char pad_9580[4];  // 0x256C(0x4)
	struct TArray<struct UAnimMontage*> BodyFrontHitReacts;  // 0x2570(0x10)
	struct TArray<struct UAnimMontage*> BodyRightHitReacts;  // 0x2580(0x10)
	struct TArray<struct UAnimMontage*> BodyBackHitReacts;  // 0x2590(0x10)
	struct TArray<struct UAnimMontage*> BodyLeftHitReacts;  // 0x25A0(0x10)
	struct TArray<struct UAnimMontage*> BodyAllHitReacts;  // 0x25B0(0x10)
	struct TArray<struct UAnimMontage*> HeadFrontHitReacts;  // 0x25C0(0x10)
	struct TArray<struct UAnimMontage*> HeadRightHitReacts;  // 0x25D0(0x10)
	struct TArray<struct UAnimMontage*> HeadBackHitReacts;  // 0x25E0(0x10)
	struct TArray<struct UAnimMontage*> HeadLeftHitReacts;  // 0x25F0(0x10)
	struct TArray<struct UAnimMontage*> HeadAllHitReacts;  // 0x2600(0x10)
	struct USQDismemberComponent* DismemberComponent;  // 0x2610(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.AnimGraph
	void HandleHitReacts(struct FHitResult& HitResult); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.HandleHitReacts
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.BlueprintUpdateAnimation
	void K2_OwnerDiedEventFired(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.K2_OwnerDiedEventFired
	void K2_OwnerDamageTakenEventFired(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.K2_OwnerDamageTakenEventFired
	void BlueprintInitializeAnimation(); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.BlueprintInitializeAnimation
	void K2_OwnerSpawnedFromPool(); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.K2_OwnerSpawnedFromPool
	void ExecuteUbergraph_ABP_Immortal_Body(int32_t EntryPoint); // Function ABP_Immortal_Body.ABP_Immortal_Body_C.ExecuteUbergraph_ABP_Immortal_Body
}; 



