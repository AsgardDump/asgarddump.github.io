#pragma once 
#include <ChoiceActive_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass ChoiceActive_GE.ChoiceActive_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UChoiceActive_GE_C : public UORGameplayEffect
{

}; 



