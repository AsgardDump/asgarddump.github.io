#pragma once 
#include "SDK.h" 
 
 
// Function BTD_Chonk_IsTargetingFriendly.BTD_Chonk_IsTargetingFriendly_C.PerformConditionCheckAI
// Size: 0x21(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AChonk_BP_C* K2Node_DynamicCast_AsChonk_BP;  // 0x18(0x8)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
