#pragma once 
#include <Chonk_ArcFiringResult_Base_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_ArcFiringResult_Base_BP.Chonk_ArcFiringResult_Base_BP_C
// Size: 0x358(Inherited: 0x358) 
struct UChonk_ArcFiringResult_Base_BP_C : public UORFiringResult_ArcProjectile
{

}; 



