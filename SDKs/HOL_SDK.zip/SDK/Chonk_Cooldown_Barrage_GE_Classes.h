#pragma once 
#include <Chonk_Cooldown_Barrage_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_Cooldown_Barrage_GE.Chonk_Cooldown_Barrage_GE_C
// Size: 0x810(Inherited: 0x810) 
struct UChonk_Cooldown_Barrage_GE_C : public UGameplayEffect
{

}; 



