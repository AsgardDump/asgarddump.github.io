#pragma once 
#include <Ability_GunInteraction_Kenny_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_GunInteraction_Kenny_BP.Ability_GunInteraction_Kenny_BP_C
// Size: 0x3F9(Inherited: 0x3F9) 
struct UAbility_GunInteraction_Kenny_BP_C : public UAbility_GunInteraction_BP_C
{

}; 



