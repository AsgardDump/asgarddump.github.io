#pragma once 
#include "SDK.h" 
 
 
// Function ApplyGEOnAppliedGETag_GA.ApplyGEOnAppliedGETag_GA_C.ExecuteUbergraph_ApplyGEOnAppliedGETag_GA
// Size: 0x34(Inherited: 0x0) 
struct FExecuteUbergraph_ApplyGEOnAppliedGETag_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	UGameplayEffect* CallFunc_Array_Get_Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FActiveGameplayEffectHandle CallFunc_ApplyGameplayEffect_ReturnValue;  // 0x2C(0x8)

}; 
