#pragma once 
#include <BTD_IsWithinDistanceFromTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_IsWithinDistanceFromTarget.BTD_IsWithinDistanceFromTarget_C
// Size: 0xCC(Inherited: 0xA0) 
struct UBTD_IsWithinDistanceFromTarget_C : public UBTDecorator_BlueprintBase
{
	struct FBlackboardKeySelector TargetKey;  // 0xA0(0x28)
	float MaxDistance;  // 0xC8(0x4)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_IsWithinDistanceFromTarget.BTD_IsWithinDistanceFromTarget_C.PerformConditionCheckAI
}; 



