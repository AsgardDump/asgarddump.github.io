#pragma once 
#include <Chonk_GroundPound_CameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_GroundPound_CameraShake.Chonk_GroundPound_CameraShake_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UChonk_GroundPound_CameraShake_C : public UMatineeCameraShake
{

}; 



