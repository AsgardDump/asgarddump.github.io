#pragma once 
#include <BTD_ValidPatrolPath_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_ValidPatrolPath.BTD_ValidPatrolPath_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_ValidPatrolPath_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_ValidPatrolPath.BTD_ValidPatrolPath_C.PerformConditionCheckAI
}; 



