#pragma once 
#include <Ability_UIInteract_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_UIInteract_BP.Ability_UIInteract_BP_C
// Size: 0x408(Inherited: 0x408) 
struct UAbility_UIInteract_BP_C : public UORGameplayAbility_UIInteract
{

}; 



