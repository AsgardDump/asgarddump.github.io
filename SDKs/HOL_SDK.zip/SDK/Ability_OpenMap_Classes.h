#pragma once 
#include <Ability_OpenMap_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_OpenMap.Ability_OpenMap_C
// Size: 0x408(Inherited: 0x3F8) 
struct UAbility_OpenMap_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)
	struct UPauseMenuPayload_C* Payload;  // 0x400(0x8)

	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function Ability_OpenMap.Ability_OpenMap_C.K2_CanActivateAbility
	void K2_ActivateAbility(); // Function Ability_OpenMap.Ability_OpenMap_C.K2_ActivateAbility
	void ExecuteUbergraph_Ability_OpenMap(int32_t EntryPoint); // Function Ability_OpenMap.Ability_OpenMap_C.ExecuteUbergraph_Ability_OpenMap
}; 



