#pragma once 
#include "SDK.h" 
 
 
// Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ExecuteUbergraph_BTS_FocusTargetActorInRange
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_FocusTargetActorInRange
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x10(0x8)
	struct AAIController* K2Node_Event_OwnerController_3;  // 0x18(0x8)
	struct APawn* K2Node_Event_ControlledPawn_3;  // 0x20(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x28(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AAIController* K2Node_Event_OwnerController;  // 0x38(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x40(0x8)

}; 
// Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ReceiveDeactivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveDeactivationAI : public FReceiveDeactivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.ReceiveActivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveActivationAI : public FReceiveActivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTS_FocusTargetActorInRange.BTS_FocusTargetActorInRange_C.UpdateControllerFocus
// Size: 0x88(Inherited: 0x0) 
struct FUpdateControllerFocus
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	struct AAIController* TheOwnerController;  // 0x10(0x8)
	struct FVector CachedTargetLocation;  // 0x18(0xC)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CachedTargetActor;  // 0x28(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_Vector_IsZero_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3B(0x1)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct AActor* CallFunc_GetFocusActor_ReturnValue;  // 0x40(0x8)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x4D(0x1)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x4E(0x1)
	char pad_79[1];  // 0x4F(0x1)
	struct FVector CallFunc_GetBlackboardValueAsVector_ReturnValue;  // 0x50(0xC)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_Vector_IsZero_ReturnValue_2 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	struct UObject* CallFunc_GetBlackboardValueAsObject_ReturnValue;  // 0x60(0x8)
	struct UActorComponent* K2Node_DynamicCast_AsActor_Component;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x78(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x80(0x8)

}; 
