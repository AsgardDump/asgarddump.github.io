#pragma once 
#include "SDK.h" 
 
 
// Function BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C.PerformConditionCheckAI
// Size: 0x4C(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AORAIController* K2Node_DynamicCast_AsORAIController;  // 0x18(0x8)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool Temp_bool_Variable : 1;  // 0x21(0x1)
	uint8_t  CallFunc_GetCoverType_ReturnValue;  // 0x22(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x23(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x24(0x1)
	struct UObject* CallFunc_GetClaimedAttractionPoint_ReturnValue;  // 0x28(0x8)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x30(0x1)
	struct TScriptInterface<IORAttractionPointInterface> K2Node_DynamicCast_AsORAttraction_Point_Interface;  // 0x38(0x10)
	char pad_79_1 : 7;  // 0x4F(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_HasAnyCoverAvailable_ReturnValue : 1;  // 0x49(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4A(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_IsAttractionPointInHomeArea_Out : 1;  // 0x4B(0x1)

}; 
// Function BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C.IsAttractionPointInHomeArea
// Size: 0x48(Inherited: 0x0) 
struct FIsAttractionPointInHomeArea
{
	struct UObject* AttractionPoint;  // 0x0(0x8)
	struct AORAIController* Controller;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Out : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector Temp_struct_Variable;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsPointInHomeArea_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<IORAttractionPointInterface> K2Node_DynamicCast_AsORAttraction_Point_Interface;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	struct FVector CallFunc_GetAttractionPointLocation_ReturnValue;  // 0x3C(0xC)

}; 
