#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.ExecuteUbergraph_Chonk_FriendlyProximityMine_Projectile_BP
// Size: 0x41(Inherited: 0x0) 
struct FExecuteUbergraph_Chonk_FriendlyProximityMine_Projectile_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* K2Node_CustomEvent_Actor;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x18(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UObject* CallFunc_GetValueAsObject_ReturnValue;  // 0x30(0x8)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)

}; 
// Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.SetTarget
// Size: 0x8(Inherited: 0x0) 
struct FSetTarget
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.AllowImpactWithActor
// Size: 0xC(Inherited: 0x54) 
struct FAllowImpactWithActor : public FAllowImpactWithActor
{
	struct AActor* OtherActor;  // 0x0(0x8)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_AllowImpactWithActor_ReturnValue : 1;  // 0x9(0x1)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA(0x1)
	char pad_95_1 : 7;  // 0x5F(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xB(0x1)

}; 
