#pragma once 
#include <BTTask_SetCombatSubState_Structs.h>
 
 
 
// BlueprintGeneratedClass BTTask_SetCombatSubState.BTTask_SetCombatSubState_C
// Size: 0xB1(Inherited: 0xA8) 
struct UBTTask_SetCombatSubState_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	uint8_t  CombatSubstate;  // 0xB0(0x1)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTTask_SetCombatSubState.BTTask_SetCombatSubState_C.ReceiveExecuteAI
	void ExecuteUbergraph_BTTask_SetCombatSubState(int32_t EntryPoint); // Function BTTask_SetCombatSubState.BTTask_SetCombatSubState_C.ExecuteUbergraph_BTTask_SetCombatSubState
}; 



