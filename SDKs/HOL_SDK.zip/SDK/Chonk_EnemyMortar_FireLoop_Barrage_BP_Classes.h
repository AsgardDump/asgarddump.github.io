#pragma once 
#include <Chonk_EnemyMortar_FireLoop_Barrage_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_EnemyMortar_FireLoop_Barrage_BP.Chonk_EnemyMortar_FireLoop_Barrage_BP_C
// Size: 0x13C(Inherited: 0x135) 
struct UChonk_EnemyMortar_FireLoop_Barrage_BP_C : public UORTestEnemyWeapons_FireLoop_C
{
	char pad_309[3];  // 0x135(0x3)
	int32_t ChargeUpAKOnPlayer;  // 0x138(0x4)

	void StopFireChargeUpSFX(); // Function Chonk_EnemyMortar_FireLoop_Barrage_BP.Chonk_EnemyMortar_FireLoop_Barrage_BP_C.StopFireChargeUpSFX
	void PlayFireChargeUpSFX(); // Function Chonk_EnemyMortar_FireLoop_Barrage_BP.Chonk_EnemyMortar_FireLoop_Barrage_BP_C.PlayFireChargeUpSFX
}; 



