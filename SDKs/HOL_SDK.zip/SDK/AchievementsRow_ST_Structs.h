#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct AchievementsRow_ST.AchievementsRow_ST
// Size: 0x30(Inherited: 0x0) 
struct FAchievementsRow_ST
{
	struct FText Name_8_79E70ADE4931F28B43761A9541AAA2BC;  // 0x0(0x18)
	struct FText Description_12_6937C46E4B5737C2FEE9E483DFC769F7;  // 0x18(0x18)

}; 
