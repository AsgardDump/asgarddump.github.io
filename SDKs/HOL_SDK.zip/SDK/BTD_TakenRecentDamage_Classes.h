#pragma once 
#include <BTD_TakenRecentDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_TakenRecentDamage.BTD_TakenRecentDamage_C
// Size: 0xA8(Inherited: 0xA0) 
struct UBTD_TakenRecentDamage_C : public UBTDecorator_BlueprintBase
{
	float TimeInPastToCheck;  // 0xA0(0x4)
	float DamageThreshold;  // 0xA4(0x4)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_TakenRecentDamage.BTD_TakenRecentDamage_C.PerformConditionCheckAI
}; 



