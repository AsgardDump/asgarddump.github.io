#pragma once 
#include <ApplyGEOnAppliedGETag_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ApplyGEOnAppliedGETag_GA.ApplyGEOnAppliedGETag_GA_C
// Size: 0x498(Inherited: 0x480) 
struct UApplyGEOnAppliedGETag_GA_C : public UActivateOnAppliedGETag_GA_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x480(0x8)
	struct TArray<UGameplayEffect*> GEToApply;  // 0x488(0x10)

	void K2_CommitExecute(); // Function ApplyGEOnAppliedGETag_GA.ApplyGEOnAppliedGETag_GA_C.K2_CommitExecute
	void ExecuteUbergraph_ApplyGEOnAppliedGETag_GA(int32_t EntryPoint); // Function ApplyGEOnAppliedGETag_GA.ApplyGEOnAppliedGETag_GA_C.ExecuteUbergraph_ApplyGEOnAppliedGETag_GA
}; 



