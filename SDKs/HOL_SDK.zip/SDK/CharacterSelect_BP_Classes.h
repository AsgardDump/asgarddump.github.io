#pragma once 
#include <CharacterSelect_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass CharacterSelect_BP.CharacterSelect_BP_C
// Size: 0x240(Inherited: 0x220) 
struct ACharacterSelect_BP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x228(0x8)
	struct UWidgetComponent* Widget;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)

	void PopSelectionWidget(); // Function CharacterSelect_BP.CharacterSelect_BP_C.PopSelectionWidget
	void PushSelectionWidget(); // Function CharacterSelect_BP.CharacterSelect_BP_C.PushSelectionWidget
	void ReceiveDestroyed(); // Function CharacterSelect_BP.CharacterSelect_BP_C.ReceiveDestroyed
	void ReceiveBeginPlay(); // Function CharacterSelect_BP.CharacterSelect_BP_C.ReceiveBeginPlay
	void ExecuteUbergraph_CharacterSelect_BP(int32_t EntryPoint); // Function CharacterSelect_BP.CharacterSelect_BP_C.ExecuteUbergraph_CharacterSelect_BP
}; 



