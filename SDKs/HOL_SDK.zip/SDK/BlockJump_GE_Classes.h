#pragma once 
#include <BlockJump_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockJump_GE.BlockJump_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UBlockJump_GE_C : public UORGameplayEffect
{

}; 



