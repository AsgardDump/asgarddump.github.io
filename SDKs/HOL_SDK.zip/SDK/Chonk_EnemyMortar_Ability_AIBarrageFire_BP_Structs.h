#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.ExecuteUbergraph_Chonk_EnemyMortar_Ability_AIBarrageFire_BP
// Size: 0x12C(Inherited: 0x0) 
struct FExecuteUbergraph_Chonk_EnemyMortar_Ability_AIBarrageFire_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* K2Node_CustomEvent_Damager;  // 0x8(0x8)
	struct AORCharacter* K2Node_CustomEvent_Damaged;  // 0x10(0x8)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x18(0x90)
	float K2Node_CustomEvent_Damage;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct FGameplayTagContainer K2Node_CustomEvent_DamageTags;  // 0xB0(0x20)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0xD1(0x1)
	char pad_210[6];  // 0xD2(0x6)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct AChonk_BP_C* K2Node_DynamicCast_AsChonk_BP;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	int32_t CallFunc_RemoveGameplayEffects_ReturnValue;  // 0xF4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue;  // 0x100(0x8)
	struct TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput;  // 0x108(0x10)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_HasMatchingGameplayTag_ReturnValue : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x119(0x1)
	char pad_282_1 : 7;  // 0x11A(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x11A(0x1)
	char pad_283_1 : 7;  // 0x11B(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x11B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x11C(0x10)

}; 
// Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_CanActivateAbility
// Size: 0x8A(Inherited: 0x78) 
struct FK2_CanActivateAbility : public FK2_CanActivateAbility
{
	struct FGameplayAbilityActorInfo ActorInfo;  // 0x0(0x48)
	struct FGameplayAbilitySpecHandle Handle;  // 0x48(0x4)
	struct FGameplayTagContainer RelevantTags;  // 0x50(0x20)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	struct USQFiringResultComponent* CallFunc_GetFireableItemFireModeFiringResult_ReturnValue;  // 0x78(0x8)
	struct UORFiringResult_ArcProjectile* K2Node_DynamicCast_AsORFiring_Result_Arc_Projectile;  // 0x80(0x8)
	char pad_245_1 : 7;  // 0xF5(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	char pad_246_1 : 7;  // 0xF6(0x1)
	bool CallFunc_HasClearViewToProbableShotApexFromSocket_ReturnValue : 1;  // 0x89(0x1)

}; 
// Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.OwnerDamageTaken
// Size: 0xC8(Inherited: 0x0) 
struct FOwnerDamageTaken
{
	struct UObject* Damager;  // 0x0(0x8)
	struct AORCharacter* Damaged;  // 0x8(0x8)
	struct FHitResult HitResult;  // 0x10(0x90)
	float Damage;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA8(0x20)

}; 
// Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.SetNDBarrageInterruptData
// Size: 0xC(Inherited: 0x0) 
struct FSetNDBarrageInterruptData
{
	float CallFunc_GetDifficultyFloat_ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_GetDifficultyInt_ReturnValue;  // 0x4(0x4)
	float CallFunc_GetDifficultyFloat_ReturnValue_2;  // 0x8(0x4)

}; 
