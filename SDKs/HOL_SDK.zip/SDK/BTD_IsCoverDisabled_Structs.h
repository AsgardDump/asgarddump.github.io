#pragma once 
#include "SDK.h" 
 
 
// Function BTD_IsCoverDisabled.BTD_IsCoverDisabled_C.PerformConditionCheckAI
// Size: 0x2A(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable : 1;  // 0x11(0x1)
	struct TScriptInterface<IGameplayTagAssetInterface> K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface;  // 0x18(0x10)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool CallFunc_HasMatchingGameplayTag_ReturnValue : 1;  // 0x29(0x1)

}; 
