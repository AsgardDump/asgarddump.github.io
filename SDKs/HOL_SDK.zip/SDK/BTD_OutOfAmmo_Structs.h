#pragma once 
#include "SDK.h" 
 
 
// Function BTD_OutOfAmmo.BTD_OutOfAmmo_C.PerformConditionCheckAI
// Size: 0x4B(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x18(0x8)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)
	struct ASQEquippableInventoryItem* CallFunc_GetFirstEquippedItem_ReturnValue;  // 0x28(0x8)
	struct AORFireableInventoryItem* K2Node_DynamicCast_AsORFireable_Inventory_Item;  // 0x30(0x8)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	struct USQFireLoopComponent* CallFunc_GetFireLoopComponent_ReturnValue;  // 0x40(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_HasAvailableResource_ReturnValue : 1;  // 0x49(0x1)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x4A(0x1)

}; 
