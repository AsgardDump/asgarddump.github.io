#pragma once 
#include <AttachedProximityMine_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass AttachedProximityMine_GE.AttachedProximityMine_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UAttachedProximityMine_GE_C : public UORGameplayEffect
{

}; 



