#pragma once 
#include <Chonk_FriendlyProximityMine_Projectile_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C
// Size: 0x458(Inherited: 0x439) 
struct AChonk_FriendlyProximityMine_Projectile_BP_C : public AChonk_ProximityMine_Projectile_BP_C
{
	char pad_1081[7];  // 0x439(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x440(0x8)
	struct FName TargetActor_Ability;  // 0x448(0x8)
	struct AActor* TargetActor;  // 0x450(0x8)

	bool AllowImpactWithActor(struct AActor* OtherActor); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.AllowImpactWithActor
	void ReceiveBeginPlay(); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.ReceiveBeginPlay
	void SetTarget(struct AActor* Actor); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.SetTarget
	void ExecuteUbergraph_Chonk_FriendlyProximityMine_Projectile_BP(int32_t EntryPoint); // Function Chonk_FriendlyProximityMine_Projectile_BP.Chonk_FriendlyProximityMine_Projectile_BP_C.ExecuteUbergraph_Chonk_FriendlyProximityMine_Projectile_BP
}; 



