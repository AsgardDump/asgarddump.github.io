#pragma once 
#include <ActivateOnAppliedGETag_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C
// Size: 0x480(Inherited: 0x3F8) 
struct UActivateOnAppliedGETag_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)
	int32_t StacksToConsume;  // 0x400(0x4)
	char pad_1028[4];  // 0x404(0x4)
	struct FGameplayTagContainer RequiredGETags;  // 0x408(0x20)
	struct FGameplayTagContainer AssetTagToConsume;  // 0x428(0x20)
	struct AActor* ActivationSource;  // 0x448(0x8)
	struct FGameplayEffectSpecHandle ActivationSpecHandle;  // 0x450(0x10)
	struct FGameplayTagContainer IgnoredGETags;  // 0x460(0x20)

	void OnEffectApplied_57C2DC75421B4EF1205EA583C33EF7C1(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.OnEffectApplied_57C2DC75421B4EF1205EA583C33EF7C1
	void K2_CommitExecute(); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.K2_CommitExecute
	void K2_ActivateAbility(); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.K2_ActivateAbility
	void ExecuteUbergraph_ActivateOnAppliedGETag_GA(int32_t EntryPoint); // Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.ExecuteUbergraph_ActivateOnAppliedGETag_GA
}; 



