#pragma once 
#include <Ability_PrimaryFire_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_PrimaryFire_BP.Ability_PrimaryFire_BP_C
// Size: 0x430(Inherited: 0x428) 
struct UAbility_PrimaryFire_BP_C : public UORGameplayAbility_FireItem
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x428(0x8)

	void K2_ActivateAbility(); // Function Ability_PrimaryFire_BP.Ability_PrimaryFire_BP_C.K2_ActivateAbility
	void ExecuteUbergraph_Ability_PrimaryFire_BP(int32_t EntryPoint); // Function Ability_PrimaryFire_BP.Ability_PrimaryFire_BP_C.ExecuteUbergraph_Ability_PrimaryFire_BP
}; 



