#pragma once 
#include <ChefStand_InteractionStation_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C
// Size: 0x4FC(Inherited: 0x3D0) 
struct AChefStand_InteractionStation_BP_C : public AInteractionStation_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3D0(0x8)
	struct USceneComponent* SyncedAnimTargetPoint;  // 0x3D8(0x8)
	struct USyncedPlayerAnimationComponent* SyncedPlayerAnimation;  // 0x3E0(0x8)
	struct TArray<struct FGameplayTag> ConversationObjectives;  // 0x3E8(0x10)
	struct FMulticastInlineDelegate StartBlortoConversation;  // 0x3F8(0x30)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool AllowPlayerExitShop : 1;  // 0x428(0x1)
	char pad_1065[3];  // 0x429(0x3)
	float EnterShopMenuOpenDelay;  // 0x42C(0x4)
	struct FMulticastInlineDelegate PlayerEnter;  // 0x430(0x30)
	struct FMulticastInlineDelegate ItemPurchased;  // 0x460(0x30)
	struct FMulticastInlineDelegate PlayerExit;  // 0x490(0x30)
	struct TArray<struct FGameplayTag> ItemsPurchasedThisTime;  // 0x4C0(0x10)
	char pad_1232_1 : 7;  // 0x4D0(0x1)
	bool IsRecentReturnToShop : 1;  // 0x4D0(0x1)
	char pad_1233[7];  // 0x4D1(0x7)
	struct FTimerHandle RecentReturnTimer;  // 0x4D8(0x8)
	char pad_1248_1 : 7;  // 0x4E0(0x1)
	bool ShouldInstallWarpDisc : 1;  // 0x4E0(0x1)
	char pad_1249_1 : 7;  // 0x4E1(0x1)
	bool IsPlayingWarpDiscInstall : 1;  // 0x4E1(0x1)
	char pad_1250[2];  // 0x4E2(0x2)
	float EquipDelayDuration;  // 0x4E4(0x4)
	struct AActor* FocusActor_Blorto;  // 0x4E8(0x8)
	char pad_1264_1 : 7;  // 0x4F0(0x1)
	bool IsMenuOpen : 1;  // 0x4F0(0x1)
	char pad_1265[3];  // 0x4F1(0x3)
	struct FGameplayTag FirstMeetMissionBool;  // 0x4F4(0x8)

	void GetOverrideComponentToFace(struct USceneComponent*& ComponentToFace); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.GetOverrideComponentToFace
	void ClearIsRecentReturn(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ClearIsRecentReturn
	void PurchaseItem(struct FChefStandTransactionData TransactionData, char ChefStandTransactionResult& Result, int32_t& AmountPurchased); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PurchaseItem
	void ResumeExitShop(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ResumeExitShop
	void ShouldStartBlortoConversation(bool& StartConversation, struct FGameplayTag& ObjectiveTag); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ShouldStartBlortoConversation
	void ResumeOpenShop(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ResumeOpenShop
	void OnStationExited(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnStationExited
	void StartEntranceAnimation(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.StartEntranceAnimation
	void StartExitAnimation(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.StartExitAnimation
	void NavigateBack(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.NavigateBack
	void OnWarpDiscInstallComplete(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnWarpDiscInstallComplete
	void OnStationEntered(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnStationEntered
	void PlaySitDownAnimation(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlaySitDownAnimation
	void RaiseGunAfterStanding(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.RaiseGunAfterStanding
	void FinishedEntrance(); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.FinishedEntrance
	void BndEvt__ChefStand_InteractionStation_BP_SyncedPlayerAnimation_K2Node_ComponentBoundEvent_0_SyncedAnimationComponentEvent__DelegateSignature(struct USyncedPlayerAnimationComponent* SyncedAnimationComponent); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.BndEvt__ChefStand_InteractionStation_BP_SyncedPlayerAnimation_K2Node_ComponentBoundEvent_0_SyncedAnimationComponentEvent__DelegateSignature
	void OnCurrencyChangedDelegate(struct FGameplayTag Currency, int32_t PreviousCount, int32_t NewCount, char EInventoryTransactionType TransactionType); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnCurrencyChangedDelegate
	void ExecuteUbergraph_ChefStand_InteractionStation_BP(int32_t EntryPoint); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ExecuteUbergraph_ChefStand_InteractionStation_BP
	void PlayerExit__DelegateSignature(struct TArray<struct FGameplayTag>& ItemsPurchased); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlayerExit__DelegateSignature
	void ItemPurchased__DelegateSignature(struct FGameplayTag ItemTag, char ChefStandTransactionResult Result); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ItemPurchased__DelegateSignature
	void PlayerEnter__DelegateSignature(bool IsRecentReturn); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlayerEnter__DelegateSignature
	void StartBlortoConversation__DelegateSignature(struct FGameplayTag ObjectiveTag); // Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.StartBlortoConversation__DelegateSignature
}; 



