#pragma once 
#include <BTD_OutOfAmmo_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_OutOfAmmo.BTD_OutOfAmmo_C
// Size: 0xB0(Inherited: 0xA0) 
struct UBTD_OutOfAmmo_C : public UBTDecorator_BlueprintBase
{
	struct FGameplayTag InventorySlotGameplayTag;  // 0xA0(0x8)
	struct FGameplayTag FireModeGameplayTag;  // 0xA8(0x8)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_OutOfAmmo.BTD_OutOfAmmo_C.PerformConditionCheckAI
}; 



