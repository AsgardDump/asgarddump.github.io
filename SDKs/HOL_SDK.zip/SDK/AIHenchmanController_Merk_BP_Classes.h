#pragma once 
#include <AIHenchmanController_Merk_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AIHenchmanController_Merk_BP.AIHenchmanController_Merk_BP_C
// Size: 0x8D8(Inherited: 0x8C2) 
struct AAIHenchmanController_Merk_BP_C : public AORAIHenchmanController_BP_C
{
	char pad_2242[2];  // 0x8C2(0x2)
	struct FGameplayTag EventNDCharging;  // 0x8C4(0x8)
	char pad_2252_1 : 7;  // 0x8CC(0x1)
	bool HasNotRetreated : 1;  // 0x8CC(0x1)
	char pad_2253[3];  // 0x8CD(0x3)
	float RetreatHealthPercent;  // 0x8D0(0x4)
	float RetreatTime;  // 0x8D4(0x4)

}; 



