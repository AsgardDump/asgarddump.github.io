#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct CharacterInfoDataStruct.CharacterInfoDataStruct
// Size: 0x19(Inherited: 0x0) 
struct FCharacterInfoDataStruct
{
	struct FText CharacterName_2_88F2DD234F573AC41AE560B5B6E17D1F;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool IsRightJustified_4_F55D118747539ED8A5D7E2AC8CF634AE : 1;  // 0x18(0x1)

}; 
