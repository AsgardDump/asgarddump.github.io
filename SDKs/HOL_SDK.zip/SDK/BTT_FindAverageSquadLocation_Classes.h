#pragma once 
#include <BTT_FindAverageSquadLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C
// Size: 0xDC(Inherited: 0xA8) 
struct UBTT_FindAverageSquadLocation_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector AverageSquadLocationBBKey;  // 0xB0(0x28)
	float HeightOffset;  // 0xD8(0x4)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C.ReceiveExecuteAI
	void ExecuteUbergraph_BTT_FindAverageSquadLocation(int32_t EntryPoint); // Function BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C.ExecuteUbergraph_BTT_FindAverageSquadLocation
}; 



