#pragma once 
#include <Chonk_EnemyMortar_Ability_AIBarrageFire_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C
// Size: 0x47C(Inherited: 0x468) 
struct UChonk_EnemyMortar_Ability_AIBarrageFire_BP_C : public UAbility_AIChargeAndFireMultipleTimesItemMontage_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x468(0x8)
	struct AChonk_BP_C* ChonkBP;  // 0x470(0x8)
	float CurrentGunDamage;  // 0x478(0x4)

	void SetNDBarrageInterruptData(); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.SetNDBarrageInterruptData
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_CanActivateAbility
	void OwnerDamageTaken(struct UObject* Damager, struct AORCharacter* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.OwnerDamageTaken
	void K2_OnEndAbility(bool bWasCancelled); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_OnEndAbility
	void K2_ActivateAbility(); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.K2_ActivateAbility
	void ExecuteUbergraph_Chonk_EnemyMortar_Ability_AIBarrageFire_BP(int32_t EntryPoint); // Function Chonk_EnemyMortar_Ability_AIBarrageFire_BP.Chonk_EnemyMortar_Ability_AIBarrageFire_BP_C.ExecuteUbergraph_Chonk_EnemyMortar_Ability_AIBarrageFire_BP
}; 



