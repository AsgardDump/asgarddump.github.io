#pragma once 
#include <ChangeCollisionWhileActive_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C
// Size: 0x414(Inherited: 0x3F8) 
struct UChangeCollisionWhileActive_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)
	struct FName OldProfileName;  // 0x400(0x8)
	char ECollisionEnabled OldCollision;  // 0x408(0x1)
	char pad_1033[3];  // 0x409(0x3)
	struct FName NewProfileName;  // 0x40C(0x8)

	void K2_ActivateAbility(); // Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.K2_ActivateAbility
	void K2_OnEndAbility(bool bWasCancelled); // Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.K2_OnEndAbility
	void ExecuteUbergraph_ChangeCollisionWhileActive_GA(int32_t EntryPoint); // Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.ExecuteUbergraph_ChangeCollisionWhileActive_GA
}; 



