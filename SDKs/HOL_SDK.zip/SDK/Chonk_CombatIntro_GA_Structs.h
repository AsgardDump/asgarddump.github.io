#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_CombatIntro_GA.Chonk_CombatIntro_GA_C.ExecuteUbergraph_Chonk_CombatIntro_GA
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_Chonk_CombatIntro_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AChonk_Mortar_v4_BP_C* K2Node_DynamicCast_AsChonk_Mortar_V_4_BP;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
