#pragma once 
#include "SDK.h" 
 
 
// Function BP_Tendril.BP_Tendril_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Tendril.BP_Tendril_C.ExecuteUbergraph_BP_Tendril
// Size: 0xE4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Tendril
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float K2Node_CustomEvent_Duration;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct AImmortalHead_BP_C* K2Node_DynamicCast_AsImmortal_Head_BP;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_GetDirectionUnitVector_ReturnValue;  // 0x38(0xC)
	float K2Node_Event_DeltaSeconds;  // 0x44(0x4)
	struct FRotator CallFunc_MakeRotationFromAxes_ReturnValue;  // 0x48(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x54(0x90)

}; 
// Function BP_Tendril.BP_Tendril_C.SetAttachments
// Size: 0x29(Inherited: 0x0) 
struct FSetAttachments
{
	struct AActor* Parent;  // 0x0(0x8)
	struct AActor* Child;  // 0x8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	struct USkeletalMeshComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_Tendril.BP_Tendril_C.Flicker
// Size: 0x4(Inherited: 0x0) 
struct FFlicker
{
	float Duration;  // 0x0(0x4)

}; 
