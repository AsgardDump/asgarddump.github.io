#pragma once 
#include <AICookAndThrowGrenade_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C
// Size: 0x4D1(Inherited: 0x428) 
struct UAICookAndThrowGrenade_GA_C : public UORGameplayAbility_FireItem
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x428(0x8)
	struct UAnimMontage* GrenadeThrowMontage;  // 0x430(0x8)
	char pad_1080_1 : 7;  // 0x438(0x1)
	bool UsesChargeLoop : 1;  // 0x438(0x1)
	char pad_1081[7];  // 0x439(0x7)
	struct UAnimMontage* GrenadeDropMontage;  // 0x440(0x8)
	struct UORWidget_HUDPrompt* WarningWidget;  // 0x448(0x8)
	struct UAkAudioEvent* GrenadeChargeAkEvent;  // 0x450(0x8)
	char pad_1112_1 : 7;  // 0x458(0x1)
	bool HandleGrenadeUsedGE : 1;  // 0x458(0x1)
	char pad_1113_1 : 7;  // 0x459(0x1)
	bool EndAbilityOnMontageCompletion : 1;  // 0x459(0x1)
	char pad_1114[2];  // 0x45A(0x2)
	float ChargeTime;  // 0x45C(0x4)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool CanBeInterrupted : 1;  // 0x460(0x1)
	char pad_1121[3];  // 0x461(0x3)
	float ThrowTime;  // 0x464(0x4)
	struct AActor* TargetActor;  // 0x468(0x8)
	struct FVector LaunchLocation;  // 0x470(0xC)
	struct FVector AimLocation;  // 0x47C(0xC)
	struct FVector EstimatedLaunchVelocity;  // 0x488(0xC)
	char pad_1172[4];  // 0x494(0x4)
	struct TArray<float> ArcSpeedModifiers;  // 0x498(0x10)
	float DefaultLaunchSpeed;  // 0x4A8(0x4)
	float TargetDistanceMultiplier;  // 0x4AC(0x4)
	float OffsetMultiplier;  // 0x4B0(0x4)
	char pad_1204_1 : 7;  // 0x4B4(0x1)
	bool FavorHighArc : 1;  // 0x4B4(0x1)
	char pad_1205[3];  // 0x4B5(0x3)
	int32_t ChargeAkID;  // 0x4B8(0x4)
	char pad_1212_1 : 7;  // 0x4BC(0x1)
	bool BeginFireTriggered : 1;  // 0x4BC(0x1)
	char pad_1213[3];  // 0x4BD(0x3)
	struct UAnimMontage* GrenadeChargeMontage;  // 0x4C0(0x8)
	struct USkeletalMeshComponent* OwnerMesh;  // 0x4C8(0x8)
	char pad_1232_1 : 7;  // 0x4D0(0x1)
	bool ShowWarningWidgetWhileCharging : 1;  // 0x4D0(0x1)

	void SetWarningWidget(bool Enabled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetWarningWidget
	void SetChargeAudioEnabled(bool Enabled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetChargeAudioEnabled
	void OnDamageTaken(struct UObject* Damager, struct AORCharacter* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnDamageTaken
	void SetDamageEventBindEnabled(bool Enabled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetDamageEventBindEnabled
	void GetRandomOffset(int32_t Min, int32_t Max, float& RandomValue); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.GetRandomOffset
	void FindLaunchVelocity(struct FVector& LaunchVelocity); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.FindLaunchVelocity
	void InitializeLaunchVariables(struct AORCharacter* OwningORCharacter); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.InitializeLaunchVariables
	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_CanActivateAbility
	void OnCancelled_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCancelled_BFF2371B49794F08C6D08BABD06E91C9
	void OnInterrupted_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_BFF2371B49794F08C6D08BABD06E91C9
	void OnBlendOut_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_BFF2371B49794F08C6D08BABD06E91C9
	void OnCompleted_BFF2371B49794F08C6D08BABD06E91C9(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_BFF2371B49794F08C6D08BABD06E91C9
	void OnNotifyEnd_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyEnd_CB052D0449732D9E04B5E68488268F05
	void OnNotifyBegin_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyBegin_CB052D0449732D9E04B5E68488268F05
	void OnInterrupted_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_CB052D0449732D9E04B5E68488268F05
	void OnBlendOut_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_CB052D0449732D9E04B5E68488268F05
	void OnCompleted_CB052D0449732D9E04B5E68488268F05(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_CB052D0449732D9E04B5E68488268F05
	void OnNotifyEnd_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyEnd_6B8CF146489C2A5CF4B68380953B270E
	void OnNotifyBegin_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyBegin_6B8CF146489C2A5CF4B68380953B270E
	void OnInterrupted_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_6B8CF146489C2A5CF4B68380953B270E
	void OnBlendOut_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_6B8CF146489C2A5CF4B68380953B270E
	void OnCompleted_6B8CF146489C2A5CF4B68380953B270E(struct FName NotifyName); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_6B8CF146489C2A5CF4B68380953B270E
	void HandleProjectileVelocityOverride(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.HandleProjectileVelocityOverride
	void ThrowGrenade(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ThrowGrenade
	void DropGrenade(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.DropGrenade
	void K2_OnEndAbility(bool bWasCancelled); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_OnEndAbility
	void K2_CommitExecute(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_CommitExecute
	void K2_ActivateAbility(); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_ActivateAbility
	void ThrowMontageNotifyBegin(struct FName Notify Begin); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ThrowMontageNotifyBegin
	void ChargeMontageNotifyBegin(struct FName Notify Begin); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ChargeMontageNotifyBegin
	void ExecuteUbergraph_AICookAndThrowGrenade_GA(int32_t EntryPoint); // Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ExecuteUbergraph_AICookAndThrowGrenade_GA
}; 



