#pragma once 
#include <BTS_UpdateTacticalRetreatLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C
// Size: 0x188(Inherited: 0x98) 
struct UBTS_UpdateTacticalRetreatLocation_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector MoveToLocation;  // 0xA0(0x28)
	struct FBlackboardKeySelector TargetActor;  // 0xC8(0x28)
	struct FBlackboardKeySelector CombatMoveInProgress;  // 0xF0(0x28)
	struct FBlackboardKeySelector AnchorRadius;  // 0x118(0x28)
	struct FBlackboardKeySelector AttractionPointCoverType_Key;  // 0x140(0x28)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool IsQueryRunning : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct UEnvQueryInstanceBlueprintWrapper* RunningEQSQuery;  // 0x170(0x8)
	struct AORAIHenchmanController_BP_C* OwnerAIHenchmanController_Cached;  // 0x178(0x8)
	struct AORAICharacter* ControlledORAICharacter_Cached;  // 0x180(0x8)

	void GetQueryRunningBool(bool& Running); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.GetQueryRunningBool
	void FindGoodAttractLocationForMove(struct AAIController* OwnerController, struct AORAICharacter* ControlledPawn, bool& FoundLocation, struct FVector& NewLocation); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.FindGoodAttractLocationForMove
	void NeedsLocationForTargetDistancing(struct AActor* TargetActor, struct AORAICharacter* ControlledPawn, bool& NeedsPosition); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.NeedsLocationForTargetDistancing
	void NeedsNewRetreatLocation(struct AAIController* OwnerController, struct AORAICharacter* ControlledPawn, bool& NeedsMove); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.NeedsNewRetreatLocation
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.ReceiveTickAI
	void EQS_QueryComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.EQS_QueryComplete
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.ReceiveDeactivationAI
	void ExecuteUbergraph_BTS_UpdateTacticalRetreatLocation(int32_t EntryPoint); // Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.ExecuteUbergraph_BTS_UpdateTacticalRetreatLocation
}; 



