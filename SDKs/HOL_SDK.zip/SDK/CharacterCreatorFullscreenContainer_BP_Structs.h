#pragma once 
#include "SDK.h" 
 
 
// Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.ExecuteUbergraph_CharacterCreatorFullscreenContainer_BP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_CharacterCreatorFullscreenContainer_BP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.OnFocusReceived
// Size: 0x1B0(Inherited: 0xF8) 
struct FOnFocusReceived : public FOnFocusReceived
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FFocusEvent InFocusEvent;  // 0x38(0x8)
	struct FEventReply ReturnValue;  // 0x40(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0xF8(0xB8)

}; 
