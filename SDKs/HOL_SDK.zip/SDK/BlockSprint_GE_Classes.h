#pragma once 
#include <BlockSprint_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockSprint_GE.BlockSprint_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UBlockSprint_GE_C : public UORGameplayEffect
{

}; 



