#pragma once 
#include <Ability_Jump_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_Jump.Ability_Jump_C
// Size: 0x3F8(Inherited: 0x3F8) 
struct UAbility_Jump_C : public UORGameplayAbility_Jump
{

}; 



