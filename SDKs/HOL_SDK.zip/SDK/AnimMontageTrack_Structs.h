#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct AnimMontageTrack.AnimMontageSectionParams
// Size: 0x20(Inherited: 0x0) 
struct FAnimMontageSectionParams
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	float StartOffset;  // 0x8(0x4)
	float PlayRate;  // 0xC(0x4)
	char bPauseOnEnd : 1;  // 0x10(0x1)
	char bReverse : 1;  // 0x10(0x1)
	char pad_16_1 : 6;  // 0x10(0x1)
	char pad_17[4];  // 0x11(0x4)
	float PostTime;  // 0x14(0x4)
	float BlendWeight;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct AnimMontageTrack.AnimMontageSectionTemplate
// Size: 0x88(Inherited: 0x20) 
struct FAnimMontageSectionTemplate : public FMovieSceneEvalTemplate
{
	struct FAnimMontageSectionParams Data;  // 0x20(0x20)
	struct FMovieSceneEasingSettings Easing;  // 0x40(0x38)
	struct TArray<struct TWeakObjectPtr<UObject>> BoundObjects;  // 0x78(0x10)

}; 
