#pragma once 
#include <Ability_UIToggleFreeLook_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_UIToggleFreeLook_BP.Ability_UIToggleFreeLook_BP_C
// Size: 0x3F8(Inherited: 0x3F8) 
struct UAbility_UIToggleFreeLook_BP_C : public UORGameplayAbility_ToggleFreeLook
{

}; 



