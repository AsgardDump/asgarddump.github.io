#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP.Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP_C.GetAimLocation
// Size: 0x50(Inherited: 0x10) 
struct FGetAimLocation : public FGetAimLocation
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bUseAimCorrections : 1;  // 0x0(0x1)
	struct FVector ReturnValue;  // 0x4(0xC)
	struct FName TargetActor_Ability;  // 0x10(0x8)
	struct ACharacter* CallFunc_GetParentCharacter_ReturnValue;  // 0x18(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x20(0x8)
	struct UObject* CallFunc_GetValueAsObject_ReturnValue;  // 0x28(0x8)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x38(0x8)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x44(0xC)

}; 
