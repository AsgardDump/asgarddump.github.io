#pragma once 
#include <Ability_ConversationChoice_2_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_ConversationChoice_2.Ability_ConversationChoice_1_C
// Size: 0x400(Inherited: 0x400) 
struct UAbility_ConversationChoice_1_C : public UORGameplayAbility_ConversationChoice
{

}; 



