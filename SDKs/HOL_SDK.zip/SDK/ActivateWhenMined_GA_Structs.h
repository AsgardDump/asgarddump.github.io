#pragma once 
#include "SDK.h" 
 
 
// Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.ExecuteUbergraph_ActivateWhenMined_GA
// Size: 0xCA(Inherited: 0x0) 
struct FExecuteUbergraph_ActivateWhenMined_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FActiveGameplayEffectHandle K2Node_CustomEvent_ActiveEffectHandle;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct FGameplayEffectSpecHandle K2Node_CustomEvent_EffectSpecHandle;  // 0x10(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x20(0x10)
	struct FGameplayEffectSpecHandle Temp_struct_Variable;  // 0x30(0x10)
	struct FActiveGameplayEffectHandle Temp_struct_Variable_2;  // 0x40(0x8)
	struct FGameplayEffectContextHandle CallFunc_GetEffectContext_ReturnValue;  // 0x48(0x18)
	struct AActor* CallFunc_EffectContextGetEffectCauser_ReturnValue;  // 0x60(0x8)
	struct UAbilitySystemComponent* CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;  // 0x68(0x8)
	struct AProximityMine_BP_C* K2Node_DynamicCast_AsProximity_Mine_BP;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FGameplayTagRequirements K2Node_MakeStruct_GameplayTagRequirements;  // 0x80(0x40)
	struct UORAbilityTask_WaitGameplayEffectApplied* CallFunc_ListenForGameplayEffectApplied_ReturnValue;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_K2_CommitAbility_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC9(0x1)

}; 
// Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.OnEffectApplied_A581AE3145728136C98999BF7C9ECED1
// Size: 0x18(Inherited: 0x0) 
struct FOnEffectApplied_A581AE3145728136C98999BF7C9ECED1
{
	struct FActiveGameplayEffectHandle ActiveEffectHandle;  // 0x0(0x8)
	struct FGameplayEffectSpecHandle EffectSpecHandle;  // 0x8(0x10)

}; 
