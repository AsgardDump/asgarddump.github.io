#pragma once 
#include "SDK.h" 
 
 
// Function Ability_WeaponBash.Ability_WeaponBash_C.BP_OnPlayerMeleeEvent
// Size: 0x8(Inherited: 0x8) 
struct FBP_OnPlayerMeleeEvent : public FBP_OnPlayerMeleeEvent
{
	struct FGameplayTag CurrentMeleeType;  // 0x0(0x8)

}; 
// Function Ability_WeaponBash.Ability_WeaponBash_C.ExecuteUbergraph_Ability_WeaponBash
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_WeaponBash
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct FActiveGameplayEffectHandle CallFunc_ApplyGameplayEffect_ReturnValue;  // 0x10(0x8)
	struct FGameplayTag K2Node_Event_CurrentMeleeType;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_GameplayTag_ReturnValue : 1;  // 0x20(0x1)

}; 
