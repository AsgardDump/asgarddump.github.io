#pragma once 
#include <Chonk_ABP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass Chonk_ABP.Chonk_ABP_C
// Size: 0x3EA8(Inherited: 0x880) 
struct UChonk_ABP_C : public UOR3PAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x880(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x888(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x8B8(0x28)
	struct FAnimNode_PoseSnapshot AnimGraphNode_PoseSnapshot;  // 0x8E0(0x90)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x970(0x30)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_7;  // 0x9A0(0xA0)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3;  // 0xA40(0xE8)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_6;  // 0xB28(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_14;  // 0xBC8(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_5;  // 0xC48(0xA0)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2;  // 0xCE8(0xE8)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0xDD0(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0xEB8(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0xEE8(0xB0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_12;  // 0xF98(0x158)
	struct FAnimNode_Slot AnimGraphNode_Slot_7;  // 0x10F0(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_11;  // 0x1138(0x158)
	struct FAnimNode_Slot AnimGraphNode_Slot_6;  // 0x1290(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_10;  // 0x12D8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_20;  // 0x1430(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x1458(0x20)
	char pad_5240[8];  // 0x1478(0x8)
	struct FAnimNode_LookAt AnimGraphNode_LookAt;  // 0x1480(0x1B0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_19;  // 0x1630(0x28)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x1658(0x20)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_4;  // 0x1678(0xA0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_9;  // 0x1718(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_18;  // 0x1870(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_17;  // 0x1898(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_5;  // 0x18C0(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_5;  // 0x1908(0xC0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_8;  // 0x19C8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_16;  // 0x1B20(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_4;  // 0x1B48(0xC0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_15;  // 0x1C08(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_4;  // 0x1C30(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_7;  // 0x1C78(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_14;  // 0x1DD0(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // 0x1DF8(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_6;  // 0x1E40(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_13;  // 0x1F98(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_12;  // 0x1FC0(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x1FE8(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_11;  // 0x2088(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_5;  // 0x20B0(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_10;  // 0x2208(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x2230(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_9;  // 0x2278(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3;  // 0x22A0(0xC0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_8;  // 0x2360(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // 0x2388(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7;  // 0x24E0(0x28)
	struct FAnimNode_SquanchDismember AnimGraphNode_SquanchDismember;  // 0x2508(0xD0)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x25D8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x25F8(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x2618(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x2720(0x108)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0x2828(0x158)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x2980(0xC0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6;  // 0x2A40(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // 0x2A68(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2A90(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x2AD8(0xC0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x2B98(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x2CF0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x2D18(0x28)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x2D40(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x2DE0(0x28)
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // 0x2E08(0xB0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x2EB8(0x158)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_13;  // 0x3010(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_12;  // 0x3090(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11;  // 0x3110(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10;  // 0x3190(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9;  // 0x3210(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8;  // 0x3290(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7;  // 0x3310(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0x3390(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0x3410(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x3490(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x3510(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3590(0x80)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x3610(0x80)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x3690(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x3730(0x28)
	char pad_14168[8];  // 0x3758(0x8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // 0x3760(0x1E0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // 0x3940(0x1E0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x3B20(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x3C28(0x108)
	char pad_15664_1 : 7;  // 0x3D30(0x1)
	bool IsDead : 1;  // 0x3D30(0x1)
	char pad_15665_1 : 7;  // 0x3D31(0x1)
	bool IsAlerted : 1;  // 0x3D31(0x1)
	char pad_15666[2];  // 0x3D32(0x2)
	float TotalSpeed_1;  // 0x3D34(0x4)
	float ForwardSpeed_1;  // 0x3D38(0x4)
	float SideSpeed_1;  // 0x3D3C(0x4)
	float VerticalSpeed_1;  // 0x3D40(0x4)
	char pad_15684[4];  // 0x3D44(0x4)
	struct TArray<struct UAnimMontage*> SmallHitFlinchs_All;  // 0x3D48(0x10)
	struct TArray<struct UAnimMontage*> SmallHitFlinchs_Front;  // 0x3D58(0x10)
	struct TArray<struct UAnimMontage*> SmallHitFlinchs_Back;  // 0x3D68(0x10)
	struct TArray<struct UAnimMontage*> SmallHitFlinchs_Right;  // 0x3D78(0x10)
	struct TArray<struct UAnimMontage*> SmallHitFlinchs_Left;  // 0x3D88(0x10)
	struct TArray<struct UAnimMontage*> MediumHitFlinchs_All;  // 0x3D98(0x10)
	struct TArray<struct UAnimMontage*> MediumHitFlinchs_Front;  // 0x3DA8(0x10)
	struct TArray<struct UAnimMontage*> MediumHitFlinchs_Back;  // 0x3DB8(0x10)
	struct TArray<struct UAnimMontage*> MediumHitFlinchs_Right;  // 0x3DC8(0x10)
	struct TArray<struct UAnimMontage*> MediumHitFlinchs_Left;  // 0x3DD8(0x10)
	struct TArray<struct UAnimMontage*> Deaths_All;  // 0x3DE8(0x10)
	struct TArray<struct UAnimMontage*> HeavyHitFlinchs_All;  // 0x3DF8(0x10)
	struct TArray<struct UAnimMontage*> Deaths_Front;  // 0x3E08(0x10)
	struct TArray<struct UAnimMontage*> Deaths_Back;  // 0x3E18(0x10)
	struct TArray<struct UAnimMontage*> Deaths_Right;  // 0x3E28(0x10)
	struct TArray<struct UAnimMontage*> Deaths_Left;  // 0x3E38(0x10)
	struct FRotator LastFrameRotation;  // 0x3E48(0xC)
	float CurrentRotationAngularSpeed;  // 0x3E54(0x4)
	struct FGameplayTag HitReactImmunityTag;  // 0x3E58(0x8)
	struct USQDismemberComponent* CachedSQDismember;  // 0x3E60(0x8)
	struct FVector LookTargetLocation;  // 0x3E68(0xC)
	char pad_15988_1 : 7;  // 0x3E74(0x1)
	bool HasLookAt : 1;  // 0x3E74(0x1)
	char pad_15989_1 : 7;  // 0x3E75(0x1)
	bool IsTotalSpeedPositive : 1;  // 0x3E75(0x1)
	char pad_15990_1 : 7;  // 0x3E76(0x1)
	bool IsUsingIdleOverride : 1;  // 0x3E76(0x1)
	char pad_15991_1 : 7;  // 0x3E77(0x1)
	bool IsTotalSpeedLarge : 1;  // 0x3E77(0x1)
	struct AChonk_BP_C* ChonkBP;  // 0x3E78(0x8)
	struct FGameplayTagContainer TriggerDeathAnimTags;  // 0x3E80(0x20)
	struct UAnimMontage* DeepCutHitReact;  // 0x3EA0(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function Chonk_ABP.Chonk_ABP_C.AnimGraph
	void CacheDismemberComponent(); // Function Chonk_ABP.Chonk_ABP_C.CacheDismemberComponent
	void IsHitReactImmune(bool& IsImmune); // Function Chonk_ABP.Chonk_ABP_C.IsHitReactImmune
	void SetControllerBBHitReactionDuration(float HitReactDuration); // Function Chonk_ABP.Chonk_ABP_C.SetControllerBBHitReactionDuration
	void UpdateYawAngularRotationSpeed(float DeltaTime); // Function Chonk_ABP.Chonk_ABP_C.UpdateYawAngularRotationSpeed
	void ORControllerAllowFlinchHitReacts(bool& bAllowFlinchHitReacts); // Function Chonk_ABP.Chonk_ABP_C.ORControllerAllowFlinchHitReacts
	void UpdateIsAlerted(); // Function Chonk_ABP.Chonk_ABP_C.UpdateIsAlerted
	void PlayMontageAndUpdateBBForFlinchHit_Medium(struct FHitResult& HitResult); // Function Chonk_ABP.Chonk_ABP_C.PlayMontageAndUpdateBBForFlinchHit_Medium
	void PlayMontageForFlinchHit_Small(struct FHitResult& HitResult); // Function Chonk_ABP.Chonk_ABP_C.PlayMontageForFlinchHit_Small
	void OwnerEventDamageTaken(struct FHitResult& HitResult, struct FGameplayTagContainer& TagContainer); // Function Chonk_ABP.Chonk_ABP_C.OwnerEventDamageTaken
	void ItemEventFired(struct ASQInventoryItem* Item, struct FGameplayTag EventTag, struct FGameplayTag FireModeTag); // Function Chonk_ABP.Chonk_ABP_C.ItemEventFired
	void OwnerDiedEvent(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function Chonk_ABP.Chonk_ABP_C.OwnerDiedEvent
	void UpdateWalkBSValues(); // Function Chonk_ABP.Chonk_ABP_C.UpdateWalkBSValues
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function Chonk_ABP.Chonk_ABP_C.BlueprintUpdateAnimation
	void K2_OwnerDiedEventFired(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function Chonk_ABP.Chonk_ABP_C.K2_OwnerDiedEventFired
	void K2_OwnerItemEventFired(struct ASQInventoryItem* Item, struct FGameplayTag EventTag, struct FGameplayTag FireModeTag, char EInventoryTransactionType TransactionType); // Function Chonk_ABP.Chonk_ABP_C.K2_OwnerItemEventFired
	void K2_OwnerDamageTakenEventFired(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function Chonk_ABP.Chonk_ABP_C.K2_OwnerDamageTakenEventFired
	void ForceHitReact(struct FHitResult HitResult, struct FGameplayTagContainer HitReactTag); // Function Chonk_ABP.Chonk_ABP_C.ForceHitReact
	void K2_OwnerSpawnedFromPool(); // Function Chonk_ABP.Chonk_ABP_C.K2_OwnerSpawnedFromPool
	void BlueprintInitializeAnimation(); // Function Chonk_ABP.Chonk_ABP_C.BlueprintInitializeAnimation
	void ExecuteUbergraph_Chonk_ABP(int32_t EntryPoint); // Function Chonk_ABP.Chonk_ABP_C.ExecuteUbergraph_Chonk_ABP
}; 



