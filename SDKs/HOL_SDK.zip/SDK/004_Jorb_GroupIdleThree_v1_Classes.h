#pragma once 
#include <004_Jorb_GroupIdleThree_v1_Structs.h>
 
 
 
// BlueprintGeneratedClass 004_Jorb_GroupIdleThree_v1.SequenceDirector_C
// Size: 0x40(Inherited: 0x38) 
struct USequenceDirector_C : public ULevelSequenceDirector
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void Jorb_BP_Event_1(struct AJorb_BP_C* Jorb_BP, struct UAnimSequence* Anim); // Function 004_Jorb_GroupIdleThree_v1.SequenceDirector_C.Jorb_BP_Event_1
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function 004_Jorb_GroupIdleThree_v1.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
}; 



