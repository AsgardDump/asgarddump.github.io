#pragma once 
#include <BTD_Merk_Melee_Trigger_Reload_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_Merk_Melee_Trigger_Reload.BTD_Merk_Melee_Trigger_Reload_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_Merk_Melee_Trigger_Reload_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_Merk_Melee_Trigger_Reload.BTD_Merk_Melee_Trigger_Reload_C.PerformConditionCheckAI
}; 



