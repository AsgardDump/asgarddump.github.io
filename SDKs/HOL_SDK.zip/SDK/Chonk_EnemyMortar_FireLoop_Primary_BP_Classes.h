#pragma once 
#include <Chonk_EnemyMortar_FireLoop_Primary_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_EnemyMortar_FireLoop_Primary_BP.Chonk_EnemyMortar_FireLoop_Primary_BP_C
// Size: 0x135(Inherited: 0x135) 
struct UChonk_EnemyMortar_FireLoop_Primary_BP_C : public UORTestEnemyWeapons_FireLoop_C
{

}; 



