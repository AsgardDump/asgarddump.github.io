#pragma once 
#include <CancelPlayerSprint_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass CancelPlayerSprint_GA.CancelPlayerSprint_GA_C
// Size: 0x400(Inherited: 0x3F8) 
struct UCancelPlayerSprint_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)

	void K2_ActivateAbility(); // Function CancelPlayerSprint_GA.CancelPlayerSprint_GA_C.K2_ActivateAbility
	void ExecuteUbergraph_CancelPlayerSprint_GA(int32_t EntryPoint); // Function CancelPlayerSprint_GA.CancelPlayerSprint_GA_C.ExecuteUbergraph_CancelPlayerSprint_GA
}; 



