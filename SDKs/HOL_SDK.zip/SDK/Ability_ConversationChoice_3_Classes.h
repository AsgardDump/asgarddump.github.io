#pragma once 
#include <Ability_ConversationChoice_3_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_ConversationChoice_3.Ability_ConversationChoice_2_C
// Size: 0x400(Inherited: 0x400) 
struct UAbility_ConversationChoice_2_C : public UORGameplayAbility_ConversationChoice
{

}; 



