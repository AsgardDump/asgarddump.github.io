#pragma once 
#include "SDK.h" 
 
 
// Function BTT_LogValues.BTT_LogValues_C.ExecuteUbergraph_BTT_LogValues
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_BTT_LogValues
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* K2Node_Event_OwnerActor;  // 0x8(0x8)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x10(0x8)
	struct FString CallFunc_GetSelectorKeyValueAsString_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x38(0x10)

}; 
// Function BTT_LogValues.BTT_LogValues_C.ReceiveExecute
// Size: 0x8(Inherited: 0x8) 
struct FReceiveExecute : public FReceiveExecute
{
	struct AActor* OwnerActor;  // 0x0(0x8)

}; 
