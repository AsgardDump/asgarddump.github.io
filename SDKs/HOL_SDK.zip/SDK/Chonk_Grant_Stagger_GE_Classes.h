#pragma once 
#include <Chonk_Grant_Stagger_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_Grant_Stagger_GE.Chonk_Grant_Stagger_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UChonk_Grant_Stagger_GE_C : public UORGameplayEffect
{

}; 



