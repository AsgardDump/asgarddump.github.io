#pragma once 
#include <Chonk_FeetLanding_CameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_FeetLanding_CameraShake.Chonk_FeetLanding_CameraShake_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UChonk_FeetLanding_CameraShake_C : public UMatineeCameraShake
{

}; 



