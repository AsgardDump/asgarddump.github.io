#pragma once 
#include "SDK.h" 
 
 
// Function Ability_EquipWeaponSlot5.Ability_EquipWeaponSlot5_C.ExecuteUbergraph_Ability_EquipWeaponSlot5
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_EquipWeaponSlot5
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x4(0x1)

}; 
// Function Ability_EquipWeaponSlot5.Ability_EquipWeaponSlot5_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
