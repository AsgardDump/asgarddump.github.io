#pragma once 
#include <AbilityAmmoPickup_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AbilityAmmoPickup_BP.AbilityAmmoPickup_BP_C
// Size: 0x2D8(Inherited: 0x2D8) 
struct AAbilityAmmoPickup_BP_C : public AORAmmoPickup
{

}; 



