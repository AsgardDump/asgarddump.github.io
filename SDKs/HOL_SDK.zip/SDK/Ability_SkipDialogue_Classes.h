#pragma once 
#include <Ability_SkipDialogue_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_SkipDialogue.Ability_SkipDialogue_C
// Size: 0x408(Inherited: 0x3F8) 
struct UAbility_SkipDialogue_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)
	struct FTimerHandle SkipTimer;  // 0x400(0x8)

	void K2_ActivateAbility(); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.K2_ActivateAbility
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.K2_OnEndAbility
	void FireSkip(); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.FireSkip
	void ExecuteUbergraph_Ability_SkipDialogue(int32_t EntryPoint); // Function Ability_SkipDialogue.Ability_SkipDialogue_C.ExecuteUbergraph_Ability_SkipDialogue
}; 



