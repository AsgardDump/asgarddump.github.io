#pragma once 
#include <BlockSuitAbility_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockSuitAbility_GE.BlockSuitAbility_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UBlockSuitAbility_GE_C : public UORGameplayEffect
{

}; 



