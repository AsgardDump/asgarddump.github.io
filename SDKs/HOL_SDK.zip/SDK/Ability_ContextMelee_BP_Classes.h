#pragma once 
#include <Ability_ContextMelee_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_ContextMelee_BP.Ability_ContextMelee_BP_C
// Size: 0x408(Inherited: 0x408) 
struct UAbility_ContextMelee_BP_C : public UORGameplayAbility_AbilityContextSwapping
{

}; 



