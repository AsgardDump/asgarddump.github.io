#pragma once 
#include <Chonk_HealthTank_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_HealthTank_BP.Chonk_HealthTank_BP_C
// Size: 0x338(Inherited: 0x330) 
struct AChonk_HealthTank_BP_C : public AORHealthTankItem
{
	struct USceneComponent* DefaultSceneRoot;  // 0x330(0x8)

}; 



