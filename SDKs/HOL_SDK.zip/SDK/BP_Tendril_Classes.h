#pragma once 
#include <BP_Tendril_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Tendril.BP_Tendril_C
// Size: 0x269(Inherited: 0x220) 
struct ABP_Tendril_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UNiagaraComponent* NI_Tendril;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float FlickerTimeline_BeamWidth_B99E267149B9AF9EFEE19AAB97F12C57;  // 0x238(0x4)
	char ETimelineDirection FlickerTimeline__Direction_B99E267149B9AF9EFEE19AAB97F12C57;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* FlickerTimeline;  // 0x240(0x8)
	struct AActor* ParentAttachment;  // 0x248(0x8)
	struct AActor* ChildAttachment;  // 0x250(0x8)
	struct UNiagaraComponent* TendrilParticles;  // 0x258(0x8)
	struct FTimerHandle FlickerTimerHandle;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool IsFlickering : 1;  // 0x268(0x1)

	void SetAttachments(struct AActor* Parent, struct AActor* Child); // Function BP_Tendril.BP_Tendril_C.SetAttachments
	void FlickerTimeline__FinishedFunc(); // Function BP_Tendril.BP_Tendril_C.FlickerTimeline__FinishedFunc
	void FlickerTimeline__UpdateFunc(); // Function BP_Tendril.BP_Tendril_C.FlickerTimeline__UpdateFunc
	void StopFlicker(); // Function BP_Tendril.BP_Tendril_C.StopFlicker
	void Flicker(float Duration); // Function BP_Tendril.BP_Tendril_C.Flicker
	void SetThin(); // Function BP_Tendril.BP_Tendril_C.SetThin
	void ReceiveTick(float DeltaSeconds); // Function BP_Tendril.BP_Tendril_C.ReceiveTick
	void ExecuteUbergraph_BP_Tendril(int32_t EntryPoint); // Function BP_Tendril.BP_Tendril_C.ExecuteUbergraph_BP_Tendril
}; 



