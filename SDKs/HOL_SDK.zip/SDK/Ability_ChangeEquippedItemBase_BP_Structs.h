#pragma once 
#include "SDK.h" 
 
 
// Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.ExecuteUbergraph_Ability_ChangeEquippedItemBase_BP
// Size: 0x1A(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_ChangeEquippedItemBase_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AORPlayerCharacter* K2Node_DynamicCast_AsORPlayer_Character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsAbilitySlotActive_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.GetOwningInventory
// Size: 0x29(Inherited: 0x0) 
struct FGetOwningInventory
{
	struct UORPlayerInventory* OutInventory;  // 0x0(0x8)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AORPlayerCharacter* K2Node_DynamicCast_AsORPlayer_Character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UORPlayerInventory* K2Node_DynamicCast_AsORPlayer_Inventory;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x28(0x1)

}; 
// Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.K2_CanActivateAbility
// Size: 0xAC(Inherited: 0x78) 
struct FK2_CanActivateAbility : public FK2_CanActivateAbility
{
	struct FGameplayAbilityActorInfo ActorInfo;  // 0x0(0x48)
	struct FGameplayAbilitySpecHandle Handle;  // 0x48(0x4)
	struct FGameplayTagContainer RelevantTags;  // 0x50(0x20)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x78(0x8)
	struct APlayerCharacter_BP_C* K2Node_DynamicCast_AsPlayer_Character_BP;  // 0x80(0x8)
	char pad_245_1 : 7;  // 0xF5(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x90(0x8)
	char pad_254_1 : 7;  // 0xFE(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x98(0x1)
	struct UOR1PAnimInstance* K2Node_DynamicCast_AsOR1PAnim_Instance;  // 0xA0(0x8)
	char pad_263_1 : 7;  // 0x107(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA8(0x1)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_IsTetherPulling_ReturnValue : 1;  // 0xA9(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0xAA(0x1)
	char pad_266_1 : 7;  // 0x10A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xAB(0x1)

}; 
