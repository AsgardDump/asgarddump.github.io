#pragma once 
#include <CanUseAbility_PrimaryFire_Structs.h>
 
 
 
// BlueprintGeneratedClass CanUseAbility_PrimaryFire.CanUseAbility_PrimaryFire_C
// Size: 0xC8(Inherited: 0xC8) 
struct UCanUseAbility_PrimaryFire_C : public UUtilityConsideration
{

}; 



