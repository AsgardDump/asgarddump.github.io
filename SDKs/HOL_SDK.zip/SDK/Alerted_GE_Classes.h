#pragma once 
#include <Alerted_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass Alerted_GE.Alerted_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UAlerted_GE_C : public UORGameplayEffect
{

}; 



