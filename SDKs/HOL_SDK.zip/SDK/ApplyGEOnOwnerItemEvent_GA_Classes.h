#pragma once 
#include <ApplyGEOnOwnerItemEvent_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C
// Size: 0x420(Inherited: 0x3F8) 
struct UApplyGEOnOwnerItemEvent_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)
	struct ASQInventoryItem* OwnerSQInventoryItem;  // 0x400(0x8)
	UGameplayEffect* GEToApply;  // 0x408(0x8)
	struct FGameplayTag EventTag;  // 0x410(0x8)
	struct FGameplayTag FireModeTag;  // 0x418(0x8)

	void OnItemEvent(struct ASQInventoryItem* Item, struct FGameplayTag EventTag, struct FGameplayTag FireMode, char EInventoryTransactionType TransactionType); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.OnItemEvent
	void K2_OnEndAbility(bool bWasCancelled); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.K2_OnEndAbility
	void K2_ActivateAbility(); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.K2_ActivateAbility
	void ExecuteUbergraph_ApplyGEOnOwnerItemEvent_GA(int32_t EntryPoint); // Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.ExecuteUbergraph_ApplyGEOnOwnerItemEvent_GA
}; 



