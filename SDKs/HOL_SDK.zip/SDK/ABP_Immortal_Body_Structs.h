#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Immortal_Body.ABP_Immortal_Body_C.ExecuteUbergraph_ABP_Immortal_Body
// Size: 0x201(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Immortal_Body
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector Temp_struct_Variable;  // 0x4(0xC)
	struct FVector Temp_struct_Variable_2;  // 0x10(0xC)
	struct FVector Temp_struct_Variable_3;  // 0x1C(0xC)
	struct FVector Temp_struct_Variable_4;  // 0x28(0xC)
	float K2Node_Event_DeltaTimeX;  // 0x34(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x38(0x8)
	struct AImmortalHead_BP_C* K2Node_DynamicCast_AsImmortal_Head_BP;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct ABP_Immortal_C* K2Node_DynamicCast_AsBP_Immortal;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UObject* K2Node_Event_Killer;  // 0x60(0x8)
	struct FHitResult K2Node_Event_HitResult_2;  // 0x68(0x90)
	struct FGameplayTagContainer K2Node_Event_DamageTags_2;  // 0xF8(0x20)
	struct UObject* K2Node_Event_Damager;  // 0x118(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0x120(0x90)
	float K2Node_Event_Damage;  // 0x1B0(0x4)
	char pad_436[4];  // 0x1B4(0x4)
	struct FGameplayTagContainer K2Node_Event_DamageTags;  // 0x1B8(0x20)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue_2;  // 0x1D8(0x8)
	struct AImmortalHead_BP_C* K2Node_DynamicCast_AsImmortal_Head_BP_2;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1E8(0x1)
	char pad_489[7];  // 0x1E9(0x7)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x1F0(0x8)
	struct AORDetachedMemberGib_C* K2Node_DynamicCast_AsORDetached_Member_Gib;  // 0x1F8(0x8)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x200(0x1)

}; 
// Function ABP_Immortal_Body.ABP_Immortal_Body_C.HandleHitReacts
// Size: 0xB0(Inherited: 0x0) 
struct FHandleHitReacts
{
	struct FHitResult HitResult;  // 0x0(0x90)
	struct UAnimMontage* MontageToPlay;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	float CallFunc_Montage_Play_ReturnValue;  // 0x9C(0x4)
	struct UAnimMontage* CallFunc_PickRandomMontageForHitResultDirection2D_ReturnValue;  // 0xA0(0x8)
	struct UAnimMontage* CallFunc_PickRandomMontageForHitResultDirection2D_ReturnValue_2;  // 0xA8(0x8)

}; 
// Function ABP_Immortal_Body.ABP_Immortal_Body_C.K2_OwnerDamageTakenEventFired
// Size: 0xC0(Inherited: 0xC0) 
struct FK2_OwnerDamageTakenEventFired : public FK2_OwnerDamageTakenEventFired
{
	struct UObject* Damager;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	float Damage;  // 0x98(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA0(0x20)

}; 
// Function ABP_Immortal_Body.ABP_Immortal_Body_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_Immortal_Body.ABP_Immortal_Body_C.K2_OwnerDiedEventFired
// Size: 0xB8(Inherited: 0xB8) 
struct FK2_OwnerDiedEventFired : public FK2_OwnerDiedEventFired
{
	struct UObject* Killer;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	struct FGameplayTagContainer DamageTags;  // 0x98(0x20)

}; 
// Function ABP_Immortal_Body.ABP_Immortal_Body_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
