#pragma once 
#include "SDK.h" 
 
 
// Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.ExecuteUbergraph_Boss_Intro_Sequence_Text_Widget
// Size: 0x181(Inherited: 0x0) 
struct FExecuteUbergraph_Boss_Intro_Sequence_Text_Widget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UOverlaySlot* K2Node_DynamicCast_AsOverlay_Slot;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char EHorizontalAlignment Temp_byte_Variable;  // 0x11(0x1)
	char EHorizontalAlignment Temp_byte_Variable_2;  // 0x12(0x1)
	char pad_19[1];  // 0x13(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x24(0x10)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x38(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x3C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x40(0x10)
	struct FText K2Node_CustomEvent_BossName;  // 0x50(0x18)
	struct UMaterialInstanceDynamic* CallFunc_GetEffectMaterial_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct TArray<float> CallFunc_Map_Values_Values;  // 0x78(0x10)
	float CallFunc_Array_Get_Item;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys;  // 0x90(0x10)
	struct FName CallFunc_Array_Get_Item_2;  // 0xA0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	struct UMaterialInstanceDynamic* CallFunc_GetEffectMaterial_ReturnValue_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct TArray<float> CallFunc_Map_Values_Values_2;  // 0xC0(0x10)
	float CallFunc_Array_Get_Item_3;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys_2;  // 0xD8(0x10)
	struct FName CallFunc_Array_Get_Item_4;  // 0xE8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	struct UUMGSequencePlayer* CallFunc_CreatePlayAnimationProxyObject_Result;  // 0xF8(0x8)
	struct UWidgetAnimationPlayCallbackProxy* CallFunc_CreatePlayAnimationProxyObject_ReturnValue;  // 0x100(0x8)
	struct FName K2Node_CustomEvent_CharacterRowName;  // 0x108(0x8)
	struct FCharacterInfoDataStruct CallFunc_GetDataTableRowFromName_OutRow;  // 0x110(0x20)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x131(0x1)
	char EHorizontalAlignment K2Node_Select_Default;  // 0x132(0x1)
	char pad_307[5];  // 0x133(0x5)
	struct UUMGSequencePlayer* CallFunc_CreatePlayAnimationProxyObject_Result_2;  // 0x138(0x8)
	struct UWidgetAnimationPlayCallbackProxy* CallFunc_CreatePlayAnimationProxyObject_ReturnValue_2;  // 0x140(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationForward_ReturnValue;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct UOverlaySlot* K2Node_DynamicCast_AsOverlay_Slot_2;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x160(0x1)
	char pad_353[7];  // 0x161(0x7)
	struct UOverlaySlot* K2Node_DynamicCast_AsOverlay_Slot_3;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct UOverlaySlot* K2Node_DynamicCast_AsOverlay_Slot_4;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x180(0x1)

}; 
// Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.ShowCharacterIntroText
// Size: 0x8(Inherited: 0x0) 
struct FShowCharacterIntroText
{
	struct FName CharacterRowName;  // 0x0(0x8)

}; 
// Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.SetBossInfo
// Size: 0x18(Inherited: 0x0) 
struct FSetBossInfo
{
	struct FText BossName;  // 0x0(0x18)

}; 
