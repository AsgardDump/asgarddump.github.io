#pragma once 
#include <BlockWeaponSwap_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockWeaponSwap_GE.BlockWeaponSwap_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UBlockWeaponSwap_GE_C : public UORGameplayEffect
{

}; 



