#pragma once 
#include <Ability_AIMerkSmgPrimaryLowAccuracyFire_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_AIMerkSmgPrimaryLowAccuracyFire_BP.Ability_AIMerkSmgPrimaryLowAccuracyFire_BP_C
// Size: 0x428(Inherited: 0x428) 
struct UAbility_AIMerkSmgPrimaryLowAccuracyFire_BP_C : public UORGameplayAbility_FireItem
{

}; 



