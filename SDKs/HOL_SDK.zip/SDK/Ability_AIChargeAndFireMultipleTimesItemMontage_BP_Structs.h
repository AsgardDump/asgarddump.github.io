#pragma once 
#include "SDK.h" 
 
 
// Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.ExecuteUbergraph_Ability_AIChargeAndFireMultipleTimesItemMontage_BP
// Size: 0xA0(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_AIChargeAndFireMultipleTimesItemMontage_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x34(0x10)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x48(0x10)
	struct UAbilityTask_PlayMontageAndWait* CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_K2_CommitAbility_ReturnValue : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct UORFireLoop_Enemy* CallFunc_GetFireloopComponent_FireloopComponent;  // 0x68(0x8)
	float CallFunc_GetDifficultyFloat_ReturnValue;  // 0x70(0x4)
	float CallFunc_GetDifficultyFloat_ReturnValue_2;  // 0x74(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x84(0x10)
	char pad_148[4];  // 0x94(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0x98(0x8)

}; 
// Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.GetFireLoopComponent
// Size: 0x29(Inherited: 0x0) 
struct FGetFireLoopComponent
{
	struct UORFireLoop_Enemy* FireloopComponent;  // 0x0(0x8)
	struct ASQFireableInventoryItem* CallFunc_GetFireableItem_ReturnValue;  // 0x8(0x8)
	struct FGameplayTag CallFunc_GetFireModeTag_ReturnValue;  // 0x10(0x8)
	struct USQFireLoopComponent* CallFunc_GetFireLoopComponent_ReturnValue;  // 0x18(0x8)
	struct UORFireLoop_Enemy* K2Node_DynamicCast_AsORFire_Loop_Enemy;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
