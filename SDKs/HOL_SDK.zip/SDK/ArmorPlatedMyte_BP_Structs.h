#pragma once 
#include "SDK.h" 
 
 
// Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.SetupDynamicMaterialInstances
// Size: 0x40(Inherited: 0x44) 
struct FSetupDynamicMaterialInstances : public FSetupDynamicMaterialInstances
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x10(0x10)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x30(0x8)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x3C(0x4)

}; 
// Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.UpdateHeadHitzone
// Size: 0x1(Inherited: 0x1) 
struct FUpdateHeadHitzone : public FUpdateHeadHitzone
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Enabled : 1;  // 0x0(0x1)

}; 
// Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.OnDied
// Size: 0xB8(Inherited: 0xB8) 
struct FOnDied : public FOnDied
{
	struct UObject* Killer;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	struct FGameplayTagContainer DamageTags;  // 0x98(0x20)

}; 
// Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.ExecuteUbergraph_ArmorPlatedMyte_BP
// Size: 0xC0(Inherited: 0x0) 
struct FExecuteUbergraph_ArmorPlatedMyte_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsArmored_Armored : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UObject* K2Node_Event_Killer;  // 0x8(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0x10(0x90)
	struct FGameplayTagContainer K2Node_Event_DamageTags;  // 0xA0(0x20)

}; 
// Function ArmorPlatedMyte_BP.ArmorPlatedMyte_BP_C.IsArmored
// Size: 0x1(Inherited: 0x0) 
struct FIsArmored
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Armored : 1;  // 0x0(0x1)

}; 
