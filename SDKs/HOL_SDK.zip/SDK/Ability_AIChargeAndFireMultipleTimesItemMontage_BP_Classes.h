#pragma once 
#include <Ability_AIChargeAndFireMultipleTimesItemMontage_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C
// Size: 0x468(Inherited: 0x428) 
struct UAbility_AIChargeAndFireMultipleTimesItemMontage_BP_C : public UORGameplayAbility_FireItem
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x428(0x8)
	struct UAnimMontage* FiringMontage;  // 0x430(0x8)
	struct FName StartSectionName;  // 0x438(0x8)
	struct FName FiringSectionName;  // 0x440(0x8)
	struct FName LastShotSectionName;  // 0x448(0x8)
	struct UORFireLoop_Enemy* Fireloop Component;  // 0x450(0x8)
	struct FTimerHandle InitialDelayTimerHandle;  // 0x458(0x8)
	struct FTimerHandle FireRateTiming;  // 0x460(0x8)

	void GetFireLoopComponent(struct UORFireLoop_Enemy*& FireloopComponent); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.GetFireLoopComponent
	void OnCancelled_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnCancelled_48D23F304AF0142EF325D88D9B4A6042
	void OnInterrupted_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnInterrupted_48D23F304AF0142EF325D88D9B4A6042
	void OnBlendOut_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnBlendOut_48D23F304AF0142EF325D88D9B4A6042
	void OnCompleted_48D23F304AF0142EF325D88D9B4A6042(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.OnCompleted_48D23F304AF0142EF325D88D9B4A6042
	void K2_ActivateAbility(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.K2_ActivateAbility
	void K2_CommitExecute(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.K2_CommitExecute
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.K2_OnEndAbility
	void InitialDelayTrigger(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.InitialDelayTrigger
	void TimerLoopTriggerShots(); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.TimerLoopTriggerShots
	void ExecuteUbergraph_Ability_AIChargeAndFireMultipleTimesItemMontage_BP(int32_t EntryPoint); // Function Ability_AIChargeAndFireMultipleTimesItemMontage_BP.Ability_AIChargeAndFireMultipleTimesItemMontage_BP_C.ExecuteUbergraph_Ability_AIChargeAndFireMultipleTimesItemMontage_BP
}; 



