#pragma once 
#include "SDK.h" 
 
 
// Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.ExecuteUbergraph_ApplyGEFromOwnerTagStatus_GA
// Size: 0xA0(Inherited: 0x0) 
struct FExecuteUbergraph_ApplyGEFromOwnerTagStatus_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x34(0x10)
	char pad_68[4];  // 0x44(0x4)
	struct UAbilityTask_WaitGameplayTagAdded* CallFunc_WaitGameplayTagAdd_ReturnValue;  // 0x48(0x8)
	struct UAbilityTask_WaitGameplayTagRemoved* CallFunc_WaitGameplayTagRemove_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue;  // 0x70(0x8)
	int32_t CallFunc_RemoveGameplayEffects_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FGameplayEffectContextHandle K2Node_MakeStruct_GameplayEffectContextHandle;  // 0x80(0x18)
	struct FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToSelf_ReturnValue;  // 0x98(0x8)

}; 
// Function ApplyGEFromOwnerTagStatus_GA.ApplyGEFromOwnerTagStatus_GA_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
