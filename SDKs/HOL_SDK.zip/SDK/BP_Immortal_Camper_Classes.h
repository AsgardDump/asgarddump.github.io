#pragma once 
#include <BP_Immortal_Camper_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Immortal_Camper.BP_Immortal_Camper_C
// Size: 0x242C(Inherited: 0x242C) 
struct ABP_Immortal_Camper_C : public ABP_Immortal_C
{

}; 



