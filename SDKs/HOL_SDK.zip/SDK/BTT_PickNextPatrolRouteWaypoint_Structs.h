#pragma once 
#include "SDK.h" 
 
 
// Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.ExecuteUbergraph_BTT_PickNextPatrolRouteWaypoint
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_BTT_PickNextPatrolRouteWaypoint
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_HandleReceiveExecuteAI_Success : 1;  // 0x18(0x1)

}; 
// Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.HandleReceiveExecuteAI
// Size: 0x72(Inherited: 0x0) 
struct FHandleReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Success : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FORPatrolWaypoint WaypointDataCopy;  // 0x18(0x10)
	struct AORPatrolRoute* PatrolRoute;  // 0x28(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AORPatrolRoute* CallFunc_GetAssignedPatrolRoute_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_GetNextIncrementingWaypointIndexAndWaypointData_NextWaypointIndex;  // 0x4C(0x4)
	struct FORPatrolWaypoint CallFunc_GetNextIncrementingWaypointIndexAndWaypointData_NextWaypointDataCopy;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_GetNextIncrementingWaypointIndexAndWaypointData_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x64(0xC)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x71(0x1)

}; 
