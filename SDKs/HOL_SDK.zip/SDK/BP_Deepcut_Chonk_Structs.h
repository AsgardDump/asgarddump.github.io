#pragma once 
#include "SDK.h" 
 
 
// Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ExecuteUbergraph_BP_Deepcut_Chonk
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Deepcut_Chonk
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_TickSeconds_Tick;  // 0x4(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x8(0x4)
	float CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0xC(0x4)

}; 
// Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.SpawnBloodDecal
// Size: 0x90(Inherited: 0x0) 
struct FSpawnBloodDecal
{
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x0(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_BreakRotator_Roll;  // 0x10(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x14(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x18(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x20(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x24(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x30(0x4)
	float CallFunc_BreakVector_X;  // 0x34(0x4)
	float CallFunc_BreakVector_Y;  // 0x38(0x4)
	float CallFunc_BreakVector_Z;  // 0x3C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x40(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x44(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x48(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x4C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x50(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x54(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x60(0x4)
	float CallFunc_RandomFloat_ReturnValue;  // 0x64(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x70(0x8)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x78(0xC)
	char pad_132[4];  // 0x84(0x4)
	struct UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue;  // 0x88(0x8)

}; 
