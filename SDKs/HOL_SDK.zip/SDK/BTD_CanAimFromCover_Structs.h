#pragma once 
#include "SDK.h" 
 
 
// Function BTD_CanAimFromCover.BTD_CanAimFromCover_C.PerformConditionCheckAI
// Size: 0x66(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable : 1;  // 0x11(0x1)
	struct AORAIController* K2Node_DynamicCast_AsORAIController;  // 0x18(0x8)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	uint8_t  CallFunc_GetCoverType_ReturnValue;  // 0x21(0x1)
	struct UObject* CallFunc_GetClaimedAttractionPoint_ReturnValue;  // 0x28(0x8)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x30(0x1)
	struct TScriptInterface<IORAttractionPointInterface> K2Node_DynamicCast_AsORAttraction_Point_Interface;  // 0x38(0x10)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_78[2];  // 0x4E(0x2)
	struct TScriptInterface<IORAttractionPointInterface> K2Node_DynamicCast_AsORAttraction_Point_Interface_2;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_HasRightCornerCover_ReturnValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_HasLeftCornerCover_ReturnValue : 1;  // 0x62(0x1)
	char pad_99_1 : 7;  // 0x63(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x63(0x1)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x65(0x1)

}; 
