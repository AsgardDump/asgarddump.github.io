#pragma once 
#include <Ability_AIMerkSmgPrimaryFrenzyFire_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_AIMerkSmgPrimaryFrenzyFire_BP.Ability_AIMerkSmgPrimaryFrenzyFire_BP_C
// Size: 0x428(Inherited: 0x428) 
struct UAbility_AIMerkSmgPrimaryFrenzyFire_BP_C : public UORGameplayAbility_FireItem
{

}; 



