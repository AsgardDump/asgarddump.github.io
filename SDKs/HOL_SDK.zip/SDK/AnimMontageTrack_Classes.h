#pragma once 
#include <AnimMontageTrack_Structs.h>
 
 
 
// Class AnimMontageTrack.AnimMontageSection
// Size: 0x110(Inherited: 0xF0) 
struct UAnimMontageSection : public UMovieSceneSection
{
	struct FAnimMontageSectionParams Params;  // 0xF0(0x20)

}; 



// Class AnimMontageTrack.AnimMontageTrack
// Size: 0xB0(Inherited: 0x98) 
struct UAnimMontageTrack : public UMovieSceneNameableTrack
{
	char pad_152[8];  // 0x98(0x8)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0xA0(0x10)

}; 



