#pragma once 
#include "SDK.h" 
 
 
// Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.ExecuteUbergraph_ChangeCollisionWhileActive_GA
// Size: 0x3C(Inherited: 0x0) 
struct FExecuteUbergraph_ChangeCollisionWhileActive_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName CallFunc_GetCollisionProfileName_ReturnValue;  // 0x1C(0x8)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x24(0x1)
	char ECollisionEnabled CallFunc_GetCollisionEnabled_ReturnValue;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x27(0x1)
	struct AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue_2;  // 0x28(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_2 : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_IsAliveAndWell_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x3B(0x1)

}; 
// Function ChangeCollisionWhileActive_GA.ChangeCollisionWhileActive_GA_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
