#pragma once 
#include <BTD_CreatureMinionCarryingItem_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_CreatureMinionCarryingItem.BTD_CreatureMinionCarryingItem_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_CreatureMinionCarryingItem_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CreatureMinionCarryingItem.BTD_CreatureMinionCarryingItem_C.PerformConditionCheckAI
}; 



