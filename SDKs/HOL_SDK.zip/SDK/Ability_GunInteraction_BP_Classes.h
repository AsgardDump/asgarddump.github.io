#pragma once 
#include <Ability_GunInteraction_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_GunInteraction_BP.Ability_GunInteraction_BP_C
// Size: 0x3F9(Inherited: 0x3F8) 
struct UAbility_GunInteraction_BP_C : public UORGameplayAbility_GunInteract
{
	char WeaponNames GunEnum;  // 0x3F8(0x1)

}; 



