#pragma once 
#include <Ability_MeleeInteract_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_MeleeInteract_BP.Ability_MeleeInteract_BP_C
// Size: 0x408(Inherited: 0x408) 
struct UAbility_MeleeInteract_BP_C : public UORGameplayAbility_MeleeInteract
{

}; 



