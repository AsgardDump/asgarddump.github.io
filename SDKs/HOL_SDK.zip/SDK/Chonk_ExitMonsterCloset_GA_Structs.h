#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.ExecuteUbergraph_Chonk_ExitMonsterCloset_GA
// Size: 0x2A0(Inherited: 0x0) 
struct FExecuteUbergraph_Chonk_ExitMonsterCloset_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x34(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x44(0x10)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool GameplayTagsK2Node_SwitchGameplayTag_CmpSuccess : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	struct FActiveGameplayEffectHandle CallFunc_ApplyGameplayEffect_ReturnValue;  // 0x58(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x60(0xC)
	float CallFunc_BreakVector_X;  // 0x6C(0x4)
	float CallFunc_BreakVector_Y;  // 0x70(0x4)
	float CallFunc_BreakVector_Z;  // 0x74(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct UAbilityTask_PlayMontageAndWait* CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue;  // 0x80(0x8)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x88(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x94(0x90)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x124(0x1)
	char pad_293_1 : 7;  // 0x125(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x125(0x1)
	char pad_294[2];  // 0x126(0x2)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x128(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x130(0x10)
	struct FHitResult K2Node_CustomEvent_Hit;  // 0x140(0x90)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1D0(0x1)
	char pad_465_1 : 7;  // 0x1D1(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x1D1(0x1)
	char pad_466[2];  // 0x1D2(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x1D4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1D8(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1DC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1E8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1F4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x200(0xC)
	char pad_524[4];  // 0x20C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x210(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x218(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x220(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x228(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x230(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x234(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x238(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x23C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x248(0xC)
	char pad_596[12];  // 0x254(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x260(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x290(0x8)
	struct AChonk_IntroJump_ExplosionDamage_BP_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x298(0x8)

}; 
// Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.ActivateJumpCollision
// Size: 0x4C(Inherited: 0x0) 
struct FActivateJumpCollision
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Activate : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x1C(0x4)
	char ECollisionResponse CallFunc_Array_Get_Item;  // 0x20(0x1)
	char ECollisionChannel CallFunc_Array_Get_Item_2;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x28(0x4)
	char ECollisionChannel CallFunc_Array_Get_Item_3;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x35(0x1)
	char pad_54[2];  // 0x36(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x38(0x4)
	char ECollisionChannel CallFunc_Array_Get_Item_4;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x44(0x1)
	char ECollisionResponse CallFunc_GetCollisionResponseToChannel_ReturnValue;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x48(0x4)

}; 
// Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.CharacterLanded
// Size: 0x90(Inherited: 0x0) 
struct FCharacterLanded
{
	struct FHitResult Hit;  // 0x0(0x90)

}; 
