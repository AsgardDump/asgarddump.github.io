#pragma once 
#include <ApplyGEOnActivation_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ApplyGEOnActivation_GA.ApplyGEOnActivation_GA_C
// Size: 0x421(Inherited: 0x3F8) 
struct UApplyGEOnActivation_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)
	struct TArray<UGameplayEffect*> GEToApply;  // 0x400(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> AppliedGE;  // 0x410(0x10)
	char pad_1056_1 : 7;  // 0x420(0x1)
	bool DoesEndOnActivation : 1;  // 0x420(0x1)

	void K2_ActivateAbility(); // Function ApplyGEOnActivation_GA.ApplyGEOnActivation_GA_C.K2_ActivateAbility
	void ExecuteUbergraph_ApplyGEOnActivation_GA(int32_t EntryPoint); // Function ApplyGEOnActivation_GA.ApplyGEOnActivation_GA_C.ExecuteUbergraph_ApplyGEOnActivation_GA
}; 



