#pragma once 
#include <Ability_ConversationChoice_Cancel_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_ConversationChoice_Cancel.Ability_ConversationChoice_Cancel_C
// Size: 0x400(Inherited: 0x400) 
struct UAbility_ConversationChoice_Cancel_C : public UORGameplayAbility_ConversationChoice
{

}; 



