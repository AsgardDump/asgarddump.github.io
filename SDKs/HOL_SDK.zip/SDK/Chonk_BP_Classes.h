#pragma once 
#include <Chonk_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_BP.Chonk_BP_C
// Size: 0x26A4(Inherited: 0x23D8) 
struct AChonk_BP_C : public AHenchman_GoopArmored_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x23D8(0x8)
	struct USceneComponent* BarrageWarningPlacementScene;  // 0x23E0(0x8)
	struct USkeletalMeshComponent* HighlightGunMesh;  // 0x23E8(0x8)
	float GunDisable_Cycle_R_Value_A839FA2A42EA0A837933648C7441B87E;  // 0x23F0(0x4)
	char ETimelineDirection GunDisable_Cycle__Direction_A839FA2A42EA0A837933648C7441B87E;  // 0x23F4(0x1)
	char pad_9205[3];  // 0x23F5(0x3)
	struct UTimelineComponent* GunDisable_Cycle;  // 0x23F8(0x8)
	int32_t GunArm_HitCount;  // 0x2400(0x4)
	int32_t GunArm_MaxHit;  // 0x2404(0x4)
	struct TArray<struct FName> Placeholder_LeftArmBoneNamesForGun;  // 0x2408(0x10)
	struct FGameplayTag eventND_ChonkGunBroken;  // 0x2418(0x8)
	struct FMulticastInlineDelegate OnDisableComplete;  // 0x2420(0x30)
	struct FScalableFloat GunAttackInterruptDamage;  // 0x2450(0x28)
	float CurrentGunDamage;  // 0x2478(0x4)
	char pad_9340_1 : 7;  // 0x247C(0x1)
	bool GunAttackActive : 1;  // 0x247C(0x1)
	char pad_9341_1 : 7;  // 0x247D(0x1)
	bool ForceHeavyHitReaction : 1;  // 0x247D(0x1)
	char pad_9342[2];  // 0x247E(0x2)
	struct UORWidget_HUDPrompt* CachedHudPrompt;  // 0x2480(0x8)
	struct FMulticastInlineDelegate ForceHitReact;  // 0x2488(0x30)
	struct AActor* MainTarget;  // 0x24B8(0x8)
	float MinDistanceToFriendlyTarget;  // 0x24C0(0x4)
	char pad_9412_1 : 7;  // 0x24C4(0x1)
	bool IsTargetingFriendly : 1;  // 0x24C4(0x1)
	char pad_9413[3];  // 0x24C5(0x3)
	float IntroJumpLaunchSpeed;  // 0x24C8(0x4)
	char pad_9420[4];  // 0x24CC(0x4)
	struct TArray<struct AActor*> OverrideTargetList;  // 0x24D0(0x10)
	struct FName TargetAdditionalActors;  // 0x24E0(0x8)
	struct FName TargetActorBBKey;  // 0x24E8(0x8)
	struct FName TargetActor_Ability;  // 0x24F0(0x8)
	struct FGameplayTagQuery ExcludeFromFriendlyTargetting;  // 0x24F8(0x48)
	struct FGameplayTagQuery PriorityFriendlyTarget;  // 0x2540(0x48)
	struct FRuntimeFloatCurve ProxyMineTargetChonkDistanceScoreCurve;  // 0x2588(0x88)
	struct FRuntimeFloatCurve ProxyMineTargetPlayerDistanceScoreCurve;  // 0x2610(0x88)
	int32_t NDBarrageInterruptTotalShots;  // 0x2698(0x4)
	float NDBarrageInterruptTimeBetweenShots;  // 0x269C(0x4)
	float NDBarrageInterruptInitialDelay;  // 0x26A0(0x4)

	void IsTargetPrioritizedForFriendlyTargeting(struct AActor* Target Character, bool& Is Prioritized); // Function Chonk_BP.Chonk_BP_C.IsTargetPrioritizedForFriendlyTargeting
	void IsTargetExcludedFromFriendlyTargeting(struct AActor* Target Character, bool& Is Excluded); // Function Chonk_BP.Chonk_BP_C.IsTargetExcludedFromFriendlyTargeting
	void SetTargetActorListFromOverride(bool& FoundTarget); // Function Chonk_BP.Chonk_BP_C.SetTargetActorListFromOverride
	void TargetRandomFriendlyCharacter(bool& NewParam); // Function Chonk_BP.Chonk_BP_C.TargetRandomFriendlyCharacter
	void TargetBestFriendlyCharacter(bool& FoundTarget); // Function Chonk_BP.Chonk_BP_C.TargetBestFriendlyCharacter
	void CalcFriendlyProxyMineTargetScore(struct AORAICharacter* ORAICharacter, float& TargetScore); // Function Chonk_BP.Chonk_BP_C.CalcFriendlyProxyMineTargetScore
	void GetBestFriendlyProxyMineTarget(struct AActor*& FriendlyProxyMineTarget); // Function Chonk_BP.Chonk_BP_C.GetBestFriendlyProxyMineTarget
	void Start Critical Damage VO(); // Function Chonk_BP.Chonk_BP_C.Start Critical Damage VO
	void EnableBarrageWarning(bool Enable); // Function Chonk_BP.Chonk_BP_C.EnableBarrageWarning
	void HandleWeakpointVFX(struct FGameplayTagContainer& TagContainer, struct FHitResult& Hit); // Function Chonk_BP.Chonk_BP_C.HandleWeakpointVFX
	void CanForceHeavyHitReact(bool& Force); // Function Chonk_BP.Chonk_BP_C.CanForceHeavyHitReact
	void EnableGunInterrupt(bool Enable); // Function Chonk_BP.Chonk_BP_C.EnableGunInterrupt
	void CancelAbilities(); // Function Chonk_BP.Chonk_BP_C.CancelAbilities
	void UserConstructionScript(); // Function Chonk_BP.Chonk_BP_C.UserConstructionScript
	void GunDisable_Cycle__FinishedFunc(); // Function Chonk_BP.Chonk_BP_C.GunDisable_Cycle__FinishedFunc
	void GunDisable_Cycle__UpdateFunc(); // Function Chonk_BP.Chonk_BP_C.GunDisable_Cycle__UpdateFunc
	void DisableGun(); // Function Chonk_BP.Chonk_BP_C.DisableGun
	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function Chonk_BP.Chonk_BP_C.OnDied
	void ReceiveBeginPlay(); // Function Chonk_BP.Chonk_BP_C.ReceiveBeginPlay
	void TriggerCriticalDamageVO(struct FHitResult HitResult, struct FGameplayTagContainer HitReactTag); // Function Chonk_BP.Chonk_BP_C.TriggerCriticalDamageVO
	void OnDamageTaken(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function Chonk_BP.Chonk_BP_C.OnDamageTaken
	void SetListOfTargetActors(struct TArray<struct AActor*>& TargetList); // Function Chonk_BP.Chonk_BP_C.SetListOfTargetActors
	void BP_SpawnedFromPool(); // Function Chonk_BP.Chonk_BP_C.BP_SpawnedFromPool
	void ExecuteUbergraph_Chonk_BP(int32_t EntryPoint); // Function Chonk_BP.Chonk_BP_C.ExecuteUbergraph_Chonk_BP
	void ForceHitReact__DelegateSignature(struct FHitResult HitResult, struct FGameplayTagContainer HitReactTag); // Function Chonk_BP.Chonk_BP_C.ForceHitReact__DelegateSignature
	void OnDisableComplete__DelegateSignature(); // Function Chonk_BP.Chonk_BP_C.OnDisableComplete__DelegateSignature
}; 



