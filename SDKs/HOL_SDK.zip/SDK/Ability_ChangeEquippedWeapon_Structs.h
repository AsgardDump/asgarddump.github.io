#pragma once 
#include "SDK.h" 
 
 
// Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.ExecuteUbergraph_Ability_ChangeEquippedWeapon
// Size: 0x7A(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_ChangeEquippedWeapon
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_GameplayTagToString_ReturnValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UORPlayerInventory* CallFunc_GetOwningInventory_OutInventory;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x40(0x8)
	struct FString CallFunc_MakeLiteralString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x58(0x10)
	struct AORCharacter* CallFunc_GetOwningCharacter_Character;  // 0x68(0x8)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_EquipItem_ReturnValue : 1;  // 0x79(0x1)

}; 
// Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.GetOwningCharacter
// Size: 0x19(Inherited: 0x0) 
struct FGetOwningCharacter
{
	struct AORCharacter* Character;  // 0x0(0x8)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
