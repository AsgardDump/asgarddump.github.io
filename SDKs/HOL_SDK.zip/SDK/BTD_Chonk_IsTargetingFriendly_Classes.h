#pragma once 
#include <BTD_Chonk_IsTargetingFriendly_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_Chonk_IsTargetingFriendly.BTD_Chonk_IsTargetingFriendly_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_Chonk_IsTargetingFriendly_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_Chonk_IsTargetingFriendly.BTD_Chonk_IsTargetingFriendly_C.PerformConditionCheckAI
}; 



