#pragma once 
#include <BaseAmmoPickupBP_Structs.h>
 
 
 
// BlueprintGeneratedClass BaseAmmoPickupBP.BaseAmmoPickupBP_C
// Size: 0x320(Inherited: 0x2D8) 
struct ABaseAmmoPickupBP_C : public AORAmmoPickup
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2D8(0x8)
	char Relationships Weapon;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool PrimaryFire : 1;  // 0x2E1(0x1)
	char pad_738_1 : 7;  // 0x2E2(0x1)
	bool PhysicsEnabled : 1;  // 0x2E2(0x1)
	char pad_739[5];  // 0x2E3(0x5)
	struct FMulticastInlineDelegate AmmoRecieved;  // 0x2E8(0x30)
	struct FName ReloadAbilityName;  // 0x318(0x8)

	void AttemptAutoReload(struct AORPlayerCharacter* Character, struct AORFireableInventoryItem* Item); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.AttemptAutoReload
	void ReceiveBeginPlay(); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ReceiveBeginPlay
	void ReceivedAmmo(struct AORFireableInventoryItem* Item, struct AORPlayerCharacter* PlayerCharacter, int32_t AmmoPickedUP); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ReceivedAmmo
	void ExecuteUbergraph_BaseAmmoPickupBP(int32_t EntryPoint); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ExecuteUbergraph_BaseAmmoPickupBP
	void AmmoRecieved__DelegateSignature(); // Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.AmmoRecieved__DelegateSignature
}; 



