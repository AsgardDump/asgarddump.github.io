#pragma once 
#include "SDK.h" 
 
 
// Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ExecuteUbergraph_BTS_UpdatePanicRetreatLocation
// Size: 0x99(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_UpdatePanicRetreatLocation
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x10(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue;  // 0x20(0x8)
	struct UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance;  // 0x28(0x8)
	char EEnvQueryStatus K2Node_CustomEvent_QueryStatus;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TArray<struct FVector> CallFunc_GetQueryResultsAsLocations_ResultLocations;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_GetQueryResultsAsLocations_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct AAIController* K2Node_Event_OwnerController;  // 0x58(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x6C(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x7C(0x10)
	char pad_140[4];  // 0x8C(0x4)
	struct AActor* CallFunc_GetFocusActor_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x98(0x1)

}; 
// Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.EQS_QueryComplete
// Size: 0x9(Inherited: 0x0) 
struct FEQS_QueryComplete
{
	struct UEnvQueryInstanceBlueprintWrapper* QueryInstance;  // 0x0(0x8)
	char EEnvQueryStatus QueryStatus;  // 0x8(0x1)

}; 
// Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ReceiveDeactivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveDeactivationAI : public FReceiveDeactivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
