#pragma once 
#include <Ability_UICancel_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_UICancel_BP.Ability_UICancel_BP_C
// Size: 0x400(Inherited: 0x400) 
struct UAbility_UICancel_BP_C : public UORGameplayAbility_UICancel
{

}; 



