#pragma once 
#include "SDK.h" 
 
 
// Function CancelEquipmentFire_GA.CancelEquipmentFire_GA_C.ExecuteUbergraph_CancelEquipmentFire_GA
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_CancelEquipmentFire_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AORPlayerCharacter* K2Node_DynamicCast_AsORPlayer_Character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function CancelEquipmentFire_GA.CancelEquipmentFire_GA_C.K2_CanActivateAbility
// Size: 0x82(Inherited: 0x78) 
struct FK2_CanActivateAbility : public FK2_CanActivateAbility
{
	struct FGameplayAbilityActorInfo ActorInfo;  // 0x0(0x48)
	struct FGameplayAbilitySpecHandle Handle;  // 0x48(0x4)
	struct FGameplayTagContainer RelevantTags;  // 0x50(0x20)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	struct AORPlayerCharacter* K2Node_DynamicCast_AsORPlayer_Character;  // 0x78(0x8)
	char pad_237_1 : 7;  // 0xED(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x80(0x1)
	char pad_238_1 : 7;  // 0xEE(0x1)
	bool CallFunc_IsAbilitySlotActive_ReturnValue : 1;  // 0x81(0x1)

}; 
