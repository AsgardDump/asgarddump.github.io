#pragma once 
#include <BlockDash_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockDash_GE.BlockDash_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UBlockDash_GE_C : public UORGameplayEffect
{

}; 



