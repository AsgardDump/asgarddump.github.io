#pragma once 
#include <CharacterCreatorWidgetV2_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C
// Size: 0x44C(Inherited: 0x3A0) 
struct UCharacterCreatorWidgetV2_BP_C : public UORWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3A0(0x8)
	struct UHorizontalBox* HorizontalBox_ButtonContainer;  // 0x3A8(0x8)
	struct UImage* Image_BackgroundClickIntercept;  // 0x3B0(0x8)
	struct UORButton* ORButton_CycleLeft;  // 0x3B8(0x8)
	struct UORButton* ORButton_CycleRight;  // 0x3C0(0x8)
	struct UORButton* ORButton_Select;  // 0x3C8(0x8)
	struct FMulticastInlineDelegate OnSelectionChanged;  // 0x3D0(0x30)
	struct FMulticastInlineDelegate OnCharacterSelected;  // 0x400(0x30)
	char pad_1072_1 : 7;  // 0x430(0x1)
	bool NewVar_1 : 1;  // 0x430(0x1)
	char pad_1073[7];  // 0x431(0x7)
	struct UCharacterCreatorFullscreenContainer_BP_C* FullscreenContainer;  // 0x438(0x8)
	int32_t Face Changes;  // 0x440(0x4)
	struct FFocusEvent In Focus Event;  // 0x444(0x8)

	struct FEventReply OnMouseButtonDown_1(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnMouseButtonDown_1
	void MatchWidgetToMirror(struct FVector2D ScreenPosition, float WidgetRadius); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.MatchWidgetToMirror
	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnPreviewKeyDown
	void SelectFace(int32_t FaceIndex); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.SelectFace
	void NavigateRight(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.NavigateRight
	void NavigateLeft(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.NavigateLeft
	void BndEvt__CharacterCreatorWidget_BP_ORButton_Select_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.BndEvt__CharacterCreatorWidget_BP_ORButton_Select_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleLeft_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleLeft_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleRight_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.BndEvt__CharacterCreatorWidgetV2_BP_ORButton_CycleRight_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_CharacterCreatorWidgetV2_BP(int32_t EntryPoint); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.ExecuteUbergraph_CharacterCreatorWidgetV2_BP
	void OnCharacterSelected__DelegateSignature(); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnCharacterSelected__DelegateSignature
	void OnSelectionChanged__DelegateSignature(bool bNavigateRight); // Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnSelectionChanged__DelegateSignature
}; 



