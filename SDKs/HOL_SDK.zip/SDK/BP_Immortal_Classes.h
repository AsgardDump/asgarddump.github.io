#pragma once 
#include <BP_Immortal_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Immortal.BP_Immortal_C
// Size: 0x242C(Inherited: 0x233D) 
struct ABP_Immortal_C : public AFlyingHenchman_BP_C
{
	char pad_9021[3];  // 0x233D(0x3)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2340(0x8)
	struct UNiagaraComponent* NPS_Death;  // 0x2348(0x8)
	struct UNiagaraComponent* NPS_FlyingPowers;  // 0x2350(0x8)
	struct USQDismemberComponent* DismemberComp;  // 0x2358(0x8)
	struct UORSquadUnitConsumerComponent* ORSquadUnitConsumer;  // 0x2360(0x8)
	struct UMercuna3DNavigationComponent* Mercuna3DNavigation;  // 0x2368(0x8)
	struct UORAkComponent* ORAk (Body);  // 0x2370(0x8)
	float WarpOutTimeline_Dissolve_8C143B554711AE346A39F78EFBB00C69;  // 0x2378(0x4)
	char ETimelineDirection WarpOutTimeline__Direction_8C143B554711AE346A39F78EFBB00C69;  // 0x237C(0x1)
	char pad_9085[3];  // 0x237D(0x3)
	struct UTimelineComponent* WarpOutTimeline;  // 0x2380(0x8)
	float WarpOutScaleTimeline_ScaleTrack_D16E5E6C485D48D058487C8106306663;  // 0x2388(0x4)
	char ETimelineDirection WarpOutScaleTimeline__Direction_D16E5E6C485D48D058487C8106306663;  // 0x238C(0x1)
	char pad_9101[3];  // 0x238D(0x3)
	struct UTimelineComponent* WarpOutScaleTimeline;  // 0x2390(0x8)
	int32_t MaxActiveShielders;  // 0x2398(0x4)
	int32_t MaxTotalSpawnedShielders;  // 0x239C(0x4)
	int32_t ActiveShielderCount;  // 0x23A0(0x4)
	int32_t SpawnedShielderCount;  // 0x23A4(0x4)
	char E_ImmortalMovementMode MovementMode;  // 0x23A8(0x1)
	char pad_9129[3];  // 0x23A9(0x3)
	float ElapsedTime;  // 0x23AC(0x4)
	struct AORAICharacter* CurrentShieldTarget;  // 0x23B0(0x8)
	struct AImmortalHead_BP_C* CurrentShielderHead;  // 0x23B8(0x8)
	struct TArray<struct AImmortalHead_BP_C*> SpawnedShielders;  // 0x23C0(0x10)
	struct AActor* OrbitTarget;  // 0x23D0(0x8)
	struct AImmortalHead_Shield_BP_C* ImmortalShield;  // 0x23D8(0x8)
	char pad_9184_1 : 7;  // 0x23E0(0x1)
	bool IsRecharging : 1;  // 0x23E0(0x1)
	char pad_9185[3];  // 0x23E1(0x3)
	struct FName HeadSpawnSocketName;  // 0x23E4(0x8)
	struct FGameplayTag MindControlStatusTag;  // 0x23EC(0x8)
	char pad_9204[4];  // 0x23F4(0x4)
	struct TArray<struct UMaterialInstanceDynamic*> DynamicMaterialInstances_Cached;  // 0x23F8(0x10)
	struct FTimerHandle UpdateAutoWarpOutTimerHandle;  // 0x2408(0x8)
	struct FTimerHandle AutoWarpOutTimer;  // 0x2410(0x8)
	float CurrentAutoWarpOutTime;  // 0x2418(0x4)
	float EncounterStartAutoWarpOutTime;  // 0x241C(0x4)
	float PostShieldAutoWarpOutTime;  // 0x2420(0x4)
	char pad_9252_1 : 7;  // 0x2424(0x1)
	bool AutoWarpOut : 1;  // 0x2424(0x1)
	char pad_9253[3];  // 0x2425(0x3)
	float InitialShieldDelay;  // 0x2428(0x4)

	void CanWarpOut(bool& CanWarpOut?); // Function BP_Immortal.BP_Immortal_C.CanWarpOut
	void IsMindControlled(bool& MindControlled); // Function BP_Immortal.BP_Immortal_C.IsMindControlled
	void FinishWarpingOut(); // Function BP_Immortal.BP_Immortal_C.FinishWarpingOut
	void StartWarpingOut(); // Function BP_Immortal.BP_Immortal_C.StartWarpingOut
	void InitiateWarpOut(); // Function BP_Immortal.BP_Immortal_C.InitiateWarpOut
	void UpdateAutoWarpOut(); // Function BP_Immortal.BP_Immortal_C.UpdateAutoWarpOut
	void CanSpawnShielder(bool& CanSpawn); // Function BP_Immortal.BP_Immortal_C.CanSpawnShielder
	void SetCurrentShieldTarget(struct AORAICharacter* NewShieldTarget); // Function BP_Immortal.BP_Immortal_C.SetCurrentShieldTarget
	void GetBestShieldTarget(struct AORAICharacter*& TargetCharacter); // Function BP_Immortal.BP_Immortal_C.GetBestShieldTarget
	void SetImmortalShieldEnabled(bool ShieldEnabled); // Function BP_Immortal.BP_Immortal_C.SetImmortalShieldEnabled
	void EndShieldRecharge(); // Function BP_Immortal.BP_Immortal_C.EndShieldRecharge
	void BeginShieldRecharge(); // Function BP_Immortal.BP_Immortal_C.BeginShieldRecharge
	void KillAllSpawnedShielders(); // Function BP_Immortal.BP_Immortal_C.KillAllSpawnedShielders
	void LoseSpawnedShielder(struct AImmortalHead_BP_C*& Shielder); // Function BP_Immortal.BP_Immortal_C.LoseSpawnedShielder
	void TrackSpawnedShielder(struct AImmortalHead_BP_C*& Shielder); // Function BP_Immortal.BP_Immortal_C.TrackSpawnedShielder
	void SetOrbitTarget(struct AORAICharacter* OrbitTarget); // Function BP_Immortal.BP_Immortal_C.SetOrbitTarget
	void SpawnShielder(); // Function BP_Immortal.BP_Immortal_C.SpawnShielder
	void DispatchShielder(struct AORAICharacter* ShieldTarget, bool& Dispatched); // Function BP_Immortal.BP_Immortal_C.DispatchShielder
	void SetScalarParameterOnMaterialInstances(struct FName Name, float Value); // Function BP_Immortal.BP_Immortal_C.SetScalarParameterOnMaterialInstances
	void SetupMaterialInstances(); // Function BP_Immortal.BP_Immortal_C.SetupMaterialInstances
	void WarpOutScaleTimeline__FinishedFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutScaleTimeline__FinishedFunc
	void WarpOutScaleTimeline__UpdateFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutScaleTimeline__UpdateFunc
	void WarpOutTimeline__FinishedFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutTimeline__FinishedFunc
	void WarpOutTimeline__UpdateFunc(); // Function BP_Immortal.BP_Immortal_C.WarpOutTimeline__UpdateFunc
	void Audio_Play_Attached_Loop(); // Function BP_Immortal.BP_Immortal_C.Audio_Play_Attached_Loop
	void Audio_Stop_Attached_Loop(); // Function BP_Immortal.BP_Immortal_C.Audio_Stop_Attached_Loop
	void Audio_ShieldHead_Death(); // Function BP_Immortal.BP_Immortal_C.Audio_ShieldHead_Death
	void Audio_ReturnedToPool(); // Function BP_Immortal.BP_Immortal_C.Audio_ReturnedToPool
	void ReceiveBeginPlay(); // Function BP_Immortal.BP_Immortal_C.ReceiveBeginPlay
	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function BP_Immortal.BP_Immortal_C.OnDied
	void ReceiveDirectEvent(struct FGameplayTag Tag, struct UORGlobalEventPayload* Payload); // Function BP_Immortal.BP_Immortal_C.ReceiveDirectEvent
	void OnShielderDied(struct AORAICharacter* Victim, struct UObject* Killer); // Function BP_Immortal.BP_Immortal_C.OnShielderDied
	void Audio_Stop_StunnedSfx(); // Function BP_Immortal.BP_Immortal_C.Audio_Stop_StunnedSfx
	void Audio_Play_StunnedSfx(); // Function BP_Immortal.BP_Immortal_C.Audio_Play_StunnedSfx
	void Audio_Death(); // Function BP_Immortal.BP_Immortal_C.Audio_Death
	void StartImmortalStun(); // Function BP_Immortal.BP_Immortal_C.StartImmortalStun
	void BP_OnStatusEffectChanged(uint8_t  NewStatusEffect); // Function BP_Immortal.BP_Immortal_C.BP_OnStatusEffectChanged
	void OnCurrentShieldTargetDied(struct UObject* Killer, struct AORCharacter* Killed, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function BP_Immortal.BP_Immortal_C.OnCurrentShieldTargetDied
	void Audio_Start_HoverLoop(); // Function BP_Immortal.BP_Immortal_C.Audio_Start_HoverLoop
	void BP_SpawnedFromPool(); // Function BP_Immortal.BP_Immortal_C.BP_SpawnedFromPool
	void BP_ReturnedToPool(); // Function BP_Immortal.BP_Immortal_C.BP_ReturnedToPool
	void ResetMaterialParams(); // Function BP_Immortal.BP_Immortal_C.ResetMaterialParams
	void ExecuteUbergraph_BP_Immortal(int32_t EntryPoint); // Function BP_Immortal.BP_Immortal_C.ExecuteUbergraph_BP_Immortal
}; 



