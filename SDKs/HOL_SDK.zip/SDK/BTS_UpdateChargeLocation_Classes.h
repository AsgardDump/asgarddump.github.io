#pragma once 
#include <BTS_UpdateChargeLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_UpdateChargeLocation.BTS_UpdateChargeLocation_C
// Size: 0xE0(Inherited: 0x98) 
struct UBTS_UpdateChargeLocation_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector MoveToLocation;  // 0xA0(0x28)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool IsQueryRunning : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct UEnvQueryInstanceBlueprintWrapper* RunningEQSQuery;  // 0xD0(0x8)
	float MinMeleeAttackRange;  // 0xD8(0x4)
	float MaxMeleeAttackRange;  // 0xDC(0x4)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateChargeLocation.BTS_UpdateChargeLocation_C.ReceiveTickAI
	void EQS_QueryComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus); // Function BTS_UpdateChargeLocation.BTS_UpdateChargeLocation_C.EQS_QueryComplete
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateChargeLocation.BTS_UpdateChargeLocation_C.ReceiveDeactivationAI
	void ExecuteUbergraph_BTS_UpdateChargeLocation(int32_t EntryPoint); // Function BTS_UpdateChargeLocation.BTS_UpdateChargeLocation_C.ExecuteUbergraph_BTS_UpdateChargeLocation
}; 



