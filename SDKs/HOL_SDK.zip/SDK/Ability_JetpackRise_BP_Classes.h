#pragma once 
#include <Ability_JetpackRise_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_JetpackRise_BP.Ability_JetpackRise_BP_C
// Size: 0x408(Inherited: 0x408) 
struct UAbility_JetpackRise_BP_C : public UORGameplayAbility_JetpackRise
{

}; 



