#pragma once 
#include <ButtonPrompt_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ButtonPrompt_BP.ButtonPrompt_BP_C
// Size: 0x337(Inherited: 0x290) 
struct UButtonPrompt_BP_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct UTextBlock* ButtonCombo_TextBlock;  // 0x298(0x8)
	struct UImage* ButtonComboImage;  // 0x2A0(0x8)
	struct UImage* ButtonImage;  // 0x2A8(0x8)
	struct UHorizontalBox* ButtonImage_HorizontalBox;  // 0x2B0(0x8)
	struct UImage* Image_44;  // 0x2B8(0x8)
	struct UImage* PlusSignImage;  // 0x2C0(0x8)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool bIsGamepad : 1;  // 0x2C8(0x1)
	char EInputDeviceType CurrentInputDevice;  // 0x2C9(0x1)
	char pad_714[6];  // 0x2CA(0x6)
	struct UDataTable* ButtonIconDataTable;  // 0x2D0(0x8)
	struct TMap<char EInputDeviceType, struct FKey> OverrideKeys;  // 0x2D8(0x50)
	struct FName Action Name;  // 0x328(0x8)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool UseText : 1;  // 0x330(0x1)
	char pad_817_1 : 7;  // 0x331(0x1)
	bool ForceKBM : 1;  // 0x331(0x1)
	char pad_818_1 : 7;  // 0x332(0x1)
	bool UseMinimalImage : 1;  // 0x332(0x1)
	char pad_819_1 : 7;  // 0x333(0x1)
	bool UseHelpTextIcon : 1;  // 0x333(0x1)
	char pad_820_1 : 7;  // 0x334(0x1)
	bool bIsAxisKey : 1;  // 0x334(0x1)
	char pad_821_1 : 7;  // 0x335(0x1)
	bool bIsPositiveAxis : 1;  // 0x335(0x1)
	char pad_822_1 : 7;  // 0x336(0x1)
	bool IsXenoButton : 1;  // 0x336(0x1)

	void ApplyKeyText(struct FButtonPromptIcon IconData); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.ApplyKeyText
	void FindImageForKey(struct FKey KeyToFind, struct FButtonPromptIcon& FoundIconData); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.FindImageForKey
	void UpdateButtonImage(); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.UpdateButtonImage
	void UpdateInputDevice(char EInputDeviceType NewInputDevice); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.UpdateInputDevice
	void OnLoaded_640DFFB94D753175E4E3B08AB61FC9BA(struct UObject* Loaded); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.OnLoaded_640DFFB94D753175E4E3B08AB61FC9BA
	void Construct(); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.Construct
	void Apply Key Image(struct FButtonPromptIcon IconData, struct UImage* ImageToSet); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.Apply Key Image
	void OnActionBindUpdated(struct FName ActionName); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.OnActionBindUpdated
	void ExecuteUbergraph_ButtonPrompt_BP(int32_t EntryPoint); // Function ButtonPrompt_BP.ButtonPrompt_BP_C.ExecuteUbergraph_ButtonPrompt_BP
}; 



