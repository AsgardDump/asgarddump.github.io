#pragma once 
#include <AIPostImpactImmunity_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass AIPostImpactImmunity_GE.AIPostImpactImmunity_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UAIPostImpactImmunity_GE_C : public UORGameplayEffect
{

}; 



