#pragma once 
#include <Ability_PlayerExecute_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C
// Size: 0x47C(Inherited: 0x428) 
struct UAbility_PlayerExecute_BP_C : public UORGameplayAbility_PlayerExecute
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x428(0x8)
	struct AORAICharacter* Target Character;  // 0x430(0x8)
	struct TArray<UGameplayEffect*> PlayerGameplayEffects;  // 0x438(0x10)
	struct TArray<UGameplayEffect*> TargetGameplayEffects;  // 0x448(0x10)
	struct FGameplayTagContainer Damage Tags;  // 0x458(0x20)
	float Execution Damage;  // 0x478(0x4)

	void OnExecutionCompleted(); // Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.OnExecutionCompleted
	void OnExecutionStart(struct AORAICharacter* TargetCharacter); // Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.OnExecutionStart
	void ExecuteUbergraph_Ability_PlayerExecute_BP(int32_t EntryPoint); // Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.ExecuteUbergraph_Ability_PlayerExecute_BP
}; 



