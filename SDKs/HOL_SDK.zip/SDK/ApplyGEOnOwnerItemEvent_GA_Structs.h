#pragma once 
#include "SDK.h" 
 
 
// Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.ExecuteUbergraph_ApplyGEOnOwnerItemEvent_GA
// Size: 0x67(Inherited: 0x0) 
struct FExecuteUbergraph_ApplyGEOnOwnerItemEvent_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct ASQInventoryItem* K2Node_DynamicCast_AsSQInventory_Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	char pad_44[4];  // 0x2C(0x4)
	struct ASQInventoryItem* K2Node_CustomEvent_Item;  // 0x30(0x8)
	struct FGameplayTag K2Node_CustomEvent_EventTag;  // 0x38(0x8)
	struct FGameplayTag K2Node_CustomEvent_FireMode;  // 0x40(0x8)
	char EInventoryTransactionType K2Node_CustomEvent_TransactionType;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x4C(0x10)
	struct FActiveGameplayEffectHandle CallFunc_BP_ApplyGameplayEffectToOwner_ReturnValue;  // 0x5C(0x8)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_EqualEqual_GameplayTag_ReturnValue : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_EqualEqual_GameplayTag_ReturnValue_2 : 1;  // 0x65(0x1)
	char pad_102_1 : 7;  // 0x66(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x66(0x1)

}; 
// Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function ApplyGEOnOwnerItemEvent_GA.ApplyGEOnOwnerItemEvent_GA_C.OnItemEvent
// Size: 0x19(Inherited: 0x0) 
struct FOnItemEvent
{
	struct ASQInventoryItem* Item;  // 0x0(0x8)
	struct FGameplayTag EventTag;  // 0x8(0x8)
	struct FGameplayTag FireMode;  // 0x10(0x8)
	char EInventoryTransactionType TransactionType;  // 0x18(0x1)

}; 
