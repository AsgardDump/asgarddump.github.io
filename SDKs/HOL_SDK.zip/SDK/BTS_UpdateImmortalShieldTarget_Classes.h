#pragma once 
#include <BTS_UpdateImmortalShieldTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C
// Size: 0xA8(Inherited: 0x98) 
struct UBTS_UpdateImmortalShieldTarget_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct ABP_Immortal_C* Immortal_Cached;  // 0xA0(0x8)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ReceiveTickAI
	void ReceiveSearchStartAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ReceiveSearchStartAI
	void ExecuteUbergraph_BTS_UpdateImmortalShieldTarget(int32_t EntryPoint); // Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ExecuteUbergraph_BTS_UpdateImmortalShieldTarget
}; 



