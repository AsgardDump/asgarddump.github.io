#pragma once 
#include <BTD_CanUseCharacterAbilityOnTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_CanUseCharacterAbilityOnTarget.BTD_CanUseCharacterAbilityOnTarget_C
// Size: 0xD9(Inherited: 0xA0) 
struct UBTD_CanUseCharacterAbilityOnTarget_C : public UBTDecorator_BlueprintBase
{
	struct FBlackboardKeySelector TargetActorKey;  // 0xA0(0x28)
	struct FGameplayTag CharacterAbilityTag;  // 0xC8(0x8)
	struct FORAbilityRequirementOverrideData AbilityRequirementOverrides;  // 0xD0(0x9)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CanUseCharacterAbilityOnTarget.BTD_CanUseCharacterAbilityOnTarget_C.PerformConditionCheckAI
}; 



