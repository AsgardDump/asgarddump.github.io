#pragma once 
#include <BlockMelee_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockMelee_GE.BlockMelee_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UBlockMelee_GE_C : public UORGameplayEffect
{

}; 



