#pragma once 
#include <Ability_EquipPrevWeapon_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_EquipPrevWeapon_BP.Ability_EquipPrevWeapon_BP_C
// Size: 0x401(Inherited: 0x3E0) 
struct UAbility_EquipPrevWeapon_BP_C : public UAbility_ChangeEquippedItemBase_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3E0(0x8)
	struct TArray<struct FGameplayTag> PlayerWeaponEquipOrder;  // 0x3E8(0x10)
	int32_t StartingWeaponIndex;  // 0x3F8(0x4)
	int32_t CurrentWeaponIndex;  // 0x3FC(0x4)
	char pad_1024_1 : 7;  // 0x400(0x1)
	bool ShouldKeepCycling : 1;  // 0x400(0x1)

	void SafelyDecrementWeaponIndex(); // Function Ability_EquipPrevWeapon_BP.Ability_EquipPrevWeapon_BP_C.SafelyDecrementWeaponIndex
	void EvaluateCycleCondition(struct UORCharacterInventory* Inventory); // Function Ability_EquipPrevWeapon_BP.Ability_EquipPrevWeapon_BP_C.EvaluateCycleCondition
	void IsCurrentIndexValidEquippable(struct UORCharacterInventory* Inventory, bool& Valid); // Function Ability_EquipPrevWeapon_BP.Ability_EquipPrevWeapon_BP_C.IsCurrentIndexValidEquippable
	void K2_ActivateAbility(); // Function Ability_EquipPrevWeapon_BP.Ability_EquipPrevWeapon_BP_C.K2_ActivateAbility
	void ExecuteUbergraph_Ability_EquipPrevWeapon_BP(int32_t EntryPoint); // Function Ability_EquipPrevWeapon_BP.Ability_EquipPrevWeapon_BP_C.ExecuteUbergraph_Ability_EquipPrevWeapon_BP
}; 



