#pragma once 
#include <BaseSkelMeshNPC_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C
// Size: 0x4D0(Inherited: 0x470) 
struct ABaseSkelMeshNPC_BP_C : public AORBaseSkeletalMeshNPC
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x470(0x8)
	struct UORDetachedTriggerComponent* InterruptVolume;  // 0x478(0x8)
	struct UNarrativeInfluenceVolumeComponent_BP_C* NIV;  // 0x480(0x8)
	struct UTrigger_OptIntoComponent_C* OptIntoTrigger;  // 0x488(0x8)
	struct UORTriggerVolumeComponent* ORTriggerVolume;  // 0x490(0x8)
	struct ATrigger_OptInto_C* OptInto;  // 0x498(0x8)
	struct FMulticastInlineDelegate OnOptIn;  // 0x4A0(0x30)

	void SetOptIntoActive(bool InEnabled); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.SetOptIntoActive
	void ReceiveBeginPlay(); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.ReceiveBeginPlay
	void OnOptedInto(); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.OnOptedInto
	void ExecuteUbergraph_BaseSkelMeshNPC_BP(int32_t EntryPoint); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.ExecuteUbergraph_BaseSkelMeshNPC_BP
	void OnOptIn__DelegateSignature(struct UTrigger_OptIntoComponent_C* OptInto); // Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.OnOptIn__DelegateSignature
}; 



