#pragma once 
#include <Ability_WeaponBash_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_WeaponBash.Ability_WeaponBash_C
// Size: 0x470(Inherited: 0x468) 
struct UAbility_WeaponBash_C : public UORGameplayAbility_PlayerMelee
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x468(0x8)

	void BP_OnPlayerMeleeEvent(struct FGameplayTag CurrentMeleeType); // Function Ability_WeaponBash.Ability_WeaponBash_C.BP_OnPlayerMeleeEvent
	void ExecuteUbergraph_Ability_WeaponBash(int32_t EntryPoint); // Function Ability_WeaponBash.Ability_WeaponBash_C.ExecuteUbergraph_Ability_WeaponBash
}; 



