#pragma once 
#include <BTT_PickNextPatrolRouteWaypoint_Structs.h>
 
 
 
// BlueprintGeneratedClass BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C
// Size: 0x104(Inherited: 0xA8) 
struct UBTT_PickNextPatrolRouteWaypoint_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector NewPatrolMoveLocationKey;  // 0xB0(0x28)
	struct FBlackboardKeySelector NewPatrolWaitAtWaypointKey;  // 0xD8(0x28)
	int32_t LastPatrolWaypointIdx;  // 0x100(0x4)

	void HandleReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, bool& Success); // Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.HandleReceiveExecuteAI
	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.ReceiveExecuteAI
	void ExecuteUbergraph_BTT_PickNextPatrolRouteWaypoint(int32_t EntryPoint); // Function BTT_PickNextPatrolRouteWaypoint.BTT_PickNextPatrolRouteWaypoint_C.ExecuteUbergraph_BTT_PickNextPatrolRouteWaypoint
}; 



