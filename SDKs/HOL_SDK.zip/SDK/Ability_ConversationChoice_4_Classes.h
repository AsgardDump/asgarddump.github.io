#pragma once 
#include <Ability_ConversationChoice_4_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_ConversationChoice_4.Ability_ConversationChoice_3_C
// Size: 0x400(Inherited: 0x400) 
struct UAbility_ConversationChoice_3_C : public UORGameplayAbility_ConversationChoice
{

}; 



