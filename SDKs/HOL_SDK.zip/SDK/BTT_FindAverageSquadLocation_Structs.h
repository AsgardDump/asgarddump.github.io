#pragma once 
#include "SDK.h" 
 
 
// Function BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C.ExecuteUbergraph_BTT_FindAverageSquadLocation
// Size: 0x4C(Inherited: 0x0) 
struct FExecuteUbergraph_BTT_FindAverageSquadLocation
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UORAISquad* CallFunc_GetAISquad_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x34(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x40(0xC)

}; 
// Function BTT_FindAverageSquadLocation.BTT_FindAverageSquadLocation_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
