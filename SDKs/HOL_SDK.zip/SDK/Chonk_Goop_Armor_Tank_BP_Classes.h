#pragma once 
#include <Chonk_Goop_Armor_Tank_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_Goop_Armor_Tank_BP.Chonk_Goop_Armor_Tank_BP_C
// Size: 0x338(Inherited: 0x338) 
struct AChonk_Goop_Armor_Tank_BP_C : public AGoop_Armor_Tank_BP_C
{

}; 



