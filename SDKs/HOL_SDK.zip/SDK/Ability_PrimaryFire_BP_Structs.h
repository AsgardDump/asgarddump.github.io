#pragma once 
#include "SDK.h" 
 
 
// Function Ability_PrimaryFire_BP.Ability_PrimaryFire_BP_C.ExecuteUbergraph_Ability_PrimaryFire_BP
// Size: 0x7B(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_PrimaryFire_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FGameplayAbilityActorInfo CallFunc_GetActorInfo_ReturnValue;  // 0x8(0x48)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_K2_CommitAbility_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct AORPlayerCharacter* K2Node_DynamicCast_AsORPlayer_Character;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct UPawnMovementComponent* CallFunc_GetMovementComponent_ReturnValue;  // 0x68(0x8)
	struct UORPlayerMovementComponent* K2Node_DynamicCast_AsORPlayer_Movement_Component;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_IsHovering_ReturnValue : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x7A(0x1)

}; 
