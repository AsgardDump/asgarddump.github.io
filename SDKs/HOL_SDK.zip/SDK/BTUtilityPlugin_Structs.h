#pragma once 
#include "SDK.h" 
 
 
// Function BTUtilityPlugin.BTDecorator_UtilityBlueprintBase.CalculateUtility
// Size: 0x18(Inherited: 0x0) 
struct FCalculateUtility
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
