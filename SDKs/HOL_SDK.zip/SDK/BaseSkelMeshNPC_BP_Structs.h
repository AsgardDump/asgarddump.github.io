#pragma once 
#include "SDK.h" 
 
 
// Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.OnOptIn__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnOptIn__DelegateSignature
{
	struct UTrigger_OptIntoComponent_C* OptInto;  // 0x0(0x8)

}; 
// Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.SetOptIntoActive
// Size: 0x1(Inherited: 0x0) 
struct FSetOptIntoActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InEnabled : 1;  // 0x0(0x1)

}; 
// Function BaseSkelMeshNPC_BP.BaseSkelMeshNPC_BP_C.ExecuteUbergraph_BaseSkelMeshNPC_BP
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_BaseSkelMeshNPC_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)

}; 
