#pragma once 
#include <BTD_DebugAllowAttacks_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_DebugAllowAttacks.BTD_DebugAllowAttacks_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_DebugAllowAttacks_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_DebugAllowAttacks.BTD_DebugAllowAttacks_C.PerformConditionCheckAI
}; 



