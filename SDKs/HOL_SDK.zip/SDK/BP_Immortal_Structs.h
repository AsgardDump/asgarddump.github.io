#pragma once 
#include "SDK.h" 
 
 
// Function BP_Immortal.BP_Immortal_C.DispatchShielder
// Size: 0xC(Inherited: 0x0) 
struct FDispatchShielder
{
	struct AORAICharacter* ShieldTarget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Dispatched : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_CanSpawnShielder_CanSpawn : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.ExecuteUbergraph_BP_Immortal
// Size: 0x313(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Immortal
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x8(0x10)
	struct FDelegate Temp_delegate_Variable;  // 0x18(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_2;  // 0x28(0x10)
	struct FDelegate Temp_delegate_Variable_2;  // 0x38(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_3;  // 0x48(0x10)
	struct FDelegate Temp_delegate_Variable_3;  // 0x58(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_4;  // 0x68(0x10)
	struct FDelegate Temp_delegate_Variable_4;  // 0x78(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_5;  // 0x88(0x10)
	struct FDelegate Temp_delegate_Variable_5;  // 0x98(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_6;  // 0xA8(0x10)
	struct FDelegate Temp_delegate_Variable_6;  // 0xB8(0x10)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_7;  // 0xC8(0x10)
	struct FDelegate Temp_delegate_Variable_7;  // 0xD8(0x10)
	int32_t CallFunc_PostAkEvent_ReturnValue;  // 0xE8(0x4)
	int32_t CallFunc_PostAkEvent_ReturnValue_2;  // 0xEC(0x4)
	int32_t CallFunc_PostAkEvent_ReturnValue_3;  // 0xF0(0x4)
	int32_t CallFunc_PostAkEvent_ReturnValue_4;  // 0xF4(0x4)
	int32_t CallFunc_PostAkEvent_ReturnValue_5;  // 0xF8(0x4)
	int32_t CallFunc_PostAkEvent_ReturnValue_6;  // 0xFC(0x4)
	int32_t CallFunc_PostAkEvent_ReturnValue_7;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct UObject* K2Node_Event_Killer;  // 0x108(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0x110(0x90)
	struct FGameplayTagContainer K2Node_Event_DamageTags;  // 0x1A0(0x20)
	struct FGameplayTag K2Node_Event_Tag;  // 0x1C0(0x8)
	struct UORGlobalEventPayload* K2Node_Event_Payload;  // 0x1C8(0x8)
	struct UORGlobalEventPayloadWithSource* K2Node_DynamicCast_AsORGlobal_Event_Payload_with_Source;  // 0x1D0(0x8)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1D8(0x1)
	char pad_473_1 : 7;  // 0x1D9(0x1)
	bool GameplayTagsK2Node_SwitchGameplayTag_CmpSuccess : 1;  // 0x1D9(0x1)
	char pad_474[6];  // 0x1DA(0x6)
	struct AORAICharacter* K2Node_CustomEvent_Victim;  // 0x1E0(0x8)
	struct UObject* K2Node_CustomEvent_Killer_2;  // 0x1E8(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct AImmortalHead_BP_C* K2Node_DynamicCast_AsImmortal_Head_BP;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x208(0x1)
	char pad_521_1 : 7;  // 0x209(0x1)
	bool CallFunc_DispatchShielder_Dispatched : 1;  // 0x209(0x1)
	uint8_t  K2Node_Event_NewStatusEffect;  // 0x20A(0x1)
	char pad_523_1 : 7;  // 0x20B(0x1)
	bool CallFunc_IsValidAndAlive_IsAliveAndWell : 1;  // 0x20B(0x1)
	char pad_524_1 : 7;  // 0x20C(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x20C(0x1)
	char pad_525[3];  // 0x20D(0x3)
	struct UObject* K2Node_CustomEvent_Killer;  // 0x210(0x8)
	struct AORCharacter* K2Node_CustomEvent_Killed;  // 0x218(0x8)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x220(0x90)
	struct FGameplayTagContainer K2Node_CustomEvent_DamageTags;  // 0x2B0(0x20)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x2D0(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x2E0(0x8)
	struct FActiveGameplayEffectHandle CallFunc_ApplyGameplayEffect_ReturnValue;  // 0x2E8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2F0(0xC)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x2FC(0x4)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x308(0x8)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x310(0x1)
	char pad_785_1 : 7;  // 0x311(0x1)
	bool CallFunc_SetCombatBehaviorSubStateKey_ReturnValue : 1;  // 0x311(0x1)
	char pad_786_1 : 7;  // 0x312(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x312(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.OnCurrentShieldTargetDied
// Size: 0xC0(Inherited: 0x0) 
struct FOnCurrentShieldTargetDied
{
	struct UObject* Killer;  // 0x0(0x8)
	struct AORCharacter* Killed;  // 0x8(0x8)
	struct FHitResult HitResult;  // 0x10(0x90)
	struct FGameplayTagContainer DamageTags;  // 0xA0(0x20)

}; 
// Function BP_Immortal.BP_Immortal_C.SetOrbitTarget
// Size: 0x21(Inherited: 0x0) 
struct FSetOrbitTarget
{
	struct AORAICharacter* OrbitTarget;  // 0x0(0x8)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x8(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x10(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.OnShielderDied
// Size: 0x10(Inherited: 0x0) 
struct FOnShielderDied
{
	struct AORAICharacter* Victim;  // 0x0(0x8)
	struct UObject* Killer;  // 0x8(0x8)

}; 
// Function BP_Immortal.BP_Immortal_C.BP_OnStatusEffectChanged
// Size: 0x1(Inherited: 0x1) 
struct FBP_OnStatusEffectChanged : public FBP_OnStatusEffectChanged
{
	uint8_t  NewStatusEffect;  // 0x0(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.SetupMaterialInstances
// Size: 0x3E(Inherited: 0x0) 
struct FSetupMaterialInstances
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x18(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3D(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.ReceiveDirectEvent
// Size: 0x10(Inherited: 0x0) 
struct FReceiveDirectEvent
{
	struct FGameplayTag Tag;  // 0x0(0x8)
	struct UORGlobalEventPayload* Payload;  // 0x8(0x8)

}; 
// Function BP_Immortal.BP_Immortal_C.SetScalarParameterOnMaterialInstances
// Size: 0x29(Inherited: 0x0) 
struct FSetScalarParameterOnMaterialInstances
{
	struct FName Name;  // 0x0(0x8)
	float Value;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.SpawnShielder
// Size: 0xD0(Inherited: 0x0) 
struct FSpawnShielder
{
	char CallFunc_GetGenericTeamId_TeamID;  // 0x0(0x1)
	struct FGenericTeamId K2Node_MakeStruct_GenericTeamId;  // 0x1(0x1)
	char pad_2[14];  // 0x2(0xE)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x10(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x40(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x4C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x58(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x64(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x68(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x6C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x70(0xC)
	char pad_124[4];  // 0x7C(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x80(0x30)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xB0(0x10)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xC0(0x8)
	struct AImmortalHead_BP_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xC8(0x8)

}; 
// Function BP_Immortal.BP_Immortal_C.TrackSpawnedShielder
// Size: 0x1C(Inherited: 0x0) 
struct FTrackSpawnedShielder
{
	struct AImmortalHead_BP_C* Shielder;  // 0x0(0x8)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	int32_t Temp_int_Variable_2;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x14(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x18(0x4)

}; 
// Function BP_Immortal.BP_Immortal_C.LoseSpawnedShielder
// Size: 0x15(Inherited: 0x0) 
struct FLoseSpawnedShielder
{
	struct AImmortalHead_BP_C* Shielder;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.KillAllSpawnedShielders
// Size: 0x20(Inherited: 0x0) 
struct FKillAllSpawnedShielders
{
	int32_t Temp_int_Loop_Counter_Variable;  // 0x0(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct AImmortalHead_BP_C* CallFunc_Array_Get_Item;  // 0x10(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x1C(0x4)

}; 
// Function BP_Immortal.BP_Immortal_C.BeginShieldRecharge
// Size: 0x1(Inherited: 0x0) 
struct FBeginShieldRecharge
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.SetImmortalShieldEnabled
// Size: 0x51(Inherited: 0x0) 
struct FSetImmortalShieldEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ShieldEnabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3[13];  // 0x3(0xD)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x40(0x8)
	struct AImmortalHead_Shield_BP_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x50(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.GetBestShieldTarget
// Size: 0x94(Inherited: 0x0) 
struct FGetBestShieldTarget
{
	struct AORAICharacter* TargetCharacter;  // 0x0(0x8)
	struct FGameplayTagContainer HighPriorityShieldTargetTags;  // 0x8(0x20)
	struct AORAICharacter* BeshShieldTarget_Cached;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsMindControlled_MindControlled : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x33(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x34(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3E(0x1)
	char pad_63[1];  // 0x3F(0x1)
	struct TArray<struct AORAICharacter*> CallFunc_GetSquadMemberQueue_ReturnValue;  // 0x40(0x10)
	struct AORAICharacter* CallFunc_Array_Get_Item;  // 0x50(0x8)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x58(0x8)
	struct AActor* CallFunc_GetMainTargetActor_ReturnValue;  // 0x60(0x8)
	struct TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasAnyMatchingGameplayTags_self_CastInput;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_HasAnyMatchingGameplayTags_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_IsEnemyActor_ReturnValue : 1;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool CallFunc_IsValidAndAlive_IsAliveAndWell : 1;  // 0x8A(0x1)
	char pad_139[1];  // 0x8B(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x8C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x90(0x4)

}; 
// Function BP_Immortal.BP_Immortal_C.SetCurrentShieldTarget
// Size: 0x39(Inherited: 0x0) 
struct FSetCurrentShieldTarget
{
	struct AORAICharacter* NewShieldTarget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1C(0x10)
	char pad_44[4];  // 0x2C(0x4)
	struct AORAICharacter* CallFunc_ConsumeSquadMember_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x38(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.CanSpawnShielder
// Size: 0x6(Inherited: 0x0) 
struct FCanSpawnShielder
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanSpawn : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x5(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.UpdateAutoWarpOut
// Size: 0x21(Inherited: 0x0) 
struct FUpdateAutoWarpOut
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_CanWarpOut_CanWarpOut_ : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_K2_IsValidTimerHandle_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.InitiateWarpOut
// Size: 0xA(Inherited: 0x0) 
struct FInitiateWarpOut
{
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_SetCombatBehaviorSubStateKey_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.StartWarpingOut
// Size: 0x8(Inherited: 0x0) 
struct FStartWarpingOut
{
	struct FActiveGameplayEffectHandle CallFunc_ApplyGameplayEffect_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_Immortal.BP_Immortal_C.FinishWarpingOut
// Size: 0x1(Inherited: 0x0) 
struct FFinishWarpingOut
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.IsMindControlled
// Size: 0x19(Inherited: 0x0) 
struct FIsMindControlled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool MindControlled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_HasMatchingGameplayTag_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.CanWarpOut
// Size: 0x16(Inherited: 0x0) 
struct FCanWarpOut
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanWarpOut? : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_HasScriptCommands_ReturnValue : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x15(0x1)

}; 
// Function BP_Immortal.BP_Immortal_C.OnDied
// Size: 0xB8(Inherited: 0xB8) 
struct FOnDied : public FOnDied
{
	struct UObject* Killer;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	struct FGameplayTagContainer DamageTags;  // 0x98(0x20)

}; 
