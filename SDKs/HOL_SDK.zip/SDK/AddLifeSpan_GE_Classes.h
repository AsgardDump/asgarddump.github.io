#pragma once 
#include <AddLifeSpan_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass AddLifeSpan_GE.AddLifeSpan_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UAddLifeSpan_GE_C : public UORGameplayEffect
{

}; 



