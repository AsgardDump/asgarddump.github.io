#pragma once 
#include "SDK.h" 
 
 
// Function ArmorPlatedMyte_HeavyArmor_GA.ArmorPlatedMyte_HeavyArmor_GA_C.ExecuteUbergraph_ArmorPlatedMyte_HeavyArmor_GA
// Size: 0x74(Inherited: 0x0) 
struct FExecuteUbergraph_ArmorPlatedMyte_HeavyArmor_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[11];  // 0x15(0xB)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x20(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x50(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct APhysicsObject_MyteArmor_BP_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x60(0x8)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x68(0xC)

}; 
