#pragma once 
#include "SDK.h" 
 
 
// Function CancelPlayerSprint_GA.CancelPlayerSprint_GA_C.ExecuteUbergraph_CancelPlayerSprint_GA
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_CancelPlayerSprint_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerCharacter_BP_C* CallFunc_GetORPlayer_PlayerCharacter;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UORPlayerMovementComponent* CallFunc_GetORPlayerMovementComponent_ORPlayerMovementComp;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x20(0x1)

}; 
