#pragma once 
#include <AltReload_FireLoop_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AltReload_FireLoop_BP.AltReload_FireLoop_BP_C
// Size: 0x88(Inherited: 0x88) 
struct UAltReload_FireLoop_BP_C : public UORFireLoop_Reload
{

	bool CanFire(); // Function AltReload_FireLoop_BP.AltReload_FireLoop_BP_C.CanFire
}; 



