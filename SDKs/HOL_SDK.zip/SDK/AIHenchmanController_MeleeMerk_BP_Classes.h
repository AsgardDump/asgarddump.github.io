#pragma once 
#include <AIHenchmanController_MeleeMerk_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AIHenchmanController_MeleeMerk_BP.AIHenchmanController_MeleeMerk_BP_C
// Size: 0x8D8(Inherited: 0x8D8) 
struct AAIHenchmanController_MeleeMerk_BP_C : public AAIHenchmanController_Merk_BP_C
{

}; 



