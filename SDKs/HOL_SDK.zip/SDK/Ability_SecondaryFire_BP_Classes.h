#pragma once 
#include <Ability_SecondaryFire_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_SecondaryFire_BP.Ability_SecondaryFire_BP_C
// Size: 0x428(Inherited: 0x428) 
struct UAbility_SecondaryFire_BP_C : public UORGameplayAbility_FireItem
{

}; 



