#pragma once 
#include "SDK.h" 
 
 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ExecuteUbergraph_AICookAndThrowGrenade_GA
// Size: 0x205(Inherited: 0x0) 
struct FExecuteUbergraph_AICookAndThrowGrenade_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName K2Node_CustomEvent_Notify_Begin;  // 0x4(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x30(0x10)
	struct FName K2Node_CustomEvent_NotifyName_10;  // 0x40(0x8)
	struct FName K2Node_CustomEvent_NotifyName_9;  // 0x48(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x50(0x10)
	struct FName K2Node_CustomEvent_NotifyName_8;  // 0x60(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x68(0x10)
	struct FName K2Node_CustomEvent_NotifyName_7;  // 0x78(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x80(0x10)
	struct FName K2Node_CustomEvent_NotifyName_6;  // 0x90(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x98(0x10)
	struct FName Temp_name_Variable;  // 0xA8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0xB0(0x10)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0xC0(0x8)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0xC8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0xD0(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0xE0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10;  // 0xE8(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0xF8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11;  // 0x100(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x110(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12;  // 0x118(0x10)
	struct FName Temp_name_Variable_2;  // 0x128(0x8)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x130(0x8)
	struct FActiveGameplayEffectHandle CallFunc_ApplyGameplayEffect_ReturnValue;  // 0x138(0x8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_K2_CommitAbility_ReturnValue : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	struct FVector CallFunc_FindLaunchVelocity_LaunchVelocity;  // 0x144(0xC)
	struct USQFiringResultComponent* CallFunc_GetFireableItemFireModeFiringResult_ReturnValue;  // 0x150(0x8)
	struct UEnemyGrenade_FiringResult_C* K2Node_DynamicCast_AsEnemy_Grenade_Firing_Result;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x161(0x1)
	char pad_354[6];  // 0x162(0x6)
	struct UAbilityTask_PlayMontageAndWait* CallFunc_CreatePlayMontageAndWaitProxy_ReturnValue;  // 0x168(0x8)
	struct USQFiringResultComponent* CallFunc_GetFireableItemFireModeFiringResult_ReturnValue_2;  // 0x170(0x8)
	struct UEnemyGrenade_FiringResult_C* K2Node_DynamicCast_AsEnemy_Grenade_Firing_Result_2;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x180(0x1)
	char pad_385_1 : 7;  // 0x181(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x181(0x1)
	char pad_386[6];  // 0x182(0x6)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue_2;  // 0x188(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x190(0x8)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x198(0x1)
	char pad_409_1 : 7;  // 0x199(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x199(0x1)
	char pad_410_1 : 7;  // 0x19A(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x19A(0x1)
	char pad_411_1 : 7;  // 0x19B(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x19B(0x1)
	char pad_412[4];  // 0x19C(0x4)
	struct USkeletalMeshComponent* CallFunc_GetOwningComponentFromActorInfo_ReturnValue;  // 0x1A0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13;  // 0x1A8(0x10)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x1B8(0x8)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1C0(0x1)
	char pad_449_1 : 7;  // 0x1C1(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x1C1(0x1)
	char pad_450[6];  // 0x1C2(0x6)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue_2;  // 0x1C8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14;  // 0x1D0(0x10)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue_3;  // 0x1E8(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter_2;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1F8(0x1)
	char pad_505[3];  // 0x1F9(0x3)
	struct FName K2Node_CustomEvent_Notify_Begin_2;  // 0x1FC(0x8)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x204(0x1)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ChargeMontageNotifyBegin
// Size: 0x8(Inherited: 0x0) 
struct FChargeMontageNotifyBegin
{
	struct FName Notify Begin;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.ThrowMontageNotifyBegin
// Size: 0x8(Inherited: 0x0) 
struct FThrowMontageNotifyBegin
{
	struct FName Notify Begin;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_CB052D0449732D9E04B5E68488268F05
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_CB052D0449732D9E04B5E68488268F05
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyBegin_6B8CF146489C2A5CF4B68380953B270E
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_6B8CF146489C2A5CF4B68380953B270E
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_6B8CF146489C2A5CF4B68380953B270E
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_6B8CF146489C2A5CF4B68380953B270E
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyBegin_CB052D0449732D9E04B5E68488268F05
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_CB052D0449732D9E04B5E68488268F05
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_6B8CF146489C2A5CF4B68380953B270E
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_6B8CF146489C2A5CF4B68380953B270E
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnBlendOut_6B8CF146489C2A5CF4B68380953B270E
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_6B8CF146489C2A5CF4B68380953B270E
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnCompleted_CB052D0449732D9E04B5E68488268F05
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_CB052D0449732D9E04B5E68488268F05
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyEnd_6B8CF146489C2A5CF4B68380953B270E
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_6B8CF146489C2A5CF4B68380953B270E
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnInterrupted_CB052D0449732D9E04B5E68488268F05
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_CB052D0449732D9E04B5E68488268F05
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.InitializeLaunchVariables
// Size: 0x98(Inherited: 0x0) 
struct FInitializeLaunchVariables
{
	struct AORCharacter* OwningORCharacter;  // 0x0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x18(0x8)
	struct USQFiringResultComponent* CallFunc_GetFireableItemFireModeFiringResult_ReturnValue;  // 0x20(0x8)
	struct FVector CallFunc_GetFocalPoint_ReturnValue;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)
	struct UORFiringResult_Projectile* K2Node_DynamicCast_AsORFiring_Result_Projectile;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_BreakVector_X;  // 0x44(0x4)
	float CallFunc_BreakVector_Y;  // 0x48(0x4)
	float CallFunc_BreakVector_Z;  // 0x4C(0x4)
	struct AActor* CallFunc_GetTargetActorKey_OutTargetActor;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_GetTargetActorKey_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x5C(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x68(0x4)
	float CallFunc_GetRandomOffset_RandomValue;  // 0x6C(0x4)
	float CallFunc_NormalizeToRangeClamped_ReturnValue;  // 0x70(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x74(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x78(0x4)
	float CallFunc_GetRandomOffset_RandomValue_2;  // 0x7C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x80(0x4)
	float CallFunc_GetRandomOffset_RandomValue_3;  // 0x84(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x88(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x8C(0xC)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnNotifyEnd_CB052D0449732D9E04B5E68488268F05
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_CB052D0449732D9E04B5E68488268F05
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.OnDamageTaken
// Size: 0xC8(Inherited: 0x0) 
struct FOnDamageTaken
{
	struct UObject* Damager;  // 0x0(0x8)
	struct AORCharacter* Damaged;  // 0x8(0x8)
	struct FHitResult HitResult;  // 0x10(0x90)
	float Damage;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA8(0x20)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.K2_CanActivateAbility
// Size: 0x71(Inherited: 0x78) 
struct FK2_CanActivateAbility : public FK2_CanActivateAbility
{
	struct FGameplayAbilityActorInfo ActorInfo;  // 0x0(0x48)
	struct FGameplayAbilitySpecHandle Handle;  // 0x48(0x4)
	struct FGameplayTagContainer RelevantTags;  // 0x50(0x20)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.FindLaunchVelocity
// Size: 0x1A8(Inherited: 0x0) 
struct FFindLaunchVelocity
{
	struct FVector LaunchVelocity;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool FoundValidLaunchVelocity : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x28(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x38(0x10)
	struct FHitResult CallFunc_Blueprint_PredictProjectilePath_ByTraceChannel_OutHit;  // 0x48(0x90)
	struct TArray<struct FVector> CallFunc_Blueprint_PredictProjectilePath_ByTraceChannel_OutPathPositions;  // 0xD8(0x10)
	struct FVector CallFunc_Blueprint_PredictProjectilePath_ByTraceChannel_OutLastTraceDestination;  // 0xE8(0xC)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_Blueprint_PredictProjectilePath_ByTraceChannel_ReturnValue : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	float CallFunc_Array_Get_Item;  // 0xF8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xFC(0x4)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x101(0x1)
	char pad_258[2];  // 0x102(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x104(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x108(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x10C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x118(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x124(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x130(0xC)
	char pad_316[4];  // 0x13C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x140(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x148(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x150(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x158(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x160(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x164(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x168(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x16C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x178(0xC)
	struct FVector CallFunc_BlueprintSuggestProjectileVelocity_TossVelocity;  // 0x184(0xC)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_BlueprintSuggestProjectileVelocity_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	float CallFunc_Dot_VectorVector_ReturnValue;  // 0x194(0x4)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x198(0x1)
	char pad_409[3];  // 0x199(0x3)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x19C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1A0(0x4)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x1A4(0x1)
	char pad_421_1 : 7;  // 0x1A5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1A5(0x1)
	char pad_422_1 : 7;  // 0x1A6(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1A6(0x1)
	char pad_423_1 : 7;  // 0x1A7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1A7(0x1)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.GetRandomOffset
// Size: 0x14(Inherited: 0x0) 
struct FGetRandomOffset
{
	int32_t Min;  // 0x0(0x4)
	int32_t Max;  // 0x4(0x4)
	float RandomValue;  // 0x8(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0xC(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x10(0x4)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetDamageEventBindEnabled
// Size: 0x39(Inherited: 0x0) 
struct FSetDamageEventBindEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x28(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetChargeAudioEnabled
// Size: 0x20(Inherited: 0x0) 
struct FSetChargeAudioEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x10(0xC)
	int32_t CallFunc_PostEventAtLocation_ReturnValue;  // 0x1C(0x4)

}; 
// Function AICookAndThrowGrenade_GA.AICookAndThrowGrenade_GA_C.SetWarningWidget
// Size: 0x79(Inherited: 0x0) 
struct FSetWarningWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x18(0x8)
	struct AORHUD* K2Node_DynamicCast_AsORHUD;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x30(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct AHUD* CallFunc_GetHUD_ReturnValue_2;  // 0x58(0x8)
	struct AORHUD* K2Node_DynamicCast_AsORHUD_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UORWidget_HUDPrompt* CallFunc_CacheAndCreateHUDPromptWidget_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x78(0x1)

}; 
