#pragma once 
#include <BTT_FindRandomMoveToLocationAnchored_Structs.h>
 
 
 
// BlueprintGeneratedClass BTT_FindRandomMoveToLocationAnchored.BTT_FindRandomMoveToLocationAnchored_C
// Size: 0x120(Inherited: 0xA8) 
struct UBTT_FindRandomMoveToLocationAnchored_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector MoveToLocation;  // 0xB0(0x28)
	struct FBlackboardKeySelector AnchorRadius;  // 0xD8(0x28)
	struct APawn* ControlledPawn;  // 0x100(0x8)
	struct UEnvQuery* EQS_RandomMoveAnchored;  // 0x108(0x8)
	struct UEnvQuery* EQS_RandomMoveAnchoredFallback;  // 0x110(0x8)
	struct UEnvQuery* EQS_TransientPickedForExecution;  // 0x118(0x8)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindRandomMoveToLocationAnchored.BTT_FindRandomMoveToLocationAnchored_C.ReceiveExecuteAI
	void QueryComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus); // Function BTT_FindRandomMoveToLocationAnchored.BTT_FindRandomMoveToLocationAnchored_C.QueryComplete
	void ExecuteUbergraph_BTT_FindRandomMoveToLocationAnchored(int32_t EntryPoint); // Function BTT_FindRandomMoveToLocationAnchored.BTT_FindRandomMoveToLocationAnchored_C.ExecuteUbergraph_BTT_FindRandomMoveToLocationAnchored
}; 



