#pragma once 
#include <Chonk_EnemyMortar_BarrageDamage_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_EnemyMortar_BarrageDamage.Chonk_EnemyMortar_BarrageDamage_C
// Size: 0x818(Inherited: 0x818) 
struct UChonk_EnemyMortar_BarrageDamage_C : public UChonk_EnemyMortar_PrimaryDamage_C
{

}; 



