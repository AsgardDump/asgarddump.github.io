#pragma once 
#include <CableComponent_Structs.h>
 
 
 
// Class CableComponent.CableActor
// Size: 0x228(Inherited: 0x220) 
struct ACableActor : public AActor
{
	struct UCableComponent* CableComponent;  // 0x220(0x8)

}; 



// Class CableComponent.CableComponent
// Size: 0x570(Inherited: 0x4E0) 
struct UCableComponent : public UMeshComponent
{
	char pad_1248_1 : 7;  // 0x4E0(0x1)
	bool bAttachStart : 1;  // 0x4D8(0x1)
	char pad_1249_1 : 7;  // 0x4E1(0x1)
	bool bAttachEnd : 1;  // 0x4D9(0x1)
	struct FComponentReference AttachEndTo;  // 0x4E0(0x28)
	struct FName AttachEndToSocketName;  // 0x508(0x8)
	struct FVector EndLocation;  // 0x510(0xC)
	float CableLength;  // 0x51C(0x4)
	int32_t NumSegments;  // 0x520(0x4)
	float SubstepTime;  // 0x524(0x4)
	int32_t SolverIterations;  // 0x528(0x4)
	char pad_1326_1 : 7;  // 0x52E(0x1)
	bool bEnableStiffness : 1;  // 0x52C(0x1)
	char pad_1327_1 : 7;  // 0x52F(0x1)
	bool bUseSubstepping : 1;  // 0x52D(0x1)
	char pad_1328_1 : 7;  // 0x530(0x1)
	bool bSkipCableUpdateWhenNotVisible : 1;  // 0x52E(0x1)
	char pad_1329_1 : 7;  // 0x531(0x1)
	bool bSkipCableUpdateWhenNotOwnerRecentlyRendered : 1;  // 0x52F(0x1)
	char pad_1330_1 : 7;  // 0x532(0x1)
	bool bEnableCollision : 1;  // 0x530(0x1)
	char pad_1331[1];  // 0x533(0x1)
	float CollisionFriction;  // 0x534(0x4)
	struct FVector CableForce;  // 0x538(0xC)
	float CableGravityScale;  // 0x544(0x4)
	float CableWidth;  // 0x548(0x4)
	int32_t NumSides;  // 0x54C(0x4)
	float TileMaterial;  // 0x550(0x4)
	char pad_1364[28];  // 0x554(0x1C)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor
}; 



