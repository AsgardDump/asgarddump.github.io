#pragma once 
#include <Base_Fauna_Enemy_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Base_Fauna_Enemy_BP.Base_Fauna_Enemy_BP_C
// Size: 0x20F8(Inherited: 0x20E0) 
struct ABase_Fauna_Enemy_BP_C : public AORAIFaunaCharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x20E0(0x8)
	struct FName PlayerEventNameForKnifeyEnemyDeath;  // 0x20E8(0x8)
	struct FName PlayerEventNameForGunEnemyDeath;  // 0x20F0(0x8)

	void OnDied(struct UObject* Killer, struct FHitResult& HitResult, struct FGameplayTagContainer& DamageTags); // Function Base_Fauna_Enemy_BP.Base_Fauna_Enemy_BP_C.OnDied
	void ExecuteUbergraph_Base_Fauna_Enemy_BP(int32_t EntryPoint); // Function Base_Fauna_Enemy_BP.Base_Fauna_Enemy_BP_C.ExecuteUbergraph_Base_Fauna_Enemy_BP
}; 



