#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct Achievements_CombatStatRow_ST.Achievements_CombatStatRow_ST
// Size: 0x24(Inherited: 0x0) 
struct FAchievements_CombatStatRow_ST
{
	struct FName StatName_31_CF66E3E4465F88A08DB2C69CA1973219;  // 0x0(0x8)
	struct FGameplayTag Event_19_354AB97F417FE73EEBF1D583A6CE2A84;  // 0x8(0x8)
	struct TArray<struct FGameplayTag> StatTags_21_4CA357324BE089DB2FA567A6419CC9B6;  // 0x10(0x10)
	int32_t MaxValue_28_4BF11DBF449065B667366BB09516262B;  // 0x20(0x4)

}; 
