#pragma once 
#include "SDK.h" 
 
 
// Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ExecuteUbergraph_BTS_Mercuna_FocusTargetActorInRange
// Size: 0x42(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_Mercuna_FocusTargetActorInRange
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x18(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x20(0x8)
	struct AAIController* K2Node_Event_OwnerController_3;  // 0x28(0x8)
	struct APawn* K2Node_Event_ControlledPawn_3;  // 0x30(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x38(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x41(0x1)

}; 
// Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ReceiveDeactivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveDeactivationAI : public FReceiveDeactivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ReceiveActivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveActivationAI : public FReceiveActivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.UpdateControllerFocus
// Size: 0x50(Inherited: 0x0) 
struct FUpdateControllerFocus
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	struct APawn* CachedPawn;  // 0x10(0x8)
	struct AAIController* TheOwnerController;  // 0x18(0x8)
	struct AActor* CachedTargetActor;  // 0x20(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AActor* CallFunc_GetFocusActor_ReturnValue;  // 0x38(0x8)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x45(0x1)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x48(0x8)

}; 
// Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ClearMercunaLookAt
// Size: 0x12(Inherited: 0x0) 
struct FClearMercunaLookAt
{
	struct APawn* controllerPawn;  // 0x0(0x8)
	struct UMercuna3DNavigationComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x11(0x1)

}; 
// Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.Set Mercuna Look At
// Size: 0x1A(Inherited: 0x0) 
struct FSet Mercuna Look At
{
	struct APawn* controllerPawn;  // 0x0(0x8)
	struct AActor* TargetActor;  // 0x8(0x8)
	struct UMercuna3DNavigationComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)

}; 
