#pragma once 
#include <BaseSkelMeshCustomizableNPC_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C
// Size: 0x500(Inherited: 0x480) 
struct ABaseSkelMeshCustomizableNPC_BP_C : public AORBaseSkelMeshCustomizableNPC
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x480(0x8)
	struct USkeletalMeshComponent* ShoesMesh;  // 0x488(0x8)
	struct USkeletalMeshComponent* LegsMesh;  // 0x490(0x8)
	struct USkeletalMeshComponent* TorsoMesh;  // 0x498(0x8)
	struct UORDetachedTriggerComponent* InterruptVolume;  // 0x4A0(0x8)
	struct UNarrativeInfluenceVolumeComponent_BP_C* NIV;  // 0x4A8(0x8)
	struct UTrigger_OptIntoComponent_C* OptIntoTrigger;  // 0x4B0(0x8)
	struct UORTriggerVolumeComponent* ORTriggerVolume;  // 0x4B8(0x8)
	struct UAnimSequence* IdleOverride;  // 0x4C0(0x8)
	struct ATrigger_OptInto_C* OptInto;  // 0x4C8(0x8)
	struct FMulticastInlineDelegate OnOptIn;  // 0x4D0(0x30)

	void UpdateAnimationInEditor(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.UpdateAnimationInEditor
	void SetupAutomaticMaterialParams(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.SetupAutomaticMaterialParams
	void SetOptIntoActive(bool InEnabled); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.SetOptIntoActive
	void UserConstructionScript(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.ReceiveBeginPlay
	void OnOptedInto(); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.OnOptedInto
	void ExecuteUbergraph_BaseSkelMeshCustomizableNPC_BP(int32_t EntryPoint); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.ExecuteUbergraph_BaseSkelMeshCustomizableNPC_BP
	void OnOptIn__DelegateSignature(struct UTrigger_OptIntoComponent_C* OptInto); // Function BaseSkelMeshCustomizableNPC_BP.BaseSkelMeshCustomizableNPC_BP_C.OnOptIn__DelegateSignature
}; 



