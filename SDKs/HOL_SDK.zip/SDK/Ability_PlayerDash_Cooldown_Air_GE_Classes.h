#pragma once 
#include <Ability_PlayerDash_Cooldown_Air_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_PlayerDash_Cooldown_Air_GE.Ability_PlayerDash_Cooldown_Air_GE_C
// Size: 0x810(Inherited: 0x810) 
struct UAbility_PlayerDash_Cooldown_Air_GE_C : public UGameplayEffect
{

}; 



