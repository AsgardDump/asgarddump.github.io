#pragma once 
#include <BTT_FindRandomMoveToLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C
// Size: 0xDC(Inherited: 0xA8) 
struct UBTT_FindRandomMoveToLocation_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector MoveToLocation;  // 0xB0(0x28)
	float Radius;  // 0xD8(0x4)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C.ReceiveExecuteAI
	void ExecuteUbergraph_BTT_FindRandomMoveToLocation(int32_t EntryPoint); // Function BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C.ExecuteUbergraph_BTT_FindRandomMoveToLocation
}; 



