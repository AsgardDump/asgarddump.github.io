#pragma once 
#include <BTS_SetAllowStationaryRotation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C
// Size: 0xA2(Inherited: 0x98) 
struct UBTS_SetAllowStationaryRotation_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool AllowStationaryRotation : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool InitialAllowStationaryRotation : 1;  // 0xA1(0x1)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C.ReceiveDeactivationAI
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C.ReceiveActivationAI
	void ExecuteUbergraph_BTS_SetAllowStationaryRotation(int32_t EntryPoint); // Function BTS_SetAllowStationaryRotation.BTS_SetAllowStationaryRotation_C.ExecuteUbergraph_BTS_SetAllowStationaryRotation
}; 



