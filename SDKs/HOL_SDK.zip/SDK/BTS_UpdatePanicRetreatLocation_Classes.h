#pragma once 
#include <BTS_UpdatePanicRetreatLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C
// Size: 0xE0(Inherited: 0x98) 
struct UBTS_UpdatePanicRetreatLocation_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector MoveToLocation;  // 0xA0(0x28)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool IsQueryRunning : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct UEnvQueryInstanceBlueprintWrapper* RunningEQSQuery;  // 0xD0(0x8)
	struct AAIController* OwnedController;  // 0xD8(0x8)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ReceiveTickAI
	void EQS_QueryComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.EQS_QueryComplete
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ReceiveDeactivationAI
	void ExecuteUbergraph_BTS_UpdatePanicRetreatLocation(int32_t EntryPoint); // Function BTS_UpdatePanicRetreatLocation.BTS_UpdatePanicRetreatLocation_C.ExecuteUbergraph_BTS_UpdatePanicRetreatLocation
}; 



