#pragma once 
#include "SDK.h" 
 
 
// Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.ExecuteUbergraph_BTS_FindCreatureMinionMoveToMarker
// Size: 0xAB(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_FindCreatureMinionMoveToMarker
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x8(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x20(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x28(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct AORAICreatureMinionController* K2Node_DynamicCast_AsORAICreature_Minion_Controller;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x54(0x10)
	char pad_100[4];  // 0x64(0x4)
	struct UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance;  // 0x68(0x8)
	char EEnvQueryStatus K2Node_CustomEvent_QueryStatus;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x71(0x1)
	char pad_114[6];  // 0x72(0x6)
	struct TArray<struct AActor*> CallFunc_GetQueryResultsAsActors_ResultActors;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_GetQueryResultsAsActors_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct AActor* CallFunc_Array_Get_Item;  // 0x90(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct ACreatureMinionMoveToMarker_BP_C* K2Node_DynamicCast_AsCreature_Minion_Move_to_Marker_BP;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xAA(0x1)

}; 
// Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.QueryFinished
// Size: 0x9(Inherited: 0x0) 
struct FQueryFinished
{
	struct UEnvQueryInstanceBlueprintWrapper* QueryInstance;  // 0x0(0x8)
	char EEnvQueryStatus QueryStatus;  // 0x8(0x1)

}; 
// Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
