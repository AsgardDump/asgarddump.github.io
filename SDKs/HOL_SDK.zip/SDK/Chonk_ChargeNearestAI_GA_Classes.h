#pragma once 
#include <Chonk_ChargeNearestAI_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_ChargeNearestAI_GA.Chonk_ChargeNearestAI_GA_C
// Size: 0x478(Inherited: 0x478) 
struct UChonk_ChargeNearestAI_GA_C : public UHenchman_ChargeNearestAI_GA_C
{

}; 



