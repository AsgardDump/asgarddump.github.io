#pragma once 
#include <BTD_HasCoverBeenFlanked_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C
// Size: 0xD0(Inherited: 0xA0) 
struct UBTD_HasCoverBeenFlanked_C : public UBTDecorator_BlueprintBase
{
	struct FBlackboardKeySelector TargetLastKnownLocationBBKey;  // 0xA0(0x28)
	float MinDistanceFromTarget;  // 0xC8(0x4)
	float BreakOutDamage;  // 0xCC(0x4)

	void IsAttractionPointInHomeArea(struct UObject* AttractionPoint, struct AORAIController* Controller, bool& Out); // Function BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C.IsAttractionPointInHomeArea
	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_HasCoverBeenFlanked.BTD_HasCoverBeenFlanked_C.PerformConditionCheckAI
}; 



