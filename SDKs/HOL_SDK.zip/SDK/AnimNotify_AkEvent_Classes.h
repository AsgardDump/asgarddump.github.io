#pragma once 
#include <AnimNotify_AkEvent_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimNotify_AkEvent.AnimNotify_AkEvent_C
// Size: 0x70(Inherited: 0x38) 
struct UAnimNotify_AkEvent_C : public UAnimNotify
{
	struct FString Attach Name;  // 0x38(0x10)
	struct UAkAudioEvent* Event;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Follow : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString EventName;  // 0x58(0x10)
	struct FGameplayTag ComponentToUse;  // 0x68(0x8)

	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_AkEvent.AnimNotify_AkEvent_C.Received_Notify
}; 



