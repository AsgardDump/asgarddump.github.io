#pragma once 
#include <BaseAICharacter_Stagger_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C
// Size: 0x59C(Inherited: 0x480) 
struct UBaseAICharacter_Stagger_GA_C : public UActivateOnAppliedGETag_GA_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x480(0x8)
	struct AORAICharacter* OwnerAICharacter;  // 0x488(0x8)
	struct AStagger_Melee_Interact_Prompt_BP_C* InteractPrompt;  // 0x490(0x8)
	struct UORAbilityTask_WaitGameplayEffectApplied* Async Task;  // 0x498(0x8)
	struct FGameplayTagRequirements StaggerTag;  // 0x4A0(0x40)
	uint8_t  StunStatus;  // 0x4E0(0x1)
	char pad_1249[3];  // 0x4E1(0x3)
	struct FName StatusEffectBBKey;  // 0x4E4(0x8)
	float EndAbilityTimer;  // 0x4EC(0x4)
	struct FTimerHandle AbilityEndTimerHandle;  // 0x4F0(0x8)
	char pad_1272_1 : 7;  // 0x4F8(0x1)
	bool AbilityStarted : 1;  // 0x4F8(0x1)
	char pad_1273[7];  // 0x4F9(0x7)
	struct FGameplayTagRequirements DeepcutTag;  // 0x500(0x40)
	float DeepcutInteractRadius;  // 0x540(0x4)
	struct FName CharactersHeadSocketName;  // 0x544(0x8)
	char pad_1356[4];  // 0x54C(0x4)
	struct UNiagaraComponent* NiagaraStaggerFXInstance;  // 0x550(0x8)
	struct UNiagaraSystem* NiagaraStaggerFXTemplate;  // 0x558(0x8)
	float StaggerFXDuration;  // 0x560(0x4)
	float StaggerFXRadiusSize;  // 0x564(0x4)
	float StaggerFXStarSize;  // 0x568(0x4)
	char pad_1388[4];  // 0x56C(0x4)
	UGameplayEffect* StaggeredGameplayEffectClass;  // 0x570(0x8)
	char pad_1400_1 : 7;  // 0x578(0x1)
	bool DoesEndStaggerOnDeepcut : 1;  // 0x578(0x1)
	char pad_1401[3];  // 0x579(0x3)
	struct FName OverrideDeepcutSocket;  // 0x57C(0x8)
	char pad_1412[4];  // 0x584(0x4)
	struct TArray<struct FName> SocketCache;  // 0x588(0x10)
	float NDTriggerStaggerLineMaxDistance;  // 0x598(0x4)

	void TriggerNDEnemyStaggerLine(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.TriggerNDEnemyStaggerLine
	void ClearOverrideSocket(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.ClearOverrideSocket
	void SetOverrideSocket(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetOverrideSocket
	void HandleStaggerFXCustomSettings(struct UNiagaraComponent* StaggerFXInstance); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.HandleStaggerFXCustomSettings
	void SetStaggeredFXEnabled(bool Enabled); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetStaggeredFXEnabled
	void SetAIStatusEffect(uint8_t  NewStatusEffect); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.SetAIStatusEffect
	void OnEffectApplied_4B30CE0F4EA8886D752C7A844956F762(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnEffectApplied_4B30CE0F4EA8886D752C7A844956F762
	void OnEffectApplied_65F2657D4CC203E18217CF988A825D0B(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnEffectApplied_65F2657D4CC203E18217CF988A825D0B
	void OnCompleted_E6EFFAD846C9B0FEBC64EB8734803303(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnCompleted_E6EFFAD846C9B0FEBC64EB8734803303
	void OnTick_E6EFFAD846C9B0FEBC64EB8734803303(float DeltaTime, float TotalElapsed); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.OnTick_E6EFFAD846C9B0FEBC64EB8734803303
	void K2_ActivateAbility(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.K2_ActivateAbility
	void K2_CommitExecute(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.K2_CommitExecute
	void StaggerCompleted(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.StaggerCompleted
	void DeepCutTriggered(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.DeepCutTriggered
	void CharacterDied(struct AORAICharacter* Victim, struct UObject* Killer); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.CharacterDied
	void DisableDeepcut(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.DisableDeepcut
	void StaggerTimerEnded(); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.StaggerTimerEnded
	void K2_OnEndAbility(bool bWasCancelled); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.K2_OnEndAbility
	void ExecuteUbergraph_BaseAICharacter_Stagger_GA(int32_t EntryPoint); // Function BaseAICharacter_Stagger_GA.BaseAICharacter_Stagger_GA_C.ExecuteUbergraph_BaseAICharacter_Stagger_GA
}; 



