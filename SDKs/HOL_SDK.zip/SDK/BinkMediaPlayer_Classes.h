#pragma once 
#include <BinkMediaPlayer_Structs.h>
 
 
 
// Class BinkMediaPlayer.BinkFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UBinkFunctionLibrary : public UBlueprintFunctionLibrary
{

	struct FTimespan BinkLoadingMovie_GetTime(); // Function BinkMediaPlayer.BinkFunctionLibrary.BinkLoadingMovie_GetTime
	struct FTimespan BinkLoadingMovie_GetDuration(); // Function BinkMediaPlayer.BinkFunctionLibrary.BinkLoadingMovie_GetDuration
	void Bink_DrawOverlays(); // Function BinkMediaPlayer.BinkFunctionLibrary.Bink_DrawOverlays
}; 



// Class BinkMediaPlayer.BinkMediaPlayer
// Size: 0x180(Inherited: 0x28) 
struct UBinkMediaPlayer : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct FMulticastInlineDelegate OnMediaClosed;  // 0x30(0x30)
	struct FMulticastInlineDelegate OnMediaOpened;  // 0x60(0x30)
	struct FMulticastInlineDelegate OnMediaReachedEnd;  // 0x90(0x30)
	struct FMulticastInlineDelegate OnPlaybackSuspended;  // 0xC0(0x30)
	char Looping : 1;  // 0xF0(0x1)
	char StartImmediately : 1;  // 0xF0(0x1)
	char DelayedOpen : 1;  // 0xF0(0x1)
	char pad_240_1 : 5;  // 0xF0(0x1)
	char pad_241[4];  // 0xF1(0x4)
	struct FVector2D BinkDestinationUpperLeft;  // 0xF4(0x8)
	struct FVector2D BinkDestinationLowerRight;  // 0xFC(0x8)
	char pad_260[4];  // 0x104(0x4)
	struct FString URL;  // 0x108(0x10)
	char EBinkMediaPlayerBinkBufferModes BinkBufferMode;  // 0x118(0x1)
	char EBinkMediaPlayerBinkSoundTrack BinkSoundTrack;  // 0x119(0x1)
	char pad_282[2];  // 0x11A(0x2)
	int32_t BinkSoundTrackStart;  // 0x11C(0x4)
	char EBinkMediaPlayerBinkDrawStyle BinkDrawStyle;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	int32_t BinkLayerDepth;  // 0x124(0x4)
	char pad_296[88];  // 0x128(0x58)

	bool SupportsSeeking(); // Function BinkMediaPlayer.BinkMediaPlayer.SupportsSeeking
	bool SupportsScrubbing(); // Function BinkMediaPlayer.BinkMediaPlayer.SupportsScrubbing
	bool SupportsRate(float Rate, bool Unthinned); // Function BinkMediaPlayer.BinkMediaPlayer.SupportsRate
	void Stop(); // Function BinkMediaPlayer.BinkMediaPlayer.Stop
	void SetVolume(float Rate); // Function BinkMediaPlayer.BinkMediaPlayer.SetVolume
	bool SetRate(float Rate); // Function BinkMediaPlayer.BinkMediaPlayer.SetRate
	bool SetLooping(bool InLooping); // Function BinkMediaPlayer.BinkMediaPlayer.SetLooping
	bool Seek(struct FTimespan& InTime, int32_t MsPerFrameSeek); // Function BinkMediaPlayer.BinkMediaPlayer.Seek
	bool Rewind(); // Function BinkMediaPlayer.BinkMediaPlayer.Rewind
	bool Play(); // Function BinkMediaPlayer.BinkMediaPlayer.Play
	bool Pause(); // Function BinkMediaPlayer.BinkMediaPlayer.Pause
	bool OpenUrl(struct FString NewUrl); // Function BinkMediaPlayer.BinkMediaPlayer.OpenUrl
	bool IsStopped(); // Function BinkMediaPlayer.BinkMediaPlayer.IsStopped
	bool IsPlaying(); // Function BinkMediaPlayer.BinkMediaPlayer.IsPlaying
	bool IsPaused(); // Function BinkMediaPlayer.BinkMediaPlayer.IsPaused
	bool IsLooping(); // Function BinkMediaPlayer.BinkMediaPlayer.IsLooping
	bool IsInitialized(); // Function BinkMediaPlayer.BinkMediaPlayer.IsInitialized
	struct FString GetUrl(); // Function BinkMediaPlayer.BinkMediaPlayer.GetUrl
	struct FTimespan GetTime(); // Function BinkMediaPlayer.BinkMediaPlayer.GetTime
	float GetRate(); // Function BinkMediaPlayer.BinkMediaPlayer.GetRate
	struct FTimespan GetDuration(); // Function BinkMediaPlayer.BinkMediaPlayer.GetDuration
	void Draw(struct UTexture* Texture, bool tonemap, int32_t out_nits, float Alpha, bool srgb_decode, bool hdr); // Function BinkMediaPlayer.BinkMediaPlayer.Draw
	void CloseUrl(); // Function BinkMediaPlayer.BinkMediaPlayer.CloseUrl
	bool CanPlay(); // Function BinkMediaPlayer.BinkMediaPlayer.CanPlay
	bool CanPause(); // Function BinkMediaPlayer.BinkMediaPlayer.CanPause
}; 



// Class BinkMediaPlayer.BinkMediaTexture
// Size: 0x1B0(Inherited: 0x180) 
struct UBinkMediaTexture : public UTexture
{
	char TextureAddress AddressX;  // 0x178(0x1)
	char TextureAddress AddressY;  // 0x179(0x1)
	struct UBinkMediaPlayer* MediaPlayer;  // 0x180(0x8)
	char EPixelFormat PixelFormat;  // 0x188(0x1)
	char pad_395_1 : 7;  // 0x18B(0x1)
	bool tonemap : 1;  // 0x189(0x1)
	float OutputNits;  // 0x18C(0x4)
	float Alpha;  // 0x190(0x4)
	char pad_404_1 : 7;  // 0x194(0x1)
	bool DecodeSRGB : 1;  // 0x194(0x1)
	char pad_405[27];  // 0x195(0x1B)

	void SetMediaPlayer(struct UBinkMediaPlayer* InMediaPlayer); // Function BinkMediaPlayer.BinkMediaTexture.SetMediaPlayer
	void Clear(); // Function BinkMediaPlayer.BinkMediaTexture.Clear
}; 



// Class BinkMediaPlayer.BinkMoviePlayerSettings
// Size: 0x48(Inherited: 0x28) 
struct UBinkMoviePlayerSettings : public UObject
{
	char EBinkMoviePlayerBinkBufferModes BinkBufferMode;  // 0x28(0x1)
	char EBinkMoviePlayerBinkSoundTrack BinkSoundTrack;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t BinkSoundTrackStart;  // 0x2C(0x4)
	struct FVector2D BinkDestinationUpperLeft;  // 0x30(0x8)
	struct FVector2D BinkDestinationLowerRight;  // 0x38(0x8)
	char EPixelFormat BinkPixelFormat;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 



