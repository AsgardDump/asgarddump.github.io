#pragma once 
#include <Bounce_GC_Structs.h>
 
 
 
// BlueprintGeneratedClass Bounce_GC.Bounce_GC_C
// Size: 0x41(Inherited: 0x40) 
struct UBounce_GC_C : public UGameplayCueNotify_Static
{
	char pad_64_1 : 7;  // 0x40(0x1)
	bool DoesPlayVO : 1;  // 0x40(0x1)

	bool OnActive(struct AActor* MyTarget, struct FGameplayCueParameters& Parameters); // Function Bounce_GC.Bounce_GC_C.OnActive
}; 



