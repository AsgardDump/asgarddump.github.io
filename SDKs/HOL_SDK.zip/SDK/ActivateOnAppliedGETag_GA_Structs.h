#pragma once 
#include "SDK.h" 
 
 
// Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.ExecuteUbergraph_ActivateOnAppliedGETag_GA
// Size: 0xA9(Inherited: 0x0) 
struct FExecuteUbergraph_ActivateOnAppliedGETag_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct FActiveGameplayEffectHandle K2Node_CustomEvent_ActiveEffectHandle;  // 0x20(0x8)
	struct FGameplayEffectSpecHandle K2Node_CustomEvent_EffectSpecHandle;  // 0x28(0x10)
	struct FGameplayEffectSpecHandle Temp_struct_Variable;  // 0x38(0x10)
	struct FActiveGameplayEffectHandle Temp_struct_Variable_2;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_K2_CommitAbility_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct UAbilitySystemComponent* CallFunc_GetAbilitySystemComponentFromActorInfo_ReturnValue;  // 0x58(0x8)
	struct FGameplayTagRequirements K2Node_MakeStruct_GameplayTagRequirements;  // 0x60(0x40)
	struct UORAbilityTask_WaitGameplayEffectApplied* CallFunc_ListenForGameplayEffectApplied_ReturnValue;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA8(0x1)

}; 
// Function ActivateOnAppliedGETag_GA.ActivateOnAppliedGETag_GA_C.OnEffectApplied_57C2DC75421B4EF1205EA583C33EF7C1
// Size: 0x18(Inherited: 0x0) 
struct FOnEffectApplied_57C2DC75421B4EF1205EA583C33EF7C1
{
	struct FActiveGameplayEffectHandle ActiveEffectHandle;  // 0x0(0x8)
	struct FGameplayEffectSpecHandle EffectSpecHandle;  // 0x8(0x10)

}; 
