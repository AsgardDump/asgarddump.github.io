#pragma once 
#include "SDK.h" 
 
 
// Function Ability_PowerSlide.Ability_PowerSlide_C.K2_OnEndAbility
// Size: 0x1(Inherited: 0x1) 
struct FK2_OnEndAbility : public FK2_OnEndAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bWasCancelled : 1;  // 0x0(0x1)

}; 
// Function Ability_PowerSlide.Ability_PowerSlide_C.ExecuteUbergraph_Ability_PowerSlide
// Size: 0x27C(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_PowerSlide
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FGameplayTagContainer Temp_struct_Variable;  // 0x8(0x20)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FGameplayEventData K2Node_CustomEvent_Payload;  // 0x40(0xB0)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct FGameplayEventData Temp_struct_Variable_2;  // 0xF8(0xB0)
	struct UAbilityTask_WaitGameplayEvent* CallFunc_WaitGameplayEvent_ReturnValue;  // 0x1A8(0x8)
	struct TScriptInterface<IGameplayTagAssetInterface> K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface;  // 0x1B0(0x10)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	struct FGameplayTagContainer CallFunc_GetOwnedGameplayTags_TagContainer;  // 0x1C8(0x20)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1E8(0x1)
	char pad_489[7];  // 0x1E9(0x7)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable_3;  // 0x1F0(0x10)
	struct FDelegate Temp_delegate_Variable;  // 0x200(0x10)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x210(0x8)
	struct UPawnMovementComponent* CallFunc_GetMovementComponent_ReturnValue;  // 0x218(0x8)
	struct UORPlayerMovementComponent* K2Node_DynamicCast_AsORPlayer_Movement_Component;  // 0x220(0x8)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x228(0x1)
	char pad_553_1 : 7;  // 0x229(0x1)
	bool K2Node_Event_bWasCancelled : 1;  // 0x229(0x1)
	char pad_554[6];  // 0x22A(0x6)
	struct FGameplayAbilityActorInfo CallFunc_GetActorInfo_ReturnValue;  // 0x230(0x48)
	int32_t CallFunc_PostEvent_ReturnValue;  // 0x278(0x4)

}; 
// Function Ability_PowerSlide.Ability_PowerSlide_C.EventReceived_8B92170A42AFC0058D8C9B95BD1EF44F
// Size: 0xB0(Inherited: 0x0) 
struct FEventReceived_8B92170A42AFC0058D8C9B95BD1EF44F
{
	struct FGameplayEventData Payload;  // 0x0(0xB0)

}; 
// Function Ability_PowerSlide.Ability_PowerSlide_C.GetCameraManager
// Size: 0x59(Inherited: 0x0) 
struct FGetCameraManager
{
	struct AORPlayerCameraManager* CameraManager;  // 0x0(0x8)
	struct FGameplayAbilityActorInfo CallFunc_GetActorInfo_ReturnValue;  // 0x8(0x48)
	struct AORPlayerCameraManager* K2Node_DynamicCast_AsORPlayer_Camera_Manager;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)

}; 
