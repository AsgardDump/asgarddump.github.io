#pragma once 
#include <ArmorPlatedMyte_HeavyArmor_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ArmorPlatedMyte_HeavyArmor_GA.ArmorPlatedMyte_HeavyArmor_GA_C
// Size: 0x470(Inherited: 0x464) 
struct UArmorPlatedMyte_HeavyArmor_GA_C : public UHeavyArmor_Removable_GA_C
{
	char pad_1124[4];  // 0x464(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x468(0x8)

	void OnHeavyArmorDestroyed(); // Function ArmorPlatedMyte_HeavyArmor_GA.ArmorPlatedMyte_HeavyArmor_GA_C.OnHeavyArmorDestroyed
	void ExecuteUbergraph_ArmorPlatedMyte_HeavyArmor_GA(int32_t EntryPoint); // Function ArmorPlatedMyte_HeavyArmor_GA.ArmorPlatedMyte_HeavyArmor_GA_C.ExecuteUbergraph_ArmorPlatedMyte_HeavyArmor_GA
}; 



