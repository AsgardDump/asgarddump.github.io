#pragma once 
#include <AIPrimaryBlindFire_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C
// Size: 0x490(Inherited: 0x428) 
struct UAIPrimaryBlindFire_GA_C : public UORGameplayAbility_FireItem
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x428(0x8)
	struct TMap<uint8_t , struct UAnimMontage*> CoverHighBlindFireMontages;  // 0x430(0x50)
	struct TArray<struct UAnimMontage*> CoverLowBlindFireMontages;  // 0x480(0x10)

	void GetCoverCornerType(uint8_t & CoverCornerType); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.GetCoverCornerType
	struct UAnimMontage* GetBlindFireMontageToPlay(); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.GetBlindFireMontageToPlay
	void EnableDamageEventBind(bool Enable); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.EnableDamageEventBind
	void OnNotifyEnd_C0F530694A22E5D9ED67E6ADD3B32677(struct FName NotifyName); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnNotifyEnd_C0F530694A22E5D9ED67E6ADD3B32677
	void OnNotifyBegin_C0F530694A22E5D9ED67E6ADD3B32677(struct FName NotifyName); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnNotifyBegin_C0F530694A22E5D9ED67E6ADD3B32677
	void OnInterrupted_C0F530694A22E5D9ED67E6ADD3B32677(struct FName NotifyName); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnInterrupted_C0F530694A22E5D9ED67E6ADD3B32677
	void OnBlendOut_C0F530694A22E5D9ED67E6ADD3B32677(struct FName NotifyName); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnBlendOut_C0F530694A22E5D9ED67E6ADD3B32677
	void OnCompleted_C0F530694A22E5D9ED67E6ADD3B32677(struct FName NotifyName); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnCompleted_C0F530694A22E5D9ED67E6ADD3B32677
	void K2_ActivateAbility(); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.K2_ActivateAbility
	void K2_CommitExecute(); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.K2_CommitExecute
	void OnDamageTaken(struct UObject* Damager, struct AORCharacter* Damaged, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.OnDamageTaken
	void K2_OnEndAbility(bool bWasCancelled); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.K2_OnEndAbility
	void ExecuteUbergraph_AIPrimaryBlindFire_GA(int32_t EntryPoint); // Function AIPrimaryBlindFire_GA.AIPrimaryBlindFire_GA_C.ExecuteUbergraph_AIPrimaryBlindFire_GA
}; 



