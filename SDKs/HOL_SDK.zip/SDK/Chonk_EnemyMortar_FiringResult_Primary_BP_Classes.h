#pragma once 
#include <Chonk_EnemyMortar_FiringResult_Primary_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_EnemyMortar_FiringResult_Primary_BP.Chonk_EnemyMortar_FiringResult_Primary_BP_C
// Size: 0x358(Inherited: 0x358) 
struct UChonk_EnemyMortar_FiringResult_Primary_BP_C : public UChonk_ArcFiringResult_Base_BP_C
{

}; 



