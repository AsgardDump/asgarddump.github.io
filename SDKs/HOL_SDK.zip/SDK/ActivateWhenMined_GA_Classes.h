#pragma once 
#include <ActivateWhenMined_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass ActivateWhenMined_GA.ActivateWhenMined_GA_C
// Size: 0x408(Inherited: 0x3F8) 
struct UActivateWhenMined_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)
	struct AProximityMine_BP_C* ProximityMine;  // 0x400(0x8)

	void OnEffectApplied_A581AE3145728136C98999BF7C9ECED1(struct FActiveGameplayEffectHandle ActiveEffectHandle, struct FGameplayEffectSpecHandle EffectSpecHandle); // Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.OnEffectApplied_A581AE3145728136C98999BF7C9ECED1
	void K2_ActivateAbility(); // Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.K2_ActivateAbility
	void ExecuteUbergraph_ActivateWhenMined_GA(int32_t EntryPoint); // Function ActivateWhenMined_GA.ActivateWhenMined_GA_C.ExecuteUbergraph_ActivateWhenMined_GA
}; 



