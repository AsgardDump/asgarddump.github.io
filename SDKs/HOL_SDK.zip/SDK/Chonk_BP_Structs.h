#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_BP.Chonk_BP_C.ForceHitReact__DelegateSignature
// Size: 0xB0(Inherited: 0x0) 
struct FForceHitReact__DelegateSignature
{
	struct FHitResult HitResult;  // 0x0(0x90)
	struct FGameplayTagContainer HitReactTag;  // 0x90(0x20)

}; 
// Function Chonk_BP.Chonk_BP_C.ExecuteUbergraph_Chonk_BP
// Size: 0x2D1(Inherited: 0x0) 
struct FExecuteUbergraph_Chonk_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x4(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue_2;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x18(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x20(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x28(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x30(0x8)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue_2;  // 0x38(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x40(0x8)
	struct UObject* K2Node_Event_Killer;  // 0x48(0x8)
	struct FHitResult K2Node_Event_HitResult_2;  // 0x50(0x90)
	struct FGameplayTagContainer K2Node_Event_DamageTags_2;  // 0xE0(0x20)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x10C(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x118(0x4)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x11C(0x90)
	char pad_428[4];  // 0x1AC(0x4)
	struct FGameplayTagContainer K2Node_CustomEvent_HitReactTag;  // 0x1B0(0x20)
	struct UObject* K2Node_Event_Damager;  // 0x1D0(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0x1D8(0x90)
	float K2Node_Event_Damage;  // 0x268(0x4)
	char pad_620[4];  // 0x26C(0x4)
	struct FGameplayTagContainer K2Node_Event_DamageTags;  // 0x270(0x20)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool CallFunc_DismemberClosest_bDismemberSuccess : 1;  // 0x291(0x1)
	char pad_658[6];  // 0x292(0x6)
	struct TArray<struct ASQDetachedMemberGib*> CallFunc_DismemberClosest_ReturnValue;  // 0x298(0x10)
	struct TArray<struct AActor*> K2Node_CustomEvent_TargetList;  // 0x2A8(0x10)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_3;  // 0x2B8(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_4;  // 0x2C0(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_5;  // 0x2C8(0x8)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool CallFunc_GetValueAsBool_ReturnValue : 1;  // 0x2D0(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.SetListOfTargetActors
// Size: 0x10(Inherited: 0x0) 
struct FSetListOfTargetActors
{
	struct TArray<struct AActor*> TargetList;  // 0x0(0x10)

}; 
// Function Chonk_BP.Chonk_BP_C.OnDied
// Size: 0xB8(Inherited: 0xB8) 
struct FOnDied : public FOnDied
{
	struct UObject* Killer;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	struct FGameplayTagContainer DamageTags;  // 0x98(0x20)

}; 
// Function Chonk_BP.Chonk_BP_C.OnDamageTaken
// Size: 0xC0(Inherited: 0xC0) 
struct FOnDamageTaken : public FOnDamageTaken
{
	struct UObject* Damager;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	float Damage;  // 0x98(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA0(0x20)

}; 
// Function Chonk_BP.Chonk_BP_C.TriggerCriticalDamageVO
// Size: 0xB0(Inherited: 0x0) 
struct FTriggerCriticalDamageVO
{
	struct FHitResult HitResult;  // 0x0(0x90)
	struct FGameplayTagContainer HitReactTag;  // 0x90(0x20)

}; 
// Function Chonk_BP.Chonk_BP_C.EnableGunInterrupt
// Size: 0x1D(Inherited: 0x0) 
struct FEnableGunInterrupt
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0xC(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1C(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.CancelAbilities
// Size: 0x79(Inherited: 0x0) 
struct FCancelAbilities
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC(0x4)
	struct FORAbilityUsageData CallFunc_Array_Get_Item;  // 0x10(0x68)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.TargetRandomFriendlyCharacter
// Size: 0xA1(Inherited: 0x0) 
struct FTargetRandomFriendlyCharacter
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewParam : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AORAICharacter*> TargettableSquadMembers;  // 0x8(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AORAICharacter* CallFunc_Array_Random_OutItem;  // 0x20(0x8)
	int32_t CallFunc_Array_Random_OutIndex;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x30(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x50(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x58(0x8)
	struct UORAISquad* CallFunc_GetAISquad_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct TArray<struct AORAICharacter*> CallFunc_GetSquadMembers_ReturnValue;  // 0x70(0x10)
	struct AORAICharacter* CallFunc_Array_Get_Item;  // 0x80(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_IsTargetPrioritizedForFriendlyTargeting_Is_Prioritized : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x90(0x4)
	int32_t CallFunc_Max_ReturnValue;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsTargetExcludedFromFriendlyTargeting_Is_Excluded : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xA0(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.CanForceHeavyHitReact
// Size: 0x1(Inherited: 0x0) 
struct FCanForceHeavyHitReact
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Force : 1;  // 0x0(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.HandleWeakpointVFX
// Size: 0x159(Inherited: 0xB0) 
struct FHandleWeakpointVFX : public FHandleWeakpointVFX
{
	struct FGameplayTagContainer TagContainer;  // 0x0(0x20)
	struct FHitResult Hit;  // 0x20(0x90)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xB0(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xB1(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xB4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xB8(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xBC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xC8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xD4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xE0(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xF0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xF8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x100(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x108(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x110(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x114(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x118(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x11C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x128(0xC)
	char pad_478_1 : 7;  // 0x1DE(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x134(0x1)
	struct TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput;  // 0x138(0x10)
	char pad_495_1 : 7;  // 0x1EF(0x1)
	bool CallFunc_HasMatchingGameplayTag_ReturnValue : 1;  // 0x148(0x1)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0x150(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x158(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.EnableBarrageWarning
// Size: 0x38(Inherited: 0x0) 
struct FEnableBarrageWarning
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct AORPlayerController* CallFunc_GetORPlayerController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x18(0x8)
	struct AORHUD* K2Node_DynamicCast_AsORHUD;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct UORWidget_HUDPrompt* CallFunc_CacheAndCreateHUDPromptWidget_ReturnValue;  // 0x30(0x8)

}; 
// Function Chonk_BP.Chonk_BP_C.GetBestFriendlyProxyMineTarget
// Size: 0x81(Inherited: 0x0) 
struct FGetBestFriendlyProxyMineTarget
{
	struct AActor* FriendlyProxyMineTarget;  // 0x0(0x8)
	float BestProxyMineTargetScore;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AActor* BestProxyMineTarget;  // 0x10(0x8)
	struct TArray<struct AORAICharacter*> SquadMembers;  // 0x18(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct AORAICharacter* CallFunc_Array_Get_Item;  // 0x40(0x8)
	float CallFunc_CalcFriendlyProxyMineTargetScore_TargetScore;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsTargetExcludedFromFriendlyTargeting_Is_Excluded : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x58(0x4)
	int32_t CallFunc_Max_ReturnValue;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct UORAISquad* CallFunc_GetAISquad_ReturnValue;  // 0x68(0x8)
	struct TArray<struct AORAICharacter*> CallFunc_GetSquadMembers_ReturnValue;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x80(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.CalcFriendlyProxyMineTargetScore
// Size: 0xB8(Inherited: 0x0) 
struct FCalcFriendlyProxyMineTargetScore
{
	struct AORAICharacter* ORAICharacter;  // 0x0(0x8)
	float TargetScore;  // 0x8(0x4)
	float AvailableSocketScore;  // 0xC(0x4)
	float PlayerDistanceScore;  // 0x10(0x4)
	float ChonkDistanceScore;  // 0x14(0x4)
	float PrioritizedTargetScore;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UORSocketReservationComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x20(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)
	struct UORSocketReservationComponent* K2Node_LowEntry_LocalVariable_Value__Object;  // 0x38(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x40(0xC)
	int32_t CallFunc_GetSocketsAvailableCount_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_GetMaxSocketsCount_ReturnValue;  // 0x50(0x4)
	int32_t K2Node_LowEntry_LocalVariable_Value__1_Object;  // 0x54(0x4)
	int32_t K2Node_LowEntry_LocalVariable_Value__2_Object;  // 0x58(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x5C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_IsTargetPrioritizedForFriendlyTargeting_Is_Prioritized : 1;  // 0x6D(0x1)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x6E(0x1)
	char pad_111[1];  // 0x6F(0x1)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x70(0x8)
	struct AActor* CallFunc_GetMainTargetActor_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x84(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x90(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x94(0xC)
	float CallFunc_EvalRuntimeFloatCurve_ReturnValue;  // 0xA0(0x4)
	float CallFunc_Vector_Distance_ReturnValue_2;  // 0xA4(0x4)
	float CallFunc_EvalRuntimeFloatCurve_ReturnValue_2;  // 0xA8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xAC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xB0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0xB4(0x4)

}; 
// Function Chonk_BP.Chonk_BP_C.TargetBestFriendlyCharacter
// Size: 0x28(Inherited: 0x0) 
struct FTargetBestFriendlyCharacter
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FoundTarget : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* CallFunc_GetBestFriendlyProxyMineTarget_FriendlyProxyMineTarget;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x18(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x20(0x8)

}; 
// Function Chonk_BP.Chonk_BP_C.SetTargetActorListFromOverride
// Size: 0x4D(Inherited: 0x0) 
struct FSetTargetActorListFromOverride
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FoundTarget : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName NewLocalVar_1;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct AActor* Temp_wildcard_Return_Value_Variable;  // 0x10(0x8)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue;  // 0x18(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x20(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x28(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x30(0x8)
	struct AActor* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x4C(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.IsTargetExcludedFromFriendlyTargeting
// Size: 0x48(Inherited: 0x0) 
struct FIsTargetExcludedFromFriendlyTargeting
{
	struct AActor* Target Character;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Is Excluded : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FGameplayTagContainer CallFunc_GetGameplayTagsFromActor_ReturnValue;  // 0x10(0x20)
	struct UORSocketReservationComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x30(0x8)
	struct UORSocketReservationComponent* K2Node_LowEntry_LocalVariable_Value__Object;  // 0x38(0x8)
	int32_t CallFunc_GetSocketsAvailableCount_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x45(0x1)
	char pad_70_1 : 7;  // 0x46(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x46(0x1)
	char pad_71_1 : 7;  // 0x47(0x1)
	bool CallFunc_DoesContainerMatchTagQuery_ReturnValue : 1;  // 0x47(0x1)

}; 
// Function Chonk_BP.Chonk_BP_C.IsTargetPrioritizedForFriendlyTargeting
// Size: 0x31(Inherited: 0x0) 
struct FIsTargetPrioritizedForFriendlyTargeting
{
	struct AActor* Target Character;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Is Prioritized : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FGameplayTagContainer CallFunc_GetGameplayTagsFromActor_ReturnValue;  // 0x10(0x20)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_DoesContainerMatchTagQuery_ReturnValue : 1;  // 0x30(0x1)

}; 
