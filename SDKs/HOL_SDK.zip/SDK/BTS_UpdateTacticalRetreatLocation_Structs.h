#pragma once 
#include "SDK.h" 
 
 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.ExecuteUbergraph_BTS_UpdateTacticalRetreatLocation
// Size: 0xDA(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_UpdateTacticalRetreatLocation
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x10(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AORAIHenchmanController_BP_C* K2Node_DynamicCast_AsORAIHenchman_Controller_BP;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance;  // 0x40(0x8)
	char EEnvQueryStatus K2Node_CustomEvent_QueryStatus;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct TArray<struct FVector> CallFunc_GetQueryResultsAsLocations_ResultLocations;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_GetQueryResultsAsLocations_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct AAIController* K2Node_Event_OwnerController;  // 0x70(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x84(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x94(0x10)
	float CallFunc_GetBlackboardValueAsFloat_ReturnValue;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_NeedsNewRetreatLocation_NeedsMove : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue;  // 0xB0(0x8)
	float CallFunc_GetAttackRepositionDistances_AttackRepositionDistanceMin;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_FindGoodAttractLocationForMove_FoundLocation : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	struct FVector CallFunc_FindGoodAttractLocationForMove_NewLocation;  // 0xC0(0xC)
	char pad_204[4];  // 0xCC(0x4)
	struct UObject* CallFunc_GetClaimedAttractionPoint_ReturnValue;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_ClaimAttractionPoint_ReturnValue : 1;  // 0xD9(0x1)

}; 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.NeedsNewRetreatLocation
// Size: 0x40(Inherited: 0x0) 
struct FNeedsNewRetreatLocation
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct AORAICharacter* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool NeedsMove : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AActor* BBTargetActor;  // 0x18(0x8)
	struct APawn* MyPawn;  // 0x20(0x8)
	struct FVector CallFunc_GetBlackboardValueAsVector_ReturnValue;  // 0x28(0xC)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_IsValidAILocation_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_NeedsLocationForTargetDistancing_NeedsPosition : 1;  // 0x36(0x1)
	char pad_55[1];  // 0x37(0x1)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x38(0x8)

}; 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.EQS_QueryComplete
// Size: 0x9(Inherited: 0x0) 
struct FEQS_QueryComplete
{
	struct UEnvQueryInstanceBlueprintWrapper* QueryInstance;  // 0x0(0x8)
	char EEnvQueryStatus QueryStatus;  // 0x8(0x1)

}; 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.ReceiveDeactivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveDeactivationAI : public FReceiveDeactivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.NeedsLocationForTargetDistancing
// Size: 0x31(Inherited: 0x0) 
struct FNeedsLocationForTargetDistancing
{
	struct AActor* TargetActor;  // 0x0(0x8)
	struct AORAICharacter* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool NeedsPosition : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector CallFunc_GetBlackboardValueAsVector_ReturnValue;  // 0x14(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x20(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.FindGoodAttractLocationForMove
// Size: 0x600(Inherited: 0x0) 
struct FFindGoodAttractLocationForMove
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct AORAICharacter* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool FoundLocation : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector NewLocation;  // 0x14(0xC)
	struct FVector AttractionPointLocation;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)
	struct AORAIController* LocalORAIController;  // 0x30(0x8)
	struct UObject* AttractionPoint;  // 0x38(0x8)
	struct AActor* BBTargetActor;  // 0x40(0x8)
	struct UORAttractionPointSubsystem* CallFunc_GetWorldSubsystem_ReturnValue;  // 0x48(0x8)
	struct AORAIController* K2Node_DynamicCast_AsORAIController;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	uint8_t  CallFunc_GetCoverType_ReturnValue;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FORAttractionPointSubsystemQuery CallFunc_GetCurrentAttractionPointQuery_ReturnValue;  // 0x60(0x548)
	struct UObject* CallFunc_QueryBestAttractionPointWithTarget_ReturnValue;  // 0x5A8(0x8)
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool CallFunc_ClaimAttractionPoint_ReturnValue : 1;  // 0x5B0(0x1)
	char pad_1457[7];  // 0x5B1(0x7)
	struct TScriptInterface<IORAttractionPointInterface> K2Node_DynamicCast_AsORAttraction_Point_Interface;  // 0x5B8(0x10)
	char pad_1480_1 : 7;  // 0x5C8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x5C8(0x1)
	char pad_1481[3];  // 0x5C9(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x5CC(0xC)
	struct FVector CallFunc_GetAttractionPointLocation_ReturnValue;  // 0x5D8(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x5E4(0x4)
	char pad_1512_1 : 7;  // 0x5E8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x5E8(0x1)
	char pad_1513_1 : 7;  // 0x5E9(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x5E9(0x1)
	char pad_1514_1 : 7;  // 0x5EA(0x1)
	bool CallFunc_ClaimAttractionPoint_ReturnValue_2 : 1;  // 0x5EA(0x1)
	char pad_1515[1];  // 0x5EB(0x1)
	struct FVector Temp_struct_Variable;  // 0x5EC(0xC)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x5F8(0x8)

}; 
// Function BTS_UpdateTacticalRetreatLocation.BTS_UpdateTacticalRetreatLocation_C.GetQueryRunningBool
// Size: 0x1(Inherited: 0x0) 
struct FGetQueryRunningBool
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Running : 1;  // 0x0(0x1)

}; 
