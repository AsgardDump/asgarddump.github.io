#pragma once 
#include <Chonk_ExitMonsterCloset_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C
// Size: 0x46C(Inherited: 0x429) 
struct UChonk_ExitMonsterCloset_GA_C : public UOREnemy_ExitMonsterCloset_GA_C
{
	char pad_1065[7];  // 0x429(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	uint8_t  CachedAwarenessState;  // 0x438(0x1)
	char pad_1081[3];  // 0x439(0x3)
	float CachedGravityScale;  // 0x43C(0x4)
	struct TArray<char ECollisionResponse> CachedCollisionResponse;  // 0x440(0x10)
	struct TArray<char ECollisionChannel> JumpCollisionChannelsToModify;  // 0x450(0x10)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool CollisionResponsesCached : 1;  // 0x460(0x1)
	char pad_1121[3];  // 0x461(0x3)
	struct FActiveGameplayEffectHandle ImmunityGE;  // 0x464(0x8)

	void ActivateJumpCollision(bool Activate); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.ActivateJumpCollision
	void OnCancelled_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnCancelled_C10F6DBF44BF0025A7FA0C92D294DD9D
	void OnInterrupted_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnInterrupted_C10F6DBF44BF0025A7FA0C92D294DD9D
	void OnBlendOut_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnBlendOut_C10F6DBF44BF0025A7FA0C92D294DD9D
	void OnCompleted_C10F6DBF44BF0025A7FA0C92D294DD9D(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.OnCompleted_C10F6DBF44BF0025A7FA0C92D294DD9D
	void K2_OnEndAbility(bool bWasCancelled); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.K2_OnEndAbility
	void K2_CommitExecute(); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.K2_CommitExecute
	void CharacterLanded(struct FHitResult& Hit); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.CharacterLanded
	void ExecuteUbergraph_Chonk_ExitMonsterCloset_GA(int32_t EntryPoint); // Function Chonk_ExitMonsterCloset_GA.Chonk_ExitMonsterCloset_GA_C.ExecuteUbergraph_Chonk_ExitMonsterCloset_GA
}; 



