#pragma once 
#include "SDK.h" 
 
 
// Function Ability_OpenInventory.Ability_OpenInventory_C.ExecuteUbergraph_Ability_OpenInventory
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_OpenInventory
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPauseMenuPayload_C* CallFunc_SpawnObject_ReturnValue;  // 0x8(0x8)

}; 
// Function Ability_OpenInventory.Ability_OpenInventory_C.K2_CanActivateAbility
// Size: 0x8D(Inherited: 0x78) 
struct FK2_CanActivateAbility : public FK2_CanActivateAbility
{
	struct FGameplayAbilityActorInfo ActorInfo;  // 0x0(0x48)
	struct FGameplayAbilitySpecHandle Handle;  // 0x48(0x4)
	struct FGameplayTagContainer RelevantTags;  // 0x50(0x20)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_229_1 : 7;  // 0xE5(0x1)
	bool CallFunc_IsItemEquippedOnPlayer_ReturnValue : 1;  // 0x71(0x1)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue;  // 0x78(0x8)
	struct AORInteractionStationManager* CallFunc_GetCurrentInteractionStation_ReturnValue;  // 0x80(0x8)
	char pad_246_1 : 7;  // 0xF6(0x1)
	bool CallFunc_IsAbilityActive_ReturnValue : 1;  // 0x88(0x1)
	char pad_247_1 : 7;  // 0xF7(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x89(0x1)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8A(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x8B(0x1)
	char pad_250_1 : 7;  // 0xFA(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x8C(0x1)

}; 
