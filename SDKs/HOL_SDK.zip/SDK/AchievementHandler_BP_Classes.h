#pragma once 
#include <AchievementHandler_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AchievementHandler_BP.AchievementHandler_BP_C
// Size: 0x90(Inherited: 0x28) 
struct UAchievementHandler_BP_C : public UORAchievementSubsystemHandler
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool AchievementsCached : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Descriptions Cached : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool PlayerIsSetUp : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool PlayerIsSettingUp : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Cache Achievement Descriptions : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool Min Progress 1% : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool SaveAfterUnlockingAchievement : 1;  // 0x36(0x1)
	char pad_55_1 : 7;  // 0x37(0x1)
	bool CanAwardAlreadyCompletedAchievements : 1;  // 0x37(0x1)
	float Cache Initial Delay;  // 0x38(0x4)
	float Cache Retry Time;  // 0x3C(0x4)
	float PlayerSetupDelay;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FGameplayTagContainer TradingCardMatches;  // 0x48(0x20)
	struct TArray<struct FGameplayTag> TradingCardsList;  // 0x68(0x10)
	struct AORCharacter* CachedORPlayerCharacter;  // 0x78(0x8)
	struct FTimerHandle WaitForPlayerValid;  // 0x80(0x8)
	struct FTimerHandle WaitForHunterChallengeFixUp;  // 0x88(0x8)

	void FixUpAchievements(); // Function AchievementHandler_BP.AchievementHandler_BP_C.FixUpAchievements
	void SetupNewGame(); // Function AchievementHandler_BP.AchievementHandler_BP_C.SetupNewGame
	void WriteCombatStatToLeaderboard(int32_t StatValue, struct FName StatBasedAchievementRowName, bool& Wrote Stat Successfully, struct FName& Stat Name, int32_t& Stat New Value, int32_t& Stat Max Value, float& Percentage Complete); // Function AchievementHandler_BP.AchievementHandler_BP_C.WriteCombatStatToLeaderboard
	void OnFailure_F5B1B17A40E65F1E422DE4B2040566A4(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_F5B1B17A40E65F1E422DE4B2040566A4
	void OnSuccess_F5B1B17A40E65F1E422DE4B2040566A4(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_F5B1B17A40E65F1E422DE4B2040566A4
	void OnFailure_66CE593143E777708052329F0F8560CC(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_66CE593143E777708052329F0F8560CC
	void OnSuccess_66CE593143E777708052329F0F8560CC(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_66CE593143E777708052329F0F8560CC
	void OnFailure_EF65249B41844C8272E99B97AA1C415A(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_EF65249B41844C8272E99B97AA1C415A
	void OnSuccess_EF65249B41844C8272E99B97AA1C415A(); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_EF65249B41844C8272E99B97AA1C415A
	void OnFailure_E324CC8F491BA969BDE7B5B55D80AA32(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_E324CC8F491BA969BDE7B5B55D80AA32
	void OnSuccess_E324CC8F491BA969BDE7B5B55D80AA32(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_E324CC8F491BA969BDE7B5B55D80AA32
	void OnFailure_302890424F0522A4AD187BB60052688C(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_302890424F0522A4AD187BB60052688C
	void OnSuccess_302890424F0522A4AD187BB60052688C(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_302890424F0522A4AD187BB60052688C
	void OnFailure_15B963E84609CB7407A79D8BA44CA5ED(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnFailure_15B963E84609CB7407A79D8BA44CA5ED
	void OnSuccess_15B963E84609CB7407A79D8BA44CA5ED(struct FName WrittenAchievementName, float WrittenProgress, int32_t WrittenUserTag); // Function AchievementHandler_BP.AchievementHandler_BP_C.OnSuccess_15B963E84609CB7407A79D8BA44CA5ED
	void HandleNewGame(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleNewGame
	void HandleStatBasedAchievementProgress(struct FName DataTableRowName, int32_t PrevValue, int32_t CurrentValue, int32_t MaxValue); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleStatBasedAchievementProgress
	void HandleStatBasedAchievementComplete(struct FName DataTableRowName, int32_t MaxValue); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleStatBasedAchievementComplete
	void ActivateStatBasedAchievementByRowName(struct FName DataTableRowName, int32_t StartingStatValue); // Function AchievementHandler_BP.AchievementHandler_BP_C.ActivateStatBasedAchievementByRowName
	void HandleOnDeinitialize(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleOnDeinitialize
	void HandleOnInitialize(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleOnInitialize
	void HandleNewDebugGame(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleNewDebugGame
	void HandleAddToAchievementProgress(struct FName DataTableName, int32_t Progress); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleAddToAchievementProgress
	void HandleResetAchievements(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleResetAchievements
	void New Game(); // Function AchievementHandler_BP.AchievementHandler_BP_C.New Game
	void HandleSetAchievementStat(struct FString AchievementName, int32_t Value); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleSetAchievementStat
	void CacheAchievements(); // Function AchievementHandler_BP.AchievementHandler_BP_C.CacheAchievements
	void AwardAchievement(struct FName DataTableRowName); // Function AchievementHandler_BP.AchievementHandler_BP_C.AwardAchievement
	void HandleSetAchievementPercent(struct FString AchievementName, float Percent); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleSetAchievementPercent
	void SetupNewPlayer(); // Function AchievementHandler_BP.AchievementHandler_BP_C.SetupNewPlayer
	void On Currency Changed(struct FGameplayTag Currency, int32_t PreviousCount, int32_t NewCount, char EInventoryTransactionType TransactionType); // Function AchievementHandler_BP.AchievementHandler_BP_C.On Currency Changed
	void HandleSetupNewPlayer(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HandleSetupNewPlayer
	void RecheckPlayerValidity(); // Function AchievementHandler_BP.AchievementHandler_BP_C.RecheckPlayerValidity
	void InventoryIsLoaded(struct UORCharacterInventory* Inventory); // Function AchievementHandler_BP.AchievementHandler_BP_C.InventoryIsLoaded
	void HunterChallengeFixupComplete(); // Function AchievementHandler_BP.AchievementHandler_BP_C.HunterChallengeFixupComplete
	void ExecuteUbergraph_AchievementHandler_BP(int32_t EntryPoint); // Function AchievementHandler_BP.AchievementHandler_BP_C.ExecuteUbergraph_AchievementHandler_BP
}; 



