#pragma once 
#include "SDK.h" 
 
 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.StartBlortoConversation__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FStartBlortoConversation__DelegateSignature
{
	struct FGameplayTag ObjectiveTag;  // 0x0(0x8)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ShouldStartBlortoConversation
// Size: 0x2B(Inherited: 0x0) 
struct FShouldStartBlortoConversation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool StartConversation : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FGameplayTag ObjectiveTag;  // 0x4(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_GetMissionBool_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	struct FGameplayTag CallFunc_Array_Get_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x28(0x1)
	uint8_t  CallFunc_GetObjectiveState_ReturnValue;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x2A(0x1)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ExecuteUbergraph_ChefStand_InteractionStation_BP
// Size: 0x16B(Inherited: 0x0) 
struct FExecuteUbergraph_ChefStand_InteractionStation_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_ShouldStartBlortoConversation_StartConversation : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FGameplayTag CallFunc_ShouldStartBlortoConversation_ObjectiveTag;  // 0x18(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x30(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x40(0x8)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct APlayerCharacter_BP_C* K2Node_DynamicCast_AsPlayer_Character_BP;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct ASQEquippableInventoryItem* CallFunc_GetFirstEquippedItemOnPlayer_Return_Value;  // 0x68(0x8)
	struct ASQEquippableInventoryItem* CallFunc_GetFirstEquippedItemOnPlayer_Return_Value_2;  // 0x70(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x78(0x10)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue_2;  // 0x88(0x8)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue_3;  // 0x90(0x8)
	float CallFunc_PlayAnimMontage_ReturnValue;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue_4;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_GetPlayerInventory_IsValid : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UORCharacterInventory* CallFunc_GetPlayerInventory_Inventory;  // 0xB0(0x8)
	float CallFunc_PlayAnimMontage_ReturnValue_2;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct UHUD_Master_Widget_C* CallFunc_GetHUD_HUDWidget_Ref;  // 0xC0(0x8)
	struct UHUD_Master_Widget_C* CallFunc_GetHUD_HUDWidget_Ref_2;  // 0xC8(0x8)
	struct UHUD_HelpText_Widget_C* K2Node_DynamicCast_AsHUD_Help_Text_Widget;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct UHUD_HelpText_Widget_C* K2Node_DynamicCast_AsHUD_Help_Text_Widget_2;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue_5;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xF9(0x1)
	char pad_250[6];  // 0xFA(0x6)
	struct USyncedPlayerAnimationComponent* K2Node_ComponentBoundEvent_SyncedAnimationComponent;  // 0x100(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x108(0x10)
	char pad_280[8];  // 0x118(0x8)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x120(0x30)
	struct FGameplayTag K2Node_CustomEvent_Currency;  // 0x150(0x8)
	int32_t K2Node_CustomEvent_PreviousCount;  // 0x158(0x4)
	int32_t K2Node_CustomEvent_NewCount;  // 0x15C(0x4)
	char EInventoryTransactionType K2Node_CustomEvent_TransactionType;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x161(0x1)
	char pad_354[2];  // 0x162(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x164(0x4)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_MatchesTag_ReturnValue : 1;  // 0x168(0x1)
	char pad_361_1 : 7;  // 0x169(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x169(0x1)
	char pad_362_1 : 7;  // 0x16A(0x1)
	bool CallFunc_GetMissionBool_ReturnValue : 1;  // 0x16A(0x1)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlayerEnter__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FPlayerEnter__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsRecentReturn : 1;  // 0x0(0x1)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ItemPurchased__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FItemPurchased__DelegateSignature
{
	struct FGameplayTag ItemTag;  // 0x0(0x8)
	char ChefStandTransactionResult Result;  // 0x8(0x1)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PlayerExit__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FPlayerExit__DelegateSignature
{
	struct TArray<struct FGameplayTag> ItemsPurchased;  // 0x0(0x10)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.ResumeOpenShop
// Size: 0x19(Inherited: 0x0) 
struct FResumeOpenShop
{
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerCharacter_BP_C* K2Node_DynamicCast_AsPlayer_Character_BP;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.OnCurrencyChangedDelegate
// Size: 0x11(Inherited: 0x0) 
struct FOnCurrencyChangedDelegate
{
	struct FGameplayTag Currency;  // 0x0(0x8)
	int32_t PreviousCount;  // 0x8(0x4)
	int32_t NewCount;  // 0xC(0x4)
	char EInventoryTransactionType TransactionType;  // 0x10(0x1)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.BndEvt__ChefStand_InteractionStation_BP_SyncedPlayerAnimation_K2Node_ComponentBoundEvent_0_SyncedAnimationComponentEvent__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__ChefStand_InteractionStation_BP_SyncedPlayerAnimation_K2Node_ComponentBoundEvent_0_SyncedAnimationComponentEvent__DelegateSignature
{
	struct USyncedPlayerAnimationComponent* SyncedAnimationComponent;  // 0x0(0x8)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.PurchaseItem
// Size: 0x100(Inherited: 0x0) 
struct FPurchaseItem
{
	struct FChefStandTransactionData TransactionData;  // 0x0(0x30)
	char ChefStandTransactionResult Result;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t AmountPurchased;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FVendorItemData CallFunc_GetDataTableRowFromName_OutRow;  // 0x40(0x78)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_PurchaseItemFromVendor_Success : 1;  // 0xB9(0x1)
	char pad_186[6];  // 0xBA(0x6)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0xC0(0x10)
	struct FString CallFunc_Conv_NameToString_ReturnValue_2;  // 0xD0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xE0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xF0(0x10)

}; 
// Function ChefStand_InteractionStation_BP.ChefStand_InteractionStation_BP_C.GetOverrideComponentToFace
// Size: 0x11(Inherited: 0x8) 
struct FGetOverrideComponentToFace : public FGetOverrideComponentToFace
{
	struct USceneComponent* ComponentToFace;  // 0x0(0x8)
	struct UInteractionStationComponent_BP_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x8(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)

}; 
