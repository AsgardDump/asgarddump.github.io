#pragma once 
#include <BTT_RecordFinishedCombatMove_Structs.h>
 
 
 
// BlueprintGeneratedClass BTT_RecordFinishedCombatMove.BTT_RecordFinishedCombatMove_C
// Size: 0xB0(Inherited: 0xA8) 
struct UBTT_RecordFinishedCombatMove_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTT_RecordFinishedCombatMove.BTT_RecordFinishedCombatMove_C.ReceiveExecuteAI
	void ExecuteUbergraph_BTT_RecordFinishedCombatMove(int32_t EntryPoint); // Function BTT_RecordFinishedCombatMove.BTT_RecordFinishedCombatMove_C.ExecuteUbergraph_BTT_RecordFinishedCombatMove
}; 



