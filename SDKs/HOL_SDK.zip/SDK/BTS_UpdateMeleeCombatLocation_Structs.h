#pragma once 
#include "SDK.h" 
 
 
// Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ExecuteUbergraph_BTS_UpdateMeleeCombatLocation
// Size: 0x1C8(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_UpdateMeleeCombatLocation
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x10(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x18(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AAIController* K2Node_Event_OwnerController;  // 0x50(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x64(0xC)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x70(0x10)
	struct FVector CallFunc_GetActorUpVector_ReturnValue;  // 0x80(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x8C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x98(0xC)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0xA8(0x90)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x139(0x1)
	char pad_314_1 : 7;  // 0x13A(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x13A(0x1)
	char pad_315[1];  // 0x13B(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x13C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x140(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x144(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x150(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x15C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x168(0xC)
	char pad_372[4];  // 0x174(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x178(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x180(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x188(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x190(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x198(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x19C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x1A0(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x1A4(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x1B0(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x1BC(0xC)

}; 
// Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ReceiveActivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveActivationAI : public FReceiveActivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
