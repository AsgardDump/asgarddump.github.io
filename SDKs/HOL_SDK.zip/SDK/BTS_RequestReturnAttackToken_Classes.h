#pragma once 
#include <BTS_RequestReturnAttackToken_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C
// Size: 0xC8(Inherited: 0x98) 
struct UBTS_RequestReturnAttackToken_C : public UBTService_BlueprintBase
{
	struct FGameplayTag CharacterAbilityTag;  // 0x98(0x8)
	struct FBlackboardKeySelector TargetActorKey;  // 0xA0(0x28)

	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C.ReceiveDeactivationAI
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C.ReceiveActivationAI
}; 



