#pragma once 
#include <CancelPlayerPowerslide_GA_Structs.h>
 
 
 
// BlueprintGeneratedClass CancelPlayerPowerslide_GA.CancelPlayerPowerslide_GA_C
// Size: 0x400(Inherited: 0x3F8) 
struct UCancelPlayerPowerslide_GA_C : public UORGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)

	void K2_ActivateAbility(); // Function CancelPlayerPowerslide_GA.CancelPlayerPowerslide_GA_C.K2_ActivateAbility
	void ExecuteUbergraph_CancelPlayerPowerslide_GA(int32_t EntryPoint); // Function CancelPlayerPowerslide_GA.CancelPlayerPowerslide_GA_C.ExecuteUbergraph_CancelPlayerPowerslide_GA
}; 



