#pragma once 
#include <Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP.Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP_C
// Size: 0x2C8(Inherited: 0x2C8) 
struct UChonk_ArcSingleShot_FriendlyFire_FiringResult_BP_C : public UORFiringResult_Projectile
{

	struct FVector GetAimLocation(bool bUseAimCorrections); // Function Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP.Chonk_ArcSingleShot_FriendlyFire_FiringResult_BP_C.GetAimLocation
}; 



