#pragma once 
#include "SDK.h" 
 
 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnMouseButtonDown_1
// Size: 0x218(Inherited: 0x0) 
struct FOnMouseButtonDown_1
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.NavigateLeft
// Size: 0x8(Inherited: 0x0) 
struct FNavigateLeft
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)

}; 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.ExecuteUbergraph_CharacterCreatorWidgetV2_BP
// Size: 0x15(Inherited: 0x0) 
struct FExecuteUbergraph_CharacterCreatorWidgetV2_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t Temp_int_Variable_2;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnSelectionChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnSelectionChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNavigateRight : 1;  // 0x0(0x1)

}; 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.MatchWidgetToMirror
// Size: 0x20(Inherited: 0x0) 
struct FMatchWidgetToMirror
{
	struct FVector2D ScreenPosition;  // 0x0(0x8)
	float WidgetRadius;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xC(0x4)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x10(0x8)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x18(0x8)

}; 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.SelectFace
// Size: 0x4(Inherited: 0x0) 
struct FSelectFace
{
	int32_t FaceIndex;  // 0x0(0x4)

}; 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.NavigateRight
// Size: 0x8(Inherited: 0x0) 
struct FNavigateRight
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)

}; 
// Function CharacterCreatorWidgetV2_BP.CharacterCreatorWidgetV2_BP_C.OnPreviewKeyDown
// Size: 0x3F8(Inherited: 0x128) 
struct FOnPreviewKeyDown : public FOnPreviewKeyDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FKeyEvent InKeyEvent;  // 0x38(0x38)
	struct FEventReply ReturnValue;  // 0x70(0xB8)
	struct FKey CallFunc_GetKey_ReturnValue;  // 0x128(0x18)
	int32_t Temp_int_Array_Index_Variable;  // 0x140(0x4)
	char pad_620_1 : 7;  // 0x26C(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue : 1;  // 0x144(0x1)
	char pad_621_1 : 7;  // 0x26D(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_2 : 1;  // 0x145(0x1)
	char pad_622_1 : 7;  // 0x26E(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_3 : 1;  // 0x146(0x1)
	char pad_623_1 : 7;  // 0x26F(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_4 : 1;  // 0x147(0x1)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_5 : 1;  // 0x148(0x1)
	char pad_625_1 : 7;  // 0x271(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x149(0x1)
	char pad_626_1 : 7;  // 0x272(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_6 : 1;  // 0x14A(0x1)
	char pad_627_1 : 7;  // 0x273(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_7 : 1;  // 0x14B(0x1)
	char pad_628_1 : 7;  // 0x274(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_8 : 1;  // 0x14C(0x1)
	char pad_629_1 : 7;  // 0x275(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_9 : 1;  // 0x14D(0x1)
	char pad_630_1 : 7;  // 0x276(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x14E(0x1)
	char pad_631_1 : 7;  // 0x277(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_10 : 1;  // 0x14F(0x1)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x150(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_11 : 1;  // 0x151(0x1)
	char pad_634_1 : 7;  // 0x27A(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0x152(0x1)
	char pad_635_1 : 7;  // 0x27B(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_12 : 1;  // 0x153(0x1)
	char pad_636_1 : 7;  // 0x27C(0x1)
	bool CallFunc_BooleanOR_ReturnValue_5 : 1;  // 0x154(0x1)
	char pad_637_1 : 7;  // 0x27D(0x1)
	bool CallFunc_BooleanOR_ReturnValue_6 : 1;  // 0x155(0x1)
	char pad_638_1 : 7;  // 0x27E(0x1)
	bool CallFunc_BooleanOR_ReturnValue_7 : 1;  // 0x156(0x1)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x158(0xB8)
	char pad_823_1 : 7;  // 0x337(0x1)
	bool CallFunc_BooleanOR_ReturnValue_8 : 1;  // 0x210(0x1)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool CallFunc_BooleanOR_ReturnValue_9 : 1;  // 0x211(0x1)
	struct UPauseMenuPayload_C* CallFunc_SpawnObject_ReturnValue;  // 0x218(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x220(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x224(0x4)
	struct AORPlayerCharacter* CallFunc_GetPlayer_ReturnValue;  // 0x228(0x8)
	char pad_849_1 : 7;  // 0x351(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x230(0x1)
	char pad_850_1 : 7;  // 0x352(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x231(0x1)
	struct UInputComponent* CallFunc_GetInputComponent_ReturnValue;  // 0x238(0x8)
	struct UORPlayerInputComponent* K2Node_DynamicCast_AsORPlayer_Input_Component;  // 0x240(0x8)
	char pad_867_1 : 7;  // 0x363(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x248(0x1)
	struct FEventReply CallFunc_Unhandled_ReturnValue;  // 0x250(0xB8)
	struct TArray<struct FKeyCombo> CallFunc_GetKeyCombosFromAction_ReturnValue;  // 0x308(0x10)
	struct FKeyCombo CallFunc_Array_Get_Item;  // 0x318(0x20)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x338(0x4)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x33C(0x1)
	char pad_1105_1 : 7;  // 0x451(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_13 : 1;  // 0x33D(0x1)
	struct FEventReply CallFunc_Handled_ReturnValue_2;  // 0x340(0xB8)

}; 
