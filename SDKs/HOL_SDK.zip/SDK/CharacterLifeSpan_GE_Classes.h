#pragma once 
#include <CharacterLifeSpan_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass CharacterLifeSpan_GE.CharacterLifeSpan_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UCharacterLifeSpan_GE_C : public UORGameplayEffect
{

}; 



