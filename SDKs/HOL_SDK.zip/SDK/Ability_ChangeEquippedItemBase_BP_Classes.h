#pragma once 
#include <Ability_ChangeEquippedItemBase_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C
// Size: 0x3E0(Inherited: 0x3D8) 
struct UAbility_ChangeEquippedItemBase_BP_C : public UGameplayAbility
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3D8(0x8)

	bool K2_CanActivateAbility(struct FGameplayAbilityActorInfo ActorInfo, struct FGameplayAbilitySpecHandle Handle, struct FGameplayTagContainer& RelevantTags); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.K2_CanActivateAbility
	void GetOwningInventory(struct UORPlayerInventory*& OutInventory); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.GetOwningInventory
	void K2_ActivateAbility(); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.K2_ActivateAbility
	void ExecuteUbergraph_Ability_ChangeEquippedItemBase_BP(int32_t EntryPoint); // Function Ability_ChangeEquippedItemBase_BP.Ability_ChangeEquippedItemBase_BP_C.ExecuteUbergraph_Ability_ChangeEquippedItemBase_BP
}; 



