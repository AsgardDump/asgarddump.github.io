#pragma once 
#include <BTS_FindCreatureMinionMoveToMarker_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C
// Size: 0xB0(Inherited: 0x98) 
struct UBTS_FindCreatureMinionMoveToMarker_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool IsQueryRunning : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct AORAICreatureMinionController* CreatureMinionController_Chached;  // 0xA8(0x8)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.ReceiveTickAI
	void QueryFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus); // Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.QueryFinished
	void ExecuteUbergraph_BTS_FindCreatureMinionMoveToMarker(int32_t EntryPoint); // Function BTS_FindCreatureMinionMoveToMarker.BTS_FindCreatureMinionMoveToMarker_C.ExecuteUbergraph_BTS_FindCreatureMinionMoveToMarker
}; 



