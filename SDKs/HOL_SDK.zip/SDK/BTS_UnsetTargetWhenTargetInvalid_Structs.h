#pragma once 
#include "SDK.h" 
 
 
// Function BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C.ExecuteUbergraph_BTS_UnsetTargetWhenTargetInvalid
// Size: 0x43(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_UnsetTargetWhenTargetInvalid
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x20(0x8)
	struct AORAIController* K2Node_DynamicCast_AsORAIController;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct AActor* CallFunc_GetAttachParentActor_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValidAndAlive_IsAliveAndWell : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_IsValidAndAlive_IsAliveAndWell_2 : 1;  // 0x42(0x1)

}; 
// Function BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
