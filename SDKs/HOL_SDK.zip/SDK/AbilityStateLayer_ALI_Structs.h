#pragma once 
#include "SDK.h" 
 
 
// Function AbilityStateLayer_ALI.AbilityStateLayer_ALI_C.AbilityStateLayer
// Size: 0x20(Inherited: 0x0) 
struct FAbilityStateLayer
{
	struct FPoseLink InPose;  // 0x0(0x10)
	struct FPoseLink AbilityStateLayer;  // 0x10(0x10)

}; 
