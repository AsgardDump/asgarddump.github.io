#pragma once 
#include <AnchorPoint_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AnchorPoint_BP.AnchorPoint_BP_C
// Size: 0x3A5(Inherited: 0x2C8) 
struct AAnchorPoint_BP_C : public AORAnchorPoint
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C8(0x8)
	struct USphereComponent* ProjectileCollision;  // 0x2D0(0x8)
	struct USkeletalMeshComponentBudgeted* BugMesh;  // 0x2D8(0x8)
	struct UORDamageHandlerComponent_NoHealth* ORDamageHandlerComponent_NoHealth;  // 0x2E0(0x8)
	struct UORInteractableComponent_AnchorPoint* ORInteractableComponent_AnchorPoint;  // 0x2E8(0x8)
	struct UORTriggerSourceComponent* ORTriggerSource;  // 0x2F0(0x8)
	struct UORTriggerVolumeComponent* ORTriggerVolume;  // 0x2F8(0x8)
	struct UORSplineFollowerComponent* ORSplineFollower;  // 0x300(0x8)
	struct USceneComponent* Helpers;  // 0x308(0x8)
	struct UORAkComponent* ORAk;  // 0x310(0x8)
	struct UORScannableComponent* ORScannable;  // 0x318(0x8)
	struct USceneComponent* Root;  // 0x320(0x8)
	struct UStaticMeshComponent* vis_8m_vertical;  // 0x328(0x8)
	struct UStaticMeshComponent* vis_8m_horizontal;  // 0x330(0x8)
	struct UStaticMeshComponent* vis_exittrajectory;  // 0x338(0x8)
	struct UStaticMeshComponent* vis_tetherrange;  // 0x340(0x8)
	struct UStaticMeshComponent* vis_exittrajectory2;  // 0x348(0x8)
	struct UStaticMeshComponent* vis_exittrajectory1;  // 0x350(0x8)
	struct UORGazeTargetComponent* ORGazeTarget;  // 0x358(0x8)
	struct FVector OriginalLocation;  // 0x360(0xC)
	char pad_876_1 : 7;  // 0x36C(0x1)
	bool AmbientMovement? : 1;  // 0x36C(0x1)
	char pad_877[3];  // 0x36D(0x3)
	float MovementRange;  // 0x370(0x4)
	int32_t AudioPlayingID;  // 0x374(0x4)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool ShowHelpers : 1;  // 0x378(0x1)
	char pad_889[3];  // 0x379(0x3)
	float CooldownDuration;  // 0x37C(0x4)
	struct FVector PrevLocation;  // 0x380(0xC)
	float TetheredMovementSpeed;  // 0x38C(0x4)
	struct FTimerHandle AngryTimer;  // 0x390(0x8)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool NDTakenFirstShot : 1;  // 0x398(0x1)
	char pad_921[3];  // 0x399(0x3)
	int32_t NDShotCount;  // 0x39C(0x4)
	int32_t NDRandomShotsTrigger;  // 0x3A0(0x4)
	char pad_932_1 : 7;  // 0x3A4(0x1)
	bool Automatically Move on Spline on Release : 1;  // 0x3A4(0x1)

	bool ShouldBlockInteractionWithActor(struct AActor* Interactor); // Function AnchorPoint_BP.AnchorPoint_BP_C.ShouldBlockInteractionWithActor
	struct TArray<struct AActor*> GetSecondaryEffectsTargets(); // Function AnchorPoint_BP.AnchorPoint_BP_C.GetSecondaryEffectsTargets
	struct UORDamageHandlerComponent* GetDamageHandler(); // Function AnchorPoint_BP.AnchorPoint_BP_C.GetDamageHandler
	struct TArray<UGameplayEffect*> GetKillerGameplayEffects(); // Function AnchorPoint_BP.AnchorPoint_BP_C.GetKillerGameplayEffects
	bool HasDied(); // Function AnchorPoint_BP.AnchorPoint_BP_C.HasDied
	float ModifyDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AnchorPoint_BP.AnchorPoint_BP_C.ModifyDamage
	float ModifyFinalDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AnchorPoint_BP.AnchorPoint_BP_C.ModifyFinalDamage
	bool ShouldBlockDamage(struct UObject* Damager, struct FHitResult& HitResult, float Damage, struct FGameplayTagContainer& DamageTags); // Function AnchorPoint_BP.AnchorPoint_BP_C.ShouldBlockDamage
	void Set ABPSpeeds(struct FVector Location); // Function AnchorPoint_BP.AnchorPoint_BP_C.Set ABPSpeeds
	void StopSound(bool& Success); // Function AnchorPoint_BP.AnchorPoint_BP_C.StopSound
	void PlaySound(int32_t& PlayingID); // Function AnchorPoint_BP.AnchorPoint_BP_C.PlaySound
	void UserConstructionScript(); // Function AnchorPoint_BP.AnchorPoint_BP_C.UserConstructionScript
	void StartCooldown(); // Function AnchorPoint_BP.AnchorPoint_BP_C.StartCooldown
	void OnCooldownComplete(); // Function AnchorPoint_BP.AnchorPoint_BP_C.OnCooldownComplete
	void BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_4_ORTriggerVolumeComponentCallback__DelegateSignature(struct AActor* SourceActor, int32_t VolumeIndex); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_4_ORTriggerVolumeComponentCallback__DelegateSignature
	void BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_5_ORTriggerVolumeComponentCallback__DelegateSignature(struct AActor* SourceActor, int32_t VolumeIndex); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_5_ORTriggerVolumeComponentCallback__DelegateSignature
	void DoneBeingAngry(); // Function AnchorPoint_BP.AnchorPoint_BP_C.DoneBeingAngry
	void BndEvt__AnchorPoint_BP_ProjectileCollision_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ProjectileCollision_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
	void TetherPullEnded(struct AORCharacter* TetherSource); // Function AnchorPoint_BP.AnchorPoint_BP_C.TetherPullEnded
	void TetherPullStarted(struct AORCharacter* TetherSource); // Function AnchorPoint_BP.AnchorPoint_BP_C.TetherPullStarted
	void SetNextMovementParams(); // Function AnchorPoint_BP.AnchorPoint_BP_C.SetNextMovementParams
	void StartNextMovement(); // Function AnchorPoint_BP.AnchorPoint_BP_C.StartNextMovement
	void BndEvt__ORScannable_K2Node_ComponentBoundEvent_3_DisableHighlightSignature__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORScannable_K2Node_ComponentBoundEvent_3_DisableHighlightSignature__DelegateSignature
	void BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_2_GazeResponseDelegate__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_2_GazeResponseDelegate__DelegateSignature
	void BndEvt__ORScannable_K2Node_ComponentBoundEvent_1_EnableHighlightSignature__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORScannable_K2Node_ComponentBoundEvent_1_EnableHighlightSignature__DelegateSignature
	void BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_0_GazeResponseDelegate__DelegateSignature(); // Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__ORGazeTarget_K2Node_ComponentBoundEvent_0_GazeResponseDelegate__DelegateSignature
	void SetMoveTarget(struct FVector MoveTarget); // Function AnchorPoint_BP.AnchorPoint_BP_C.SetMoveTarget
	void ReceiveBeginPlay(); // Function AnchorPoint_BP.AnchorPoint_BP_C.ReceiveBeginPlay
	void SetInteractableState(bool bEnabled); // Function AnchorPoint_BP.AnchorPoint_BP_C.SetInteractableState
	void InteractionTriggeredWithComponent(struct AActor* Interactor, struct UORInteractableComponent* Component); // Function AnchorPoint_BP.AnchorPoint_BP_C.InteractionTriggeredWithComponent
	void InteractionTriggered(struct AActor* Interactable); // Function AnchorPoint_BP.AnchorPoint_BP_C.InteractionTriggered
	void ExecuteUbergraph_AnchorPoint_BP(int32_t EntryPoint); // Function AnchorPoint_BP.AnchorPoint_BP_C.ExecuteUbergraph_AnchorPoint_BP
}; 



