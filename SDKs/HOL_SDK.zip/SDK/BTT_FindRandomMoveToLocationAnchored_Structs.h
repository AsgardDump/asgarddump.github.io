#pragma once 
#include "SDK.h" 
 
 
// Function BTT_FindRandomMoveToLocationAnchored.BTT_FindRandomMoveToLocationAnchored_C.ExecuteUbergraph_BTT_FindRandomMoveToLocationAnchored
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_BTT_FindRandomMoveToLocationAnchored
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance;  // 0x18(0x8)
	char EEnvQueryStatus K2Node_CustomEvent_QueryStatus;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct FVector> CallFunc_GetQueryResultsAsLocations_ResultLocations;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_GetQueryResultsAsLocations_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	float CallFunc_GetBlackboardValueAsFloat_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x58(0xC)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	struct UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue;  // 0x68(0x8)

}; 
// Function BTT_FindRandomMoveToLocationAnchored.BTT_FindRandomMoveToLocationAnchored_C.QueryComplete
// Size: 0x9(Inherited: 0x0) 
struct FQueryComplete
{
	struct UEnvQueryInstanceBlueprintWrapper* QueryInstance;  // 0x0(0x8)
	char EEnvQueryStatus QueryStatus;  // 0x8(0x1)

}; 
// Function BTT_FindRandomMoveToLocationAnchored.BTT_FindRandomMoveToLocationAnchored_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
