#pragma once 
#include <Boss_Intro_Sequence_Text_Widget_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C
// Size: 0x3B0(Inherited: 0x290) 
struct UBoss_Intro_Sequence_Text_Widget_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct UWidgetAnimation* ToIdle;  // 0x298(0x8)
	struct UWidgetAnimation* ToOff;  // 0x2A0(0x8)
	struct UWidgetAnimation* ToOn;  // 0x2A8(0x8)
	struct UImage* Image_287;  // 0x2B0(0x8)
	struct URetainerBox* RetainerBox_1;  // 0x2B8(0x8)
	struct UTextBlock* TextBlock;  // 0x2C0(0x8)
	struct UTextBlock* TextBlock_2;  // 0x2C8(0x8)
	struct UTextBlock* TextBlock_3;  // 0x2D0(0x8)
	struct UTextBlock* TextBlock_28;  // 0x2D8(0x8)
	struct UOverlay* TextJustify_2;  // 0x2E0(0x8)
	struct UScaleBox* TextJustify_3;  // 0x2E8(0x8)
	struct UScaleBox* TextJustify_4;  // 0x2F0(0x8)
	struct UScaleBox* TextJustify_5;  // 0x2F8(0x8)
	struct UImage* UnderLine;  // 0x300(0x8)
	struct TMap<struct FName, float> NormalShaderParams;  // 0x308(0x50)
	struct TMap<struct FName, float> DistortionShaderParams;  // 0x358(0x50)
	struct UDataTable* CharacterInfoDataTable;  // 0x3A8(0x8)

	void SequenceEvent__ENTRYPOINTBoss_Intro_Sequence_Text_Widget_1(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.SequenceEvent__ENTRYPOINTBoss_Intro_Sequence_Text_Widget_1
	void Finished_436BDBBA44E3C3A1A2E02E9BA2ED7C3B(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.Finished_436BDBBA44E3C3A1A2E02E9BA2ED7C3B
	void Finished_AAD7CFF646779387A2FB9B80A5417972(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.Finished_AAD7CFF646779387A2FB9B80A5417972
	void StartDistortion(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.StartDistortion
	void SetBossInfo(struct FText BossName); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.SetBossInfo
	void StopDistortion(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.StopDistortion
	void HideCharacterIntroText(); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.HideCharacterIntroText
	void ShowCharacterIntroText(struct FName CharacterRowName); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.ShowCharacterIntroText
	void ExecuteUbergraph_Boss_Intro_Sequence_Text_Widget(int32_t EntryPoint); // Function Boss_Intro_Sequence_Text_Widget.Boss_Intro_Sequence_Text_Widget_C.ExecuteUbergraph_Boss_Intro_Sequence_Text_Widget
}; 



