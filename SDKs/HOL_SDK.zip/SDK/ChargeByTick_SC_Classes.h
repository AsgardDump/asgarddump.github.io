#pragma once 
#include <ChargeByTick_SC_Structs.h>
 
 
 
// BlueprintGeneratedClass ChargeByTick_SC.ChargeByTick_SC_C
// Size: 0x58(Inherited: 0x50) 
struct UChargeByTick_SC_C : public UORScriptComponent_ChargeByTick
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x50(0x8)

	bool GetIsActive(); // Function ChargeByTick_SC.ChargeByTick_SC_C.GetIsActive
	void SetIsActive(bool IsActive); // Function ChargeByTick_SC.ChargeByTick_SC_C.SetIsActive
	void ExecuteUbergraph_ChargeByTick_SC(int32_t EntryPoint); // Function ChargeByTick_SC.ChargeByTick_SC_C.ExecuteUbergraph_ChargeByTick_SC
}; 



