#pragma once 
#include "SDK.h" 
 
 
// Function Berserk_GC.Berserk_GC_C.OnRemove
// Size: 0xC9(Inherited: 0xD0) 
struct FOnRemove : public FOnRemove
{
	struct AActor* MyTarget;  // 0x0(0x8)
	struct FGameplayCueParameters Parameters;  // 0x8(0xC0)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool ReturnValue : 1;  // 0xC8(0x1)

}; 
// Function Berserk_GC.Berserk_GC_C.OnActive
// Size: 0xD8(Inherited: 0xD0) 
struct FOnActive : public FOnActive
{
	struct AActor* MyTarget;  // 0x0(0x8)
	struct FGameplayCueParameters Parameters;  // 0x8(0xC0)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool ReturnValue : 1;  // 0xC8(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xCC(0xC)

}; 
