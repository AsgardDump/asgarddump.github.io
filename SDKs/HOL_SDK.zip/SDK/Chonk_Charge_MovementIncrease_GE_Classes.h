#pragma once 
#include <Chonk_Charge_MovementIncrease_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_Charge_MovementIncrease_GE.Chonk_Charge_MovementIncrease_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UChonk_Charge_MovementIncrease_GE_C : public UORGameplayEffect
{

}; 



