#pragma once 
#include <BTD_IsMeleeMerkInPhaseDodge_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_IsMeleeMerkInPhaseDodge.BTD_IsMeleeMerkInPhaseDodge_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_IsMeleeMerkInPhaseDodge_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_IsMeleeMerkInPhaseDodge.BTD_IsMeleeMerkInPhaseDodge_C.PerformConditionCheckAI
}; 



