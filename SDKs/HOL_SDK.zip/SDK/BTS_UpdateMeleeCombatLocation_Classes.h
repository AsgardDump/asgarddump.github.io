#pragma once 
#include <BTS_UpdateMeleeCombatLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C
// Size: 0x100(Inherited: 0x98) 
struct UBTS_UpdateMeleeCombatLocation_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector TargetActorKey;  // 0xA0(0x28)
	struct FBlackboardKeySelector CombatMoveLocation;  // 0xC8(0x28)
	struct AORCharacter* TargetORCharacter;  // 0xF0(0x8)
	struct APawn* Controlled Pawn;  // 0xF8(0x8)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ReceiveTickAI
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ReceiveActivationAI
	void ExecuteUbergraph_BTS_UpdateMeleeCombatLocation(int32_t EntryPoint); // Function BTS_UpdateMeleeCombatLocation.BTS_UpdateMeleeCombatLocation_C.ExecuteUbergraph_BTS_UpdateMeleeCombatLocation
}; 



