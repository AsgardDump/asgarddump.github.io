#pragma once 
#include <BP_Immortal_HealthTank_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Immortal_HealthTank.BP_Immortal_HealthTank_C
// Size: 0x338(Inherited: 0x330) 
struct ABP_Immortal_HealthTank_C : public AORHealthTankItem
{
	struct USceneComponent* DefaultSceneRoot;  // 0x330(0x8)

}; 



