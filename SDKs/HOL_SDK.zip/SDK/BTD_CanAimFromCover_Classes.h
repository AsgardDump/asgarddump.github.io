#pragma once 
#include <BTD_CanAimFromCover_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_CanAimFromCover.BTD_CanAimFromCover_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_CanAimFromCover_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_CanAimFromCover.BTD_CanAimFromCover_C.PerformConditionCheckAI
}; 



