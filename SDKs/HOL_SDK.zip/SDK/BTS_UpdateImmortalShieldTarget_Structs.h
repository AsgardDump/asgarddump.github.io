#pragma once 
#include "SDK.h" 
 
 
// Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ExecuteUbergraph_BTS_UpdateImmortalShieldTarget
// Size: 0x4D(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_UpdateImmortalShieldTarget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValidAndAlive_IsAliveAndWell : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct ABP_Immortal_C* K2Node_DynamicCast_AsBP_Immortal;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AORAICharacter* CallFunc_GetBestShieldTarget_TargetCharacter;  // 0x30(0x8)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x38(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x40(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4C(0x1)

}; 
// Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_UpdateImmortalShieldTarget.BTS_UpdateImmortalShieldTarget_C.ReceiveSearchStartAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveSearchStartAI : public FReceiveSearchStartAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
