#pragma once 
#include <BTD_ImmortalMovementModeCheck_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_ImmortalMovementModeCheck.BTD_ImmortalMovementModeCheck_C
// Size: 0xA1(Inherited: 0xA0) 
struct UBTD_ImmortalMovementModeCheck_C : public UBTDecorator_BlueprintBase
{
	char E_ImmortalMovementMode MovementMode;  // 0xA0(0x1)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_ImmortalMovementModeCheck.BTD_ImmortalMovementModeCheck_C.PerformConditionCheckAI
}; 



