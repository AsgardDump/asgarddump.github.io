#pragma once 
#include <CharacterCreatorFullscreenContainer_BP_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C
// Size: 0x2D0(Inherited: 0x290) 
struct UCharacterCreatorFullscreenContainer_BP_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct UImage* Image_47;  // 0x298(0x8)
	struct FMulticastInlineDelegate OnContainerFocused;  // 0x2A0(0x30)

	struct FEventReply OnFocusReceived(struct FGeometry MyGeometry, struct FFocusEvent InFocusEvent); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.OnFocusReceived
	void Construct(); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.Construct
	void ExecuteUbergraph_CharacterCreatorFullscreenContainer_BP(int32_t EntryPoint); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.ExecuteUbergraph_CharacterCreatorFullscreenContainer_BP
	void OnContainerFocused__DelegateSignature(); // Function CharacterCreatorFullscreenContainer_BP.CharacterCreatorFullscreenContainer_BP_C.OnContainerFocused__DelegateSignature
}; 



