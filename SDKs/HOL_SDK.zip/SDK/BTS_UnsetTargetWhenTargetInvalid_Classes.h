#pragma once 
#include <BTS_UnsetTargetWhenTargetInvalid_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C
// Size: 0xC8(Inherited: 0x98) 
struct UBTS_UnsetTargetWhenTargetInvalid_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector TargetKey;  // 0xA0(0x28)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C.ReceiveTickAI
	void ExecuteUbergraph_BTS_UnsetTargetWhenTargetInvalid(int32_t EntryPoint); // Function BTS_UnsetTargetWhenTargetInvalid.BTS_UnsetTargetWhenTargetInvalid_C.ExecuteUbergraph_BTS_UnsetTargetWhenTargetInvalid
}; 



