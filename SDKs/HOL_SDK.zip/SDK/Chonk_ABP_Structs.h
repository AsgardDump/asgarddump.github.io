#pragma once 
#include "SDK.h" 
 
 
// Function Chonk_ABP.Chonk_ABP_C.K2_OwnerItemEventFired
// Size: 0x19(Inherited: 0x20) 
struct FK2_OwnerItemEventFired : public FK2_OwnerItemEventFired
{
	struct ASQInventoryItem* Item;  // 0x0(0x8)
	struct FGameplayTag EventTag;  // 0x8(0x8)
	struct FGameplayTag FireModeTag;  // 0x10(0x8)
	char EInventoryTransactionType TransactionType;  // 0x18(0x1)

}; 
// Function Chonk_ABP.Chonk_ABP_C.ExecuteUbergraph_Chonk_ABP
// Size: 0x28D(Inherited: 0x0) 
struct FExecuteUbergraph_Chonk_ABP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ASQInventoryItem* K2Node_Event_Item;  // 0x8(0x8)
	struct FGameplayTag K2Node_Event_EventTag;  // 0x10(0x8)
	struct FGameplayTag K2Node_Event_FireModeTag;  // 0x18(0x8)
	char EInventoryTransactionType K2Node_Event_TransactionType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UObject* K2Node_Event_Killer;  // 0x28(0x8)
	struct FHitResult K2Node_Event_HitResult_2;  // 0x30(0x90)
	struct FGameplayTagContainer K2Node_Event_DamageTags_2;  // 0xC0(0x20)
	struct UObject* K2Node_Event_Damager;  // 0xE0(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0xE8(0x90)
	float K2Node_Event_Damage;  // 0x178(0x4)
	char pad_380[4];  // 0x17C(0x4)
	struct FGameplayTagContainer K2Node_Event_DamageTags;  // 0x180(0x20)
	float K2Node_Event_DeltaTimeX;  // 0x1A0(0x4)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_IsHitReactImmune_IsImmune : 1;  // 0x1A4(0x1)
	char pad_421[3];  // 0x1A5(0x3)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x1A8(0x8)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x1B0(0x90)
	struct FGameplayTagContainer K2Node_CustomEvent_HitReactTag;  // 0x240(0x20)
	struct AChonk_BP_C* K2Node_DynamicCast_AsChonk_BP;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x268(0x1)
	char pad_617[3];  // 0x269(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x26C(0x10)
	struct FVector CallFunc_GetLookAtTargetLocation_ReturnValue;  // 0x27C(0xC)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool CallFunc_HasLookAtLocation_ReturnValue : 1;  // 0x289(0x1)
	char pad_650_1 : 7;  // 0x28A(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x28A(0x1)
	char pad_651_1 : 7;  // 0x28B(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x28B(0x1)
	char pad_652_1 : 7;  // 0x28C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x28C(0x1)

}; 
// Function Chonk_ABP.Chonk_ABP_C.UpdateYawAngularRotationSpeed
// Size: 0x3C(Inherited: 0x0) 
struct FUpdateYawAngularRotationSpeed
{
	float DeltaTime;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x14(0xC)
	struct FRotator CallFunc_NormalizedDeltaRotator_ReturnValue;  // 0x20(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x2C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x30(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x34(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x38(0x4)

}; 
// Function Chonk_ABP.Chonk_ABP_C.UpdateWalkBSValues
// Size: 0x18(Inherited: 0x0) 
struct FUpdateWalkBSValues
{
	struct FVector Temp_struct_Variable;  // 0x0(0xC)
	struct FVector Temp_struct_Variable_2;  // 0xC(0xC)

}; 
// Function Chonk_ABP.Chonk_ABP_C.K2_OwnerDamageTakenEventFired
// Size: 0xC0(Inherited: 0xC0) 
struct FK2_OwnerDamageTakenEventFired : public FK2_OwnerDamageTakenEventFired
{
	struct UObject* Damager;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	float Damage;  // 0x98(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA0(0x20)

}; 
// Function Chonk_ABP.Chonk_ABP_C.CacheDismemberComponent
// Size: 0x29(Inherited: 0x0) 
struct FCacheDismemberComponent
{
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x0(0x8)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x8(0x8)
	struct AChonk_BP_C* K2Node_DynamicCast_AsChonk_BP;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct ASQDetachedMemberGib* K2Node_DynamicCast_AsSQDetached_Member_Gib;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x28(0x1)

}; 
// Function Chonk_ABP.Chonk_ABP_C.ForceHitReact
// Size: 0xB0(Inherited: 0x0) 
struct FForceHitReact
{
	struct FHitResult HitResult;  // 0x0(0x90)
	struct FGameplayTagContainer HitReactTag;  // 0x90(0x20)

}; 
// Function Chonk_ABP.Chonk_ABP_C.K2_OwnerDiedEventFired
// Size: 0xB8(Inherited: 0xB8) 
struct FK2_OwnerDiedEventFired : public FK2_OwnerDiedEventFired
{
	struct UObject* Killer;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	struct FGameplayTagContainer DamageTags;  // 0x98(0x20)

}; 
// Function Chonk_ABP.Chonk_ABP_C.OwnerDiedEvent
// Size: 0x100(Inherited: 0x0) 
struct FOwnerDiedEvent
{
	struct UObject* Killer;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	struct FGameplayTagContainer DamageTags;  // 0x98(0x20)
	struct UAnimMontage* DeathMontageToPlay;  // 0xB8(0x8)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_HasAnyTags_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue_2;  // 0xE0(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter_2;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xF1(0x1)
	char pad_242[6];  // 0xF2(0x6)
	struct UAnimMontage* CallFunc_PickRandomMontageForHitResultDirection2D_ReturnValue;  // 0xF8(0x8)

}; 
// Function Chonk_ABP.Chonk_ABP_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function Chonk_ABP.Chonk_ABP_C.ItemEventFired
// Size: 0x18(Inherited: 0x0) 
struct FItemEventFired
{
	struct ASQInventoryItem* Item;  // 0x0(0x8)
	struct FGameplayTag EventTag;  // 0x8(0x8)
	struct FGameplayTag FireModeTag;  // 0x10(0x8)

}; 
// Function Chonk_ABP.Chonk_ABP_C.OwnerEventDamageTaken
// Size: 0xB5(Inherited: 0x0) 
struct FOwnerEventDamageTaken
{
	struct FHitResult HitResult;  // 0x0(0x90)
	struct FGameplayTagContainer TagContainer;  // 0x90(0x20)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_Montage_IsPlaying_ReturnValue : 1;  // 0xB1(0x1)
	uint8_t  CallFunc_LargestHitReactionTypeInTagContainer_HitReactionType;  // 0xB2(0x1)
	char pad_179_1 : 7;  // 0xB3(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xB3(0x1)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_ORControllerAllowFlinchHitReacts_bAllowFlinchHitReacts : 1;  // 0xB4(0x1)

}; 
// Function Chonk_ABP.Chonk_ABP_C.PlayMontageForFlinchHit_Small
// Size: 0xA8(Inherited: 0x0) 
struct FPlayMontageForFlinchHit_Small
{
	struct FHitResult HitResult;  // 0x0(0x90)
	struct UAnimMontage* FlinchMontageToPlay;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	float CallFunc_Montage_Play_ReturnValue;  // 0x9C(0x4)
	struct UAnimMontage* CallFunc_PickRandomMontageForHitResultDirection2D_ReturnValue;  // 0xA0(0x8)

}; 
// Function Chonk_ABP.Chonk_ABP_C.PlayMontageAndUpdateBBForFlinchHit_Medium
// Size: 0xA8(Inherited: 0x0) 
struct FPlayMontageAndUpdateBBForFlinchHit_Medium
{
	struct FHitResult HitResult;  // 0x0(0x90)
	struct UAnimMontage* FlinchMontageToPlay;  // 0x90(0x8)
	struct UAnimMontage* CallFunc_PickRandomMontageForHitResultDirection2D_ReturnValue;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	float CallFunc_Montage_Play_ReturnValue;  // 0xA4(0x4)

}; 
// Function Chonk_ABP.Chonk_ABP_C.UpdateIsAlerted
// Size: 0x41(Inherited: 0x0) 
struct FUpdateIsAlerted
{
	struct AORAIController* LocalMyAIController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x10(0x8)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue_2;  // 0x18(0x8)
	struct TScriptInterface<IGameplayTagAssetInterface> K2Node_DynamicCast_AsGameplay_Tag_Asset_Interface;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_HasMatchingGameplayTag_ReturnValue : 1;  // 0x40(0x1)

}; 
// Function Chonk_ABP.Chonk_ABP_C.IsHitReactImmune
// Size: 0x33(Inherited: 0x0) 
struct FIsHitReactImmune
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsImmune : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UAbilitySystemComponent* CallFunc_GetAbilitySystemComponent_ReturnValue;  // 0x18(0x8)
	struct TScriptInterface<IGameplayTagAssetInterface> CallFunc_HasMatchingGameplayTag_self_CastInput;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_HasMatchingGameplayTag_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x32(0x1)

}; 
// Function Chonk_ABP.Chonk_ABP_C.ORControllerAllowFlinchHitReacts
// Size: 0x28(Inherited: 0x0) 
struct FORControllerAllowFlinchHitReacts
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllowFlinchHitReacts : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AORAIController* TheORAIController;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_AllowHitReacts_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x18(0x8)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x20(0x8)

}; 
// Function Chonk_ABP.Chonk_ABP_C.SetControllerBBHitReactionDuration
// Size: 0x1A(Inherited: 0x0) 
struct FSetControllerBBHitReactionDuration
{
	float HitReactDuration;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x8(0x8)
	struct AORAIController* CallFunc_GetORAIController_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_SetHitReactDurationKey_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function Chonk_ABP.Chonk_ABP_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
