#pragma once 
#include "SDK.h" 
 
 
// Function BTD_IsWithinDistanceFromTarget.BTD_IsWithinDistanceFromTarget_C.PerformConditionCheckAI
// Size: 0x9D(Inherited: 0x18) 
struct FPerformConditionCheckAI : public FPerformConditionCheckAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x14(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x20(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x2C(0xC)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x38(0x8)
	struct FVector CallFunc_GetBlackboardValueAsVector_ReturnValue;  // 0x40(0xC)
	float CallFunc_Vector_Distance2D_ReturnValue;  // 0x4C(0x4)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x50(0x1)
	struct UObject* CallFunc_GetValueAsObject_ReturnValue;  // 0x58(0x8)
	struct USceneComponent* K2Node_DynamicCast_AsScene_Component;  // 0x60(0x8)
	char pad_118_1 : 7;  // 0x76(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_119_1 : 7;  // 0x77(0x1)
	bool CallFunc_IsVectorValueSet_ReturnValue : 1;  // 0x69(0x1)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x6C(0xC)
	float CallFunc_Vector_Distance2D_ReturnValue_2;  // 0x78(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x7C(0x1)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x80(0x8)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x88(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x8C(0xC)
	float CallFunc_Vector_Distance2D_ReturnValue_3;  // 0x98(0x4)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0x9C(0x1)

}; 
