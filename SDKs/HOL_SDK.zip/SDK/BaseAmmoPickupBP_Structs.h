#pragma once 
#include "SDK.h" 
 
 
// Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.AttemptAutoReload
// Size: 0x81(Inherited: 0x0) 
struct FAttemptAutoReload
{
	struct AORPlayerCharacter* Character;  // 0x0(0x8)
	struct AORFireableInventoryItem* Item;  // 0x8(0x8)
	struct FGameplayTag Temp_struct_Variable;  // 0x10(0x8)
	struct AORFireableInventoryItem* CallFunc_GetEquippedPrimaryItem_ReturnValue;  // 0x18(0x8)
	struct AORFireableInventoryItem* K2Node_DynamicCast_AsORFireable_Inventory_Item;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FFireMode CallFunc_Map_Find_Value;  // 0x30(0x48)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x7A(0x1)
	char pad_123[1];  // 0x7B(0x1)
	int32_t CallFunc_GetResourceAvailable_ReturnValue;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x80(0x1)

}; 
// Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ReceivedAmmo
// Size: 0x14(Inherited: 0x18) 
struct FReceivedAmmo : public FReceivedAmmo
{
	struct AORFireableInventoryItem* Item;  // 0x0(0x8)
	struct AORPlayerCharacter* PlayerCharacter;  // 0x8(0x8)
	int32_t AmmoPickedUP;  // 0x10(0x4)

}; 
// Function BaseAmmoPickupBP.BaseAmmoPickupBP_C.ExecuteUbergraph_BaseAmmoPickupBP
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_BaseAmmoPickupBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AORFireableInventoryItem* K2Node_Event_Item;  // 0x8(0x8)
	struct AORPlayerCharacter* K2Node_Event_PlayerCharacter;  // 0x10(0x8)
	int32_t K2Node_Event_AmmoPickedUP;  // 0x18(0x4)

}; 
