#pragma once 
#include "SDK.h" 
 
 
// Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.ExecuteUbergraph_Ability_PlayerExecute_BP
// Size: 0xE8(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_PlayerExecute_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AORAICharacter* K2Node_Event_TargetCharacter;  // 0x8(0x8)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x10(0x8)
	struct APlayerCharacter_BP_C* K2Node_DynamicCast_AsPlayer_Character_BP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)
	float CallFunc_GetCurrentHealth_ReturnValue;  // 0x24(0x4)
	struct APlayerCharacter_BP_C* CallFunc_GetORPlayer_PlayerCharacter;  // 0x28(0x8)
	struct FHitResult CallFunc_MakeHitResult_ReturnValue;  // 0x30(0x90)
	struct APlayerCharacter_BP_C* CallFunc_GetORPlayer_PlayerCharacter_2;  // 0xC0(0x8)
	struct TArray<struct FActiveGameplayEffectHandle> CallFunc_ApplyGameplayEffectArray_ReturnValue;  // 0xC8(0x10)
	struct TArray<struct FActiveGameplayEffectHandle> CallFunc_ApplyGameplayEffectArray_ReturnValue_2;  // 0xD8(0x10)

}; 
// Function Ability_PlayerExecute_BP.Ability_PlayerExecute_BP_C.OnExecutionStart
// Size: 0x8(Inherited: 0x8) 
struct FOnExecutionStart : public FOnExecutionStart
{
	struct AORAICharacter* TargetCharacter;  // 0x0(0x8)

}; 
