#pragma once 
#include <BP_3DMapVolume_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_3DMapVolume.BP_3DMapVolume_C
// Size: 0x290(Inherited: 0x278) 
struct ABP_3DMapVolume_C : public AOR3DMapVolume
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x278(0x8)
	struct UStaticMeshComponent* EditorPreview;  // 0x280(0x8)
	struct UBillboardComponent* EditorBillboard;  // 0x288(0x8)

	void UserConstructionScript(); // Function BP_3DMapVolume.BP_3DMapVolume_C.UserConstructionScript
	void OnActorEnterMapVolume(struct AActor* Actor, struct AORTriggerVolume* Volume); // Function BP_3DMapVolume.BP_3DMapVolume_C.OnActorEnterMapVolume
	void ExecuteUbergraph_BP_3DMapVolume(int32_t EntryPoint); // Function BP_3DMapVolume.BP_3DMapVolume_C.ExecuteUbergraph_BP_3DMapVolume
}; 



