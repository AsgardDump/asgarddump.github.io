#pragma once 
#include <Ability_EquipWeaponSlot3_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_EquipWeaponSlot3.Ability_EquipWeaponSlot3_C
// Size: 0x400(Inherited: 0x3F5) 
struct UAbility_EquipWeaponSlot3_C : public UAbility_ChangeEquippedWeapon_C
{
	char pad_1013[3];  // 0x3F5(0x3)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F8(0x8)

	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_EquipWeaponSlot3.Ability_EquipWeaponSlot3_C.K2_OnEndAbility
	void ExecuteUbergraph_Ability_EquipWeaponSlot3(int32_t EntryPoint); // Function Ability_EquipWeaponSlot3.Ability_EquipWeaponSlot3_C.ExecuteUbergraph_Ability_EquipWeaponSlot3
}; 



