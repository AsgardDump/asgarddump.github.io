#pragma once 
#include <CheckDebugAllowAttacks_Structs.h>
 
 
 
// BlueprintGeneratedClass CheckDebugAllowAttacks.CheckDebugAllowAttacks_C
// Size: 0xC8(Inherited: 0xC8) 
struct UCheckDebugAllowAttacks_C : public UUtilityConsideration
{

}; 



