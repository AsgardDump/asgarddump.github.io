#pragma once 
#include "SDK.h" 
 
 
// Function BlockCrouch_GA.BlockCrouch_GA_C.ExecuteUbergraph_BlockCrouch_GA
// Size: 0x1A(Inherited: 0x0) 
struct FExecuteUbergraph_BlockCrouch_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsCrouching_ReturnValue : 1;  // 0x19(0x1)

}; 
