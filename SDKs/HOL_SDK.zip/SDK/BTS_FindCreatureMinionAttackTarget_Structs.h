#pragma once 
#include "SDK.h" 
 
 
// Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.ExecuteUbergraph_BTS_FindCreatureMinionAttackTarget
// Size: 0x9C(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_FindCreatureMinionAttackTarget
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AAIController* K2Node_Event_OwnerController;  // 0x18(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x20(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue;  // 0x30(0x8)
	struct AORAICreatureMinionController* K2Node_DynamicCast_AsORAICreature_Minion_Controller;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x43(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x44(0x10)
	char pad_84[4];  // 0x54(0x4)
	struct UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance;  // 0x58(0x8)
	char EEnvQueryStatus K2Node_CustomEvent_QueryStatus;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct TArray<struct AActor*> CallFunc_GetQueryResultsAsActors_ResultActors;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_GetQueryResultsAsActors_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct AActor* CallFunc_Array_Get_Item;  // 0x80(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct AORCharacter* K2Node_DynamicCast_AsORCharacter;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9A(0x1)
	char pad_155_1 : 7;  // 0x9B(0x1)
	bool CallFunc_IsValidAttackTarget_ReturnValue : 1;  // 0x9B(0x1)

}; 
// Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.QueryFinished
// Size: 0x9(Inherited: 0x0) 
struct FQueryFinished
{
	struct UEnvQueryInstanceBlueprintWrapper* QueryInstance;  // 0x0(0x8)
	char EEnvQueryStatus QueryStatus;  // 0x8(0x1)

}; 
