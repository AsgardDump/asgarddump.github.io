#pragma once 
#include <BP_Deepcut_Chonk_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Deepcut_Chonk.BP_Deepcut_Chonk_C
// Size: 0x250(Inherited: 0x220) 
struct ABP_Deepcut_Chonk_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DecalPosition;  // 0x228(0x8)
	struct UNiagaraComponent* Niagara;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float Min;  // 0x240(0x4)
	float Max;  // 0x244(0x4)
	float DecalLifetime;  // 0x248(0x4)
	float Timestamp;  // 0x24C(0x4)

	void SpawnBloodDecal(); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.SpawnBloodDecal
	void ReceiveBeginPlay(); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ReceiveTick
	void Execute(); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.Execute
	void ExecuteUbergraph_BP_Deepcut_Chonk(int32_t EntryPoint); // Function BP_Deepcut_Chonk.BP_Deepcut_Chonk_C.ExecuteUbergraph_BP_Deepcut_Chonk
}; 



