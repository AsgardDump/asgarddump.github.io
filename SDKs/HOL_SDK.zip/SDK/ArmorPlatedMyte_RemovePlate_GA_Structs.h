#pragma once 
#include "SDK.h" 
 
 
// Function ArmorPlatedMyte_RemovePlate_GA.ArmorPlatedMyte_RemovePlate_GA_C.ExecuteUbergraph_ArmorPlatedMyte_RemovePlate_GA
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_ArmorPlatedMyte_RemovePlate_GA
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetAvatarActorFromActorInfo_ReturnValue;  // 0x8(0x8)
	struct TScriptInterface<IIArmored_C> K2Node_DynamicCast_AsIArmored;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
