#pragma once 
#include "SDK.h" 
 
 
// Function BTT_CreatureMinionRecordTaskComplete.BTT_CreatureMinionRecordTaskComplete_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTT_CreatureMinionRecordTaskComplete.BTT_CreatureMinionRecordTaskComplete_C.ExecuteUbergraph_BTT_CreatureMinionRecordTaskComplete
// Size: 0x22(Inherited: 0x0) 
struct FExecuteUbergraph_BTT_CreatureMinionRecordTaskComplete
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct AORAICreatureMinionController* K2Node_DynamicCast_AsORAICreature_Minion_Controller;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)

}; 
