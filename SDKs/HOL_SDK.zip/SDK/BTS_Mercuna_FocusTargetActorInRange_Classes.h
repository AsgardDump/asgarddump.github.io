#pragma once 
#include <BTS_Mercuna_FocusTargetActorInRange_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C
// Size: 0xD4(Inherited: 0x98) 
struct UBTS_Mercuna_FocusTargetActorInRange_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector TargetActorKey;  // 0xA0(0x28)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool ClearFocusOnDeactivation : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float ActivationDelay;  // 0xCC(0x4)
	float TimeSinceActivation;  // 0xD0(0x4)

	void Set Mercuna Look At(struct APawn* controllerPawn, struct AActor* TargetActor); // Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.Set Mercuna Look At
	void ClearMercunaLookAt(struct APawn* controllerPawn); // Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ClearMercunaLookAt
	void UpdateControllerFocus(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.UpdateControllerFocus
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ReceiveTickAI
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ReceiveDeactivationAI
	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ReceiveActivationAI
	void ExecuteUbergraph_BTS_Mercuna_FocusTargetActorInRange(int32_t EntryPoint); // Function BTS_Mercuna_FocusTargetActorInRange.BTS_Mercuna_FocusTargetActorInRange_C.ExecuteUbergraph_BTS_Mercuna_FocusTargetActorInRange
}; 



