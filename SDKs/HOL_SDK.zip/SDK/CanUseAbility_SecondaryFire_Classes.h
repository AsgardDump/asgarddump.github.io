#pragma once 
#include <CanUseAbility_SecondaryFire_Structs.h>
 
 
 
// BlueprintGeneratedClass CanUseAbility_SecondaryFire.CanUseAbility_SecondaryFire_C
// Size: 0xC8(Inherited: 0xC8) 
struct UCanUseAbility_SecondaryFire_C : public UUtilityConsideration
{

}; 



