#pragma once 
#include "SDK.h" 
 
 
// Function BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C.ReceiveDeactivationAI
// Size: 0x19(Inherited: 0x10) 
struct FReceiveDeactivationAI : public FReceiveDeactivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	struct AORAIController* K2Node_DynamicCast_AsORAIController;  // 0x10(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BTS_RequestReturnAttackToken.BTS_RequestReturnAttackToken_C.ReceiveActivationAI
// Size: 0xAA(Inherited: 0x10) 
struct FReceiveActivationAI : public FReceiveActivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	struct AActor* TargetActor;  // 0x10(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x18(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	struct AORAIController* K2Node_DynamicCast_AsORAIController;  // 0x28(0x8)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x31(0x1)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x38(0x8)
	struct FORAbilityUsageData CallFunc_GetAbilityUsageDataForTag_OutAbilityData;  // 0x40(0x68)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool CallFunc_GetAbilityUsageDataForTag_ReturnValue : 1;  // 0xA8(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_RequestAttackTokenForTarget_ReturnValue : 1;  // 0xA9(0x1)

}; 
