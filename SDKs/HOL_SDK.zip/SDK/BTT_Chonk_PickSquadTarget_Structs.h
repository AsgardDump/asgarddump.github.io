#pragma once 
#include "SDK.h" 
 
 
// Function BTT_Chonk_PickSquadTarget.BTT_Chonk_PickSquadTarget_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTT_Chonk_PickSquadTarget.BTT_Chonk_PickSquadTarget_C.ExecuteUbergraph_BTT_Chonk_PickSquadTarget
// Size: 0x22(Inherited: 0x0) 
struct FExecuteUbergraph_BTT_Chonk_PickSquadTarget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct AChonk_BP_C* K2Node_DynamicCast_AsChonk_BP;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_TargetBestFriendlyCharacter_FoundTarget : 1;  // 0x21(0x1)

}; 
