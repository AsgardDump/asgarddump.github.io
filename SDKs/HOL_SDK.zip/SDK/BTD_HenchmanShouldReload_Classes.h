#pragma once 
#include <BTD_HenchmanShouldReload_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_HenchmanShouldReload.BTD_HenchmanShouldReload_C
// Size: 0xA0(Inherited: 0xA0) 
struct UBTD_HenchmanShouldReload_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_HenchmanShouldReload.BTD_HenchmanShouldReload_C.PerformConditionCheckAI
}; 



