#pragma once 
#include <BTD_IsInCover_Structs.h>
 
 
 
// BlueprintGeneratedClass BTD_IsInCover.BTD_IsInCover_C
// Size: 0xA8(Inherited: 0xA0) 
struct UBTD_IsInCover_C : public UBTDecorator_BlueprintBase
{
	struct FGameplayTag TakingCoverGamplayTag;  // 0xA0(0x8)

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTD_IsInCover.BTD_IsInCover_C.PerformConditionCheckAI
}; 



