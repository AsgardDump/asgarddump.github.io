#pragma once 
#include <BTS_FindCreatureMinionAttackTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C
// Size: 0x100(Inherited: 0x98) 
struct UBTS_FindCreatureMinionAttackTarget_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector ActorTarget_Key;  // 0xA0(0x28)
	struct FBlackboardKeySelector CombatBehaviorSubState_Key;  // 0xC8(0x28)
	float SearchRadius;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool IsQueryRunning : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	struct AORAICreatureMinionController* CreatureMinionController_Chached;  // 0xF8(0x8)

	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.ReceiveTickAI
	void QueryFinished(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus); // Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.QueryFinished
	void ExecuteUbergraph_BTS_FindCreatureMinionAttackTarget(int32_t EntryPoint); // Function BTS_FindCreatureMinionAttackTarget.BTS_FindCreatureMinionAttackTarget_C.ExecuteUbergraph_BTS_FindCreatureMinionAttackTarget
}; 



