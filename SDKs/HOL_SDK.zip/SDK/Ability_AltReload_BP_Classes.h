#pragma once 
#include <Ability_AltReload_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_AltReload_BP.Ability_AltReload_BP_C
// Size: 0x428(Inherited: 0x428) 
struct UAbility_AltReload_BP_C : public UORGameplayAbility_FireItem
{

}; 



