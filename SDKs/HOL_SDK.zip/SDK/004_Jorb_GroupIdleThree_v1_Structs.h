#pragma once 
#include "SDK.h" 
 
 
// Function 004_Jorb_GroupIdleThree_v1.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_SequenceDirector
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AJorb_BP_C* K2Node_CustomEvent_Jorb_BP;  // 0x8(0x8)
	struct UAnimSequence* K2Node_CustomEvent_Anim;  // 0x10(0x8)

}; 
// Function 004_Jorb_GroupIdleThree_v1.SequenceDirector_C.Jorb_BP_Event_1
// Size: 0x10(Inherited: 0x0) 
struct FJorb_BP_Event_1
{
	struct AJorb_BP_C* Jorb_BP;  // 0x0(0x8)
	struct UAnimSequence* Anim;  // 0x8(0x8)

}; 
