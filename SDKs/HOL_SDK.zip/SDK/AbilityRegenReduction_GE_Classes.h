#pragma once 
#include <AbilityRegenReduction_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass AbilityRegenReduction_GE.AbilityRegenReduction_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UAbilityRegenReduction_GE_C : public UORGameplayEffect
{

}; 



