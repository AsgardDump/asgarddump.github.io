#pragma once 
#include "SDK.h" 
 
 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsNewMoveToLocation
// Size: 0x58(Inherited: 0x0) 
struct FNeedsNewMoveToLocation
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool NeedsMove : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AORAICharacter* LocalORAICharacter;  // 0x18(0x8)
	struct AActor* BBTargetActor;  // 0x20(0x8)
	struct AORAIHenchmanController_BP_C* ProtoEnemyController;  // 0x28(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AORAIHenchmanController_BP_C* K2Node_DynamicCast_AsORAIHenchman_Controller_BP;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_NeedsPositionForPeriodicMove_NeedsPosition : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_NeedsPositionForAttackRanging_NeedsPosition : 1;  // 0x4B(0x1)
	char pad_76[4];  // 0x4C(0x4)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x50(0x8)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ExecuteUbergraph_BTS_UpdateAttackLocation
// Size: 0xE0(Inherited: 0x0) 
struct FExecuteUbergraph_BTS_UpdateAttackLocation
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UEnvQueryInstanceBlueprintWrapper* K2Node_CustomEvent_QueryInstance;  // 0x8(0x8)
	char EEnvQueryStatus K2Node_CustomEvent_QueryStatus;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AORAIWeaponizedController* K2Node_DynamicCast_AsORAIWeaponized_Controller;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FVector> CallFunc_GetQueryResultsAsLocations_ResultLocations;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_GetQueryResultsAsLocations_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct AAIController* K2Node_Event_OwnerController_2;  // 0x48(0x8)
	struct APawn* K2Node_Event_ControlledPawn_2;  // 0x50(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct AAIController* K2Node_Event_OwnerController;  // 0x70(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_NeedsNewMoveToLocation_NeedsMove : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x84(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x94(0x10)
	float CallFunc_GetBlackboardValueAsFloat_ReturnValue;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_FindGoodAttractLocationForMove_FoundLocation : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	struct FVector CallFunc_FindGoodAttractLocationForMove_NewLocation;  // 0xAC(0xC)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_GetBestEQSQueryForMove_NeedsToRunQuery : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct UEnvQuery* CallFunc_GetBestEQSQueryForMove_QueryToRun;  // 0xC0(0x8)
	struct AORAIHenchmanController_BP_C* CallFunc_GetBestEQSQueryForMove_ORProtoController;  // 0xC8(0x8)
	float CallFunc_GetAttackRepositionDistances_AttackRepositionDistanceMin;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)
	struct UEnvQueryInstanceBlueprintWrapper* CallFunc_RunEQSQuery_ReturnValue;  // 0xD8(0x8)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ReceiveDeactivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveDeactivationAI : public FReceiveDeactivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsPositionForPeriodicMove
// Size: 0x1D(Inherited: 0x0) 
struct FNeedsPositionForPeriodicMove
{
	struct AActor* TargetActor;  // 0x0(0x8)
	struct AORAIHenchmanController_BP_C* OwningController;  // 0x8(0x8)
	struct APawn* ControlledPawn;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool NeedsPosition : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_WantsToAttackReposition_Reposition : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_GetBlackboardValueAsBool_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1C(0x1)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ReceiveTickAI
// Size: 0x14(Inherited: 0x18) 
struct FReceiveTickAI : public FReceiveTickAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	float DeltaSeconds;  // 0x10(0x4)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.EQS_QueryComplete
// Size: 0x9(Inherited: 0x0) 
struct FEQS_QueryComplete
{
	struct UEnvQueryInstanceBlueprintWrapper* QueryInstance;  // 0x0(0x8)
	char EEnvQueryStatus QueryStatus;  // 0x8(0x1)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsPositionForAttackRanging
// Size: 0x58(Inherited: 0x0) 
struct FNeedsPositionForAttackRanging
{
	struct AActor* TargetActor;  // 0x0(0x8)
	struct AORAICharacter* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool NeedsPosition : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AORAICharacter* LocalControlledAIHenchmanCharacter;  // 0x18(0x8)
	struct AActor* LocalTargetActor;  // 0x20(0x8)
	float Dist_TargetActorToControlledPawn;  // 0x28(0x4)
	float Dist_TargetActorToMoveLocation;  // 0x2C(0x4)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x30(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x34(0xC)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x42(0x1)
	char pad_67[1];  // 0x43(0x1)
	struct FVector CallFunc_GetBlackboardValueAsVector_ReturnValue;  // 0x44(0xC)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x54(0x4)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.GetBestEQSQueryForMove
// Size: 0x68(Inherited: 0x0) 
struct FGetBestEQSQueryForMove
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool NeedsToRunQuery : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UEnvQuery* QueryToRun;  // 0x18(0x8)
	struct AORAIHenchmanController_BP_C* ORProtoController;  // 0x20(0x8)
	struct AORAICharacter* LocalORAICharacter;  // 0x28(0x8)
	struct AActor* BBTargetActor;  // 0x30(0x8)
	struct AORAIHenchmanController_BP_C* ProtoEnemyController;  // 0x38(0x8)
	struct AORAICharacter* K2Node_DynamicCast_AsORAICharacter;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AORAIHenchmanController_BP_C* K2Node_DynamicCast_AsORAIHenchman_Controller_BP;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_NeedsPositionForPeriodicMove_NeedsPosition : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_NeedsPositionForAttackRanging_NeedsPosition : 1;  // 0x5A(0x1)
	char pad_91[5];  // 0x5B(0x5)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x60(0x8)

}; 
// Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.FindGoodAttractLocationForMove
// Size: 0x5E8(Inherited: 0x0) 
struct FFindGoodAttractLocationForMove
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct AORAICharacter* ControlledPawn;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool FoundLocation : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVector NewLocation;  // 0x14(0xC)
	struct AORAIController* LocalORAIController;  // 0x20(0x8)
	struct UObject* AttractionPoint;  // 0x28(0x8)
	struct AActor* BBTargetActor;  // 0x30(0x8)
	struct AORAIController* K2Node_DynamicCast_AsORAIController;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct UORAttractionPointSubsystem* CallFunc_GetWorldSubsystem_ReturnValue;  // 0x48(0x8)
	uint8_t  CallFunc_GetCoverType_ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FORAttractionPointSubsystemQuery CallFunc_GetCurrentAttractionPointQuery_ReturnValue;  // 0x58(0x548)
	char pad_1440_1 : 7;  // 0x5A0(0x1)
	bool CallFunc_ClaimAttractionPoint_ReturnValue : 1;  // 0x5A0(0x1)
	char pad_1441[7];  // 0x5A1(0x7)
	struct UObject* CallFunc_QueryBestAttractionPointWithTarget_ReturnValue;  // 0x5A8(0x8)
	struct TScriptInterface<IORAttractionPointInterface> K2Node_DynamicCast_AsORAttraction_Point_Interface;  // 0x5B0(0x10)
	char pad_1472_1 : 7;  // 0x5C0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x5C0(0x1)
	char pad_1473_1 : 7;  // 0x5C1(0x1)
	bool CallFunc_ClaimAttractionPoint_ReturnValue_2 : 1;  // 0x5C1(0x1)
	char pad_1474[2];  // 0x5C2(0x2)
	struct FVector CallFunc_GetAttractionPointLocation_ReturnValue;  // 0x5C4(0xC)
	struct FVector Temp_struct_Variable;  // 0x5D0(0xC)
	char pad_1500[4];  // 0x5DC(0x4)
	struct AActor* CallFunc_GetBlackboardValueAsActor_ReturnValue;  // 0x5E0(0x8)

}; 
