#pragma once 
#include <CanAimFromCover_Structs.h>
 
 
 
// BlueprintGeneratedClass CanAimFromCover.CanAimFromCover_C
// Size: 0xC8(Inherited: 0xC8) 
struct UCanAimFromCover_C : public UUtilityConsideration
{

}; 



