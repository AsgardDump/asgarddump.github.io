#pragma once 
#include <Chonk_FriendlyFire_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Chonk_FriendlyFire_BP.Chonk_FriendlyFire_BP_C
// Size: 0x448(Inherited: 0x448) 
struct UChonk_FriendlyFire_BP_C : public UORGameplayAbility_Montage
{

}; 



