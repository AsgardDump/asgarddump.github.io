#pragma once 
#include "SDK.h" 
 
 
// Function CharacterSelect_BP.CharacterSelect_BP_C.ExecuteUbergraph_CharacterSelect_BP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_CharacterSelect_BP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function CharacterSelect_BP.CharacterSelect_BP_C.PushSelectionWidget
// Size: 0x8(Inherited: 0x0) 
struct FPushSelectionWidget
{
	struct UUserWidget* CallFunc_GetWidget_ReturnValue;  // 0x0(0x8)

}; 
// Function CharacterSelect_BP.CharacterSelect_BP_C.PopSelectionWidget
// Size: 0x19(Inherited: 0x0) 
struct FPopSelectionWidget
{
	struct UWidget* CallFunc_UIManager_PopWidget_ReturnValue;  // 0x0(0x8)
	struct UWidget* CallFunc_UIManager_GetTopmostWidget_ReturnValue;  // 0x8(0x8)
	struct UUserWidget* CallFunc_GetWidget_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x18(0x1)

}; 
