#pragma once 
#include "SDK.h" 
 
 
// Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.ExecuteUbergraph_Ability_EquipNextWeapon_BP
// Size: 0x31(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_EquipNextWeapon_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UORPlayerInventory* CallFunc_GetOwningInventory_OutInventory;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsCurrentIndexValidEquippable_Valid : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct ASQEquippableInventoryItem* CallFunc_GetFirstEquippedItem_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x24(0x4)
	struct FGameplayTag CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_EquipItem_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.SafelyIncrementWeaponIndex
// Size: 0xC(Inherited: 0x0) 
struct FSafelyIncrementWeaponIndex
{
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x8(0x4)

}; 
// Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.IsCurrentIndexValidEquippable
// Size: 0x15(Inherited: 0x0) 
struct FIsCurrentIndexValidEquippable
{
	struct UORCharacterInventory* Inventory;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Valid : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FGameplayTag CallFunc_Array_Get_Item;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_ContainsEquippableItem_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function Ability_EquipNextWeapon_BP.Ability_EquipNextWeapon_BP_C.EvaluateCycleCondition
// Size: 0xC(Inherited: 0x0) 
struct FEvaluateCycleCondition
{
	struct UORCharacterInventory* Inventory;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsCurrentIndexValidEquippable_Valid : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB(0x1)

}; 
