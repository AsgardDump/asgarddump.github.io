#pragma once 
#include <Ability_ChangeEquippedWeapon_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C
// Size: 0x3F5(Inherited: 0x3E0) 
struct UAbility_ChangeEquippedWeapon_C : public UAbility_ChangeEquippedItemBase_BP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3E0(0x8)
	struct FGameplayTag ItemTag;  // 0x3E8(0x8)
	float EquipmentSwapDelay;  // 0x3F0(0x4)
	char pad_1012_1 : 7;  // 0x3F4(0x1)
	bool bHasSwappedEquipment : 1;  // 0x3F4(0x1)

	void GetOwningCharacter(struct AORCharacter*& Character); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.GetOwningCharacter
	void K2_ActivateAbility(); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.K2_ActivateAbility
	void K2_OnEndAbility(bool bWasCancelled); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.K2_OnEndAbility
	void SwapEquipment(); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.SwapEquipment
	void ExecuteUbergraph_Ability_ChangeEquippedWeapon(int32_t EntryPoint); // Function Ability_ChangeEquippedWeapon.Ability_ChangeEquippedWeapon_C.ExecuteUbergraph_Ability_ChangeEquippedWeapon
}; 



