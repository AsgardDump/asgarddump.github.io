#pragma once 
#include <Charge_SC_Structs.h>
 
 
 
// BlueprintGeneratedClass Charge_SC.Charge_SC_C
// Size: 0x50(Inherited: 0x48) 
struct UCharge_SC_C : public UORScriptComponent_Charge
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x48(0x8)

	bool GetIsActive(); // Function Charge_SC.Charge_SC_C.GetIsActive
	void SetIsActive(bool IsActive); // Function Charge_SC.Charge_SC_C.SetIsActive
	void ExecuteUbergraph_Charge_SC(int32_t EntryPoint); // Function Charge_SC.Charge_SC_C.ExecuteUbergraph_Charge_SC
}; 



