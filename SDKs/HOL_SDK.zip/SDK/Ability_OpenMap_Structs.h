#pragma once 
#include "SDK.h" 
 
 
// Function Ability_OpenMap.Ability_OpenMap_C.K2_CanActivateAbility
// Size: 0x71(Inherited: 0x78) 
struct FK2_CanActivateAbility : public FK2_CanActivateAbility
{
	struct FGameplayAbilityActorInfo ActorInfo;  // 0x0(0x48)
	struct FGameplayAbilitySpecHandle Handle;  // 0x48(0x4)
	struct FGameplayTagContainer RelevantTags;  // 0x50(0x20)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)

}; 
// Function Ability_OpenMap.Ability_OpenMap_C.ExecuteUbergraph_Ability_OpenMap
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_Ability_OpenMap
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UPauseMenuPayload_C* CallFunc_SpawnObject_ReturnValue;  // 0x8(0x8)

}; 
