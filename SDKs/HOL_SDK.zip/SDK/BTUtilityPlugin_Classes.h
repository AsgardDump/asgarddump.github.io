#pragma once 
#include <BTUtilityPlugin_Structs.h>
 
 
 
// Class BTUtilityPlugin.BTComposite_Utility
// Size: 0x98(Inherited: 0x90) 
struct UBTComposite_Utility : public UBTCompositeNode
{
	uint8_t  SelectionMethod;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool bShouldTryNextChildOnFailure : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)

}; 



// Class BTUtilityPlugin.BTDecorator_UtilityFunction
// Size: 0x68(Inherited: 0x68) 
struct UBTDecorator_UtilityFunction : public UBTDecorator
{

}; 



// Class BTUtilityPlugin.BTDecorator_UtilityBlackboard
// Size: 0x90(Inherited: 0x68) 
struct UBTDecorator_UtilityBlackboard : public UBTDecorator_UtilityFunction
{
	struct FBlackboardKeySelector UtilityValueKey;  // 0x68(0x28)

}; 



// Class BTUtilityPlugin.BTDecorator_UtilityBlueprintBase
// Size: 0x78(Inherited: 0x68) 
struct UBTDecorator_UtilityBlueprintBase : public UBTDecorator_UtilityFunction
{
	struct AAIController* AIOwner;  // 0x68(0x8)
	struct AActor* ActorOwner;  // 0x70(0x8)

	float CalculateUtility(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTUtilityPlugin.BTDecorator_UtilityBlueprintBase.CalculateUtility
}; 



// Class BTUtilityPlugin.BTDecorator_UtilityConstant
// Size: 0x70(Inherited: 0x68) 
struct UBTDecorator_UtilityConstant : public UBTDecorator_UtilityFunction
{
	float UtilityValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 



// Class BTUtilityPlugin.BTUtilitySelectionMethod
// Size: 0x28(Inherited: 0x28) 
struct UBTUtilitySelectionMethod : public UObject
{

}; 



