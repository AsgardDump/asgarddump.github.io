#pragma once 
#include "SDK.h" 
 
 
// Function AnchorPoint_BP.AnchorPoint_BP_C.ExecuteUbergraph_AnchorPoint_BP
// Size: 0x2D0(Inherited: 0x0) 
struct FExecuteUbergraph_AnchorPoint_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	struct AActor* K2Node_ComponentBoundEvent_SourceActor_2;  // 0x20(0x8)
	int32_t K2Node_ComponentBoundEvent_VolumeIndex_2;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct AActor* K2Node_ComponentBoundEvent_SourceActor;  // 0x30(0x8)
	int32_t K2Node_ComponentBoundEvent_VolumeIndex;  // 0x38(0x4)
	int32_t CallFunc_PlaySound_PlayingID;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_StopSound_Success : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x48(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x50(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x58(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x60(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x6C(0x90)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xFC(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x100(0x4)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x104(0x1)
	char pad_261_1 : 7;  // 0x105(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x105(0x1)
	char pad_262[10];  // 0x106(0xA)
	struct FTransform CallFunc_GetRelativeTransform_ReturnValue;  // 0x110(0x30)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	struct FVector CallFunc_BreakTransform_Location;  // 0x144(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x150(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x15C(0xC)
	struct AORCharacter* K2Node_Event_TetherSource_2;  // 0x168(0x8)
	struct FTransform CallFunc_GetRelativeTransform_ReturnValue_2;  // 0x170(0x30)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x1A0(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x1AC(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x1B8(0xC)
	char pad_452[4];  // 0x1C4(0x4)
	struct AORCharacter* K2Node_Event_TetherSource;  // 0x1C8(0x8)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x1D0(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x1DC(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x1E0(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x1E4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x1E8(0xC)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue_2;  // 0x1F4(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0x200(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x204(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x208(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x20C(0xC)
	char pad_536[8];  // 0x218(0x8)
	struct FTransform CallFunc_GetRelativeTransform_ReturnValue_3;  // 0x220(0x30)
	struct FVector CallFunc_BreakTransform_Location_3;  // 0x250(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_3;  // 0x25C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_3;  // 0x268(0xC)
	struct FVector K2Node_CustomEvent_MoveTarget;  // 0x274(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x280(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x284(0x4)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool K2Node_Event_bEnabled : 1;  // 0x288(0x1)
	char pad_649[3];  // 0x289(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x28C(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x290(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x294(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x298(0x4)
	int32_t Temp_int_Variable;  // 0x29C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x2A0(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x2AC(0xC)
	struct AActor* K2Node_Event_Interactor;  // 0x2B8(0x8)
	struct UORInteractableComponent* K2Node_Event_Component;  // 0x2C0(0x8)
	struct AActor* K2Node_Event_Interactable;  // 0x2C8(0x8)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.InteractionTriggered
// Size: 0x8(Inherited: 0x0) 
struct FInteractionTriggered
{
	struct AActor* Interactable;  // 0x0(0x8)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.SetMoveTarget
// Size: 0xC(Inherited: 0x0) 
struct FSetMoveTarget
{
	struct FVector MoveTarget;  // 0x0(0xC)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.TetherPullStarted
// Size: 0x8(Inherited: 0x0) 
struct FTetherPullStarted
{
	struct AORCharacter* TetherSource;  // 0x0(0x8)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.GetSecondaryEffectsTargets
// Size: 0x10(Inherited: 0x0) 
struct FGetSecondaryEffectsTargets
{
	struct TArray<struct AActor*> ReturnValue;  // 0x0(0x10)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.InteractionTriggeredWithComponent
// Size: 0x10(Inherited: 0x0) 
struct FInteractionTriggeredWithComponent
{
	struct AActor* Interactor;  // 0x0(0x8)
	struct UORInteractableComponent* Component;  // 0x8(0x8)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.SetInteractableState
// Size: 0x1(Inherited: 0x0) 
struct FSetInteractableState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.TetherPullEnded
// Size: 0x8(Inherited: 0x0) 
struct FTetherPullEnded
{
	struct AORCharacter* TetherSource;  // 0x0(0x8)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ProjectileCollision_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
// Size: 0xB4(Inherited: 0x0) 
struct FBndEvt__AnchorPoint_BP_ProjectileCollision_K2Node_ComponentBoundEvent_6_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x90)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_5_ORTriggerVolumeComponentCallback__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FBndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_5_ORTriggerVolumeComponentCallback__DelegateSignature
{
	struct AActor* SourceActor;  // 0x0(0x8)
	int32_t VolumeIndex;  // 0x8(0x4)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.BndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_4_ORTriggerVolumeComponentCallback__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FBndEvt__AnchorPoint_BP_ORTriggerVolume_K2Node_ComponentBoundEvent_4_ORTriggerVolumeComponentCallback__DelegateSignature
{
	struct AActor* SourceActor;  // 0x0(0x8)
	int32_t VolumeIndex;  // 0x8(0x4)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.ModifyDamage
// Size: 0xC4(Inherited: 0x0) 
struct FModifyDamage
{
	struct UObject* Damager;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	float Damage;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA0(0x20)
	float ReturnValue;  // 0xC0(0x4)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.PlaySound
// Size: 0x2C(Inherited: 0x0) 
struct FPlaySound
{
	int32_t PlayingID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FAkExternalSourceInfo> Temp_struct_Variable;  // 0x8(0x10)
	struct FDelegate Temp_delegate_Variable;  // 0x18(0x10)
	int32_t CallFunc_PostAkEvent_ReturnValue;  // 0x28(0x4)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.StopSound
// Size: 0x2(Inherited: 0x0) 
struct FStopSound
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.Set ABPSpeeds
// Size: 0x34(Inherited: 0x0) 
struct FSet ABPSpeeds
{
	struct FVector Location;  // 0x0(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0xC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x18(0xC)
	float CallFunc_BreakVector_X;  // 0x24(0x4)
	float CallFunc_BreakVector_Y;  // 0x28(0x4)
	float CallFunc_BreakVector_Z;  // 0x2C(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x30(0x4)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.GetKillerGameplayEffects
// Size: 0x10(Inherited: 0x0) 
struct FGetKillerGameplayEffects
{
	struct TArray<UGameplayEffect*> ReturnValue;  // 0x0(0x10)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.ShouldBlockDamage
// Size: 0xC1(Inherited: 0x0) 
struct FShouldBlockDamage
{
	struct UObject* Damager;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	float Damage;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA0(0x20)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool ReturnValue : 1;  // 0xC0(0x1)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.ModifyFinalDamage
// Size: 0xC4(Inherited: 0x0) 
struct FModifyFinalDamage
{
	struct UObject* Damager;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x90)
	float Damage;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FGameplayTagContainer DamageTags;  // 0xA0(0x20)
	float ReturnValue;  // 0xC0(0x4)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.HasDied
// Size: 0x1(Inherited: 0x0) 
struct FHasDied
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.GetDamageHandler
// Size: 0x8(Inherited: 0x0) 
struct FGetDamageHandler
{
	struct UORDamageHandlerComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function AnchorPoint_BP.AnchorPoint_BP_C.ShouldBlockInteractionWithActor
// Size: 0x9(Inherited: 0x0) 
struct FShouldBlockInteractionWithActor
{
	struct AActor* Interactor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)

}; 
