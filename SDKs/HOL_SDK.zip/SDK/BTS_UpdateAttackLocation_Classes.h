#pragma once 
#include <BTS_UpdateAttackLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C
// Size: 0x198(Inherited: 0x98) 
struct UBTS_UpdateAttackLocation_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector MoveToLocation;  // 0xA0(0x28)
	struct FBlackboardKeySelector TargetActor;  // 0xC8(0x28)
	struct FBlackboardKeySelector CombatMoveInProgress;  // 0xF0(0x28)
	struct FBlackboardKeySelector AnchorRadius;  // 0x118(0x28)
	struct FBlackboardKeySelector AttractionPointCoverType_Key;  // 0x140(0x28)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool IsQueryRunning : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct UEnvQueryInstanceBlueprintWrapper* RunningEQSQuery;  // 0x170(0x8)
	struct UEnvQuery* MoveToBestAttackPositionQuery;  // 0x178(0x8)
	struct UEnvQuery* InRangeAttackRepositionQuery;  // 0x180(0x8)
	struct AORAICharacter* CachedControlledORAICharacter;  // 0x188(0x8)
	struct AAIController* CachedAIController;  // 0x190(0x8)

	void FindGoodAttractLocationForMove(struct AAIController* OwnerController, struct AORAICharacter* ControlledPawn, bool& FoundLocation, struct FVector& NewLocation); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.FindGoodAttractLocationForMove
	void GetBestEQSQueryForMove(struct AAIController* OwnerController, struct APawn* ControlledPawn, bool& NeedsToRunQuery, struct UEnvQuery*& QueryToRun, struct AORAIHenchmanController_BP_C*& ORProtoController); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.GetBestEQSQueryForMove
	void NeedsNewMoveToLocation(struct AAIController* OwnerController, struct APawn* ControlledPawn, bool& NeedsMove); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsNewMoveToLocation
	void NeedsPositionForPeriodicMove(struct AActor* TargetActor, struct AORAIHenchmanController_BP_C* OwningController, struct APawn* ControlledPawn, bool& NeedsPosition); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsPositionForPeriodicMove
	void NeedsPositionForAttackRanging(struct AActor* TargetActor, struct AORAICharacter* ControlledPawn, bool& NeedsPosition); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.NeedsPositionForAttackRanging
	void ReceiveTickAI(struct AAIController* OwnerController, struct APawn* ControlledPawn, float DeltaSeconds); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ReceiveTickAI
	void EQS_QueryComplete(struct UEnvQueryInstanceBlueprintWrapper* QueryInstance, char EEnvQueryStatus QueryStatus); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.EQS_QueryComplete
	void ReceiveDeactivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ReceiveDeactivationAI
	void ExecuteUbergraph_BTS_UpdateAttackLocation(int32_t EntryPoint); // Function BTS_UpdateAttackLocation.BTS_UpdateAttackLocation_C.ExecuteUbergraph_BTS_UpdateAttackLocation
}; 



