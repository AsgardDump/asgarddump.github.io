#pragma once 
#include <Ability_AIMerkSmgPrimaryFire_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Ability_AIMerkSmgPrimaryFire_BP.Ability_AIMerkSmgPrimaryFire_BP_C
// Size: 0x428(Inherited: 0x428) 
struct UAbility_AIMerkSmgPrimaryFire_BP_C : public UORGameplayAbility_FireItem
{

}; 



