#pragma once 
#include "SDK.h" 
 
 
// Function BP_3DMapVolume.BP_3DMapVolume_C.ExecuteUbergraph_BP_3DMapVolume
// Size: 0x29(Inherited: 0x0) 
struct FExecuteUbergraph_BP_3DMapVolume
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AActor* K2Node_Event_Actor;  // 0x8(0x8)
	struct AORTriggerVolume* K2Node_Event_Volume;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct APlayerCharacter_BP_C* K2Node_DynamicCast_AsPlayer_Character_BP;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_3DMapVolume.BP_3DMapVolume_C.UserConstructionScript
// Size: 0x5(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x0(0x1)
	uint8_t  CallFunc_GetShape_ReturnValue;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_3 : 1;  // 0x4(0x1)

}; 
// Function BP_3DMapVolume.BP_3DMapVolume_C.OnActorEnterMapVolume
// Size: 0x10(Inherited: 0x10) 
struct FOnActorEnterMapVolume : public FOnActorEnterMapVolume
{
	struct AActor* Actor;  // 0x0(0x8)
	struct AORTriggerVolume* Volume;  // 0x8(0x8)

}; 
