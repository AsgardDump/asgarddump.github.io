#pragma once 
#include <BlockReload_GE_Structs.h>
 
 
 
// BlueprintGeneratedClass BlockReload_GE.BlockReload_GE_C
// Size: 0x818(Inherited: 0x818) 
struct UBlockReload_GE_C : public UORGameplayEffect
{

}; 



