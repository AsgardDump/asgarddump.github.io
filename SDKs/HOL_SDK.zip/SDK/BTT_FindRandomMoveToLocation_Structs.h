#pragma once 
#include "SDK.h" 
 
 
// Function BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C.ExecuteUbergraph_BTT_FindRandomMoveToLocation
// Size: 0x31(Inherited: 0x0) 
struct FExecuteUbergraph_BTT_FindRandomMoveToLocation
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x18(0xC)
	struct FVector CallFunc_K2_GetRandomReachablePointInRadius_RandomLocation;  // 0x24(0xC)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_K2_GetRandomReachablePointInRadius_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BTT_FindRandomMoveToLocation.BTT_FindRandomMoveToLocation_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
