#pragma once 
#include <BP_HDProj_OutpostBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDProj_OutpostBase.BP_HDProj_OutpostBase_C
// Size: 0x430(Inherited: 0x430) 
struct ABP_HDProj_OutpostBase_C : public ABP_HDProj_SPDeployableBase_C
{

}; 



