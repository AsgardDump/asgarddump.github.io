#pragma once 
#include "SDK.h" 
 
 
// Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.OnCheckStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnCheckStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.ExecuteUbergraph_WBP_ModifierSetting_CheckBox
// Size: 0x48(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_ModifierSetting_CheckBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool Temp_bool_Variable : 1;  // 0x23(0x1)
	float CallFunc_BreakVector2D_X;  // 0x24(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FText K2Node_Select_Default;  // 0x30(0x18)

}; 
// Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.BndEvt__ModifierCheckBox_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ModifierCheckBox_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.GetSettingText
// Size: 0x18(Inherited: 0x0) 
struct FGetSettingText
{
	struct FText SettingText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.SetSettingText
// Size: 0x18(Inherited: 0x0) 
struct FSetSettingText
{
	struct FText InSettingText;  // 0x0(0x18)

}; 
