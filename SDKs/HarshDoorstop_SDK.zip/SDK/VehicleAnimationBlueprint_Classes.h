#pragma once 
#include <VehicleAnimationBlueprint_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass VehicleAnimationBlueprint.VehicleAnimationBlueprint_C
// Size: 0x3890(Inherited: 0x980) 
struct UVehicleAnimationBlueprint_C : public UVehicleAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x980(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x988(0x30)
	struct FAnimNode_WheelHandler AnimGraphNode_WheelHandler;  // 0x9B8(0xE0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0xA98(0x20)
	struct FAnimNode_MeshSpaceRefPose AnimGraphNode_MeshRefPose;  // 0xAB8(0x10)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_20;  // 0xAC8(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_19;  // 0xBB8(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_18;  // 0xCA8(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_17;  // 0xD98(0xF0)
	char pad_3720[8];  // 0xE88(0x8)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_16;  // 0xE90(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_15;  // 0x1040(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_14;  // 0x11F0(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_13;  // 0x13A0(0x1B0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_16;  // 0x1550(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_15;  // 0x1640(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_14;  // 0x1730(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_13;  // 0x1820(0xF0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_12;  // 0x1910(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_11;  // 0x1AC0(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_10;  // 0x1C70(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_9;  // 0x1E20(0x1B0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_12;  // 0x1FD0(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_11;  // 0x20C0(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_10;  // 0x21B0(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_9;  // 0x22A0(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_8;  // 0x2390(0xF0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_8;  // 0x2480(0x1B0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_7;  // 0x2630(0xF0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_7;  // 0x2720(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_6;  // 0x28D0(0x1B0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_6;  // 0x2A80(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_5;  // 0x2B70(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_4;  // 0x2C60(0xF0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_5;  // 0x2D50(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_4;  // 0x2F00(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_3;  // 0x30B0(0x1B0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_3;  // 0x3260(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_2;  // 0x3350(0xF0)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone;  // 0x3440(0xF0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt_2;  // 0x3530(0x1B0)
	struct FAnimNode_LookAt AnimGraphNode_LookAt;  // 0x36E0(0x1B0)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function VehicleAnimationBlueprint.VehicleAnimationBlueprint_C.AnimGraph
	void ExecuteUbergraph_VehicleAnimationBlueprint(int32_t EntryPoint); // Function VehicleAnimationBlueprint.VehicleAnimationBlueprint_C.ExecuteUbergraph_VehicleAnimationBlueprint
}; 



