#pragma once 
#include "SDK.h" 
 
 
// Function WBP_JoinServer_Header.WBP_JoinServer_Header_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServer_Header.WBP_JoinServer_Header_C.ExecuteUbergraph_WBP_JoinServer_Header
// Size: 0x5A(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_JoinServer_Header
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x8(0x18)
	struct FFServerListingLayoutInfo CallFunc_GetDataTableRowFromName_OutRow;  // 0x20(0x38)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x59(0x1)

}; 
// Function WBP_JoinServer_Header.WBP_JoinServer_Header_C.SetSortBtnIsEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetSortBtnIsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
