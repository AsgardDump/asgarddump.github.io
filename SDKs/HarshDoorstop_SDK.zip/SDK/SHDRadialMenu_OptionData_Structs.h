#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct SHDRadialMenu_OptionData.SHDRadialMenu_OptionData
// Size: 0x28(Inherited: 0x0) 
struct FSHDRadialMenu_OptionData
{
	struct FText Name_12_99AF5ED145774162AF6420BF7284600B;  // 0x0(0x18)
	struct UTexture2D* Icon_7_C4E650D34F88944E1AE759BDB3AE341D;  // 0x18(0x8)
	struct UDataTable* Submenu_11_FFA2C5184995E2E1079DDB864ABB6249;  // 0x20(0x8)

}; 
