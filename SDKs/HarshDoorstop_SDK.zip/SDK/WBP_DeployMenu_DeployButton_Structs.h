#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalGetSpawnTimeRemaining
// Size: 0x30(Inherited: 0x0) 
struct FInternalGetSpawnTimeRemaining
{
	int32_t SpawnSeconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FTimerHandle CallFunc_GetUnFreezeTimerHandle_ReturnValue;  // 0x20(0x8)
	float CallFunc_K2_GetTimerRemainingTimeHandle_ReturnValue;  // 0x28(0x4)
	int32_t CallFunc_Round_ReturnValue;  // 0x2C(0x4)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnClicked__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnClicked__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCloseBtn : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnPressed__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnPressed__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCloseBtn : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnHovered__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnHovered__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCloseBtn : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnReleased__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnReleased__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCloseBtn : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnUnhovered__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnUnhovered__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCloseBtn : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.ExecuteUbergraph_WBP_DeployMenu_DeployButton
// Size: 0x2F6(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_DeployButton
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x8(0x38)
	float K2Node_Event_InDeltaTime;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x48(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FTimerHandle CallFunc_GetUnFreezeTimerHandle_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_K2_IsTimerActiveHandle_ReturnValue : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x6A(0x1)
	char pad_107_1 : 7;  // 0x6B(0x1)
	bool Temp_bool_Variable : 1;  // 0x6B(0x1)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x6D(0x1)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x6E(0x1)
	char pad_111[1];  // 0x6F(0x1)
	struct FButtonStyle K2Node_Select_Default;  // 0x70(0x278)
	int32_t CallFunc_InternalGetSpawnTimeRemaining_SpawnSeconds;  // 0x2E8(0x4)
	char pad_748_1 : 7;  // 0x2EC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2EC(0x1)
	char pad_749[3];  // 0x2ED(0x3)
	int32_t CallFunc_InternalGetSpawnTimeRemaining_SpawnSeconds_2;  // 0x2F0(0x4)
	char pad_756_1 : 7;  // 0x2F4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x2F4(0x1)
	char pad_757_1 : 7;  // 0x2F5(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x2F5(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.UpdateDeployBtnState
// Size: 0x35(Inherited: 0x0) 
struct FUpdateDeployBtnState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPlayerAlive : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bDeploymentQueued : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bSpawnPointSelected : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FTimerHandle CallFunc_GetUnFreezeTimerHandle_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_K2_IsTimerActiveHandle_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_InternalGetSpawnTimeRemaining_SpawnSeconds;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x34(0x1)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalUpdateBtnText
// Size: 0x1A0(Inherited: 0x0) 
struct FInternalUpdateBtnText
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDeploying : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bSpawnPointSelected : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t CallFunc_InternalGetSpawnTimeRemaining_SpawnSeconds;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x10(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x50(0x10)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x60(0x40)
	struct FText CallFunc_Format_ReturnValue;  // 0xA0(0x18)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB9(0x1)
	char pad_186[6];  // 0xBA(0x6)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0xC0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x100(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x110(0x18)
	struct FText K2Node_Select_Default;  // 0x128(0x18)
	struct FText K2Node_Select_Default_2;  // 0x140(0x18)
	struct FText K2Node_Select_Default_3;  // 0x158(0x18)
	struct FText K2Node_Select_Default_4;  // 0x170(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x188(0x18)

}; 
// Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalUpdateBtnStyle
// Size: 0x280(Inherited: 0x0) 
struct FInternalUpdateBtnStyle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FButtonStyle K2Node_Select_Default;  // 0x8(0x278)

}; 
