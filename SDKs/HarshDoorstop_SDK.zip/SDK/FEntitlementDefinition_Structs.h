#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FEntitlementDefinition.FEntitlementDefinition
// Size: 0x10(Inherited: 0x0) 
struct FFEntitlementDefinition
{
	char EEntitlementType AppType_9_59A34CB643EFB5B38A4B959FC285E1FF;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	int64_t AppID_5_6EE051BA41BB4AD74980F6A1D69E9ADC;  // 0x8(0x8)

}; 
