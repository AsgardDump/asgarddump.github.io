#pragma once 
#include "SDK.h" 
 
 
// Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.ExecuteUbergraph_ABP_HDPlayerCharacter_SharedIK
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_HDPlayerCharacter_SharedIK
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.AnimGraph
// Size: 0x20(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink InPose;  // 0x0(0x10)
	struct FPoseLink AnimGraph;  // 0x10(0x10)

}; 
// Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.HandIK
// Size: 0x20(Inherited: 0x0) 
struct FHandIK
{
	struct FPoseLink InLocoPose;  // 0x0(0x10)
	struct FPoseLink HandIK;  // 0x10(0x10)

}; 
// Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.FootIK
// Size: 0x20(Inherited: 0x0) 
struct FFootIK
{
	struct FPoseLink InLocoPose;  // 0x0(0x10)
	struct FPoseLink FootIK;  // 0x10(0x10)

}; 
