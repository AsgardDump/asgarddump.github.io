#pragma once 
#include <BP_ImpactFX_DefaultWeap_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C
// Size: 0x4F8(Inherited: 0x4E8) 
struct ABP_ImpactFX_DefaultWeap_C : public ADFBaseImpactEffect
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4E8(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x4F0(0x8)

	void ReceiveTick(float DeltaSeconds); // Function BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C.ReceiveTick
	void ExecuteUbergraph_BP_ImpactFX_DefaultWeap(int32_t EntryPoint); // Function BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C.ExecuteUbergraph_BP_ImpactFX_DefaultWeap
}; 



