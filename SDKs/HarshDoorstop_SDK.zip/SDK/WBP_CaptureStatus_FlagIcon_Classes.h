#pragma once 
#include <WBP_CaptureStatus_FlagIcon_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C
// Size: 0x718(Inherited: 0x230) 
struct UWBP_CaptureStatus_FlagIcon_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* Bg;  // 0x238(0x8)
	struct UImage* Icon;  // 0x240(0x8)
	struct UImage* IconFrame;  // 0x248(0x8)
	struct FSlateBrush IconFrameNoTeam;  // 0x250(0x88)
	struct FSlateBrush BgNoTeam;  // 0x2D8(0x88)
	struct FSlateBrush IconLocked;  // 0x360(0x88)
	struct FSlateBrush IconFlag;  // 0x3E8(0x88)
	struct FSlateBrush IconFrameEnemy;  // 0x470(0x88)
	float IconOpacityCapturable;  // 0x4F8(0x4)
	float IconOpacityUncapturable;  // 0x4FC(0x4)
	float IconOpacityOffensive;  // 0x500(0x4)
	char pad_1284[4];  // 0x504(0x4)
	struct FSlateBrush IconFrameFriendly;  // 0x508(0x88)
	struct FSlateBrush BgEnemy;  // 0x590(0x88)
	struct FSlateBrush BgFriendly;  // 0x618(0x88)
	struct FSlateColor ColorFriendly;  // 0x6A0(0x28)
	struct FSlateColor ColorEnemy;  // 0x6C8(0x28)
	struct FSlateColor ColorNoTeam;  // 0x6F0(0x28)

	void SetBrushOpacityByCaptureStatus(struct FSlateBrush& BrushToUpdate, bool bLocked, uint8_t  ObjType, struct FSlateBrush& NewBrush); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.SetBrushOpacityByCaptureStatus
	void TintBrushByTeam(struct FSlateBrush& BrushToTint, uint8_t  Team, struct FSlateBrush& NewBrush); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.TintBrushByTeam
	void UpdateBrushesByTeam(bool bLocked, uint8_t  Team, uint8_t  ObjType); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.UpdateBrushesByTeam
	void SetBrushes(struct FSlateBrush& IconFrame, struct FSlateBrush& Bg, struct FSlateBrush& Icon); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.SetBrushes
	void OnUpdateIcon(bool bActive, uint8_t  Team, bool bLocked, uint8_t  ObjType); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.OnUpdateIcon
	void PreConstruct(bool IsDesignTime); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.PreConstruct
	void ExecuteUbergraph_WBP_CaptureStatus_FlagIcon(int32_t EntryPoint); // Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.ExecuteUbergraph_WBP_CaptureStatus_FlagIcon
}; 



