#pragma once 
#include <BP_HDHUDBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDHUDBase.BP_HDHUDBase_C
// Size: 0x494(Inherited: 0x310) 
struct ABP_HDHUDBase_C : public AHDHUD
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool bDrawCrosshair : 1;  // 0x320(0x1)
	char pad_801_1 : 7;  // 0x321(0x1)
	bool bShowCompass : 1;  // 0x321(0x1)
	char pad_802_1 : 7;  // 0x322(0x1)
	bool bShowPlayerStatus : 1;  // 0x322(0x1)
	char pad_803_1 : 7;  // 0x323(0x1)
	bool bShowWeaponStatus : 1;  // 0x323(0x1)
	char pad_804_1 : 7;  // 0x324(0x1)
	bool bShowCaptureStatus : 1;  // 0x324(0x1)
	char pad_805_1 : 7;  // 0x325(0x1)
	bool bShowEquipmentSelect : 1;  // 0x325(0x1)
	char pad_806_1 : 7;  // 0x326(0x1)
	bool bShowWatermark : 1;  // 0x326(0x1)
	char pad_807_1 : 7;  // 0x327(0x1)
	bool bInitialized : 1;  // 0x327(0x1)
	float CrosshairWidth;  // 0x328(0x4)
	float CrosshairHeight;  // 0x32C(0x4)
	UWBP_HUD_C* HUDContainerUWClass;  // 0x330(0x8)
	uint8_t  HUDContainerUWVisibilityOverride;  // 0x338(0x1)
	char pad_825_1 : 7;  // 0x339(0x1)
	bool bHUDWidgetShown : 1;  // 0x339(0x1)
	char pad_826[6];  // 0x33A(0x6)
	struct APawn* LastOwningPawn;  // 0x340(0x8)
	struct ABP_HDPlayerControllerBase_C* OwningHDPC;  // 0x348(0x8)
	struct ABP_HDPlayerCharacterBase_C* OwningHDPawn;  // 0x350(0x8)
	struct ADFBaseItem* OwningPawnEquippedItem;  // 0x358(0x8)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool bDrawNametags : 1;  // 0x360(0x1)
	char pad_865[3];  // 0x361(0x3)
	float DrawNametagDistanceMin;  // 0x364(0x4)
	float DrawNametagDistanceMax;  // 0x368(0x4)
	char pad_876[4];  // 0x36C(0x4)
	struct UWBP_HUD_C* HUDContainerUW;  // 0x370(0x8)
	float DrawDotsDistanceMin;  // 0x378(0x4)
	float DrawDotsDistanceMax;  // 0x37C(0x4)
	struct UFont* NametagFont;  // 0x380(0x8)
	float NametagTextVerticalOffset;  // 0x388(0x4)
	int32_t NametagTextLengthMax;  // 0x38C(0x4)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool bNametagUseTextScaling : 1;  // 0x390(0x1)
	char pad_913[3];  // 0x391(0x3)
	float NametagTextScaleMin;  // 0x394(0x4)
	float NametagTextScaleMax;  // 0x398(0x4)
	char pad_924_1 : 7;  // 0x39C(0x1)
	bool bEnableNametagTextFade : 1;  // 0x39C(0x1)
	char pad_925[3];  // 0x39D(0x3)
	float NametagTextFadeRangeNear;  // 0x3A0(0x4)
	float NametagDotVerticalOffset;  // 0x3A4(0x4)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool bNametagUseDotSymbolScaling : 1;  // 0x3A8(0x1)
	char pad_937[3];  // 0x3A9(0x3)
	float NametagDotScaleMin;  // 0x3AC(0x4)
	float NametagDotScaleMax;  // 0x3B0(0x4)
	char pad_948_1 : 7;  // 0x3B4(0x1)
	bool bEnableNametagDotFade : 1;  // 0x3B4(0x1)
	char pad_949[3];  // 0x3B5(0x3)
	float NametagDotFadeRangeNear;  // 0x3B8(0x4)
	float NametagDotFadeRangeFar;  // 0x3BC(0x4)
	struct FLinearColor NametagTextColorSquad;  // 0x3C0(0x10)
	struct UTexture2D* NametagDotSymbolSquad;  // 0x3D0(0x8)
	struct FLinearColor NametagDotSymbolSquadColor;  // 0x3D8(0x10)
	float NametagDotSymbolSquadWidth;  // 0x3E8(0x4)
	float NametagDotSymbolSquadHeight;  // 0x3EC(0x4)
	struct FLinearColor NametagTextColorOther;  // 0x3F0(0x10)
	struct UTexture2D* NametagDotSymbolOther;  // 0x400(0x8)
	struct FLinearColor NametagDotSymbolOtherColor;  // 0x408(0x10)
	float NametagDotSymbolOtherWidth;  // 0x418(0x4)
	float NametagDotSymbolOtherHeight;  // 0x41C(0x4)
	struct FLinearColor NametagTextColorDefault;  // 0x420(0x10)
	struct UTexture2D* NametagDotSymbolDefault;  // 0x430(0x8)
	struct FLinearColor NametagDotSymbolDefaultColor;  // 0x438(0x10)
	float NametagDotSymbolDefaultWidth;  // 0x448(0x4)
	float NametagDotSymbolDefaultHeight;  // 0x44C(0x4)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool bNametagUseLineTraces : 1;  // 0x450(0x1)
	char pad_1105[3];  // 0x451(0x3)
	struct FVector2D NametagReferenceResolution;  // 0x454(0x8)
	float NametagLineTraceOffsetTop;  // 0x45C(0x4)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool bNametagUseAdditionalLineTraces : 1;  // 0x460(0x1)
	char pad_1121[3];  // 0x461(0x3)
	float NametagAdditionalLineTraceOffsetSides;  // 0x464(0x4)
	float NametagTextFadeRangeFar;  // 0x468(0x4)
	char pad_1132_1 : 7;  // 0x46C(0x1)
	bool bEnableNametagTextFrame : 1;  // 0x46C(0x1)
	char pad_1133[3];  // 0x46D(0x3)
	float NametagTextFrameHorizontalMargin;  // 0x470(0x4)
	float NametagTextFrameHorizontalFade;  // 0x474(0x4)
	float NametagTextFrameVerticalMargin;  // 0x478(0x4)
	float NametagTextFrameVerticalFade;  // 0x47C(0x4)
	char pad_1152_1 : 7;  // 0x480(0x1)
	bool bEnableNametagDotFrame : 1;  // 0x480(0x1)
	char pad_1153[3];  // 0x481(0x3)
	float NametagDotFrameHorizontalMargin;  // 0x484(0x4)
	float NametagDotFrameHorizontalFade;  // 0x488(0x4)
	float NametagDotFrameVerticalMargin;  // 0x48C(0x4)
	float NametagDotFrameVerticalFade;  // 0x490(0x4)

	bool NametagsSingleLinetrace(struct FVector Start, struct FVector End, struct ABP_HDPlayerCharacterBase_C* OtherPlayer); // Function BP_HDHUDBase.BP_HDHUDBase_C.NametagsSingleLinetrace
	void CanDrawNametag(struct ABP_HDPlayerCharacterBase_C* InOtherPawn, float InVerticalOffset, struct FVector InOwnerCameraLocation, bool& bCanDrawNametag, struct FVector2D& NametagScreenPosition); // Function BP_HDHUDBase.BP_HDHUDBase_C.CanDrawNametag
	void DrawNametags(int32_t SizeX, int32_t SizeY); // Function BP_HDHUDBase.BP_HDHUDBase_C.DrawNametags
	void DrawCrosshair(int32_t SizeX, int32_t SizeY); // Function BP_HDHUDBase.BP_HDHUDBase_C.DrawCrosshair
	void IsTextChatHistoryVisible(bool& bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.IsTextChatHistoryVisible
	void SetTextChatHistoryVisibility(bool bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.SetTextChatHistoryVisibility
	void SetMedicHealingEffectVisibility(bool bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.SetMedicHealingEffectVisibility
	void SetAmmoResupplyEffectVisibility(bool bVisible); // Function BP_HDHUDBase.BP_HDHUDBase_C.SetAmmoResupplyEffectVisibility
	void ResetPlayerStatusEffectsUI(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ResetPlayerStatusEffectsUI
	void ClearOwningPawnReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ClearOwningPawnReferences
	void ForceUpdateOwningPawnReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ForceUpdateOwningPawnReferences
	void ClearAllOwningPlayerReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ClearAllOwningPlayerReferences
	void ForceUpdateAllOwningPlayerReferences(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ForceUpdateAllOwningPlayerReferences
	void CleanupDelegatesForHDPawn(struct ABP_HDPlayerCharacterBase_C* PlayerChar); // Function BP_HDHUDBase.BP_HDHUDBase_C.CleanupDelegatesForHDPawn
	void InitOwningHDPawnDelegates(); // Function BP_HDHUDBase.BP_HDHUDBase_C.InitOwningHDPawnDelegates
	void CleanupOwningHDPCDelegates(); // Function BP_HDHUDBase.BP_HDHUDBase_C.CleanupOwningHDPCDelegates
	void InitOwningHDPCDelegates(); // Function BP_HDHUDBase.BP_HDHUDBase_C.InitOwningHDPCDelegates
	void UpdateHUDVisibility(bool bDestroyOnHide); // Function BP_HDHUDBase.BP_HDHUDBase_C.UpdateHUDVisibility
	void HideHUDWidget(bool bDestroyWidgetOnHide); // Function BP_HDHUDBase.BP_HDHUDBase_C.HideHUDWidget
	void ShowHUDWidget(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ShowHUDWidget
	void EquipmentSelectEquippedItem(struct UHDKit* CurrentLoadout, struct AHDBaseWeapon* EquippedItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectEquippedItem
	void EquipmentSelectItemBySlotNum(int32_t SlotNum, bool& bOutNewSelection); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectItemBySlotNum
	void EquipmentGetSelectedItemSlotNum(int32_t& OutSlotNum, bool& bFoundItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentGetSelectedItemSlotNum
	void EquipmentGetSelectedItem(struct AHDBaseWeapon*& OutItemToEquip, bool& bFoundItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentGetSelectedItem
	void EquipmentAddItemsFromLoadout(struct UHDKit* NewLoadout, struct UDFInventoryComponent* PlayerInventory, struct ADFBaseWeapon* EquippedItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentAddItemsFromLoadout
	void EquipmentSelectItem(int32_t ItemIndex); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectItem
	void EquipmentSelectPrevItem(); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectPrevItem
	void EquipmentSelectNextItem(); // Function BP_HDHUDBase.BP_HDHUDBase_C.EquipmentSelectNextItem
	void ToggleWeaponStatusUI(bool bShown); // Function BP_HDHUDBase.BP_HDHUDBase_C.ToggleWeaponStatusUI
	void ToggleEquipmentUI(bool bShown); // Function BP_HDHUDBase.BP_HDHUDBase_C.ToggleEquipmentUI
	void ReceiveDrawHUD(int32_t SizeX, int32_t SizeY); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveDrawHUD
	void ReceiveBeginPlay(); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveBeginPlay
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveEndPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_HDHUDBase.BP_HDHUDBase_C.ReceiveTick
	void OwningPawnUpdated(struct APawn* NewOwningPawn, struct APawn* PrevOwningPawn); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPawnUpdated
	void OwningPawnEquipmentItemChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPawnEquipmentItemChanged
	void OwningPlayerPossessPawn(struct APawn* Pawn); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPlayerPossessPawn
	void OwningPlayerUnpossessPawn(struct APawn* Pawn); // Function BP_HDHUDBase.BP_HDHUDBase_C.OwningPlayerUnpossessPawn
	void ExecuteUbergraph_BP_HDHUDBase(int32_t EntryPoint); // Function BP_HDHUDBase.BP_HDHUDBase_C.ExecuteUbergraph_BP_HDHUDBase
}; 



