#pragma once 
#include <TinkerUI_Structs.h>
 
 
 
// Class TinkerUI.TBButton
// Size: 0x460(Inherited: 0x428) 
struct UTBButton : public UButton
{
	struct FMulticastInlineDelegate OnDoubleClicked;  // 0x428(0x10)
	char pad_1080[16];  // 0x438(0x10)
	char pad_1096_1 : 2;  // 0x448(0x1)
	char bStopDoubleClickPropagation : 1;  // 0x448(0x1)
	char pad_1096_2 : 5;  // 0x448(0x1)
	char pad_1097[24];  // 0x449(0x18)

	void StopDoubleClickPropagation(); // Function TinkerUI.TBButton.StopDoubleClickPropagation
	void SetIsInteractionEnabled(bool bInIsInteractionEnabled); // Function TinkerUI.TBButton.SetIsInteractionEnabled
	void SetIsFocusable(bool bInIsFocusable); // Function TinkerUI.TBButton.SetIsFocusable
	bool IsInteractionEnabled(); // Function TinkerUI.TBButton.IsInteractionEnabled
	bool GetIsFocusable(); // Function TinkerUI.TBButton.GetIsFocusable
}; 



// Class TinkerUI.TBSlider
// Size: 0x508(Inherited: 0x4F8) 
struct UTBSlider : public USlider
{
	struct FLinearColor SliderFgBarColor;  // 0x4F8(0x10)

	void SetSliderFgBarColor(struct FLinearColor InValue); // Function TinkerUI.TBSlider.SetSliderFgBarColor
	void SetMouseUsesStep(bool bInValue); // Function TinkerUI.TBSlider.SetMouseUsesStep
}; 



// Class TinkerUI.TBListView
// Size: 0x378(Inherited: 0x368) 
struct UTBListView : public UListView
{
	struct FMulticastInlineDelegate BP_OnPreviewItemCreated;  // 0x368(0x10)

}; 



// Class TinkerUI.TBSliderWidgetStyle
// Size: 0x370(Inherited: 0x30) 
struct UTBSliderWidgetStyle : public USlateWidgetStyleContainerBase
{
	struct FSliderStyle SliderStyle;  // 0x30(0x340)

}; 



