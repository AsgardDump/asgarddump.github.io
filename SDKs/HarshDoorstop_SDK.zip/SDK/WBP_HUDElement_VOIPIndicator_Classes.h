#pragma once 
#include <WBP_HUDElement_VOIPIndicator_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C
// Size: 0x2C1(Inherited: 0x280) 
struct UWBP_HUDElement_VOIPIndicator_C : public UHDVoipIndicatorWidgetBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UWBP_VOIPOwnerChatIndicator_C* CommandChatIndicator;  // 0x288(0x8)
	struct UWBP_VOIPOwnerChatIndicator_C* LocalChatIndicator;  // 0x290(0x8)
	struct UWBP_VOIPOwnerChatIndicator_C* SquadChatIndicator;  // 0x298(0x8)
	struct UVerticalBox* TalkerListVBox;  // 0x2A0(0x8)
	int32_t NumFakeOutputListings;  // 0x2A8(0x4)
	int32_t MaxTalkerListings;  // 0x2AC(0x4)
	struct FMargin TalkerListingPadding;  // 0x2B0(0x10)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool bTalkerListingTintClassIconOnly : 1;  // 0x2C0(0x1)

	void ContainsTalkerListing(struct UHDVoiceChatMsgInfo* PlayerMsgInfo, bool& bMatchFound); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.ContainsTalkerListing
	void FindTalkerListing(struct UHDVoiceChatMsgInfo* PlayerMsgInfo, bool& bListingFound, struct UWBP_HUDElement_VOIPIndicator_OutputListing_C*& TalkerListing); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.FindTalkerListing
	void PlayerStoppedTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PlayerStoppedTalking
	void PlayerStartedTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PlayerStartedTalking
	void OnPlayerStartTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnPlayerStartTalking
	void OnPlayerStopTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnPlayerStopTalking
	void OnOwningPlayerStartTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnOwningPlayerStartTalking
	void OnOwningPlayerStopTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnOwningPlayerStopTalking
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PreConstruct
	void ExecuteUbergraph_WBP_HUDElement_VOIPIndicator(int32_t EntryPoint); // Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.ExecuteUbergraph_WBP_HUDElement_VOIPIndicator
}; 



