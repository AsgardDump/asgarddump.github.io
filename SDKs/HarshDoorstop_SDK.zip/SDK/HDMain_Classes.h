#pragma once 
#include <HDMain_Structs.h>
 
 
 
// Class HDMain.HDGameInstance
// Size: 0x2D8(Inherited: 0x2D0) 
struct UHDGameInstance : public UTBGameInstance
{
	struct UHDScoreboardBase* ScoreboardMenu;  // 0x2D0(0x8)

	void UnloadScoreboardMenu(); // Function HDMain.HDGameInstance.UnloadScoreboardMenu
	bool OwnsAppBP(int64_t AppID); // Function HDMain.HDGameInstance.OwnsAppBP
	void LoadScoreboardMenu(); // Function HDMain.HDGameInstance.LoadScoreboardMenu
	bool HasModsLoaded(); // Function HDMain.HDGameInstance.HasModsLoaded
	bool HasDLCBP(int64_t DLCAppID); // Function HDMain.HDGameInstance.HasDLCBP
}; 



// Class HDMain.DeployMenu_ClassSelectionListing
// Size: 0x230(Inherited: 0x230) 
struct UDeployMenu_ClassSelectionListing : public UUserWidget
{

}; 



// Class HDMain.HDNavigationSystemConfig
// Size: 0x60(Inherited: 0x60) 
struct UHDNavigationSystemConfig : public UDFNavigationSystemConfig
{

}; 



// Class HDMain.HDHUD
// Size: 0x310(Inherited: 0x310) 
struct AHDHUD : public AHUD
{

}; 



// Class HDMain.DeployMenu
// Size: 0x238(Inherited: 0x238) 
struct UDeployMenu : public UDFBaseMenu
{

}; 



// Class HDMain.DeployMenu_ClassSelectionPanel
// Size: 0x230(Inherited: 0x230) 
struct UDeployMenu_ClassSelectionPanel : public UUserWidget
{

}; 



// Class HDMain.HDTeamDefinition
// Size: 0x68(Inherited: 0x58) 
struct UHDTeamDefinition : public UDFTeamDefinition
{
	int32_t StartingTickets;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct UDFCommChannelDefinition* CommChannelDefinition;  // 0x60(0x8)

}; 



// Class HDMain.HDCheatManager
// Size: 0x80(Inherited: 0x78) 
struct UHDCheatManager : public UDFCheatManager
{
	char pad_120[8];  // 0x78(0x8)

	void ToggleIdleSway(); // Function HDMain.HDCheatManager.ToggleIdleSway
	void ToggleFreeAimADS(); // Function HDMain.HDCheatManager.ToggleFreeAimADS
	void ToggleFreeAim(); // Function HDMain.HDCheatManager.ToggleFreeAim
	void SpawnVehicle(); // Function HDMain.HDCheatManager.SpawnVehicle
	void SetMaxFreeAimYawADS(float NewYaw); // Function HDMain.HDCheatManager.SetMaxFreeAimYawADS
	void SetMaxFreeAimYaw(float NewYaw); // Function HDMain.HDCheatManager.SetMaxFreeAimYaw
	void SetMaxFreeAimPitchADS(float NewPitch); // Function HDMain.HDCheatManager.SetMaxFreeAimPitchADS
	void SetMaxFreeAimPitch(float NewPitch); // Function HDMain.HDCheatManager.SetMaxFreeAimPitch
	void SetFreeAimReturnToCenterInterpSpeed(float NewInterpSpeed); // Function HDMain.HDCheatManager.SetFreeAimReturnToCenterInterpSpeed
	void SetFreeAimDeadzoneCameraSpeedFactor(float NewSpeedFactor); // Function HDMain.HDCheatManager.SetFreeAimDeadzoneCameraSpeedFactor
}; 



// Class HDMain.HDKitPrerequisite_SquadSizeLimit
// Size: 0x48(Inherited: 0x40) 
struct UHDKitPrerequisite_SquadSizeLimit : public UHDKitPrerequisiteBase
{
	int32_t MaxSquadCount;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 



// Class HDMain.DeployMenu_SpawnMinimap
// Size: 0x298(Inherited: 0x298) 
struct UDeployMenu_SpawnMinimap : public UDFMinimap
{

}; 



// Class HDMain.HDKit
// Size: 0xB8(Inherited: 0x40) 
struct UHDKit : public UDFLoadout
{
	struct TArray<struct FHDItemEntry> ItemEntries;  // 0x40(0x10)
	int32_t PrimaryItemSlotNum;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	AHDBasePickup_Kit* KitDropPrefabClass;  // 0x58(0x8)
	struct TArray<struct UHDKitPrerequisiteBase*> KitRequirements;  // 0x60(0x10)
	struct TArray<struct FDataTableRowHandle> CharacterVariations;  // 0x70(0x10)
	char bSquadLeaderKit : 1;  // 0x80(0x1)
	char bAllowsRallyPointDeployment : 1;  // 0x80(0x1)
	char pad_128_1 : 6;  // 0x80(0x1)
	char pad_129[24];  // 0x81(0x18)
	struct FText KitDisplayName;  // 0x98(0x18)
	struct UTexture2D* KitDisplaySymbol;  // 0xB0(0x8)

	struct FDFCharacterVariationDataHandle RandomCharacterVariationDataFromKit(); // Function HDMain.HDKit.RandomCharacterVariationDataFromKit
	bool PlayerCanStartWithKit(struct AController* Player, struct FText& OutKitDenialReason); // Function HDMain.HDKit.PlayerCanStartWithKit
	bool HasKitRequirements(); // Function HDMain.HDKit.HasKitRequirements
	bool GetPrimaryItemEntryDisplayIcon(struct UTexture2D*& OutDisplayIcon); // Function HDMain.HDKit.GetPrimaryItemEntryDisplayIcon
	bool GetPrimaryItemEntry(struct FHDItemEntry& OutPrimaryEntry); // Function HDMain.HDKit.GetPrimaryItemEntry
	int32_t GetPlayersUsingKit(struct UObject* WorldContextObject, struct TArray<struct AHDPlayerState*>& OutPSArray); // Function HDMain.HDKit.GetPlayersUsingKit
	int32_t GetNumPlayersUsingKit(struct UObject* WorldContextObject); // Function HDMain.HDKit.GetNumPlayersUsingKit
	bool GetItemEntryDisplayIcon(struct FHDItemEntry& ItemEntry, struct UTexture2D*& OutDisplayIcon); // Function HDMain.HDKit.GetItemEntryDisplayIcon
	bool GetItemEntryDisplayEquipmentSymbol(struct FHDItemEntry& ItemEntry, struct UTexture2D*& OutDisplayEquipmentSymbol); // Function HDMain.HDKit.GetItemEntryDisplayEquipmentSymbol
	bool GetItemEntryBySlotNum(int32_t SlotNum, struct FHDItemEntry& OutEntry); // Function HDMain.HDKit.GetItemEntryBySlotNum
}; 



// Class HDMain.HDAIHandlerBase
// Size: 0x50(Inherited: 0x28) 
struct UHDAIHandlerBase : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct AHDAIController* Controller;  // 0x30(0x8)
	struct UHDGOAPComponent* GOAPComponent;  // 0x38(0x8)
	char pad_64[8];  // 0x40(0x8)
	struct UHDAIHandlerBase* HandlerDuplicate;  // 0x48(0x8)

}; 



// Class HDMain.HDGOAPAct_LoadWeapon
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPAct_LoadWeapon : public UHDGOAPActionBase
{

}; 



// Class HDMain.HDGameSession
// Size: 0x278(Inherited: 0x270) 
struct AHDGameSession : public ADFGameSession
{
	char pad_624_1 : 7;  // 0x270(0x1)
	bool bSupportersOnlyWhitelist : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)

}; 



// Class HDMain.HDWeaponScopeComponent
// Size: 0x1F0(Inherited: 0x1F0) 
struct UHDWeaponScopeComponent : public USceneComponent
{

}; 



// Class HDMain.DeployMenu_SpawnMapView
// Size: 0x230(Inherited: 0x230) 
struct UDeployMenu_SpawnMapView : public UUserWidget
{

}; 



// Class HDMain.DeployMenu_PlatoonSquadListBase
// Size: 0x250(Inherited: 0x230) 
struct UDeployMenu_PlatoonSquadListBase : public UUserWidget
{
	struct UPlatoonListEntry* PlatoonData;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool bSortSquads : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct TArray<struct USquadListEntry*> CurrentSquads;  // 0x240(0x10)

	void SquadPreRemoveFromPlatoon(struct AHDPlatoonState* SourcePlatoon, struct AHDSquadState* SquadToBeRemoved); // Function HDMain.DeployMenu_PlatoonSquadListBase.SquadPreRemoveFromPlatoon
	void SquadAddedToPlatoon(struct AHDPlatoonState* SourcePlatoon, struct AHDSquadState* NewSquad); // Function HDMain.DeployMenu_PlatoonSquadListBase.SquadAddedToPlatoon
	void SetupPlatoon(struct UPlatoonListEntry* InPlatoonData); // Function HDMain.DeployMenu_PlatoonSquadListBase.SetupPlatoon
	void RepopulatePlatoon(); // Function HDMain.DeployMenu_PlatoonSquadListBase.RepopulatePlatoon
	void OnPlatoonSet(); // Function HDMain.DeployMenu_PlatoonSquadListBase.OnPlatoonSet
	struct AHDPlatoonState* GetPlatoonStateFromData(); // Function HDMain.DeployMenu_PlatoonSquadListBase.GetPlatoonStateFromData
	void GenerateSquad(struct USquadListEntry* SquadData); // Function HDMain.DeployMenu_PlatoonSquadListBase.GenerateSquad
	void DeconstructSquad(struct USquadListEntry* RemovedSquadData, int32_t RemovedSquadIdx); // Function HDMain.DeployMenu_PlatoonSquadListBase.DeconstructSquad
}; 



// Class HDMain.HDGOAPAct_MoveToLocation
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPAct_MoveToLocation : public UHDGOAPActionBase
{

}; 



// Class HDMain.SquadMemberInfo
// Size: 0x50(Inherited: 0x28) 
struct USquadMemberInfo : public UObject
{
	char TeamId;  // 0x28(0x1)
	uint8_t  Team;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct AHDTeamState* TeamState;  // 0x30(0x8)
	struct UPlatoonListEntry* ParentPlatoonData;  // 0x38(0x8)
	struct USquadListEntry* ParentSquadData;  // 0x40(0x8)
	struct AHDPlayerState* PlayerState;  // 0x48(0x8)

	struct AHDSquadState* GetParentSquadState(); // Function HDMain.SquadMemberInfo.GetParentSquadState
	struct AHDPlatoonState* GetParentPlatoonState(); // Function HDMain.SquadMemberInfo.GetParentPlatoonState
}; 



// Class HDMain.DeployMenu_SquadListBase
// Size: 0x260(Inherited: 0x230) 
struct UDeployMenu_SquadListBase : public UUserWidget
{
	struct USquadListEntry* SquadData;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool bSortSquadMembers : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct TArray<struct USquadMemberInfo*> CurrentSquadMembers;  // 0x240(0x10)
	struct TArray<struct USquadMemberInfo*> MemberEntryWidgetsPendingRemoval;  // 0x250(0x10)

	void SquadNameChanged(struct AHDSquadState* SourceSquad, struct FText& NewName, struct FText& PrevName); // Function HDMain.DeployMenu_SquadListBase.SquadNameChanged
	void SquadLockStateUpdated(struct AHDSquadState* SourceSquad, bool bNewLocked); // Function HDMain.DeployMenu_SquadListBase.SquadLockStateUpdated
	void SquadLeaderChanged(struct AHDSquadState* SourceSquad, struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function HDMain.DeployMenu_SquadListBase.SquadLeaderChanged
	void SetupSquad(struct USquadListEntry* InSquadData); // Function HDMain.DeployMenu_SquadListBase.SetupSquad
	void RepopulateSquad(); // Function HDMain.DeployMenu_SquadListBase.RepopulateSquad
	void OnSquadSet(); // Function HDMain.DeployMenu_SquadListBase.OnSquadSet
	void OnSquadNameUpdated(struct FText& NewSquadName, struct FText& PreviousSquadName); // Function HDMain.DeployMenu_SquadListBase.OnSquadNameUpdated
	void OnSquadLockStateUpdated(bool bNewLockedState); // Function HDMain.DeployMenu_SquadListBase.OnSquadLockStateUpdated
	void OnSquadLeaderUpdated(struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function HDMain.DeployMenu_SquadListBase.OnSquadLeaderUpdated
	void OnListRefresh(); // Function HDMain.DeployMenu_SquadListBase.OnListRefresh
	void MemberSquadInfoUpdated(struct AHDSquadState* SourceSquad, struct AHDPlayerState* MemberPS, struct FHDSquadAssignmentInfo& MemberSQInfo); // Function HDMain.DeployMenu_SquadListBase.MemberSquadInfoUpdated
	void MemberPreRemoveFromSquad(struct AHDSquadState* SourceSquad, struct AHDPlayerState* MemberPSToBeRemoved); // Function HDMain.DeployMenu_SquadListBase.MemberPreRemoveFromSquad
	void MemberAddedToSquad(struct AHDSquadState* SourceSquad, struct AHDPlayerState* NewMemberPS); // Function HDMain.DeployMenu_SquadListBase.MemberAddedToSquad
	struct AHDSquadState* GetSquadStateFromData(); // Function HDMain.DeployMenu_SquadListBase.GetSquadStateFromData
	struct AHDPlatoonState* GetParentPlatoonStateFromData(); // Function HDMain.DeployMenu_SquadListBase.GetParentPlatoonStateFromData
	void GenerateSquadMember(struct USquadMemberInfo* MemberData); // Function HDMain.DeployMenu_SquadListBase.GenerateSquadMember
	void DeconstructSquadMember(struct USquadMemberInfo* RemovedMemberData); // Function HDMain.DeployMenu_SquadListBase.DeconstructSquadMember
}; 



// Class HDMain.HDOptionsMenu
// Size: 0x238(Inherited: 0x238) 
struct UHDOptionsMenu : public UDFBaseMenu
{

}; 



// Class HDMain.HDAINavigationHandler
// Size: 0x150(Inherited: 0x50) 
struct UHDAINavigationHandler : public UHDAIHandlerBase
{
	struct FMulticastInlineDelegate OnMoveToLocationFailed;  // 0x50(0x10)
	struct UNavigationSystemV1* NavSystem;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bMoving : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	struct FVector DesiredLocation;  // 0x6C(0xC)
	char pad_120[16];  // 0x78(0x10)
	int32_t TargetNavPointIndex;  // 0x88(0x4)
	struct FVector TargetNavPoint;  // 0x8C(0xC)
	float AcceptanceRadius;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool bRandomizeNavPoints : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	float NavPointRandomizationRadius;  // 0xA0(0x4)
	float NavPointRandomizationOffset;  // 0xA4(0x4)
	float StuckCheckTime;  // 0xA8(0x4)
	float StuckCheckInterval;  // 0xAC(0x4)
	float StuckCheckDistance;  // 0xB0(0x4)
	struct FVector StuckCheckLastLocation;  // 0xB4(0xC)
	char bEnableBoidsSteering : 1;  // 0xC0(0x1)
	char pad_192_1 : 7;  // 0xC0(0x1)
	char pad_193[4];  // 0xC1(0x4)
	float SteeringMass;  // 0xC4(0x4)
	float SteeringMaxForce;  // 0xC8(0x4)
	struct FVector SteeringVector;  // 0xCC(0xC)
	float SteeringMovementSpeedModifier;  // 0xD8(0x4)
	float FollowPathAcceptanceRadius;  // 0xDC(0x4)
	float ArrivalSlowDownRadius;  // 0xE0(0x4)
	struct FVector FollowPathVector;  // 0xE4(0xC)
	float SteeringNeighborhoodRadius;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct TArray<struct AActor*> SteeringNeighborhood;  // 0xF8(0x10)
	float SeparationStrength;  // 0x108(0x4)
	float InternalSeparationStrength;  // 0x10C(0x4)
	float CohesionStrength;  // 0x110(0x4)
	struct FVector SeparationVector;  // 0x114(0xC)
	struct FVector CohesionVector;  // 0x120(0xC)
	float ObstacleAvoidanceTraceLength;  // 0x12C(0x4)
	float ObstacleAvoidanceStrength;  // 0x130(0x4)
	struct FVector ObstacleAvoidanceVector;  // 0x134(0xC)
	char bEnableRVOAvoidance : 1;  // 0x140(0x1)
	char pad_320_1 : 7;  // 0x140(0x1)
	char pad_321[4];  // 0x141(0x4)
	float RVOAvoidanceConsiderationRadius;  // 0x144(0x4)
	float RVOAvoidanceWeight;  // 0x148(0x4)
	char pad_332[4];  // 0x14C(0x4)

	void SetupRVOAvoidance(); // Function HDMain.HDAINavigationHandler.SetupRVOAvoidance
	void SetupNextTargetNavPoint(); // Function HDMain.HDAINavigationHandler.SetupNextTargetNavPoint
	void SetDesiredLocation(struct FVector& InDesiredLocation); // Function HDMain.HDAINavigationHandler.SetDesiredLocation
	void MoveToLocationFailed(); // Function HDMain.HDAINavigationHandler.MoveToLocationFailed
	bool MakePathToDesiredLocation(); // Function HDMain.HDAINavigationHandler.MakePathToDesiredLocation
	bool IsPawnAtDestination(); // Function HDMain.HDAINavigationHandler.IsPawnAtDestination
	bool IsNavigationPossible(); // Function HDMain.HDAINavigationHandler.IsNavigationPossible
	bool IsNavDataValidForAllControlPoints(); // Function HDMain.HDAINavigationHandler.IsNavDataValidForAllControlPoints
	void FixVectorValuesNaN(struct FVector& InVector, bool bRandomize); // Function HDMain.HDAINavigationHandler.FixVectorValuesNaN
	bool FindNewControlPointNavLocation(struct AHDBaseCapturePoint* CP); // Function HDMain.HDAINavigationHandler.FindNewControlPointNavLocation
	bool FindNavLocationInsideControlPoint(struct AHDBaseCapturePoint* CP, struct FVector& OutNavLoc); // Function HDMain.HDAINavigationHandler.FindNavLocationInsideControlPoint
	bool CheckPawnStuckStatus(); // Function HDMain.HDAINavigationHandler.CheckPawnStuckStatus
	struct FVector CalcSeparationVector(); // Function HDMain.HDAINavigationHandler.CalcSeparationVector
	struct FVector CalcObstacleAvoidanceVector(); // Function HDMain.HDAINavigationHandler.CalcObstacleAvoidanceVector
	struct FVector CalcCohesionVector(); // Function HDMain.HDAINavigationHandler.CalcCohesionVector
}; 



// Class HDMain.DeployMenu_SquadMemberListingBase
// Size: 0x238(Inherited: 0x230) 
struct UDeployMenu_SquadMemberListingBase : public UUserWidget
{
	struct USquadMemberInfo* MemberData;  // 0x230(0x8)

	void SetupMember(struct USquadMemberInfo* InMemberData); // Function HDMain.DeployMenu_SquadMemberListingBase.SetupMember
	void OnMemberSet(); // Function HDMain.DeployMenu_SquadMemberListingBase.OnMemberSet
	void OnMemberPlayerNameUpdated(struct FString NewPlayerName); // Function HDMain.DeployMenu_SquadMemberListingBase.OnMemberPlayerNameUpdated
	void MemberPlayerNameChanged(struct APlayerState* PlayerState, struct FString NewPlayerName); // Function HDMain.DeployMenu_SquadMemberListingBase.MemberPlayerNameChanged
	struct AHDPlayerState* GetPlayerStateFromData(); // Function HDMain.DeployMenu_SquadMemberListingBase.GetPlayerStateFromData
	struct AHDSquadState* GetParentSquadStateFromData(); // Function HDMain.DeployMenu_SquadMemberListingBase.GetParentSquadStateFromData
	struct AHDPlatoonState* GetParentPlatoonStateFromData(); // Function HDMain.DeployMenu_SquadMemberListingBase.GetParentPlatoonStateFromData
}; 



// Class HDMain.DeployMenu_SquadSelectionWidgetBase
// Size: 0x250(Inherited: 0x230) 
struct UDeployMenu_SquadSelectionWidgetBase : public UUserWidget
{
	struct AHDTeamState* PlatoonTeamState;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool bSortPlatoons : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct TArray<struct UPlatoonListEntry*> CurrentPlatoons;  // 0x240(0x10)

	void SetupSquadSelection(struct AHDTeamState* InPlatoonTeamState); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.SetupSquadSelection
	void RepopulateSquadSelection(); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.RepopulateSquadSelection
	void PlatoonPreRemoveFromTeam(struct AHDTeamState* SourceTeam, struct AHDPlatoonState* PlatoonToBeRemoved); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.PlatoonPreRemoveFromTeam
	void PlatoonAddedToTeam(struct AHDTeamState* SourceTeam, struct AHDPlatoonState* NewPlatoon); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.PlatoonAddedToTeam
	void OnSquadSelectionSet(); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.OnSquadSelectionSet
	void GeneratePlatoon(struct UPlatoonListEntry* PlatoonData); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.GeneratePlatoon
	void DeconstructPlatoon(struct UPlatoonListEntry* RemovedPlatoonData, int32_t RemovedPlatoonIdx); // Function HDMain.DeployMenu_SquadSelectionWidgetBase.DeconstructPlatoon
}; 



// Class HDMain.HDUIUserWidget
// Size: 0x238(Inherited: 0x230) 
struct UHDUIUserWidget : public UUserWidget
{
	char bListenForPlayerCharacterEvents : 1;  // 0x230(0x1)
	char pad_560_1 : 7;  // 0x230(0x1)
	char pad_561[8];  // 0x231(0x8)

	void OwnerUnpossessPawn(struct APawn* UnpossessedPawn); // Function HDMain.HDUIUserWidget.OwnerUnpossessPawn
	void OwnerPossessPawn(struct APawn* NewPawn); // Function HDMain.HDUIUserWidget.OwnerPossessPawn
	void OwnerEquippedItemChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function HDMain.HDUIUserWidget.OwnerEquippedItemChanged
	void OwnerDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function HDMain.HDUIUserWidget.OwnerDeath
	struct AHUD* GetOwningPlayerHUD(); // Function HDMain.HDUIUserWidget.GetOwningPlayerHUD
	struct AHDHUD* GetOwningHDPlayerHUD(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayerHUD
	struct UDFCharacterMovementComponent* GetOwningHDPlayerCharacterMovement(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayerCharacterMovement
	struct AHDPlayerCharacter* GetOwningHDPlayerCharacter(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayerCharacter
	struct AHDPlayerController* GetOwningHDPlayer(); // Function HDMain.HDUIUserWidget.GetOwningHDPlayer
	struct AHDBaseWeapon* GetOwnerEquippedWeapon(); // Function HDMain.HDUIUserWidget.GetOwnerEquippedWeapon
	void BPOwnerWeaponChanged(struct AHDBaseWeapon* NewWeap, struct AHDBaseWeapon* PrevWeap); // Function HDMain.HDUIUserWidget.BPOwnerWeaponChanged
	void BPOwnerUnpossessPawn(struct APawn* UnpossessedPawn); // Function HDMain.HDUIUserWidget.BPOwnerUnpossessPawn
	void BPOwnerPossessPawn(struct APawn* NewPawn); // Function HDMain.HDUIUserWidget.BPOwnerPossessPawn
	void BPOwnerDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function HDMain.HDUIUserWidget.BPOwnerDeath
	void BPInitializeForOwnerWeapon(struct AHDBaseWeapon* OwnerWeap); // Function HDMain.HDUIUserWidget.BPInitializeForOwnerWeapon
	void BPInitializeForOwnerPlayerCharacter(struct AHDPlayerCharacter* OwnerPlyChar); // Function HDMain.HDUIUserWidget.BPInitializeForOwnerPlayerCharacter
	void BPDeinitializeFromOwnerWeapon(struct AHDBaseWeapon* OwnerWeap); // Function HDMain.HDUIUserWidget.BPDeinitializeFromOwnerWeapon
	void BPDeinitializeFromOwnerPlayerCharacter(struct AHDPlayerCharacter* OwnerPlyChar); // Function HDMain.HDUIUserWidget.BPDeinitializeFromOwnerPlayerCharacter
}; 



// Class HDMain.HDAIAimingHandler
// Size: 0x138(Inherited: 0x50) 
struct UHDAIAimingHandler : public UHDAIHandlerBase
{
	float RefreshTargetRate;  // 0x50(0x4)
	float NewTargetStimulusStrengthThreshold;  // 0x54(0x4)
	struct FMulticastInlineDelegate OnContactStateChanged;  // 0x58(0x10)
	struct FVector CurrentTargetLocation;  // 0x68(0xC)
	float CurrentTargetStimulusStrength;  // 0x74(0x4)
	float CurrentTargetStimulusAge;  // 0x78(0x4)
	float RefreshTargetTime;  // 0x7C(0x4)
	struct FVector AimingTargetPoint;  // 0x80(0xC)
	struct FVector ProjectileAimingTossVelocity;  // 0x8C(0xC)
	struct UHDAICombatHandler* CombatHandler;  // 0x98(0x8)
	struct UHDAINavigationHandler* NavigationHandler;  // 0xA0(0x8)
	struct UHDAIBehaviorHandler* BehaviorHandler;  // 0xA8(0x8)
	struct UHDAIVocalHandler* VocalHandler;  // 0xB0(0x8)
	struct UAIPerceptionComponent* PerceptionComponent;  // 0xB8(0x8)
	float NextFocalPointTime;  // 0xC0(0x4)
	float NextFocalPointIntervalMin;  // 0xC4(0x4)
	float NextFocalPointIntervalMax;  // 0xC8(0x4)
	float NextFocalPointAngleMin;  // 0xCC(0x4)
	float NextFocalPointAngleMax;  // 0xD0(0x4)
	float NextFocalPointDistanceMin;  // 0xD4(0x4)
	float NextFocalPointDistanceMax;  // 0xD8(0x4)
	struct FRotator RotationRate;  // 0xDC(0xC)
	struct FRotator DefaultRotationRate;  // 0xE8(0xC)
	float WeaponAimingDistance;  // 0xF4(0x4)
	float WeaponMinConeOfFireAngleDegrees;  // 0xF8(0x4)
	float WeaponMaxConeOfFireAngleDegrees;  // 0xFC(0x4)
	struct FVector NoEnemyFocalPoint;  // 0x100(0xC)
	char pad_268_1 : 7;  // 0x10C(0x1)
	bool bEnableNoEnemyLookAround : 1;  // 0x10C(0x1)
	char bAimingAtTarget : 1;  // 0x10D(0x1)
	char pad_269_1 : 7;  // 0x10D(0x1)
	char pad_270[3];  // 0x10E(0x3)
	float ProjectileAimingTime;  // 0x110(0x4)
	float ProjectileAimingRate;  // 0x114(0x4)
	float ProjectileAimingRateVariation;  // 0x118(0x4)
	float AimingAtTargetAngleThreshold;  // 0x11C(0x4)
	float AimingSpeedAngleNear;  // 0x120(0x4)
	float AimingSpeedAngleFar;  // 0x124(0x4)
	float AimingSpeed;  // 0x128(0x4)
	float AimingSpeedNear;  // 0x12C(0x4)
	float AimingSpeedFar;  // 0x130(0x4)
	float AimingSpeedMultiplier;  // 0x134(0x4)

	bool SuggestProjectileVelocity(struct FVector& TossVelocity, struct FVector StartLocation, struct FVector EndLocation, float TossSpeed); // Function HDMain.HDAIAimingHandler.SuggestProjectileVelocity
	bool ShouldChangeNoEnemyFocalPoint(); // Function HDMain.HDAIAimingHandler.ShouldChangeNoEnemyFocalPoint
	void SetEnableNoEnemyLookAround(bool bInEnableNoEnemyLookAround); // Function HDMain.HDAIAimingHandler.SetEnableNoEnemyLookAround
	void MakeNoEnemyFocalPoint(); // Function HDMain.HDAIAimingHandler.MakeNoEnemyFocalPoint
	bool IsCandidateTarget(struct AActor* ActorToCheck); // Function HDMain.HDAIAimingHandler.IsCandidateTarget
	bool IsAimingAtTarget(); // Function HDMain.HDAIAimingHandler.IsAimingAtTarget
	struct FVector GetNoEnemyFocalPoint(); // Function HDMain.HDAIAimingHandler.GetNoEnemyFocalPoint
	bool GetIsNewTargetMoreRelevant(float OldTargetStrength, float NewTargetStrength); // Function HDMain.HDAIAimingHandler.GetIsNewTargetMoreRelevant
	bool GetEnableNoEnemyLookAround(); // Function HDMain.HDAIAimingHandler.GetEnableNoEnemyLookAround
	void GetActorStimulusData(struct AActor* InActor, struct FVector& OutLocation, float& OutStrength, float& OutAge); // Function HDMain.HDAIAimingHandler.GetActorStimulusData
	void EstablishNewTargetFromPerception(UAISense*& SenseToUse); // Function HDMain.HDAIAimingHandler.EstablishNewTargetFromPerception
	bool CheckForTarget(struct AActor* TargetActor, struct FAIStimulus Stimulus); // Function HDMain.HDAIAimingHandler.CheckForTarget
	void CalcAimingDirection(); // Function HDMain.HDAIAimingHandler.CalcAimingDirection
	void AimAtCurrentTarget(); // Function HDMain.HDAIAimingHandler.AimAtCurrentTarget
}; 



// Class HDMain.HDKitPrerequisite_MinSquadMembers
// Size: 0x48(Inherited: 0x40) 
struct UHDKitPrerequisite_MinSquadMembers : public UHDKitPrerequisiteBase
{
	int32_t MinSquadMembers;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 



// Class HDMain.HDAIBehaviorHandler
// Size: 0x140(Inherited: 0x50) 
struct UHDAIBehaviorHandler : public UHDAIHandlerBase
{
	struct FMulticastInlineDelegate OnSafeBehaviorStart;  // 0x50(0x10)
	struct FMulticastInlineDelegate OnAwareBehaviorStart;  // 0x60(0x10)
	struct FMulticastInlineDelegate OnCombatBehaviorStart;  // 0x70(0x10)
	struct FMulticastInlineDelegate OnDangerBehaviorStart;  // 0x80(0x10)
	uint8_t  CurrentThreatLevel;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct UHDAINavigationHandler* NavigationHandler;  // 0x98(0x8)
	struct UHDAICombatHandler* CombatHandler;  // 0xA0(0x8)
	struct UHDAIAimingHandler* AimingHandler;  // 0xA8(0x8)
	struct UHDAIVocalHandler* VocalHandler;  // 0xB0(0x8)
	float SuppressionThreatLevel;  // 0xB8(0x4)
	float SuppressionLevelPerShot;  // 0xBC(0x4)
	float SuppressionThreatThreshold;  // 0xC0(0x4)
	float SuppressionFalloff;  // 0xC4(0x4)
	float SuppressionTime;  // 0xC8(0x4)
	float SuppressionFallingOffDelay;  // 0xCC(0x4)
	float BeingHitThreatLevel;  // 0xD0(0x4)
	float BeingHitThreatThreshold;  // 0xD4(0x4)
	float BeingHitFalloff;  // 0xD8(0x4)
	float BeingHitThreatLevelSpikeProbability;  // 0xDC(0x4)
	float BeingHitThreatLevelSpikeAmount;  // 0xE0(0x4)
	float BeingHitFallingOffDelay;  // 0xE4(0x4)
	float BeingHitTime;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	char bIsSprinting : 1;  // 0xF0(0x1)
	char pad_240_1 : 7;  // 0xF0(0x1)
	char pad_241[4];  // 0xF1(0x4)
	float SprintTimeMin;  // 0xF4(0x4)
	float SprintTimeMax;  // 0xF8(0x4)
	float SprintTimeEnd;  // 0xFC(0x4)
	float SprintStaminaThresholdMin;  // 0x100(0x4)
	float SprintStaminaThresholdMax;  // 0x104(0x4)
	float SprintStaminaThreshold;  // 0x108(0x4)
	float SprintStaminaMin;  // 0x10C(0x4)
	float SprintLookAroundTimeMin;  // 0x110(0x4)
	float SprintLookAroundTimeMax;  // 0x114(0x4)
	float SprintLookAroundTimeEnd;  // 0x118(0x4)
	char bCombatCanCrouch : 1;  // 0x11C(0x1)
	char bCombatCanProne : 1;  // 0x11C(0x1)
	char pad_284_1 : 6;  // 0x11C(0x1)
	char pad_285[4];  // 0x11D(0x4)
	float CombatSuppressionThresholdCrouching;  // 0x120(0x4)
	float CombatSuppressionThresholdProning;  // 0x124(0x4)
	char bDangerCanCrouch : 1;  // 0x128(0x1)
	char bDangerCanProne : 1;  // 0x128(0x1)
	char pad_296_1 : 6;  // 0x128(0x1)
	char pad_297[4];  // 0x129(0x4)
	float DangerSuppressionThresholdCrouching;  // 0x12C(0x4)
	float DangerSuppressionThresholdProning;  // 0x130(0x4)
	float DangerHealthThresholdCrouching;  // 0x134(0x4)
	float DangerHealthThresholdProning;  // 0x138(0x4)
	char pad_316[4];  // 0x13C(0x4)

	void StartSafeBehavior(); // Function HDMain.HDAIBehaviorHandler.StartSafeBehavior
	void StartDangerBehavior(); // Function HDMain.HDAIBehaviorHandler.StartDangerBehavior
	void StartCombatBehavior(); // Function HDMain.HDAIBehaviorHandler.StartCombatBehavior
	void StartAwareBehavior(); // Function HDMain.HDAIBehaviorHandler.StartAwareBehavior
	void ReceiveSuppression(); // Function HDMain.HDAIBehaviorHandler.ReceiveSuppression
	void ReceiveHitDamage(); // Function HDMain.HDAIBehaviorHandler.ReceiveHitDamage
	void HandleSafeBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleSafeBehavior
	void HandleDangerBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleDangerBehavior
	void HandleCombatBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleCombatBehavior
	void HandleBehaviorStates(); // Function HDMain.HDAIBehaviorHandler.HandleBehaviorStates
	void HandleAwareBehavior(); // Function HDMain.HDAIBehaviorHandler.HandleAwareBehavior
	bool GetIsUnderSuppression(); // Function HDMain.HDAIBehaviorHandler.GetIsUnderSuppression
	bool GetIsBeingHit(); // Function HDMain.HDAIBehaviorHandler.GetIsBeingHit
	void DetermineThreatLevel(); // Function HDMain.HDAIBehaviorHandler.DetermineThreatLevel
	void CalcThreatLevels(); // Function HDMain.HDAIBehaviorHandler.CalcThreatLevels
}; 



// Class HDMain.HDAICaptureHandler
// Size: 0x68(Inherited: 0x50) 
struct UHDAICaptureHandler : public UHDAIHandlerBase
{
	struct AHDBaseCapturePoint* CurrentCP;  // 0x50(0x8)
	uint8_t  CurrentCaptureMode;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	float AICaptureModePreference;  // 0x5C(0x4)
	char bAutoUpdateNavHandlerDesiredLocation : 1;  // 0x60(0x1)
	char pad_96_1 : 7;  // 0x60(0x1)
	char pad_97[8];  // 0x61(0x8)

	bool ShouldEstablishNewControlPoint(); // Function HDMain.HDAICaptureHandler.ShouldEstablishNewControlPoint
	void SetCurrentCP(struct AHDBaseCapturePoint* InCurrentCP); // Function HDMain.HDAICaptureHandler.SetCurrentCP
	void SetCurrentCaptureMode(uint8_t  NewCaptureMode); // Function HDMain.HDAICaptureHandler.SetCurrentCaptureMode
	struct AActor* GetStartSpotClosestToControlPoint(struct AActor* InCapturePoint); // Function HDMain.HDAICaptureHandler.GetStartSpotClosestToControlPoint
	struct FVector GetCurrentCPLocation(); // Function HDMain.HDAICaptureHandler.GetCurrentCPLocation
	bool FindControlPointToCapture(struct AHDBaseCapturePoint*& OutFoundCP); // Function HDMain.HDAICaptureHandler.FindControlPointToCapture
	struct AHDBaseCapturePoint* FindControlPointRandom(struct TArray<struct AHDBaseCapturePoint*>& CPs); // Function HDMain.HDAICaptureHandler.FindControlPointRandom
	struct AHDBaseCapturePoint* FindControlPointClosestToPawn(struct TArray<struct AHDBaseCapturePoint*>& CPs); // Function HDMain.HDAICaptureHandler.FindControlPointClosestToPawn
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfTypeV3(uint8_t  InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV3
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfTypeV2(uint8_t  InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV2
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfTypeV1(uint8_t  InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV1
	struct TArray<struct AHDBaseCapturePoint*> FindAvailableControlPointsOfType(uint8_t  InCaptureMode); // Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfType
	bool EstablishNewControlPoint(); // Function HDMain.HDAICaptureHandler.EstablishNewControlPoint
}; 



// Class HDMain.HDTextChatMsgInfo
// Size: 0x48(Inherited: 0x28) 
struct UHDTextChatMsgInfo : public UObject
{
	struct UDFCommChannel* CommChannel;  // 0x28(0x8)
	struct APlayerState* SenderPS;  // 0x30(0x8)
	struct FString ChatMsgContent;  // 0x38(0x10)

}; 



// Class HDMain.HDAICombatHandler
// Size: 0x1D8(Inherited: 0x50) 
struct UHDAICombatHandler : public UHDAIHandlerBase
{
	struct UHDAIBehaviorHandler* BehaviorHandler;  // 0x50(0x8)
	struct UHDAIVocalHandler* VocalHandler;  // 0x58(0x8)
	char pad_96_1 : 1;  // 0x60(0x1)
	char bWeaponAutoReload : 1;  // 0x60(0x1)
	char bWeaponMovementFire : 1;  // 0x60(0x1)
	char bWeaponHasAmmo : 1;  // 0x60(0x1)
	char pad_96_2 : 4;  // 0x60(0x1)
	char pad_97[8];  // 0x61(0x8)
	struct AActor* Enemy;  // 0x68(0x8)
	float WeaponNextFireTime;  // 0x70(0x4)
	float AttackRateMin;  // 0x74(0x4)
	float AttackRateMax;  // 0x78(0x4)
	float BurstAttackProbability;  // 0x7C(0x4)
	int32_t BurstAttackNumberMin;  // 0x80(0x4)
	int32_t BurstAttackNumberMax;  // 0x84(0x4)
	int32_t CurrentBurstAttackNumber;  // 0x88(0x4)
	float WeaponStopFireTime;  // 0x8C(0x4)
	float WeaponStopFireTimeMin;  // 0x90(0x4)
	float WeaponStopFireTimeMax;  // 0x94(0x4)
	char bWeaponInfiniteAmmo : 1;  // 0x98(0x1)
	char bWeaponInfiniteClipAmmo : 1;  // 0x98(0x1)
	char bIgnoreFriendlySuppression : 1;  // 0x98(0x1)
	char bIgnoreFriendlyHits : 1;  // 0x98(0x1)
	char pad_152_1 : 4;  // 0x98(0x1)
	char pad_153[8];  // 0x99(0x8)
	struct FMulticastInlineDelegate OnReceiveSuppression;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnReceiveHitDamage;  // 0xB0(0x10)
	struct FVector SuppressionDirection;  // 0xC0(0xC)
	float SuppressionOriginDistance;  // 0xCC(0x4)
	struct FVector SuppressionOrigin;  // 0xD0(0xC)
	char pad_220[4];  // 0xDC(0x4)
	struct FMulticastInlineDelegate OnReload;  // 0xE0(0x10)
	struct UHDKit* CurrentKit;  // 0xF0(0x8)
	uint8_t  CurrentSpecificItemType;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct TArray<struct FHDAIItemData> EquipmentReferences;  // 0x100(0x10)
	float EquipmentHandlingTime;  // 0x110(0x4)
	float EquipmentHandlingRate;  // 0x114(0x4)
	float EquipmentHandlingRateVariation;  // 0x118(0x4)
	char bSpecialtyItemInUse : 1;  // 0x11C(0x1)
	char bProjectileWeaponInUse : 1;  // 0x11C(0x1)
	char pad_284_1 : 6;  // 0x11C(0x1)
	char pad_285[4];  // 0x11D(0x4)
	float AfterEquipCooldownTime;  // 0x120(0x4)
	float SpecialtyItemUseTimeLimit;  // 0x124(0x4)
	float AfterSpecialtyItemUsedTimeLimit;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)
	struct TMap<uint8_t , struct FHDAISpecificItemTypeAttackData> ItemAttackData;  // 0x130(0x50)
	struct FHDAISpecificItemTypeAttackData DefaultItemAttackData;  // 0x180(0x2C)
	float GrenadeLauncherRangeMin;  // 0x1AC(0x4)
	float GrenadeLauncherRangeMax;  // 0x1B0(0x4)
	float GrenadeLauncherChance;  // 0x1B4(0x4)
	float RocketLauncherRangeMin;  // 0x1B8(0x4)
	float RocketLauncherRangeMax;  // 0x1BC(0x4)
	float RocketLauncherChance;  // 0x1C0(0x4)
	float FragGrenadeRangeMin;  // 0x1C4(0x4)
	float FragGrenadeRangeMax;  // 0x1C8(0x4)
	float FragGrenadeChance;  // 0x1CC(0x4)
	float SmokeGrenadeRangeMin;  // 0x1D0(0x4)
	float SmokeGrenadeChance;  // 0x1D4(0x4)

	void UpdateEquipmentHandling(); // Function HDMain.HDAICombatHandler.UpdateEquipmentHandling
	void UpdateAttackParameters(); // Function HDMain.HDAICombatHandler.UpdateAttackParameters
	void StopUsingSpecialtyItem(); // Function HDMain.HDAICombatHandler.StopUsingSpecialtyItem
	void StopAttack(); // Function HDMain.HDAICombatHandler.StopAttack
	void StartAttack(); // Function HDMain.HDAICombatHandler.StartAttack
	void SetWeaponMovementFireEnabled(bool bInWeaponMovementFire); // Function HDMain.HDAICombatHandler.SetWeaponMovementFireEnabled
	void SetWeaponAutoReloadEnabled(bool bInWeaponAutoReload); // Function HDMain.HDAICombatHandler.SetWeaponAutoReloadEnabled
	void SetupEquipmentReferences(); // Function HDMain.HDAICombatHandler.SetupEquipmentReferences
	void SetNextAttackTime(); // Function HDMain.HDAICombatHandler.SetNextAttackTime
	void SetItemAttackParameters(struct FHDAISpecificItemTypeAttackData& InAttackData); // Function HDMain.HDAICombatHandler.SetItemAttackParameters
	void SetEnemy(struct AActor* NewEnemy); // Function HDMain.HDAICombatHandler.SetEnemy
	void Reload(struct AHDBaseWeapon* InWeapon); // Function HDMain.HDAICombatHandler.Reload
	void ReceiveSuppression(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function HDMain.HDAICombatHandler.ReceiveSuppression
	void ReceiveHitDamage(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function HDMain.HDAICombatHandler.ReceiveHitDamage
	void PauseAttack(); // Function HDMain.HDAICombatHandler.PauseAttack
	bool IsFiring(); // Function HDMain.HDAICombatHandler.IsFiring
	bool HasValidEnemy(bool bAliveCheck); // Function HDMain.HDAICombatHandler.HasValidEnemy
	bool HasAmmoLoaded(); // Function HDMain.HDAICombatHandler.HasAmmoLoaded
	bool CanAttackEnemy(bool bCheckFireTime, bool bIgnoreAmmoReloadCheck); // Function HDMain.HDAICombatHandler.CanAttackEnemy
}; 



// Class HDMain.HDGOAPAct_MoveToDesiredLocation
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPAct_MoveToDesiredLocation : public UHDGOAPActionBase
{

}; 



// Class HDMain.HDGOAPActionBase
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPActionBase : public UGOAPAction
{

}; 



// Class HDMain.HDGOAPAct_CaptureControlPoint
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPAct_CaptureControlPoint : public UHDGOAPActionBase
{

}; 



// Class HDMain.HDAIController
// Size: 0x360(Inherited: 0x330) 
struct AHDAIController : public ADFBaseAIController
{
	struct UHDPlayerComponent* PlayerComponent;  // 0x330(0x8)
	struct UHDGOAPComponent* GOAPComponent;  // 0x338(0x8)
	char bCanJoinSquads : 1;  // 0x340(0x1)
	char bCanJoinPlayerSquads : 1;  // 0x340(0x1)
	char bCanCreateSquads : 1;  // 0x340(0x1)
	char pad_832_1 : 5;  // 0x340(0x1)
	char pad_833[4];  // 0x341(0x4)
	int32_t MaxNumberOfAILedSquads;  // 0x344(0x4)
	int32_t MaxNumberOfSquadMembers;  // 0x348(0x4)
	int32_t MaxNumberOfAISquadMembers;  // 0x34C(0x4)
	char bUseFactionSpecifiedSquadLeaderKit : 1;  // 0x350(0x1)
	char bUseFactionSpecifiedSquadMemberKit : 1;  // 0x350(0x1)
	char pad_848_1 : 6;  // 0x350(0x1)
	char pad_849[4];  // 0x351(0x4)
	struct FVector FocusActorPerceivedLocation;  // 0x354(0xC)

	bool JoinOrCreateSquad(); // Function HDMain.HDAIController.JoinOrCreateSquad
	APawn* GetStartPawnClass(); // Function HDMain.HDAIController.GetStartPawnClass
	struct UHDKit* GetFactionSpecifiedSquadMemberKit(); // Function HDMain.HDAIController.GetFactionSpecifiedSquadMemberKit
	struct UHDKit* GetFactionSpecifiedSquadLeaderKit(); // Function HDMain.HDAIController.GetFactionSpecifiedSquadLeaderKit
}; 



// Class HDMain.HDAIGroupBehaviorHandler
// Size: 0x160(Inherited: 0x50) 
struct UHDAIGroupBehaviorHandler : public UHDAIHandlerBase
{
	struct UHDAINavigationHandler* NavigationHandler;  // 0x50(0x8)
	struct UHDAICaptureHandler* CaptureHandler;  // 0x58(0x8)
	struct AHDPlayerState* PlayerState;  // 0x60(0x8)
	char bIsGroupLeader : 1;  // 0x68(0x1)
	char bIsGroupMember : 1;  // 0x68(0x1)
	char bGroupDataIsSet : 1;  // 0x68(0x1)
	char bGroupDataIsSynchronized : 1;  // 0x68(0x1)
	char bIsRespawned : 1;  // 0x68(0x1)
	char bLeaderIsHuman : 1;  // 0x68(0x1)
	char pad_104_1 : 2;  // 0x68(0x1)
	char pad_105[4];  // 0x69(0x4)
	float GroupFormationRadius;  // 0x6C(0x4)
	float GroupFormationSlotRadius;  // 0x70(0x4)
	float GroupFormationSlotDistance;  // 0x74(0x4)
	struct TArray<struct FVector> FormationSlots;  // 0x78(0x10)
	int32_t FormationIndex;  // 0x88(0x4)
	float WaitingTimePerGroupMember;  // 0x8C(0x4)
	float WaitingGroupRadiusMultiplier;  // 0x90(0x4)
	int32_t NumValidGroupMembers;  // 0x94(0x4)
	int32_t NumGroupMembersOnPoint;  // 0x98(0x4)
	int32_t NumGroupMembersKIA;  // 0x9C(0x4)
	char bWaitingForGroupMembers : 1;  // 0xA0(0x1)
	char pad_160_1 : 7;  // 0xA0(0x1)
	char pad_161[4];  // 0xA1(0x4)
	float WaitingForMembersStartTime;  // 0xA4(0x4)
	char bIsGroupWaiting : 1;  // 0xA8(0x1)
	char pad_168_1 : 7;  // 0xA8(0x1)
	char pad_169[4];  // 0xA9(0x4)
	float GroupWaitTimeEnd;  // 0xAC(0x4)
	float GroupWaitTimeDuration;  // 0xB0(0x4)
	int32_t MinNumGroupMembersOnPoint;  // 0xB4(0x4)
	float AdvanceWaitTimeDurationMin;  // 0xB8(0x4)
	float AdvanceWaitTimeDurationMax;  // 0xBC(0x4)
	float PatrolWaitTimeDurationMin;  // 0xC0(0x4)
	float PatrolWaitTimeDurationMax;  // 0xC4(0x4)
	char bIsGroupRetreating : 1;  // 0xC8(0x1)
	char bGroupRetreatOnLeaderKIA : 1;  // 0xC8(0x1)
	char pad_200_1 : 6;  // 0xC8(0x1)
	char pad_201[4];  // 0xC9(0x4)
	float GroupRetreatMemberPercentageThreshold;  // 0xCC(0x4)
	char bEnableFollowHumanLeader : 1;  // 0xD0(0x1)
	char pad_208_1 : 7;  // 0xD0(0x1)
	char pad_209[4];  // 0xD1(0x4)
	float FollowHumanLeaderInterval;  // 0xD4(0x4)
	float FollowHumanLeaderVelocityMultiplier;  // 0xD8(0x4)
	float FollowHumanLeaderAcceptanceRadius;  // 0xDC(0x4)
	float FollowHumanLeaderRange;  // 0xE0(0x4)
	float FollowHumanLeaderPatrolTimeThreshold;  // 0xE4(0x4)
	float FollowHumanLeaderTime;  // 0xE8(0x4)
	float FollowHumanLeaderPatrolTime;  // 0xEC(0x4)
	struct FVector FollowHumanLeaderLastKnownLocation;  // 0xF0(0xC)
	char pad_252[4];  // 0xFC(0x4)
	struct TArray<struct FHDAIMasterNavPoint> MasterNavPath;  // 0x100(0x10)
	float MasterNavPathLength;  // 0x110(0x4)
	float NavPathSegmentLengthMin;  // 0x114(0x4)
	float NavPathSegmentLengthMax;  // 0x118(0x4)
	char bCompensatePartialPathForGroupFormationRadius : 1;  // 0x11C(0x1)
	char pad_284_1 : 7;  // 0x11C(0x1)
	char pad_285[4];  // 0x11D(0x4)
	float PartialPathGroupRadiusMultiplier;  // 0x120(0x4)
	float RemainingNavPathLength;  // 0x124(0x4)
	int32_t NavPointIndex;  // 0x128(0x4)
	char bPawnIsAtTheEndOfPath : 1;  // 0x12C(0x1)
	char pad_300_1 : 7;  // 0x12C(0x1)
	char pad_301[4];  // 0x12D(0x4)
	struct FVector GroupCenterNavPoint;  // 0x130(0xC)
	struct FVector TargetNavPoint;  // 0x13C(0xC)
	float NavPointRandomRange;  // 0x148(0x4)
	float MoveToFailedTime;  // 0x14C(0x4)
	float MoveToFailedTimeDelay;  // 0x150(0x4)
	char bMovetoFailedIsBeingHandled : 1;  // 0x154(0x1)
	char pad_340_1 : 7;  // 0x154(0x1)
	char pad_341[4];  // 0x155(0x4)
	struct AHDBaseCapturePoint* SavedCapturePoint;  // 0x158(0x8)

	void StopRetreat(); // Function HDMain.HDAIGroupBehaviorHandler.StopRetreat
	void StartRetreat(); // Function HDMain.HDAIGroupBehaviorHandler.StartRetreat
	void StartGroupWaitTime(); // Function HDMain.HDAIGroupBehaviorHandler.StartGroupWaitTime
	bool ShouldRetreat(); // Function HDMain.HDAIGroupBehaviorHandler.ShouldRetreat
	void SetupGroupData(); // Function HDMain.HDAIGroupBehaviorHandler.SetupGroupData
	void SetSquadParams(); // Function HDMain.HDAIGroupBehaviorHandler.SetSquadParams
	void SetCurrentDestination(); // Function HDMain.HDAIGroupBehaviorHandler.SetCurrentDestination
	bool RequestGroupDataSync(); // Function HDMain.HDAIGroupBehaviorHandler.RequestGroupDataSync
	bool PointsAreEqualXY(struct FVector& Vector1, struct FVector& Vector2, float Tolerance); // Function HDMain.HDAIGroupBehaviorHandler.PointsAreEqualXY
	void OnOwnerDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function HDMain.HDAIGroupBehaviorHandler.OnOwnerDeath
	void OnMoveToFailed(); // Function HDMain.HDAIGroupBehaviorHandler.OnMoveToFailed
	void MakeNewMasterNavPath(struct FVector InStart, struct FVector InDestination); // Function HDMain.HDAIGroupBehaviorHandler.MakeNewMasterNavPath
	void MakeNavPathSegment(); // Function HDMain.HDAIGroupBehaviorHandler.MakeNavPathSegment
	bool IsGroupWaitTimeOver(); // Function HDMain.HDAIGroupBehaviorHandler.IsGroupWaitTimeOver
	void HandleMoveToFailed(); // Function HDMain.HDAIGroupBehaviorHandler.HandleMoveToFailed
	struct FHDAIGroupData GetGroupData(); // Function HDMain.HDAIGroupBehaviorHandler.GetGroupData
	void FollowHumanLeader(); // Function HDMain.HDAIGroupBehaviorHandler.FollowHumanLeader
	void BroadcastGroupData(); // Function HDMain.HDAIGroupBehaviorHandler.BroadcastGroupData
	bool AllGroupMembersAreOnPoint(); // Function HDMain.HDAIGroupBehaviorHandler.AllGroupMembersAreOnPoint
}; 



// Class HDMain.HDPlatoonStateCreationPayload
// Size: 0x38(Inherited: 0x28) 
struct UHDPlatoonStateCreationPayload : public UObject
{
	struct FHDPlatoonCreationParams CreationParams;  // 0x28(0x10)

}; 



// Class HDMain.HDAIPerceptionComponent
// Size: 0xF0(Inherited: 0xB0) 
struct UHDAIPerceptionComponent : public UActorComponent
{
	struct AHDPlayerCharacter* OwnerPlayer;  // 0xB0(0x8)
	char bEnableAdvancedLineTracing : 1;  // 0xB8(0x1)
	char pad_184_1 : 7;  // 0xB8(0x1)
	char pad_185[4];  // 0xB9(0x4)
	float ObserverSightRadius;  // 0xBC(0x4)
	float ObserverLoseSightRadius;  // 0xC0(0x4)
	float DistanceToObserverRangeFar;  // 0xC4(0x4)
	float DistanceToObserverRangeNear;  // 0xC8(0x4)
	char bComplexSightLineTrace : 1;  // 0xCC(0x1)
	char pad_204_1 : 7;  // 0xCC(0x1)
	char pad_205[4];  // 0xCD(0x4)
	float ShoulderLocationFactor;  // 0xD0(0x4)
	float RangeFactorWeight;  // 0xD4(0x4)
	float StanceFactorWeight;  // 0xD8(0x4)
	float MovementFactorWeight;  // 0xDC(0x4)
	float StanceFactorMaxValue;  // 0xE0(0x4)
	float StanceFactorMinValue;  // 0xE4(0x4)
	float OwnerMaxMovementSpeed;  // 0xE8(0x4)
	float OwnerDefaultHalfHeight;  // 0xEC(0x4)

	bool CanBeSeenFrom(struct FVector& ObserverLocation, struct FVector& OutSeenLocation, int32_t& NumberOfLoSChecksPerformed, float& OutSightStrength, struct AActor* IgnoreActor); // Function HDMain.HDAIPerceptionComponent.CanBeSeenFrom
	float CalcSightStrength(float Distance); // Function HDMain.HDAIPerceptionComponent.CalcSightStrength
}; 



// Class HDMain.HDGOAPAct_AttackEnemy
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPAct_AttackEnemy : public UHDGOAPActionBase
{

}; 



// Class HDMain.HDAIVocalHandler
// Size: 0x118(Inherited: 0x50) 
struct UHDAIVocalHandler : public UHDAIHandlerBase
{
	struct UHDAICombatHandler* CombatHandler;  // 0x50(0x8)
	char bEnableVocalization : 1;  // 0x58(0x1)
	char pad_88_1 : 7;  // 0x58(0x1)
	char pad_89[8];  // 0x59(0x8)
	struct FAICharacterVocalProfile CurrentProfile;  // 0x60(0x68)
	char bEnableTimeLimitNotify : 1;  // 0xC8(0x1)
	char bFactionOnlyTimeLimit : 1;  // 0xC8(0x1)
	char pad_200_1 : 6;  // 0xC8(0x1)
	char pad_201[4];  // 0xC9(0x4)
	float TimeLimitNotifyRange;  // 0xCC(0x4)
	float PitchMultiplier;  // 0xD0(0x4)
	float MinPitchMultiplier;  // 0xD4(0x4)
	float MaxPitchMultiplier;  // 0xD8(0x4)
	float AnySoundTimeLimit;  // 0xDC(0x4)
	float ContactTimeLimit;  // 0xE0(0x4)
	float LostContactTimeLimit;  // 0xE4(0x4)
	float ReloadingTimeLimit;  // 0xE8(0x4)
	float BeenHitTimeLimit;  // 0xEC(0x4)
	float UnderSuppressionTimeLimit;  // 0xF0(0x4)
	float DeathTimeLimit;  // 0xF4(0x4)
	float NextAnySoundTime;  // 0xF8(0x4)
	float NextContactTime;  // 0xFC(0x4)
	float NextLostContactTime;  // 0x100(0x4)
	float NextReloadingTime;  // 0x104(0x4)
	float NextBeenHitTime;  // 0x108(0x4)
	float NextUnderSuppressionTime;  // 0x10C(0x4)
	float NextDeathTime;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)

	void VocalizeSuppression(); // Function HDMain.HDAIVocalHandler.VocalizeSuppression
	void VocalizeReload(); // Function HDMain.HDAIVocalHandler.VocalizeReload
	void VocalizeContact(bool bHasContact); // Function HDMain.HDAIVocalHandler.VocalizeContact
	void VocalizeBeenHit(); // Function HDMain.HDAIVocalHandler.VocalizeBeenHit
	void Vocalize(uint8_t  InVocalType); // Function HDMain.HDAIVocalHandler.Vocalize
	void SetTimeLimit(uint8_t  InVocalType); // Function HDMain.HDAIVocalHandler.SetTimeLimit
	void SetPitchMultiplier(float InPitchMultiplier); // Function HDMain.HDAIVocalHandler.SetPitchMultiplier
	void RandomizePitchMultiplier(); // Function HDMain.HDAIVocalHandler.RandomizePitchMultiplier
	void PlayVocalSound(uint8_t  InVocalType); // Function HDMain.HDAIVocalHandler.PlayVocalSound
	void NotifySurroundingCharacters(uint8_t  InVocalType); // Function HDMain.HDAIVocalHandler.NotifySurroundingCharacters
}; 



// Class HDMain.HDAssetManager
// Size: 0x440(Inherited: 0x440) 
struct UHDAssetManager : public UDFAssetManager
{

}; 



// Class HDMain.HDBaseCapturePoint
// Size: 0x350(Inherited: 0x220) 
struct AHDBaseCapturePoint : public AActor
{
	char pad_544[8];  // 0x220(0x8)
	struct USkeletalMeshComponent* Mesh;  // 0x228(0x8)
	struct USphereComponent* SphereCollision;  // 0x230(0x8)
	struct UDFPOIComponent* POI;  // 0x238(0x8)
	struct UNavigationInvokerComponent* NavigationInvoker;  // 0x240(0x8)
	char bActive : 1;  // 0x248(0x1)
	char bLocked : 1;  // 0x248(0x1)
	char bContested : 1;  // 0x248(0x1)
	char bCaptured : 1;  // 0x248(0x1)
	char bCapturedOnce : 1;  // 0x248(0x1)
	char pad_584_1 : 3;  // 0x248(0x1)
	char pad_585[4];  // 0x249(0x4)
	int32_t CaptureProgress;  // 0x24C(0x4)
	int32_t ActiveRoute;  // 0x250(0x4)
	char pad_596[12];  // 0x254(0xC)
	struct TArray<struct UChildActorComponent*> SpawnPoints;  // 0x260(0x10)
	struct FMulticastInlineDelegate OnCaptureProgressUpdated;  // 0x270(0x10)
	uint8_t  StartingTeam;  // 0x280(0x1)
	char pad_641[7];  // 0x281(0x7)
	struct FText CaptureDisplayName;  // 0x288(0x18)
	float CaptureTimerRate;  // 0x2A0(0x4)
	int32_t CaptureSpeed;  // 0x2A4(0x4)
	float CaptureRadius;  // 0x2A8(0x4)
	int32_t MinPlayersToCapture;  // 0x2AC(0x4)
	char bEnforceMinPlayersToCaptureWithSmallerPlayerCount : 1;  // 0x2B0(0x1)
	char bScaleCaptureSpeed : 1;  // 0x2B0(0x1)
	char bRecapturable : 1;  // 0x2B0(0x1)
	char bWinOnCapture : 1;  // 0x2B0(0x1)
	char bProvideSpawnPoint : 1;  // 0x2B0(0x1)
	char bProvideSpawnPointWhenUnderAttack : 1;  // 0x2B0(0x1)
	char pad_688_1 : 2;  // 0x2B0(0x1)
	char pad_689[8];  // 0x2B1(0x8)
	struct TSet<int32_t> PossibleRoutes;  // 0x2B8(0x50)
	int32_t Tier;  // 0x308(0x4)
	char pad_780[4];  // 0x30C(0x4)
	struct TArray<struct FTransform> SpawnPointTransforms;  // 0x310(0x10)
	uint8_t  OwningTeam;  // 0x320(0x1)
	uint8_t  PrevNonNeutralOwningTeam;  // 0x321(0x1)
	char pad_802[6];  // 0x322(0x6)
	struct FMulticastInlineDelegate OnOwningTeamUpdate;  // 0x328(0x10)
	char bCapturableByTeamRed : 1;  // 0x338(0x1)
	char bCapturableByTeamBlue : 1;  // 0x338(0x1)
	char pad_824_1 : 6;  // 0x338(0x1)
	char pad_825[8];  // 0x339(0x8)
	struct FMulticastInlineDelegate OnTeamCaptureStatusUpdate;  // 0x340(0x10)

	void Unlock(); // Function HDMain.HDBaseCapturePoint.Unlock
	void SetActiveRoute(int32_t NewActiveRoute); // Function HDMain.HDBaseCapturePoint.SetActiveRoute
	void SetActive(bool bNewActive); // Function HDMain.HDBaseCapturePoint.SetActive
	void ReceiveOnTeamCaptureStatusUpdated(); // Function HDMain.HDBaseCapturePoint.ReceiveOnTeamCaptureStatusUpdated
	void ReceiveOnOwningTeamUpdated(uint8_t  LastOwningTeam); // Function HDMain.HDBaseCapturePoint.ReceiveOnOwningTeamUpdated
	void ReceiveOnLocked(bool bNewLocked); // Function HDMain.HDBaseCapturePoint.ReceiveOnLocked
	void ReceiveOnCaptureProgress(bool bNewContested); // Function HDMain.HDBaseCapturePoint.ReceiveOnCaptureProgress
	void ReceiveOnActive(bool bNewActive); // Function HDMain.HDBaseCapturePoint.ReceiveOnActive
	void OnRep_OwningTeam(uint8_t  LastOwningTeam); // Function HDMain.HDBaseCapturePoint.OnRep_OwningTeam
	void OnRep_Locked(); // Function HDMain.HDBaseCapturePoint.OnRep_Locked
	void OnRep_Contested(); // Function HDMain.HDBaseCapturePoint.OnRep_Contested
	void OnRep_CaptureProgress(); // Function HDMain.HDBaseCapturePoint.OnRep_CaptureProgress
	void OnRep_CapturableByTeam(); // Function HDMain.HDBaseCapturePoint.OnRep_CapturableByTeam
	void OnRep_Active(); // Function HDMain.HDBaseCapturePoint.OnRep_Active
	void OnOwningTeamUpdated(uint8_t  LastOwningTeam); // Function HDMain.HDBaseCapturePoint.OnOwningTeamUpdated
	void OnEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function HDMain.HDBaseCapturePoint.OnEndOverlap
	void OnBeginOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function HDMain.HDBaseCapturePoint.OnBeginOverlap
	void Lock(); // Function HDMain.HDBaseCapturePoint.Lock
	bool IsCapturableByTeam(uint8_t  CaptureTeam); // Function HDMain.HDBaseCapturePoint.IsCapturableByTeam
	void GetOverlappingCharactersByTeam(struct TArray<struct ADFBaseCharacter*>& OverlappingCharsRed, struct TArray<struct ADFBaseCharacter*>& OverlappingCharsBlue); // Function HDMain.HDBaseCapturePoint.GetOverlappingCharactersByTeam
	uint8_t  GetObjectiveTypeForTeam(uint8_t  ObjTeam); // Function HDMain.HDBaseCapturePoint.GetObjectiveTypeForTeam
	int32_t GetMinPlayersRequiredForCaptureTeam(uint8_t  CaptureTeam); // Function HDMain.HDBaseCapturePoint.GetMinPlayersRequiredForCaptureTeam
	struct AActor* ChoosePlayerStart(struct AHDPlayerController* Player); // Function HDMain.HDBaseCapturePoint.ChoosePlayerStart
	bool CanRestartPlayer(struct AController* Player); // Function HDMain.HDBaseCapturePoint.CanRestartPlayer
	bool CanCapture(); // Function HDMain.HDBaseCapturePoint.CanCapture
}; 



// Class HDMain.HDServerListFilterRule
// Size: 0x28(Inherited: 0x28) 
struct UHDServerListFilterRule : public UObject
{

	bool MatchesServer(struct UHDServerListItemData* ListItem); // Function HDMain.HDServerListFilterRule.MatchesServer
}; 



// Class HDMain.HDGameModeDefinition
// Size: 0x110(Inherited: 0xE8) 
struct UHDGameModeDefinition : public UDFGameModeDefinition
{
	struct TSoftClassPtr<UObject> GameModeClass;  // 0xE8(0x28)

}; 



// Class HDMain.HDGameEngine
// Size: 0xE30(Inherited: 0xE30) 
struct UHDGameEngine : public UDFGameEngine
{

}; 



// Class HDMain.HDFactionInfo
// Size: 0xE0(Inherited: 0x90) 
struct UHDFactionInfo : public UDFFactionInfo
{
	struct TSet<struct TSoftObjectPtr<UHDKit>> Kits;  // 0x90(0x50)

}; 



// Class HDMain.HDBaseGameMode
// Size: 0x488(Inherited: 0x3F8) 
struct AHDBaseGameMode : public ADFBaseGameMode
{
	UHDScoreboardBase* ScoreboardMenuClass;  // 0x3F8(0x8)
	struct FHDGameRoundEndEventDetails RoundEndEventDetails;  // 0x400(0x10)
	char bDisablePlayerSpawnKitRestrictions : 1;  // 0x410(0x1)
	char bUseTickets : 1;  // 0x410(0x1)
	char pad_1040_1 : 6;  // 0x410(0x1)
	char pad_1041[8];  // 0x411(0x8)
	struct UHDTeamDefinition* DefaultBluforTeamDefinition;  // 0x418(0x8)
	struct UHDTeamDefinition* DefaultOpforTeamDefinition;  // 0x420(0x8)
	struct UHDTeamDefinition* BluforTeamDefinition;  // 0x428(0x8)
	struct UHDTeamDefinition* OpforTeamDefinition;  // 0x430(0x8)
	char bRandomPlayerTeamBalance : 1;  // 0x438(0x1)
	char pad_1080_1 : 7;  // 0x438(0x1)
	char pad_1081[56];  // 0x439(0x38)
	struct TArray<struct UHDPlatoonInfo*> PlatoonInfos;  // 0x470(0x10)
	AHDPlatoonState* PlatoonStateClass;  // 0x480(0x8)

	void RemoveOpforBots(int32_t Num); // Function HDMain.HDBaseGameMode.RemoveOpforBots
	void RemoveBluforBots(int32_t Num); // Function HDMain.HDBaseGameMode.RemoveBluforBots
	bool PlayerCanRestartAtPlayerStart(struct AController* Player, struct AActor* StartSpot, struct UDFLoadout* StartLoadout); // Function HDMain.HDBaseGameMode.PlayerCanRestartAtPlayerStart
	void AddOpforBots(int32_t Num); // Function HDMain.HDBaseGameMode.AddOpforBots
	void AddBluforBots(int32_t Num); // Function HDMain.HDBaseGameMode.AddBluforBots
}; 



// Class HDMain.HDBasePickup_Kit
// Size: 0x278(Inherited: 0x258) 
struct AHDBasePickup_Kit : public ADFBasePickup
{
	struct UDFInventoryComponent* Inventory;  // 0x258(0x8)
	struct TArray<struct UPrimitiveComponent*> KitVisuals;  // 0x260(0x10)
	struct UHDKit* KitLoadout;  // 0x270(0x8)

}; 



// Class HDMain.HDGOAPGoal_EliminateEnemy
// Size: 0x68(Inherited: 0x68) 
struct UHDGOAPGoal_EliminateEnemy : public UHDGOAPGoalBase
{

}; 



// Class HDMain.HDBaseProjectile
// Size: 0x380(Inherited: 0x380) 
struct AHDBaseProjectile : public ADFBaseProjectile
{

}; 



// Class HDMain.HDBaseWeapon
// Size: 0x870(Inherited: 0x858) 
struct AHDBaseWeapon : public ADFBaseGun_Projectile
{
	struct UTexture2D* DisplayIcon;  // 0x858(0x8)
	struct UTexture2D* DisplayEquipmentSymbol;  // 0x860(0x8)
	char bUseFreeAim : 1;  // 0x868(0x1)
	char bSelectable : 1;  // 0x868(0x1)
	char bHideFireModeIndicator : 1;  // 0x868(0x1)
	char pad_2152_1 : 5;  // 0x868(0x1)
	char pad_2153[4];  // 0x869(0x4)
	float AmmoReplenishmentDelay;  // 0x86C(0x4)

	bool IsSelectableEquipment(); // Function HDMain.HDBaseWeapon.IsSelectableEquipment
}; 



// Class HDMain.HDPlayerController
// Size: 0x6A0(Inherited: 0x5F8) 
struct AHDPlayerController : public ADFBasePlayerController
{
	struct AHDPlayerCharacter* HDCharacter;  // 0x5F8(0x8)
	struct UHDPlayerComponent* PlayerComponent;  // 0x600(0x8)
	struct TMap<struct FName, struct FPTTKeyState> PushToTalkKeyStates;  // 0x608(0x50)
	char pad_1624[4];  // 0x658(0x4)
	struct FName TextCommsFormatName;  // 0x65C(0x8)
	struct FName TeamLocalVoipCommChannelGroupName;  // 0x664(0x8)
	struct FName SquadVoipCommChannelGroupName;  // 0x66C(0x8)
	struct FName CommandVoipCommChannelGroupName;  // 0x674(0x8)
	char pad_1660[4];  // 0x67C(0x4)
	struct UDFPlayerCommsComponent* CachedPlayerCommsComp;  // 0x680(0x8)
	UVictoryMenu* VictoryMenuClass;  // 0x688(0x8)
	struct UVictoryMenu* VictoryMenu;  // 0x690(0x8)
	char pad_1688[8];  // 0x698(0x8)

	void UnloadVictoryMenu(); // Function HDMain.HDPlayerController.UnloadVictoryMenu
	void TeamTalk(); // Function HDMain.HDPlayerController.TeamTalk
	void Talk(); // Function HDMain.HDPlayerController.Talk
	void StopTalkingOverChannelIfActive(struct FName TalkStopChannelName); // Function HDMain.HDPlayerController.StopTalkingOverChannelIfActive
	void StopTalkingOverChannelGroupIfActive(struct FName TalkStopGroupName); // Function HDMain.HDPlayerController.StopTalkingOverChannelGroupIfActive
	void StopTalkingOnActiveChannels(); // Function HDMain.HDPlayerController.StopTalkingOnActiveChannels
	void StartTalkingOverChannelGroup(struct FName TalkStartGroupName); // Function HDMain.HDPlayerController.StartTalkingOverChannelGroup
	void StartTalkingOverChannel(struct FName TalkStartChannelName); // Function HDMain.HDPlayerController.StartTalkingOverChannel
	void ServerSwitchTeam(); // Function HDMain.HDPlayerController.ServerSwitchTeam
	void ServerSpawnVehicle(); // Function HDMain.HDPlayerController.ServerSpawnVehicle
	void ServerRestartPlayerAtStartSpot(struct AActor* DesiredStartSpot, struct UDFLoadout* DesiredStartLoadout); // Function HDMain.HDPlayerController.ServerRestartPlayerAtStartSpot
	void ServerPickTeam(uint8_t  DesiredTeam); // Function HDMain.HDPlayerController.ServerPickTeam
	void ServerCheatSetAllowIdleSway(bool bIdleSwayDisallowed); // Function HDMain.HDPlayerController.ServerCheatSetAllowIdleSway
	void ReceiveVoipTalkerMsgReceived(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function HDMain.HDPlayerController.ReceiveVoipTalkerMsgReceived
	void OnShowScoreboardReleased(); // Function HDMain.HDPlayerController.OnShowScoreboardReleased
	void OnShowScoreboardPressed(); // Function HDMain.HDPlayerController.OnShowScoreboardPressed
	void OnPlayerSpawnTimerElapsed(); // Function HDMain.HDPlayerController.OnPlayerSpawnTimerElapsed
	void OnPauseMenu(); // Function HDMain.HDPlayerController.OnPauseMenu
	void LoadVictoryMenu(struct FHDGameRoundEndEventDetails& RoundDetails, bool bWinner); // Function HDMain.HDPlayerController.LoadVictoryMenu
	bool IsTalkingOverChannelName(struct FName TalkChannelName); // Function HDMain.HDPlayerController.IsTalkingOverChannelName
	bool IsTalkingOverChannelGroup(struct FName TalkGroupName); // Function HDMain.HDPlayerController.IsTalkingOverChannelGroup
	bool IsTalkingOverChannel(struct UDFCommChannel* TalkChannel); // Function HDMain.HDPlayerController.IsTalkingOverChannel
	bool IsTalking(bool bIncludeWantsToTalk); // Function HDMain.HDPlayerController.IsTalking
	bool IsInVehicle(); // Function HDMain.HDPlayerController.IsInVehicle
	bool IsIdleSwayAllowed(); // Function HDMain.HDPlayerController.IsIdleSwayAllowed
	struct UDFCommChannel* GetTalkChannel(); // Function HDMain.HDPlayerController.GetTalkChannel
	struct UDFPlayerCommsComponent* GetPlayerCommsComponent(); // Function HDMain.HDPlayerController.GetPlayerCommsComponent
	void ClientRoundEnd(struct FHDGameRoundEndEventDetails RoundDetails, bool bIsWinner); // Function HDMain.HDPlayerController.ClientRoundEnd
	void ClientLoadTeamData(struct TArray<struct FString> FactionAssetPaths); // Function HDMain.HDPlayerController.ClientLoadTeamData
	void ClientCheatSetAllowIdleSway(bool bIdleSwayDisallowed); // Function HDMain.HDPlayerController.ClientCheatSetAllowIdleSway
	bool CanTalkOverChannel(struct FName TalkChannelName); // Function HDMain.HDPlayerController.CanTalkOverChannel
	void Auth_SpawnVehicle(); // Function HDMain.HDPlayerController.Auth_SpawnVehicle
}; 



// Class HDMain.HDGame_AdvanceAndSecure
// Size: 0x4C0(Inherited: 0x488) 
struct AHDGame_AdvanceAndSecure : public AHDBaseGameMode
{
	int32_t StartingBlueTier;  // 0x488(0x4)
	int32_t StartingRedTier;  // 0x48C(0x4)
	int32_t ActiveRoute;  // 0x490(0x4)
	int32_t CurrentBlueCaptureTier;  // 0x494(0x4)
	int32_t CurrentRedCaptureTier;  // 0x498(0x4)
	char bBlueIncreasesTier : 1;  // 0x49C(0x1)
	char pad_1180_1 : 7;  // 0x49C(0x1)
	char pad_1181[36];  // 0x49D(0x24)

	int32_t GetCurrentRedCaptureTier(); // Function HDMain.HDGame_AdvanceAndSecure.GetCurrentRedCaptureTier
	int32_t GetCurrentBlueCaptureTier(); // Function HDMain.HDGame_AdvanceAndSecure.GetCurrentBlueCaptureTier
}; 



// Class HDMain.HDKitPrerequisite_AdminOnly
// Size: 0x40(Inherited: 0x40) 
struct UHDKitPrerequisite_AdminOnly : public UHDKitPrerequisiteBase
{

}; 



// Class HDMain.HDGame_TeamDeathMatch
// Size: 0x488(Inherited: 0x488) 
struct AHDGame_TeamDeathMatch : public AHDBaseGameMode
{

}; 



// Class HDMain.HDGameProjectBuildSettings
// Size: 0x28(Inherited: 0x28) 
struct UHDGameProjectBuildSettings : public UBlueprintFunctionLibrary
{

	bool IsDemoBuild(); // Function HDMain.HDGameProjectBuildSettings.IsDemoBuild
}; 



// Class HDMain.HDGameModsProjectPolicies
// Size: 0x28(Inherited: 0x28) 
struct UHDGameModsProjectPolicies : public UHDCoreDefaultUGCProjectPolicies
{

}; 



// Class HDMain.HDScoreboardListingRowBase
// Size: 0x318(Inherited: 0x230) 
struct UHDScoreboardListingRowBase : public UUserWidget
{
	struct UHDScoreboardBase* ParentMenu;  // 0x230(0x8)
	struct ADFBasePlayerState* PlayerState;  // 0x238(0x8)
	char pad_576[3];  // 0x240(0x3)
	char bRefreshListingOnTick : 1;  // 0x243(0x1)
	char pad_579_1 : 7;  // 0x243(0x1)
	char pad_580[5];  // 0x244(0x5)
	struct UButton* MutePlayerBtn;  // 0x248(0x8)
	struct UTextBlock* PlayerName;  // 0x250(0x8)
	struct UTextBlock* Score;  // 0x258(0x8)
	struct UTextBlock* Kills;  // 0x260(0x8)
	struct UTextBlock* Deaths;  // 0x268(0x8)
	struct UTextBlock* Ping;  // 0x270(0x8)
	struct TSoftObjectPtr<UTexture2D> NotTalkingVoiceIcon;  // 0x278(0x28)
	struct TSoftObjectPtr<UTexture2D> TalkingVoiceIcon;  // 0x2A0(0x28)
	struct TSoftObjectPtr<UTexture2D> MutedVoiceIcon;  // 0x2C8(0x28)
	char pad_752[32];  // 0x2F0(0x20)
	struct UTextBlock* PlayerNumber;  // 0x310(0x8)

	void SetVoiceStateIcon(struct UTexture2D* NewIcon); // Function HDMain.HDScoreboardListingRowBase.SetVoiceStateIcon
	void RefreshListing(); // Function HDMain.HDScoreboardListingRowBase.RefreshListing
	void ReceivePlayerVoiceStateChanged(uint8_t  NewVoiceState); // Function HDMain.HDScoreboardListingRowBase.ReceivePlayerVoiceStateChanged
	void OnMutePlayer(); // Function HDMain.HDScoreboardListingRowBase.OnMutePlayer
	void Init(struct UHDScoreboardBase* InParentMenu, struct ADFBasePlayerState* InPlayerState, bool bInRefreshListingOnTick); // Function HDMain.HDScoreboardListingRowBase.Init
	bool HasInitialized(); // Function HDMain.HDScoreboardListingRowBase.HasInitialized
	struct TSoftObjectPtr<UTexture2D> GetIconForVoiceState(uint8_t  VoiceState); // Function HDMain.HDScoreboardListingRowBase.GetIconForVoiceState
	int32_t GetCurrentPing(); // Function HDMain.HDScoreboardListingRowBase.GetCurrentPing
}; 



// Class HDMain.HDGameRulesetBase
// Size: 0x60(Inherited: 0x58) 
struct UHDGameRulesetBase : public UDFGameRulesetBase
{
	char bUseTickets : 1;  // 0x58(0x1)
	char pad_88_1 : 7;  // 0x58(0x1)
	char pad_89[8];  // 0x59(0x8)

	void RevokeTicketsFromTeam(uint8_t  TicketTeam, int32_t TicketsToRemove); // Function HDMain.HDGameRulesetBase.RevokeTicketsFromTeam
	void GiveTicketsToTeam(uint8_t  TicketTeam, int32_t TicketsToAdd); // Function HDMain.HDGameRulesetBase.GiveTicketsToTeam
	struct AHDGameState* GetHDGameState(); // Function HDMain.HDGameRulesetBase.GetHDGameState
	struct AHDBaseGameMode* GetHDGameMode(); // Function HDMain.HDGameRulesetBase.GetHDGameMode
}; 



// Class HDMain.HDKitPrerequisite_TeamSpecific
// Size: 0x48(Inherited: 0x40) 
struct UHDKitPrerequisite_TeamSpecific : public UHDKitPrerequisiteBase
{
	uint8_t  RequiredTeam;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 



// Class HDMain.HDScoreboardBase
// Size: 0x250(Inherited: 0x238) 
struct UHDScoreboardBase : public UDFBaseMenu
{
	UHDScoreboardListingRowBase* ScoreboardListRowClass;  // 0x238(0x8)
	struct UPanelWidget* OpforPlayerList;  // 0x240(0x8)
	struct UPanelWidget* BluforPlayerList;  // 0x248(0x8)

	void ReceiveScoreboardListRowAdded(struct UHDScoreboardListingRowBase* NewListEntry); // Function HDMain.HDScoreboardBase.ReceiveScoreboardListRowAdded
}; 



// Class HDMain.HDGameState
// Size: 0x320(Inherited: 0x300) 
struct AHDGameState : public ADFBaseGameState
{
	float ReplicatedMinRespawnDelay;  // 0x300(0x4)
	char bReplicatedDisableSpawnKitRestrictions : 1;  // 0x304(0x1)
	char pad_772_1 : 7;  // 0x304(0x1)
	char pad_773[4];  // 0x305(0x4)
	int32_t BluforTickets;  // 0x308(0x4)
	int32_t OpforTickets;  // 0x30C(0x4)
	struct AHDTeamState* BluforTeamState;  // 0x310(0x8)
	struct AHDTeamState* OpforTeamState;  // 0x318(0x8)

	void RevokeTicketsFromTeam(uint8_t  TicketTeam, int32_t TicketsToRemove); // Function HDMain.HDGameState.RevokeTicketsFromTeam
	bool IsGameUsingTickets(); // Function HDMain.HDGameState.IsGameUsingTickets
	bool IsGameUsingPlayerSpawnKitRestrictions(struct AController* Controller); // Function HDMain.HDGameState.IsGameUsingPlayerSpawnKitRestrictions
	void GiveTicketsToTeam(uint8_t  TicketTeam, int32_t TicketsToAdd); // Function HDMain.HDGameState.GiveTicketsToTeam
	int32_t GetNumPlayersOnTeam(uint8_t  TeamToCheck); // Function HDMain.HDGameState.GetNumPlayersOnTeam
	void ClearTickets(); // Function HDMain.HDGameState.ClearTickets
}; 



// Class HDMain.HDGOAPAct_MoveToOrganic
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPAct_MoveToOrganic : public UHDGOAPActionBase
{

}; 



// Class HDMain.HDGOAPAct_DefendControlPoint
// Size: 0x98(Inherited: 0x98) 
struct UHDGOAPAct_DefendControlPoint : public UHDGOAPActionBase
{

}; 



// Class HDMain.HDGOAPComponent
// Size: 0x1D8(Inherited: 0x168) 
struct UHDGOAPComponent : public UGOAPComponent
{
	struct AHDAIController* HDAIOwner;  // 0x168(0x8)
	struct AHDPlayerCharacter* HDAICharOwner;  // 0x170(0x8)
	struct TArray<struct UHDAIHandlerBase*> AIHandlers;  // 0x178(0x10)
	struct UHDAINavigationHandler* NavigationHandler;  // 0x188(0x8)
	struct UHDAICaptureHandler* CaptureHandler;  // 0x190(0x8)
	struct UHDAICombatHandler* CombatHandler;  // 0x198(0x8)
	struct UHDAIBehaviorHandler* BehaviorHandler;  // 0x1A0(0x8)
	struct UHDAIGroupBehaviorHandler* GroupBehaviorHandler;  // 0x1A8(0x8)
	struct UHDAIAimingHandler* AimingHandler;  // 0x1B0(0x8)
	struct UHDAIVocalHandler* VocalHandler;  // 0x1B8(0x8)
	char pad_448[16];  // 0x1C0(0x10)
	float DecisionFrequency;  // 0x1D0(0x4)
	char pad_468[4];  // 0x1D4(0x4)

	void TargetPerceptionUpdated(struct AActor* Actor, struct FAIStimulus Stimulus); // Function HDMain.HDGOAPComponent.TargetPerceptionUpdated
	void ResetPlanningTimer(); // Function HDMain.HDGOAPComponent.ResetPlanningTimer
	bool IsAIActiveInWorld(); // Function HDMain.HDGOAPComponent.IsAIActiveInWorld
	bool IsAIActive(); // Function HDMain.HDGOAPComponent.IsAIActive
	struct UHDAIHandlerBase* GetAIHandler(UHDAIHandlerBase* HandlerClass); // Function HDMain.HDGOAPComponent.GetAIHandler
}; 



// Class HDMain.HDGOAPGoalBase
// Size: 0x68(Inherited: 0x68) 
struct UHDGOAPGoalBase : public UGOAPGoal
{

}; 



// Class HDMain.HDKitPrerequisite_TeamUsageLimit
// Size: 0x48(Inherited: 0x40) 
struct UHDKitPrerequisite_TeamUsageLimit : public UHDKitPrerequisiteBase
{
	int32_t MaxTeamMembers;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 



// Class HDMain.HDKitPrerequisite_SquadLeaderOnly
// Size: 0x40(Inherited: 0x40) 
struct UHDKitPrerequisite_SquadLeaderOnly : public UHDKitPrerequisiteBase
{

}; 



// Class HDMain.HDJoinGameMenu
// Size: 0x280(Inherited: 0x238) 
struct UHDJoinGameMenu : public UDFBaseMenu
{
	struct UHDServerListView* ServerList;  // 0x238(0x8)
	struct TArray<struct FPrimaryAssetId> MapIds;  // 0x240(0x10)
	char pad_592[48];  // 0x250(0x30)

	void ReceiveOnRefreshStart(); // Function HDMain.HDJoinGameMenu.ReceiveOnRefreshStart
	void ReceiveOnRefreshComplete(bool bSortAscending, uint8_t  SortBy); // Function HDMain.HDJoinGameMenu.ReceiveOnRefreshComplete
	void OnRefresh(bool bSortAscending, uint8_t  SortBy); // Function HDMain.HDJoinGameMenu.OnRefresh
	void JoinGame(struct UHDServerListItemData* ServerItem, struct FString JoinPassword); // Function HDMain.HDJoinGameMenu.JoinGame
	bool IsUsingDebugServerListings(); // Function HDMain.HDJoinGameMenu.IsUsingDebugServerListings
}; 



// Class HDMain.HDKitPrerequisite_AlwaysDisable
// Size: 0x40(Inherited: 0x40) 
struct UHDKitPrerequisite_AlwaysDisable : public UHDKitPrerequisiteBase
{

}; 



// Class HDMain.HDEmptyServerFilterRule
// Size: 0x28(Inherited: 0x28) 
struct UHDEmptyServerFilterRule : public UHDServerListFilterRule
{

}; 



// Class HDMain.HDGOAPGoal_CaptureControlPoint
// Size: 0x78(Inherited: 0x68) 
struct UHDGOAPGoal_CaptureControlPoint : public UHDGOAPGoalBase
{
	struct AHDBaseCapturePoint* CPToCaptureCurrent;  // 0x68(0x8)
	struct AHDBaseCapturePoint* CPToCapturePending;  // 0x70(0x8)

}; 



// Class HDMain.HDServerListView
// Size: 0x3C0(Inherited: 0x368) 
struct UHDServerListView : public UListView
{
	char pad_872[4];  // 0x368(0x4)
	char pad_876_1 : 7;  // 0x36C(0x1)
	bool bItemSortAscending : 1;  // 0x36C(0x1)
	uint8_t  ItemSortBy;  // 0x36D(0x1)
	char pad_878[2];  // 0x36E(0x2)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> ItemFilterRules;  // 0x370(0x50)

	void SortListItems(bool bSortAscending, uint8_t  SortBy); // Function HDMain.HDServerListView.SortListItems
	void SetItemSortBy(uint8_t  SortBy); // Function HDMain.HDServerListView.SetItemSortBy
	void SetItemSortAscending(bool bSortAscending); // Function HDMain.HDServerListView.SetItemSortAscending
	void SetItemFilterRules(struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams>& FilterRules); // Function HDMain.HDServerListView.SetItemFilterRules
	float GetEntrySpacing(); // Function HDMain.HDServerListView.GetEntrySpacing
	struct FMargin GetDesiredEntryPaddingForItem(struct UObject* Item); // Function HDMain.HDServerListView.GetDesiredEntryPaddingForItem
	bool DoesFilterExcludeListItem(struct UObject* Item); // Function HDMain.HDServerListView.DoesFilterExcludeListItem
}; 



// Class HDMain.HDKitPrerequisiteBase
// Size: 0x40(Inherited: 0x28) 
struct UHDKitPrerequisiteBase : public UObject
{
	struct FText KitDenialReason;  // 0x28(0x18)

}; 



// Class HDMain.HDKitPrerequisite_SquadUsageLimit
// Size: 0x48(Inherited: 0x40) 
struct UHDKitPrerequisite_SquadUsageLimit : public UHDKitPrerequisiteBase
{
	int32_t MaxSquadMembers;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 



// Class HDMain.HDModData
// Size: 0x48(Inherited: 0x30) 
struct UHDModData : public UHDCoreUGCData
{
	struct TArray<struct FHDPrimaryAssetSearchPath> PrimaryAssetPathsToScan;  // 0x30(0x10)
	uint32_t ModDataVersion;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

	bool DoesModPluginUseLegacyMapScanning(struct FString PluginName); // Function HDMain.HDModData.DoesModPluginUseLegacyMapScanning
}; 



// Class HDMain.HDPlayerStart
// Size: 0x250(Inherited: 0x250) 
struct AHDPlayerStart : public APlayerStart
{

	struct UCapsuleComponent* K2_GetCapsuleComponent(); // Function HDMain.HDPlayerStart.K2_GetCapsuleComponent
}; 



// Class HDMain.HDNavigationSystem
// Size: 0x538(Inherited: 0x538) 
struct UHDNavigationSystem : public UDFNavigationSystem
{

}; 



// Class HDMain.HDOnlineSessionClient
// Size: 0x1A8(Inherited: 0x1A8) 
struct UHDOnlineSessionClient : public UDFOnlineSessionClient
{

}; 



// Class HDMain.HDPhysicsCollisionHandler
// Size: 0x40(Inherited: 0x40) 
struct UHDPhysicsCollisionHandler : public UDFPhysicsCollisionHandler
{

}; 



// Class HDMain.HDPlatoonCreationRuleBase
// Size: 0x28(Inherited: 0x28) 
struct UHDPlatoonCreationRuleBase : public UObject
{

	bool SatisfiesRule(struct UHDTeamDefinition* TeamDef); // Function HDMain.HDPlatoonCreationRuleBase.SatisfiesRule
}; 



// Class HDMain.HDPlatoonInfo
// Size: 0x68(Inherited: 0x30) 
struct UHDPlatoonInfo : public UPrimaryDataAsset
{
	struct FPrimaryAssetType PlatoonType;  // 0x30(0x8)
	struct TArray<struct UHDPlatoonCreationRuleBase*> CreationRules;  // 0x38(0x10)
	struct FText DisplayName;  // 0x48(0x18)
	int32_t MaxSquadLimit;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

	bool ShouldCreateForTeam(struct UHDTeamDefinition* TeamDef); // Function HDMain.HDPlatoonInfo.ShouldCreateForTeam
}; 



// Class HDMain.HDRuleset_AAS
// Size: 0x60(Inherited: 0x60) 
struct UHDRuleset_AAS : public UHDGameRulesetBase
{

}; 



// Class HDMain.HDPlatoonState
// Size: 0x3F0(Inherited: 0x220) 
struct AHDPlatoonState : public ADFReplInfo
{
	char pad_544[8];  // 0x220(0x8)
	struct FMulticastInlineDelegate OnSquadAdded;  // 0x228(0x10)
	struct FMulticastInlineDelegate OnSquadPreRemove;  // 0x238(0x10)
	AHDSquadState* SquadStateClass;  // 0x248(0x8)
	struct FDFGenericObjectContainer Squads;  // 0x250(0x180)
	char bInitialized : 1;  // 0x3D0(0x1)
	char pad_976_1 : 7;  // 0x3D0(0x1)
	char pad_977[4];  // 0x3D1(0x4)
	int32_t ID;  // 0x3D4(0x4)
	struct UHDPlatoonInfo* Info;  // 0x3D8(0x8)
	char TeamId;  // 0x3E0(0x1)
	char pad_993[7];  // 0x3E1(0x7)
	struct AHDTeamState* OwnerTeam;  // 0x3E8(0x8)

	bool SquadExists(struct AHDSquadState* Squad, bool bIgnorePendingRemoval); // Function HDMain.HDPlatoonState.SquadExists
	void RemoveSquadAt(int32_t RemoveIdx); // Function HDMain.HDPlatoonState.RemoveSquadAt
	void RemoveSquad(struct AHDSquadState* SquadToRemove); // Function HDMain.HDPlatoonState.RemoveSquad
	void RemoveFromOwner(); // Function HDMain.HDPlatoonState.RemoveFromOwner
	void ReceiveSquadPreRemove(struct AHDSquadState* Squad); // Function HDMain.HDPlatoonState.ReceiveSquadPreRemove
	void ReceiveSquadAdded(struct AHDSquadState* Squad); // Function HDMain.HDPlatoonState.ReceiveSquadAdded
	bool IsSquadPendingRemovalFromPlatoon(struct AHDSquadState* Squad); // Function HDMain.HDPlatoonState.IsSquadPendingRemovalFromPlatoon
	bool HasReachedMaxSquadLimit(); // Function HDMain.HDPlatoonState.HasReachedMaxSquadLimit
	struct AHDSquadState* GetSquadAt(int32_t Index, bool bIgnorePendingRemoval); // Function HDMain.HDPlatoonState.GetSquadAt
	int32_t GetNumSquads(bool bValidSquadsOnly); // Function HDMain.HDPlatoonState.GetNumSquads
	int32_t GetMaxSquadLimit(); // Function HDMain.HDPlatoonState.GetMaxSquadLimit
	bool FindSquadByName(struct FText& SquadDisplayName, struct AHDSquadState*& OutFoundSquad); // Function HDMain.HDPlatoonState.FindSquadByName
	void DumpSquadState(); // Function HDMain.HDPlatoonState.DumpSquadState
	struct AHDSquadState* AddSquad(struct FText& SquadDisplayName, struct AHDPlayerState* SquadLeader, bool bStartLocked); // Function HDMain.HDPlatoonState.AddSquad
}; 



// Class HDMain.HDPlayerCameraManager
// Size: 0x2740(Inherited: 0x2740) 
struct AHDPlayerCameraManager : public ADFPlayerCameraManager
{

}; 



// Class HDMain.HDPlayerCharacter
// Size: 0xA40(Inherited: 0x970) 
struct AHDPlayerCharacter : public ADFBasePlayerCharacter
{
	char pad_2416_1 : 7;  // 0x970(0x1)
	bool bUseAttachedVehicleRelevancy : 1;  // 0x970(0x1)
	char pad_2417[3];  // 0x971(0x3)
	float WalkingBobSpeed;  // 0x974(0x4)
	char bDoHeadBob : 1;  // 0x978(0x1)
	char bAllowFreeAim : 1;  // 0x978(0x1)
	char bAllowFreeAimWhileAiming : 1;  // 0x978(0x1)
	char bDoFreeAim : 1;  // 0x978(0x1)
	char pad_2424_1 : 4;  // 0x978(0x1)
	char pad_2425[8];  // 0x979(0x8)
	struct FDFCharacterVariationDataHandle VariationHandle;  // 0x980(0x18)
	struct USpringArmComponent* SpringArm;  // 0x998(0x8)
	struct USpringArmComponent* FreeAimSpringArm;  // 0x9A0(0x8)
	struct UHDKit* CurrentLoadout;  // 0x9A8(0x8)
	AHDBasePickup_Kit* KitClassFallback;  // 0x9B0(0x8)
	float KitDropTraceDistance;  // 0x9B8(0x4)
	char bInventoryMenuShown : 1;  // 0x9BC(0x1)
	char pad_2492_1 : 7;  // 0x9BC(0x1)
	char pad_2493[4];  // 0x9BD(0x4)
	struct FMulticastInlineDelegate OnAimStyleChanged;  // 0x9C0(0x10)
	uint8_t  AimStyle;  // 0x9D0(0x1)
	char pad_2513[7];  // 0x9D1(0x7)
	struct AHDTeamState* HDTeamState;  // 0x9D8(0x8)
	struct UAudioComponent* AIVocalAC;  // 0x9E0(0x8)
	UCameraShake* WalkingHeadBob;  // 0x9E8(0x8)
	UCameraShake* SprintingHeadBob;  // 0x9F0(0x8)
	char bCanAddYawInput : 1;  // 0x9F8(0x1)
	char bCanAddPitchInput : 1;  // 0x9F8(0x1)
	char bCanAddRollInput : 1;  // 0x9F8(0x1)
	char pad_2552_1 : 5;  // 0x9F8(0x1)
	char pad_2553[4];  // 0x9F9(0x4)
	float FreeAimDeadzoneCameraSpeedFactor;  // 0x9FC(0x4)
	float FreeAimReturnToCenterInterpSpeed;  // 0xA00(0x4)
	float MaxFreeAimYaw;  // 0xA04(0x4)
	float MaxFreeAimPitch;  // 0xA08(0x4)
	float MaxFreeAimYawADS;  // 0xA0C(0x4)
	float MaxFreeAimPitchADS;  // 0xA10(0x4)
	float CurrentFreeAimYaw;  // 0xA14(0x4)
	float CurrentFreeAimPitch;  // 0xA18(0x4)
	float FreeAimMouseDeltaX;  // 0xA1C(0x4)
	float FreeAimMouseDeltaY;  // 0xA20(0x4)
	float FreeAimExternalDeltaX;  // 0xA24(0x4)
	float FreeAimExternalDeltaY;  // 0xA28(0x4)
	uint8_t  LastAIVocalization;  // 0xA2C(0x1)
	char pad_2605[3];  // 0xA2D(0x3)
	struct UHDAIPerceptionComponent* HDAIPerceptionComponent;  // 0xA30(0x8)
	char pad_2616[8];  // 0xA38(0x8)

	void VariationDataChangedInternal(struct FDFCharacterVariationDataHandle PreviousHandle); // Function HDMain.HDPlayerCharacter.VariationDataChangedInternal
	void SetVariationHandle(struct FDFCharacterVariationDataHandle InVariationHandle); // Function HDMain.HDPlayerCharacter.SetVariationHandle
	void SetMaxFreeAimYawADS(float NewYaw); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimYawADS
	void SetMaxFreeAimYaw(float NewYaw); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimYaw
	void SetMaxFreeAimPitchADS(float NewPitch); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimPitchADS
	void SetMaxFreeAimPitch(float NewPitch); // Function HDMain.HDPlayerCharacter.SetMaxFreeAimPitch
	void SetFreeAimReturnToCenterInterpSpeed(float NewInterpSpeed); // Function HDMain.HDPlayerCharacter.SetFreeAimReturnToCenterInterpSpeed
	void SetFreeAimDeadzoneCameraSpeedFactor(float NewSpeedFactor); // Function HDMain.HDPlayerCharacter.SetFreeAimDeadzoneCameraSpeedFactor
	void SetAllowFreeAimADS(bool bEnabled); // Function HDMain.HDPlayerCharacter.SetAllowFreeAimADS
	void SetAllowFreeAim(bool bEnabled); // Function HDMain.HDPlayerCharacter.SetAllowFreeAim
	void SetAimStyle(uint8_t  InAimStyle, bool bFromPlayerInput); // Function HDMain.HDPlayerCharacter.SetAimStyle
	void ReceiveVoipTalkerMsgReceived(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function HDMain.HDPlayerCharacter.ReceiveVoipTalkerMsgReceived
	void ReceiveVariationDataChanged(struct FDFCharacterVariationData& NewVariation, struct FDFCharacterVariationData& PreviousVariation); // Function HDMain.HDPlayerCharacter.ReceiveVariationDataChanged
	void ReceiveFreeAim(float DeltaSeconds); // Function HDMain.HDPlayerCharacter.ReceiveFreeAim
	void ReceiveCurrentLoadout(); // Function HDMain.HDPlayerCharacter.ReceiveCurrentLoadout
	void ReceiveAimStyleChanged(uint8_t  NewAimStyle, uint8_t  PrevAimStyle, bool bFromPlayerInput); // Function HDMain.HDPlayerCharacter.ReceiveAimStyleChanged
	void PlayVocalSoundAI(struct USoundBase* SoundToUse, uint8_t  VocalType, float PitchMultiplier); // Function HDMain.HDPlayerCharacter.PlayVocalSoundAI
	void OnRep_CurrentLoadout(); // Function HDMain.HDPlayerCharacter.OnRep_CurrentLoadout
	void OnPickupKit(struct AHDBasePickup_Kit* Kit); // Function HDMain.HDPlayerCharacter.OnPickupKit
	void NotifyPlayerStateChanged(struct APlayerState* NewPlayerState, struct APlayerState* OldPlayerState); // Function HDMain.HDPlayerCharacter.NotifyPlayerStateChanged
	bool IsInVehicle(); // Function HDMain.HDPlayerCharacter.IsInVehicle
	void HeadBob(); // Function HDMain.HDPlayerCharacter.HeadBob
	struct UHDPlayerComponent* GetPlayerComponent(); // Function HDMain.HDPlayerCharacter.GetPlayerComponent
	float GetMaxFreeAimYawToUse(); // Function HDMain.HDPlayerCharacter.GetMaxFreeAimYawToUse
	float GetMaxFreeAimPitchToUse(); // Function HDMain.HDPlayerCharacter.GetMaxFreeAimPitchToUse
	AHDBasePickup_Kit* GetKitClassToUse(); // Function HDMain.HDPlayerCharacter.GetKitClassToUse
	void FreeAim(float DeltaSeconds); // Function HDMain.HDPlayerCharacter.FreeAim
	bool EquipPrimaryItem(); // Function HDMain.HDPlayerCharacter.EquipPrimaryItem
	void DropKit(); // Function HDMain.HDPlayerCharacter.DropKit
}; 



// Class HDMain.HDPlayerCharacterAnimInstanceBase
// Size: 0x2E0(Inherited: 0x2C0) 
struct UHDPlayerCharacterAnimInstanceBase : public UDFCharacterAnimInstance
{
	struct AHDPlayerCharacter* HDPlyCharOwner;  // 0x2B8(0x8)
	struct AHDPlayerController* HDPCOwner;  // 0x2C0(0x8)
	struct AHDBaseWeapon* HDEquippedWeapon;  // 0x2C8(0x8)
	char bInVehicle : 1;  // 0x2D0(0x1)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	char pad_729[8];  // 0x2D9(0x8)

}; 



// Class HDMain.HDPlayerCharacterAnimInst_FPP
// Size: 0x2E0(Inherited: 0x2E0) 
struct UHDPlayerCharacterAnimInst_FPP : public UHDPlayerCharacterAnimInstanceBase
{

}; 



// Class HDMain.HDPlayerCharacterAnimInst_TPP
// Size: 0x2E0(Inherited: 0x2E0) 
struct UHDPlayerCharacterAnimInst_TPP : public UHDPlayerCharacterAnimInstanceBase
{

}; 



// Class HDMain.HDPlayerComponent
// Size: 0xD0(Inherited: 0xC8) 
struct UHDPlayerComponent : public UDFPlayerComponent
{
	struct UDFLoadout* StartLoadout;  // 0xC8(0x8)

	void SwitchTeam(); // Function HDMain.HDPlayerComponent.SwitchTeam
	void RestartPlayerAtStartSpot(struct AActor* DesiredStartSpot, struct UDFLoadout* DesiredStartLoadout); // Function HDMain.HDPlayerComponent.RestartPlayerAtStartSpot
	void PickTeam(uint8_t  DesiredTeam); // Function HDMain.HDPlayerComponent.PickTeam
}; 



// Class HDMain.HDPlayerState
// Size: 0x3A8(Inherited: 0x378) 
struct AHDPlayerState : public ADFBasePlayerState
{
	struct UHDKit* SpawnLoadout;  // 0x378(0x8)
	struct UHDKit* CurrentLoadout;  // 0x380(0x8)
	struct FHDSquadAssignmentInfo SquadInfo;  // 0x388(0x10)
	struct FMulticastInlineDelegate OnPlayerSquadInfoUpdated;  // 0x398(0x10)

	void UnregisterFromSquad(); // Function HDMain.HDPlayerState.UnregisterFromSquad
	void OnRep_SquadInfo(); // Function HDMain.HDPlayerState.OnRep_SquadInfo
	void OnRep_SpawnLoadout(struct UHDKit* PrevSpawnLoadout); // Function HDMain.HDPlayerState.OnRep_SpawnLoadout
	void OnRep_CurrentLoadout(struct UHDKit* PrevLoadout); // Function HDMain.HDPlayerState.OnRep_CurrentLoadout
	void AssignSpawnLoadout(struct UHDKit* NewSpawnLoadout); // Function HDMain.HDPlayerState.AssignSpawnLoadout
	void AssignCurrentLoadout(struct UHDKit* NewCurrentLoadout); // Function HDMain.HDPlayerState.AssignCurrentLoadout
}; 



// Class HDMain.HDProj_Bullet
// Size: 0x380(Inherited: 0x380) 
struct AHDProj_Bullet : public AHDBaseProjectile
{
	struct USphereComponent* ProjectileCollision;  // 0x378(0x8)

}; 



// Class HDMain.HDProj_Deployable
// Size: 0x380(Inherited: 0x380) 
struct AHDProj_Deployable : public AHDBaseProjectile
{

}; 



// Class HDMain.HDProj_Grenade
// Size: 0x390(Inherited: 0x380) 
struct AHDProj_Grenade : public AHDBaseProjectile
{
	float FuzeDelay;  // 0x37C(0x4)
	float PayloadPostTriggerLifeSpan;  // 0x380(0x4)
	float PayloadServerActivationTime;  // 0x384(0x4)
	char pad_908[4];  // 0x38C(0x4)

	void OnRep_PayloadServerActivationTime(); // Function HDMain.HDProj_Grenade.OnRep_PayloadServerActivationTime
}; 



// Class HDMain.HDProj_SpawnPointDeployable
// Size: 0x390(Inherited: 0x380) 
struct AHDProj_SpawnPointDeployable : public AHDProj_Deployable
{
	uint8_t  Team;  // 0x380(0x1)
	char pad_897[15];  // 0x381(0xF)

}; 



// Class HDMain.HDRuleset_KillDeath
// Size: 0xB0(Inherited: 0x60) 
struct UHDRuleset_KillDeath : public UHDGameRulesetBase
{
	struct FKillDeathRulesetSettings BluforTeamKDSettings;  // 0x60(0x28)
	struct FKillDeathRulesetSettings OpforTeamKDSettings;  // 0x88(0x28)

	void PlayerTeamKilled(struct AController* Killer, struct AController* Victim); // Function HDMain.HDRuleset_KillDeath.PlayerTeamKilled
	struct FKillDeathRulesetSettings GetKillDeathSettingsForTeam(uint8_t  KillDeathTeam); // Function HDMain.HDRuleset_KillDeath.GetKillDeathSettingsForTeam
}; 



// Class HDMain.HDRecastNavMesh
// Size: 0x4B8(Inherited: 0x4B8) 
struct AHDRecastNavMesh : public ADFRecastNavMesh
{

}; 



// Class HDMain.HDRuleset_ControlPoint
// Size: 0xA0(Inherited: 0x60) 
struct UHDRuleset_ControlPoint : public UHDGameRulesetBase
{
	struct FControlPointRulesetSettings BluforTeamCPSettings;  // 0x60(0x20)
	struct FControlPointRulesetSettings OpforTeamCPSettings;  // 0x80(0x20)

	struct FControlPointRulesetSettings GetControlPointSettingsForTeam(uint8_t  ControlPointTeam); // Function HDMain.HDRuleset_ControlPoint.GetControlPointSettingsForTeam
	void ControlPointTeamUpdated(struct AHDBaseCapturePoint* ControlPoint, uint8_t  PrevTeam, uint8_t  NewTeam, bool bCaptured); // Function HDMain.HDRuleset_ControlPoint.ControlPointTeamUpdated
	void ControlPointCaptureProgressUpdated(struct AHDBaseCapturePoint* ControlPoint, bool bContested, int32_t Progress); // Function HDMain.HDRuleset_ControlPoint.ControlPointCaptureProgressUpdated
}; 



// Class HDMain.HDRuleset_NoPlayerSpawnKitRestrictions
// Size: 0x60(Inherited: 0x60) 
struct UHDRuleset_NoPlayerSpawnKitRestrictions : public UHDGameRulesetBase
{

}; 



// Class HDMain.HDRuleset_TicketBleed
// Size: 0x90(Inherited: 0x60) 
struct UHDRuleset_TicketBleed : public UHDGameRulesetBase
{
	char pad_96[8];  // 0x60(0x8)
	struct TArray<struct AHDBaseCapturePoint*> RegisteredCPs;  // 0x68(0x10)
	struct FTicketBleedRulesetSettings BluforTeamTBSettings;  // 0x78(0xC)
	struct FTicketBleedRulesetSettings OpforTeamTBSettings;  // 0x84(0xC)

	void UpdateTicketBleedState(); // Function HDMain.HDRuleset_TicketBleed.UpdateTicketBleedState
	struct FTicketBleedRulesetSettings GetTicketBleedSettingsForTeam(uint8_t  TicketBleedTeam); // Function HDMain.HDRuleset_TicketBleed.GetTicketBleedSettingsForTeam
	void ControlPointTeamUpdated(struct AHDBaseCapturePoint* ControlPoint, uint8_t  PrevTeam, uint8_t  NewTeam, bool bCaptured); // Function HDMain.HDRuleset_TicketBleed.ControlPointTeamUpdated
	void ApplyTicketBleed(uint8_t  BleedTeam, int32_t TicketBleedMultiplier, bool bUseMercyTicketBleed); // Function HDMain.HDRuleset_TicketBleed.ApplyTicketBleed
}; 



// Class HDMain.HDVoipIndicatorWidgetBase
// Size: 0x280(Inherited: 0x230) 
struct UHDVoipIndicatorWidgetBase : public UUserWidget
{
	struct TMap<struct FUniqueNetIdVoipWrapper, struct UHDVoiceChatMsgInfo*> ActiveTalkerMap;  // 0x230(0x50)

	void OnPlayerStopTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnPlayerStopTalking
	void OnPlayerStartTalking(struct UHDVoiceChatMsgInfo* TalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnPlayerStartTalking
	void OnOwningPlayerStopTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnOwningPlayerStopTalking
	void OnOwningPlayerStartTalking(struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo); // Function HDMain.HDVoipIndicatorWidgetBase.OnOwningPlayerStartTalking
}; 



// Class HDMain.HDServerAtCapacityFilterRule
// Size: 0x28(Inherited: 0x28) 
struct UHDServerAtCapacityFilterRule : public UHDServerListFilterRule
{

}; 



// Class HDMain.HDPasswordProtectedServerFilterRule
// Size: 0x28(Inherited: 0x28) 
struct UHDPasswordProtectedServerFilterRule : public UHDServerListFilterRule
{

}; 



// Class HDMain.HDSupportersOnlyServerFilterRule
// Size: 0x28(Inherited: 0x28) 
struct UHDSupportersOnlyServerFilterRule : public UHDServerListFilterRule
{

}; 



// Class HDMain.HDHasUGCServerFilterRule
// Size: 0x28(Inherited: 0x28) 
struct UHDHasUGCServerFilterRule : public UHDServerListFilterRule
{

}; 



// Class HDMain.HDContainsAddressServerFilterRule
// Size: 0x28(Inherited: 0x28) 
struct UHDContainsAddressServerFilterRule : public UHDServerListFilterRule
{

}; 



// Class HDMain.HDServerListItemData
// Size: 0xC8(Inherited: 0x28) 
struct UHDServerListItemData : public UObject
{
	struct FHDServerInfo ServerInfo;  // 0x28(0xA0)

}; 



// Class HDMain.HDServerListing
// Size: 0x270(Inherited: 0x230) 
struct UHDServerListing : public UUserWidget
{
	char bTextToUpper : 1;  // 0x230(0x1)
	char pad_560_1 : 7;  // 0x230(0x1)
	char pad_561[8];  // 0x231(0x8)
	struct UHDServerListItemData* ServerData;  // 0x238(0x8)
	struct UTextBlock* ServerNameText;  // 0x240(0x8)
	struct UTextBlock* ModNameText;  // 0x248(0x8)
	struct UTextBlock* GameModeText;  // 0x250(0x8)
	struct UTextBlock* MapNameText;  // 0x258(0x8)
	struct UTextBlock* PlayersText;  // 0x260(0x8)
	struct UTextBlock* PingText;  // 0x268(0x8)

	void SetupListing(struct UHDServerListItemData* InServerItemData); // Function HDMain.HDServerListing.SetupListing
	void OnServerItemDataSet(bool bIsDesignTime); // Function HDMain.HDServerListing.OnServerItemDataSet
}; 



// Class HDMain.HDSquadStateCreationPayload
// Size: 0x58(Inherited: 0x28) 
struct UHDSquadStateCreationPayload : public UObject
{
	struct FHDSquadCreationParams CreationParams;  // 0x28(0x30)

}; 



// Class HDMain.HDSQCommChannelState
// Size: 0x58(Inherited: 0x28) 
struct UHDSQCommChannelState : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct AHDSquadState* SquadState;  // 0x30(0x8)
	struct FDFCommStateSetupParams InitialSetupParams;  // 0x38(0x18)
	char pad_80[8];  // 0x50(0x8)

	void SetupSQChannelState(struct AHDSquadState* ForSquadState); // Function HDMain.HDSQCommChannelState.SetupSQChannelState
	struct FName GetChannelNameForSquad(struct AHDSquadState* Squad); // Function HDMain.HDSQCommChannelState.GetChannelNameForSquad
}; 



// Class HDMain.HDSquadHiddenState
// Size: 0x230(Inherited: 0x220) 
struct AHDSquadHiddenState : public AInfo
{
	char pad_544[8];  // 0x220(0x8)
	struct AHDSquadState* SquadStateOwner;  // 0x228(0x8)

}; 



// Class HDMain.HDSquadState
// Size: 0x460(Inherited: 0x220) 
struct AHDSquadState : public ADFReplInfo
{
	char pad_544[8];  // 0x220(0x8)
	char bInitialized : 1;  // 0x228(0x1)
	char pad_552_1 : 7;  // 0x228(0x1)
	char pad_553[8];  // 0x229(0x8)
	AHDSquadHiddenState* SquadHiddenStateClass;  // 0x230(0x8)
	int32_t ID;  // 0x238(0x4)
	char TeamId;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct AHDPlatoonState* OwnerPlatoon;  // 0x240(0x8)
	struct FText DisplayName;  // 0x248(0x18)
	struct AHDSquadHiddenState* SquadHiddenState;  // 0x260(0x8)
	struct AHDPlayerState* SquadLeader;  // 0x268(0x8)
	char bLocked : 1;  // 0x270(0x1)
	char pad_624_1 : 2;  // 0x270(0x1)
	char bRequiresSquadLeader : 1;  // 0x270(0x1)
	char bDisbandSquadOnEmpty : 1;  // 0x270(0x1)
	char pad_624_2 : 3;  // 0x270(0x1)
	char pad_625[8];  // 0x271(0x8)
	struct FMulticastInlineDelegate OnSquadLeaderAssigned;  // 0x278(0x10)
	struct FMulticastInlineDelegate OnSquadMemberRegistered;  // 0x288(0x10)
	struct FMulticastInlineDelegate OnSquadMemberPreUnregister;  // 0x298(0x10)
	struct FMulticastInlineDelegate OnSquadMemberInfoUpdated;  // 0x2A8(0x10)
	struct FMulticastInlineDelegate OnSquadRenamed;  // 0x2B8(0x10)
	struct FMulticastInlineDelegate OnSquadLockToggled;  // 0x2C8(0x10)
	struct FDFGenericObjectContainer SquadMembers;  // 0x2D8(0x180)
	int32_t MaxSquadMemberLimit;  // 0x458(0x4)
	char pad_1116[4];  // 0x45C(0x4)

	bool UnregisterSquadMemberAt(int32_t RemoveIdx); // Function HDMain.HDSquadState.UnregisterSquadMemberAt
	bool UnregisterSquadMember(struct AHDPlayerState* MemberPSToRemove); // Function HDMain.HDSquadState.UnregisterSquadMember
	bool UnregisterPlayerSquadMember(struct AHDPlayerController* MemberPCToRemove); // Function HDMain.HDSquadState.UnregisterPlayerSquadMember
	void UnlockSquad(); // Function HDMain.HDSquadState.UnlockSquad
	void SquadMemberPSTeamUpdated(struct APlayerState* MemberPS, char LastTeamNum, char NewTeamNum); // Function HDMain.HDSquadState.SquadMemberPSTeamUpdated
	void SquadMemberPSSquadUpdated(struct AHDPlayerState* MemberPS, struct FHDSquadAssignmentInfo& MemberSQInfo); // Function HDMain.HDSquadState.SquadMemberPSSquadUpdated
	void SquadMemberPSEndPlay(struct AActor* Actor, char EEndPlayReason EndPlayReason); // Function HDMain.HDSquadState.SquadMemberPSEndPlay
	void RenameSquad(struct FText& NewDisplayName); // Function HDMain.HDSquadState.RenameSquad
	void RemoveFromOwner(); // Function HDMain.HDSquadState.RemoveFromOwner
	bool RegisterSquadMember(struct AHDPlayerState* NewMemberPS); // Function HDMain.HDSquadState.RegisterSquadMember
	bool RegisterPlayerSquadMember(struct AHDPlayerController* NewMemberPC); // Function HDMain.HDSquadState.RegisterPlayerSquadMember
	void ReceiveSquadUnlocked(); // Function HDMain.HDSquadState.ReceiveSquadUnlocked
	void ReceiveSquadRenamed(struct FText& NewName, struct FText& PrevName); // Function HDMain.HDSquadState.ReceiveSquadRenamed
	void ReceiveSquadMemberRegistered(struct AHDPlayerState* MemberPS); // Function HDMain.HDSquadState.ReceiveSquadMemberRegistered
	void ReceiveSquadMemberPreUnregister(struct AHDPlayerState* MemberPS); // Function HDMain.HDSquadState.ReceiveSquadMemberPreUnregister
	void ReceiveSquadLocked(); // Function HDMain.HDSquadState.ReceiveSquadLocked
	void ReceiveSquadLeaderAssigned(struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function HDMain.HDSquadState.ReceiveSquadLeaderAssigned
	void ReceiveInit(struct FHDSquadCreationParams& CreationParams); // Function HDMain.HDSquadState.ReceiveInit
	void OnRep_SquadLeader(struct AHDPlayerState* PrevSquadLeader); // Function HDMain.HDSquadState.OnRep_SquadLeader
	void OnRep_SquadHiddenState(); // Function HDMain.HDSquadState.OnRep_SquadHiddenState
	void OnRep_DisplayName(struct FText& PrevDisplayName); // Function HDMain.HDSquadState.OnRep_DisplayName
	void OnRep_bLocked(); // Function HDMain.HDSquadState.OnRep_bLocked
	void LockSquad(); // Function HDMain.HDSquadState.LockSquad
	bool IsRegisteredSquadMember(struct AHDPlayerState* PS, bool bIgnorePendingRemoval); // Function HDMain.HDSquadState.IsRegisteredSquadMember
	bool IsPlayerRegisteredSquadMember(struct AHDPlayerController* PC, bool bIgnorePendingRemoval); // Function HDMain.HDSquadState.IsPlayerRegisteredSquadMember
	bool IsPlayerPendingRemovalFromSquad(struct AHDPlayerController* PC); // Function HDMain.HDSquadState.IsPlayerPendingRemovalFromSquad
	bool IsPendingRemovalFromSquad(struct AHDPlayerState* PS); // Function HDMain.HDSquadState.IsPendingRemovalFromSquad
	bool HasReachedMaxSquadMemberLimit(); // Function HDMain.HDSquadState.HasReachedMaxSquadMemberLimit
	struct AHDPlayerState* GetSquadMemberAt(int32_t Index, bool bIgnorePendingRemoval); // Function HDMain.HDSquadState.GetSquadMemberAt
	int32_t GetNumSquadMembersBots(bool bValidMembersOnly); // Function HDMain.HDSquadState.GetNumSquadMembersBots
	int32_t GetNumSquadMembers(bool bValidMembersOnly); // Function HDMain.HDSquadState.GetNumSquadMembers
	void DumpSquadMemberState(); // Function HDMain.HDSquadState.DumpSquadMemberState
	bool CanRegisterSquadMember(struct AHDPlayerState* NewMemberPS); // Function HDMain.HDSquadState.CanRegisterSquadMember
	bool CanRegisterPlayerSquadMember(struct AHDPlayerController* NewMemberPC); // Function HDMain.HDSquadState.CanRegisterPlayerSquadMember
	bool AssignSquadLeader(struct AHDPlayerState* NewLeaderPS); // Function HDMain.HDSquadState.AssignSquadLeader
}; 



// Class HDMain.HDTeamCommChannelState
// Size: 0x58(Inherited: 0x28) 
struct UHDTeamCommChannelState : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct AHDTeamState* TeamState;  // 0x30(0x8)
	struct FDFCommStateSetupParams InitialSetupParams;  // 0x38(0x18)
	char pad_80[8];  // 0x50(0x8)

	void SetupTeamChannelState(struct AHDTeamState* ForTeamState); // Function HDMain.HDTeamCommChannelState.SetupTeamChannelState
	struct FName GetChannelNameForTeam(struct AHDTeamState* Team); // Function HDMain.HDTeamCommChannelState.GetChannelNameForTeam
	struct FName GetChannelNameForCommand(struct AHDTeamState* CmdTeam); // Function HDMain.HDTeamCommChannelState.GetChannelNameForCommand
}; 



// Class HDMain.HDTeamState
// Size: 0x448(Inherited: 0x250) 
struct AHDTeamState : public ADFTeamState
{
	struct FMulticastInlineDelegate OnPlatoonAdded;  // 0x250(0x10)
	struct FMulticastInlineDelegate OnPlatoonPreRemove;  // 0x260(0x10)
	struct FDFGenericObjectContainer Platoons;  // 0x270(0x180)
	int32_t MaxPlatoonLimit;  // 0x3F0(0x4)
	char pad_1012[4];  // 0x3F4(0x4)
	struct TSet<struct UHDKit*> Kits;  // 0x3F8(0x50)

	void RemovePlatoonAt(int32_t RemoveIdx); // Function HDMain.HDTeamState.RemovePlatoonAt
	void RemovePlatoon(struct AHDPlatoonState* PlatoonToRemove); // Function HDMain.HDTeamState.RemovePlatoon
	void ReceivePlatoonPreRemove(struct AHDPlatoonState* Platoon); // Function HDMain.HDTeamState.ReceivePlatoonPreRemove
	void ReceivePlatoonAdded(struct AHDPlatoonState* Platoon); // Function HDMain.HDTeamState.ReceivePlatoonAdded
	bool PlatoonExists(struct AHDPlatoonState* Platoon, bool bIgnorePendingRemoval); // Function HDMain.HDTeamState.PlatoonExists
	bool IsPlatoonPendingRemovalFromTeam(struct AHDPlatoonState* Platoon); // Function HDMain.HDTeamState.IsPlatoonPendingRemovalFromTeam
	bool HasReachedMaxPlatoonLimit(); // Function HDMain.HDTeamState.HasReachedMaxPlatoonLimit
	uint8_t  GetTeam(); // Function HDMain.HDTeamState.GetTeam
	struct AHDPlatoonState* GetPlatoonAt(int32_t Index, bool bIgnorePendingRemoval); // Function HDMain.HDTeamState.GetPlatoonAt
	int32_t GetNumPlatoons(bool bValidPlatoonsOnly); // Function HDMain.HDTeamState.GetNumPlatoons
	bool FindPlatoonByName(struct FText& PlatoonDisplayName, struct AHDPlatoonState*& OutFoundPlatoon); // Function HDMain.HDTeamState.FindPlatoonByName
	bool FindPlatoonByDefinition(struct UHDPlatoonInfo* PlatoonDef, struct AHDPlatoonState*& OutFoundPlatoon); // Function HDMain.HDTeamState.FindPlatoonByDefinition
	void DumpPlatoonState(); // Function HDMain.HDTeamState.DumpPlatoonState
	struct AHDPlatoonState* AddPlatoon(struct UHDPlatoonInfo* PlatoonInfo); // Function HDMain.HDTeamState.AddPlatoon
}; 



// Class HDMain.HDTextChatInputWidgetBase
// Size: 0x240(Inherited: 0x230) 
struct UHDTextChatInputWidgetBase : public UUserWidget
{
	struct FName TextCommsFormatName;  // 0x230(0x8)
	struct UDFCommChannel* CurrentTalkChannel;  // 0x238(0x8)

	void SubmitChatMessage(struct FText ChatMsgText); // Function HDMain.HDTextChatInputWidgetBase.SubmitChatMessage
	void StopTalkingOnCurrentChannel(); // Function HDMain.HDTextChatInputWidgetBase.StopTalkingOnCurrentChannel
	void StopTalking(struct UDFCommChannel* CurrentChannel); // Function HDMain.HDTextChatInputWidgetBase.StopTalking
	void StartTalkingOnChannel(struct UDFCommChannel* TalkChannel); // Function HDMain.HDTextChatInputWidgetBase.StartTalkingOnChannel
	void StartTalking(struct UDFCommChannel* NewTalkChannel); // Function HDMain.HDTextChatInputWidgetBase.StartTalking
	void OnChatMessageSubmitted(struct UHDTextChatMsgInfo* SubmittedChatMsg); // Function HDMain.HDTextChatInputWidgetBase.OnChatMessageSubmitted
}; 



// Class HDMain.HDTextChatWidgetBase
// Size: 0x2A8(Inherited: 0x230) 
struct UHDTextChatWidgetBase : public UUserWidget
{
	char pad_560[56];  // 0x230(0x38)
	struct FName SayAllInputActionName;  // 0x268(0x8)
	struct FName SayTeamInputActionName;  // 0x270(0x8)
	struct FName SaySquadInputActionName;  // 0x278(0x8)
	struct FName SayAllChannelName;  // 0x280(0x8)
	int32_t MaxChatMsgsToCache;  // 0x288(0x4)
	struct FName LastTalkChannelName;  // 0x28C(0x8)
	char pad_660[4];  // 0x294(0x4)
	struct TArray<struct UHDTextChatMsgInfo*> CurrentChatMsgs;  // 0x298(0x10)

	void StopTalking(); // Function HDMain.HDTextChatWidgetBase.StopTalking
	void StartTalking(struct UDFCommChannel* TalkChannel); // Function HDMain.HDTextChatWidgetBase.StartTalking
	void SetMaxChatMsgsToCache(int32_t NumChatMsgsToCache); // Function HDMain.HDTextChatWidgetBase.SetMaxChatMsgsToCache
	void SayTeamActionPressed(); // Function HDMain.HDTextChatWidgetBase.SayTeamActionPressed
	void SaySquadActionPressed(); // Function HDMain.HDTextChatWidgetBase.SaySquadActionPressed
	void SayAllActionPressed(); // Function HDMain.HDTextChatWidgetBase.SayAllActionPressed
	int32_t GetNumCachedChatMsgs(); // Function HDMain.HDTextChatWidgetBase.GetNumCachedChatMsgs
	bool GetCachedChatMsgAt(int32_t MsgIndex, struct UHDTextChatMsgInfo*& OutFoundMsg); // Function HDMain.HDTextChatWidgetBase.GetCachedChatMsgAt
	void DisplayChatMessage(struct UHDTextChatMsgInfo* NewChatMsg); // Function HDMain.HDTextChatWidgetBase.DisplayChatMessage
}; 



// Class HDMain.HDURLStatics
// Size: 0x28(Inherited: 0x28) 
struct UHDURLStatics : public UBlueprintFunctionLibrary
{

	struct FString GetNumTicketsOptionName(uint8_t  Team); // Function HDMain.HDURLStatics.GetNumTicketsOptionName
	struct FString GetNumBotsOptionName(uint8_t  Team); // Function HDMain.HDURLStatics.GetNumBotsOptionName
	struct FString GetFactionOptionName(uint8_t  Team); // Function HDMain.HDURLStatics.GetFactionOptionName
	struct FString GetDisableKitRestrictionsOptionName(); // Function HDMain.HDURLStatics.GetDisableKitRestrictionsOptionName
}; 



// Class HDMain.HDUIStatics
// Size: 0x28(Inherited: 0x28) 
struct UHDUIStatics : public UBlueprintFunctionLibrary
{

	int32_t GetServerPort(struct FHDServerInfo& InServerInfo); // Function HDMain.HDUIStatics.GetServerPort
	struct FString GetServerIpPort(struct FHDServerInfo& InServerInfo); // Function HDMain.HDUIStatics.GetServerIpPort
	struct FString GetServerIp(struct FHDServerInfo& InServerInfo); // Function HDMain.HDUIStatics.GetServerIp
}; 



// Class HDMain.HDUIUWCaptureStatus
// Size: 0x268(Inherited: 0x238) 
struct UHDUIUWCaptureStatus : public UHDUIUserWidget
{
	char pad_568[48];  // 0x238(0x30)

	void OwnerTouchingControlPoint(struct AHDBaseCapturePoint* OverlappingCP, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.OwnerTouchingControlPoint
	void OwnerNoControlPoint(); // Function HDMain.HDUIUWCaptureStatus.OwnerNoControlPoint
	void OwnerEndOverlap(struct AActor* OverlappedOwnerChar, struct AActor* OtherActor); // Function HDMain.HDUIUWCaptureStatus.OwnerEndOverlap
	void OwnerBeginOverlap(struct AActor* OverlappedOwnerChar, struct AActor* OtherActor); // Function HDMain.HDUIUWCaptureStatus.OwnerBeginOverlap
	void CPOwnershipUpdate(struct AHDBaseCapturePoint* ControlPoint, uint8_t  PrevOwningTeam, uint8_t  NewOwningTeam, bool bCaptured); // Function HDMain.HDUIUWCaptureStatus.CPOwnershipUpdate
	void CPCaptureProgressUpdate(struct AHDBaseCapturePoint* ControlPoint, bool bInCaptureContested, int32_t InCaptureProgress); // Function HDMain.HDUIUWCaptureStatus.CPCaptureProgressUpdate
	void CPBeginEndOverlap(struct AActor* OverlappedControlPointActor, struct AActor* OtherActor); // Function HDMain.HDUIUWCaptureStatus.CPBeginEndOverlap
	void ControlPointSetOwnershipState(bool bCaptured, uint8_t  NewOwningTeam, uint8_t  OldOwningTeam, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.ControlPointSetOwnershipState
	void ControlPointSetGarrisonedPlayerCount(int32_t NumFriendlies, int32_t NumEnemies, int32_t MinNumRequiredForCapture, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.ControlPointSetGarrisonedPlayerCount
	void ControlPointSetCaptureProgress(bool bContested, float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWCaptureStatus.ControlPointSetCaptureProgress
}; 



// Class HDMain.HDUIUWHUD
// Size: 0x238(Inherited: 0x238) 
struct UHDUIUWHUD : public UHDUIUserWidget
{

}; 



// Class HDMain.HDUIUWPlayerStatus
// Size: 0x258(Inherited: 0x238) 
struct UHDUIUWPlayerStatus : public UHDUIUserWidget
{
	char pad_568[32];  // 0x238(0x20)

	void OwnerUpdateStamina(float SprintValueNorm, float JumpValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerUpdateStamina
	void OwnerStartSprint(); // Function HDMain.HDUIUWPlayerStatus.OwnerStartSprint
	void OwnerStartAim(); // Function HDMain.HDUIUWPlayerStatus.OwnerStartAim
	void OwnerSprintTransitionUpdate(bool bIsSprinting); // Function HDMain.HDUIUWPlayerStatus.OwnerSprintTransitionUpdate
	void OwnerSetStanceState(uint8_t  NewState, uint8_t  OldState, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetStanceState
	void OwnerSetStance(uint8_t  NewStance, uint8_t  OldStance, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetStance
	void OwnerSetSprintStamina(float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetSprintStamina
	void OwnerSetJumpStamina(float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetJumpStamina
	void OwnerSetHealth(float NewValueNorm, float OldValueNorm, bool bInitial); // Function HDMain.HDUIUWPlayerStatus.OwnerSetHealth
	void OwnerHealthUpdate(struct ADFBaseCharacter* Character, float NewHealthTotal, float PrevHealthTotal); // Function HDMain.HDUIUWPlayerStatus.OwnerHealthUpdate
	void OwnerEndSprint(); // Function HDMain.HDUIUWPlayerStatus.OwnerEndSprint
	void OwnerEndAim(); // Function HDMain.HDUIUWPlayerStatus.OwnerEndAim
	void OwnerAimTransitionUpdate(bool bIsAiming); // Function HDMain.HDUIUWPlayerStatus.OwnerAimTransitionUpdate
}; 



// Class HDMain.HDUIUWWeaponStatus
// Size: 0x260(Inherited: 0x238) 
struct UHDUIUWWeaponStatus : public UHDUIUserWidget
{
	struct AHDBaseWeapon* OwnerEquippedWeapon;  // 0x238(0x8)
	char pad_576[8];  // 0x240(0x8)
	struct FHDUIWeaponAmmoState WeapAmmoState;  // 0x248(0x18)

	void OwnerWeaponFireModeChanged(struct ADFBaseGun* Gun, uint8_t  NewFireMode, uint8_t  PrevFireMode, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.OwnerWeaponFireModeChanged
	void OwnerSetAimStyle(uint8_t  NewAimStyle, uint8_t  PrevAimStyle, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.OwnerSetAimStyle
	void OwnerAimStyleChanged(struct AHDPlayerCharacter* Character, uint8_t  NewAimStyle, uint8_t  PrevAimStyle, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.OwnerAimStyleChanged
	void BPOwnerWeaponSetFireMode(uint8_t  NewFireMode, uint8_t  PreviousFireMode, bool bFromPlayerInput); // Function HDMain.HDUIUWWeaponStatus.BPOwnerWeaponSetFireMode
	void BPOwnerWeaponAmmoUpdated(struct FHDUIWeaponAmmoState& AmmoState, bool bFromReload, bool bTotalFreeAmmoUpdated, bool bNumFreeAmmoClipsUpdated); // Function HDMain.HDUIUWWeaponStatus.BPOwnerWeaponAmmoUpdated
}; 



// Class HDMain.HDVehiclePlayerSeatComponent
// Size: 0x198(Inherited: 0x198) 
struct UHDVehiclePlayerSeatComponent : public UArcVehiclePlayerSeatComponent
{

}; 



// Class HDMain.HDVoiceChatMsgInfo
// Size: 0x40(Inherited: 0x28) 
struct UHDVoiceChatMsgInfo : public UObject
{
	struct UDFCommChannel* CommChannel;  // 0x28(0x8)
	struct APlayerState* TalkerPS;  // 0x30(0x8)
	char bTalking : 1;  // 0x38(0x1)
	char pad_56_1 : 7;  // 0x38(0x1)
	char pad_57[8];  // 0x39(0x8)

}; 



// Class HDMain.HDVoipIndicatorListingWidgetBase
// Size: 0x238(Inherited: 0x230) 
struct UHDVoipIndicatorListingWidgetBase : public UUserWidget
{
	struct UHDVoiceChatMsgInfo* VoiceMsgInfo;  // 0x230(0x8)

	void SetupVoiceListing(struct UHDVoiceChatMsgInfo* InVoiceMsgInfo); // Function HDMain.HDVoipIndicatorListingWidgetBase.SetupVoiceListing
	void OnVoiceMsgInfoSet(bool bIsDesignTime); // Function HDMain.HDVoipIndicatorListingWidgetBase.OnVoiceMsgInfoSet
}; 



// Class HDMain.HDWeaponAnimInstance
// Size: 0x280(Inherited: 0x280) 
struct UHDWeaponAnimInstance : public UDFWeaponAnimInstance
{
	struct AHDBaseWeapon* HDWeaponOwner;  // 0x278(0x8)

}; 



// Class HDMain.HDWorldSettings
// Size: 0x528(Inherited: 0x518) 
struct AHDWorldSettings : public ATBWorldSettings
{
	struct UHDTeamDefinition* BluforTeamDefinition;  // 0x518(0x8)
	struct UHDTeamDefinition* OpforTeamDefinition;  // 0x520(0x8)

}; 



// Class HDMain.PlatoonListEntry
// Size: 0x50(Inherited: 0x28) 
struct UPlatoonListEntry : public UObject
{
	char TeamId;  // 0x28(0x1)
	uint8_t  Team;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct AHDTeamState* TeamState;  // 0x30(0x8)
	int32_t ID;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UHDPlatoonInfo* Info;  // 0x40(0x8)
	struct AHDPlatoonState* PlatoonState;  // 0x48(0x8)

}; 



// Class HDMain.SquadListEntry
// Size: 0x50(Inherited: 0x28) 
struct USquadListEntry : public UObject
{
	char TeamId;  // 0x28(0x1)
	uint8_t  Team;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct AHDTeamState* TeamState;  // 0x30(0x8)
	struct UPlatoonListEntry* ParentPlatoonData;  // 0x38(0x8)
	int32_t ID;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct AHDSquadState* SquadState;  // 0x48(0x8)

	struct AHDPlatoonState* GetParentPlatoonState(); // Function HDMain.SquadListEntry.GetParentPlatoonState
}; 



// Class HDMain.VictoryMenu
// Size: 0x250(Inherited: 0x238) 
struct UVictoryMenu : public UDFBaseMenu
{
	struct FHDGameRoundEndEventDetails RoundDetails;  // 0x238(0x10)
	char bWinner : 1;  // 0x248(0x1)
	char pad_584_1 : 7;  // 0x248(0x1)
	char pad_585[8];  // 0x249(0x8)

	void OnVictoryInit(); // Function HDMain.VictoryMenu.OnVictoryInit
	void Init(struct FHDGameRoundEndEventDetails& InRoundDetails, bool bInWinner); // Function HDMain.VictoryMenu.Init
}; 



