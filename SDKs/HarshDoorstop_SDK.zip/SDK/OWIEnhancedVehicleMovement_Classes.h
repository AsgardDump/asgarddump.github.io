#pragma once 
#include <OWIEnhancedVehicleMovement_Structs.h>
 
 
 
// Class OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentNW
// Size: 0x408(Inherited: 0x290) 
struct UWheeledVehicleMovementComponentNW : public UWheeledVehicleMovementComponent
{
	struct FVehicleNWEngineData EngineSetup;  // 0x290(0xA0)
	struct TArray<struct FVehicleNWWheelDifferentialData> DifferentialSetup;  // 0x330(0x10)
	struct FVehicleNWTransmissionData TransmissionSetup;  // 0x340(0x40)
	struct FRuntimeFloatCurve SteeringCurve;  // 0x380(0x88)

}; 



// Class OWIEnhancedVehicleMovement.VehicleMovementTankVehicle
// Size: 0x290(Inherited: 0x290) 
struct AVehicleMovementTankVehicle : public AWheeledVehicle
{

}; 



// Class OWIEnhancedVehicleMovement.VehicleMovementNWheeledVehicle
// Size: 0x290(Inherited: 0x290) 
struct AVehicleMovementNWheeledVehicle : public AWheeledVehicle
{

}; 



// Class OWIEnhancedVehicleMovement.VehicleMovementWheelTracked
// Size: 0x100(Inherited: 0xF0) 
struct UVehicleMovementWheelTracked : public UVehicleWheel
{
	struct FVector SuspensionDirection;  // 0xF0(0xC)
	char pad_252[4];  // 0xFC(0x4)

}; 



// Class OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank
// Size: 0x3B8(Inherited: 0x290) 
struct UWheeledVehicleMovementComponentTank : public UWheeledVehicleMovementComponent
{
	struct FVehicleTankEngineData EngineSetup;  // 0x290(0xA0)
	struct FVehicleTankTransmissionData TransmissionSetup;  // 0x330(0x40)
	float RawBothTracksThrottleInput;  // 0x370(0x4)
	float RawLeftTrackThrottleInput;  // 0x374(0x4)
	float RawRightTrackThrottleInput;  // 0x378(0x4)
	float BothTracksThrottleInput;  // 0x37C(0x4)
	float LeftTrackThrottleInput;  // 0x380(0x4)
	float RightTrackThrottleInput;  // 0x384(0x4)
	struct TArray<float> WheelSpeeds;  // 0x388(0x10)
	struct TArray<float> WheelAngles;  // 0x398(0x10)
	float LeftTrackSpeed;  // 0x3A8(0x4)
	float RightTrackSpeed;  // 0x3AC(0x4)
	char pad_944[8];  // 0x3B0(0x8)

	void SetRightTrackThrottleInput(float InThrottle); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetRightTrackThrottleInput
	void SetLeftTrackThrottleInput(float InThrottle); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetLeftTrackThrottleInput
	void SetBothTracksThrottleInput(float InThrottle); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetBothTracksThrottleInput
	float GetRightTrackSpeed(); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.GetRightTrackSpeed
	float GetLeftTrackSpeed(); // Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.GetLeftTrackSpeed
}; 



