#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.ExecuteUbergraph_WBP_HUDElement_EquipmentSelect
// Size: 0x91(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUDElement_EquipmentSelect
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* Temp_object_Variable;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UWBP_EquipmentSelect_EqBox_C* K2Node_DynamicCast_AsWBP_Equipment_Select_Eq_Box;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct TSoftObjectPtr<UTexture2D> K2Node_CustomEvent_IconToLoad;  // 0x50(0x28)
	int32_t K2Node_CustomEvent_SlotNum;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct AHDBaseWeapon* K2Node_CustomEvent_EqpItem;  // 0x80(0x8)
	struct UObject* K2Node_CustomEvent_Loaded;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_IsSelectableEquipment_ReturnValue : 1;  // 0x90(0x1)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.GetSelectedItem
// Size: 0x62(Inherited: 0x0) 
struct FGetSelectedItem
{
	struct FFEqpSlotData OutSlotData;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bFoundItem : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t SlotNum;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x30(0x8)
	struct FFEqpSlotData CallFunc_Array_Get_Item;  // 0x38(0x18)
	struct UWBP_EquipmentSelect_EqBox_C* K2Node_DynamicCast_AsWBP_Equipment_Select_Eq_Box;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x61(0x1)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.LoadEquipmentAsset
// Size: 0x38(Inherited: 0x0) 
struct FLoadEquipmentAsset
{
	struct TSoftObjectPtr<UTexture2D> IconToLoad;  // 0x0(0x28)
	int32_t SlotNum;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct AHDBaseWeapon* EqpItem;  // 0x30(0x8)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectItem
// Size: 0x48(Inherited: 0x0) 
struct FSelectItem
{
	int32_t NewSlotIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x8(0x8)
	struct UWidget* CallFunc_GetChildAt_ReturnValue_2;  // 0x10(0x8)
	struct UWBP_EquipmentSelect_EqBox_C* K2Node_DynamicCast_AsWBP_Equipment_Select_Eq_Box;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UWBP_EquipmentSelect_EqBox_C* K2Node_DynamicCast_AsWBP_Equipment_Select_Eq_Box_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue_2;  // 0x3C(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x40(0x4)
	int32_t K2Node_Select_Default;  // 0x44(0x4)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.RebuildEquipmentList
// Size: 0x70(Inherited: 0x0) 
struct FRebuildEquipmentList
{
	struct TArray<struct FFEqpSlotData> SlotDataCopy;  // 0x0(0x10)
	int32_t MinSlotNum;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x1C(0x4)
	struct UTexture2D* Temp_object_Variable;  // 0x20(0x8)
	int32_t Temp_int_Variable;  // 0x28(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x30(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool Temp_bool_Variable : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	int32_t CallFunc_GetMinSlotIndex_MinSlotIndex;  // 0x3C(0x4)
	struct FFEqpSlotData CallFunc_Array_Get_Item;  // 0x40(0x18)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x58(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsSelectableEquipment_ReturnValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x62(0x1)
	char pad_99[5];  // 0x63(0x5)
	struct UTexture2D* K2Node_Select_Default;  // 0x68(0x8)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.OnLoaded_B4ECD00040B15A8A41EE1DA4CE775D64
// Size: 0x8(Inherited: 0x0) 
struct FOnLoaded_B4ECD00040B15A8A41EE1DA4CE775D64
{
	struct UObject* Loaded;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectPrevItem
// Size: 0x4(Inherited: 0x0) 
struct FSelectPrevItem
{
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x0(0x4)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectNextItem
// Size: 0x4(Inherited: 0x0) 
struct FSelectNextItem
{
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x0(0x4)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.AddEquipment
// Size: 0x3C(Inherited: 0x0) 
struct FAddEquipment
{
	struct FHDItemEntry EqpInfo;  // 0x0(0x10)
	struct AHDBaseWeapon* EqpItem;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FFEqpSlotData K2Node_MakeStruct_FEqpSlotData;  // 0x20(0x18)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x38(0x4)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.RemoveEquipmentAtSlotNum
// Size: 0x39(Inherited: 0x0) 
struct FRemoveEquipmentAtSlotNum
{
	int32_t SlotNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bRemoved : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FFEqpSlotData CallFunc_Array_Get_Item;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.CreateAndAddEquipmentWidget
// Size: 0x38(Inherited: 0x0) 
struct FCreateAndAddEquipmentWidget
{
	struct UTexture2D* Icon;  // 0x0(0x8)
	int32_t SlotNum;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bEnabled : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct AHDBaseWeapon* EqpItem;  // 0x10(0x8)
	struct UWBP_EquipmentSelect_EqBox_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0x20(0x8)
	struct FMargin K2Node_MakeStruct_Margin;  // 0x28(0x10)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.GetMinSlotIndex
// Size: 0x52(Inherited: 0x0) 
struct FGetMinSlotIndex
{
	struct TArray<struct FFEqpSlotData> SlotDataArray;  // 0x0(0x10)
	int32_t MinSlotIndex;  // 0x10(0x4)
	int32_t SlotIndex;  // 0x14(0x4)
	int32_t MinSlotNum;  // 0x18(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FFEqpSlotData CallFunc_Array_Get_Item;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75[1];  // 0x4B(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x51(0x1)

}; 
// Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectItemBySlotNum
// Size: 0x38(Inherited: 0x0) 
struct FSelectItemBySlotNum
{
	int32_t SlotNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UWBP_EquipmentSelect_EqBox_C* K2Node_DynamicCast_AsWBP_Equipment_Select_Eq_Box;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)

}; 
