#pragma once 
#include <BP_HDAIControllerBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDAIControllerBase.BP_HDAIControllerBase_C
// Size: 0x390(Inherited: 0x360) 
struct ABP_HDAIControllerBase_C : public AHDAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x360(0x8)
	struct UAIPerceptionComponent* PerceptionComp;  // 0x368(0x8)
	struct UHDGOAPComponent* GOAPComp;  // 0x370(0x8)
	float SavedMaxConeOfFireAngleDegrees;  // 0x378(0x4)
	float SavedMinConeOfFireAngleDegrees;  // 0x37C(0x4)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool bSavedInfiniteAmmo : 1;  // 0x380(0x1)
	char pad_897_1 : 7;  // 0x381(0x1)
	bool bSavedInfiniteClipAmmo : 1;  // 0x381(0x1)
	char pad_898[6];  // 0x382(0x6)
	struct UDataTable* DefaultFactionVocalProfiles;  // 0x388(0x8)

	void SetupVocalProfile(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupVocalProfile
	void ResetWeaponBase(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ResetWeaponBase
	void SetupWeaponBase(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupWeaponBase
	void ClearWeaponSavedValues(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ClearWeaponSavedValues
	void RestorePreviousValuesForWeapon(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.RestorePreviousValuesForWeapon
	void SaveAndApplyNewValuesToWeapon(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SaveAndApplyNewValuesToWeapon
	void ResetRecoilHandler(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ResetRecoilHandler
	void SetupRecoilHandler(struct ABP_HDWeaponBase_C* Weapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupRecoilHandler
	void CharacterCleanup(struct ABP_HDPlayerCharacterBase_C* Character); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.CharacterCleanup
	void UnbindEventsFromCharacter(struct ABP_HDPlayerCharacterBase_C* Character); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.UnbindEventsFromCharacter
	void BindEventsToCharacter(struct ABP_HDPlayerCharacterBase_C* Character); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.BindEventsToCharacter
	void WarnOfNoRecoilHandler(struct ABP_HDWeaponBase_C* EquippedWeapon); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.WarnOfNoRecoilHandler
	struct UHDKit* GetFactionSpecifiedSquadMemberKit(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.GetFactionSpecifiedSquadMemberKit
	struct UHDKit* GetFactionSpecifiedSquadLeaderKit(); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.GetFactionSpecifiedSquadLeaderKit
	void OnOwnerPawnDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.OnOwnerPawnDeath
	void OnOwnerPawnEquippedItemChange(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.OnOwnerPawnEquippedItemChange
	void ReceivePossess(struct APawn* PossessedPawn); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ReceivePossess
	void SuppressionEvent(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SuppressionEvent
	void HitDamageEvent(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.HitDamageEvent
	void ReceiveUnPossess(struct APawn* UnpossessedPawn); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ReceiveUnPossess
	void ExecuteUbergraph_BP_HDAIControllerBase(int32_t EntryPoint); // Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ExecuteUbergraph_BP_HDAIControllerBase
}; 



