#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Tinkerbox.MinimapGenerationSettings
// Size: 0x28(Inherited: 0x0) 
struct FMinimapGenerationSettings
{
	struct AActor* BoundaryMarkerA;  // 0x0(0x8)
	struct AActor* BoundaryMarkerB;  // 0x8(0x8)
	struct FVector BoundaryMidPointLoc;  // 0x10(0xC)
	uint8_t  CaptureResolution;  // 0x1C(0x2)
	char pad_30[2];  // 0x1E(0x2)
	float PlayableBoundaryLength;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.EnableHeadphoneMode
// Size: 0x1(Inherited: 0x0) 
struct FEnableHeadphoneMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.GetPushToTalkCommandKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetPushToTalkCommandKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.SetNextItemKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetNextItemKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.FirstRunHardwareBenchmark
// Size: 0x10(Inherited: 0x0) 
struct FFirstRunHardwareBenchmark
{
	int32_t WorkScale;  // 0x0(0x4)
	float CPUMultiplier;  // 0x4(0x4)
	float GPUMultiplier;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function Tinkerbox.TBGameUserSettings.GetVaultKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetVaultKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetPreviousItemKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetPreviousItemKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameInstance.GetCurrentSessionHostAddressStr
// Size: 0x18(Inherited: 0x0) 
struct FGetCurrentSessionHostAddressStr
{
	struct FString OutHostAddrStr;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bPreferSteamP2PAddr : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bAppendPort : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool ReturnValue : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)

}; 
// Function Tinkerbox.TBGameUserSettings.GetLeanRightKeyToggleBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetLeanRightKeyToggleBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameInstance.LoadMainMenu
// Size: 0x1(Inherited: 0x0) 
struct FLoadMainMenu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bExclusive : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.GetAimDownSightsToggleKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetAimDownSightsToggleKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetAimDownSightsKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetAimDownSightsKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetReloadKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetReloadKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetCameraToggleKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetCameraToggleKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMoveRightKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetMoveRightKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSwitchFireModeKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetSwitchFireModeKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetConsoleKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetConsoleKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetCrouchKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetCrouchKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetFieldOfView
// Size: 0x4(Inherited: 0x0) 
struct FGetFieldOfView
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetCrouchToggleKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetCrouchToggleKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetCycleWeaponSightsKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetCycleWeaponSightsKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMasterVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FGetMasterVolumeLevel
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetJumpKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetJumpKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetDeployMenuKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetDeployMenuKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSprintToggleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetSprintToggleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.GetDialogueVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FGetDialogueVolumeLevel
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetRadialMenuKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetRadialMenuKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.IsAllowSoundInBackgroundDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsAllowSoundInBackgroundDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.GetFrameRateLimitCurrent
// Size: 0x4(Inherited: 0x0) 
struct FGetFrameRateLimitCurrent
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetDialogueVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetDialogueVolumeLevelNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSaySquadKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetSaySquadKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetDisplayGamma
// Size: 0x4(Inherited: 0x0) 
struct FGetDisplayGamma
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetLeanRightKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetLeanRightKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.GetFireKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetFireKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetInvertMousePitch
// Size: 0x1(Inherited: 0x0) 
struct FGetInvertMousePitch
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.GetJumpVaultKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetJumpVaultKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetLeanLeftToggleKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetLeanLeftToggleKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMusicVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FSetMusicVolumeLevel
{
	float MusicVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetLastConfirmedMasterVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FGetLastConfirmedMasterVolumeLevel
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMusicVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FSetMusicVolumeLevelNormalized
{
	float NormMusicVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetLastConfirmedMasterVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetLastConfirmedMasterVolumeLevelNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetPushToTalkSquadKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetPushToTalkSquadKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetLeanLeftKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetLeanLeftKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetLeanRightKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetLeanRightKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetLocalPlayerControllerBP
// Size: 0x8(Inherited: 0x0) 
struct FGetLocalPlayerControllerBP
{
	struct APlayerController* ReturnValue;  // 0x0(0x8)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMasterVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetMasterVolumeLevelNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSayTeamKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetSayTeamKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.GetProneKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetProneKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityX
// Size: 0x4(Inherited: 0x0) 
struct FGetMouseSensitivityX
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityXNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetMouseSensitivityXNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetPointAimToggleKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetPointAimToggleKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityY
// Size: 0x4(Inherited: 0x0) 
struct FGetMouseSensitivityY
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMouseSensitivity
// Size: 0x8(Inherited: 0x0) 
struct FSetMouseSensitivity
{
	float SensitivityX;  // 0x0(0x4)
	float SensitivityY;  // 0x4(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityYNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetMouseSensitivityYNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMoveBackwardKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetMoveBackwardKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMoveForwardKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetMoveForwardKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSprintKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetSprintKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMoveLeftKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetMoveLeftKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSayTeamKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetSayTeamKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetPushToTalkLocalKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetPushToTalkLocalKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot1KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot1KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMusicVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FGetMusicVolumeLevel
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetMusicVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetMusicVolumeLevelNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetVoiceVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FGetVoiceVolumeLevel
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetNextItemKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetNextItemKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSayAllKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetSayAllKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetShowScoreboardKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetShowScoreboardKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.SetDisplayGamma
// Size: 0x4(Inherited: 0x0) 
struct FSetDisplayGamma
{
	float NewGamma;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSoundEffectsVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FGetSoundEffectsVolumeLevel
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSoundEffectsVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetSoundEffectsVolumeLevelNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSprintToggleKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetSprintToggleKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetVoiceVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FGetVoiceVolumeLevelNormalized
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.GetSwitchFireModeOnReselect
// Size: 0x2(Inherited: 0x0) 
struct FGetSwitchFireModeOnReselect
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLastConfirmed : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.GetUseKeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetUseKeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot0KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot0KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot2KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot2KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot3KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot3KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot4KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot4KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.SetAimDownSightsKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetAimDownSightsKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot5KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot5KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot6KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot6KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot7KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot7KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.SetJumpVaultKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetJumpVaultKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot8KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot8KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.GetWeaponSlot9KeyBinding
// Size: 0x18(Inherited: 0x0) 
struct FGetWeaponSlot9KeyBinding
{
	struct FKey ReturnValue;  // 0x0(0x18)

}; 
// Function Tinkerbox.TBGameUserSettings.IsAnyInputKeyBindingDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsAnyInputKeyBindingDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsAudioQualityDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsAudioQualityDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsDialogueVolumeLevelDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsDialogueVolumeLevelDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsSmoothMouseDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsSmoothMouseDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsDisplayGammaDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsDisplayGammaDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsFieldOfViewDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsFieldOfViewDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsFrameRateLimitDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsFrameRateLimitDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot1KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot1KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.IsHeadphoneModeDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsHeadphoneModeDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetRadialMenuKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetRadialMenuKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.IsHeadphoneModeEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsHeadphoneModeEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsInvertMouseDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsInvertMouseDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsMasterVolumeLevelDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsMasterVolumeLevelDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsMotionBlurDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsMotionBlurDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsMotionBlurEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsMotionBlurEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSayAllKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetSayAllKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.IsMouseSensitivityDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsMouseSensitivityDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSwitchFireModeOnReselect
// Size: 0x1(Inherited: 0x0) 
struct FSetSwitchFireModeOnReselect
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnable : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsMusicVolumeLevelDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsMusicVolumeLevelDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsPlayerChangingKeyBindings
// Size: 0x1(Inherited: 0x0) 
struct FIsPlayerChangingKeyBindings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsSmoothFrameRateDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsSmoothFrameRateDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsSmoothFrameRateEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsSmoothFrameRateEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsSmoothMouseEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsSmoothMouseEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsSoundEffectsVolumeLevelDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsSoundEffectsVolumeLevelDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsSoundInBackgroundAllowed
// Size: 0x1(Inherited: 0x0) 
struct FIsSoundInBackgroundAllowed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsSwitchFireModeOnReselectDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsSwitchFireModeOnReselectDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.IsVoiceVolumeLevelDirty
// Size: 0x1(Inherited: 0x0) 
struct FIsVoiceVolumeLevelDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetAimDownSightsToggleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetAimDownSightsToggleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetAllowSoundInBackground
// Size: 0x1(Inherited: 0x0) 
struct FSetAllowSoundInBackground
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllow : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetCameraToggleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetCameraToggleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetConsoleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetConsoleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetCrouchKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetCrouchKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetCrouchToggleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetCrouchToggleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetCycleWeaponSightsKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetCycleWeaponSightsKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMasterVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FSetMasterVolumeLevel
{
	float MasterVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetDeployMenuKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetDeployMenuKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetDialogueVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FSetDialogueVolumeLevel
{
	float DialogueVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetDialogueVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FSetDialogueVolumeLevelNormalized
{
	float NormDialogueVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetFieldOfView
// Size: 0x4(Inherited: 0x0) 
struct FSetFieldOfView
{
	float NewFOV;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetJumpKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetJumpKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetFireKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetFireKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetInvertMousePitch
// Size: 0x1(Inherited: 0x0) 
struct FSetInvertMousePitch
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInvertPitch : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetLeanLeftKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetLeanLeftKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetLeanLeftToggleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetLeanLeftToggleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetLeanRightToggleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetLeanRightToggleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMasterVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FSetMasterVolumeLevelNormalized
{
	float NormMasterVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMotionBlurEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetMotionBlurEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMouseSensitivityNormalized
// Size: 0x8(Inherited: 0x0) 
struct FSetMouseSensitivityNormalized
{
	float NormSensitivityX;  // 0x0(0x4)
	float NormSensitivityY;  // 0x4(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMoveBackwardKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetMoveBackwardKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMoveForwardKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetMoveForwardKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMoveLeftKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetMoveLeftKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetMoveRightKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetMoveRightKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot5KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot5KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetPlayerIsChangingKeyBindings
// Size: 0x1(Inherited: 0x0) 
struct FSetPlayerIsChangingKeyBindings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewValue : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetPointAimToggleKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetPointAimToggleKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetPreviousItemKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetPreviousItemKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetProneKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetProneKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetPushToTalkCommandKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetPushToTalkCommandKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetPushToTalkLocalKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetPushToTalkLocalKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetPushToTalkSquadKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetPushToTalkSquadKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetReloadKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetReloadKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSaySquadKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetSaySquadKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetShowScoreboardKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetShowScoreboardKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSmoothFrameRateEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetSmoothFrameRateEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSmoothMouseEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetSmoothMouseEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnable : 1;  // 0x0(0x1)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSoundEffectsVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FSetSoundEffectsVolumeLevel
{
	float SFXVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSoundEffectsVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FSetSoundEffectsVolumeLevelNormalized
{
	float NormSFXVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBVoiceIndicatorListing.Init
// Size: 0x40(Inherited: 0x0) 
struct FInit
{
	struct UTBVoiceIndicator* InParentMenu;  // 0x0(0x8)
	struct FUniqueNetIdRepl InUniqueNetId;  // 0x8(0x28)
	struct FString InPlayerName;  // 0x30(0x10)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSprintKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetSprintKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetSwitchFireModeKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetSwitchFireModeKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetUseKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetUseKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetVaultKeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetVaultKeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetVoiceVolumeLevel
// Size: 0x4(Inherited: 0x0) 
struct FSetVoiceVolumeLevel
{
	float VoiceVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetVoiceVolumeLevelNormalized
// Size: 0x4(Inherited: 0x0) 
struct FSetVoiceVolumeLevelNormalized
{
	float NormVoiceVolume;  // 0x0(0x4)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot0KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot0KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot2KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot2KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot3KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot3KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot4KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot4KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot6KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot6KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot7KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot7KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot8KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot8KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBGameUserSettings.SetWeaponSlot9KeyBinding
// Size: 0x20(Inherited: 0x0) 
struct FSetWeaponSlot9KeyBinding
{
	struct FInputChord NewKey;  // 0x0(0x20)

}; 
// Function Tinkerbox.TBVoiceIndicator.ActiveVoiceAdded
// Size: 0x10(Inherited: 0x0) 
struct FActiveVoiceAdded
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct UPanelSlot* NewVoiceWidget;  // 0x8(0x8)

}; 
// Function Tinkerbox.TBVoiceIndicator.ActiveVoiceRemoved
// Size: 0x10(Inherited: 0x0) 
struct FActiveVoiceRemoved
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct UPanelSlot* NewVoiceWidget;  // 0x8(0x8)

}; 
