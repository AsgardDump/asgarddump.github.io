#pragma once 
#include <WBP_EquipmentSelect_EqBox_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C
// Size: 0x291(Inherited: 0x230) 
struct UWBP_EquipmentSelect_EqBox_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UTextBlock* EquipmentNumber;  // 0x238(0x8)
	struct UImage* Image_11;  // 0x240(0x8)
	struct UImage* Image_12;  // 0x248(0x8)
	struct UImage* Image_13;  // 0x250(0x8)
	struct UImage* Image_14;  // 0x258(0x8)
	struct UImage* Item;  // 0x260(0x8)
	struct UOverlay* RestrictedOverlay;  // 0x268(0x8)
	struct UImage* Selected;  // 0x270(0x8)
	struct UTexture2D* Icon;  // 0x278(0x8)
	int32_t SlotNum;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool bEnabled : 1;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct AHDBaseWeapon* EqpItem;  // 0x288(0x8)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bHighlighted : 1;  // 0x290(0x1)

	void SetEnabled(bool bEnabled); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.SetEnabled
	void IsHighlighted(bool& bHighlight); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.IsHighlighted
	void SetHighlight(bool bHighlighted); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.SetHighlight
	void PreConstruct(bool IsDesignTime); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.PreConstruct
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.Tick
	void ExecuteUbergraph_WBP_EquipmentSelect_EqBox(int32_t EntryPoint); // Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.ExecuteUbergraph_WBP_EquipmentSelect_EqBox
}; 



