#pragma once 
#include "SDK.h" 
 
 
// Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.BuildBotCountURLOption
// Size: 0x58(Inherited: 0x0) 
struct FBuildBotCountURLOption
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Count;  // 0x4(0x4)
	struct FString Pair;  // 0x8(0x10)
	struct FString CallFunc_GetNumBotsOptionName_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)

}; 
// Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.ExecuteUbergraph_WBP_BotsGameModifierSettings
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_BotsGameModifierSettings
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UWBP_OptionMenu_CreateGame_C* K2Node_Event_ParentMenu;  // 0x8(0x8)

}; 
// Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.SetupModifier
// Size: 0x8(Inherited: 0x0) 
struct FSetupModifier
{
	struct UWBP_OptionMenu_CreateGame_C* ParentMenu;  // 0x0(0x8)

}; 
// Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.IsEnabled
// Size: 0x2(Inherited: 0x0) 
struct FIsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsActive_bActive : 1;  // 0x1(0x1)

}; 
// Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.GetTravelURLOptions
// Size: 0x88(Inherited: 0x0) 
struct FGetTravelURLOptions
{
	struct FString Options;  // 0x0(0x10)
	struct FString OptionsStr;  // 0x10(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x20(0x10)
	int32_t CallFunc_MakeLiteralInt_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	float CallFunc_GetValue_Value;  // 0x58(0x4)
	float CallFunc_GetValue_Value_2;  // 0x5C(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x60(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x64(0x4)
	struct FString CallFunc_BuildBotCountURLOption_Pair;  // 0x68(0x10)
	struct FString CallFunc_BuildBotCountURLOption_Pair_2;  // 0x78(0x10)

}; 
