#pragma once 
#include "SDK.h" 
 
 
// Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.ExecuteUbergraph_WBP_CreditsListEntry
// Size: 0x40(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_CreditsListEntry
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString CallFunc_CombineBodyText_BodyCombinedStr;  // 0x8(0x10)
	struct FString CallFunc_ToUpper_ReturnValue;  // 0x18(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x28(0x18)

}; 
// Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.CombineBodyText
// Size: 0xE0(Inherited: 0x0) 
struct FCombineBodyText
{
	struct FString BodyCombinedStr;  // 0x0(0x10)
	struct FString CombinedStr;  // 0x10(0x10)
	struct FString Temp_string_Variable;  // 0x20(0x10)
	struct FString Temp_string_Variable_2;  // 0x30(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x44(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool Temp_bool_Variable : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FFGameCreditsEntry CallFunc_Array_Get_Item;  // 0x60(0x30)
	struct FString K2Node_Select_Default;  // 0x90(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xC0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xD0(0x10)

}; 
