#pragma once 
#include <WBP_CommunityMediaLink_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_CommunityMediaLink.WBP_CommunityMediaLink_C
// Size: 0x310(Inherited: 0x230) 
struct UWBP_CommunityMediaLink_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UButton* LinkBtn;  // 0x238(0x8)
	struct UImage* LinkIcon;  // 0x240(0x8)
	struct UTextBlock* LinkText;  // 0x248(0x8)
	struct FFCommunityMediaLinkUIDefinition LinkUIDefinition;  // 0x250(0xC0)

	void BndEvt__LinkBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_CommunityMediaLink.WBP_CommunityMediaLink_C.BndEvt__LinkBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_CommunityMediaLink.WBP_CommunityMediaLink_C.PreConstruct
	void ExecuteUbergraph_WBP_CommunityMediaLink(int32_t EntryPoint); // Function WBP_CommunityMediaLink.WBP_CommunityMediaLink_C.ExecuteUbergraph_WBP_CommunityMediaLink
}; 



