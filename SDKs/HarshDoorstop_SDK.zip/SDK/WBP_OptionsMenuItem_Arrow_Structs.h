#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.ExecuteUbergraph_WBP_OptionsMenuItem_Arrow
// Size: 0xAA(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionsMenuItem_Arrow
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x1C(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_2;  // 0x20(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue_3;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x2C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x30(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_Max_ReturnValue;  // 0x3C(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x44(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_6;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	int32_t CallFunc_Array_Length_ReturnValue_7;  // 0x50(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_8;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_4 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_5 : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91[1];  // 0x5B(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_9;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_6 : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x68(0x18)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x84(0x10)
	char pad_148[4];  // 0x94(0x4)
	struct FString K2Node_CustomEvent_SelectedItemValue;  // 0x98(0x10)
	char ESelectInfo K2Node_CustomEvent_SelectionType;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xA9(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnSelectionChanged__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FOnSelectionChanged__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)
	char ESelectInfo SelectionType;  // 0x10(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnItemSelectionChanged
// Size: 0x11(Inherited: 0x0) 
struct FOnItemSelectionChanged
{
	struct FString SelectedItemValue;  // 0x0(0x10)
	char ESelectInfo SelectionType;  // 0x10(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.INTERNAL_SetSelectedOptionByIndex
// Size: 0x20(Inherited: 0x0) 
struct FINTERNAL_SetSelectedOptionByIndex
{
	int32_t Index;  // 0x0(0x4)
	char ESelectInfo SelectionType;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x8(0x18)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetSelectedOptionValue
// Size: 0x20(Inherited: 0x0) 
struct FGetSelectedOptionValue
{
	struct FString OptionValue;  // 0x0(0x10)
	struct FString CallFunc_GetOptionValueAtIndex_OptionValue;  // 0x10(0x10)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetOptionValueAtIndex
// Size: 0x48(Inherited: 0x0) 
struct FGetOptionValueAtIndex
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString OptionValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString Temp_string_Variable;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString K2Node_Select_Default;  // 0x38(0x10)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.AddOption
// Size: 0x2C(Inherited: 0x0) 
struct FAddOption
{
	struct FFOptionItemSelection NewOption;  // 0x0(0x28)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x28(0x4)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.PopulateOptionsByPreset
// Size: 0x3D(Inherited: 0x0) 
struct FPopulateOptionsByPreset
{
	char EArrowOptionsPreset Preset;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct FFOptionItemSelection CallFunc_Array_Get_Item;  // 0x10(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3C(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetOptionCount
// Size: 0x8(Inherited: 0x0) 
struct FGetOptionCount
{
	int32_t OptionCount;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.RemoveOptionAtIndex
// Size: 0x7(Inherited: 0x0) 
struct FRemoveOptionAtIndex
{
	int32_t IndexToRemove;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bRemovalSuccess : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x6(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.INTERNAL_ClearSelection
// Size: 0x1(Inherited: 0x0) 
struct FINTERNAL_ClearSelection
{
	char ESelectInfo DeselectionType;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOptionByIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetSelectedOptionByIndex
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.FindOptionValueIndex
// Size: 0x6F(Inherited: 0x0) 
struct FFindOptionValueIndex
{
	struct FString OptionValue;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString InOptionValue;  // 0x18(0x10)
	int32_t OptionIndex;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FFOptionItemSelection CallFunc_Array_Get_Item;  // 0x40(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x6D(0x1)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x6E(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOptionByValue
// Size: 0x15(Inherited: 0x0) 
struct FSetSelectedOptionByValue
{
	struct FString OptionValue;  // 0x0(0x10)
	int32_t CallFunc_FindOptionValueIndex_Index;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOption
// Size: 0x1D(Inherited: 0x0) 
struct FSetSelectedOption
{
	struct FText OptionDisplayName;  // 0x0(0x18)
	int32_t CallFunc_FindOptionIndex_Index;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x1C(0x1)

}; 
// Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.FindOptionIndex
// Size: 0x7F(Inherited: 0x0) 
struct FFindOptionIndex
{
	struct FText OptionDisplayName;  // 0x0(0x18)
	int32_t Index;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FText InOptionDisplayName;  // 0x20(0x18)
	int32_t OptionIndex;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62[2];  // 0x3E(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x44(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FFOptionItemSelection CallFunc_Array_Get_Item;  // 0x50(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_EqualEqual_TextText_ReturnValue : 1;  // 0x7D(0x1)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7E(0x1)

}; 
