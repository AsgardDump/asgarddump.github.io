#pragma once 
#include <DonkehFrameworkUI_Structs.h>
 
 
 
// Class DonkehFrameworkUI.DFContextualWidgetBase
// Size: 0x240(Inherited: 0x230) 
struct UDFContextualWidgetBase : public UUserWidget
{
	struct TArray<struct UDFContextualWidgetPrerequisiteBase*> Prerequisites;  // 0x230(0x10)

	bool TestPrerequisites(bool bInvokeEvents); // Function DonkehFrameworkUI.DFContextualWidgetBase.TestPrerequisites
	void PrerequisitesMet(); // Function DonkehFrameworkUI.DFContextualWidgetBase.PrerequisitesMet
	void PrerequisiteNotMet(struct UDFContextualWidgetPrerequisiteBase* FailedPrereq); // Function DonkehFrameworkUI.DFContextualWidgetBase.PrerequisiteNotMet
}; 



// Class DonkehFrameworkUI.DFMenuManager
// Size: 0x58(Inherited: 0x28) 
struct UDFMenuManager : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TArray<struct FMenuStackEntry> MenuStack;  // 0x30(0x10)
	struct FSoftClassPath MenuManagerClassName;  // 0x40(0x18)

	struct UDFBaseMenu* Top(); // Function DonkehFrameworkUI.DFMenuManager.Top
	void RemoveMenu(struct UDFBaseMenu* MenuToRemove); // Function DonkehFrameworkUI.DFMenuManager.RemoveMenu
	void PopMenu(); // Function DonkehFrameworkUI.DFMenuManager.PopMenu
	void ClearMenuStack(); // Function DonkehFrameworkUI.DFMenuManager.ClearMenuStack
	void ActivateMenu(struct UDFBaseMenu* MenuToAdd, uint8_t  ActivationMode, bool bShowMouseCursor, bool bUIOnlyInput); // Function DonkehFrameworkUI.DFMenuManager.ActivateMenu
}; 



// Class DonkehFrameworkUI.DFBaseMenu
// Size: 0x238(Inherited: 0x230) 
struct UDFBaseMenu : public UUserWidget
{
	char bMenuConstructedInDesigner : 1;  // 0x230(0x1)
	char bMenuPopped : 1;  // 0x230(0x1)
	char bFlushPlayerInputUponConstruction : 1;  // 0x230(0x1)
	char pad_560_1 : 5;  // 0x230(0x1)
	char pad_561[8];  // 0x231(0x8)

	void RemoveFromMenuStack(); // Function DonkehFrameworkUI.DFBaseMenu.RemoveFromMenuStack
	void ReceiveOnMenuUncovered(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuUncovered
	void ReceiveOnMenuPush(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuPush
	void ReceiveOnMenuPop(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuPop
	void ReceiveOnMenuCovered(); // Function DonkehFrameworkUI.DFBaseMenu.ReceiveOnMenuCovered
	bool IsTopOfMenuStack(); // Function DonkehFrameworkUI.DFBaseMenu.IsTopOfMenuStack
}; 



// Class DonkehFrameworkUI.DFPOIWidget
// Size: 0x3A0(Inherited: 0x230) 
struct UDFPOIWidget : public UUserWidget
{
	char pad_560[16];  // 0x230(0x10)
	struct AActor* POIActor;  // 0x240(0x8)
	struct FMinimapPOITableRow POIActorData;  // 0x248(0x130)
	char pad_888[8];  // 0x378(0x8)
	struct FMulticastInlineDelegate OnSelectionStateChanged;  // 0x380(0x10)
	char bSelected : 1;  // 0x390(0x1)
	char pad_912_1 : 7;  // 0x390(0x1)
	char pad_913[8];  // 0x391(0x8)
	struct UNamedSlot* IconSlot;  // 0x398(0x8)

	void UpdateRotation(); // Function DonkehFrameworkUI.DFPOIWidget.UpdateRotation
	void UpdatePosition(); // Function DonkehFrameworkUI.DFPOIWidget.UpdatePosition
	void SetPOISelectionState(bool bNewSelected); // Function DonkehFrameworkUI.DFPOIWidget.SetPOISelectionState
	void SelectPOI(); // Function DonkehFrameworkUI.DFPOIWidget.SelectPOI
	void ReceivePOISelected(); // Function DonkehFrameworkUI.DFPOIWidget.ReceivePOISelected
	void ReceivePOIInitialized(); // Function DonkehFrameworkUI.DFPOIWidget.ReceivePOIInitialized
	void ReceivePOIDeselected(); // Function DonkehFrameworkUI.DFPOIWidget.ReceivePOIDeselected
	void ReceiveOnPOIActorEndPlay(struct AActor* Actor, char EEndPlayReason EndPlayReason); // Function DonkehFrameworkUI.DFPOIWidget.ReceiveOnPOIActorEndPlay
	bool ReceiveCanSelect(); // Function DonkehFrameworkUI.DFPOIWidget.ReceiveCanSelect
	void OnPOIActorEndPlay(struct AActor* Actor, char EEndPlayReason EndPlayReason); // Function DonkehFrameworkUI.DFPOIWidget.OnPOIActorEndPlay
	void OnOwningMapDirty(); // Function DonkehFrameworkUI.DFPOIWidget.OnOwningMapDirty
	bool IsSelectable(); // Function DonkehFrameworkUI.DFPOIWidget.IsSelectable
	bool IsPOIActorValid(); // Function DonkehFrameworkUI.DFPOIWidget.IsPOIActorValid
	bool IsInitialized(); // Function DonkehFrameworkUI.DFPOIWidget.IsInitialized
	bool IsDynamic(); // Function DonkehFrameworkUI.DFPOIWidget.IsDynamic
	void InitPOI(struct UDFMinimap* OwningMapWidget, struct AActor* ActorToTrack, struct FMinimapPOITableRow& ActorPOIData); // Function DonkehFrameworkUI.DFPOIWidget.InitPOI
	bool HasFixedRotation(); // Function DonkehFrameworkUI.DFPOIWidget.HasFixedRotation
	struct FSlateBrush GetDefaultIconBrush(); // Function DonkehFrameworkUI.DFPOIWidget.GetDefaultIconBrush
	void DeselectPOI(); // Function DonkehFrameworkUI.DFPOIWidget.DeselectPOI
	bool CanSelect(); // Function DonkehFrameworkUI.DFPOIWidget.CanSelect
}; 



// Class DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase
// Size: 0x30(Inherited: 0x28) 
struct UDFContextualWidgetPrerequisiteBase : public UObject
{
	char bForceSuccess : 1;  // 0x28(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	char pad_41[8];  // 0x29(0x8)

	bool TestPrerequisite(); // Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.TestPrerequisite
	bool SatisfiesPrerequisite(); // Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.SatisfiesPrerequisite
	struct UDFContextualWidgetBase* GetWidgetOuter(); // Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.GetWidgetOuter
}; 



// Class DonkehFrameworkUI.DFMenuManagerBlueprintFunctions
// Size: 0x28(Inherited: 0x28) 
struct UDFMenuManagerBlueprintFunctions : public UBlueprintFunctionLibrary
{

	struct UDFMenuManager* GetMenuManager(struct UObject* WorldContextObject); // Function DonkehFrameworkUI.DFMenuManagerBlueprintFunctions.GetMenuManager
	struct UDFBaseMenu* CreateAndActivate(struct UObject* WorldContextObject, UDFBaseMenu* MenuWidgetType, struct APlayerController* OwningPlayer, uint8_t  ActivationMode, bool bShowMouseCursor, bool bUIOnlyInput); // Function DonkehFrameworkUI.DFMenuManagerBlueprintFunctions.CreateAndActivate
}; 



// Class DonkehFrameworkUI.DFMinimap
// Size: 0x298(Inherited: 0x230) 
struct UDFMinimap : public UUserWidget
{
	struct TArray<struct UDFPOIWidget*> MapPOIs;  // 0x230(0x10)
	char pad_576[24];  // 0x240(0x18)
	struct FVector2D CurrentMapPos;  // 0x258(0x8)
	float CurrentZoom;  // 0x260(0x4)
	float MaxZoom;  // 0x264(0x4)
	float MapLength;  // 0x268(0x4)
	struct FVector MapOffset;  // 0x26C(0xC)
	struct UDataTable* POIDataTable;  // 0x278(0x8)
	struct UCanvasPanel* OuterCanvas;  // 0x280(0x8)
	struct UCanvasPanel* MapCanvas;  // 0x288(0x8)
	struct UImage* MapImg;  // 0x290(0x8)

	void UpdateZoomValue(float NewZoomValue); // Function DonkehFrameworkUI.DFMinimap.UpdateZoomValue
	void UpdateMapPos(struct FVector2D& NewMapPos); // Function DonkehFrameworkUI.DFMinimap.UpdateMapPos
	void SetMapDirty(); // Function DonkehFrameworkUI.DFMinimap.SetMapDirty
	bool RemovePOIByActorClass(AActor*& POIActorClass); // Function DonkehFrameworkUI.DFMinimap.RemovePOIByActorClass
	bool RemovePOIByActor(struct AActor* POIActorToRemove); // Function DonkehFrameworkUI.DFMinimap.RemovePOIByActor
	bool RemovePOIAt(int32_t Index); // Function DonkehFrameworkUI.DFMinimap.RemovePOIAt
	bool RemovePOI(struct UDFPOIWidget* POIToRemove); // Function DonkehFrameworkUI.DFMinimap.RemovePOI
	void ReceiveOnPOISelectionStateChanged(struct UDFPOIWidget* POI, bool bSelected); // Function DonkehFrameworkUI.DFMinimap.ReceiveOnPOISelectionStateChanged
	bool ProjectWorldLocationToMap(struct FVector WorldLocation, struct FVector2D& MapLocation); // Function DonkehFrameworkUI.DFMinimap.ProjectWorldLocationToMap
	void OnPOISelectionStateChanged(struct UDFPOIWidget* POI, bool bSelected); // Function DonkehFrameworkUI.DFMinimap.OnPOISelectionStateChanged
	bool HasPOI(struct UDFPOIWidget* POI); // Function DonkehFrameworkUI.DFMinimap.HasPOI
	bool HasAnyPOIs(); // Function DonkehFrameworkUI.DFMinimap.HasAnyPOIs
	int32_t GetPOIIndex(struct UDFPOIWidget* POI); // Function DonkehFrameworkUI.DFMinimap.GetPOIIndex
	int32_t GetPOICount(); // Function DonkehFrameworkUI.DFMinimap.GetPOICount
	struct UDFPOIWidget* GetPOIAt(int32_t Index); // Function DonkehFrameworkUI.DFMinimap.GetPOIAt
	struct FVector2D GetMapSizeLocal(); // Function DonkehFrameworkUI.DFMinimap.GetMapSizeLocal
	struct FVector2D GetMapSizeAbsolute(); // Function DonkehFrameworkUI.DFMinimap.GetMapSizeAbsolute
	bool FindPOIByActor(struct AActor* POIActor, struct UDFPOIWidget*& OutFoundPOI); // Function DonkehFrameworkUI.DFMinimap.FindPOIByActor
	bool DeprojectMapLocationToWorld(struct FVector2D MapLocation, struct FVector& WorldLocation); // Function DonkehFrameworkUI.DFMinimap.DeprojectMapLocationToWorld
	bool ConvertMapLocationToLocalWidgetLocation(struct FVector2D MapLocation, struct FVector2D& WidgetLocation); // Function DonkehFrameworkUI.DFMinimap.ConvertMapLocationToLocalWidgetLocation
	int32_t ClearPOIs(); // Function DonkehFrameworkUI.DFMinimap.ClearPOIs
	struct UDFPOIWidget* AddNewPOI(struct AActor* POIActor); // Function DonkehFrameworkUI.DFMinimap.AddNewPOI
}; 



// Class DonkehFrameworkUI.DFPOIComponent
// Size: 0xC8(Inherited: 0xB0) 
struct UDFPOIComponent : public UActorComponent
{
	char pad_176[20];  // 0xB0(0x14)
	char bAutoRegisterPOI : 1;  // 0xC4(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	char pad_197[4];  // 0xC5(0x4)

	void UnregisterPOI(); // Function DonkehFrameworkUI.DFPOIComponent.UnregisterPOI
	void RegisterPOI(struct UDFMinimap* MinimapWidget); // Function DonkehFrameworkUI.DFPOIComponent.RegisterPOI
	void OnMinimapLateInit(struct UDFMinimap* NewMinimap); // Function DonkehFrameworkUI.DFPOIComponent.OnMinimapLateInit
	bool IsPOIRegistered(); // Function DonkehFrameworkUI.DFPOIComponent.IsPOIRegistered
	struct UDFPOIWidget* GetPOIWidget(); // Function DonkehFrameworkUI.DFPOIComponent.GetPOIWidget
	struct UDFMinimap* GetMinimap(); // Function DonkehFrameworkUI.DFPOIComponent.GetMinimap
}; 



// Class DonkehFrameworkUI.POIWidgetSlotInterface
// Size: 0x28(Inherited: 0x28) 
struct UPOIWidgetSlotInterface : public UInterface
{

	void SetIconBrush(struct FSlateBrush& NewIconBrush); // Function DonkehFrameworkUI.POIWidgetSlotInterface.SetIconBrush
	struct UNamedSlot* GetIconSlot(); // Function DonkehFrameworkUI.POIWidgetSlotInterface.GetIconSlot
	struct FSlateBrush GetIconBrush(); // Function DonkehFrameworkUI.POIWidgetSlotInterface.GetIconBrush
}; 



