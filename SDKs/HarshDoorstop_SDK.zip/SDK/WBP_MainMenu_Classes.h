#pragma once 
#include <WBP_MainMenu_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_MainMenu.WBP_MainMenu_C
// Size: 0x3EC(Inherited: 0x238) 
struct UWBP_MainMenu_C : public UDFBaseMenu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UWidgetAnimation* MainMenuOpenUIAnim;  // 0x240(0x8)
	struct UNamedSlot* BgSlot;  // 0x248(0x8)
	struct UTextBlock* CopyrightNoticeText;  // 0x250(0x8)
	struct UWBP_MainMenu_NavBarButton_C* CreditsNavBtn;  // 0x258(0x8)
	struct UWBP_MainMenu_NavBarButton_C* ExitGameNavBtn;  // 0x260(0x8)
	struct UImage* FooterBg;  // 0x268(0x8)
	struct UWBP_MainMenu_NavBarButton_C* HomeNavBtn;  // 0x270(0x8)
	struct UWBP_MainMenu_NavBarButton_C* LeaveGameNavBtn;  // 0x278(0x8)
	struct UImage* Logo;  // 0x280(0x8)
	struct UHorizontalBox* MainMenuNavHBox;  // 0x288(0x8)
	struct UWBP_MainMenu_NavBarButton_C* ModsNavBtn;  // 0x290(0x8)
	struct UWBP_MainMenu_NavBarButton_C* MultiplayerNavBtn;  // 0x298(0x8)
	struct UImage* NavBarBg;  // 0x2A0(0x8)
	struct UWidgetSwitcher* NavBarWS;  // 0x2A8(0x8)
	struct UBorder* OptionMenuContainer;  // 0x2B0(0x8)
	struct UWBP_MainMenu_NavBarButton_C* OptionsNavBtn;  // 0x2B8(0x8)
	struct UWBP_MainMenu_NavBarButton_C* PauseExitGameNavBtn;  // 0x2C0(0x8)
	struct UHorizontalBox* PauseMenuNavHBox;  // 0x2C8(0x8)
	struct UWBP_MainMenu_NavBarButton_C* ResumeNavBtn;  // 0x2D0(0x8)
	struct UWBP_MainMenu_NavBarButton_C* ShootingRangeNavBtn;  // 0x2D8(0x8)
	struct UWBP_MainMenu_NavBarButton_C* SingleplayerNavBtn;  // 0x2E0(0x8)
	struct USizeBox* SubNavBar;  // 0x2E8(0x8)
	struct UVerticalBox* SubNavVBox;  // 0x2F0(0x8)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool bPauseMenu : 1;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool bShowPauseMenuInDesigner : 1;  // 0x2F9(0x1)
	char pad_762[2];  // 0x2FA(0x2)
	int32_t MenuIndex;  // 0x2FC(0x4)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool bShowReferenceBackground : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	UUserWidget* MenuBackgroundUWClass;  // 0x308(0x8)
	UUserWidget* PauseMenuBackgroundUWClass;  // 0x310(0x8)
	struct FVector2D LogoPosition;  // 0x318(0x8)
	struct FSlateBrush LogoBrush;  // 0x320(0x88)
	struct TArray<struct FFSubMenuOption> CurrentSubMenuOptions;  // 0x3A8(0x10)
	struct UDFBaseMenu* CurrentOptionMenu;  // 0x3B8(0x8)
	struct FMargin SubNavBtnPadding;  // 0x3C0(0x10)
	struct USoundBase* MenuMusic;  // 0x3D0(0x8)
	struct UAudioComponent* MenuMusicAC;  // 0x3D8(0x8)
	char pad_992_1 : 7;  // 0x3E0(0x1)
	bool bShowShootingRangeBtn : 1;  // 0x3E0(0x1)
	char pad_993[3];  // 0x3E1(0x3)
	struct FName ShootingRangeLevelName;  // 0x3E4(0x8)

	void PlayMenuMusic(); // Function WBP_MainMenu.WBP_MainMenu_C.PlayMenuMusic
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MainMenu.WBP_MainMenu_C.OnMouseWheel
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MainMenu.WBP_MainMenu_C.OnMouseButtonDown
	void TeardownSubNavBarClickEvents(); // Function WBP_MainMenu.WBP_MainMenu_C.TeardownSubNavBarClickEvents
	void SetupSubNavBarClickEvents(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupSubNavBarClickEvents
	void ToggleSubNavBar(bool bNewVisible); // Function WBP_MainMenu.WBP_MainMenu_C.ToggleSubNavBar
	void ClearCurrentOptionMenu(); // Function WBP_MainMenu.WBP_MainMenu_C.ClearCurrentOptionMenu
	void PopulateSubNavBar(struct TArray<struct FFSubMenuOption>& SubMenuOptions); // Function WBP_MainMenu.WBP_MainMenu_C.PopulateSubNavBar
	void ClearSubNavBarOptions(); // Function WBP_MainMenu.WBP_MainMenu_C.ClearSubNavBarOptions
	void UpdateSubNavBarOptions(struct TScriptInterface<IBPI_OptionMenu_C> NewOptionMenu); // Function WBP_MainMenu.WBP_MainMenu_C.UpdateSubNavBarOptions
	void GetNavBarHBox(struct UHorizontalBox*& HBoxToUse); // Function WBP_MainMenu.WBP_MainMenu_C.GetNavBarHBox
	void SetOptionMenu(UDFBaseMenu* NewOptionMenuClass, bool IsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.SetOptionMenu
	void GetNavBtnCount(int32_t& Count); // Function WBP_MainMenu.WBP_MainMenu_C.GetNavBtnCount
	void SetupCopyrightNotice(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupCopyrightNotice
	void SetActiveMenu(int32_t NewIndex, UDFBaseMenu* NewOptionMenuClass, bool IsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.SetActiveMenu
	void SetupNavBarClickEvents(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupNavBarClickEvents
	void SetupMenuBackgroundWidget(); // Function WBP_MainMenu.WBP_MainMenu_C.SetupMenuBackgroundWidget
	void InitMenuState(bool bIsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.InitMenuState
	void Construct(); // Function WBP_MainMenu.WBP_MainMenu_C.Construct
	void OnNavBtnClicked(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.OnNavBtnClicked
	void BndEvt__ResumeNavBtn_K2Node_ComponentBoundEvent_11_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ResumeNavBtn_K2Node_ComponentBoundEvent_11_ButtonClicked__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_MainMenu.WBP_MainMenu_C.PreConstruct
	void BndEvt__ReturnToMenuNavBtn_K2Node_ComponentBoundEvent_12_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ReturnToMenuNavBtn_K2Node_ComponentBoundEvent_12_ButtonClicked__DelegateSignature
	void OnSubNavBtnClicked(struct UWBP_MenuSubNavSelectionListEntry_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.OnSubNavBtnClicked
	void OnPauseMenuPressed(); // Function WBP_MainMenu.WBP_MainMenu_C.OnPauseMenuPressed
	void BndEvt__ShootingRangeNavBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ShootingRangeNavBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature
	void OnInitialized(); // Function WBP_MainMenu.WBP_MainMenu_C.OnInitialized
	void BndEvt__ExitGameNavBtn_K2Node_ComponentBoundEvent_4_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ExitGameNavBtn_K2Node_ComponentBoundEvent_4_ButtonClicked__DelegateSignature
	void BndEvt__PauseExitGameNavBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature(struct UWBP_MainMenu_NavBarButton_C* ClickedBtn); // Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__PauseExitGameNavBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature
	void ExecuteUbergraph_WBP_MainMenu(int32_t EntryPoint); // Function WBP_MainMenu.WBP_MainMenu_C.ExecuteUbergraph_WBP_MainMenu
}; 



