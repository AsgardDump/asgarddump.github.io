#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDKitPickupBase.BP_HDKitPickupBase_C.UserConstructionScript
// Size: 0x31(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct USkeletalMeshComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct USkeletalMeshComponent* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
