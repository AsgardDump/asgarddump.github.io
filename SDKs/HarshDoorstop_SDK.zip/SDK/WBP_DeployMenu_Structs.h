#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu.WBP_DeployMenu_C.DeployAtSelectedSpawnPoint
// Size: 0x1A(Inherited: 0x0) 
struct FDeployAtSelectedSpawnPoint
{
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnBluforPostInitTeam
// Size: 0x8(Inherited: 0x0) 
struct FOnBluforPostInitTeam
{
	struct ADFTeamState* TeamState;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.ExecuteUbergraph_WBP_DeployMenu
// Size: 0x1EC(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* K2Node_CustomEvent_VictimPawn;  // 0x8(0x8)
	struct AController* K2Node_CustomEvent_VictimController;  // 0x10(0x8)
	float K2Node_CustomEvent_KillingDamage;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FDamageEvent K2Node_CustomEvent_DamageEvent;  // 0x20(0x10)
	struct APawn* K2Node_CustomEvent_InstigatingPawn;  // 0x30(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x38(0x8)
	struct APawn* K2Node_CustomEvent_UnpossessedPawn;  // 0x40(0x8)
	struct APawn* K2Node_CustomEvent_PossessedPawn;  // 0x48(0x8)
	char K2Node_CustomEvent_PrevTeam;  // 0x50(0x1)
	char K2Node_CustomEvent_NewTeam;  // 0x51(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x52(0x1)
	char pad_83[5];  // 0x53(0x5)
	struct AActor* K2Node_ComponentBoundEvent_POISpawnPointActor;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_ComponentBoundEvent_bCloseBtn : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x68(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x88(0x1)
	char CallFunc_GetTeam_ReturnValue;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x8A(0x1)
	char CallFunc_GetValidValue_ReturnValue_2;  // 0x8B(0x1)
	char pad_140[4];  // 0x8C(0x4)
	struct AHDTeamState* K2Node_DynamicCast_AsTeam_State__HD_;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x98(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x99(0x1)
	char CallFunc_GetValidValue_ReturnValue_3;  // 0x9A(0x1)
	char pad_155[1];  // 0x9B(0x1)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x9C(0x38)
	float K2Node_Event_InDeltaTime;  // 0xD4(0x4)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xDA(0x1)
	char pad_219_1 : 7;  // 0xDB(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xDB(0x1)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	struct AHDGameState* CallFunc_GetHDGameState_HDGameState;  // 0xE0(0x8)
	char CallFunc_MakeLiteralByte_ReturnValue_2;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0xE9(0x1)
	char CallFunc_GetValidValue_ReturnValue_4;  // 0xEA(0x1)
	char pad_235[5];  // 0xEB(0x5)
	struct AHDGameState* CallFunc_GetHDGameState_HDGameState_2;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xFC(0x10)
	char pad_268[4];  // 0x10C(0x4)
	struct ADFTeamState* K2Node_CustomEvent_TeamState_2;  // 0x110(0x8)
	struct ADFTeamState* K2Node_CustomEvent_TeamState;  // 0x118(0x8)
	struct UDFFactionInfo* CallFunc_GetFactionInfo_ReturnValue;  // 0x120(0x8)
	struct UDFFactionInfo* CallFunc_GetFactionInfo_ReturnValue_2;  // 0x128(0x8)
	struct UBP_HDFactionInfoBase_C* K2Node_DynamicCast_AsBP_HDFaction_Info_Base;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct UBP_HDFactionInfoBase_C* K2Node_DynamicCast_AsBP_HDFaction_Info_Base_2;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x149(0x1)
	char pad_330_1 : 7;  // 0x14A(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x14A(0x1)
	char pad_331_1 : 7;  // 0x14B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x14B(0x1)
	char pad_332[4];  // 0x14C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x150(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x158(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base_2;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct UHDGameInstance* K2Node_DynamicCast_AsHDGame_Instance;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct FTimerHandle CallFunc_GetUnFreezeTimerHandle_ReturnValue;  // 0x180(0x8)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool CallFunc_K2_IsTimerActiveHandle_ReturnValue : 1;  // 0x188(0x1)
	char pad_393[7];  // 0x189(0x7)
	struct ADFTeamState* K2Node_CustomEvent_LastTeamState;  // 0x190(0x8)
	struct ADFTeamState* K2Node_CustomEvent_NewTeamState;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool K2Node_CustomEvent_bNewTeamStateInit : 1;  // 0x1A0(0x1)
	char pad_417[7];  // 0x1A1(0x7)
	struct AHDTeamState* K2Node_DynamicCast_AsTeam_State__HD__2;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x1B0(0x1)
	char pad_433_1 : 7;  // 0x1B1(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x1B1(0x1)
	char CallFunc_GetValidValue_ReturnValue_5;  // 0x1B2(0x1)
	char pad_435_1 : 7;  // 0x1B3(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1B3(0x1)
	char pad_436[4];  // 0x1B4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_3;  // 0x1B8(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base_3;  // 0x1C0(0x8)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x1C8(0x1)
	char pad_457[3];  // 0x1C9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1CC(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x1DC(0x10)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnPlayerTeamStateUpdated
// Size: 0x11(Inherited: 0x0) 
struct FOnPlayerTeamStateUpdated
{
	struct ADFTeamState* LastTeamState;  // 0x0(0x8)
	struct ADFTeamState* NewTeamState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bNewTeamStateInit : 1;  // 0x10(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnOpforPostInitTeam
// Size: 0x8(Inherited: 0x0) 
struct FOnOpforPostInitTeam
{
	struct ADFTeamState* TeamState;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnOwningCharDeath
// Size: 0x38(Inherited: 0x0) 
struct FOnOwningCharDeath
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.BndEvt__SpawnMapView_K2Node_ComponentBoundEvent_5_OnSpawnPointSelected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__SpawnMapView_K2Node_ComponentBoundEvent_5_OnSpawnPointSelected__DelegateSignature
{
	struct AActor* POISpawnPointActor;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__DeployBtn_K2Node_ComponentBoundEvent_7_OnClicked__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCloseBtn : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnPlayerTeamUpdated
// Size: 0x2(Inherited: 0x0) 
struct FOnPlayerTeamUpdated
{
	char PrevTeam;  // 0x0(0x1)
	char NewTeam;  // 0x1(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnPossessedPawn
// Size: 0x8(Inherited: 0x0) 
struct FOnPossessedPawn
{
	struct APawn* PossessedPawn;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamSwitchUISettings
// Size: 0x351(Inherited: 0x0) 
struct FUpdateTeamSwitchUISettings
{
	uint8_t  TeamToUpdate;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UBP_HDFactionInfoBase_C* FactionInfoToUse;  // 0x8(0x8)
	struct UImage* CheckmarkImageToUse;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bTeamSelected : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UImage* SelectionOverlayToUse;  // 0x20(0x8)
	struct FSlateBrush SelectionOverlayBrushToUse;  // 0x28(0x88)
	struct FButtonStyle ButtonStyleToUse;  // 0xB0(0x278)
	struct UButton* TeamSwitchBtnToUse;  // 0x328(0x8)
	uint8_t  Temp_byte_Variable;  // 0x330(0x1)
	char pad_817[7];  // 0x331(0x7)
	struct UBP_HDFactionInfoBase_C* Temp_object_Variable;  // 0x338(0x8)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x340(0x1)
	char pad_833[7];  // 0x341(0x7)
	struct UBP_HDFactionInfoBase_C* K2Node_Select_Default;  // 0x348(0x8)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x350(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.CleanupOwningPlayerDelegates
// Size: 0x89(Inherited: 0x0) 
struct FCleanupOwningPlayerDelegates
{
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x0(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x34(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x44(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x54(0x10)
	char pad_100[4];  // 0x64(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x68(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x70(0x10)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x88(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnUnpossessedPawn
// Size: 0x8(Inherited: 0x0) 
struct FOnUnpossessedPawn
{
	struct APawn* UnpossessedPawn;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnMouseButtonDown
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnMouseWheel
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseWheel : public FOnMouseWheel
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.TeamSwitch
// Size: 0x2C(Inherited: 0x0) 
struct FTeamSwitch
{
	uint8_t  NewTeam;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x28(0x1)
	char CallFunc_GetTeam_ReturnValue;  // 0x29(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x2B(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.InitTeamUI
// Size: 0x23(Inherited: 0x0) 
struct FInitTeamUI
{
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x0(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x20(0x1)
	char CallFunc_GetTeam_ReturnValue;  // 0x21(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x22(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamSwitchBtnState
// Size: 0x6(Inherited: 0x0) 
struct FUpdateTeamSwitchBtnState
{
	uint8_t  NewTeam;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x1(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x2(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamSwitchVisuals
// Size: 0x1100(Inherited: 0x0) 
struct FUpdateTeamSwitchVisuals
{
	uint8_t  TeamToUpdate;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UBP_HDFactionInfoBase_C* FactionInfoToUse;  // 0x8(0x8)
	struct UImage* CheckmarkImageToUse;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bTeamSelected : 1;  // 0x18(0x1)
	uint8_t  InTeamToUpdate;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UImage* SelectionOverlayToUse;  // 0x20(0x8)
	struct FSlateBrush SelectionOverlayBrushToUse;  // 0x28(0x88)
	struct FButtonStyle ButtonStyleToUse;  // 0xB0(0x278)
	struct UTextBlock* TeamSwitchBtnTextToUse;  // 0x328(0x8)
	struct UButton* TeamSwitchBtnToUse;  // 0x330(0x8)
	struct FText Temp_text_Variable;  // 0x338(0x18)
	struct FText Temp_text_Variable_2;  // 0x350(0x18)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool Temp_bool_Variable : 1;  // 0x368(0x1)
	uint8_t  Temp_byte_Variable;  // 0x369(0x1)
	char pad_874[6];  // 0x36A(0x6)
	struct UTextBlock* Temp_object_Variable;  // 0x370(0x8)
	uint8_t  Temp_byte_Variable_2;  // 0x378(0x1)
	char pad_889[7];  // 0x379(0x7)
	struct UBP_HDFactionInfoBase_C* Temp_object_Variable_2;  // 0x380(0x8)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x388(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x389(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x38A(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0x38B(0x1)
	char pad_908[4];  // 0x38C(0x4)
	struct UImage* Temp_object_Variable_3;  // 0x390(0x8)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x398(0x1)
	char pad_921_1 : 7;  // 0x399(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x399(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0x39A(0x1)
	char pad_923[5];  // 0x39B(0x5)
	struct FSlateBrush Temp_struct_Variable;  // 0x3A0(0x88)
	uint8_t  Temp_byte_Variable_7;  // 0x428(0x1)
	char pad_1065[7];  // 0x429(0x7)
	struct UImage* Temp_object_Variable_4;  // 0x430(0x8)
	char pad_1080_1 : 7;  // 0x438(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x438(0x1)
	char pad_1081_1 : 7;  // 0x439(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x439(0x1)
	uint8_t  Temp_byte_Variable_8;  // 0x43A(0x1)
	char pad_1083[5];  // 0x43B(0x5)
	struct FButtonStyle Temp_struct_Variable_2;  // 0x440(0x278)
	uint8_t  Temp_byte_Variable_9;  // 0x6B8(0x1)
	char pad_1721[7];  // 0x6B9(0x7)
	struct UButton* Temp_object_Variable_5;  // 0x6C0(0x8)
	char pad_1736_1 : 7;  // 0x6C8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x6C8(0x1)
	char pad_1737[7];  // 0x6C9(0x7)
	struct FText Temp_text_Variable_3;  // 0x6D0(0x18)
	char pad_1768_1 : 7;  // 0x6E8(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x6E8(0x1)
	char pad_1769_1 : 7;  // 0x6E9(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue_2 : 1;  // 0x6E9(0x1)
	char pad_1770[6];  // 0x6EA(0x6)
	struct UTextBlock* K2Node_Select_Default;  // 0x6F0(0x8)
	struct UBP_HDFactionInfoBase_C* K2Node_Select_Default_2;  // 0x6F8(0x8)
	char pad_1792_1 : 7;  // 0x700(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x700(0x1)
	char pad_1793[7];  // 0x701(0x7)
	struct UButton* K2Node_Select_Default_3;  // 0x708(0x8)
	uint8_t  K2Node_Select_Default_4;  // 0x710(0x1)
	char pad_1809[7];  // 0x711(0x7)
	struct UImage* K2Node_Select_Default_5;  // 0x718(0x8)
	char pad_1824_1 : 7;  // 0x720(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x720(0x1)
	uint8_t  Temp_byte_Variable_10;  // 0x721(0x1)
	char pad_1826[6];  // 0x722(0x6)
	struct FText K2Node_Select_Default_6;  // 0x728(0x18)
	struct FText K2Node_Select_Default_7;  // 0x740(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x758(0x40)
	struct FSlateBrush K2Node_Select_Default_8;  // 0x798(0x88)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x820(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x830(0x18)
	struct FSlateBrush K2Node_Select_Default_9;  // 0x848(0x88)
	struct FSlateBrush K2Node_Select_Default_10;  // 0x8D0(0x88)
	char pad_2392_1 : 7;  // 0x958(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x958(0x1)
	char pad_2393[7];  // 0x959(0x7)
	struct UImage* K2Node_Select_Default_11;  // 0x960(0x8)
	struct FText K2Node_Select_Default_12;  // 0x968(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x980(0x18)
	struct FButtonStyle K2Node_Select_Default_13;  // 0x998(0x278)
	struct FButtonStyle K2Node_Select_Default_14;  // 0xC10(0x278)
	struct FButtonStyle K2Node_Select_Default_15;  // 0xE88(0x278)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.InitOwningPlayerDelegates
// Size: 0x89(Inherited: 0x0) 
struct FInitOwningPlayerDelegates
{
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x0(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x34(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x44(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x54(0x10)
	char pad_100[4];  // 0x64(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x68(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x70(0x10)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x88(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.RequestSuicide
// Size: 0x12(Inherited: 0x0) 
struct FRequestSuicide
{
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x0(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x11(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.InitMapUI
// Size: 0x18(Inherited: 0x0) 
struct FInitMapUI
{
	struct FText CallFunc_GetMapNameForDisplay_ReturnValue;  // 0x0(0x18)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateSuicideBtnState
// Size: 0x12(Inherited: 0x0) 
struct FUpdateSuicideBtnState
{
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x0(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x11(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.CloseDeployMenu
// Size: 0x19(Inherited: 0x0) 
struct FCloseDeployMenu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bForce : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateDeployBtnState
// Size: 0x1A(Inherited: 0x0) 
struct FUpdateDeployBtnState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPlayerAlive : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x8(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.DeselectCurrentPOI
// Size: 0xA(Inherited: 0x0) 
struct FDeselectCurrentPOI
{
	struct UDFPOIWidget* CallFunc_FindPOIByActor_OutFoundPOI;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_FindPOIByActor_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.InitClassSelectionUI
// Size: 0x24(Inherited: 0x0) 
struct FInitClassSelectionUI
{
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x0(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x20(0x1)
	char CallFunc_GetTeam_ReturnValue;  // 0x21(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x23(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateMatchTime
// Size: 0xE8(Inherited: 0x0) 
struct FUpdateMatchTime
{
	struct AHDGameState* CallFunc_GetHDGameState_HDGameState;  // 0x0(0x8)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0xC(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x10(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x28(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x40(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x80(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xC0(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xD0(0x18)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTicketCounts
// Size: 0x38(Inherited: 0x0) 
struct FUpdateTicketCounts
{
	struct AHDGameState* CallFunc_GetHDGameState_HDGameState;  // 0x0(0x8)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x8(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x20(0x18)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.InitSquadSelectionUI
// Size: 0x40(Inherited: 0x0) 
struct FInitSquadSelectionUI
{
	struct AHDTeamState* Temp_object_Variable;  // 0x0(0x8)
	uint8_t  Temp_byte_Variable;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x10(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct AHDTeamState* K2Node_Select_Default;  // 0x38(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.SetTeamSwitchLayout
// Size: 0x5(Inherited: 0x0) 
struct FSetTeamSwitchLayout
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseVerticalLayout : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable : 1;  // 0x3(0x1)
	uint8_t  K2Node_Select_Default;  // 0x4(0x1)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.UpdateTeamLayoutElements
// Size: 0xA8(Inherited: 0x0) 
struct FUpdateTeamLayoutElements
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseVerticalLayout : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUpdateTeam0 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool Temp_bool_Variable_9 : 1;  // 0xB(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Temp_bool_Variable_10 : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1D(0x1)
	char pad_30[2];  // 0x1E(0x2)
	struct UTextBlock* K2Node_Select_Default;  // 0x20(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Temp_bool_Variable_11 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UButton* K2Node_Select_Default_2;  // 0x40(0x8)
	struct UButton* K2Node_Select_Default_3;  // 0x48(0x8)
	struct UWidget* K2Node_Select_Default_4;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UWidget* K2Node_Select_Default_5;  // 0x60(0x8)
	struct UTextBlock* K2Node_Select_Default_6;  // 0x68(0x8)
	struct UImage* K2Node_Select_Default_7;  // 0x70(0x8)
	struct UImage* K2Node_Select_Default_8;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool Temp_bool_Variable_12 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UTextBlock* K2Node_Select_Default_9;  // 0x88(0x8)
	struct UTextBlock* K2Node_Select_Default_10;  // 0x90(0x8)
	struct UImage* K2Node_Select_Default_11;  // 0x98(0x8)
	struct UImage* K2Node_Select_Default_12;  // 0xA0(0x8)

}; 
// Function WBP_DeployMenu.WBP_DeployMenu_C.OnPaint
// Size: 0x30(Inherited: 0x30) 
struct FOnPaint : public FOnPaint
{
	struct FPaintContext Context;  // 0x0(0x30)

}; 
