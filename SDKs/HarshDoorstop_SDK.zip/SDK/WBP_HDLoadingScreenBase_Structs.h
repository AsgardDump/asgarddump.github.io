#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetOpforStartingTicketCount
// Size: 0x70(Inherited: 0x0) 
struct FSetOpforStartingTicketCount
{
	int32_t TicketCount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x48(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x58(0x18)

}; 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.ExecuteUbergraph_WBP_HDLoadingScreenBase
// Size: 0x160(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HDLoadingScreenBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FLoadingScreenDescription K2Node_Event_Description;  // 0x8(0x38)
	struct TSoftObjectPtr<UTexture2D> CallFunc_Array_Get_Item;  // 0x40(0x28)
	struct FLoadScreenLevelData K2Node_Event_LevelData;  // 0x68(0x68)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_IsValidSoftObjectReference_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0xE9(0x1)
	char pad_234[6];  // 0xEA(0x6)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0xF0(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue_2;  // 0x108(0x18)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue_2 : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x121(0x1)
	uint8_t  Temp_byte_Variable;  // 0x122(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x123(0x1)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool Temp_bool_Variable : 1;  // 0x124(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x125(0x1)
	uint8_t  K2Node_Select_Default;  // 0x126(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x127(0x1)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x128(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x129(0x1)
	char pad_298[2];  // 0x12A(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x12C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x130(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x134(0x4)
	struct TSoftObjectPtr<UTexture2D> CallFunc_Array_Get_Item_2;  // 0x138(0x28)

}; 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetLevelLoadData
// Size: 0x68(Inherited: 0x0) 
struct FSetLevelLoadData
{
	struct FLoadScreenLevelData LevelData;  // 0x0(0x68)

}; 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetMapElementVisibility
// Size: 0x1(Inherited: 0x0) 
struct FSetMapElementVisibility
{
	uint8_t  NewVisibility;  // 0x0(0x1)

}; 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetLoadingScreenDescription
// Size: 0x38(Inherited: 0x0) 
struct FSetLoadingScreenDescription
{
	struct FLoadingScreenDescription Description;  // 0x0(0x38)

}; 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetBluforStartingTicketCount
// Size: 0x70(Inherited: 0x0) 
struct FSetBluforStartingTicketCount
{
	int32_t TicketCount;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x48(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x58(0x18)

}; 
// Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetMapBgImage
// Size: 0x39(Inherited: 0x0) 
struct FSetMapBgImage
{
	struct TSoftObjectPtr<UTexture2D> InBgImage;  // 0x0(0x28)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0x28(0x8)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)

}; 
