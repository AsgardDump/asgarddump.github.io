#pragma once 
#include <BPFL_RadialMenuHelpers_Structs.h>
 
 
 
// BlueprintGeneratedClass BPFL_RadialMenuHelpers.BPFL_RadialMenuHelpers_C
// Size: 0x28(Inherited: 0x28) 
struct UBPFL_RadialMenuHelpers_C : public UBlueprintFunctionLibrary
{

	void CenterMousePosition(int32_t PlayerIndex, struct APlayerController* PlayerController, struct UObject* __WorldContext); // Function BPFL_RadialMenuHelpers.BPFL_RadialMenuHelpers_C.CenterMousePosition
}; 



