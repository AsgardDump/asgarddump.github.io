#pragma once 
#include <SRadialMenuIconSettings_Structs.h>
 
 
 
