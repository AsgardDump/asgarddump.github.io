#pragma once 
#include <ChaosSolverEngine_Structs.h>
 
 
 
// Class ChaosSolverEngine.ChaosDebugDrawComponent
// Size: 0xB8(Inherited: 0xB0) 
struct UChaosDebugDrawComponent : public UActorComponent
{
	char pad_176[8];  // 0xB0(0x8)

}; 



// Class ChaosSolverEngine.ChaosSolverActor
// Size: 0x2A8(Inherited: 0x220) 
struct AChaosSolverActor : public AActor
{
	float TimeStepMultiplier;  // 0x220(0x4)
	int32_t CollisionIterations;  // 0x224(0x4)
	int32_t PushOutIterations;  // 0x228(0x4)
	int32_t PushOutPairIterations;  // 0x22C(0x4)
	float ClusterConnectionFactor;  // 0x230(0x4)
	uint8_t  ClusterUnionConnectionType;  // 0x234(0x1)
	char pad_565_1 : 7;  // 0x235(0x1)
	bool DoGenerateCollisionData : 1;  // 0x235(0x1)
	char pad_566[2];  // 0x236(0x2)
	struct FSolverCollisionFilterSettings CollisionFilterSettings;  // 0x238(0x10)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool DoGenerateBreakingData : 1;  // 0x248(0x1)
	char pad_585[3];  // 0x249(0x3)
	struct FSolverBreakingFilterSettings BreakingFilterSettings;  // 0x24C(0x10)
	char pad_604_1 : 7;  // 0x25C(0x1)
	bool DoGenerateTrailingData : 1;  // 0x25C(0x1)
	char pad_605[3];  // 0x25D(0x3)
	struct FSolverTrailingFilterSettings TrailingFilterSettings;  // 0x260(0x10)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool bHasFloor : 1;  // 0x270(0x1)
	char pad_625[3];  // 0x271(0x3)
	float FloorHeight;  // 0x274(0x4)
	float MassScale;  // 0x278(0x4)
	char pad_636_1 : 7;  // 0x27C(0x1)
	bool bGenerateContactGraph : 1;  // 0x27C(0x1)
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl;  // 0x27D(0x3)
	struct UBillboardComponent* SpriteComponent;  // 0x280(0x8)
	char pad_648[24];  // 0x288(0x18)
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent;  // 0x2A0(0x8)

	void SetSolverActive(bool bActive); // Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
	void SetAsCurrentWorldSolver(); // Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver
}; 



// Class ChaosSolverEngine.ChaosEventListenerComponent
// Size: 0xB8(Inherited: 0xB0) 
struct UChaosEventListenerComponent : public UActorComponent
{
	char pad_176[8];  // 0xB0(0x8)

}; 



// Class ChaosSolverEngine.ChaosSolver
// Size: 0x28(Inherited: 0x28) 
struct UChaosSolver : public UObject
{

}; 



// Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Size: 0x270(Inherited: 0xB8) 
struct UChaosGameplayEventDispatcher : public UChaosEventListenerComponent
{
	char pad_184[272];  // 0xB8(0x110)
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations;  // 0x1C8(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations;  // 0x218(0x50)
	char pad_616[8];  // 0x268(0x8)

}; 



// Class ChaosSolverEngine.ChaosSolverSettings
// Size: 0x58(Inherited: 0x38) 
struct UChaosSolverSettings : public UDeveloperSettings
{
	char pad_56[8];  // 0x38(0x8)
	struct FSoftClassPath DefaultChaosSolverActorClass;  // 0x40(0x18)

}; 



// Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Size: 0x28(Inherited: 0x28) 
struct UChaosNotifyHandlerInterface : public UInterface
{

}; 



// Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UChaosSolverEngineBlueprintLibrary : public UBlueprintFunctionLibrary
{

	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision); // Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
}; 



