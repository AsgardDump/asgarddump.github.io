#pragma once 
#include "SDK.h" 
 
 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.ExecuteUbergraph_WBP_GameModifierSettingsSection
// Size: 0x60(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_GameModifierSettingsSection
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	uint8_t  Temp_byte_Variable;  // 0x21(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x27(0x1)
	uint8_t  K2Node_Select_Default;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText K2Node_Select_Default_2;  // 0x30(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x48(0x18)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.BndEvt__SectionActiveToggleChkBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__SectionActiveToggleChkBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetTitleText
// Size: 0x30(Inherited: 0x0) 
struct FSetTitleText
{
	struct FText InTitleText;  // 0x0(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x18(0x18)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetIsActive
// Size: 0x1(Inherited: 0x0) 
struct FSetIsActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetExpansionState
// Size: 0x18(Inherited: 0x0) 
struct FSetExpansionState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bExpanded : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Temp_float_Variable;  // 0x4(0x4)
	float Temp_float_Variable_2;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	uint8_t  Temp_byte_Variable;  // 0xD(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xF(0x1)
	uint8_t  K2Node_Select_Default;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float K2Node_Select_Default_2;  // 0x14(0x4)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.IsExpanded
// Size: 0x1(Inherited: 0x0) 
struct FIsExpanded
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bExpanded : 1;  // 0x0(0x1)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.GetTitleText
// Size: 0x18(Inherited: 0x0) 
struct FGetTitleText
{
	struct FText TitleText;  // 0x0(0x18)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.IsActive
// Size: 0x1(Inherited: 0x0) 
struct FIsActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)

}; 
// Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.InternalRecursiveSetContentIsEnabled
// Size: 0x30(Inherited: 0x0) 
struct FInternalRecursiveSetContentIsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsEnabled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UWidget* CurWidget;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UPanelWidget* CallFunc_GetParent_ReturnValue;  // 0x18(0x8)
	struct UWidget* CallFunc_GetContent_ReturnValue;  // 0x20(0x8)
	struct UPanelWidget* CallFunc_GetParent_ReturnValue_2;  // 0x28(0x8)

}; 
