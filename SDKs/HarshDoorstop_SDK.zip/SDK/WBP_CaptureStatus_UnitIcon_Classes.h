#pragma once 
#include <WBP_CaptureStatus_UnitIcon_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C
// Size: 0x4B0(Inherited: 0x230) 
struct UWBP_CaptureStatus_UnitIcon_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* UnitIcon;  // 0x238(0x8)
	char ECaptureUnitType UnitType;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct FSlateBrush UnoccupiedUnitImage;  // 0x248(0x88)
	struct FSlateBrush FriendlyUnitImage;  // 0x2D0(0x88)
	struct FSlateBrush EnemyUnitImage;  // 0x358(0x88)
	struct FSlateBrush MultipleUnitImage;  // 0x3E0(0x88)
	char pad_1128_1 : 7;  // 0x468(0x1)
	bool bUseFriendlyUnitColor : 1;  // 0x468(0x1)
	char pad_1129[3];  // 0x469(0x3)
	struct FLinearColor UnoccupiedUnitColor;  // 0x46C(0x10)
	struct FLinearColor FriendlyUnitColor;  // 0x47C(0x10)
	struct FLinearColor EnemyUnitColor;  // 0x48C(0x10)
	char pad_1180_1 : 7;  // 0x49C(0x1)
	bool bUnitMultiple : 1;  // 0x49C(0x1)
	char pad_1181_1 : 7;  // 0x49D(0x1)
	bool bIsDesignTime : 1;  // 0x49D(0x1)
	char pad_1182[2];  // 0x49E(0x2)
	struct FLinearColor LocalUnitColorToUse;  // 0x4A0(0x10)

	void SetIsMultipleUnit(bool bNewUnitMultiple); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.SetIsMultipleUnit
	void SetUnitType(char ECaptureUnitType NewUnitType); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.SetUnitType
	void PreConstruct(bool IsDesignTime); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.PreConstruct
	void ExecuteUbergraph_WBP_CaptureStatus_UnitIcon(int32_t EntryPoint); // Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.ExecuteUbergraph_WBP_CaptureStatus_UnitIcon
}; 



