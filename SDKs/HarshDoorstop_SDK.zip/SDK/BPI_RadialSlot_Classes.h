#pragma once 
#include <BPI_RadialSlot_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_RadialSlot.BPI_RadialSlot_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_RadialSlot_C : public UInterface
{

	void OnUnhighlight(); // Function BPI_RadialSlot.BPI_RadialSlot_C.OnUnhighlight
	void OnHighlight(); // Function BPI_RadialSlot.BPI_RadialSlot_C.OnHighlight
}; 



