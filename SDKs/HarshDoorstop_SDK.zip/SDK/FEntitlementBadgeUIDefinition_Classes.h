#pragma once 
#include <FEntitlementBadgeUIDefinition_Structs.h>
 
 
 
