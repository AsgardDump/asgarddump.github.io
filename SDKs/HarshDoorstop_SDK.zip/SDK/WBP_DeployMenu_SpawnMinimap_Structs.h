#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnContentPreloadStarted
// Size: 0x20(Inherited: 0x0) 
struct FOnContentPreloadStarted
{
	struct TArray<struct TSoftObjectPtr<UObject>> AssetsToLoad;  // 0x0(0x10)
	struct TArray<struct TSoftClassPtr<UObject>> ClassesToLoad;  // 0x10(0x10)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnSpawnPointSelected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnSpawnPointSelected__DelegateSignature
{
	struct AActor* POISpawnPointActor;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ZoomOut
// Size: 0x14(Inherited: 0x0) 
struct FZoomOut
{
	float ZoomDecrement;  // 0x0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_FMax_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.UpdateMapMatParams
// Size: 0x8(Inherited: 0x0) 
struct FUpdateMapMatParams
{
	float CallFunc_BreakVector2D_X;  // 0x0(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x4(0x4)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseEnter
// Size: 0xA8(Inherited: 0xA8) 
struct FOnMouseEnter : public FOnMouseEnter
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnSpawnPointDeselected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnSpawnPointDeselected__DelegateSignature
{
	struct AActor* POISpawnPointActor;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseWheel
// Size: 0x225(Inherited: 0x160) 
struct FOnMouseWheel : public FOnMouseWheel
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)
	float CallFunc_PointerEvent_GetWheelDelta_ReturnValue;  // 0x218(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x21C(0x4)
	float CallFunc_SignOfFloat_ReturnValue;  // 0x220(0x4)
	char pad_900_1 : 7;  // 0x384(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x224(0x1)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseMove
// Size: 0x30C(Inherited: 0x160) 
struct FOnMouseMove : public FOnMouseMove
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FVector2D CallFunc_PointerEvent_GetCursorDelta_ReturnValue;  // 0x160(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x168(0x4)
	char pad_716_1 : 7;  // 0x2CC(0x1)
	bool CallFunc_PointerEvent_IsMouseButtonDown_ReturnValue : 1;  // 0x16C(0x1)
	struct FVector2D CallFunc_GetLocalSize_ReturnValue;  // 0x170(0x8)
	float CallFunc_BreakVector2D_X;  // 0x178(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x17C(0x4)
	struct FEventReply CallFunc_Unhandled_ReturnValue;  // 0x180(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x238(0xB8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x2F0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x2F4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x2F8(0x4)
	struct FVector2D CallFunc_Divide_Vector2DFloat_ReturnValue;  // 0x2FC(0x8)
	struct FVector2D CallFunc_Add_Vector2DVector2D_ReturnValue;  // 0x304(0x8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.InitMapBg
// Size: 0x10(Inherited: 0x0) 
struct FInitMapBg
{
	struct UTexture2D* MapTexture;  // 0x0(0x8)
	struct UMaterialInstanceDynamic* CallFunc_GetDynamicMaterial_ReturnValue;  // 0x8(0x8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ReceiveOnPOISelectionStateChanged
// Size: 0x9(Inherited: 0x10) 
struct FReceiveOnPOISelectionStateChanged : public FReceiveOnPOISelectionStateChanged
{
	struct UDFPOIWidget* POI;  // 0x0(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bSelected : 1;  // 0x8(0x1)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.UpdatePlayerPOIs
// Size: 0x32(Inherited: 0x0) 
struct FUpdatePlayerPOIs
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct ABP_HDPlayerCharacterBase_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct ABP_HDPlayerCharacterBase_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ExecuteUbergraph_WBP_DeployMenu_SpawnMinimap
// Size: 0x20A(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_SpawnMinimap
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* Temp_object_Variable;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FGeometry K2Node_Event_MyGeometry_2;  // 0x14(0x38)
	char pad_76[4];  // 0x4C(0x4)
	struct FPointerEvent K2Node_Event_MouseEvent;  // 0x50(0x70)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_PointerEvent_IsMouseButtonDown_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	struct FGeometry K2Node_Event_MyGeometry;  // 0xC4(0x38)
	float K2Node_Event_InDeltaTime;  // 0xFC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x100(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x104(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)
	struct UObject* K2Node_CustomEvent_Loaded_2;  // 0x110(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x118(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x11C(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x120(0x4)
	int32_t Temp_int_Variable;  // 0x124(0x4)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x128(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x129(0x1)
	char pad_298[6];  // 0x12A(0x6)
	struct TArray<struct TSoftObjectPtr<UObject>> K2Node_CustomEvent_AssetsToLoad;  // 0x130(0x10)
	struct TArray<struct TSoftClassPtr<UObject>> K2Node_CustomEvent_ClassesToLoad;  // 0x140(0x10)
	struct TSoftClassPtr<UObject> CallFunc_Array_Get_Item;  // 0x150(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x178(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x17C(0x4)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct TSoftObjectPtr<UObject> CallFunc_Array_Get_Item_2;  // 0x188(0x28)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x1B0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x1B4(0x4)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x1B8(0x1)
	char pad_441[3];  // 0x1B9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x1BC(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C0(0x10)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x1D0(0x1)
	char pad_465[3];  // 0x1D1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x1D4(0x4)
	UObject* Temp_class_Variable;  // 0x1D8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1E0(0x10)
	struct UDFPOIWidget* K2Node_Event_POI;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool K2Node_Event_bSelected : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	UObject* K2Node_CustomEvent_Loaded;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsPOIActorValid_ReturnValue : 1;  // 0x208(0x1)
	char pad_521_1 : 7;  // 0x209(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x209(0x1)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnLoaded_BB8D079144A98AFE7BD3849D43A40947
// Size: 0x8(Inherited: 0x0) 
struct FOnLoaded_BB8D079144A98AFE7BD3849D43A40947
{
	UObject* Loaded;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnLoaded_BACDC4954F814289E55DD7AAEBE3E34E
// Size: 0x8(Inherited: 0x0) 
struct FOnLoaded_BACDC4954F814289E55DD7AAEBE3E34E
{
	struct UObject* Loaded;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseButtonDown
// Size: 0x220(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool CallFunc_PointerEvent_IsMouseButtonDown_ReturnValue : 1;  // 0x160(0x1)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x168(0xB8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.GetLocalCursorDelta
// Size: 0xD8(Inherited: 0x0) 
struct FGetLocalCursorDelta
{
	struct FGeometry Geometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FVector2D LocalDelta;  // 0xA8(0x8)
	struct FVector2D CallFunc_PointerEvent_GetScreenSpacePosition_ReturnValue;  // 0xB0(0x8)
	struct FVector2D CallFunc_PointerEvent_GetLastScreenSpacePosition_ReturnValue;  // 0xB8(0x8)
	struct FVector2D CallFunc_AbsoluteToLocal_ReturnValue;  // 0xC0(0x8)
	struct FVector2D CallFunc_AbsoluteToLocal_ReturnValue_2;  // 0xC8(0x8)
	struct FVector2D CallFunc_Subtract_Vector2DVector2D_ReturnValue;  // 0xD0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseButtonUp
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonUp : public FOnMouseButtonUp
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ZoomIn
// Size: 0x14(Inherited: 0x0) 
struct FZoomIn
{
	float ZoomIncrement;  // 0x0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_FMax_ReturnValue;  // 0xC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x10(0x4)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.PreloadContent
// Size: 0x28(Inherited: 0x0) 
struct FPreloadContent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct TSoftObjectPtr<UObject>> K2Node_MakeArray_Array;  // 0x8(0x10)
	struct TArray<struct TSoftClassPtr<UObject>> K2Node_MakeArray_Array_2;  // 0x18(0x10)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ApplyPreloadedContent
// Size: 0x11(Inherited: 0x0) 
struct FApplyPreloadedContent
{
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x0(0x8)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.HasPreloadInProgress
// Size: 0x2(Inherited: 0x0) 
struct FHasPreloadInProgress
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPreloading : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.SetCurrentMapTexture
// Size: 0x8(Inherited: 0x0) 
struct FSetCurrentMapTexture
{
	struct UTexture2D* NewMapTexture;  // 0x0(0x8)

}; 
