#pragma once 
#include <WBP_BotsGameModifierSettings_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C
// Size: 0x250(Inherited: 0x230) 
struct UWBP_BotsGameModifierSettings_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_GameModifierSettingsSection_C* SectionContainer;  // 0x238(0x8)
	struct UWBP_ModifierSetting_Numeric_C* TeamBotCountBlufor;  // 0x240(0x8)
	struct UWBP_ModifierSetting_Numeric_C* TeamBotCountOpfor;  // 0x248(0x8)

	void GetTravelURLOptions(struct FString& Options); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.GetTravelURLOptions
	void IsEnabled(bool& bEnabled); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.IsEnabled
	void BuildBotCountURLOption(uint8_t  Team, int32_t Count, struct FString& Pair); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.BuildBotCountURLOption
	void SetupModifier(struct UWBP_OptionMenu_CreateGame_C* ParentMenu); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.SetupModifier
	void ExecuteUbergraph_WBP_BotsGameModifierSettings(int32_t EntryPoint); // Function WBP_BotsGameModifierSettings.WBP_BotsGameModifierSettings_C.ExecuteUbergraph_WBP_BotsGameModifierSettings
}; 



