#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Niagara.NiagaraID
// Size: 0x8(Inherited: 0x0) 
struct FNiagaraID
{
	int32_t Index;  // 0x0(0x4)
	int32_t AcquireTag;  // 0x4(0x4)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraParameterSectionTemplate
// Size: 0x48(Inherited: 0x20) 
struct FMovieSceneNiagaraParameterSectionTemplate : public FMovieSceneEvalTemplate
{
	struct FNiagaraVariable Parameter;  // 0x20(0x28)

}; 
// ScriptStruct Niagara.NiagaraMatrix
// Size: 0x40(Inherited: 0x0) 
struct FNiagaraMatrix
{
	struct FVector4 Row0;  // 0x0(0x10)
	struct FVector4 Row1;  // 0x10(0x10)
	struct FVector4 Row2;  // 0x20(0x10)
	struct FVector4 Row3;  // 0x30(0x10)

}; 
// DelegateFunction Niagara.OnNiagaraSystemFinished__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnNiagaraSystemFinished__DelegateSignature
{
	struct UNiagaraComponent* PSystem;  // 0x0(0x8)

}; 
// ScriptStruct Niagara.NiagaraPlatformSetConflictEntry
// Size: 0xC(Inherited: 0x0) 
struct FNiagaraPlatformSetConflictEntry
{
	struct FName ProfileName;  // 0x0(0x8)
	int32_t QualityLevelMask;  // 0x8(0x4)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraColorParameterSectionTemplate
// Size: 0x2C8(Inherited: 0x48) 
struct FMovieSceneNiagaraColorParameterSectionTemplate : public FMovieSceneNiagaraParameterSectionTemplate
{
	struct FMovieSceneFloatChannel RedChannel;  // 0x48(0xA0)
	struct FMovieSceneFloatChannel GreenChannel;  // 0xE8(0xA0)
	struct FMovieSceneFloatChannel BlueChannel;  // 0x188(0xA0)
	struct FMovieSceneFloatChannel AlphaChannel;  // 0x228(0xA0)

}; 
// ScriptStruct Niagara.NiagaraSystemScalabilityOverrides
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraSystemScalabilityOverrides
{
	struct TArray<struct FNiagaraSystemScalabilityOverride> Overrides;  // 0x0(0x10)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetQuatParameter
// Size: 0x20(Inherited: 0x0) 
struct FSetQuatParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FQuat InValue;  // 0x10(0x10)

}; 
// ScriptStruct Niagara.NiagaraEmitterScalabilitySettingsArray
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraEmitterScalabilitySettingsArray
{
	struct TArray<struct FNiagaraEmitterScalabilitySettings> Settings;  // 0x0(0x10)

}; 
// Function Niagara.NiagaraPreviewAxis.Num
// Size: 0x4(Inherited: 0x0) 
struct FNum
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct Niagara.NiagaraTypeDefinition
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraTypeDefinition
{
	struct UObject* ClassStructOrEnum;  // 0x0(0x8)
	uint16_t UnderlyingType;  // 0x8(0x2)
	char pad_10[6];  // 0xA(0x6)

}; 
// ScriptStruct Niagara.NiagaraVariableBase
// Size: 0x18(Inherited: 0x0) 
struct FNiagaraVariableBase
{
	struct FName Name;  // 0x0(0x8)
	struct FNiagaraTypeDefinition TypeDef;  // 0x8(0x10)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetColorParameter
// Size: 0x20(Inherited: 0x0) 
struct FGetColorParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FLinearColor ReturnValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraFunctionLibrary.SpawnSystemAttached
// Size: 0x40(Inherited: 0x0) 
struct FSpawnSystemAttached
{
	struct UNiagaraSystem* SystemTemplate;  // 0x0(0x8)
	struct USceneComponent* AttachToComponent;  // 0x8(0x8)
	struct FName AttachPointName;  // 0x10(0x8)
	struct FVector Location;  // 0x18(0xC)
	struct FRotator Rotation;  // 0x24(0xC)
	char EAttachLocation LocationType;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bAutoDestroy : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool bAutoActivate : 1;  // 0x32(0x1)
	uint8_t  PoolingMethod;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bPreCullCheck : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct UNiagaraComponent* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct Niagara.NiagaraVariable
// Size: 0x28(Inherited: 0x18) 
struct FNiagaraVariable : public FNiagaraVariableBase
{
	struct TArray<char> VarData;  // 0x18(0x10)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraBoolParameterSectionTemplate
// Size: 0xD8(Inherited: 0x48) 
struct FMovieSceneNiagaraBoolParameterSectionTemplate : public FMovieSceneNiagaraParameterSectionTemplate
{
	struct FMovieSceneBoolChannel BoolChannel;  // 0x48(0x90)

}; 
// ScriptStruct Niagara.NiagaraVariableWithOffset
// Size: 0x20(Inherited: 0x18) 
struct FNiagaraVariableWithOffset : public FNiagaraVariableBase
{
	int32_t Offset;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct Niagara.NiagaraVariableDataInterfaceBinding
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraVariableDataInterfaceBinding
{
	struct FNiagaraVariable BoundVariable;  // 0x0(0x28)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraFloatParameterSectionTemplate
// Size: 0xE8(Inherited: 0x48) 
struct FMovieSceneNiagaraFloatParameterSectionTemplate : public FMovieSceneNiagaraParameterSectionTemplate
{
	struct FMovieSceneFloatChannel FloatChannel;  // 0x48(0xA0)

}; 
// Function Niagara.NiagaraComponent.AdvanceSimulation
// Size: 0x8(Inherited: 0x0) 
struct FAdvanceSimulation
{
	int32_t TickCount;  // 0x0(0x4)
	float TickDeltaSeconds;  // 0x4(0x4)

}; 
// ScriptStruct Niagara.NiagaraEventScriptProperties
// Size: 0x58(Inherited: 0x28) 
struct FNiagaraEventScriptProperties : public FNiagaraEmitterScriptProperties
{
	uint8_t  ExecutionMode;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	uint32_t SpawnNumber;  // 0x2C(0x4)
	uint32_t MaxEventsPerFrame;  // 0x30(0x4)
	struct FGuid SourceEmitterID;  // 0x34(0x10)
	struct FName SourceEventName;  // 0x44(0x8)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool bRandomSpawnNumber : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	uint32_t MinSpawnNumber;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraIntegerParameterSectionTemplate
// Size: 0xD8(Inherited: 0x48) 
struct FMovieSceneNiagaraIntegerParameterSectionTemplate : public FMovieSceneNiagaraParameterSectionTemplate
{
	struct FMovieSceneIntegerChannel IntegerChannel;  // 0x48(0x90)

}; 
// ScriptStruct Niagara.NiagaraGraphViewSettings
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraGraphViewSettings
{
	struct FVector2D Location;  // 0x0(0x8)
	float Zoom;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bIsValid : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraSystemTrackImplementation
// Size: 0x28(Inherited: 0x10) 
struct FMovieSceneNiagaraSystemTrackImplementation : public FMovieSceneTrackImplementation
{
	struct FFrameNumber SpawnSectionStartFrame;  // 0x10(0x4)
	struct FFrameNumber SpawnSectionEndFrame;  // 0x14(0x4)
	uint8_t  SpawnSectionStartBehavior;  // 0x18(0x4)
	uint8_t  SpawnSectionEvaluateBehavior;  // 0x1C(0x4)
	uint8_t  SpawnSectionEndBehavior;  // 0x20(0x4)
	uint8_t  AgeUpdateMode;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct Niagara.NiagaraScriptDataInterfaceCompileInfo
// Size: 0x38(Inherited: 0x0) 
struct FNiagaraScriptDataInterfaceCompileInfo
{
	struct FName Name;  // 0x0(0x8)
	int32_t UserPtrIdx;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FNiagaraTypeDefinition Type;  // 0x10(0x10)
	struct FName RegisteredParameterMapRead;  // 0x20(0x8)
	struct FName RegisteredParameterMapWrite;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bIsPlaceholder : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct Niagara.NiagaraUserParameterBinding
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraUserParameterBinding
{
	struct FNiagaraVariable Parameter;  // 0x0(0x28)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraSystemTrackTemplate
// Size: 0x20(Inherited: 0x20) 
struct FMovieSceneNiagaraSystemTrackTemplate : public FMovieSceneEvalTemplate
{

}; 
// ScriptStruct Niagara.NiagaraSystemScalabilitySettings
// Size: 0x30(Inherited: 0x0) 
struct FNiagaraSystemScalabilitySettings
{
	struct FNiagaraPlatformSet Platforms;  // 0x0(0x20)
	char bCullByDistance : 1;  // 0x20(0x1)
	char bCullMaxInstanceCount : 1;  // 0x20(0x1)
	char bCullByMaxTimeWithoutRender : 1;  // 0x20(0x1)
	char pad_32_1 : 5;  // 0x20(0x1)
	char pad_33[4];  // 0x21(0x4)
	float MaxDistance;  // 0x24(0x4)
	float MaxInstances;  // 0x28(0x4)
	float MaxTimeWithoutRender;  // 0x2C(0x4)

}; 
// Function Niagara.NiagaraComponent.GetMaxSimTime
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxSimTime
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct Niagara.NiagaraTestStruct
// Size: 0x48(Inherited: 0x0) 
struct FNiagaraTestStruct
{
	struct FVector Vector1;  // 0x0(0xC)
	struct FVector Vector2;  // 0xC(0xC)
	struct FNiagaraTestStructInner InnerStruct1;  // 0x18(0x18)
	struct FNiagaraTestStructInner InnerStruct2;  // 0x30(0x18)

}; 
// ScriptStruct Niagara.MovieSceneNiagaraVectorParameterSectionTemplate
// Size: 0x2D0(Inherited: 0x48) 
struct FMovieSceneNiagaraVectorParameterSectionTemplate : public FMovieSceneNiagaraParameterSectionTemplate
{
	struct FMovieSceneFloatChannel VectorChannels[4];  // 0x48(0x280)
	int32_t ChannelsUsed;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)

}; 
// ScriptStruct Niagara.BasicParticleData
// Size: 0x1C(Inherited: 0x0) 
struct FBasicParticleData
{
	struct FVector Position;  // 0x0(0xC)
	float Size;  // 0xC(0x4)
	struct FVector Velocity;  // 0x10(0xC)

}; 
// ScriptStruct Niagara.NiagaraDataSetProperties
// Size: 0x20(Inherited: 0x0) 
struct FNiagaraDataSetProperties
{
	struct FNiagaraDataSetID ID;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FNiagaraVariable> Variables;  // 0x10(0x10)

}; 
// ScriptStruct Niagara.NiagaraRandInfo
// Size: 0xC(Inherited: 0x0) 
struct FNiagaraRandInfo
{
	int32_t Seed1;  // 0x0(0x4)
	int32_t Seed2;  // 0x4(0x4)
	int32_t Seed3;  // 0x8(0x4)

}; 
// ScriptStruct Niagara.NiagaraScriptVariableBinding
// Size: 0x8(Inherited: 0x0) 
struct FNiagaraScriptVariableBinding
{
	struct FName Name;  // 0x0(0x8)

}; 
// ScriptStruct Niagara.NiagaraVariableAttributeBinding
// Size: 0x78(Inherited: 0x0) 
struct FNiagaraVariableAttributeBinding
{
	struct FNiagaraVariable BoundVariable;  // 0x0(0x28)
	struct FNiagaraVariable DataSetVariable;  // 0x28(0x28)
	struct FNiagaraVariable DefaultValueIfNonExistent;  // 0x50(0x28)

}; 
// ScriptStruct Niagara.NiagaraVariableInfo
// Size: 0x48(Inherited: 0x0) 
struct FNiagaraVariableInfo
{
	struct FNiagaraVariable Variable;  // 0x0(0x28)
	struct FText Definition;  // 0x28(0x18)
	struct UNiagaraDataInterface* DataInterface;  // 0x40(0x8)

}; 
// ScriptStruct Niagara.NiagaraDataSetCompiledData
// Size: 0x40(Inherited: 0x0) 
struct FNiagaraDataSetCompiledData
{
	struct TArray<struct FNiagaraVariable> Variables;  // 0x0(0x10)
	struct TArray<struct FNiagaraVariableLayoutInfo> VariableLayouts;  // 0x10(0x10)
	uint32_t TotalFloatComponents;  // 0x20(0x4)
	uint32_t TotalInt32Components;  // 0x24(0x4)
	char bRequiresPersistentIDs : 1;  // 0x28(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	char pad_41[4];  // 0x29(0x4)
	struct FNiagaraDataSetID ID;  // 0x2C(0xC)
	uint8_t  SimTarget;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct Niagara.NiagaraSystemUpdateContext
// Size: 0x38(Inherited: 0x0) 
struct FNiagaraSystemUpdateContext
{
	struct TArray<struct UNiagaraComponent*> ComponentsToReset;  // 0x0(0x10)
	struct TArray<struct UNiagaraComponent*> ComponentsToReInit;  // 0x10(0x10)
	struct TArray<struct UNiagaraSystem*> SystemSimsToDestroy;  // 0x20(0x10)
	char pad_48[8];  // 0x30(0x8)

}; 
// ScriptStruct Niagara.VMExternalFunctionBindingInfo
// Size: 0x38(Inherited: 0x0) 
struct FVMExternalFunctionBindingInfo
{
	struct FName Name;  // 0x0(0x8)
	struct FName OwnerName;  // 0x8(0x8)
	struct TArray<bool> InputParamLocations;  // 0x10(0x10)
	int32_t NumOutputs;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct FVMFunctionSpecifier> FunctionSpecifiers;  // 0x28(0x10)

}; 
// ScriptStruct Niagara.VMFunctionSpecifier
// Size: 0x10(Inherited: 0x0) 
struct FVMFunctionSpecifier
{
	struct FName Key;  // 0x0(0x8)
	struct FName Value;  // 0x8(0x8)

}; 
// ScriptStruct Niagara.NiagaraStatScope
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraStatScope
{
	struct FName FullName;  // 0x0(0x8)
	struct FName FriendlyName;  // 0x8(0x8)

}; 
// ScriptStruct Niagara.NiagaraEmitterScalabilityOverrides
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraEmitterScalabilityOverrides
{
	struct TArray<struct FNiagaraEmitterScalabilityOverride> Overrides;  // 0x0(0x10)

}; 
// ScriptStruct Niagara.NCPool
// Size: 0x38(Inherited: 0x0) 
struct FNCPool
{
	struct TArray<struct FNCPoolElement> FreeElements;  // 0x0(0x10)
	struct TArray<struct UNiagaraComponent*> InUseComponents_Auto;  // 0x10(0x10)
	struct TArray<struct UNiagaraComponent*> InUseComponents_Manual;  // 0x20(0x10)
	char pad_48[8];  // 0x30(0x8)

}; 
// ScriptStruct Niagara.NiagaraScriptDataInterfaceInfo
// Size: 0x38(Inherited: 0x0) 
struct FNiagaraScriptDataInterfaceInfo
{
	struct UNiagaraDataInterface* DataInterface;  // 0x0(0x8)
	struct FName Name;  // 0x8(0x8)
	int32_t UserPtrIdx;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FNiagaraTypeDefinition Type;  // 0x18(0x10)
	struct FName RegisteredParameterMapRead;  // 0x28(0x8)
	struct FName RegisteredParameterMapWrite;  // 0x30(0x8)

}; 
// ScriptStruct Niagara.NiagaraFunctionSignature
// Size: 0x88(Inherited: 0x0) 
struct FNiagaraFunctionSignature
{
	struct FName Name;  // 0x0(0x8)
	struct TArray<struct FNiagaraVariable> Inputs;  // 0x8(0x10)
	struct TArray<struct FNiagaraVariable> Outputs;  // 0x18(0x10)
	struct FName OwnerName;  // 0x28(0x8)
	char bRequiresContext : 1;  // 0x30(0x1)
	char bMemberFunction : 1;  // 0x30(0x1)
	char bExperimental : 1;  // 0x30(0x1)
	char bSupportsCPU : 1;  // 0x30(0x1)
	char bSupportsGPU : 1;  // 0x30(0x1)
	char bWriteFunction : 1;  // 0x30(0x1)
	char pad_48_1 : 2;  // 0x30(0x1)
	char pad_49[8];  // 0x31(0x8)
	struct TMap<struct FName, struct FName> FunctionSpecifiers;  // 0x38(0x50)

}; 
// ScriptStruct Niagara.NiagaraScalabilityManager
// Size: 0x40(Inherited: 0x0) 
struct FNiagaraScalabilityManager
{
	struct UNiagaraEffectType* EffectType;  // 0x0(0x8)
	struct TArray<struct UNiagaraComponent*> ManagedComponents;  // 0x8(0x10)
	char pad_24[40];  // 0x18(0x28)

}; 
// ScriptStruct Niagara.NiagaraScriptDataUsageInfo
// Size: 0x1(Inherited: 0x0) 
struct FNiagaraScriptDataUsageInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bReadsAttributeData : 1;  // 0x0(0x1)

}; 
// ScriptStruct Niagara.NiagaraDataSetID
// Size: 0xC(Inherited: 0x0) 
struct FNiagaraDataSetID
{
	struct FName Name;  // 0x0(0x8)
	uint8_t  Type;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// ScriptStruct Niagara.NCPoolElement
// Size: 0x10(Inherited: 0x0) 
struct FNCPoolElement
{
	struct UNiagaraComponent* Component;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)

}; 
// Function Niagara.NiagaraComponent.GetSeekDelta
// Size: 0x4(Inherited: 0x0) 
struct FGetSeekDelta
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct Niagara.MeshTriCoordinate
// Size: 0x10(Inherited: 0x0) 
struct FMeshTriCoordinate
{
	int32_t Tri;  // 0x0(0x4)
	struct FVector BaryCoord;  // 0x4(0xC)

}; 
// ScriptStruct Niagara.NDIStaticMeshSectionFilter
// Size: 0x10(Inherited: 0x0) 
struct FNDIStaticMeshSectionFilter
{
	struct TArray<int32_t> AllowedMaterialSlots;  // 0x0(0x10)

}; 
// ScriptStruct Niagara.NiagaraSystemScalabilitySettingsArray
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraSystemScalabilitySettingsArray
{
	struct TArray<struct FNiagaraSystemScalabilitySettings> Settings;  // 0x0(0x10)

}; 
// ScriptStruct Niagara.NiagaraVariableLayoutInfo
// Size: 0x48(Inherited: 0x0) 
struct FNiagaraVariableLayoutInfo
{
	uint32_t FloatComponentStart;  // 0x0(0x4)
	uint32_t Int32ComponentStart;  // 0x4(0x4)
	struct FNiagaraTypeLayoutInfo LayoutInfo;  // 0x8(0x40)

}; 
// ScriptStruct Niagara.NiagaraTypeLayoutInfo
// Size: 0x40(Inherited: 0x0) 
struct FNiagaraTypeLayoutInfo
{
	struct TArray<uint32_t> FloatComponentByteOffsets;  // 0x0(0x10)
	struct TArray<uint32_t> FloatComponentRegisterOffsets;  // 0x10(0x10)
	struct TArray<uint32_t> Int32ComponentByteOffsets;  // 0x20(0x10)
	struct TArray<uint32_t> Int32ComponentRegisterOffsets;  // 0x30(0x10)

}; 
// ScriptStruct Niagara.NiagaraEmitterScalabilitySettings
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraEmitterScalabilitySettings
{
	struct FNiagaraPlatformSet Platforms;  // 0x0(0x20)
	char bScaleSpawnCount : 1;  // 0x20(0x1)
	char pad_32_1 : 7;  // 0x20(0x1)
	char pad_33[4];  // 0x21(0x4)
	float SpawnCountScale;  // 0x24(0x4)

}; 
// ScriptStruct Niagara.NiagaraPlatformSet
// Size: 0x20(Inherited: 0x0) 
struct FNiagaraPlatformSet
{
	int32_t QualityLevelMask;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FNiagaraDeviceProfileStateEntry> DeviceProfileStates;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)

}; 
// ScriptStruct Niagara.NiagaraEventReceiverProperties
// Size: 0x18(Inherited: 0x0) 
struct FNiagaraEventReceiverProperties
{
	struct FName Name;  // 0x0(0x8)
	struct FName SourceEventGenerator;  // 0x8(0x8)
	struct FName SourceEmitter;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraComponent.SetRenderingEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetRenderingEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInRenderingEnabled : 1;  // 0x0(0x1)

}; 
// ScriptStruct Niagara.NiagaraEmitterScriptProperties
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraEmitterScriptProperties
{
	struct UNiagaraScript* Script;  // 0x0(0x8)
	struct TArray<struct FNiagaraEventReceiverProperties> EventReceivers;  // 0x8(0x10)
	struct TArray<struct FNiagaraEventGeneratorProperties> EventGenerators;  // 0x18(0x10)

}; 
// ScriptStruct Niagara.NiagaraDeviceProfileStateEntry
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraDeviceProfileStateEntry
{
	struct FName ProfileName;  // 0x0(0x8)
	uint32_t QualityLevelMask;  // 0x8(0x4)
	uint32_t SetQualityLevelMask;  // 0xC(0x4)

}; 
// Function Niagara.NiagaraPreviewGrid.SetPaused
// Size: 0x1(Inherited: 0x0) 
struct FSetPaused
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPaused : 1;  // 0x0(0x1)

}; 
// ScriptStruct Niagara.NiagaraEmitterScalabilityOverride
// Size: 0x30(Inherited: 0x28) 
struct FNiagaraEmitterScalabilityOverride : public FNiagaraEmitterScalabilitySettings
{
	char bOverrideSpawnCountScale : 1;  // 0x28(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	char pad_41[8];  // 0x29(0x8)

}; 
// Function Niagara.NiagaraComponent.GetForceSolo
// Size: 0x1(Inherited: 0x0) 
struct FGetForceSolo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct Niagara.NiagaraBoundParameter
// Size: 0x30(Inherited: 0x0) 
struct FNiagaraBoundParameter
{
	struct FNiagaraVariable Parameter;  // 0x0(0x28)
	int32_t SrcOffset;  // 0x28(0x4)
	int32_t DestOffset;  // 0x2C(0x4)

}; 
// ScriptStruct Niagara.NiagaraSystemScalabilityOverride
// Size: 0x38(Inherited: 0x30) 
struct FNiagaraSystemScalabilityOverride : public FNiagaraSystemScalabilitySettings
{
	char bOverrideDistanceSettings : 1;  // 0x30(0x1)
	char bOverrideInstanceCountSettings : 1;  // 0x30(0x1)
	char bOverrideTimeSinceRendererSettings : 1;  // 0x30(0x1)
	char pad_48_1 : 5;  // 0x30(0x1)
	char pad_49[8];  // 0x31(0x8)

}; 
// ScriptStruct Niagara.NiagaraDetailsLevelScaleOverrides
// Size: 0x14(Inherited: 0x0) 
struct FNiagaraDetailsLevelScaleOverrides
{
	float Low;  // 0x0(0x4)
	float Medium;  // 0x4(0x4)
	float High;  // 0x8(0x4)
	float Epic;  // 0xC(0x4)
	float Cine;  // 0x10(0x4)

}; 
// ScriptStruct Niagara.NiagaraEventGeneratorProperties
// Size: 0x50(Inherited: 0x0) 
struct FNiagaraEventGeneratorProperties
{
	int32_t MaxEventsPerFrame;  // 0x0(0x4)
	struct FName ID;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct FNiagaraDataSetCompiledData DataSetCompiledData;  // 0x10(0x40)

}; 
// ScriptStruct Niagara.NiagaraEmitterHandle
// Size: 0x30(Inherited: 0x0) 
struct FNiagaraEmitterHandle
{
	struct FGuid ID;  // 0x0(0x10)
	struct FName IdName;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bIsEnabled : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FName Name;  // 0x1C(0x8)
	char pad_36[4];  // 0x24(0x4)
	struct UNiagaraEmitter* Instance;  // 0x28(0x8)

}; 
// ScriptStruct Niagara.NiagaraParameterDataSetBinding
// Size: 0x8(Inherited: 0x0) 
struct FNiagaraParameterDataSetBinding
{
	int32_t ParameterOffset;  // 0x0(0x4)
	int32_t DataSetComponentOffset;  // 0x4(0x4)

}; 
// ScriptStruct Niagara.NiagaraCollisionEventPayload
// Size: 0x2C(Inherited: 0x0) 
struct FNiagaraCollisionEventPayload
{
	struct FVector CollisionPos;  // 0x0(0xC)
	struct FVector CollisionNormal;  // 0xC(0xC)
	struct FVector CollisionVelocity;  // 0x18(0xC)
	int32_t ParticleIndex;  // 0x24(0x4)
	int32_t PhysicalMaterialIndex;  // 0x28(0x4)

}; 
// ScriptStruct Niagara.NiagaraParameters
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraParameters
{
	struct TArray<struct FNiagaraVariable> Parameters;  // 0x0(0x10)

}; 
// ScriptStruct Niagara.NiagaraMeshMaterialOverride
// Size: 0x30(Inherited: 0x0) 
struct FNiagaraMeshMaterialOverride
{
	struct UMaterialInterface* ExplicitMat;  // 0x0(0x8)
	struct FNiagaraUserParameterBinding UserParamBinding;  // 0x8(0x28)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetBoolParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetBoolParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool InValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct Niagara.NiagaraParameterStore
// Size: 0xB8(Inherited: 0x0) 
struct FNiagaraParameterStore
{
	char pad_0[8];  // 0x0(0x8)
	struct UObject* Owner;  // 0x8(0x8)
	struct TArray<struct FNiagaraVariableWithOffset> SortedParameterOffsets;  // 0x10(0x10)
	struct TArray<char> ParameterData;  // 0x20(0x10)
	struct TArray<struct UNiagaraDataInterface*> DataInterfaces;  // 0x30(0x10)
	struct TArray<struct UObject*> UObjects;  // 0x40(0x10)
	char pad_80[104];  // 0x50(0x68)

}; 
// ScriptStruct Niagara.NiagaraPlatformSetConflictInfo
// Size: 0x18(Inherited: 0x0) 
struct FNiagaraPlatformSetConflictInfo
{
	int32_t SetAIndex;  // 0x0(0x4)
	int32_t SetBIndex;  // 0x4(0x4)
	struct TArray<struct FNiagaraPlatformSetConflictEntry> Conflicts;  // 0x8(0x10)

}; 
// Function Niagara.NiagaraFunctionLibrary.SpawnSystemAtLocation
// Size: 0x40(Inherited: 0x0) 
struct FSpawnSystemAtLocation
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UNiagaraSystem* SystemTemplate;  // 0x8(0x8)
	struct FVector Location;  // 0x10(0xC)
	struct FRotator Rotation;  // 0x1C(0xC)
	struct FVector Scale;  // 0x28(0xC)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bAutoDestroy : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool bAutoActivate : 1;  // 0x35(0x1)
	uint8_t  PoolingMethod;  // 0x36(0x1)
	char pad_55_1 : 7;  // 0x37(0x1)
	bool bPreCullCheck : 1;  // 0x37(0x1)
	struct UNiagaraComponent* ReturnValue;  // 0x38(0x8)

}; 
// Function Niagara.NiagaraFunctionLibrary.GetNiagaraParameterCollection
// Size: 0x18(Inherited: 0x0) 
struct FGetNiagaraParameterCollection
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UNiagaraParameterCollection* Collection;  // 0x8(0x8)
	struct UNiagaraParameterCollectionInstance* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct Niagara.NiagaraVMExecutableData
// Size: 0x128(Inherited: 0x0) 
struct FNiagaraVMExecutableData
{
	struct TArray<char> ByteCode;  // 0x0(0x10)
	struct TArray<char> OptimizedByteCode;  // 0x10(0x10)
	int32_t NumTempRegisters;  // 0x20(0x4)
	int32_t NumUserPtrs;  // 0x24(0x4)
	struct FNiagaraParameters Parameters;  // 0x28(0x10)
	struct FNiagaraParameters InternalParameters;  // 0x38(0x10)
	struct TMap<struct FName, struct FNiagaraParameters> DataSetToParameters;  // 0x48(0x50)
	struct TArray<struct FNiagaraVariable> Attributes;  // 0x98(0x10)
	struct FNiagaraScriptDataUsageInfo DataUsage;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct TArray<struct FNiagaraScriptDataInterfaceCompileInfo> DataInterfaceInfo;  // 0xB0(0x10)
	struct TArray<struct FVMExternalFunctionBindingInfo> CalledVMExternalFunctions;  // 0xC0(0x10)
	struct TArray<struct FNiagaraDataSetID> ReadDataSets;  // 0xD0(0x10)
	struct TArray<struct FNiagaraDataSetProperties> WriteDataSets;  // 0xE0(0x10)
	struct TArray<struct FNiagaraStatScope> StatScopes;  // 0xF0(0x10)
	struct TArray<struct FNiagaraDataInterfaceGPUParamInfo> DIParamInfo;  // 0x100(0x10)
	uint8_t  LastCompileStatus;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct TArray<struct FSimulationStageMetaData> SimulationStageMetaData;  // 0x118(0x10)

}; 
// ScriptStruct Niagara.SimulationStageMetaData
// Size: 0x28(Inherited: 0x0) 
struct FSimulationStageMetaData
{
	struct FName IterationSource;  // 0x0(0x8)
	char bSpawnOnly : 1;  // 0x8(0x1)
	char bWritesParticles : 1;  // 0x8(0x1)
	char pad_8_1 : 6;  // 0x8(0x1)
	char pad_9[8];  // 0x9(0x8)
	struct TArray<struct FName> OutputDestinations;  // 0x10(0x10)
	int32_t MinStage;  // 0x20(0x4)
	int32_t MaxStage;  // 0x24(0x4)

}; 
// ScriptStruct Niagara.NiagaraVMExecutableDataId
// Size: 0x48(Inherited: 0x0) 
struct FNiagaraVMExecutableDataId
{
	struct FGuid CompilerVersionID;  // 0x0(0x10)
	uint8_t  ScriptUsageType;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FGuid ScriptUsageTypeID;  // 0x14(0x10)
	char bUsesRapidIterationParams : 1;  // 0x24(0x1)
	char bInterpolatedSpawn : 1;  // 0x24(0x1)
	char bRequiresPersistentIDs : 1;  // 0x24(0x1)
	char pad_36_1 : 5;  // 0x24(0x1)
	char pad_37[4];  // 0x25(0x4)
	struct FGuid BaseScriptID;  // 0x28(0x10)
	struct FNiagaraCompileHash BaseScriptCompileHash;  // 0x38(0x10)

}; 
// ScriptStruct Niagara.NiagaraScriptHighlight
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraScriptHighlight
{
	struct FLinearColor Color;  // 0x0(0x10)
	struct FText DisplayName;  // 0x10(0x18)

}; 
// ScriptStruct Niagara.NiagaraModuleDependency
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraModuleDependency
{
	struct FName ID;  // 0x0(0x8)
	uint8_t  Type;  // 0x8(0x1)
	uint8_t  ScriptConstraint;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FText Description;  // 0x10(0x18)

}; 
// Function Niagara.NiagaraFunctionLibrary.SetVolumeTextureObject
// Size: 0x20(Inherited: 0x0) 
struct FSetVolumeTextureObject
{
	struct UNiagaraComponent* NiagaraSystem;  // 0x0(0x8)
	struct FString OverrideName;  // 0x8(0x10)
	struct UVolumeTexture* Texture;  // 0x18(0x8)

}; 
// ScriptStruct Niagara.NiagaraScriptExecutionParameterStore
// Size: 0xD8(Inherited: 0xB8) 
struct FNiagaraScriptExecutionParameterStore : public FNiagaraParameterStore
{
	int32_t ParameterSize;  // 0xB8(0x4)
	uint32_t PaddedParameterSize;  // 0xBC(0x4)
	struct TArray<struct FNiagaraScriptExecutionPaddingInfo> PaddingInfo;  // 0xC0(0x10)
	char bInitialized : 1;  // 0xD0(0x1)
	char pad_208_1 : 7;  // 0xD0(0x1)
	char pad_209[8];  // 0xD1(0x8)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetFloatParameter
// Size: 0x18(Inherited: 0x0) 
struct FGetFloatParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableFloat
// Size: 0x18(Inherited: 0x0) 
struct FSetNiagaraVariableFloat
{
	struct FString InVariableName;  // 0x0(0x10)
	float InValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct Niagara.NiagaraScriptExecutionPaddingInfo
// Size: 0x8(Inherited: 0x0) 
struct FNiagaraScriptExecutionPaddingInfo
{
	uint16_t SrcOffset;  // 0x0(0x2)
	uint16_t DestOffset;  // 0x2(0x2)
	uint16_t SrcSize;  // 0x4(0x2)
	uint16_t DestSize;  // 0x6(0x2)

}; 
// ScriptStruct Niagara.NiagaraSystemCompileRequest
// Size: 0x80(Inherited: 0x0) 
struct FNiagaraSystemCompileRequest
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct UObject*> RootObjects;  // 0x8(0x10)
	char pad_24[104];  // 0x18(0x68)

}; 
// ScriptStruct Niagara.EmitterCompiledScriptPair
// Size: 0x78(Inherited: 0x0) 
struct FEmitterCompiledScriptPair
{
	char pad_0[120];  // 0x0(0x78)

}; 
// ScriptStruct Niagara.NiagaraSystemCompiledData
// Size: 0x258(Inherited: 0x0) 
struct FNiagaraSystemCompiledData
{
	struct FNiagaraParameterStore InstanceParamStore;  // 0x0(0xB8)
	struct FNiagaraDataSetCompiledData DataSetCompiledData;  // 0xB8(0x40)
	struct FNiagaraDataSetCompiledData SpawnInstanceParamsDataSetCompiledData;  // 0xF8(0x40)
	struct FNiagaraDataSetCompiledData UpdateInstanceParamsDataSetCompiledData;  // 0x138(0x40)
	struct FNiagaraParameterDataSetBindingCollection SpawnInstanceGlobalBinding;  // 0x178(0x20)
	struct FNiagaraParameterDataSetBindingCollection SpawnInstanceSystemBinding;  // 0x198(0x20)
	struct FNiagaraParameterDataSetBindingCollection SpawnInstanceOwnerBinding;  // 0x1B8(0x20)
	struct TArray<struct FNiagaraParameterDataSetBindingCollection> SpawnInstanceEmitterBindings;  // 0x1D8(0x10)
	struct FNiagaraParameterDataSetBindingCollection UpdateInstanceGlobalBinding;  // 0x1E8(0x20)
	struct FNiagaraParameterDataSetBindingCollection UpdateInstanceSystemBinding;  // 0x208(0x20)
	struct FNiagaraParameterDataSetBindingCollection UpdateInstanceOwnerBinding;  // 0x228(0x20)
	struct TArray<struct FNiagaraParameterDataSetBindingCollection> UpdateInstanceEmitterBindings;  // 0x248(0x10)

}; 
// ScriptStruct Niagara.NiagaraParameterDataSetBindingCollection
// Size: 0x20(Inherited: 0x0) 
struct FNiagaraParameterDataSetBindingCollection
{
	struct TArray<struct FNiagaraParameterDataSetBinding> FloatOffsets;  // 0x0(0x10)
	struct TArray<struct FNiagaraParameterDataSetBinding> Int32Offsets;  // 0x10(0x10)

}; 
// ScriptStruct Niagara.NiagaraEmitterCompiledData
// Size: 0x140(Inherited: 0x0) 
struct FNiagaraEmitterCompiledData
{
	struct TArray<struct FName> SpawnAttributes;  // 0x0(0x10)
	struct FNiagaraVariable EmitterSpawnIntervalVar;  // 0x10(0x28)
	struct FNiagaraVariable EmitterInterpSpawnStartDTVar;  // 0x38(0x28)
	struct FNiagaraVariable EmitterSpawnGroupVar;  // 0x60(0x28)
	struct FNiagaraVariable EmitterAgeVar;  // 0x88(0x28)
	struct FNiagaraVariable EmitterRandomSeedVar;  // 0xB0(0x28)
	struct FNiagaraVariable EmitterTotalSpawnedParticlesVar;  // 0xD8(0x28)
	struct FNiagaraDataSetCompiledData DataSetCompiledData;  // 0x100(0x40)

}; 
// ScriptStruct Niagara.NiagaraVariableMetaData
// Size: 0xE8(Inherited: 0x0) 
struct FNiagaraVariableMetaData
{
	struct FText Description;  // 0x0(0x18)
	struct FText CategoryName;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bAdvancedDisplay : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t EditorSortPriority;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bInlineEditConditionToggle : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FNiagaraInputConditionMetadata EditCondition;  // 0x40(0x18)
	struct FNiagaraInputConditionMetadata VisibleCondition;  // 0x58(0x18)
	struct TMap<struct FName, struct FString> PropertyMetaData;  // 0x70(0x50)
	struct FName ScopeName;  // 0xC0(0x8)
	uint8_t  Usage;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool bIsStaticSwitch : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	int32_t StaticSwitchDefaultValue;  // 0xD0(0x4)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool bAddedToNodeGraphDeepCopy : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool bOutputIsPersistent : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)
	struct FName CachedNamespacelessVariableName;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bCreatedInSystemEditor : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool bUseLegacyNameString : 1;  // 0xE1(0x1)
	char pad_226[6];  // 0xE2(0x6)

}; 
// Function Niagara.NiagaraComponent.GetNiagaraParticleValues_DebugOnly
// Size: 0x30(Inherited: 0x0) 
struct FGetNiagaraParticleValues_DebugOnly
{
	struct FString InEmitterName;  // 0x0(0x10)
	struct FString InValueName;  // 0x10(0x10)
	struct TArray<float> ReturnValue;  // 0x20(0x10)

}; 
// ScriptStruct Niagara.NiagaraInputConditionMetadata
// Size: 0x18(Inherited: 0x0) 
struct FNiagaraInputConditionMetadata
{
	struct FName InputName;  // 0x0(0x8)
	struct TArray<struct FString> TargetValues;  // 0x8(0x10)

}; 
// ScriptStruct Niagara.NiagaraParameterScopeInfo
// Size: 0x18(Inherited: 0x0) 
struct FNiagaraParameterScopeInfo
{
	uint8_t  Scope;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString NamespaceString;  // 0x8(0x10)

}; 
// ScriptStruct Niagara.NiagaraCompileHashVisitorDebugInfo
// Size: 0x30(Inherited: 0x0) 
struct FNiagaraCompileHashVisitorDebugInfo
{
	struct FString Object;  // 0x0(0x10)
	struct TArray<struct FString> PropertyKeys;  // 0x10(0x10)
	struct TArray<struct FString> PropertyValues;  // 0x20(0x10)

}; 
// ScriptStruct Niagara.NiagaraSpawnInfo
// Size: 0x10(Inherited: 0x0) 
struct FNiagaraSpawnInfo
{
	int32_t Count;  // 0x0(0x4)
	float InterpStartDt;  // 0x4(0x4)
	float IntervalDt;  // 0x8(0x4)
	int32_t SpawnGroup;  // 0xC(0x4)

}; 
// Function Niagara.NiagaraComponent.SetForceSolo
// Size: 0x1(Inherited: 0x0) 
struct FSetForceSolo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInForceSolo : 1;  // 0x0(0x1)

}; 
// ScriptStruct Niagara.NiagaraTestStructInner
// Size: 0x18(Inherited: 0x0) 
struct FNiagaraTestStructInner
{
	struct FVector InnerVector1;  // 0x0(0xC)
	struct FVector InnerVector2;  // 0xC(0xC)

}; 
// ScriptStruct Niagara.NiagaraParameterMap
// Size: 0x1(Inherited: 0x0) 
struct FNiagaraParameterMap
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct Niagara.NiagaraNumeric
// Size: 0x1(Inherited: 0x0) 
struct FNiagaraNumeric
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct Niagara.NiagaraBool
// Size: 0x4(Inherited: 0x0) 
struct FNiagaraBool
{
	int32_t Value;  // 0x0(0x4)

}; 
// ScriptStruct Niagara.NiagaraInt32
// Size: 0x4(Inherited: 0x0) 
struct FNiagaraInt32
{
	int32_t Value;  // 0x0(0x4)

}; 
// ScriptStruct Niagara.NiagaraFloat
// Size: 0x4(Inherited: 0x0) 
struct FNiagaraFloat
{
	float Value;  // 0x0(0x4)

}; 
// ScriptStruct Niagara.NiagaraUserRedirectionParameterStore
// Size: 0x108(Inherited: 0xB8) 
struct FNiagaraUserRedirectionParameterStore : public FNiagaraParameterStore
{
	struct TMap<struct FNiagaraVariable, struct FNiagaraVariable> UserParameterRedirects;  // 0xB8(0x50)

}; 
// ScriptStruct Niagara.NiagaraVariant
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraVariant
{
	struct UObject* Object;  // 0x0(0x8)
	struct UNiagaraDataInterface* DataInterface;  // 0x8(0x8)
	struct TArray<char> Bytes;  // 0x10(0x10)
	uint8_t  CurrentMode;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct Niagara.NiagaraWorldManagerTickFunction
// Size: 0x30(Inherited: 0x28) 
struct FNiagaraWorldManagerTickFunction : public FTickFunction
{
	char pad_40[8];  // 0x28(0x8)

}; 
// Function Niagara.NiagaraComponent.AdvanceSimulationByTime
// Size: 0x8(Inherited: 0x0) 
struct FAdvanceSimulationByTime
{
	float SimulateTime;  // 0x0(0x4)
	float TickDeltaSeconds;  // 0x4(0x4)

}; 
// Function Niagara.NiagaraActor.OnNiagaraSystemFinished
// Size: 0x8(Inherited: 0x0) 
struct FOnNiagaraSystemFinished
{
	struct UNiagaraComponent* FinishedComponent;  // 0x0(0x8)

}; 
// Function Niagara.NiagaraActor.SetDestroyOnSystemFinish
// Size: 0x1(Inherited: 0x0) 
struct FSetDestroyOnSystemFinish
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldDestroyOnSystemFinish : 1;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.GetAgeUpdateMode
// Size: 0x1(Inherited: 0x0) 
struct FGetAgeUpdateMode
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.GetAsset
// Size: 0x8(Inherited: 0x0) 
struct FGetAsset
{
	struct UNiagaraSystem* ReturnValue;  // 0x0(0x8)

}; 
// Function Niagara.NiagaraComponent.GetDataInterface
// Size: 0x18(Inherited: 0x0) 
struct FGetDataInterface
{
	struct FString Name;  // 0x0(0x10)
	struct UNiagaraDataInterface* ReturnValue;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraComponent.GetDesiredAge
// Size: 0x4(Inherited: 0x0) 
struct FGetDesiredAge
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Niagara.NiagaraComponent.GetNiagaraParticlePositions_DebugOnly
// Size: 0x20(Inherited: 0x0) 
struct FGetNiagaraParticlePositions_DebugOnly
{
	struct FString InEmitterName;  // 0x0(0x10)
	struct TArray<struct FVector> ReturnValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraComponent.GetNiagaraParticleValueVec3_DebugOnly
// Size: 0x30(Inherited: 0x0) 
struct FGetNiagaraParticleValueVec3_DebugOnly
{
	struct FString InEmitterName;  // 0x0(0x10)
	struct FString InValueName;  // 0x10(0x10)
	struct TArray<struct FVector> ReturnValue;  // 0x20(0x10)

}; 
// Function Niagara.NiagaraComponent.GetPreviewLODDistance
// Size: 0x4(Inherited: 0x0) 
struct FGetPreviewLODDistance
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function Niagara.NiagaraComponent.GetPreviewLODDistanceEnabled
// Size: 0x1(Inherited: 0x0) 
struct FGetPreviewLODDistanceEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.IsPaused
// Size: 0x1(Inherited: 0x0) 
struct FIsPaused
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.SeekToDesiredAge
// Size: 0x4(Inherited: 0x0) 
struct FSeekToDesiredAge
{
	float InDesiredAge;  // 0x0(0x4)

}; 
// Function Niagara.NiagaraComponent.SetVariableObject
// Size: 0x10(Inherited: 0x0) 
struct FSetVariableObject
{
	struct FName InVariableName;  // 0x0(0x8)
	struct UObject* Object;  // 0x8(0x8)

}; 
// Function Niagara.NiagaraComponent.SetVariableActor
// Size: 0x10(Inherited: 0x0) 
struct FSetVariableActor
{
	struct FName InVariableName;  // 0x0(0x8)
	struct AActor* Actor;  // 0x8(0x8)

}; 
// Function Niagara.NiagaraComponent.SetAgeUpdateMode
// Size: 0x1(Inherited: 0x0) 
struct FSetAgeUpdateMode
{
	uint8_t  InAgeUpdateMode;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.SetAllowScalability
// Size: 0x1(Inherited: 0x0) 
struct FSetAllowScalability
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllow : 1;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.SetAsset
// Size: 0x8(Inherited: 0x0) 
struct FSetAsset
{
	struct UNiagaraSystem* InAsset;  // 0x0(0x8)

}; 
// Function Niagara.NiagaraComponent.SetAutoDestroy
// Size: 0x1(Inherited: 0x0) 
struct FSetAutoDestroy
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInAutoDestroy : 1;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.SetCanRenderWhileSeeking
// Size: 0x1(Inherited: 0x0) 
struct FSetCanRenderWhileSeeking
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInCanRenderWhileSeeking : 1;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraComponent.SetDesiredAge
// Size: 0x4(Inherited: 0x0) 
struct FSetDesiredAge
{
	float InDesiredAge;  // 0x0(0x4)

}; 
// Function Niagara.NiagaraComponent.SetMaxSimTime
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxSimTime
{
	float InMaxTime;  // 0x0(0x4)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableActor
// Size: 0x18(Inherited: 0x0) 
struct FSetNiagaraVariableActor
{
	struct FString InVariableName;  // 0x0(0x10)
	struct AActor* Actor;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableBool
// Size: 0x18(Inherited: 0x0) 
struct FSetNiagaraVariableBool
{
	struct FString InVariableName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool InValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableInt
// Size: 0x18(Inherited: 0x0) 
struct FSetNiagaraVariableInt
{
	struct FString InVariableName;  // 0x0(0x10)
	int32_t InValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableLinearColor
// Size: 0x20(Inherited: 0x0) 
struct FSetNiagaraVariableLinearColor
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FLinearColor InValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableObject
// Size: 0x18(Inherited: 0x0) 
struct FSetNiagaraVariableObject
{
	struct FString InVariableName;  // 0x0(0x10)
	struct UObject* Object;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableQuat
// Size: 0x20(Inherited: 0x0) 
struct FSetNiagaraVariableQuat
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FQuat InValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableVec2
// Size: 0x18(Inherited: 0x0) 
struct FSetNiagaraVariableVec2
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector2D InValue;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableVec3
// Size: 0x20(Inherited: 0x0) 
struct FSetNiagaraVariableVec3
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector InValue;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function Niagara.NiagaraComponent.SetNiagaraVariableVec4
// Size: 0x20(Inherited: 0x0) 
struct FSetNiagaraVariableVec4
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector4 InValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraComponent.SetPreviewLODDistance
// Size: 0x8(Inherited: 0x0) 
struct FSetPreviewLODDistance
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnablePreviewLODDistance : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float PreviewLODDistance;  // 0x4(0x4)

}; 
// Function Niagara.NiagaraComponent.SetSeekDelta
// Size: 0x4(Inherited: 0x0) 
struct FSetSeekDelta
{
	float InSeekDelta;  // 0x0(0x4)

}; 
// Function Niagara.NiagaraComponent.SetVariableBool
// Size: 0xC(Inherited: 0x0) 
struct FSetVariableBool
{
	struct FName InVariableName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool InValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function Niagara.NiagaraComponent.SetVariableFloat
// Size: 0xC(Inherited: 0x0) 
struct FSetVariableFloat
{
	struct FName InVariableName;  // 0x0(0x8)
	float InValue;  // 0x8(0x4)

}; 
// Function Niagara.NiagaraComponent.SetVariableInt
// Size: 0xC(Inherited: 0x0) 
struct FSetVariableInt
{
	struct FName InVariableName;  // 0x0(0x8)
	int32_t InValue;  // 0x8(0x4)

}; 
// Function Niagara.NiagaraComponent.SetVariableLinearColor
// Size: 0x18(Inherited: 0x0) 
struct FSetVariableLinearColor
{
	struct FName InVariableName;  // 0x0(0x8)
	struct FLinearColor InValue;  // 0x8(0x10)

}; 
// Function Niagara.NiagaraComponent.SetVariableMaterial
// Size: 0x10(Inherited: 0x0) 
struct FSetVariableMaterial
{
	struct FName InVariableName;  // 0x0(0x8)
	struct UMaterialInterface* Object;  // 0x8(0x8)

}; 
// Function Niagara.NiagaraComponent.SetVariableQuat
// Size: 0x20(Inherited: 0x0) 
struct FSetVariableQuat
{
	struct FName InVariableName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FQuat InValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetIntParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetIntParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	int32_t InValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function Niagara.NiagaraComponent.SetVariableVec2
// Size: 0x10(Inherited: 0x0) 
struct FSetVariableVec2
{
	struct FName InVariableName;  // 0x0(0x8)
	struct FVector2D InValue;  // 0x8(0x8)

}; 
// Function Niagara.NiagaraComponent.SetVariableVec3
// Size: 0x14(Inherited: 0x0) 
struct FSetVariableVec3
{
	struct FName InVariableName;  // 0x0(0x8)
	struct FVector InValue;  // 0x8(0xC)

}; 
// Function Niagara.NiagaraComponent.SetVariableVec4
// Size: 0x20(Inherited: 0x0) 
struct FSetVariableVec4
{
	struct FName InVariableName;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FVector4 InValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraParticleCallbackHandler.ReceiveParticleData
// Size: 0x18(Inherited: 0x0) 
struct FReceiveParticleData
{
	struct TArray<struct FBasicParticleData> Data;  // 0x0(0x10)
	struct UNiagaraSystem* NiagaraSystem;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetVector4Parameter
// Size: 0x20(Inherited: 0x0) 
struct FGetVector4Parameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector4 ReturnValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillRawTexture2D
// Size: 0x20(Inherited: 0x0) 
struct FFillRawTexture2D
{
	struct UNiagaraComponent* Component;  // 0x0(0x8)
	struct UTextureRenderTarget2D* Dest;  // 0x8(0x8)
	int32_t TilesX;  // 0x10(0x4)
	int32_t TilesY;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillTexture2D
// Size: 0x18(Inherited: 0x0) 
struct FFillTexture2D
{
	struct UNiagaraComponent* Component;  // 0x0(0x8)
	struct UTextureRenderTarget2D* Dest;  // 0x8(0x8)
	int32_t AttributeIndex;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetRawTextureSize
// Size: 0x10(Inherited: 0x0) 
struct FGetRawTextureSize
{
	struct UNiagaraComponent* Component;  // 0x0(0x8)
	int32_t SizeX;  // 0x8(0x4)
	int32_t SizeY;  // 0xC(0x4)

}; 
// Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMeshComponent
// Size: 0x20(Inherited: 0x0) 
struct FOverrideSystemUserVariableStaticMeshComponent
{
	struct UNiagaraComponent* NiagaraSystem;  // 0x0(0x8)
	struct FString OverrideName;  // 0x8(0x10)
	struct UStaticMeshComponent* StaticMeshComponent;  // 0x18(0x8)

}; 
// Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetTextureSize
// Size: 0x10(Inherited: 0x0) 
struct FGetTextureSize
{
	struct UNiagaraComponent* Component;  // 0x0(0x8)
	int32_t SizeX;  // 0x8(0x4)
	int32_t SizeY;  // 0xC(0x4)

}; 
// Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableSkeletalMeshComponent
// Size: 0x20(Inherited: 0x0) 
struct FOverrideSystemUserVariableSkeletalMeshComponent
{
	struct UNiagaraComponent* NiagaraSystem;  // 0x0(0x8)
	struct FString OverrideName;  // 0x8(0x10)
	struct USkeletalMeshComponent* SkeletalMeshComponent;  // 0x18(0x8)

}; 
// Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMesh
// Size: 0x20(Inherited: 0x0) 
struct FOverrideSystemUserVariableStaticMesh
{
	struct UNiagaraComponent* NiagaraSystem;  // 0x0(0x8)
	struct FString OverrideName;  // 0x8(0x10)
	struct UStaticMesh* StaticMesh;  // 0x18(0x8)

}; 
// Function Niagara.NiagaraFunctionLibrary.SetTextureObject
// Size: 0x20(Inherited: 0x0) 
struct FSetTextureObject
{
	struct UNiagaraComponent* NiagaraSystem;  // 0x0(0x8)
	struct FString OverrideName;  // 0x8(0x10)
	struct UTexture* Texture;  // 0x18(0x8)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetBoolParameter
// Size: 0x18(Inherited: 0x0) 
struct FGetBoolParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetIntParameter
// Size: 0x18(Inherited: 0x0) 
struct FGetIntParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetQuatParameter
// Size: 0x20(Inherited: 0x0) 
struct FGetQuatParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FQuat ReturnValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetVector2DParameter
// Size: 0x18(Inherited: 0x0) 
struct FGetVector2DParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector2D ReturnValue;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.GetVectorParameter
// Size: 0x20(Inherited: 0x0) 
struct FGetVectorParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector ReturnValue;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetColorParameter
// Size: 0x20(Inherited: 0x0) 
struct FSetColorParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FLinearColor InValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetFloatParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetFloatParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	float InValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetVector2DParameter
// Size: 0x18(Inherited: 0x0) 
struct FSetVector2DParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector2D InValue;  // 0x10(0x8)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetVector4Parameter
// Size: 0x20(Inherited: 0x0) 
struct FSetVector4Parameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector4 InValue;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraParameterCollectionInstance.SetVectorParameter
// Size: 0x20(Inherited: 0x0) 
struct FSetVectorParameter
{
	struct FString InVariableName;  // 0x0(0x10)
	struct FVector InValue;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function Niagara.NiagaraPreviewBase.SetLabelText
// Size: 0x30(Inherited: 0x0) 
struct FSetLabelText
{
	struct FText InXAxisText;  // 0x0(0x18)
	struct FText InYAxisText;  // 0x18(0x18)

}; 
// Function Niagara.NiagaraPreviewBase.SetSystem
// Size: 0x8(Inherited: 0x0) 
struct FSetSystem
{
	struct UNiagaraSystem* InSystem;  // 0x0(0x8)

}; 
// Function Niagara.NiagaraPreviewAxis.ApplyToPreview
// Size: 0x20(Inherited: 0x0) 
struct FApplyToPreview
{
	struct UNiagaraComponent* PreviewComponent;  // 0x0(0x8)
	int32_t PreviewIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bIsXAxis : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FString OutLabelText;  // 0x10(0x10)

}; 
// Function Niagara.NiagaraPreviewGrid.ActivatePreviews
// Size: 0x1(Inherited: 0x0) 
struct FActivatePreviews
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bReset : 1;  // 0x0(0x1)

}; 
// Function Niagara.NiagaraPreviewGrid.GetPreviews
// Size: 0x10(Inherited: 0x0) 
struct FGetPreviews
{
	struct TArray<struct UNiagaraComponent*> OutPreviews;  // 0x0(0x10)

}; 
