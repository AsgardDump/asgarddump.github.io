#pragma once 
#include <WBP_DialogBox_Button_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DialogBox_Button.WBP_DialogBox_Button_C
// Size: 0x340(Inherited: 0x230) 
struct UWBP_DialogBox_Button_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UButton* DlgBtn;  // 0x238(0x8)
	struct UTextBlock* DlgText;  // 0x240(0x8)
	struct FText BtnText;  // 0x248(0x18)
	struct FMulticastInlineDelegate ButtonClicked;  // 0x260(0x10)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool bActive : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)
	struct FSlateColor TextColor;  // 0x278(0x28)
	struct FSlateColor TextColorActive;  // 0x2A0(0x28)
	struct FSlateColor BtnTint;  // 0x2C8(0x28)
	struct FSlateColor TextColorPressed;  // 0x2F0(0x28)
	struct FSlateColor TextColorHovered;  // 0x318(0x28)

	void UpdateAppearance(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.UpdateAppearance
	void SetActive(bool bNewActive); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.SetActive
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature
	void BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.BndEvt__NavBarBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.PreConstruct
	void ExecuteUbergraph_WBP_DialogBox_Button(int32_t EntryPoint); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.ExecuteUbergraph_WBP_DialogBox_Button
	void ButtonClicked__DelegateSignature(struct UWBP_DialogBox_Button_C* ClickedBtn); // Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.ButtonClicked__DelegateSignature
}; 



