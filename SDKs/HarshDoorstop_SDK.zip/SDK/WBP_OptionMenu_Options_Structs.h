#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.ExecuteUbergraph_WBP_OptionMenu_Options
// Size: 0x881(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionMenu_Options
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_11;  // 0x8(0x10)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_12;  // 0x18(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue;  // 0x28(0x4)
	char CallFunc_Conv_IntToByte_ReturnValue;  // 0x2C(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2F(0x1)
	float CallFunc_GetMasterVolumeLevel_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool K2Node_ComponentBoundEvent_bChecked_8 : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_10;  // 0x38(0x10)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_9;  // 0x48(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_2;  // 0x58(0x4)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_3;  // 0x5C(0x4)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_8;  // 0x60(0x10)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_7;  // 0x70(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_4;  // 0x80(0x4)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_5;  // 0x84(0x4)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_6;  // 0x88(0x10)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_5;  // 0x98(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_6;  // 0xA8(0x4)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_7;  // 0xAC(0x4)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_4;  // 0xB0(0x10)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_3;  // 0xC0(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_8;  // 0xD0(0x4)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_9;  // 0xD4(0x4)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xDA(0x1)
	char pad_219[1];  // 0xDB(0x1)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0xDC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_IsDirty_bDirty : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	int32_t CallFunc_Clamp_ReturnValue;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct FString K2Node_CustomEvent_SelectedItemValue;  // 0xF0(0x10)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_CustomEvent_bChecked : 1;  // 0x100(0x1)
	char pad_257[3];  // 0x101(0x3)
	int32_t K2Node_Event_SubMenuIndex;  // 0x104(0x4)
	float K2Node_CustomEvent_Value;  // 0x108(0x4)
	char pad_268_1 : 7;  // 0x10C(0x1)
	bool K2Node_CustomEvent_bToggledOn : 1;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	float K2Node_ComponentBoundEvent_Value_10;  // 0x110(0x4)
	char pad_276_1 : 7;  // 0x114(0x1)
	bool K2Node_ComponentBoundEvent_bChecked_7 : 1;  // 0x114(0x1)
	char pad_277_1 : 7;  // 0x115(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x115(0x1)
	char pad_278[2];  // 0x116(0x2)
	float K2Node_ComponentBoundEvent_Value_9;  // 0x118(0x4)
	float K2Node_ComponentBoundEvent_Value_8;  // 0x11C(0x4)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool K2Node_ComponentBoundEvent_bChecked_6 : 1;  // 0x121(0x1)
	char pad_290_1 : 7;  // 0x122(0x1)
	bool K2Node_ComponentBoundEvent_bChecked_5 : 1;  // 0x122(0x1)
	char pad_291[1];  // 0x123(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x124(0x10)
	float K2Node_ComponentBoundEvent_Value_7;  // 0x134(0x4)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	float K2Node_ComponentBoundEvent_Value_6;  // 0x13C(0x4)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x144(0x10)
	char pad_340[4];  // 0x154(0x4)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue_2;  // 0x158(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_10;  // 0x168(0x4)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x16C(0x1)
	char pad_365_1 : 7;  // 0x16D(0x1)
	bool K2Node_ComponentBoundEvent_bChecked_4 : 1;  // 0x16D(0x1)
	char pad_366[2];  // 0x16E(0x2)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x170(0x8)
	struct UTBGameUserSettings* K2Node_DynamicCast_AsTBGame_User_Settings;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x180(0x1)
	char pad_385_1 : 7;  // 0x181(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x181(0x1)
	char pad_386[2];  // 0x182(0x2)
	float K2Node_ComponentBoundEvent_Value_5;  // 0x184(0x4)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x188(0x1)
	char pad_393_1 : 7;  // 0x189(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x189(0x1)
	char pad_394[2];  // 0x18A(0x2)
	float K2Node_ComponentBoundEvent_Value_4;  // 0x18C(0x4)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	float K2Node_ComponentBoundEvent_Value_3;  // 0x194(0x4)
	float K2Node_ComponentBoundEvent_Value_2;  // 0x198(0x4)
	float K2Node_ComponentBoundEvent_Value;  // 0x19C(0x4)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0x1A0(0x1)
	char pad_417_1 : 7;  // 0x1A1(0x1)
	bool CallFunc_IsValid_ReturnValue_14 : 1;  // 0x1A1(0x1)
	char pad_418_1 : 7;  // 0x1A2(0x1)
	bool CallFunc_IsValid_ReturnValue_15 : 1;  // 0x1A2(0x1)
	char pad_419_1 : 7;  // 0x1A3(0x1)
	bool CallFunc_IsValid_ReturnValue_16 : 1;  // 0x1A3(0x1)
	char pad_420[4];  // 0x1A4(0x4)
	struct FString K2Node_ComponentBoundEvent_SelectedItemValue;  // 0x1A8(0x10)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_11;  // 0x1B8(0x4)
	char pad_444_1 : 7;  // 0x1BC(0x1)
	bool CallFunc_IsValid_ReturnValue_17 : 1;  // 0x1BC(0x1)
	char pad_445_1 : 7;  // 0x1BD(0x1)
	bool K2Node_ComponentBoundEvent_bChecked_3 : 1;  // 0x1BD(0x1)
	char pad_446_1 : 7;  // 0x1BE(0x1)
	bool K2Node_ComponentBoundEvent_bChecked_2 : 1;  // 0x1BE(0x1)
	char pad_447_1 : 7;  // 0x1BF(0x1)
	bool CallFunc_IsValid_ReturnValue_18 : 1;  // 0x1BF(0x1)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool CallFunc_IsValid_ReturnValue_19 : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_47;  // 0x1C8(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_46;  // 0x1E8(0x20)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool CallFunc_IsValid_ReturnValue_20 : 1;  // 0x208(0x1)
	char pad_521[7];  // 0x209(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_45;  // 0x210(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_44;  // 0x230(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_43;  // 0x250(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_42;  // 0x270(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_41;  // 0x290(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_40;  // 0x2B0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_39;  // 0x2D0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_38;  // 0x2F0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_37;  // 0x310(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_36;  // 0x330(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_35;  // 0x350(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_34;  // 0x370(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_33;  // 0x390(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_32;  // 0x3B0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_31;  // 0x3D0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_30;  // 0x3F0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_29;  // 0x410(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_28;  // 0x430(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_27;  // 0x450(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_26;  // 0x470(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_25;  // 0x490(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_24;  // 0x4B0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_23;  // 0x4D0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_22;  // 0x4F0(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_21;  // 0x510(0x20)
	char pad_1328_1 : 7;  // 0x530(0x1)
	bool CallFunc_IsValid_ReturnValue_21 : 1;  // 0x530(0x1)
	char pad_1329_1 : 7;  // 0x531(0x1)
	bool CallFunc_IsValid_ReturnValue_22 : 1;  // 0x531(0x1)
	char pad_1330_1 : 7;  // 0x532(0x1)
	bool CallFunc_IsValid_ReturnValue_23 : 1;  // 0x532(0x1)
	char pad_1331_1 : 7;  // 0x533(0x1)
	bool CallFunc_IsValid_ReturnValue_24 : 1;  // 0x533(0x1)
	char pad_1332_1 : 7;  // 0x534(0x1)
	bool CallFunc_IsValid_ReturnValue_25 : 1;  // 0x534(0x1)
	char pad_1333_1 : 7;  // 0x535(0x1)
	bool CallFunc_IsValid_ReturnValue_26 : 1;  // 0x535(0x1)
	char pad_1334_1 : 7;  // 0x536(0x1)
	bool CallFunc_IsValid_ReturnValue_27 : 1;  // 0x536(0x1)
	char pad_1335_1 : 7;  // 0x537(0x1)
	bool CallFunc_IsValid_ReturnValue_28 : 1;  // 0x537(0x1)
	char pad_1336_1 : 7;  // 0x538(0x1)
	bool CallFunc_IsValid_ReturnValue_29 : 1;  // 0x538(0x1)
	char pad_1337_1 : 7;  // 0x539(0x1)
	bool CallFunc_IsValid_ReturnValue_30 : 1;  // 0x539(0x1)
	char pad_1338_1 : 7;  // 0x53A(0x1)
	bool CallFunc_IsValid_ReturnValue_31 : 1;  // 0x53A(0x1)
	char pad_1339_1 : 7;  // 0x53B(0x1)
	bool CallFunc_IsValid_ReturnValue_32 : 1;  // 0x53B(0x1)
	char pad_1340_1 : 7;  // 0x53C(0x1)
	bool CallFunc_IsValid_ReturnValue_33 : 1;  // 0x53C(0x1)
	char pad_1341_1 : 7;  // 0x53D(0x1)
	bool CallFunc_IsValid_ReturnValue_34 : 1;  // 0x53D(0x1)
	char pad_1342_1 : 7;  // 0x53E(0x1)
	bool CallFunc_IsValid_ReturnValue_35 : 1;  // 0x53E(0x1)
	char pad_1343_1 : 7;  // 0x53F(0x1)
	bool CallFunc_IsValid_ReturnValue_36 : 1;  // 0x53F(0x1)
	char pad_1344_1 : 7;  // 0x540(0x1)
	bool CallFunc_IsValid_ReturnValue_37 : 1;  // 0x540(0x1)
	char pad_1345_1 : 7;  // 0x541(0x1)
	bool CallFunc_IsValid_ReturnValue_38 : 1;  // 0x541(0x1)
	char pad_1346_1 : 7;  // 0x542(0x1)
	bool CallFunc_IsValid_ReturnValue_39 : 1;  // 0x542(0x1)
	char pad_1347_1 : 7;  // 0x543(0x1)
	bool CallFunc_IsValid_ReturnValue_40 : 1;  // 0x543(0x1)
	char pad_1348_1 : 7;  // 0x544(0x1)
	bool CallFunc_IsValid_ReturnValue_41 : 1;  // 0x544(0x1)
	char pad_1349_1 : 7;  // 0x545(0x1)
	bool CallFunc_IsValid_ReturnValue_42 : 1;  // 0x545(0x1)
	char pad_1350_1 : 7;  // 0x546(0x1)
	bool CallFunc_IsValid_ReturnValue_43 : 1;  // 0x546(0x1)
	char pad_1351_1 : 7;  // 0x547(0x1)
	bool CallFunc_IsValid_ReturnValue_44 : 1;  // 0x547(0x1)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool CallFunc_IsValid_ReturnValue_45 : 1;  // 0x548(0x1)
	char pad_1353_1 : 7;  // 0x549(0x1)
	bool CallFunc_IsValid_ReturnValue_46 : 1;  // 0x549(0x1)
	char pad_1354_1 : 7;  // 0x54A(0x1)
	bool CallFunc_IsValid_ReturnValue_47 : 1;  // 0x54A(0x1)
	char pad_1355_1 : 7;  // 0x54B(0x1)
	bool CallFunc_IsValid_ReturnValue_48 : 1;  // 0x54B(0x1)
	char pad_1356_1 : 7;  // 0x54C(0x1)
	bool CallFunc_IsValid_ReturnValue_49 : 1;  // 0x54C(0x1)
	char pad_1357_1 : 7;  // 0x54D(0x1)
	bool CallFunc_IsValid_ReturnValue_50 : 1;  // 0x54D(0x1)
	char pad_1358_1 : 7;  // 0x54E(0x1)
	bool CallFunc_IsValid_ReturnValue_51 : 1;  // 0x54E(0x1)
	char pad_1359_1 : 7;  // 0x54F(0x1)
	bool CallFunc_IsValid_ReturnValue_52 : 1;  // 0x54F(0x1)
	char pad_1360_1 : 7;  // 0x550(0x1)
	bool CallFunc_IsValid_ReturnValue_53 : 1;  // 0x550(0x1)
	char pad_1361_1 : 7;  // 0x551(0x1)
	bool CallFunc_IsValid_ReturnValue_54 : 1;  // 0x551(0x1)
	char pad_1362_1 : 7;  // 0x552(0x1)
	bool CallFunc_IsValid_ReturnValue_55 : 1;  // 0x552(0x1)
	char pad_1363[5];  // 0x553(0x5)
	struct FInputChord K2Node_CustomEvent_Key_Selected;  // 0x558(0x20)
	char pad_1400_1 : 7;  // 0x578(0x1)
	bool CallFunc_IsValid_ReturnValue_56 : 1;  // 0x578(0x1)
	char pad_1401[3];  // 0x579(0x3)
	float K2Node_ComponentBoundEvent_CurrentOffset;  // 0x57C(0x4)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_20;  // 0x580(0x20)
	char pad_1440_1 : 7;  // 0x5A0(0x1)
	bool CallFunc_IsValid_ReturnValue_57 : 1;  // 0x5A0(0x1)
	char pad_1441[7];  // 0x5A1(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_19;  // 0x5A8(0x20)
	char pad_1480_1 : 7;  // 0x5C8(0x1)
	bool CallFunc_IsValid_ReturnValue_58 : 1;  // 0x5C8(0x1)
	char pad_1481[7];  // 0x5C9(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_18;  // 0x5D0(0x20)
	char pad_1520_1 : 7;  // 0x5F0(0x1)
	bool CallFunc_IsValid_ReturnValue_59 : 1;  // 0x5F0(0x1)
	char pad_1521_1 : 7;  // 0x5F1(0x1)
	bool CallFunc_IsValid_ReturnValue_60 : 1;  // 0x5F1(0x1)
	char pad_1522[6];  // 0x5F2(0x6)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_17;  // 0x5F8(0x20)
	char pad_1560_1 : 7;  // 0x618(0x1)
	bool CallFunc_IsValid_ReturnValue_61 : 1;  // 0x618(0x1)
	char pad_1561[7];  // 0x619(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_16;  // 0x620(0x20)
	char pad_1600_1 : 7;  // 0x640(0x1)
	bool CallFunc_IsValid_ReturnValue_62 : 1;  // 0x640(0x1)
	char pad_1601[7];  // 0x641(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_15;  // 0x648(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_14;  // 0x668(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_13;  // 0x688(0x20)
	char pad_1704_1 : 7;  // 0x6A8(0x1)
	bool CallFunc_IsValid_ReturnValue_63 : 1;  // 0x6A8(0x1)
	char pad_1705_1 : 7;  // 0x6A9(0x1)
	bool CallFunc_IsValid_ReturnValue_64 : 1;  // 0x6A9(0x1)
	char pad_1706_1 : 7;  // 0x6AA(0x1)
	bool CallFunc_IsValid_ReturnValue_65 : 1;  // 0x6AA(0x1)
	char pad_1707_1 : 7;  // 0x6AB(0x1)
	bool CallFunc_IsValid_ReturnValue_66 : 1;  // 0x6AB(0x1)
	char pad_1708[4];  // 0x6AC(0x4)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_12;  // 0x6B0(0x20)
	char pad_1744_1 : 7;  // 0x6D0(0x1)
	bool CallFunc_IsValid_ReturnValue_67 : 1;  // 0x6D0(0x1)
	char pad_1745_1 : 7;  // 0x6D1(0x1)
	bool CallFunc_IsValid_ReturnValue_68 : 1;  // 0x6D1(0x1)
	char pad_1746[6];  // 0x6D2(0x6)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_11;  // 0x6D8(0x20)
	char pad_1784_1 : 7;  // 0x6F8(0x1)
	bool CallFunc_IsValid_ReturnValue_69 : 1;  // 0x6F8(0x1)
	char pad_1785[7];  // 0x6F9(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_10;  // 0x700(0x20)
	char pad_1824_1 : 7;  // 0x720(0x1)
	bool CallFunc_IsValid_ReturnValue_70 : 1;  // 0x720(0x1)
	char pad_1825[7];  // 0x721(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_9;  // 0x728(0x20)
	char pad_1864_1 : 7;  // 0x748(0x1)
	bool CallFunc_IsValid_ReturnValue_71 : 1;  // 0x748(0x1)
	char pad_1865[7];  // 0x749(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_8;  // 0x750(0x20)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_7;  // 0x770(0x20)
	char pad_1936_1 : 7;  // 0x790(0x1)
	bool CallFunc_IsValid_ReturnValue_72 : 1;  // 0x790(0x1)
	char pad_1937_1 : 7;  // 0x791(0x1)
	bool CallFunc_IsValid_ReturnValue_73 : 1;  // 0x791(0x1)
	char pad_1938_1 : 7;  // 0x792(0x1)
	bool CallFunc_IsValid_ReturnValue_74 : 1;  // 0x792(0x1)
	char pad_1939[5];  // 0x793(0x5)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_6;  // 0x798(0x20)
	char pad_1976_1 : 7;  // 0x7B8(0x1)
	bool CallFunc_IsValid_ReturnValue_75 : 1;  // 0x7B8(0x1)
	char pad_1977[7];  // 0x7B9(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_5;  // 0x7C0(0x20)
	char pad_2016_1 : 7;  // 0x7E0(0x1)
	bool CallFunc_IsValid_ReturnValue_76 : 1;  // 0x7E0(0x1)
	char pad_2017[7];  // 0x7E1(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_4;  // 0x7E8(0x20)
	char pad_2056_1 : 7;  // 0x808(0x1)
	bool CallFunc_IsValid_ReturnValue_77 : 1;  // 0x808(0x1)
	char pad_2057[7];  // 0x809(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_3;  // 0x810(0x20)
	char pad_2096_1 : 7;  // 0x830(0x1)
	bool CallFunc_IsValid_ReturnValue_78 : 1;  // 0x830(0x1)
	char pad_2097[7];  // 0x831(0x7)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey_2;  // 0x838(0x20)
	char pad_2136_1 : 7;  // 0x858(0x1)
	bool CallFunc_IsValid_ReturnValue_79 : 1;  // 0x858(0x1)
	char pad_2137_1 : 7;  // 0x859(0x1)
	bool CallFunc_IsValid_ReturnValue_80 : 1;  // 0x859(0x1)
	char pad_2138_1 : 7;  // 0x85A(0x1)
	bool K2Node_ComponentBoundEvent_bChecked : 1;  // 0x85A(0x1)
	char pad_2139[5];  // 0x85B(0x5)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey;  // 0x860(0x20)
	char pad_2176_1 : 7;  // 0x880(0x1)
	bool CallFunc_IsValid_ReturnValue_81 : 1;  // 0x880(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveBackward_IKS_K2Node_ComponentBoundEvent_37_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__MoveBackward_IKS_K2Node_ComponentBoundEvent_37_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Console_IKS_K2Node_ComponentBoundEvent_130_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Console_IKS_K2Node_ComponentBoundEvent_130_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.CatchMouseWheelInput
// Size: 0x4B(Inherited: 0x0) 
struct FCatchMouseWheelInput
{
	float NewScrollOffset;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FInputChord K2Node_MakeStruct_InputChord;  // 0x8(0x20)
	struct FInputChord K2Node_MakeStruct_InputChord_2;  // 0x28(0x20)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsPlayerChangingKeyBindings_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4A(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AimDownSightsToggle_IKS_K2Node_ComponentBoundEvent_119_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__AimDownSightsToggle_IKS_K2Node_ComponentBoundEvent_119_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CycleWeaponSights_IKS_K2Node_ComponentBoundEvent_127_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__CycleWeaponSights_IKS_K2Node_ComponentBoundEvent_127_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SwitchFireModeOnReselectOption_K2Node_ComponentBoundEvent_129_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__SwitchFireModeOnReselectOption_K2Node_ComponentBoundEvent_129_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PointAimToggle_IKS_K2Node_ComponentBoundEvent_125_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__PointAimToggle_IKS_K2Node_ComponentBoundEvent_125_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SwitchFireMode_IKS_K2Node_ComponentBoundEvent_123_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__SwitchFireMode_IKS_K2Node_ComponentBoundEvent_123_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SaySquad_IKS_K2Node_ComponentBoundEvent_105_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__SaySquad_IKS_K2Node_ComponentBoundEvent_105_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SFXVolOption_K2Node_ComponentBoundEvent_29_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__SFXVolOption_K2Node_ComponentBoundEvent_29_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SprintToggle_IKS_K2Node_ComponentBoundEvent_121_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__SprintToggle_IKS_K2Node_ComponentBoundEvent_121_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetActiveSubMenuByIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetActiveSubMenuByIndex
{
	int32_t SubMenuIndex;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanRightToggle_IKS_K2Node_ComponentBoundEvent_117_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__LeanRightToggle_IKS_K2Node_ComponentBoundEvent_117_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Sprint_IKS_K2Node_ComponentBoundEvent_40_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Sprint_IKS_K2Node_ComponentBoundEvent_40_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanLeftToggle_IKS_K2Node_ComponentBoundEvent_115_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__LeanLeftToggle_IKS_K2Node_ComponentBoundEvent_115_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CrouchToggle_IKS_K2Node_ComponentBoundEvent_113_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__CrouchToggle_IKS_K2Node_ComponentBoundEvent_113_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Vault_IKS_K2Node_ComponentBoundEvent_111_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Vault_IKS_K2Node_ComponentBoundEvent_111_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__JumpVault_IKS_K2Node_ComponentBoundEvent_109_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__JumpVault_IKS_K2Node_ComponentBoundEvent_109_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__RadialMenu_IKS_K2Node_ComponentBoundEvent_107_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__RadialMenu_IKS_K2Node_ComponentBoundEvent_107_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AimDownSights_IKS_K2Node_ComponentBoundEvent_45_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__AimDownSights_IKS_K2Node_ComponentBoundEvent_45_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Scoreboard_IKS_K2Node_ComponentBoundEvent_60_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Scoreboard_IKS_K2Node_ComponentBoundEvent_60_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalkCommand_IKS_K2Node_ComponentBoundEvent_103_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__PushToTalkCommand_IKS_K2Node_ComponentBoundEvent_103_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalkSquad_IKS_K2Node_ComponentBoundEvent_101_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__PushToTalkSquad_IKS_K2Node_ComponentBoundEvent_101_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Prone_IKS_K2Node_ComponentBoundEvent_99_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Prone_IKS_K2Node_ComponentBoundEvent_99_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanRight_IKS_K2Node_ComponentBoundEvent_98_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__LeanRight_IKS_K2Node_ComponentBoundEvent_98_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.PopulateAllKeyBindings
// Size: 0x478(Inherited: 0x0) 
struct FPopulateAllKeyBindings
{
	struct UTBGameUserSettings* Settings;  // 0x0(0x8)
	struct FKey CallFunc_GetConsoleKeyBinding_ReturnValue;  // 0x8(0x18)
	struct FKey CallFunc_GetCycleWeaponSightsKeyBinding_ReturnValue;  // 0x20(0x18)
	struct FKey CallFunc_GetPointAimToggleKeyBinding_ReturnValue;  // 0x38(0x18)
	struct FKey CallFunc_GetSwitchFireModeKeyBinding_ReturnValue;  // 0x50(0x18)
	struct FKey CallFunc_GetLeanRightKeyToggleBinding_ReturnValue;  // 0x68(0x18)
	struct FKey CallFunc_GetLeanLeftToggleKeyBinding_ReturnValue;  // 0x80(0x18)
	struct FKey CallFunc_GetSprintToggleKeyBinding_ReturnValue;  // 0x98(0x18)
	struct FKey CallFunc_GetAimDownSightsToggleKeyBinding_ReturnValue;  // 0xB0(0x18)
	struct FKey CallFunc_GetCrouchToggleKeyBinding_ReturnValue;  // 0xC8(0x18)
	struct FKey CallFunc_GetVaultKeyBinding_ReturnValue;  // 0xE0(0x18)
	struct FKey CallFunc_GetJumpVaultKeyBinding_ReturnValue;  // 0xF8(0x18)
	struct FKey CallFunc_GetRadialMenuKeyBinding_ReturnValue;  // 0x110(0x18)
	struct FKey CallFunc_GetSaySquadKeyBinding_ReturnValue;  // 0x128(0x18)
	struct FKey CallFunc_GetPushToTalkCommandKeyBinding_ReturnValue;  // 0x140(0x18)
	struct FKey CallFunc_GetPushToTalkSquadKeyBinding_ReturnValue;  // 0x158(0x18)
	struct FKey CallFunc_GetProneKeyBinding_ReturnValue;  // 0x170(0x18)
	struct FKey CallFunc_GetLeanRightKeyBinding_ReturnValue;  // 0x188(0x18)
	struct FKey CallFunc_GetLeanLeftKeyBinding_ReturnValue;  // 0x1A0(0x18)
	struct FKey CallFunc_GetWeaponSlot0KeyBinding_ReturnValue;  // 0x1B8(0x18)
	struct FKey CallFunc_GetWeaponSlot9KeyBinding_ReturnValue;  // 0x1D0(0x18)
	struct FKey CallFunc_GetCameraToggleKeyBinding_ReturnValue;  // 0x1E8(0x18)
	struct FKey CallFunc_GetDeployMenuKeyBinding_ReturnValue;  // 0x200(0x18)
	struct FKey CallFunc_GetSayTeamKeyBinding_ReturnValue;  // 0x218(0x18)
	struct FKey CallFunc_GetShowScoreboardKeyBinding_ReturnValue;  // 0x230(0x18)
	struct FKey CallFunc_GetSayAllKeyBinding_ReturnValue;  // 0x248(0x18)
	struct FKey CallFunc_GetUseKeyBinding_ReturnValue;  // 0x260(0x18)
	struct FKey CallFunc_GetPushToTalkLocalKeyBinding_ReturnValue;  // 0x278(0x18)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct FKey CallFunc_GetWeaponSlot3KeyBinding_ReturnValue;  // 0x298(0x18)
	struct FKey CallFunc_GetWeaponSlot4KeyBinding_ReturnValue;  // 0x2B0(0x18)
	struct FKey CallFunc_GetWeaponSlot5KeyBinding_ReturnValue;  // 0x2C8(0x18)
	struct FKey CallFunc_GetWeaponSlot6KeyBinding_ReturnValue;  // 0x2E0(0x18)
	struct FKey CallFunc_GetWeaponSlot7KeyBinding_ReturnValue;  // 0x2F8(0x18)
	struct FKey CallFunc_GetWeaponSlot8KeyBinding_ReturnValue;  // 0x310(0x18)
	struct FKey CallFunc_GetFireKeyBinding_ReturnValue;  // 0x328(0x18)
	struct FKey CallFunc_GetWeaponSlot2KeyBinding_ReturnValue;  // 0x340(0x18)
	struct FKey CallFunc_GetWeaponSlot1KeyBinding_ReturnValue;  // 0x358(0x18)
	struct FKey CallFunc_GetPreviousItemKeyBinding_ReturnValue;  // 0x370(0x18)
	struct FKey CallFunc_GetNextItemKeyBinding_ReturnValue;  // 0x388(0x18)
	struct FKey CallFunc_GetAimDownSightsKeyBinding_ReturnValue;  // 0x3A0(0x18)
	struct FKey CallFunc_GetReloadKeyBinding_ReturnValue;  // 0x3B8(0x18)
	struct FKey CallFunc_GetJumpKeyBinding_ReturnValue;  // 0x3D0(0x18)
	struct FKey CallFunc_GetCrouchKeyBinding_ReturnValue;  // 0x3E8(0x18)
	struct FKey CallFunc_GetSprintKeyBinding_ReturnValue;  // 0x400(0x18)
	struct FKey CallFunc_GetMoveRightKeyBinding_ReturnValue;  // 0x418(0x18)
	struct FKey CallFunc_GetMoveLeftKeyBinding_ReturnValue;  // 0x430(0x18)
	struct FKey CallFunc_GetMoveBackwardKeyBinding_ReturnValue;  // 0x448(0x18)
	struct FKey CallFunc_GetMoveForwardKeyBinding_ReturnValue;  // 0x460(0x18)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__InvertMousePitchOption_K2Node_ComponentBoundEvent_23_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__InvertMousePitchOption_K2Node_ComponentBoundEvent_23_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__VOIPVolOption_K2Node_ComponentBoundEvent_32_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__VOIPVolOption_K2Node_ComponentBoundEvent_32_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanLeft_IKS_K2Node_ComponentBoundEvent_97_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__LeanLeft_IKS_K2Node_ComponentBoundEvent_97_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot9_IKS_K2Node_ComponentBoundEvent_93_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot9_IKS_K2Node_ComponentBoundEvent_93_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SayTeam_IKS_K2Node_ComponentBoundEvent_58_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__SayTeam_IKS_K2Node_ComponentBoundEvent_58_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot0_IKS_K2Node_ComponentBoundEvent_91_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot0_IKS_K2Node_ComponentBoundEvent_91_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MotionBlurOption_K2Node_ComponentBoundEvent_35_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__MotionBlurOption_K2Node_ComponentBoundEvent_35_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__HeadphoneModeOption_K2Node_ComponentBoundEvent_28_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__HeadphoneModeOption_K2Node_ComponentBoundEvent_28_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__KeyRemappingSBox_K2Node_ComponentBoundEvent_90_OnUserScrolledEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__KeyRemappingSBox_K2Node_ComponentBoundEvent_90_OnUserScrolledEvent__DelegateSignature
{
	float CurrentOffset;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshAllOptionUI
// Size: 0x2(Inherited: 0x0) 
struct FRefreshAllOptionUI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsDirty_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalk_IKS_K2Node_ComponentBoundEvent_56_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__PushToTalk_IKS_K2Node_ComponentBoundEvent_56_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnIKSMenuKeySelected
// Size: 0x20(Inherited: 0x0) 
struct FOnIKSMenuKeySelected
{
	struct FInputChord Key Selected;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__VOVolOption_K2Node_ComponentBoundEvent_31_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__VOVolOption_K2Node_ComponentBoundEvent_31_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CameraToggle_IKS_K2Node_ComponentBoundEvent_62_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__CameraToggle_IKS_K2Node_ComponentBoundEvent_62_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot1_IKS_K2Node_ComponentBoundEvent_48_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot1_IKS_K2Node_ComponentBoundEvent_48_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DeployMenu_IKS_K2Node_ComponentBoundEvent_61_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__DeployMenu_IKS_K2Node_ComponentBoundEvent_61_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Use_IKS_K2Node_ComponentBoundEvent_59_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Use_IKS_K2Node_ComponentBoundEvent_59_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot6_IKS_K2Node_ComponentBoundEvent_53_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot6_IKS_K2Node_ComponentBoundEvent_53_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SayAll_IKS_K2Node_ComponentBoundEvent_57_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__SayAll_IKS_K2Node_ComponentBoundEvent_57_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot8_IKS_K2Node_ComponentBoundEvent_55_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot8_IKS_K2Node_ComponentBoundEvent_55_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetDesiredHorizontalAlignment
// Size: 0x1(Inherited: 0x0) 
struct FGetDesiredHorizontalAlignment
{
	char EHorizontalAlignment Alignment;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot7_IKS_K2Node_ComponentBoundEvent_54_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot7_IKS_K2Node_ComponentBoundEvent_54_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot5_IKS_K2Node_ComponentBoundEvent_52_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot5_IKS_K2Node_ComponentBoundEvent_52_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot4_IKS_K2Node_ComponentBoundEvent_51_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot4_IKS_K2Node_ComponentBoundEvent_51_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot3_IKS_K2Node_ComponentBoundEvent_50_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot3_IKS_K2Node_ComponentBoundEvent_50_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DisplayGammaOption_K2Node_ComponentBoundEvent_25_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__DisplayGammaOption_K2Node_ComponentBoundEvent_25_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot2_IKS_K2Node_ComponentBoundEvent_49_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__WeaponSlot2_IKS_K2Node_ComponentBoundEvent_49_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PreviousWeapon_IKS_K2Node_ComponentBoundEvent_47_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__PreviousWeapon_IKS_K2Node_ComponentBoundEvent_47_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__NextWeapon_IKS_K2Node_ComponentBoundEvent_46_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__NextWeapon_IKS_K2Node_ComponentBoundEvent_46_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Reload_IKS_K2Node_ComponentBoundEvent_44_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Reload_IKS_K2Node_ComponentBoundEvent_44_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AudioQualityOption_K2Node_ComponentBoundEvent_27_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__AudioQualityOption_K2Node_ComponentBoundEvent_27_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveRight_IKS_K2Node_ComponentBoundEvent_39_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__MoveRight_IKS_K2Node_ComponentBoundEvent_39_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Fire_IKS_K2Node_ComponentBoundEvent_43_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Fire_IKS_K2Node_ComponentBoundEvent_43_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__FOVOption_K2Node_ComponentBoundEvent_26_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__FOVOption_K2Node_ComponentBoundEvent_26_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Jump_IKS_K2Node_ComponentBoundEvent_42_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Jump_IKS_K2Node_ComponentBoundEvent_42_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Crouch_IKS_K2Node_ComponentBoundEvent_41_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__Crouch_IKS_K2Node_ComponentBoundEvent_41_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveLeft_IKS_K2Node_ComponentBoundEvent_38_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__MoveLeft_IKS_K2Node_ComponentBoundEvent_38_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveForward_IKS_K2Node_ComponentBoundEvent_36_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__MoveForward_IKS_K2Node_ComponentBoundEvent_36_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AllowSoundInBgOption_K2Node_ComponentBoundEvent_34_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__AllowSoundInBgOption_K2Node_ComponentBoundEvent_34_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ShadingOption_K2Node_ComponentBoundEvent_33_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ShadingOption_K2Node_ComponentBoundEvent_33_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MusicVolOption_K2Node_ComponentBoundEvent_30_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__MusicVolOption_K2Node_ComponentBoundEvent_30_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MasterVolOption_K2Node_ComponentBoundEvent_5_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__MasterVolOption_K2Node_ComponentBoundEvent_5_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SmoothMouseOption_K2Node_ComponentBoundEvent_24_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__SmoothMouseOption_K2Node_ComponentBoundEvent_24_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__GlobalMouseSensitivityOption_K2Node_ComponentBoundEvent_22_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__GlobalMouseSensitivityOption_K2Node_ComponentBoundEvent_22_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__FrameRateLimitOption_K2Node_ComponentBoundEvent_19_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__FrameRateLimitOption_K2Node_ComponentBoundEvent_19_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SmoothFrameRateOption_K2Node_ComponentBoundEvent_20_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__SmoothFrameRateOption_K2Node_ComponentBoundEvent_20_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ResolutionScaleOption_K2Node_ComponentBoundEvent_4_ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__ResolutionScaleOption_K2Node_ComponentBoundEvent_4_ValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnToggleMenuToggleStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnToggleMenuToggleStateChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bToggledOn : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnSliderMenuValueChanged
// Size: 0x4(Inherited: 0x0) 
struct FOnSliderMenuValueChanged
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshAudioOptionUI
// Size: 0x21(Inherited: 0x0) 
struct FRefreshAudioOptionUI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsSoundInBackgroundAllowed_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_GetVoiceVolumeLevel_ReturnValue;  // 0x4(0x4)
	float CallFunc_GetDialogueVolumeLevel_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetMusicVolumeLevel_ReturnValue;  // 0xC(0x4)
	float CallFunc_GetSoundEffectsVolumeLevel_ReturnValue;  // 0x10(0x4)
	float CallFunc_GetMasterVolumeLevel_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsHeadphoneModeEnabled_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_GetAudioQualityLevel_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnCheckboxMenuCheckStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnCheckboxMenuCheckStateChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnArrowMenuSelectionChangedUser
// Size: 0x10(Inherited: 0x0) 
struct FOnArrowMenuSelectionChangedUser
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__FoliageOption_K2Node_ComponentBoundEvent_18_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__FoliageOption_K2Node_ComponentBoundEvent_18_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__EffectsOption_K2Node_ComponentBoundEvent_17_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__EffectsOption_K2Node_ComponentBoundEvent_17_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__TextureOption_K2Node_ComponentBoundEvent_16_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__TextureOption_K2Node_ComponentBoundEvent_16_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ShadowOption_K2Node_ComponentBoundEvent_15_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ShadowOption_K2Node_ComponentBoundEvent_15_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PPOption_K2Node_ComponentBoundEvent_14_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__PPOption_K2Node_ComponentBoundEvent_14_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AAOption_K2Node_ComponentBoundEvent_13_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__AAOption_K2Node_ComponentBoundEvent_13_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ViewDistanceOption_K2Node_ComponentBoundEvent_12_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ViewDistanceOption_K2Node_ComponentBoundEvent_12_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__OverallQualityOption_K2Node_ComponentBoundEvent_11_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__OverallQualityOption_K2Node_ComponentBoundEvent_11_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__VerticalSyncOption_K2Node_ComponentBoundEvent_10_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__VerticalSyncOption_K2Node_ComponentBoundEvent_10_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ScreenResolutionOption_K2Node_ComponentBoundEvent_7_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ScreenResolutionOption_K2Node_ComponentBoundEvent_7_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DisplayModeOption_K2Node_ComponentBoundEvent_6_OnSelectionChangedByUser__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__DisplayModeOption_K2Node_ComponentBoundEvent_6_OnSelectionChangedByUser__DelegateSignature
{
	struct FString SelectedItemValue;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetMenuIndex
// Size: 0xF(Inherited: 0x0) 
struct FSetMenuIndex
{
	int32_t NewIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0xE(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnNavOptionSelected
// Size: 0xD(Inherited: 0x0) 
struct FOnNavOptionSelected
{
	struct UWBP_TextButton_C* NavBtn;  // 0x0(0x8)
	int32_t CallFunc_GetChildIndex_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xC(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshGameplayOptionUI
// Size: 0x8(Inherited: 0x0) 
struct FRefreshGameplayOptionUI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsSmoothMouseEnabled_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_GetInvertMousePitch_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_GetSwitchFireModeOnReselect_ReturnValue : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float CallFunc_GetMouseSensitivityX_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.IsDirty
// Size: 0x4(Inherited: 0x0) 
struct FIsDirty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDirty : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsDirty_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshVideoOptionUI
// Size: 0x11C(Inherited: 0x0) 
struct FRefreshVideoOptionUI
{
	float CallFunc_GetFieldOfView_ReturnValue;  // 0x0(0x4)
	float CallFunc_GetDisplayGamma_ReturnValue;  // 0x4(0x4)
	float CallFunc_GetFrameRateLimit_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_IsSmoothFrameRateEnabled_ReturnValue : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_IsMotionBlurEnabled_ReturnValue : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_IsVSyncEnabled_ReturnValue : 1;  // 0xE(0x1)
	char pad_15[1];  // 0xF(0x1)
	struct FIntPoint CallFunc_GetScreenResolution_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x20(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x38(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x50(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x90(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xD0(0x10)
	char EWindowMode CallFunc_GetFullscreenMode_ReturnValue;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct FText CallFunc_Format_ReturnValue;  // 0xE8(0x18)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x108(0x10)
	int32_t CallFunc_FindOptionValueIndex_Index;  // 0x118(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.PopulateScreenResolutionOption
// Size: 0x160(Inherited: 0x0) 
struct FPopulateScreenResolutionOption
{
	int32_t Temp_int_Loop_Counter_Variable;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FIntPoint> CallFunc_GetSupportedFullscreenResolutions_Resolutions;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_GetSupportedFullscreenResolutions_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FIntPoint CallFunc_Array_Get_Item;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x38(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x50(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x68(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xE8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xF8(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x110(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x120(0x18)
	struct FFOptionItemSelection K2Node_MakeStruct_FOptionItemSelection;  // 0x138(0x28)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetScreenResolutionSetting
// Size: 0x48(Inherited: 0x0) 
struct FSetScreenResolutionSetting
{
	struct FString ScreenResolution;  // 0x0(0x10)
	struct FString CallFunc_Split_LeftS;  // 0x10(0x10)
	struct FString CallFunc_Split_RightS;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Split_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Conv_StringToInt_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_Conv_StringToInt_ReturnValue_2;  // 0x3C(0x4)
	struct FIntPoint K2Node_MakeStruct_IntPoint;  // 0x40(0x8)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshOverallQualityOption
// Size: 0x14(Inherited: 0x0) 
struct FRefreshOverallQualityOption
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t CallFunc_GetOverallScalabilityLevel_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool Temp_bool_Variable : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	int32_t K2Node_Select_Default;  // 0x10(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshQualityOptions
// Size: 0x31(Inherited: 0x0) 
struct FRefreshQualityOptions
{
	int32_t CallFunc_GetShadingQuality_ReturnValue;  // 0x0(0x4)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleNormalized;  // 0x4(0x4)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleValue;  // 0x8(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MinScaleValue;  // 0xC(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MaxScaleValue;  // 0x10(0x4)
	int32_t CallFunc_GetFoliageQuality_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_GetVisualEffectQuality_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_GetTextureQuality_ReturnValue;  // 0x1C(0x4)
	int32_t CallFunc_GetShadowQuality_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_GetPostProcessingQuality_ReturnValue;  // 0x24(0x4)
	int32_t CallFunc_GetAntiAliasingQuality_ReturnValue;  // 0x28(0x4)
	int32_t CallFunc_GetViewDistanceQuality_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RegisterClickEventsForContainer
// Size: 0xA0(Inherited: 0x0) 
struct FRegisterClickEventsForContainer
{
	struct UPanelWidget* Container;  // 0x0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x20(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x34(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x44(0x10)
	int32_t Temp_int_Variable;  // 0x54(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x58(0x8)
	struct UWBP_OptionsMenuItem_Toggle_C* K2Node_DynamicCast_AsWBP_Options_Menu_Item_Toggle;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UWBP_OptionsMenuItem_Slider_C* K2Node_DynamicCast_AsWBP_Options_Menu_Item_Slider;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UWBP_OptionsMenuItem_Checkbox_C* K2Node_DynamicCast_AsWBP_Options_Menu_Item_Checkbox;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct UWBP_OptionsMenuItem_Arrow_C* K2Node_DynamicCast_AsWBP_Options_Menu_Item_Arrow;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x99(0x1)
	char pad_154[2];  // 0x9A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x9C(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.UpdateUnsavedStatus
// Size: 0x6(Inherited: 0x0) 
struct FUpdateUnsavedStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_IsDirty_bDirty : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsDirty_bDirty_2 : 1;  // 0x4(0x1)
	uint8_t  K2Node_Select_Default;  // 0x5(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetResolutionScaleBounds
// Size: 0x14(Inherited: 0x0) 
struct FSetResolutionScaleBounds
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleNormalized;  // 0x4(0x4)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleValue;  // 0x8(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MinScaleValue;  // 0xC(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MaxScaleValue;  // 0x10(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.UpdateScreenResolutionState
// Size: 0xF8(Inherited: 0x0) 
struct FUpdateScreenResolutionState
{
	char EWindowMode CallFunc_GetFullscreenMode_ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FIntPoint CallFunc_GetDesktopResolution_ReturnValue;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x10(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x28(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x40(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x80(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xC0(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xD0(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0xE8(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BalanceVolumeLevels
// Size: 0x1(Inherited: 0x0) 
struct FBalanceVolumeLevels
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRefreshAudioUI : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BalanceMasterVolumeLevel
// Size: 0x10(Inherited: 0x0) 
struct FBalanceMasterVolumeLevel
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRefreshAudioUI : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_GetMaxSecondaryVolumeLevel_MaxVolLvl;  // 0x4(0x4)
	float CallFunc_GetMasterVolumeLevel_ReturnValue;  // 0x8(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xC(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BalanceSecondaryVolumeLevels
// Size: 0x24(Inherited: 0x0) 
struct FBalanceSecondaryVolumeLevels
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bMatchMasterVolLvl : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bRefreshAudioUI : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_GetVoiceVolumeLevel_ReturnValue;  // 0x4(0x4)
	float CallFunc_GetDialogueVolumeLevel_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetBalancedSecondaryVolumeLevel_VolLevelBalanced;  // 0xC(0x4)
	float CallFunc_GetMusicVolumeLevel_ReturnValue;  // 0x10(0x4)
	float CallFunc_GetBalancedSecondaryVolumeLevel_VolLevelBalanced_2;  // 0x14(0x4)
	float CallFunc_GetBalancedSecondaryVolumeLevel_VolLevelBalanced_3;  // 0x18(0x4)
	float CallFunc_GetSoundEffectsVolumeLevel_ReturnValue;  // 0x1C(0x4)
	float CallFunc_GetBalancedSecondaryVolumeLevel_VolLevelBalanced_4;  // 0x20(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetBalancedSecondaryVolumeLevel
// Size: 0x1C(Inherited: 0x0) 
struct FGetBalancedSecondaryVolumeLevel
{
	float VolumeLevelToBalance;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bMatchMasterVolLvl : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float VolLevelBalanced;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_GetMasterVolumeLevel_ReturnValue;  // 0x10(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x14(0x4)
	float K2Node_Select_Default;  // 0x18(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetMaxSecondaryVolumeLevel
// Size: 0x20(Inherited: 0x0) 
struct FGetMaxSecondaryVolumeLevel
{
	float MaxVolLvl;  // 0x0(0x4)
	float CallFunc_GetSoundEffectsVolumeLevel_ReturnValue;  // 0x4(0x4)
	float CallFunc_GetVoiceVolumeLevel_ReturnValue;  // 0x8(0x4)
	float CallFunc_GetDialogueVolumeLevel_ReturnValue;  // 0xC(0x4)
	float CallFunc_GetMusicVolumeLevel_ReturnValue;  // 0x10(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x14(0x4)
	float CallFunc_FMax_ReturnValue_2;  // 0x18(0x4)
	float CallFunc_FMax_ReturnValue_3;  // 0x1C(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.Update Key Binding
// Size: 0x4C(Inherited: 0x0) 
struct FUpdate Key Binding
{
	struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS;  // 0x0(0x8)
	struct FInputChord NewInputChord;  // 0x8(0x20)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool PlayerChanging : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FKey New Key;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_IsPlayerChangingKeyBindings_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x4B(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetCurrentIKS
// Size: 0xC(Inherited: 0x0) 
struct FSetCurrentIKS
{
	struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS;  // 0x0(0x8)
	float CallFunc_GetScrollOffset_ReturnValue;  // 0x8(0x4)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.StartSelectingKey
// Size: 0x14(Inherited: 0x0) 
struct FStartSelectingKey
{
	struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS;  // 0x0(0x8)
	struct UWBP_MouseInputCatcherOverlay_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsSelectingKey_IsSelecting : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x13(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetSubMenuOptions
// Size: 0x10(Inherited: 0x0) 
struct FGetSubMenuOptions
{
	struct TArray<struct FFSubMenuOption> SubOptions;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.HasSubMenus
// Size: 0x1(Inherited: 0x0) 
struct FHasSubMenus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSubMenuOptions : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetDesiredVerticalAlignment
// Size: 0x1(Inherited: 0x0) 
struct FGetDesiredVerticalAlignment
{
	char EVerticalAlignment Alignment;  // 0x0(0x1)

}; 
