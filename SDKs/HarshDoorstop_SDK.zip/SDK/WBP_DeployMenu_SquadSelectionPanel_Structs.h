#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.GeneratePlatoon
// Size: 0x8(Inherited: 0x8) 
struct FGeneratePlatoon : public FGeneratePlatoon
{
	struct UPlatoonListEntry* PlatoonData;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.DeconstructPlatoon
// Size: 0xC(Inherited: 0x10) 
struct FDeconstructPlatoon : public FDeconstructPlatoon
{
	struct UPlatoonListEntry* RemovedPlatoonData;  // 0x0(0x8)
	int32_t RemovedPlatoonIdx;  // 0x8(0x4)

}; 
// Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.ExecuteUbergraph_WBP_DeployMenu_SquadSelectionPanel
// Size: 0x2D(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_SquadSelectionPanel
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UPlatoonListEntry* K2Node_Event_PlatoonData;  // 0x10(0x8)
	struct UPlatoonListEntry* K2Node_Event_RemovedPlatoonData;  // 0x18(0x8)
	int32_t K2Node_Event_RemovedPlatoonIdx;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x2C(0x1)

}; 
// Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.AddNewPlatoonItemWidget
// Size: 0x29(Inherited: 0x0) 
struct FAddNewPlatoonItemWidget
{
	struct UPlatoonListEntry* PlatoonData;  // 0x0(0x8)
	struct UWBP_DeployMenu_PlatoonSquadList_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x18(0x8)
	struct UScrollBoxSlot* K2Node_DynamicCast_AsScroll_Box_Slot;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.RemovePlatoonItemWidgetFromList
// Size: 0x6A(Inherited: 0x0) 
struct FRemovePlatoonItemWidgetFromList
{
	struct UPlatoonListEntry* RemovedPlatoonData;  // 0x0(0x8)
	int32_t RemoveIdx;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_RemoveChildAt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x20(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UWBP_DeployMenu_PlatoonSquadList_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Platoon_Squad_List;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_RemoveChildAt_ReturnValue_2 : 1;  // 0x4B(0x1)
	char pad_76[4];  // 0x4C(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UWBP_DeployMenu_PlatoonSquadList_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Platoon_Squad_List_2;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x69(0x1)

}; 
