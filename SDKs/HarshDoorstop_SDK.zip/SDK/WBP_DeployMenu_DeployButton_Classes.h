#pragma once 
#include <WBP_DeployMenu_DeployButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C
// Size: 0x802(Inherited: 0x230) 
struct UWBP_DeployMenu_DeployButton_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UButton* DeployBtn;  // 0x238(0x8)
	struct UTextBlock* DeployBtnText;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool bCloseBtnBehavior : 1;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct FText DeployText;  // 0x250(0x18)
	struct FText CloseMenuText;  // 0x268(0x18)
	struct FMulticastInlineDelegate OnClicked;  // 0x280(0x10)
	struct FMulticastInlineDelegate OnPressed;  // 0x290(0x10)
	struct FMulticastInlineDelegate OnReleased;  // 0x2A0(0x10)
	struct FMulticastInlineDelegate OnHovered;  // 0x2B0(0x10)
	struct FMulticastInlineDelegate OnUnhovered;  // 0x2C0(0x10)
	struct FText SelectSpawnText;  // 0x2D0(0x18)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool bDeploying : 1;  // 0x2E8(0x1)
	char pad_745[7];  // 0x2E9(0x7)
	struct FButtonStyle DeployBtnStyle;  // 0x2F0(0x278)
	struct FButtonStyle CancelBtnStyle;  // 0x568(0x278)
	char pad_2016_1 : 7;  // 0x7E0(0x1)
	bool bDesignPreviewCancelBtn : 1;  // 0x7E0(0x1)
	char pad_2017[7];  // 0x7E1(0x7)
	struct FText CancelDeploymentText;  // 0x7E8(0x18)
	char pad_2048_1 : 7;  // 0x800(0x1)
	bool bSpawnPointSelected : 1;  // 0x800(0x1)
	char pad_2049_1 : 7;  // 0x801(0x1)
	bool bUseCancelBehavior : 1;  // 0x801(0x1)

	void InternalGetSpawnTimeRemaining(int32_t& SpawnSeconds); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalGetSpawnTimeRemaining
	void InternalUpdateBtnStyle(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalUpdateBtnStyle
	void InternalUpdateBtnText(bool bDeploying, bool bSpawnPointSelected); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.InternalUpdateBtnText
	void UpdateDeployBtnState(bool bPlayerAlive, bool bDeploymentQueued, bool bSpawnPointSelected); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.UpdateDeployBtnState
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.PreConstruct
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_1_OnButtonPressedEvent__DelegateSignature
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_2_OnButtonReleasedEvent__DelegateSignature
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_3_OnButtonHoverEvent__DelegateSignature
	void BndEvt__DeployBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature(); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.BndEvt__DeployBtn_K2Node_ComponentBoundEvent_4_OnButtonHoverEvent__DelegateSignature
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.Tick
	void ExecuteUbergraph_WBP_DeployMenu_DeployButton(int32_t EntryPoint); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.ExecuteUbergraph_WBP_DeployMenu_DeployButton
	void OnUnhovered__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnUnhovered__DelegateSignature
	void OnHovered__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnHovered__DelegateSignature
	void OnReleased__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnReleased__DelegateSignature
	void OnPressed__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnPressed__DelegateSignature
	void OnClicked__DelegateSignature(bool bCloseBtn); // Function WBP_DeployMenu_DeployButton.WBP_DeployMenu_DeployButton_C.OnClicked__DelegateSignature
}; 



