#pragma once 
#include "SDK.h" 
 
 
// Function ABPI_VehicleAnimLayer.ABPI_VehicleAnimLayer_C.VehicleLowerBody
// Size: 0x20(Inherited: 0x0) 
struct FVehicleLowerBody
{
	struct FPoseLink LowerBody;  // 0x0(0x10)
	struct FPoseLink VehicleLowerBody;  // 0x10(0x10)

}; 
// Function ABPI_VehicleAnimLayer.ABPI_VehicleAnimLayer_C.VehicleFullBody
// Size: 0x20(Inherited: 0x0) 
struct FVehicleFullBody
{
	struct FPoseLink FullBody;  // 0x0(0x10)
	struct FPoseLink VehicleFullBody;  // 0x10(0x10)

}; 
