#pragma once 
#include "SDK.h" 
 
 
// Function WBP_EntitlementBadge.WBP_EntitlementBadge_C.ExecuteUbergraph_WBP_EntitlementBadge
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_EntitlementBadge
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)

}; 
// Function WBP_EntitlementBadge.WBP_EntitlementBadge_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
