#pragma once 
#include <BP_HDVOIPTalker_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDVOIPTalker.BP_HDVOIPTalker_C
// Size: 0x138(Inherited: 0xE8) 
struct UBP_HDVOIPTalker_C : public UVOIPTalker
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xE8(0x8)
	struct APlayerState* OwningPS;  // 0xF0(0x8)
	struct FVoiceSettings NonSpatializedSettings;  // 0xF8(0x18)
	struct FVoiceSettings SpatializedSettings;  // 0x110(0x18)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool bRegistered : 1;  // 0x128(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool bTalking : 1;  // 0x129(0x1)
	char pad_298[6];  // 0x12A(0x6)
	struct UAudioComponent* CachedAudioComp;  // 0x130(0x8)

	void ListenForTalkingStateChangedEvents(); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.ListenForTalkingStateChangedEvents
	void UpdateSettingsUsageForNextBeginTalk(bool bUseSpatialized, bool& bSettingsUpdated); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.UpdateSettingsUsageForNextBeginTalk
	void RegisterTalker(struct APlayerState* InRegisteredPS, struct FVoiceSettings& InSpatializedSettings, struct FVoiceSettings& InNonSpatializedSettings, bool bStartSpatialized); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.RegisterTalker
	void BPOnTalkingBegin(struct UAudioComponent* AudioComponent); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.BPOnTalkingBegin
	void BPOnTalkingEnd(); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.BPOnTalkingEnd
	void TalkStateChangedOnChannel(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.TalkStateChangedOnChannel
	void ExecuteUbergraph_BP_HDVOIPTalker(int32_t EntryPoint); // Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.ExecuteUbergraph_BP_HDVOIPTalker
}; 



