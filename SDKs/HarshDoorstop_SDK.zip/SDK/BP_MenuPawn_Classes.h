#pragma once 
#include <BP_MenuPawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MenuPawn.BP_MenuPawn_C
// Size: 0x2A8(Inherited: 0x2A8) 
struct ABP_MenuPawn_C : public ADefaultPawn
{

}; 



