#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.ExecuteUbergraph_WBP_OptionMenu_Home
// Size: 0x1D1(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionMenu_Home
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_GetMaxGridSize_MaxSize;  // 0x1C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x30(0x10)
	struct FName CallFunc_Array_Get_Item;  // 0x40(0x8)
	struct FFEntitlementBadgeUIDefinition CallFunc_GetDataTableRowFromName_OutRow;  // 0x48(0x98)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xE4(0x4)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_IsEntitledToBadge_bEntitled : 1;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xEA(0x1)
	char pad_235[5];  // 0xEB(0x5)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames_2;  // 0xF0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x100(0x4)
	struct FName CallFunc_Array_Get_Item_2;  // 0x104(0x8)
	char pad_268_1 : 7;  // 0x10C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	struct FFCommunityMediaLinkUIDefinition CallFunc_GetDataTableRowFromName_OutRow_2;  // 0x110(0xC0)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue_2 : 1;  // 0x1D0(0x1)

}; 
// Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.InsertEntitlementBadge
// Size: 0xB8(Inherited: 0x0) 
struct FInsertEntitlementBadge
{
	struct FFEntitlementBadgeUIDefinition EntitlementUIDef;  // 0x0(0x98)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct UWBP_EntitlementBadge_C* CallFunc_Create_ReturnValue;  // 0xA0(0x8)
	int32_t CallFunc_GetColumnFromIndex_ReturnValue;  // 0xA8(0x4)
	int32_t CallFunc_GetRowFromIndex_ReturnValue;  // 0xAC(0x4)
	struct UUniformGridSlot* CallFunc_AddChildToUniformGrid_ReturnValue;  // 0xB0(0x8)

}; 
// Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.IsEntitledToBadge
// Size: 0x12(Inherited: 0x0) 
struct FIsEntitledToBadge
{
	struct TArray<struct FFEntitlementDefinition> Entitlements;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bEntitled : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_CheckEntitlement_bEntitled : 1;  // 0x11(0x1)

}; 
// Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.InsertMediaLink
// Size: 0xD0(Inherited: 0x0) 
struct FInsertMediaLink
{
	struct FFCommunityMediaLinkUIDefinition LinkUIDef;  // 0x0(0xC0)
	struct UWBP_CommunityMediaLink_C* CallFunc_Create_ReturnValue;  // 0xC0(0x8)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0xC8(0x8)

}; 
// Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.GetMaxGridSize
// Size: 0x8(Inherited: 0x0) 
struct FGetMaxGridSize
{
	int32_t MaxSize;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)

}; 
