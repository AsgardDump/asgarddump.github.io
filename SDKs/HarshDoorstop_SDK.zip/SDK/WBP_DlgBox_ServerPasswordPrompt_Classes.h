#pragma once 
#include <WBP_DlgBox_ServerPasswordPrompt_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C
// Size: 0x260(Inherited: 0x230) 
struct UWBP_DlgBox_ServerPasswordPrompt_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UEditableTextBox* PromptTextBox;  // 0x238(0x8)
	struct FMulticastInlineDelegate OnConfirmInput;  // 0x240(0x10)
	struct FMulticastInlineDelegate OnCancelInput;  // 0x250(0x10)

	struct FEventReply OnPreviewKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnPreviewKeyDown
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnMouseButtonDown
	void Construct(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.Construct
	void DummyInput(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.DummyInput
	void ConfirmInput(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.ConfirmInput
	void CancelInput(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.CancelInput
	void OnRemovedFromFocusPath(struct FFocusEvent InFocusEvent); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnRemovedFromFocusPath
	void ExecuteUbergraph_WBP_DlgBox_ServerPasswordPrompt(int32_t EntryPoint); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.ExecuteUbergraph_WBP_DlgBox_ServerPasswordPrompt
	void OnCancelInput__DelegateSignature(); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnCancelInput__DelegateSignature
	void OnConfirmInput__DelegateSignature(struct FText InputText); // Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnConfirmInput__DelegateSignature
}; 



