#pragma once 
#include "SDK.h" 
 
 
// Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.OnSelectionChanged__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FOnSelectionChanged__DelegateSignature
{
	struct FString SelectedItem;  // 0x0(0x10)
	char ESelectInfo SelectionType;  // 0x10(0x1)

}; 
// Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.GetSettingText
// Size: 0x18(Inherited: 0x0) 
struct FGetSettingText
{
	struct FText SettingText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.ExecuteUbergraph_WBP_ModifierSetting_ComboBox
// Size: 0x80(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_ModifierSetting_ComboBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct FString CallFunc_Array_Get_Item;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FString K2Node_ComponentBoundEvent_SelectedItem;  // 0x48(0x10)
	char ESelectInfo K2Node_ComponentBoundEvent_SelectionType;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool Temp_bool_Variable : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FText K2Node_Select_Default;  // 0x60(0x18)
	struct USizeBoxSlot* CallFunc_SlotAsSizeBoxSlot_ReturnValue;  // 0x78(0x8)

}; 
// Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.SetSettingText
// Size: 0x18(Inherited: 0x0) 
struct FSetSettingText
{
	struct FText InSettingText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_ComboBox.WBP_ModifierSetting_ComboBox_C.BndEvt__ModifierComboBox_K2Node_ComponentBoundEvent_0_OnSelectionChangedEvent__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FBndEvt__ModifierComboBox_K2Node_ComponentBoundEvent_0_OnSelectionChangedEvent__DelegateSignature
{
	struct FString SelectedItem;  // 0x0(0x10)
	char ESelectInfo SelectionType;  // 0x10(0x1)

}; 
