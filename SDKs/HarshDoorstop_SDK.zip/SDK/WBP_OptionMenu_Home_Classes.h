#pragma once 
#include <WBP_OptionMenu_Home_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionMenu_Home.WBP_OptionMenu_Home_C
// Size: 0x280(Inherited: 0x238) 
struct UWBP_OptionMenu_Home_C : public UDFBaseMenu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UUniformGridPanel* EntitlementBadgeGrid;  // 0x240(0x8)
	struct UVerticalBox* MediaLinkVBox;  // 0x248(0x8)
	struct UDataTable* EntitlementBadgeDefinitionSource;  // 0x250(0x8)
	struct UDataTable* MediaLinkDefinitionSource;  // 0x258(0x8)
	int32_t BadgeMaxRows;  // 0x260(0x4)
	int32_t BadgeMaxColumns;  // 0x264(0x4)
	struct FMargin BadgeSlotPadding;  // 0x268(0x10)
	float BadgeMinDesiredSlotWidth;  // 0x278(0x4)
	float BadgeMinDesiredSlotHeight;  // 0x27C(0x4)

	void IsEntitledToBadge(struct TArray<struct FFEntitlementDefinition>& Entitlements, bool& bEntitled); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.IsEntitledToBadge
	void GetMaxGridSize(int32_t& MaxSize); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.GetMaxGridSize
	void InsertMediaLink(struct FFCommunityMediaLinkUIDefinition& LinkUIDef); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.InsertMediaLink
	void InsertEntitlementBadge(struct FFEntitlementBadgeUIDefinition& EntitlementUIDef); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.InsertEntitlementBadge
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.PreConstruct
	void OnInitialized(); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.OnInitialized
	void ExecuteUbergraph_WBP_OptionMenu_Home(int32_t EntryPoint); // Function WBP_OptionMenu_Home.WBP_OptionMenu_Home_C.ExecuteUbergraph_WBP_OptionMenu_Home
}; 



