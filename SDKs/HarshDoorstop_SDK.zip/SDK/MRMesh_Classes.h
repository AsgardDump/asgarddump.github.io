#pragma once 
#include <MRMesh_Structs.h>
 
 
 
// Class MRMesh.MeshReconstructorBase
// Size: 0x28(Inherited: 0x28) 
struct UMeshReconstructorBase : public UObject
{

	void StopReconstruction(); // Function MRMesh.MeshReconstructorBase.StopReconstruction
	void StartReconstruction(); // Function MRMesh.MeshReconstructorBase.StartReconstruction
	void PauseReconstruction(); // Function MRMesh.MeshReconstructorBase.PauseReconstruction
	bool IsReconstructionStarted(); // Function MRMesh.MeshReconstructorBase.IsReconstructionStarted
	bool IsReconstructionPaused(); // Function MRMesh.MeshReconstructorBase.IsReconstructionPaused
	void DisconnectMRMesh(); // Function MRMesh.MeshReconstructorBase.DisconnectMRMesh
	void ConnectMRMesh(struct UMRMeshComponent* Mesh); // Function MRMesh.MeshReconstructorBase.ConnectMRMesh
}; 



// Class MRMesh.MRMeshComponent
// Size: 0x480(Inherited: 0x410) 
struct UMRMeshComponent : public UPrimitiveComponent
{
	struct UMaterialInterface* Material;  // 0x410(0x8)
	char pad_1048_1 : 7;  // 0x418(0x1)
	bool bCreateMeshProxySections : 1;  // 0x418(0x1)
	char pad_1049_1 : 7;  // 0x419(0x1)
	bool bUpdateNavMeshOnMeshUpdate : 1;  // 0x419(0x1)
	char pad_1050_1 : 7;  // 0x41A(0x1)
	bool bNeverCreateCollisionMesh : 1;  // 0x41A(0x1)
	char pad_1051[5];  // 0x41B(0x5)
	struct UBodySetup* CachedBodySetup;  // 0x420(0x8)
	struct TArray<struct UBodySetup*> BodySetups;  // 0x428(0x10)
	struct UMaterialInterface* WireframeMaterial;  // 0x438(0x8)
	char pad_1088[64];  // 0x440(0x40)

	bool IsConnected(); // Function MRMesh.MRMeshComponent.IsConnected
	void ForceNavMeshUpdate(); // Function MRMesh.MRMeshComponent.ForceNavMeshUpdate
	void Clear(); // Function MRMesh.MRMeshComponent.Clear
}; 



// Class MRMesh.MockDataMeshTrackerComponent
// Size: 0x260(Inherited: 0x1F0) 
struct UMockDataMeshTrackerComponent : public USceneComponent
{
	struct FMulticastInlineDelegate OnMeshTrackerUpdated;  // 0x1F0(0x10)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool ScanWorld : 1;  // 0x200(0x1)
	char pad_513_1 : 7;  // 0x201(0x1)
	bool RequestNormals : 1;  // 0x201(0x1)
	char pad_514_1 : 7;  // 0x202(0x1)
	bool RequestVertexConfidence : 1;  // 0x202(0x1)
	uint8_t  VertexColorMode;  // 0x203(0x1)
	char pad_516[4];  // 0x204(0x4)
	struct TArray<struct FColor> BlockVertexColors;  // 0x208(0x10)
	struct FLinearColor VertexColorFromConfidenceZero;  // 0x218(0x10)
	struct FLinearColor VertexColorFromConfidenceOne;  // 0x228(0x10)
	float UpdateInterval;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)
	struct UMRMeshComponent* MRMesh;  // 0x240(0x8)
	char pad_584[24];  // 0x248(0x18)

	void OnMockDataMeshTrackerUpdated__DelegateSignature(int32_t Index, struct TArray<struct FVector>& Vertices, struct TArray<int32_t>& Triangles, struct TArray<struct FVector>& Normals, struct TArray<float>& Confidence); // DelegateFunction MRMesh.MockDataMeshTrackerComponent.OnMockDataMeshTrackerUpdated__DelegateSignature
	void DisconnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.DisconnectMRMesh
	void ConnectMRMesh(struct UMRMeshComponent* InMRMeshPtr); // Function MRMesh.MockDataMeshTrackerComponent.ConnectMRMesh
}; 



