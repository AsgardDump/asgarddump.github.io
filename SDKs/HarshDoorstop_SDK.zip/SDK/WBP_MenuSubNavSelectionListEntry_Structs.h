#pragma once 
#include "SDK.h" 
 
 
// Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.ExecuteUbergraph_WBP_MenuSubNavSelectionListEntry
// Size: 0x11(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_MenuSubNavSelectionListEntry
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_CustomEvent_bIsSelected : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UWBP_CreateGameSelectionListEntry_C* K2Node_ComponentBoundEvent_Item;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_ComponentBoundEvent_bSelected : 1;  // 0x10(0x1)

}; 
// Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FButtonClicked__DelegateSignature
{
	struct UWBP_MenuSubNavSelectionListEntry_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.BndEvt__SelectionEntry_K2Node_ComponentBoundEvent_1_OnSelectionStateChanged__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FBndEvt__SelectionEntry_K2Node_ComponentBoundEvent_1_OnSelectionStateChanged__DelegateSignature
{
	struct UWBP_CreateGameSelectionListEntry_C* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelected : 1;  // 0x8(0x1)

}; 
// Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.OnItemSelectionChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnItemSelectionChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsSelected : 1;  // 0x0(0x1)

}; 
// Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.SetSubMenuIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetSubMenuIndex
{
	int32_t Idx;  // 0x0(0x4)

}; 
