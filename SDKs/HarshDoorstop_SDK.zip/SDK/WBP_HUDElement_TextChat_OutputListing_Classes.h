#pragma once 
#include <WBP_HUDElement_TextChat_OutputListing_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C
// Size: 0x2B0(Inherited: 0x230) 
struct UWBP_HUDElement_TextChat_OutputListing_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWidgetAnimation* FadeOutAnim;  // 0x238(0x8)
	struct URichTextBlock* MsgContentText;  // 0x240(0x8)
	struct UWBP_TextChat_MsgPrefix_C* MsgPrefix;  // 0x248(0x8)
	struct UHDTextChatMsgInfo* ChatMsg;  // 0x250(0x8)
	float MsgLifeTime;  // 0x258(0x4)
	char pad_604[4];  // 0x25C(0x4)
	struct FSlateColor EnemyMsgColor;  // 0x260(0x28)
	struct FSlateColor FriendlyMsgColor;  // 0x288(0x28)

	void Finished_54BC5F4D4E481384960AD59474319862(); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.Finished_54BC5F4D4E481384960AD59474319862
	void LifetimeExpired(); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.LifetimeExpired
	void OnInitialized(); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.OnInitialized
	void SetupListing(struct UHDTextChatMsgInfo* Msg); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.SetupListing
	void ExecuteUbergraph_WBP_HUDElement_TextChat_OutputListing(int32_t EntryPoint); // Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.ExecuteUbergraph_WBP_HUDElement_TextChat_OutputListing
}; 



