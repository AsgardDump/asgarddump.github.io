#pragma once 
#include <FGameCreditsEntry_Structs.h>
 
 
 
