#pragma once 
#include "SDK.h" 
 
 
// Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.OnServerFiltersChanged__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnServerFiltersChanged__DelegateSignature
{
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters;  // 0x0(0x50)

}; 
// Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.ExecuteUbergraph_WBP_JoinServerFiltersPanel
// Size: 0x68(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_JoinServerFiltersPanel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> K2Node_CustomEvent_ActiveFilters;  // 0x8(0x50)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x58(0x10)

}; 
// Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.FilterSettingsChanged
// Size: 0x50(Inherited: 0x0) 
struct FFilterSettingsChanged
{
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters;  // 0x0(0x50)

}; 
// Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.GetFilterRules
// Size: 0x169(Inherited: 0x0) 
struct FGetFilterRules
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActiveOnly : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> FilterRules;  // 0x8(0x50)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> Rules;  // 0x58(0x50)
	int32_t Temp_int_Variable;  // 0xA8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xAC(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xB0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xB4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0xC0(0x8)
	struct TScriptInterface<IBPI_ServerFilterRules_C> K2Node_DynamicCast_AsBPI_Server_Filter_Rules;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0xDC(0x4)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> CallFunc_GetFilterRules_FilterRules;  // 0xE0(0x50)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x130(0x4)
	char pad_308_1 : 7;  // 0x134(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x134(0x1)
	char pad_309[3];  // 0x135(0x3)
	struct TArray<struct FHDFilterRuleParams> CallFunc_Map_Values_Values;  // 0x138(0x10)
	struct TArray<UHDServerListFilterRule*> CallFunc_Map_Keys_Keys;  // 0x148(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x158(0x4)
	char pad_348[4];  // 0x15C(0x4)
	UHDServerListFilterRule* CallFunc_Array_Get_Item;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x168(0x1)

}; 
