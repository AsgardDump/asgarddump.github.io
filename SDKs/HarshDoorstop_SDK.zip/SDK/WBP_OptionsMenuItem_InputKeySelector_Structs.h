#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.ExecuteUbergraph_WBP_OptionsMenuItem_InputKeySelector
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionsMenuItem_InputKeySelector
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey;  // 0x8(0x20)

}; 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.BndEvt__OptionIKS_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__OptionIKS_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.GetSelectedKey
// Size: 0x30(Inherited: 0x0) 
struct FGetSelectedKey
{
	struct FKey SelectedKey;  // 0x0(0x18)
	struct FKey CallFunc_GetSelectedKey_SelectedKey;  // 0x18(0x18)

}; 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.SetSelectedKey
// Size: 0x18(Inherited: 0x0) 
struct FSetSelectedKey
{
	struct FKey SelectedKey;  // 0x0(0x18)

}; 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.IsSelectingKey
// Size: 0x2(Inherited: 0x0) 
struct FIsSelectingKey
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsSelecting : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_GetIsSelectingKey_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.ClearSelectedKey
// Size: 0x41(Inherited: 0x0) 
struct FClearSelectedKey
{
	struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS;  // 0x0(0x8)
	struct FKey NewKey;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bIsPlayerChangingKeyBindings : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct FKey CallFunc_GetSelectedKey_SelectedKey;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue : 1;  // 0x40(0x1)

}; 
