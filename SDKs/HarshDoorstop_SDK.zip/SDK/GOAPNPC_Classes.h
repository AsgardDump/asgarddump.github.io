#pragma once 
#include <GOAPNPC_Structs.h>
 
 
 
// Class GOAPNPC.GOAPAction
// Size: 0x98(Inherited: 0x28) 
struct UGOAPAction : public UObject
{
	struct FString Name;  // 0x28(0x10)
	float Cost;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	AActor* TargetClass;  // 0x40(0x8)
	struct TArray<struct FAtom> Preconditions;  // 0x48(0x10)
	struct TArray<struct FAtom> Effects;  // 0x58(0x10)
	struct AActor* Target;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bActivated : 1;  // 0x70(0x1)
	char pad_113[39];  // 0x71(0x27)

	bool Validate(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.Validate
	bool ReceiveIsActionInvalid(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.ReceiveIsActionInvalid
	bool HasCompleted(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.HasCompleted
	struct TArray<struct AActor*> GetTargetsList(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.GetTargetsList
	void EndAction(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.EndAction
	bool DoAction(struct APawn* Pawn, struct FString& FailureReason); // Function GOAPNPC.GOAPAction.DoAction
	bool CheckProceduralPrecondition(struct APawn* Pawn, bool bPlanning); // Function GOAPNPC.GOAPAction.CheckProceduralPrecondition
	void BeginAction(struct APawn* Pawn); // Function GOAPNPC.GOAPAction.BeginAction
}; 



// Class GOAPNPC.GOAPComponent
// Size: 0x168(Inherited: 0xB0) 
struct UGOAPComponent : public UActorComponent
{
	struct TArray<struct FAtom> CurrentWorldInitial;  // 0xB0(0x10)
	struct TArray<struct FAtom> DesiredWorldInitial;  // 0xC0(0x10)
	UGOAPGoal* GoalInitial;  // 0xD0(0x8)
	struct TSoftObjectPtr<UGOAPGoalSet> GoalSetInitial;  // 0xD8(0x28)
	struct TArray<UGOAPAction*> ActionClasses;  // 0x100(0x10)
	int32_t MaxDepth;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)
	struct AAIController* AIOwner;  // 0x118(0x8)
	struct APawn* AIPawnOwner;  // 0x120(0x8)
	char pad_296[8];  // 0x128(0x8)
	struct UGOAPGoalManager* GoalManager;  // 0x130(0x8)
	struct TArray<struct UGOAPAction*> AuxActions;  // 0x138(0x10)
	struct TArray<struct UGOAPAction*> Plan;  // 0x148(0x10)
	char pad_344[16];  // 0x158(0x10)

	void UpdateCurrentWorld(struct TArray<struct FAtom>& Atoms); // Function GOAPNPC.GOAPComponent.UpdateCurrentWorld
	void SetGoal(struct UGOAPGoal* NewGoal); // Function GOAPNPC.GOAPComponent.SetGoal
	void SetCurrentWorld(struct TArray<struct FAtom>& NewCurrentWorld); // Function GOAPNPC.GOAPComponent.SetCurrentWorld
	void Reset(); // Function GOAPNPC.GOAPComponent.Reset
	void ReceiveOnReset(); // Function GOAPNPC.GOAPComponent.ReceiveOnReset
	bool IsPlanValid(); // Function GOAPNPC.GOAPComponent.IsPlanValid
	void InvalidatePlan(); // Function GOAPNPC.GOAPComponent.InvalidatePlan
	void InvalidateGoalSelection(); // Function GOAPNPC.GOAPComponent.InvalidateGoalSelection
	bool HasPlan(); // Function GOAPNPC.GOAPComponent.HasPlan
	struct TArray<struct UGOAPAction*> GetPlanSnapshot(); // Function GOAPNPC.GOAPComponent.GetPlanSnapshot
	struct TArray<struct FAtom> GetDesiredWorldStateAtoms(); // Function GOAPNPC.GOAPComponent.GetDesiredWorldStateAtoms
	struct TArray<struct FAtom> GetCurrentWorldStateAtoms(); // Function GOAPNPC.GOAPComponent.GetCurrentWorldStateAtoms
	bool GeneratePlan(); // Function GOAPNPC.GOAPComponent.GeneratePlan
	bool ExecuteGOAP(bool bCreatePlan, bool bRemoveActionOnComplete); // Function GOAPNPC.GOAPComponent.ExecuteGOAP
	void ClearPlan(); // Function GOAPNPC.GOAPComponent.ClearPlan
}; 



// Class GOAPNPC.GOAPGoalSet
// Size: 0x90(Inherited: 0x30) 
struct UGOAPGoalSet : public UPrimaryDataAsset
{
	struct FString Name;  // 0x30(0x10)
	struct TSet<UGOAPGoal*> Goals;  // 0x40(0x50)

}; 



// Class GOAPNPC.GOAPGoalManager
// Size: 0x60(Inherited: 0x28) 
struct UGOAPGoalManager : public UObject
{
	struct UGOAPGoalSet* GoalSet;  // 0x28(0x8)
	struct TArray<struct UGOAPGoal*> AuxGoals;  // 0x30(0x10)
	struct UGOAPGoal* CurrentGoal;  // 0x40(0x8)
	char pad_72[24];  // 0x48(0x18)

	void UpdateGoalSet(struct UGOAPGoalSet* InGoalSet); // Function GOAPNPC.GOAPGoalManager.UpdateGoalSet
	void SetGoalSet(struct UGOAPGoalSet* InGoalSet); // Function GOAPNPC.GOAPGoalManager.SetGoalSet
	void SetCurrentGoal(struct UGOAPGoal* NewGoal, bool bDeactivatePreviousGoal); // Function GOAPNPC.GOAPGoalManager.SetCurrentGoal
	void RemoveGoal(UGOAPGoal*& GoalClass); // Function GOAPNPC.GOAPGoalManager.RemoveGoal
	void InvalidatePlan(); // Function GOAPNPC.GOAPGoalManager.InvalidatePlan
	void InvalidateGoalSelection(); // Function GOAPNPC.GOAPGoalManager.InvalidateGoalSelection
	struct UGOAPComponent* GetOuterGOAPComp(); // Function GOAPNPC.GOAPGoalManager.GetOuterGOAPComp
	struct TArray<struct FAtom> GetCurrentGoalAtoms(); // Function GOAPNPC.GOAPGoalManager.GetCurrentGoalAtoms
	struct UGOAPGoal* FindGoal(UGOAPGoal*& GoalClass); // Function GOAPNPC.GOAPGoalManager.FindGoal
	void ClearGoals(); // Function GOAPNPC.GOAPGoalManager.ClearGoals
	struct UGOAPGoal* AddGoal(UGOAPGoal*& GoalClass); // Function GOAPNPC.GOAPGoalManager.AddGoal
}; 



// Class GOAPNPC.GOAPGoal
// Size: 0x68(Inherited: 0x28) 
struct UGOAPGoal : public UObject
{
	struct FString GoalName;  // 0x28(0x10)
	struct TArray<struct FAtom> DesiredWorldInitial;  // 0x38(0x10)
	char pad_72[16];  // 0x48(0x10)
	float RelevanceWeightBase;  // 0x58(0x4)
	float RelevanceWeight;  // 0x5C(0x4)
	struct AAIController* AIOwner;  // 0x60(0x8)

	bool RequiresNewPlan(); // Function GOAPNPC.GOAPGoal.RequiresNewPlan
	struct UGOAPGoalManager* GetOuterGoalManager(); // Function GOAPNPC.GOAPGoal.GetOuterGoalManager
	void GeneratePlanFailure(); // Function GOAPNPC.GOAPGoal.GeneratePlanFailure
	void Deactivate(); // Function GOAPNPC.GOAPGoal.Deactivate
	void ClearRelevance(); // Function GOAPNPC.GOAPGoal.ClearRelevance
	void CalculateRelevance(); // Function GOAPNPC.GOAPGoal.CalculateRelevance
	void Activate(); // Function GOAPNPC.GOAPGoal.Activate
}; 



// Class GOAPNPC.GOAPAIController
// Size: 0x330(Inherited: 0x328) 
struct AGOAPAIController : public AAIController
{
	struct UGOAPComponent* GOAPComponent;  // 0x328(0x8)

}; 



