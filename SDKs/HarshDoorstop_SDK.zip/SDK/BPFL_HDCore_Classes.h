#pragma once 
#include <BPFL_HDCore_Structs.h>
 
 
 
// BlueprintGeneratedClass BPFL_HDCore.BPFL_HDCore_C
// Size: 0x28(Inherited: 0x28) 
struct UBPFL_HDCore_C : public UBlueprintFunctionLibrary
{

	void CheckEntitlement(struct TArray<struct FFEntitlementDefinition>& Entitlements, struct UObject* __WorldContext, bool& bEntitled); // Function BPFL_HDCore.BPFL_HDCore_C.CheckEntitlement
	void FindMapIdByDisplayName(struct FText& MapDisplayName, struct TArray<struct FPrimaryAssetId>& MapIds, struct UObject* __WorldContext, struct FPrimaryAssetId& FoundMapId); // Function BPFL_HDCore.BPFL_HDCore_C.FindMapIdByDisplayName
	void GetPackageShortName(struct FString& LongName, struct UObject* __WorldContext, bool& bSuccess, struct FString& ShortName); // Function BPFL_HDCore.BPFL_HDCore_C.GetPackageShortName
	void GetPluginDisplayNameFromPath(struct FString& AssetPath, struct UObject* __WorldContext, struct FString& ModName); // Function BPFL_HDCore.BPFL_HDCore_C.GetPluginDisplayNameFromPath
	void GetContentRootFromPackageName(struct FString& PackageName, struct UObject* __WorldContext, bool& bSuccess, struct FString& ContentRootName); // Function BPFL_HDCore.BPFL_HDCore_C.GetContentRootFromPackageName
	void GetContentRootPathFromPackageName(struct FString& PackageName, struct UObject* __WorldContext, bool& bSuccess, struct FString& ContentRootPath); // Function BPFL_HDCore.BPFL_HDCore_C.GetContentRootPathFromPackageName
	void AddOption(struct FString& Options, struct FString& StrToAdd, struct UObject* __WorldContext); // Function BPFL_HDCore.BPFL_HDCore_C.AddOption
	void SplitLoadedPrimaryAssetClassIds(struct TArray<struct FPrimaryAssetId>& AssetIds, struct UObject* __WorldContext, struct TArray<struct FPrimaryAssetId>& UnloadedAssetIds, struct TArray<UObject*>& LoadedAssetClasses); // Function BPFL_HDCore.BPFL_HDCore_C.SplitLoadedPrimaryAssetClassIds
	void SplitLoadedPrimaryAssetIds(struct TArray<struct FPrimaryAssetId>& AssetIds, struct UObject* __WorldContext, struct TArray<struct FPrimaryAssetId>& UnloadedAssetIds, struct TArray<struct UObject*>& LoadedAssets); // Function BPFL_HDCore.BPFL_HDCore_C.SplitLoadedPrimaryAssetIds
	void GetAllMapAssets(struct UObject* __WorldContext, bool& bSuccess, struct TArray<struct FAssetData>& LevelAssets); // Function BPFL_HDCore.BPFL_HDCore_C.GetAllMapAssets
	void GetPlayerControllerFromPlayerState(struct APlayerState* PlayerState, struct UObject* __WorldContext, struct APlayerController*& OwnerPC); // Function BPFL_HDCore.BPFL_HDCore_C.GetPlayerControllerFromPlayerState
	void GetControllerFromPlayerState(struct APlayerState* PlayerState, struct UObject* __WorldContext, struct AController*& OwnerC); // Function BPFL_HDCore.BPFL_HDCore_C.GetControllerFromPlayerState
	void GetBluforOpforTeamStateForTeam(uint8_t  Team, struct UObject* __WorldContext, struct AHDTeamState*& HDTeamState); // Function BPFL_HDCore.BPFL_HDCore_C.GetBluforOpforTeamStateForTeam
	void GetHDFactionInfoForTeam(uint8_t  Team, struct UObject* __WorldContext, UBP_HDFactionInfoBase_C*& HDFactionInfoClass); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDFactionInfoForTeam
	void GetIndexForPhoneticCodeWord(struct FString CodeWord, struct UObject* __WorldContext, int32_t& LetterIdx); // Function BPFL_HDCore.BPFL_HDCore_C.GetIndexForPhoneticCodeWord
	void GetIndexForPredefinedSquadName(struct FText SquadName, struct UObject* __WorldContext, int32_t& SquadNameIdx); // Function BPFL_HDCore.BPFL_HDCore_C.GetIndexForPredefinedSquadName
	void GetPhoneticCodeWordByIndex(int32_t LetterIdx, struct UObject* __WorldContext, struct FString& CodeWord); // Function BPFL_HDCore.BPFL_HDCore_C.GetPhoneticCodeWordByIndex
	void GetPhoneticCodeWordByCharacter(struct FString LetterChar, struct UObject* __WorldContext, struct FString& CodeWord); // Function BPFL_HDCore.BPFL_HDCore_C.GetPhoneticCodeWordByCharacter
	void AbbreviateString(struct FString SourceString, int32_t MaxStartLength, int32_t MaxEndLength, struct FString Separator, struct UObject* __WorldContext, struct FString& AbbrevString); // Function BPFL_HDCore.BPFL_HDCore_C.AbbreviateString
	void GetPredefinedSquadNameByIndex(int32_t SquadCreationIdx, struct UObject* __WorldContext, struct FText& SquadName); // Function BPFL_HDCore.BPFL_HDCore_C.GetPredefinedSquadNameByIndex
	void GetHDTeamStateForTeam(uint8_t  Team, struct UObject* __WorldContext, struct AHDTeamState*& HDTeamState); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDTeamStateForTeam
	void GetHDHUDBP(int32_t PlayerIndex, struct UObject* __WorldContext, struct ABP_HDHUDBase_C*& HDHUD); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDHUDBP
	void GetHDGameUserSettings(struct UObject* __WorldContext, struct UTBGameUserSettings*& HDGameUserSettings); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameUserSettings
	void GetHDGameState(struct UObject* __WorldContext, struct AHDGameState*& HDGameState); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameState
	void GetHDGameMode(struct UObject* __WorldContext, struct AHDBaseGameMode*& HDGame); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameMode
	void GetHDGameInstance(struct UObject* __WorldContext, struct UHDGameInstance*& HDGI); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameInstance
	void GetHDPlayerCharacterBP(int32_t PlayerIndex, struct UObject* __WorldContext, struct ABP_HDPlayerCharacterBase_C*& HDPlayerChar); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDPlayerCharacterBP
	void GetHDPlayerControllerBP(int32_t PlayerIndex, struct UObject* __WorldContext, struct ABP_HDPlayerControllerBase_C*& HDPC); // Function BPFL_HDCore.BPFL_HDCore_C.GetHDPlayerControllerBP
}; 



