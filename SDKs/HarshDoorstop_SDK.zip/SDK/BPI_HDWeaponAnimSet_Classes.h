#pragma once 
#include <BPI_HDWeaponAnimSet_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_HDWeaponAnimSet_C : public UInterface
{

	void ShouldUseMirroredLowerBodyLoco(bool& bOutUseMirrored); // Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.ShouldUseMirroredLowerBodyLoco
	void GetLocoTPPAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.GetLocoTPPAnimSet
	void GetLocoAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.GetLocoAnimSet
}; 



