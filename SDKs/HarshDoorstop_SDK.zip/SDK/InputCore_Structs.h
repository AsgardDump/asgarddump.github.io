#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct InputCore.Key
// Size: 0x18(Inherited: 0x0) 
struct FKey
{
	struct FName KeyName;  // 0x0(0x8)
	char pad_8[16];  // 0x8(0x10)

}; 
