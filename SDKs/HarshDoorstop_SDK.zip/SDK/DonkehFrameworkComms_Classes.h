#pragma once 
#include <DonkehFrameworkComms_Structs.h>
 
 
 
// Class DonkehFrameworkComms.CreateCommChannelCallbackProxy
// Size: 0x88(Inherited: 0x30) 
struct UCreateCommChannelCallbackProxy : public UBlueprintAsyncActionBase
{
	struct FMulticastInlineDelegate OnPerformSetup;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnSuccess;  // 0x40(0x10)
	struct FMulticastInlineDelegate OnFailure;  // 0x50(0x10)
	struct APlayerController* CreateChannelOwnerPC;  // 0x60(0x8)
	struct UDFCommChannelDefinition* CreateChannelDef;  // 0x68(0x8)
	char pad_112[24];  // 0x70(0x18)

	struct UCreateCommChannelCallbackProxy* CreateCommChannelFor(struct APlayerController* Player, struct UDFCommChannelDefinition* ChannelDef, struct FName ChannelNameOverride); // Function DonkehFrameworkComms.CreateCommChannelCallbackProxy.CreateCommChannelFor
}; 



// Class DonkehFrameworkComms.DFCommChannelDefinition
// Size: 0xB8(Inherited: 0x30) 
struct UDFCommChannelDefinition : public UDataAsset
{
	struct FName ChannelName;  // 0x30(0x8)
	struct FText ChannelDisplayName;  // 0x38(0x18)
	char bInstanceChannelWithGroup : 1;  // 0x50(0x1)
	char pad_80_1 : 7;  // 0x50(0x1)
	char pad_81[4];  // 0x51(0x4)
	struct FName ChannelGroupName;  // 0x54(0x8)
	char pad_92[4];  // 0x5C(0x4)
	UObject* ChannelStateClass;  // 0x60(0x8)
	struct TMap<UDFCommsFormatBase*, uint8_t > FormatAccessRules;  // 0x68(0x50)

	bool InstancesChannelWithGroup(); // Function DonkehFrameworkComms.DFCommChannelDefinition.InstancesChannelWithGroup
}; 



// Class DonkehFrameworkComms.DFTextCommsFormat
// Size: 0xE0(Inherited: 0xD0) 
struct UDFTextCommsFormat : public UDFCommsFormatBase
{
	struct FMulticastInlineDelegate OnChatMsgReceived;  // 0xD0(0x10)

}; 



// Class DonkehFrameworkComms.DFCommChannel
// Size: 0x90(Inherited: 0x28) 
struct UDFCommChannel : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	char bChannelPreInitialized : 1;  // 0x30(0x1)
	char bChannelClosed : 1;  // 0x30(0x1)
	char bCompletedSetup : 1;  // 0x30(0x1)
	char pad_48_1 : 5;  // 0x30(0x1)
	char pad_49[4];  // 0x31(0x4)
	struct FName ChannelName;  // 0x34(0x8)
	char pad_60[4];  // 0x3C(0x4)
	struct UDFCommChannelDefinition* ChannelDefinition;  // 0x40(0x8)
	struct UObject* ChannelState;  // 0x48(0x8)
	struct TArray<struct UDFCommsFormatBase*> AssociatedCommsFormats;  // 0x50(0x10)
	char pad_96[48];  // 0x60(0x30)

	void SetChannelState(struct UObject* NewChannelState); // Function DonkehFrameworkComms.DFCommChannel.SetChannelState
	bool IsReady(); // Function DonkehFrameworkComms.DFCommChannel.IsReady
	bool HasFormat(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFCommChannel.HasFormat
	struct FString GetChannelNameStr(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelNameStr
	struct FName GetChannelName(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelName
	struct FName GetChannelGroupNameIfValid(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelGroupNameIfValid
	struct FText GetChannelDisplayName(); // Function DonkehFrameworkComms.DFCommChannel.GetChannelDisplayName
}; 



// Class DonkehFrameworkComms.DFCommDeveloperSettings
// Size: 0xF0(Inherited: 0x38) 
struct UDFCommDeveloperSettings : public UDeveloperSettings
{
	struct FSoftClassPath PlayerCommsCompClass;  // 0x38(0x18)
	struct TSet<struct FDFCommsFormatEntry> CommsFormatDefinitions;  // 0x50(0x50)
	struct TSet<struct FDFCommChannelEntry> CommChannelDefinitions;  // 0xA0(0x50)

}; 



// Class DonkehFrameworkComms.DFCommChannelStateInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFCommChannelStateInterface : public UInterface
{

	void BP_OnSetupState(struct FDFCommStateSetupParams& SetupParams); // Function DonkehFrameworkComms.DFCommChannelStateInterface.BP_OnSetupState
}; 



// Class DonkehFrameworkComms.DFCommStatics
// Size: 0x28(Inherited: 0x28) 
struct UDFCommStatics : public UBlueprintFunctionLibrary
{

	void UpdateExclusiveChannelForFormatByName(struct APlayerController* Player, struct FName FormatNameToUpdate, struct FName SingleChannelNameToUse); // Function DonkehFrameworkComms.DFCommStatics.UpdateExclusiveChannelForFormatByName
	void UpdateExclusiveChannelForFormat(struct APlayerController* Player, struct UDFCommsFormatBase* FormatToUpdate, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFCommStatics.UpdateExclusiveChannelForFormat
	void SendCommsViaChannelByName(struct APlayerController* PlayerSender, struct FName FormatName, struct FName ReceivingChannelName, struct FDFGenericChannelMsg& MsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFCommStatics.SendCommsViaChannelByName
	void SendCommsViaChannel(struct APlayerController* PlayerSender, struct UDFCommsFormatBase* FormatToUse, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg& MsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFCommStatics.SendCommsViaChannel
	bool PlayerHasCommChannelByName(struct APlayerController* Player, struct FName ChannelName); // Function DonkehFrameworkComms.DFCommStatics.PlayerHasCommChannelByName
	bool PlayerHasCommChannel(struct APlayerController* Player, struct UDFCommChannel* Channel); // Function DonkehFrameworkComms.DFCommStatics.PlayerHasCommChannel
	bool FindCommsComponentByPlayer(struct APlayerController* Player, struct UDFPlayerCommsComponent*& OutPlayerCommsComp); // Function DonkehFrameworkComms.DFCommStatics.FindCommsComponentByPlayer
	bool CommsFormatUsesChannelByName(struct APlayerController* Player, struct FName FormatName, struct FName ChannelNameToCheck); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatUsesChannelByName
	bool CommsFormatUsesChannel(struct APlayerController* Player, struct UDFCommsFormatBase* Format, struct UDFCommChannel* ChannelToCheck); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatUsesChannel
	bool CommsFormatHasExclusiveChannelByName(struct APlayerController* PlayerFormatOwner, struct FName FormatName); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatHasExclusiveChannelByName
	bool CommsFormatHasExclusiveChannel(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatHasExclusiveChannel
	struct UDFCommChannel* CommsFormatGetExclusiveChannelByName(struct APlayerController* PlayerFormatOwner, struct FName FormatName); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatGetExclusiveChannelByName
	struct UDFCommChannel* CommsFormatGetExclusiveChannel(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFCommStatics.CommsFormatGetExclusiveChannel
	void ClearCurrentExclusiveChannelForFormatByName(struct APlayerController* Player, struct FName FormatNameToUpdate); // Function DonkehFrameworkComms.DFCommStatics.ClearCurrentExclusiveChannelForFormatByName
	void ClearCurrentExclusiveChannelForFormat(struct APlayerController* Player, struct UDFCommsFormatBase* FormatToUpdate); // Function DonkehFrameworkComms.DFCommStatics.ClearCurrentExclusiveChannelForFormat
}; 



// Class DonkehFrameworkComms.DFCommChannelStateLibrary
// Size: 0x28(Inherited: 0x28) 
struct UDFCommChannelStateLibrary : public UBlueprintFunctionLibrary
{

	void NotifyChannelOfPreparedState(struct TScriptInterface<IDFCommChannelStateInterface> ChannelState); // Function DonkehFrameworkComms.DFCommChannelStateLibrary.NotifyChannelOfPreparedState
	bool IsChannelStatePrepared(struct TScriptInterface<IDFCommChannelStateInterface> ChannelState); // Function DonkehFrameworkComms.DFCommChannelStateLibrary.IsChannelStatePrepared
	struct UDFCommChannel* GetOwningCommChannel(struct TScriptInterface<IDFCommChannelStateInterface> ChannelState); // Function DonkehFrameworkComms.DFCommChannelStateLibrary.GetOwningCommChannel
}; 



// Class DonkehFrameworkComms.DFCommsFormatBase
// Size: 0xD0(Inherited: 0x28) 
struct UDFCommsFormatBase : public UObject
{
	char bSingleChannelUsageOnly : 1;  // 0x28(0x1)
	char bRequiresValidSingleChannelAssignment : 1;  // 0x28(0x1)
	char pad_40_1 : 6;  // 0x28(0x1)
	char pad_41[24];  // 0x29(0x18)
	struct FDFGenericChannelMsg LastReceivedCommMsg;  // 0x40(0x38)
	char pad_120[80];  // 0x78(0x50)
	struct FName FormatName;  // 0xC8(0x8)

	bool HasAccessToChannel(struct FName ChannelName, uint8_t  AccessRulesToCheck); // Function DonkehFrameworkComms.DFCommsFormatBase.HasAccessToChannel
	bool CanWriteToChannel(struct FName ChannelName); // Function DonkehFrameworkComms.DFCommsFormatBase.CanWriteToChannel
	bool CanReadFromChannel(struct FName ChannelName); // Function DonkehFrameworkComms.DFCommsFormatBase.CanReadFromChannel
}; 



// Class DonkehFrameworkComms.DFCommWorldSubsystem
// Size: 0x30(Inherited: 0x30) 
struct UDFCommWorldSubsystem : public UWorldSubsystem
{

	void PostSeamlessTravelPCDestroyed(struct AActor* DestroyedPlayerActor); // Function DonkehFrameworkComms.DFCommWorldSubsystem.PostSeamlessTravelPCDestroyed
	struct UDFPlayerCommsComponent* InitPlayerComms(struct APlayerController* Player); // Function DonkehFrameworkComms.DFCommWorldSubsystem.InitPlayerComms
	void GameModePostLogin(struct AGameModeBase* GameMode, struct APlayerController* NewPlayer); // Function DonkehFrameworkComms.DFCommWorldSubsystem.GameModePostLogin
}; 



// Class DonkehFrameworkComms.DFPlayerCommsComponent
// Size: 0x3AB0(Inherited: 0xB0) 
struct UDFPlayerCommsComponent : public UActorComponent
{
	struct TMap<struct FName, struct UDFCommsFormatBase*> CommsFormats;  // 0xB0(0x50)
	struct FDFCommChannelMap OpenCommChannels;  // 0x100(0x170)
	struct FDFChannelMsgRecord MsgSendBuffer[64];  // 0x270(0x1C20)
	struct FDFChannelMsgRecord MsgRecvBuffer[64];  // 0x1E90(0x1C20)

	void UpdateExclusiveChannelToUseForCommsFormatByName(struct FName& FormatName, struct FName& SingleChannelNameToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.UpdateExclusiveChannelToUseForCommsFormatByName
	void UpdateExclusiveChannelToUseForCommsFormat(struct UDFCommsFormatBase* Format, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.UpdateExclusiveChannelToUseForCommsFormat
	void ServerVerifyCommMsg(int32_t VerifyMsgID); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerVerifyCommMsg
	void ServerUpdateExclusiveChannelToUseForCommsFormat(struct FName FormatName, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerUpdateExclusiveChannelToUseForCommsFormat
	void ServerSendCommMsgViaExclChannel(struct FName FormatName, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg CommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerSendCommMsgViaExclChannel
	void ServerSendCommMsgViaChannel(struct FName FormatName, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg CommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerSendCommMsgViaChannel
	void ServerRequestExclusiveChannelUsedForCommsFormat(struct FName RequestedFormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerRequestExclusiveChannelUsedForCommsFormat
	void ServerClearCurrentExclusiveChannelForCommsFormat(struct FName FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerClearCurrentExclusiveChannelForCommsFormat
	void SendCommMsgViaChannelByName(struct FName& FormatName, struct FName& ReceivingChannelName, struct FDFGenericChannelMsg& CommMsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.SendCommMsgViaChannelByName
	void SendCommMsgViaChannel(struct UDFCommsFormatBase* FormatToUse, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg& CommMsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.SendCommMsgViaChannel
	void RemoveCommChannelByName(struct FName ChannelNameToRemove); // Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveCommChannelByName
	void RemoveCommChannel(struct UDFCommChannel* ChannelToRemove); // Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveCommChannel
	void RemoveAllCommChannels(); // Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveAllCommChannels
	void ReceiveCommChannelPreRemoved(struct UDFCommChannel* RemovedChannel); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ReceiveCommChannelPreRemoved
	void ReceiveCommChannelAdded(struct UDFCommChannel* AddedChannel); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ReceiveCommChannelAdded
	bool FormatUsesChannelByName(struct FName& FormatName, struct FName& ChannelNameToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatUsesChannelByName
	bool FormatUsesChannel(struct UDFCommsFormatBase* Format, struct UDFCommChannel* ChannelToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatUsesChannel
	bool FormatHasExclusiveChannelByName(struct FName& FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatHasExclusiveChannelByName
	bool FormatHasExclusiveChannel(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatHasExclusiveChannel
	bool FindCommChannel(struct FName ChannelName, struct UDFCommChannel*& OutChannelFound); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FindCommChannel
	bool FindAssociatedCommsFormat(struct FName FormatName, struct UDFCommsFormatBase*& OutFormatFound); // Function DonkehFrameworkComms.DFPlayerCommsComponent.FindAssociatedCommsFormat
	bool ContainsCommChannelByName(struct FName ChannelNameToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsCommChannelByName
	bool ContainsCommChannel(struct UDFCommChannel* ChannelToCheck); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsCommChannel
	bool ContainsAssociatedCommsFormat(struct FName FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsAssociatedCommsFormat
	void ClientVerifyCommMsgFailed(int32_t VerifyMsgID); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientVerifyCommMsgFailed
	void ClientUpdateExclusiveChannelToUseForCommsFormat(struct FName FormatName, struct UDFCommChannel* SingleChannelToUse); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientUpdateExclusiveChannelToUseForCommsFormat
	void ClientRecvCommMsgFromChannel(struct FName SourceFormatName, struct UDFCommChannel* SourceChannel, struct FDFGenericChannelMsg ReceivedCommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientRecvCommMsgFromChannel
	void ClientClearCurrentExclusiveChannelForCommsFormat(struct FName FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientClearCurrentExclusiveChannelForCommsFormat
	void ClearCurrentExclusiveChannelForCommsFormatByName(struct FName& FormatName); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClearCurrentExclusiveChannelForCommsFormatByName
	void ClearCurrentExclusiveChannelForCommsFormat(struct UDFCommsFormatBase* Format); // Function DonkehFrameworkComms.DFPlayerCommsComponent.ClearCurrentExclusiveChannelForCommsFormat
	bool CanSendCommMsgViaChannel(struct UDFCommsFormatBase* ReceivingFormat, struct UDFCommChannel* ReceivingChannel, struct FDFGenericChannelMsg& CommMsgToSend, bool bUseChannelAsNewExclusive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.CanSendCommMsgViaChannel
	bool CanSendAndRecvCommMsgViaChannel(struct FName& FormatName, struct FName& ChannelName, struct FDFGenericChannelMsg& CommMsg); // Function DonkehFrameworkComms.DFPlayerCommsComponent.CanSendAndRecvCommMsgViaChannel
	bool CanRecvCommMsgViaChannel(struct FName& SourceFormatName, struct FName& SourceChannelName, struct FDFGenericChannelMsg& CommMsgToReceive); // Function DonkehFrameworkComms.DFPlayerCommsComponent.CanRecvCommMsgViaChannel
}; 



// Class DonkehFrameworkComms.DFVOIPCommStatics
// Size: 0x28(Inherited: 0x28) 
struct UDFVOIPCommStatics : public UBlueprintFunctionLibrary
{

	bool WasPlayerTalking(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.WasPlayerTalking
	bool IsPlayerTalkingOverChannel(struct APlayerState* PlayerState, struct UDFCommChannel* TalkChannel); // Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalkingOverChannel
	bool IsPlayerTalking(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalking
	bool IsPlayerTalkerPendingReset(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalkerPendingReset
	struct UVoipListenerSynthComponent* GetVoiceSynthOwnerOfAudioComponent(struct UAudioComponent* TalkerAudioComp); // Function DonkehFrameworkComms.DFVOIPCommStatics.GetVoiceSynthOwnerOfAudioComponent
	struct UVoipListenerSynthComponent* GetVoiceSynthComponentForVOIPTalker(struct UVOIPTalker* Talker); // Function DonkehFrameworkComms.DFVOIPCommStatics.GetVoiceSynthComponentForVOIPTalker
	struct FDFPlayerVOIPTalkingState GetValidVoiceEntryForPlayer(struct APlayerState* PlayerState); // Function DonkehFrameworkComms.DFVOIPCommStatics.GetValidVoiceEntryForPlayer
	void ApplyVOIPTalkerSettingsForPlayer(struct APlayerState* TalkerPlayerState, char ListenerLocalUserNum); // Function DonkehFrameworkComms.DFVOIPCommStatics.ApplyVOIPTalkerSettingsForPlayer
}; 



// Class DonkehFrameworkComms.DFVOIPCommsFormat
// Size: 0x100(Inherited: 0xD0) 
struct UDFVOIPCommsFormat : public UDFCommsFormatBase
{
	struct FMulticastInlineDelegate OnPlayerTalkingStateChangedOnChannel;  // 0xD0(0x10)
	char pad_224[32];  // 0xE0(0x20)

	void OnTalkerPSDestroyed(struct AActor* DestroyedPS); // Function DonkehFrameworkComms.DFVOIPCommsFormat.OnTalkerPSDestroyed
}; 



