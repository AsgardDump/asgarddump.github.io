#pragma once 
#include "SDK.h" 
 
 
// Function BPI_RadialInput.BPI_RadialInput_C.GetJoystickDirection
// Size: 0xC(Inherited: 0x0) 
struct FGetJoystickDirection
{
	char EJoystickTypes Stick;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector2D StickInput;  // 0x4(0x8)

}; 
