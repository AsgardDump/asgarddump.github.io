#pragma once 
#include <FEqpSlotData_Structs.h>
 
 
 
