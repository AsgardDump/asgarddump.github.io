#pragma once 
#include <WBP_JoinServerFiltersPanel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C
// Size: 0x260(Inherited: 0x230) 
struct UWBP_JoinServerFiltersPanel_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_ServerListModifierSettings_AdvancedFilters_C* AdvancedFilterSettings;  // 0x238(0x8)
	struct UWBP_ServerListModifierSettings_BasicFilters_C* BasicFilterSettings;  // 0x240(0x8)
	struct UVerticalBox* FiltersVBox;  // 0x248(0x8)
	struct FMulticastInlineDelegate OnServerFiltersChanged;  // 0x250(0x10)

	void GetFilterRules(bool bActiveOnly, struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams>& FilterRules); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.GetFilterRules
	void OnInitialized(); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.OnInitialized
	void FilterSettingsChanged(struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.FilterSettingsChanged
	void ExecuteUbergraph_WBP_JoinServerFiltersPanel(int32_t EntryPoint); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.ExecuteUbergraph_WBP_JoinServerFiltersPanel
	void OnServerFiltersChanged__DelegateSignature(struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters); // Function WBP_JoinServerFiltersPanel.WBP_JoinServerFiltersPanel_C.OnServerFiltersChanged__DelegateSignature
}; 



