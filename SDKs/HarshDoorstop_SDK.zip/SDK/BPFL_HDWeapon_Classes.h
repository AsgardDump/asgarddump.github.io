#pragma once 
#include <BPFL_HDWeapon_Structs.h>
 
 
 
// BlueprintGeneratedClass BPFL_HDWeapon.BPFL_HDWeapon_C
// Size: 0x28(Inherited: 0x28) 
struct UBPFL_HDWeapon_C : public UBlueprintFunctionLibrary
{

	void AimStyleToDisplayText(uint8_t  AimStyle, struct UObject* __WorldContext, struct FText& StyleText); // Function BPFL_HDWeapon.BPFL_HDWeapon_C.AimStyleToDisplayText
	void FireModeToDisplayText(uint8_t  FireMode, struct UObject* __WorldContext, struct FText& ModeText); // Function BPFL_HDWeapon.BPFL_HDWeapon_C.FireModeToDisplayText
	void FireModeToString(uint8_t  FireMode, struct UObject* __WorldContext, struct FString& ModeString); // Function BPFL_HDWeapon.BPFL_HDWeapon_C.FireModeToString
}; 



