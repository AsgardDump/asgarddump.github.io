#pragma once 
#include "SDK.h" 
 
 
// Function VehicleAnimationBlueprint.VehicleAnimationBlueprint_C.ExecuteUbergraph_VehicleAnimationBlueprint
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_VehicleAnimationBlueprint
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function VehicleAnimationBlueprint.VehicleAnimationBlueprint_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
