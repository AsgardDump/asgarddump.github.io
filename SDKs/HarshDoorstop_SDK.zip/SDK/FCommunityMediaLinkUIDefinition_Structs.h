#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FCommunityMediaLinkUIDefinition.FCommunityMediaLinkUIDefinition
// Size: 0xC0(Inherited: 0x0) 
struct FFCommunityMediaLinkUIDefinition
{
	struct FString WebURL_10_B0B8D2E845186B9EBA7D3D9AB4977679;  // 0x0(0x10)
	struct FText Label_2_C9F6D86045D38E44BD06299F84FE78CC;  // 0x10(0x18)
	struct FSlateBrush Icon_5_C498661E4A5CAC2BA18263AF12394AF5;  // 0x28(0x88)
	struct FMargin Padding_14_F77BEB464BD9B2414E644FBC7B03FA31;  // 0xB0(0x10)

}; 
