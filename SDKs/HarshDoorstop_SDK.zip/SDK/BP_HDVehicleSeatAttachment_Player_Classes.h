#pragma once 
#include <BP_HDVehicleSeatAttachment_Player_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDVehicleSeatAttachment_Player.BP_HDVehicleSeatAttachment_Player_C
// Size: 0xE1(Inherited: 0xD8) 
struct UBP_HDVehicleSeatAttachment_Player_C : public UArcVehicleSeatConfig_PlayerAttachment
{
	UAnimInstance* SeatAnimInstanceLinked;  // 0xD8(0x8)
	uint8_t  SeatItemMode;  // 0xE0(0x1)

}; 



