#pragma once 
#include <WBP_MobilityStatusBar_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_MobilityStatusBar.WBP_MobilityStatusBar_C
// Size: 0x250(Inherited: 0x230) 
struct UWBP_MobilityStatusBar_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWidgetAnimation* PingUIAnim;  // 0x238(0x8)
	struct UProgressBar* StatusBar;  // 0x240(0x8)
	struct UImage* StatusPingImg;  // 0x248(0x8)

	void SetPercent(float InPercent, bool bInitial); // Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.SetPercent
	void PingValueFull(); // Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.PingValueFull
	void ExecuteUbergraph_WBP_MobilityStatusBar(int32_t EntryPoint); // Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.ExecuteUbergraph_WBP_MobilityStatusBar
}; 



