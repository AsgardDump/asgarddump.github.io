#pragma once 
#include "SDK.h" 
 
 
// Function BP_ContextWidgetPrereq_ExcludeSquadLeader.BP_ContextWidgetPrereq_ExcludeSquadLeader_C.SetupContext
// Size: 0x11(Inherited: 0x0) 
struct FSetupContext
{
	struct AHDSquadState* InMemberSQState;  // 0x0(0x8)
	struct AHDPlayerState* InMemberPSToTest;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValidContext_bValidData : 1;  // 0x10(0x1)

}; 
// Function BP_ContextWidgetPrereq_ExcludeSquadLeader.BP_ContextWidgetPrereq_ExcludeSquadLeader_C.IsValidContext
// Size: 0x4(Inherited: 0x0) 
struct FIsValidContext
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidData : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_ContextWidgetPrereq_ExcludeSquadLeader.BP_ContextWidgetPrereq_ExcludeSquadLeader_C.SatisfiesPrerequisite
// Size: 0x6(Inherited: 0x1) 
struct FSatisfiesPrerequisite : public FSatisfiesPrerequisite
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValidContext_bValidData : 1;  // 0x1(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x4(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x5(0x1)

}; 
