#pragma once 
#include "SDK.h" 
 
 
// Function MagicLeapARPin.MagicLeapARPinComponent.GetPinnedPinID
// Size: 0x14(Inherited: 0x0) 
struct FGetPinnedPinID
{
	struct FGuid PinID;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.BindToOnMagicLeapARPinUpdatedDelegate
// Size: 0x10(Inherited: 0x0) 
struct FBindToOnMagicLeapARPinUpdatedDelegate
{
	struct FDelegate Delegate;  // 0x0(0x10)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinActor
// Size: 0x10(Inherited: 0x0) 
struct FPinActor
{
	struct AActor* ActorToPin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapARPinUpdatedDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FMagicLeapARPinUpdatedDelegate__DelegateSignature
{
	struct TArray<struct FGuid> Added;  // 0x0(0x10)
	struct TArray<struct FGuid> Updated;  // 0x10(0x10)
	struct TArray<struct FGuid> Deleted;  // 0x20(0x10)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinStateToString
// Size: 0x20(Inherited: 0x0) 
struct FGetARPinStateToString
{
	struct FMagicLeapARPinState State;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapARPinUpdatedMultiDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FMagicLeapARPinUpdatedMultiDelegate__DelegateSignature
{
	struct TArray<struct FGuid> Added;  // 0x0(0x10)
	struct TArray<struct FGuid> Updated;  // 0x10(0x10)
	struct TArray<struct FGuid> Deleted;  // 0x20(0x10)

}; 
// DelegateFunction MagicLeapARPin.MagicLeapARPinComponent.PersistentEntityPinned__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FPersistentEntityPinned__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRestoredOrSynced : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.GetPinData
// Size: 0x10(Inherited: 0x0) 
struct FGetPinData
{
	UMagicLeapARPinSaveGame* PinDataClass;  // 0x0(0x8)
	struct UMagicLeapARPinSaveGame* ReturnValue;  // 0x8(0x8)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetNumAvailableARPins
// Size: 0x8(Inherited: 0x0) 
struct FGetNumAvailableARPins
{
	int32_t Count;  // 0x0(0x4)
	uint8_t  ReturnValue;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.GetPinState
// Size: 0x14(Inherited: 0x0) 
struct FGetPinState
{
	struct FMagicLeapARPinState State;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// ScriptStruct MagicLeapARPin.MagicLeapARPinState
// Size: 0x10(Inherited: 0x0) 
struct FMagicLeapARPinState
{
	float Confidence;  // 0x0(0x4)
	float ValidRadius;  // 0x4(0x4)
	float RotationError;  // 0x8(0x4)
	float TranslationError;  // 0xC(0x4)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.IsPinned
// Size: 0x1(Inherited: 0x0) 
struct FIsPinned
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinRestoredOrSynced
// Size: 0x1(Inherited: 0x0) 
struct FPinRestoredOrSynced
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinComponent.PinSceneComponent
// Size: 0x10(Inherited: 0x0) 
struct FPinSceneComponent
{
	struct USceneComponent* ComponentToPin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.CreateTracker
// Size: 0x1(Inherited: 0x0) 
struct FCreateTracker
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.DestroyTracker
// Size: 0x1(Inherited: 0x0) 
struct FDestroyTracker
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinPositionAndOrientation
// Size: 0x2C(Inherited: 0x0) 
struct FGetARPinPositionAndOrientation
{
	struct FGuid PinID;  // 0x0(0x10)
	struct FVector Position;  // 0x10(0xC)
	struct FRotator Orientation;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool PinFoundInEnvironment : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinPositionAndOrientation_TrackingSpace
// Size: 0x2C(Inherited: 0x0) 
struct FGetARPinPositionAndOrientation_TrackingSpace
{
	struct FGuid PinID;  // 0x0(0x10)
	struct FVector Position;  // 0x10(0xC)
	struct FRotator Orientation;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool PinFoundInEnvironment : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetARPinState
// Size: 0x24(Inherited: 0x0) 
struct FGetARPinState
{
	struct FGuid PinID;  // 0x0(0x10)
	struct FMagicLeapARPinState State;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetAvailableARPins
// Size: 0x20(Inherited: 0x0) 
struct FGetAvailableARPins
{
	int32_t NumRequested;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FGuid> Pins;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.GetClosestARPin
// Size: 0x20(Inherited: 0x0) 
struct FGetClosestARPin
{
	struct FVector SearchPoint;  // 0x0(0xC)
	struct FGuid PinID;  // 0xC(0x10)
	uint8_t  ReturnValue;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.IsTrackerValid
// Size: 0x1(Inherited: 0x0) 
struct FIsTrackerValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapARPin.MagicLeapARPinFunctionLibrary.UnBindToOnMagicLeapARPinUpdatedDelegate
// Size: 0x10(Inherited: 0x0) 
struct FUnBindToOnMagicLeapARPinUpdatedDelegate
{
	struct FDelegate Delegate;  // 0x0(0x10)

}; 
