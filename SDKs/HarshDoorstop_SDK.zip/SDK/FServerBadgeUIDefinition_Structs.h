#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FServerBadgeUIDefinition.FServerBadgeUIDefinition
// Size: 0x94(Inherited: 0x0) 
struct FFServerBadgeUIDefinition
{
	char EServerBadgeType Type_11_EDB490C54973A52E253141B62C748510;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FSlateBrush Icon_3_FCCFEB524CD1FF61B4B6B8AB1739316E;  // 0x8(0x88)
	int32_t OrderingIdx_8_900B3535409A63FA032C5D866D3A48AF;  // 0x90(0x4)

}; 
