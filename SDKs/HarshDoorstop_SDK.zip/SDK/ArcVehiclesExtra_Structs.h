#pragma once 
#include "SDK.h" 
 
 
// Function ArcVehiclesExtra.ArcVehicleSpawner.OnVehicleDestroyed
// Size: 0x8(Inherited: 0x0) 
struct FOnVehicleDestroyed
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
