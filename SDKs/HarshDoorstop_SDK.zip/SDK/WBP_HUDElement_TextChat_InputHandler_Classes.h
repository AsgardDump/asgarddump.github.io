#pragma once 
#include <WBP_HUDElement_TextChat_InputHandler_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C
// Size: 0x270(Inherited: 0x240) 
struct UWBP_HUDElement_TextChat_InputHandler_C : public UHDTextChatInputWidgetBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x240(0x8)
	struct UTextBlock* ChannelNameText;  // 0x248(0x8)
	struct UEditableTextBox* MsgInputTextBox;  // 0x250(0x8)
	struct UDFCommChannel* CurrentChannel;  // 0x258(0x8)
	struct FMulticastInlineDelegate OnInputTextCommitted;  // 0x260(0x10)

	void StartTalking(struct UDFCommChannel* NewTalkChannel); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.StartTalking
	void StopTalking(struct UDFCommChannel* CurrentChannel); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.StopTalking
	void InputTextEntered(struct FText Text); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.InputTextEntered
	void BndEvt__MsgInputTextBox_K2Node_ComponentBoundEvent_1_OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, char ETextCommit CommitMethod); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.BndEvt__MsgInputTextBox_K2Node_ComponentBoundEvent_1_OnEditableTextBoxCommittedEvent__DelegateSignature
	void ExecuteUbergraph_WBP_HUDElement_TextChat_InputHandler(int32_t EntryPoint); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.ExecuteUbergraph_WBP_HUDElement_TextChat_InputHandler
	void OnInputTextCommitted__DelegateSignature(struct FText Text, char ETextCommit CommitMethod); // Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.OnInputTextCommitted__DelegateSignature
}; 



