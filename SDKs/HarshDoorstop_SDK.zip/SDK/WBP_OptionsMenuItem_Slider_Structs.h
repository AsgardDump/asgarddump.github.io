#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.ValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FValueChanged__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.ExecuteUbergraph_WBP_OptionsMenuItem_Slider
// Size: 0x30(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionsMenuItem_Slider
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x4(0x4)
	float K2Node_ComponentBoundEvent_Value;  // 0x8(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_GetValue_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UHorizontalBoxSlot* CallFunc_SlotAsHorizontalBoxSlot_ReturnValue;  // 0x20(0x8)
	struct UHorizontalBoxSlot* CallFunc_SlotAsHorizontalBoxSlot_ReturnValue_2;  // 0x28(0x8)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.IsLocked
// Size: 0x1(Inherited: 0x0) 
struct FIsLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOutLocked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.BndEvt__OptionSlider_K2Node_ComponentBoundEvent_0_OnFloatValueChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__OptionSlider_K2Node_ComponentBoundEvent_0_OnFloatValueChangedEvent__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.GetValue
// Size: 0x8(Inherited: 0x0) 
struct FGetValue
{
	float Value;  // 0x0(0x4)
	float CallFunc_GetValue_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValue
// Size: 0x4(Inherited: 0x0) 
struct FSetValue
{
	float InValue;  // 0x0(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetLocked
// Size: 0x1(Inherited: 0x0) 
struct FSetLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInLocked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetNormalizedValue
// Size: 0x8(Inherited: 0x0) 
struct FSetNormalizedValue
{
	float InNormValue;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueStepSize
// Size: 0x4(Inherited: 0x0) 
struct FSetValueStepSize
{
	float NewStepSize;  // 0x0(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.GetNormalizedValue
// Size: 0x8(Inherited: 0x0) 
struct FGetNormalizedValue
{
	float ValueNormalized;  // 0x0(0x4)
	float CallFunc_GetNormalizedValue_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.UpdateSliderText
// Size: 0x158(Inherited: 0x0) 
struct FUpdateSliderText
{
	float NewValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x48(0x40)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x88(0x18)
	struct FText CallFunc_Map_Find_Value;  // 0xA0(0x18)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0xC0(0x18)
	struct FText K2Node_Select_Default;  // 0xD8(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0xF0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x130(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x140(0x18)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetMouseUsesStep
// Size: 0x1(Inherited: 0x0) 
struct FSetMouseUsesStep
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInMouseUsesStep : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueMin
// Size: 0x8(Inherited: 0x0) 
struct FSetValueMin
{
	float NewMin;  // 0x0(0x4)
	float CallFunc_FMin_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueMax
// Size: 0x8(Inherited: 0x0) 
struct FSetValueMax
{
	float NewMax;  // 0x0(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.DoesMouseUseStep
// Size: 0x1(Inherited: 0x0) 
struct FDoesMouseUseStep
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOutMouseUsesStep : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueInternal
// Size: 0x18(Inherited: 0x0) 
struct FSetValueInternal
{
	float InValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bDirectSet : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Temp_bool_Variable : 1;  // 0x7(0x1)
	float CallFunc_GridSnap_Float_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	float K2Node_Select_Default;  // 0x10(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x14(0x4)

}; 
