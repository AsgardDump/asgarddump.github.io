#pragma once 
#include <ABPI_VehicleAnimLayer_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABPI_VehicleAnimLayer.ABPI_VehicleAnimLayer_C
// Size: 0x28(Inherited: 0x28) 
struct UABPI_VehicleAnimLayer_C : public UAnimLayerInterface
{

	void VehicleFullBody(struct FPoseLink FullBody, struct FPoseLink& VehicleFullBody); // Function ABPI_VehicleAnimLayer.ABPI_VehicleAnimLayer_C.VehicleFullBody
	void VehicleLowerBody(struct FPoseLink LowerBody, struct FPoseLink& VehicleLowerBody); // Function ABPI_VehicleAnimLayer.ABPI_VehicleAnimLayer_C.VehicleLowerBody
}; 



