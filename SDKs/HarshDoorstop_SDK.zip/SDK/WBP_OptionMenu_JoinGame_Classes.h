#pragma once 
#include <WBP_OptionMenu_JoinGame_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C
// Size: 0x329(Inherited: 0x280) 
struct UWBP_OptionMenu_JoinGame_C : public UHDJoinGameMenu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UWBP_JoinServerDetailsPanel_C* DetailsPanel;  // 0x288(0x8)
	struct UButton* FiltersOpenCloseBtn;  // 0x290(0x8)
	struct UWBP_JoinServerFiltersPanel_C* FiltersPanel;  // 0x298(0x8)
	struct USizeBox* FiltersPanelOpenCloseBox;  // 0x2A0(0x8)
	struct UWBP_JoinServer_Header_C* GameModeHeader;  // 0x2A8(0x8)
	struct UWBP_JoinServer_Header_C* MapHeader;  // 0x2B0(0x8)
	struct UWBP_JoinServer_Header_C* ModHeader;  // 0x2B8(0x8)
	struct UWBP_JoinServer_Header_C* PingHeader;  // 0x2C0(0x8)
	struct UWBP_JoinServer_Header_C* PlayersHeader;  // 0x2C8(0x8)
	struct UButton* RefreshListBtn;  // 0x2D0(0x8)
	struct UCircularThrobber* RefreshListThrobber;  // 0x2D8(0x8)
	struct UWBP_ServerDetails_C* ServerDetails;  // 0x2E0(0x8)
	struct UBorder* ServerDetailsContainer;  // 0x2E8(0x8)
	struct USizeBox* ServerListBox;  // 0x2F0(0x8)
	struct UWBP_JoinServer_Header_C* ServerNameHeader;  // 0x2F8(0x8)
	struct UHDServerListItemData* SelectedServerListItem;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool bShowServerDetailsInDesigner : 1;  // 0x308(0x1)
	char pad_777[7];  // 0x309(0x7)
	struct UDataTable* ServerBadgeTable;  // 0x310(0x8)
	struct TArray<struct FFServerBadgeUIDefinition> ServerBadgeDefs;  // 0x318(0x10)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool bDesignTime : 1;  // 0x328(0x1)

	void HasSubMenus(bool& bSubMenuOptions); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.HasSubMenus
	void GetSubMenuOptions(struct TArray<struct FFSubMenuOption>& SubOptions); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetSubMenuOptions
	void GetDesiredHorizontalAlignment(char EHorizontalAlignment& Alignment); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetDesiredHorizontalAlignment
	void GetDesiredVerticalAlignment(char EVerticalAlignment& Alignment); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetDesiredVerticalAlignment
	void OpenPasswordPrompt(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.OpenPasswordPrompt
	void ApplyActiveServerFilters(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ApplyActiveServerFilters
	void RefreshServerList(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.RefreshServerList
	void ToggleServerDetails(bool bShown); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ToggleServerDetails
	void GetServerListSortPreference(struct FFServerSortPreference& SortPreference); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetServerListSortPreference
	void IsValidServerListItemIndex(int32_t IndexToTest, bool& bValidIndex); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.IsValidServerListItemIndex
	void GetSelectedServerListItem(struct UHDServerListItemData*& ServerItem); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetSelectedServerListItem
	void ClearServerListItemSelection(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ClearServerListItemSelection
	void ServerListItemSelectionCleared(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ServerListItemSelectionCleared
	void ServerListItemSelectionUpdated(struct UHDServerListItemData* InSelectedServerListItem); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ServerListItemSelectionUpdated
	void SetActiveSubMenuByIndex(int32_t SubMenuIndex); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.SetActiveSubMenuByIndex
	void ReceiveOnRefreshStart(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ReceiveOnRefreshStart
	void ReceiveOnRefreshComplete(bool bSortAscending, uint8_t  SortBy); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ReceiveOnRefreshComplete
	void BndEvt__RefreshListBtn_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__RefreshListBtn_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_4_OnListItemSelectionChangedDynamic__DelegateSignature(struct UObject* Item, bool bIsSelected); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_4_OnListItemSelectionChangedDynamic__DelegateSignature
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_1_OnListItemScrolledIntoViewDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_1_OnListItemScrolledIntoViewDynamic__DelegateSignature
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature(struct UUserWidget* Widget); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature
	void BndEvt__DetailsPanel_K2Node_ComponentBoundEvent_3_OnJoinServerBtnClicked__DelegateSignature(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__DetailsPanel_K2Node_ComponentBoundEvent_3_OnJoinServerBtnClicked__DelegateSignature
	void OnInitialized(); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.OnInitialized
	void BndEvt__ServerList_K2Node_ComponentBoundEvent_0_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_0_OnListEntryInitializedDynamic__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.PreConstruct
	void BndEvt__FiltersPanel_K2Node_ComponentBoundEvent_8_OnServerFiltersChanged__DelegateSignature(struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__FiltersPanel_K2Node_ComponentBoundEvent_8_OnServerFiltersChanged__DelegateSignature
	void SortPreferenceChanged(struct FFServerSortPreference SortPreference); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.SortPreferenceChanged
	void ConfirmServerPasswordInput(struct FText InputText); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ConfirmServerPasswordInput
	void ExecuteUbergraph_WBP_OptionMenu_JoinGame(int32_t EntryPoint); // Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ExecuteUbergraph_WBP_OptionMenu_JoinGame
}; 



