#pragma once 
#include "SDK.h" 
 
 
// Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.ShouldUseMirroredLowerBodyLoco
// Size: 0x1(Inherited: 0x0) 
struct FShouldUseMirroredLowerBodyLoco
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOutUseMirrored : 1;  // 0x0(0x1)

}; 
// Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.GetLocoAnimSet
// Size: 0x50(Inherited: 0x0) 
struct FGetLocoAnimSet
{
	struct TMap<struct FName, struct UAnimSequenceBase*> OutAnimSet;  // 0x0(0x50)

}; 
// Function BPI_HDWeaponAnimSet.BPI_HDWeaponAnimSet_C.GetLocoTPPAnimSet
// Size: 0x50(Inherited: 0x0) 
struct FGetLocoTPPAnimSet
{
	struct TMap<struct FName, struct UAnimSequenceBase*> OutAnimSet;  // 0x0(0x50)

}; 
