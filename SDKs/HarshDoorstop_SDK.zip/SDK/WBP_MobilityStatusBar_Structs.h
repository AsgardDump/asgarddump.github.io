#pragma once 
#include "SDK.h" 
 
 
// Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.ExecuteUbergraph_WBP_MobilityStatusBar
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_MobilityStatusBar
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationForward_ReturnValue;  // 0x8(0x8)

}; 
// Function WBP_MobilityStatusBar.WBP_MobilityStatusBar_C.SetPercent
// Size: 0x8(Inherited: 0x0) 
struct FSetPercent
{
	float InPercent;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInitial : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7(0x1)

}; 
