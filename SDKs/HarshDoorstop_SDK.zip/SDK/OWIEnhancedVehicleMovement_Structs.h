#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWTransmissionData
// Size: 0x40(Inherited: 0x0) 
struct FVehicleNWTransmissionData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseGearAutoBox : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float GearSwitchTime;  // 0x4(0x4)
	float GearAutoBoxLatency;  // 0x8(0x4)
	float FinalRatio;  // 0xC(0x4)
	struct TArray<struct FVehicleNWGearData> ForwardGears;  // 0x10(0x10)
	struct TArray<struct FVehicleNWGearData> BackwardGears;  // 0x20(0x10)
	float ReverseGearRatio;  // 0x30(0x4)
	float NeutralGearUpRatio;  // 0x34(0x4)
	float NeutralGearDownRatio;  // 0x38(0x4)
	float ClutchStrength;  // 0x3C(0x4)

}; 
// Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.GetLeftTrackSpeed
// Size: 0x4(Inherited: 0x0) 
struct FGetLeftTrackSpeed
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct OWIEnhancedVehicleMovement.VehicleTankTransmissionData
// Size: 0x40(Inherited: 0x0) 
struct FVehicleTankTransmissionData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseGearAutoBox : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float GearSwitchTime;  // 0x4(0x4)
	float GearAutoBoxLatency;  // 0x8(0x4)
	float FinalRatio;  // 0xC(0x4)
	struct TArray<struct FVehicleTankGearData> ForwardGears;  // 0x10(0x10)
	struct TArray<struct FVehicleTankGearData> BackwardGears;  // 0x20(0x10)
	float ReverseGearRatio;  // 0x30(0x4)
	float NeutralGearUpRatio;  // 0x34(0x4)
	float NeutralGearDownRatio;  // 0x38(0x4)
	float ClutchStrength;  // 0x3C(0x4)

}; 
// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWGearData
// Size: 0xC(Inherited: 0x0) 
struct FVehicleNWGearData
{
	float Ratio;  // 0x0(0x4)
	float DownRatio;  // 0x4(0x4)
	float UpRatio;  // 0x8(0x4)

}; 
// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWEngineData
// Size: 0xA0(Inherited: 0x0) 
struct FVehicleNWEngineData
{
	struct FRuntimeFloatCurve TorqueCurve;  // 0x0(0x88)
	float MaxRPM;  // 0x88(0x4)
	float MOI;  // 0x8C(0x4)
	float DampingRateFullThrottle;  // 0x90(0x4)
	float DampingRateZeroThrottleClutchEngaged;  // 0x94(0x4)
	float DampingRateZeroThrottleClutchDisengaged;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)

}; 
// ScriptStruct OWIEnhancedVehicleMovement.VehicleNWWheelDifferentialData
// Size: 0x1(Inherited: 0x0) 
struct FVehicleNWWheelDifferentialData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDriven : 1;  // 0x0(0x1)

}; 
// ScriptStruct OWIEnhancedVehicleMovement.VehicleTankGearData
// Size: 0xC(Inherited: 0x0) 
struct FVehicleTankGearData
{
	float Ratio;  // 0x0(0x4)
	float DownRatio;  // 0x4(0x4)
	float UpRatio;  // 0x8(0x4)

}; 
// ScriptStruct OWIEnhancedVehicleMovement.VehicleTankEngineData
// Size: 0xA0(Inherited: 0x0) 
struct FVehicleTankEngineData
{
	struct FRuntimeFloatCurve TorqueCurve;  // 0x0(0x88)
	float MaxRPM;  // 0x88(0x4)
	float MOI;  // 0x8C(0x4)
	float DampingRateFullThrottle;  // 0x90(0x4)
	float DampingRateZeroThrottleClutchEngaged;  // 0x94(0x4)
	float DampingRateZeroThrottleClutchDisengaged;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)

}; 
// Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.GetRightTrackSpeed
// Size: 0x4(Inherited: 0x0) 
struct FGetRightTrackSpeed
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetBothTracksThrottleInput
// Size: 0x4(Inherited: 0x0) 
struct FSetBothTracksThrottleInput
{
	float InThrottle;  // 0x0(0x4)

}; 
// Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetLeftTrackThrottleInput
// Size: 0x4(Inherited: 0x0) 
struct FSetLeftTrackThrottleInput
{
	float InThrottle;  // 0x0(0x4)

}; 
// Function OWIEnhancedVehicleMovement.WheeledVehicleMovementComponentTank.SetRightTrackThrottleInput
// Size: 0x4(Inherited: 0x0) 
struct FSetRightTrackThrottleInput
{
	float InThrottle;  // 0x0(0x4)

}; 
