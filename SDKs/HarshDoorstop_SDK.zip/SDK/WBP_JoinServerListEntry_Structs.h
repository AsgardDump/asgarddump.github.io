#pragma once 
#include "SDK.h" 
 
 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnSelectionStateChanged__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FOnSelectionStateChanged__DelegateSignature
{
	struct UWBP_JoinServerListEntry_C* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelected : 1;  // 0x8(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.ExecuteUbergraph_WBP_JoinServerListEntry
// Size: 0x282(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_JoinServerListEntry
{
	int32_t EntryPoint;  // 0x0(0x4)
	uint8_t  Temp_byte_Variable;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable : 1;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FText Temp_text_Variable;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x28(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2C(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x2E(0x1)
	uint8_t  K2Node_Select_Default;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x31(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0x32(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool K2Node_Event_bIsSelected : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool K2Node_CustomEvent_bSelected : 1;  // 0x35(0x1)
	char pad_54[2];  // 0x36(0x2)
	struct UListViewBase* CallFunc_GetOwningListView_ReturnValue;  // 0x38(0x8)
	struct UObject* CallFunc_GetListItemObject_ReturnValue;  // 0x40(0x8)
	struct UListView* K2Node_DynamicCast_AsList_View;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UObject* K2Node_Event_ListItemObject;  // 0x58(0x8)
	struct UHDServerListItemData* K2Node_DynamicCast_AsHDServer_List_Item_Data;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool K2Node_Event_bIsDesignTime : 1;  // 0x69(0x1)
	char pad_106[6];  // 0x6A(0x6)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x70(0x18)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x90(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0xA8(0x40)
	struct FText K2Node_Select_Default_3;  // 0xE8(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_3;  // 0x100(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x118(0x40)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x158(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x170(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x180(0x18)
	struct FText CallFunc_Format_ReturnValue;  // 0x198(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_3;  // 0x1B0(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_4;  // 0x1C8(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x1E0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x220(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x230(0x18)
	uint8_t  Temp_byte_Variable_7;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct TArray<struct FFServerBadgeUIDefinition> CallFunc_ParseServerBadgesFromTable_SortedBadgeDefs;  // 0x250(0x10)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x260(0x1)
	char pad_609_1 : 7;  // 0x261(0x1)
	bool K2Node_Event_bIsExpanded : 1;  // 0x261(0x1)
	uint8_t  K2Node_Select_Default_4;  // 0x262(0x1)
	char pad_611[5];  // 0x263(0x5)
	struct UListViewBase* CallFunc_GetOwningListView_ReturnValue_2;  // 0x268(0x8)
	struct UHDServerListView* K2Node_DynamicCast_AsList_View__Harsh_Doorstop_Server_List_;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x278(0x1)
	uint8_t  Temp_byte_Variable_8;  // 0x279(0x1)
	char pad_634_1 : 7;  // 0x27A(0x1)
	bool CallFunc_DoesFilterExcludeListItem_ReturnValue : 1;  // 0x27A(0x1)
	uint8_t  CallFunc_GetVisibilityDefault_ReturnValue;  // 0x27B(0x1)
	uint8_t  Temp_byte_Variable_9;  // 0x27C(0x1)
	uint8_t  K2Node_Select_Default_5;  // 0x27D(0x1)
	char pad_638_1 : 7;  // 0x27E(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x27E(0x1)
	char pad_639_1 : 7;  // 0x27F(0x1)
	bool CallFunc_IsListItemSelected_ReturnValue : 1;  // 0x27F(0x1)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x280(0x1)
	uint8_t  K2Node_Select_Default_6;  // 0x281(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBrushWithImageTexture
// Size: 0x1A0(Inherited: 0x0) 
struct FGetBrushWithImageTexture
{
	struct FSlateBrush Brush;  // 0x0(0x88)
	struct UTexture2D* Image;  // 0x88(0x8)
	struct FSlateBrush UpdatedBrush;  // 0x90(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x118(0x88)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnItemExpansionChanged
// Size: 0x1(Inherited: 0x0) 
struct FBP_OnItemExpansionChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsExpanded : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnItemSelectionChanged
// Size: 0x1(Inherited: 0x0) 
struct FBP_OnItemSelectionChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsSelected : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnServerItemDataSet
// Size: 0x1(Inherited: 0x1) 
struct FOnServerItemDataSet : public FOnServerItemDataSet
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bIsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnListItemObjectSet
// Size: 0x8(Inherited: 0x0) 
struct FOnListItemObjectSet
{
	struct UObject* ListItemObject;  // 0x0(0x8)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.InternalUpdateItemBgTintColor
// Size: 0x80(Inherited: 0x0) 
struct FInternalUpdateItemBgTintColor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x8(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x30(0x28)
	struct FSlateColor K2Node_Select_Default;  // 0x58(0x28)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.On Selection State Changed
// Size: 0x1(Inherited: 0x0) 
struct FOn Selection State Changed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemSelectionState
// Size: 0xE(Inherited: 0x0) 
struct FSetItemSelectionState
{
	uint8_t  InSelectionState;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x3(0x1)
	uint8_t  Temp_byte_Variable;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x6(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9(0x1)
	uint8_t  K2Node_Select_Default;  // 0xA(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0xB(0x1)
	uint8_t  CallFunc_GetCheckedState_ReturnValue;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_2 : 1;  // 0xD(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemIsSelected
// Size: 0xC(Inherited: 0x0) 
struct FSetItemIsSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7(0x1)
	uint8_t  K2Node_Select_Default;  // 0x8(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.PopulateBadges
// Size: 0xC0(Inherited: 0x0) 
struct FPopulateBadges
{
	struct TArray<struct FFServerBadgeUIDefinition> BadgeDefs;  // 0x0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x10(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FFServerBadgeUIDefinition CallFunc_Array_Get_Item;  // 0x20(0x98)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xBC(0x4)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBrushWithItemDimensions
// Size: 0x1D0(Inherited: 0x0) 
struct FGetBrushWithItemDimensions
{
	struct FSlateBrush InBrush;  // 0x0(0x88)
	struct FSlateBrush OutBrush;  // 0x88(0x88)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool Temp_bool_Variable : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x111(0x1)
	char pad_274[2];  // 0x112(0x2)
	struct FVector2D CallFunc_GetDesiredSize_ReturnValue;  // 0x114(0x8)
	float CallFunc_BreakVector2D_X;  // 0x11C(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x120(0x4)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x124(0x1)
	char pad_293[3];  // 0x125(0x3)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x128(0x4)
	float K2Node_Select_Default;  // 0x12C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x130(0x4)
	char pad_308_1 : 7;  // 0x134(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x134(0x1)
	char pad_309[3];  // 0x135(0x3)
	float K2Node_Select_Default_2;  // 0x138(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x13C(0x8)
	char pad_324[4];  // 0x144(0x4)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x148(0x88)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemSelectionState
// Size: 0x2(Inherited: 0x0) 
struct FGetItemSelectionState
{
	uint8_t  SelectionState;  // 0x0(0x1)
	uint8_t  CallFunc_GetCheckedState_ReturnValue;  // 0x1(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.IsItemSelected
// Size: 0x2(Inherited: 0x0) 
struct FIsItemSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemStyle
// Size: 0xFC8(Inherited: 0x0) 
struct FSetItemStyle
{
	struct FCheckBoxStyle InItemStyle;  // 0x0(0x580)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush;  // 0x580(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_2;  // 0x608(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_3;  // 0x690(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_4;  // 0x718(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_5;  // 0x7A0(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_6;  // 0x828(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_7;  // 0x8B0(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_8;  // 0x938(0x88)
	struct FSlateBrush CallFunc_GetBrushWithItemDimensions_OutBrush_9;  // 0x9C0(0x88)
	struct FCheckBoxStyle K2Node_MakeStruct_CheckBoxStyle;  // 0xA48(0x580)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemImage
// Size: 0x18(Inherited: 0x0) 
struct FSetItemImage
{
	struct UTexture2D* InItemImg;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct UTexture2D* K2Node_Select_Default;  // 0x10(0x8)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemMinDimensions
// Size: 0x8(Inherited: 0x0) 
struct FSetItemMinDimensions
{
	int32_t InMinWidth;  // 0x0(0x4)
	int32_t InMinHeight;  // 0x4(0x4)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemStyle
// Size: 0x580(Inherited: 0x0) 
struct FGetItemStyle
{
	struct FCheckBoxStyle ItemStyle;  // 0x0(0x580)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemMinWidth
// Size: 0x4(Inherited: 0x0) 
struct FGetItemMinWidth
{
	int32_t MinWidth;  // 0x0(0x4)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemMinHeight
// Size: 0x4(Inherited: 0x0) 
struct FGetItemMinHeight
{
	int32_t MinHeight;  // 0x0(0x4)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.InternalRefreshDimensions
// Size: 0xC(Inherited: 0x0) 
struct FInternalRefreshDimensions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x8(0x4)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetBadgeVisibilityFromServerData
// Size: 0x41(Inherited: 0x0) 
struct FSetBadgeVisibilityFromServerData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisible : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	uint8_t  K2Node_Select_Default;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x18(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	struct UWBP_ServerBadge_C* K2Node_DynamicCast_AsWBP_Server_Badge;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.HideAllBadges
// Size: 0x41(Inherited: 0x0) 
struct FHideAllBadges
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UWBP_ServerBadge_C* K2Node_DynamicCast_AsWBP_Server_Badge;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBadgeDefinitionFromTable
// Size: 0x149(Inherited: 0x0) 
struct FGetBadgeDefinitionFromTable
{
	struct FDataTableRowHandle RowHandle;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bFound : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FFServerBadgeUIDefinition BadgeUIDef;  // 0x18(0x98)
	struct FFServerBadgeUIDefinition CallFunc_GetDataTableRowFromName_OutRow;  // 0xB0(0x98)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x148(0x1)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.CreateAndAddBadgeWidgetFromDefinition
// Size: 0xA8(Inherited: 0x0) 
struct FCreateAndAddBadgeWidgetFromDefinition
{
	struct FFServerBadgeUIDefinition BadgeUIDef;  // 0x0(0x98)
	struct UWBP_ServerBadge_C* CallFunc_Create_ReturnValue;  // 0x98(0x8)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue;  // 0xA0(0x8)

}; 
// Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.AddBadgeDefinitionToListIfFound
// Size: 0xCC(Inherited: 0x0) 
struct FAddBadgeDefinitionToListIfFound
{
	struct FName TableRowName;  // 0x0(0x8)
	struct TArray<struct FFServerBadgeUIDefinition> BadgeArr;  // 0x8(0x10)
	struct FDataTableRowHandle K2Node_MakeStruct_DataTableRowHandle;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_GetBadgeDefinitionFromTable_bFound : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FFServerBadgeUIDefinition CallFunc_GetBadgeDefinitionFromTable_BadgeUIDef;  // 0x30(0x98)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xC8(0x4)

}; 
