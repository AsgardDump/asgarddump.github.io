#pragma once 
#include <BP_HDFactionInfoBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDFactionInfoBase.BP_HDFactionInfoBase_C
// Size: 0x850(Inherited: 0xE0) 
struct UBP_HDFactionInfoBase_C : public UHDFactionInfo
{
	struct FButtonStyle TeamBtnSelectedStyle;  // 0xE0(0x278)
	struct FButtonStyle TeamBtnDeselectedStyle;  // 0x358(0x278)
	struct FSlateBrush TeamBtnSelectedBrush;  // 0x5D0(0x88)
	struct FSlateBrush TeamBtnDeselectedBrush;  // 0x658(0x88)
	struct TSoftObjectPtr<UTexture2D> CPFlagIcon;  // 0x6E0(0x28)
	struct TSoftObjectPtr<USkeletalMesh> CharMesh;  // 0x708(0x28)
	struct TSoftObjectPtr<USkeletalMesh> CharMesh1P;  // 0x730(0x28)
	struct FText TeamBtnDisplayText;  // 0x758(0x18)
	struct FText VictoryText;  // 0x770(0x18)
	struct TSoftClassPtr<UObject> RallyPointClass;  // 0x788(0x28)
	struct TSoftClassPtr<UObject> OutpostClass;  // 0x7B0(0x28)
	struct TSoftObjectPtr<UHDKit> AIControlledSquadLeaderKit;  // 0x7D8(0x28)
	struct TSoftObjectPtr<UHDKit> AIControlledSquadMemberKit;  // 0x800(0x28)
	struct TSoftObjectPtr<UDataTable> AIVocalProfiles;  // 0x828(0x28)

}; 



