#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUD.WBP_HUD_C.ExecuteUbergraph_WBP_HUD
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUD
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function WBP_HUD.WBP_HUD_C.ToggleEquipmentSelect
// Size: 0x1(Inherited: 0x0) 
struct FToggleEquipmentSelect
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisible : 1;  // 0x0(0x1)

}; 
// Function WBP_HUD.WBP_HUD_C.ToggleWeaponStatus
// Size: 0x1(Inherited: 0x0) 
struct FToggleWeaponStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisible : 1;  // 0x0(0x1)

}; 
// Function WBP_HUD.WBP_HUD_C.SetHUDElementVisibility
// Size: 0xD(Inherited: 0x0) 
struct FSetHUDElementVisibility
{
	struct UWidget* Widget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bShown : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable : 1;  // 0x9(0x1)
	uint8_t  CallFunc_GetVisibilityDefault_ReturnValue;  // 0xA(0x1)
	uint8_t  Temp_byte_Variable;  // 0xB(0x1)
	uint8_t  K2Node_Select_Default;  // 0xC(0x1)

}; 
