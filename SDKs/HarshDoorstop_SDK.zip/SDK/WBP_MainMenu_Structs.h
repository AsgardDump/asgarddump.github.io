#pragma once 
#include "SDK.h" 
 
 
// Function WBP_MainMenu.WBP_MainMenu_C.ExecuteUbergraph_WBP_MainMenu
// Size: 0x161(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_MainMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_CustomEvent_ClickedBtn_2;  // 0x8(0x8)
	int32_t CallFunc_GetNavBtnCount_Count;  // 0x10(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x14(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	int32_t CallFunc_Max_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWBP_DlgBox_LeaveGame_C* CallFunc_Create_ReturnValue;  // 0x28(0x8)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x30(0x4)
	int32_t Temp_int_Variable;  // 0x34(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x38(0x8)
	struct UWBP_DlgBox_Quit_C* CallFunc_Create_ReturnValue_2;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_ComponentBoundEvent_ClickedBtn_5;  // 0x50(0x8)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_GetChildIndex_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x6A(0x1)
	char pad_107[5];  // 0x6B(0x5)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_ComponentBoundEvent_ClickedBtn_4;  // 0x70(0x8)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse_2;  // 0x78(0x8)
	uint8_t  Temp_byte_Variable;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UWBP_MenuSubNavSelectionListEntry_C* K2Node_CustomEvent_ClickedBtn;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool Temp_bool_Variable : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x98(0x8)
	struct UTBGameInstance* K2Node_DynamicCast_AsTBGame_Instance;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue_2;  // 0xB0(0x8)
	struct UTBGameInstance* K2Node_DynamicCast_AsTBGame_Instance_2;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC4(0x10)
	uint8_t  Temp_byte_Variable_2;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0xD8(0x8)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_ComponentBoundEvent_ClickedBtn_3;  // 0xE0(0x8)
	uint8_t  K2Node_Select_Default;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	int32_t Temp_int_Variable_2;  // 0xEC(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0xF0(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0xF8(0x8)
	struct UWBP_MenuSubNavSelectionListEntry_C* K2Node_DynamicCast_AsWBP_Menu_Sub_Nav_Selection_List_Entry;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x109(0x1)
	char pad_266[2];  // 0x10A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10C(0x4)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_ComponentBoundEvent_ClickedBtn_2;  // 0x110(0x8)
	struct UWidget* CallFunc_GetChildAt_ReturnValue_2;  // 0x118(0x8)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_DynamicCast_AsWBP_Main_Menu_Nav_Bar_Button;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x128(0x1)
	char pad_297_1 : 7;  // 0x129(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x129(0x1)
	char pad_298_1 : 7;  // 0x12A(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x12A(0x1)
	char pad_299[5];  // 0x12B(0x5)
	struct TScriptInterface<IBPI_OptionMenu_C> K2Node_DynamicCast_AsBPI_Option_Menu;  // 0x130(0x10)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x140(0x1)
	char pad_321[7];  // 0x141(0x7)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_ComponentBoundEvent_ClickedBtn;  // 0x148(0x8)
	int32_t Temp_int_Variable_3;  // 0x150(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x154(0x4)
	int32_t K2Node_Select_Default_2;  // 0x158(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x15C(0x4)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x160(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ShootingRangeNavBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__ShootingRangeNavBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature
{
	struct UWBP_MainMenu_NavBarButton_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__PauseExitGameNavBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__PauseExitGameNavBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature
{
	struct UWBP_MainMenu_NavBarButton_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ExitGameNavBtn_K2Node_ComponentBoundEvent_4_ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__ExitGameNavBtn_K2Node_ComponentBoundEvent_4_ButtonClicked__DelegateSignature
{
	struct UWBP_MainMenu_NavBarButton_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.OnSubNavBtnClicked
// Size: 0x8(Inherited: 0x0) 
struct FOnSubNavBtnClicked
{
	struct UWBP_MenuSubNavSelectionListEntry_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ReturnToMenuNavBtn_K2Node_ComponentBoundEvent_12_ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__ReturnToMenuNavBtn_K2Node_ComponentBoundEvent_12_ButtonClicked__DelegateSignature
{
	struct UWBP_MainMenu_NavBarButton_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.OnMouseButtonDown
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.BndEvt__ResumeNavBtn_K2Node_ComponentBoundEvent_11_ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__ResumeNavBtn_K2Node_ComponentBoundEvent_11_ButtonClicked__DelegateSignature
{
	struct UWBP_MainMenu_NavBarButton_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.TeardownSubNavBarClickEvents
// Size: 0x2A(Inherited: 0x0) 
struct FTeardownSubNavBarClickEvents
{
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x18(0x8)
	struct UWBP_MenuSubNavSelectionListEntry_C* K2Node_DynamicCast_AsWBP_Menu_Sub_Nav_Selection_List_Entry;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x29(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.OnNavBtnClicked
// Size: 0x8(Inherited: 0x0) 
struct FOnNavBtnClicked
{
	struct UWBP_MainMenu_NavBarButton_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.InitMenuState
// Size: 0x19(Inherited: 0x0) 
struct FInitMenuState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsDesignTime : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct ABP_MenuPC_C* K2Node_DynamicCast_AsBP_Menu_PC;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.SetupMenuBackgroundWidget
// Size: 0x28(Inherited: 0x0) 
struct FSetupMenuBackgroundWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	UUserWidget* K2Node_Select_Default;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UUserWidget* CallFunc_Create_ReturnValue;  // 0x18(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x20(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.SetOptionMenu
// Size: 0x43(Inherited: 0x0) 
struct FSetOptionMenu
{
	UDFBaseMenu* NewOptionMenuClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsDesignTime : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UDFBaseMenu* CallFunc_Create_ReturnValue;  // 0x10(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x18(0x8)
	struct TScriptInterface<IBPI_OptionMenu_C> K2Node_DynamicCast_AsBPI_Option_Menu;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UBorderSlot* K2Node_DynamicCast_AsBorder_Slot;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)
	char EVerticalAlignment CallFunc_GetDesiredVerticalAlignment_Alignment;  // 0x41(0x1)
	char EHorizontalAlignment CallFunc_GetDesiredHorizontalAlignment_Alignment;  // 0x42(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.SetupNavBarClickEvents
// Size: 0x52(Inherited: 0x0) 
struct FSetupNavBarClickEvents
{
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse;  // 0x0(0x8)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse_2;  // 0x8(0x8)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse_3;  // 0x10(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x20(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x24(0x10)
	int32_t Temp_int_Variable;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x40(0x8)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_DynamicCast_AsWBP_Main_Menu_Nav_Bar_Button;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x51(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.SetActiveMenu
// Size: 0x5B(Inherited: 0x0) 
struct FSetActiveMenu
{
	int32_t NewIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	UDFBaseMenu* NewOptionMenuClass;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsDesignTime : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse_2;  // 0x28(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x30(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x34(0x4)
	int32_t Temp_int_Variable;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x48(0x8)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_DynamicCast_AsWBP_Main_Menu_Nav_Bar_Button;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5A(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.SetupCopyrightNotice
// Size: 0x50(Inherited: 0x0) 
struct FSetupCopyrightNotice
{
	struct FString CallFunc_GetCopyrightNotice_ReturnValue;  // 0x0(0x10)
	struct FString CallFunc_Replace_ReturnValue;  // 0x10(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x20(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x38(0x18)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.GetNavBtnCount
// Size: 0x50(Inherited: 0x0) 
struct FGetNavBtnCount
{
	int32_t Count;  // 0x0(0x4)
	int32_t Sum;  // 0x4(0x4)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse;  // 0x10(0x8)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x18(0x8)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse_2;  // 0x20(0x8)
	struct UWBP_MainMenu_NavBarButton_C* K2Node_DynamicCast_AsWBP_Main_Menu_Nav_Bar_Button;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x34(0x4)
	struct UHorizontalBox* CallFunc_GetNavBarHBox_HBoxToUse_3;  // 0x38(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	int32_t Temp_int_Variable_2;  // 0x48(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x4C(0x4)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.GetNavBarHBox
// Size: 0x18(Inherited: 0x0) 
struct FGetNavBarHBox
{
	struct UHorizontalBox* HBoxToUse;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UHorizontalBox* K2Node_Select_Default;  // 0x10(0x8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.UpdateSubNavBarOptions
// Size: 0x21(Inherited: 0x0) 
struct FUpdateSubNavBarOptions
{
	struct TScriptInterface<IBPI_OptionMenu_C> NewOptionMenu;  // 0x0(0x10)
	struct TArray<struct FFSubMenuOption> CallFunc_GetSubMenuOptions_SubOptions;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_HasSubMenus_bSubMenuOptions : 1;  // 0x20(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.PopulateSubNavBar
// Size: 0xA0(Inherited: 0x0) 
struct FPopulateSubNavBar
{
	struct TArray<struct FFSubMenuOption> SubMenuOptions;  // 0x0(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	struct FFSubMenuOption CallFunc_Array_Get_Item;  // 0x20(0x20)
	struct FMargin K2Node_MakeStruct_Margin;  // 0x40(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x58(0x18)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UWBP_MenuSubNavSelectionListEntry_C* CallFunc_Create_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool Temp_bool_Variable : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0x88(0x8)
	struct FMargin K2Node_Select_Default;  // 0x90(0x10)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.ToggleSubNavBar
// Size: 0x5(Inherited: 0x0) 
struct FToggleSubNavBar
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewVisible : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	uint8_t  K2Node_Select_Default;  // 0x4(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.SetupSubNavBarClickEvents
// Size: 0x3A(Inherited: 0x0) 
struct FSetupSubNavBarClickEvents
{
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x8(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC(0x10)
	int32_t Temp_int_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x28(0x8)
	struct UWBP_MenuSubNavSelectionListEntry_C* K2Node_DynamicCast_AsWBP_Menu_Sub_Nav_Selection_List_Entry;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x39(0x1)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.OnMouseWheel
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseWheel : public FOnMouseWheel
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_MainMenu.WBP_MainMenu_C.PlayMenuMusic
// Size: 0x10(Inherited: 0x0) 
struct FPlayMenuMusic
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UAudioComponent* CallFunc_SpawnSound2D_ReturnValue;  // 0x8(0x8)

}; 
