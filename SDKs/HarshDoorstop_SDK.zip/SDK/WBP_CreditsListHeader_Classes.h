#pragma once 
#include <WBP_CreditsListHeader_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_CreditsListHeader.WBP_CreditsListHeader_C
// Size: 0x278(Inherited: 0x230) 
struct UWBP_CreditsListHeader_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* DividerLine;  // 0x238(0x8)
	struct UTextBlock* HeaderText;  // 0x240(0x8)
	struct FFGameCreditsEntry CreditsEntry;  // 0x248(0x30)

	void SetCreditsEntry(struct FFGameCreditsEntry& Entry, struct FMargin HeaderPadding); // Function WBP_CreditsListHeader.WBP_CreditsListHeader_C.SetCreditsEntry
	void PreConstruct(bool IsDesignTime); // Function WBP_CreditsListHeader.WBP_CreditsListHeader_C.PreConstruct
	void ExecuteUbergraph_WBP_CreditsListHeader(int32_t EntryPoint); // Function WBP_CreditsListHeader.WBP_CreditsListHeader_C.ExecuteUbergraph_WBP_CreditsListHeader
}; 



