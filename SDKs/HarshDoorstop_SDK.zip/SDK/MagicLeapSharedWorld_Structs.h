#pragma once 
#include "SDK.h" 
 
 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.SendSharedWorldDataToClients
// Size: 0x1(Inherited: 0x0) 
struct FSendSharedWorldDataToClients
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldGameMode.DetermineSharedWorldData
// Size: 0x10(Inherited: 0x0) 
struct FDetermineSharedWorldData
{
	struct FMagicLeapSharedWorldSharedData NewSharedWorldData;  // 0x0(0x10)

}; 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.CanSendLocalDataToServer
// Size: 0x1(Inherited: 0x0) 
struct FCanSendLocalDataToServer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct MagicLeapSharedWorld.MagicLeapSharedWorldPinData
// Size: 0x20(Inherited: 0x0) 
struct FMagicLeapSharedWorldPinData
{
	struct FGuid PinID;  // 0x0(0x10)
	struct FMagicLeapARPinState PinState;  // 0x10(0x10)

}; 
// ScriptStruct MagicLeapSharedWorld.MagicLeapSharedWorldSharedData
// Size: 0x10(Inherited: 0x0) 
struct FMagicLeapSharedWorldSharedData
{
	struct TArray<struct FGuid> PinIDs;  // 0x0(0x10)

}; 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldGameState.CalculateXRCameraRootTransform
// Size: 0x30(Inherited: 0x0) 
struct FCalculateXRCameraRootTransform
{
	struct FTransform ReturnValue;  // 0x0(0x30)

}; 
// ScriptStruct MagicLeapSharedWorld.MagicLeapSharedWorldAlignmentTransforms
// Size: 0x10(Inherited: 0x0) 
struct FMagicLeapSharedWorldAlignmentTransforms
{
	struct TArray<struct FTransform> AlignmentTransforms;  // 0x0(0x10)

}; 
// ScriptStruct MagicLeapSharedWorld.MagicLeapSharedWorldLocalData
// Size: 0x10(Inherited: 0x0) 
struct FMagicLeapSharedWorldLocalData
{
	struct TArray<struct FMagicLeapSharedWorldPinData> LocalPins;  // 0x0(0x10)

}; 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ClientSetChosenOne
// Size: 0x1(Inherited: 0x0) 
struct FClientSetChosenOne
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChosenOne : 1;  // 0x0(0x1)

}; 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.IsChosenOne
// Size: 0x1(Inherited: 0x0) 
struct FIsChosenOne
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetAlignmentTransforms
// Size: 0x10(Inherited: 0x0) 
struct FServerSetAlignmentTransforms
{
	struct FMagicLeapSharedWorldAlignmentTransforms InAlignmentTransforms;  // 0x0(0x10)

}; 
// Function MagicLeapSharedWorld.MagicLeapSharedWorldPlayerController.ServerSetLocalWorldData
// Size: 0x10(Inherited: 0x0) 
struct FServerSetLocalWorldData
{
	struct FMagicLeapSharedWorldLocalData LocalWorldReplicationData;  // 0x0(0x10)

}; 
