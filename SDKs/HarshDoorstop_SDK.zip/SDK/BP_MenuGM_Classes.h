#pragma once 
#include <BP_MenuGM_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MenuGM.BP_MenuGM_C
// Size: 0x318(Inherited: 0x308) 
struct ABP_MenuGM_C : public AGameMode
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x308(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x310(0x8)

	void ReceiveBeginPlay(); // Function BP_MenuGM.BP_MenuGM_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_MenuGM(int32_t EntryPoint); // Function BP_MenuGM.BP_MenuGM_C.ExecuteUbergraph_BP_MenuGM
}; 



