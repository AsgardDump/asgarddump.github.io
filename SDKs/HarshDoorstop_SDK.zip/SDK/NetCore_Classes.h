#pragma once 
#include <NetCore_Structs.h>
 
 
 
// Class NetCore.NetAnalyticsAggregatorConfig
// Size: 0x38(Inherited: 0x28) 
struct UNetAnalyticsAggregatorConfig : public UObject
{
	struct TArray<struct FNetAnalyticsDataConfig> NetAnalyticsData;  // 0x28(0x10)

}; 



