#pragma once 
#include <BP_DmgType_DefaultWeapon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DmgType_DefaultWeapon.BP_DmgType_DefaultWeapon_C
// Size: 0x48(Inherited: 0x48) 
struct UBP_DmgType_DefaultWeapon_C : public UDFDamageType
{

}; 



