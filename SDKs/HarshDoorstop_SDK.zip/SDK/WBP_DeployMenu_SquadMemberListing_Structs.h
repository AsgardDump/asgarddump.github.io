#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.ExecuteUbergraph_WBP_DeployMenu_SquadMemberListing
// Size: 0x9F(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_SquadMemberListing
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FString K2Node_Event_NewPlayerName;  // 0x8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x38(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x48(0x18)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x60(0x38)
	float K2Node_Event_InDeltaTime;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x9C(0x1)
	char pad_157_1 : 7;  // 0x9D(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x9D(0x1)
	char pad_158_1 : 7;  // 0x9E(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x9E(0x1)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.SetPlayerNameText
// Size: 0x30(Inherited: 0x0) 
struct FSetPlayerNameText
{
	struct FText NewPlayerName;  // 0x0(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x18(0x18)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.SetupOptions
// Size: 0x58(Inherited: 0x0) 
struct FSetupOptions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNoVisibleWidgets : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	uint8_t  Temp_byte_Variable_2;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_Variable : 1;  // 0x11(0x1)
	uint8_t  K2Node_Select_Default;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UWBP_SQMemberOption_C* K2Node_DynamicCast_AsWBP_SQMember_Option;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)
	struct UHorizontalBoxSlot* CallFunc_SlotAsHorizontalBoxSlot_ReturnValue;  // 0x50(0x8)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.TestOptionPrereqs
// Size: 0x42(Inherited: 0x0) 
struct FTestOptionPrereqs
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UDFContextualWidgetBase* K2Node_DynamicCast_AsDFContextual_Widget_Base;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_TestPrerequisites_ReturnValue : 1;  // 0x41(0x1)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.UpdateColorOffset
// Size: 0x24(Inherited: 0x0) 
struct FUpdateColorOffset
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEvenNumberListing : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	struct FLinearColor K2Node_Select_Default;  // 0x4(0x10)
	struct FLinearColor K2Node_Select_Default_2;  // 0x14(0x10)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.OnMemberPlayerNameUpdated
// Size: 0x10(Inherited: 0x10) 
struct FOnMemberPlayerNameUpdated : public FOnMemberPlayerNameUpdated
{
	struct FString NewPlayerName;  // 0x0(0x10)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.UpdatePlayerClassIcon
// Size: 0x90(Inherited: 0x0) 
struct FUpdatePlayerClassIcon
{
	struct UHDKit* Loadout;  // 0x0(0x8)
	struct FSlateBrush CallFunc_GetClassIconForLoadout_ClassIconToUse;  // 0x8(0x88)

}; 
// Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.GetClassIconForLoadout
// Size: 0x1A9(Inherited: 0x0) 
struct FGetClassIconForLoadout
{
	struct UHDKit* Loadout;  // 0x0(0x8)
	struct FSlateBrush ClassIconToUse;  // 0x8(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x90(0x88)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_2;  // 0x120(0x88)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1A8(0x1)

}; 
