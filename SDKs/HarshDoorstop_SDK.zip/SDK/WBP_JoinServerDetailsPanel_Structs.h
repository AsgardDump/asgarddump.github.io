#pragma once 
#include "SDK.h" 
 
 
// Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.ExecuteUbergraph_WBP_JoinServerDetailsPanel
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_JoinServerDetailsPanel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)

}; 
// Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.SetupServerDetails
// Size: 0xA0(Inherited: 0x0) 
struct FSetupServerDetails
{
	struct FHDServerInfo ServerInfo;  // 0x0(0xA0)

}; 
// Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.UpdateServerData
// Size: 0x288(Inherited: 0x0) 
struct FUpdateServerData
{
	struct FHDServerInfo ServerData;  // 0x0(0xA0)
	struct FString CallFunc_GetServerIpPort_ReturnValue;  // 0xA0(0x10)
	struct FString CallFunc_Split_LeftS;  // 0xB0(0x10)
	struct FString CallFunc_Split_RightS;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_Split_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xD8(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0xF0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x108(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x148(0x40)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x188(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x1A0(0x40)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x1E0(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x1F8(0x10)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x208(0x40)
	struct FText CallFunc_Format_ReturnValue;  // 0x248(0x18)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x260(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x270(0x18)

}; 
// Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.SetMapPreviewImage
// Size: 0x8(Inherited: 0x0) 
struct FSetMapPreviewImage
{
	struct UTexture2D* NewImg;  // 0x0(0x8)

}; 
// Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.UpdateServerMetaData
// Size: 0xD8(Inherited: 0x0) 
struct FUpdateServerMetaData
{
	struct FHDServerInfo ServerData;  // 0x0(0xA0)
	struct FString CallFunc_ToUpper_ReturnValue;  // 0xA0(0x10)
	struct FString CallFunc_AbbreviateString_AbbrevString;  // 0xB0(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xC0(0x18)

}; 
