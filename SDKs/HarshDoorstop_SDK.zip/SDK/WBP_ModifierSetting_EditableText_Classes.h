#pragma once 
#include <WBP_ModifierSetting_EditableText_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C
// Size: 0x340(Inherited: 0x230) 
struct UWBP_ModifierSetting_EditableText_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UEditableText* ModifierEditableText;  // 0x238(0x8)
	struct UWBP_ModifierSettingBox_C* ModifierSetting;  // 0x240(0x8)
	struct FText SettingLabelText;  // 0x248(0x18)
	struct FFModifierTextStyle SettingLabelTextStyle;  // 0x260(0x78)
	struct FText DefaultText;  // 0x2D8(0x18)
	struct FText DefaultHintText;  // 0x2F0(0x18)
	struct TArray<struct FString> DefaultOptions;  // 0x308(0x10)
	int32_t DefaultSelectedOptionIdx;  // 0x318(0x4)
	char pad_796[4];  // 0x31C(0x4)
	struct FMulticastInlineDelegate OnTextChanged;  // 0x320(0x10)
	struct FMulticastInlineDelegate OnTextCommitted;  // 0x330(0x10)

	void GetSettingLabel(struct FText& SettingText); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.GetSettingLabel
	void SetSettingLabel(struct FText InSettingText); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.SetSettingLabel
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.PreConstruct
	void OnInitialized(); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnInitialized
	void BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature(struct FText& Text); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature
	void BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_3_OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, char ETextCommit CommitMethod); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_3_OnEditableTextCommittedEvent__DelegateSignature
	void ExecuteUbergraph_WBP_ModifierSetting_EditableText(int32_t EntryPoint); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.ExecuteUbergraph_WBP_ModifierSetting_EditableText
	void OnTextCommitted__DelegateSignature(struct FText Text, char ETextCommit CommitMethod); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnTextCommitted__DelegateSignature
	void OnTextChanged__DelegateSignature(struct FText Text); // Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnTextChanged__DelegateSignature
}; 



