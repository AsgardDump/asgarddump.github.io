#pragma once 
#include "SDK.h" 
 
 
// Function DonkehFramework.DFGameRulesetBase.PlayerDied
// Size: 0x8(Inherited: 0x0) 
struct FPlayerDied
{
	struct AController* Victim;  // 0x0(0x8)

}; 
// DelegateFunction DonkehFramework.PlayerTalkingStateChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FPlayerTalkingStateChanged__DelegateSignature
{
	struct APlayerState* TalkerPS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bTalking : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseGameMode.RemoveTeamBots
// Size: 0x8(Inherited: 0x0) 
struct FRemoveTeamBots
{
	char TeamId;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Num;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseGun.StartReload
// Size: 0x1(Inherited: 0x0) 
struct FStartReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.PerspectiveStaticMesh
// Size: 0x10(Inherited: 0x0) 
struct FPerspectiveStaticMesh
{
	struct UStaticMesh* Mesh1P;  // 0x0(0x8)
	struct UStaticMesh* Mesh3P;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.ServerOnToggleFirstPerson
// Size: 0x1(Inherited: 0x0) 
struct FServerOnToggleFirstPerson
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewFirstPerson : 1;  // 0x0(0x1)

}; 
// DelegateFunction DonkehFramework.CharacterAbilityTransitionSignature__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCharacterAbilityTransitionSignature__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsStartTransition : 1;  // 0x0(0x1)

}; 
// DelegateFunction DonkehFramework.TeamNumUpdateSignature__DelegateSignature
// Size: 0x2(Inherited: 0x0) 
struct FTeamNumUpdateSignature__DelegateSignature
{
	char LastTeamNum;  // 0x0(0x1)
	char NewTeamNum;  // 0x1(0x1)

}; 
// DelegateFunction DonkehFramework.WeaponFireSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FWeaponFireSignature__DelegateSignature
{
	struct ADFBaseWeapon* FiredWeapon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bLastFire : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction DonkehFramework.PawnPossessionSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FPawnPossessionSignature__DelegateSignature
{
	struct APawn* Pawn;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.GetPreviousStance
// Size: 0x1(Inherited: 0x0) 
struct FGetPreviousStance
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.TakeHitInfo
// Size: 0x120(Inherited: 0x0) 
struct FTakeHitInfo
{
	float ActualDamage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	UObject* DamageTypeClass;  // 0x8(0x8)
	struct TWeakObjectPtr<APawn> PawnInstigator;  // 0x10(0x8)
	struct TWeakObjectPtr<AActor> DamageCauser;  // 0x18(0x8)
	int32_t DamageEventClassID;  // 0x20(0x4)
	char bKilled : 1;  // 0x24(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	char EnsureReplicationByte;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	struct FDamageEvent GeneralDamageEvent;  // 0x28(0x10)
	struct FPointDamageEvent PointDamageEvent;  // 0x38(0xA8)
	struct FRadialDamageEvent RadialDamageEvent;  // 0xE0(0x40)

}; 
// DelegateFunction DonkehFramework.TeamStateUpdateSignature__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FTeamStateUpdateSignature__DelegateSignature
{
	struct ADFTeamState* LastTeamState;  // 0x0(0x8)
	struct ADFTeamState* NewTeamState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bNewTeamStateInit : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBaseGameInstance.OnNetworkLagStateChanged
// Size: 0x18(Inherited: 0x0) 
struct FOnNetworkLagStateChanged
{
	struct UWorld* World;  // 0x0(0x8)
	struct UNetDriver* NetDriver;  // 0x8(0x8)
	char ENetworkLagState LagType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// DelegateFunction DonkehFramework.CharacterEquippedItemChangedSignature__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FCharacterEquippedItemChangedSignature__DelegateSignature
{
	struct ADFBaseCharacter* Character;  // 0x0(0x8)
	struct ADFBaseItem* NewEquippedItem;  // 0x8(0x8)
	struct ADFBaseItem* PrevEquippedItem;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerJoined
// Size: 0x8(Inherited: 0x0) 
struct FPlayerJoined
{
	struct APlayerController* NewPlayer;  // 0x0(0x8)

}; 
// ScriptStruct DonkehFramework.CharacterAnimCollection
// Size: 0x128(Inherited: 0x0) 
struct FCharacterAnimCollection
{
	struct UAnimSequence* BasePose;  // 0x0(0x8)
	struct UAnimSequence* BasePoseTPP;  // 0x8(0x8)
	struct UAnimSequence* AimBasePose;  // 0x10(0x8)
	struct UAnimMontage* Death;  // 0x18(0x8)
	struct FIntrinsicWeaponAnimSubset Intrinsic;  // 0x20(0x28)
	struct FLocomotionWeaponAnimSubset Locomotion;  // 0x48(0x18)
	struct FSingleActionWeaponAnimSubset SingleAction;  // 0x60(0x8)
	struct FSingleLoadWeaponAnimSubset SingleLoad;  // 0x68(0x10)
	struct FThrowableWeaponAnimSubset Throwable;  // 0x78(0x20)
	struct FPerspectiveAnim DeathAnim;  // 0x98(0x10)
	struct FPerspectiveAnim EquipAnim;  // 0xA8(0x10)
	struct FPerspectiveAnim UnEquipAnim;  // 0xB8(0x10)
	struct FPerspectiveAnim FireAnim;  // 0xC8(0x10)
	struct FPerspectiveAnim ActionAnim;  // 0xD8(0x10)
	struct FPerspectiveAnim ReloadAnim;  // 0xE8(0x10)
	struct FPerspectiveAnim ReloadFullAnim;  // 0xF8(0x10)
	struct FPerspectiveAnim StartReloadAnim;  // 0x108(0x10)
	struct FPerspectiveAnim EndReloadAnim;  // 0x118(0x10)

}; 
// Function DonkehFramework.DFPlayerComponent.ReceiveSeamlessTravelToCommon
// Size: 0x10(Inherited: 0x0) 
struct FReceiveSeamlessTravelToCommon
{
	struct AController* NewC;  // 0x0(0x8)
	struct UDFPlayerComponent* NewCPlayerComp;  // 0x8(0x8)

}; 
// DelegateFunction DonkehFramework.CharacterHealthChangedSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FCharacterHealthChangedSignature__DelegateSignature
{
	struct ADFBaseCharacter* Character;  // 0x0(0x8)
	float NewHealthTotal;  // 0x8(0x4)
	float PrevHealthTotal;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetSupportedGameModes
// Size: 0x68(Inherited: 0x0) 
struct FGetMapAssetSupportedGameModes
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	struct TSet<struct TSoftClassPtr<UObject>> OutSupportedGameModes;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function DonkehFramework.SpawnPointStatics.CanRestartPlayerFromSpawnPoint
// Size: 0x80(Inherited: 0x0) 
struct FCanRestartPlayerFromSpawnPoint
{
	struct UObject* Target;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FSpawnPointDef SpawnPoint;  // 0x10(0x50)
	struct AController* Player;  // 0x60(0x8)
	APawn* PlayerPawnClass;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_113[15];  // 0x71(0xF)

}; 
// DelegateFunction DonkehFramework.CharacterOnDeathSignature__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FCharacterOnDeathSignature__DelegateSignature
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function DonkehFramework.DFBasePlayerState.SetTeam
// Size: 0x2(Inherited: 0x0) 
struct FSetTeam
{
	char NewTeamNum;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bCopyToInactivePlayerState : 1;  // 0x1(0x1)

}; 
// ScriptStruct DonkehFramework.WeaponAnimSequence
// Size: 0x10(Inherited: 0x0) 
struct FWeaponAnimSequence
{
	struct UAnimSequence* CharAnim;  // 0x0(0x8)
	struct UAnimSequence* WeapAnim;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.GetLeanYOffset
// Size: 0x8(Inherited: 0x0) 
struct FGetLeanYOffset
{
	float DesiredLeanAmt;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// ScriptStruct DonkehFramework.WeaponAnimMontage
// Size: 0x10(Inherited: 0x0) 
struct FWeaponAnimMontage
{
	struct UAnimMontage* CharAnim;  // 0x0(0x8)
	struct UAnimMontage* WeapAnim;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.BanPlayerByName
// Size: 0x30(Inherited: 0x0) 
struct FBanPlayerByName
{
	struct FString BannedPlayerName;  // 0x0(0x10)
	struct FText BanReason;  // 0x10(0x18)
	float BanDuration;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsVaulting
// Size: 0x1(Inherited: 0x0) 
struct FIsVaulting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction DonkehFramework.GameStatePSAddRemove__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FGameStatePSAddRemove__DelegateSignature
{
	struct APlayerState* PlayerState;  // 0x0(0x8)

}; 
// DelegateFunction DonkehFramework.GameStateTSAddRemove__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FGameStateTSAddRemove__DelegateSignature
{
	struct ADFTeamState* TeamState;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponThrowUnderhandMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponThrowUnderhandMontage
{
	struct UAnimMontage* ThrowUnderhandMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetShotCounterBPCompat
// Size: 0x8(Inherited: 0x0) 
struct FGetShotCounterBPCompat
{
	struct FRepShotInfo Counter;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// DelegateFunction DonkehFramework.InventoryOnItemAddedSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FInventoryOnItemAddedSignature__DelegateSignature
{
	struct ADFBaseItem* AddedItem;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFGameRulesetBase.GetGameMode
// Size: 0x8(Inherited: 0x0) 
struct FGetGameMode
{
	struct ADFBaseGameMode* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct DonkehFramework.AssetDescriptor
// Size: 0x20(Inherited: 0x0) 
struct FAssetDescriptor
{
	struct FName AssetName;  // 0x0(0x8)
	struct FText DisplayText;  // 0x8(0x18)

}; 
// Function DonkehFramework.DFBaseGameMode.KickPlayerById
// Size: 0x28(Inherited: 0x0) 
struct FKickPlayerById
{
	int32_t KickedPlayerId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText KickReason;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBaseWeapon.StopWeaponMontage
// Size: 0x8(Inherited: 0x0) 
struct FStopWeaponMontage
{
	struct UAnimMontage* WeapMontage;  // 0x0(0x8)

}; 
// DelegateFunction DonkehFramework.InventoryOnItemRemovedSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FInventoryOnItemRemovedSignature__DelegateSignature
{
	struct ADFBaseItem* RemovedItem;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.ClampSpeedMultiplier
// Size: 0x8(Inherited: 0x0) 
struct FClampSpeedMultiplier
{
	float MultValue;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// ScriptStruct DonkehFramework.CharacterSoundCollection
// Size: 0x10(Inherited: 0x0) 
struct FCharacterSoundCollection
{
	struct FPerspectiveSound DeathSound;  // 0x0(0x10)

}; 
// DelegateFunction DonkehFramework.DFNetworkEventSubsystem.OnGameStateEventDynamic__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnGameStateEventDynamic__DelegateSignature
{
	struct AGameStateBase* GameState;  // 0x0(0x8)

}; 
// DelegateFunction DonkehFramework.GunReloadSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FGunReloadSignature__DelegateSignature
{
	struct ADFBaseGun* Gun;  // 0x0(0x8)

}; 
// DelegateFunction DonkehFramework.GunFireModeSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FGunFireModeSignature__DelegateSignature
{
	struct ADFBaseGun* Gun;  // 0x0(0x8)
	uint8_t  NewFireMode;  // 0x8(0x1)
	uint8_t  PrevFireMode;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bFromPlayerInput : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// SparseDelegateFunction DonkehFramework.GunProjProcessCSHitSignature__DelegateSignature
// Size: 0x90(Inherited: 0x0) 
struct FGunProjProcessCSHitSignature__DelegateSignature
{
	struct ADFBaseGun_Projectile* Gun;  // 0x0(0x8)
	struct FHitResult SimulatedCSHitResult;  // 0x8(0x88)

}; 
// Function DonkehFramework.DFBaseCharacter.SetHealth
// Size: 0x4(Inherited: 0x0) 
struct FSetHealth
{
	float InHealth;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseGun.OnReload
// Size: 0x1(Inherited: 0x0) 
struct FOnReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerState.GetAssists
// Size: 0x4(Inherited: 0x0) 
struct FGetAssists
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// SparseDelegateFunction DonkehFramework.ProjectileProcessHitSignature__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FProjectileProcessHitSignature__DelegateSignature
{
	struct ADFBaseProjectile* Projectile;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector HitLocation;  // 0x18(0xC)
	struct FVector HitNormal;  // 0x24(0xC)
	struct FHitResult HitResult;  // 0x30(0x88)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bFromCSHitNotify : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterEndReloadMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterEndReloadMontage
{
	struct UAnimMontage* EndReloadMontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDryReload : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseItem.OwnerIsAiming
// Size: 0x1(Inherited: 0x0) 
struct FOwnerIsAiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.GetMontageToUseFromPerspectiveAnimPair
// Size: 0x18(Inherited: 0x0) 
struct FGetMontageToUseFromPerspectiveAnimPair
{
	struct FPerspectiveAnim AnimationPair;  // 0x0(0x10)
	struct UAnimMontage* ReturnValue;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.ReceiveOnSwapAIControllers
// Size: 0x10(Inherited: 0x0) 
struct FReceiveOnSwapAIControllers
{
	struct AAIController* OldAIC;  // 0x0(0x8)
	struct AAIController* NewAIC;  // 0x8(0x8)

}; 
// ScriptStruct DonkehFramework.PlayerChatMsg
// Size: 0x30(Inherited: 0x0) 
struct FPlayerChatMsg
{
	struct APlayerState* SenderPS;  // 0x0(0x8)
	struct FString SenderName;  // 0x8(0x10)
	char MsgTeamId;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString MsgContent;  // 0x20(0x10)

}; 
// SparseDelegateFunction DonkehFramework.ProjectileTriggerPayloadSignature__DelegateSignature
// Size: 0x98(Inherited: 0x0) 
struct FProjectileTriggerPayloadSignature__DelegateSignature
{
	struct ADFBaseProjectile* Projectile;  // 0x0(0x8)
	struct FHitResult ImpactHitResult;  // 0x8(0x88)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bFromTearOff : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
// DelegateFunction DonkehFramework.PlayerToggleFirstPerson__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FPlayerToggleFirstPerson__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFirstPerson : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.GameSessionBlueprintLibrary.GetMinPlayers
// Size: 0x10(Inherited: 0x0) 
struct FGetMinPlayers
{
	struct UObject* WorldContextObj;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct DonkehFramework.SpawnPointDef
// Size: 0x50(Inherited: 0x0) 
struct FSpawnPointDef
{
	int32_t SpawnID;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform SpawnTransform;  // 0x10(0x30)
	struct UObject* SpawnContextObject;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)

}; 
// DelegateFunction DonkehFramework.RepPlayerNameSignature__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FRepPlayerNameSignature__DelegateSignature
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct FString NewPlayerName;  // 0x8(0x10)

}; 
// Function DonkehFramework.DFBaseItem.GetOwnerViewRotation
// Size: 0xC(Inherited: 0x0) 
struct FGetOwnerViewRotation
{
	struct FRotator ReturnValue;  // 0x0(0xC)

}; 
// Function DonkehFramework.DFBlueprintFunctions.FlushPressedKeys
// Size: 0x8(Inherited: 0x0) 
struct FFlushPressedKeys
{
	struct APlayerController* PC;  // 0x0(0x8)

}; 
// DelegateFunction DonkehFramework.PlayerTeamNumUpdateSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FPlayerTeamNumUpdateSignature__DelegateSignature
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	char LastTeamNum;  // 0x8(0x1)
	char NewTeamNum;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function DonkehFramework.DFNetworkEventSubsystem.Get
// Size: 0x10(Inherited: 0x0) 
struct FGet
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UDFNetworkEventSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.ReceivePlayHit
// Size: 0x30(Inherited: 0x0) 
struct FReceivePlayHit
{
	float DamageTaken;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDamageEvent DamageEvent;  // 0x8(0x10)
	struct APawn* PawnInstigator;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bKilled : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function DonkehFramework.GameSessionBlueprintLibrary.GetMaxSpectators
// Size: 0x10(Inherited: 0x0) 
struct FGetMaxSpectators
{
	struct UObject* WorldContextObj;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction DonkehFramework.TSInitSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FTSInitSignature__DelegateSignature
{
	struct ADFTeamState* TeamState;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseWeapon.GetWeaponMesh1P
// Size: 0x8(Inherited: 0x0) 
struct FGetWeaponMesh1P
{
	struct USkeletalMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct DonkehFramework.DFPropertyAssetBundles
// Size: 0x1(Inherited: 0x0) 
struct FDFPropertyAssetBundles
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.DFCharacterVariationDataSource
// Size: 0x8(Inherited: 0x0) 
struct FDFCharacterVariationDataSource
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsEmptyOrWhitespace
// Size: 0x18(Inherited: 0x0) 
struct FIsEmptyOrWhitespace
{
	struct FString inString;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct DonkehFramework.DFGenericObjectContainer
// Size: 0x180(Inherited: 0x108) 
struct FDFGenericObjectContainer : public FFastArraySerializer
{
	struct TArray<struct FDFGenericObject> GenericObjects;  // 0x108(0x10)
	char pad_280[8];  // 0x118(0x8)
	UObject* RequiredClass;  // 0x120(0x8)
	char pad_296[88];  // 0x128(0x58)

}; 
// ScriptStruct DonkehFramework.WeaponAnim
// Size: 0x10(Inherited: 0x0) 
struct FWeaponAnim
{
	struct UAnimSequenceBase* CharAnim;  // 0x0(0x8)
	struct UAnimSequenceBase* WeapAnim;  // 0x8(0x8)

}; 
// ScriptStruct DonkehFramework.PerspectiveSound
// Size: 0x10(Inherited: 0x0) 
struct FPerspectiveSound
{
	struct USoundBase* Sound1P;  // 0x0(0x8)
	struct USoundBase* Sound3P;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerSuicide
// Size: 0x8(Inherited: 0x0) 
struct FPlayerSuicide
{
	struct AController* Victim;  // 0x0(0x8)

}; 
// ScriptStruct DonkehFramework.DFGenericObject
// Size: 0x28(Inherited: 0xC) 
struct FDFGenericObject : public FFastArraySerializerItem
{
	char pad_12[4];  // 0xC(0x4)
	struct UObject* Object;  // 0x10(0x8)
	char pad_24[8];  // 0x18(0x8)
	char bPendingRemoval : 1;  // 0x20(0x1)
	char bPredictivelyRemoved : 1;  // 0x20(0x1)
	char pad_32_1 : 6;  // 0x20(0x1)
	char pad_33[8];  // 0x21(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetVOIPTalkerForPlayer
// Size: 0x10(Inherited: 0x0) 
struct FGetVOIPTalkerForPlayer
{
	struct APlayerState* InPlayerState;  // 0x0(0x8)
	struct UVOIPTalker* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct DonkehFramework.DFVaultTraceData
// Size: 0x18(Inherited: 0x0) 
struct FDFVaultTraceData
{
	struct FDFVaultTargetParams TargetParams;  // 0x0(0x10)
	uint8_t  Behavior;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float Height;  // 0x14(0x4)

}; 
// Function DonkehFramework.DFBaseGameInstance.IsHibernating
// Size: 0x1(Inherited: 0x0) 
struct FIsHibernating
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.DFVaultTargetParams
// Size: 0x10(Inherited: 0x0) 
struct FDFVaultTargetParams
{
	uint8_t  DesiredBehavior;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector_NetQuantize10 Location;  // 0x4(0xC)

}; 
// Function DonkehFramework.SpawnPointStatics.CanSpawnActorFromAnySpawnPoint
// Size: 0x18(Inherited: 0x0) 
struct FCanSpawnActorFromAnySpawnPoint
{
	struct UObject* Target;  // 0x0(0x8)
	AActor* SpawnActorClass;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct DonkehFramework.AnimMontagePlaybackParams
// Size: 0x10(Inherited: 0x0) 
struct FAnimMontagePlaybackParams
{
	struct UAnimMontage* Montage;  // 0x0(0x8)
	struct USkeletalMeshComponent* SourceMeshComp;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBasePlayerController.IsGameInputAllowed
// Size: 0x1(Inherited: 0x0) 
struct FIsGameInputAllowed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.LocomotionWeaponAnimSubset
// Size: 0x18(Inherited: 0x0) 
struct FLocomotionWeaponAnimSubset
{
	struct UAnimSequence* Idle;  // 0x0(0x8)
	struct UAnimSequence* Move;  // 0x8(0x8)
	struct UAnimSequence* Sprint;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFBasePlayerState.GetPreviousTeam
// Size: 0x1(Inherited: 0x0) 
struct FGetPreviousTeam
{
	char ReturnValue;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.DFVaultTraceResult
// Size: 0x1C(Inherited: 0x18) 
struct FDFVaultTraceResult : public FDFVaultTraceData
{
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// Function DonkehFramework.DFBaseItem.GetOwnerViewPoint
// Size: 0x1C(Inherited: 0x0) 
struct FGetOwnerViewPoint
{
	struct FVector OutViewLoc;  // 0x0(0xC)
	struct FRotator OutViewRot;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)

}; 
// ScriptStruct DonkehFramework.DFCharacterVariationDataHandle
// Size: 0x18(Inherited: 0x0) 
struct FDFCharacterVariationDataHandle
{
	char pad_0[24];  // 0x0(0x18)

}; 
// Function DonkehFramework.DFBaseCharacter.GetCharacterAnimTickOptionToUse
// Size: 0x2(Inherited: 0x0) 
struct FGetCharacterAnimTickOptionToUse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisibleMesh : 1;  // 0x0(0x1)
	uint8_t  ReturnValue;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.StopWeaponPerspectiveAnimation
// Size: 0x10(Inherited: 0x0) 
struct FStopWeaponPerspectiveAnimation
{
	struct FPerspectiveAnim WeapAnim;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBaseAmmoClip.GetStartingClipAmmo
// Size: 0x4(Inherited: 0x0) 
struct FGetStartingClipAmmo
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct DonkehFramework.DFCharacterVariationDataSource_TableRow
// Size: 0x20(Inherited: 0x8) 
struct FDFCharacterVariationDataSource_TableRow : public FDFCharacterVariationDataSource
{
	struct FDataTableRowHandle RowHandle;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bValidRowHandle : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFramework.DFFunctionLibrary.ClearMeshAnimInstance
// Size: 0x8(Inherited: 0x0) 
struct FClearMeshAnimInstance
{
	struct USkeletalMeshComponent* MeshToClear;  // 0x0(0x8)

}; 
// ScriptStruct DonkehFramework.PerspectiveAnimSequence
// Size: 0x10(Inherited: 0x0) 
struct FPerspectiveAnimSequence
{
	struct UAnimSequence* Anim1P;  // 0x0(0x8)
	struct UAnimSequence* Anim3P;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseGun.GetMuzzleLocation
// Size: 0x10(Inherited: 0x0) 
struct FGetMuzzleLocation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnoreLocalControlOnServer : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector ReturnValue;  // 0x4(0xC)

}; 
// ScriptStruct DonkehFramework.DFCharacterVariationData
// Size: 0x68(Inherited: 0x8) 
struct FDFCharacterVariationData : public FTableRowBase
{
	struct FDFCharacterVariation Variation;  // 0x8(0x30)
	struct FDFCharacterVariation VariationFPP;  // 0x38(0x30)

}; 
// Function DonkehFramework.DFBaseWeapon.GetAnimPlayLengthToUseFromPerspectiveAnimPair
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimPlayLengthToUseFromPerspectiveAnimPair
{
	struct FPerspectiveAnim AnimationPair;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function DonkehFramework.DFBasePlayerController.IsServerAdministrator
// Size: 0x1(Inherited: 0x0) 
struct FIsServerAdministrator
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.GetLeanAmount
// Size: 0x4(Inherited: 0x0) 
struct FGetLeanAmount
{
	float ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct DonkehFramework.DFCharacterVariation
// Size: 0x30(Inherited: 0x0) 
struct FDFCharacterVariation
{
	char pad_0[8];  // 0x0(0x8)
	struct TSoftObjectPtr<USkeletalMesh> Mesh;  // 0x8(0x28)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.GetOwningCharacterMovement
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningCharacterMovement
{
	struct UDFCharacterMovementComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponCockMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponCockMontage
{
	struct UAnimMontage* CockMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayCockMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCockMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// ScriptStruct DonkehFramework.WeaponSoundCollection
// Size: 0x80(Inherited: 0x0) 
struct FWeaponSoundCollection
{
	struct FPerspectiveSound EquipSound;  // 0x0(0x10)
	struct FPerspectiveSound UnEquipSound;  // 0x10(0x10)
	struct FPerspectiveSound FireSound;  // 0x20(0x10)
	struct FPerspectiveSound FireLastSound;  // 0x30(0x10)
	struct FPerspectiveSound DryFireSound;  // 0x40(0x10)
	struct FPerspectiveSound ReloadSound;  // 0x50(0x10)
	struct FPerspectiveSound ReloadFullSound;  // 0x60(0x10)
	struct FPerspectiveSound FireModeSound;  // 0x70(0x10)

}; 
// Function DonkehFramework.DFBaseGameInstance.OnNetworkFailure
// Size: 0x28(Inherited: 0x0) 
struct FOnNetworkFailure
{
	struct UWorld* World;  // 0x0(0x8)
	struct UNetDriver* NetDriver;  // 0x8(0x8)
	char ENetworkFailure FailureType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString ErrorString;  // 0x18(0x10)

}; 
// ScriptStruct DonkehFramework.CSHitInfo
// Size: 0x70(Inherited: 0x0) 
struct FCSHitInfo
{
	char bBlockingHit : 1;  // 0x0(0x1)
	char pad_0_1 : 7;  // 0x0(0x1)
	char pad_1[4];  // 0x1(0x4)
	float Distance;  // 0x4(0x4)
	struct FVector_NetQuantize Location;  // 0x8(0xC)
	struct FVector_NetQuantizeNormal Normal;  // 0x14(0xC)
	struct FName BoneName;  // 0x20(0x8)
	struct FVector_NetQuantize ShootLoc;  // 0x28(0xC)
	struct FVector_NetQuantizeNormal ShootDir;  // 0x34(0xC)
	struct FVector_NetQuantize TraceStart;  // 0x40(0xC)
	struct FVector_NetQuantize TraceEnd;  // 0x4C(0xC)
	struct TWeakObjectPtr<AActor> Actor;  // 0x58(0x8)
	struct TWeakObjectPtr<UPrimitiveComponent> Component;  // 0x60(0x8)
	struct TWeakObjectPtr<AController> InstigatingController;  // 0x68(0x8)

}; 
// Function DonkehFramework.DFFunctionLibrary.SetEnableAutoBlendOutForActiveMontage
// Size: 0x18(Inherited: 0x0) 
struct FSetEnableAutoBlendOutForActiveMontage
{
	struct UAnimMontage* AnimMontage;  // 0x0(0x8)
	struct USkeletalMeshComponent* AnimSourceMesh;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bNewEnableAutoBlendOut : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct DonkehFramework.PerspectiveAnim
// Size: 0x10(Inherited: 0x0) 
struct FPerspectiveAnim
{
	struct UAnimSequenceBase* Anim1P;  // 0x0(0x8)
	struct UAnimSequenceBase* Anim3P;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBasePlayerController.ReceivePreClientTravel
// Size: 0x18(Inherited: 0x0) 
struct FReceivePreClientTravel
{
	struct FString PendingURL;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsSeamlessTravelWithRelativeTravelType : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct DonkehFramework.ThrowableWeaponAnimSubset
// Size: 0x20(Inherited: 0x0) 
struct FThrowableWeaponAnimSubset
{
	struct UAnimSequence* ReadyBasePose;  // 0x0(0x8)
	struct UAnimMontage* Cock;  // 0x8(0x8)
	struct UAnimMontage* ThrowOverhand;  // 0x10(0x8)
	struct UAnimMontage* ThrowUnderhand;  // 0x18(0x8)

}; 
// Function DonkehFramework.DFBaseItem.CanAimWhileEquipped
// Size: 0x1(Inherited: 0x0) 
struct FCanAimWhileEquipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.CanDealDamage
// Size: 0x18(Inherited: 0x0) 
struct FCanDealDamage
{
	struct ADFBasePlayerState* DamageInstigator;  // 0x0(0x8)
	struct ADFBasePlayerState* DamagedPlayer;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct DonkehFramework.SingleLoadWeaponAnimSubset
// Size: 0x10(Inherited: 0x0) 
struct FSingleLoadWeaponAnimSubset
{
	struct UAnimMontage* StartReload;  // 0x0(0x8)
	struct UAnimMontage* EndReload;  // 0x8(0x8)

}; 
// ScriptStruct DonkehFramework.SingleActionWeaponAnimSubset
// Size: 0x8(Inherited: 0x0) 
struct FSingleActionWeaponAnimSubset
{
	struct UAnimMontage* Action;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimMontage
// Size: 0x28(Inherited: 0x0) 
struct FEqualEqual_WeaponAnimMontage
{
	struct FWeaponAnimMontage A;  // 0x0(0x10)
	struct FWeaponAnimMontage B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.CanVault
// Size: 0x1(Inherited: 0x0) 
struct FCanVault
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.IsUsingFirstPersonMesh
// Size: 0x1(Inherited: 0x0) 
struct FIsUsingFirstPersonMesh
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.IntrinsicWeaponAnimSubset
// Size: 0x28(Inherited: 0x0) 
struct FIntrinsicWeaponAnimSubset
{
	struct UAnimMontage* Equip;  // 0x0(0x8)
	struct UAnimMontage* UnEquip;  // 0x8(0x8)
	struct UAnimMontage* Fire;  // 0x10(0x8)
	struct UAnimMontage* Reload;  // 0x18(0x8)
	struct UAnimMontage* ReloadEmpty;  // 0x20(0x8)

}; 
// ScriptStruct DonkehFramework.WeaponAnimCollection
// Size: 0xF0(Inherited: 0x0) 
struct FWeaponAnimCollection
{
	struct UAnimSequence* BasePose;  // 0x0(0x8)
	struct UAnimSequence* EmptyBasePose;  // 0x8(0x8)
	struct FIntrinsicWeaponAnimSubset Intrinsic;  // 0x10(0x28)
	struct FSingleActionWeaponAnimSubset SingleAction;  // 0x38(0x8)
	struct FSingleLoadWeaponAnimSubset SingleLoad;  // 0x40(0x10)
	struct FThrowableWeaponAnimSubset Throwable;  // 0x50(0x20)
	struct FPerspectiveAnim EquipAnim;  // 0x70(0x10)
	struct FPerspectiveAnim UnEquipAnim;  // 0x80(0x10)
	struct FPerspectiveAnim FireAnim;  // 0x90(0x10)
	struct FPerspectiveAnim ActionAnim;  // 0xA0(0x10)
	struct FPerspectiveAnim ReloadAnim;  // 0xB0(0x10)
	struct FPerspectiveAnim ReloadFullAnim;  // 0xC0(0x10)
	struct FPerspectiveAnim StartReloadAnim;  // 0xD0(0x10)
	struct FPerspectiveAnim EndReloadAnim;  // 0xE0(0x10)

}; 
// Function DonkehFramework.DFBaseAmmoClip.IsLoaded
// Size: 0x1(Inherited: 0x0) 
struct FIsLoaded
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFramework.PerspectiveSkeletalMesh
// Size: 0x10(Inherited: 0x0) 
struct FPerspectiveSkeletalMesh
{
	struct USkeletalMesh* Mesh1P;  // 0x0(0x8)
	struct USkeletalMesh* Mesh3P;  // 0x8(0x8)

}; 
// ScriptStruct DonkehFramework.RepShotInfo
// Size: 0x4(Inherited: 0x0) 
struct FRepShotInfo
{
	uint16_t ShotCounter;  // 0x0(0x2)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bIsFiring : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bCompressByte : 1;  // 0x3(0x1)

}; 
// Function DonkehFramework.DFPlayerComponent.GetPawnOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetPawnOwner
{
	struct APawn* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.CreateTeam
// Size: 0x18(Inherited: 0x0) 
struct FCreateTeam
{
	struct UDFTeamDefinition* NewTeamDef;  // 0x0(0x8)
	char NewTeamIdToUse;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ADFTeamState* ReturnValue;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFBaseItem.OnRep_PawnOwner
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_PawnOwner
{
	struct ADFBaseCharacter* LastOwner;  // 0x0(0x8)

}; 
// ScriptStruct DonkehFramework.DFDamageParams
// Size: 0x14(Inherited: 0x14) 
struct FDFDamageParams : public FRadialDamageParams
{

}; 
// ScriptStruct DonkehFramework.DecalData
// Size: 0x10(Inherited: 0x0) 
struct FDecalData
{
	struct UMaterialInterface* DecalMaterial;  // 0x0(0x8)
	float DecalSize;  // 0x8(0x4)
	float LifeSpan;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBasePlayerController.GetUnFreezeTimerHandle
// Size: 0x8(Inherited: 0x0) 
struct FGetUnFreezeTimerHandle
{
	struct FTimerHandle ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerState.OnRep_bAdmin
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_bAdmin
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAdminStatusBeforeUpdate : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFPlayerComponent.CanRestartPlayer
// Size: 0x1(Inherited: 0x0) 
struct FCanRestartPlayer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.SetOwningPawn
// Size: 0x8(Inherited: 0x0) 
struct FSetOwningPawn
{
	struct ADFBaseCharacter* NewOwner;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.CanEquip
// Size: 0x1(Inherited: 0x0) 
struct FCanEquip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.CanFire
// Size: 0x1(Inherited: 0x0) 
struct FCanFire
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePickup.GivePickupTo
// Size: 0x8(Inherited: 0x0) 
struct FGivePickupTo
{
	struct ADFBaseCharacter* PickupOwner;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.CanSprintWhileEquipped
// Size: 0x1(Inherited: 0x0) 
struct FCanSprintWhileEquipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.CanStartFire
// Size: 0x1(Inherited: 0x0) 
struct FCanStartFire
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.CanTriggerFire
// Size: 0x1(Inherited: 0x0) 
struct FCanTriggerFire
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerPostLogin
// Size: 0x8(Inherited: 0x0) 
struct FPlayerPostLogin
{
	struct APlayerController* NewPlayer;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.GetAdjustedAimDirection
// Size: 0xC(Inherited: 0x0) 
struct FGetAdjustedAimDirection
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function DonkehFramework.DFBaseGameMode.IsFriendlyFireEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsFriendlyFireEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.GetItemMesh
// Size: 0x8(Inherited: 0x0) 
struct FGetItemMesh
{
	struct UStaticMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.GetItemMesh1P
// Size: 0x8(Inherited: 0x0) 
struct FGetItemMesh1P
{
	struct UStaticMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.GetItemMeshToUse
// Size: 0x10(Inherited: 0x0) 
struct FGetItemMeshToUse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnoreLocalControlOnServer : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UStaticMeshComponent* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseItem.GetItemType
// Size: 0x1(Inherited: 0x0) 
struct FGetItemType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.GetLegacyLocomotionAnims
// Size: 0x58(Inherited: 0x0) 
struct FGetLegacyLocomotionAnims
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFPP : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TMap<struct FName, struct UAnimSequenceBase*> ReturnValue;  // 0x8(0x50)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveAnimSequence
// Size: 0x28(Inherited: 0x0) 
struct FEqualEqual_PerspectiveAnimSequence
{
	struct FPerspectiveAnimSequence A;  // 0x0(0x10)
	struct FPerspectiveAnimSequence B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBaseItem.GetOwnerViewLocation
// Size: 0xC(Inherited: 0x0) 
struct FGetOwnerViewLocation
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function DonkehFramework.DFPlayerComponent.GetMinRestartDelay
// Size: 0x4(Inherited: 0x0) 
struct FGetMinRestartDelay
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseItem.GetPawnInventory
// Size: 0x8(Inherited: 0x0) 
struct FGetPawnInventory
{
	struct UDFInventoryComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.GetSpecificItemType
// Size: 0x1(Inherited: 0x0) 
struct FGetSpecificItemType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.GetNumFreeAmmoClips
// Size: 0x8(Inherited: 0x0) 
struct FGetNumFreeAmmoClips
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIncludeEmptyMags : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bIncludeCurrentMag : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataPreviewBannerImg
// Size: 0x80(Inherited: 0x0) 
struct FGetMapAssetDataPreviewBannerImg
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct TSoftObjectPtr<UTexture2D> OutMapPreviewBannerImgRef;  // 0x50(0x28)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function DonkehFramework.DFBaseItem.IsClientSimulated
// Size: 0x1(Inherited: 0x0) 
struct FIsClientSimulated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.StopSimulatingWeaponFire
// Size: 0x1(Inherited: 0x0) 
struct FStopSimulatingWeaponFire
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bForceStopAll : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.SetFireMode
// Size: 0x4(Inherited: 0x0) 
struct FSetFireMode
{
	uint8_t  NewFireMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bFromPlayerInput : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bForce : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool ReturnValue : 1;  // 0x3(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.IsEquipped
// Size: 0x1(Inherited: 0x0) 
struct FIsEquipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.IsEquipping
// Size: 0x1(Inherited: 0x0) 
struct FIsEquipping
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.IsLocallyControlled
// Size: 0x1(Inherited: 0x0) 
struct FIsLocallyControlled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameInstance.HostGame
// Size: 0x38(Inherited: 0x0) 
struct FHostGame
{
	struct FString TravelURL;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bLANGame : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t MaxPlayers;  // 0x14(0x4)
	struct FString HostName;  // 0x18(0x10)
	struct FString Password;  // 0x28(0x10)

}; 
// Function DonkehFramework.DFBaseItem.IsUnEquipping
// Size: 0x1(Inherited: 0x0) 
struct FIsUnEquipping
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponSound
// Size: 0x18(Inherited: 0x0) 
struct FPlayWeaponSound
{
	struct FPerspectiveSound Sound;  // 0x0(0x10)
	struct UAudioComponent* ReturnValue;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFBaseItem.OnEnterInventory
// Size: 0x10(Inherited: 0x0) 
struct FOnEnterInventory
{
	struct ADFBaseCharacter* NewOwner;  // 0x0(0x8)
	struct ADFBaseCharacter* LastOwner;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseItem.OnEquip
// Size: 0x8(Inherited: 0x0) 
struct FOnEquip
{
	struct ADFBaseItem* LastItem;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.ReceiveEquippedItemChanged
// Size: 0x10(Inherited: 0x0) 
struct FReceiveEquippedItemChanged
{
	struct ADFBaseItem* NewEquippedItem;  // 0x0(0x8)
	struct ADFBaseItem* PrevEquippedItem;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseItem.OnLeaveInventory
// Size: 0x8(Inherited: 0x0) 
struct FOnLeaveInventory
{
	struct ADFBaseCharacter* LastOwner;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.OnUnEquip
// Size: 0x2(Inherited: 0x0) 
struct FOnUnEquip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPlayAnimAndWait : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bLeavingPawnInventory : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBasePlayerController.Say
// Size: 0x10(Inherited: 0x0) 
struct FSay
{
	struct FString Msg;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetCopyrightNotice
// Size: 0x10(Inherited: 0x0) 
struct FGetCopyrightNotice
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBaseItem.OwnerIsSprinting
// Size: 0x1(Inherited: 0x0) 
struct FOwnerIsSprinting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseProjectile.HasValidPredictedClientProjectile
// Size: 0x1(Inherited: 0x0) 
struct FHasValidPredictedClientProjectile
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.ReceiveOnEnterInventory
// Size: 0x10(Inherited: 0x0) 
struct FReceiveOnEnterInventory
{
	struct ADFBaseCharacter* NewOwner;  // 0x0(0x8)
	struct ADFBaseCharacter* LastOwner;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseItem.ReceiveOnEquip
// Size: 0x8(Inherited: 0x0) 
struct FReceiveOnEquip
{
	struct ADFBaseItem* LastItem;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseItem.ReceiveOnLeaveInventory
// Size: 0x8(Inherited: 0x0) 
struct FReceiveOnLeaveInventory
{
	struct ADFBaseCharacter* LastOwner;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.SpawnImpactFXFromHitResult
// Size: 0xA0(Inherited: 0x0) 
struct FSpawnImpactFXFromHitResult
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	ADFBaseImpactEffect* ImpactClass;  // 0x8(0x8)
	struct FHitResult Impact;  // 0x10(0x88)
	struct ADFBaseImpactEffect* ReturnValue;  // 0x98(0x8)

}; 
// Function DonkehFramework.DFBaseItem.ReceiveOnUnEquip
// Size: 0x2(Inherited: 0x0) 
struct FReceiveOnUnEquip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPlayAnimAndWait : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bLeavingPawnInventory : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBaseItem.ReceiveOnUnEquipFinished
// Size: 0x1(Inherited: 0x0) 
struct FReceiveOnUnEquipFinished
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLeavingPawnInventory : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.ReceiveVisibilityChanged
// Size: 0x1(Inherited: 0x0) 
struct FReceiveVisibilityChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFirstPerson : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseItem.RemoveLegacyLocomotionAnims
// Size: 0x2(Inherited: 0x0) 
struct FRemoveLegacyLocomotionAnims
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFPP : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBaseItem.ServerStartFire
// Size: 0x24(Inherited: 0x0) 
struct FServerStartFire
{
	struct FVector_NetQuantize Origin;  // 0x0(0xC)
	struct FVector_NetQuantizeNormal ShootDir;  // 0xC(0xC)
	int32_t RandomSeed;  // 0x18(0x4)
	float Timestamp;  // 0x1C(0x4)
	int32_t ShotID;  // 0x20(0x4)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.SetMeshVisibility
// Size: 0x1(Inherited: 0x0) 
struct FSetMeshVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFirstPersonVisibility : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimSequence
// Size: 0x28(Inherited: 0x0) 
struct FEqualEqual_WeaponAnimSequence
{
	struct FWeaponAnimSequence A;  // 0x0(0x10)
	struct FWeaponAnimSequence B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBaseAmmoClip.ConsumeAmmo
// Size: 0x4(Inherited: 0x0) 
struct FConsumeAmmo
{
	int32_t AmmoToConsume;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseAmmoClip.GetCurrentClipAmmo
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentClipAmmo
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseAmmoClip.GetGunOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetGunOwner
{
	struct ADFBaseGun* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseAmmoClip.GetMaxClipAmmo
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxClipAmmo
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseAmmoClip.SetOwningGun
// Size: 0x8(Inherited: 0x0) 
struct FSetOwningGun
{
	struct ADFBaseGun* NewOwner;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.ForceTeamId
// Size: 0x8(Inherited: 0x0) 
struct FForceTeamId
{
	int32_t SwitchedPlayerId;  // 0x0(0x4)
	char TeamIdToAssign;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// Function DonkehFramework.DFBaseAmmoClip.StoreAmmo
// Size: 0x4(Inherited: 0x0) 
struct FStoreAmmo
{
	int32_t AmmoToStore;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseAmmoClip.StoreAmmoInInventory
// Size: 0x20(Inherited: 0x0) 
struct FStoreAmmoInInventory
{
	struct UDFInventoryComponent* AmmoStore;  // 0x0(0x8)
	int32_t AmmoAmt;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	ADFBaseAmmoClip* AmmoType;  // 0x10(0x8)
	int32_t ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.GetLeanRollRot
// Size: 0x8(Inherited: 0x0) 
struct FGetLeanRollRot
{
	float DesiredLeanAmt;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.Aim
// Size: 0x1(Inherited: 0x0) 
struct FAim
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.AllowsWeaponFire
// Size: 0x1(Inherited: 0x0) 
struct FAllowsWeaponFire
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.UnAim
// Size: 0x1(Inherited: 0x0) 
struct FUnAim
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.CanAim
// Size: 0x1(Inherited: 0x0) 
struct FCanAim
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.CanDie
// Size: 0x30(Inherited: 0x0) 
struct FCanDie
{
	float KillingDamage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDamageEvent DamageEvent;  // 0x8(0x10)
	struct AController* Killer;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function DonkehFramework.DFBaseGun.ReceiveFireModeChanged
// Size: 0x3(Inherited: 0x0) 
struct FReceiveFireModeChanged
{
	uint8_t  NewFireMode;  // 0x0(0x1)
	uint8_t  PrevFireMode;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bFromPlayerInput : 1;  // 0x2(0x1)

}; 
// Function DonkehFramework.DFPlayerComponent.GetTeamState
// Size: 0x8(Inherited: 0x0) 
struct FGetTeamState
{
	struct ADFTeamState* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.CanGoProne
// Size: 0x1(Inherited: 0x0) 
struct FCanGoProne
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePickup.UpdatePickupState
// Size: 0x1(Inherited: 0x0) 
struct FUpdatePickupState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewActive : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.CanLean
// Size: 0x2(Inherited: 0x0) 
struct FCanLean
{
	uint8_t  DesiredLeanDir;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.CanSprint
// Size: 0x1(Inherited: 0x0) 
struct FCanSprint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.OnRep_CurrentAmmoClip
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_CurrentAmmoClip
{
	struct ADFBaseAmmoClip* PrevAmmoClip;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGun.GetTotalAmmo
// Size: 0x8(Inherited: 0x0) 
struct FGetTotalAmmo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIncludeLoadedMags : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ClearCharacterAnimInstances
// Size: 0x1(Inherited: 0x0) 
struct FClearCharacterAnimInstances
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPerspectiveMeshOnly : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.IsPlayer
// Size: 0x1(Inherited: 0x0) 
struct FIsPlayer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponFireMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponFireMontage
{
	struct UAnimMontage* FireMontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFireLast : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bFireADS : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ClientAdjustPosition_CustomStamina
// Size: 0x38(Inherited: 0x0) 
struct FClientAdjustPosition_CustomStamina
{
	float Timestamp;  // 0x0(0x4)
	struct FVector NewLoc;  // 0x4(0xC)
	struct FVector NewVel;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	struct UPrimitiveComponent* NewBase;  // 0x20(0x8)
	struct FName NewBaseBoneName;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bHasBase : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bBaseRelativePosition : 1;  // 0x31(0x1)
	char ServerMovementMode;  // 0x32(0x1)
	char pad_51[1];  // 0x33(0x1)
	float ServerSprintStamina;  // 0x34(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ClientAdjustRootMotionPosition_CustomStamina
// Size: 0x40(Inherited: 0x0) 
struct FClientAdjustRootMotionPosition_CustomStamina
{
	float Timestamp;  // 0x0(0x4)
	float ServerMontageTrackPosition;  // 0x4(0x4)
	struct FVector ServerLoc;  // 0x8(0xC)
	struct FVector_NetQuantizeNormal ServerRotation;  // 0x14(0xC)
	float ServerVelZ;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UPrimitiveComponent* ServerBase;  // 0x28(0x8)
	struct FName ServerBoneName;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bHasBase : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bBaseRelativePosition : 1;  // 0x39(0x1)
	char ServerMovementMode;  // 0x3A(0x1)
	char pad_59[1];  // 0x3B(0x1)
	float ServerSprintStamina;  // 0x3C(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ClientAdjustRootMotionSourcePosition_CustomStamina
// Size: 0x80(Inherited: 0x0) 
struct FClientAdjustRootMotionSourcePosition_CustomStamina
{
	float Timestamp;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FRootMotionSourceGroup ServerRootMotion;  // 0x8(0x38)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bHasAnimRootMotion : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float ServerMontageTrackPosition;  // 0x44(0x4)
	struct FVector ServerLoc;  // 0x48(0xC)
	struct FVector_NetQuantizeNormal ServerRotation;  // 0x54(0xC)
	float ServerVelZ;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct UPrimitiveComponent* ServerBase;  // 0x68(0x8)
	struct FName ServerBoneName;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bHasBase : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool bBaseRelativePosition : 1;  // 0x79(0x1)
	char ServerMovementMode;  // 0x7A(0x1)
	char pad_123[1];  // 0x7B(0x1)
	float ServerSprintStamina;  // 0x7C(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.UnLean
// Size: 0x2(Inherited: 0x0) 
struct FUnLean
{
	uint8_t  UnDesiredLeanDir;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bClientSimulation : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBaseProjectile.GetProjectileUpdatedComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetProjectileUpdatedComponent
{
	struct USceneComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.ClientVeryShortAdjustPosition_CustomStamina
// Size: 0x28(Inherited: 0x0) 
struct FClientVeryShortAdjustPosition_CustomStamina
{
	float Timestamp;  // 0x0(0x4)
	struct FVector NewLoc;  // 0x4(0xC)
	struct UPrimitiveComponent* NewBase;  // 0x10(0x8)
	struct FName NewBaseBoneName;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bHasBase : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bBaseRelativePosition : 1;  // 0x21(0x1)
	char ServerMovementMode;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)
	float ServerSprintStamina;  // 0x24(0x4)

}; 
// Function DonkehFramework.DFBaseProjectile.K2_PostProcessValidHit
// Size: 0xB8(Inherited: 0x0) 
struct FK2_PostProcessValidHit
{
	struct AActor* OtherActor;  // 0x0(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct FHitResult HitResult;  // 0x28(0x88)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bFromCSHitNotify : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 
// Function DonkehFramework.DFBaseProjectileLegacy.ReceivePayloadActivated
// Size: 0x88(Inherited: 0x0) 
struct FReceivePayloadActivated
{
	struct FHitResult ImpactHitResult;  // 0x0(0x88)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterCockMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterCockMontage
{
	struct UAnimMontage* CockMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsStrafing
// Size: 0x8(Inherited: 0x0) 
struct FIsStrafing
{
	float Threshold;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function DonkehFramework.DFBaseCharacter.Die
// Size: 0x30(Inherited: 0x0) 
struct FDie
{
	float KillingDamage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDamageEvent DamageEvent;  // 0x8(0x10)
	struct AController* Killer;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.EquipItem
// Size: 0x8(Inherited: 0x0) 
struct FEquipItem
{
	struct ADFBaseItem* ItemToEquip;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.EquipNextItemByType
// Size: 0x1(Inherited: 0x0) 
struct FEquipNextItemByType
{
	uint8_t  ItemType;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayCockAnimations
// Size: 0x8(Inherited: 0x0) 
struct FPlayCockAnimations
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDontPlayAndReturnDominantPlayLengthOnly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseWeapon.ShouldSimulateWeaponFire
// Size: 0x1(Inherited: 0x0) 
struct FShouldSimulateWeaponFire
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.GetAimOffsets
// Size: 0xC(Inherited: 0x0) 
struct FGetAimOffsets
{
	struct FRotator ReturnValue;  // 0x0(0xC)

}; 
// Function DonkehFramework.DFBaseWeapon.GetAnimToUseFromPerspectiveAnimPair
// Size: 0x18(Inherited: 0x0) 
struct FGetAnimToUseFromPerspectiveAnimPair
{
	struct FPerspectiveAnim AnimationPair;  // 0x0(0x10)
	struct UAnimSequenceBase* ReturnValue;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFBaseWeapon.PrefireDelayElapsed
// Size: 0x1(Inherited: 0x0) 
struct FPrefireDelayElapsed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun_Projectile.CalcShotVector
// Size: 0x18(Inherited: 0x0) 
struct FCalcShotVector
{
	struct FVector OutProjOrigin;  // 0x0(0xC)
	struct FVector OutProjDir;  // 0xC(0xC)

}; 
// Function DonkehFramework.DFBaseCharacter.GetCharacterDeathMontageToUse
// Size: 0x10(Inherited: 0x0) 
struct FGetCharacterDeathMontageToUse
{
	struct UAnimMontage* OutCharDeathMontage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.IsPrefiring
// Size: 0x1(Inherited: 0x0) 
struct FIsPrefiring
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.GetCharacterMeshToUse
// Size: 0x10(Inherited: 0x0) 
struct FGetCharacterMeshToUse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnoreLocalControlOnServer : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USkeletalMeshComponent* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.GetDamageMultiplierByBoneName
// Size: 0x10(Inherited: 0x0) 
struct FGetDamageMultiplierByBoneName
{
	struct FName BoneName;  // 0x0(0x8)
	float DamageMultiplier;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function DonkehFramework.DFBaseCharacter.GetEquippedItem
// Size: 0x8(Inherited: 0x0) 
struct FGetEquippedItem
{
	struct ADFBaseItem* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.ShouldBotAutofill
// Size: 0x1(Inherited: 0x0) 
struct FShouldBotAutofill
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataNameForDisplay
// Size: 0x68(Inherited: 0x0) 
struct FGetMapAssetDataNameForDisplay
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct FText ReturnValue;  // 0x50(0x18)

}; 
// Function DonkehFramework.DFBaseCharacter.GetInventory
// Size: 0x8(Inherited: 0x0) 
struct FGetInventory
{
	struct UDFInventoryComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.GetItemAttachPoint
// Size: 0x8(Inherited: 0x0) 
struct FGetItemAttachPoint
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.ChooseTeam
// Size: 0x10(Inherited: 0x0) 
struct FChooseTeam
{
	struct ADFBasePlayerState* ForPlayerState;  // 0x0(0x8)
	char ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.ReceiveOnStartProne
// Size: 0x8(Inherited: 0x0) 
struct FReceiveOnStartProne
{
	float HalfHeightAdjust;  // 0x0(0x4)
	float ScaledHalfHeightAdjust;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.GetItemEnabledMode
// Size: 0x1(Inherited: 0x0) 
struct FGetItemEnabledMode
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.GetNextInventoryItem
// Size: 0x10(Inherited: 0x0) 
struct FGetNextInventoryItem
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEquippable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ADFBaseItem* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDescription
// Size: 0x28(Inherited: 0x0) 
struct FGetMapAssetDescription
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	struct FString OutMapDescription;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.GetPreviousInventoryItem
// Size: 0x10(Inherited: 0x0) 
struct FGetPreviousInventoryItem
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEquippable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ADFBaseItem* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.GetRelevantEquippedItem
// Size: 0x8(Inherited: 0x0) 
struct FGetRelevantEquippedItem
{
	struct ADFBaseItem* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.GiveLoadout
// Size: 0x10(Inherited: 0x0) 
struct FGiveLoadout
{
	struct UDFLoadout* Loadout;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEquipFirstItem : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.GoProne
// Size: 0x1(Inherited: 0x0) 
struct FGoProne
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsAlive
// Size: 0x1(Inherited: 0x0) 
struct FIsAlive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFGunRecoilHandler.IsFiring
// Size: 0x1(Inherited: 0x0) 
struct FIsFiring
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsLeaning
// Size: 0x1(Inherited: 0x0) 
struct FIsLeaning
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.IsPerspectiveMesh
// Size: 0x10(Inherited: 0x0) 
struct FIsPerspectiveMesh
{
	struct USkeletalMeshComponent* MeshCompToCheck;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.VaultTrace
// Size: 0x1C(Inherited: 0x0) 
struct FVaultTrace
{
	struct FDFVaultTraceResult ReturnValue;  // 0x0(0x1C)

}; 
// Function DonkehFramework.DFBaseCharacter.ItemEnabledModeChanged
// Size: 0x1(Inherited: 0x0) 
struct FItemEnabledModeChanged
{
	uint8_t  PreviousItemEnabledMode;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerJoinedTeam
// Size: 0x10(Inherited: 0x0) 
struct FPlayerJoinedTeam
{
	struct AController* JoiningPlayer;  // 0x0(0x8)
	char TeamNum;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseCharacter.Lean
// Size: 0x2(Inherited: 0x0) 
struct FLean
{
	uint8_t  DesiredLeanDir;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bClientSimulation : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_UInt8Sort
// Size: 0x18(Inherited: 0x0) 
struct FArray_UInt8Sort
{
	struct TArray<char> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFGunRecoilHandler.OnTick
// Size: 0x4(Inherited: 0x0) 
struct FOnTick
{
	float DeltaTime;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.TurnAtRate
// Size: 0x4(Inherited: 0x0) 
struct FTurnAtRate
{
	float Rate;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.LeanToggle
// Size: 0x1(Inherited: 0x0) 
struct FLeanToggle
{
	uint8_t  LeanDir;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.LeaveProne
// Size: 0x1(Inherited: 0x0) 
struct FLeaveProne
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.NextShotID
// Size: 0x4(Inherited: 0x0) 
struct FNextShotID
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseGun.SetFireModeBP
// Size: 0x1(Inherited: 0x0) 
struct FSetFireModeBP
{
	uint8_t  NewFireMode;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.OnDeath
// Size: 0x28(Inherited: 0x0) 
struct FOnDeath
{
	float KillingDamage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDamageEvent DamageEvent;  // 0x8(0x10)
	struct APawn* InstigatingPawn;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.OnRep_EquippedItem
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_EquippedItem
{
	struct ADFBaseItem* LastItem;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.SetNetAddressable
// Size: 0x8(Inherited: 0x0) 
struct FSetNetAddressable
{
	struct UActorComponent* ActorComp;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.OnRep_Health
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_Health
{
	float PreviousValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.OnRep_ItemEnabledMode
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_ItemEnabledMode
{
	uint8_t  PreviousItemEnabledMode;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.GetCameraBoom
// Size: 0x8(Inherited: 0x0) 
struct FGetCameraBoom
{
	struct USpringArmComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.OnRep_ReplicatedLeanAmount
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_ReplicatedLeanAmount
{
	float LastReplicatedLeanAmount;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.MoveForward
// Size: 0x4(Inherited: 0x0) 
struct FMoveForward
{
	float Value;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_Int32Sort
// Size: 0x18(Inherited: 0x0) 
struct FArray_Int32Sort
{
	struct TArray<int32_t> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBasePlayerState.OnRep_TeamNum
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_TeamNum
{
	char TeamNumBeforeUpdate;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerState.ScorePoints
// Size: 0x8(Inherited: 0x0) 
struct FScorePoints
{
	float Points;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bForceNetUpdate : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsValidActor
// Size: 0x10(Inherited: 0x0) 
struct FIsValidActor
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBasePlayerState.OnRep_TeamState
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_TeamState
{
	struct ADFTeamState* TeamStateBeforeUpdate;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseProjectile.ApplyDamageToImpactedActor
// Size: 0xB8(Inherited: 0x0) 
struct FApplyDamageToImpactedActor
{
	struct AActor* OtherActor;  // 0x0(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	struct FVector HitNormal;  // 0x1C(0xC)
	struct FHitResult HitResult;  // 0x28(0x88)
	float ReturnValue;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterActionMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterActionMontage
{
	struct UAnimMontage* ActionMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBasePickup.CanBePickedUp
// Size: 0x10(Inherited: 0x0) 
struct FCanBePickedUp
{
	struct ADFBaseCharacter* Invoker;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.FindMapIdByDisplayName
// Size: 0x38(Inherited: 0x0) 
struct FFindMapIdByDisplayName
{
	struct FText MapDisplayName;  // 0x0(0x18)
	struct TArray<struct FPrimaryAssetId> MapIds;  // 0x18(0x10)
	struct FPrimaryAssetId ReturnValue;  // 0x28(0x10)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsProne
// Size: 0x1(Inherited: 0x0) 
struct FIsProne
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterDeathMontage
// Size: 0x8(Inherited: 0x0) 
struct FPlayCharacterDeathMontage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDontPlayAndReturnDominantPlayLengthOnly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterEquipMontage
// Size: 0x8(Inherited: 0x0) 
struct FPlayCharacterEquipMontage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDontPlayAndReturnDominantPlayLengthOnly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterFireMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterFireMontage
{
	struct UAnimMontage* FireMontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFireLast : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bFireADS : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.CharacterVariationGetData
// Size: 0x80(Inherited: 0x0) 
struct FCharacterVariationGetData
{
	struct FDFCharacterVariationDataHandle VariationData;  // 0x0(0x18)
	struct FDFCharacterVariationData ReturnValue;  // 0x18(0x68)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterMontage
{
	struct UAnimMontage* CharMontage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bForceDisableAutoBlendOut : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterPerspectiveAnimation
// Size: 0x18(Inherited: 0x0) 
struct FPlayCharacterPerspectiveAnimation
{
	struct FPerspectiveAnim CharAnim;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bForceDisableAutoBlendOut : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float ReturnValue;  // 0x14(0x4)

}; 
// Function DonkehFramework.DFBaseGun.PlayReloadTransitionAnimations
// Size: 0x8(Inherited: 0x0) 
struct FPlayReloadTransitionAnimations
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bStartReload : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bDontPlayAndReturnDominantPlayLengthOnly : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterReloadMontage
// Size: 0x8(Inherited: 0x0) 
struct FPlayCharacterReloadMontage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDryReload : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterSound
// Size: 0x18(Inherited: 0x0) 
struct FPlayCharacterSound
{
	struct FPerspectiveSound Sound;  // 0x0(0x10)
	struct UAudioComponent* ReturnValue;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterStartReloadMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterStartReloadMontage
{
	struct UAnimMontage* StartReloadMontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDryReload : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.GetDeaths
// Size: 0x4(Inherited: 0x0) 
struct FGetDeaths
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayThrowAnimations
// Size: 0x8(Inherited: 0x0) 
struct FPlayThrowAnimations
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOverhandThrow : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bDontPlayAndReturnDominantPlayLengthOnly : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterThrowOverhandMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterThrowOverhandMontage
{
	struct UAnimMontage* ThrowOverhandMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterThrowUnderhandMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterThrowUnderhandMontage
{
	struct UAnimMontage* ThrowUnderhandMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetFocalPoint
// Size: 0x18(Inherited: 0x0) 
struct FGetFocalPoint
{
	struct AActor* Actor;  // 0x0(0x8)
	struct FVector ReturnValue;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.PlayCharacterUnEquipMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayCharacterUnEquipMontage
{
	struct UAnimMontage* UnEquipMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ReceiveHealthChanged
// Size: 0x8(Inherited: 0x0) 
struct FReceiveHealthChanged
{
	float NewHealthTotal;  // 0x0(0x4)
	float PrevHealthTotal;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ReceiveOnEndProne
// Size: 0x8(Inherited: 0x0) 
struct FReceiveOnEndProne
{
	float HalfHeightAdjust;  // 0x0(0x4)
	float ScaledHalfHeightAdjust;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ReceivePawnTeamNumUpdated
// Size: 0x2(Inherited: 0x0) 
struct FReceivePawnTeamNumUpdated
{
	char LastTeamNum;  // 0x0(0x1)
	char NewTeamNum;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.GetOwningCharacter
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningCharacter
{
	struct ADFBaseCharacter* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.WasShotFired
// Size: 0xA(Inherited: 0x0) 
struct FWasShotFired
{
	struct FRepShotInfo Counter;  // 0x0(0x4)
	struct FRepShotInfo OtherCounter;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[1];  // 0x9(0x1)

}; 
// Function DonkehFramework.SpawnPointStatics.FindSpawnPoint
// Size: 0x70(Inherited: 0x0) 
struct FFindSpawnPoint
{
	struct UObject* Target;  // 0x0(0x8)
	int32_t SpawnPointID;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FSpawnPointDef FoundSpawnPoint;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[15];  // 0x61(0xF)

}; 
// Function DonkehFramework.DFBaseGun.PlayWeaponStartReloadMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponStartReloadMontage
{
	struct UAnimMontage* StartReloadMontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDryReload : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFSingleLoadWeapAnimInstInterface.PlayStartReloadMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayStartReloadMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFullReload : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ReceivePawnTeamStateUpdated
// Size: 0x18(Inherited: 0x0) 
struct FReceivePawnTeamStateUpdated
{
	struct ADFTeamState* TeamStateBeforeUpdate;  // 0x0(0x8)
	struct ADFTeamState* NewTeamState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bNewTeamStateInit : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBaseGun.PlayReloadAnimations
// Size: 0x8(Inherited: 0x0) 
struct FPlayReloadAnimations
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDryReload : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bDontPlayAndReturnDominantPlayLengthOnly : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseCharacter.ServerDoVault
// Size: 0x18(Inherited: 0x0) 
struct FServerDoVault
{
	struct FDFVaultTraceData VaultStartParams;  // 0x0(0x18)

}; 
// Function DonkehFramework.DFBaseCharacter.ServerEquipItem
// Size: 0x8(Inherited: 0x0) 
struct FServerEquipItem
{
	struct ADFBaseItem* ItemToEquip;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.SetItemEnabledMode
// Size: 0x1(Inherited: 0x0) 
struct FSetItemEnabledMode
{
	uint8_t  ItemMode;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.SpawnHitImpactFX
// Size: 0x28(Inherited: 0x0) 
struct FSpawnHitImpactFX
{
	float DamageTaken;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FDamageEvent DamageEvent;  // 0x8(0x10)
	struct APawn* PawnInstigator;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.HasFiringStopped
// Size: 0x6(Inherited: 0x0) 
struct FHasFiringStopped
{
	struct FRepShotInfo Counter;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[1];  // 0x5(0x1)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.ReceiveGetDefaultPawnMesh1P
// Size: 0x8(Inherited: 0x0) 
struct FReceiveGetDefaultPawnMesh1P
{
	struct USkeletalMesh* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.Sprint
// Size: 0x1(Inherited: 0x0) 
struct FSprint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseCharacter.StopAllAnimMontages
// Size: 0x1(Inherited: 0x0) 
struct FStopAllAnimMontages
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPerspectiveMeshOnly : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameState.GetTeamStateById
// Size: 0x10(Inherited: 0x0) 
struct FGetTeamStateById
{
	char TeamIdNum;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ADFTeamState* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.StopCharacterMontage
// Size: 0x8(Inherited: 0x0) 
struct FStopCharacterMontage
{
	struct UAnimMontage* CharMontage;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseCharacter.StopCharacterPerspectiveAnimation
// Size: 0x10(Inherited: 0x0) 
struct FStopCharacterPerspectiveAnimation
{
	struct FPerspectiveAnim CharAnim;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBaseCharacter.UnSprint
// Size: 0x1(Inherited: 0x0) 
struct FUnSprint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bClientSimulation : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.AddBot
// Size: 0x20(Inherited: 0x0) 
struct FAddBot
{
	char PlayerTeamID;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString PlayerName;  // 0x8(0x10)
	struct APlayerState* ReturnValue;  // 0x18(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.AddBots
// Size: 0x4(Inherited: 0x0) 
struct FAddBots
{
	int32_t Num;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFHandlerInterface.EventOnNewPawn
// Size: 0x10(Inherited: 0x0) 
struct FEventOnNewPawn
{
	struct APawn* NewPawn;  // 0x0(0x8)
	struct APawn* PreviousPawn;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.AddNamedBot
// Size: 0x10(Inherited: 0x0) 
struct FAddNamedBot
{
	struct FString BotName;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBaseGameMode.AddTeamBots
// Size: 0x8(Inherited: 0x0) 
struct FAddTeamBots
{
	char TeamId;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Num;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseGameMode.AssignTeam
// Size: 0x10(Inherited: 0x0) 
struct FAssignTeam
{
	struct AController* ForController;  // 0x0(0x8)
	char AssignedTeam;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.OnToggleFirstPerson
// Size: 0x1(Inherited: 0x0) 
struct FOnToggleFirstPerson
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewFirstPerson : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.BanPlayerById
// Size: 0x28(Inherited: 0x0) 
struct FBanPlayerById
{
	int32_t BannedPlayerId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText BanReason;  // 0x8(0x18)
	float BanDuration;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function DonkehFramework.DFBaseGameMode.ChooseSpawnPointFromPlayerStart
// Size: 0x70(Inherited: 0x0) 
struct FChooseSpawnPointFromPlayerStart
{
	struct AController* Player;  // 0x0(0x8)
	struct AActor* StartSpot;  // 0x8(0x8)
	struct FSpawnPointDef OutChosenSpawnPoint;  // 0x10(0x50)
	uint8_t  OutCollisionHandlingMethod;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool ReturnValue : 1;  // 0x61(0x1)
	char pad_98[14];  // 0x62(0xE)

}; 
// Function DonkehFramework.DFHandlerInterface.EventShouldUpdateThisFrame
// Size: 0x8(Inherited: 0x0) 
struct FEventShouldUpdateThisFrame
{
	float DeltaTime;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bActiveAndSpawnedInWorld : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)

}; 
// Function DonkehFramework.DFBaseGameMode.CanAddRuleset
// Size: 0x20(Inherited: 0x0) 
struct FCanAddRuleset
{
	UDFGameRulesetBase* RulesetClassToAdd;  // 0x0(0x8)
	struct FString RulesetDenialReason;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFramework.DFBaseGameMode.CanRegisterSignificantActor
// Size: 0x20(Inherited: 0x0) 
struct FCanRegisterSignificantActor
{
	struct AActor* ActorToRegister;  // 0x0(0x8)
	struct FString ActorDenialReason;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetTargetLocation
// Size: 0x20(Inherited: 0x0) 
struct FGetTargetLocation
{
	struct AActor* Actor;  // 0x0(0x8)
	struct AActor* RequestedBy;  // 0x8(0x8)
	struct FVector ReturnValue;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function DonkehFramework.DFBaseGameMode.CheckRulesetWinConditions
// Size: 0x1(Inherited: 0x0) 
struct FCheckRulesetWinConditions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.SetStartSpot
// Size: 0x10(Inherited: 0x0) 
struct FSetStartSpot
{
	struct AController* Controller;  // 0x0(0x8)
	struct AActor* NewStartSpot;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.CheckWinConditions
// Size: 0x1(Inherited: 0x0) 
struct FCheckWinConditions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.FindPlayerStartTransform
// Size: 0x60(Inherited: 0x0) 
struct FFindPlayerStartTransform
{
	struct AController* Player;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform OutFoundSpawnTransform;  // 0x10(0x30)
	struct FString IncomingName;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[15];  // 0x51(0xF)

}; 
// Function DonkehFramework.DFBaseGameMode.ForceTeam
// Size: 0x18(Inherited: 0x0) 
struct FForceTeam
{
	struct FString SwitchedPlayerName;  // 0x0(0x10)
	char TeamIdToAssign;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.UpdateLeanDirection
// Size: 0x1(Inherited: 0x0) 
struct FUpdateLeanDirection
{
	uint8_t  NewLeanDir;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.GetAutoAssignHumanTeam
// Size: 0x1(Inherited: 0x0) 
struct FGetAutoAssignHumanTeam
{
	char ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.GetNextGameName
// Size: 0x10(Inherited: 0x0) 
struct FGetNextGameName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBaseGameMode.GetNextMapName
// Size: 0x10(Inherited: 0x0) 
struct FGetNextMapName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBaseGameMode.GetNumPlayersOnTeam
// Size: 0x8(Inherited: 0x0) 
struct FGetNumPlayersOnTeam
{
	char TeamId;  // 0x0(0x1)
	uint8_t  PlayerType;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.OnRep_NumKills
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_NumKills
{
	int32_t PrevNumKills;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetGameNameForDisplay
// Size: 0x20(Inherited: 0x0) 
struct FGetGameNameForDisplay
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FText ReturnValue;  // 0x8(0x18)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerKilled
// Size: 0x10(Inherited: 0x0) 
struct FPlayerKilled
{
	struct AController* Killer;  // 0x0(0x8)
	struct AController* Victim;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.GetTotalNumPlayers
// Size: 0x8(Inherited: 0x0) 
struct FGetTotalNumPlayers
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIncludeTravellingPlayers : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.ScoreDeath
// Size: 0x10(Inherited: 0x0) 
struct FScoreDeath
{
	struct ADFBasePlayerState* KilledBy;  // 0x0(0x8)
	float Points;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseGameMode.IsMatchWinner
// Size: 0x10(Inherited: 0x0) 
struct FIsMatchWinner
{
	struct ADFBasePlayerState* PlayerStateToCheck;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseGameState.IsValidTeamId
// Size: 0x2(Inherited: 0x0) 
struct FIsValidTeamId
{
	char TeamId;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFTableLibrary.GetRowInvFromIndex
// Size: 0xC(Inherited: 0x0) 
struct FGetRowInvFromIndex
{
	int32_t Index;  // 0x0(0x4)
	int32_t TableHeight;  // 0x4(0x4)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function DonkehFramework.DFBaseGameMode.KickPlayerByName
// Size: 0x30(Inherited: 0x0) 
struct FKickPlayerByName
{
	struct FString KickedPlayerName;  // 0x0(0x10)
	struct FText KickReason;  // 0x10(0x18)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_NameSort
// Size: 0x18(Inherited: 0x0) 
struct FArray_NameSort
{
	struct TArray<struct FName> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFPlayerComponent.ReceiveGameHasEnded
// Size: 0x10(Inherited: 0x0) 
struct FReceiveGameHasEnded
{
	struct AActor* EndGameFocus;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsWinner : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetVisibleInMapSelectUI
// Size: 0x14(Inherited: 0x0) 
struct FGetMapAssetVisibleInMapSelectUI
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bOutVisibleInMapSelectUI : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)

}; 
// Function DonkehFramework.DFBaseGameMode.ModifyDamage
// Size: 0x38(Inherited: 0x0) 
struct FModifyDamage
{
	float Damage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* DamagedActor;  // 0x8(0x8)
	struct FDamageEvent DamageEvent;  // 0x10(0x10)
	struct AController* EventInstigator;  // 0x20(0x8)
	struct AActor* DamageCauser;  // 0x28(0x8)
	float ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function DonkehFramework.DFBaseGameMode.PlayerBotCanRestart
// Size: 0x10(Inherited: 0x0) 
struct FPlayerBotCanRestart
{
	struct AAIController* Player;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.SetTeamNum
// Size: 0x10(Inherited: 0x0) 
struct FSetTeamNum
{
	struct AActor* Target;  // 0x0(0x8)
	char NewTeamNum;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseGameMode.PlayerCanRestartGeneric
// Size: 0x10(Inherited: 0x0) 
struct FPlayerCanRestartGeneric
{
	struct AController* Player;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseGameMode.RegisterSignificantActor
// Size: 0x8(Inherited: 0x0) 
struct FRegisterSignificantActor
{
	struct AActor* ActorToRegister;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGun.PlayWeaponEndReloadMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponEndReloadMontage
{
	struct UAnimMontage* EndReloadMontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDryReload : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFSingleLoadWeapAnimInstInterface.PlayEndReloadMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayEndReloadMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFullReload : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseGameMode.RemoveBot
// Size: 0x10(Inherited: 0x0) 
struct FRemoveBot
{
	struct APlayerState* BotPS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.LookUpAtRate
// Size: 0x4(Inherited: 0x0) 
struct FLookUpAtRate
{
	float Rate;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseGameMode.RemoveBotByName
// Size: 0x18(Inherited: 0x0) 
struct FRemoveBotByName
{
	struct FString PlayerName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBaseGameMode.RemovePlayerByAge
// Size: 0x3(Inherited: 0x0) 
struct FRemovePlayerByAge
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewest : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bExcludeBots : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bExcludeHumans : 1;  // 0x2(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.ShouldGameplayMuteRemotePlayer
// Size: 0x18(Inherited: 0x0) 
struct FShouldGameplayMuteRemotePlayer
{
	struct ADFBasePlayerController* ForPlayer;  // 0x0(0x8)
	struct ADFBasePlayerController* PlayerToCheck;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBaseGameMode.ShouldHibernate
// Size: 0x1(Inherited: 0x0) 
struct FShouldHibernate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameMode.SignificantActorEndPlay
// Size: 0x10(Inherited: 0x0) 
struct FSignificantActorEndPlay
{
	struct AActor* RemovedActor;  // 0x0(0x8)
	char EEndPlayReason EndPlayReason;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBaseGameMode.UnregisterSignificantActor
// Size: 0x8(Inherited: 0x0) 
struct FUnregisterSignificantActor
{
	struct AActor* ActorToRemove;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGameMode.UpdatePlayerGameplayMuteStates
// Size: 0x8(Inherited: 0x0) 
struct FUpdatePlayerGameplayMuteStates
{
	struct ADFBasePlayerController* ForPlayerController;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGameInstance.FindGames
// Size: 0x1(Inherited: 0x0) 
struct FFindGames
{
	uint8_t  SearchPresenceType;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.GetMuzzleDirection
// Size: 0x10(Inherited: 0x0) 
struct FGetMuzzleDirection
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnoreLocalControlOnServer : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector ReturnValue;  // 0x4(0xC)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetTeamStateFromTeamId
// Size: 0x18(Inherited: 0x0) 
struct FGetTeamStateFromTeamId
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	char TeamIdNum;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ADFTeamState* ReturnValue;  // 0x10(0x8)

}; 
// Function DonkehFramework.DFBaseGameInstance.JoinGame
// Size: 0x18(Inherited: 0x0) 
struct FJoinGame
{
	int32_t SearchResultIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString JoinPassword;  // 0x8(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDefaultGameMode
// Size: 0x40(Inherited: 0x0) 
struct FGetMapAssetDefaultGameMode
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	struct TSoftClassPtr<UObject> OutDefaultGameModeRef;  // 0x10(0x28)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function DonkehFramework.DFBaseGameInstance.JoinGameByIP
// Size: 0x20(Inherited: 0x0) 
struct FJoinGameByIP
{
	struct FString IPAddress;  // 0x0(0x10)
	struct FString JoinPassword;  // 0x10(0x10)

}; 
// Function DonkehFramework.DFBaseGun.OnRep_SelectedFireMode
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_SelectedFireMode
{
	uint8_t  PrevSelectedFireMode;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGameInstance.OnTravelFailure
// Size: 0x20(Inherited: 0x0) 
struct FOnTravelFailure
{
	struct UWorld* World;  // 0x0(0x8)
	char ETravelFailure FailureType;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString ErrorString;  // 0x10(0x10)

}; 
// Function DonkehFramework.DFBaseGameState.SetRemainingTime
// Size: 0x4(Inherited: 0x0) 
struct FSetRemainingTime
{
	int32_t NewRemainingTime;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.SpawnImpactFXFromDamageEvent
// Size: 0x48(Inherited: 0x0) 
struct FSpawnImpactFXFromDamageEvent
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	ADFBaseImpactEffect* ImpactClass;  // 0x8(0x8)
	float DamageTaken;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct AActor* HitActor;  // 0x28(0x8)
	struct AActor* HitInstigator;  // 0x30(0x8)
	struct AActor* DamageCauser;  // 0x38(0x8)
	struct ADFBaseImpactEffect* ReturnValue;  // 0x40(0x8)

}; 
// Function DonkehFramework.DFBaseGameState.SetTimerPauseState
// Size: 0x1(Inherited: 0x0) 
struct FSetTimerPauseState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewPauseState : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.GetMontagePlayLengthToUseFromPerspectiveAnimPair
// Size: 0x18(Inherited: 0x0) 
struct FGetMontagePlayLengthToUseFromPerspectiveAnimPair
{
	struct FPerspectiveAnim AnimationPair;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function DonkehFramework.DFBaseWeapon.GetWeaponMesh
// Size: 0x8(Inherited: 0x0) 
struct FGetWeaponMesh
{
	struct USkeletalMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseWeapon.GetWeaponMeshToUse
// Size: 0x10(Inherited: 0x0) 
struct FGetWeaponMeshToUse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnoreLocalControlOnServer : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USkeletalMeshComponent* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseWeapon.OnRep_FireCounter
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_FireCounter
{
	struct FRepShotInfo PreviousValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseProjectileLegacy.SpawnImpactFX
// Size: 0x88(Inherited: 0x0) 
struct FSpawnImpactFX
{
	struct FHitResult Impact;  // 0x0(0x88)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerPostLogout
// Size: 0x8(Inherited: 0x0) 
struct FPlayerPostLogout
{
	struct AController* ExitingPlayer;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.IsFirstPerson
// Size: 0x1(Inherited: 0x0) 
struct FIsFirstPerson
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayActionAnimations
// Size: 0x1(Inherited: 0x0) 
struct FPlayActionAnimations
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDontPlayAndReturnDominantPlayLengthOnly : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponActionMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponActionMontage
{
	struct UAnimMontage* ActionMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponEquipMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponEquipMontage
{
	struct UAnimMontage* EquipMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.GetLeanXOffset
// Size: 0x8(Inherited: 0x0) 
struct FGetLeanXOffset
{
	float DesiredLeanAmt;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseGun.CanReload
// Size: 0x1(Inherited: 0x0) 
struct FCanReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponMontage
{
	struct UAnimMontage* WeapMontage;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bForceDisableAutoBlendOut : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponPerspectiveAnimation
// Size: 0x18(Inherited: 0x0) 
struct FPlayWeaponPerspectiveAnimation
{
	struct FPerspectiveAnim WeapAnim;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponThrowOverhandMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponThrowOverhandMontage
{
	struct UAnimMontage* ThrowOverhandMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseProjectileLegacy.TriggerPayload
// Size: 0x88(Inherited: 0x0) 
struct FTriggerPayload
{
	struct FHitResult ImpactHitResult;  // 0x0(0x88)

}; 
// Function DonkehFramework.DFBaseWeapon.PlayWeaponUnEquipMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayWeaponUnEquipMontage
{
	struct UAnimMontage* UnEquipMontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBaseWeapon.ServerFireShot
// Size: 0x24(Inherited: 0x0) 
struct FServerFireShot
{
	struct FVector_NetQuantize Origin;  // 0x0(0xC)
	struct FVector_NetQuantizeNormal ShootDir;  // 0xC(0xC)
	int32_t RandomSeed;  // 0x18(0x4)
	float Timestamp;  // 0x1C(0x4)
	int32_t ShotID;  // 0x20(0x4)

}; 
// Function DonkehFramework.DFBaseGun.GetClipAmmo
// Size: 0x4(Inherited: 0x0) 
struct FGetClipAmmo
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBaseImpactEffect.GetImpactFX
// Size: 0x10(Inherited: 0x0) 
struct FGetImpactFX
{
	char EPhysicalSurface SurfaceType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UParticleSystem* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseProjectile.SetProjectileUpdatedComponent
// Size: 0x8(Inherited: 0x0) 
struct FSetProjectileUpdatedComponent
{
	struct USceneComponent* NewProjectileUpdatedComponent;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGun.GetMuzzleAttachComponent
// Size: 0x10(Inherited: 0x0) 
struct FGetMuzzleAttachComponent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnoreLocalControlOnServer : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USceneComponent* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBaseGun.GetMuzzleAttachPoint
// Size: 0x8(Inherited: 0x0) 
struct FGetMuzzleAttachPoint
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerController.TeamSay
// Size: 0x10(Inherited: 0x0) 
struct FTeamSay
{
	struct FString Msg;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBaseGun.GetPreviousReloadState
// Size: 0x1(Inherited: 0x0) 
struct FGetPreviousReloadState
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.PrintTextToLog
// Size: 0x28(Inherited: 0x0) 
struct FPrintTextToLog
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FText InText;  // 0x8(0x18)
	uint8_t  InLogVerbosity;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bPrintStackTrace : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapNameForDisplay
// Size: 0x20(Inherited: 0x0) 
struct FGetMapNameForDisplay
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FText ReturnValue;  // 0x8(0x18)

}; 
// Function DonkehFramework.DFBaseGun.GetReloadState
// Size: 0x1(Inherited: 0x0) 
struct FGetReloadState
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.DoesMapIDSupportGMDefinition
// Size: 0x20(Inherited: 0x0) 
struct FDoesMapIDSupportGMDefinition
{
	struct FPrimaryAssetId MapId;  // 0x0(0x10)
	struct UDFGameModeDefinition* GMDef;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFramework.DFBaseGun.GetSelectedFireMode
// Size: 0x1(Inherited: 0x0) 
struct FGetSelectedFireMode
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.GetShellEjectAttachPoint
// Size: 0x8(Inherited: 0x0) 
struct FGetShellEjectAttachPoint
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.GetCamera1P
// Size: 0x8(Inherited: 0x0) 
struct FGetCamera1P
{
	struct UCameraComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGun.GetSupportedFireModes
// Size: 0x1(Inherited: 0x0) 
struct FGetSupportedFireModes
{
	char ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.HasAmmoClip
// Size: 0x1(Inherited: 0x0) 
struct FHasAmmoClip
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.OnRep_PendingReloadState
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_PendingReloadState
{
	uint8_t  PrevReloadState;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.HasExhaustedAllAmmo
// Size: 0x1(Inherited: 0x0) 
struct FHasExhaustedAllAmmo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.IsDryReloading
// Size: 0x1(Inherited: 0x0) 
struct FIsDryReloading
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsReloading
// Size: 0x1(Inherited: 0x0) 
struct FIsReloading
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.LoadAmmoClip
// Size: 0x8(Inherited: 0x0) 
struct FLoadAmmoClip
{
	struct ADFBaseAmmoClip* ClipToLoad;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseGun.PlayWeaponReloadMontage
// Size: 0x8(Inherited: 0x0) 
struct FPlayWeaponReloadMontage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDryReload : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFBaseGun.ServerSetFireMode
// Size: 0x1(Inherited: 0x0) 
struct FServerSetFireMode
{
	uint8_t  NewFireMode;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.SetReloadState
// Size: 0x1(Inherited: 0x0) 
struct FSetReloadState
{
	uint8_t  NewReloadState;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.ShouldSimulateGunReload
// Size: 0x1(Inherited: 0x0) 
struct FShouldSimulateGunReload
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun.ShouldUseRecoil
// Size: 0x1(Inherited: 0x0) 
struct FShouldUseRecoil
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBaseGun_Projectile.ClientDrawDebugFireCone
// Size: 0x18(Inherited: 0x0) 
struct FClientDrawDebugFireCone
{
	struct FVector ConeOrig;  // 0x0(0xC)
	struct FVector_NetQuantizeNormal ConeDir;  // 0xC(0xC)

}; 
// Function DonkehFramework.DFBaseGun_Projectile.ClientProjDebugImpactInfo
// Size: 0x20(Inherited: 0x0) 
struct FClientProjDebugImpactInfo
{
	struct ADFBaseProjectile* Proj;  // 0x0(0x8)
	struct FVector ImpactLoc;  // 0x8(0xC)
	struct FVector_NetQuantizeNormal ImpactNorm;  // 0x14(0xC)

}; 
// Function DonkehFramework.DFBaseGun_Projectile.ClientProjDebugInfo
// Size: 0x38(Inherited: 0x0) 
struct FClientProjDebugInfo
{
	struct ADFBaseProjectile* Proj;  // 0x0(0x8)
	struct FVector NewProjLoc;  // 0x8(0xC)
	struct FVector LastProjLoc;  // 0x14(0xC)
	struct FRotator NewProjRot;  // 0x20(0xC)
	struct FVector NewProjVel;  // 0x2C(0xC)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_AssetDescriptorSort
// Size: 0x18(Inherited: 0x0) 
struct FArray_AssetDescriptorSort
{
	struct TArray<struct FAssetDescriptor> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bCompareDisplayText : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function DonkehFramework.DFBaseGun_Projectile.ServerNotifyCSHit
// Size: 0x80(Inherited: 0x0) 
struct FServerNotifyCSHit
{
	struct ADFBaseProjectile* HitProj;  // 0x0(0x8)
	struct FCSHitInfo HitInfo;  // 0x8(0x70)
	int32_t ShotID;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)

}; 
// Function DonkehFramework.DFBaseGun_Projectile.ServerNotifyCSHitPredicted
// Size: 0x74(Inherited: 0x0) 
struct FServerNotifyCSHitPredicted
{
	struct FCSHitInfo HitInfo;  // 0x0(0x70)
	int32_t ShotID;  // 0x70(0x4)

}; 
// Function DonkehFramework.DFBaseProjectileLegacy.ProjectileStop
// Size: 0x88(Inherited: 0x0) 
struct FProjectileStop
{
	struct FHitResult ImpactResult;  // 0x0(0x88)

}; 
// Function DonkehFramework.DFBaseImpactEffect.GetImpactSound
// Size: 0x10(Inherited: 0x0) 
struct FGetImpactSound
{
	char EPhysicalSurface SurfaceType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USoundCue* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.GetCamera
// Size: 0x8(Inherited: 0x0) 
struct FGetCamera
{
	struct UCameraComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseProjectile.GetProjectileUpdatedPrimitive
// Size: 0x8(Inherited: 0x0) 
struct FGetProjectileUpdatedPrimitive
{
	struct UPrimitiveComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.GetDefaultPawnMesh1P
// Size: 0x8(Inherited: 0x0) 
struct FGetDefaultPawnMesh1P
{
	struct USkeletalMesh* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.GetItemAttachPoint1P
// Size: 0x8(Inherited: 0x0) 
struct FGetItemAttachPoint1P
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.GetMesh1P
// Size: 0x8(Inherited: 0x0) 
struct FGetMesh1P
{
	struct USkeletalMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDefaultGameMode
// Size: 0x80(Inherited: 0x0) 
struct FGetMapAssetDataDefaultGameMode
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct TSoftClassPtr<UObject> OutDefaultGameModeRef;  // 0x50(0x28)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.IsLocalFirstPerson
// Size: 0x1(Inherited: 0x0) 
struct FIsLocalFirstPerson
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.IsTrueFirstPerson
// Size: 0x1(Inherited: 0x0) 
struct FIsTrueFirstPerson
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.MoveRight
// Size: 0x4(Inherited: 0x0) 
struct FMoveRight
{
	float Value;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBasePlayerCharacter.MoveUp
// Size: 0x4(Inherited: 0x0) 
struct FMoveUp
{
	float Value;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBasePlayerController.Admin
// Size: 0x10(Inherited: 0x0) 
struct FAdmin
{
	struct FString Cmd;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBasePlayerController.ReceiveNewChatMsg
// Size: 0x30(Inherited: 0x0) 
struct FReceiveNewChatMsg
{
	struct FPlayerChatMsg ChatMsg;  // 0x0(0x30)

}; 
// Function DonkehFramework.DFBasePlayerController.ReceivePlayerTeamNumUpdated
// Size: 0x2(Inherited: 0x0) 
struct FReceivePlayerTeamNumUpdated
{
	char LastTeamNum;  // 0x0(0x1)
	char NewTeamNum;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBasePlayerController.ReceivePlayerTeamStateUpdated
// Size: 0x18(Inherited: 0x0) 
struct FReceivePlayerTeamStateUpdated
{
	struct ADFTeamState* LastTeamState;  // 0x0(0x8)
	struct ADFTeamState* NewTeamState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bNewTeamStateInit : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBasePlayerController.ReceivePossessPawn
// Size: 0x8(Inherited: 0x0) 
struct FReceivePossessPawn
{
	struct APawn* NewPawn;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetGameDefaultMap
// Size: 0x10(Inherited: 0x0) 
struct FGetGameDefaultMap
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBasePlayerController.ReceiveUnpossessPawn
// Size: 0x8(Inherited: 0x0) 
struct FReceiveUnpossessPawn
{
	struct APawn* UnpossessedPawn;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerController.ServerAdmin
// Size: 0x10(Inherited: 0x0) 
struct FServerAdmin
{
	struct FString Cmd;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBasePlayerController.ServerNotifyProjCSHit
// Size: 0x88(Inherited: 0x0) 
struct FServerNotifyProjCSHit
{
	struct ADFBaseProjectile* HitProj;  // 0x0(0x8)
	struct APawn* HitProjDamageInstigator;  // 0x8(0x8)
	struct FCSHitInfo HitInfo;  // 0x10(0x70)
	int32_t ShotID;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)

}; 
// Function DonkehFramework.DFBasePlayerController.ServerSay
// Size: 0x10(Inherited: 0x0) 
struct FServerSay
{
	struct FString Msg;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBasePlayerController.ServerTeamSay
// Size: 0x10(Inherited: 0x0) 
struct FServerTeamSay
{
	struct FString Msg;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBasePlayerState.GetKills
// Size: 0x4(Inherited: 0x0) 
struct FGetKills
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.GetTeam
// Size: 0x1(Inherited: 0x0) 
struct FGetTeam
{
	char ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_StringSort
// Size: 0x18(Inherited: 0x0) 
struct FArray_StringSort
{
	struct TArray<struct FString> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsCrawling
// Size: 0x1(Inherited: 0x0) 
struct FIsCrawling
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerState.OnRep_NumAssists
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_NumAssists
{
	int32_t PrevNumAssists;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.OnRep_NumDeaths
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_NumDeaths
{
	int32_t PrevNumDeaths;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.OnTeamNumUpdated
// Size: 0x1(Inherited: 0x0) 
struct FOnTeamNumUpdated
{
	char TeamNumBeforeUpdate;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBasePlayerState.OnTeamStateUpdated
// Size: 0x8(Inherited: 0x0) 
struct FOnTeamStateUpdated
{
	struct ADFTeamState* TeamStateBeforeUpdate;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBasePlayerState.ScoreAssistPlayer
// Size: 0x18(Inherited: 0x0) 
struct FScoreAssistPlayer
{
	struct ADFBasePlayerState* Killer;  // 0x0(0x8)
	struct ADFBasePlayerState* Victim;  // 0x8(0x8)
	float Points;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.ScoreKillPlayer
// Size: 0x10(Inherited: 0x0) 
struct FScoreKillPlayer
{
	struct ADFBasePlayerState* Victim;  // 0x0(0x8)
	float Points;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBasePlayerState.SetAdminStatus
// Size: 0x1(Inherited: 0x0) 
struct FSetAdminStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewAdminStatus : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetPreviewBannerImg
// Size: 0x40(Inherited: 0x0) 
struct FGetMapAssetPreviewBannerImg
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	struct TSoftObjectPtr<UTexture2D> OutMapPreviewBannerImgRef;  // 0x10(0x28)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function DonkehFramework.DFBaseProjectile.GetAdjustedDamageParams
// Size: 0x28(Inherited: 0x0) 
struct FGetAdjustedDamageParams
{
	struct AActor* OtherActor;  // 0x0(0x8)
	struct FVector HitLocation;  // 0x8(0xC)
	struct FDFDamageParams ReturnValue;  // 0x14(0x14)

}; 
// Function DonkehFramework.SpawnPointStatics.GetSpawnPointCollisionHandlingOverride
// Size: 0x70(Inherited: 0x0) 
struct FGetSpawnPointCollisionHandlingOverride
{
	struct UObject* Target;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FSpawnPointDef SpawnPoint;  // 0x10(0x50)
	uint8_t  OutSpawnCollisionMethod;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool ReturnValue : 1;  // 0x61(0x1)
	char pad_98[14];  // 0x62(0xE)

}; 
// Function DonkehFramework.DFBaseProjectile.GetImpactFXClass
// Size: 0x8(Inherited: 0x0) 
struct FGetImpactFXClass
{
	ADFBaseImpactEffect* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseProjectileLegacy.GetOwningWeapon
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningWeapon
{
	struct ADFBaseWeapon* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBaseProjectile.IgnoreInstigatorWhenMoving
// Size: 0x2(Inherited: 0x0) 
struct FIgnoreInstigatorWhenMoving
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldIgnore : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bBidirectional : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFBlueprintFunctions.CharacterVariationIsValid
// Size: 0x20(Inherited: 0x0) 
struct FCharacterVariationIsValid
{
	struct FDFCharacterVariationDataHandle VariationData;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFramework.DFBaseProjectile.K2_ShouldIgnoreHit
// Size: 0xA0(Inherited: 0x0) 
struct FK2_ShouldIgnoreHit
{
	struct AActor* OtherActor;  // 0x0(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x8(0x8)
	struct FHitResult HitResult;  // 0x10(0x88)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 
// Function DonkehFramework.DFBaseProjectileLegacy.ProjectileBounce
// Size: 0x94(Inherited: 0x0) 
struct FProjectileBounce
{
	struct FHitResult ImpactResult;  // 0x0(0x88)
	struct FVector ImpactVelocity;  // 0x88(0xC)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_FloatSort
// Size: 0x18(Inherited: 0x0) 
struct FArray_FloatSort
{
	struct TArray<float> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_Int64Sort
// Size: 0x18(Inherited: 0x0) 
struct FArray_Int64Sort
{
	struct TArray<int64_t> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_Reverse
// Size: 0x10(Inherited: 0x0) 
struct FArray_Reverse
{
	struct TArray<int32_t> TargetArray;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.Array_TextSort
// Size: 0x18(Inherited: 0x0) 
struct FArray_TextSort
{
	struct TArray<struct FText> ArrayToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetStartSpot
// Size: 0x10(Inherited: 0x0) 
struct FGetStartSpot
{
	struct AController* Controller;  // 0x0(0x8)
	struct AActor* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.CharacterVariationDataFromTableRow
// Size: 0x30(Inherited: 0x0) 
struct FCharacterVariationDataFromTableRow
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FDataTableRowHandle RowHandle;  // 0x8(0x10)
	struct FDFCharacterVariationDataHandle ReturnValue;  // 0x18(0x18)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_CharacterAnimCollection
// Size: 0x258(Inherited: 0x0) 
struct FEqualEqual_CharacterAnimCollection
{
	struct FCharacterAnimCollection A;  // 0x0(0x128)
	struct FCharacterAnimCollection B;  // 0x128(0x128)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool ReturnValue : 1;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetAllMapNames
// Size: 0x10(Inherited: 0x0) 
struct FGetAllMapNames
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_CharacterSoundCollection
// Size: 0x28(Inherited: 0x0) 
struct FEqualEqual_CharacterSoundCollection
{
	struct FCharacterSoundCollection A;  // 0x0(0x10)
	struct FCharacterSoundCollection B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveAnim
// Size: 0x28(Inherited: 0x0) 
struct FEqualEqual_PerspectiveAnim
{
	struct FPerspectiveAnim A;  // 0x0(0x10)
	struct FPerspectiveAnim B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveSound
// Size: 0x28(Inherited: 0x0) 
struct FEqualEqual_PerspectiveSound
{
	struct FPerspectiveSound A;  // 0x0(0x10)
	struct FPerspectiveSound B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnim
// Size: 0x28(Inherited: 0x0) 
struct FEqualEqual_WeaponAnim
{
	struct FWeaponAnim A;  // 0x0(0x10)
	struct FWeaponAnim B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetGameVersion
// Size: 0x10(Inherited: 0x0) 
struct FGetGameVersion
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimCollection
// Size: 0x1E8(Inherited: 0x0) 
struct FEqualEqual_WeaponAnimCollection
{
	struct FWeaponAnimCollection A;  // 0x0(0xF0)
	struct FWeaponAnimCollection B;  // 0xF0(0xF0)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool ReturnValue : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponSoundCollection
// Size: 0x108(Inherited: 0x0) 
struct FEqualEqual_WeaponSoundCollection
{
	struct FWeaponSoundCollection A;  // 0x0(0x80)
	struct FWeaponSoundCollection B;  // 0x80(0x80)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool ReturnValue : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GameHasEnded
// Size: 0x18(Inherited: 0x0) 
struct FGameHasEnded
{
	struct AController* Controller;  // 0x0(0x8)
	struct AActor* EndGameFocus;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsWinner : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetDefaultBoundingCylinder
// Size: 0x10(Inherited: 0x0) 
struct FGetDefaultBoundingCylinder
{
	struct AActor* Actor;  // 0x0(0x8)
	float CylinderRadius;  // 0x8(0x4)
	float CylinderHalfHeight;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetGameBuildInfo
// Size: 0x10(Inherited: 0x0) 
struct FGetGameBuildInfo
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetGameModeForMapName
// Size: 0x20(Inherited: 0x0) 
struct FGetGameModeForMapName
{
	struct FString MapName;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetGameModeForName
// Size: 0x20(Inherited: 0x0) 
struct FGetGameModeForName
{
	struct FString GameModeName;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetGlobalDefaultGameMode
// Size: 0x10(Inherited: 0x0) 
struct FGetGlobalDefaultGameMode
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDescription
// Size: 0x68(Inherited: 0x0) 
struct FGetMapAssetDataDescription
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct FString OutMapDescription;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDisplayName
// Size: 0x70(Inherited: 0x0) 
struct FGetMapAssetDataDisplayName
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct FText OutMapDisplayName;  // 0x50(0x18)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataGameRulesetClasses
// Size: 0xA8(Inherited: 0x0) 
struct FGetMapAssetDataGameRulesetClasses
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct TSet<struct TSoftClassPtr<UObject>> OutGameRulesetClasses;  // 0x50(0x50)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataPreviewImg
// Size: 0x80(Inherited: 0x0) 
struct FGetMapAssetDataPreviewImg
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct TSoftObjectPtr<UTexture2D> OutMapPreviewImgRef;  // 0x50(0x28)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetSurfaceName
// Size: 0xC(Inherited: 0x0) 
struct FGetSurfaceName
{
	char EPhysicalSurface SurfaceType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName ReturnValue;  // 0x4(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataSupportedGameModes
// Size: 0xA8(Inherited: 0x0) 
struct FGetMapAssetDataSupportedGameModes
{
	struct FAssetData WorldAsset;  // 0x0(0x50)
	struct TSet<struct TSoftClassPtr<UObject>> OutSupportedGameModes;  // 0x50(0x50)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetGameRulesetClasses
// Size: 0x68(Inherited: 0x0) 
struct FGetMapAssetGameRulesetClasses
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	struct TSet<struct TSoftClassPtr<UObject>> OutGameRulesetClasses;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetNameForDisplay
// Size: 0x28(Inherited: 0x0) 
struct FGetMapAssetNameForDisplay
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	struct FText ReturnValue;  // 0x10(0x18)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapAssetPreviewImg
// Size: 0x40(Inherited: 0x0) 
struct FGetMapAssetPreviewImg
{
	struct FPrimaryAssetId WorldAssetId;  // 0x0(0x10)
	struct TSoftObjectPtr<UTexture2D> OutMapPreviewImgRef;  // 0x10(0x28)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetMapName
// Size: 0x18(Inherited: 0x0) 
struct FGetMapName
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetNumShotsFiredBPCompat
// Size: 0xC(Inherited: 0x0) 
struct FGetNumShotsFiredBPCompat
{
	struct FRepShotInfo Counter;  // 0x0(0x4)
	struct FRepShotInfo PreviousCounter;  // 0x4(0x4)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetPluginFriendlyName
// Size: 0x20(Inherited: 0x0) 
struct FGetPluginFriendlyName
{
	struct FString PluginName;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function DonkehFramework.DFBlueprintFunctions.ResetPlayerVoiceTalker
// Size: 0x8(Inherited: 0x0) 
struct FResetPlayerVoiceTalker
{
	struct APlayerState* InPlayerState;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetTeamNum
// Size: 0x10(Inherited: 0x0) 
struct FGetTeamNum
{
	struct AActor* Target;  // 0x0(0x8)
	char ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.GameSessionBlueprintLibrary.RemoveAdmin
// Size: 0x10(Inherited: 0x0) 
struct FRemoveAdmin
{
	struct UObject* WorldContextObj;  // 0x0(0x8)
	struct APlayerController* AdminPlayer;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetVisibilityDefault
// Size: 0x10(Inherited: 0x0) 
struct FGetVisibilityDefault
{
	struct UWidget* Widget;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFIntrinsicCharAnimInstInterface.PlayDeathMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayDeathMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.GetWorldSettings
// Size: 0x10(Inherited: 0x0) 
struct FGetWorldSettings
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct AWorldSettings* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.HasOptions
// Size: 0x28(Inherited: 0x0) 
struct FHasOptions
{
	struct FString Options;  // 0x0(0x10)
	struct TArray<struct FString> Keys;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bMatchAll : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function DonkehFramework.DFGameRulesetBase.ReceiveTick
// Size: 0x4(Inherited: 0x0) 
struct FReceiveTick
{
	float DeltaTime;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsLocallyPlayerControlled
// Size: 0x10(Inherited: 0x0) 
struct FIsLocallyPlayerControlled
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsPendingKillPending
// Size: 0x10(Inherited: 0x0) 
struct FIsPendingKillPending
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsPlayerMuted
// Size: 0x18(Inherited: 0x0) 
struct FIsPlayerMuted
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct APlayerState* PSToCheck;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsPlayerTalking
// Size: 0x10(Inherited: 0x0) 
struct FIsPlayerTalking
{
	struct APlayerState* PlayerPS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsPlayInEditor
// Size: 0x10(Inherited: 0x0) 
struct FIsPlayInEditor
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFTableLibrary.GetIndexFromRowColumnPair
// Size: 0x10(Inherited: 0x0) 
struct FGetIndexFromRowColumnPair
{
	int32_t Row;  // 0x0(0x4)
	int32_t Column;  // 0x4(0x4)
	int32_t TableWidth;  // 0x8(0x4)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFBlueprintFunctions.IsVOIPTalkerStillAlive
// Size: 0x10(Inherited: 0x0) 
struct FIsVOIPTalkerStillAlive
{
	struct UVOIPTalker* InTalker;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFBlueprintFunctions.PrintStringToLog
// Size: 0x20(Inherited: 0x0) 
struct FPrintStringToLog
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FString inString;  // 0x8(0x10)
	uint8_t  InLogVerbosity;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bPrintStackTrace : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function DonkehFramework.DFBlueprintFunctions.TextIsEmptyOrWhitespace
// Size: 0x20(Inherited: 0x0) 
struct FTextIsEmptyOrWhitespace
{
	struct FText InText;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFramework.DFGameRulesetBase.GetGameState
// Size: 0x8(Inherited: 0x0) 
struct FGetGameState
{
	struct ADFBaseGameState* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFBlueprintFunctions.TransferInventoryItems
// Size: 0x18(Inherited: 0x0) 
struct FTransferInventoryItems
{
	struct UDFInventoryComponent* FromInv;  // 0x0(0x8)
	struct UDFInventoryComponent* ToInv;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bKeepLoadedAmmo : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.DetermineLeanTargetAmount
// Size: 0x8(Inherited: 0x0) 
struct FDetermineLeanTargetAmount
{
	uint8_t  DesiredLeanDir;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bMoving : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFCharacterLeanHandler.GetMaxLeanXOffset
// Size: 0x8(Inherited: 0x0) 
struct FGetMaxLeanXOffset
{
	uint8_t  NewLeanDir;  // 0x0(0x1)
	uint8_t  LeanStance;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bMoving : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.GetStance
// Size: 0x1(Inherited: 0x0) 
struct FGetStance
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsMoving
// Size: 0x2(Inherited: 0x0) 
struct FIsMoving
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnoreZVel : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.GetDFCharacterOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetDFCharacterOwner
{
	struct ADFBaseCharacter* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.GetLeanDirection
// Size: 0x1(Inherited: 0x0) 
struct FGetLeanDirection
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsAiming
// Size: 0x1(Inherited: 0x0) 
struct FIsAiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsMovingForward
// Size: 0x1(Inherited: 0x0) 
struct FIsMovingForward
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsSprinting
// Size: 0x1(Inherited: 0x0) 
struct FIsSprinting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFCharacterMovementComponent.IsStanding
// Size: 0x1(Inherited: 0x0) 
struct FIsStanding
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFInventoryComponent.IsValidIndex
// Size: 0x8(Inherited: 0x0) 
struct FIsValidIndex
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerSpawn
// Size: 0x10(Inherited: 0x0) 
struct FPlayerSpawn
{
	struct AController* Player;  // 0x0(0x8)
	struct APawn* NewPlayerPawn;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFInventoryComponent.Clear
// Size: 0x1(Inherited: 0x0) 
struct FClear
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDestroyItems : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFGameRulesetBase.PlayerWounded
// Size: 0x28(Inherited: 0x0) 
struct FPlayerWounded
{
	struct AController* Victim;  // 0x0(0x8)
	float DamageAmount;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UDamageType* DamageType;  // 0x10(0x8)
	struct AController* InstigatedBy;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function DonkehFramework.DFGameRulesetBase.RegisterActor
// Size: 0x8(Inherited: 0x0) 
struct FRegisterActor
{
	struct AActor* RegisteredActor;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFGameRulesetBase.UnregisterActor
// Size: 0x8(Inherited: 0x0) 
struct FUnregisterActor
{
	struct AActor* UnregisteredActor;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFGunRecoilHandler.GetConeOfFireOffset
// Size: 0xC(Inherited: 0x0) 
struct FGetConeOfFireOffset
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function DonkehFramework.DFPlayerComponent.GetPlayerState
// Size: 0x8(Inherited: 0x0) 
struct FGetPlayerState
{
	struct APlayerState* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFGunRecoilHandler.GetOwningGun
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningGun
{
	struct ADFBaseGun* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFGunRecoilHandler.GetOwningPawn
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningPawn
{
	struct APawn* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFHandlerInterface.EventUpdate
// Size: 0x8(Inherited: 0x0) 
struct FEventUpdate
{
	float DeltaTime;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bMakeDecision : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayEquipMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayEquipMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.SpawnPointProviderInterface.CanSpawnActorFromSpawnPointBP
// Size: 0x60(Inherited: 0x0) 
struct FCanSpawnActorFromSpawnPointBP
{
	struct FSpawnPointDef SpawnPoint;  // 0x0(0x50)
	AActor* SpawnActorClass;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayFireMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayFireMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFireLast : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bAiming : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayReloadMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayReloadMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bFullReload : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayUnEquipMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayUnEquipMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFInventoryComponent.Add
// Size: 0x10(Inherited: 0x0) 
struct FAdd
{
	struct ADFBaseItem* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFramework.DFInventoryComponent.Find
// Size: 0x10(Inherited: 0x0) 
struct FFind
{
	struct ADFBaseItem* ItemToCompare;  // 0x0(0x8)
	int32_t OutIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function DonkehFramework.SpawnPointProviderInterface.GetAllSpawnPointsBP
// Size: 0x18(Inherited: 0x0) 
struct FGetAllSpawnPointsBP
{
	struct TArray<struct FSpawnPointDef> SpawnPoints;  // 0x0(0x10)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function DonkehFramework.DFInventoryComponent.FindItemByClass
// Size: 0x18(Inherited: 0x0) 
struct FFindItemByClass
{
	ADFBaseItem* ItemClass;  // 0x0(0x8)
	struct ADFBaseItem* OutItem;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.SpawnPointProviderInterface.CanRestartPlayerFromSpawnPointBP
// Size: 0x70(Inherited: 0x0) 
struct FCanRestartPlayerFromSpawnPointBP
{
	struct FSpawnPointDef SpawnPoint;  // 0x0(0x50)
	struct AController* Player;  // 0x50(0x8)
	APawn* PlayerPawnClass;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[15];  // 0x61(0xF)

}; 
// Function DonkehFramework.DFInventoryComponent.GetItem
// Size: 0x18(Inherited: 0x0) 
struct FGetItem
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ADFBaseItem* OutItem;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFramework.DFInventoryComponent.Remove
// Size: 0x10(Inherited: 0x0) 
struct FRemove
{
	struct ADFBaseItem* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDestroyItem : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function DonkehFramework.DFInventoryComponent.RemoveItemAt
// Size: 0x18(Inherited: 0x0) 
struct FRemoveItemAt
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ADFBaseItem* OutRemovedItem;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDestroyItem : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function DonkehFramework.DFInventoryComponent.Size
// Size: 0x4(Inherited: 0x0) 
struct FSize
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFramework.DFPlayerComponent.IsPendingRestart
// Size: 0x1(Inherited: 0x0) 
struct FIsPendingRestart
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFPlayerComponent.ReceiveSeamlessTravelFromCommon
// Size: 0x10(Inherited: 0x0) 
struct FReceiveSeamlessTravelFromCommon
{
	struct AController* OldC;  // 0x0(0x8)
	struct UDFPlayerComponent* OldCPlayerComp;  // 0x8(0x8)

}; 
// Function DonkehFramework.DFSingleActionWeapAnimInstInterface.PlayActionMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayActionMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFTableLibrary.GetColumnFromIndex
// Size: 0xC(Inherited: 0x0) 
struct FGetColumnFromIndex
{
	int32_t Index;  // 0x0(0x4)
	int32_t TableWidth;  // 0x4(0x4)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function DonkehFramework.DFTableLibrary.GetColumnInvFromIndex
// Size: 0xC(Inherited: 0x0) 
struct FGetColumnInvFromIndex
{
	int32_t Index;  // 0x0(0x4)
	int32_t TableHeight;  // 0x4(0x4)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function DonkehFramework.DFTableLibrary.GetIndexFromColumnRowPair
// Size: 0x10(Inherited: 0x0) 
struct FGetIndexFromColumnRowPair
{
	int32_t Column;  // 0x0(0x4)
	int32_t Row;  // 0x4(0x4)
	int32_t TableHeight;  // 0x8(0x4)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function DonkehFramework.DFTableLibrary.GetRowFromIndex
// Size: 0xC(Inherited: 0x0) 
struct FGetRowFromIndex
{
	int32_t Index;  // 0x0(0x4)
	int32_t TableWidth;  // 0x4(0x4)
	int32_t ReturnValue;  // 0x8(0x4)

}; 
// Function DonkehFramework.DFTeamAgentInterface.EventGetTeamNum
// Size: 0x1(Inherited: 0x0) 
struct FEventGetTeamNum
{
	char ReturnValue;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFTeamAgentInterface.EventSetTeamNum
// Size: 0x1(Inherited: 0x0) 
struct FEventSetTeamNum
{
	char NewTeamNum;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFTeamState.GetFactionInfo
// Size: 0x8(Inherited: 0x0) 
struct FGetFactionInfo
{
	struct UDFFactionInfo* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFTeamState.IsPendingSetupBP
// Size: 0x1(Inherited: 0x0) 
struct FIsPendingSetupBP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFTeamState.IsReadyToInitialize
// Size: 0x1(Inherited: 0x0) 
struct FIsReadyToInitialize
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFramework.DFTeamState.ReceiveInitTeam
// Size: 0x8(Inherited: 0x0) 
struct FReceiveInitTeam
{
	struct UDFTeamDefinition* InTeamDef;  // 0x0(0x8)

}; 
// Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayThrowOverhandMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayThrowOverhandMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayThrowUnderhandMontage
// Size: 0x10(Inherited: 0x0) 
struct FPlayThrowUnderhandMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)
	float ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.GameSessionBlueprintLibrary.AddAdmin
// Size: 0x10(Inherited: 0x0) 
struct FAddAdmin
{
	struct UObject* WorldContextObj;  // 0x0(0x8)
	struct APlayerController* AdminPlayer;  // 0x8(0x8)

}; 
// Function DonkehFramework.GameSessionBlueprintLibrary.GetMaxPlayers
// Size: 0x10(Inherited: 0x0) 
struct FGetMaxPlayers
{
	struct UObject* WorldContextObj;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function DonkehFramework.SpawnPointProviderInterface.FindSpawnPointBP
// Size: 0x70(Inherited: 0x0) 
struct FFindSpawnPointBP
{
	int32_t SpawnPointID;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FSpawnPointDef FoundSpawnPoint;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[15];  // 0x61(0xF)

}; 
// Function DonkehFramework.SpawnPointProviderInterface.GetSpawnPointCollisionHandlingOverrideBP
// Size: 0x60(Inherited: 0x0) 
struct FGetSpawnPointCollisionHandlingOverrideBP
{
	struct FSpawnPointDef SpawnPoint;  // 0x0(0x50)
	uint8_t  OutSpawnCollisionMethod;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool ReturnValue : 1;  // 0x51(0x1)
	char pad_82[14];  // 0x52(0xE)

}; 
// Function DonkehFramework.SpawnPointStatics.CanRestartPlayerFromAnySpawnPoint
// Size: 0x20(Inherited: 0x0) 
struct FCanRestartPlayerFromAnySpawnPoint
{
	struct UObject* Target;  // 0x0(0x8)
	struct AController* Player;  // 0x8(0x8)
	APawn* PlayerPawnClass;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFramework.SpawnPointStatics.CanSpawnActorFromSpawnPoint
// Size: 0x70(Inherited: 0x0) 
struct FCanSpawnActorFromSpawnPoint
{
	struct UObject* Target;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FSpawnPointDef SpawnPoint;  // 0x10(0x50)
	AActor* SpawnActorClass;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function DonkehFramework.SpawnPointStatics.GetAllSpawnPoints
// Size: 0x20(Inherited: 0x0) 
struct FGetAllSpawnPoints
{
	struct UObject* Target;  // 0x0(0x8)
	struct TArray<struct FSpawnPointDef> SpawnPoints;  // 0x8(0x10)
	int32_t ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function DonkehFramework.SpawnPointStatics.GetAllSpawnPointTransforms
// Size: 0x20(Inherited: 0x0) 
struct FGetAllSpawnPointTransforms
{
	struct UObject* Target;  // 0x0(0x8)
	struct TArray<struct FTransform> SpawnPointTransforms;  // 0x8(0x10)
	int32_t ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function DonkehFramework.SpawnPointStatics.SpawnPointExists
// Size: 0x10(Inherited: 0x0) 
struct FSpawnPointExists
{
	struct UObject* Target;  // 0x0(0x8)
	int32_t SpawnPointID;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function DonkehFramework.UseableInterface.Used
// Size: 0x8(Inherited: 0x0) 
struct FUsed
{
	struct AActor* Invoker;  // 0x0(0x8)

}; 
// Function DonkehFramework.VisibilityInterface.EventGetFocalPoint
// Size: 0xC(Inherited: 0x0) 
struct FEventGetFocalPoint
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
