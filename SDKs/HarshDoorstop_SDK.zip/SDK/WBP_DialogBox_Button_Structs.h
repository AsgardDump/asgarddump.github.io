#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FButtonClicked__DelegateSignature
{
	struct UWBP_DialogBox_Button_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.ExecuteUbergraph_WBP_DialogBox_Button
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DialogBox_Button
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x8(0x18)

}; 
// Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.UpdateAppearance
// Size: 0x528(Inherited: 0x0) 
struct FUpdateAppearance
{
	struct FSlateColor NewTint;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor K2Node_MakeStruct_LinearColor;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x40(0x28)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x68(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_2;  // 0xF0(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_3;  // 0x178(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_4;  // 0x200(0x88)
	struct FButtonStyle K2Node_MakeStruct_ButtonStyle;  // 0x288(0x278)
	struct FSlateColor K2Node_Select_Default;  // 0x500(0x28)

}; 
// Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DialogBox_Button.WBP_DialogBox_Button_C.SetActive
// Size: 0x1(Inherited: 0x0) 
struct FSetActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewActive : 1;  // 0x0(0x1)

}; 
