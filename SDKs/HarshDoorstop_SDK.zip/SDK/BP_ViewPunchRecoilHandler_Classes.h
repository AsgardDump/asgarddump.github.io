#pragma once 
#include <BP_ViewPunchRecoilHandler_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C
// Size: 0x74(Inherited: 0x28) 
struct UBP_ViewPunchRecoilHandler_C : public UDFGunRecoilHandler
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x28(0x8)
	float CurrentCofAngleDegrees;  // 0x30(0x4)
	float ConeOfFireAngleGrowthPerShotDegrees;  // 0x34(0x4)
	float MaxConeOfFireAngleDegrees;  // 0x38(0x4)
	float MinConeOfFireAngleDegrees;  // 0x3C(0x4)
	float ConeOfFireDecayRate;  // 0x40(0x4)
	float DesiredCoF;  // 0x44(0x4)
	float RecoilDirection;  // 0x48(0x4)
	float RecoilPunchMagnitude;  // 0x4C(0x4)
	float RecoilCounter;  // 0x50(0x4)
	struct FRotator InitialViewAngle;  // 0x54(0xC)
	float Recoil_DX;  // 0x60(0x4)
	float Recoil_DY;  // 0x64(0x4)
	float RecoilRestitutionTime;  // 0x68(0x4)
	char EEasingFunc VerticalRecoilEasingMode;  // 0x6C(0x1)
	char EEasingFunc HorizontalRecoilEasingMode;  // 0x6D(0x1)
	char pad_110[2];  // 0x6E(0x2)
	float RecoilDT;  // 0x70(0x4)

	void GetController(struct AController*& Controller); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetController
	void GetControlRotation(struct FRotator& ViewRotation); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetControlRotation
	struct FVector GetConeOfFireOffset(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetConeOfFireOffset
	void OnWeaponFire(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnWeaponFire
	void ViewPunch(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ViewPunch
	void OnTick(float DeltaTime); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnTick
	void ComputeConeOfFire(float DT); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ComputeConeOfFire
	void ComputeRecoil(float DT); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ComputeRecoil
	void OnWeaponStopFire(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnWeaponStopFire
	void OnWeaponStartFire(); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnWeaponStartFire
	void ExecuteUbergraph_BP_ViewPunchRecoilHandler(int32_t EntryPoint); // Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ExecuteUbergraph_BP_ViewPunchRecoilHandler
}; 



