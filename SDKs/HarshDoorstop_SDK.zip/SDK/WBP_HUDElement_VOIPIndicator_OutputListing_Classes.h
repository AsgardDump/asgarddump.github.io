#pragma once 
#include <WBP_HUDElement_VOIPIndicator_OutputListing_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C
// Size: 0x2E2(Inherited: 0x238) 
struct UWBP_HUDElement_VOIPIndicator_OutputListing_C : public UHDVoipIndicatorListingWidgetBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UWidgetAnimation* VOIPInputUIAnim;  // 0x240(0x8)
	struct UImage* PlayerClassIcon;  // 0x248(0x8)
	struct UTextBlock* PlayerName;  // 0x250(0x8)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool bTintClassSymbolOnly : 1;  // 0x258(0x1)
	char pad_601[7];  // 0x259(0x7)
	struct FSlateColor LocalChannelColor;  // 0x260(0x28)
	struct FSlateColor SquadChannelColor;  // 0x288(0x28)
	struct FSlateColor CommandChannelColor;  // 0x2B0(0x28)
	struct UHDKit* PlayerLoadout;  // 0x2D8(0x8)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool bVoiceMsgInfoSet : 1;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool bActive : 1;  // 0x2E1(0x1)

	void CheckForClassSymbolUpdates(); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.CheckForClassSymbolUpdates
	void UpdateClassSymbol(struct UHDKit* Loadout); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.UpdateClassSymbol
	void GetClassSymbolForLoadout(struct UHDKit* Loadout, struct FSlateBrush& ClassSymbolToUse); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.GetClassSymbolForLoadout
	void GetMostValidLoadoutFromPS(struct APlayerState* PlayerState, struct UHDKit*& Loadout); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.GetMostValidLoadoutFromPS
	void OnVoiceMsgInfoSet(bool bIsDesignTime); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.OnVoiceMsgInfoSet
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.Tick
	void PlayerLoadoutChanged(struct UHDKit* NewLoadout); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.PlayerLoadoutChanged
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.PreConstruct
	void OnInitialized(); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.OnInitialized
	void Activate(); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.Activate
	void Deactivate(); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.Deactivate
	void InputAnimFinished(); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.InputAnimFinished
	void ExecuteUbergraph_WBP_HUDElement_VOIPIndicator_OutputListing(int32_t EntryPoint); // Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.ExecuteUbergraph_WBP_HUDElement_VOIPIndicator_OutputListing
}; 



