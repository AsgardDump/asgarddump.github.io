#pragma once 
#include "SDK.h" 
 
 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDPlayerControllerBP
// Size: 0x29(Inherited: 0x0) 
struct FGetHDPlayerControllerBP
{
	int32_t PlayerIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct ABP_HDPlayerControllerBase_C* HDPC;  // 0x10(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x18(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDPlayerCharacterBP
// Size: 0x29(Inherited: 0x0) 
struct FGetHDPlayerCharacterBP
{
	int32_t PlayerIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct ABP_HDPlayerCharacterBase_C* HDPlayerChar;  // 0x10(0x8)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x18(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameMode
// Size: 0x21(Inherited: 0x0) 
struct FGetHDGameMode
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct AHDBaseGameMode* HDGame;  // 0x8(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	struct AHDBaseGameMode* K2Node_DynamicCast_AsHDBase_Game_Mode;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.CheckEntitlement
// Size: 0x40(Inherited: 0x0) 
struct FCheckEntitlement
{
	struct TArray<struct FFEntitlementDefinition> Entitlements;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bEntitled : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	struct FFEntitlementDefinition CallFunc_Array_Get_Item;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_OwnsAppBP_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_HasDLCBP_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x3B(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.SplitLoadedPrimaryAssetClassIds
// Size: 0x90(Inherited: 0x0) 
struct FSplitLoadedPrimaryAssetClassIds
{
	struct TArray<struct FPrimaryAssetId> AssetIds;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct TArray<struct FPrimaryAssetId> UnloadedAssetIds;  // 0x18(0x10)
	struct TArray<UObject*> LoadedAssetClasses;  // 0x28(0x10)
	struct TArray<UObject*> LoadedClasses;  // 0x38(0x10)
	struct TArray<struct FPrimaryAssetId> UnloadedIds;  // 0x48(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x5C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x60(0x4)
	struct FPrimaryAssetId CallFunc_Array_Get_Item;  // 0x64(0x10)
	char pad_116[4];  // 0x74(0x4)
	UObject* CallFunc_GetClassFromPrimaryAssetId_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x84(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x88(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x8C(0x4)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameInstance
// Size: 0x21(Inherited: 0x0) 
struct FGetHDGameInstance
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UHDGameInstance* HDGI;  // 0x8(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x10(0x8)
	struct UHDGameInstance* K2Node_DynamicCast_AsHDGame_Instance;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDHUDBP
// Size: 0x31(Inherited: 0x0) 
struct FGetHDHUDBP
{
	int32_t PlayerIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct ABP_HDHUDBase_C* HDHUD;  // 0x10(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x18(0x8)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x20(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameState
// Size: 0x21(Inherited: 0x0) 
struct FGetHDGameState
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct AHDGameState* HDGameState;  // 0x8(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x10(0x8)
	struct AHDGameState* K2Node_DynamicCast_AsHDGame_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDTeamStateForTeam
// Size: 0x29(Inherited: 0x0) 
struct FGetHDTeamStateForTeam
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct AHDTeamState* HDTeamState;  // 0x10(0x8)
	struct ADFTeamState* CallFunc_GetTeamStateFromTeamId_ReturnValue;  // 0x18(0x8)
	struct AHDTeamState* K2Node_DynamicCast_AsTeam_State__HD_;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetControllerFromPlayerState
// Size: 0x29(Inherited: 0x0) 
struct FGetControllerFromPlayerState
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct AController* OwnerC;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AController* K2Node_DynamicCast_AsController;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDGameUserSettings
// Size: 0x29(Inherited: 0x0) 
struct FGetHDGameUserSettings
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	struct UTBGameUserSettings* HDGameUserSettings;  // 0x8(0x8)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UTBGameUserSettings* K2Node_DynamicCast_AsTBGame_User_Settings;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetPredefinedSquadNameByIndex
// Size: 0x50(Inherited: 0x0) 
struct FGetPredefinedSquadNameByIndex
{
	int32_t SquadCreationIdx;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText SquadName;  // 0x10(0x18)
	struct FString CallFunc_GetPhoneticCodeWordByIndex_CodeWord;  // 0x28(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x38(0x18)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.AbbreviateString
// Size: 0x98(Inherited: 0x0) 
struct FAbbreviateString
{
	struct FString SourceString;  // 0x0(0x10)
	int32_t MaxStartLength;  // 0x10(0x4)
	int32_t MaxEndLength;  // 0x14(0x4)
	struct FString Separator;  // 0x18(0x10)
	struct UObject* __WorldContext;  // 0x28(0x8)
	struct FString AbbrevString;  // 0x30(0x10)
	struct FString CallFunc_Left_ReturnValue;  // 0x40(0x10)
	int32_t CallFunc_Len_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x58(0x10)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	int32_t CallFunc_Min_ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct FString CallFunc_Right_ReturnValue;  // 0x78(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x88(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetPhoneticCodeWordByCharacter
// Size: 0x40(Inherited: 0x0) 
struct FGetPhoneticCodeWordByCharacter
{
	struct FString LetterChar;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FString CodeWord;  // 0x18(0x10)
	int32_t CallFunc_GetIndexForPhoneticCodeWord_LetterIdx;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString CallFunc_GetPhoneticCodeWordByIndex_CodeWord;  // 0x30(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetPhoneticCodeWordByIndex
// Size: 0x278(Inherited: 0x0) 
struct FGetPhoneticCodeWordByIndex
{
	int32_t LetterIdx;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FString CodeWord;  // 0x10(0x10)
	int32_t Temp_int_Variable;  // 0x20(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x24(0x4)
	struct FString Temp_string_Variable;  // 0x28(0x10)
	struct FString Temp_string_Variable_2;  // 0x38(0x10)
	struct FString Temp_string_Variable_3;  // 0x48(0x10)
	struct FString Temp_string_Variable_4;  // 0x58(0x10)
	struct FString Temp_string_Variable_5;  // 0x68(0x10)
	struct FString Temp_string_Variable_6;  // 0x78(0x10)
	struct FString Temp_string_Variable_7;  // 0x88(0x10)
	struct FString Temp_string_Variable_8;  // 0x98(0x10)
	struct FString Temp_string_Variable_9;  // 0xA8(0x10)
	struct FString Temp_string_Variable_10;  // 0xB8(0x10)
	struct FString Temp_string_Variable_11;  // 0xC8(0x10)
	struct FString Temp_string_Variable_12;  // 0xD8(0x10)
	struct FString Temp_string_Variable_13;  // 0xE8(0x10)
	struct FString Temp_string_Variable_14;  // 0xF8(0x10)
	struct FString Temp_string_Variable_15;  // 0x108(0x10)
	struct FString Temp_string_Variable_16;  // 0x118(0x10)
	struct FString Temp_string_Variable_17;  // 0x128(0x10)
	struct FString Temp_string_Variable_18;  // 0x138(0x10)
	struct FString Temp_string_Variable_19;  // 0x148(0x10)
	struct FString Temp_string_Variable_20;  // 0x158(0x10)
	struct FString Temp_string_Variable_21;  // 0x168(0x10)
	struct FString Temp_string_Variable_22;  // 0x178(0x10)
	struct FString Temp_string_Variable_23;  // 0x188(0x10)
	struct FString Temp_string_Variable_24;  // 0x198(0x10)
	struct FString Temp_string_Variable_25;  // 0x1A8(0x10)
	struct FString Temp_string_Variable_26;  // 0x1B8(0x10)
	struct FString Temp_string_Variable_27;  // 0x1C8(0x10)
	struct FString Temp_string_Variable_28;  // 0x1D8(0x10)
	struct FString Temp_string_Variable_29;  // 0x1E8(0x10)
	struct FString Temp_string_Variable_30;  // 0x1F8(0x10)
	struct FString Temp_string_Variable_31;  // 0x208(0x10)
	struct FString Temp_string_Variable_32;  // 0x218(0x10)
	struct FString Temp_string_Variable_33;  // 0x228(0x10)
	struct FString Temp_string_Variable_34;  // 0x238(0x10)
	struct FString Temp_string_Variable_35;  // 0x248(0x10)
	struct FString Temp_string_Variable_36;  // 0x258(0x10)
	struct FString K2Node_Select_Default;  // 0x268(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetContentRootFromPackageName
// Size: 0x80(Inherited: 0x0) 
struct FGetContentRootFromPackageName
{
	struct FString PackageName;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString ContentRootName;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Temp_bool_Variable : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_GetContentRootPathFromPackageName_bSuccess : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct FString CallFunc_GetContentRootPathFromPackageName_ContentRootPath;  // 0x38(0x10)
	struct FString Temp_string_Variable;  // 0x48(0x10)
	int32_t CallFunc_FindSubstring_ReturnValue;  // 0x58(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x5C(0x4)
	struct FString CallFunc_Mid_ReturnValue;  // 0x60(0x10)
	struct FString K2Node_Select_Default;  // 0x70(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetIndexForPredefinedSquadName
// Size: 0x3C(Inherited: 0x0) 
struct FGetIndexForPredefinedSquadName
{
	struct FText SquadName;  // 0x0(0x18)
	struct UObject* __WorldContext;  // 0x18(0x8)
	int32_t SquadNameIdx;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x28(0x10)
	int32_t CallFunc_GetIndexForPhoneticCodeWord_LetterIdx;  // 0x38(0x4)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetIndexForPhoneticCodeWord
// Size: 0x48(Inherited: 0x0) 
struct FGetIndexForPhoneticCodeWord
{
	struct FString CodeWord;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	int32_t LetterIdx;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Temp_bool_Variable : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FString CallFunc_ToUpper_ReturnValue;  // 0x20(0x10)
	int32_t CallFunc_GetCharacterAsNumber_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_InRange_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x40(0x4)
	int32_t K2Node_Select_Default;  // 0x44(0x4)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetHDFactionInfoForTeam
// Size: 0x29(Inherited: 0x0) 
struct FGetHDFactionInfoForTeam
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	UBP_HDFactionInfoBase_C* HDFactionInfoClass;  // 0x10(0x8)
	struct AHDTeamState* CallFunc_GetHDTeamStateForTeam_HDTeamState;  // 0x18(0x8)
	UBP_HDFactionInfoBase_C* K2Node_ClassDynamicCast_AsBP_HDFaction_Info_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetBluforOpforTeamStateForTeam
// Size: 0x38(Inherited: 0x0) 
struct FGetBluforOpforTeamStateForTeam
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct AHDTeamState* HDTeamState;  // 0x10(0x8)
	uint8_t  Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AHDGameState* CallFunc_GetHDGameState_HDGameState;  // 0x20(0x8)
	struct AHDTeamState* Temp_object_Variable;  // 0x28(0x8)
	struct AHDTeamState* K2Node_Select_Default;  // 0x30(0x8)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetPlayerControllerFromPlayerState
// Size: 0x29(Inherited: 0x0) 
struct FGetPlayerControllerFromPlayerState
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct APlayerController* OwnerPC;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetAllMapAssets
// Size: 0x139(Inherited: 0x0) 
struct FGetAllMapAssets
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct TArray<struct FAssetData> LevelAssets;  // 0x10(0x10)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x20(0x10)
	struct TScriptInterface<IAssetRegistry> CallFunc_GetAssetRegistry_ReturnValue;  // 0x30(0x10)
	struct FARFilter K2Node_MakeStruct_ARFilter;  // 0x40(0xE8)
	struct TArray<struct FAssetData> CallFunc_GetAssets_OutAssetData;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_GetAssets_ReturnValue : 1;  // 0x138(0x1)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.SplitLoadedPrimaryAssetIds
// Size: 0x90(Inherited: 0x0) 
struct FSplitLoadedPrimaryAssetIds
{
	struct TArray<struct FPrimaryAssetId> AssetIds;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct TArray<struct FPrimaryAssetId> UnloadedAssetIds;  // 0x18(0x10)
	struct TArray<struct UObject*> LoadedAssets;  // 0x28(0x10)
	struct TArray<struct UObject*> LoadedObjects;  // 0x38(0x10)
	struct TArray<struct FPrimaryAssetId> UnloadedIds;  // 0x48(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x5C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x60(0x4)
	struct FPrimaryAssetId CallFunc_Array_Get_Item;  // 0x64(0x10)
	char pad_116[4];  // 0x74(0x4)
	struct UObject* CallFunc_GetObjectFromPrimaryAssetId_ReturnValue;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x84(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x88(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x8C(0x4)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.AddOption
// Size: 0x88(Inherited: 0x0) 
struct FAddOption
{
	struct FString Options;  // 0x0(0x10)
	struct FString StrToAdd;  // 0x10(0x10)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FString Temp_string_Variable;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsEmpty_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString Temp_string_Variable_2;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Temp_bool_Variable : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FString K2Node_Select_Default;  // 0x58(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x68(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x78(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetContentRootPathFromPackageName
// Size: 0x50(Inherited: 0x0) 
struct FGetContentRootPathFromPackageName
{
	struct FString PackageName;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString ContentRootPath;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_StartsWith_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_FindSubstring_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	struct FString CallFunc_Mid_ReturnValue;  // 0x40(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetPluginDisplayNameFromPath
// Size: 0xA0(Inherited: 0x0) 
struct FGetPluginDisplayNameFromPath
{
	struct FString AssetPath;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct FString ModName;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_GetContentRootFromPackageName_bSuccess : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct FString CallFunc_GetContentRootFromPackageName_ContentRootName;  // 0x30(0x10)
	struct FString Temp_string_Variable;  // 0x40(0x10)
	struct FString CallFunc_GetPluginFriendlyName_ReturnValue;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsEmpty_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FString K2Node_Select_Default;  // 0x80(0x10)
	struct FString K2Node_Select_Default_2;  // 0x90(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.GetPackageShortName
// Size: 0x58(Inherited: 0x0) 
struct FGetPackageShortName
{
	struct FString LongName;  // 0x0(0x10)
	struct UObject* __WorldContext;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString ShortName;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_StartsWith_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Len_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_FindSubstring_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString CallFunc_Mid_ReturnValue;  // 0x48(0x10)

}; 
// Function BPFL_HDCore.BPFL_HDCore_C.FindMapIdByDisplayName
// Size: 0x7C(Inherited: 0x0) 
struct FFindMapIdByDisplayName
{
	struct FText MapDisplayName;  // 0x0(0x18)
	struct TArray<struct FPrimaryAssetId> MapIds;  // 0x18(0x10)
	struct UObject* __WorldContext;  // 0x28(0x8)
	struct FPrimaryAssetId FoundMapId;  // 0x30(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	struct FPrimaryAssetId CallFunc_Array_Get_Item;  // 0x48(0x10)
	struct FText CallFunc_GetMapAssetNameForDisplay_ReturnValue;  // 0x58(0x18)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_EqualEqual_IgnoreCase_TextText_ReturnValue : 1;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x75(0x1)
	char pad_118[2];  // 0x76(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x78(0x4)

}; 
