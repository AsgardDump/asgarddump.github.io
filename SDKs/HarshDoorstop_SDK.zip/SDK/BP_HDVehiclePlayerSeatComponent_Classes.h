#pragma once 
#include <BP_HDVehiclePlayerSeatComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C
// Size: 0x1A0(Inherited: 0x198) 
struct UBP_HDVehiclePlayerSeatComponent_C : public UHDVehiclePlayerSeatComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x198(0x8)

	void GetValidSeatConfig(struct UArcVehicleSeatConfig*& SeatConfig); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.GetValidSeatConfig
	void ReceiveBeginPlay(); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.ReceiveBeginPlay
	void OnDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.OnDeath
	void OnSeatChangeEvent(uint8_t  SeatChangeType); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.OnSeatChangeEvent
	void ResetPlayerCameraConstraints(struct APlayerController* PC); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.ResetPlayerCameraConstraints
	void SetupPlayerCameraConstraints(struct APlayerController* PC); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.SetupPlayerCameraConstraints
	void ExecuteUbergraph_BP_HDVehiclePlayerSeatComponent(int32_t EntryPoint); // Function BP_HDVehiclePlayerSeatComponent.BP_HDVehiclePlayerSeatComponent_C.ExecuteUbergraph_BP_HDVehiclePlayerSeatComponent
}; 



