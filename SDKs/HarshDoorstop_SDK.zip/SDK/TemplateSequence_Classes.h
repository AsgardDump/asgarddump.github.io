#pragma once 
#include <TemplateSequence_Structs.h>
 
 
 
// Class TemplateSequence.TemplateSequence
// Size: 0x3F0(Inherited: 0x348) 
struct UTemplateSequence : public UMovieSceneSequence
{
	struct UMovieScene* MovieScene;  // 0x348(0x8)
	struct TSoftClassPtr<UObject> BoundActorClass;  // 0x350(0x28)
	struct TSoftObjectPtr<AActor> BoundPreviewActor;  // 0x378(0x28)
	struct TMap<struct FGuid, struct FName> BoundActorComponents;  // 0x3A0(0x50)

}; 



// Class TemplateSequence.CameraAnimationSequence
// Size: 0x3F0(Inherited: 0x3F0) 
struct UCameraAnimationSequence : public UTemplateSequence
{

}; 



// Class TemplateSequence.TemplateSequenceActor
// Size: 0x270(Inherited: 0x220) 
struct ATemplateSequenceActor : public AActor
{
	char pad_544[8];  // 0x220(0x8)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings;  // 0x228(0x14)
	char pad_572[4];  // 0x23C(0x4)
	struct UTemplateSequencePlayer* SequencePlayer;  // 0x240(0x8)
	struct FSoftObjectPath TemplateSequence;  // 0x248(0x18)
	struct FTemplateSequenceBindingOverrideData BindingOverride;  // 0x260(0xC)
	char pad_620[4];  // 0x26C(0x4)

	void SetSequence(struct UTemplateSequence* InSequence); // Function TemplateSequence.TemplateSequenceActor.SetSequence
	void SetBinding(struct AActor* Actor); // Function TemplateSequence.TemplateSequenceActor.SetBinding
	struct UTemplateSequence* LoadSequence(); // Function TemplateSequence.TemplateSequenceActor.LoadSequence
	struct UTemplateSequencePlayer* GetSequencePlayer(); // Function TemplateSequence.TemplateSequenceActor.GetSequencePlayer
	struct UTemplateSequence* GetSequence(); // Function TemplateSequence.TemplateSequenceActor.GetSequence
}; 



// Class TemplateSequence.TemplateSequencePlayer
// Size: 0x890(Inherited: 0x888) 
struct UTemplateSequencePlayer : public UMovieSceneSequencePlayer
{
	char pad_2184[8];  // 0x888(0x8)

	struct UTemplateSequencePlayer* CreateTemplateSequencePlayer(struct UObject* WorldContextObject, struct UTemplateSequence* TemplateSequence, struct FMovieSceneSequencePlaybackSettings Settings, struct ATemplateSequenceActor*& OutActor); // Function TemplateSequence.TemplateSequencePlayer.CreateTemplateSequencePlayer
}; 



// Class TemplateSequence.TemplateSequenceSection
// Size: 0x158(Inherited: 0x158) 
struct UTemplateSequenceSection : public UMovieSceneSubSection
{

}; 



// Class TemplateSequence.TemplateSequenceTrack
// Size: 0x68(Inherited: 0x68) 
struct UTemplateSequenceTrack : public UMovieSceneSubTrack
{

}; 



