#pragma once 
#include <CableComponent_Structs.h>
 
 
 
// Class CableComponent.CableActor
// Size: 0x228(Inherited: 0x220) 
struct ACableActor : public AActor
{
	struct UCableComponent* CableComponent;  // 0x220(0x8)

}; 



// Class CableComponent.CableComponent
// Size: 0x4C0(Inherited: 0x430) 
struct UCableComponent : public UMeshComponent
{
	char pad_1072_1 : 7;  // 0x430(0x1)
	bool bAttachStart : 1;  // 0x430(0x1)
	char pad_1073_1 : 7;  // 0x431(0x1)
	bool bAttachEnd : 1;  // 0x431(0x1)
	char pad_1074[6];  // 0x432(0x6)
	struct FComponentReference AttachEndTo;  // 0x438(0x28)
	struct FName AttachEndToSocketName;  // 0x460(0x8)
	struct FVector EndLocation;  // 0x468(0xC)
	float CableLength;  // 0x474(0x4)
	int32_t NumSegments;  // 0x478(0x4)
	float SubstepTime;  // 0x47C(0x4)
	int32_t SolverIterations;  // 0x480(0x4)
	char pad_1156_1 : 7;  // 0x484(0x1)
	bool bEnableStiffness : 1;  // 0x484(0x1)
	char pad_1157_1 : 7;  // 0x485(0x1)
	bool bEnableCollision : 1;  // 0x485(0x1)
	char pad_1158[2];  // 0x486(0x2)
	float CollisionFriction;  // 0x488(0x4)
	struct FVector CableForce;  // 0x48C(0xC)
	float CableGravityScale;  // 0x498(0x4)
	float CableWidth;  // 0x49C(0x4)
	int32_t NumSides;  // 0x4A0(0x4)
	float TileMaterial;  // 0x4A4(0x4)
	char pad_1192[24];  // 0x4A8(0x18)

	void SetAttachEndToComponent(struct USceneComponent* Component, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndToComponent
	void SetAttachEndTo(struct AActor* Actor, struct FName ComponentProperty, struct FName SocketName); // Function CableComponent.CableComponent.SetAttachEndTo
	void GetCableParticleLocations(struct TArray<struct FVector>& Locations); // Function CableComponent.CableComponent.GetCableParticleLocations
	struct USceneComponent* GetAttachedComponent(); // Function CableComponent.CableComponent.GetAttachedComponent
	struct AActor* GetAttachedActor(); // Function CableComponent.CableComponent.GetAttachedActor
}; 



