#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveSettings
// Size: 0xE4(Inherited: 0x0) 
struct FFantasticPerspectiveSettings
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FFantasticPerspectiveFrustum Frustum;  // 0x4(0x44)
	struct FFantasticPerspectivePoints Points;  // 0x48(0x48)
	struct FFantasticPerspectiveTransform Transform;  // 0x90(0x3C)
	struct FFantasticPerspectiveDebug Debug;  // 0xCC(0x18)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetDebugSettings
// Size: 0xFC(Inherited: 0x0) 
struct FSetDebugSettings
{
	struct FFantasticPerspectiveSettings Target;  // 0x0(0xE4)
	struct FFantasticPerspectiveDebug Debug;  // 0xE4(0x18)

}; 
// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveDebug
// Size: 0x18(Inherited: 0x0) 
struct FFantasticPerspectiveDebug
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool DrawOriginalFrustum : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FColor OriginalFrustumColor;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool DrawAdjustedFrustum : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FColor AdjustedFrustumColor;  // 0xC(0x4)
	float LineThickness;  // 0x10(0x4)
	float FrustumDepth;  // 0x14(0x4)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyFrustumEffects
// Size: 0x160(Inherited: 0x0) 
struct FApplyFrustumEffects
{
	struct FFantasticPerspectiveFrustum Frustum;  // 0x0(0x44)
	struct FVector ViewOrigin;  // 0x44(0xC)
	struct FMatrix ViewRotationMatrix;  // 0x50(0x40)
	struct FMatrix ProjectionMatrix;  // 0x90(0x40)
	struct FVector OutViewOrigin;  // 0xD0(0xC)
	char pad_220[4];  // 0xDC(0x4)
	struct FMatrix OutViewRotationMatrix;  // 0xE0(0x40)
	struct FMatrix OutProjectionMatrix;  // 0x120(0x40)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.WorldToScreenConversionMatrix
// Size: 0x40(Inherited: 0x0) 
struct FWorldToScreenConversionMatrix
{
	struct FMatrix ReturnValue;  // 0x0(0x40)

}; 
// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectivePoints
// Size: 0x48(Inherited: 0x0) 
struct FFantasticPerspectivePoints
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool OverrideViewTransform : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector ViewOrigin;  // 0x4(0xC)
	float NearClipPlane;  // 0x10(0x4)
	float OrthoFrustumDepth;  // 0x14(0x4)
	struct FVector LeftBottom;  // 0x18(0xC)
	struct FVector LeftTop;  // 0x24(0xC)
	struct FVector RightTop;  // 0x30(0xC)
	struct FVector RightBottom;  // 0x3C(0xC)

}; 
// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveTransform
// Size: 0x3C(Inherited: 0x0) 
struct FFantasticPerspectiveTransform
{
	struct FVector ViewOriginWorldOffset;  // 0x0(0xC)
	struct FVector WorldTranslation;  // 0xC(0xC)
	struct FRotator WorldRotation;  // 0x18(0xC)
	struct FVector LocalTranslation;  // 0x24(0xC)
	struct FRotator LocalRotation;  // 0x30(0xC)

}; 
// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveFrustum
// Size: 0x44(Inherited: 0x0) 
struct FFantasticPerspectiveFrustum
{
	struct FVector2D LensShift;  // 0x0(0x8)
	struct FVector2D LensTilt;  // 0x8(0x8)
	struct FVector2D PositionShift;  // 0x10(0x8)
	struct FVector2D Skew;  // 0x18(0x8)
	struct FVector2D PreAspectScale;  // 0x20(0x8)
	struct FVector2D PostAspectScale;  // 0x28(0x8)
	struct FVector2D ClippingPlaneSkew;  // 0x30(0x8)
	struct FFantasticPerspectiveDollyZoom DollyZoom;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CompensateAspectRatio : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CompensateFOV : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool SeamlessLensTilt : 1;  // 0x42(0x1)
	char pad_67[1];  // 0x43(0x1)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveComponent.Apply
// Size: 0x140(Inherited: 0x0) 
struct FApply
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	uint8_t  StereoPass;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector ViewOrigin;  // 0xC(0xC)
	char pad_24[8];  // 0x18(0x8)
	struct FMatrix ViewRotationMatrix;  // 0x20(0x40)
	struct FMatrix ProjectionMatrix;  // 0x60(0x40)
	struct FVector OutViewOrigin;  // 0xA0(0xC)
	char pad_172[4];  // 0xAC(0x4)
	struct FMatrix OutViewRotationMatrix;  // 0xB0(0x40)
	struct FMatrix OutProjectionMatrix;  // 0xF0(0x40)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool ReturnValue : 1;  // 0x130(0x1)
	char pad_305[15];  // 0x131(0xF)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetDebugSettings
// Size: 0xFC(Inherited: 0x0) 
struct FGetDebugSettings
{
	struct FFantasticPerspectiveSettings Target;  // 0x0(0xE4)
	struct FFantasticPerspectiveDebug ReturnValue;  // 0xE4(0x18)

}; 
// ScriptStruct FantasticPerspectivePlugin.FantasticPerspectiveDollyZoom
// Size: 0x8(Inherited: 0x0) 
struct FFantasticPerspectiveDollyZoom
{
	float DollyZoom;  // 0x0(0x4)
	float FocalDistance;  // 0x4(0x4)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyPointsBasing
// Size: 0x130(Inherited: 0x0) 
struct FApplyPointsBasing
{
	struct FFantasticPerspectivePoints Settings;  // 0x0(0x48)
	struct FVector ViewOrigin;  // 0x48(0xC)
	char pad_84[12];  // 0x54(0xC)
	struct FMatrix ViewRotationMatrix;  // 0x60(0x40)
	struct FVector OutViewOrigin;  // 0xA0(0xC)
	char pad_172[4];  // 0xAC(0x4)
	struct FMatrix OutViewRotationMatrix;  // 0xB0(0x40)
	struct FMatrix OutProjectionMatrix;  // 0xF0(0x40)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetFrustumSettings
// Size: 0x128(Inherited: 0x0) 
struct FSetFrustumSettings
{
	struct FFantasticPerspectiveSettings Target;  // 0x0(0xE4)
	struct FFantasticPerspectiveFrustum Frustum;  // 0xE4(0x44)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplySettings
// Size: 0x200(Inherited: 0x0) 
struct FApplySettings
{
	struct FFantasticPerspectiveSettings Settings;  // 0x0(0xE4)
	struct FVector ViewOrigin;  // 0xE4(0xC)
	struct FMatrix ViewRotationMatrix;  // 0xF0(0x40)
	struct FMatrix ProjectionMatrix;  // 0x130(0x40)
	struct FVector OutViewOrigin;  // 0x170(0xC)
	char pad_380[4];  // 0x17C(0x4)
	struct FMatrix OutViewRotationMatrix;  // 0x180(0x40)
	struct FMatrix OutProjectionMatrix;  // 0x1C0(0x40)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplySettingsAndDrawDebug
// Size: 0x210(Inherited: 0x0) 
struct FApplySettingsAndDrawDebug
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FFantasticPerspectiveSettings Settings;  // 0x8(0xE4)
	struct FVector ViewOrigin;  // 0xEC(0xC)
	char pad_248[8];  // 0xF8(0x8)
	struct FMatrix ViewRotationMatrix;  // 0x100(0x40)
	struct FMatrix ProjectionMatrix;  // 0x140(0x40)
	struct FVector OutViewOrigin;  // 0x180(0xC)
	char pad_396[4];  // 0x18C(0x4)
	struct FMatrix OutViewRotationMatrix;  // 0x190(0x40)
	struct FMatrix OutProjectionMatrix;  // 0x1D0(0x40)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyToSceneCapture2D
// Size: 0xA0(Inherited: 0x0) 
struct FApplyToSceneCapture2D
{
	struct USceneCaptureComponent2D* SceneCapture;  // 0x0(0x8)
	struct FVector ViewOrigin;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FMatrix ViewRotationMatrix;  // 0x20(0x40)
	struct FMatrix ProjectionMatrix;  // 0x60(0x40)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyTransformEffects
// Size: 0xE0(Inherited: 0x0) 
struct FApplyTransformEffects
{
	struct FFantasticPerspectiveTransform Transform;  // 0x0(0x3C)
	struct FVector ViewOrigin;  // 0x3C(0xC)
	char pad_72[8];  // 0x48(0x8)
	struct FMatrix ViewRotationMatrix;  // 0x50(0x40)
	struct FVector OutViewOrigin;  // 0x90(0xC)
	char pad_156[4];  // 0x9C(0x4)
	struct FMatrix OutViewRotationMatrix;  // 0xA0(0x40)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.DrawDebugPositionedFrustum
// Size: 0xD0(Inherited: 0x0) 
struct FDrawDebugPositionedFrustum
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector ViewOrigin;  // 0x8(0xC)
	char pad_20[12];  // 0x14(0xC)
	struct FMatrix ViewRotationMatrix;  // 0x20(0x40)
	struct FMatrix ProjectionMatrix;  // 0x60(0x40)
	struct FLinearColor Color;  // 0xA0(0x10)
	float PerspectiveFrustumDepth;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bPersistentLines : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	float LifeTime;  // 0xB8(0x4)
	char DepthPriority;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float Thickness;  // 0xC0(0x4)
	char pad_196[12];  // 0xC4(0xC)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetFrustumSettings
// Size: 0x128(Inherited: 0x0) 
struct FGetFrustumSettings
{
	struct FFantasticPerspectiveSettings Target;  // 0x0(0xE4)
	struct FFantasticPerspectiveFrustum ReturnValue;  // 0xE4(0x44)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetTransformSettings
// Size: 0x120(Inherited: 0x0) 
struct FGetTransformSettings
{
	struct FFantasticPerspectiveSettings Target;  // 0x0(0xE4)
	struct FFantasticPerspectiveTransform ReturnValue;  // 0xE4(0x3C)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ResetSettings
// Size: 0xE4(Inherited: 0x0) 
struct FResetSettings
{
	struct FFantasticPerspectiveSettings Target;  // 0x0(0xE4)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ScreenToWorldConversionMatrix
// Size: 0x40(Inherited: 0x0) 
struct FScreenToWorldConversionMatrix
{
	struct FMatrix ReturnValue;  // 0x0(0x40)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ScreenToWorldConversionRotator
// Size: 0xC(Inherited: 0x0) 
struct FScreenToWorldConversionRotator
{
	struct FRotator ReturnValue;  // 0x0(0xC)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetTransformSettings
// Size: 0x120(Inherited: 0x0) 
struct FSetTransformSettings
{
	struct FFantasticPerspectiveSettings Target;  // 0x0(0xE4)
	struct FFantasticPerspectiveTransform Transform;  // 0xE4(0x3C)

}; 
// Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.WorldToScreenConversionRotator
// Size: 0xC(Inherited: 0x0) 
struct FWorldToScreenConversionRotator
{
	struct FRotator ReturnValue;  // 0x0(0xC)

}; 
