#pragma once 
#include <WBP_CreditsListEntry_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_CreditsListEntry.WBP_CreditsListEntry_C
// Size: 0x298(Inherited: 0x230) 
struct UWBP_CreditsListEntry_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UTextBlock* EntryBodyText;  // 0x238(0x8)
	struct UWBP_CreditsListHeader_C* EntryHeader;  // 0x240(0x8)
	struct FFGameCreditsEntry Header;  // 0x248(0x30)
	struct FMargin HeaderPadding;  // 0x278(0x10)
	struct TArray<struct FFGameCreditsEntry> BodyEntries;  // 0x288(0x10)

	void CombineBodyText(struct FString& BodyCombinedStr); // Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.CombineBodyText
	void PreConstruct(bool IsDesignTime); // Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.PreConstruct
	void ExecuteUbergraph_WBP_CreditsListEntry(int32_t EntryPoint); // Function WBP_CreditsListEntry.WBP_CreditsListEntry_C.ExecuteUbergraph_WBP_CreditsListEntry
}; 



