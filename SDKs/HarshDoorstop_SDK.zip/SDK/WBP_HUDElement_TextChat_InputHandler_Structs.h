#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.BndEvt__MsgInputTextBox_K2Node_ComponentBoundEvent_1_OnEditableTextBoxCommittedEvent__DelegateSignature
// Size: 0x19(Inherited: 0x0) 
struct FBndEvt__MsgInputTextBox_K2Node_ComponentBoundEvent_1_OnEditableTextBoxCommittedEvent__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)
	char ETextCommit CommitMethod;  // 0x18(0x1)

}; 
// Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.OnInputTextCommitted__DelegateSignature
// Size: 0x19(Inherited: 0x0) 
struct FOnInputTextCommitted__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)
	char ETextCommit CommitMethod;  // 0x18(0x1)

}; 
// Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.ExecuteUbergraph_WBP_HUDElement_TextChat_InputHandler
// Size: 0x129(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUDElement_TextChat_InputHandler
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText K2Node_ComponentBoundEvent_Text;  // 0x8(0x18)
	char ETextCommit K2Node_ComponentBoundEvent_CommitMethod;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UDFCommChannel* K2Node_Event_CurrentChannel;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UDFCommChannel* K2Node_Event_NewTalkChannel;  // 0x38(0x8)
	struct FText CallFunc_GetChannelDisplayName_ReturnValue;  // 0x40(0x18)
	struct FText K2Node_CustomEvent_Text;  // 0x58(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x70(0x40)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0xB0(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xC0(0x10)
	struct FString CallFunc_Left_ReturnValue;  // 0xD0(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xE0(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xF8(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x110(0x18)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_TextIsEmptyOrWhitespace_ReturnValue : 1;  // 0x128(0x1)

}; 
// Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.InputTextEntered
// Size: 0x18(Inherited: 0x0) 
struct FInputTextEntered
{
	struct FText Text;  // 0x0(0x18)

}; 
// Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.StopTalking
// Size: 0x8(Inherited: 0x8) 
struct FStopTalking : public FStopTalking
{
	struct UDFCommChannel* CurrentChannel;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_TextChat_InputHandler.WBP_HUDElement_TextChat_InputHandler_C.StartTalking
// Size: 0x8(Inherited: 0x8) 
struct FStartTalking : public FStartTalking
{
	struct UDFCommChannel* NewTalkChannel;  // 0x0(0x8)

}; 
