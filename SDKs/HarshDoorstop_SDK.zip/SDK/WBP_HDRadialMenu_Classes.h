#pragma once 
#include <WBP_HDRadialMenu_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HDRadialMenu.WBP_HDRadialMenu_C
// Size: 0x3A4(Inherited: 0x278) 
struct UWBP_HDRadialMenu_C : public UWBP_HDRadialMenuBase_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x278(0x8)
	struct UWidgetAnimation* ShowFirst;  // 0x280(0x8)
	struct UWidgetAnimation* ShowCategory;  // 0x288(0x8)
	struct UWidgetAnimation* ShowBuild;  // 0x290(0x8)
	struct UTextBlock* CategoryTitle;  // 0x298(0x8)
	struct UImage* CenterCircle;  // 0x2A0(0x8)
	struct UWBP_RadialMenuBase_C* MenuOptionsRing;  // 0x2A8(0x8)
	struct UTextBlock* MenuSubselection;  // 0x2B0(0x8)
	struct FName SelectedItem;  // 0x2B8(0x8)
	struct FName SelectedMenuOption;  // 0x2C0(0x8)
	struct FSHDRadialMenu_OptionData CategoryData;  // 0x2C8(0x28)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool bPickingItem : 1;  // 0x2F0(0x1)
	char pad_753[7];  // 0x2F1(0x7)
	struct FSHDRadialMenu_OptionData SelectedItemData;  // 0x2F8(0x28)
	int32_t SelectedIndex;  // 0x320(0x4)
	char pad_804[4];  // 0x324(0x4)
	struct USoundBase* CategorySelectSound;  // 0x328(0x8)
	struct USoundBase* GoBackSound;  // 0x330(0x8)
	struct FSRadialMenuIconSettings IconStyle;  // 0x338(0x28)
	struct UDataTable* MenuOptionsMain;  // 0x360(0x8)
	struct UDataTable* MenuOptionsSelected;  // 0x368(0x8)
	struct FSRadialMenuIconSettings DisabledIconStyle;  // 0x370(0x28)
	float RallypointRespawnTimeDefault;  // 0x398(0x4)
	float OutpostRespawnTime;  // 0x39C(0x4)
	int32_t NumberOfSegments;  // 0x3A0(0x4)

	struct FText GetOutpostName(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetOutpostName
	void GetOutpostTimeRemaining(struct ABP_HDPlayerCharacterBase_C* OwnerPawn, struct FText& TimeRemaining); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetOutpostTimeRemaining
	struct FText GetRallypointName(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetRallypointName
	void GetRallypointTimeRemaining(struct ABP_HDPlayerCharacterBase_C* OwnerPawn, struct FText& TimeRemaining); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetRallypointTimeRemaining
	void OwnerPawnDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.OwnerPawnDeath
	void MakeOutpostIcon(struct FSHDRadialMenu_OptionData OptionData, struct UWBP_RadialMenuIconBase_C*& Widget); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeOutpostIcon
	void MakeRallypointIcon(struct FSHDRadialMenu_OptionData OptionData, struct UWBP_RadialMenuIconBase_C*& Widget); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeRallypointIcon
	void MakeSpottingIcon(struct FSHDRadialMenu_OptionData OptionData, struct UWBP_RadialMenuIconBase_C*& Widget); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeSpottingIcon
	void SelectSubmenu(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.SelectSubmenu
	void PopulateSubmenuOptions(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.PopulateSubmenuOptions
	void PopulateMenuOptions(struct UDataTable* MenuOptions); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.PopulateMenuOptions
	void GetItemData(struct FName RowName, struct FSHDRadialMenu_OptionData& ItemData); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetItemData
	void GetItemNamesForSelectedOption(struct TArray<struct FName>& OutRowNames); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetItemNamesForSelectedOption
	void GetCategoryData(struct FName Category, struct FSHDRadialMenu_OptionData& CategoryData); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategoryData
	void GetCategories(struct TArray<struct FName>& Categories); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategories
	struct FText GetCategoryName(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategoryName
	void BndEvt__categoryRing_K2Node_ComponentBoundEvent_1_SelectionChanged__DelegateSignature(int32_t NewSelection, int32_t OldSelection); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.BndEvt__categoryRing_K2Node_ComponentBoundEvent_1_SelectionChanged__DelegateSignature
	void Submit(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.Submit
	void GoBack(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GoBack
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.Tick
	void Construct(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.Construct
	void OnCancel(); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.OnCancel
	void ExecuteUbergraph_WBP_HDRadialMenu(int32_t EntryPoint); // Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.ExecuteUbergraph_WBP_HDRadialMenu
}; 



