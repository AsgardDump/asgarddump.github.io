#pragma once 
#include "SDK.h" 
 
 
// Function BPFL_AnimationHelpers.BPFL_AnimationHelpers_C.VInterp To Smooth
// Size: 0x60(Inherited: 0x0) 
struct FVInterp To Smooth
{
	struct FVector A;  // 0x0(0xC)
	struct FVector B;  // 0xC(0xC)
	float DeltaTime;  // 0x18(0x4)
	float InterpSpeed;  // 0x1C(0x4)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FVector Return Value;  // 0x28(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x34(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x40(0x4)
	float CallFunc_FMin_ReturnValue;  // 0x44(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x48(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x54(0xC)

}; 
// Function BPFL_AnimationHelpers.BPFL_AnimationHelpers_C.RInterp To Smooth
// Size: 0x60(Inherited: 0x0) 
struct FRInterp To Smooth
{
	struct FRotator A;  // 0x0(0xC)
	struct FRotator B;  // 0xC(0xC)
	float DeltaTime;  // 0x18(0x4)
	float InterpSpeed;  // 0x1C(0x4)
	struct UObject* __WorldContext;  // 0x20(0x8)
	struct FRotator Return Value;  // 0x28(0xC)
	struct FRotator CallFunc_NormalizedDeltaRotator_ReturnValue;  // 0x34(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x40(0x4)
	float CallFunc_FMin_ReturnValue;  // 0x44(0x4)
	struct FRotator CallFunc_Multiply_RotatorFloat_ReturnValue;  // 0x48(0xC)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x54(0xC)

}; 
