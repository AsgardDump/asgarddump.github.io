#pragma once 
#include <WBP_OptionMenu_HDCredits_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C
// Size: 0x270(Inherited: 0x264) 
struct UWBP_OptionMenu_HDCredits_C : public UWBP_OptionMenu_Credits_C
{
	char pad_612[4];  // 0x264(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)

	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C.Tick
	void ExecuteUbergraph_WBP_OptionMenu_HDCredits(int32_t EntryPoint); // Function WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C.ExecuteUbergraph_WBP_OptionMenu_HDCredits
}; 



