#pragma once 
#include <WBP_DeployMenu_SquadList_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C
// Size: 0x340(Inherited: 0x260) 
struct UWBP_DeployMenu_SquadList_C : public UDeployMenu_SquadListBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UCanvasPanel* CanvasPanel_2;  // 0x268(0x8)
	struct USizeBox* DummyOption;  // 0x270(0x8)
	struct UButton* DummyOptionBtn;  // 0x278(0x8)
	struct UImage* Image_6;  // 0x280(0x8)
	struct UWBP_SQOption_C* JoinLeaveSQOption;  // 0x288(0x8)
	struct UButton* JoinLeaveSQOptionBtn;  // 0x290(0x8)
	struct UTextBlock* JoinLeaveSQOptionText;  // 0x298(0x8)
	struct UWBP_SQOption_C* LockUnlockSQOption;  // 0x2A0(0x8)
	struct UButton* LockUnlockSQOptionBtn;  // 0x2A8(0x8)
	struct UTextBlock* LockUnlockSQOptionText;  // 0x2B0(0x8)
	struct UHorizontalBox* SQOptionsHBox;  // 0x2B8(0x8)
	struct UTextBlock* SquadMemberCountText;  // 0x2C0(0x8)
	struct UVerticalBox* SquadMembersList;  // 0x2C8(0x8)
	struct UTextBlock* SquadNameText;  // 0x2D0(0x8)
	struct UButton* ToggleListVisibilityBtn;  // 0x2D8(0x8)
	struct UImage* ToggleListVisibilityImg;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool bExpanded : 1;  // 0x2E8(0x1)
	char pad_745[7];  // 0x2E9(0x7)
	struct FText SquadTextFormat;  // 0x2F0(0x18)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool bExpandListInDesigner : 1;  // 0x308(0x1)
	char pad_777[3];  // 0x309(0x3)
	int32_t NumFakeSquadMemberItems;  // 0x30C(0x4)
	struct FMargin SquadMemberItemPadding;  // 0x310(0x10)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool bCollapsedByUser : 1;  // 0x320(0x1)
	char pad_801[7];  // 0x321(0x7)
	struct UWBP_DeployMenu_PlatoonSquadList_C* ParentContainerWidget;  // 0x328(0x8)
	struct FMargin OptionPadding;  // 0x330(0x10)

	void IsSquadValid(bool& bValidSQ); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsSquadValid
	void OnPaint(struct FPaintContext& Context); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnPaint
	void SetSquadLockedState(bool bNewLocked); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetSquadLockedState
	void UnlockSquad(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UnlockSquad
	void LockSquad(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.LockSquad
	void KickSquadMember(struct AHDPlayerState* MemberPSToKick); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.KickSquadMember
	void WasListCollapsedByUser(bool& bCollapsedByUser); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.WasListCollapsedByUser
	void UpdateLockUnlockBtnState(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateLockUnlockBtnState
	void HasAnySquadMembers(bool& bValidMembersPresent); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.HasAnySquadMembers
	void SetupSQOptions(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetupSQOptions
	void IsOwningPlayerInMemberWidgetList(bool& bOwnsMemberWidget); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerInMemberWidgetList
	void TestPrereqsForAllMembers(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestPrereqsForAllMembers
	void TestSquadAndMemberPrereqs(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestSquadAndMemberPrereqs
	void TestSQPrereqs(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestSQPrereqs
	void IsOwningPlayerRegisteredSquadLeader(bool& bSquadLeader); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerRegisteredSquadLeader
	void IsOwningPlayerRegisteredSquadMember(bool bIgnorePendingRemoval, bool& bRegisteredMember); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerRegisteredSquadMember
	void UpdateJoinLeaveBtnState(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateJoinLeaveBtnState
	void UpdateSquadMemberCountText(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateSquadMemberCountText
	void CollapseListIfEmpty(bool bCollapseParentIfEmpty); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.CollapseListIfEmpty
	void SetSquadNameText(struct FText NewSquadName); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetSquadNameText
	void RemoveSquadMemberItemWidgetFromList(struct USquadMemberInfo* RemovedMemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.RemoveSquadMemberItemWidgetFromList
	void AddNewSquadMemberItemWidget(struct USquadMemberInfo* MemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.AddNewSquadMemberItemWidget
	void CollapseList(bool bCollapseParent); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.CollapseList
	void ExpandList(bool bExpandParent); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.ExpandList
	void BndEvt__LockUnlockSQOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.BndEvt__LockUnlockSQOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void GenerateSquadMember(struct USquadMemberInfo* MemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.GenerateSquadMember
	void DeconstructSquadMember(struct USquadMemberInfo* RemovedMemberData); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.DeconstructSquadMember
	void BndEvt__LeaveSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.BndEvt__LeaveSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void BndEvt__ExpandBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.BndEvt__ExpandBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.PreConstruct
	void SquadMembersListExpanded(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SquadMembersListExpanded
	void SquadMembersListCollapsed(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SquadMembersListCollapsed
	void OnSquadSet(); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadSet
	void OnSquadNameUpdated(struct FText& NewSquadName, struct FText& PreviousSquadName); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadNameUpdated
	void OnSquadLeaderUpdated(struct AHDPlayerState* NewLeaderPS, struct AHDPlayerState* PrevLeaderPS); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadLeaderUpdated
	void OnSquadLockStateUpdated(bool bNewLockedState); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadLockStateUpdated
	void ExecuteUbergraph_WBP_DeployMenu_SquadList(int32_t EntryPoint); // Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.ExecuteUbergraph_WBP_DeployMenu_SquadList
}; 



