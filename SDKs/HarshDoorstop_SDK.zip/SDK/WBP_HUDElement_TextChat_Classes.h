#pragma once 
#include <WBP_HUDElement_TextChat_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C
// Size: 0x318(Inherited: 0x2A8) 
struct UWBP_HUDElement_TextChat_C : public UHDTextChatWidgetBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A8(0x8)
	struct UWidgetAnimation* DisplayChatInputUI;  // 0x2B0(0x8)
	struct UWidgetAnimation* DisplayChatHistoryUI;  // 0x2B8(0x8)
	struct UOverlay* ChatHistory;  // 0x2C0(0x8)
	struct UOverlay* ChatInput;  // 0x2C8(0x8)
	struct UWBP_HUDElement_TextChat_InputHandler_C* ChatInputHandler;  // 0x2D0(0x8)
	struct UScrollBox* ChatMsgLogSBox;  // 0x2D8(0x8)
	int32_t NumFakeChatMsgs;  // 0x2E0(0x4)
	int32_t MaxChatMsgs;  // 0x2E4(0x4)
	struct FMargin ChatMsgPadding;  // 0x2E8(0x10)
	float ChatHistoryFadeOutDelay;  // 0x2F8(0x4)
	char pad_764_1 : 7;  // 0x2FC(0x1)
	bool bChatHistoryVisible : 1;  // 0x2FC(0x1)
	char pad_765[3];  // 0x2FD(0x3)
	struct FTimerHandle ChatHistoryTimeoutHandle;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool bWantsScrollToEnd : 1;  // 0x308(0x1)
	char pad_777[7];  // 0x309(0x7)
	struct UWidget* ScrollToWidget;  // 0x310(0x8)

	void OnPaint(struct FPaintContext& Context); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.OnPaint
	void GetChatHistoryIsVisible(bool& bVisible); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.GetChatHistoryIsVisible
	void AddNewOutputListing(struct UHDTextChatMsgInfo* ChatMsg, struct UWidget*& Listing); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.AddNewOutputListing
	void DisplayChatMessage(struct UHDTextChatMsgInfo* NewChatMsg); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.DisplayChatMessage
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.PreConstruct
	void StartTalking(struct UDFCommChannel* TalkChannel); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.StartTalking
	void StopTalking(); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.StopTalking
	void BndEvt__WBP_TextChat_Input_K2Node_ComponentBoundEvent_2_OnInputTextCommitted__DelegateSignature(struct FText Text, char ETextCommit CommitMethod); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.BndEvt__WBP_TextChat_Input_K2Node_ComponentBoundEvent_2_OnInputTextCommitted__DelegateSignature
	void OnInitialized(); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.OnInitialized
	void ChatHistoryTimeout(); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.ChatHistoryTimeout
	void SetChatHistoryIsVisible(bool bVisible); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.SetChatHistoryIsVisible
	void BndEvt__ChatMsgLogSBox_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature(float CurrentOffset); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.BndEvt__ChatMsgLogSBox_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature
	void ExecuteUbergraph_WBP_HUDElement_TextChat(int32_t EntryPoint); // Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.ExecuteUbergraph_WBP_HUDElement_TextChat
}; 



