#pragma once 
#include "SDK.h" 
 
 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.OnSelectionStateChanged__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FOnSelectionStateChanged__DelegateSignature
{
	struct UWBP_CreateGameSelectionListEntry_C* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelected : 1;  // 0x8(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetBrushWithImageTexture
// Size: 0x1A0(Inherited: 0x0) 
struct FGetBrushWithImageTexture
{
	struct FSlateBrush Brush;  // 0x0(0x88)
	struct UTexture2D* Image;  // 0x88(0x8)
	struct FSlateBrush UpdatedBrush;  // 0x90(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x118(0x88)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemSubText
// Size: 0x30(Inherited: 0x0) 
struct FGetItemSubText
{
	struct FText Text;  // 0x0(0x18)
	struct FText CallFunc_GetText_ReturnValue;  // 0x18(0x18)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.ExecuteUbergraph_WBP_CreateGameSelectionListEntry
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_CreateGameSelectionListEntry
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x7(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0xA(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0xB(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked : 1;  // 0xE(0x1)
	uint8_t  K2Node_Select_Default;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x12(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x14(0x1)
	uint8_t  K2Node_Select_Default_3;  // 0x15(0x1)
	uint8_t  Temp_byte_Variable_7;  // 0x16(0x1)
	uint8_t  Temp_byte_Variable_8;  // 0x17(0x1)
	uint8_t  K2Node_Select_Default_4;  // 0x18(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.IsItemSelected
// Size: 0x2(Inherited: 0x0) 
struct FIsItemSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemText
// Size: 0x30(Inherited: 0x0) 
struct FGetItemText
{
	struct FText Text;  // 0x0(0x18)
	struct FText CallFunc_GetText_ReturnValue;  // 0x18(0x18)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemSelectionState
// Size: 0xE(Inherited: 0x0) 
struct FSetItemSelectionState
{
	uint8_t  InSelectionState;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x3(0x1)
	uint8_t  Temp_byte_Variable;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x6(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9(0x1)
	uint8_t  K2Node_Select_Default;  // 0xA(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0xB(0x1)
	uint8_t  CallFunc_GetCheckedState_ReturnValue;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_2 : 1;  // 0xD(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemIsSelected
// Size: 0xC(Inherited: 0x0) 
struct FSetItemIsSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7(0x1)
	uint8_t  K2Node_Select_Default;  // 0x8(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemSelectionState
// Size: 0x2(Inherited: 0x0) 
struct FGetItemSelectionState
{
	uint8_t  SelectionState;  // 0x0(0x1)
	uint8_t  CallFunc_GetCheckedState_ReturnValue;  // 0x1(0x1)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.InternalApplyStyleToText
// Size: 0x140(Inherited: 0x0) 
struct FInternalApplyStyleToText
{
	struct UTextBlock* Text;  // 0x0(0x8)
	struct FFSelectionItemTextStyle TextStyle;  // 0x8(0x130)
	struct UOverlaySlot* CallFunc_SlotAsOverlaySlot_ReturnValue;  // 0x138(0x8)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.InternalUpdateItemBgTintColor
// Size: 0x80(Inherited: 0x0) 
struct FInternalUpdateItemBgTintColor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x8(0x28)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x30(0x28)
	struct FSlateColor K2Node_Select_Default;  // 0x58(0x28)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemStyle
// Size: 0x580(Inherited: 0x0) 
struct FSetItemStyle
{
	struct FCheckBoxStyle InItemStyle;  // 0x0(0x580)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemTextStyle
// Size: 0x130(Inherited: 0x0) 
struct FSetItemTextStyle
{
	struct FFSelectionItemTextStyle InItemTextStyle;  // 0x0(0x130)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemSubTextStyle
// Size: 0x130(Inherited: 0x0) 
struct FSetItemSubTextStyle
{
	struct FFSelectionItemTextStyle InItemSubTextStyle;  // 0x0(0x130)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemImage
// Size: 0x8(Inherited: 0x0) 
struct FSetItemImage
{
	struct UTexture2D* InItemImg;  // 0x0(0x8)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemMinDimensions
// Size: 0x8(Inherited: 0x0) 
struct FSetItemMinDimensions
{
	int32_t InMinWidth;  // 0x0(0x4)
	int32_t InMinHeight;  // 0x4(0x4)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemSubText
// Size: 0x18(Inherited: 0x0) 
struct FSetItemSubText
{
	struct FText InText;  // 0x0(0x18)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemStyle
// Size: 0x580(Inherited: 0x0) 
struct FGetItemStyle
{
	struct FCheckBoxStyle ItemStyle;  // 0x0(0x580)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemTextStyle
// Size: 0x130(Inherited: 0x0) 
struct FGetItemTextStyle
{
	struct FFSelectionItemTextStyle TextStyle;  // 0x0(0x130)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemSubTextStyle
// Size: 0x130(Inherited: 0x0) 
struct FGetItemSubTextStyle
{
	struct FFSelectionItemTextStyle TextStyle;  // 0x0(0x130)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.SetItemText
// Size: 0x18(Inherited: 0x0) 
struct FSetItemText
{
	struct FText InText;  // 0x0(0x18)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemMinWidth
// Size: 0x4(Inherited: 0x0) 
struct FGetItemMinWidth
{
	int32_t MinWidth;  // 0x0(0x4)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.GetItemMinHeight
// Size: 0x4(Inherited: 0x0) 
struct FGetItemMinHeight
{
	int32_t MinHeight;  // 0x0(0x4)

}; 
// Function WBP_CreateGameSelectionListEntry.WBP_CreateGameSelectionListEntry_C.InternalRefreshDimensions
// Size: 0x8(Inherited: 0x0) 
struct FInternalRefreshDimensions
{
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x0(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x4(0x4)

}; 
