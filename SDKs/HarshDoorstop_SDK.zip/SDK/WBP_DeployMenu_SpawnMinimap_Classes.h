#pragma once 
#include <WBP_DeployMenu_SpawnMinimap_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C
// Size: 0x340(Inherited: 0x298) 
struct UWBP_DeployMenu_SpawnMinimap_C : public UDeployMenu_SpawnMinimap
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x298(0x8)
	struct UMaterialInstanceDynamic* MapMI;  // 0x2A0(0x8)
	struct TSoftObjectPtr<UTexture2D> MapTexture;  // 0x2A8(0x28)
	float InitialZoom;  // 0x2D0(0x4)
	char pad_724[4];  // 0x2D4(0x4)
	struct UMaterialInterface* MapMaterial;  // 0x2D8(0x8)
	float PanSpeedFactor;  // 0x2E0(0x4)
	float ZoomDivisor;  // 0x2E4(0x4)
	float ZoomStep;  // 0x2E8(0x4)
	struct FLinearColor MapTint;  // 0x2EC(0x10)
	char pad_764_1 : 7;  // 0x2FC(0x1)
	bool bDonePreloading : 1;  // 0x2FC(0x1)
	char pad_765_1 : 7;  // 0x2FD(0x1)
	bool bMenuInitialized : 1;  // 0x2FD(0x1)
	char pad_766[2];  // 0x2FE(0x2)
	struct UTexture2D* CurrentMapTexture;  // 0x300(0x8)
	int32_t NumContentToLoad;  // 0x308(0x4)
	int32_t NumLoadedContent;  // 0x30C(0x4)
	struct FMulticastInlineDelegate OnPreloadFinished;  // 0x310(0x10)
	struct FMulticastInlineDelegate OnSpawnPointSelected;  // 0x320(0x10)
	struct FMulticastInlineDelegate OnSpawnPointDeselected;  // 0x330(0x10)

	void UpdatePlayerPOIs(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.UpdatePlayerPOIs
	void SetCurrentMapTexture(struct UTexture2D* NewMapTexture); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.SetCurrentMapTexture
	void HasPreloadInProgress(bool& bPreloading); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.HasPreloadInProgress
	void ApplyPreloadedContent(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ApplyPreloadedContent
	void PreloadContent(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.PreloadContent
	void ZoomOut(float ZoomDecrement); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ZoomOut
	void ZoomIn(float ZoomIncrement); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ZoomIn
	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseWheel
	struct FEventReply OnMouseButtonUp(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseButtonUp
	void UpdateMapMatParams(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.UpdateMapMatParams
	void GetLocalCursorDelta(struct FGeometry& Geometry, struct FPointerEvent& MouseEvent, struct FVector2D& LocalDelta); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.GetLocalCursorDelta
	struct FEventReply OnMouseMove(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseMove
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseButtonDown
	void InitMapBg(struct UTexture2D* MapTexture); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.InitMapBg
	void OnLoaded_BACDC4954F814289E55DD7AAEBE3E34E(struct UObject* Loaded); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnLoaded_BACDC4954F814289E55DD7AAEBE3E34E
	void OnLoaded_BB8D079144A98AFE7BD3849D43A40947(UObject* Loaded); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnLoaded_BB8D079144A98AFE7BD3849D43A40947
	void Construct(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.Construct
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.PreConstruct
	void OnMouseEnter(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnMouseEnter
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.Tick
	void OnContentPreloadStarted(struct TArray<struct TSoftObjectPtr<UObject>>& AssetsToLoad, struct TArray<struct TSoftClassPtr<UObject>>& ClassesToLoad); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnContentPreloadStarted
	void OnContentPreloadFinished(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnContentPreloadFinished
	void OnAsyncLoadCompleted(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnAsyncLoadCompleted
	void ReceiveOnPOISelectionStateChanged(struct UDFPOIWidget* POI, bool bSelected); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ReceiveOnPOISelectionStateChanged
	void ExecuteUbergraph_WBP_DeployMenu_SpawnMinimap(int32_t EntryPoint); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.ExecuteUbergraph_WBP_DeployMenu_SpawnMinimap
	void OnSpawnPointDeselected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnSpawnPointDeselected__DelegateSignature
	void OnSpawnPointSelected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnSpawnPointSelected__DelegateSignature
	void OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu_SpawnMinimap.WBP_DeployMenu_SpawnMinimap_C.OnPreloadFinished__DelegateSignature
}; 



