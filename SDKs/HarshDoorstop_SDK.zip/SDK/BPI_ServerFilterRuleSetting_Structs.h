#pragma once 
#include "SDK.h" 
 
 
// Function BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C.GetFilterRulePair
// Size: 0xA(Inherited: 0x0) 
struct FGetFilterRulePair
{
	UHDServerListFilterRule* Rule;  // 0x0(0x8)
	struct FHDFilterRuleParams RuleParams;  // 0x8(0x2)

}; 
// Function BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C.IsFilterEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsFilterEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)

}; 
