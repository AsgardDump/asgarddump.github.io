#pragma once 
#include <WBP_HDVictoryMenuBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C
// Size: 0x330(Inherited: 0x250) 
struct UWBP_HDVictoryMenuBase_C : public UVictoryMenu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x250(0x8)
	struct UTextBlock* BluforForceText;  // 0x258(0x8)
	struct UTextBlock* BluforTeamScoreText;  // 0x260(0x8)
	struct UTextBlock* ElapsedTimeText;  // 0x268(0x8)
	struct UTextBlock* GameModeNameText;  // 0x270(0x8)
	struct UTextBlock* MapNameText;  // 0x278(0x8)
	struct UTextBlock* OpforForceText;  // 0x280(0x8)
	struct UTextBlock* OpforTeamScoreText;  // 0x288(0x8)
	struct UTextBlock* VictoryText;  // 0x290(0x8)
	struct FText BluforVictoryText;  // 0x298(0x18)
	struct FText OpforVictoryText;  // 0x2B0(0x18)
	struct FText NoTeamVictoryText;  // 0x2C8(0x18)
	struct UAudioComponent* MenuMusicAC;  // 0x2E0(0x8)
	struct USoundBase* WinMusicBlufor;  // 0x2E8(0x8)
	struct USoundBase* WinMusicOpfor;  // 0x2F0(0x8)
	struct USoundBase* LossMusicBlufor;  // 0x2F8(0x8)
	struct USoundBase* LossMusicOpfor;  // 0x300(0x8)
	struct AHDTeamState* WinningTeamState;  // 0x308(0x8)
	struct AHDTeamState* BluforTeamState;  // 0x310(0x8)
	UBP_HDFactionInfoBase_C* BluforFactionInfoClass;  // 0x318(0x8)
	struct AHDTeamState* OpforTeamState;  // 0x320(0x8)
	UBP_HDFactionInfoBase_C* OpforFactionInfoClass;  // 0x328(0x8)

	void GetPlayerTeam(uint8_t & PlayerTeam); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.GetPlayerTeam
	void GetMusicTrackToUse(uint8_t  PlayerTeam, bool bPlayerWon, struct USoundBase*& SoundToUse); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.GetMusicTrackToUse
	void PlayWinLossMenuMusic(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.PlayWinLossMenuMusic
	void SetupTeamScoreText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupTeamScoreText
	void SetupGameModeNameText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupGameModeNameText
	void SetupElapsedTimeText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupElapsedTimeText
	void SetupMapNameText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupMapNameText
	void SetupForceNameText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupForceNameText
	void SetupVictoryText(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupVictoryText
	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnMouseButtonDoubleClick
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnMouseButtonDown
	void Construct(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.Construct
	void OnVictoryInit(); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnVictoryInit
	void ExecuteUbergraph_WBP_HDVictoryMenuBase(int32_t EntryPoint); // Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.ExecuteUbergraph_WBP_HDVictoryMenuBase
}; 



