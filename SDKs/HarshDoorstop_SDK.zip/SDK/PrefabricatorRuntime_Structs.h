#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct PrefabricatorRuntime.PrefabricatorAssetCollectionItem
// Size: 0x30(Inherited: 0x0) 
struct FPrefabricatorAssetCollectionItem
{
	struct TSoftObjectPtr<UPrefabricatorAsset> PrefabAsset;  // 0x0(0x28)
	float Weight;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function PrefabricatorRuntime.PrefabRandomizer.Randomize
// Size: 0x4(Inherited: 0x0) 
struct FRandomize
{
	int32_t InSeed;  // 0x0(0x4)

}; 
// ScriptStruct PrefabricatorRuntime.PrefabricatorActorData
// Size: 0x90(Inherited: 0x0) 
struct FPrefabricatorActorData
{
	struct FGuid PrefabItemID;  // 0x0(0x10)
	struct FTransform RelativeTransform;  // 0x10(0x30)
	struct FString ClassPath;  // 0x40(0x10)
	struct FSoftClassPath ClassPathRef;  // 0x50(0x18)
	struct TArray<struct UPrefabricatorProperty*> Properties;  // 0x68(0x10)
	struct TArray<struct FPrefabricatorComponentData> Components;  // 0x78(0x10)
	char pad_136[8];  // 0x88(0x8)

}; 
// ScriptStruct PrefabricatorRuntime.PrefabricatorPropertyAssetMapping
// Size: 0x38(Inherited: 0x0) 
struct FPrefabricatorPropertyAssetMapping
{
	struct FSoftObjectPath AssetReference;  // 0x0(0x18)
	struct FString AssetClassName;  // 0x18(0x10)
	struct FName AssetObjectPath;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bUseQuotes : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct PrefabricatorRuntime.PrefabricatorComponentData
// Size: 0x50(Inherited: 0x0) 
struct FPrefabricatorComponentData
{
	struct FTransform RelativeTransform;  // 0x0(0x30)
	struct FString ComponentName;  // 0x30(0x10)
	struct TArray<struct UPrefabricatorProperty*> Properties;  // 0x40(0x10)

}; 
// Function PrefabricatorRuntime.PrefabActor.IsPrefabOutdated
// Size: 0x1(Inherited: 0x0) 
struct FIsPrefabOutdated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function PrefabricatorRuntime.PrefabActor.GetPrefabAsset
// Size: 0x8(Inherited: 0x0) 
struct FGetPrefabAsset
{
	struct UPrefabricatorAsset* ReturnValue;  // 0x0(0x8)

}; 
// Function PrefabricatorRuntime.PrefabActor.RandomizeSeed
// Size: 0xC(Inherited: 0x0) 
struct FRandomizeSeed
{
	struct FRandomStream InRandom;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bRecursive : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function PrefabricatorRuntime.PrefabricatorEventListener.PostSpawn
// Size: 0x8(Inherited: 0x0) 
struct FPostSpawn
{
	struct APrefabActor* Prefab;  // 0x0(0x8)

}; 
// Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.FindTopMostPrefabActor
// Size: 0x10(Inherited: 0x0) 
struct FFindTopMostPrefabActor
{
	struct AActor* InActor;  // 0x0(0x8)
	struct APrefabActor* ReturnValue;  // 0x8(0x8)

}; 
// Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.GetAllAttachedActors
// Size: 0x18(Inherited: 0x0) 
struct FGetAllAttachedActors
{
	struct AActor* Prefab;  // 0x0(0x8)
	struct TArray<struct AActor*> AttachedActors;  // 0x8(0x10)

}; 
// Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.RandomizePrefab
// Size: 0x10(Inherited: 0x0) 
struct FRandomizePrefab
{
	struct APrefabActor* PrefabActor;  // 0x0(0x8)
	struct FRandomStream InRandom;  // 0x8(0x8)

}; 
// Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.SetPrefabAsset
// Size: 0x18(Inherited: 0x0) 
struct FSetPrefabAsset
{
	struct APrefabActor* PrefabActor;  // 0x0(0x8)
	struct UPrefabricatorAssetInterface* Prefab;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bReloadPrefab : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.SpawnPrefab
// Size: 0x50(Inherited: 0x0) 
struct FSpawnPrefab
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UPrefabricatorAssetInterface* Prefab;  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x30)
	int32_t Seed;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct APrefabActor* ReturnValue;  // 0x48(0x8)

}; 
// Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.UnlinkPrefab
// Size: 0x8(Inherited: 0x0) 
struct FUnlinkPrefab
{
	struct APrefabActor* PrefabActor;  // 0x0(0x8)

}; 
