#pragma once 
#include <FantasticPerspectivePlugin_Structs.h>
 
 
 
// Class FantasticPerspectivePlugin.FantasticPerspectiveLocalPlayer
// Size: 0x258(Inherited: 0x258) 
struct UFantasticPerspectiveLocalPlayer : public ULocalPlayer
{

}; 



// Class FantasticPerspectivePlugin.FantasticPerspectiveActor
// Size: 0x368(Inherited: 0x220) 
struct AFantasticPerspectiveActor : public AActor
{
	char pad_544[96];  // 0x220(0x60)
	struct FFantasticPerspectiveSettings Settings;  // 0x280(0xE4)
	char pad_868_1 : 7;  // 0x364(0x1)
	bool Cache : 1;  // 0x364(0x1)
	char pad_869[3];  // 0x365(0x3)

	bool Apply(struct APlayerController* PlayerController, uint8_t  StereoPass, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveActor.Apply
}; 



// Class FantasticPerspectivePlugin.FantasticPerspectiveComponent
// Size: 0x1F8(Inherited: 0xB0) 
struct UFantasticPerspectiveComponent : public UActorComponent
{
	char pad_176[96];  // 0xB0(0x60)
	struct FFantasticPerspectiveSettings Settings;  // 0x110(0xE4)
	char pad_500_1 : 7;  // 0x1F4(0x1)
	bool Cache : 1;  // 0x1F4(0x1)
	char pad_501[3];  // 0x1F5(0x3)

	bool Apply(struct APlayerController* PlayerController, uint8_t  StereoPass, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveComponent.Apply
}; 



// Class FantasticPerspectivePlugin.FantasticPerspectiveFunctions
// Size: 0x28(Inherited: 0x28) 
struct UFantasticPerspectiveFunctions : public UBlueprintFunctionLibrary
{

	struct FRotator WorldToScreenConversionRotator(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.WorldToScreenConversionRotator
	struct FMatrix WorldToScreenConversionMatrix(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.WorldToScreenConversionMatrix
	void SetTransformSettings(struct FFantasticPerspectiveSettings& Target, struct FFantasticPerspectiveTransform Transform); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetTransformSettings
	void SetFrustumSettings(struct FFantasticPerspectiveSettings& Target, struct FFantasticPerspectiveFrustum Frustum); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetFrustumSettings
	void SetDebugSettings(struct FFantasticPerspectiveSettings& Target, struct FFantasticPerspectiveDebug Debug); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.SetDebugSettings
	struct FRotator ScreenToWorldConversionRotator(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ScreenToWorldConversionRotator
	struct FMatrix ScreenToWorldConversionMatrix(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ScreenToWorldConversionMatrix
	void ResetSettings(struct FFantasticPerspectiveSettings& Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ResetSettings
	void ResetCache(); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ResetCache
	struct FFantasticPerspectiveTransform GetTransformSettings(struct FFantasticPerspectiveSettings Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetTransformSettings
	struct FFantasticPerspectiveFrustum GetFrustumSettings(struct FFantasticPerspectiveSettings Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetFrustumSettings
	struct FFantasticPerspectiveDebug GetDebugSettings(struct FFantasticPerspectiveSettings Target); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.GetDebugSettings
	void DrawDebugPositionedFrustum(struct UObject* WorldContextObject, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FLinearColor Color, float PerspectiveFrustumDepth, bool bPersistentLines, float LifeTime, char DepthPriority, float Thickness); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.DrawDebugPositionedFrustum
	void ApplyTransformEffects(struct FFantasticPerspectiveTransform Transform, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyTransformEffects
	void ApplyToSceneCapture2D(struct USceneCaptureComponent2D* SceneCapture, struct FVector& ViewOrigin, struct FMatrix& ViewRotationMatrix, struct FMatrix& ProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyToSceneCapture2D
	void ApplySettingsAndDrawDebug(struct UObject* WorldContextObject, struct FFantasticPerspectiveSettings Settings, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplySettingsAndDrawDebug
	void ApplySettings(struct FFantasticPerspectiveSettings Settings, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplySettings
	void ApplyPointsBasing(struct FFantasticPerspectivePoints Settings, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyPointsBasing
	void ApplyFrustumEffects(struct FFantasticPerspectiveFrustum Frustum, struct FVector ViewOrigin, struct FMatrix ViewRotationMatrix, struct FMatrix ProjectionMatrix, struct FVector& OutViewOrigin, struct FMatrix& OutViewRotationMatrix, struct FMatrix& OutProjectionMatrix); // Function FantasticPerspectivePlugin.FantasticPerspectiveFunctions.ApplyFrustumEffects
}; 



