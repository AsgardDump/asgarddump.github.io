#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct UdpMessaging.UdpMockMessage
// Size: 0x10(Inherited: 0x0) 
struct FUdpMockMessage
{
	struct TArray<char> Data;  // 0x0(0x10)

}; 
