#pragma once 
#include <WBP_HDContextualWidgetBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C
// Size: 0x24C(Inherited: 0x240) 
struct UWBP_HDContextualWidgetBase_C : public UDFContextualWidgetBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x240(0x8)
	uint8_t  VisibilitySatisfiedPrereqs;  // 0x248(0x1)
	char pad_585_1 : 7;  // 0x249(0x1)
	bool bIsEnabledSatisfiedPrereqs : 1;  // 0x249(0x1)
	uint8_t  VisibilityUnsatisfiedPrereqs;  // 0x24A(0x1)
	char pad_587_1 : 7;  // 0x24B(0x1)
	bool bIsEnabledUnsatisfiedPrereqs : 1;  // 0x24B(0x1)

	void PrerequisitesMet(); // Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.PrerequisitesMet
	void PrerequisiteNotMet(struct UDFContextualWidgetPrerequisiteBase* FailedPrereq); // Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.PrerequisiteNotMet
	void ExecuteUbergraph_WBP_HDContextualWidgetBase(int32_t EntryPoint); // Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.ExecuteUbergraph_WBP_HDContextualWidgetBase
}; 



