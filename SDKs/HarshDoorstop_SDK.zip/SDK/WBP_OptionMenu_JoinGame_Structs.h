#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ExecuteUbergraph_WBP_OptionMenu_JoinGame
// Size: 0x188(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionMenu_JoinGame
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* K2Node_ComponentBoundEvent_Item_3;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_ComponentBoundEvent_bIsSelected : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UHDServerListItemData* K2Node_DynamicCast_AsHDServer_List_Item_Data;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct UObject* K2Node_ComponentBoundEvent_Item_2;  // 0x28(0x8)
	struct UUserWidget* K2Node_ComponentBoundEvent_Widget_3;  // 0x30(0x8)
	struct UUserWidget* K2Node_ComponentBoundEvent_Widget_2;  // 0x38(0x8)
	struct UWBP_JoinServerListEntry_C* K2Node_DynamicCast_AsWBP_Join_Server_List_Entry;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_GetItemMinHeight_MinHeight;  // 0x4C(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x54(0x4)
	struct TArray<struct FFServerBadgeUIDefinition> CallFunc_ParseServerBadgesFromTable_SortedBadgeDefs;  // 0x58(0x10)
	struct UObject* K2Node_ComponentBoundEvent_Item;  // 0x68(0x8)
	struct UUserWidget* K2Node_ComponentBoundEvent_Widget;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UWBP_JoinServerListEntry_C* K2Node_DynamicCast_AsWBP_Join_Server_List_Entry_2;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool K2Node_Event_bSortAscending : 1;  // 0x89(0x1)
	uint8_t  K2Node_Event_SortBy;  // 0x8A(0x1)
	char pad_139_1 : 7;  // 0x8B(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x8B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8C(0x10)
	char pad_156[4];  // 0x9C(0x4)
	struct TScriptInterface<IBPI_ServerFilterRules_C> K2Node_DynamicCast_AsBPI_Server_Filter_Rules;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	int32_t K2Node_Event_SubMenuIndex;  // 0xB4(0x4)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> CallFunc_GetFilterRules_FilterRules;  // 0xB8(0x50)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> K2Node_ComponentBoundEvent_ActiveFilters;  // 0x108(0x50)
	struct FFServerSortPreference K2Node_CustomEvent_SortPreference;  // 0x158(0x2)
	char pad_346_1 : 7;  // 0x15A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x15A(0x1)
	char pad_347_1 : 7;  // 0x15B(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x15B(0x1)
	char pad_348[4];  // 0x15C(0x4)
	struct FText K2Node_CustomEvent_InputText;  // 0x160(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x178(0x10)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ConfirmServerPasswordInput
// Size: 0x18(Inherited: 0x0) 
struct FConfirmServerPasswordInput
{
	struct FText InputText;  // 0x0(0x18)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_1_OnListItemScrolledIntoViewDynamic__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ServerList_K2Node_ComponentBoundEvent_1_OnListItemScrolledIntoViewDynamic__DelegateSignature
{
	struct UObject* Item;  // 0x0(0x8)
	struct UUserWidget* Widget;  // 0x8(0x8)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_0_OnListEntryInitializedDynamic__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__ServerList_K2Node_ComponentBoundEvent_0_OnListEntryInitializedDynamic__DelegateSignature
{
	struct UObject* Item;  // 0x0(0x8)
	struct UUserWidget* Widget;  // 0x8(0x8)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetDesiredHorizontalAlignment
// Size: 0x6(Inherited: 0x0) 
struct FGetDesiredHorizontalAlignment
{
	char EHorizontalAlignment Alignment;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char EHorizontalAlignment Temp_byte_Variable;  // 0x2(0x1)
	char EHorizontalAlignment Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x4(0x1)
	char EHorizontalAlignment K2Node_Select_Default;  // 0x5(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.SortPreferenceChanged
// Size: 0x2(Inherited: 0x0) 
struct FSortPreferenceChanged
{
	struct FFServerSortPreference SortPreference;  // 0x0(0x2)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.IsValidServerListItemIndex
// Size: 0xE(Inherited: 0x0) 
struct FIsValidServerListItemIndex
{
	int32_t IndexToTest;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bValidIndex : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t CallFunc_GetNumItems_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xD(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__FiltersPanel_K2Node_ComponentBoundEvent_8_OnServerFiltersChanged__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FBndEvt__FiltersPanel_K2Node_ComponentBoundEvent_8_OnServerFiltersChanged__DelegateSignature
{
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> ActiveFilters;  // 0x0(0x50)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__ServerList_K2Node_ComponentBoundEvent_7_OnListEntryGeneratedDynamic__DelegateSignature
{
	struct UUserWidget* Widget;  // 0x0(0x8)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.BndEvt__ServerList_K2Node_ComponentBoundEvent_4_OnListItemSelectionChangedDynamic__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FBndEvt__ServerList_K2Node_ComponentBoundEvent_4_OnListItemSelectionChangedDynamic__DelegateSignature
{
	struct UObject* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsSelected : 1;  // 0x8(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ReceiveOnRefreshComplete
// Size: 0x2(Inherited: 0x2) 
struct FReceiveOnRefreshComplete : public FReceiveOnRefreshComplete
{
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bSortAscending : 1;  // 0x0(0x1)
	uint8_t  SortBy;  // 0x1(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.SetActiveSubMenuByIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetActiveSubMenuByIndex
{
	int32_t SubMenuIndex;  // 0x0(0x4)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ServerListItemSelectionUpdated
// Size: 0x9(Inherited: 0x0) 
struct FServerListItemSelectionUpdated
{
	struct UHDServerListItemData* InSelectedServerListItem;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsRefreshPending_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetSelectedServerListItem
// Size: 0x8(Inherited: 0x0) 
struct FGetSelectedServerListItem
{
	struct UHDServerListItemData* ServerItem;  // 0x0(0x8)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetServerListSortPreference
// Size: 0x4(Inherited: 0x0) 
struct FGetServerListSortPreference
{
	struct FFServerSortPreference SortPreference;  // 0x0(0x2)
	struct FFServerSortPreference CallFunc_GetSelectedServerSortPreference_SortPreference;  // 0x2(0x2)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.ToggleServerDetails
// Size: 0x1(Inherited: 0x0) 
struct FToggleServerDetails
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShown : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.RefreshServerList
// Size: 0x3(Inherited: 0x0) 
struct FRefreshServerList
{
	struct FFServerSortPreference CallFunc_GetServerListSortPreference_SortPreference;  // 0x0(0x2)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.OpenPasswordPrompt
// Size: 0x18(Inherited: 0x0) 
struct FOpenPasswordPrompt
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	struct UWBP_DlgBox_ServerPasswordPrompt_C* CallFunc_Create_ReturnValue;  // 0x10(0x8)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetDesiredVerticalAlignment
// Size: 0x1(Inherited: 0x0) 
struct FGetDesiredVerticalAlignment
{
	char EVerticalAlignment Alignment;  // 0x0(0x1)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.GetSubMenuOptions
// Size: 0x10(Inherited: 0x0) 
struct FGetSubMenuOptions
{
	struct TArray<struct FFSubMenuOption> SubOptions;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_JoinGame.WBP_OptionMenu_JoinGame_C.HasSubMenus
// Size: 0x1(Inherited: 0x0) 
struct FHasSubMenus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSubMenuOptions : 1;  // 0x0(0x1)

}; 
