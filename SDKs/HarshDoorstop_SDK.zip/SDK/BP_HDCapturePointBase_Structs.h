#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.OnCaptureStatusUpdated__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnCaptureStatusUpdated__DelegateSignature
{
	struct ABP_HDCapturePointBase_C* ControlPoint;  // 0x0(0x8)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnActive
// Size: 0x1(Inherited: 0x1) 
struct FReceiveOnActive : public FReceiveOnActive
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bNewActive : 1;  // 0x0(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnLocked
// Size: 0x1(Inherited: 0x1) 
struct FReceiveOnLocked : public FReceiveOnLocked
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bNewLocked : 1;  // 0x0(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ExecuteUbergraph_BP_HDCapturePointBase
// Size: 0x6D0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDCapturePointBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FLinearColor Temp_struct_Variable;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x16(0x1)
	char pad_23[9];  // 0x17(0x9)
	struct FTransform Temp_struct_Variable_2;  // 0x20(0x30)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UNavigationInvokerComponent* CallFunc_AddComponent_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x64(0x4)
	struct FString CallFunc_Conv_BoolToString_ReturnValue;  // 0x68(0x10)
	struct FString CallFunc_Conv_BoolToString_ReturnValue_2;  // 0x78(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x88(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0xA0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0xB8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xF8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x138(0x40)
	struct FText CallFunc_MakeLiteralText_ReturnValue;  // 0x178(0x18)
	struct FText CallFunc_MakeLiteralText_ReturnValue_2;  // 0x190(0x18)
	struct FText CallFunc_MakeLiteralText_ReturnValue_3;  // 0x1A8(0x18)
	uint8_t  K2Node_Event_LastOwningTeam;  // 0x1C0(0x1)
	char pad_449_1 : 7;  // 0x1C1(0x1)
	bool K2Node_Event_bNewContested : 1;  // 0x1C1(0x1)
	char pad_450[2];  // 0x1C2(0x2)
	struct FLinearColor CallFunc_SelectColor_ReturnValue;  // 0x1C4(0x10)
	struct FLinearColor Temp_struct_Variable_3;  // 0x1D4(0x10)
	char pad_484[4];  // 0x1E4(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x1E8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x228(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x238(0x18)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool K2Node_CustomEvent_bContested : 1;  // 0x250(0x1)
	char pad_593[3];  // 0x251(0x3)
	int32_t K2Node_CustomEvent_Progress;  // 0x254(0x4)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x258(0x10)
	struct FString CallFunc_SelectString_ReturnValue;  // 0x268(0x10)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool K2Node_Event_bNewActive : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool K2Node_Event_bNewLocked : 1;  // 0x279(0x1)
	char pad_634[6];  // 0x27A(0x6)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5;  // 0x280(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_6;  // 0x2C0(0x40)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x300(0x1)
	char pad_769_1 : 7;  // 0x301(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x301(0x1)
	char pad_770_1 : 7;  // 0x302(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x302(0x1)
	char pad_771_1 : 7;  // 0x303(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x303(0x1)
	struct FLinearColor K2Node_Select_Default;  // 0x304(0x10)
	char pad_788[4];  // 0x314(0x4)
	struct FText CallFunc_MakeLiteralText_ReturnValue_4;  // 0x318(0x18)
	struct FText CallFunc_MakeLiteralText_ReturnValue_5;  // 0x330(0x18)
	struct FText CallFunc_MakeLiteralText_ReturnValue_6;  // 0x348(0x18)
	struct FText K2Node_Select_Default_2;  // 0x360(0x18)
	struct FText CallFunc_MakeLiteralText_ReturnValue_7;  // 0x378(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_7;  // 0x390(0x40)
	struct FText K2Node_Select_Default_3;  // 0x3D0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_8;  // 0x3E8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_9;  // 0x428(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_10;  // 0x468(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_11;  // 0x4A8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_12;  // 0x4E8(0x40)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x528(0x1)
	char pad_1321_1 : 7;  // 0x529(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // 0x529(0x1)
	char pad_1322_1 : 7;  // 0x52A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x52A(0x1)
	char pad_1323_1 : 7;  // 0x52B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x52B(0x1)
	char pad_1324[4];  // 0x52C(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_13;  // 0x530(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_14;  // 0x570(0x40)
	uint8_t  Temp_byte_Variable;  // 0x5B0(0x1)
	char pad_1457_1 : 7;  // 0x5B1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x5B1(0x1)
	char pad_1458[6];  // 0x5B2(0x6)
	struct FText K2Node_Select_Default_4;  // 0x5B8(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_15;  // 0x5D0(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_16;  // 0x610(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x650(0x10)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_3;  // 0x660(0x10)
	struct FText CallFunc_Format_ReturnValue_2;  // 0x670(0x18)
	struct FText CallFunc_Format_ReturnValue_3;  // 0x688(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0x6A0(0x10)
	struct FString CallFunc_Conv_TextToString_ReturnValue_3;  // 0x6B0(0x10)
	struct FString K2Node_Select_Default_5;  // 0x6C0(0x10)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnOwningTeamUpdated
// Size: 0x1(Inherited: 0x1) 
struct FReceiveOnOwningTeamUpdated : public FReceiveOnOwningTeamUpdated
{
	uint8_t  LastOwningTeam;  // 0x0(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.RemovePOI
// Size: 0x2(Inherited: 0x0) 
struct FRemovePOI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_RemovePOIByActor_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.OnCaptureUpdate
// Size: 0x8(Inherited: 0x0) 
struct FOnCaptureUpdate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bContested : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Progress;  // 0x4(0x4)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnCaptureProgress
// Size: 0x1(Inherited: 0x1) 
struct FReceiveOnCaptureProgress : public FReceiveOnCaptureProgress
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bNewContested : 1;  // 0x0(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UserConstructionScript
// Size: 0xCC(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	float CapsuleHalfHeight;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct FTransform CallFunc_Array_Get_Item;  // 0x10(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x40(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x4C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x58(0xC)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x64(0x4)
	float CallFunc_BreakVector_X;  // 0x68(0x4)
	float CallFunc_BreakVector_Y;  // 0x6C(0x4)
	float CallFunc_BreakVector_Z;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x74(0x1)
	char pad_117[3];  // 0x75(0x3)
	float CallFunc_FMax_ReturnValue;  // 0x78(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x7C(0xC)
	char pad_136[8];  // 0x88(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x90(0x30)
	struct UChildActorComponent* CallFunc_AddComponent_ReturnValue;  // 0xC0(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xC8(0x4)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagColor
// Size: 0x50(Inherited: 0x0) 
struct FUpdateFlagColor
{
	uint8_t  InOwningTeam;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FLinearColor Temp_struct_Variable;  // 0x4(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_3;  // 0x24(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x34(0x10)
	char pad_68[4];  // 0x44(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x48(0x8)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagIcon
// Size: 0x7B(Inherited: 0x0) 
struct FUpdateFlagIcon
{
	uint8_t  InOwningTeam;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AHUD* InLocalPlayerHUD;  // 0x8(0x8)
	struct AHUD* LocalPlayerHUDToUse;  // 0x10(0x8)
	uint8_t  Temp_byte_Variable;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool Temp_bool_Variable : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue_2;  // 0x50(0x8)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x58(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x5B(0x1)
	uint8_t  CallFunc_GetObjectiveTypeForTeam_ReturnValue;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_Select_Default : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UWBP_CaptureStatus_FlagIcon_C* K2Node_DynamicCast_AsWBP_Capture_Status_Flag_Icon;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x7A(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.InitPOI
// Size: 0x8(Inherited: 0x0) 
struct FInitPOI
{
	struct UDFMinimap* Minimap;  // 0x0(0x8)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdatePOIState
// Size: 0x11(Inherited: 0x0) 
struct FUpdatePOIState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UDFPOIWidget* CallFunc_FindPOIByActor_OutFoundPOI;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_FindPOIByActor_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.AddPOI
// Size: 0x10(Inherited: 0x0) 
struct FAddPOI
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UDFPOIWidget* CallFunc_AddNewPOI_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagClothLOD
// Size: 0x38(Inherited: 0x0) 
struct FUpdateFlagClothLOD
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsClothingSimulationSuspended_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsClothingSimulationSuspended_ReturnValue_2 : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_WasRecentlyRendered_ReturnValue : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x28(0x10)

}; 
