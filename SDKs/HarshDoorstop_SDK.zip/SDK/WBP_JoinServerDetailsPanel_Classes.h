#pragma once 
#include <WBP_JoinServerDetailsPanel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C
// Size: 0x270(Inherited: 0x230) 
struct UWBP_JoinServerDetailsPanel_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_ServerListModifierSettings_AdvancedServerData_C* AdvancedServerData;  // 0x238(0x8)
	struct UWBP_ServerListModifierSettings_BasicServerData_C* BasicServerData;  // 0x240(0x8)
	struct UButton* JoinGameBtn;  // 0x248(0x8)
	struct UImage* MapPreviewImg;  // 0x250(0x8)
	struct FMulticastInlineDelegate OnJoinServerBtnClicked;  // 0x258(0x10)
	struct UTexture2D* PlaceholderMapPreviewImg;  // 0x268(0x8)

	void SetMapPreviewImage(struct UTexture2D* NewImg); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.SetMapPreviewImage
	void HideServerDetails(); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.HideServerDetails
	void ShowServerDetails(); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.ShowServerDetails
	void UpdateServerMetaData(struct FHDServerInfo& ServerData); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.UpdateServerMetaData
	void UpdateServerData(struct FHDServerInfo& ServerData); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.UpdateServerData
	void SetupServerDetails(struct FHDServerInfo ServerInfo); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.SetupServerDetails
	void BndEvt__JoinGameBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.BndEvt__JoinGameBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void OnInitialized(); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.OnInitialized
	void PreConstruct(bool IsDesignTime); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.PreConstruct
	void ExecuteUbergraph_WBP_JoinServerDetailsPanel(int32_t EntryPoint); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.ExecuteUbergraph_WBP_JoinServerDetailsPanel
	void OnJoinServerBtnClicked__DelegateSignature(); // Function WBP_JoinServerDetailsPanel.WBP_JoinServerDetailsPanel_C.OnJoinServerBtnClicked__DelegateSignature
}; 



