#pragma once 
#include <MaterialShaderQualitySettings_Structs.h>
 
 
 
// Class MaterialShaderQualitySettings.MaterialShaderQualitySettings
// Size: 0x78(Inherited: 0x28) 
struct UMaterialShaderQualitySettings : public UObject
{
	struct TMap<struct FName, struct UShaderPlatformQualitySettings*> ForwardSettingMap;  // 0x28(0x50)

}; 



// Class MaterialShaderQualitySettings.ShaderPlatformQualitySettings
// Size: 0x58(Inherited: 0x28) 
struct UShaderPlatformQualitySettings : public UObject
{
	struct FMaterialQualityOverrides QualityOverrides[3];  // 0x28(0x1B)
	char pad_67[21];  // 0x43(0x15)

}; 



