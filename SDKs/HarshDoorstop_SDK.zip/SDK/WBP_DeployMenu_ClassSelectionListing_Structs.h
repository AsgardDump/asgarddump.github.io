#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SetSelected
// Size: 0x1(Inherited: 0x0) 
struct FSetSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelected : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.OnClassSelected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnClassSelected__DelegateSignature
{
	struct UWBP_DeployMenu_ClassSelectionListing_C* SelectedClassWidget;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.Init
// Size: 0x10(Inherited: 0x0) 
struct FInit
{
	struct UHDKit* Kit;  // 0x0(0x8)
	struct ABP_HDPlayerControllerBase_C* OwningPC;  // 0x8(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.OnClassDeselected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnClassDeselected__DelegateSignature
{
	struct UWBP_DeployMenu_ClassSelectionListing_C* DeselectedClassWidget;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplayEqpSlots
// Size: 0x2C(Inherited: 0x0) 
struct FInternalSetupKitDisplayEqpSlots
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FHDItemEntry CallFunc_Array_Get_Item;  // 0x8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupPrimaryWeaponIcon
// Size: 0x9(Inherited: 0x0) 
struct FInternalSetupPrimaryWeaponIcon
{
	struct UTexture2D* CallFunc_GetPrimaryItemEntryDisplayIcon_OutDisplayIcon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_GetPrimaryItemEntryDisplayIcon_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.ExecuteUbergraph_WBP_DeployMenu_ClassSelectionListing
// Size: 0x538(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_ClassSelectionListing
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct FText CallFunc_MakeLiteralText_ReturnValue;  // 0x28(0x18)
	struct FButtonStyle K2Node_Select_Default;  // 0x40(0x278)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x2B8(0x1)
	char pad_697[7];  // 0x2B9(0x7)
	struct FButtonStyle K2Node_Select_Default_2;  // 0x2C0(0x278)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalGetEqpSlotImageWidgetByNum
// Size: 0x28(Inherited: 0x0) 
struct FInternalGetEqpSlotImageWidgetByNum
{
	int32_t SlotNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UImage* EqpSlotImage;  // 0x8(0x8)
	int32_t Temp_int_Variable;  // 0x10(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UImage* K2Node_Select_Default;  // 0x20(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.UpdateRestrictedState
// Size: 0x21(Inherited: 0x0) 
struct FUpdateRestrictedState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_InternalIsKitRestricted_bKitRestricted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText CallFunc_InternalIsKitRestricted_KitRestrictionReason;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetEqpDisplaySymbolBySlotNum
// Size: 0x3C(Inherited: 0x0) 
struct FInternalSetEqpDisplaySymbolBySlotNum
{
	int32_t SlotNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UTexture2D* SlotSymbolToUse;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDesignTime : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct UImage* CallFunc_InternalGetEqpSlotImageWidgetByNum_EqpSlotImage;  // 0x18(0x8)
	struct UPanelWidget* CallFunc_GetParent_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x2C(0x10)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalKitDisplaySetup
// Size: 0x20(Inherited: 0x0) 
struct FInternalKitDisplaySetup
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_InternalIsKitRestricted_bKitRestricted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText CallFunc_InternalIsKitRestricted_KitRestrictionReason;  // 0x8(0x18)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetClassSelectionState
// Size: 0x280(Inherited: 0x0) 
struct FInternalSetClassSelectionState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewSelected : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable : 1;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct FButtonStyle K2Node_Select_Default;  // 0x8(0x278)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.ToggleClassSelection
// Size: 0x1(Inherited: 0x0) 
struct FToggleClassSelection
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplaySymbol
// Size: 0x30(Inherited: 0x0) 
struct FInternalSetupKitDisplaySymbol
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FSlateColor K2Node_Select_Default;  // 0x8(0x28)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplayName
// Size: 0x38(Inherited: 0x0) 
struct FInternalSetupKitDisplayName
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct FText K2Node_Select_Default;  // 0x8(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x20(0x18)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalIsKitRestricted
// Size: 0x78(Inherited: 0x0) 
struct FInternalIsKitRestricted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bKitRestricted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText KitRestrictionReason;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Temp_text_Variable;  // 0x28(0x18)
	struct FText CallFunc_PlayerCanStartWithKit_OutKitDenialReason;  // 0x40(0x18)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_PlayerCanStartWithKit_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91[5];  // 0x5B(0x5)
	struct FText K2Node_Select_Default;  // 0x60(0x18)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitRestrictionDisplay
// Size: 0x24(Inherited: 0x0) 
struct FInternalSetupKitRestrictionDisplay
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bKitRestricted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText KitRestrictionReason;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	uint8_t  Temp_byte_Variable;  // 0x21(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x22(0x1)
	uint8_t  K2Node_Select_Default;  // 0x23(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalUpdateClassRestrictedText
// Size: 0xA0(Inherited: 0x0) 
struct FInternalUpdateClassRestrictedText
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bKitRestricted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText KitRestrictionReason;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Temp_text_Variable;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_HasKitRequirements_ReturnValue : 1;  // 0x42(0x1)
	char pad_67[5];  // 0x43(0x5)
	struct FText K2Node_Select_Default;  // 0x48(0x18)
	struct FText K2Node_Select_Default_2;  // 0x60(0x18)
	struct FSlateColor K2Node_Select_Default_3;  // 0x78(0x28)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetClassRestrictedState
// Size: 0x21(Inherited: 0x0) 
struct FInternalSetClassRestrictedState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewRestricted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText NewRestrictionReason;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SortItemEntriesInPlaceBySlotNum
// Size: 0x54(Inherited: 0x0) 
struct FSortItemEntriesInPlaceBySlotNum
{
	struct TArray<struct FHDItemEntry> EntriesToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bSwapped : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct FHDItemEntry> SortedEntries;  // 0x18(0x10)
	int32_t Temp_int_Variable;  // 0x28(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	int32_t Temp_int_Variable_2;  // 0x48(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue_2 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool Temp_bool_Variable : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x53(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalFillEqpSlots
// Size: 0x52(Inherited: 0x0) 
struct FInternalFillEqpSlots
{
	int32_t Temp_int_Loop_Counter_Variable;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	int32_t Temp_int_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UImage* CallFunc_InternalGetEqpSlotImageWidgetByNum_EqpSlotImage;  // 0x18(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_AreColorsNearlyEqual_bEqual : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x26(0x1)
	char pad_39[1];  // 0x27(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FHDItemEntry CallFunc_Array_Get_Item;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UTexture2D* CallFunc_GetItemEntryDisplayEquipmentSymbol_OutDisplayEquipmentSymbol;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_GetItemEntryDisplayEquipmentSymbol_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x51(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.AreColorsNearlyEqual
// Size: 0x28(Inherited: 0x0) 
struct FAreColorsNearlyEqual
{
	struct FLinearColor ColorOne;  // 0x0(0x10)
	struct FLinearColor ColorTwo;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bEqual : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_2 : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_3 : 1;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_4 : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x27(0x1)

}; 
