#pragma once 
#include "SDK.h" 
 
 
// Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.ExecuteUbergraph_WBP_ModifierSettingBox
// Size: 0x58(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_ModifierSettingBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct FText K2Node_Select_Default;  // 0x28(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x40(0x18)

}; 
// Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.GetSettingText
// Size: 0x18(Inherited: 0x0) 
struct FGetSettingText
{
	struct FText SettingText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.SetSettingText
// Size: 0x30(Inherited: 0x0) 
struct FSetSettingText
{
	struct FText InSettingText;  // 0x0(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x18(0x18)

}; 
// Function WBP_ModifierSettingBox.WBP_ModifierSettingBox_C.SetSettingTextStyle
// Size: 0x78(Inherited: 0x0) 
struct FSetSettingTextStyle
{
	struct FFModifierTextStyle InSettingTextStyle;  // 0x0(0x78)

}; 
