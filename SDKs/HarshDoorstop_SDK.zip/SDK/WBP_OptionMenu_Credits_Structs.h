#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.ExecuteUbergraph_WBP_OptionMenu_Credits
// Size: 0x101(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionMenu_Credits
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UWBP_CreditsListEntry_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x20(0x8)
	struct UScrollBoxSlot* K2Node_DynamicCast_AsScroll_Box_Slot;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FMargin K2Node_MakeStruct_Margin;  // 0x34(0x10)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x48(0x10)
	struct FName CallFunc_Array_Get_Item;  // 0x58(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FFGameCreditsEntry CallFunc_GetDataTableRowFromName_OutRow;  // 0x68(0x30)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)
	struct TArray<struct FFGameCreditsEntry> CallFunc_GetCreditEntriesForHeader_CreditEntries;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	struct FGeometry K2Node_Event_MyGeometry;  // 0xB4(0x38)
	float K2Node_Event_InDeltaTime;  // 0xEC(0x4)
	float CallFunc_GetScrollOffsetOfEnd_ReturnValue;  // 0xF0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xF4(0x4)
	float CallFunc_GetScrollOffset_ReturnValue;  // 0xF8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xFC(0x4)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x100(0x1)

}; 
// Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.GetCreditEntriesForHeader
// Size: 0x93(Inherited: 0x0) 
struct FGetCreditEntriesForHeader
{
	struct FName HeaderRowName;  // 0x0(0x8)
	struct TArray<struct FFGameCreditsEntry> CreditEntries;  // 0x8(0x10)
	struct TArray<struct FFGameCreditsEntry> Entries;  // 0x18(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x28(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x38(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x4C(0x8)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FFGameCreditsEntry CallFunc_GetDataTableRowFromName_OutRow;  // 0x58(0x30)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x92(0x1)

}; 
// Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
