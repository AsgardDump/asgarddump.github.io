#pragma once 
#include <BPI_ServerFilterRuleSetting_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_ServerFilterRuleSetting_C : public UInterface
{

	void IsFilterEnabled(bool& bActive); // Function BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C.IsFilterEnabled
	void GetFilterRulePair(UHDServerListFilterRule*& Rule, struct FHDFilterRuleParams& RuleParams); // Function BPI_ServerFilterRuleSetting.BPI_ServerFilterRuleSetting_C.GetFilterRulePair
}; 



