#pragma once 
#include "SDK.h" 
 
 
// Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.SetupModifier
// Size: 0x8(Inherited: 0x0) 
struct FSetupModifier
{
	struct UWBP_OptionMenu_CreateGame_C* ParentMenu;  // 0x0(0x8)

}; 
// Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.IsEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.GetTravelURLOptions
// Size: 0x10(Inherited: 0x0) 
struct FGetTravelURLOptions
{
	struct FString Options;  // 0x0(0x10)

}; 
