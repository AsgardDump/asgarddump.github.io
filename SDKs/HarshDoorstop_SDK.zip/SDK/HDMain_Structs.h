#pragma once 
#include "SDK.h" 
 
 
// Function HDMain.HDSquadState.IsPlayerPendingRemovalFromSquad
// Size: 0x10(Inherited: 0x0) 
struct FIsPlayerPendingRemovalFromSquad
{
	struct AHDPlayerController* PC;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction HDMain.OnSquadRenamed__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnSquadRenamed__DelegateSignature
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct FText NewName;  // 0x8(0x18)
	struct FText PrevName;  // 0x20(0x18)

}; 
// DelegateFunction HDMain.OnSquadMemberChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSquadMemberChanged__DelegateSignature
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct AHDPlayerState* MemberPS;  // 0x8(0x8)

}; 
// Function HDMain.HDTeamCommChannelState.GetChannelNameForTeam
// Size: 0x10(Inherited: 0x0) 
struct FGetChannelNameForTeam
{
	struct AHDTeamState* Team;  // 0x0(0x8)
	struct FName ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct HDMain.HDPlatoonAttributes
// Size: 0x20(Inherited: 0x0) 
struct FHDPlatoonAttributes
{
	int32_t ID;  // 0x0(0x4)
	char TeamId;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText DisplayName;  // 0x8(0x18)

}; 
// Function HDMain.HDServerListView.SetItemFilterRules
// Size: 0x50(Inherited: 0x0) 
struct FSetItemFilterRules
{
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> FilterRules;  // 0x0(0x50)

}; 
// Function HDMain.HDAICombatHandler.SetEnemy
// Size: 0x8(Inherited: 0x0) 
struct FSetEnemy
{
	struct AActor* NewEnemy;  // 0x0(0x8)

}; 
// DelegateFunction HDMain.AimingHandlerContactSignature__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FAimingHandlerContactSignature__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHasContact : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDSquadState.UnregisterSquadMemberAt
// Size: 0x8(Inherited: 0x0) 
struct FUnregisterSquadMemberAt
{
	int32_t RemoveIdx;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function HDMain.HDScoreboardListingRowBase.GetCurrentPing
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentPing
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction HDMain.PlayerSquadInfoUpdateSignature__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FPlayerSquadInfoUpdateSignature__DelegateSignature
{
	struct AHDPlayerState* PlayerState;  // 0x0(0x8)
	struct FHDSquadAssignmentInfo PlayerSQInfo;  // 0x8(0x10)

}; 
// DelegateFunction HDMain.OnSquadLeaderAssigned__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnSquadLeaderAssigned__DelegateSignature
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct AHDPlayerState* NewLeaderPS;  // 0x8(0x8)
	struct AHDPlayerState* PrevLeaderPS;  // 0x10(0x8)

}; 
// ScriptStruct HDMain.HDAIMasterNavPoint
// Size: 0x10(Inherited: 0x0) 
struct FHDAIMasterNavPoint
{
	struct FVector Location;  // 0x0(0xC)
	float DistanceToNext;  // 0xC(0x4)

}; 
// DelegateFunction HDMain.OnSquadMemberInfoUpdated__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnSquadMemberInfoUpdated__DelegateSignature
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct AHDPlayerState* MemberPS;  // 0x8(0x8)
	struct FHDSquadAssignmentInfo MemberSQInfo;  // 0x10(0x10)

}; 
// Function HDMain.HDKit.GetPrimaryItemEntry
// Size: 0x18(Inherited: 0x0) 
struct FGetPrimaryItemEntry
{
	struct FHDItemEntry OutPrimaryEntry;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function HDMain.DeployMenu_SquadSelectionWidgetBase.PlatoonPreRemoveFromTeam
// Size: 0x10(Inherited: 0x0) 
struct FPlatoonPreRemoveFromTeam
{
	struct AHDTeamState* SourceTeam;  // 0x0(0x8)
	struct AHDPlatoonState* PlatoonToBeRemoved;  // 0x8(0x8)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerSetStance
// Size: 0x3(Inherited: 0x0) 
struct FOwnerSetStance
{
	uint8_t  NewStance;  // 0x0(0x1)
	uint8_t  OldStance;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bInitial : 1;  // 0x2(0x1)

}; 
// DelegateFunction HDMain.OnSquadLockToggled__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSquadLockToggled__DelegateSignature
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bNewLocked : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct HDMain.HDSquadAssignmentInfo
// Size: 0x10(Inherited: 0x0) 
struct FHDSquadAssignmentInfo
{
	struct AHDSquadState* SquadState;  // 0x0(0x8)
	float SquadAssignmentTime;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function HDMain.DeployMenu_SquadListBase.MemberPreRemoveFromSquad
// Size: 0x10(Inherited: 0x0) 
struct FMemberPreRemoveFromSquad
{
	struct AHDSquadState* SourceSquad;  // 0x0(0x8)
	struct AHDPlayerState* MemberPSToBeRemoved;  // 0x8(0x8)

}; 
// ScriptStruct HDMain.TicketBleedRulesetSettings
// Size: 0xC(Inherited: 0x0) 
struct FTicketBleedRulesetSettings
{
	int32_t TicketBleed;  // 0x0(0x4)
	int32_t MercyTicketBleed;  // 0x4(0x4)
	char bAllowMercyTicketBleed : 1;  // 0x8(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	char pad_9[4];  // 0x9(0x4)

}; 
// Function HDMain.HDServerListView.GetDesiredEntryPaddingForItem
// Size: 0x18(Inherited: 0x0) 
struct FGetDesiredEntryPaddingForItem
{
	struct UObject* Item;  // 0x0(0x8)
	struct FMargin ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction HDMain.OnPlatoonSquadChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnPlatoonSquadChanged__DelegateSignature
{
	struct AHDPlatoonState* Platoon;  // 0x0(0x8)
	struct AHDSquadState* Squad;  // 0x8(0x8)

}; 
// Function HDMain.DeployMenu_PlatoonSquadListBase.SetupPlatoon
// Size: 0x8(Inherited: 0x0) 
struct FSetupPlatoon
{
	struct UPlatoonListEntry* InPlatoonData;  // 0x0(0x8)

}; 
// Function HDMain.HDGOAPComponent.IsAIActive
// Size: 0x1(Inherited: 0x0) 
struct FIsAIActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction HDMain.CaptureProgressSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FCaptureProgressSignature__DelegateSignature
{
	struct AHDBaseCapturePoint* ControlPoint;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bContested : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Progress;  // 0xC(0x4)

}; 
// Function HDMain.HDUIUWWeaponStatus.OwnerAimStyleChanged
// Size: 0x10(Inherited: 0x0) 
struct FOwnerAimStyleChanged
{
	struct AHDPlayerCharacter* Character;  // 0x0(0x8)
	uint8_t  NewAimStyle;  // 0x8(0x1)
	uint8_t  PrevAimStyle;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bFromPlayerInput : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerSprintTransitionUpdate
// Size: 0x1(Inherited: 0x0) 
struct FOwnerSprintTransitionUpdate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsSprinting : 1;  // 0x0(0x1)

}; 
// ScriptStruct HDMain.HDItemEntry
// Size: 0x10(Inherited: 0x0) 
struct FHDItemEntry
{
	AHDBaseWeapon* ItemClass;  // 0x0(0x8)
	int32_t SlotNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction HDMain.OwningTeamUpdateSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOwningTeamUpdateSignature__DelegateSignature
{
	struct AHDBaseCapturePoint* ControlPoint;  // 0x0(0x8)
	uint8_t  PrevTeam;  // 0x8(0x1)
	uint8_t  NewTeam;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bCaptured : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// DelegateFunction HDMain.TeamCaptureStatusUpdateSignature__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FTeamCaptureStatusUpdateSignature__DelegateSignature
{
	struct AHDBaseCapturePoint* ControlPoint;  // 0x0(0x8)

}; 
// Function HDMain.DeployMenu_SquadListBase.MemberSquadInfoUpdated
// Size: 0x20(Inherited: 0x0) 
struct FMemberSquadInfoUpdated
{
	struct AHDSquadState* SourceSquad;  // 0x0(0x8)
	struct AHDPlayerState* MemberPS;  // 0x8(0x8)
	struct FHDSquadAssignmentInfo MemberSQInfo;  // 0x10(0x10)

}; 
// Function HDMain.HDBaseCapturePoint.SetActive
// Size: 0x1(Inherited: 0x0) 
struct FSetActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewActive : 1;  // 0x0(0x1)

}; 
// DelegateFunction HDMain.CharacterAimStyleChangedSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FCharacterAimStyleChangedSignature__DelegateSignature
{
	struct AHDPlayerCharacter* Character;  // 0x0(0x8)
	uint8_t  NewAimStyle;  // 0x8(0x1)
	uint8_t  PrevAimStyle;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bFromPlayerInput : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// DelegateFunction HDMain.OnTeamPlatoonChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnTeamPlatoonChanged__DelegateSignature
{
	struct AHDTeamState* Team;  // 0x0(0x8)
	struct AHDPlatoonState* Platoon;  // 0x8(0x8)

}; 
// Function HDMain.DeployMenu_PlatoonSquadListBase.GenerateSquad
// Size: 0x8(Inherited: 0x0) 
struct FGenerateSquad
{
	struct USquadListEntry* SquadData;  // 0x0(0x8)

}; 
// ScriptStruct HDMain.HDPrimaryAssetSearchPath
// Size: 0x18(Inherited: 0x0) 
struct FHDPrimaryAssetSearchPath
{
	uint8_t  AssetType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Directory;  // 0x8(0x10)

}; 
// ScriptStruct HDMain.HDAISpecificItemTypeAttackData
// Size: 0x2C(Inherited: 0x0) 
struct FHDAISpecificItemTypeAttackData
{
	float AttackRateMin;  // 0x0(0x4)
	float AttackRateMax;  // 0x4(0x4)
	float BurstAttackProbability;  // 0x8(0x4)
	int32_t BurstAttackNumberMin;  // 0xC(0x4)
	int32_t BurstAttackNumberMax;  // 0x10(0x4)
	float WeaponStopFireTimeMin;  // 0x14(0x4)
	float WeaponStopFireTimeMax;  // 0x18(0x4)
	float AfterEquipCooldownTime;  // 0x1C(0x4)
	float SpecialtyItemUseTimeLimit;  // 0x20(0x4)
	float AfterSpecialtyItemUsedTimeLimit;  // 0x24(0x4)
	char bWeaponMovementFire : 1;  // 0x28(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	char pad_41[4];  // 0x29(0x4)

}; 
// Function HDMain.HDUIUWCaptureStatus.ControlPointSetGarrisonedPlayerCount
// Size: 0x10(Inherited: 0x0) 
struct FControlPointSetGarrisonedPlayerCount
{
	int32_t NumFriendlies;  // 0x0(0x4)
	int32_t NumEnemies;  // 0x4(0x4)
	int32_t MinNumRequiredForCapture;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function HDMain.HDSquadState.GetSquadMemberAt
// Size: 0x10(Inherited: 0x0) 
struct FGetSquadMemberAt
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AHDPlayerState* ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.DeployMenu_SquadMemberListingBase.GetParentSquadStateFromData
// Size: 0x8(Inherited: 0x0) 
struct FGetParentSquadStateFromData
{
	struct AHDSquadState* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct HDMain.HDAIItemData
// Size: 0x8(Inherited: 0x0) 
struct FHDAIItemData
{
	uint8_t  SpecificType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t InventoryIndex;  // 0x4(0x4)

}; 
// ScriptStruct HDMain.HDSquadCreationParams
// Size: 0x30(Inherited: 0x0) 
struct FHDSquadCreationParams
{
	struct FText DisplayName;  // 0x0(0x18)
	struct AHDPlatoonState* OwnerPlatoon;  // 0x18(0x8)
	struct AHDPlayerState* SquadLeader;  // 0x20(0x8)
	char bLocked : 1;  // 0x28(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	char pad_41[8];  // 0x29(0x8)

}; 
// ScriptStruct HDMain.HDAIGroupData
// Size: 0x28(Inherited: 0x0) 
struct FHDAIGroupData
{
	struct AHDBaseCapturePoint* CapturePoint;  // 0x0(0x8)
	uint8_t  CaptureMode;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector GroupCenter;  // 0xC(0xC)
	struct FVector TargetLocation;  // 0x18(0xC)
	int32_t FormationIndex;  // 0x24(0x4)

}; 
// ScriptStruct HDMain.PTTKeyState
// Size: 0xC(Inherited: 0x0) 
struct FPTTKeyState
{
	char pad_0[12];  // 0x0(0xC)

}; 
// Function HDMain.DeployMenu_PlatoonSquadListBase.SquadAddedToPlatoon
// Size: 0x10(Inherited: 0x0) 
struct FSquadAddedToPlatoon
{
	struct AHDPlatoonState* SourcePlatoon;  // 0x0(0x8)
	struct AHDSquadState* NewSquad;  // 0x8(0x8)

}; 
// ScriptStruct HDMain.ControlPointRulesetSettings
// Size: 0x20(Inherited: 0x0) 
struct FControlPointRulesetSettings
{
	int32_t TicketsGainedForCapture;  // 0x0(0x4)
	int32_t TicketsGainedForCaptureFromNeutral;  // 0x4(0x4)
	int32_t TicketsLostOnCapture;  // 0x8(0x4)
	float PointsForNeutralize;  // 0xC(0x4)
	float PointsForCapture;  // 0x10(0x4)
	float PointsForDefense;  // 0x14(0x4)
	float PointsOnCaptureProgress;  // 0x18(0x4)
	float PointsOnDefenseProgress;  // 0x1C(0x4)

}; 
// Function HDMain.HDTeamState.IsPlatoonPendingRemovalFromTeam
// Size: 0x10(Inherited: 0x0) 
struct FIsPlatoonPendingRemovalFromTeam
{
	struct AHDPlatoonState* Platoon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.DeployMenu_SquadListBase.SetupSquad
// Size: 0x8(Inherited: 0x0) 
struct FSetupSquad
{
	struct USquadListEntry* InSquadData;  // 0x0(0x8)

}; 
// Function HDMain.HDAINavigationHandler.IsNavigationPossible
// Size: 0x1(Inherited: 0x0) 
struct FIsNavigationPossible
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct HDMain.KillDeathRulesetSettings
// Size: 0x28(Inherited: 0x0) 
struct FKillDeathRulesetSettings
{
	int32_t TicketsGainedForKill;  // 0x0(0x4)
	int32_t TicketsLostOnKill;  // 0x4(0x4)
	int32_t TicketsLostOnTeamKill;  // 0x8(0x4)
	int32_t TicketsLostOnDeath;  // 0xC(0x4)
	int32_t TicketsLostOnSuicide;  // 0x10(0x4)
	float PointsForKill;  // 0x14(0x4)
	float PointsForAssist;  // 0x18(0x4)
	float PointsForTeamKill;  // 0x1C(0x4)
	float PointsForDeath;  // 0x20(0x4)
	float PointsForSuicide;  // 0x24(0x4)

}; 
// Function HDMain.DeployMenu_SquadMemberListingBase.SetupMember
// Size: 0x8(Inherited: 0x0) 
struct FSetupMember
{
	struct USquadMemberInfo* InMemberData;  // 0x0(0x8)

}; 
// ScriptStruct HDMain.AICharacterVocalProfile
// Size: 0x68(Inherited: 0x8) 
struct FAICharacterVocalProfile : public FTableRowBase
{
	struct TArray<struct USoundBase*> ContactSounds;  // 0x8(0x10)
	struct TArray<struct USoundBase*> LostContactSounds;  // 0x18(0x10)
	struct TArray<struct USoundBase*> ReloadingSounds;  // 0x28(0x10)
	struct TArray<struct USoundBase*> BeenHitSounds;  // 0x38(0x10)
	struct TArray<struct USoundBase*> UnderSuppressionSounds;  // 0x48(0x10)
	struct TArray<struct USoundBase*> DeathSounds;  // 0x58(0x10)

}; 
// ScriptStruct HDMain.HDGameRoundEndEventDetails
// Size: 0x10(Inherited: 0x0) 
struct FHDGameRoundEndEventDetails
{
	int32_t ElapsedTime;  // 0x0(0x4)
	uint8_t  WinningTeam;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t BluforTickets;  // 0x8(0x4)
	int32_t OpforTickets;  // 0xC(0x4)

}; 
// Function HDMain.HDPlatoonCreationRuleBase.SatisfiesRule
// Size: 0x10(Inherited: 0x0) 
struct FSatisfiesRule
{
	struct UHDTeamDefinition* TeamDef;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct HDMain.HDCharacterVariationData
// Size: 0x68(Inherited: 0x68) 
struct FHDCharacterVariationData : public FDFCharacterVariationData
{

}; 
// Function HDMain.DeployMenu_SquadListBase.MemberAddedToSquad
// Size: 0x10(Inherited: 0x0) 
struct FMemberAddedToSquad
{
	struct AHDSquadState* SourceSquad;  // 0x0(0x8)
	struct AHDPlayerState* NewMemberPS;  // 0x8(0x8)

}; 
// ScriptStruct HDMain.HDPlatoonCreationParams
// Size: 0x10(Inherited: 0x0) 
struct FHDPlatoonCreationParams
{
	struct UHDPlatoonInfo* Info;  // 0x0(0x8)
	struct AHDTeamState* OwnerTeam;  // 0x8(0x8)

}; 
// Function HDMain.DeployMenu_PlatoonSquadListBase.GetPlatoonStateFromData
// Size: 0x8(Inherited: 0x0) 
struct FGetPlatoonStateFromData
{
	struct AHDPlatoonState* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDPlatoonState.ReceiveSquadAdded
// Size: 0x8(Inherited: 0x0) 
struct FReceiveSquadAdded
{
	struct AHDSquadState* Squad;  // 0x0(0x8)

}; 
// ScriptStruct HDMain.HDServerInfo
// Size: 0xA0(Inherited: 0x0) 
struct FHDServerInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString GameVersion;  // 0x8(0x10)
	struct FString ServerName;  // 0x18(0x10)
	char pad_40[16];  // 0x28(0x10)
	struct FHDServerInfoFlags ServerFlags;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FString ModName;  // 0x40(0x10)
	struct FString GameMode;  // 0x50(0x10)
	struct FString MapName;  // 0x60(0x10)
	struct FPrimaryAssetId MapId;  // 0x70(0x10)
	struct UTexture2D* MapBannerImg;  // 0x80(0x8)
	struct UTexture2D* MapThumbnailImg;  // 0x88(0x8)
	int32_t CurrentPlayers;  // 0x90(0x4)
	int32_t MaxPlayers;  // 0x94(0x4)
	int32_t Ping;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerSetStanceState
// Size: 0x3(Inherited: 0x0) 
struct FOwnerSetStanceState
{
	uint8_t  NewState;  // 0x0(0x1)
	uint8_t  OldState;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bInitial : 1;  // 0x2(0x1)

}; 
// ScriptStruct HDMain.HDServerInfoFlags
// Size: 0x4(Inherited: 0x0) 
struct FHDServerInfoFlags
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPasswordProtected : 1;  // 0x0(0x1)
	uint8_t  WhitelistType;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bSupportersOnlyWhitelist : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bUtilizesUGC : 1;  // 0x3(0x1)

}; 
// ScriptStruct HDMain.HDFilterRuleParams
// Size: 0x2(Inherited: 0x0) 
struct FHDFilterRuleParams
{
	uint8_t  Behavior;  // 0x0(0x1)
	uint8_t  ComparisonOp;  // 0x1(0x1)

}; 
// Function HDMain.HDPlatoonState.GetNumSquads
// Size: 0x8(Inherited: 0x0) 
struct FGetNumSquads
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidSquadsOnly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function HDMain.DeployMenu_SquadListBase.SquadNameChanged
// Size: 0x38(Inherited: 0x0) 
struct FSquadNameChanged
{
	struct AHDSquadState* SourceSquad;  // 0x0(0x8)
	struct FText NewName;  // 0x8(0x18)
	struct FText PrevName;  // 0x20(0x18)

}; 
// ScriptStruct HDMain.HDUIWeaponAmmoState
// Size: 0x18(Inherited: 0x0) 
struct FHDUIWeaponAmmoState
{
	int32_t TotalFreeAmmo;  // 0x0(0x4)
	int32_t NumFreeAmmoClips;  // 0x4(0x4)
	int32_t CurrentClipAmmo;  // 0x8(0x4)
	int32_t CurrentClipMaxAmmo;  // 0xC(0x4)
	ADFBaseAmmoClip* CurrentClipAmmoClass;  // 0x10(0x8)

}; 
// Function HDMain.HDBaseCapturePoint.ReceiveOnLocked
// Size: 0x1(Inherited: 0x0) 
struct FReceiveOnLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewLocked : 1;  // 0x0(0x1)

}; 
// Function HDMain.DeployMenu_PlatoonSquadListBase.SquadPreRemoveFromPlatoon
// Size: 0x10(Inherited: 0x0) 
struct FSquadPreRemoveFromPlatoon
{
	struct AHDPlatoonState* SourcePlatoon;  // 0x0(0x8)
	struct AHDSquadState* SquadToBeRemoved;  // 0x8(0x8)

}; 
// Function HDMain.HDGameInstance.OwnsAppBP
// Size: 0x10(Inherited: 0x0) 
struct FOwnsAppBP
{
	int64_t AppID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct HDMain.UniqueNetIdVoipWrapper
// Size: 0x18(Inherited: 0x0) 
struct FUniqueNetIdVoipWrapper
{
	char pad_0[24];  // 0x0(0x18)

}; 
// Function HDMain.DeployMenu_SquadMemberListingBase.GetPlayerStateFromData
// Size: 0x8(Inherited: 0x0) 
struct FGetPlayerStateFromData
{
	struct AHDPlayerState* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.DeployMenu_SquadMemberListingBase.OnMemberPlayerNameUpdated
// Size: 0x10(Inherited: 0x0) 
struct FOnMemberPlayerNameUpdated
{
	struct FString NewPlayerName;  // 0x0(0x10)

}; 
// Function HDMain.DeployMenu_PlatoonSquadListBase.DeconstructSquad
// Size: 0x10(Inherited: 0x0) 
struct FDeconstructSquad
{
	struct USquadListEntry* RemovedSquadData;  // 0x0(0x8)
	int32_t RemovedSquadIdx;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function HDMain.DeployMenu_SquadSelectionWidgetBase.GeneratePlatoon
// Size: 0x8(Inherited: 0x0) 
struct FGeneratePlatoon
{
	struct UPlatoonListEntry* PlatoonData;  // 0x0(0x8)

}; 
// Function HDMain.DeployMenu_SquadListBase.DeconstructSquadMember
// Size: 0x8(Inherited: 0x0) 
struct FDeconstructSquadMember
{
	struct USquadMemberInfo* RemovedMemberData;  // 0x0(0x8)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.IsGroupWaitTimeOver
// Size: 0x1(Inherited: 0x0) 
struct FIsGroupWaitTimeOver
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.DeployMenu_SquadListBase.GenerateSquadMember
// Size: 0x8(Inherited: 0x0) 
struct FGenerateSquadMember
{
	struct USquadMemberInfo* MemberData;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerCharacter.SetAllowFreeAim
// Size: 0x1(Inherited: 0x0) 
struct FSetAllowFreeAim
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function HDMain.DeployMenu_SquadMemberListingBase.GetParentPlatoonStateFromData
// Size: 0x8(Inherited: 0x0) 
struct FGetParentPlatoonStateFromData
{
	struct AHDPlatoonState* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.SquadMemberInfo.GetParentSquadState
// Size: 0x8(Inherited: 0x0) 
struct FGetParentSquadState
{
	struct AHDSquadState* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerCharacter.GetMaxFreeAimPitchToUse
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxFreeAimPitchToUse
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function HDMain.HDAIAimingHandler.EstablishNewTargetFromPerception
// Size: 0x8(Inherited: 0x0) 
struct FEstablishNewTargetFromPerception
{
	UAISense* SenseToUse;  // 0x0(0x8)

}; 
// Function HDMain.DeployMenu_SquadListBase.GetSquadStateFromData
// Size: 0x8(Inherited: 0x0) 
struct FGetSquadStateFromData
{
	struct AHDSquadState* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDSquadState.ReceiveSquadMemberRegistered
// Size: 0x8(Inherited: 0x0) 
struct FReceiveSquadMemberRegistered
{
	struct AHDPlayerState* MemberPS;  // 0x0(0x8)

}; 
// Function HDMain.DeployMenu_SquadListBase.OnSquadLeaderUpdated
// Size: 0x10(Inherited: 0x0) 
struct FOnSquadLeaderUpdated
{
	struct AHDPlayerState* NewLeaderPS;  // 0x0(0x8)
	struct AHDPlayerState* PrevLeaderPS;  // 0x8(0x8)

}; 
// Function HDMain.HDVoipIndicatorWidgetBase.OnPlayerStopTalking
// Size: 0x8(Inherited: 0x0) 
struct FOnPlayerStopTalking
{
	struct UHDVoiceChatMsgInfo* TalkerMsgInfo;  // 0x0(0x8)

}; 
// Function HDMain.HDVoipIndicatorWidgetBase.OnOwningPlayerStopTalking
// Size: 0x8(Inherited: 0x0) 
struct FOnOwningPlayerStopTalking
{
	struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo;  // 0x0(0x8)

}; 
// Function HDMain.DeployMenu_SquadListBase.OnSquadLockStateUpdated
// Size: 0x1(Inherited: 0x0) 
struct FOnSquadLockStateUpdated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewLockedState : 1;  // 0x0(0x1)

}; 
// Function HDMain.DeployMenu_SquadListBase.OnSquadNameUpdated
// Size: 0x30(Inherited: 0x0) 
struct FOnSquadNameUpdated
{
	struct FText NewSquadName;  // 0x0(0x18)
	struct FText PreviousSquadName;  // 0x18(0x18)

}; 
// Function HDMain.DeployMenu_SquadListBase.SquadLeaderChanged
// Size: 0x18(Inherited: 0x0) 
struct FSquadLeaderChanged
{
	struct AHDSquadState* SourceSquad;  // 0x0(0x8)
	struct AHDPlayerState* NewLeaderPS;  // 0x8(0x8)
	struct AHDPlayerState* PrevLeaderPS;  // 0x10(0x8)

}; 
// Function HDMain.DeployMenu_SquadListBase.SquadLockStateUpdated
// Size: 0x10(Inherited: 0x0) 
struct FSquadLockStateUpdated
{
	struct AHDSquadState* SourceSquad;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bNewLocked : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.DeployMenu_SquadMemberListingBase.MemberPlayerNameChanged
// Size: 0x18(Inherited: 0x0) 
struct FMemberPlayerNameChanged
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct FString NewPlayerName;  // 0x8(0x10)

}; 
// Function HDMain.DeployMenu_SquadSelectionWidgetBase.DeconstructPlatoon
// Size: 0x10(Inherited: 0x0) 
struct FDeconstructPlatoon
{
	struct UPlatoonListEntry* RemovedPlatoonData;  // 0x0(0x8)
	int32_t RemovedPlatoonIdx;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function HDMain.DeployMenu_SquadSelectionWidgetBase.PlatoonAddedToTeam
// Size: 0x10(Inherited: 0x0) 
struct FPlatoonAddedToTeam
{
	struct AHDTeamState* SourceTeam;  // 0x0(0x8)
	struct AHDPlatoonState* NewPlatoon;  // 0x8(0x8)

}; 
// Function HDMain.HDPlayerCharacter.NotifyPlayerStateChanged
// Size: 0x10(Inherited: 0x0) 
struct FNotifyPlayerStateChanged
{
	struct APlayerState* NewPlayerState;  // 0x0(0x8)
	struct APlayerState* OldPlayerState;  // 0x8(0x8)

}; 
// Function HDMain.HDGameState.IsGameUsingTickets
// Size: 0x1(Inherited: 0x0) 
struct FIsGameUsingTickets
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.DeployMenu_SquadSelectionWidgetBase.SetupSquadSelection
// Size: 0x8(Inherited: 0x0) 
struct FSetupSquadSelection
{
	struct AHDTeamState* InPlatoonTeamState;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerHealthUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOwnerHealthUpdate
{
	struct ADFBaseCharacter* Character;  // 0x0(0x8)
	float NewHealthTotal;  // 0x8(0x4)
	float PrevHealthTotal;  // 0xC(0x4)

}; 
// Function HDMain.HDAIAimingHandler.CheckForTarget
// Size: 0x48(Inherited: 0x0) 
struct FCheckForTarget
{
	struct AActor* TargetActor;  // 0x0(0x8)
	struct FAIStimulus Stimulus;  // 0x8(0x3C)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)

}; 
// Function HDMain.HDAIAimingHandler.GetActorStimulusData
// Size: 0x20(Inherited: 0x0) 
struct FGetActorStimulusData
{
	struct AActor* InActor;  // 0x0(0x8)
	struct FVector OutLocation;  // 0x8(0xC)
	float OutStrength;  // 0x14(0x4)
	float OutAge;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function HDMain.VictoryMenu.Init
// Size: 0x14(Inherited: 0x0) 
struct FInit
{
	struct FHDGameRoundEndEventDetails InRoundDetails;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bInWinner : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function HDMain.HDAIAimingHandler.GetEnableNoEnemyLookAround
// Size: 0x1(Inherited: 0x0) 
struct FGetEnableNoEnemyLookAround
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIAimingHandler.GetIsNewTargetMoreRelevant
// Size: 0xC(Inherited: 0x0) 
struct FGetIsNewTargetMoreRelevant
{
	float OldTargetStrength;  // 0x0(0x4)
	float NewTargetStrength;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDAIAimingHandler.GetNoEnemyFocalPoint
// Size: 0xC(Inherited: 0x0) 
struct FGetNoEnemyFocalPoint
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function HDMain.HDAIAimingHandler.IsAimingAtTarget
// Size: 0x1(Inherited: 0x0) 
struct FIsAimingAtTarget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDBaseGameMode.RemoveBluforBots
// Size: 0x4(Inherited: 0x0) 
struct FRemoveBluforBots
{
	int32_t Num;  // 0x0(0x4)

}; 
// Function HDMain.HDAIAimingHandler.IsCandidateTarget
// Size: 0x10(Inherited: 0x0) 
struct FIsCandidateTarget
{
	struct AActor* ActorToCheck;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDServerListView.SortListItems
// Size: 0x2(Inherited: 0x0) 
struct FSortListItems
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSortAscending : 1;  // 0x0(0x1)
	uint8_t  SortBy;  // 0x1(0x1)

}; 
// Function HDMain.HDAIAimingHandler.SetEnableNoEnemyLookAround
// Size: 0x1(Inherited: 0x0) 
struct FSetEnableNoEnemyLookAround
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInEnableNoEnemyLookAround : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDServerListView.SetItemSortAscending
// Size: 0x1(Inherited: 0x0) 
struct FSetItemSortAscending
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSortAscending : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIAimingHandler.ShouldChangeNoEnemyFocalPoint
// Size: 0x1(Inherited: 0x0) 
struct FShouldChangeNoEnemyFocalPoint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDBaseCapturePoint.CanCapture
// Size: 0x1(Inherited: 0x0) 
struct FCanCapture
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIAimingHandler.SuggestProjectileVelocity
// Size: 0x2C(Inherited: 0x0) 
struct FSuggestProjectileVelocity
{
	struct FVector TossVelocity;  // 0x0(0xC)
	struct FVector StartLocation;  // 0xC(0xC)
	struct FVector EndLocation;  // 0x18(0xC)
	float TossSpeed;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)

}; 
// Function HDMain.HDAIBehaviorHandler.GetIsBeingHit
// Size: 0x1(Inherited: 0x0) 
struct FGetIsBeingHit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIBehaviorHandler.GetIsUnderSuppression
// Size: 0x1(Inherited: 0x0) 
struct FGetIsUnderSuppression
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAICaptureHandler.EstablishNewControlPoint
// Size: 0x1(Inherited: 0x0) 
struct FEstablishNewControlPoint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIPerceptionComponent.CalcSightStrength
// Size: 0x8(Inherited: 0x0) 
struct FCalcSightStrength
{
	float Distance;  // 0x0(0x4)
	float ReturnValue;  // 0x4(0x4)

}; 
// Function HDMain.HDAINavigationHandler.SetDesiredLocation
// Size: 0xC(Inherited: 0x0) 
struct FSetDesiredLocation
{
	struct FVector InDesiredLocation;  // 0x0(0xC)

}; 
// Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfType
// Size: 0x18(Inherited: 0x0) 
struct FFindAvailableControlPointsOfType
{
	uint8_t  InCaptureMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AHDBaseCapturePoint*> ReturnValue;  // 0x8(0x10)

}; 
// Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV1
// Size: 0x18(Inherited: 0x0) 
struct FFindAvailableControlPointsOfTypeV1
{
	uint8_t  InCaptureMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AHDBaseCapturePoint*> ReturnValue;  // 0x8(0x10)

}; 
// Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV2
// Size: 0x18(Inherited: 0x0) 
struct FFindAvailableControlPointsOfTypeV2
{
	uint8_t  InCaptureMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AHDBaseCapturePoint*> ReturnValue;  // 0x8(0x10)

}; 
// Function HDMain.HDPlayerCharacter.GetMaxFreeAimYawToUse
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxFreeAimYawToUse
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function HDMain.HDAIPerceptionComponent.CanBeSeenFrom
// Size: 0x30(Inherited: 0x0) 
struct FCanBeSeenFrom
{
	struct FVector ObserverLocation;  // 0x0(0xC)
	struct FVector OutSeenLocation;  // 0xC(0xC)
	int32_t NumberOfLoSChecksPerformed;  // 0x18(0x4)
	float OutSightStrength;  // 0x1C(0x4)
	struct AActor* IgnoreActor;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function HDMain.HDAICaptureHandler.FindAvailableControlPointsOfTypeV3
// Size: 0x18(Inherited: 0x0) 
struct FFindAvailableControlPointsOfTypeV3
{
	uint8_t  InCaptureMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AHDBaseCapturePoint*> ReturnValue;  // 0x8(0x10)

}; 
// Function HDMain.HDAICaptureHandler.FindControlPointClosestToPawn
// Size: 0x18(Inherited: 0x0) 
struct FFindControlPointClosestToPawn
{
	struct TArray<struct AHDBaseCapturePoint*> CPs;  // 0x0(0x10)
	struct AHDBaseCapturePoint* ReturnValue;  // 0x10(0x8)

}; 
// Function HDMain.HDAICaptureHandler.FindControlPointRandom
// Size: 0x18(Inherited: 0x0) 
struct FFindControlPointRandom
{
	struct TArray<struct AHDBaseCapturePoint*> CPs;  // 0x0(0x10)
	struct AHDBaseCapturePoint* ReturnValue;  // 0x10(0x8)

}; 
// Function HDMain.HDUIUserWidget.GetOwningHDPlayerCharacterMovement
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningHDPlayerCharacterMovement
{
	struct UDFCharacterMovementComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDAICaptureHandler.FindControlPointToCapture
// Size: 0x10(Inherited: 0x0) 
struct FFindControlPointToCapture
{
	struct AHDBaseCapturePoint* OutFoundCP;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDAICaptureHandler.GetCurrentCPLocation
// Size: 0xC(Inherited: 0x0) 
struct FGetCurrentCPLocation
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function HDMain.HDAICaptureHandler.GetStartSpotClosestToControlPoint
// Size: 0x10(Inherited: 0x0) 
struct FGetStartSpotClosestToControlPoint
{
	struct AActor* InCapturePoint;  // 0x0(0x8)
	struct AActor* ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDTeamState.FindPlatoonByDefinition
// Size: 0x18(Inherited: 0x0) 
struct FFindPlatoonByDefinition
{
	struct UHDPlatoonInfo* PlatoonDef;  // 0x0(0x8)
	struct AHDPlatoonState* OutFoundPlatoon;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function HDMain.HDSquadState.SquadMemberPSEndPlay
// Size: 0x10(Inherited: 0x0) 
struct FSquadMemberPSEndPlay
{
	struct AActor* Actor;  // 0x0(0x8)
	char EEndPlayReason EndPlayReason;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDBaseCapturePoint.ReceiveOnActive
// Size: 0x1(Inherited: 0x0) 
struct FReceiveOnActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewActive : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAICaptureHandler.SetCurrentCaptureMode
// Size: 0x1(Inherited: 0x0) 
struct FSetCurrentCaptureMode
{
	uint8_t  NewCaptureMode;  // 0x0(0x1)

}; 
// Function HDMain.HDAICaptureHandler.SetCurrentCP
// Size: 0x8(Inherited: 0x0) 
struct FSetCurrentCP
{
	struct AHDBaseCapturePoint* InCurrentCP;  // 0x0(0x8)

}; 
// Function HDMain.HDAICaptureHandler.ShouldEstablishNewControlPoint
// Size: 0x1(Inherited: 0x0) 
struct FShouldEstablishNewControlPoint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAICombatHandler.CanAttackEnemy
// Size: 0x3(Inherited: 0x0) 
struct FCanAttackEnemy
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCheckFireTime : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bIgnoreAmmoReloadCheck : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool ReturnValue : 1;  // 0x2(0x1)

}; 
// Function HDMain.HDTeamState.PlatoonExists
// Size: 0x10(Inherited: 0x0) 
struct FPlatoonExists
{
	struct AHDPlatoonState* Platoon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function HDMain.HDBaseCapturePoint.OnOwningTeamUpdated
// Size: 0x1(Inherited: 0x0) 
struct FOnOwningTeamUpdated
{
	uint8_t  LastOwningTeam;  // 0x0(0x1)

}; 
// Function HDMain.HDAICombatHandler.HasAmmoLoaded
// Size: 0x1(Inherited: 0x0) 
struct FHasAmmoLoaded
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDServerListView.SetItemSortBy
// Size: 0x1(Inherited: 0x0) 
struct FSetItemSortBy
{
	uint8_t  SortBy;  // 0x0(0x1)

}; 
// Function HDMain.HDAICombatHandler.HasValidEnemy
// Size: 0x2(Inherited: 0x0) 
struct FHasValidEnemy
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAliveCheck : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function HDMain.HDAICombatHandler.IsFiring
// Size: 0x1(Inherited: 0x0) 
struct FIsFiring
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDUIUserWidget.OwnerPossessPawn
// Size: 0x8(Inherited: 0x0) 
struct FOwnerPossessPawn
{
	struct APawn* NewPawn;  // 0x0(0x8)

}; 
// Function HDMain.HDAINavigationHandler.IsPawnAtDestination
// Size: 0x1(Inherited: 0x0) 
struct FIsPawnAtDestination
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAICombatHandler.ReceiveHitDamage
// Size: 0x10(Inherited: 0x0) 
struct FReceiveHitDamage
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)

}; 
// Function HDMain.HDAICombatHandler.ReceiveSuppression
// Size: 0x10(Inherited: 0x0) 
struct FReceiveSuppression
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)

}; 
// Function HDMain.HDAICombatHandler.Reload
// Size: 0x8(Inherited: 0x0) 
struct FReload
{
	struct AHDBaseWeapon* InWeapon;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUWCaptureStatus.OwnerEndOverlap
// Size: 0x10(Inherited: 0x0) 
struct FOwnerEndOverlap
{
	struct AActor* OverlappedOwnerChar;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
// Function HDMain.HDAICombatHandler.SetItemAttackParameters
// Size: 0x2C(Inherited: 0x0) 
struct FSetItemAttackParameters
{
	struct FHDAISpecificItemTypeAttackData InAttackData;  // 0x0(0x2C)

}; 
// Function HDMain.HDAINavigationHandler.CalcObstacleAvoidanceVector
// Size: 0xC(Inherited: 0x0) 
struct FCalcObstacleAvoidanceVector
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function HDMain.HDAICombatHandler.SetWeaponAutoReloadEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetWeaponAutoReloadEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInWeaponAutoReload : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDSquadState.OnRep_SquadLeader
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_SquadLeader
{
	struct AHDPlayerState* PrevSquadLeader;  // 0x0(0x8)

}; 
// Function HDMain.HDPlatoonState.IsSquadPendingRemovalFromPlatoon
// Size: 0x10(Inherited: 0x0) 
struct FIsSquadPendingRemovalFromPlatoon
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDAICombatHandler.SetWeaponMovementFireEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetWeaponMovementFireEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInWeaponMovementFire : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIController.GetFactionSpecifiedSquadLeaderKit
// Size: 0x8(Inherited: 0x0) 
struct FGetFactionSpecifiedSquadLeaderKit
{
	struct UHDKit* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDTextChatWidgetBase.GetCachedChatMsgAt
// Size: 0x18(Inherited: 0x0) 
struct FGetCachedChatMsgAt
{
	int32_t MsgIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UHDTextChatMsgInfo* OutFoundMsg;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function HDMain.HDPlatoonState.RemoveSquad
// Size: 0x8(Inherited: 0x0) 
struct FRemoveSquad
{
	struct AHDSquadState* SquadToRemove;  // 0x0(0x8)

}; 
// Function HDMain.HDAIController.GetFactionSpecifiedSquadMemberKit
// Size: 0x8(Inherited: 0x0) 
struct FGetFactionSpecifiedSquadMemberKit
{
	struct UHDKit* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDAIController.GetStartPawnClass
// Size: 0x8(Inherited: 0x0) 
struct FGetStartPawnClass
{
	APawn* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDAIController.JoinOrCreateSquad
// Size: 0x1(Inherited: 0x0) 
struct FJoinOrCreateSquad
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.AllGroupMembersAreOnPoint
// Size: 0x1(Inherited: 0x0) 
struct FAllGroupMembersAreOnPoint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.GetGroupData
// Size: 0x28(Inherited: 0x0) 
struct FGetGroupData
{
	struct FHDAIGroupData ReturnValue;  // 0x0(0x28)

}; 
// Function HDMain.HDSquadState.ReceiveSquadMemberPreUnregister
// Size: 0x8(Inherited: 0x0) 
struct FReceiveSquadMemberPreUnregister
{
	struct AHDPlayerState* MemberPS;  // 0x0(0x8)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.MakeNewMasterNavPath
// Size: 0x18(Inherited: 0x0) 
struct FMakeNewMasterNavPath
{
	struct FVector InStart;  // 0x0(0xC)
	struct FVector InDestination;  // 0xC(0xC)

}; 
// Function HDMain.HDSquadState.AssignSquadLeader
// Size: 0x10(Inherited: 0x0) 
struct FAssignSquadLeader
{
	struct AHDPlayerState* NewLeaderPS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.OnOwnerDeath
// Size: 0x38(Inherited: 0x0) 
struct FOnOwnerDeath
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function HDMain.HDUIUserWidget.BPDeinitializeFromOwnerPlayerCharacter
// Size: 0x8(Inherited: 0x0) 
struct FBPDeinitializeFromOwnerPlayerCharacter
{
	struct AHDPlayerCharacter* OwnerPlyChar;  // 0x0(0x8)

}; 
// Function HDMain.HDAINavigationHandler.CalcCohesionVector
// Size: 0xC(Inherited: 0x0) 
struct FCalcCohesionVector
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.PointsAreEqualXY
// Size: 0x20(Inherited: 0x0) 
struct FPointsAreEqualXY
{
	struct FVector Vector1;  // 0x0(0xC)
	struct FVector Vector2;  // 0xC(0xC)
	float Tolerance;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function HDMain.HDModData.DoesModPluginUseLegacyMapScanning
// Size: 0x18(Inherited: 0x0) 
struct FDoesModPluginUseLegacyMapScanning
{
	struct FString PluginName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.RequestGroupDataSync
// Size: 0x1(Inherited: 0x0) 
struct FRequestGroupDataSync
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlatoonState.SquadExists
// Size: 0x10(Inherited: 0x0) 
struct FSquadExists
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function HDMain.HDKit.HasKitRequirements
// Size: 0x1(Inherited: 0x0) 
struct FHasKitRequirements
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIGroupBehaviorHandler.ShouldRetreat
// Size: 0x1(Inherited: 0x0) 
struct FShouldRetreat
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAINavigationHandler.CalcSeparationVector
// Size: 0xC(Inherited: 0x0) 
struct FCalcSeparationVector
{
	struct FVector ReturnValue;  // 0x0(0xC)

}; 
// Function HDMain.HDAINavigationHandler.CheckPawnStuckStatus
// Size: 0x1(Inherited: 0x0) 
struct FCheckPawnStuckStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAINavigationHandler.FindNavLocationInsideControlPoint
// Size: 0x18(Inherited: 0x0) 
struct FFindNavLocationInsideControlPoint
{
	struct AHDBaseCapturePoint* CP;  // 0x0(0x8)
	struct FVector OutNavLoc;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function HDMain.HDAINavigationHandler.FindNewControlPointNavLocation
// Size: 0x10(Inherited: 0x0) 
struct FFindNewControlPointNavLocation
{
	struct AHDBaseCapturePoint* CP;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDAINavigationHandler.FixVectorValuesNaN
// Size: 0x10(Inherited: 0x0) 
struct FFixVectorValuesNaN
{
	struct FVector InVector;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bRandomize : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function HDMain.HDPlayerCharacter.OnPickupKit
// Size: 0x8(Inherited: 0x0) 
struct FOnPickupKit
{
	struct AHDBasePickup_Kit* Kit;  // 0x0(0x8)

}; 
// Function HDMain.HDAINavigationHandler.IsNavDataValidForAllControlPoints
// Size: 0x1(Inherited: 0x0) 
struct FIsNavDataValidForAllControlPoints
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDUIUserWidget.GetOwningHDPlayer
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningHDPlayer
{
	struct AHDPlayerController* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDAINavigationHandler.MakePathToDesiredLocation
// Size: 0x1(Inherited: 0x0) 
struct FMakePathToDesiredLocation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDAIVocalHandler.NotifySurroundingCharacters
// Size: 0x1(Inherited: 0x0) 
struct FNotifySurroundingCharacters
{
	uint8_t  InVocalType;  // 0x0(0x1)

}; 
// Function HDMain.HDTeamState.GetPlatoonAt
// Size: 0x10(Inherited: 0x0) 
struct FGetPlatoonAt
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AHDPlatoonState* ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDAIVocalHandler.PlayVocalSound
// Size: 0x1(Inherited: 0x0) 
struct FPlayVocalSound
{
	uint8_t  InVocalType;  // 0x0(0x1)

}; 
// Function HDMain.HDTeamState.RemovePlatoon
// Size: 0x8(Inherited: 0x0) 
struct FRemovePlatoon
{
	struct AHDPlatoonState* PlatoonToRemove;  // 0x0(0x8)

}; 
// Function HDMain.HDAIVocalHandler.SetPitchMultiplier
// Size: 0x4(Inherited: 0x0) 
struct FSetPitchMultiplier
{
	float InPitchMultiplier;  // 0x0(0x4)

}; 
// Function HDMain.HDAIVocalHandler.SetTimeLimit
// Size: 0x1(Inherited: 0x0) 
struct FSetTimeLimit
{
	uint8_t  InVocalType;  // 0x0(0x1)

}; 
// Function HDMain.HDAIVocalHandler.Vocalize
// Size: 0x1(Inherited: 0x0) 
struct FVocalize
{
	uint8_t  InVocalType;  // 0x0(0x1)

}; 
// Function HDMain.HDRuleset_KillDeath.PlayerTeamKilled
// Size: 0x10(Inherited: 0x0) 
struct FPlayerTeamKilled
{
	struct AController* Killer;  // 0x0(0x8)
	struct AController* Victim;  // 0x8(0x8)

}; 
// Function HDMain.HDAIVocalHandler.VocalizeContact
// Size: 0x1(Inherited: 0x0) 
struct FVocalizeContact
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHasContact : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDBaseCapturePoint.CanRestartPlayer
// Size: 0x10(Inherited: 0x0) 
struct FCanRestartPlayer
{
	struct AController* Player;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDUIUserWidget.GetOwningHDPlayerHUD
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningHDPlayerHUD
{
	struct AHDHUD* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDBaseCapturePoint.ChoosePlayerStart
// Size: 0x10(Inherited: 0x0) 
struct FChoosePlayerStart
{
	struct AHDPlayerController* Player;  // 0x0(0x8)
	struct AActor* ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDBaseCapturePoint.GetMinPlayersRequiredForCaptureTeam
// Size: 0x8(Inherited: 0x0) 
struct FGetMinPlayersRequiredForCaptureTeam
{
	uint8_t  CaptureTeam;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function HDMain.HDBaseCapturePoint.GetObjectiveTypeForTeam
// Size: 0x2(Inherited: 0x0) 
struct FGetObjectiveTypeForTeam
{
	uint8_t  ObjTeam;  // 0x0(0x1)
	uint8_t  ReturnValue;  // 0x1(0x1)

}; 
// Function HDMain.HDBaseGameMode.AddBluforBots
// Size: 0x4(Inherited: 0x0) 
struct FAddBluforBots
{
	int32_t Num;  // 0x0(0x4)

}; 
// Function HDMain.HDBaseCapturePoint.GetOverlappingCharactersByTeam
// Size: 0x20(Inherited: 0x0) 
struct FGetOverlappingCharactersByTeam
{
	struct TArray<struct ADFBaseCharacter*> OverlappingCharsRed;  // 0x0(0x10)
	struct TArray<struct ADFBaseCharacter*> OverlappingCharsBlue;  // 0x10(0x10)

}; 
// Function HDMain.HDBaseCapturePoint.IsCapturableByTeam
// Size: 0x2(Inherited: 0x0) 
struct FIsCapturableByTeam
{
	uint8_t  CaptureTeam;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function HDMain.HDBaseCapturePoint.OnBeginOverlap
// Size: 0xA8(Inherited: 0x0) 
struct FOnBeginOverlap
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function HDMain.HDBaseCapturePoint.OnEndOverlap
// Size: 0x20(Inherited: 0x0) 
struct FOnEndOverlap
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function HDMain.HDBaseCapturePoint.OnRep_OwningTeam
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_OwningTeam
{
	uint8_t  LastOwningTeam;  // 0x0(0x1)

}; 
// Function HDMain.HDBaseCapturePoint.ReceiveOnCaptureProgress
// Size: 0x1(Inherited: 0x0) 
struct FReceiveOnCaptureProgress
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewContested : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerSetJumpStamina
// Size: 0xC(Inherited: 0x0) 
struct FOwnerSetJumpStamina
{
	float NewValueNorm;  // 0x0(0x4)
	float OldValueNorm;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInitial : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDBaseCapturePoint.ReceiveOnOwningTeamUpdated
// Size: 0x1(Inherited: 0x0) 
struct FReceiveOnOwningTeamUpdated
{
	uint8_t  LastOwningTeam;  // 0x0(0x1)

}; 
// Function HDMain.HDBaseCapturePoint.SetActiveRoute
// Size: 0x4(Inherited: 0x0) 
struct FSetActiveRoute
{
	int32_t NewActiveRoute;  // 0x0(0x4)

}; 
// Function HDMain.HDBaseGameMode.AddOpforBots
// Size: 0x4(Inherited: 0x0) 
struct FAddOpforBots
{
	int32_t Num;  // 0x0(0x4)

}; 
// Function HDMain.HDBaseGameMode.PlayerCanRestartAtPlayerStart
// Size: 0x20(Inherited: 0x0) 
struct FPlayerCanRestartAtPlayerStart
{
	struct AController* Player;  // 0x0(0x8)
	struct AActor* StartSpot;  // 0x8(0x8)
	struct UDFLoadout* StartLoadout;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function HDMain.HDBaseGameMode.RemoveOpforBots
// Size: 0x4(Inherited: 0x0) 
struct FRemoveOpforBots
{
	int32_t Num;  // 0x0(0x4)

}; 
// Function HDMain.HDBaseWeapon.IsSelectableEquipment
// Size: 0x1(Inherited: 0x0) 
struct FIsSelectableEquipment
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerCharacter.SetFreeAimDeadzoneCameraSpeedFactor
// Size: 0x4(Inherited: 0x0) 
struct FSetFreeAimDeadzoneCameraSpeedFactor
{
	float NewSpeedFactor;  // 0x0(0x4)

}; 
// Function HDMain.HDPlayerController.IsTalkingOverChannelGroup
// Size: 0xC(Inherited: 0x0) 
struct FIsTalkingOverChannelGroup
{
	struct FName TalkGroupName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDPlayerCharacter.SetFreeAimReturnToCenterInterpSpeed
// Size: 0x4(Inherited: 0x0) 
struct FSetFreeAimReturnToCenterInterpSpeed
{
	float NewInterpSpeed;  // 0x0(0x4)

}; 
// Function HDMain.HDPlayerCharacter.SetMaxFreeAimPitch
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxFreeAimPitch
{
	float NewPitch;  // 0x0(0x4)

}; 
// Function HDMain.HDPlayerCharacter.SetMaxFreeAimPitchADS
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxFreeAimPitchADS
{
	float NewPitch;  // 0x0(0x4)

}; 
// Function HDMain.HDTeamState.GetNumPlatoons
// Size: 0x8(Inherited: 0x0) 
struct FGetNumPlatoons
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidPlatoonsOnly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function HDMain.HDPlayerCharacter.SetMaxFreeAimYaw
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxFreeAimYaw
{
	float NewYaw;  // 0x0(0x4)

}; 
// Function HDMain.HDPlayerCharacter.SetMaxFreeAimYawADS
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxFreeAimYawADS
{
	float NewYaw;  // 0x0(0x4)

}; 
// Function HDMain.HDURLStatics.GetDisableKitRestrictionsOptionName
// Size: 0x10(Inherited: 0x0) 
struct FGetDisableKitRestrictionsOptionName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function HDMain.HDGame_AdvanceAndSecure.GetCurrentBlueCaptureTier
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentBlueCaptureTier
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HDMain.HDGame_AdvanceAndSecure.GetCurrentRedCaptureTier
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentRedCaptureTier
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HDMain.HDGameInstance.HasDLCBP
// Size: 0x10(Inherited: 0x0) 
struct FHasDLCBP
{
	int64_t DLCAppID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDGameInstance.HasModsLoaded
// Size: 0x1(Inherited: 0x0) 
struct FHasModsLoaded
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDGameProjectBuildSettings.IsDemoBuild
// Size: 0x1(Inherited: 0x0) 
struct FIsDemoBuild
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDKit.RandomCharacterVariationDataFromKit
// Size: 0x18(Inherited: 0x0) 
struct FRandomCharacterVariationDataFromKit
{
	struct FDFCharacterVariationDataHandle ReturnValue;  // 0x0(0x18)

}; 
// Function HDMain.HDGameRulesetBase.GetHDGameMode
// Size: 0x8(Inherited: 0x0) 
struct FGetHDGameMode
{
	struct AHDBaseGameMode* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDGameRulesetBase.GetHDGameState
// Size: 0x8(Inherited: 0x0) 
struct FGetHDGameState
{
	struct AHDGameState* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDGameState.GiveTicketsToTeam
// Size: 0x8(Inherited: 0x0) 
struct FGiveTicketsToTeam
{
	uint8_t  TicketTeam;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t TicketsToAdd;  // 0x4(0x4)

}; 
// Function HDMain.HDGameState.RevokeTicketsFromTeam
// Size: 0x8(Inherited: 0x0) 
struct FRevokeTicketsFromTeam
{
	uint8_t  TicketTeam;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t TicketsToRemove;  // 0x4(0x4)

}; 
// Function HDMain.HDGameState.GetNumPlayersOnTeam
// Size: 0x8(Inherited: 0x0) 
struct FGetNumPlayersOnTeam
{
	uint8_t  TeamToCheck;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function HDMain.HDTextChatInputWidgetBase.SubmitChatMessage
// Size: 0x18(Inherited: 0x0) 
struct FSubmitChatMessage
{
	struct FText ChatMsgText;  // 0x0(0x18)

}; 
// Function HDMain.HDKit.GetItemEntryDisplayEquipmentSymbol
// Size: 0x20(Inherited: 0x0) 
struct FGetItemEntryDisplayEquipmentSymbol
{
	struct FHDItemEntry ItemEntry;  // 0x0(0x10)
	struct UTexture2D* OutDisplayEquipmentSymbol;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function HDMain.HDGameState.IsGameUsingPlayerSpawnKitRestrictions
// Size: 0x10(Inherited: 0x0) 
struct FIsGameUsingPlayerSpawnKitRestrictions
{
	struct AController* Controller;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDGOAPComponent.GetAIHandler
// Size: 0x10(Inherited: 0x0) 
struct FGetAIHandler
{
	UHDAIHandlerBase* HandlerClass;  // 0x0(0x8)
	struct UHDAIHandlerBase* ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDGOAPComponent.IsAIActiveInWorld
// Size: 0x1(Inherited: 0x0) 
struct FIsAIActiveInWorld
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDGOAPComponent.TargetPerceptionUpdated
// Size: 0x48(Inherited: 0x0) 
struct FTargetPerceptionUpdated
{
	struct AActor* Actor;  // 0x0(0x8)
	struct FAIStimulus Stimulus;  // 0x8(0x3C)
	char pad_68[4];  // 0x44(0x4)

}; 
// Function HDMain.HDServerListView.DoesFilterExcludeListItem
// Size: 0x10(Inherited: 0x0) 
struct FDoesFilterExcludeListItem
{
	struct UObject* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDServerListView.GetEntrySpacing
// Size: 0x4(Inherited: 0x0) 
struct FGetEntrySpacing
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function HDMain.HDJoinGameMenu.IsUsingDebugServerListings
// Size: 0x1(Inherited: 0x0) 
struct FIsUsingDebugServerListings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDJoinGameMenu.OnRefresh
// Size: 0x2(Inherited: 0x0) 
struct FOnRefresh
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSortAscending : 1;  // 0x0(0x1)
	uint8_t  SortBy;  // 0x1(0x1)

}; 
// Function HDMain.HDJoinGameMenu.JoinGame
// Size: 0x18(Inherited: 0x0) 
struct FJoinGame
{
	struct UHDServerListItemData* ServerItem;  // 0x0(0x8)
	struct FString JoinPassword;  // 0x8(0x10)

}; 
// Function HDMain.HDJoinGameMenu.ReceiveOnRefreshComplete
// Size: 0x2(Inherited: 0x0) 
struct FReceiveOnRefreshComplete
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSortAscending : 1;  // 0x0(0x1)
	uint8_t  SortBy;  // 0x1(0x1)

}; 
// Function HDMain.HDKit.GetItemEntryBySlotNum
// Size: 0x20(Inherited: 0x0) 
struct FGetItemEntryBySlotNum
{
	int32_t SlotNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FHDItemEntry OutEntry;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function HDMain.HDKit.GetItemEntryDisplayIcon
// Size: 0x20(Inherited: 0x0) 
struct FGetItemEntryDisplayIcon
{
	struct FHDItemEntry ItemEntry;  // 0x0(0x10)
	struct UTexture2D* OutDisplayIcon;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function HDMain.HDUIUWWeaponStatus.BPOwnerWeaponSetFireMode
// Size: 0x3(Inherited: 0x0) 
struct FBPOwnerWeaponSetFireMode
{
	uint8_t  NewFireMode;  // 0x0(0x1)
	uint8_t  PreviousFireMode;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bFromPlayerInput : 1;  // 0x2(0x1)

}; 
// Function HDMain.HDKit.GetNumPlayersUsingKit
// Size: 0x10(Inherited: 0x0) 
struct FGetNumPlayersUsingKit
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function HDMain.HDKit.GetPlayersUsingKit
// Size: 0x20(Inherited: 0x0) 
struct FGetPlayersUsingKit
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct TArray<struct AHDPlayerState*> OutPSArray;  // 0x8(0x10)
	int32_t ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function HDMain.HDKit.GetPrimaryItemEntryDisplayIcon
// Size: 0x10(Inherited: 0x0) 
struct FGetPrimaryItemEntryDisplayIcon
{
	struct UTexture2D* OutDisplayIcon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDKit.PlayerCanStartWithKit
// Size: 0x28(Inherited: 0x0) 
struct FPlayerCanStartWithKit
{
	struct AController* Player;  // 0x0(0x8)
	struct FText OutKitDenialReason;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function HDMain.HDServerListing.OnServerItemDataSet
// Size: 0x1(Inherited: 0x0) 
struct FOnServerItemDataSet
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsDesignTime : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlatoonInfo.ShouldCreateForTeam
// Size: 0x10(Inherited: 0x0) 
struct FShouldCreateForTeam
{
	struct UHDTeamDefinition* TeamDef;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDUIUserWidget.BPOwnerWeaponChanged
// Size: 0x10(Inherited: 0x0) 
struct FBPOwnerWeaponChanged
{
	struct AHDBaseWeapon* NewWeap;  // 0x0(0x8)
	struct AHDBaseWeapon* PrevWeap;  // 0x8(0x8)

}; 
// Function HDMain.HDPlatoonState.AddSquad
// Size: 0x30(Inherited: 0x0) 
struct FAddSquad
{
	struct FText SquadDisplayName;  // 0x0(0x18)
	struct AHDPlayerState* SquadLeader;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bStartLocked : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AHDSquadState* ReturnValue;  // 0x28(0x8)

}; 
// Function HDMain.HDSquadState.SquadMemberPSTeamUpdated
// Size: 0x10(Inherited: 0x0) 
struct FSquadMemberPSTeamUpdated
{
	struct APlayerState* MemberPS;  // 0x0(0x8)
	char LastTeamNum;  // 0x8(0x1)
	char NewTeamNum;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function HDMain.HDPlatoonState.FindSquadByName
// Size: 0x28(Inherited: 0x0) 
struct FFindSquadByName
{
	struct FText SquadDisplayName;  // 0x0(0x18)
	struct AHDSquadState* OutFoundSquad;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function HDMain.HDUIUWCaptureStatus.ControlPointSetOwnershipState
// Size: 0x4(Inherited: 0x0) 
struct FControlPointSetOwnershipState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCaptured : 1;  // 0x0(0x1)
	uint8_t  NewOwningTeam;  // 0x1(0x1)
	uint8_t  OldOwningTeam;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bInitial : 1;  // 0x3(0x1)

}; 
// Function HDMain.HDPlayerCharacter.SetVariationHandle
// Size: 0x18(Inherited: 0x0) 
struct FSetVariationHandle
{
	struct FDFCharacterVariationDataHandle InVariationHandle;  // 0x0(0x18)

}; 
// Function HDMain.HDPlatoonState.GetMaxSquadLimit
// Size: 0x4(Inherited: 0x0) 
struct FGetMaxSquadLimit
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HDMain.HDPlatoonState.GetSquadAt
// Size: 0x10(Inherited: 0x0) 
struct FGetSquadAt
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AHDSquadState* ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDPlatoonState.HasReachedMaxSquadLimit
// Size: 0x1(Inherited: 0x0) 
struct FHasReachedMaxSquadLimit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlatoonState.ReceiveSquadPreRemove
// Size: 0x8(Inherited: 0x0) 
struct FReceiveSquadPreRemove
{
	struct AHDSquadState* Squad;  // 0x0(0x8)

}; 
// Function HDMain.HDPlatoonState.RemoveSquadAt
// Size: 0x4(Inherited: 0x0) 
struct FRemoveSquadAt
{
	int32_t RemoveIdx;  // 0x0(0x4)

}; 
// Function HDMain.HDPlayerCharacter.EquipPrimaryItem
// Size: 0x1(Inherited: 0x0) 
struct FEquipPrimaryItem
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerCharacter.FreeAim
// Size: 0x4(Inherited: 0x0) 
struct FFreeAim
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function HDMain.HDTeamCommChannelState.GetChannelNameForCommand
// Size: 0x10(Inherited: 0x0) 
struct FGetChannelNameForCommand
{
	struct AHDTeamState* CmdTeam;  // 0x0(0x8)
	struct FName ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDPlayerCharacter.GetKitClassToUse
// Size: 0x8(Inherited: 0x0) 
struct FGetKitClassToUse
{
	AHDBasePickup_Kit* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerCharacter.GetPlayerComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetPlayerComponent
{
	struct UHDPlayerComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerController.IsInVehicle
// Size: 0x1(Inherited: 0x0) 
struct FIsInVehicle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerCharacter.PlayVocalSoundAI
// Size: 0x10(Inherited: 0x0) 
struct FPlayVocalSoundAI
{
	struct USoundBase* SoundToUse;  // 0x0(0x8)
	uint8_t  VocalType;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float PitchMultiplier;  // 0xC(0x4)

}; 
// Function HDMain.HDPlayerCharacter.ReceiveAimStyleChanged
// Size: 0x3(Inherited: 0x0) 
struct FReceiveAimStyleChanged
{
	uint8_t  NewAimStyle;  // 0x0(0x1)
	uint8_t  PrevAimStyle;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bFromPlayerInput : 1;  // 0x2(0x1)

}; 
// Function HDMain.HDPlayerCharacter.ReceiveFreeAim
// Size: 0x4(Inherited: 0x0) 
struct FReceiveFreeAim
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function HDMain.HDPlayerCharacter.ReceiveVariationDataChanged
// Size: 0xD0(Inherited: 0x0) 
struct FReceiveVariationDataChanged
{
	struct FDFCharacterVariationData NewVariation;  // 0x0(0x68)
	struct FDFCharacterVariationData PreviousVariation;  // 0x68(0x68)

}; 
// Function HDMain.HDPlayerController.ReceiveVoipTalkerMsgReceived
// Size: 0x18(Inherited: 0x0) 
struct FReceiveVoipTalkerMsgReceived
{
	struct UDFCommChannel* MsgTalkerChannel;  // 0x0(0x8)
	struct APlayerState* MsgTalkerPS;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bMsgIsTalking : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function HDMain.HDPlayerCharacter.SetAimStyle
// Size: 0x2(Inherited: 0x0) 
struct FSetAimStyle
{
	uint8_t  InAimStyle;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bFromPlayerInput : 1;  // 0x1(0x1)

}; 
// Function HDMain.HDTeamCommChannelState.SetupTeamChannelState
// Size: 0x8(Inherited: 0x0) 
struct FSetupTeamChannelState
{
	struct AHDTeamState* ForTeamState;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerCharacter.SetAllowFreeAimADS
// Size: 0x1(Inherited: 0x0) 
struct FSetAllowFreeAimADS
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerCharacter.VariationDataChangedInternal
// Size: 0x18(Inherited: 0x0) 
struct FVariationDataChangedInternal
{
	struct FDFCharacterVariationDataHandle PreviousHandle;  // 0x0(0x18)

}; 
// Function HDMain.HDPlayerComponent.PickTeam
// Size: 0x1(Inherited: 0x0) 
struct FPickTeam
{
	uint8_t  DesiredTeam;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerController.StopTalkingOverChannelGroupIfActive
// Size: 0x8(Inherited: 0x0) 
struct FStopTalkingOverChannelGroupIfActive
{
	struct FName TalkStopGroupName;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerComponent.RestartPlayerAtStartSpot
// Size: 0x10(Inherited: 0x0) 
struct FRestartPlayerAtStartSpot
{
	struct AActor* DesiredStartSpot;  // 0x0(0x8)
	struct UDFLoadout* DesiredStartLoadout;  // 0x8(0x8)

}; 
// Function HDMain.HDPlayerController.CanTalkOverChannel
// Size: 0xC(Inherited: 0x0) 
struct FCanTalkOverChannel
{
	struct FName TalkChannelName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerUpdateStamina
// Size: 0xC(Inherited: 0x0) 
struct FOwnerUpdateStamina
{
	float SprintValueNorm;  // 0x0(0x4)
	float JumpValueNorm;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInitial : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDPlayerController.ClientCheatSetAllowIdleSway
// Size: 0x1(Inherited: 0x0) 
struct FClientCheatSetAllowIdleSway
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIdleSwayDisallowed : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerState.OnRep_CurrentLoadout
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_CurrentLoadout
{
	struct UHDKit* PrevLoadout;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerController.ClientLoadTeamData
// Size: 0x10(Inherited: 0x0) 
struct FClientLoadTeamData
{
	struct TArray<struct FString> FactionAssetPaths;  // 0x0(0x10)

}; 
// Function HDMain.HDPlayerController.StartTalkingOverChannelGroup
// Size: 0x8(Inherited: 0x0) 
struct FStartTalkingOverChannelGroup
{
	struct FName TalkStartGroupName;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerController.ClientRoundEnd
// Size: 0x14(Inherited: 0x0) 
struct FClientRoundEnd
{
	struct FHDGameRoundEndEventDetails RoundDetails;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsWinner : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function HDMain.HDPlayerController.GetPlayerCommsComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetPlayerCommsComponent
{
	struct UDFPlayerCommsComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDSquadState.HasReachedMaxSquadMemberLimit
// Size: 0x1(Inherited: 0x0) 
struct FHasReachedMaxSquadMemberLimit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerController.GetTalkChannel
// Size: 0x8(Inherited: 0x0) 
struct FGetTalkChannel
{
	struct UDFCommChannel* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerController.IsIdleSwayAllowed
// Size: 0x1(Inherited: 0x0) 
struct FIsIdleSwayAllowed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerController.IsTalking
// Size: 0x2(Inherited: 0x0) 
struct FIsTalking
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIncludeWantsToTalk : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function HDMain.HDPlayerController.IsTalkingOverChannel
// Size: 0x10(Inherited: 0x0) 
struct FIsTalkingOverChannel
{
	struct UDFCommChannel* TalkChannel;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDPlayerController.IsTalkingOverChannelName
// Size: 0xC(Inherited: 0x0) 
struct FIsTalkingOverChannelName
{
	struct FName TalkChannelName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDServerListing.SetupListing
// Size: 0x8(Inherited: 0x0) 
struct FSetupListing
{
	struct UHDServerListItemData* InServerItemData;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerController.LoadVictoryMenu
// Size: 0x14(Inherited: 0x0) 
struct FLoadVictoryMenu
{
	struct FHDGameRoundEndEventDetails RoundDetails;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWinner : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function HDMain.HDPlayerController.ServerCheatSetAllowIdleSway
// Size: 0x1(Inherited: 0x0) 
struct FServerCheatSetAllowIdleSway
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIdleSwayDisallowed : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerController.ServerPickTeam
// Size: 0x1(Inherited: 0x0) 
struct FServerPickTeam
{
	uint8_t  DesiredTeam;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerController.ServerRestartPlayerAtStartSpot
// Size: 0x10(Inherited: 0x0) 
struct FServerRestartPlayerAtStartSpot
{
	struct AActor* DesiredStartSpot;  // 0x0(0x8)
	struct UDFLoadout* DesiredStartLoadout;  // 0x8(0x8)

}; 
// Function HDMain.HDPlayerController.StartTalkingOverChannel
// Size: 0x8(Inherited: 0x0) 
struct FStartTalkingOverChannel
{
	struct FName TalkStartChannelName;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerController.StopTalkingOverChannelIfActive
// Size: 0x8(Inherited: 0x0) 
struct FStopTalkingOverChannelIfActive
{
	struct FName TalkStopChannelName;  // 0x0(0x8)

}; 
// Function HDMain.HDTeamState.HasReachedMaxPlatoonLimit
// Size: 0x1(Inherited: 0x0) 
struct FHasReachedMaxPlatoonLimit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDPlayerStart.K2_GetCapsuleComponent
// Size: 0x8(Inherited: 0x0) 
struct FK2_GetCapsuleComponent
{
	struct UCapsuleComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerState.AssignCurrentLoadout
// Size: 0x8(Inherited: 0x0) 
struct FAssignCurrentLoadout
{
	struct UHDKit* NewCurrentLoadout;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerState.AssignSpawnLoadout
// Size: 0x8(Inherited: 0x0) 
struct FAssignSpawnLoadout
{
	struct UHDKit* NewSpawnLoadout;  // 0x0(0x8)

}; 
// Function HDMain.HDPlayerState.OnRep_SpawnLoadout
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_SpawnLoadout
{
	struct UHDKit* PrevSpawnLoadout;  // 0x0(0x8)

}; 
// Function HDMain.HDRuleset_ControlPoint.ControlPointCaptureProgressUpdated
// Size: 0x10(Inherited: 0x0) 
struct FControlPointCaptureProgressUpdated
{
	struct AHDBaseCapturePoint* ControlPoint;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bContested : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Progress;  // 0xC(0x4)

}; 
// Function HDMain.HDRuleset_KillDeath.GetKillDeathSettingsForTeam
// Size: 0x2C(Inherited: 0x0) 
struct FGetKillDeathSettingsForTeam
{
	uint8_t  KillDeathTeam;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FKillDeathRulesetSettings ReturnValue;  // 0x4(0x28)

}; 
// Function HDMain.HDRuleset_TicketBleed.ControlPointTeamUpdated
// Size: 0x10(Inherited: 0x0) 
struct FControlPointTeamUpdated
{
	struct AHDBaseCapturePoint* ControlPoint;  // 0x0(0x8)
	uint8_t  PrevTeam;  // 0x8(0x1)
	uint8_t  NewTeam;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bCaptured : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// Function HDMain.HDRuleset_ControlPoint.GetControlPointSettingsForTeam
// Size: 0x24(Inherited: 0x0) 
struct FGetControlPointSettingsForTeam
{
	uint8_t  ControlPointTeam;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FControlPointRulesetSettings ReturnValue;  // 0x4(0x20)

}; 
// Function HDMain.HDRuleset_TicketBleed.ApplyTicketBleed
// Size: 0xC(Inherited: 0x0) 
struct FApplyTicketBleed
{
	uint8_t  BleedTeam;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t TicketBleedMultiplier;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bUseMercyTicketBleed : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDRuleset_TicketBleed.GetTicketBleedSettingsForTeam
// Size: 0x10(Inherited: 0x0) 
struct FGetTicketBleedSettingsForTeam
{
	uint8_t  TicketBleedTeam;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FTicketBleedRulesetSettings ReturnValue;  // 0x4(0xC)

}; 
// Function HDMain.HDScoreboardBase.ReceiveScoreboardListRowAdded
// Size: 0x8(Inherited: 0x0) 
struct FReceiveScoreboardListRowAdded
{
	struct UHDScoreboardListingRowBase* NewListEntry;  // 0x0(0x8)

}; 
// Function HDMain.HDScoreboardListingRowBase.GetIconForVoiceState
// Size: 0x30(Inherited: 0x0) 
struct FGetIconForVoiceState
{
	uint8_t  VoiceState;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TSoftObjectPtr<UTexture2D> ReturnValue;  // 0x8(0x28)

}; 
// Function HDMain.HDScoreboardListingRowBase.HasInitialized
// Size: 0x1(Inherited: 0x0) 
struct FHasInitialized
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDScoreboardListingRowBase.ReceivePlayerVoiceStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FReceivePlayerVoiceStateChanged
{
	uint8_t  NewVoiceState;  // 0x0(0x1)

}; 
// Function HDMain.HDScoreboardListingRowBase.SetVoiceStateIcon
// Size: 0x8(Inherited: 0x0) 
struct FSetVoiceStateIcon
{
	struct UTexture2D* NewIcon;  // 0x0(0x8)

}; 
// Function HDMain.HDServerListFilterRule.MatchesServer
// Size: 0x10(Inherited: 0x0) 
struct FMatchesServer
{
	struct UHDServerListItemData* ListItem;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDSQCommChannelState.GetChannelNameForSquad
// Size: 0x10(Inherited: 0x0) 
struct FGetChannelNameForSquad
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct FName ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDSQCommChannelState.SetupSQChannelState
// Size: 0x8(Inherited: 0x0) 
struct FSetupSQChannelState
{
	struct AHDSquadState* ForSquadState;  // 0x0(0x8)

}; 
// Function HDMain.HDSquadState.CanRegisterPlayerSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FCanRegisterPlayerSquadMember
{
	struct AHDPlayerController* NewMemberPC;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDSquadState.CanRegisterSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FCanRegisterSquadMember
{
	struct AHDPlayerState* NewMemberPS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDSquadState.GetNumSquadMembers
// Size: 0x8(Inherited: 0x0) 
struct FGetNumSquadMembers
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidMembersOnly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function HDMain.HDSquadState.GetNumSquadMembersBots
// Size: 0x8(Inherited: 0x0) 
struct FGetNumSquadMembersBots
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidMembersOnly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// Function HDMain.HDUIStatics.GetServerIpPort
// Size: 0xB0(Inherited: 0x0) 
struct FGetServerIpPort
{
	struct FHDServerInfo InServerInfo;  // 0x0(0xA0)
	struct FString ReturnValue;  // 0xA0(0x10)

}; 
// Function HDMain.HDSquadState.IsPendingRemovalFromSquad
// Size: 0x10(Inherited: 0x0) 
struct FIsPendingRemovalFromSquad
{
	struct AHDPlayerState* PS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDSquadState.IsPlayerRegisteredSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FIsPlayerRegisteredSquadMember
{
	struct AHDPlayerController* PC;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function HDMain.HDSquadState.IsRegisteredSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FIsRegisteredSquadMember
{
	struct AHDPlayerState* PS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function HDMain.HDUIUserWidget.BPInitializeForOwnerPlayerCharacter
// Size: 0x8(Inherited: 0x0) 
struct FBPInitializeForOwnerPlayerCharacter
{
	struct AHDPlayerCharacter* OwnerPlyChar;  // 0x0(0x8)

}; 
// Function HDMain.HDSquadState.OnRep_DisplayName
// Size: 0x18(Inherited: 0x0) 
struct FOnRep_DisplayName
{
	struct FText PrevDisplayName;  // 0x0(0x18)

}; 
// Function HDMain.HDSquadState.ReceiveInit
// Size: 0x30(Inherited: 0x0) 
struct FReceiveInit
{
	struct FHDSquadCreationParams CreationParams;  // 0x0(0x30)

}; 
// Function HDMain.HDSquadState.ReceiveSquadLeaderAssigned
// Size: 0x10(Inherited: 0x0) 
struct FReceiveSquadLeaderAssigned
{
	struct AHDPlayerState* NewLeaderPS;  // 0x0(0x8)
	struct AHDPlayerState* PrevLeaderPS;  // 0x8(0x8)

}; 
// Function HDMain.HDUIUserWidget.OwnerEquippedItemChanged
// Size: 0x18(Inherited: 0x0) 
struct FOwnerEquippedItemChanged
{
	struct ADFBaseCharacter* Character;  // 0x0(0x8)
	struct ADFBaseItem* NewEquippedItem;  // 0x8(0x8)
	struct ADFBaseItem* PrevEquippedItem;  // 0x10(0x8)

}; 
// Function HDMain.HDSquadState.ReceiveSquadRenamed
// Size: 0x30(Inherited: 0x0) 
struct FReceiveSquadRenamed
{
	struct FText NewName;  // 0x0(0x18)
	struct FText PrevName;  // 0x18(0x18)

}; 
// Function HDMain.HDSquadState.RegisterPlayerSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FRegisterPlayerSquadMember
{
	struct AHDPlayerController* NewMemberPC;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDSquadState.RegisterSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FRegisterSquadMember
{
	struct AHDPlayerState* NewMemberPS;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDSquadState.RenameSquad
// Size: 0x18(Inherited: 0x0) 
struct FRenameSquad
{
	struct FText NewDisplayName;  // 0x0(0x18)

}; 
// Function HDMain.SquadMemberInfo.GetParentPlatoonState
// Size: 0x8(Inherited: 0x0) 
struct FGetParentPlatoonState
{
	struct AHDPlatoonState* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDSquadState.SquadMemberPSSquadUpdated
// Size: 0x18(Inherited: 0x0) 
struct FSquadMemberPSSquadUpdated
{
	struct AHDPlayerState* MemberPS;  // 0x0(0x8)
	struct FHDSquadAssignmentInfo MemberSQInfo;  // 0x8(0x10)

}; 
// Function HDMain.HDTeamState.GetTeam
// Size: 0x1(Inherited: 0x0) 
struct FGetTeam
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function HDMain.HDSquadState.UnregisterPlayerSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterPlayerSquadMember
{
	struct AHDPlayerController* MemberPCToRemove;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDSquadState.UnregisterSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterSquadMember
{
	struct AHDPlayerState* MemberPSToRemove;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDTeamState.AddPlatoon
// Size: 0x10(Inherited: 0x0) 
struct FAddPlatoon
{
	struct UHDPlatoonInfo* PlatoonInfo;  // 0x0(0x8)
	struct AHDPlatoonState* ReturnValue;  // 0x8(0x8)

}; 
// Function HDMain.HDTeamState.FindPlatoonByName
// Size: 0x28(Inherited: 0x0) 
struct FFindPlatoonByName
{
	struct FText PlatoonDisplayName;  // 0x0(0x18)
	struct AHDPlatoonState* OutFoundPlatoon;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function HDMain.HDTeamState.ReceivePlatoonAdded
// Size: 0x8(Inherited: 0x0) 
struct FReceivePlatoonAdded
{
	struct AHDPlatoonState* Platoon;  // 0x0(0x8)

}; 
// Function HDMain.HDTeamState.ReceivePlatoonPreRemove
// Size: 0x8(Inherited: 0x0) 
struct FReceivePlatoonPreRemove
{
	struct AHDPlatoonState* Platoon;  // 0x0(0x8)

}; 
// Function HDMain.HDTextChatInputWidgetBase.StartTalkingOnChannel
// Size: 0x8(Inherited: 0x0) 
struct FStartTalkingOnChannel
{
	struct UDFCommChannel* TalkChannel;  // 0x0(0x8)

}; 
// Function HDMain.HDTeamState.RemovePlatoonAt
// Size: 0x4(Inherited: 0x0) 
struct FRemovePlatoonAt
{
	int32_t RemoveIdx;  // 0x0(0x4)

}; 
// Function HDMain.HDTextChatInputWidgetBase.OnChatMessageSubmitted
// Size: 0x8(Inherited: 0x0) 
struct FOnChatMessageSubmitted
{
	struct UHDTextChatMsgInfo* SubmittedChatMsg;  // 0x0(0x8)

}; 
// Function HDMain.HDURLStatics.GetFactionOptionName
// Size: 0x18(Inherited: 0x0) 
struct FGetFactionOptionName
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function HDMain.HDTextChatWidgetBase.StartTalking
// Size: 0x8(Inherited: 0x0) 
struct FStartTalking
{
	struct UDFCommChannel* TalkChannel;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUserWidget.BPOwnerUnpossessPawn
// Size: 0x8(Inherited: 0x0) 
struct FBPOwnerUnpossessPawn
{
	struct APawn* UnpossessedPawn;  // 0x0(0x8)

}; 
// Function HDMain.HDTextChatInputWidgetBase.StopTalking
// Size: 0x8(Inherited: 0x0) 
struct FStopTalking
{
	struct UDFCommChannel* CurrentChannel;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUWCaptureStatus.CPOwnershipUpdate
// Size: 0x10(Inherited: 0x0) 
struct FCPOwnershipUpdate
{
	struct AHDBaseCapturePoint* ControlPoint;  // 0x0(0x8)
	uint8_t  PrevOwningTeam;  // 0x8(0x1)
	uint8_t  NewOwningTeam;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bCaptured : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// Function HDMain.HDTextChatWidgetBase.DisplayChatMessage
// Size: 0x8(Inherited: 0x0) 
struct FDisplayChatMessage
{
	struct UHDTextChatMsgInfo* NewChatMsg;  // 0x0(0x8)

}; 
// Function HDMain.HDTextChatWidgetBase.GetNumCachedChatMsgs
// Size: 0x4(Inherited: 0x0) 
struct FGetNumCachedChatMsgs
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HDMain.HDTextChatWidgetBase.SetMaxChatMsgsToCache
// Size: 0x4(Inherited: 0x0) 
struct FSetMaxChatMsgsToCache
{
	int32_t NumChatMsgsToCache;  // 0x0(0x4)

}; 
// Function HDMain.HDURLStatics.GetNumBotsOptionName
// Size: 0x18(Inherited: 0x0) 
struct FGetNumBotsOptionName
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function HDMain.HDURLStatics.GetNumTicketsOptionName
// Size: 0x18(Inherited: 0x0) 
struct FGetNumTicketsOptionName
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function HDMain.HDUIStatics.GetServerIp
// Size: 0xB0(Inherited: 0x0) 
struct FGetServerIp
{
	struct FHDServerInfo InServerInfo;  // 0x0(0xA0)
	struct FString ReturnValue;  // 0xA0(0x10)

}; 
// Function HDMain.HDUIStatics.GetServerPort
// Size: 0xA8(Inherited: 0x0) 
struct FGetServerPort
{
	struct FHDServerInfo InServerInfo;  // 0x0(0xA0)
	int32_t ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)

}; 
// Function HDMain.HDUIUserWidget.BPDeinitializeFromOwnerWeapon
// Size: 0x8(Inherited: 0x0) 
struct FBPDeinitializeFromOwnerWeapon
{
	struct AHDBaseWeapon* OwnerWeap;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUserWidget.BPInitializeForOwnerWeapon
// Size: 0x8(Inherited: 0x0) 
struct FBPInitializeForOwnerWeapon
{
	struct AHDBaseWeapon* OwnerWeap;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUserWidget.BPOwnerDeath
// Size: 0x38(Inherited: 0x0) 
struct FBPOwnerDeath
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function HDMain.HDUIUserWidget.BPOwnerPossessPawn
// Size: 0x8(Inherited: 0x0) 
struct FBPOwnerPossessPawn
{
	struct APawn* NewPawn;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUserWidget.GetOwnerEquippedWeapon
// Size: 0x8(Inherited: 0x0) 
struct FGetOwnerEquippedWeapon
{
	struct AHDBaseWeapon* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUserWidget.GetOwningHDPlayerCharacter
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningHDPlayerCharacter
{
	struct AHDPlayerCharacter* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUserWidget.GetOwningPlayerHUD
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningPlayerHUD
{
	struct AHUD* ReturnValue;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUserWidget.OwnerDeath
// Size: 0x38(Inherited: 0x0) 
struct FOwnerDeath
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function HDMain.HDUIUserWidget.OwnerUnpossessPawn
// Size: 0x8(Inherited: 0x0) 
struct FOwnerUnpossessPawn
{
	struct APawn* UnpossessedPawn;  // 0x0(0x8)

}; 
// Function HDMain.HDUIUWCaptureStatus.ControlPointSetCaptureProgress
// Size: 0x10(Inherited: 0x0) 
struct FControlPointSetCaptureProgress
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bContested : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float NewValueNorm;  // 0x4(0x4)
	float OldValueNorm;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bInitial : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function HDMain.HDUIUWCaptureStatus.CPBeginEndOverlap
// Size: 0x10(Inherited: 0x0) 
struct FCPBeginEndOverlap
{
	struct AActor* OverlappedControlPointActor;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
// Function HDMain.HDUIUWWeaponStatus.OwnerSetAimStyle
// Size: 0x3(Inherited: 0x0) 
struct FOwnerSetAimStyle
{
	uint8_t  NewAimStyle;  // 0x0(0x1)
	uint8_t  PrevAimStyle;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bFromPlayerInput : 1;  // 0x2(0x1)

}; 
// Function HDMain.HDUIUWCaptureStatus.CPCaptureProgressUpdate
// Size: 0x10(Inherited: 0x0) 
struct FCPCaptureProgressUpdate
{
	struct AHDBaseCapturePoint* ControlPoint;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInCaptureContested : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t InCaptureProgress;  // 0xC(0x4)

}; 
// Function HDMain.HDUIUWCaptureStatus.OwnerBeginOverlap
// Size: 0x10(Inherited: 0x0) 
struct FOwnerBeginOverlap
{
	struct AActor* OverlappedOwnerChar;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)

}; 
// Function HDMain.HDUIUWCaptureStatus.OwnerTouchingControlPoint
// Size: 0x10(Inherited: 0x0) 
struct FOwnerTouchingControlPoint
{
	struct AHDBaseCapturePoint* OverlappingCP;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInitial : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerAimTransitionUpdate
// Size: 0x1(Inherited: 0x0) 
struct FOwnerAimTransitionUpdate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsAiming : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerSetHealth
// Size: 0xC(Inherited: 0x0) 
struct FOwnerSetHealth
{
	float NewValueNorm;  // 0x0(0x4)
	float OldValueNorm;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInitial : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDUIUWPlayerStatus.OwnerSetSprintStamina
// Size: 0xC(Inherited: 0x0) 
struct FOwnerSetSprintStamina
{
	float NewValueNorm;  // 0x0(0x4)
	float OldValueNorm;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bInitial : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function HDMain.HDUIUWWeaponStatus.BPOwnerWeaponAmmoUpdated
// Size: 0x20(Inherited: 0x0) 
struct FBPOwnerWeaponAmmoUpdated
{
	struct FHDUIWeaponAmmoState AmmoState;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bFromReload : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bTotalFreeAmmoUpdated : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool bNumFreeAmmoClipsUpdated : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)

}; 
// Function HDMain.HDUIUWWeaponStatus.OwnerWeaponFireModeChanged
// Size: 0x10(Inherited: 0x0) 
struct FOwnerWeaponFireModeChanged
{
	struct ADFBaseGun* Gun;  // 0x0(0x8)
	uint8_t  NewFireMode;  // 0x8(0x1)
	uint8_t  PrevFireMode;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bFromPlayerInput : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// Function HDMain.HDVoipIndicatorListingWidgetBase.OnVoiceMsgInfoSet
// Size: 0x1(Inherited: 0x0) 
struct FOnVoiceMsgInfoSet
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsDesignTime : 1;  // 0x0(0x1)

}; 
// Function HDMain.HDVoipIndicatorListingWidgetBase.SetupVoiceListing
// Size: 0x8(Inherited: 0x0) 
struct FSetupVoiceListing
{
	struct UHDVoiceChatMsgInfo* InVoiceMsgInfo;  // 0x0(0x8)

}; 
// Function HDMain.HDVoipIndicatorWidgetBase.OnPlayerStartTalking
// Size: 0x8(Inherited: 0x0) 
struct FOnPlayerStartTalking
{
	struct UHDVoiceChatMsgInfo* TalkerMsgInfo;  // 0x0(0x8)

}; 
// Function HDMain.HDVoipIndicatorWidgetBase.OnOwningPlayerStartTalking
// Size: 0x8(Inherited: 0x0) 
struct FOnOwningPlayerStartTalking
{
	struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo;  // 0x0(0x8)

}; 
