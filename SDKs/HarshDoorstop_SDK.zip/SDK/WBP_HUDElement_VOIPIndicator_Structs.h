#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnPlayerStartTalking
// Size: 0x8(Inherited: 0x8) 
struct FOnPlayerStartTalking : public FOnPlayerStartTalking
{
	struct UHDVoiceChatMsgInfo* TalkerMsgInfo;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.ExecuteUbergraph_WBP_HUDElement_VOIPIndicator
// Size: 0x6D(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUDElement_VOIPIndicator
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UHDVoiceChatMsgInfo* K2Node_Event_TalkerMsgInfo_2;  // 0x8(0x8)
	struct UHDVoiceChatMsgInfo* K2Node_Event_TalkerMsgInfo;  // 0x10(0x8)
	struct UHDVoiceChatMsgInfo* K2Node_Event_LocalTalkerMsgInfo_2;  // 0x18(0x8)
	struct UHDVoiceChatMsgInfo* K2Node_Event_LocalTalkerMsgInfo;  // 0x20(0x8)
	struct FName CallFunc_GetChannelName_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_InstancesChannelWithGroup_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	int32_t Temp_int_Variable;  // 0x34(0x4)
	int32_t CallFunc_Min_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x3C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x48(0x8)
	struct UWBP_HUDElement_VOIPIndicator_OutputListing_C* CallFunc_Create_ReturnValue;  // 0x50(0x8)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Variable : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FName K2Node_Select_Default;  // 0x64(0x8)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0x6C(0x1)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnPlayerStopTalking
// Size: 0x8(Inherited: 0x8) 
struct FOnPlayerStopTalking : public FOnPlayerStopTalking
{
	struct UHDVoiceChatMsgInfo* TalkerMsgInfo;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnOwningPlayerStopTalking
// Size: 0x8(Inherited: 0x8) 
struct FOnOwningPlayerStopTalking : public FOnOwningPlayerStopTalking
{
	struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.OnOwningPlayerStartTalking
// Size: 0x8(Inherited: 0x8) 
struct FOnOwningPlayerStartTalking : public FOnOwningPlayerStartTalking
{
	struct UHDVoiceChatMsgInfo* LocalTalkerMsgInfo;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PlayerStartedTalking
// Size: 0x40(Inherited: 0x0) 
struct FPlayerStartedTalking
{
	struct UHDVoiceChatMsgInfo* TalkerMsgInfo;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_FindTalkerListing_bListingFound : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UWBP_HUDElement_VOIPIndicator_OutputListing_C* CallFunc_FindTalkerListing_TalkerListing;  // 0x10(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWBP_HUDElement_VOIPIndicator_OutputListing_C* CallFunc_Create_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0x38(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.PlayerStoppedTalking
// Size: 0x18(Inherited: 0x0) 
struct FPlayerStoppedTalking
{
	struct UHDVoiceChatMsgInfo* TalkerMsgInfo;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_FindTalkerListing_bListingFound : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UWBP_HUDElement_VOIPIndicator_OutputListing_C* CallFunc_FindTalkerListing_TalkerListing;  // 0x10(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.FindTalkerListing
// Size: 0x63(Inherited: 0x0) 
struct FFindTalkerListing
{
	struct UHDVoiceChatMsgInfo* PlayerMsgInfo;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bListingFound : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UWBP_HUDElement_VOIPIndicator_OutputListing_C* TalkerListing;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UWBP_HUDElement_VOIPIndicator_OutputListing_C* K2Node_DynamicCast_AsWBP_HUDElement_VOIPIndicator_Output_Listing;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x62(0x1)

}; 
// Function WBP_HUDElement_VOIPIndicator.WBP_HUDElement_VOIPIndicator_C.ContainsTalkerListing
// Size: 0x18(Inherited: 0x0) 
struct FContainsTalkerListing
{
	struct UHDVoiceChatMsgInfo* PlayerMsgInfo;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bMatchFound : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_FindTalkerListing_bListingFound : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct UWBP_HUDElement_VOIPIndicator_OutputListing_C* CallFunc_FindTalkerListing_TalkerListing;  // 0x10(0x8)

}; 
