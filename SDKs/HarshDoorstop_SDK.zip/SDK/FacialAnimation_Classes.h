#pragma once 
#include <FacialAnimation_Structs.h>
 
 
 
// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x810(Inherited: 0x7D0) 
struct UAudioCurveSourceComponent : public UAudioComponent
{
	char pad_2000[8];  // 0x7D0(0x8)
	struct FName CurveSourceBindingName;  // 0x7D8(0x8)
	float CurveSyncOffset;  // 0x7E0(0x4)
	char pad_2020[44];  // 0x7E4(0x2C)

}; 



