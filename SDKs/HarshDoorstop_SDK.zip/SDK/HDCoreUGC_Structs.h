#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct HDCoreUGC.UGCPrimaryAssetSearchInfo
// Size: 0x18(Inherited: 0x0) 
struct FUGCPrimaryAssetSearchInfo
{
	struct FPrimaryAssetType AssetType;  // 0x0(0x8)
	struct FString Directory;  // 0x8(0x10)

}; 
// ScriptStruct HDCoreUGC.HDCoreUGCPluginStateMachineProperties
// Size: 0xE8(Inherited: 0x0) 
struct FHDCoreUGCPluginStateMachineProperties
{
	char pad_0[144];  // 0x0(0x90)
	struct UHDCoreUGCData* UGCData;  // 0x90(0x8)
	char pad_152[80];  // 0x98(0x50)

}; 
