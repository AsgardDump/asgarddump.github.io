#pragma once 
#include "SDK.h" 
 
 
// Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.ExecuteUbergraph_WBP_CaptureStatus_FlagIcon
// Size: 0xD(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_CaptureStatus_FlagIcon
{
	int32_t EntryPoint;  // 0x0(0x4)
	uint8_t  Temp_byte_Variable;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool K2Node_CustomEvent_bActive : 1;  // 0x6(0x1)
	uint8_t  K2Node_CustomEvent_Team;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_CustomEvent_bLocked : 1;  // 0x8(0x1)
	uint8_t  K2Node_CustomEvent_ObjType;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool Temp_bool_Variable : 1;  // 0xB(0x1)
	uint8_t  K2Node_Select_Default;  // 0xC(0x1)

}; 
// Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.UpdateBrushesByTeam
// Size: 0xB8(Inherited: 0x0) 
struct FUpdateBrushesByTeam
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLocked : 1;  // 0x0(0x1)
	uint8_t  Team;  // 0x1(0x1)
	uint8_t  ObjType;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bInLocked : 1;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct FSlateBrush IconToUse;  // 0x8(0x88)
	struct UTexture2D* Temp_object_Variable;  // 0x90(0x8)
	struct UTexture2D* Temp_object_Variable_2;  // 0x98(0x8)
	struct UTexture2D* Temp_object_Variable_3;  // 0xA0(0x8)
	uint8_t  Temp_byte_Variable;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UTexture2D* K2Node_Select_Default;  // 0xB0(0x8)

}; 
// Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.OnUpdateIcon
// Size: 0x4(Inherited: 0x0) 
struct FOnUpdateIcon
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)
	uint8_t  Team;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bLocked : 1;  // 0x2(0x1)
	uint8_t  ObjType;  // 0x3(0x1)

}; 
// Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.SetBrushOpacityByCaptureStatus
// Size: 0x1E8(Inherited: 0x0) 
struct FSetBrushOpacityByCaptureStatus
{
	struct FSlateBrush BrushToUpdate;  // 0x0(0x88)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bLocked : 1;  // 0x88(0x1)
	uint8_t  ObjType;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct FSlateBrush NewBrush;  // 0x90(0x88)
	float OpacityToUse;  // 0x118(0x4)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool Temp_bool_Variable : 1;  // 0x11C(0x1)
	uint8_t  Temp_byte_Variable;  // 0x11D(0x1)
	char pad_286[2];  // 0x11E(0x2)
	struct FLinearColor K2Node_MakeStruct_LinearColor;  // 0x120(0x10)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x130(0x28)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x158(0x88)
	float K2Node_Select_Default;  // 0x1E0(0x4)
	float K2Node_Select_Default_2;  // 0x1E4(0x4)

}; 
// Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.SetBrushes
// Size: 0x198(Inherited: 0x0) 
struct FSetBrushes
{
	struct FSlateBrush IconFrame;  // 0x0(0x88)
	struct FSlateBrush Bg;  // 0x88(0x88)
	struct FSlateBrush Icon;  // 0x110(0x88)

}; 
// Function WBP_CaptureStatus_FlagIcon.WBP_CaptureStatus_FlagIcon_C.TintBrushByTeam
// Size: 0x1F8(Inherited: 0x0) 
struct FTintBrushByTeam
{
	struct FSlateBrush BrushToTint;  // 0x0(0x88)
	uint8_t  Team;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FSlateBrush NewBrush;  // 0x90(0x88)
	struct FSlateColor TintColor;  // 0x118(0x28)
	uint8_t  Temp_byte_Variable;  // 0x140(0x1)
	char pad_321[7];  // 0x141(0x7)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x148(0x88)
	struct FSlateColor K2Node_Select_Default;  // 0x1D0(0x28)

}; 
