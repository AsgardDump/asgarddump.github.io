#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.SetupListing
// Size: 0x8(Inherited: 0x0) 
struct FSetupListing
{
	struct UHDTextChatMsgInfo* Msg;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_TextChat_OutputListing.WBP_HUDElement_TextChat_OutputListing_C.ExecuteUbergraph_WBP_HUDElement_TextChat_OutputListing
// Size: 0x138(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUDElement_TextChat_OutputListing
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FString CallFunc_Replace_ReturnValue;  // 0x18(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x28(0x18)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x40(0x10)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x50(0x40)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x90(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA8(0x40)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xF0(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x100(0x18)
	struct UUMGSequencePlayer* CallFunc_CreatePlayAnimationProxyObject_Result;  // 0x118(0x8)
	struct UWidgetAnimationPlayCallbackProxy* CallFunc_CreatePlayAnimationProxyObject_ReturnValue;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct UHDTextChatMsgInfo* K2Node_CustomEvent_Msg;  // 0x130(0x8)

}; 
