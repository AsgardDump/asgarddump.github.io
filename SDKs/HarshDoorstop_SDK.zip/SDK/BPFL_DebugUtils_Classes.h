#pragma once 
#include <BPFL_DebugUtils_Structs.h>
 
 
 
// BlueprintGeneratedClass BPFL_DebugUtils.BPFL_DebugUtils_C
// Size: 0x28(Inherited: 0x28) 
struct UBPFL_DebugUtils_C : public UBlueprintFunctionLibrary
{

	void PrintFloat(struct FString Name, float InFloat, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintFloat
	void PrintInt(struct FString Name, int32_t InInteger, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintInt
	void PrintBool(struct FString Name, bool bInBool, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintBool
	void PrintStr(struct FString Name, struct FString Value, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintStr
	void PrintProperty(struct FString PropName, struct FString Value, struct FLinearColor TextColor, struct UObject* __WorldContext); // Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintProperty
}; 



