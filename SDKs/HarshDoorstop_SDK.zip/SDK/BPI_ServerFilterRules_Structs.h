#pragma once 
#include "SDK.h" 
 
 
// Function BPI_ServerFilterRules.BPI_ServerFilterRules_C.GetFilterRules
// Size: 0x58(Inherited: 0x0) 
struct FGetFilterRules
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActiveOnly : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TMap<UHDServerListFilterRule*, struct FHDFilterRuleParams> FilterRules;  // 0x8(0x50)

}; 
