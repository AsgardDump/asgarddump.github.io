#pragma once 
#include <WBP_DeathScreen_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeathScreen.WBP_DeathScreen_C
// Size: 0x240(Inherited: 0x230) 
struct UWBP_DeathScreen_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UTextBlock* DeathKeyBindText;  // 0x238(0x8)

	void UpdateDeathKeyText(struct FKey& Key); // Function WBP_DeathScreen.WBP_DeathScreen_C.UpdateDeathKeyText
	void PreConstruct(bool IsDesignTime); // Function WBP_DeathScreen.WBP_DeathScreen_C.PreConstruct
	void ExecuteUbergraph_WBP_DeathScreen(int32_t EntryPoint); // Function WBP_DeathScreen.WBP_DeathScreen_C.ExecuteUbergraph_WBP_DeathScreen
}; 



