#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickRot
// Size: 0xB0(Inherited: 0x0) 
struct FTickRot
{
	float DeltaTime;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USpringArmComponent* CallFunc_GetFPPSpringArmComp_FPPSpringArm;  // 0x8(0x8)
	float CallFunc_GetLeanRollRot_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x18(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x1C(0xC)
	struct FHitResult CallFunc_K2_AddRelativeRotation_SweepHitResult;  // 0x28(0x88)

}; 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.ExecuteUbergraph_BP_HDCharacterLeanHandler
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDCharacterLeanHandler
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ADFBaseCharacter* CallFunc_GetOwningCharacter_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float K2Node_Event_DeltaTime;  // 0x14(0x4)

}; 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickYOffset
// Size: 0xC4(Inherited: 0x0) 
struct FTickYOffset
{
	float DeltaTime;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ADFBaseCharacter* CallFunc_GetOwningCharacter_ReturnValue;  // 0x8(0x8)
	float CallFunc_GetLeanYOffset_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct USpringArmComponent* CallFunc_GetFPPSpringArmComp_FPPSpringArm;  // 0x18(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_BreakVector_X;  // 0x24(0x4)
	float CallFunc_BreakVector_Y;  // 0x28(0x4)
	float CallFunc_BreakVector_Z;  // 0x2C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x30(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x3C(0x88)

}; 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaTime;  // 0x0(0x4)

}; 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPMeshComp
// Size: 0x21(Inherited: 0x0) 
struct FGetFPPMeshComp
{
	struct USkeletalMeshComponent* FPPMesh;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ADFBaseCharacter* CallFunc_GetOwningCharacter_ReturnValue;  // 0x10(0x8)
	struct ADFBasePlayerCharacter* K2Node_DynamicCast_AsDFBase_Player_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPSpringArmComp
// Size: 0x21(Inherited: 0x0) 
struct FGetFPPSpringArmComp
{
	struct USpringArmComponent* FPPSpringArm;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ADFBaseCharacter* CallFunc_GetOwningCharacter_ReturnValue;  // 0x10(0x8)
	struct AHDPlayerCharacter* K2Node_DynamicCast_AsHDPlayer_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPCameraComp
// Size: 0x21(Inherited: 0x0) 
struct FGetFPPCameraComp
{
	struct UCameraComponent* FPPCamera;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ADFBaseCharacter* CallFunc_GetOwningCharacter_ReturnValue;  // 0x10(0x8)
	struct ADFBasePlayerCharacter* K2Node_DynamicCast_AsDFBase_Player_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickXOffset
// Size: 0xBC(Inherited: 0x0) 
struct FTickXOffset
{
	float DeltaTime;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USpringArmComponent* CallFunc_GetFPPSpringArmComp_FPPSpringArm;  // 0x8(0x8)
	float CallFunc_GetLeanXOffset_ReturnValue;  // 0x10(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x14(0x4)
	float CallFunc_BreakVector_X;  // 0x18(0x4)
	float CallFunc_BreakVector_Y;  // 0x1C(0x4)
	float CallFunc_BreakVector_Z;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x28(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x34(0x88)

}; 
