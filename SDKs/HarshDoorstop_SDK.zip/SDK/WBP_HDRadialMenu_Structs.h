#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.ExecuteUbergraph_WBP_HDRadialMenu
// Size: 0x1A9(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HDRadialMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x8(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TArray<struct FName> CallFunc_GetCategories_Categories;  // 0x20(0x10)
	int32_t K2Node_ComponentBoundEvent_NewSelection;  // 0x30(0x4)
	int32_t K2Node_ComponentBoundEvent_OldSelection;  // 0x34(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct TArray<struct FName> CallFunc_GetItemNamesForSelectedOption_OutRowNames;  // 0x50(0x10)
	struct FName CallFunc_Array_Get_Item_2;  // 0x60(0x8)
	struct FSHDRadialMenu_OptionData CallFunc_GetCategoryData_CategoryData;  // 0x68(0x28)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_2 : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x94(0x38)
	float K2Node_Event_InDeltaTime;  // 0xCC(0x4)
	struct FSHDRadialMenu_OptionData K2Node_MakeStruct_SHDRadialMenu_OptionData;  // 0xD0(0x28)
	struct FSHDRadialMenu_OptionData K2Node_MakeStruct_SHDRadialMenu_OptionData_2;  // 0xF8(0x28)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue_2 : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct FSHDRadialMenu_OptionData CallFunc_GetItemData_ItemData;  // 0x128(0x28)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x150(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x160(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x170(0x10)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue_2 : 1;  // 0x180(0x1)
	char pad_385[3];  // 0x181(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x184(0x10)
	char pad_404[4];  // 0x194(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_2;  // 0x198(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base_2;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1A8(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetItemData
// Size: 0xB9(Inherited: 0x0) 
struct FGetItemData
{
	struct FName RowName;  // 0x0(0x8)
	struct FSHDRadialMenu_OptionData ItemData;  // 0x8(0x28)
	struct FSHDRadialMenu_OptionData K2Node_MakeStruct_SHDRadialMenu_OptionData;  // 0x30(0x28)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FSHDRadialMenu_OptionData K2Node_MakeStruct_SHDRadialMenu_OptionData_2;  // 0x60(0x28)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FSHDRadialMenu_OptionData CallFunc_GetDataTableRowFromName_OutRow;  // 0x90(0x28)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0xB8(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetOutpostName
// Size: 0x59(Inherited: 0x0) 
struct FGetOutpostName
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_CalcOutpostEnemiesNearbyRestriction_bAreEnemiesNearby : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsOutpostNumberLimitReached_bNumberLimitReached : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_RadialMenuCanSelectOutpost_bSelectable : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_CalcOutpostDistanceRestriction_bIsOutpostDistanceRestricted : 1;  // 0x23(0x1)
	char pad_36[4];  // 0x24(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x28(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FText CallFunc_GetOutpostTimeRemaining_TimeRemaining;  // 0x40(0x18)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_GetIsSpawnedOutpostValid_bIsSpawnedOutpostValid : 1;  // 0x58(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategoryName
// Size: 0x89(Inherited: 0x0) 
struct FGetCategoryName
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x18(0x8)
	struct FText CallFunc_GetOutpostName_ReturnValue;  // 0x20(0x18)
	struct FText CallFunc_MakeLiteralText_ReturnValue;  // 0x38(0x18)
	struct FText CallFunc_GetRallypointName_ReturnValue;  // 0x50(0x18)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_EqualEqual_TextText_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FText CallFunc_MakeLiteralText_ReturnValue_2;  // 0x70(0x18)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_EqualEqual_TextText_ReturnValue_2 : 1;  // 0x88(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.BndEvt__categoryRing_K2Node_ComponentBoundEvent_1_SelectionChanged__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__categoryRing_K2Node_ComponentBoundEvent_1_SelectionChanged__DelegateSignature
{
	int32_t NewSelection;  // 0x0(0x4)
	int32_t OldSelection;  // 0x4(0x4)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetItemNamesForSelectedOption
// Size: 0x48(Inherited: 0x0) 
struct FGetItemNamesForSelectedOption
{
	struct TArray<struct FName> OutRowNames;  // 0x0(0x10)
	struct FSHDRadialMenu_OptionData CallFunc_GetCategoryData_CategoryData;  // 0x10(0x28)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x38(0x10)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategoryData
// Size: 0x81(Inherited: 0x0) 
struct FGetCategoryData
{
	struct FName Category;  // 0x0(0x8)
	struct FSHDRadialMenu_OptionData CategoryData;  // 0x8(0x28)
	struct FSHDRadialMenu_OptionData K2Node_MakeStruct_SHDRadialMenu_OptionData;  // 0x30(0x28)
	struct FSHDRadialMenu_OptionData CallFunc_GetDataTableRowFromName_OutRow;  // 0x58(0x28)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x80(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetCategories
// Size: 0x20(Inherited: 0x0) 
struct FGetCategories
{
	struct TArray<struct FName> Categories;  // 0x0(0x10)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x10(0x10)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.PopulateMenuOptions
// Size: 0x8D(Inherited: 0x0) 
struct FPopulateMenuOptions
{
	struct UDataTable* MenuOptions;  // 0x0(0x8)
	struct FSHDRadialMenu_OptionData CallFunc_GetDataTableRowFromName_OutRow;  // 0x8(0x28)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UWBP_RadialMenuIconBase_C* CallFunc_MakeOutpostIcon_Widget;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_AddChildToRadialMenu_Success : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FSHDRadialMenu_OptionData CallFunc_GetDataTableRowFromName_OutRow_2;  // 0x48(0x28)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct UWBP_RadialMenuIconBase_C* CallFunc_MakeRallypointIcon_Widget;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_AddChildToRadialMenu_Success_2 : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_AddChildToRadialMenu_Success_3 : 1;  // 0x81(0x1)
	char pad_130_1 : 7;  // 0x82(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x82(0x1)
	char pad_131[1];  // 0x83(0x1)
	int32_t Temp_int_Variable;  // 0x84(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x8C(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.PopulateSubmenuOptions
// Size: 0x79(Inherited: 0x0) 
struct FPopulateSubmenuOptions
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct TArray<struct FName> CallFunc_GetItemNamesForSelectedOption_OutRowNames;  // 0x10(0x10)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue;  // 0x20(0x8)
	struct FName CallFunc_Array_Get_Item;  // 0x28(0x8)
	struct FSHDRadialMenu_OptionData CallFunc_GetItemData_ItemData;  // 0x30(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x58(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x5C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x60(0x8)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_AddChildToRadialMenu_Success : 1;  // 0x71(0x1)
	char pad_114[2];  // 0x72(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_AddChildToRadialMenu_Success_2 : 1;  // 0x78(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.SelectSubmenu
// Size: 0x29(Inherited: 0x0) 
struct FSelectSubmenu
{
	struct FSHDRadialMenu_OptionData CallFunc_GetCategoryData_CategoryData;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeSpottingIcon
// Size: 0x71(Inherited: 0x0) 
struct FMakeSpottingIcon
{
	struct FSHDRadialMenu_OptionData OptionData;  // 0x0(0x28)
	struct UWBP_RadialMenuIconBase_C* Widget;  // 0x28(0x8)
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x30(0x8)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x38(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x50(0x8)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue;  // 0x58(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x60(0x8)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_RadialMenuCanSelectSpot_bSelectable : 1;  // 0x70(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.OwnerPawnDeath
// Size: 0x38(Inherited: 0x0) 
struct FOwnerPawnDeath
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeRallypointIcon
// Size: 0x71(Inherited: 0x0) 
struct FMakeRallypointIcon
{
	struct FSHDRadialMenu_OptionData OptionData;  // 0x0(0x28)
	struct UWBP_RadialMenuIconBase_C* Widget;  // 0x28(0x8)
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x30(0x8)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x38(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x50(0x8)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue;  // 0x58(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x60(0x8)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_RadialMenuCanSelectRallypoint_bSelectable : 1;  // 0x70(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.MakeOutpostIcon
// Size: 0x71(Inherited: 0x0) 
struct FMakeOutpostIcon
{
	struct FSHDRadialMenu_OptionData OptionData;  // 0x0(0x28)
	struct UWBP_RadialMenuIconBase_C* Widget;  // 0x28(0x8)
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x30(0x8)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x38(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x50(0x8)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue;  // 0x58(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x60(0x8)
	struct UWBP_RadialMenuIconBase_C* CallFunc_Create_ReturnValue_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_RadialMenuCanSelectOutpost_bSelectable : 1;  // 0x70(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetRallypointTimeRemaining
// Size: 0x11C(Inherited: 0x0) 
struct FGetRallypointTimeRemaining
{
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x0(0x8)
	struct FText TimeRemaining;  // 0x8(0x18)
	float RallypointTimeRemaining;  // 0x20(0x4)
	float RallypointRespawnTime;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2C(0x4)
	struct FTimespan CallFunc_FromSeconds_ReturnValue;  // 0x30(0x8)
	float CallFunc_SelectFloat_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_BreakTimespan_Days;  // 0x3C(0x4)
	int32_t CallFunc_BreakTimespan_Hours;  // 0x40(0x4)
	int32_t CallFunc_BreakTimespan_Minutes;  // 0x44(0x4)
	int32_t CallFunc_BreakTimespan_Seconds;  // 0x48(0x4)
	int32_t CallFunc_BreakTimespan_Milliseconds;  // 0x4C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x50(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x68(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xE8(0x10)
	float CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct FText CallFunc_Format_ReturnValue;  // 0x100(0x18)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x118(0x4)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetRallypointName
// Size: 0x52(Inherited: 0x0) 
struct FGetRallypointName
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_CalcRallypointEnemiesNearbyRestriction_bAreEnemiesNearby : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_RadialMenuCanSelectRallypoint_bSelectable : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_CalcRallypointDistanceRestriction_bIsRallypointDistanceRestricted : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_GetIsSpawnedRallypointValid_bIsSpawnedRallypointValid : 1;  // 0x23(0x1)
	char pad_36[4];  // 0x24(0x4)
	struct FText CallFunc_GetRallypointTimeRemaining_TimeRemaining;  // 0x28(0x18)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x40(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsRallypointNumberLimitReached_bNumberLimitReached : 1;  // 0x51(0x1)

}; 
// Function WBP_HDRadialMenu.WBP_HDRadialMenu_C.GetOutpostTimeRemaining
// Size: 0x110(Inherited: 0x0) 
struct FGetOutpostTimeRemaining
{
	struct ABP_HDPlayerCharacterBase_C* OwnerPawn;  // 0x0(0x8)
	struct FText TimeRemaining;  // 0x8(0x18)
	float CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0x20(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FTimespan CallFunc_FromSeconds_ReturnValue;  // 0x30(0x8)
	int32_t CallFunc_BreakTimespan_Days;  // 0x38(0x4)
	int32_t CallFunc_BreakTimespan_Hours;  // 0x3C(0x4)
	int32_t CallFunc_BreakTimespan_Minutes;  // 0x40(0x4)
	int32_t CallFunc_BreakTimespan_Seconds;  // 0x44(0x4)
	int32_t CallFunc_BreakTimespan_Milliseconds;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x50(0x40)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x90(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA8(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xE8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xF8(0x18)

}; 
