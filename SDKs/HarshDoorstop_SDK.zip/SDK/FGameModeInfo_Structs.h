#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FGameModeInfo.FGameModeInfo
// Size: 0x28(Inherited: 0x0) 
struct FFGameModeInfo
{
	struct FName PackageName_10_DE62EF824DB907D3A65B2EB997DB647E;  // 0x0(0x8)
	struct FText DisplayName_7_446411A24792CE413F09BCA2B0B6D2D6;  // 0x8(0x18)
	struct UTexture2D* BannerImage_18_9311664649510AFCF003C4B106EF5C56;  // 0x20(0x8)

}; 
