#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FNumericModifierValueBound.FNumericModifierValueBound
// Size: 0x8(Inherited: 0x0) 
struct FFNumericModifierValueBound
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled_6_0293F2C7458E05C676241791D8AD3719 : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float Bound_3_25213DFA41A567AA433FC4A5458865AE;  // 0x4(0x4)

}; 
