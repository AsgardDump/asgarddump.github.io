#pragma once 
#include <WBP_JoinServer_Header_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_JoinServer_Header.WBP_JoinServer_Header_C
// Size: 0x289(Inherited: 0x230) 
struct UWBP_JoinServer_Header_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UTextBlock* HeaderText;  // 0x238(0x8)
	struct FDataTableRowHandle LayoutInfoHandle;  // 0x240(0x10)
	struct FFServerListingLayoutInfo HeaderLayoutInfo;  // 0x250(0x38)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool bSortListBtnEnabled : 1;  // 0x288(0x1)

	void SetSortBtnIsEnabled(bool bEnabled); // Function WBP_JoinServer_Header.WBP_JoinServer_Header_C.SetSortBtnIsEnabled
	void PreConstruct(bool IsDesignTime); // Function WBP_JoinServer_Header.WBP_JoinServer_Header_C.PreConstruct
	void ExecuteUbergraph_WBP_JoinServer_Header(int32_t EntryPoint); // Function WBP_JoinServer_Header.WBP_JoinServer_Header_C.ExecuteUbergraph_WBP_JoinServer_Header
}; 



