#pragma once 
#include <WBP_MouseInputCatcherOverlay_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C
// Size: 0x238(Inherited: 0x230) 
struct UWBP_MouseInputCatcherOverlay_C : public UUserWidget
{
	struct UWBP_OptionsMenuItem_InputKeySelector_C* TargetIKS;  // 0x230(0x8)

	struct FEventReply OnMouseWheel(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.OnMouseWheel
	void SelectKey(struct FKey Key); // Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.SelectKey
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.OnMouseButtonDown
}; 



