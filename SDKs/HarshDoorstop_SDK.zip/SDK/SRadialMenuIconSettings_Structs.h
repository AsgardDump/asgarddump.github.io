#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct SRadialMenuIconSettings.SRadialMenuIconSettings
// Size: 0x28(Inherited: 0x0) 
struct FSRadialMenuIconSettings
{
	char EIconAnimationStyles AnimationStyle_2_C5857E2F4AC7D5363326C8B5363D9ADD;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FLinearColor HighlightColor_7_FCF133C849CA59F3A456E984F1122433;  // 0x4(0x10)
	struct FLinearColor UnhighlightColor_9_20CEE6F940EC3C0A462D609528F7D138;  // 0x14(0x10)
	float ColorTransitionSpeed_12_2636B2604C9B6A366DD018A588954C28;  // 0x24(0x4)

}; 
