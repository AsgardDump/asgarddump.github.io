#pragma once 
#include <WBP_JoinServerListEntry_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_JoinServerListEntry.WBP_JoinServerListEntry_C
// Size: 0x885(Inherited: 0x270) 
struct UWBP_JoinServerListEntry_C : public UHDServerListing
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x270(0x8)
	struct UWBP_ServerListEntryColumn_C* GameVersionCol;  // 0x278(0x8)
	struct UWBP_ServerListEntryColumn_C* GMNameCol;  // 0x280(0x8)
	struct UImage* ItemBg;  // 0x288(0x8)
	struct USizeBox* ItemBox;  // 0x290(0x8)
	struct UCheckBox* ItemCheckBox;  // 0x298(0x8)
	struct UImage* ItemSelectionHighlight;  // 0x2A0(0x8)
	struct UWBP_ServerListEntryColumn_C* MapNameCol;  // 0x2A8(0x8)
	struct UWBP_ServerListEntryColumn_C* PingCol;  // 0x2B0(0x8)
	struct UWBP_ServerListEntryColumn_C* PlayerCountCol;  // 0x2B8(0x8)
	struct UHorizontalBox* ServerBadgeHBox;  // 0x2C0(0x8)
	struct UWBP_ServerListEntryColumn_C* ServerNameCol;  // 0x2C8(0x8)
	struct FMulticastInlineDelegate OnSelectionStateChanged;  // 0x2D0(0x10)
	struct UTexture2D* PlaceholderMapBannerImg;  // 0x2E0(0x8)
	struct FMargin BadgePadding;  // 0x2E8(0x10)
	struct FCheckBoxStyle ItemStyle;  // 0x2F8(0x580)
	char pad_2168_1 : 7;  // 0x878(0x1)
	bool bSelectionToggle : 1;  // 0x878(0x1)
	char pad_2169[3];  // 0x879(0x3)
	int32_t ItemMinWidth;  // 0x87C(0x4)
	int32_t ItemMinHeight;  // 0x880(0x4)
	char pad_2180_1 : 7;  // 0x884(0x1)
	bool bBadgesInitialized : 1;  // 0x884(0x1)

	void AddBadgeDefinitionToListIfFound(struct FName TableRowName, struct TArray<struct FFServerBadgeUIDefinition>& BadgeArr); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.AddBadgeDefinitionToListIfFound
	void CreateAndAddBadgeWidgetFromDefinition(struct FFServerBadgeUIDefinition& BadgeUIDef); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.CreateAndAddBadgeWidgetFromDefinition
	void GetBadgeDefinitionFromTable(struct FDataTableRowHandle RowHandle, bool& bFound, struct FFServerBadgeUIDefinition& BadgeUIDef); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBadgeDefinitionFromTable
	void HideAllBadges(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.HideAllBadges
	void SetBadgeVisibilityFromServerData(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetBadgeVisibilityFromServerData
	void PopulateBadges(struct TArray<struct FFServerBadgeUIDefinition>& BadgeDefs); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.PopulateBadges
	void GetBrushWithItemDimensions(struct FSlateBrush& InBrush, struct FSlateBrush& OutBrush); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBrushWithItemDimensions
	void GetBrushWithImageTexture(struct FSlateBrush& Brush, struct UTexture2D* Image, struct FSlateBrush& UpdatedBrush); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetBrushWithImageTexture
	void InternalRefreshDimensions(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.InternalRefreshDimensions
	void GetItemMinHeight(int32_t& MinHeight); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemMinHeight
	void GetItemMinWidth(int32_t& MinWidth); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemMinWidth
	void SetItemMinDimensions(int32_t InMinWidth, int32_t InMinHeight); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemMinDimensions
	void GetItemStyle(struct FCheckBoxStyle& ItemStyle); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemStyle
	void SetItemImage(struct UTexture2D* InItemImg); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemImage
	void SetItemStyle(struct FCheckBoxStyle InItemStyle); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemStyle
	void InternalUpdateItemBgTintColor(bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.InternalUpdateItemBgTintColor
	void IsItemSelected(bool& bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.IsItemSelected
	void GetItemSelectionState(uint8_t & SelectionState); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.GetItemSelectionState
	void SetItemIsSelected(bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemIsSelected
	void SetItemSelectionState(uint8_t  InSelectionState); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.SetItemSelectionState
	void PreConstruct(bool IsDesignTime); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.PreConstruct
	void BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BndEvt__ItemCheckBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
	void BP_OnItemSelectionChanged(bool bIsSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnItemSelectionChanged
	void On Selection State Changed(bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.On Selection State Changed
	void OnListItemObjectSet(struct UObject* ListItemObject); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnListItemObjectSet
	void OnServerItemDataSet(bool bIsDesignTime); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnServerItemDataSet
	void BP_OnEntryReleased(); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnEntryReleased
	void BP_OnItemExpansionChanged(bool bIsExpanded); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.BP_OnItemExpansionChanged
	void ExecuteUbergraph_WBP_JoinServerListEntry(int32_t EntryPoint); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.ExecuteUbergraph_WBP_JoinServerListEntry
	void OnSelectionStateChanged__DelegateSignature(struct UWBP_JoinServerListEntry_C* Item, bool bSelected); // Function WBP_JoinServerListEntry.WBP_JoinServerListEntry_C.OnSelectionStateChanged__DelegateSignature
}; 



