#pragma once 
#include "SDK.h" 
 
 
// Function DonkehFrameworkUI.DFMinimap.GetPOIIndex
// Size: 0x10(Inherited: 0x0) 
struct FGetPOIIndex
{
	struct UDFPOIWidget* POI;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction DonkehFrameworkUI.POISelectionStateSignature__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FPOISelectionStateSignature__DelegateSignature
{
	struct UDFPOIWidget* POI;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelected : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.POIWidgetSlotInterface.GetIconSlot
// Size: 0x8(Inherited: 0x0) 
struct FGetIconSlot
{
	struct UNamedSlot* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.IsPOIActorValid
// Size: 0x1(Inherited: 0x0) 
struct FIsPOIActorValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.GetWidgetOuter
// Size: 0x8(Inherited: 0x0) 
struct FGetWidgetOuter
{
	struct UDFContextualWidgetBase* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFContextualWidgetBase.PrerequisiteNotMet
// Size: 0x8(Inherited: 0x0) 
struct FPrerequisiteNotMet
{
	struct UDFContextualWidgetPrerequisiteBase* FailedPrereq;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFBaseMenu.IsTopOfMenuStack
// Size: 0x1(Inherited: 0x0) 
struct FIsTopOfMenuStack
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFrameworkUI.MenuStackEntry
// Size: 0x10(Inherited: 0x0) 
struct FMenuStackEntry
{
	struct UDFBaseMenu* Menu;  // 0x0(0x8)
	uint8_t  ActivationMode;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bShowMouseCursor : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bUIOnlyInput : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// Function DonkehFrameworkUI.DFContextualWidgetBase.TestPrerequisites
// Size: 0x2(Inherited: 0x0) 
struct FTestPrerequisites
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInvokeEvents : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// ScriptStruct DonkehFrameworkUI.MinimapPOITableRow
// Size: 0x130(Inherited: 0x8) 
struct FMinimapPOITableRow : public FTableRowBase
{
	struct TSoftClassPtr<UObject> ActorClass;  // 0x8(0x28)
	char bMatchChildClasses : 1;  // 0x30(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	char pad_49[8];  // 0x31(0x8)
	struct TSoftClassPtr<UObject> ToolTipWidgetClass;  // 0x38(0x28)
	struct TSoftClassPtr<UObject> WidgetClass;  // 0x60(0x28)
	struct FSlateBrush IconBrush;  // 0x88(0x88)
	struct FText ToolTipText;  // 0x110(0x18)
	char bSelectable : 1;  // 0x128(0x1)
	char bDynamic : 1;  // 0x128(0x1)
	char bFixedRotation : 1;  // 0x128(0x1)
	char pad_296_1 : 5;  // 0x128(0x1)
	char pad_297[8];  // 0x129(0x8)

}; 
// Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.SatisfiesPrerequisite
// Size: 0x1(Inherited: 0x0) 
struct FSatisfiesPrerequisite
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFContextualWidgetPrerequisiteBase.TestPrerequisite
// Size: 0x1(Inherited: 0x0) 
struct FTestPrerequisite
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFMinimap.RemovePOIByActor
// Size: 0x10(Inherited: 0x0) 
struct FRemovePOIByActor
{
	struct AActor* POIActorToRemove;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFMenuManager.ActivateMenu
// Size: 0x10(Inherited: 0x0) 
struct FActivateMenu
{
	struct UDFBaseMenu* MenuToAdd;  // 0x0(0x8)
	uint8_t  ActivationMode;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bShowMouseCursor : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bUIOnlyInput : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)

}; 
// Function DonkehFrameworkUI.POIWidgetSlotInterface.SetIconBrush
// Size: 0x88(Inherited: 0x0) 
struct FSetIconBrush
{
	struct FSlateBrush NewIconBrush;  // 0x0(0x88)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.SetPOISelectionState
// Size: 0x1(Inherited: 0x0) 
struct FSetPOISelectionState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewSelected : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFMenuManager.RemoveMenu
// Size: 0x8(Inherited: 0x0) 
struct FRemoveMenu
{
	struct UDFBaseMenu* MenuToRemove;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.OnPOIActorEndPlay
// Size: 0x10(Inherited: 0x0) 
struct FOnPOIActorEndPlay
{
	struct AActor* Actor;  // 0x0(0x8)
	char EEndPlayReason EndPlayReason;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFMenuManager.Top
// Size: 0x8(Inherited: 0x0) 
struct FTop
{
	struct UDFBaseMenu* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFPOIComponent.IsPOIRegistered
// Size: 0x1(Inherited: 0x0) 
struct FIsPOIRegistered
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFMinimap.GetMapSizeAbsolute
// Size: 0x8(Inherited: 0x0) 
struct FGetMapSizeAbsolute
{
	struct FVector2D ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFMenuManagerBlueprintFunctions.CreateAndActivate
// Size: 0x28(Inherited: 0x0) 
struct FCreateAndActivate
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	UDFBaseMenu* MenuWidgetType;  // 0x8(0x8)
	struct APlayerController* OwningPlayer;  // 0x10(0x8)
	uint8_t  ActivationMode;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bShowMouseCursor : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool bUIOnlyInput : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	struct UDFBaseMenu* ReturnValue;  // 0x20(0x8)

}; 
// Function DonkehFrameworkUI.DFMenuManagerBlueprintFunctions.GetMenuManager
// Size: 0x10(Inherited: 0x0) 
struct FGetMenuManager
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UDFMenuManager* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFrameworkUI.DFMinimap.AddNewPOI
// Size: 0x10(Inherited: 0x0) 
struct FAddNewPOI
{
	struct AActor* POIActor;  // 0x0(0x8)
	struct UDFPOIWidget* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFrameworkUI.DFMinimap.ClearPOIs
// Size: 0x4(Inherited: 0x0) 
struct FClearPOIs
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFrameworkUI.DFMinimap.ConvertMapLocationToLocalWidgetLocation
// Size: 0x14(Inherited: 0x0) 
struct FConvertMapLocationToLocalWidgetLocation
{
	struct FVector2D MapLocation;  // 0x0(0x8)
	struct FVector2D WidgetLocation;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function DonkehFrameworkUI.DFMinimap.RemovePOI
// Size: 0x10(Inherited: 0x0) 
struct FRemovePOI
{
	struct UDFPOIWidget* POIToRemove;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFMinimap.DeprojectMapLocationToWorld
// Size: 0x18(Inherited: 0x0) 
struct FDeprojectMapLocationToWorld
{
	struct FVector2D MapLocation;  // 0x0(0x8)
	struct FVector WorldLocation;  // 0x8(0xC)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function DonkehFrameworkUI.DFMinimap.FindPOIByActor
// Size: 0x18(Inherited: 0x0) 
struct FFindPOIByActor
{
	struct AActor* POIActor;  // 0x0(0x8)
	struct UDFPOIWidget* OutFoundPOI;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.IsSelectable
// Size: 0x1(Inherited: 0x0) 
struct FIsSelectable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFPOIComponent.GetPOIWidget
// Size: 0x8(Inherited: 0x0) 
struct FGetPOIWidget
{
	struct UDFPOIWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFMinimap.GetMapSizeLocal
// Size: 0x8(Inherited: 0x0) 
struct FGetMapSizeLocal
{
	struct FVector2D ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFMinimap.GetPOIAt
// Size: 0x10(Inherited: 0x0) 
struct FGetPOIAt
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UDFPOIWidget* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFrameworkUI.DFPOIComponent.RegisterPOI
// Size: 0x8(Inherited: 0x0) 
struct FRegisterPOI
{
	struct UDFMinimap* MinimapWidget;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFMinimap.GetPOICount
// Size: 0x4(Inherited: 0x0) 
struct FGetPOICount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function DonkehFrameworkUI.POIWidgetSlotInterface.GetIconBrush
// Size: 0x88(Inherited: 0x0) 
struct FGetIconBrush
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)

}; 
// Function DonkehFrameworkUI.DFMinimap.HasAnyPOIs
// Size: 0x1(Inherited: 0x0) 
struct FHasAnyPOIs
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFMinimap.HasPOI
// Size: 0x10(Inherited: 0x0) 
struct FHasPOI
{
	struct UDFPOIWidget* POI;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFMinimap.OnPOISelectionStateChanged
// Size: 0x10(Inherited: 0x0) 
struct FOnPOISelectionStateChanged
{
	struct UDFPOIWidget* POI;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelected : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFMinimap.ProjectWorldLocationToMap
// Size: 0x18(Inherited: 0x0) 
struct FProjectWorldLocationToMap
{
	struct FVector WorldLocation;  // 0x0(0xC)
	struct FVector2D MapLocation;  // 0xC(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function DonkehFrameworkUI.DFMinimap.ReceiveOnPOISelectionStateChanged
// Size: 0x10(Inherited: 0x0) 
struct FReceiveOnPOISelectionStateChanged
{
	struct UDFPOIWidget* POI;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelected : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFMinimap.RemovePOIAt
// Size: 0x8(Inherited: 0x0) 
struct FRemovePOIAt
{
	int32_t Index;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function DonkehFrameworkUI.DFMinimap.RemovePOIByActorClass
// Size: 0x10(Inherited: 0x0) 
struct FRemovePOIByActorClass
{
	AActor* POIActorClass;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFMinimap.UpdateMapPos
// Size: 0x8(Inherited: 0x0) 
struct FUpdateMapPos
{
	struct FVector2D NewMapPos;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFMinimap.UpdateZoomValue
// Size: 0x4(Inherited: 0x0) 
struct FUpdateZoomValue
{
	float NewZoomValue;  // 0x0(0x4)

}; 
// Function DonkehFrameworkUI.DFPOIComponent.GetMinimap
// Size: 0x8(Inherited: 0x0) 
struct FGetMinimap
{
	struct UDFMinimap* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFPOIComponent.OnMinimapLateInit
// Size: 0x8(Inherited: 0x0) 
struct FOnMinimapLateInit
{
	struct UDFMinimap* NewMinimap;  // 0x0(0x8)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.IsInitialized
// Size: 0x1(Inherited: 0x0) 
struct FIsInitialized
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.CanSelect
// Size: 0x1(Inherited: 0x0) 
struct FCanSelect
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.GetDefaultIconBrush
// Size: 0x88(Inherited: 0x0) 
struct FGetDefaultIconBrush
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.ReceiveOnPOIActorEndPlay
// Size: 0x10(Inherited: 0x0) 
struct FReceiveOnPOIActorEndPlay
{
	struct AActor* Actor;  // 0x0(0x8)
	char EEndPlayReason EndPlayReason;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.InitPOI
// Size: 0x140(Inherited: 0x0) 
struct FInitPOI
{
	struct UDFMinimap* OwningMapWidget;  // 0x0(0x8)
	struct AActor* ActorToTrack;  // 0x8(0x8)
	struct FMinimapPOITableRow ActorPOIData;  // 0x10(0x130)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.HasFixedRotation
// Size: 0x1(Inherited: 0x0) 
struct FHasFixedRotation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.IsDynamic
// Size: 0x1(Inherited: 0x0) 
struct FIsDynamic
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkUI.DFPOIWidget.ReceiveCanSelect
// Size: 0x1(Inherited: 0x0) 
struct FReceiveCanSelect
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
