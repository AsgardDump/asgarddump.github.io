#pragma once 
#include <WBP_OptionMenu_Options_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionMenu_Options.WBP_OptionMenu_Options_C
// Size: 0x8A0(Inherited: 0x238) 
struct UWBP_OptionMenu_Options_C : public UHDOptionsMenu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* AAOption;  // 0x240(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* AimDownSights_IKS;  // 0x248(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* AimDownSightsToggle_IKS;  // 0x250(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* AllowSoundInBgOption;  // 0x258(0x8)
	struct UWBP_TextButton_C* ApplyBtn;  // 0x260(0x8)
	struct UWBP_TextButton_C* AudioBtn;  // 0x268(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* AudioQualityOption;  // 0x270(0x8)
	struct UScrollBox* AudioSBox;  // 0x278(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* CameraToggle_IKS;  // 0x280(0x8)
	struct UVerticalBox* CameraVideoVBox;  // 0x288(0x8)
	struct UVerticalBox* CommunicationKeyRemappingVBox;  // 0x290(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Console_IKS;  // 0x298(0x8)
	struct UWBP_TextButton_C* ControlsBtn;  // 0x2A0(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Crouch_IKS;  // 0x2A8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* CrouchToggle_IKS;  // 0x2B0(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* CycleWeaponSights_IKS;  // 0x2B8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* DeployMenu_IKS;  // 0x2C0(0x8)
	struct UWBP_TextButton_C* DiscardChangesBtn;  // 0x2C8(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* DisplayGammaOption;  // 0x2D0(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* DisplayModeOption;  // 0x2D8(0x8)
	struct UImage* DividerM;  // 0x2E0(0x8)
	struct UImage* DividerM_2;  // 0x2E8(0x8)
	struct UImage* DividerM_3;  // 0x2F0(0x8)
	struct UImage* DividerM_4;  // 0x2F8(0x8)
	struct UImage* DividerM_5;  // 0x300(0x8)
	struct UImage* DividerM_6;  // 0x308(0x8)
	struct UImage* DividerM_7;  // 0x310(0x8)
	struct UImage* DividerM_8;  // 0x318(0x8)
	struct UImage* DividerM_9;  // 0x320(0x8)
	struct UImage* DividerM_10;  // 0x328(0x8)
	struct UImage* DividerM_11;  // 0x330(0x8)
	struct UImage* DividerM_12;  // 0x338(0x8)
	struct UImage* DividerM_13;  // 0x340(0x8)
	struct UImage* DividerM_14;  // 0x348(0x8)
	struct UImage* DividerM_15;  // 0x350(0x8)
	struct UImage* DividerM_16;  // 0x358(0x8)
	struct UImage* DividerM_17;  // 0x360(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* FieldOfViewOption;  // 0x368(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Fire_IKS;  // 0x370(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* FoliageOption;  // 0x378(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* FrameRateLimitOption;  // 0x380(0x8)
	struct UVerticalBox* FrameRateVideoVBox;  // 0x388(0x8)
	struct UWBP_TextButton_C* GameplayBtn;  // 0x390(0x8)
	struct UScrollBox* GameplaySBox;  // 0x398(0x8)
	struct UVerticalBox* GeneralAudioVBox;  // 0x3A0(0x8)
	struct UVerticalBox* GeneralGameplayVBox;  // 0x3A8(0x8)
	struct UVerticalBox* GeneralVideoVBox;  // 0x3B0(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* GlobalMouseSensitivityOption;  // 0x3B8(0x8)
	struct UImage* HeaderDivider;  // 0x3C0(0x8)
	struct UImage* HeaderDivider_2;  // 0x3C8(0x8)
	struct UImage* HeaderDivider_3;  // 0x3D0(0x8)
	struct UImage* HeaderDivider_4;  // 0x3D8(0x8)
	struct UImage* HeaderDivider_5;  // 0x3E0(0x8)
	struct UImage* HeaderDivider10;  // 0x3E8(0x8)
	struct UImage* HeaderDivider11;  // 0x3F0(0x8)
	struct UImage* HeaderDivider12;  // 0x3F8(0x8)
	struct UImage* HeaderDivider13;  // 0x400(0x8)
	struct UImage* HeaderDivider14;  // 0x408(0x8)
	struct UImage* HeaderDivider15;  // 0x410(0x8)
	struct UImage* HeaderDivider15_2;  // 0x418(0x8)
	struct UImage* HeaderDivider2;  // 0x420(0x8)
	struct UImage* HeaderDivider2_2;  // 0x428(0x8)
	struct UImage* HeaderDivider2_3;  // 0x430(0x8)
	struct UImage* HeaderDivider2_5;  // 0x438(0x8)
	struct UImage* HeaderDivider2_6;  // 0x440(0x8)
	struct UImage* HeaderDivider2_7;  // 0x448(0x8)
	struct UImage* HeaderDivider2_8;  // 0x450(0x8)
	struct UImage* HeaderDivider2_9;  // 0x458(0x8)
	struct UImage* HeaderDivider2_10;  // 0x460(0x8)
	struct UImage* HeaderDivider2_11;  // 0x468(0x8)
	struct UImage* HeaderDivider2_12;  // 0x470(0x8)
	struct UImage* HeaderDivider2_13;  // 0x478(0x8)
	struct UImage* HeaderDivider2_14;  // 0x480(0x8)
	struct UImage* HeaderDivider2_15;  // 0x488(0x8)
	struct UImage* HeaderDivider2_16;  // 0x490(0x8)
	struct UImage* HeaderDivider2_17;  // 0x498(0x8)
	struct UImage* HeaderDivider2_18;  // 0x4A0(0x8)
	struct UImage* HeaderDivider2_19;  // 0x4A8(0x8)
	struct UImage* HeaderDivider2_20;  // 0x4B0(0x8)
	struct UImage* HeaderDivider2_21;  // 0x4B8(0x8)
	struct UImage* HeaderDivider2_22;  // 0x4C0(0x8)
	struct UImage* HeaderDivider2_23;  // 0x4C8(0x8)
	struct UImage* HeaderDivider2_24;  // 0x4D0(0x8)
	struct UImage* HeaderDivider2_25;  // 0x4D8(0x8)
	struct UImage* HeaderDivider2_26;  // 0x4E0(0x8)
	struct UImage* HeaderDivider2_27;  // 0x4E8(0x8)
	struct UImage* HeaderDivider2_28;  // 0x4F0(0x8)
	struct UImage* HeaderDivider2_29;  // 0x4F8(0x8)
	struct UImage* HeaderDivider2_30;  // 0x500(0x8)
	struct UImage* HeaderDivider2_31;  // 0x508(0x8)
	struct UImage* HeaderDivider2_32;  // 0x510(0x8)
	struct UImage* HeaderDivider2_33;  // 0x518(0x8)
	struct UImage* HeaderDivider2_34;  // 0x520(0x8)
	struct UImage* HeaderDivider3;  // 0x528(0x8)
	struct UImage* HeaderDivider3_2;  // 0x530(0x8)
	struct UImage* HeaderDivider3_3;  // 0x538(0x8)
	struct UImage* HeaderDivider4;  // 0x540(0x8)
	struct UImage* HeaderDivider5;  // 0x548(0x8)
	struct UImage* HeaderDivider6;  // 0x550(0x8)
	struct UImage* HeaderDivider6_2;  // 0x558(0x8)
	struct UImage* HeaderDivider6_3;  // 0x560(0x8)
	struct UImage* HeaderDivider6_4;  // 0x568(0x8)
	struct UImage* HeaderDivider6_5;  // 0x570(0x8)
	struct UImage* HeaderDivider7;  // 0x578(0x8)
	struct UImage* HeaderDivider7_2;  // 0x580(0x8)
	struct UImage* HeaderDivider7_3;  // 0x588(0x8)
	struct UImage* HeaderDivider8;  // 0x590(0x8)
	struct UImage* HeaderDivider8_2;  // 0x598(0x8)
	struct UImage* HeaderDivider8_3;  // 0x5A0(0x8)
	struct UImage* HeaderDivider8_4;  // 0x5A8(0x8)
	struct UImage* HeaderDivider8_5;  // 0x5B0(0x8)
	struct UImage* HeaderDivider8_6;  // 0x5B8(0x8)
	struct UImage* HeaderDivider8_7;  // 0x5C0(0x8)
	struct UImage* HeaderDivider8_8;  // 0x5C8(0x8)
	struct UImage* HeaderDivider8_9;  // 0x5D0(0x8)
	struct UImage* HeaderDivider8_10;  // 0x5D8(0x8)
	struct UImage* HeaderDivider8_11;  // 0x5E0(0x8)
	struct UImage* HeaderDivider81;  // 0x5E8(0x8)
	struct UImage* HeaderDivider9;  // 0x5F0(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* HeadphoneModeOption;  // 0x5F8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Helper_IKS;  // 0x600(0x8)
	struct UVerticalBox* HelperVBox;  // 0x608(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* InvertMouseOption;  // 0x610(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Jump_IKS;  // 0x618(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* JumpVault_IKS;  // 0x620(0x8)
	struct UScrollBox* KeyRemappingSBox;  // 0x628(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* LeanLeft_IKS;  // 0x630(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* LeanLeftToggle_IKS;  // 0x638(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* LeanRight_IKS;  // 0x640(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* LeanRightToggle_IKS;  // 0x648(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* MasterVolOption;  // 0x650(0x8)
	struct UVerticalBox* MiscellaneousKeyRemappingVBox;  // 0x658(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* MotionBlurOption;  // 0x660(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* MoveBackward_IKS;  // 0x668(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* MoveForward_IKS;  // 0x670(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* MoveLeft_IKS;  // 0x678(0x8)
	struct UVerticalBox* MovementKeyRemappingVBox;  // 0x680(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* MoveRight_IKS;  // 0x688(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* MusicVolOption;  // 0x690(0x8)
	struct UImage* NavBarBg;  // 0x698(0x8)
	struct UHorizontalBox* NavHBox;  // 0x6A0(0x8)
	struct UWidgetSwitcher* NavWS;  // 0x6A8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* NextWeapon_IKS;  // 0x6B0(0x8)
	struct UImage* OptionsMenuBg;  // 0x6B8(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* OverallQualityOption;  // 0x6C0(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* PointAimToggle_IKS;  // 0x6C8(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* PPOption;  // 0x6D0(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* PreviousWeapon_IKS;  // 0x6D8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Prone_IKS;  // 0x6E0(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* PushToTalkCommand_IKS;  // 0x6E8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* PushToTalkLocal_IKS;  // 0x6F0(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* PushToTalkSquad_IKS;  // 0x6F8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* RadialMenu_IKS;  // 0x700(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Reload_IKS;  // 0x708(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* ResolutionScaleOption;  // 0x710(0x8)
	struct UWBP_TextButton_C* RestoreDefaultsBtn;  // 0x718(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* SayAll_IKS;  // 0x720(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* SaySquad_IKS;  // 0x728(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* SayTeam_IKS;  // 0x730(0x8)
	struct UVerticalBox* ScalabilityAudioVBox;  // 0x738(0x8)
	struct UVerticalBox* ScalabilityVideoVBox;  // 0x740(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Scoreboard_IKS;  // 0x748(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* ScreenResolutionOption;  // 0x750(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* SFXVolOption;  // 0x758(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* ShadingOption;  // 0x760(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* ShadowOption;  // 0x768(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* SmoothFrameRateOption;  // 0x770(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* SmoothMouseOption;  // 0x778(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Sprint_IKS;  // 0x780(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* SprintToggle_IKS;  // 0x788(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* SwitchFireMode_IKS;  // 0x790(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* SwitchFireModeOnReselectOption;  // 0x798(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* TextureOption;  // 0x7A0(0x8)
	struct UTextBlock* UnsavedChangesText;  // 0x7A8(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Use_IKS;  // 0x7B0(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* Vault_IKS;  // 0x7B8(0x8)
	struct UWBP_OptionsMenuItem_Checkbox_C* VerticalSyncOption;  // 0x7C0(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* VFXOption;  // 0x7C8(0x8)
	struct UWBP_TextButton_C* VideoBtn;  // 0x7D0(0x8)
	struct UScrollBox* VideoSBox;  // 0x7D8(0x8)
	struct UWBP_OptionsMenuItem_Arrow_C* ViewDistanceOption;  // 0x7E0(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* VOIPVolOption;  // 0x7E8(0x8)
	struct UVerticalBox* VolumeAudioVBox;  // 0x7F0(0x8)
	struct UWBP_OptionsMenuItem_Slider_C* VOVolOption;  // 0x7F8(0x8)
	struct UVerticalBox* WeaponKeyRemappingVBox;  // 0x800(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot0_IKS;  // 0x808(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot1_IKS;  // 0x810(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot2_IKS;  // 0x818(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot3_IKS;  // 0x820(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot4_IKS;  // 0x828(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot5_IKS;  // 0x830(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot6_IKS;  // 0x838(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot7_IKS;  // 0x840(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot8_IKS;  // 0x848(0x8)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* WeaponSlot9_IKS;  // 0x850(0x8)
	int32_t MenuIndex;  // 0x858(0x4)
	char pad_2140[4];  // 0x85C(0x4)
	struct UTBGameUserSettings* GameUserSettings;  // 0x860(0x8)
	char pad_2152_1 : 7;  // 0x868(0x1)
	bool bDirty : 1;  // 0x868(0x1)
	char pad_2153[7];  // 0x869(0x7)
	struct TArray<struct FFSubMenuOption> SubMenuOptions;  // 0x870(0x10)
	char pad_2176_1 : 7;  // 0x880(0x1)
	bool bBalanceVolumeLevels : 1;  // 0x880(0x1)
	char pad_2177[7];  // 0x881(0x7)
	struct UWBP_OptionsMenuItem_InputKeySelector_C* CurrentIKS;  // 0x888(0x8)
	float CurrentScrollOffset;  // 0x890(0x4)
	char pad_2196[4];  // 0x894(0x4)
	struct UWBP_MouseInputCatcherOverlay_C* MouseInputCatcher;  // 0x898(0x8)

	void GetDesiredVerticalAlignment(char EVerticalAlignment& Alignment); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetDesiredVerticalAlignment
	void GetDesiredHorizontalAlignment(char EHorizontalAlignment& Alignment); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetDesiredHorizontalAlignment
	void HasSubMenus(bool& bSubMenuOptions); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.HasSubMenus
	void GetSubMenuOptions(struct TArray<struct FFSubMenuOption>& SubOptions); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetSubMenuOptions
	void StartSelectingKey(struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.StartSelectingKey
	void CatchMouseWheelInput(float NewScrollOffset); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.CatchMouseWheelInput
	void SetCurrentIKS(struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetCurrentIKS
	void RefreshControlsOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshControlsOptionUI
	void Update Key Binding(struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS, struct FInputChord NewInputChord); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.Update Key Binding
	void PopulateAllKeyBindings(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.PopulateAllKeyBindings
	void SetupControlsOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetupControlsOptionUI
	void GetMaxSecondaryVolumeLevel(float& MaxVolLvl); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetMaxSecondaryVolumeLevel
	void GetBalancedSecondaryVolumeLevel(float VolumeLevelToBalance, bool bMatchMasterVolLvl, float& VolLevelBalanced); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.GetBalancedSecondaryVolumeLevel
	void BalanceSecondaryVolumeLevels(bool bMatchMasterVolLvl, bool bRefreshAudioUI); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BalanceSecondaryVolumeLevels
	void BalanceMasterVolumeLevel(bool bRefreshAudioUI); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BalanceMasterVolumeLevel
	void BalanceVolumeLevels(bool bRefreshAudioUI); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BalanceVolumeLevels
	void RefreshAudioOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshAudioOptionUI
	void UpdateScreenResolutionState(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.UpdateScreenResolutionState
	void SetResolutionScaleBounds(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetResolutionScaleBounds
	void UpdateUnsavedStatus(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.UpdateUnsavedStatus
	void RegisterClickEventsForContainer(struct UPanelWidget* Container); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RegisterClickEventsForContainer
	void SetupOptionSelectionEvents(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetupOptionSelectionEvents
	void RefreshQualityOptions(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshQualityOptions
	void RefreshOverallQualityOption(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshOverallQualityOption
	void SetScreenResolutionSetting(struct FString ScreenResolution); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetScreenResolutionSetting
	void SetupVideoOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetupVideoOptionUI
	void PopulateScreenResolutionOption(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.PopulateScreenResolutionOption
	void RefreshVideoOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshVideoOptionUI
	void IsDirty(bool& bDirty); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.IsDirty
	void RefreshGameplayOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshGameplayOptionUI
	void SetupGameplayOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetupGameplayOptionUI
	void SetupAllOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetupAllOptionUI
	void RefreshAllOptionUI(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.RefreshAllOptionUI
	void OnNavOptionSelected(struct UWBP_TextButton_C* NavBtn); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnNavOptionSelected
	void SetMenuIndex(int32_t NewIndex); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetMenuIndex
	void Destruct(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.Destruct
	void BndEvt__GameplayBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__GameplayBtn_K2Node_ComponentBoundEvent_0_ButtonClicked__DelegateSignature
	void BndEvt__VideoBtn_K2Node_ComponentBoundEvent_1_ButtonClicked__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__VideoBtn_K2Node_ComponentBoundEvent_1_ButtonClicked__DelegateSignature
	void BndEvt__AudioBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AudioBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature
	void BndEvt__ControlsBtn_K2Node_ComponentBoundEvent_3_ButtonClicked__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ControlsBtn_K2Node_ComponentBoundEvent_3_ButtonClicked__DelegateSignature
	void OnOptionsUINeedsUpdate(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnOptionsUINeedsUpdate
	void Construct(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.Construct
	void BndEvt__DisplayModeOption_K2Node_ComponentBoundEvent_6_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DisplayModeOption_K2Node_ComponentBoundEvent_6_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__ScreenResolutionOption_K2Node_ComponentBoundEvent_7_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ScreenResolutionOption_K2Node_ComponentBoundEvent_7_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__RestoreDefaultsBtn_K2Node_ComponentBoundEvent_8_ButtonClicked__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__RestoreDefaultsBtn_K2Node_ComponentBoundEvent_8_ButtonClicked__DelegateSignature
	void BndEvt__ApplyBtn_K2Node_ComponentBoundEvent_9_ButtonClicked__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ApplyBtn_K2Node_ComponentBoundEvent_9_ButtonClicked__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.PreConstruct
	void BndEvt__VerticalSyncOption_K2Node_ComponentBoundEvent_10_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__VerticalSyncOption_K2Node_ComponentBoundEvent_10_CheckStateChangedBool__DelegateSignature
	void BndEvt__OverallQualityOption_K2Node_ComponentBoundEvent_11_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__OverallQualityOption_K2Node_ComponentBoundEvent_11_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__ViewDistanceOption_K2Node_ComponentBoundEvent_12_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ViewDistanceOption_K2Node_ComponentBoundEvent_12_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__AAOption_K2Node_ComponentBoundEvent_13_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AAOption_K2Node_ComponentBoundEvent_13_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__PPOption_K2Node_ComponentBoundEvent_14_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PPOption_K2Node_ComponentBoundEvent_14_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__ShadowOption_K2Node_ComponentBoundEvent_15_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ShadowOption_K2Node_ComponentBoundEvent_15_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__TextureOption_K2Node_ComponentBoundEvent_16_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__TextureOption_K2Node_ComponentBoundEvent_16_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__EffectsOption_K2Node_ComponentBoundEvent_17_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__EffectsOption_K2Node_ComponentBoundEvent_17_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__FoliageOption_K2Node_ComponentBoundEvent_18_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__FoliageOption_K2Node_ComponentBoundEvent_18_OnSelectionChangedByUser__DelegateSignature
	void OnArrowMenuSelectionChangedUser(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnArrowMenuSelectionChangedUser
	void OnCheckboxMenuCheckStateChanged(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnCheckboxMenuCheckStateChanged
	void SetActiveSubMenuByIndex(int32_t SubMenuIndex); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.SetActiveSubMenuByIndex
	void OnSliderMenuValueChanged(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnSliderMenuValueChanged
	void OnToggleMenuToggleStateChanged(bool bToggledOn); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnToggleMenuToggleStateChanged
	void BndEvt__ResolutionScaleOption_K2Node_ComponentBoundEvent_4_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ResolutionScaleOption_K2Node_ComponentBoundEvent_4_ValueChanged__DelegateSignature
	void BndEvt__SmoothFrameRateOption_K2Node_ComponentBoundEvent_20_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SmoothFrameRateOption_K2Node_ComponentBoundEvent_20_CheckStateChangedBool__DelegateSignature
	void BndEvt__FrameRateLimitOption_K2Node_ComponentBoundEvent_19_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__FrameRateLimitOption_K2Node_ComponentBoundEvent_19_ValueChanged__DelegateSignature
	void BndEvt__DiscardChangesBtn_K2Node_ComponentBoundEvent_21_ButtonClicked__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DiscardChangesBtn_K2Node_ComponentBoundEvent_21_ButtonClicked__DelegateSignature
	void BndEvt__GlobalMouseSensitivityOption_K2Node_ComponentBoundEvent_22_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__GlobalMouseSensitivityOption_K2Node_ComponentBoundEvent_22_ValueChanged__DelegateSignature
	void BndEvt__InvertMousePitchOption_K2Node_ComponentBoundEvent_23_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__InvertMousePitchOption_K2Node_ComponentBoundEvent_23_CheckStateChangedBool__DelegateSignature
	void BndEvt__SmoothMouseOption_K2Node_ComponentBoundEvent_24_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SmoothMouseOption_K2Node_ComponentBoundEvent_24_CheckStateChangedBool__DelegateSignature
	void BndEvt__DisplayGammaOption_K2Node_ComponentBoundEvent_25_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DisplayGammaOption_K2Node_ComponentBoundEvent_25_ValueChanged__DelegateSignature
	void BndEvt__FOVOption_K2Node_ComponentBoundEvent_26_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__FOVOption_K2Node_ComponentBoundEvent_26_ValueChanged__DelegateSignature
	void BndEvt__AudioQualityOption_K2Node_ComponentBoundEvent_27_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AudioQualityOption_K2Node_ComponentBoundEvent_27_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__HeadphoneModeOption_K2Node_ComponentBoundEvent_28_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__HeadphoneModeOption_K2Node_ComponentBoundEvent_28_CheckStateChangedBool__DelegateSignature
	void BndEvt__MasterVolOption_K2Node_ComponentBoundEvent_5_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MasterVolOption_K2Node_ComponentBoundEvent_5_ValueChanged__DelegateSignature
	void BndEvt__SFXVolOption_K2Node_ComponentBoundEvent_29_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SFXVolOption_K2Node_ComponentBoundEvent_29_ValueChanged__DelegateSignature
	void BndEvt__MusicVolOption_K2Node_ComponentBoundEvent_30_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MusicVolOption_K2Node_ComponentBoundEvent_30_ValueChanged__DelegateSignature
	void BndEvt__VOVolOption_K2Node_ComponentBoundEvent_31_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__VOVolOption_K2Node_ComponentBoundEvent_31_ValueChanged__DelegateSignature
	void BndEvt__VOIPVolOption_K2Node_ComponentBoundEvent_32_ValueChanged__DelegateSignature(float Value); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__VOIPVolOption_K2Node_ComponentBoundEvent_32_ValueChanged__DelegateSignature
	void BndEvt__ShadingOption_K2Node_ComponentBoundEvent_33_OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__ShadingOption_K2Node_ComponentBoundEvent_33_OnSelectionChangedByUser__DelegateSignature
	void BndEvt__AllowSoundInBgOption_K2Node_ComponentBoundEvent_34_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AllowSoundInBgOption_K2Node_ComponentBoundEvent_34_CheckStateChangedBool__DelegateSignature
	void BndEvt__MotionBlurOption_K2Node_ComponentBoundEvent_35_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MotionBlurOption_K2Node_ComponentBoundEvent_35_CheckStateChangedBool__DelegateSignature
	void BndEvt__MoveForward_IKS_K2Node_ComponentBoundEvent_36_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveForward_IKS_K2Node_ComponentBoundEvent_36_OnKeySelected__DelegateSignature
	void BndEvt__MoveBackward_IKS_K2Node_ComponentBoundEvent_37_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveBackward_IKS_K2Node_ComponentBoundEvent_37_OnKeySelected__DelegateSignature
	void BndEvt__MoveLeft_IKS_K2Node_ComponentBoundEvent_38_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveLeft_IKS_K2Node_ComponentBoundEvent_38_OnKeySelected__DelegateSignature
	void BndEvt__MoveRight_IKS_K2Node_ComponentBoundEvent_39_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveRight_IKS_K2Node_ComponentBoundEvent_39_OnKeySelected__DelegateSignature
	void BndEvt__Sprint_IKS_K2Node_ComponentBoundEvent_40_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Sprint_IKS_K2Node_ComponentBoundEvent_40_OnKeySelected__DelegateSignature
	void BndEvt__Crouch_IKS_K2Node_ComponentBoundEvent_41_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Crouch_IKS_K2Node_ComponentBoundEvent_41_OnKeySelected__DelegateSignature
	void BndEvt__Jump_IKS_K2Node_ComponentBoundEvent_42_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Jump_IKS_K2Node_ComponentBoundEvent_42_OnKeySelected__DelegateSignature
	void BndEvt__Fire_IKS_K2Node_ComponentBoundEvent_43_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Fire_IKS_K2Node_ComponentBoundEvent_43_OnKeySelected__DelegateSignature
	void BndEvt__Reload_IKS_K2Node_ComponentBoundEvent_44_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Reload_IKS_K2Node_ComponentBoundEvent_44_OnKeySelected__DelegateSignature
	void BndEvt__AimDownSights_IKS_K2Node_ComponentBoundEvent_45_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AimDownSights_IKS_K2Node_ComponentBoundEvent_45_OnKeySelected__DelegateSignature
	void BndEvt__NextWeapon_IKS_K2Node_ComponentBoundEvent_46_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__NextWeapon_IKS_K2Node_ComponentBoundEvent_46_OnKeySelected__DelegateSignature
	void BndEvt__PreviousWeapon_IKS_K2Node_ComponentBoundEvent_47_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PreviousWeapon_IKS_K2Node_ComponentBoundEvent_47_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot1_IKS_K2Node_ComponentBoundEvent_48_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot1_IKS_K2Node_ComponentBoundEvent_48_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot2_IKS_K2Node_ComponentBoundEvent_49_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot2_IKS_K2Node_ComponentBoundEvent_49_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot3_IKS_K2Node_ComponentBoundEvent_50_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot3_IKS_K2Node_ComponentBoundEvent_50_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot4_IKS_K2Node_ComponentBoundEvent_51_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot4_IKS_K2Node_ComponentBoundEvent_51_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot5_IKS_K2Node_ComponentBoundEvent_52_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot5_IKS_K2Node_ComponentBoundEvent_52_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot6_IKS_K2Node_ComponentBoundEvent_53_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot6_IKS_K2Node_ComponentBoundEvent_53_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot7_IKS_K2Node_ComponentBoundEvent_54_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot7_IKS_K2Node_ComponentBoundEvent_54_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot8_IKS_K2Node_ComponentBoundEvent_55_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot8_IKS_K2Node_ComponentBoundEvent_55_OnKeySelected__DelegateSignature
	void BndEvt__PushToTalk_IKS_K2Node_ComponentBoundEvent_56_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalk_IKS_K2Node_ComponentBoundEvent_56_OnKeySelected__DelegateSignature
	void BndEvt__SayAll_IKS_K2Node_ComponentBoundEvent_57_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SayAll_IKS_K2Node_ComponentBoundEvent_57_OnKeySelected__DelegateSignature
	void BndEvt__SayTeam_IKS_K2Node_ComponentBoundEvent_58_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SayTeam_IKS_K2Node_ComponentBoundEvent_58_OnKeySelected__DelegateSignature
	void BndEvt__Use_IKS_K2Node_ComponentBoundEvent_59_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Use_IKS_K2Node_ComponentBoundEvent_59_OnKeySelected__DelegateSignature
	void BndEvt__Scoreboard_IKS_K2Node_ComponentBoundEvent_60_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Scoreboard_IKS_K2Node_ComponentBoundEvent_60_OnKeySelected__DelegateSignature
	void BndEvt__DeployMenu_IKS_K2Node_ComponentBoundEvent_61_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DeployMenu_IKS_K2Node_ComponentBoundEvent_61_OnKeySelected__DelegateSignature
	void BndEvt__CameraToggle_IKS_K2Node_ComponentBoundEvent_62_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CameraToggle_IKS_K2Node_ComponentBoundEvent_62_OnKeySelected__DelegateSignature
	void OnIKSMenuKeySelected(struct FInputChord Key Selected); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.OnIKSMenuKeySelected
	void BndEvt__MoveForward_IKS_K2Node_ComponentBoundEvent_63_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveForward_IKS_K2Node_ComponentBoundEvent_63_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__MoveLeft_IKS_K2Node_ComponentBoundEvent_65_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveLeft_IKS_K2Node_ComponentBoundEvent_65_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__MoveRight_IKS_K2Node_ComponentBoundEvent_66_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveRight_IKS_K2Node_ComponentBoundEvent_66_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Sprint_IKS_K2Node_ComponentBoundEvent_67_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Sprint_IKS_K2Node_ComponentBoundEvent_67_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Crouch_IKS_K2Node_ComponentBoundEvent_68_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Crouch_IKS_K2Node_ComponentBoundEvent_68_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Jump_IKS_K2Node_ComponentBoundEvent_69_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Jump_IKS_K2Node_ComponentBoundEvent_69_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Fire_IKS_K2Node_ComponentBoundEvent_70_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Fire_IKS_K2Node_ComponentBoundEvent_70_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Reload_IKS_K2Node_ComponentBoundEvent_71_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Reload_IKS_K2Node_ComponentBoundEvent_71_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__AimDownSights_IKS_K2Node_ComponentBoundEvent_72_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AimDownSights_IKS_K2Node_ComponentBoundEvent_72_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__NextWeapon_IKS_K2Node_ComponentBoundEvent_73_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__NextWeapon_IKS_K2Node_ComponentBoundEvent_73_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__PreviousWeapon_IKS_K2Node_ComponentBoundEvent_74_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PreviousWeapon_IKS_K2Node_ComponentBoundEvent_74_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot1_IKS_K2Node_ComponentBoundEvent_75_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot1_IKS_K2Node_ComponentBoundEvent_75_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot2_IKS_K2Node_ComponentBoundEvent_76_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot2_IKS_K2Node_ComponentBoundEvent_76_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot3_IKS_K2Node_ComponentBoundEvent_77_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot3_IKS_K2Node_ComponentBoundEvent_77_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot4_IKS_K2Node_ComponentBoundEvent_78_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot4_IKS_K2Node_ComponentBoundEvent_78_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot5_IKS_K2Node_ComponentBoundEvent_79_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot5_IKS_K2Node_ComponentBoundEvent_79_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot6_IKS_K2Node_ComponentBoundEvent_80_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot6_IKS_K2Node_ComponentBoundEvent_80_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot7_IKS_K2Node_ComponentBoundEvent_81_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot7_IKS_K2Node_ComponentBoundEvent_81_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot8_IKS_K2Node_ComponentBoundEvent_82_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot8_IKS_K2Node_ComponentBoundEvent_82_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__PushToTalk_IKS_K2Node_ComponentBoundEvent_83_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalk_IKS_K2Node_ComponentBoundEvent_83_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__SayAll_IKS_K2Node_ComponentBoundEvent_84_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SayAll_IKS_K2Node_ComponentBoundEvent_84_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__SayTeam_IKS_K2Node_ComponentBoundEvent_85_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SayTeam_IKS_K2Node_ComponentBoundEvent_85_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Use_IKS_K2Node_ComponentBoundEvent_86_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Use_IKS_K2Node_ComponentBoundEvent_86_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Scoreboard_IKS_K2Node_ComponentBoundEvent_87_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Scoreboard_IKS_K2Node_ComponentBoundEvent_87_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__DeployMenu_IKS_K2Node_ComponentBoundEvent_88_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__DeployMenu_IKS_K2Node_ComponentBoundEvent_88_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__CameraToggle_IKS_K2Node_ComponentBoundEvent_89_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CameraToggle_IKS_K2Node_ComponentBoundEvent_89_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__KeyRemappingSBox_K2Node_ComponentBoundEvent_90_OnUserScrolledEvent__DelegateSignature(float CurrentOffset); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__KeyRemappingSBox_K2Node_ComponentBoundEvent_90_OnUserScrolledEvent__DelegateSignature
	void BndEvt__MoveBackward_IKS_K2Node_ComponentBoundEvent_64_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__MoveBackward_IKS_K2Node_ComponentBoundEvent_64_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot0_IKS_K2Node_ComponentBoundEvent_91_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot0_IKS_K2Node_ComponentBoundEvent_91_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot0_IKS_K2Node_ComponentBoundEvent_92_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot0_IKS_K2Node_ComponentBoundEvent_92_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__WeaponSlot9_IKS_K2Node_ComponentBoundEvent_93_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot9_IKS_K2Node_ComponentBoundEvent_93_OnKeySelected__DelegateSignature
	void BndEvt__WeaponSlot9_IKS_K2Node_ComponentBoundEvent_94_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__WeaponSlot9_IKS_K2Node_ComponentBoundEvent_94_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__LeanLeft_IKS_K2Node_ComponentBoundEvent_95_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanLeft_IKS_K2Node_ComponentBoundEvent_95_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__LeanRight_IKS_K2Node_ComponentBoundEvent_96_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanRight_IKS_K2Node_ComponentBoundEvent_96_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__LeanLeft_IKS_K2Node_ComponentBoundEvent_97_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanLeft_IKS_K2Node_ComponentBoundEvent_97_OnKeySelected__DelegateSignature
	void BndEvt__LeanRight_IKS_K2Node_ComponentBoundEvent_98_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanRight_IKS_K2Node_ComponentBoundEvent_98_OnKeySelected__DelegateSignature
	void BndEvt__Prone_IKS_K2Node_ComponentBoundEvent_99_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Prone_IKS_K2Node_ComponentBoundEvent_99_OnKeySelected__DelegateSignature
	void BndEvt__Prone_IKS_K2Node_ComponentBoundEvent_100_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Prone_IKS_K2Node_ComponentBoundEvent_100_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__PushToTalkSquad_IKS_K2Node_ComponentBoundEvent_101_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalkSquad_IKS_K2Node_ComponentBoundEvent_101_OnKeySelected__DelegateSignature
	void BndEvt__PushToTalkSquad_IKS_K2Node_ComponentBoundEvent_102_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalkSquad_IKS_K2Node_ComponentBoundEvent_102_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__PushToTalkCommand_IKS_K2Node_ComponentBoundEvent_103_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalkCommand_IKS_K2Node_ComponentBoundEvent_103_OnKeySelected__DelegateSignature
	void BndEvt__PushToTalkCommand_IKS_K2Node_ComponentBoundEvent_104_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PushToTalkCommand_IKS_K2Node_ComponentBoundEvent_104_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__SaySquad_IKS_K2Node_ComponentBoundEvent_105_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SaySquad_IKS_K2Node_ComponentBoundEvent_105_OnKeySelected__DelegateSignature
	void BndEvt__SaySquad_IKS_K2Node_ComponentBoundEvent_106_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SaySquad_IKS_K2Node_ComponentBoundEvent_106_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__RadialMenu_IKS_K2Node_ComponentBoundEvent_107_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__RadialMenu_IKS_K2Node_ComponentBoundEvent_107_OnKeySelected__DelegateSignature
	void BndEvt__RadialMenu_IKS_K2Node_ComponentBoundEvent_108_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__RadialMenu_IKS_K2Node_ComponentBoundEvent_108_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__JumpVault_IKS_K2Node_ComponentBoundEvent_109_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__JumpVault_IKS_K2Node_ComponentBoundEvent_109_OnKeySelected__DelegateSignature
	void BndEvt__JumpVault_IKS_K2Node_ComponentBoundEvent_110_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__JumpVault_IKS_K2Node_ComponentBoundEvent_110_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__Vault_IKS_K2Node_ComponentBoundEvent_111_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Vault_IKS_K2Node_ComponentBoundEvent_111_OnKeySelected__DelegateSignature
	void BndEvt__Vault_IKS_K2Node_ComponentBoundEvent_112_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Vault_IKS_K2Node_ComponentBoundEvent_112_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__CrouchToggle_IKS_K2Node_ComponentBoundEvent_113_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CrouchToggle_IKS_K2Node_ComponentBoundEvent_113_OnKeySelected__DelegateSignature
	void BndEvt__CrouchToggle_IKS_K2Node_ComponentBoundEvent_114_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CrouchToggle_IKS_K2Node_ComponentBoundEvent_114_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__LeanLeftToggle_IKS_K2Node_ComponentBoundEvent_115_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanLeftToggle_IKS_K2Node_ComponentBoundEvent_115_OnKeySelected__DelegateSignature
	void BndEvt__LeanLeftToggle_IKS_K2Node_ComponentBoundEvent_116_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanLeftToggle_IKS_K2Node_ComponentBoundEvent_116_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__LeanRightToggle_IKS_K2Node_ComponentBoundEvent_117_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanRightToggle_IKS_K2Node_ComponentBoundEvent_117_OnKeySelected__DelegateSignature
	void BndEvt__LeanRightToggle_IKS_K2Node_ComponentBoundEvent_118_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__LeanRightToggle_IKS_K2Node_ComponentBoundEvent_118_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__AimDownSightsToggle_IKS_K2Node_ComponentBoundEvent_119_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AimDownSightsToggle_IKS_K2Node_ComponentBoundEvent_119_OnKeySelected__DelegateSignature
	void BndEvt__AimDownSightsToggle_IKS_K2Node_ComponentBoundEvent_120_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__AimDownSightsToggle_IKS_K2Node_ComponentBoundEvent_120_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__SprintToggle_IKS_K2Node_ComponentBoundEvent_121_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SprintToggle_IKS_K2Node_ComponentBoundEvent_121_OnKeySelected__DelegateSignature
	void BndEvt__SprintToggle_IKS_K2Node_ComponentBoundEvent_122_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SprintToggle_IKS_K2Node_ComponentBoundEvent_122_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__SwitchFireMode_IKS_K2Node_ComponentBoundEvent_123_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SwitchFireMode_IKS_K2Node_ComponentBoundEvent_123_OnKeySelected__DelegateSignature
	void BndEvt__SwitchFireMode_IKS_K2Node_ComponentBoundEvent_124_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SwitchFireMode_IKS_K2Node_ComponentBoundEvent_124_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__PointAimToggle_IKS_K2Node_ComponentBoundEvent_125_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PointAimToggle_IKS_K2Node_ComponentBoundEvent_125_OnKeySelected__DelegateSignature
	void BndEvt__PointAimToggle_IKS_K2Node_ComponentBoundEvent_126_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__PointAimToggle_IKS_K2Node_ComponentBoundEvent_126_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__CycleWeaponSights_IKS_K2Node_ComponentBoundEvent_127_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CycleWeaponSights_IKS_K2Node_ComponentBoundEvent_127_OnKeySelected__DelegateSignature
	void BndEvt__CycleWeaponSights_IKS_K2Node_ComponentBoundEvent_128_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__CycleWeaponSights_IKS_K2Node_ComponentBoundEvent_128_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__SwitchFireModeOnReselectOption_K2Node_ComponentBoundEvent_129_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__SwitchFireModeOnReselectOption_K2Node_ComponentBoundEvent_129_CheckStateChangedBool__DelegateSignature
	void BndEvt__Console_IKS_K2Node_ComponentBoundEvent_130_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Console_IKS_K2Node_ComponentBoundEvent_130_OnKeySelected__DelegateSignature
	void BndEvt__Console_IKS_K2Node_ComponentBoundEvent_131_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.BndEvt__Console_IKS_K2Node_ComponentBoundEvent_131_OnIsSelectingKeyChanged__DelegateSignature
	void ExecuteUbergraph_WBP_OptionMenu_Options(int32_t EntryPoint); // Function WBP_OptionMenu_Options.WBP_OptionMenu_Options_C.ExecuteUbergraph_WBP_OptionMenu_Options
}; 



