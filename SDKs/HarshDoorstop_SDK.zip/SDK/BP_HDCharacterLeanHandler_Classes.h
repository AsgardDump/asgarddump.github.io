#pragma once 
#include <BP_HDCharacterLeanHandler_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C
// Size: 0x2B0(Inherited: 0x280) 
struct UBP_HDCharacterLeanHandler_C : public UDFCharacterLeanHandler
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UCameraComponent* CachedFPPCamera;  // 0x288(0x8)
	struct USkeletalMeshComponent* CachedFPPMesh;  // 0x290(0x8)
	float LastLeanRollAmt;  // 0x298(0x4)
	float LastXOffset;  // 0x29C(0x4)
	float LastYOffset;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct USpringArmComponent* CachedFPPSpringArm;  // 0x2A8(0x8)

	void TickRot(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickRot
	void TickYOffset(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickYOffset
	void TickXOffset(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.TickXOffset
	void GetFPPSpringArmComp(struct USpringArmComponent*& FPPSpringArm); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPSpringArmComp
	void GetFPPCameraComp(struct UCameraComponent*& FPPCamera); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPCameraComp
	void GetFPPMeshComp(struct USkeletalMeshComponent*& FPPMesh); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.GetFPPMeshComp
	void ReceiveTick(float DeltaTime); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.ReceiveTick
	void ExecuteUbergraph_BP_HDCharacterLeanHandler(int32_t EntryPoint); // Function BP_HDCharacterLeanHandler.BP_HDCharacterLeanHandler_C.ExecuteUbergraph_BP_HDCharacterLeanHandler
}; 



