#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.ExecuteUbergraph_WBP_HUDElement_VOIPIndicator_OutputListing
// Size: 0x108(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUDElement_VOIPIndicator_OutputListing
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_bIsDesignTime : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_ToUpper_ReturnValue;  // 0x18(0x10)
	struct FSlateColor CallFunc_GetColorForCommChannel_ChannelColor;  // 0x28(0x28)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x50(0x18)
	struct FSlateColor CallFunc_GetColorForCommChannel_ChannelColor_2;  // 0x68(0x28)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x90(0x38)
	float K2Node_Event_InDeltaTime;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct UHDKit* K2Node_CustomEvent_NewLoadout;  // 0xD0(0x8)
	struct UHDKit* CallFunc_GetMostValidLoadoutFromPS_Loadout;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xE4(0x10)
	char pad_244[4];  // 0xF4(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationReverse_ReturnValue;  // 0xF8(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationForward_ReturnValue;  // 0x100(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.PlayerLoadoutChanged
// Size: 0x8(Inherited: 0x0) 
struct FPlayerLoadoutChanged
{
	struct UHDKit* NewLoadout;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.OnVoiceMsgInfoSet
// Size: 0x1(Inherited: 0x1) 
struct FOnVoiceMsgInfoSet : public FOnVoiceMsgInfoSet
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bIsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.GetClassSymbolForLoadout
// Size: 0x1B0(Inherited: 0x0) 
struct FGetClassSymbolForLoadout
{
	struct UHDKit* Loadout;  // 0x0(0x8)
	struct FSlateBrush ClassSymbolToUse;  // 0x8(0x88)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x98(0x88)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_2;  // 0x128(0x88)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.UpdateClassSymbol
// Size: 0x90(Inherited: 0x0) 
struct FUpdateClassSymbol
{
	struct UHDKit* Loadout;  // 0x0(0x8)
	struct FSlateBrush CallFunc_GetClassSymbolForLoadout_ClassSymbolToUse;  // 0x8(0x88)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.GetMostValidLoadoutFromPS
// Size: 0x1B(Inherited: 0x0) 
struct FGetMostValidLoadoutFromPS
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct UHDKit* Loadout;  // 0x8(0x8)
	struct AHDPlayerState* K2Node_DynamicCast_AsHDPlayer_State;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1A(0x1)

}; 
// Function WBP_HUDElement_VOIPIndicator_OutputListing.WBP_HUDElement_VOIPIndicator_OutputListing_C.CheckForClassSymbolUpdates
// Size: 0x12(Inherited: 0x0) 
struct FCheckForClassSymbolUpdates
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UHDKit* CallFunc_GetMostValidLoadoutFromPS_Loadout;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x11(0x1)

}; 
