#pragma once 
#include <TinkerLoadingScreen_Structs.h>
 
 
 
// Class TinkerLoadingScreen.LoadingScreenSettings
// Size: 0xB0(Inherited: 0x38) 
struct ULoadingScreenSettings : public UDeveloperSettings
{
	char bUseStartupScreen : 1;  // 0x38(0x1)
	char pad_56_1 : 7;  // 0x38(0x1)
	char pad_57[8];  // 0x39(0x8)
	struct FLoadingScreenDescription StartupScreen;  // 0x40(0x38)
	struct FLoadingScreenDescription DefaultScreen;  // 0x78(0x38)

}; 



// Class TinkerLoadingScreen.LoadingScreenWidgetInterface
// Size: 0x28(Inherited: 0x28) 
struct ULoadingScreenWidgetInterface : public UInterface
{

	void SetLoadingScreenDescription(struct FLoadingScreenDescription& Description); // Function TinkerLoadingScreen.LoadingScreenWidgetInterface.SetLoadingScreenDescription
	void SetLevelLoadData(struct FLoadScreenLevelData& LevelData); // Function TinkerLoadingScreen.LoadingScreenWidgetInterface.SetLevelLoadData
}; 



