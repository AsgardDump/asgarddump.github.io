#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnConfirmInput__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnConfirmInput__DelegateSignature
{
	struct FText InputText;  // 0x0(0x18)

}; 
// Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnMouseButtonDown
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.ExecuteUbergraph_WBP_DlgBox_ServerPasswordPrompt
// Size: 0x3A(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DlgBox_ServerPasswordPrompt
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FFocusEvent K2Node_Event_InFocusEvent;  // 0x14(0x8)
	char pad_28[4];  // 0x1C(0x4)
	struct FText CallFunc_GetText_ReturnValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x39(0x1)

}; 
// Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnPreviewKeyDown
// Size: 0x200(Inherited: 0x128) 
struct FOnPreviewKeyDown : public FOnPreviewKeyDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FKeyEvent InKeyEvent;  // 0x38(0x38)
	struct FEventReply ReturnValue;  // 0x70(0xB8)
	struct FKey CallFunc_GetKey_ReturnValue;  // 0x128(0x18)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue : 1;  // 0x140(0x1)
	char pad_617_1 : 7;  // 0x269(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_2 : 1;  // 0x141(0x1)
	char pad_618_1 : 7;  // 0x26A(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_3 : 1;  // 0x142(0x1)
	char pad_619_1 : 7;  // 0x26B(0x1)
	bool CallFunc_EqualEqual_KeyKey_ReturnValue_4 : 1;  // 0x143(0x1)
	char pad_620_1 : 7;  // 0x26C(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x144(0x1)
	char pad_621_1 : 7;  // 0x26D(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x145(0x1)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x148(0xB8)

}; 
// Function WBP_DlgBox_ServerPasswordPrompt.WBP_DlgBox_ServerPasswordPrompt_C.OnRemovedFromFocusPath
// Size: 0x8(Inherited: 0x8) 
struct FOnRemovedFromFocusPath : public FOnRemovedFromFocusPath
{
	struct FFocusEvent InFocusEvent;  // 0x0(0x8)

}; 
