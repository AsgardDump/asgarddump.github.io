#pragma once 
#include <WBP_OptionsMenuItem_Checkbox_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C
// Size: 0x298(Inherited: 0x230) 
struct UWBP_OptionsMenuItem_Checkbox_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_Checkbox_C* OptionCBox;  // 0x238(0x8)
	struct UTextBlock* OptionText;  // 0x240(0x8)
	struct FText Text;  // 0x248(0x18)
	struct FMulticastInlineDelegate CheckStateChanged;  // 0x260(0x10)
	struct FMulticastInlineDelegate CheckStateChangedBool;  // 0x270(0x10)
	struct FText TextDescription;  // 0x280(0x18)

	void SetCheckedState(uint8_t  NewCheckedState); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.SetCheckedState
	void SetIsChecked(bool bChecked); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.SetIsChecked
	void IsChecked(bool& bChecked); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.IsChecked
	void GetCheckedState(uint8_t & CheckedState); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.GetCheckedState
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.PreConstruct
	void BndEvt__OptionCBox_K2Node_ComponentBoundEvent_0_CheckStateChanged__DelegateSignature(uint8_t  CheckedState); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.BndEvt__OptionCBox_K2Node_ComponentBoundEvent_0_CheckStateChanged__DelegateSignature
	void BndEvt__OptionCBox_K2Node_ComponentBoundEvent_1_CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.BndEvt__OptionCBox_K2Node_ComponentBoundEvent_1_CheckStateChangedBool__DelegateSignature
	void ExecuteUbergraph_WBP_OptionsMenuItem_Checkbox(int32_t EntryPoint); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.ExecuteUbergraph_WBP_OptionsMenuItem_Checkbox
	void CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.CheckStateChangedBool__DelegateSignature
	void CheckStateChanged__DelegateSignature(uint8_t  CheckedState); // Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.CheckStateChanged__DelegateSignature
}; 



