#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C.ExecuteUbergraph_WBP_OptionMenu_HDCredits
// Size: 0x40(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionMenu_HDCredits
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x4(0x38)
	float K2Node_Event_InDeltaTime;  // 0x3C(0x4)

}; 
// Function WBP_OptionMenu_HDCredits.WBP_OptionMenu_HDCredits_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
