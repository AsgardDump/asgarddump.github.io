#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AppendTravelURL
// Size: 0x30(Inherited: 0x0) 
struct FAppendTravelURL
{
	struct FString OptionsToAdd;  // 0x0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x10(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x20(0x10)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__GMList_K2Node_ComponentBoundEvent_2_OnListItemSelectionChangedDynamic__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FBndEvt__GMList_K2Node_ComponentBoundEvent_2_OnListItemSelectionChangedDynamic__DelegateSignature
{
	struct UObject* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsSelected : 1;  // 0x8(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ExecuteUbergraph_WBP_OptionMenu_CreateGame
// Size: 0x1A8(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionMenu_CreateGame
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UObject* K2Node_ComponentBoundEvent_Item_4;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_ComponentBoundEvent_bIsSelected_2 : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UObject* CallFunc_BP_GetSelectedItem_ReturnValue;  // 0x28(0x8)
	struct UBP_GMListItemData_C* K2Node_DynamicCast_AsBP_GMList_Item_Data;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UBP_MapListItemData_C* K2Node_DynamicCast_AsBP_Map_List_Item_Data;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)
	struct UObject* K2Node_ComponentBoundEvent_Item_3;  // 0x50(0x8)
	struct UUserWidget* K2Node_ComponentBoundEvent_Widget_2;  // 0x58(0x8)
	int32_t CallFunc_BP_GetNumItemsSelected_ReturnValue;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	struct UObject* K2Node_ComponentBoundEvent_Item_2;  // 0x68(0x8)
	struct UUserWidget* K2Node_ComponentBoundEvent_Widget;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_BP_GetNumItemsSelected_ReturnValue_2;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UObject* K2Node_ComponentBoundEvent_Item;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_ComponentBoundEvent_bIsSelected : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct UBP_MapListItemData_C* K2Node_DynamicCast_AsBP_Map_List_Item_Data_2;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xA2(0x1)
	char pad_163[1];  // 0xA3(0x1)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xA4(0x4)
	struct UObject* CallFunc_BP_GetSelectedItem_ReturnValue_2;  // 0xA8(0x8)
	struct UBP_GMListItemData_C* K2Node_DynamicCast_AsBP_GMList_Item_Data_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0xBA(0x1)
	char pad_187[1];  // 0xBB(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xBC(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0xC0(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0xD0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)
	struct TScriptInterface<IBPI_GameModifierSettings_C> K2Node_DynamicCast_AsBPI_Game_Modifier_Settings;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0xF1(0x1)
	char pad_242[6];  // 0xF2(0x6)
	struct TArray<struct FPrimaryAssetId> CallFunc_GetPrimaryAssetIdList_OutPrimaryAssetIdList;  // 0xF8(0x10)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x108(0x10)
	struct TArray<struct FPrimaryAssetId> CallFunc_SplitLoadedPrimaryAssetIds_UnloadedAssetIds;  // 0x118(0x10)
	struct TArray<struct UObject*> CallFunc_SplitLoadedPrimaryAssetIds_LoadedAssets;  // 0x128(0x10)
	struct TArray<struct UObject*> Temp_object_Variable;  // 0x138(0x10)
	struct UObject* CallFunc_Array_Get_Item_2;  // 0x148(0x8)
	struct UHDGameModeDefinition* K2Node_DynamicCast_AsHDGame_Mode_Definition;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x15C(0x4)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_ShouldAddGMListing_bAddListing : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x161(0x1)
	char pad_354[6];  // 0x162(0x6)
	struct UAsyncActionLoadPrimaryAssetList* CallFunc_AsyncLoadPrimaryAssetList_ReturnValue;  // 0x168(0x8)
	struct TArray<struct UObject*> K2Node_CustomEvent_Loaded;  // 0x170(0x10)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x180(0x1)
	char pad_385[3];  // 0x181(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x184(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x188(0x10)
	struct TArray<struct FPrimaryAssetId> CallFunc_GetPrimaryAssetIdList_OutPrimaryAssetIdList_2;  // 0x198(0x10)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__MapList_K2Node_ComponentBoundEvent_1_OnListItemSelectionChangedDynamic__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FBndEvt__MapList_K2Node_ComponentBoundEvent_1_OnListItemSelectionChangedDynamic__DelegateSignature
{
	struct UObject* Item;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsSelected : 1;  // 0x8(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ShouldAddMapListing
// Size: 0x16A(Inherited: 0x0) 
struct FShouldAddMapListing
{
	struct FPrimaryAssetId MapAssetId;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bAddListing : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bLegacyMap : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct FString ContentRootName;  // 0x18(0x10)
	struct FString MapName;  // 0x28(0x10)
	struct TArray<struct TSoftClassPtr<UObject>> GameModes;  // 0x38(0x10)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_DoesMapIDSupportGMDefinition_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_GetPackageShortName_bSuccess : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FString CallFunc_GetPackageShortName_ShortName;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_GetContentRootFromPackageName_bSuccess : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FString CallFunc_GetContentRootFromPackageName_ContentRootName;  // 0x78(0x10)
	struct TSoftClassPtr<UObject> CallFunc_GetMapAssetDefaultGameMode_OutDefaultGameModeRef;  // 0x88(0x28)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_GetMapAssetDefaultGameMode_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_GetMapAssetVisibleInMapSelectUI_bOutVisibleInMapSelectUI : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool CallFunc_GetMapAssetVisibleInMapSelectUI_ReturnValue : 1;  // 0xB2(0x1)
	char pad_179_1 : 7;  // 0xB3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB3(0x1)
	char pad_180[4];  // 0xB4(0x4)
	struct TSet<struct TSoftClassPtr<UObject>> CallFunc_GetMapAssetSupportedGameModes_OutSupportedGameModes;  // 0xB8(0x50)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_GetMapAssetSupportedGameModes_ReturnValue : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct TArray<struct TSoftClassPtr<UObject>> CallFunc_Set_ToArray_Result;  // 0x110(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x120(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x124(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)
	struct TSoftClassPtr<UObject> CallFunc_Array_Get_Item;  // 0x130(0x28)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_FilterExcludesGMClass_bExcludeGM : 1;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x15C(0x4)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x160(0x1)
	char pad_353[3];  // 0x161(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x164(0x4)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_DoesModPluginUseLegacyMapScanning_ReturnValue : 1;  // 0x168(0x1)
	char pad_361_1 : 7;  // 0x169(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x169(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchMapsFromRegistry
// Size: 0x2B8(Inherited: 0x0) 
struct FFetchMapsFromRegistry
{
	struct TArray<struct FFMapInfo> MapsFound;  // 0x0(0x10)
	struct FFMapInfo NewMap;  // 0x10(0x48)
	struct TArray<struct FFMapInfo> MapInfos;  // 0x58(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x68(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x6C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct TArray<struct FPrimaryAssetId> CallFunc_GetPrimaryAssetIdList_OutPrimaryAssetIdList;  // 0x78(0x10)
	struct FPrimaryAssetId CallFunc_Array_Get_Item;  // 0x88(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct TSoftObjectPtr<UTexture2D> CallFunc_GetMapAssetPreviewBannerImg_OutMapPreviewBannerImgRef;  // 0xA0(0x28)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_GetMapAssetPreviewBannerImg_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC9(0x1)
	char pad_202[6];  // 0xCA(0x6)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_IsValidSoftObjectReference_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct TSoftObjectPtr<UObject> CallFunc_GetSoftObjectReferenceFromPrimaryAssetId_ReturnValue;  // 0xF0(0x28)
	struct FText CallFunc_GetMapAssetNameForDisplay_ReturnValue;  // 0x118(0x18)
	struct FString CallFunc_Conv_SoftObjectReferenceToString_ReturnValue;  // 0x130(0x10)
	struct FString CallFunc_GetPluginDisplayNameFromPath_ModName;  // 0x140(0x10)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x150(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x160(0x18)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_GetPackageShortName_bSuccess : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct FString CallFunc_GetPackageShortName_ShortName;  // 0x180(0x10)
	struct TSoftObjectPtr<UTexture2D> CallFunc_GetMapAssetPreviewImg_OutMapPreviewImgRef;  // 0x190(0x28)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_GetMapAssetPreviewImg_ReturnValue : 1;  // 0x1B8(0x1)
	char pad_441[3];  // 0x1B9(0x3)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x1BC(0x8)
	char pad_452[4];  // 0x1C4(0x4)
	struct FText CallFunc_Map_Find_Value;  // 0x1C8(0x18)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue_2;  // 0x1E8(0x8)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool CallFunc_IsValidSoftObjectReference_ReturnValue_2 : 1;  // 0x1F0(0x1)
	char pad_497[7];  // 0x1F1(0x7)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D_2;  // 0x1F8(0x8)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x200(0x1)
	char pad_513_1 : 7;  // 0x201(0x1)
	bool CallFunc_ShouldAddMapListing_bAddListing : 1;  // 0x201(0x1)
	char pad_514_1 : 7;  // 0x202(0x1)
	bool Temp_bool_Variable : 1;  // 0x202(0x1)
	char pad_515[5];  // 0x203(0x5)
	struct FText K2Node_Select_Default;  // 0x208(0x18)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x220(0x4)
	char pad_548[4];  // 0x224(0x4)
	struct FFMapInfo K2Node_MakeStruct_FMapInfo;  // 0x228(0x48)
	struct FFMapInfo K2Node_SetFieldsInStruct_StructOut;  // 0x270(0x48)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__MapList_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__MapList_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature
{
	struct UObject* Item;  // 0x0(0x8)
	struct UUserWidget* Widget;  // 0x8(0x8)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__GMList_K2Node_ComponentBoundEvent_3_OnListEntryInitializedDynamic__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__GMList_K2Node_ComponentBoundEvent_3_OnListEntryInitializedDynamic__DelegateSignature
{
	struct UObject* Item;  // 0x0(0x8)
	struct UUserWidget* Widget;  // 0x8(0x8)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.Completed_D5E8D9AE41A0DF3C4DEC0184D72FF481
// Size: 0x10(Inherited: 0x0) 
struct FCompleted_D5E8D9AE41A0DF3C4DEC0184D72FF481
{
	struct TArray<struct UObject*> Loaded;  // 0x0(0x10)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchGameModesFromRegistry
// Size: 0xB4(Inherited: 0x0) 
struct FFetchGameModesFromRegistry
{
	struct TArray<struct FFGameModeInfo> GMsFound;  // 0x0(0x10)
	struct TArray<struct FFGameModeInfo> GMInfos;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UHDGameModeDefinition* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FString CallFunc_Conv_SoftClassReferenceToString_ReturnValue;  // 0x40(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x50(0x8)
	struct FText CallFunc_GetValidDisplayNameForGMDefinition_DisplayName;  // 0x58(0x18)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x70(0x8)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct FFGameModeInfo K2Node_MakeStruct_FGameModeInfo;  // 0x88(0x28)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xB0(0x4)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ContainsGMByClass
// Size: 0x46(Inherited: 0x0) 
struct FContainsGMByClass
{
	struct TSoftClassPtr<UObject> GMClass;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bContainsGM : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x2C(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x30(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)
	struct UHDGameModeDefinition* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_EqualEqual_SoftClassReference_ReturnValue : 1;  // 0x45(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ShouldAddGMListing
// Size: 0xB(Inherited: 0x0) 
struct FShouldAddGMListing
{
	struct UHDGameModeDefinition* GMDef;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bAddListing : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsValidSoftClassReference_ReturnValue : 1;  // 0xA(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AddMapToList
// Size: 0x58(Inherited: 0x0) 
struct FAddMapToList
{
	struct FFMapInfo MapInfo;  // 0x0(0x48)
	struct UBP_MapListItemData_C* NewMapItem;  // 0x48(0x8)
	struct UBP_MapListItemData_C* CallFunc_CreateMapListItem_MapItem;  // 0x50(0x8)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.RepopulateGameListFromRegistry
// Size: 0x98(Inherited: 0x0) 
struct FRepopulateGameListFromRegistry
{
	struct TArray<struct FFGameModeInfo> GMListSorted;  // 0x0(0x10)
	struct TArray<struct UBP_GMListItemData_C*> GMItemsArr;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct FFGameModeInfo> CallFunc_FetchGameModesFromRegistry_GMsFound;  // 0x30(0x10)
	struct FFGameModeInfo CallFunc_Array_Get_Item;  // 0x40(0x28)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct UBP_GMListItemData_C* CallFunc_CreateGMListItem_GMItem;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool Temp_bool_Variable : 1;  // 0x79(0x1)
	char pad_122[2];  // 0x7A(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct TArray<struct FFGameModeInfo> K2Node_Select_Default;  // 0x88(0x10)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.RepopulateMapListFromRegistry
// Size: 0xE0(Inherited: 0x0) 
struct FRepopulateMapListFromRegistry
{
	struct UBP_GMListItemData_C* GMItemFilter;  // 0x0(0x8)
	struct TArray<struct FFMapInfo> MapListSorted;  // 0x8(0x10)
	struct TArray<struct UBP_MapListItemData_C*> MapItemsArr;  // 0x18(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x30(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UHDGameModeDefinition* CallFunc_FindGMDefinitionByClassName_GMDef;  // 0x48(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FFMapInfo CallFunc_Array_Get_Item;  // 0x58(0x48)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct UBP_MapListItemData_C* CallFunc_CreateMapListItem_MapItem;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool Temp_bool_Variable : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct TArray<struct FFMapInfo> CallFunc_FetchMapsFromRegistry_MapsFound;  // 0xC0(0x10)
	struct TArray<struct FFMapInfo> K2Node_Select_Default;  // 0xD0(0x10)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.CreateGMListItem
// Size: 0x61(Inherited: 0x0) 
struct FCreateGMListItem
{
	struct FFGameModeInfo GMInfo;  // 0x0(0x28)
	struct UBP_GMListItemData_C* GMItem;  // 0x28(0x8)
	struct FFGameModeInfo GMInfoToUse;  // 0x30(0x28)
	struct UBP_GMListItemData_C* CallFunc_SpawnObject_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.CreateMapListItem
// Size: 0x58(Inherited: 0x0) 
struct FCreateMapListItem
{
	struct FFMapInfo MapInfo;  // 0x0(0x48)
	struct UBP_MapListItemData_C* MapItem;  // 0x48(0x8)
	struct UBP_MapListItemData_C* CallFunc_SpawnObject_ReturnValue;  // 0x50(0x8)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.GetActiveModifiers
// Size: 0x71(Inherited: 0x0) 
struct FGetActiveModifiers
{
	struct TArray<struct TScriptInterface<IBPI_GameModifierSettings_C>> ActiveModifiers;  // 0x0(0x10)
	struct TArray<struct TScriptInterface<IBPI_GameModifierSettings_C>> ActiveModifierList;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TScriptInterface<IBPI_GameModifierSettings_C> K2Node_DynamicCast_AsBPI_Game_Modifier_Settings;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsEnabled_bEnabled : 1;  // 0x70(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AppendOptionsFromActiveModifiers
// Size: 0x50(Inherited: 0x0) 
struct FAppendOptionsFromActiveModifiers
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct TScriptInterface<IBPI_GameModifierSettings_C>> CallFunc_GetActiveModifiers_ActiveModifiers;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TScriptInterface<IBPI_GameModifierSettings_C> CallFunc_Array_Get_Item;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString CallFunc_GetTravelURLOptions_Options;  // 0x40(0x10)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.HandleStartGame
// Size: 0x90(Inherited: 0x0) 
struct FHandleStartGame
{
	struct FFMapInfo SelectedMapInfo;  // 0x0(0x48)
	struct FFGameModeInfo SelectedGMInfo;  // 0x48(0x28)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x70(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x80(0x10)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AddGMToList
// Size: 0x38(Inherited: 0x0) 
struct FAddGMToList
{
	struct FFGameModeInfo GMInfo;  // 0x0(0x28)
	struct UBP_GMListItemData_C* NewGMItem;  // 0x28(0x8)
	struct UBP_GMListItemData_C* CallFunc_CreateGMListItem_GMItem;  // 0x30(0x8)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SetMapPreviewImage
// Size: 0x8(Inherited: 0x0) 
struct FSetMapPreviewImage
{
	struct UTexture2D* NewImg;  // 0x0(0x8)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FindGMDefinitionByClassName
// Size: 0x49(Inherited: 0x0) 
struct FFindGMDefinitionByClassName
{
	struct FString ClassName;  // 0x0(0x10)
	struct UHDGameModeDefinition* GMDef;  // 0x10(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	struct UHDGameModeDefinition* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_Conv_SoftClassReferenceToString_ReturnValue;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x48(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.UpdateStartButtonState
// Size: 0xB(Inherited: 0x0) 
struct FUpdateStartButtonState
{
	int32_t CallFunc_BP_GetNumItemsSelected_ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_BP_GetNumItemsSelected_ReturnValue_2;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xA(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SortGMList
// Size: 0x198(Inherited: 0x0) 
struct FSortGMList
{
	struct TArray<struct FFGameModeInfo> GMListToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TMap<struct FName, struct FFGameModeInfo> InfoMap;  // 0x18(0x50)
	struct TArray<struct FAssetDescriptor> GMDescriptors;  // 0x68(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x78(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x7C(0x4)
	struct FFGameModeInfo CallFunc_Array_Get_Item;  // 0x80(0x28)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xA8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xAC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB0(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0xB4(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xB8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xBC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct FAssetDescriptor CallFunc_Array_Get_Item_2;  // 0xD0(0x20)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)
	struct FFGameModeInfo CallFunc_Map_Find_Value;  // 0xF8(0x28)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct TArray<struct FFGameModeInfo> CallFunc_Map_Values_Values;  // 0x128(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x138(0x4)
	char pad_316[4];  // 0x13C(0x4)
	struct FFGameModeInfo CallFunc_Array_Get_Item_3;  // 0x140(0x28)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x168(0x4)
	char pad_364[4];  // 0x16C(0x4)
	struct FAssetDescriptor K2Node_MakeStruct_AssetDescriptor;  // 0x170(0x20)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x194(0x4)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SortMapList
// Size: 0x1FC(Inherited: 0x0) 
struct FSortMapList
{
	struct TArray<struct FFMapInfo> MapListToSort;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bDescending : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TMap<struct FName, struct FFMapInfo> InfoMap;  // 0x18(0x50)
	struct TArray<struct FAssetDescriptor> MapDescriptors;  // 0x68(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x78(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x7C(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x80(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8C(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FFMapInfo CallFunc_Array_Get_Item;  // 0x98(0x48)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct FAssetDescriptor CallFunc_Array_Get_Item_2;  // 0xE8(0x20)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x108(0x4)
	char pad_268[4];  // 0x10C(0x4)
	struct FFMapInfo CallFunc_Map_Find_Value;  // 0x110(0x48)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x15C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x160(0x4)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x164(0x1)
	char pad_357[3];  // 0x165(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x168(0x4)
	char pad_364[4];  // 0x16C(0x4)
	struct TArray<struct FFMapInfo> CallFunc_Map_Values_Values;  // 0x170(0x10)
	struct FFMapInfo CallFunc_Array_Get_Item_3;  // 0x180(0x48)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct FAssetDescriptor K2Node_MakeStruct_AssetDescriptor;  // 0x1D0(0x20)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x1F0(0x4)
	char pad_500_1 : 7;  // 0x1F4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x1F4(0x1)
	char pad_501[3];  // 0x1F5(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x1F8(0x4)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FilterExcludesMapPrefix
// Size: 0x71(Inherited: 0x0) 
struct FFilterExcludesMapPrefix
{
	struct FString MapName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bExcludePrefix : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString CallFunc_GetGameModeForMapName_ReturnValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FSoftClassPath CallFunc_MakeSoftClassPath_ReturnValue;  // 0x30(0x18)
	struct TSoftClassPtr<UObject> CallFunc_Conv_SoftClassPathToSoftClassRef_ReturnValue;  // 0x48(0x28)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_NotEqual_SoftClassReference_ReturnValue : 1;  // 0x70(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FilterExcludesGMClass
// Size: 0x32(Inherited: 0x0) 
struct FFilterExcludesGMClass
{
	struct TSoftClassPtr<UObject> GMClass;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bLegacyAASSupport : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bExcludeGM : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_EqualEqual_SoftClassReference_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_IsValidSoftClassReference_ReturnValue : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool CallFunc_NotEqual_SoftClassReference_ReturnValue : 1;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x31(0x1)

}; 
// Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.GetValidDisplayNameForGMDefinition
// Size: 0x118(Inherited: 0x0) 
struct FGetValidDisplayNameForGMDefinition
{
	struct UHDGameModeDefinition* GMDef;  // 0x0(0x8)
	struct FText DisplayName;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FPrimaryAssetId CallFunc_GetPrimaryAssetIdFromObject_ReturnValue;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_IsValidSoftClassReference_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x38(0x18)
	struct FString CallFunc_Conv_SoftClassReferenceToString_ReturnValue;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_GetPackageShortName_bSuccess : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FString CallFunc_GetPackageShortName_ShortName;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_TextIsEmptyOrWhitespace_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_Len_ReturnValue;  // 0x7C(0x4)
	int32_t CallFunc_FindSubstring_ReturnValue;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x88(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FString CallFunc_Right_ReturnValue;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_EndsWith_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FString CallFunc_LeftChop_ReturnValue;  // 0xB0(0x10)
	struct FString K2Node_Select_Default;  // 0xC0(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xD0(0x18)
	struct FText K2Node_Select_Default_2;  // 0xE8(0x18)
	struct FText K2Node_Select_Default_3;  // 0x100(0x18)

}; 
