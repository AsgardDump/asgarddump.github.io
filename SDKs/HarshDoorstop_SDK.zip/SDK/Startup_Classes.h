#pragma once 
#include <Startup_Structs.h>
 
 
 
// BlueprintGeneratedClass Startup.Startup_C
// Size: 0x230(Inherited: 0x228) 
struct AStartup_C : public ATBLevelScriptActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x228(0x8)

	void ReceiveBeginPlay(); // Function Startup.Startup_C.ReceiveBeginPlay
	void ExecuteUbergraph_Startup(int32_t EntryPoint); // Function Startup.Startup_C.ExecuteUbergraph_Startup
}; 



