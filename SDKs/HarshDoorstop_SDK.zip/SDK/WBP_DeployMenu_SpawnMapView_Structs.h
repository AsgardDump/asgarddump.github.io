#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.PreloadContent
// Size: 0x59(Inherited: 0x0) 
struct FPreloadContent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_GetMinimapData_bSuccess : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TSoftObjectPtr<UTexture2D> CallFunc_GetMinimapData_MinimapImg;  // 0x8(0x28)
	struct FMinimapGenerationSettings CallFunc_GetMinimapData_MinimapSettings;  // 0x30(0x28)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValidSoftObjectReference_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnSpawnPointSelected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnSpawnPointSelected__DelegateSignature
{
	struct AActor* POISpawnPointActor;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_2_OnSpawnPointDeselected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__Minimap_K2Node_ComponentBoundEvent_2_OnSpawnPointDeselected__DelegateSignature
{
	struct AActor* POISpawnPointActor;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.ExecuteUbergraph_WBP_DeployMenu_SpawnMapView
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_SpawnMapView
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* K2Node_ComponentBoundEvent_POISpawnPointActor;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AActor* K2Node_ComponentBoundEvent_POISpawnPointActor_2;  // 0x18(0x8)

}; 
// Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_0_OnSpawnPointSelected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__Minimap_K2Node_ComponentBoundEvent_0_OnSpawnPointSelected__DelegateSignature
{
	struct AActor* POISpawnPointActor;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.GetMinimapData
// Size: 0x69(Inherited: 0x0) 
struct FGetMinimapData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSuccess : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TSoftObjectPtr<UTexture2D> MinimapImg;  // 0x8(0x28)
	struct FMinimapGenerationSettings MinimapSettings;  // 0x30(0x28)
	struct AWorldSettings* CallFunc_GetWorldSettings_ReturnValue;  // 0x58(0x8)
	struct ATBWorldSettings* K2Node_DynamicCast_AsTBWorld_Settings;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)

}; 
