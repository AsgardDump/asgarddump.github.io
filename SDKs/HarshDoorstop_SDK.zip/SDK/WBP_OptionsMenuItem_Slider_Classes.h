#pragma once 
#include <WBP_OptionsMenuItem_Slider_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C
// Size: 0x360(Inherited: 0x230) 
struct UWBP_OptionsMenuItem_Slider_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UTBSlider* OptionSlider;  // 0x238(0x8)
	struct UTextBlock* OptionText;  // 0x240(0x8)
	struct UTextBlock* SliderValueText;  // 0x248(0x8)
	struct FText Text;  // 0x250(0x18)
	struct FText TextDescription;  // 0x268(0x18)
	float InitialValue;  // 0x280(0x4)
	char pad_644[4];  // 0x284(0x4)
	struct FMulticastInlineDelegate ValueChanged;  // 0x288(0x10)
	float ValueMin;  // 0x298(0x4)
	float ValueMax;  // 0x29C(0x4)
	float ValueStepSize;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct TMap<float, struct FText> SpecialValues;  // 0x2A8(0x50)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool bStepValuesOnly : 1;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool bMouseUsesStep : 1;  // 0x2F9(0x1)
	char pad_762_1 : 7;  // 0x2FA(0x1)
	bool bSnapToStepValue : 1;  // 0x2FA(0x1)
	char pad_763[1];  // 0x2FB(0x1)
	int32_t TextIntegralDigitsMin;  // 0x2FC(0x4)
	int32_t TextIntegralDigitsMax;  // 0x300(0x4)
	int32_t TextFractionalDigitsMin;  // 0x304(0x4)
	int32_t TextFractionalDigitsMax;  // 0x308(0x4)
	char pad_780_1 : 7;  // 0x30C(0x1)
	bool bTextUsesGrouping : 1;  // 0x30C(0x1)
	char ERoundingMode TextRoundingMode;  // 0x30D(0x1)
	char pad_782[2];  // 0x30E(0x2)
	struct FText TextSuffix;  // 0x310(0x18)
	struct FText TextPrefix;  // 0x328(0x18)
	struct FMargin SliderPadding;  // 0x340(0x10)
	struct FMargin OptionTextPadding;  // 0x350(0x10)

	void SetValueInternal(float InValue, bool bDirectSet); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueInternal
	void DoesMouseUseStep(bool& bOutMouseUsesStep); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.DoesMouseUseStep
	void SetMouseUsesStep(bool bInMouseUsesStep); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetMouseUsesStep
	void SetValueStepSize(float NewStepSize); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueStepSize
	void SetValueMax(float NewMax); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueMax
	void SetValueMin(float NewMin); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValueMin
	void UpdateSliderText(float NewValue); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.UpdateSliderText
	void GetNormalizedValue(float& ValueNormalized); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.GetNormalizedValue
	void SetNormalizedValue(float InNormValue); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetNormalizedValue
	void SetLocked(bool bInLocked); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetLocked
	void IsLocked(bool& bOutLocked); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.IsLocked
	void SetValue(float InValue); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.SetValue
	void GetValue(float& Value); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.GetValue
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.PreConstruct
	void BndEvt__OptionSlider_K2Node_ComponentBoundEvent_0_OnFloatValueChangedEvent__DelegateSignature(float Value); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.BndEvt__OptionSlider_K2Node_ComponentBoundEvent_0_OnFloatValueChangedEvent__DelegateSignature
	void ExecuteUbergraph_WBP_OptionsMenuItem_Slider(int32_t EntryPoint); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.ExecuteUbergraph_WBP_OptionsMenuItem_Slider
	void ValueChanged__DelegateSignature(float Value); // Function WBP_OptionsMenuItem_Slider.WBP_OptionsMenuItem_Slider_C.ValueChanged__DelegateSignature
}; 



