#pragma once 
#include <WBP_HDPOI_Player_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HDPOI_Player.WBP_HDPOI_Player_C
// Size: 0x410(Inherited: 0x3A0) 
struct UWBP_HDPOI_Player_C : public UDFPOIWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3A0(0x8)
	struct UImage* PlayerIcon;  // 0x3A8(0x8)
	struct UTextBlock* SquadNumberText;  // 0x3B0(0x8)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool POIWidgetInitialized : 1;  // 0x3B8(0x1)
	char pad_953[7];  // 0x3B9(0x7)
	struct FSlateColor SelectedTintColor;  // 0x3C0(0x28)
	struct FSlateColor DeselectedTintColor;  // 0x3E8(0x28)

	void ReceivePOISelected(); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.ReceivePOISelected
	void ReceivePOIDeselected(); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.ReceivePOIDeselected
	void PreConstruct(bool IsDesignTime); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.PreConstruct
	void Construct(); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.Construct
	void SetIconBrush(struct FSlateBrush& NewIconBrush); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.SetIconBrush
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.Tick
	void ExecuteUbergraph_WBP_HDPOI_Player(int32_t EntryPoint); // Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.ExecuteUbergraph_WBP_HDPOI_Player
}; 



