#pragma once 
#include <WBP_MenuBackground_OHDMovie_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_MenuBackground_OHDMovie.WBP_MenuBackground_OHDMovie_C
// Size: 0x2F0(Inherited: 0x2F0) 
struct UWBP_MenuBackground_OHDMovie_C : public UWBP_MenuBackground_Movie_C
{

}; 



