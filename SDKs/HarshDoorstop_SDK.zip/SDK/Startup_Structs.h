#pragma once 
#include "SDK.h" 
 
 
// Function Startup.Startup_C.ExecuteUbergraph_Startup
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_Startup
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x8(0x8)
	struct UTBGameInstance* K2Node_DynamicCast_AsTBGame_Instance;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
