#pragma once 
#include <NiagaraShader_Structs.h>
 
 
 
