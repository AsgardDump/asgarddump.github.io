#pragma once 
#include <WBP_HUDElement_Compass_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUDElement_Compass.WBP_HUDElement_Compass_C
// Size: 0x26C(Inherited: 0x230) 
struct UWBP_HUDElement_Compass_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UOverlay* CompassClips;  // 0x238(0x8)
	struct URetainerBox* FadeEffectMask;  // 0x240(0x8)
	struct UInvalidationBox* MarkerContainer;  // 0x248(0x8)
	struct FVector2D CompassClippedRegion;  // 0x250(0x8)
	struct FVector2D CompassSizeAbsolute;  // 0x258(0x8)
	float CompassPosFactor;  // 0x260(0x4)
	float CompassHalfWidth;  // 0x264(0x4)
	float CompassHalfHeightNeg;  // 0x268(0x4)

	void SetWidgetCanvasSlotSize(struct UWidget* Widget, struct FVector2D NewLayoutSize); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.SetWidgetCanvasSlotSize
	void UpdateDirection(); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.UpdateDirection
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.Tick
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.PreConstruct
	void OnInitialized(); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.OnInitialized
	void ExecuteUbergraph_WBP_HUDElement_Compass(int32_t EntryPoint); // Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.ExecuteUbergraph_WBP_HUDElement_Compass
}; 



