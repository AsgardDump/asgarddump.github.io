#pragma once 
#include "SDK.h" 
 
 
// Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetController
// Size: 0x19(Inherited: 0x0) 
struct FGetController
{
	struct AController* Controller;  // 0x0(0x8)
	struct APawn* CallFunc_GetOwningPawn_ReturnValue;  // 0x8(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ExecuteUbergraph_BP_ViewPunchRecoilHandler
// Size: 0xD9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ViewPunchRecoilHandler
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AController* CallFunc_GetController_Controller;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float K2Node_Event_DeltaTime;  // 0x14(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x18(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x1C(0x4)
	float K2Node_CustomEvent_DT_2;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	float K2Node_CustomEvent_DT;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsFiring_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FRotator CallFunc_GetControlRotation_ViewRotation;  // 0x30(0xC)
	char pad_60[4];  // 0x3C(0x4)
	struct AController* CallFunc_GetController_Controller_2;  // 0x40(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x50(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct AHDPlayerCharacter* K2Node_DynamicCast_AsHDPlayer_Character;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	float Temp_float_Variable;  // 0x6C(0x4)
	float Temp_float_Variable_2;  // 0x70(0x4)
	float Temp_float_Variable_3;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool Temp_bool_Variable : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x7C(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x80(0x4)
	float K2Node_Select_Default;  // 0x84(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x88(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x8C(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x90(0x4)
	float CallFunc_Ease_ReturnValue;  // 0x94(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x98(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x9C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0xA0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0xA4(0x4)
	float CallFunc_SignOfFloat_ReturnValue;  // 0xA8(0x4)
	float CallFunc_Ease_ReturnValue_2;  // 0xAC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0xB0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0xB4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0xB8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_9;  // 0xBC(0x4)
	struct AController* CallFunc_GetController_Controller_3;  // 0xC0(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0xC8(0x8)
	struct AHDPlayerCharacter* K2Node_DynamicCast_AsHDPlayer_Character_2;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xD8(0x1)

}; 
// Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetConeOfFireOffset
// Size: 0x1C(Inherited: 0xC) 
struct FGetConeOfFireOffset : public FGetConeOfFireOffset
{
	struct FVector ReturnValue;  // 0x0(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xC(0x4)
	struct FVector CallFunc_RandomUnitVectorInConeInDegrees_ReturnValue;  // 0x10(0xC)

}; 
// Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ComputeRecoil
// Size: 0x4(Inherited: 0x0) 
struct FComputeRecoil
{
	float DT;  // 0x0(0x4)

}; 
// Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.ComputeConeOfFire
// Size: 0x4(Inherited: 0x0) 
struct FComputeConeOfFire
{
	float DT;  // 0x0(0x4)

}; 
// Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.OnTick
// Size: 0x4(Inherited: 0x4) 
struct FOnTick : public FOnTick
{
	float DeltaTime;  // 0x0(0x4)

}; 
// Function BP_ViewPunchRecoilHandler.BP_ViewPunchRecoilHandler_C.GetControlRotation
// Size: 0x26(Inherited: 0x0) 
struct FGetControlRotation
{
	struct FRotator ViewRotation;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct AController* CallFunc_GetController_Controller;  // 0x10(0x8)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x18(0xC)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x25(0x1)

}; 
