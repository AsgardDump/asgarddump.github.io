#pragma once 
#include <WBP_MenuBackground_Static_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_MenuBackground_Static.WBP_MenuBackground_Static_C
// Size: 0x240(Inherited: 0x230) 
struct UWBP_MenuBackground_Static_C : public UUserWidget
{
	struct UBackgroundBlur* BgBlur;  // 0x230(0x8)
	struct UImage* BgImg;  // 0x238(0x8)

}; 



