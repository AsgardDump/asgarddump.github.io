#pragma once 
#include <BP_ContextWidgetPrereq_SquadLeaderOnly_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ContextWidgetPrereq_SquadLeaderOnly.BP_ContextWidgetPrereq_SquadLeaderOnly_C
// Size: 0x41(Inherited: 0x30) 
struct UBP_ContextWidgetPrereq_SquadLeaderOnly_C : public UDFContextualWidgetPrerequisiteBase
{
	struct AHDSquadState* MemberSQState;  // 0x30(0x8)
	struct AHDPlayerState* MemberPSToTest;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bInitialized : 1;  // 0x40(0x1)

	void IsValidContext(bool& bValidData); // Function BP_ContextWidgetPrereq_SquadLeaderOnly.BP_ContextWidgetPrereq_SquadLeaderOnly_C.IsValidContext
	bool SatisfiesPrerequisite(); // Function BP_ContextWidgetPrereq_SquadLeaderOnly.BP_ContextWidgetPrereq_SquadLeaderOnly_C.SatisfiesPrerequisite
	void SetupContext(struct AHDSquadState* InMemberSQState, struct AHDPlayerState* InMemberPSToTest); // Function BP_ContextWidgetPrereq_SquadLeaderOnly.BP_ContextWidgetPrereq_SquadLeaderOnly_C.SetupContext
}; 



