#pragma once 
#include "SDK.h" 
 
 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.GetCheckedState
// Size: 0x2(Inherited: 0x0) 
struct FGetCheckedState
{
	uint8_t  CheckedState;  // 0x0(0x1)
	uint8_t  CallFunc_GetCheckedState_CheckedState;  // 0x1(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.BndEvt__OptionCBox_K2Node_ComponentBoundEvent_0_CheckStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__OptionCBox_K2Node_ComponentBoundEvent_0_CheckStateChanged__DelegateSignature
{
	uint8_t  CheckedState;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.CheckStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCheckStateChanged__DelegateSignature
{
	uint8_t  CheckedState;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.ExecuteUbergraph_WBP_OptionsMenuItem_Checkbox
// Size: 0x7(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_OptionsMenuItem_Checkbox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	uint8_t  K2Node_ComponentBoundEvent_CheckedState;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool K2Node_ComponentBoundEvent_bChecked : 1;  // 0x6(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.BndEvt__OptionCBox_K2Node_ComponentBoundEvent_1_CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__OptionCBox_K2Node_ComponentBoundEvent_1_CheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.IsChecked
// Size: 0x2(Inherited: 0x0) 
struct FIsChecked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsChecked_bChecked : 1;  // 0x1(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.SetIsChecked
// Size: 0x1(Inherited: 0x0) 
struct FSetIsChecked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_OptionsMenuItem_Checkbox.WBP_OptionsMenuItem_Checkbox_C.SetCheckedState
// Size: 0x1(Inherited: 0x0) 
struct FSetCheckedState
{
	uint8_t  NewCheckedState;  // 0x0(0x1)

}; 
