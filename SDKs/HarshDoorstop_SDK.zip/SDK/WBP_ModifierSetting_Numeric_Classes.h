#pragma once 
#include <WBP_ModifierSetting_Numeric_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C
// Size: 0x360(Inherited: 0x230) 
struct UWBP_ModifierSetting_Numeric_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_ModifierSettingBox_C* ModifierSetting;  // 0x238(0x8)
	struct UTextBlock* NumericHintText;  // 0x240(0x8)
	struct USpinBox* NumericSpinBox;  // 0x248(0x8)
	struct FText SettingText;  // 0x250(0x18)
	struct TMap<float, struct FText> MagicValues;  // 0x268(0x50)
	struct FText MagicValueText;  // 0x2B8(0x18)
	float ValueSnapDelta;  // 0x2D0(0x4)
	float ValueInitial;  // 0x2D4(0x4)
	struct FFNumericModifierValueBound ValueMinInitial;  // 0x2D8(0x8)
	struct FFNumericModifierValueBound ValueMaxInitial;  // 0x2E0(0x8)
	struct FSlateColor VisibleSpinBoxForegroundColor;  // 0x2E8(0x28)
	int32_t MinFractionalDigitsInitial;  // 0x310(0x4)
	int32_t MaxFractionalDigitsInitial;  // 0x314(0x4)
	struct FSlateColor HiddenSpinBoxForegroundColor;  // 0x318(0x28)
	struct FMulticastInlineDelegate OnValueChanged;  // 0x340(0x10)
	struct FMulticastInlineDelegate OnValueCommitted;  // 0x350(0x10)

	void UpdateMagicValueState(); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.UpdateMagicValueState
	void GetValueSnapDelta(float& Delta); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetValueSnapDelta
	void SetValueSnapDelta(float InDelta); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetValueSnapDelta
	void GetValue(float& Value); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetValue
	void SetValue(float InValue); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetValue
	void GetMagicValueText(struct FText& MagicValueText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetMagicValueText
	void SetMagicValueText(struct FText InMagicValueText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetMagicValueText
	void GetSettingText(struct FText& SettingText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetSettingText
	void SetSettingText(struct FText InSettingText); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetSettingText
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.PreConstruct
	void BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_0_OnSpinBoxValueChangedEvent__DelegateSignature(float InValue); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_0_OnSpinBoxValueChangedEvent__DelegateSignature
	void BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_1_OnSpinBoxValueCommittedEvent__DelegateSignature(float InValue, char ETextCommit CommitMethod); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_1_OnSpinBoxValueCommittedEvent__DelegateSignature
	void ExecuteUbergraph_WBP_ModifierSetting_Numeric(int32_t EntryPoint); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.ExecuteUbergraph_WBP_ModifierSetting_Numeric
	void OnValueCommitted__DelegateSignature(float InValue, char ETextCommit CommitMethod); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.OnValueCommitted__DelegateSignature
	void OnValueChanged__DelegateSignature(float InValue); // Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.OnValueChanged__DelegateSignature
}; 



