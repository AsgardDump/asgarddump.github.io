#pragma once 
#include "SDK.h" 
 
 
// Function BPFL_HDWeapon.BPFL_HDWeapon_C.FireModeToString
// Size: 0x68(Inherited: 0x0) 
struct FFireModeToString
{
	uint8_t  FireMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FString ModeString;  // 0x10(0x10)
	uint8_t  Temp_byte_Variable;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString Temp_string_Variable;  // 0x28(0x10)
	struct FString Temp_string_Variable_2;  // 0x38(0x10)
	struct FString Temp_string_Variable_3;  // 0x48(0x10)
	struct FString K2Node_Select_Default;  // 0x58(0x10)

}; 
// Function BPFL_HDWeapon.BPFL_HDWeapon_C.FireModeToDisplayText
// Size: 0x90(Inherited: 0x0) 
struct FFireModeToDisplayText
{
	uint8_t  FireMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText ModeText;  // 0x10(0x18)
	uint8_t  Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FText Temp_text_Variable_2;  // 0x48(0x18)
	struct FText Temp_text_Variable_3;  // 0x60(0x18)
	struct FText K2Node_Select_Default;  // 0x78(0x18)

}; 
// Function BPFL_HDWeapon.BPFL_HDWeapon_C.AimStyleToDisplayText
// Size: 0xC0(Inherited: 0x0) 
struct FAimStyleToDisplayText
{
	uint8_t  AimStyle;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FText StyleText;  // 0x10(0x18)
	uint8_t  Temp_byte_Variable;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText Temp_text_Variable;  // 0x30(0x18)
	struct FText Temp_text_Variable_2;  // 0x48(0x18)
	struct FText Temp_text_Variable_3;  // 0x60(0x18)
	struct FText Temp_text_Variable_4;  // 0x78(0x18)
	struct FText Temp_text_Variable_5;  // 0x90(0x18)
	struct FText K2Node_Select_Default;  // 0xA8(0x18)

}; 
