#pragma once 
#include <BP_HDScopeComponentBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDScopeComponentBase.BP_HDScopeComponentBase_C
// Size: 0x820(Inherited: 0x1F0) 
struct UBP_HDScopeComponentBase_C : public UHDWeaponScopeComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool UseOverlay : 1;  // 0x1F8(0x1)
	char pad_505[3];  // 0x1F9(0x3)
	float ScopeRadius;  // 0x1FC(0x4)
	float AimingFOV;  // 0x200(0x4)
	float ADSOffset;  // 0x204(0x4)
	int32_t ScopeMaterialIndex;  // 0x208(0x4)
	char pad_524[4];  // 0x20C(0x4)
	struct TArray<struct FWeightedBlendable> PostProcessMaterial;  // 0x210(0x10)
	struct UMaterialInterface* ScopeGlassMaterial;  // 0x220(0x8)
	struct UMaterialInterface* ScopeOpticMaterial;  // 0x228(0x8)
	UUserWidget* ScopeOverlayClass;  // 0x230(0x8)
	float FreeAimMaxPitch;  // 0x238(0x4)
	float FreeAimMaxYaw;  // 0x23C(0x4)
	float ReticleOffsetY;  // 0x240(0x4)
	float ReticleOffsetX;  // 0x244(0x4)
	struct UMaterialInstanceDynamic* ScopeMIDGlass;  // 0x248(0x8)
	struct UUserWidget* ScopeOverlay;  // 0x250(0x8)
	float AimInterpSpeed;  // 0x258(0x4)
	char pad_604[4];  // 0x25C(0x4)
	struct UMaterialInstanceDynamic* ScopeMID;  // 0x260(0x8)
	float DefaultAimingFOV;  // 0x268(0x4)
	float DefaultAimInterpSpeed;  // 0x26C(0x4)
	float DefaultFreeAimPitch;  // 0x270(0x4)
	float DefaultFreeAimYaw;  // 0x274(0x4)
	char pad_632[8];  // 0x278(0x8)
	struct FPostProcessSettings DefaultCameraPostProcess;  // 0x280(0x540)
	char pad_1984_1 : 7;  // 0x7C0(0x1)
	bool bIsScopedIn : 1;  // 0x7C0(0x1)
	char pad_1985[3];  // 0x7C1(0x3)
	float DefaultADSOffset;  // 0x7C4(0x4)
	struct UMeshComponent* ParentMesh;  // 0x7C8(0x8)
	struct AHDPlayerController* ControllerRef;  // 0x7D0(0x8)
	struct ABP_HDPlayerCharacterBase_C* CharacterRef;  // 0x7D8(0x8)
	struct ABP_HDWeaponBase_C* ParentWeaponRef;  // 0x7E0(0x8)
	struct TArray<struct FWeightedBlendable> PostProcessRef;  // 0x7E8(0x10)
	struct ADFPlayerCameraManager* CameraRef;  // 0x7F8(0x8)
	struct TArray<struct UBP_HDScopeComponentBase_C*> ParentSightList;  // 0x800(0x10)
	struct FMaterialParameterInfo MPC;  // 0x810(0x10)

	void ClearOwnerData(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ClearOwnerData
	void SetupOwnerData(bool& IsValid); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.SetupOwnerData
	void LoadDefaults(bool IsPlayerDead); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.LoadDefaults
	void SaveDefaults(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.SaveDefaults
	void Init(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.Init
	void ScopeEffect(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ScopeEffect
	void CanScope(bool& CanScope); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.CanScope
	void GetData(struct ABP_HDPlayerCharacterBase_C*& Character, struct AHDPlayerController*& Controller, struct UDFCharacterMovementComponent*& Movement, struct ADFPlayerCameraManager*& Camera, struct ABP_HDWeaponBase_C*& Parent, struct USkeletalMeshComponent*& CharacterMesh, struct UMeshComponent*& WeaponMesh, struct TArray<struct UBP_HDScopeComponentBase_C*>& ParentSightList, struct TArray<struct UMaterialInstanceDynamic*>& FirstPersonMatArray, struct TArray<struct UMaterialInstanceDynamic*>& ThirdPersonMatArray); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.GetData
	void AimOut(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimOut
	void AimIn(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimIn
	void AimTransition(bool bIsStartTransition); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimTransition
	void AimStyle(struct AHDPlayerCharacter* Character, uint8_t  NewAimStyle, uint8_t  PrevAimStyle, bool bFromPlayerInput); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.AimStyle
	void DeathEvent(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.DeathEvent
	void ItemChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ItemChanged
	void ChangeSights(); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ChangeSights
	void ReceiveTick(float DeltaSeconds); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ReceiveTick
	void EventActivated(struct UActorComponent* Component, bool bReset); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.EventActivated
	void EventDeactivated(struct UActorComponent* Component); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.EventDeactivated
	void BindEvents(struct ABP_HDPlayerCharacterBase_C* NewCharacter, struct ABP_HDWeaponBase_C* NewWeapon); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.BindEvents
	void UnbindEvents(struct ABP_HDPlayerCharacterBase_C* OldCharacter, struct ABP_HDWeaponBase_C* OldWeapon); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.UnbindEvents
	void ExecuteUbergraph_BP_HDScopeComponentBase(int32_t EntryPoint); // Function BP_HDScopeComponentBase.BP_HDScopeComponentBase_C.ExecuteUbergraph_BP_HDScopeComponentBase
}; 



