#pragma once 
#include <BP_HDGameInstanceBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDGameInstanceBase.BP_HDGameInstanceBase_C
// Size: 0x2D8(Inherited: 0x2D8) 
struct UBP_HDGameInstanceBase_C : public UHDGameInstance
{

}; 



