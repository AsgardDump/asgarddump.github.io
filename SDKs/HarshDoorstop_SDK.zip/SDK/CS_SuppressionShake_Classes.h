#pragma once 
#include <CS_SuppressionShake_Structs.h>
 
 
 
// BlueprintGeneratedClass CS_SuppressionShake.CS_SuppressionShake_C
// Size: 0x160(Inherited: 0x160) 
struct UCS_SuppressionShake_C : public UCameraShake
{

}; 



