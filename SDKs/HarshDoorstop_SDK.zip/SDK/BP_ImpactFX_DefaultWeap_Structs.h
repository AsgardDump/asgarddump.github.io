#pragma once 
#include "SDK.h" 
 
 
// Function BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C.ExecuteUbergraph_BP_ImpactFX_DefaultWeap
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ImpactFX_DefaultWeap
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)

}; 
// Function BP_ImpactFX_DefaultWeap.BP_ImpactFX_DefaultWeap_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
