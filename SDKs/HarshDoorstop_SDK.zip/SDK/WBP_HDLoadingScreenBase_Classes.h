#pragma once 
#include <WBP_HDLoadingScreenBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C
// Size: 0x342(Inherited: 0x230) 
struct UWBP_HDLoadingScreenBase_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* BackgroundImage_Map;  // 0x238(0x8)
	struct UTextBlock* BluforFactionName;  // 0x240(0x8)
	struct UOverlay* BluforTeamInfo;  // 0x248(0x8)
	struct UTextBlock* BluforTeamReinforcementText;  // 0x250(0x8)
	struct UTextBlock* DeploymentText;  // 0x258(0x8)
	struct UThrobber* DeploymentThrobber;  // 0x260(0x8)
	struct UOverlay* GameModeHeader;  // 0x268(0x8)
	struct UTextBlock* GameModeNameText;  // 0x270(0x8)
	struct UTextBlock* MapNameText;  // 0x278(0x8)
	struct UOverlay* MapOverview;  // 0x280(0x8)
	struct UImage* MinimapImage;  // 0x288(0x8)
	struct UTextBlock* OpforFactionName;  // 0x290(0x8)
	struct UOverlay* OpforTeamInfo;  // 0x298(0x8)
	struct UTextBlock* OpforTeamReinforcementText;  // 0x2A0(0x8)
	struct TArray<struct TSoftObjectPtr<UTexture2D>> MapBgImages;  // 0x2A8(0x10)
	struct FSlateBrush MapBgBrush;  // 0x2B8(0x88)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool bEnableMapOverviewUI : 1;  // 0x340(0x1)
	char pad_833_1 : 7;  // 0x341(0x1)
	bool bEnableTeamInfoUI : 1;  // 0x341(0x1)

	void SetMapBgImage(struct TSoftObjectPtr<UTexture2D> InBgImage); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetMapBgImage
	void SetOpforStartingTicketCount(int32_t TicketCount); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetOpforStartingTicketCount
	void SetBluforStartingTicketCount(int32_t TicketCount); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetBluforStartingTicketCount
	void SetMapElementVisibility(uint8_t  NewVisibility); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetMapElementVisibility
	void SetLoadingScreenDescription(struct FLoadingScreenDescription& Description); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetLoadingScreenDescription
	void SetLevelLoadData(struct FLoadScreenLevelData& LevelData); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.SetLevelLoadData
	void PreConstruct(bool IsDesignTime); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.PreConstruct
	void OnInitialized(); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.OnInitialized
	void ExecuteUbergraph_WBP_HDLoadingScreenBase(int32_t EntryPoint); // Function WBP_HDLoadingScreenBase.WBP_HDLoadingScreenBase_C.ExecuteUbergraph_WBP_HDLoadingScreenBase
}; 



