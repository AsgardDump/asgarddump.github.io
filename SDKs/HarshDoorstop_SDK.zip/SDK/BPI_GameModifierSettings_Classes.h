#pragma once 
#include <BPI_GameModifierSettings_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_GameModifierSettings.BPI_GameModifierSettings_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_GameModifierSettings_C : public UInterface
{

	void GetTravelURLOptions(struct FString& Options); // Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.GetTravelURLOptions
	void IsEnabled(bool& bEnabled); // Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.IsEnabled
	void SetupModifier(struct UWBP_OptionMenu_CreateGame_C* ParentMenu); // Function BPI_GameModifierSettings.BPI_GameModifierSettings_C.SetupModifier
}; 



