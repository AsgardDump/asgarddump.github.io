#pragma once 
#include <WBP_HDRadialMenuBase_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C
// Size: 0x278(Inherited: 0x230) 
struct UWBP_HDRadialMenuBase_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct FMulticastInlineDelegate SubmenuCommit;  // 0x238(0x10)
	struct TArray<struct FKey> SubmitKeys;  // 0x248(0x10)
	struct TArray<struct FKey> BackKeys;  // 0x258(0x10)
	struct FMulticastInlineDelegate Cancel;  // 0x268(0x10)

	struct FEventReply OnMouseButtonDoubleClick(struct FGeometry InMyGeometry, struct FPointerEvent& InMouseEvent); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnMouseButtonDoubleClick
	struct FEventReply OnKeyDown(struct FGeometry MyGeometry, struct FKeyEvent InKeyEvent); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnKeyDown
	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnMouseButtonDown
	void Submit(); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.Submit
	void GoBack(); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.GoBack
	void ExecuteUbergraph_WBP_HDRadialMenuBase(int32_t EntryPoint); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.ExecuteUbergraph_WBP_HDRadialMenuBase
	void Cancel__DelegateSignature(); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.Cancel__DelegateSignature
	void SubmenuCommit__DelegateSignature(struct FName Category, struct FName SubItem); // Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.SubmenuCommit__DelegateSignature
}; 



