#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct NiagaraShader.NiagaraDataInterfaceGPUParamInfo
// Size: 0x30(Inherited: 0x0) 
struct FNiagaraDataInterfaceGPUParamInfo
{
	struct FString DataInterfaceHLSLSymbol;  // 0x0(0x10)
	struct FString DIClassName;  // 0x10(0x10)
	struct TArray<struct FNiagaraDataInterfaceGeneratedFunction> GeneratedFunctions;  // 0x20(0x10)

}; 
// ScriptStruct NiagaraShader.NiagaraDataInterfaceGeneratedFunction
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraDataInterfaceGeneratedFunction
{
	char pad_0[40];  // 0x0(0x28)

}; 
// ScriptStruct NiagaraShader.NiagaraCompileEvent
// Size: 0x48(Inherited: 0x0) 
struct FNiagaraCompileEvent
{
	uint8_t  Severity;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Message;  // 0x8(0x10)
	struct FGuid NodeGuid;  // 0x18(0x10)
	struct FGuid PinGuid;  // 0x28(0x10)
	struct TArray<struct FGuid> StackGuids;  // 0x38(0x10)

}; 
