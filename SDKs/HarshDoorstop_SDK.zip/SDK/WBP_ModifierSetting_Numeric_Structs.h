#pragma once 
#include "SDK.h" 
 
 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetValue
// Size: 0x4(Inherited: 0x0) 
struct FSetValue
{
	float InValue;  // 0x0(0x4)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.OnValueChanged__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnValueChanged__DelegateSignature
{
	float InValue;  // 0x0(0x4)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.ExecuteUbergraph_WBP_ModifierSetting_Numeric
// Size: 0x4D(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_ModifierSetting_Numeric
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText K2Node_Select_Default;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float K2Node_ComponentBoundEvent_InValue_2;  // 0x44(0x4)
	float K2Node_ComponentBoundEvent_InValue;  // 0x48(0x4)
	char ETextCommit K2Node_ComponentBoundEvent_CommitMethod;  // 0x4C(0x1)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetSettingText
// Size: 0x18(Inherited: 0x0) 
struct FGetSettingText
{
	struct FText SettingText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_0_OnSpinBoxValueChangedEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_0_OnSpinBoxValueChangedEvent__DelegateSignature
{
	float InValue;  // 0x0(0x4)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.OnValueCommitted__DelegateSignature
// Size: 0x5(Inherited: 0x0) 
struct FOnValueCommitted__DelegateSignature
{
	float InValue;  // 0x0(0x4)
	char ETextCommit CommitMethod;  // 0x4(0x1)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.BndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_1_OnSpinBoxValueCommittedEvent__DelegateSignature
// Size: 0x5(Inherited: 0x0) 
struct FBndEvt__NumericSpinBox_K2Node_ComponentBoundEvent_1_OnSpinBoxValueCommittedEvent__DelegateSignature
{
	float InValue;  // 0x0(0x4)
	char ETextCommit CommitMethod;  // 0x4(0x1)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetSettingText
// Size: 0x18(Inherited: 0x0) 
struct FSetSettingText
{
	struct FText InSettingText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetMagicValueText
// Size: 0x18(Inherited: 0x0) 
struct FSetMagicValueText
{
	struct FText InMagicValueText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetMagicValueText
// Size: 0x18(Inherited: 0x0) 
struct FGetMagicValueText
{
	struct FText MagicValueText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetValue
// Size: 0x8(Inherited: 0x0) 
struct FGetValue
{
	float Value;  // 0x0(0x4)
	float CallFunc_GetValue_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.SetValueSnapDelta
// Size: 0x9(Inherited: 0x0) 
struct FSetValueSnapDelta
{
	float InDelta;  // 0x0(0x4)
	float CallFunc_GetDelta_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.GetValueSnapDelta
// Size: 0x8(Inherited: 0x0) 
struct FGetValueSnapDelta
{
	float Delta;  // 0x0(0x4)
	float CallFunc_GetDelta_ReturnValue;  // 0x4(0x4)

}; 
// Function WBP_ModifierSetting_Numeric.WBP_ModifierSetting_Numeric_C.UpdateMagicValueState
// Size: 0x89(Inherited: 0x0) 
struct FUpdateMagicValueState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_GetValue_ReturnValue;  // 0x24(0x4)
	struct FText CallFunc_Map_Find_Value;  // 0x28(0x18)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FText K2Node_Select_Default;  // 0x48(0x18)
	struct FSlateColor K2Node_Select_Default_2;  // 0x60(0x28)
	uint8_t  K2Node_Select_Default_3;  // 0x88(0x1)

}; 
