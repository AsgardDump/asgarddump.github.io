#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SetClassSelectionState
// Size: 0x42(Inherited: 0x0) 
struct FSetClassSelectionState
{
	struct UHDKit* ClassToUpdate;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSelected : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bMatchDisplayNames : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bClassUpdated : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool bClassSelected : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	int32_t Temp_int_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x18(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Class_Selection_Listing;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_EqualEqual_IgnoreCase_TextText_ReturnValue : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x36(0x1)
	char pad_55[1];  // 0x37(0x1)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x41(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.ExecuteUbergraph_WBP_DeployMenu_ClassSelectionPanel
// Size: 0x79(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_ClassSelectionPanel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x1B(0x1)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x1C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_CustomEvent_SelectedClassWidget;  // 0x28(0x8)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_CustomEvent_DeselectedClassWidget;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x3B(0x1)
	char pad_60[4];  // 0x3C(0x4)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char CallFunc_GetTeam_ReturnValue;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	int32_t Temp_int_Variable;  // 0x4C(0x4)
	char CallFunc_GetValidValue_ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x58(0x8)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Class_Selection_Listing;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x69(0x1)
	char pad_106[2];  // 0x6A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x6C(0x4)
	struct UDFFactionInfo* CallFunc_GetFactionInfo_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x78(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalPopulateListWithClasses
// Size: 0x90(Inherited: 0x0) 
struct FInternalPopulateListWithClasses
{
	struct TSet<struct UHDKit*> TeamKits;  // 0x0(0x50)
	struct TArray<struct UHDKit*> CallFunc_Set_ToArray_Result;  // 0x50(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x60(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x64(0x4)
	struct UHDKit* CallFunc_Array_Get_Item;  // 0x68(0x8)
	struct UWBP_DeployMenu_ClassSelectionListing_C* CallFunc_InternalCreateClassListingWidget_NewKitListingWidget;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x84(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x88(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.OnClassDeselected
// Size: 0x8(Inherited: 0x0) 
struct FOnClassDeselected
{
	struct UWBP_DeployMenu_ClassSelectionListing_C* DeselectedClassWidget;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SelectFirstUnrestrictedClass
// Size: 0x29(Inherited: 0x0) 
struct FSelectFirstUnrestrictedClass
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Temp_int_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0xC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x18(0x8)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Class_Selection_Listing;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.RepopulateListByFaction
// Size: 0x56(Inherited: 0x0) 
struct FRepopulateListByFaction
{
	uint8_t  OwningPlayerTeam;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AHDTeamState* FactionTeamState;  // 0x8(0x8)
	struct UHDKit* LastSelectedClass;  // 0x10(0x8)
	struct AHDGameState* CallFunc_GetHDGameState_HDGameState;  // 0x18(0x8)
	struct ADFTeamState* CallFunc_GetTeamStateById_ReturnValue;  // 0x20(0x8)
	struct AHDTeamState* K2Node_DynamicCast_AsTeam_State__HD_;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Set_Length_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x40(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_SetClassSelectionState_bClassUpdated : 1;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_SetClassSelectionState_bClassUpdated_2 : 1;  // 0x55(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.OnClassSelected
// Size: 0x8(Inherited: 0x0) 
struct FOnClassSelected
{
	struct UWBP_DeployMenu_ClassSelectionListing_C* SelectedClassWidget;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalCreateClassListingWidget
// Size: 0x38(Inherited: 0x0) 
struct FInternalCreateClassListingWidget
{
	struct UHDKit* Kit;  // 0x0(0x8)
	struct UWBP_DeployMenu_ClassSelectionListing_C* NewKitListingWidget;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x20(0x10)
	struct UWBP_DeployMenu_ClassSelectionListing_C* CallFunc_Create_ReturnValue;  // 0x30(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.ToggleRestrictionsTimer
// Size: 0x20(Inherited: 0x0) 
struct FToggleRestrictionsTimer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bFireOnceImmediately : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SetClassSelectionStateByIndex
// Size: 0x19(Inherited: 0x0) 
struct FSetClassSelectionStateByIndex
{
	int32_t ChildIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bSelected : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValidClassListingIndex_bValidIndex : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x8(0x8)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Class_Selection_Listing;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.IsValidClassListingIndex
// Size: 0x12(Inherited: 0x0) 
struct FIsValidClassListingIndex
{
	int32_t ChildIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bValidIndex : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7(0x1)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x11(0x1)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalDeselectAllClasses
// Size: 0x2C(Inherited: 0x0) 
struct FInternalDeselectAllClasses
{
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x0(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Class_Selection_Listing;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Variable;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)

}; 
// Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalUpdateSelectionState
// Size: 0x42(Inherited: 0x0) 
struct FInternalUpdateSelectionState
{
	struct UDeployMenu_ClassSelectionListing* NewSelection;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Variable : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Temp_int_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_HasAnyChildren_ReturnValue : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UWBP_DeployMenu_ClassSelectionListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Class_Selection_Listing;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x41(0x1)

}; 
