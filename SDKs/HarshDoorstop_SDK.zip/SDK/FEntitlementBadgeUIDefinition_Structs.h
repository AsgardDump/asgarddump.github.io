#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FEntitlementBadgeUIDefinition.FEntitlementBadgeUIDefinition
// Size: 0x98(Inherited: 0x0) 
struct FFEntitlementBadgeUIDefinition
{
	struct FSlateBrush Icon_2_CF5F88F845329D7B7884FAAA929513D7;  // 0x0(0x88)
	struct TArray<struct FFEntitlementDefinition> Entitlements_20_EBFD21A24AC78F2267FB5C946C532D63;  // 0x88(0x10)

}; 
