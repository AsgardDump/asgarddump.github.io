#pragma once 
#include <BP_HDCapturePointBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDCapturePointBase.BP_HDCapturePointBase_C
// Size: 0x398(Inherited: 0x350) 
struct ABP_HDCapturePointBase_C : public AHDBaseCapturePoint
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct UWidgetComponent* IconWidget;  // 0x358(0x8)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool bDebug : 1;  // 0x360(0x1)
	char pad_865_1 : 7;  // 0x361(0x1)
	bool bDebugFlagClothLOD : 1;  // 0x361(0x1)
	char pad_866_1 : 7;  // 0x362(0x1)
	bool bOnlyShowDebugIfActive : 1;  // 0x362(0x1)
	char pad_867[5];  // 0x363(0x5)
	struct UDFMinimap* Minimap;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool bShowIconWidget : 1;  // 0x370(0x1)
	char pad_881[7];  // 0x371(0x7)
	struct FMulticastInlineDelegate OnCaptureStatusUpdated;  // 0x378(0x10)
	struct AHDPlayerController* LocalPC;  // 0x388(0x8)
	struct UNavigationInvokerComponent* NavInvoker;  // 0x390(0x8)

	void UpdateFlagClothLOD(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagClothLOD
	void AddPOI(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.AddPOI
	void RemovePOI(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.RemovePOI
	void UpdatePOIState(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdatePOIState
	void InitPOI(struct UDFMinimap* Minimap); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.InitPOI
	void UpdateFlagIcon(uint8_t  InOwningTeam, struct AHUD* InLocalPlayerHUD); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagIcon
	void UpdateFlagColor(uint8_t  InOwningTeam); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UpdateFlagColor
	void UserConstructionScript(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.UserConstructionScript
	void ReceiveTick(float DeltaSeconds); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveTick
	void ReceiveOnOwningTeamUpdated(uint8_t  LastOwningTeam); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnOwningTeamUpdated
	void ReceiveOnCaptureProgress(bool bNewContested); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnCaptureProgress
	void OnCaptureUpdate(bool bContested, int32_t Progress); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.OnCaptureUpdate
	void ReceiveOnActive(bool bNewActive); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnActive
	void ReceiveOnLocked(bool bNewLocked); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnLocked
	void ReceiveBeginPlay(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveBeginPlay
	void ReceiveOnTeamCaptureStatusUpdated(); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveOnTeamCaptureStatusUpdated
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ReceiveEndPlay
	void ExecuteUbergraph_BP_HDCapturePointBase(int32_t EntryPoint); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.ExecuteUbergraph_BP_HDCapturePointBase
	void OnCaptureStatusUpdated__DelegateSignature(struct ABP_HDCapturePointBase_C* ControlPoint); // Function BP_HDCapturePointBase.BP_HDCapturePointBase_C.OnCaptureStatusUpdated__DelegateSignature
}; 



