#pragma once 
#include <ArcVehiclesExtra_Structs.h>
 
 
 
// Class ArcVehiclesExtra.ArcVehicleSampleCharacter
// Size: 0x4C0(Inherited: 0x4C0) 
struct AArcVehicleSampleCharacter : public ACharacter
{
	char pad_1216_1 : 7;  // 0x4C0(0x1)
	bool bUseAttachedVehicleRelevancy : 1;  // 0x4B8(0x1)

}; 



// Class ArcVehiclesExtra.ArcVehicleSpawner
// Size: 0x258(Inherited: 0x220) 
struct AArcVehicleSpawner : public AActor
{
	struct UChildActorComponent* EditorVehicleMesh;  // 0x220(0x8)
	AArcBaseVehicle* VehicleClass;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool bSpawnImmediately : 1;  // 0x230(0x1)
	char pad_561[3];  // 0x231(0x3)
	float RespawnDelay;  // 0x234(0x4)
	int32_t MaxVehiclesAlive;  // 0x238(0x4)
	char pad_572[28];  // 0x23C(0x1C)

	void SpawnVehicleTimerEnd(); // Function ArcVehiclesExtra.ArcVehicleSpawner.SpawnVehicleTimerEnd
	void OnVehicleDestroyed(struct AActor* DestroyedActor); // Function ArcVehiclesExtra.ArcVehicleSpawner.OnVehicleDestroyed
}; 



