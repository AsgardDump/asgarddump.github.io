#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeathScreen.WBP_DeathScreen_C.ExecuteUbergraph_WBP_DeathScreen
// Size: 0x38(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeathScreen
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x8(0x8)
	struct UTBGameUserSettings* K2Node_DynamicCast_AsTBGame_User_Settings;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FKey CallFunc_GetDeployMenuKeyBinding_ReturnValue;  // 0x20(0x18)

}; 
// Function WBP_DeathScreen.WBP_DeathScreen_C.UpdateDeathKeyText
// Size: 0x98(Inherited: 0x0) 
struct FUpdateDeathKeyText
{
	struct FKey Key;  // 0x0(0x18)
	struct FText CallFunc_Key_GetDisplayName_ReturnValue;  // 0x18(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x30(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x70(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x80(0x18)

}; 
// Function WBP_DeathScreen.WBP_DeathScreen_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
