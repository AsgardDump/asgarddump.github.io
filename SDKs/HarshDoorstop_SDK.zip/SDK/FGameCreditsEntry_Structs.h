#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FGameCreditsEntry.FGameCreditsEntry
// Size: 0x2C(Inherited: 0x0) 
struct FFGameCreditsEntry
{
	char EGameCreditsEntryType EntryType_6_793CFEE04DA4AF9360FD6A8A9B1C6812;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText Text_5_DFA977D64EC46726AC35AE9CDF6FB11A;  // 0x8(0x18)
	struct FName HeaderRowName_9_808E074444E26274A7D579AC4B409585;  // 0x20(0x8)
	float HeaderDividerWidth_13_DE3954594351434E75DE5D882ACEC8C0;  // 0x28(0x4)

}; 
