#pragma once 
#include <BP_HDGameInstance_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDGameInstance.BP_HDGameInstance_C
// Size: 0x2D8(Inherited: 0x2D8) 
struct UBP_HDGameInstance_C : public UBP_HDGameInstanceBase_C
{

}; 



