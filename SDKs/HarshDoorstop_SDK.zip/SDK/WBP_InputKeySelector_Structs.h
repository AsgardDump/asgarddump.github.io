#pragma once 
#include "SDK.h" 
 
 
// Function WBP_InputKeySelector.WBP_InputKeySelector_C.OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_InputKeySelector.WBP_InputKeySelector_C.ExecuteUbergraph_WBP_InputKeySelector
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_InputKeySelector
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FInputChord K2Node_ComponentBoundEvent_SelectedKey;  // 0x8(0x20)

}; 
// Function WBP_InputKeySelector.WBP_InputKeySelector_C.BndEvt__IKS_K2Node_ComponentBoundEvent_1_OnKeySelected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBndEvt__IKS_K2Node_ComponentBoundEvent_1_OnKeySelected__DelegateSignature
{
	struct FInputChord SelectedKey;  // 0x0(0x20)

}; 
// Function WBP_InputKeySelector.WBP_InputKeySelector_C.GetSelectedKey
// Size: 0x18(Inherited: 0x0) 
struct FGetSelectedKey
{
	struct FKey SelectedKey;  // 0x0(0x18)

}; 
// Function WBP_InputKeySelector.WBP_InputKeySelector_C.SetSelectedKey
// Size: 0x38(Inherited: 0x0) 
struct FSetSelectedKey
{
	struct FKey SelectedKey;  // 0x0(0x18)
	struct FInputChord K2Node_MakeStruct_InputChord;  // 0x18(0x20)

}; 
