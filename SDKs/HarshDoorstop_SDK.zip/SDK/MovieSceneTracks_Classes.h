#pragma once 
#include <MovieSceneTracks_Structs.h>
 
 
 
// Class MovieSceneTracks.MovieSceneVectorSection
// Size: 0x368(Inherited: 0xE0) 
struct UMovieSceneVectorSection : public UMovieSceneSection
{
	struct FMovieSceneFloatChannel Curves[4];  // 0xE0(0x280)
	int32_t ChannelsUsed;  // 0x360(0x4)
	char pad_868[4];  // 0x364(0x4)

}; 



// Class MovieSceneTracks.MovieSceneEventSectionBase
// Size: 0xE0(Inherited: 0xE0) 
struct UMovieSceneEventSectionBase : public UMovieSceneSection
{

}; 



// Class MovieSceneTracks.MovieSceneTransformOrigin
// Size: 0x28(Inherited: 0x28) 
struct UMovieSceneTransformOrigin : public UInterface
{

	struct FTransform BP_GetTransformOrigin(); // Function MovieSceneTracks.MovieSceneTransformOrigin.BP_GetTransformOrigin
}; 



// Class MovieSceneTracks.MovieScene3DPathTrack
// Size: 0x68(Inherited: 0x68) 
struct UMovieScene3DPathTrack : public UMovieScene3DConstraintTrack
{

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneCameraShakeTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> CameraShakeSections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieScene3DConstraintSection
// Size: 0x108(Inherited: 0xE0) 
struct UMovieScene3DConstraintSection : public UMovieSceneSection
{
	struct FGuid ConstraintId;  // 0xE0(0x10)
	struct FMovieSceneObjectBindingID ConstraintBindingID;  // 0xF0(0x18)

	void SetConstraintBindingID(struct FMovieSceneObjectBindingID& InConstraintBindingID); // Function MovieSceneTracks.MovieScene3DConstraintSection.SetConstraintBindingID
	struct FMovieSceneObjectBindingID GetConstraintBindingID(); // Function MovieSceneTracks.MovieScene3DConstraintSection.GetConstraintBindingID
}; 



// Class MovieSceneTracks.MovieScene3DPathSection
// Size: 0x1B0(Inherited: 0x108) 
struct UMovieScene3DPathSection : public UMovieScene3DConstraintSection
{
	struct FMovieSceneFloatChannel TimingCurve;  // 0x108(0xA0)
	uint8_t  FrontAxisEnum;  // 0x1A8(0x1)
	uint8_t  UpAxisEnum;  // 0x1A9(0x1)
	char pad_426[2];  // 0x1AA(0x2)
	char bFollow : 1;  // 0x1AC(0x1)
	char bReverse : 1;  // 0x1AC(0x1)
	char bForceUpright : 1;  // 0x1AC(0x1)
	char pad_428_1 : 5;  // 0x1AC(0x1)
	char pad_429[4];  // 0x1AD(0x4)

}; 



// Class MovieSceneTracks.MovieSceneEnumTrack
// Size: 0x90(Inherited: 0x88) 
struct UMovieSceneEnumTrack : public UMovieScenePropertyTrack
{
	struct UEnum* Enum;  // 0x88(0x8)

}; 



// Class MovieSceneTracks.MovieScene3DConstraintTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieScene3DConstraintTrack : public UMovieSceneTrack
{
	struct TArray<struct UMovieSceneSection*> ConstraintSections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieScene3DAttachTrack
// Size: 0x68(Inherited: 0x68) 
struct UMovieScene3DAttachTrack : public UMovieScene3DConstraintTrack
{

}; 



// Class MovieSceneTracks.MovieSceneEulerTransformTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneEulerTransformTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneAudioSection
// Size: 0x330(Inherited: 0xE0) 
struct UMovieSceneAudioSection : public UMovieSceneSection
{
	struct USoundBase* Sound;  // 0xE0(0x8)
	struct FFrameNumber StartFrameOffset;  // 0xE8(0x4)
	float StartOffset;  // 0xEC(0x4)
	float AudioStartTime;  // 0xF0(0x4)
	float AudioDilationFactor;  // 0xF4(0x4)
	float AudioVolume;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct FMovieSceneFloatChannel SoundVolume;  // 0x100(0xA0)
	struct FMovieSceneFloatChannel PitchMultiplier;  // 0x1A0(0xA0)
	struct FMovieSceneActorReferenceData AttachActorData;  // 0x240(0xB0)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool bSuppressSubtitles : 1;  // 0x2F0(0x1)
	char pad_753_1 : 7;  // 0x2F1(0x1)
	bool bOverrideAttenuation : 1;  // 0x2F1(0x1)
	char pad_754[6];  // 0x2F2(0x6)
	struct USoundAttenuation* AttenuationSettings;  // 0x2F8(0x8)
	struct FDelegate OnQueueSubtitles;  // 0x300(0x10)
	struct FMulticastInlineDelegate OnAudioFinished;  // 0x310(0x10)
	struct FMulticastInlineDelegate OnAudioPlaybackPercent;  // 0x320(0x10)

	void SetStartOffset(struct FFrameNumber InStartOffset); // Function MovieSceneTracks.MovieSceneAudioSection.SetStartOffset
	void SetSound(struct USoundBase* InSound); // Function MovieSceneTracks.MovieSceneAudioSection.SetSound
	struct FFrameNumber GetStartOffset(); // Function MovieSceneTracks.MovieSceneAudioSection.GetStartOffset
	struct USoundBase* GetSound(); // Function MovieSceneTracks.MovieSceneAudioSection.GetSound
}; 



// Class MovieSceneTracks.MovieSceneParticleSection
// Size: 0x178(Inherited: 0xE0) 
struct UMovieSceneParticleSection : public UMovieSceneSection
{
	struct FMovieSceneParticleChannel ParticleKeys;  // 0xE0(0x98)

}; 



// Class MovieSceneTracks.MovieSceneMaterialTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneMaterialTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieSceneColorTrack
// Size: 0x90(Inherited: 0x88) 
struct UMovieSceneColorTrack : public UMovieScenePropertyTrack
{
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bIsSlateColor : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 



// Class MovieSceneTracks.MovieScene3DAttachSection
// Size: 0x120(Inherited: 0x108) 
struct UMovieScene3DAttachSection : public UMovieScene3DConstraintSection
{
	struct FName AttachSocketName;  // 0x108(0x8)
	struct FName AttachComponentName;  // 0x110(0x8)
	uint8_t  AttachmentLocationRule;  // 0x118(0x1)
	uint8_t  AttachmentRotationRule;  // 0x119(0x1)
	uint8_t  AttachmentScaleRule;  // 0x11A(0x1)
	uint8_t  DetachmentLocationRule;  // 0x11B(0x1)
	uint8_t  DetachmentRotationRule;  // 0x11C(0x1)
	uint8_t  DetachmentScaleRule;  // 0x11D(0x1)
	char pad_286[2];  // 0x11E(0x2)

}; 



// Class MovieSceneTracks.MovieScene3DTransformSection
// Size: 0x730(Inherited: 0xE0) 
struct UMovieScene3DTransformSection : public UMovieSceneSection
{
	struct FMovieSceneTransformMask TransformMask;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct FMovieSceneFloatChannel Translation[3];  // 0xE8(0x1E0)
	struct FMovieSceneFloatChannel Rotation[3];  // 0x2C8(0x1E0)
	struct FMovieSceneFloatChannel Scale[3];  // 0x4A8(0x1E0)
	struct FMovieSceneFloatChannel ManualWeight;  // 0x688(0xA0)
	char pad_1832[4];  // 0x728(0x4)
	char pad_1836_1 : 7;  // 0x72C(0x1)
	bool bUseQuaternionInterpolation : 1;  // 0x72C(0x1)
	char pad_1837[3];  // 0x72D(0x3)

}; 



// Class MovieSceneTracks.MovieScenePropertyTrack
// Size: 0x88(Inherited: 0x58) 
struct UMovieScenePropertyTrack : public UMovieSceneNameableTrack
{
	struct UMovieSceneSection* SectionToKey;  // 0x58(0x8)
	struct FName PropertyName;  // 0x60(0x8)
	struct FString PropertyPath;  // 0x68(0x10)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x78(0x10)

}; 



// Class MovieSceneTracks.MovieSceneIntegerSection
// Size: 0x170(Inherited: 0xE0) 
struct UMovieSceneIntegerSection : public UMovieSceneSection
{
	struct FMovieSceneIntegerChannel IntegerCurve;  // 0xE0(0x90)

}; 



// Class MovieSceneTracks.MovieSceneFadeTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneFadeTrack : public UMovieSceneFloatTrack
{

}; 



// Class MovieSceneTracks.MovieScene3DTransformTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieScene3DTransformTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Size: 0xF8(Inherited: 0xE0) 
struct UMovieSceneLevelVisibilitySection : public UMovieSceneSection
{
	uint8_t  Visibility;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct TArray<struct FName> LevelNames;  // 0xE8(0x10)

	void SetVisibility(uint8_t  InVisibility); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetVisibility
	void SetLevelNames(struct TArray<struct FName>& InLevelNames); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetLevelNames
	uint8_t  GetVisibility(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetVisibility
	struct TArray<struct FName> GetLevelNames(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetLevelNames
}; 



// Class MovieSceneTracks.MovieSceneActorReferenceSection
// Size: 0x220(Inherited: 0xE0) 
struct UMovieSceneActorReferenceSection : public UMovieSceneSection
{
	struct FMovieSceneActorReferenceData ActorReferenceData;  // 0xE0(0xB0)
	struct FIntegralCurve ActorGuidIndexCurve;  // 0x190(0x80)
	struct TArray<struct FString> ActorGuidStrings;  // 0x210(0x10)

}; 



// Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneActorReferenceTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneAudioTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneAudioTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> AudioSections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieSceneBoolSection
// Size: 0x178(Inherited: 0xE0) 
struct UMovieSceneBoolSection : public UMovieSceneSection
{
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool DefaultValue : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	struct FMovieSceneBoolChannel BoolCurve;  // 0xE8(0x90)

}; 



// Class MovieSceneTracks.MovieSceneBoolTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneBoolTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneByteSection
// Size: 0x178(Inherited: 0xE0) 
struct UMovieSceneByteSection : public UMovieSceneSection
{
	struct FMovieSceneByteChannel ByteCurve;  // 0xE0(0x98)

}; 



// Class MovieSceneTracks.MovieSceneEventTrack
// Size: 0x80(Inherited: 0x58) 
struct UMovieSceneEventTrack : public UMovieSceneNameableTrack
{
	char bFireEventsWhenForwards : 1;  // 0x58(0x1)
	char bFireEventsWhenBackwards : 1;  // 0x58(0x1)
	char pad_88_1 : 6;  // 0x58(0x1)
	char pad_89[4];  // 0x59(0x4)
	uint8_t  EventPosition;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers;  // 0x60(0x10)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x70(0x10)

}; 



// Class MovieSceneTracks.MovieSceneByteTrack
// Size: 0x90(Inherited: 0x88) 
struct UMovieSceneByteTrack : public UMovieScenePropertyTrack
{
	struct UEnum* Enum;  // 0x88(0x8)

}; 



// Class MovieSceneTracks.MovieSceneCameraAnimSection
// Size: 0x120(Inherited: 0xE0) 
struct UMovieSceneCameraAnimSection : public UMovieSceneSection
{
	struct FMovieSceneCameraAnimSectionData AnimData;  // 0xE0(0x20)
	struct UCameraAnim* CameraAnim;  // 0x100(0x8)
	float PlayRate;  // 0x108(0x4)
	float PlayScale;  // 0x10C(0x4)
	float BlendInTime;  // 0x110(0x4)
	float BlendOutTime;  // 0x114(0x4)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool bLooping : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)

}; 



// Class MovieSceneTracks.MovieSceneCameraAnimTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneCameraAnimTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> CameraAnimSections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieSceneTransformTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneTransformTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneEventTriggerSection
// Size: 0x168(Inherited: 0xE0) 
struct UMovieSceneEventTriggerSection : public UMovieSceneEventSectionBase
{
	struct FMovieSceneEventChannel EventChannel;  // 0xE0(0x88)

}; 



// Class MovieSceneTracks.MovieSceneEnumSection
// Size: 0x178(Inherited: 0xE0) 
struct UMovieSceneEnumSection : public UMovieSceneSection
{
	struct FMovieSceneByteChannel EnumCurve;  // 0xE0(0x98)

}; 



// Class MovieSceneTracks.MovieSceneCameraCutSection
// Size: 0x108(Inherited: 0xE0) 
struct UMovieSceneCameraCutSection : public UMovieSceneSection
{
	struct FGuid CameraGuid;  // 0xE0(0x10)
	struct FMovieSceneObjectBindingID CameraBindingID;  // 0xF0(0x18)

	void SetCameraBindingID(struct FMovieSceneObjectBindingID& InCameraBindingID); // Function MovieSceneTracks.MovieSceneCameraCutSection.SetCameraBindingID
	struct FMovieSceneObjectBindingID GetCameraBindingID(); // Function MovieSceneTracks.MovieSceneCameraCutSection.GetCameraBindingID
}; 



// Class MovieSceneTracks.MovieSceneCameraCutTrack
// Size: 0x70(Inherited: 0x58) 
struct UMovieSceneCameraCutTrack : public UMovieSceneNameableTrack
{
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bCanBlend : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x60(0x10)

}; 



// Class MovieSceneTracks.MovieSceneCameraShakeSection
// Size: 0x120(Inherited: 0xE0) 
struct UMovieSceneCameraShakeSection : public UMovieSceneSection
{
	struct FMovieSceneCameraShakeSectionData ShakeData;  // 0xE0(0x20)
	UCameraShake* ShakeClass;  // 0x100(0x8)
	float PlayScale;  // 0x108(0x4)
	char ECameraAnimPlaySpace PlaySpace;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	struct FRotator UserDefinedPlaySpace;  // 0x110(0xC)
	char pad_284[4];  // 0x11C(0x4)

}; 



// Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Size: 0x68(Inherited: 0x68) 
struct UMovieSceneCinematicShotTrack : public UMovieSceneSubTrack
{

}; 



// Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Size: 0x70(Inherited: 0x68) 
struct UMovieSceneComponentMaterialTrack : public UMovieSceneMaterialTrack
{
	int32_t MaterialIndex;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 



// Class MovieSceneTracks.MovieSceneCinematicShotSection
// Size: 0x180(Inherited: 0x158) 
struct UMovieSceneCinematicShotSection : public UMovieSceneSubSection
{
	struct FString ShotDisplayName;  // 0x158(0x10)
	struct FText DisplayName;  // 0x168(0x18)

	void SetShotDisplayName(struct FString InShotDisplayName); // Function MovieSceneTracks.MovieSceneCinematicShotSection.SetShotDisplayName
	struct FString GetShotDisplayName(); // Function MovieSceneTracks.MovieSceneCinematicShotSection.GetShotDisplayName
}; 



// Class MovieSceneTracks.MovieSceneParameterSection
// Size: 0x140(Inherited: 0xE0) 
struct UMovieSceneParameterSection : public UMovieSceneSection
{
	struct TArray<struct FBoolParameterNameAndCurve> BoolParameterNamesAndCurves;  // 0xE0(0x10)
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves;  // 0xF0(0x10)
	struct TArray<struct FVector2DParameterNameAndCurves> Vector2DParameterNamesAndCurves;  // 0x100(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves;  // 0x110(0x10)
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves;  // 0x120(0x10)
	struct TArray<struct FTransformParameterNameAndCurves> TransformParameterNamesAndCurves;  // 0x130(0x10)

}; 



// Class MovieSceneTracks.MovieSceneColorSection
// Size: 0x360(Inherited: 0xE0) 
struct UMovieSceneColorSection : public UMovieSceneSection
{
	struct FMovieSceneFloatChannel RedCurve;  // 0xE0(0xA0)
	struct FMovieSceneFloatChannel GreenCurve;  // 0x180(0xA0)
	struct FMovieSceneFloatChannel BlueCurve;  // 0x220(0xA0)
	struct FMovieSceneFloatChannel AlphaCurve;  // 0x2C0(0xA0)

}; 



// Class MovieSceneTracks.MovieSceneEventRepeaterSection
// Size: 0x108(Inherited: 0xE0) 
struct UMovieSceneEventRepeaterSection : public UMovieSceneEventSectionBase
{
	struct FMovieSceneEvent Event;  // 0xE0(0x28)

}; 



// Class MovieSceneTracks.MovieSceneEventSection
// Size: 0x1E0(Inherited: 0xE0) 
struct UMovieSceneEventSection : public UMovieSceneSection
{
	struct FNameCurve Events;  // 0xE0(0x78)
	struct FMovieSceneEventSectionData EventData;  // 0x158(0x88)

}; 



// Class MovieSceneTracks.MovieSceneFadeSection
// Size: 0x198(Inherited: 0x180) 
struct UMovieSceneFadeSection : public UMovieSceneFloatSection
{
	struct FLinearColor FadeColor;  // 0x180(0x10)
	char bFadeAudio : 1;  // 0x190(0x1)
	char pad_400_1 : 7;  // 0x190(0x1)
	char pad_401[8];  // 0x191(0x8)

}; 



// Class MovieSceneTracks.MovieSceneFloatSection
// Size: 0x180(Inherited: 0xE0) 
struct UMovieSceneFloatSection : public UMovieSceneSection
{
	struct FMovieSceneFloatChannel FloatCurve;  // 0xE0(0xA0)

}; 



// Class MovieSceneTracks.MovieSceneSpawnSection
// Size: 0x178(Inherited: 0x178) 
struct UMovieSceneSpawnSection : public UMovieSceneBoolSection
{

}; 



// Class MovieSceneTracks.MovieSceneFloatTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneFloatTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneIntegerTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneIntegerTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneLevelVisibilityTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Size: 0x70(Inherited: 0x68) 
struct UMovieSceneMaterialParameterCollectionTrack : public UMovieSceneMaterialTrack
{
	struct UMaterialParameterCollection* MPC;  // 0x68(0x8)

}; 



// Class MovieSceneTracks.MovieSceneObjectPropertySection
// Size: 0x1A0(Inherited: 0xE0) 
struct UMovieSceneObjectPropertySection : public UMovieSceneSection
{
	struct FMovieSceneObjectPathChannel ObjectChannel;  // 0xE0(0xC0)

}; 



// Class MovieSceneTracks.MovieSceneSpawnTrack
// Size: 0x78(Inherited: 0x58) 
struct UMovieSceneSpawnTrack : public UMovieSceneTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x58(0x10)
	struct FGuid ObjectGuid;  // 0x68(0x10)

}; 



// Class MovieSceneTracks.MovieSceneObjectPropertyTrack
// Size: 0x90(Inherited: 0x88) 
struct UMovieSceneObjectPropertyTrack : public UMovieScenePropertyTrack
{
	UObject* PropertyClass;  // 0x88(0x8)

}; 



// Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneParticleParameterTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieSceneParticleTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneParticleTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> ParticleSections;  // 0x58(0x10)

}; 



// Class MovieSceneTracks.MovieScenePrimitiveMaterialSection
// Size: 0x1A0(Inherited: 0xE0) 
struct UMovieScenePrimitiveMaterialSection : public UMovieSceneSection
{
	struct FMovieSceneObjectPathChannel MaterialChannel;  // 0xE0(0xC0)

}; 



// Class MovieSceneTracks.MovieScenePrimitiveMaterialTrack
// Size: 0x90(Inherited: 0x88) 
struct UMovieScenePrimitiveMaterialTrack : public UMovieScenePropertyTrack
{
	int32_t MaterialIndex;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)

}; 



// Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Size: 0x1E0(Inherited: 0xE0) 
struct UMovieSceneSkeletalAnimationSection : public UMovieSceneSection
{
	struct FMovieSceneSkeletalAnimationParams Params;  // 0xE0(0xD8)
	struct UAnimSequence* AnimSequence;  // 0x1B8(0x8)
	struct UAnimSequenceBase* Animation;  // 0x1C0(0x8)
	float StartOffset;  // 0x1C8(0x4)
	float EndOffset;  // 0x1CC(0x4)
	float PlayRate;  // 0x1D0(0x4)
	char bReverse : 1;  // 0x1D4(0x1)
	char pad_468_1 : 7;  // 0x1D4(0x1)
	char pad_469[4];  // 0x1D5(0x4)
	struct FName SlotName;  // 0x1D8(0x8)

}; 



// Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Size: 0x70(Inherited: 0x58) 
struct UMovieSceneSkeletalAnimationTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> AnimationSections;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bUseLegacySectionIndexBlend : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 



// Class MovieSceneTracks.MovieSceneSlomoSection
// Size: 0x180(Inherited: 0x180) 
struct UMovieSceneSlomoSection : public UMovieSceneFloatSection
{

}; 



// Class MovieSceneTracks.MovieSceneSlomoTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneSlomoTrack : public UMovieSceneFloatTrack
{

}; 



// Class MovieSceneTracks.MovieSceneStringSection
// Size: 0x180(Inherited: 0xE0) 
struct UMovieSceneStringSection : public UMovieSceneSection
{
	struct FMovieSceneStringChannel StringCurve;  // 0xE0(0xA0)

}; 



// Class MovieSceneTracks.MovieSceneStringTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneStringTrack : public UMovieScenePropertyTrack
{

}; 



// Class MovieSceneTracks.MovieSceneVectorTrack
// Size: 0x90(Inherited: 0x88) 
struct UMovieSceneVectorTrack : public UMovieScenePropertyTrack
{
	int32_t NumChannelsUsed;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)

}; 



// Class MovieSceneTracks.MovieSceneVisibilityTrack
// Size: 0x88(Inherited: 0x88) 
struct UMovieSceneVisibilityTrack : public UMovieSceneBoolTrack
{

}; 



