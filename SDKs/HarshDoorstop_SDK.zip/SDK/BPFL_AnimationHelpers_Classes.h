#pragma once 
#include <BPFL_AnimationHelpers_Structs.h>
 
 
 
// BlueprintGeneratedClass BPFL_AnimationHelpers.BPFL_AnimationHelpers_C
// Size: 0x28(Inherited: 0x28) 
struct UBPFL_AnimationHelpers_C : public UBlueprintFunctionLibrary
{

	void RInterp To Smooth(struct FRotator A, struct FRotator B, float DeltaTime, float InterpSpeed, struct UObject* __WorldContext, struct FRotator& Return Value); // Function BPFL_AnimationHelpers.BPFL_AnimationHelpers_C.RInterp To Smooth
	void VInterp To Smooth(struct FVector A, struct FVector B, float DeltaTime, float InterpSpeed, struct UObject* __WorldContext, struct FVector& Return Value); // Function BPFL_AnimationHelpers.BPFL_AnimationHelpers_C.VInterp To Smooth
}; 



