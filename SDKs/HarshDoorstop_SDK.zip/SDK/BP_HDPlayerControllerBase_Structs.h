#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerJoinSquad
// Size: 0x8(Inherited: 0x0) 
struct FServerJoinSquad
{
	struct AHDSquadState* SquadToJoin;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ExecuteUbergraph_BP_HDPlayerControllerBase
// Size: 0x588(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDPlayerControllerBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AHDSquadState* K2Node_CustomEvent_SquadToJoin;  // 0x8(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_JoinSquad_bJoinSuccess : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_LeaveCurrentSquad_bLeaveSuccess : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AHDSquadState* K2Node_CustomEvent_Squad_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_CustomEvent_bLocked : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x34(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	UObject* Temp_class_Variable;  // 0x40(0x8)
	struct AHDSquadState* K2Node_CustomEvent_Squad;  // 0x48(0x8)
	struct AHDPlayerState* K2Node_CustomEvent_MemberToRemove;  // 0x50(0x8)
	UUserWidget* K2Node_ClassDynamicCast_AsUser_Widget;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_KickSquadMember_bRemoveSuccess : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	UObject* K2Node_CustomEvent_Loaded;  // 0x68(0x8)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x70(0x18)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x88(0x18)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0xA8(0x18)
	struct TArray<struct ABP_HDPlayerCharacterBase_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0xC0(0x10)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0xD0(0x18)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xE8(0x4)
	char pad_236_1 : 7;  // 0xEC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xEC(0x1)
	char pad_237[3];  // 0xED(0x3)
	struct FKey K2Node_InputKeyEvent_Key_4;  // 0xF0(0x18)
	struct UUserWidget* CallFunc_Create_ReturnValue;  // 0x108(0x8)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x110(0x10)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x120(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x131(0x1)
	char pad_306_1 : 7;  // 0x132(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x132(0x1)
	char pad_307[5];  // 0x133(0x5)
	struct TArray<struct ABP_HDCapturePointBase_C*> CallFunc_GetAllActorsOfClass_OutActors_2;  // 0x138(0x10)
	struct ABP_HDCapturePointBase_C* CallFunc_Array_Get_Item;  // 0x148(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x150(0x4)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x154(0x1)
	char pad_341[3];  // 0x155(0x3)
	struct AHDTeamState* CallFunc_GetHDTeamState_TeamState;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x160(0x1)
	char pad_353[7];  // 0x161(0x7)
	struct AHDPlatoonState* K2Node_CustomEvent_ForPlatoon;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_InternalCreateUnnamedSquad_bSuccess : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct AHDSquadState* CallFunc_InternalCreateUnnamedSquad_NewSquad;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_HasReachedMaxSquadLimit_ReturnValue : 1;  // 0x180(0x1)
	char pad_385_1 : 7;  // 0x181(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x181(0x1)
	char pad_386_1 : 7;  // 0x182(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x182(0x1)
	char pad_387[5];  // 0x183(0x5)
	struct UDFMinimap* CallFunc_GetMinimapWidget_MinimapWidget;  // 0x188(0x8)
	char K2Node_Event_LastTeamNum;  // 0x190(0x1)
	char K2Node_Event_NewTeamNum;  // 0x191(0x1)
	char pad_402[6];  // 0x192(0x6)
	struct TArray<struct ABP_HDCapturePointBase_C*> CallFunc_GetAllActorsOfClass_OutActors_3;  // 0x198(0x10)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x1A8(0x18)
	struct ABP_HDCapturePointBase_C* CallFunc_Array_Get_Item_2;  // 0x1C0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x1C8(0x4)
	char pad_460_1 : 7;  // 0x1CC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x1CC(0x1)
	char pad_461_1 : 7;  // 0x1CD(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x1CD(0x1)
	char pad_462_1 : 7;  // 0x1CE(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x1CE(0x1)
	char pad_463[1];  // 0x1CF(0x1)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x1D0(0x10)
	struct AArcBaseVehicle* K2Node_CustomEvent_Vehicle_2;  // 0x1E0(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x1E8(0x8)
	struct AArcBaseVehicle* K2Node_CustomEvent_Vehicle;  // 0x1F0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1F8(0xC)
	char pad_516[4];  // 0x204(0x4)
	struct ADFBasePlayerCharacter* K2Node_DynamicCast_AsDFBase_Player_Character;  // 0x208(0x8)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x210(0x1)
	char pad_529[7];  // 0x211(0x7)
	struct UCameraComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x218(0x8)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x220(0xC)
	char pad_556[4];  // 0x22C(0x4)
	struct UArcVehiclePlayerSeatComponent* CallFunc_GetComponentByClass_ReturnValue_2;  // 0x230(0x8)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x238(0xC)
	char pad_580_1 : 7;  // 0x244(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x248(0xC)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x254(0x88)
	char pad_732_1 : 7;  // 0x2DC(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x2DC(0x1)
	char pad_733[3];  // 0x2DD(0x3)
	struct AArcBaseVehicle* CallFunc_GetVehicleFromSeatConfig_ReturnValue;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool CallFunc_IsSeatRefValid_ReturnValue : 1;  // 0x2E8(0x1)
	char pad_745_1 : 7;  // 0x2E9(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x2E9(0x1)
	char pad_746_1 : 7;  // 0x2EA(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x2EA(0x1)
	char pad_747[1];  // 0x2EB(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x2EC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x2F0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x2F4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x300(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x30C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x318(0xC)
	char pad_804[4];  // 0x324(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x328(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x330(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x338(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x340(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x348(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x34C(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x350(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x35C(0xC)
	struct AArcBaseVehicle* K2Node_DynamicCast_AsArc_Base_Vehicle;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x370(0x1)
	char pad_881[7];  // 0x371(0x7)
	struct AArcBaseVehicle* K2Node_DynamicCast_AsArc_Base_Vehicle_2;  // 0x378(0x8)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x380(0x1)
	char pad_897[7];  // 0x381(0x7)
	struct FKey K2Node_InputActionEvent_Key;  // 0x388(0x18)
	struct FKey Temp_struct_Variable;  // 0x3A0(0x18)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_3;  // 0x3B8(0x8)
	struct FKey K2Node_InputActionEvent_Key_4;  // 0x3C0(0x18)
	char pad_984_1 : 7;  // 0x3D8(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x3D8(0x1)
	char pad_985[7];  // 0x3D9(0x7)
	struct AArcVehiclePawn* K2Node_DynamicCast_AsArc_Vehicle_Pawn;  // 0x3E0(0x8)
	char pad_1000_1 : 7;  // 0x3E8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x3E8(0x1)
	char pad_1001[7];  // 0x3E9(0x7)
	struct UArcVehiclePlayerSeatComponent* CallFunc_GetComponentByClass_ReturnValue_3;  // 0x3F0(0x8)
	struct AArcBaseVehicle* CallFunc_GetOwningVehicle_ReturnValue;  // 0x3F8(0x8)
	char pad_1024_1 : 7;  // 0x400(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x400(0x1)
	char pad_1025_1 : 7;  // 0x401(0x1)
	bool CallFunc_IsSeatRefValid_ReturnValue_2 : 1;  // 0x401(0x1)
	char pad_1026[6];  // 0x402(0x6)
	struct AArcBaseVehicle* CallFunc_GetVehicleFromSeatConfig_ReturnValue_2;  // 0x408(0x8)
	int32_t K2Node_CustomEvent_Seat;  // 0x410(0x4)
	char pad_1044[4];  // 0x414(0x4)
	struct FKey K2Node_InputActionEvent_Key_5;  // 0x418(0x18)
	char pad_1072_1 : 7;  // 0x430(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x430(0x1)
	char pad_1073_1 : 7;  // 0x431(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x431(0x1)
	char pad_1074[6];  // 0x432(0x6)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x438(0x8)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x440(0x4)
	char pad_1092[4];  // 0x444(0x4)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase;  // 0x448(0x8)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x450(0x1)
	char pad_1105_1 : 7;  // 0x451(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x451(0x1)
	char pad_1106[2];  // 0x452(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x454(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x458(0x4)
	char pad_1116_1 : 7;  // 0x45C(0x1)
	bool CallFunc_IsValidSoftClassReference_ReturnValue : 1;  // 0x45C(0x1)
	char pad_1117[3];  // 0x45D(0x3)
	struct ABP_HDPlayerCharacterBase_C* CallFunc_Array_Get_Item_3;  // 0x460(0x8)
	char pad_1128_1 : 7;  // 0x468(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x468(0x1)
	char pad_1129[7];  // 0x469(0x7)
	struct APawn* K2Node_Event_NewPawn;  // 0x470(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x478(0x10)
	struct ADFBaseCharacter* K2Node_DynamicCast_AsDFBase_Character;  // 0x488(0x8)
	char pad_1168_1 : 7;  // 0x490(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x490(0x1)
	char pad_1169[7];  // 0x491(0x7)
	struct APawn* K2Node_CustomEvent_VictimPawn;  // 0x498(0x8)
	struct AController* K2Node_CustomEvent_VictimController;  // 0x4A0(0x8)
	float K2Node_CustomEvent_KillingDamage;  // 0x4A8(0x4)
	char pad_1196[4];  // 0x4AC(0x4)
	struct FDamageEvent K2Node_CustomEvent_DamageEvent;  // 0x4B0(0x10)
	struct APawn* K2Node_CustomEvent_InstigatingPawn;  // 0x4C0(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x4C8(0x8)
	struct ADFBaseCharacter* K2Node_DynamicCast_AsDFBase_Character_2;  // 0x4D0(0x8)
	char pad_1240_1 : 7;  // 0x4D8(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x4D8(0x1)
	char pad_1241[3];  // 0x4D9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x4DC(0x10)
	char pad_1260[4];  // 0x4EC(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_4;  // 0x4F0(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base_2;  // 0x4F8(0x8)
	char pad_1280_1 : 7;  // 0x500(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x500(0x1)
	char pad_1281_1 : 7;  // 0x501(0x1)
	bool CallFunc_IsLocalController_ReturnValue_2 : 1;  // 0x501(0x1)
	char pad_1282[6];  // 0x502(0x6)
	struct AActor* K2Node_Event_EndGameFocus;  // 0x508(0x8)
	char pad_1296_1 : 7;  // 0x510(0x1)
	bool K2Node_Event_bIsWinner : 1;  // 0x510(0x1)
	char pad_1297_1 : 7;  // 0x511(0x1)
	bool CallFunc_IsLocalController_ReturnValue_3 : 1;  // 0x511(0x1)
	char pad_1298[2];  // 0x512(0x2)
	struct FLinearColor CallFunc_MakeColor_ReturnValue;  // 0x514(0x10)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_2;  // 0x524(0x10)
	char pad_1332[4];  // 0x534(0x4)
	struct AHUD* CallFunc_GetHUD_ReturnValue_2;  // 0x538(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase_2;  // 0x540(0x8)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x548(0x1)
	char pad_1353_1 : 7;  // 0x549(0x1)
	bool CallFunc_IsTextChatHistoryVisible_bVisible : 1;  // 0x549(0x1)
	char pad_1354[2];  // 0x54A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x54C(0x10)
	char pad_1372_1 : 7;  // 0x55C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x55C(0x1)
	char pad_1373[3];  // 0x55D(0x3)
	struct AHUD* CallFunc_GetHUD_ReturnValue_3;  // 0x560(0x8)
	struct AHUD* CallFunc_GetHUD_ReturnValue_4;  // 0x568(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase_3;  // 0x570(0x8)
	char pad_1400_1 : 7;  // 0x578(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x578(0x1)
	char pad_1401[7];  // 0x579(0x7)
	struct APawn* K2Node_Event_UnpossessedPawn;  // 0x580(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceivePossessPawn
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessPawn : public FReceivePossessPawn
{
	struct APawn* NewPawn;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F2_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_F2_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveGameHasEnded
// Size: 0x9(Inherited: 0x10) 
struct FReceiveGameHasEnded : public FReceiveGameHasEnded
{
	struct AActor* EndGameFocus;  // 0x0(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bIsWinner : 1;  // 0x8(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationRollLimits
// Size: 0x5C(Inherited: 0x0) 
struct FSetCamViewRotationRollLimits
{
	float ViewRollMin;  // 0x0(0x4)
	float ViewRollMax;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bRelativeToPawnRotation : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FRotator PawnRotation;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_BreakRotator_Roll;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x20(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x24(0x4)
	float CallFunc_NormalizeAxis_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x30(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x40(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float K2Node_Select_Default;  // 0x54(0x4)
	float K2Node_Select_Default_2;  // 0x58(0x4)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.CharacterDeath
// Size: 0x38(Inherited: 0x0) 
struct FCharacterDeath
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveUnpossessPawn
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnpossessPawn : public FReceiveUnpossessPawn
{
	struct APawn* UnpossessedPawn;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_ChatHistoryToggle_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ChatHistoryToggle_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.Server_RequestSeatChange
// Size: 0x4(Inherited: 0x0) 
struct FServer_RequestSeatChange
{
	int32_t Seat;  // 0x0(0x4)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.HideHUD
// Size: 0x9(Inherited: 0x0) 
struct FHideHUD
{
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RequestExitVehicle
// Size: 0x8(Inherited: 0x0) 
struct FRequestExitVehicle
{
	struct AArcBaseVehicle* Vehicle;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.TryGetInVehicle
// Size: 0x8(Inherited: 0x0) 
struct FTryGetInVehicle
{
	struct AArcBaseVehicle* Vehicle;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SpawnVehicleAtPlayer
// Size: 0x90(Inherited: 0x0) 
struct FSpawnVehicleAtPlayer
{
	ABP_HDVehicleBase_C* VehicleClass;  // 0x0(0x8)
	struct FVector CallFunc_GetActorEyesViewPoint_OutLocation;  // 0x8(0xC)
	struct FRotator CallFunc_GetActorEyesViewPoint_OutRotation;  // 0x14(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x20(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x38(0xC)
	char pad_68[12];  // 0x44(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x50(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x80(0x8)
	struct ABP_HDVehicleBase_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x88(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceivePlayerTeamNumUpdated
// Size: 0x2(Inherited: 0x2) 
struct FReceivePlayerTeamNumUpdated : public FReceivePlayerTeamNumUpdated
{
	char LastTeamNum;  // 0x0(0x1)
	char NewTeamNum;  // 0x1(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationYawLimits
// Size: 0x5C(Inherited: 0x0) 
struct FSetCamViewRotationYawLimits
{
	float ViewYawMin;  // 0x0(0x4)
	float ViewYawMax;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bRelativeToPawnRotation : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FRotator PawnRotation;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_BreakRotator_Roll;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x20(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x24(0x4)
	float CallFunc_NormalizeAxis_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x3C(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x48(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float K2Node_Select_Default;  // 0x54(0x4)
	float K2Node_Select_Default_2;  // 0x58(0x4)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerKickSquadMember
// Size: 0x10(Inherited: 0x0) 
struct FServerKickSquadMember
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct AHDPlayerState* MemberToRemove;  // 0x8(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetHDPlayerState
// Size: 0x11(Inherited: 0x0) 
struct FGetHDPlayerState
{
	struct AHDPlayerState* PlayerState;  // 0x0(0x8)
	struct AHDPlayerState* K2Node_DynamicCast_AsHDPlayer_State;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Fire_K2Node_InputActionEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Fire_K2Node_InputActionEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerSetSquadLockedState
// Size: 0x9(Inherited: 0x0) 
struct FServerSetSquadLockedState
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bLocked : 1;  // 0x8(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerCreateAndJoinUserSquadUnnamed
// Size: 0x8(Inherited: 0x0) 
struct FServerCreateAndJoinUserSquadUnnamed
{
	struct AHDPlatoonState* ForPlatoon;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnLoaded_97A2A56D4425648AEE60ECA073085E53
// Size: 0x8(Inherited: 0x0) 
struct FOnLoaded_97A2A56D4425648AEE60ECA073085E53
{
	UObject* Loaded;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F4_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_F4_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationYawLimits
// Size: 0x8(Inherited: 0x0) 
struct FRestoreCamDefaultViewRotationYawLimits
{
	APlayerCameraManager* CallFunc_GetObjectClass_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.KickSquadMember
// Size: 0x1B(Inherited: 0x0) 
struct FKickSquadMember
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct AHDPlayerState* MemberToRemove;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bRemoveSuccess : 1;  // 0x10(0x1)
	uint8_t  Temp_byte_Variable;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x12(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_UnregisterSquadMember_ReturnValue : 1;  // 0x16(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x17(0x1)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsSquadLeader_bSquadLeader : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x19(0x1)
	uint8_t  K2Node_Select_Default;  // 0x1A(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Use_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Use_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F3_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_F3_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetJoystickDirection
// Size: 0x34(Inherited: 0x0) 
struct FGetJoystickDirection
{
	char EJoystickTypes Stick;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector2D StickInput;  // 0x4(0x8)
	float CallFunc_GetInputAxisKeyValue_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_GetInputAxisKeyValue_ReturnValue_2;  // 0x14(0x4)
	float CallFunc_GetInputAxisKeyValue_ReturnValue_3;  // 0x18(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x1C(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_GetInputAxisKeyValue_ReturnValue_4;  // 0x28(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_2;  // 0x2C(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F1_K2Node_InputKeyEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_F1_K2Node_InputKeyEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_DeployMenu_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_DeployMenu_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Fire_K2Node_InputActionEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Fire_K2Node_InputActionEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadAndActivateDeployMenu
// Size: 0x20(Inherited: 0x0) 
struct FLoadAndActivateDeployMenu
{
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x0(0x8)
	struct UHDGameInstance* K2Node_DynamicCast_AsHDGame_Instance;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UWBP_DeployMenu_C* CallFunc_CreateAndActivate_ReturnValue;  // 0x18(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadDeployMenu
// Size: 0x20(Inherited: 0x0) 
struct FLoadDeployMenu
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UWBP_DeployMenu_C* CallFunc_Create_ReturnValue;  // 0x18(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.UnloadDeployMenu
// Size: 0x2(Inherited: 0x0) 
struct FUnloadDeployMenu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationPitchLimits
// Size: 0x5C(Inherited: 0x0) 
struct FSetCamViewRotationPitchLimits
{
	float ViewPitchMin;  // 0x0(0x4)
	float ViewPitchMax;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bRelativeToPawnRotation : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FRotator PawnRotation;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_BreakRotator_Roll;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x20(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x24(0x4)
	float CallFunc_NormalizeAxis_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x30(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x40(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	float K2Node_Select_Default;  // 0x54(0x4)
	float K2Node_Select_Default_2;  // 0x58(0x4)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.DeployMenuToggle
// Size: 0x39(Inherited: 0x0) 
struct FDeployMenuToggle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShowMenu : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bForce : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsVictoryMenuShown_bShown : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UHDGameInstance* K2Node_DynamicCast_AsHDGame_Instance;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsInViewport_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x27(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UDFMenuManager* CallFunc_GetMenuManager_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x38(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.JoinSquad
// Size: 0x11(Inherited: 0x0) 
struct FJoinSquad
{
	struct AHDSquadState* SquadToJoin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bJoinSuccess : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_CanJoinSquad_bJoinableSquad : 1;  // 0xA(0x1)
	uint8_t  Temp_byte_Variable;  // 0xB(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xE(0x1)
	uint8_t  K2Node_Select_Default;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_RegisterPlayerSquadMember_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadDeathScreen
// Size: 0x9(Inherited: 0x0) 
struct FLoadDeathScreen
{
	struct UWBP_DeathScreen_C* CallFunc_Create_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.DeathScreenToggle
// Size: 0x5(Inherited: 0x0) 
struct FDeathScreenToggle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShow : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_AddToPlayerScreen_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_IsInViewport_ReturnValue : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x4(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.IsVictoryMenuShown
// Size: 0x3(Inherited: 0x0) 
struct FIsVictoryMenuShown
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShown : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsInViewport_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetMinimapWidget
// Size: 0xA(Inherited: 0x0) 
struct FGetMinimapWidget
{
	struct UDFMinimap* MinimapWidget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x9(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetTeamKits
// Size: 0xA9(Inherited: 0x0) 
struct FGetTeamKits
{
	struct TSet<struct UHDKit*> TeamKits;  // 0x0(0x50)
	struct TSet<struct UHDKit*> K2Node_MakeSet_Set;  // 0x50(0x50)
	struct AHDTeamState* K2Node_DynamicCast_AsTeam_State__HD_;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA8(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ShowHUD
// Size: 0x9(Inherited: 0x0) 
struct FShowHUD
{
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetHDTeamState
// Size: 0x11(Inherited: 0x0) 
struct FGetHDTeamState
{
	struct AHDTeamState* TeamState;  // 0x0(0x8)
	struct AHDTeamState* K2Node_DynamicCast_AsTeam_State__HD_;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetSquadLockedState
// Size: 0x11(Inherited: 0x0) 
struct FSetSquadLockedState
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bLocked : 1;  // 0x8(0x1)
	uint8_t  Temp_byte_Variable;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Temp_bool_Variable : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_IsSquadLeader_bSquadLeader : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xF(0x1)
	uint8_t  K2Node_Select_Default;  // 0x10(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InternalCreateUnnamedSquad
// Size: 0x1F8(Inherited: 0x0) 
struct FInternalCreateUnnamedSquad
{
	struct AHDPlatoonState* ForPlatoon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bJoinSquadAfterCreation : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bStartLocked : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bSuccess : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)
	struct AHDSquadState* NewSquad;  // 0x10(0x8)
	int32_t PlayerPrevSquadIdx;  // 0x18(0x4)
	int32_t IdxToUseForName;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Temp_text_Variable;  // 0x28(0x18)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x40(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x50(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x68(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xA8(0x40)
	struct AHDPlayerState* Temp_object_Variable;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0xF1(0x1)
	char pad_242[6];  // 0xF2(0x6)
	struct AHDPlayerState* CallFunc_GetHDPlayerState_PlayerState;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct AHDPlayerState* K2Node_Select_Default;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct FText CallFunc_MakeLiteralText_ReturnValue;  // 0x118(0x18)
	struct AHDSquadState* CallFunc_AddSquad_ReturnValue;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x138(0x1)
	char pad_313[3];  // 0x139(0x3)
	int32_t K2Node_Select_Default_2;  // 0x13C(0x4)
	int32_t K2Node_Select_Default_3;  // 0x140(0x4)
	char pad_324_1 : 7;  // 0x144(0x1)
	bool CallFunc_TextIsEmptyOrWhitespace_ReturnValue : 1;  // 0x144(0x1)
	char pad_325[3];  // 0x145(0x3)
	struct FText CallFunc_GetPredefinedSquadNameByIndex_SquadName;  // 0x148(0x18)
	struct FText K2Node_Select_Default_4;  // 0x160(0x18)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x178(0x1)
	char pad_377[7];  // 0x179(0x7)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x180(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x1C0(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x1D0(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x1E8(0x10)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.CanJoinSquad
// Size: 0x1E(Inherited: 0x0) 
struct FCanJoinSquad
{
	struct AHDSquadState* SquadToJoin;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bJoinableSquad : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct AHDTeamState* CallFunc_GetHDTeamState_TeamState;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_CanRegisterPlayerSquadMember_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_IsPlayerRegisteredSquadMember_ReturnValue : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1D(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.IsSquadLeader
// Size: 0x1A(Inherited: 0x0) 
struct FIsSquadLeader
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSquadLeader : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct AHDPlayerState* CallFunc_GetHDPlayerState_PlayerState;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationRollLimits
// Size: 0x8(Inherited: 0x0) 
struct FRestoreCamDefaultViewRotationRollLimits
{
	APlayerCameraManager* CallFunc_GetObjectClass_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LeaveCurrentSquad
// Size: 0x14(Inherited: 0x0) 
struct FLeaveCurrentSquad
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLeaveSuccess : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x3(0x1)
	uint8_t  Temp_byte_Variable;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct AHDPlayerState* CallFunc_GetHDPlayerState_PlayerState;  // 0x8(0x8)
	uint8_t  K2Node_Select_Default;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_UnregisterPlayerSquadMember_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x13(0x1)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationLimits
// Size: 0x40(Inherited: 0x0) 
struct FSetCamViewRotationLimits
{
	struct FRotator ViewRotMin;  // 0x0(0xC)
	struct FRotator ViewRotMax;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bRelativeToPawnRotation : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FRotator PawnRotation;  // 0x1C(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x28(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x2C(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x30(0x4)
	float CallFunc_BreakRotator_Roll_2;  // 0x34(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x38(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x3C(0x4)

}; 
// Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationPitchLimits
// Size: 0x8(Inherited: 0x0) 
struct FRestoreCamDefaultViewRotationPitchLimits
{
	APlayerCameraManager* CallFunc_GetObjectClass_ReturnValue;  // 0x0(0x8)

}; 
