#pragma once 
#include <WBP_ModifierSetting_CheckBox_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C
// Size: 0x300(Inherited: 0x230) 
struct UWBP_ModifierSetting_CheckBox_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UCheckBox* ModifierCheckBox;  // 0x238(0x8)
	struct USizeBox* ModifierSBox;  // 0x240(0x8)
	struct UWBP_ModifierSettingBox_C* ModifierSetting;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool bDefaultIsChecked : 1;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct FText SettingText;  // 0x258(0x18)
	struct FMulticastInlineDelegate OnCheckStateChanged;  // 0x270(0x10)
	struct FFModifierTextStyle SettingTextStyle;  // 0x280(0x78)
	struct FVector2D CheckBoxMinSize;  // 0x2F8(0x8)

	void GetSettingText(struct FText& SettingText); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.GetSettingText
	void SetSettingText(struct FText InSettingText); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.SetSettingText
	void PreConstruct(bool IsDesignTime); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.PreConstruct
	void BndEvt__ModifierCheckBox_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.BndEvt__ModifierCheckBox_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature
	void OnInitialized(); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.OnInitialized
	void ExecuteUbergraph_WBP_ModifierSetting_CheckBox(int32_t EntryPoint); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.ExecuteUbergraph_WBP_ModifierSetting_CheckBox
	void OnCheckStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_ModifierSetting_CheckBox.WBP_ModifierSetting_CheckBox_C.OnCheckStateChanged__DelegateSignature
}; 



