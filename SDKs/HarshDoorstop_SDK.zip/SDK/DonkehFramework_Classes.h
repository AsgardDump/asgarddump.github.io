#pragma once 
#include <DonkehFramework_Structs.h>
 
 
 
// Class DonkehFramework.DFCfgDataManager
// Size: 0x78(Inherited: 0x28) 
struct UDFCfgDataManager : public UObject
{
	char pad_40[80];  // 0x28(0x50)

}; 



// Class DonkehFramework.DFSingleActionWeapAnimInstInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFSingleActionWeapAnimInstInterface : public UInterface
{

	float PlayActionMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFSingleActionWeapAnimInstInterface.PlayActionMontage
}; 



// Class DonkehFramework.DFMapRotationManager
// Size: 0x90(Inherited: 0x78) 
struct UDFMapRotationManager : public UDFCfgDataManager
{
	char pad_120[24];  // 0x78(0x18)

}; 



// Class DonkehFramework.DFBaseAmmoClip
// Size: 0x3C0(Inherited: 0x3A8) 
struct ADFBaseAmmoClip : public ADFBaseItem
{
	struct ADFBaseGun* GunOwner;  // 0x3A8(0x8)
	int32_t CurrentClipAmmo;  // 0x3B0(0x4)
	int32_t StartingClipAmmo;  // 0x3B4(0x4)
	int32_t MaxClipAmmo;  // 0x3B8(0x4)
	char pad_956[4];  // 0x3BC(0x4)

	int32_t StoreAmmoInInventory(struct UDFInventoryComponent* AmmoStore, int32_t AmmoAmt, ADFBaseAmmoClip*& AmmoType); // Function DonkehFramework.DFBaseAmmoClip.StoreAmmoInInventory
	void StoreAmmo(int32_t AmmoToStore); // Function DonkehFramework.DFBaseAmmoClip.StoreAmmo
	void SetOwningGun(struct ADFBaseGun* NewOwner); // Function DonkehFramework.DFBaseAmmoClip.SetOwningGun
	bool IsLoaded(); // Function DonkehFramework.DFBaseAmmoClip.IsLoaded
	int32_t GetStartingClipAmmo(); // Function DonkehFramework.DFBaseAmmoClip.GetStartingClipAmmo
	int32_t GetMaxClipAmmo(); // Function DonkehFramework.DFBaseAmmoClip.GetMaxClipAmmo
	struct ADFBaseGun* GetGunOwner(); // Function DonkehFramework.DFBaseAmmoClip.GetGunOwner
	int32_t GetCurrentClipAmmo(); // Function DonkehFramework.DFBaseAmmoClip.GetCurrentClipAmmo
	void ConsumeAmmo(int32_t AmmoToConsume); // Function DonkehFramework.DFBaseAmmoClip.ConsumeAmmo
}; 



// Class DonkehFramework.DFTeamDefinition
// Size: 0x58(Inherited: 0x28) 
struct UDFTeamDefinition : public UObject
{
	struct FName TeamName;  // 0x28(0x8)
	struct TSoftClassPtr<UObject> FactionInfoClass;  // 0x30(0x28)

}; 



// Class DonkehFramework.DFPlayerAdminList
// Size: 0xC8(Inherited: 0x78) 
struct UDFPlayerAdminList : public UDFCfgDataManager
{
	char pad_120[80];  // 0x78(0x50)

}; 



// Class DonkehFramework.DFPlayerBanList
// Size: 0xC8(Inherited: 0x78) 
struct UDFPlayerBanList : public UDFCfgDataManager
{
	char pad_120[80];  // 0x78(0x50)

}; 



// Class DonkehFramework.DFPlayerWhitelist
// Size: 0xC8(Inherited: 0x78) 
struct UDFPlayerWhitelist : public UDFCfgDataManager
{
	char pad_120[80];  // 0x78(0x50)

}; 



// Class DonkehFramework.VisibilityInterface
// Size: 0x28(Inherited: 0x28) 
struct UVisibilityInterface : public UInterface
{

	struct FVector EventGetFocalPoint(); // Function DonkehFramework.VisibilityInterface.EventGetFocalPoint
}; 



// Class DonkehFramework.DFAssetManager
// Size: 0x440(Inherited: 0x438) 
struct UDFAssetManager : public UAssetManager
{
	char pad_1080[8];  // 0x438(0x8)

}; 



// Class DonkehFramework.DFBaseItem
// Size: 0x3A8(Inherited: 0x220) 
struct ADFBaseItem : public AActor
{
	struct ADFBaseCharacter* PawnOwner;  // 0x220(0x8)
	struct UStaticMeshComponent* ItemMesh;  // 0x228(0x8)
	struct UStaticMeshComponent* ItemMesh1P;  // 0x230(0x8)
	struct USkeletalMesh* PawnMesh1P;  // 0x238(0x8)
	UAnimInstance* PawnMesh1PAnimClass;  // 0x240(0x8)
	struct FVector PawnMesh1PLocationOffset;  // 0x248(0xC)
	struct FRotator PawnMesh1PRotationOffset;  // 0x254(0xC)
	uint8_t  ItemType;  // 0x260(0x1)
	uint8_t  SpecificItemType;  // 0x261(0x1)
	char bCanEquip : 1;  // 0x262(0x1)
	char bCanAimWhileEquipped : 1;  // 0x262(0x1)
	char bDisableFireInput : 1;  // 0x262(0x1)
	char bEquipped : 1;  // 0x262(0x1)
	char bPendingEquip : 1;  // 0x262(0x1)
	char bPendingUnEquip : 1;  // 0x262(0x1)
	char bWantsToFire : 1;  // 0x262(0x1)
	char pad_610_1 : 1;  // 0x262(0x1)
	char pad_611[22];  // 0x263(0x16)
	char bDebug : 1;  // 0x278(0x1)
	char pad_632_1 : 7;  // 0x278(0x1)
	char pad_633[8];  // 0x279(0x8)
	struct FCharacterAnimCollection CharacterAnimCollection;  // 0x280(0x128)

	void StopFire(); // Function DonkehFramework.DFBaseItem.StopFire
	void StartFire(); // Function DonkehFramework.DFBaseItem.StartFire
	void SetOwningPawn(struct ADFBaseCharacter* NewOwner); // Function DonkehFramework.DFBaseItem.SetOwningPawn
	void SetMeshVisibility(bool bFirstPerson); // Function DonkehFramework.DFBaseItem.SetMeshVisibility
	void ServerStopFire(); // Function DonkehFramework.DFBaseItem.ServerStopFire
	void ServerStartFire(struct FVector_NetQuantize Origin, struct FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float Timestamp, int32_t ShotID); // Function DonkehFramework.DFBaseItem.ServerStartFire
	bool RemoveLegacyLocomotionAnims(bool bFPP); // Function DonkehFramework.DFBaseItem.RemoveLegacyLocomotionAnims
	void ReceiveVisibilityChanged(bool bFirstPerson); // Function DonkehFramework.DFBaseItem.ReceiveVisibilityChanged
	void ReceiveStopFire(); // Function DonkehFramework.DFBaseItem.ReceiveStopFire
	void ReceiveStartFire(); // Function DonkehFramework.DFBaseItem.ReceiveStartFire
	void ReceiveOnUnEquipFinished(bool bLeavingPawnInventory); // Function DonkehFramework.DFBaseItem.ReceiveOnUnEquipFinished
	void ReceiveOnUnEquip(bool bPlayAnimAndWait, bool bLeavingPawnInventory); // Function DonkehFramework.DFBaseItem.ReceiveOnUnEquip
	void ReceiveOnTurnOff(); // Function DonkehFramework.DFBaseItem.ReceiveOnTurnOff
	void ReceiveOnLeaveInventory(struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.ReceiveOnLeaveInventory
	void ReceiveOnEquipFinished(); // Function DonkehFramework.DFBaseItem.ReceiveOnEquipFinished
	void ReceiveOnEquip(struct ADFBaseItem* LastItem); // Function DonkehFramework.DFBaseItem.ReceiveOnEquip
	void ReceiveOnEnterInventory(struct ADFBaseCharacter* NewOwner, struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.ReceiveOnEnterInventory
	bool OwnerIsSprinting(); // Function DonkehFramework.DFBaseItem.OwnerIsSprinting
	bool OwnerIsAiming(); // Function DonkehFramework.DFBaseItem.OwnerIsAiming
	void OnUnEquip(bool bPlayAnimAndWait, bool bLeavingPawnInventory); // Function DonkehFramework.DFBaseItem.OnUnEquip
	void OnTurnOff(); // Function DonkehFramework.DFBaseItem.OnTurnOff
	void OnRep_PawnOwner(struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.OnRep_PawnOwner
	void OnLeaveInventory(struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.OnLeaveInventory
	void OnEquip(struct ADFBaseItem* LastItem); // Function DonkehFramework.DFBaseItem.OnEquip
	void OnEnterInventory(struct ADFBaseCharacter* NewOwner, struct ADFBaseCharacter* LastOwner); // Function DonkehFramework.DFBaseItem.OnEnterInventory
	bool IsUnEquipping(); // Function DonkehFramework.DFBaseItem.IsUnEquipping
	bool IsLocallyControlled(); // Function DonkehFramework.DFBaseItem.IsLocallyControlled
	bool IsEquipping(); // Function DonkehFramework.DFBaseItem.IsEquipping
	bool IsEquipped(); // Function DonkehFramework.DFBaseItem.IsEquipped
	bool IsClientSimulated(); // Function DonkehFramework.DFBaseItem.IsClientSimulated
	uint8_t  GetSpecificItemType(); // Function DonkehFramework.DFBaseItem.GetSpecificItemType
	struct ADFBaseCharacter* GetPawnOwner(); // Function DonkehFramework.DFBaseItem.GetPawnOwner
	struct UDFInventoryComponent* GetPawnInventory(); // Function DonkehFramework.DFBaseItem.GetPawnInventory
	struct FRotator GetOwnerViewRotation(); // Function DonkehFramework.DFBaseItem.GetOwnerViewRotation
	bool GetOwnerViewPoint(struct FVector& OutViewLoc, struct FRotator& OutViewRot); // Function DonkehFramework.DFBaseItem.GetOwnerViewPoint
	struct FVector GetOwnerViewLocation(); // Function DonkehFramework.DFBaseItem.GetOwnerViewLocation
	struct TMap<struct FName, struct UAnimSequenceBase*> GetLegacyLocomotionAnims(bool bFPP); // Function DonkehFramework.DFBaseItem.GetLegacyLocomotionAnims
	uint8_t  GetItemType(); // Function DonkehFramework.DFBaseItem.GetItemType
	struct UStaticMeshComponent* GetItemMeshToUse(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseItem.GetItemMeshToUse
	struct UStaticMeshComponent* GetItemMesh1P(); // Function DonkehFramework.DFBaseItem.GetItemMesh1P
	struct UStaticMeshComponent* GetItemMesh(); // Function DonkehFramework.DFBaseItem.GetItemMesh
	struct FVector GetAdjustedAimDirection(); // Function DonkehFramework.DFBaseItem.GetAdjustedAimDirection
	void ForceStopFiring(); // Function DonkehFramework.DFBaseItem.ForceStopFiring
	bool CanTriggerFire(); // Function DonkehFramework.DFBaseItem.CanTriggerFire
	bool CanStartFire(); // Function DonkehFramework.DFBaseItem.CanStartFire
	bool CanSprintWhileEquipped(); // Function DonkehFramework.DFBaseItem.CanSprintWhileEquipped
	bool CanFire(); // Function DonkehFramework.DFBaseItem.CanFire
	bool CanEquip(); // Function DonkehFramework.DFBaseItem.CanEquip
	bool CanAimWhileEquipped(); // Function DonkehFramework.DFBaseItem.CanAimWhileEquipped
}; 



// Class DonkehFramework.DFBaseGameState
// Size: 0x300(Inherited: 0x290) 
struct ADFBaseGameState : public AGameState
{
	char NumTeams;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool bTimerPaused : 1;  // 0x291(0x1)
	char pad_658[2];  // 0x292(0x2)
	int32_t RemainingTime;  // 0x294(0x4)
	int32_t ReplicatedRemainingTime;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	struct TArray<float> TeamScores;  // 0x2A0(0x10)
	struct TArray<struct ADFTeamState*> TeamArray;  // 0x2B0(0x10)
	struct FMulticastInlineDelegate OnTeamStateAdded;  // 0x2C0(0x10)
	struct FMulticastInlineDelegate OnTeamStateRemoved;  // 0x2D0(0x10)
	struct FMulticastInlineDelegate OnPlayerStateAdded;  // 0x2E0(0x10)
	struct FMulticastInlineDelegate OnPlayerStateRemoved;  // 0x2F0(0x10)

	void SetTimerPauseState(bool bNewPauseState); // Function DonkehFramework.DFBaseGameState.SetTimerPauseState
	void SetRemainingTime(int32_t NewRemainingTime); // Function DonkehFramework.DFBaseGameState.SetRemainingTime
	void OnRep_ReplicatedRemainingTime(); // Function DonkehFramework.DFBaseGameState.OnRep_ReplicatedRemainingTime
	void OnRep_NumTeams(); // Function DonkehFramework.DFBaseGameState.OnRep_NumTeams
	bool IsValidTeamId(char TeamId); // Function DonkehFramework.DFBaseGameState.IsValidTeamId
	struct ADFTeamState* GetTeamStateById(char TeamIdNum); // Function DonkehFramework.DFBaseGameState.GetTeamStateById
}; 



// Class DonkehFramework.DFBaseCharacter
// Size: 0x910(Inherited: 0x4C0) 
struct ADFBaseCharacter : public ACharacter
{
	char RemoteViewYaw;  // 0x4C0(0x1)
	char pad_1217[7];  // 0x4C1(0x7)
	char bClientResimulateSprintStamina : 1;  // 0x4C8(0x1)
	char pad_1224_1 : 7;  // 0x4C8(0x1)
	char pad_1225[8];  // 0x4C9(0x8)
	struct FCharacterAnimCollection DefaultPawnAnimCollection;  // 0x4D0(0x128)
	char bPlayFootstepFXWithPerspMeshOnly : 1;  // 0x5F8(0x1)
	char bTickAllAnimationOnDedicatedServer : 1;  // 0x5F8(0x1)
	char bOnlyTickAnimMontagesOnDedicatedServer : 1;  // 0x5F8(0x1)
	char pad_1528_1 : 5;  // 0x5F8(0x1)
	char pad_1529[8];  // 0x5F9(0x8)
	struct FCharacterSoundCollection DefaultPawnSoundCollection;  // 0x600(0x10)
	struct ADFBaseItem* EquippedItem;  // 0x610(0x8)
	struct ADFBaseItem* LastEquippedItem;  // 0x618(0x8)
	struct FMulticastInlineDelegate OnEquippedItemChanged;  // 0x620(0x10)
	struct FName ItemAttachPoint;  // 0x630(0x8)
	struct UDFInventoryComponent* Inventory;  // 0x638(0x8)
	struct UDFLoadout* DefaultLoadout;  // 0x640(0x8)
	uint8_t  ItemEnabledMode;  // 0x648(0x1)
	char pad_1609[3];  // 0x649(0x3)
	int32_t ShotIDCounter;  // 0x64C(0x4)
	char bDying : 1;  // 0x650(0x1)
	char pad_1616_1 : 7;  // 0x650(0x1)
	char pad_1617[8];  // 0x651(0x8)
	struct FMulticastInlineDelegate OnHealthChanged;  // 0x658(0x10)
	float Health;  // 0x668(0x4)
	char pad_1644[20];  // 0x66C(0x14)
	float RagdollLifeSpan;  // 0x680(0x4)
	char pad_1668[4];  // 0x684(0x4)
	struct FMulticastInlineDelegate OnCharacterDeath;  // 0x688(0x10)
	float MaxHealth;  // 0x698(0x4)
	char pad_1692[4];  // 0x69C(0x4)
	struct FTakeHitInfo LastTakeHitInfo;  // 0x6A0(0x120)
	char pad_1984[8];  // 0x7C0(0x8)
	struct TMap<struct FName, float> BoneDamageMultipliers;  // 0x7C8(0x50)
	char bApplyDamageMomentumOnHit : 1;  // 0x818(0x1)
	char pad_2072_1 : 7;  // 0x818(0x1)
	char pad_2073[8];  // 0x819(0x8)
	struct FMulticastInlineDelegate OnSprintTransition;  // 0x820(0x10)
	struct FMulticastInlineDelegate OnAimTransition;  // 0x830(0x10)
	struct FMulticastInlineDelegate OnLeanTransition;  // 0x840(0x10)
	struct FMulticastInlineDelegate OnVaultTransition;  // 0x850(0x10)
	uint8_t  ReplicatedStance;  // 0x860(0x1)
	uint8_t  PreviousStance;  // 0x861(0x1)
	char bPressedVault : 1;  // 0x862(0x1)
	char bSprinting : 1;  // 0x862(0x1)
	char bAiming : 1;  // 0x862(0x1)
	char bIsProne : 1;  // 0x862(0x1)
	char bVaulting : 1;  // 0x862(0x1)
	char bWasVaulting : 1;  // 0x862(0x1)
	char pad_2146_1 : 2;  // 0x862(0x1)
	char pad_2147[2];  // 0x863(0x2)
	struct FDFVaultTraceResult PendingVaultTraceResult;  // 0x864(0x1C)
	struct FDFVaultTraceData VaultParams;  // 0x880(0x18)
	float ReplicatedLeanAmount;  // 0x898(0x4)
	char pad_2204[4];  // 0x89C(0x4)
	struct UDFCharacterLeanHandler* LeanHandler;  // 0x8A0(0x8)
	struct UDFCharacterMovementComponent* DFCharacterMovement;  // 0x8A8(0x8)
	float TargetEyeHeight;  // 0x8B0(0x4)
	char pad_2228_1 : 1;  // 0x8B4(0x1)
	char bInterpCrouchedEyeHeight : 1;  // 0x8B4(0x1)
	char pad_2228_2 : 6;  // 0x8B4(0x1)
	char pad_2229[4];  // 0x8B5(0x4)
	float CrouchedTransitionInterpSpeed;  // 0x8B8(0x4)
	char bInterpProneEyeHeight : 1;  // 0x8BC(0x1)
	char pad_2236_1 : 7;  // 0x8BC(0x1)
	char pad_2237[4];  // 0x8BD(0x4)
	float ProneTransitionInterpSpeed;  // 0x8C0(0x4)
	float ProneEyeHeight;  // 0x8C4(0x4)
	char TeamNum;  // 0x8C8(0x1)
	char pad_2249[7];  // 0x8C9(0x7)
	struct ADFTeamState* TeamState;  // 0x8D0(0x8)
	struct ADFTeamState* PrevTeamState;  // 0x8D8(0x8)
	char bAllowTeamIdOverride : 1;  // 0x8E0(0x1)
	char pad_2272_1 : 7;  // 0x8E0(0x1)
	char pad_2273[8];  // 0x8E1(0x8)
	struct FMulticastInlineDelegate OnPawnTeamNumUpdated;  // 0x8E8(0x10)
	struct FMulticastInlineDelegate OnPawnTeamStateUpdated;  // 0x8F8(0x10)
	char pad_2312[8];  // 0x908(0x8)

	void Vault(); // Function DonkehFramework.DFBaseCharacter.Vault
	void UnSprint(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.UnSprint
	void UnLean(uint8_t  UnDesiredLeanDir, bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.UnLean
	void UnAim(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.UnAim
	void Suicide(); // Function DonkehFramework.DFBaseCharacter.Suicide
	void StopVaulting(); // Function DonkehFramework.DFBaseCharacter.StopVaulting
	void StopFire(); // Function DonkehFramework.DFBaseCharacter.StopFire
	void StopCharacterPerspectiveAnimation(struct FPerspectiveAnim& CharAnim); // Function DonkehFramework.DFBaseCharacter.StopCharacterPerspectiveAnimation
	void StopCharacterMontage(struct UAnimMontage* CharMontage); // Function DonkehFramework.DFBaseCharacter.StopCharacterMontage
	void StopAllAnimMontages(bool bPerspectiveMeshOnly); // Function DonkehFramework.DFBaseCharacter.StopAllAnimMontages
	void StartFire(); // Function DonkehFramework.DFBaseCharacter.StartFire
	void SprintToggle(); // Function DonkehFramework.DFBaseCharacter.SprintToggle
	void Sprint(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.Sprint
	void SpawnHitImpactFX(float DamageTaken, struct FDamageEvent& DamageEvent, struct APawn* PawnInstigator, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.SpawnHitImpactFX
	void SetRagdollPhysics(); // Function DonkehFramework.DFBaseCharacter.SetRagdollPhysics
	void SetItemEnabledMode(uint8_t  ItemMode); // Function DonkehFramework.DFBaseCharacter.SetItemEnabledMode
	void SetHealth(float InHealth); // Function DonkehFramework.DFBaseCharacter.SetHealth
	void ServerSuicide(); // Function DonkehFramework.DFBaseCharacter.ServerSuicide
	void ServerEquipItem(struct ADFBaseItem* ItemToEquip); // Function DonkehFramework.DFBaseCharacter.ServerEquipItem
	void ServerDoVault(struct FDFVaultTraceData VaultStartParams); // Function DonkehFramework.DFBaseCharacter.ServerDoVault
	void Reload(); // Function DonkehFramework.DFBaseCharacter.Reload
	void ReceiveRestart(); // Function DonkehFramework.DFBaseCharacter.ReceiveRestart
	void ReceivePlayHit(float DamageTaken, struct FDamageEvent& DamageEvent, struct APawn* PawnInstigator, struct AActor* DamageCauser, bool bKilled); // Function DonkehFramework.DFBaseCharacter.ReceivePlayHit
	void ReceivePawnTeamStateUpdated(struct ADFTeamState* TeamStateBeforeUpdate, struct ADFTeamState* NewTeamState, bool bNewTeamStateInit); // Function DonkehFramework.DFBaseCharacter.ReceivePawnTeamStateUpdated
	void ReceivePawnTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function DonkehFramework.DFBaseCharacter.ReceivePawnTeamNumUpdated
	void ReceiveOnStartVault(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartVault
	void ReceiveOnStartSprint(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartSprint
	void ReceiveOnStartProne(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartProne
	void ReceiveOnStartLean(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartLean
	void ReceiveOnStartAim(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnStartAim
	void ReceiveOnRepPlayerState(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnRepPlayerState
	void ReceiveOnEndVault(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndVault
	void ReceiveOnEndSprint(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndSprint
	void ReceiveOnEndProne(float HalfHeightAdjust, float ScaledHalfHeightAdjust); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndProne
	void ReceiveOnEndLean(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndLean
	void ReceiveOnEndAim(); // Function DonkehFramework.DFBaseCharacter.ReceiveOnEndAim
	void ReceiveHealthChanged(float NewHealthTotal, float PrevHealthTotal); // Function DonkehFramework.DFBaseCharacter.ReceiveHealthChanged
	void ReceiveEquippedItemChanged(struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function DonkehFramework.DFBaseCharacter.ReceiveEquippedItemChanged
	void ProneToggle(); // Function DonkehFramework.DFBaseCharacter.ProneToggle
	float PlayCharacterUnEquipMontage(struct UAnimMontage* UnEquipMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterUnEquipMontage
	float PlayCharacterThrowUnderhandMontage(struct UAnimMontage* ThrowUnderhandMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterThrowUnderhandMontage
	float PlayCharacterThrowOverhandMontage(struct UAnimMontage* ThrowOverhandMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterThrowOverhandMontage
	float PlayCharacterStartReloadMontage(struct UAnimMontage* StartReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseCharacter.PlayCharacterStartReloadMontage
	struct UAudioComponent* PlayCharacterSound(struct FPerspectiveSound& Sound); // Function DonkehFramework.DFBaseCharacter.PlayCharacterSound
	float PlayCharacterReloadMontage(bool bDryReload); // Function DonkehFramework.DFBaseCharacter.PlayCharacterReloadMontage
	float PlayCharacterPerspectiveAnimation(struct FPerspectiveAnim& CharAnim, bool bForceDisableAutoBlendOut); // Function DonkehFramework.DFBaseCharacter.PlayCharacterPerspectiveAnimation
	float PlayCharacterMontage(struct UAnimMontage* CharMontage, bool bForceDisableAutoBlendOut); // Function DonkehFramework.DFBaseCharacter.PlayCharacterMontage
	float PlayCharacterFireMontage(struct UAnimMontage* FireMontageToPlay, bool bFireLast, bool bFireADS); // Function DonkehFramework.DFBaseCharacter.PlayCharacterFireMontage
	float PlayCharacterEquipMontage(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseCharacter.PlayCharacterEquipMontage
	float PlayCharacterEndReloadMontage(struct UAnimMontage* EndReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseCharacter.PlayCharacterEndReloadMontage
	float PlayCharacterDeathMontage(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseCharacter.PlayCharacterDeathMontage
	float PlayCharacterCockMontage(struct UAnimMontage* CockMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterCockMontage
	float PlayCharacterActionMontage(struct UAnimMontage* ActionMontageToPlay); // Function DonkehFramework.DFBaseCharacter.PlayCharacterActionMontage
	void OnRep_TeamState(struct ADFTeamState* TeamStateBeforeUpdate); // Function DonkehFramework.DFBaseCharacter.OnRep_TeamState
	void OnRep_TeamNum(char LastTeamNum); // Function DonkehFramework.DFBaseCharacter.OnRep_TeamNum
	void OnRep_ReplicatedStance(); // Function DonkehFramework.DFBaseCharacter.OnRep_ReplicatedStance
	void OnRep_ReplicatedLeanAmount(float LastReplicatedLeanAmount); // Function DonkehFramework.DFBaseCharacter.OnRep_ReplicatedLeanAmount
	void OnRep_LastTakeHitInfo(); // Function DonkehFramework.DFBaseCharacter.OnRep_LastTakeHitInfo
	void OnRep_ItemEnabledMode(uint8_t  PreviousItemEnabledMode); // Function DonkehFramework.DFBaseCharacter.OnRep_ItemEnabledMode
	void OnRep_IsProne(); // Function DonkehFramework.DFBaseCharacter.OnRep_IsProne
	void OnRep_Health(float PreviousValue); // Function DonkehFramework.DFBaseCharacter.OnRep_Health
	void OnRep_EquippedItem(struct ADFBaseItem* LastItem); // Function DonkehFramework.DFBaseCharacter.OnRep_EquippedItem
	void OnRep_bSprinting(); // Function DonkehFramework.DFBaseCharacter.OnRep_bSprinting
	void OnRep_bAiming(); // Function DonkehFramework.DFBaseCharacter.OnRep_bAiming
	void OnDeath(float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.OnDeath
	int32_t NextShotID(); // Function DonkehFramework.DFBaseCharacter.NextShotID
	void LeaveProne(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.LeaveProne
	void LeanToggle(uint8_t  LeanDir); // Function DonkehFramework.DFBaseCharacter.LeanToggle
	void Lean(uint8_t  DesiredLeanDir, bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.Lean
	void ItemEnabledModeChanged(uint8_t  PreviousItemEnabledMode); // Function DonkehFramework.DFBaseCharacter.ItemEnabledModeChanged
	bool IsPrefiring(); // Function DonkehFramework.DFBaseCharacter.IsPrefiring
	bool IsPlayer(); // Function DonkehFramework.DFBaseCharacter.IsPlayer
	bool IsPerspectiveMesh(struct USkeletalMeshComponent* MeshCompToCheck); // Function DonkehFramework.DFBaseCharacter.IsPerspectiveMesh
	bool IsLeaning(); // Function DonkehFramework.DFBaseCharacter.IsLeaning
	bool IsFiring(); // Function DonkehFramework.DFBaseCharacter.IsFiring
	bool IsEquipped(); // Function DonkehFramework.DFBaseCharacter.IsEquipped
	bool IsAlive(); // Function DonkehFramework.DFBaseCharacter.IsAlive
	void GoProne(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.GoProne
	void GiveLoadout(struct UDFLoadout* Loadout, bool bEquipFirstItem); // Function DonkehFramework.DFBaseCharacter.GiveLoadout
	struct ADFBaseItem* GetRelevantEquippedItem(); // Function DonkehFramework.DFBaseCharacter.GetRelevantEquippedItem
	struct ADFBaseItem* GetPreviousInventoryItem(bool bEquippable); // Function DonkehFramework.DFBaseCharacter.GetPreviousInventoryItem
	struct ADFBaseItem* GetNextInventoryItem(bool bEquippable); // Function DonkehFramework.DFBaseCharacter.GetNextInventoryItem
	struct UAnimMontage* GetMontageToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseCharacter.GetMontageToUseFromPerspectiveAnimPair
	uint8_t  GetItemEnabledMode(); // Function DonkehFramework.DFBaseCharacter.GetItemEnabledMode
	struct FName GetItemAttachPoint(); // Function DonkehFramework.DFBaseCharacter.GetItemAttachPoint
	struct UDFInventoryComponent* GetInventory(); // Function DonkehFramework.DFBaseCharacter.GetInventory
	struct ADFBaseItem* GetEquippedItem(); // Function DonkehFramework.DFBaseCharacter.GetEquippedItem
	bool GetDamageMultiplierByBoneName(struct FName& BoneName, float& DamageMultiplier); // Function DonkehFramework.DFBaseCharacter.GetDamageMultiplierByBoneName
	struct USkeletalMeshComponent* GetCharacterMeshToUse(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseCharacter.GetCharacterMeshToUse
	bool GetCharacterDeathMontageToUse(struct UAnimMontage*& OutCharDeathMontage); // Function DonkehFramework.DFBaseCharacter.GetCharacterDeathMontageToUse
	uint8_t  GetCharacterAnimTickOptionToUse(bool bVisibleMesh); // Function DonkehFramework.DFBaseCharacter.GetCharacterAnimTickOptionToUse
	struct UAnimSequenceBase* GetAnimToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseCharacter.GetAnimToUseFromPerspectiveAnimPair
	struct FRotator GetAimOffsets(); // Function DonkehFramework.DFBaseCharacter.GetAimOffsets
	void EquipPreviousItem(); // Function DonkehFramework.DFBaseCharacter.EquipPreviousItem
	void EquipNextItemByType(uint8_t  ItemType); // Function DonkehFramework.DFBaseCharacter.EquipNextItemByType
	void EquipNextItem(); // Function DonkehFramework.DFBaseCharacter.EquipNextItem
	void EquipItem(struct ADFBaseItem* ItemToEquip); // Function DonkehFramework.DFBaseCharacter.EquipItem
	bool Die(float KillingDamage, struct FDamageEvent& DamageEvent, struct AController* Killer, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.Die
	void CrouchToggle(); // Function DonkehFramework.DFBaseCharacter.CrouchToggle
	void ClientVeryShortAdjustPosition_CustomStamina(float Timestamp, struct FVector NewLoc, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientVeryShortAdjustPosition_CustomStamina
	void ClientAdjustRootMotionSourcePosition_CustomStamina(float Timestamp, struct FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientAdjustRootMotionSourcePosition_CustomStamina
	void ClientAdjustRootMotionPosition_CustomStamina(float Timestamp, float ServerMontageTrackPosition, struct FVector ServerLoc, struct FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, struct UPrimitiveComponent* ServerBase, struct FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientAdjustRootMotionPosition_CustomStamina
	void ClientAdjustPosition_CustomStamina(float Timestamp, struct FVector NewLoc, struct FVector NewVel, struct UPrimitiveComponent* NewBase, struct FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, char ServerMovementMode, float ServerSprintStamina); // Function DonkehFramework.DFBaseCharacter.ClientAdjustPosition_CustomStamina
	void ClearCharacterAnimInstances(bool bPerspectiveMeshOnly); // Function DonkehFramework.DFBaseCharacter.ClearCharacterAnimInstances
	bool CanVault(); // Function DonkehFramework.DFBaseCharacter.CanVault
	bool CanSprint(); // Function DonkehFramework.DFBaseCharacter.CanSprint
	bool CanLean(uint8_t  DesiredLeanDir); // Function DonkehFramework.DFBaseCharacter.CanLean
	bool CanGoProne(); // Function DonkehFramework.DFBaseCharacter.CanGoProne
	bool CanDie(float KillingDamage, struct FDamageEvent& DamageEvent, struct AController* Killer, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseCharacter.CanDie
	bool CanAim(); // Function DonkehFramework.DFBaseCharacter.CanAim
	bool AllowsWeaponFire(); // Function DonkehFramework.DFBaseCharacter.AllowsWeaponFire
	void AimToggle(); // Function DonkehFramework.DFBaseCharacter.AimToggle
	void Aim(bool bClientSimulation); // Function DonkehFramework.DFBaseCharacter.Aim
}; 



// Class DonkehFramework.DFBaseAIController
// Size: 0x330(Inherited: 0x328) 
struct ADFBaseAIController : public AAIController
{
	char pad_808[8];  // 0x328(0x8)

	bool CanRestartPlayer(); // Function DonkehFramework.DFBaseAIController.CanRestartPlayer
}; 



// Class DonkehFramework.DFBasePlayerController
// Size: 0x5F8(Inherited: 0x570) 
struct ADFBasePlayerController : public APlayerController
{
	char pad_1392[8];  // 0x570(0x8)
	struct FMulticastInlineDelegate OnPossessPawn;  // 0x578(0x10)
	struct FMulticastInlineDelegate OnUnpossessPawn;  // 0x588(0x10)
	char pad_1432[8];  // 0x598(0x8)
	struct ADFBaseCharacter* DFCharacter;  // 0x5A0(0x8)
	char pad_1448[24];  // 0x5A8(0x18)
	char bSetGameOnlyInputOnBeginPlay : 1;  // 0x5C0(0x1)
	char pad_1472_1 : 7;  // 0x5C0(0x1)
	char pad_1473[8];  // 0x5C1(0x8)
	struct FMulticastInlineDelegate OnPlayerTeamNumUpdated;  // 0x5C8(0x10)
	struct FMulticastInlineDelegate OnPlayerTeamStateUpdated;  // 0x5D8(0x10)
	struct ADFTeamState* TeamState;  // 0x5E8(0x8)
	int32_t MaxChatMsgLen;  // 0x5F0(0x4)
	char pad_1524[4];  // 0x5F4(0x4)

	void TeamSay(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.TeamSay
	void ServerTeamSay(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.ServerTeamSay
	void ServerSay(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.ServerSay
	void ServerNotifyProjCSHit(struct ADFBaseProjectile* HitProj, struct APawn* HitProjDamageInstigator, struct FCSHitInfo HitInfo, int32_t ShotID); // Function DonkehFramework.DFBasePlayerController.ServerNotifyProjCSHit
	void ServerEnableCheats(); // Function DonkehFramework.DFBasePlayerController.ServerEnableCheats
	void ServerAdmin(struct FString Cmd); // Function DonkehFramework.DFBasePlayerController.ServerAdmin
	void Say(struct FString Msg); // Function DonkehFramework.DFBasePlayerController.Say
	void ReceiveUnpossessPawn(struct APawn* UnpossessedPawn); // Function DonkehFramework.DFBasePlayerController.ReceiveUnpossessPawn
	void ReceivePreClientTravel(struct FString PendingURL, bool bIsSeamlessTravelWithRelativeTravelType); // Function DonkehFramework.DFBasePlayerController.ReceivePreClientTravel
	void ReceivePossessPawn(struct APawn* NewPawn); // Function DonkehFramework.DFBasePlayerController.ReceivePossessPawn
	void ReceivePlayerTeamStateUpdated(struct ADFTeamState* LastTeamState, struct ADFTeamState* NewTeamState, bool bNewTeamStateInit); // Function DonkehFramework.DFBasePlayerController.ReceivePlayerTeamStateUpdated
	void ReceivePlayerTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function DonkehFramework.DFBasePlayerController.ReceivePlayerTeamNumUpdated
	void ReceiveOnRepPlayerState(); // Function DonkehFramework.DFBasePlayerController.ReceiveOnRepPlayerState
	void ReceiveNewChatMsg(struct FPlayerChatMsg& ChatMsg); // Function DonkehFramework.DFBasePlayerController.ReceiveNewChatMsg
	void ReceiveGameHasEnded(struct AActor* EndGameFocus, bool bIsWinner); // Function DonkehFramework.DFBasePlayerController.ReceiveGameHasEnded
	void OnFireReleased(); // Function DonkehFramework.DFBasePlayerController.OnFireReleased
	void OnFirePressed(); // Function DonkehFramework.DFBasePlayerController.OnFirePressed
	bool IsServerAdministrator(); // Function DonkehFramework.DFBasePlayerController.IsServerAdministrator
	bool IsGameInputAllowed(); // Function DonkehFramework.DFBasePlayerController.IsGameInputAllowed
	struct FTimerHandle GetUnFreezeTimerHandle(); // Function DonkehFramework.DFBasePlayerController.GetUnFreezeTimerHandle
	void ClientEnableCheats(); // Function DonkehFramework.DFBasePlayerController.ClientEnableCheats
	void Admin(struct FString Cmd); // Function DonkehFramework.DFBasePlayerController.Admin
}; 



// Class DonkehFramework.DFBaseGameMode
// Size: 0x3F8(Inherited: 0x308) 
struct ADFBaseGameMode : public AGameMode
{
	struct ADFGameSession* DFGameSession;  // 0x308(0x8)
	char pad_784[8];  // 0x310(0x8)
	ADFTeamState* TeamStateClass;  // 0x318(0x8)
	AAIController* AIControllerClass;  // 0x320(0x8)
	struct TArray<char> WinningTeams;  // 0x328(0x10)
	struct FTimerHandle TimerHandle_DefaultTimer;  // 0x338(0x8)
	int32_t WarmupTime;  // 0x340(0x4)
	int32_t RoundTimeLimit;  // 0x344(0x4)
	int32_t RoundScoreLimit;  // 0x348(0x4)
	int32_t TimeBetweenMatches;  // 0x34C(0x4)
	char bBalanceTeams : 1;  // 0x350(0x1)
	char pad_848_1 : 7;  // 0x350(0x1)
	char pad_849[4];  // 0x351(0x4)
	float BalanceTimerInterval;  // 0x354(0x4)
	char AutoAssignHumanTeam;  // 0x358(0x1)
	char bBotAutofill : 1;  // 0x359(0x1)
	char pad_857_1 : 7;  // 0x359(0x1)
	char pad_858[7];  // 0x35A(0x7)
	struct FText GameDisplayName;  // 0x360(0x18)
	int32_t NumTeams;  // 0x378(0x4)
	char bAllowUnassignedTeams : 1;  // 0x37C(0x1)
	char bAllowPlayerNameChanges : 1;  // 0x37C(0x1)
	char bAllowPlayerNameChangesUnderNullOSS : 1;  // 0x37C(0x1)
	char bAllowPlayerNameChangesUnderSteamOSS : 1;  // 0x37C(0x1)
	char bAlwaysDestroyPlayerDuringSeamlessTravel : 1;  // 0x37C(0x1)
	char bForceRespawn : 1;  // 0x37C(0x1)
	char bRandomSpawns : 1;  // 0x37C(0x1)
	char bRestartPlayerAtTransformOnly : 1;  // 0x37C(0x1)
	char bFriendlyFire : 1;  // 0x37D(0x1)
	char bUpdatePlayerGameplayMuteStates : 1;  // 0x37D(0x1)
	char bTeamOnlyVoice : 1;  // 0x37D(0x1)
	char pad_893_1 : 5;  // 0x37D(0x1)
	uint8_t  DefaultPawnSpawnCollisionHandlingMethodOverride;  // 0x37E(0x1)
	char bAllowBots : 1;  // 0x37F(0x1)
	char pad_895_1 : 7;  // 0x37F(0x1)
	struct FTimerHandle TimerHandle_BalanceTimer;  // 0x380(0x8)
	struct TSet<struct TSoftClassPtr<UObject>> GameRulesetClasses;  // 0x388(0x50)
	struct TArray<struct AActor*> SignificantActors;  // 0x3D8(0x10)
	struct TArray<struct UDFGameRulesetBase*> GameRulesets;  // 0x3E8(0x10)

	void UpdatePlayerGameplayMuteStates(struct ADFBasePlayerController* ForPlayerController); // Function DonkehFramework.DFBaseGameMode.UpdatePlayerGameplayMuteStates
	void UnregisterSignificantActor(struct AActor* ActorToRemove); // Function DonkehFramework.DFBaseGameMode.UnregisterSignificantActor
	void SwitchToNextMap(); // Function DonkehFramework.DFBaseGameMode.SwitchToNextMap
	void SignificantActorEndPlay(struct AActor* RemovedActor, char EEndPlayReason EndPlayReason); // Function DonkehFramework.DFBaseGameMode.SignificantActorEndPlay
	bool ShouldHibernate(); // Function DonkehFramework.DFBaseGameMode.ShouldHibernate
	bool ShouldGameplayMuteRemotePlayer(struct ADFBasePlayerController* ForPlayer, struct ADFBasePlayerController* PlayerToCheck); // Function DonkehFramework.DFBaseGameMode.ShouldGameplayMuteRemotePlayer
	bool ShouldBotAutofill(); // Function DonkehFramework.DFBaseGameMode.ShouldBotAutofill
	void RemoveTeamBots(char TeamId, int32_t Num); // Function DonkehFramework.DFBaseGameMode.RemoveTeamBots
	void RemovePlayerByAge(bool bNewest, bool bExcludeBots, bool bExcludeHumans); // Function DonkehFramework.DFBaseGameMode.RemovePlayerByAge
	void RemoveOldestPlayer(); // Function DonkehFramework.DFBaseGameMode.RemoveOldestPlayer
	void RemoveOldestBot(); // Function DonkehFramework.DFBaseGameMode.RemoveOldestBot
	void RemoveNewestPlayer(); // Function DonkehFramework.DFBaseGameMode.RemoveNewestPlayer
	void RemoveNewestBot(); // Function DonkehFramework.DFBaseGameMode.RemoveNewestBot
	bool RemoveBotByName(struct FString PlayerName); // Function DonkehFramework.DFBaseGameMode.RemoveBotByName
	bool RemoveBot(struct APlayerState* BotPS); // Function DonkehFramework.DFBaseGameMode.RemoveBot
	void RemoveAllBots(); // Function DonkehFramework.DFBaseGameMode.RemoveAllBots
	void RegisterSignificantActor(struct AActor* ActorToRegister); // Function DonkehFramework.DFBaseGameMode.RegisterSignificantActor
	void ReceiveOnSwapAIControllers(struct AAIController* OldAIC, struct AAIController* NewAIC); // Function DonkehFramework.DFBaseGameMode.ReceiveOnSwapAIControllers
	void ReceiveOnMatchIsWaitingToStart(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchIsWaitingToStart
	void ReceiveOnMatchHasStarted(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchHasStarted
	void ReceiveOnMatchHasEnded(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchHasEnded
	void ReceiveOnMatchAborted(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnMatchAborted
	void ReceiveOnLeavingMap(); // Function DonkehFramework.DFBaseGameMode.ReceiveOnLeavingMap
	bool PlayerCanRestartGeneric(struct AController* Player); // Function DonkehFramework.DFBaseGameMode.PlayerCanRestartGeneric
	bool PlayerBotCanRestart(struct AAIController* Player); // Function DonkehFramework.DFBaseGameMode.PlayerBotCanRestart
	void NextMap(); // Function DonkehFramework.DFBaseGameMode.NextMap
	float ModifyDamage(float Damage, struct AActor* DamagedActor, struct FDamageEvent& DamageEvent, struct AController* EventInstigator, struct AActor* DamageCauser); // Function DonkehFramework.DFBaseGameMode.ModifyDamage
	bool KickPlayerByName(struct FString KickedPlayerName, struct FText& KickReason); // Function DonkehFramework.DFBaseGameMode.KickPlayerByName
	bool KickPlayerById(int32_t KickedPlayerId, struct FText& KickReason); // Function DonkehFramework.DFBaseGameMode.KickPlayerById
	bool IsValidTeamId(char TeamId); // Function DonkehFramework.DFBaseGameMode.IsValidTeamId
	bool IsMatchWinner(struct ADFBasePlayerState* PlayerStateToCheck); // Function DonkehFramework.DFBaseGameMode.IsMatchWinner
	bool IsHibernating(); // Function DonkehFramework.DFBaseGameMode.IsHibernating
	bool IsFriendlyFireEnabled(); // Function DonkehFramework.DFBaseGameMode.IsFriendlyFireEnabled
	int32_t GetTotalNumPlayers(bool bIncludeTravellingPlayers); // Function DonkehFramework.DFBaseGameMode.GetTotalNumPlayers
	int32_t GetNumPlayersOnTeam(char TeamId, uint8_t  PlayerType); // Function DonkehFramework.DFBaseGameMode.GetNumPlayersOnTeam
	struct FString GetNextMapName(); // Function DonkehFramework.DFBaseGameMode.GetNextMapName
	struct FString GetNextGameName(); // Function DonkehFramework.DFBaseGameMode.GetNextGameName
	char GetAutoAssignHumanTeam(); // Function DonkehFramework.DFBaseGameMode.GetAutoAssignHumanTeam
	bool ForceTeamId(int32_t SwitchedPlayerId, char TeamIdToAssign); // Function DonkehFramework.DFBaseGameMode.ForceTeamId
	bool ForceTeam(struct FString SwitchedPlayerName, char TeamIdToAssign); // Function DonkehFramework.DFBaseGameMode.ForceTeam
	bool FindPlayerStartTransform(struct AController* Player, struct FTransform& OutFoundSpawnTransform, struct FString IncomingName); // Function DonkehFramework.DFBaseGameMode.FindPlayerStartTransform
	void DumpActiveRulesets(); // Function DonkehFramework.DFBaseGameMode.DumpActiveRulesets
	void DetermineMatchWinner(); // Function DonkehFramework.DFBaseGameMode.DetermineMatchWinner
	struct ADFTeamState* CreateTeam(struct UDFTeamDefinition* NewTeamDef, char NewTeamIdToUse); // Function DonkehFramework.DFBaseGameMode.CreateTeam
	char ChooseTeam(struct ADFBasePlayerState* ForPlayerState); // Function DonkehFramework.DFBaseGameMode.ChooseTeam
	bool ChooseSpawnPointFromPlayerStart(struct AController* Player, struct AActor* StartSpot, struct FSpawnPointDef& OutChosenSpawnPoint, uint8_t & OutCollisionHandlingMethod); // Function DonkehFramework.DFBaseGameMode.ChooseSpawnPointFromPlayerStart
	bool CheckWinConditions(); // Function DonkehFramework.DFBaseGameMode.CheckWinConditions
	bool CheckRulesetWinConditions(); // Function DonkehFramework.DFBaseGameMode.CheckRulesetWinConditions
	bool CanRegisterSignificantActor(struct AActor* ActorToRegister, struct FString& ActorDenialReason); // Function DonkehFramework.DFBaseGameMode.CanRegisterSignificantActor
	bool CanDealDamage(struct ADFBasePlayerState* DamageInstigator, struct ADFBasePlayerState* DamagedPlayer); // Function DonkehFramework.DFBaseGameMode.CanDealDamage
	bool CanAddRuleset(UDFGameRulesetBase*& RulesetClassToAdd, struct FString& RulesetDenialReason); // Function DonkehFramework.DFBaseGameMode.CanAddRuleset
	bool BanPlayerByName(struct FString BannedPlayerName, struct FText& BanReason, float BanDuration); // Function DonkehFramework.DFBaseGameMode.BanPlayerByName
	bool BanPlayerById(int32_t BannedPlayerId, struct FText& BanReason, float BanDuration); // Function DonkehFramework.DFBaseGameMode.BanPlayerById
	void AutofillWithBots(); // Function DonkehFramework.DFBaseGameMode.AutofillWithBots
	void AssignTeam(struct AController* ForController, char AssignedTeam); // Function DonkehFramework.DFBaseGameMode.AssignTeam
	void AddTeamBots(char TeamId, int32_t Num); // Function DonkehFramework.DFBaseGameMode.AddTeamBots
	void AddNamedBot(struct FString BotName); // Function DonkehFramework.DFBaseGameMode.AddNamedBot
	void AddBots(int32_t Num); // Function DonkehFramework.DFBaseGameMode.AddBots
	struct APlayerState* AddBot(char PlayerTeamID, struct FString PlayerName); // Function DonkehFramework.DFBaseGameMode.AddBot
}; 



// Class DonkehFramework.DFGunRecoilHandler
// Size: 0x28(Inherited: 0x28) 
struct UDFGunRecoilHandler : public UObject
{

	void OnWeaponStopFire(); // Function DonkehFramework.DFGunRecoilHandler.OnWeaponStopFire
	void OnWeaponStartFire(); // Function DonkehFramework.DFGunRecoilHandler.OnWeaponStartFire
	void OnWeaponFire(); // Function DonkehFramework.DFGunRecoilHandler.OnWeaponFire
	void OnTick(float DeltaTime); // Function DonkehFramework.DFGunRecoilHandler.OnTick
	bool IsFiring(); // Function DonkehFramework.DFGunRecoilHandler.IsFiring
	struct APawn* GetOwningPawn(); // Function DonkehFramework.DFGunRecoilHandler.GetOwningPawn
	struct ADFBaseGun* GetOwningGun(); // Function DonkehFramework.DFGunRecoilHandler.GetOwningGun
	struct FVector GetConeOfFireOffset(); // Function DonkehFramework.DFGunRecoilHandler.GetConeOfFireOffset
}; 



// Class DonkehFramework.DFBaseImpactEffect
// Size: 0x4E8(Inherited: 0x220) 
struct ADFBaseImpactEffect : public AActor
{
	struct TArray<struct FDecalData> ConcreteDecals;  // 0x220(0x10)
	struct TArray<struct FDecalData> MetalSolidDecals;  // 0x230(0x10)
	struct TArray<struct FDecalData> WoodDecals;  // 0x240(0x10)
	struct TArray<struct FDecalData> GlassBPDecals;  // 0x250(0x10)
	struct TArray<struct FDecalData> GlassDecals;  // 0x260(0x10)
	struct TArray<struct FDecalData> GlassWHDecals;  // 0x270(0x10)
	struct TArray<struct FDecalData> MetalThinDecals;  // 0x280(0x10)
	struct TArray<struct FDecalData> SandbagDecals;  // 0x290(0x10)
	struct TArray<struct FDecalData> BrickWallDecals;  // 0x2A0(0x10)
	struct TArray<struct FDecalData> RubberDecals;  // 0x2B0(0x10)
	struct TArray<struct FDecalData> DrywallDecals;  // 0x2C0(0x10)
	struct TArray<struct FDecalData> ElectricDevicesDecals;  // 0x2D0(0x10)
	struct TArray<struct FDecalData> OilBarrelDecals;  // 0x2E0(0x10)
	struct UParticleSystem* SnowFX;  // 0x2F0(0x8)
	struct UParticleSystem* WaterFX;  // 0x2F8(0x8)
	struct UParticleSystem* ConcreteFX;  // 0x300(0x8)
	struct UParticleSystem* DirtFX;  // 0x308(0x8)
	struct UParticleSystem* MetalSolidFX;  // 0x310(0x8)
	struct UParticleSystem* WoodFX;  // 0x318(0x8)
	struct UParticleSystem* GlassBPFX;  // 0x320(0x8)
	struct UParticleSystem* GlassFX;  // 0x328(0x8)
	struct UParticleSystem* GlassWHFX;  // 0x330(0x8)
	struct UParticleSystem* GrassFX;  // 0x338(0x8)
	struct UParticleSystem* MetalThinFX;  // 0x340(0x8)
	struct UParticleSystem* SandbagFX;  // 0x348(0x8)
	struct UParticleSystem* BrickWallFX;  // 0x350(0x8)
	struct UParticleSystem* RubberFX;  // 0x358(0x8)
	struct UParticleSystem* DrywallFX;  // 0x360(0x8)
	struct UParticleSystem* ElectricDevicesFX;  // 0x368(0x8)
	struct UParticleSystem* OilBarrelFX;  // 0x370(0x8)
	struct UParticleSystem* SandFX;  // 0x378(0x8)
	struct UParticleSystem* SoftFX;  // 0x380(0x8)
	struct UParticleSystem* GroundFX;  // 0x388(0x8)
	struct UParticleSystem* RockFX;  // 0x390(0x8)
	struct UParticleSystem* FleshFX;  // 0x398(0x8)
	struct USoundCue* ConcreteSound;  // 0x3A0(0x8)
	struct USoundCue* DirtSound;  // 0x3A8(0x8)
	struct USoundCue* SnowSound;  // 0x3B0(0x8)
	struct USoundCue* SandbagSound;  // 0x3B8(0x8)
	struct USoundCue* BrickWallSound;  // 0x3C0(0x8)
	struct USoundCue* WaterSound;  // 0x3C8(0x8)
	struct USoundCue* MetalSolidSound;  // 0x3D0(0x8)
	struct USoundCue* MetalThinSound;  // 0x3D8(0x8)
	struct USoundCue* WoodSound;  // 0x3E0(0x8)
	struct USoundCue* GlassSound;  // 0x3E8(0x8)
	struct USoundCue* GlassBPSound;  // 0x3F0(0x8)
	struct USoundCue* GlassWHSound;  // 0x3F8(0x8)
	struct USoundCue* GrassSound;  // 0x400(0x8)
	struct USoundCue* RubberSound;  // 0x408(0x8)
	struct USoundCue* DrywallSound;  // 0x410(0x8)
	struct USoundCue* GroundSound;  // 0x418(0x8)
	struct USoundCue* ElectricDevicesSound;  // 0x420(0x8)
	struct USoundCue* OilBarrelSound;  // 0x428(0x8)
	struct USoundCue* RockSound;  // 0x430(0x8)
	struct USoundCue* FleshSound;  // 0x438(0x8)
	struct FDecalData DefaultDecal;  // 0x440(0x10)
	struct UParticleSystem* DefaultFX;  // 0x450(0x8)
	struct USoundCue* DefaultSound;  // 0x458(0x8)
	struct FHitResult SurfaceHit;  // 0x460(0x88)

	struct USoundCue* GetImpactSound(char EPhysicalSurface SurfaceType); // Function DonkehFramework.DFBaseImpactEffect.GetImpactSound
	struct UParticleSystem* GetImpactFX(char EPhysicalSurface SurfaceType); // Function DonkehFramework.DFBaseImpactEffect.GetImpactFX
}; 



// Class DonkehFramework.DFBaseGame_DeathMatch
// Size: 0x400(Inherited: 0x3F8) 
struct ADFBaseGame_DeathMatch : public ADFBaseGameMode
{
	struct ADFBasePlayerState* WinningPlayerState;  // 0x3F8(0x8)

}; 



// Class DonkehFramework.DFRecastNavMesh
// Size: 0x4B8(Inherited: 0x4B8) 
struct ADFRecastNavMesh : public ARecastNavMesh
{

}; 



// Class DonkehFramework.DFBaseGame_TeamDeathMatch
// Size: 0x3F8(Inherited: 0x3F8) 
struct ADFBaseGame_TeamDeathMatch : public ADFBaseGameMode
{

}; 



// Class DonkehFramework.DFLevelScriptActor
// Size: 0x228(Inherited: 0x228) 
struct ADFLevelScriptActor : public ALevelScriptActor
{

}; 



// Class DonkehFramework.DFFactionInfo
// Size: 0x90(Inherited: 0x30) 
struct UDFFactionInfo : public UDFPrimaryDataAsset
{
	struct FPrimaryAssetType FactionType;  // 0x30(0x8)
	struct FName FactionName;  // 0x38(0x8)
	char bVisibleInFactionSelectUI : 1;  // 0x40(0x1)
	char pad_64_1 : 7;  // 0x40(0x1)
	char pad_65[8];  // 0x41(0x8)
	struct FText DisplayName;  // 0x48(0x18)
	struct FText DisplayNameShort;  // 0x60(0x18)
	struct FText DisplayNameAcronym;  // 0x78(0x18)

}; 



// Class DonkehFramework.DFBaseGameInstance
// Size: 0x280(Inherited: 0x198) 
struct UDFBaseGameInstance : public UGameInstance
{
	char pad_408[216];  // 0x198(0xD8)
	struct FMulticastInlineDelegate OnPlayerStateTalkingStateChanged;  // 0x270(0x10)

	void ProjectVersion(); // Function DonkehFramework.DFBaseGameInstance.ProjectVersion
	void OnTravelFailure(struct UWorld* World, char ETravelFailure FailureType, struct FString ErrorString); // Function DonkehFramework.DFBaseGameInstance.OnTravelFailure
	void OnNetworkLagStateChanged(struct UWorld* World, struct UNetDriver* NetDriver, char ENetworkLagState LagType); // Function DonkehFramework.DFBaseGameInstance.OnNetworkLagStateChanged
	void OnNetworkFailure(struct UWorld* World, struct UNetDriver* NetDriver, char ENetworkFailure FailureType, struct FString ErrorString); // Function DonkehFramework.DFBaseGameInstance.OnNetworkFailure
	void JoinGameByIP(struct FString IPAddress, struct FString JoinPassword); // Function DonkehFramework.DFBaseGameInstance.JoinGameByIP
	void JoinGame(int32_t SearchResultIndex, struct FString JoinPassword); // Function DonkehFramework.DFBaseGameInstance.JoinGame
	bool IsHibernating(); // Function DonkehFramework.DFBaseGameInstance.IsHibernating
	void HostGame(struct FString TravelURL, bool bLANGame, int32_t MaxPlayers, struct FString HostName, struct FString Password); // Function DonkehFramework.DFBaseGameInstance.HostGame
	void ForceUpdateSession(); // Function DonkehFramework.DFBaseGameInstance.ForceUpdateSession
	void FindGames(uint8_t  SearchPresenceType); // Function DonkehFramework.DFBaseGameInstance.FindGames
	void DumpOnlineSessionState(); // Function DonkehFramework.DFBaseGameInstance.DumpOnlineSessionState
}; 



// Class DonkehFramework.DFBaseWeapon
// Size: 0x650(Inherited: 0x3A8) 
struct ADFBaseWeapon : public ADFBaseItem
{
	struct FMulticastInlineDelegate OnFire;  // 0x3A8(0x10)
	char bFiring : 1;  // 0x3B8(0x1)
	char pad_952_1 : 4;  // 0x3B8(0x1)
	char bReadyToFirePendingRelease : 1;  // 0x3B8(0x1)
	char bFireOnRelease : 1;  // 0x3B8(0x1)
	char pad_952_2 : 1;  // 0x3B8(0x1)
	char pad_953[4];  // 0x3B9(0x4)
	float PrefireDelayMin;  // 0x3BC(0x4)
	char bPrefiring : 1;  // 0x3C0(0x1)
	char pad_960_1 : 7;  // 0x3C0(0x1)
	char pad_961[72];  // 0x3C1(0x48)
	char bADSFireOnly : 1;  // 0x408(0x1)
	char bLastShotFired : 1;  // 0x408(0x1)
	char bRepCounterPending : 1;  // 0x408(0x1)
	char pad_1032_1 : 5;  // 0x408(0x1)
	char pad_1033[2];  // 0x409(0x2)
	struct FRepShotInfo FireCounter;  // 0x40A(0x4)
	struct FRepShotInfo PreviousRepFireCounter;  // 0x40E(0x4)
	struct FRepShotInfo PostStoppedFireCounter;  // 0x412(0x4)
	char pad_1046[2];  // 0x416(0x2)
	float LastFireTime;  // 0x418(0x4)
	float LastShotFireTime;  // 0x41C(0x4)
	char pad_1056[4];  // 0x420(0x4)
	char bUseServerSideFiringLogic : 1;  // 0x424(0x1)
	char bSimulateWeaponFireOnDedicatedServer : 1;  // 0x424(0x1)
	char pad_1060_1 : 6;  // 0x424(0x1)
	char pad_1061[4];  // 0x425(0x4)
	struct FWeaponAnimCollection WeaponAnimCollection;  // 0x428(0xF0)
	char bStopAllFireAnimsAfterFireRateDelay : 1;  // 0x518(0x1)
	char bSimulate1PWeaponFireOnPawnOwner1PMesh : 1;  // 0x518(0x1)
	char pad_1304_1 : 6;  // 0x518(0x1)
	char pad_1305[8];  // 0x519(0x8)
	struct FWeaponSoundCollection WeaponSoundCollection;  // 0x520(0x80)
	char bSingleAction : 1;  // 0x5A0(0x1)
	char bSingleLoad : 1;  // 0x5A0(0x1)
	char pad_1440_1 : 6;  // 0x5A0(0x1)
	char pad_1441[8];  // 0x5A1(0x8)
	struct USkeletalMeshComponent* WeaponMesh;  // 0x5A8(0x8)
	struct USkeletalMeshComponent* WeaponMesh1P;  // 0x5B0(0x8)
	char bCanSprintWhilePrefiring : 1;  // 0x5B8(0x1)
	char pad_1464_1 : 7;  // 0x5B8(0x1)
	char pad_1465[8];  // 0x5B9(0x8)
	struct FRuntimeFloatCurve DamageFalloffCurve;  // 0x5C0(0x88)
	UDamageType* DamageTypeClass;  // 0x648(0x8)

	void StopWeaponPerspectiveAnimation(struct FPerspectiveAnim& WeapAnim); // Function DonkehFramework.DFBaseWeapon.StopWeaponPerspectiveAnimation
	void StopWeaponMontage(struct UAnimMontage* WeapMontage); // Function DonkehFramework.DFBaseWeapon.StopWeaponMontage
	void StopSimulatingWeaponFire(bool bForceStopAll); // Function DonkehFramework.DFBaseWeapon.StopSimulatingWeaponFire
	void SimulateWeaponFire(); // Function DonkehFramework.DFBaseWeapon.SimulateWeaponFire
	bool ShouldSimulateWeaponFire(); // Function DonkehFramework.DFBaseWeapon.ShouldSimulateWeaponFire
	void ServerPreFire(); // Function DonkehFramework.DFBaseWeapon.ServerPreFire
	void ServerFireShot(struct FVector_NetQuantize Origin, struct FVector_NetQuantizeNormal ShootDir, int32_t RandomSeed, float Timestamp, int32_t ShotID); // Function DonkehFramework.DFBaseWeapon.ServerFireShot
	void ReceiveStopSimulatingWeaponFire(); // Function DonkehFramework.DFBaseWeapon.ReceiveStopSimulatingWeaponFire
	void ReceiveSimulateWeaponFire(); // Function DonkehFramework.DFBaseWeapon.ReceiveSimulateWeaponFire
	void ReceiveOnStopFiring(); // Function DonkehFramework.DFBaseWeapon.ReceiveOnStopFiring
	void ReceiveOnStartFiring(); // Function DonkehFramework.DFBaseWeapon.ReceiveOnStartFiring
	void ReceiveFire(); // Function DonkehFramework.DFBaseWeapon.ReceiveFire
	void PrefireDelayElapsed(bool bClientSimulation); // Function DonkehFramework.DFBaseWeapon.PrefireDelayElapsed
	float PlayWeaponUnEquipMontage(struct UAnimMontage* UnEquipMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponUnEquipMontage
	float PlayWeaponThrowUnderhandMontage(struct UAnimMontage* ThrowUnderhandMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponThrowUnderhandMontage
	float PlayWeaponThrowOverhandMontage(struct UAnimMontage* ThrowOverhandMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponThrowOverhandMontage
	struct UAudioComponent* PlayWeaponSound(struct FPerspectiveSound& Sound); // Function DonkehFramework.DFBaseWeapon.PlayWeaponSound
	float PlayWeaponPerspectiveAnimation(struct FPerspectiveAnim& WeapAnim); // Function DonkehFramework.DFBaseWeapon.PlayWeaponPerspectiveAnimation
	float PlayWeaponMontage(struct UAnimMontage* WeapMontage, bool bForceDisableAutoBlendOut); // Function DonkehFramework.DFBaseWeapon.PlayWeaponMontage
	float PlayWeaponFireMontage(struct UAnimMontage* FireMontageToPlay, bool bFireLast, bool bFireADS); // Function DonkehFramework.DFBaseWeapon.PlayWeaponFireMontage
	float PlayWeaponEquipMontage(struct UAnimMontage* EquipMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponEquipMontage
	float PlayWeaponCockMontage(struct UAnimMontage* CockMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponCockMontage
	float PlayWeaponActionMontage(struct UAnimMontage* ActionMontageToPlay); // Function DonkehFramework.DFBaseWeapon.PlayWeaponActionMontage
	float PlayThrowAnimations(bool bOverhandThrow, bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseWeapon.PlayThrowAnimations
	float PlayCockAnimations(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseWeapon.PlayCockAnimations
	void PlayActionAnimations(bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseWeapon.PlayActionAnimations
	void OnStopFiring(); // Function DonkehFramework.DFBaseWeapon.OnStopFiring
	void OnStartFiring(); // Function DonkehFramework.DFBaseWeapon.OnStartFiring
	void OnRep_FireCounter(struct FRepShotInfo& PreviousValue); // Function DonkehFramework.DFBaseWeapon.OnRep_FireCounter
	void OnRep_bPrefiring(); // Function DonkehFramework.DFBaseWeapon.OnRep_bPrefiring
	bool IsFiring(); // Function DonkehFramework.DFBaseWeapon.IsFiring
	void HandleFire(); // Function DonkehFramework.DFBaseWeapon.HandleFire
	struct USkeletalMeshComponent* GetWeaponMeshToUse(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseWeapon.GetWeaponMeshToUse
	struct USkeletalMeshComponent* GetWeaponMesh1P(); // Function DonkehFramework.DFBaseWeapon.GetWeaponMesh1P
	struct USkeletalMeshComponent* GetWeaponMesh(); // Function DonkehFramework.DFBaseWeapon.GetWeaponMesh
	struct UAnimMontage* GetMontageToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetMontageToUseFromPerspectiveAnimPair
	float GetMontagePlayLengthToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetMontagePlayLengthToUseFromPerspectiveAnimPair
	struct UAnimSequenceBase* GetAnimToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetAnimToUseFromPerspectiveAnimPair
	float GetAnimPlayLengthToUseFromPerspectiveAnimPair(struct FPerspectiveAnim& AnimationPair); // Function DonkehFramework.DFBaseWeapon.GetAnimPlayLengthToUseFromPerspectiveAnimPair
}; 



// Class DonkehFramework.DFBaseGun
// Size: 0x830(Inherited: 0x650) 
struct ADFBaseGun : public ADFBaseWeapon
{
	struct FMulticastInlineDelegate OnFireModeChanged;  // 0x650(0x10)
	char pad_1632[8];  // 0x660(0x8)
	float TimerIntervalAdjustment;  // 0x668(0x4)
	char pad_1644_1 : 7;  // 0x66C(0x1)
	bool bAllowAutomaticWeaponCatchup : 1;  // 0x66C(0x1)
	char pad_1645[3];  // 0x66D(0x3)
	float FireRate;  // 0x670(0x4)
	int32_t ShotsPerBurst;  // 0x674(0x4)
	char SupportedFireModes;  // 0x678(0x1)
	uint8_t  SelectedFireMode;  // 0x679(0x1)
	char pad_1658[6];  // 0x67A(0x6)
	struct UDFGunRecoilHandler* RecoilHandler;  // 0x680(0x8)
	struct FMulticastInlineDelegate OnReloadStarted;  // 0x688(0x10)
	struct FMulticastInlineDelegate OnReloadFinished;  // 0x698(0x10)
	uint8_t  PendingReloadState;  // 0x6A8(0x1)
	uint8_t  PreviousReloadState;  // 0x6A9(0x1)
	char bKeepLoadedAmmoOnLeaveInventory : 1;  // 0x6AA(0x1)
	char pad_1706_1 : 2;  // 0x6AA(0x1)
	char bUsesAmmo : 1;  // 0x6AA(0x1)
	char bExhaustible : 1;  // 0x6AA(0x1)
	char bCanSprintWhileReloading : 1;  // 0x6AA(0x1)
	char pad_1706_2 : 2;  // 0x6AA(0x1)
	char pad_1707[78];  // 0x6AB(0x4E)
	char bReloadOnEquip : 1;  // 0x6F8(0x1)
	char bInstantReloadOnEquip : 1;  // 0x6F8(0x1)
	char bInstantReloadOnInitialEquip : 1;  // 0x6F8(0x1)
	char bInstantReloadOnInitialEnterInventory : 1;  // 0x6F8(0x1)
	char bReloadOnDryFire : 1;  // 0x6F8(0x1)
	char bReloadOnStopFire : 1;  // 0x6F8(0x1)
	char bSimulateGunReloadOnDedicatedServer : 1;  // 0x6F8(0x1)
	char pad_1784_1 : 1;  // 0x6F8(0x1)
	uint8_t  AmmoClipReloadBehavior;  // 0x6F9(0x1)
	char pad_1786[6];  // 0x6FA(0x6)
	struct TSet<ADFBaseAmmoClip*> SupportedAmmoClips;  // 0x700(0x50)
	int32_t StartingAmmoClips;  // 0x750(0x4)
	char bDispensedStartingAmmoClips : 1;  // 0x754(0x1)
	char pad_1876_1 : 7;  // 0x754(0x1)
	char pad_1877[4];  // 0x755(0x4)
	struct ADFBaseAmmoClip* CurrentAmmoClip;  // 0x758(0x8)
	int32_t CurrentAmmoClipInvIndex;  // 0x760(0x4)
	char pad_1892[4];  // 0x764(0x4)
	struct ADFBaseAmmoClip* PreviousAmmoClip;  // 0x768(0x8)
	int32_t CurrentAmmoInClipBeforeReload;  // 0x770(0x4)
	int32_t ReloadCycleIterations;  // 0x774(0x4)
	char bInfiniteClipAmmo : 1;  // 0x778(0x1)
	char bInfiniteAmmo : 1;  // 0x778(0x1)
	char bNoRecoil : 1;  // 0x778(0x1)
	char pad_1912_1 : 5;  // 0x778(0x1)
	char pad_1913[8];  // 0x779(0x8)
	struct FComponentReference CustomMuzzleAttachComponentToUse;  // 0x780(0x28)
	struct FName MuzzleAttachComponentName;  // 0x7A8(0x8)
	struct FName MuzzleAttachPoint;  // 0x7B0(0x8)
	struct UParticleSystem* MuzzleFX;  // 0x7B8(0x8)
	struct FVector MuzzleLocationOffset;  // 0x7C0(0xC)
	struct FRotator MuzzleRotationOffset;  // 0x7CC(0xC)
	char bLoopedMuzzleFX : 1;  // 0x7D8(0x1)
	char pad_2008_1 : 7;  // 0x7D8(0x1)
	char pad_2009[8];  // 0x7D9(0x8)
	struct UParticleSystemComponent* MuzzlePSC;  // 0x7E0(0x8)
	struct FName ShellEjectAttachPoint;  // 0x7E8(0x8)
	struct UParticleSystem* ShellEjectFX;  // 0x7F0(0x8)
	struct FVector ShellEjectLocationOffset;  // 0x7F8(0xC)
	struct FRotator ShellEjectRotationOffset;  // 0x804(0xC)
	char bLoopedShellEjectFX : 1;  // 0x810(0x1)
	char bPlayShellEjectFXOnFireLast : 1;  // 0x810(0x1)
	char pad_2064_1 : 6;  // 0x810(0x1)
	char pad_2065[4];  // 0x811(0x4)
	float ShellEjectDelay;  // 0x814(0x4)
	struct UParticleSystemComponent* ShellEjectPSC;  // 0x818(0x8)
	char pad_2080[16];  // 0x820(0x10)

	void UnloadCurrentAmmoClip(); // Function DonkehFramework.DFBaseGun.UnloadCurrentAmmoClip
	void StopSimulatingGunReload(); // Function DonkehFramework.DFBaseGun.StopSimulatingGunReload
	void StartReload(bool bClientSimulation); // Function DonkehFramework.DFBaseGun.StartReload
	void SimulateGunReload(); // Function DonkehFramework.DFBaseGun.SimulateGunReload
	bool ShouldUseRecoil(); // Function DonkehFramework.DFBaseGun.ShouldUseRecoil
	bool ShouldSimulateGunReload(); // Function DonkehFramework.DFBaseGun.ShouldSimulateGunReload
	void SetReloadState(uint8_t  NewReloadState); // Function DonkehFramework.DFBaseGun.SetReloadState
	void SetFireModeBP(uint8_t  NewFireMode); // Function DonkehFramework.DFBaseGun.SetFireModeBP
	bool SetFireMode(uint8_t  NewFireMode, bool bFromPlayerInput, bool bForce); // Function DonkehFramework.DFBaseGun.SetFireMode
	void ServerStartReload(); // Function DonkehFramework.DFBaseGun.ServerStartReload
	void ServerSetFireMode(uint8_t  NewFireMode); // Function DonkehFramework.DFBaseGun.ServerSetFireMode
	void ReceiveReloadStarted(); // Function DonkehFramework.DFBaseGun.ReceiveReloadStarted
	void ReceiveReloadFinished(); // Function DonkehFramework.DFBaseGun.ReceiveReloadFinished
	void ReceiveFireModeChanged(uint8_t  NewFireMode, uint8_t  PrevFireMode, bool bFromPlayerInput); // Function DonkehFramework.DFBaseGun.ReceiveFireModeChanged
	void ReceiveAmmoExhausted(); // Function DonkehFramework.DFBaseGun.ReceiveAmmoExhausted
	float PlayWeaponStartReloadMontage(struct UAnimMontage* StartReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseGun.PlayWeaponStartReloadMontage
	float PlayWeaponReloadMontage(bool bDryReload); // Function DonkehFramework.DFBaseGun.PlayWeaponReloadMontage
	float PlayWeaponEndReloadMontage(struct UAnimMontage* EndReloadMontageToPlay, bool bDryReload); // Function DonkehFramework.DFBaseGun.PlayWeaponEndReloadMontage
	float PlayReloadTransitionAnimations(bool bStartReload, bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseGun.PlayReloadTransitionAnimations
	float PlayReloadAnimations(bool bDryReload, bool bDontPlayAndReturnDominantPlayLengthOnly); // Function DonkehFramework.DFBaseGun.PlayReloadAnimations
	void OnRep_SelectedFireMode(uint8_t  PrevSelectedFireMode); // Function DonkehFramework.DFBaseGun.OnRep_SelectedFireMode
	void OnRep_PendingReloadState(uint8_t  PrevReloadState); // Function DonkehFramework.DFBaseGun.OnRep_PendingReloadState
	void OnRep_CurrentAmmoClip(struct ADFBaseAmmoClip* PrevAmmoClip); // Function DonkehFramework.DFBaseGun.OnRep_CurrentAmmoClip
	void OnReload(bool bClientSimulation); // Function DonkehFramework.DFBaseGun.OnReload
	void LoadPreviousAmmoClip(); // Function DonkehFramework.DFBaseGun.LoadPreviousAmmoClip
	void LoadNextAmmoClip(); // Function DonkehFramework.DFBaseGun.LoadNextAmmoClip
	void LoadAmmoClip(struct ADFBaseAmmoClip* ClipToLoad); // Function DonkehFramework.DFBaseGun.LoadAmmoClip
	bool IsReloading(); // Function DonkehFramework.DFBaseGun.IsReloading
	bool IsDryReloading(); // Function DonkehFramework.DFBaseGun.IsDryReloading
	bool HasExhaustedAllAmmo(); // Function DonkehFramework.DFBaseGun.HasExhaustedAllAmmo
	bool HasAmmoClip(); // Function DonkehFramework.DFBaseGun.HasAmmoClip
	int32_t GetTotalAmmo(bool bIncludeLoadedMags); // Function DonkehFramework.DFBaseGun.GetTotalAmmo
	char GetSupportedFireModes(); // Function DonkehFramework.DFBaseGun.GetSupportedFireModes
	struct FName GetShellEjectAttachPoint(); // Function DonkehFramework.DFBaseGun.GetShellEjectAttachPoint
	uint8_t  GetSelectedFireMode(); // Function DonkehFramework.DFBaseGun.GetSelectedFireMode
	uint8_t  GetReloadState(); // Function DonkehFramework.DFBaseGun.GetReloadState
	uint8_t  GetPreviousReloadState(); // Function DonkehFramework.DFBaseGun.GetPreviousReloadState
	int32_t GetNumFreeAmmoClips(bool bIncludeEmptyMags, bool bIncludeCurrentMag); // Function DonkehFramework.DFBaseGun.GetNumFreeAmmoClips
	struct FVector GetMuzzleLocation(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseGun.GetMuzzleLocation
	struct FVector GetMuzzleDirection(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseGun.GetMuzzleDirection
	struct FName GetMuzzleAttachPoint(); // Function DonkehFramework.DFBaseGun.GetMuzzleAttachPoint
	struct USceneComponent* GetMuzzleAttachComponent(bool bIgnoreLocalControlOnServer); // Function DonkehFramework.DFBaseGun.GetMuzzleAttachComponent
	int32_t GetClipAmmo(); // Function DonkehFramework.DFBaseGun.GetClipAmmo
	bool CanReload(); // Function DonkehFramework.DFBaseGun.CanReload
}; 



// Class DonkehFramework.DFBaseGun_Projectile
// Size: 0x858(Inherited: 0x830) 
struct ADFBaseGun_Projectile : public ADFBaseGun
{
	ADFBaseProjectile* ProjectileClass;  // 0x830(0x8)
	float ProjectileSpawnDistance;  // 0x838(0x4)
	float TargetTraceDistance;  // 0x83C(0x4)
	char pad_2112_1 : 7;  // 0x840(0x1)
	bool bUseMuzzleAsTrace : 1;  // 0x840(0x1)
	char pad_2113[3];  // 0x841(0x3)
	struct FVector MuzzleSightOffset;  // 0x844(0xC)
	struct FMulticastSparseDelegate OnProcessValidProjCSHit;  // 0x850(0x1)
	char pad_2129[7];  // 0x851(0x7)

	void ServerNotifyCSHitPredicted(struct FCSHitInfo HitInfo, int32_t ShotID); // Function DonkehFramework.DFBaseGun_Projectile.ServerNotifyCSHitPredicted
	void ServerNotifyCSHit(struct ADFBaseProjectile* HitProj, struct FCSHitInfo HitInfo, int32_t ShotID); // Function DonkehFramework.DFBaseGun_Projectile.ServerNotifyCSHit
	void ClientProjDebugInfo(struct ADFBaseProjectile* Proj, struct FVector NewProjLoc, struct FVector LastProjLoc, struct FRotator NewProjRot, struct FVector NewProjVel); // Function DonkehFramework.DFBaseGun_Projectile.ClientProjDebugInfo
	void ClientProjDebugImpactInfo(struct ADFBaseProjectile* Proj, struct FVector ImpactLoc, struct FVector_NetQuantizeNormal ImpactNorm); // Function DonkehFramework.DFBaseGun_Projectile.ClientProjDebugImpactInfo
	void ClientDrawDebugFireCone(struct FVector ConeOrig, struct FVector_NetQuantizeNormal ConeDir); // Function DonkehFramework.DFBaseGun_Projectile.ClientDrawDebugFireCone
	void CalcShotVector(struct FVector& OutProjOrigin, struct FVector& OutProjDir); // Function DonkehFramework.DFBaseGun_Projectile.CalcShotVector
}; 



// Class DonkehFramework.DFInfo
// Size: 0x220(Inherited: 0x220) 
struct ADFInfo : public AInfo
{

}; 



// Class DonkehFramework.DFBasePickup
// Size: 0x258(Inherited: 0x220) 
struct ADFBasePickup : public AActor
{
	char pad_544[8];  // 0x220(0x8)
	struct UStaticMeshComponent* Mesh;  // 0x228(0x8)
	char bActive : 1;  // 0x230(0x1)
	char pad_560_1 : 7;  // 0x230(0x1)
	char pad_561[8];  // 0x231(0x8)
	struct ADFBaseCharacter* InvokingPawn;  // 0x238(0x8)
	char pad_576[8];  // 0x240(0x8)
	char bUseable : 1;  // 0x248(0x1)
	char bOverlap : 1;  // 0x248(0x1)
	char pad_584_1 : 6;  // 0x248(0x1)
	char pad_585[4];  // 0x249(0x4)
	float RespawnDelay;  // 0x24C(0x4)
	struct USoundCue* PickupSound;  // 0x250(0x8)

	void UpdatePickupState(bool bNewActive); // Function DonkehFramework.DFBasePickup.UpdatePickupState
	void RespawnPickup(); // Function DonkehFramework.DFBasePickup.RespawnPickup
	void OnRespawn(); // Function DonkehFramework.DFBasePickup.OnRespawn
	void OnRep_Active(); // Function DonkehFramework.DFBasePickup.OnRep_Active
	void OnPickup(); // Function DonkehFramework.DFBasePickup.OnPickup
	void InitializePickup(); // Function DonkehFramework.DFBasePickup.InitializePickup
	void GivePickupTo(struct ADFBaseCharacter* PickupOwner); // Function DonkehFramework.DFBasePickup.GivePickupTo
	bool CanBePickedUp(struct ADFBaseCharacter* Invoker); // Function DonkehFramework.DFBasePickup.CanBePickedUp
}; 



// Class DonkehFramework.DFBasePickup_Health
// Size: 0x260(Inherited: 0x258) 
struct ADFBasePickup_Health : public ADFBasePickup
{
	float Health;  // 0x258(0x4)
	char pad_604[4];  // 0x25C(0x4)

}; 



// Class DonkehFramework.DFBasePickup_Item
// Size: 0x260(Inherited: 0x258) 
struct ADFBasePickup_Item : public ADFBasePickup
{
	struct UDFInventoryComponent* Inventory;  // 0x258(0x8)

}; 



// Class DonkehFramework.DFHandlerInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFHandlerInterface : public UInterface
{

	void EventUpdate(float DeltaTime, bool bMakeDecision); // Function DonkehFramework.DFHandlerInterface.EventUpdate
	bool EventShouldUpdateThisFrame(float DeltaTime, bool bActiveAndSpawnedInWorld); // Function DonkehFramework.DFHandlerInterface.EventShouldUpdateThisFrame
	void EventRespawn(); // Function DonkehFramework.DFHandlerInterface.EventRespawn
	void EventReset(); // Function DonkehFramework.DFHandlerInterface.EventReset
	void EventOnNewPawn(struct APawn* NewPawn, struct APawn* PreviousPawn); // Function DonkehFramework.DFHandlerInterface.EventOnNewPawn
	void EventInit(); // Function DonkehFramework.DFHandlerInterface.EventInit
}; 



// Class DonkehFramework.DFBasePlayerCharacter
// Size: 0x970(Inherited: 0x910) 
struct ADFBasePlayerCharacter : public ADFBaseCharacter
{
	float BaseTurnRate;  // 0x908(0x4)
	float BaseLookUpRate;  // 0x90C(0x4)
	float InteractionDistance;  // 0x914(0x4)
	char bFirstPerson : 1;  // 0x918(0x1)
	char pad_2332_1 : 7;  // 0x91C(0x1)
	char pad_2333[4];  // 0x91D(0x4)
	struct UCameraComponent* Camera;  // 0x920(0x8)
	struct USpringArmComponent* CameraBoom;  // 0x928(0x8)
	struct UCameraComponent* Camera1P;  // 0x930(0x8)
	char bStartInFirstPerson : 1;  // 0x938(0x1)
	char bTrueFirstPerson : 1;  // 0x938(0x1)
	char bDisableOrientationOfRotationToMovementInFirstPerson : 1;  // 0x938(0x1)
	char bDisableUsageOfControllerRotationYawInThirdPerson : 1;  // 0x938(0x1)
	char pad_2360_1 : 4;  // 0x938(0x1)
	char pad_2361[8];  // 0x939(0x8)
	struct USkeletalMeshComponent* Mesh1P;  // 0x940(0x8)
	char bUseFirstPersonMesh : 1;  // 0x948(0x1)
	char pad_2376_1 : 7;  // 0x948(0x1)
	char pad_2377[4];  // 0x949(0x4)
	struct FName ItemAttachPoint1P;  // 0x94C(0x8)
	char pad_2388[4];  // 0x954(0x4)
	struct FMulticastInlineDelegate OnPlayerToggleFirstPerson;  // 0x958(0x10)
	char pad_2408[8];  // 0x968(0x8)

	void Use(); // Function DonkehFramework.DFBasePlayerCharacter.Use
	void TurnAtRate(float Rate); // Function DonkehFramework.DFBasePlayerCharacter.TurnAtRate
	void SwitchFireMode(); // Function DonkehFramework.DFBasePlayerCharacter.SwitchFireMode
	void SetMeshVisibility(bool bFirstPersonVisibility); // Function DonkehFramework.DFBasePlayerCharacter.SetMeshVisibility
	void ServerUse(); // Function DonkehFramework.DFBasePlayerCharacter.ServerUse
	void ServerOnToggleFirstPerson(bool bNewFirstPerson); // Function DonkehFramework.DFBasePlayerCharacter.ServerOnToggleFirstPerson
	struct USkeletalMesh* ReceiveGetDefaultPawnMesh1P(); // Function DonkehFramework.DFBasePlayerCharacter.ReceiveGetDefaultPawnMesh1P
	void OnToggleFirstPerson(bool bNewFirstPerson); // Function DonkehFramework.DFBasePlayerCharacter.OnToggleFirstPerson
	void OnFireReleased(); // Function DonkehFramework.DFBasePlayerCharacter.OnFireReleased
	void OnFirePressed(); // Function DonkehFramework.DFBasePlayerCharacter.OnFirePressed
	void MoveUp(float Value); // Function DonkehFramework.DFBasePlayerCharacter.MoveUp
	void MoveRight(float Value); // Function DonkehFramework.DFBasePlayerCharacter.MoveRight
	void MoveForward(float Value); // Function DonkehFramework.DFBasePlayerCharacter.MoveForward
	void LookUpAtRate(float Rate); // Function DonkehFramework.DFBasePlayerCharacter.LookUpAtRate
	void JumpVaultPressed(); // Function DonkehFramework.DFBasePlayerCharacter.JumpVaultPressed
	bool IsUsingFirstPersonMesh(); // Function DonkehFramework.DFBasePlayerCharacter.IsUsingFirstPersonMesh
	bool IsTrueFirstPerson(); // Function DonkehFramework.DFBasePlayerCharacter.IsTrueFirstPerson
	bool IsLocalFirstPerson(); // Function DonkehFramework.DFBasePlayerCharacter.IsLocalFirstPerson
	bool IsFirstPerson(); // Function DonkehFramework.DFBasePlayerCharacter.IsFirstPerson
	struct USkeletalMeshComponent* GetMesh1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetMesh1P
	struct FName GetItemAttachPoint1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetItemAttachPoint1P
	struct USkeletalMesh* GetDefaultPawnMesh1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetDefaultPawnMesh1P
	struct USpringArmComponent* GetCameraBoom(); // Function DonkehFramework.DFBasePlayerCharacter.GetCameraBoom
	struct UCameraComponent* GetCamera1P(); // Function DonkehFramework.DFBasePlayerCharacter.GetCamera1P
	struct UCameraComponent* GetCamera(); // Function DonkehFramework.DFBasePlayerCharacter.GetCamera
}; 



// Class DonkehFramework.DFBasePlayerState
// Size: 0x378(Inherited: 0x320) 
struct ADFBasePlayerState : public APlayerState
{
	char pad_800[8];  // 0x320(0x8)
	struct FMulticastInlineDelegate OnRepPlayerName;  // 0x328(0x10)
	struct FMulticastInlineDelegate OnPlayerTeamNumUpdated;  // 0x338(0x10)
	char TeamNum;  // 0x348(0x1)
	char PrevTeamNum;  // 0x349(0x1)
	char pad_842[6];  // 0x34A(0x6)
	struct ADFTeamState* TeamState;  // 0x350(0x8)
	struct ADFTeamState* PrevTeamState;  // 0x358(0x8)
	char bAdmin : 1;  // 0x360(0x1)
	char pad_864_1 : 7;  // 0x360(0x1)
	char pad_865[4];  // 0x361(0x4)
	int32_t NumKills;  // 0x364(0x4)
	int32_t NumAssists;  // 0x368(0x4)
	int32_t NumDeaths;  // 0x36C(0x4)
	int32_t TeamStartTime;  // 0x370(0x4)
	char pad_884[4];  // 0x374(0x4)

	void SetTeam(char NewTeamNum, bool bCopyToInactivePlayerState); // Function DonkehFramework.DFBasePlayerState.SetTeam
	void SetAdminStatus(bool bNewAdminStatus); // Function DonkehFramework.DFBasePlayerState.SetAdminStatus
	void ScorePoints(float Points, bool bForceNetUpdate); // Function DonkehFramework.DFBasePlayerState.ScorePoints
	void ScoreKillPlayer(struct ADFBasePlayerState* Victim, float Points); // Function DonkehFramework.DFBasePlayerState.ScoreKillPlayer
	void ScoreDeath(struct ADFBasePlayerState* KilledBy, float Points); // Function DonkehFramework.DFBasePlayerState.ScoreDeath
	void ScoreAssistPlayer(struct ADFBasePlayerState* Killer, struct ADFBasePlayerState* Victim, float Points); // Function DonkehFramework.DFBasePlayerState.ScoreAssistPlayer
	void ReceiveOnRepPlayerName(); // Function DonkehFramework.DFBasePlayerState.ReceiveOnRepPlayerName
	void OnTeamStateUpdated(struct ADFTeamState* TeamStateBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnTeamStateUpdated
	void OnTeamNumUpdated(char TeamNumBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnTeamNumUpdated
	void OnRep_TeamState(struct ADFTeamState* TeamStateBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnRep_TeamState
	void OnRep_TeamNum(char TeamNumBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnRep_TeamNum
	void OnRep_NumKills(int32_t PrevNumKills); // Function DonkehFramework.DFBasePlayerState.OnRep_NumKills
	void OnRep_NumDeaths(int32_t PrevNumDeaths); // Function DonkehFramework.DFBasePlayerState.OnRep_NumDeaths
	void OnRep_NumAssists(int32_t PrevNumAssists); // Function DonkehFramework.DFBasePlayerState.OnRep_NumAssists
	void OnRep_bAdmin(bool bAdminStatusBeforeUpdate); // Function DonkehFramework.DFBasePlayerState.OnRep_bAdmin
	char GetTeam(); // Function DonkehFramework.DFBasePlayerState.GetTeam
	char GetPreviousTeam(); // Function DonkehFramework.DFBasePlayerState.GetPreviousTeam
	int32_t GetKills(); // Function DonkehFramework.DFBasePlayerState.GetKills
	int32_t GetDeaths(); // Function DonkehFramework.DFBasePlayerState.GetDeaths
	int32_t GetAssists(); // Function DonkehFramework.DFBasePlayerState.GetAssists
}; 



// Class DonkehFramework.DFBaseProjectile
// Size: 0x380(Inherited: 0x220) 
struct ADFBaseProjectile : public AActor
{
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x220(0x8)
	ADFBaseImpactEffect* ProjectileImpactFXClass;  // 0x228(0x8)
	struct FTransform SpawnTransform;  // 0x230(0x30)
	int32_t ShotID;  // 0x260(0x4)
	struct FVector LastLoc;  // 0x264(0xC)
	char bSpawnImpactFXOnHit : 1;  // 0x270(0x1)
	char bAlwaysShootable : 1;  // 0x270(0x1)
	char bIgnoreInstigator : 1;  // 0x270(0x1)
	char bIgnoreInstigatorOnPayloadActivation : 1;  // 0x270(0x1)
	char pad_624_1 : 4;  // 0x270(0x1)
	char pad_625[8];  // 0x271(0x8)
	struct AController* InstigatingController;  // 0x278(0x8)
	char bDebug : 1;  // 0x280(0x1)
	char pad_640_1 : 7;  // 0x280(0x1)
	struct FMulticastSparseDelegate OnProcessValidHit;  // 0x281(0x1)
	char bIgnoreInstigatorHitEventsOnly : 1;  // 0x282(0x1)
	char bProcessedAHit : 1;  // 0x282(0x1)
	char bClientSideHitDetectionEnabled : 1;  // 0x282(0x1)
	char bClientSideHitDamageEnabled : 1;  // 0x282(0x1)
	char bNotifyOfPredictedProjectileHits : 1;  // 0x282(0x1)
	char bOnlyNotifyOfPredictedProjectileHits : 1;  // 0x282(0x1)
	char pad_642_1 : 2;  // 0x282(0x1)
	char pad_643[2];  // 0x283(0x2)
	struct FCSHitInfo PendingHitInfo;  // 0x284(0x70)
	char pad_756[4];  // 0x2F4(0x4)
	struct AActor* ImpactedActor;  // 0x2F8(0x8)
	char bApplyDamageOnImpact : 1;  // 0x300(0x1)
	char bApplyDamageOnBounceImpact : 1;  // 0x300(0x1)
	char bApplyDamageToInstigator : 1;  // 0x300(0x1)
	char pad_768_1 : 5;  // 0x300(0x1)
	char pad_769[4];  // 0x301(0x4)
	struct FDFDamageParams BaseDamageParams;  // 0x304(0x14)
	UDamageType* WeaponDamageTypeClass;  // 0x318(0x8)
	struct FVector RadialDamageOriginOffset;  // 0x320(0xC)
	char ECollisionChannel RadialDamagePreventionChannel;  // 0x32C(0x1)
	char bWantsToUseClientSidePrediction : 1;  // 0x32D(0x1)
	char bReconcilePredictedProjWithServerProj : 1;  // 0x32D(0x1)
	char bPredictedClientProjectile : 1;  // 0x32D(0x1)
	char pad_813_1 : 5;  // 0x32D(0x1)
	char pad_814[3];  // 0x32E(0x3)
	struct ADFBaseProjectile* MyPredictedClientProjectile;  // 0x330(0x8)
	struct ADFBaseProjectile* ServerAuthoritativeProjectile;  // 0x338(0x8)
	char pad_832[49];  // 0x340(0x31)
	struct FMulticastSparseDelegate OnTriggerPayload;  // 0x371(0x1)
	char bPayloadTriggered : 1;  // 0x372(0x1)
	char bTriggerPayloadWhenStopped : 1;  // 0x372(0x1)
	char bTearOffOnPayloadActivation : 1;  // 0x372(0x1)
	char bDisableOnPayloadActivation : 1;  // 0x372(0x1)
	char pad_882_1 : 4;  // 0x372(0x1)
	char pad_883[14];  // 0x373(0xE)

	void TriggerPayload(struct FHitResult& ImpactHitResult, bool bFromTearOff); // Function DonkehFramework.DFBaseProjectile.TriggerPayload
	void SpawnImpactFX(struct FHitResult& Impact); // Function DonkehFramework.DFBaseProjectile.SpawnImpactFX
	void SetProjectileUpdatedComponent(struct USceneComponent* NewProjectileUpdatedComponent); // Function DonkehFramework.DFBaseProjectile.SetProjectileUpdatedComponent
	void ReceivePayloadActivated(struct FHitResult& ImpactHitResult); // Function DonkehFramework.DFBaseProjectile.ReceivePayloadActivated
	void ProjectileStop(struct FHitResult& ImpactResult); // Function DonkehFramework.DFBaseProjectile.ProjectileStop
	void ProjectileBounce(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function DonkehFramework.DFBaseProjectile.ProjectileBounce
	bool K2_ShouldIgnoreHit(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FHitResult& HitResult); // Function DonkehFramework.DFBaseProjectile.K2_ShouldIgnoreHit
	void K2_PostProcessValidHit(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector& HitLocation, struct FVector& HitNormal, struct FHitResult& HitResult, bool bFromCSHitNotify); // Function DonkehFramework.DFBaseProjectile.K2_PostProcessValidHit
	void IgnoreInstigatorWhenMoving(bool bShouldIgnore, bool bBidirectional); // Function DonkehFramework.DFBaseProjectile.IgnoreInstigatorWhenMoving
	bool HasValidPredictedClientProjectile(); // Function DonkehFramework.DFBaseProjectile.HasValidPredictedClientProjectile
	struct UPrimitiveComponent* GetProjectileUpdatedPrimitive(); // Function DonkehFramework.DFBaseProjectile.GetProjectileUpdatedPrimitive
	struct USceneComponent* GetProjectileUpdatedComponent(); // Function DonkehFramework.DFBaseProjectile.GetProjectileUpdatedComponent
	struct ADFBaseWeapon* GetOwningWeapon(); // Function DonkehFramework.DFBaseProjectile.GetOwningWeapon
	ADFBaseImpactEffect* GetImpactFXClass(); // Function DonkehFramework.DFBaseProjectile.GetImpactFXClass
	struct FDFDamageParams GetAdjustedDamageParams(struct AActor* OtherActor, struct FVector& HitLocation); // Function DonkehFramework.DFBaseProjectile.GetAdjustedDamageParams
	void DisableAndDeferDestroy(); // Function DonkehFramework.DFBaseProjectile.DisableAndDeferDestroy
	float ApplyDamageToImpactedActor(struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector& HitLocation, struct FVector& HitNormal, struct FHitResult& HitResult); // Function DonkehFramework.DFBaseProjectile.ApplyDamageToImpactedActor
}; 



// Class DonkehFramework.DFCheatManager
// Size: 0x78(Inherited: 0x78) 
struct UDFCheatManager : public UCheatManager
{

	void ToggleItemDebug(); // Function DonkehFramework.DFCheatManager.ToggleItemDebug
	void ToggleGunRecoil(); // Function DonkehFramework.DFCheatManager.ToggleGunRecoil
	void ToggleGunInfiniteClipAmmo(); // Function DonkehFramework.DFCheatManager.ToggleGunInfiniteClipAmmo
	void ToggleGunInfiniteAmmo(); // Function DonkehFramework.DFCheatManager.ToggleGunInfiniteAmmo
}; 



// Class DonkehFramework.DFPhysicsCollisionHandler
// Size: 0x40(Inherited: 0x40) 
struct UDFPhysicsCollisionHandler : public UPhysicsCollisionHandler
{

}; 



// Class DonkehFramework.DFBaseProjectileLegacy
// Size: 0x340(Inherited: 0x220) 
struct ADFBaseProjectileLegacy : public AActor
{
	struct UPrimitiveComponent* ProjectileCollision;  // 0x220(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x228(0x8)
	ADFBaseImpactEffect* ProjectileImpactFXClass;  // 0x230(0x8)
	char pad_568[8];  // 0x238(0x8)
	struct FTransform SpawnTransform;  // 0x240(0x30)
	struct FVector LastLoc;  // 0x270(0xC)
	char bListenForImpactEvents : 1;  // 0x27C(0x1)
	char bIgnoreInstigator : 1;  // 0x27C(0x1)
	char pad_636_1 : 6;  // 0x27C(0x1)
	char pad_637[4];  // 0x27D(0x4)
	struct AController* InstigatingController;  // 0x280(0x8)
	float ActiveLifeSpan;  // 0x288(0x4)
	char pad_652[12];  // 0x28C(0xC)
	UDamageType* WeaponDamageTypeClass;  // 0x298(0x8)
	char bDebug : 1;  // 0x2A0(0x1)
	char bApplyDamageFromPayload : 1;  // 0x2A0(0x1)
	char pad_672_1 : 6;  // 0x2A0(0x1)
	char pad_673[4];  // 0x2A1(0x4)
	float HitDamage;  // 0x2A4(0x4)
	char bApplyRadialDamage : 1;  // 0x2A8(0x1)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	char pad_681[4];  // 0x2A9(0x4)
	struct FVector RadialDamageLocOffset;  // 0x2AC(0xC)
	char ECollisionChannel RadialDamagePreventionChannel;  // 0x2B8(0x1)
	char pad_697[3];  // 0x2B9(0x3)
	float DamageRadius;  // 0x2BC(0x4)
	char bPayloadTriggered : 1;  // 0x2C0(0x1)
	char bTriggerPayloadWhenStopped : 1;  // 0x2C0(0x1)
	char bTriggerPayloadOnDelay : 1;  // 0x2C0(0x1)
	char pad_704_1 : 5;  // 0x2C0(0x1)
	char pad_705[4];  // 0x2C1(0x4)
	float PayloadTriggerDelay;  // 0x2C4(0x4)
	struct UParticleSystem* PayloadTriggerFX;  // 0x2C8(0x8)
	char bAttachTriggerFXToRoot : 1;  // 0x2D0(0x1)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	char pad_721[8];  // 0x2D1(0x8)
	struct UParticleSystemComponent* TriggerFXPSC;  // 0x2D8(0x8)
	struct USoundBase* PayloadTriggerSnd;  // 0x2E0(0x8)
	char bAttachTriggerSndToRoot : 1;  // 0x2E8(0x1)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	char pad_745[8];  // 0x2E9(0x8)
	struct UAudioComponent* TriggerSnd;  // 0x2F0(0x8)
	char pad_760[72];  // 0x2F8(0x48)

	void TriggerPayload(struct FHitResult& ImpactHitResult); // Function DonkehFramework.DFBaseProjectileLegacy.TriggerPayload
	void StopSimulatingPayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.StopSimulatingPayloadActivation
	void SpawnImpactFX(struct FHitResult& Impact); // Function DonkehFramework.DFBaseProjectileLegacy.SpawnImpactFX
	void SimulatePayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.SimulatePayloadActivation
	void ReceiveStopSimulatingPayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.ReceiveStopSimulatingPayloadActivation
	void ReceiveSimulatePayloadActivation(); // Function DonkehFramework.DFBaseProjectileLegacy.ReceiveSimulatePayloadActivation
	void ReceivePayloadActivated(struct FHitResult& ImpactHitResult); // Function DonkehFramework.DFBaseProjectileLegacy.ReceivePayloadActivated
	void ProjectileStop(struct FHitResult& ImpactResult); // Function DonkehFramework.DFBaseProjectileLegacy.ProjectileStop
	void ProjectileBounce(struct FHitResult& ImpactResult, struct FVector& ImpactVelocity); // Function DonkehFramework.DFBaseProjectileLegacy.ProjectileBounce
	void PayloadDelayElapsed(); // Function DonkehFramework.DFBaseProjectileLegacy.PayloadDelayElapsed
	void OnRep_bPayloadTriggered(); // Function DonkehFramework.DFBaseProjectileLegacy.OnRep_bPayloadTriggered
	struct ADFBaseWeapon* GetOwningWeapon(); // Function DonkehFramework.DFBaseProjectileLegacy.GetOwningWeapon
}; 



// Class DonkehFramework.DFGameRulesetBase
// Size: 0x58(Inherited: 0x28) 
struct UDFGameRulesetBase : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	char bTickable : 1;  // 0x30(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	char pad_49[8];  // 0x31(0x8)
	struct FText DisplayName;  // 0x38(0x18)
	int32_t Priority;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

	void UnregisterActor(struct AActor* UnregisteredActor); // Function DonkehFramework.DFGameRulesetBase.UnregisterActor
	void RegisterActor(struct AActor* RegisteredActor); // Function DonkehFramework.DFGameRulesetBase.RegisterActor
	void ReceiveTick(float DeltaTime); // Function DonkehFramework.DFGameRulesetBase.ReceiveTick
	void PlayerWounded(struct AController* Victim, float DamageAmount, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function DonkehFramework.DFGameRulesetBase.PlayerWounded
	void PlayerSuicide(struct AController* Victim); // Function DonkehFramework.DFGameRulesetBase.PlayerSuicide
	void PlayerSpawn(struct AController* Player, struct APawn* NewPlayerPawn); // Function DonkehFramework.DFGameRulesetBase.PlayerSpawn
	void PlayerPostLogout(struct AController* ExitingPlayer); // Function DonkehFramework.DFGameRulesetBase.PlayerPostLogout
	void PlayerPostLogin(struct APlayerController* NewPlayer); // Function DonkehFramework.DFGameRulesetBase.PlayerPostLogin
	void PlayerKilled(struct AController* Killer, struct AController* Victim); // Function DonkehFramework.DFGameRulesetBase.PlayerKilled
	void PlayerJoinedTeam(struct AController* JoiningPlayer, char TeamNum); // Function DonkehFramework.DFGameRulesetBase.PlayerJoinedTeam
	void PlayerJoined(struct APlayerController* NewPlayer); // Function DonkehFramework.DFGameRulesetBase.PlayerJoined
	void PlayerDied(struct AController* Victim); // Function DonkehFramework.DFGameRulesetBase.PlayerDied
	void MatchHasEnded(); // Function DonkehFramework.DFGameRulesetBase.MatchHasEnded
	void Init(); // Function DonkehFramework.DFGameRulesetBase.Init
	struct ADFBaseGameState* GetGameState(); // Function DonkehFramework.DFGameRulesetBase.GetGameState
	struct ADFBaseGameMode* GetGameMode(); // Function DonkehFramework.DFGameRulesetBase.GetGameMode
}; 



// Class DonkehFramework.DFBlueprintFunctions
// Size: 0x28(Inherited: 0x28) 
struct UDFBlueprintFunctions : public UBlueprintFunctionLibrary
{

	bool WasShotFired(struct FRepShotInfo& Counter, struct FRepShotInfo& OtherCounter); // Function DonkehFramework.DFBlueprintFunctions.WasShotFired
	void TransferInventoryItems(struct UDFInventoryComponent* FromInv, struct UDFInventoryComponent* ToInv, bool bKeepLoadedAmmo); // Function DonkehFramework.DFBlueprintFunctions.TransferInventoryItems
	bool TextIsEmptyOrWhitespace(struct FText& InText); // Function DonkehFramework.DFBlueprintFunctions.TextIsEmptyOrWhitespace
	struct ADFBaseImpactEffect* SpawnImpactFXFromHitResult(struct UObject* WorldContextObject, ADFBaseImpactEffect* ImpactClass, struct FHitResult& Impact); // Function DonkehFramework.DFBlueprintFunctions.SpawnImpactFXFromHitResult
	struct ADFBaseImpactEffect* SpawnImpactFXFromDamageEvent(struct UObject* WorldContextObject, ADFBaseImpactEffect* ImpactClass, float DamageTaken, struct FDamageEvent& DamageEvent, struct AActor* HitActor, struct AActor* HitInstigator, struct AActor* DamageCauser); // Function DonkehFramework.DFBlueprintFunctions.SpawnImpactFXFromDamageEvent
	void SetTeamNum(struct AActor* Target, char NewTeamNum); // Function DonkehFramework.DFBlueprintFunctions.SetTeamNum
	void SetStartSpot(struct AController* Controller, struct AActor* NewStartSpot); // Function DonkehFramework.DFBlueprintFunctions.SetStartSpot
	void SetNetAddressable(struct UActorComponent* ActorComp); // Function DonkehFramework.DFBlueprintFunctions.SetNetAddressable
	void ResetPlayerVoiceTalker(struct APlayerState* InPlayerState); // Function DonkehFramework.DFBlueprintFunctions.ResetPlayerVoiceTalker
	void ResetAllPlayerVoiceTalkers(); // Function DonkehFramework.DFBlueprintFunctions.ResetAllPlayerVoiceTalkers
	void PrintTextToLog(struct UObject* WorldContextObject, struct FText InText, uint8_t  InLogVerbosity, bool bPrintStackTrace); // Function DonkehFramework.DFBlueprintFunctions.PrintTextToLog
	void PrintStringToLog(struct UObject* WorldContextObject, struct FString inString, uint8_t  InLogVerbosity, bool bPrintStackTrace); // Function DonkehFramework.DFBlueprintFunctions.PrintStringToLog
	bool IsVOIPTalkerStillAlive(struct UVOIPTalker* InTalker); // Function DonkehFramework.DFBlueprintFunctions.IsVOIPTalkerStillAlive
	bool IsValidActor(struct AActor* Actor); // Function DonkehFramework.DFBlueprintFunctions.IsValidActor
	bool IsPlayInEditor(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.IsPlayInEditor
	bool IsPlayerTalking(struct APlayerState* PlayerPS); // Function DonkehFramework.DFBlueprintFunctions.IsPlayerTalking
	bool IsPlayerMuted(struct APlayerController* PC, struct APlayerState* PSToCheck); // Function DonkehFramework.DFBlueprintFunctions.IsPlayerMuted
	bool IsPendingKillPending(struct AActor* Actor); // Function DonkehFramework.DFBlueprintFunctions.IsPendingKillPending
	bool IsLocallyPlayerControlled(struct APawn* Pawn); // Function DonkehFramework.DFBlueprintFunctions.IsLocallyPlayerControlled
	bool IsEmptyOrWhitespace(struct FString inString); // Function DonkehFramework.DFBlueprintFunctions.IsEmptyOrWhitespace
	bool HasOptions(struct FString Options, struct TArray<struct FString>& Keys, bool bMatchAll); // Function DonkehFramework.DFBlueprintFunctions.HasOptions
	bool HasFiringStopped(struct FRepShotInfo& Counter); // Function DonkehFramework.DFBlueprintFunctions.HasFiringStopped
	struct AWorldSettings* GetWorldSettings(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetWorldSettings
	struct UVOIPTalker* GetVOIPTalkerForPlayer(struct APlayerState* InPlayerState); // Function DonkehFramework.DFBlueprintFunctions.GetVOIPTalkerForPlayer
	uint8_t  GetVisibilityDefault(struct UWidget* Widget); // Function DonkehFramework.DFBlueprintFunctions.GetVisibilityDefault
	struct ADFTeamState* GetTeamStateFromTeamId(struct UObject* WorldContextObject, char TeamIdNum); // Function DonkehFramework.DFBlueprintFunctions.GetTeamStateFromTeamId
	char GetTeamNum(struct AActor* Target); // Function DonkehFramework.DFBlueprintFunctions.GetTeamNum
	struct FVector GetTargetLocation(struct AActor* Actor, struct AActor* RequestedBy); // Function DonkehFramework.DFBlueprintFunctions.GetTargetLocation
	struct FName GetSurfaceName(char EPhysicalSurface SurfaceType); // Function DonkehFramework.DFBlueprintFunctions.GetSurfaceName
	struct AActor* GetStartSpot(struct AController* Controller); // Function DonkehFramework.DFBlueprintFunctions.GetStartSpot
	int32_t GetShotCounterBPCompat(struct FRepShotInfo& Counter); // Function DonkehFramework.DFBlueprintFunctions.GetShotCounterBPCompat
	struct FString GetPluginFriendlyName(struct FString PluginName); // Function DonkehFramework.DFBlueprintFunctions.GetPluginFriendlyName
	int32_t GetNumShotsFiredBPCompat(struct FRepShotInfo& Counter, struct FRepShotInfo& PreviousCounter); // Function DonkehFramework.DFBlueprintFunctions.GetNumShotsFiredBPCompat
	struct FText GetMapNameForDisplay(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetMapNameForDisplay
	struct FString GetMapName(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetMapName
	bool GetMapAssetVisibleInMapSelectUI(struct FPrimaryAssetId& WorldAssetId, bool& bOutVisibleInMapSelectUI); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetVisibleInMapSelectUI
	bool GetMapAssetSupportedGameModes(struct FPrimaryAssetId& WorldAssetId, struct TSet<struct TSoftClassPtr<UObject>>& OutSupportedGameModes); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetSupportedGameModes
	bool GetMapAssetPreviewImg(struct FPrimaryAssetId& WorldAssetId, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetPreviewImg
	bool GetMapAssetPreviewBannerImg(struct FPrimaryAssetId& WorldAssetId, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewBannerImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetPreviewBannerImg
	struct FText GetMapAssetNameForDisplay(struct FPrimaryAssetId& WorldAssetId); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetNameForDisplay
	bool GetMapAssetGameRulesetClasses(struct FPrimaryAssetId& WorldAssetId, struct TSet<struct TSoftClassPtr<UObject>>& OutGameRulesetClasses); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetGameRulesetClasses
	bool GetMapAssetDescription(struct FPrimaryAssetId& WorldAssetId, struct FString& OutMapDescription); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDescription
	bool GetMapAssetDefaultGameMode(struct FPrimaryAssetId& WorldAssetId, struct TSoftClassPtr<UObject>& OutDefaultGameModeRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDefaultGameMode
	bool GetMapAssetDataSupportedGameModes(struct FAssetData& WorldAsset, struct TSet<struct TSoftClassPtr<UObject>>& OutSupportedGameModes); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataSupportedGameModes
	bool GetMapAssetDataPreviewImg(struct FAssetData& WorldAsset, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataPreviewImg
	bool GetMapAssetDataPreviewBannerImg(struct FAssetData& WorldAsset, struct TSoftObjectPtr<UTexture2D>& OutMapPreviewBannerImgRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataPreviewBannerImg
	struct FText GetMapAssetDataNameForDisplay(struct FAssetData& WorldAsset); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataNameForDisplay
	bool GetMapAssetDataGameRulesetClasses(struct FAssetData& WorldAsset, struct TSet<struct TSoftClassPtr<UObject>>& OutGameRulesetClasses); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataGameRulesetClasses
	bool GetMapAssetDataDisplayName(struct FAssetData& WorldAsset, struct FText& OutMapDisplayName); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDisplayName
	bool GetMapAssetDataDescription(struct FAssetData& WorldAsset, struct FString& OutMapDescription); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDescription
	bool GetMapAssetDataDefaultGameMode(struct FAssetData& WorldAsset, struct TSoftClassPtr<UObject>& OutDefaultGameModeRef); // Function DonkehFramework.DFBlueprintFunctions.GetMapAssetDataDefaultGameMode
	struct FString GetGlobalDefaultGameMode(); // Function DonkehFramework.DFBlueprintFunctions.GetGlobalDefaultGameMode
	struct FString GetGameVersion(); // Function DonkehFramework.DFBlueprintFunctions.GetGameVersion
	struct FText GetGameNameForDisplay(struct UObject* WorldContextObject); // Function DonkehFramework.DFBlueprintFunctions.GetGameNameForDisplay
	struct FString GetGameModeForName(struct FString GameModeName); // Function DonkehFramework.DFBlueprintFunctions.GetGameModeForName
	struct FString GetGameModeForMapName(struct FString MapName); // Function DonkehFramework.DFBlueprintFunctions.GetGameModeForMapName
	struct FString GetGameDefaultMap(); // Function DonkehFramework.DFBlueprintFunctions.GetGameDefaultMap
	struct FString GetGameBuildInfo(); // Function DonkehFramework.DFBlueprintFunctions.GetGameBuildInfo
	struct FVector GetFocalPoint(struct AActor* Actor); // Function DonkehFramework.DFBlueprintFunctions.GetFocalPoint
	void GetDefaultBoundingCylinder(struct AActor* Actor, float& CylinderRadius, float& CylinderHalfHeight); // Function DonkehFramework.DFBlueprintFunctions.GetDefaultBoundingCylinder
	struct FString GetCopyrightNotice(); // Function DonkehFramework.DFBlueprintFunctions.GetCopyrightNotice
	struct TArray<struct FString> GetAllMapNames(); // Function DonkehFramework.DFBlueprintFunctions.GetAllMapNames
	void GameHasEnded(struct AController* Controller, struct AActor* EndGameFocus, bool bIsWinner); // Function DonkehFramework.DFBlueprintFunctions.GameHasEnded
	void FlushPressedKeys(struct APlayerController* PC); // Function DonkehFramework.DFBlueprintFunctions.FlushPressedKeys
	struct FPrimaryAssetId FindMapIdByDisplayName(struct FText& MapDisplayName, struct TArray<struct FPrimaryAssetId>& MapIds); // Function DonkehFramework.DFBlueprintFunctions.FindMapIdByDisplayName
	bool EqualEqual_WeaponSoundCollection(struct FWeaponSoundCollection& A, struct FWeaponSoundCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponSoundCollection
	bool EqualEqual_WeaponAnimSequence(struct FWeaponAnimSequence& A, struct FWeaponAnimSequence& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimSequence
	bool EqualEqual_WeaponAnimMontage(struct FWeaponAnimMontage& A, struct FWeaponAnimMontage& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimMontage
	bool EqualEqual_WeaponAnimCollection(struct FWeaponAnimCollection& A, struct FWeaponAnimCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnimCollection
	bool EqualEqual_WeaponAnim(struct FWeaponAnim& A, struct FWeaponAnim& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_WeaponAnim
	bool EqualEqual_PerspectiveSound(struct FPerspectiveSound& A, struct FPerspectiveSound& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveSound
	bool EqualEqual_PerspectiveAnimSequence(struct FPerspectiveAnimSequence& A, struct FPerspectiveAnimSequence& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveAnimSequence
	bool EqualEqual_PerspectiveAnim(struct FPerspectiveAnim& A, struct FPerspectiveAnim& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_PerspectiveAnim
	bool EqualEqual_CharacterSoundCollection(struct FCharacterSoundCollection& A, struct FCharacterSoundCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_CharacterSoundCollection
	bool EqualEqual_CharacterAnimCollection(struct FCharacterAnimCollection& A, struct FCharacterAnimCollection& B); // Function DonkehFramework.DFBlueprintFunctions.EqualEqual_CharacterAnimCollection
	bool DoesMapIDSupportGMDefinition(struct FPrimaryAssetId& MapId, struct UDFGameModeDefinition* GMDef); // Function DonkehFramework.DFBlueprintFunctions.DoesMapIDSupportGMDefinition
	bool CharacterVariationIsValid(struct FDFCharacterVariationDataHandle VariationData); // Function DonkehFramework.DFBlueprintFunctions.CharacterVariationIsValid
	struct FDFCharacterVariationData CharacterVariationGetData(struct FDFCharacterVariationDataHandle VariationData); // Function DonkehFramework.DFBlueprintFunctions.CharacterVariationGetData
	struct FDFCharacterVariationDataHandle CharacterVariationDataFromTableRow(struct UObject* WorldContextObject, struct FDataTableRowHandle RowHandle); // Function DonkehFramework.DFBlueprintFunctions.CharacterVariationDataFromTableRow
	void Array_UInt8Sort(struct TArray<char>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_UInt8Sort
	void Array_TextSort(struct TArray<struct FText>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_TextSort
	void Array_StringSort(struct TArray<struct FString>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_StringSort
	void Array_Reverse(struct TArray<int32_t>& TargetArray); // Function DonkehFramework.DFBlueprintFunctions.Array_Reverse
	void Array_NameSort(struct TArray<struct FName>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_NameSort
	void Array_Int64Sort(struct TArray<int64_t>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_Int64Sort
	void Array_Int32Sort(struct TArray<int32_t>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_Int32Sort
	void Array_FloatSort(struct TArray<float>& ArrayToSort, bool bDescending); // Function DonkehFramework.DFBlueprintFunctions.Array_FloatSort
	void Array_AssetDescriptorSort(struct TArray<struct FAssetDescriptor>& ArrayToSort, bool bDescending, bool bCompareDisplayText); // Function DonkehFramework.DFBlueprintFunctions.Array_AssetDescriptorSort
}; 



// Class DonkehFramework.DFCharacterLeanHandler
// Size: 0x280(Inherited: 0x28) 
struct UDFCharacterLeanHandler : public UObject
{
	struct FRuntimeFloatCurve StationaryStandLeanCurve;  // 0x28(0x88)
	struct FRuntimeFloatCurve MobileStandLeanCurve;  // 0xB0(0x88)
	struct FRuntimeFloatCurve StationaryCrouchLeanCurve;  // 0x138(0x88)
	struct FRuntimeFloatCurve MobileCrouchLeanCurve;  // 0x1C0(0x88)
	float LeanTransitionSpeed;  // 0x248(0x4)
	float StandLeanInYOffset;  // 0x24C(0x4)
	float CrouchLeanInYOffset;  // 0x250(0x4)
	float LeanRollAmount;  // 0x254(0x4)
	uint8_t  LeanDirection;  // 0x258(0x1)
	char pad_601[3];  // 0x259(0x3)
	float LeanTarget;  // 0x25C(0x4)
	char bAtFullLeanTarget : 1;  // 0x260(0x1)
	char pad_608_1 : 7;  // 0x260(0x1)
	char pad_609[4];  // 0x261(0x4)
	float LeanAmount;  // 0x264(0x4)
	char pad_616[24];  // 0x268(0x18)

	void UpdateLeanDirection(uint8_t  NewLeanDir); // Function DonkehFramework.DFCharacterLeanHandler.UpdateLeanDirection
	void ReceiveTick(float DeltaTime); // Function DonkehFramework.DFCharacterLeanHandler.ReceiveTick
	void ReceiveReset(); // Function DonkehFramework.DFCharacterLeanHandler.ReceiveReset
	bool IsMoving(); // Function DonkehFramework.DFCharacterLeanHandler.IsMoving
	bool IsLeaning(); // Function DonkehFramework.DFCharacterLeanHandler.IsLeaning
	uint8_t  GetStance(); // Function DonkehFramework.DFCharacterLeanHandler.GetStance
	uint8_t  GetPreviousStance(); // Function DonkehFramework.DFCharacterLeanHandler.GetPreviousStance
	struct UDFCharacterMovementComponent* GetOwningCharacterMovement(); // Function DonkehFramework.DFCharacterLeanHandler.GetOwningCharacterMovement
	struct ADFBaseCharacter* GetOwningCharacter(); // Function DonkehFramework.DFCharacterLeanHandler.GetOwningCharacter
	float GetMaxLeanXOffset(uint8_t  NewLeanDir, uint8_t  LeanStance, bool bMoving); // Function DonkehFramework.DFCharacterLeanHandler.GetMaxLeanXOffset
	float GetLeanYOffset(float DesiredLeanAmt); // Function DonkehFramework.DFCharacterLeanHandler.GetLeanYOffset
	float GetLeanXOffset(float DesiredLeanAmt); // Function DonkehFramework.DFCharacterLeanHandler.GetLeanXOffset
	float GetLeanRollRot(float DesiredLeanAmt); // Function DonkehFramework.DFCharacterLeanHandler.GetLeanRollRot
	float DetermineLeanTargetAmount(uint8_t  DesiredLeanDir, bool bMoving); // Function DonkehFramework.DFCharacterLeanHandler.DetermineLeanTargetAmount
}; 



// Class DonkehFramework.DFDamageType
// Size: 0x48(Inherited: 0x40) 
struct UDFDamageType : public UDamageType
{
	ADFBaseImpactEffect* ImpactFXClass;  // 0x40(0x8)

}; 



// Class DonkehFramework.DFCharacterMovementComponent
// Size: 0x750(Inherited: 0x610) 
struct UDFCharacterMovementComponent : public UCharacterMovementComponent
{
	struct ADFBaseCharacter* DFCharacterOwner;  // 0x610(0x8)
	char EMovementMode LastMovementMode;  // 0x618(0x1)
	char LastCustomMovementMode;  // 0x619(0x1)
	char pad_1562[2];  // 0x61A(0x2)
	struct FFloatRange StandWalkSpeedMultiplierRange;  // 0x61C(0x10)
	struct FFloatRange CrouchedWalkSpeedMultiplierRange;  // 0x62C(0x10)
	struct FFloatRange ProneWalkSpeedMultiplierRange;  // 0x63C(0x10)
	float LeanSpeedMultiplier;  // 0x64C(0x4)
	char bUseLeanSpeedMultiplierWhileAiming : 1;  // 0x650(0x1)
	char bCanCrouchWhileFalling : 1;  // 0x650(0x1)
	char pad_1616_1 : 6;  // 0x650(0x1)
	char pad_1617[4];  // 0x651(0x4)
	char bUseJumpStamina : 1;  // 0x654(0x1)
	char pad_1620_1 : 7;  // 0x654(0x1)
	char pad_1621[4];  // 0x655(0x4)
	float JumpMaxStamina;  // 0x658(0x4)
	float JumpStaminaCost;  // 0x65C(0x4)
	float JumpStaminaRecoveryRate;  // 0x660(0x4)
	float JumpStaminaThreshold;  // 0x664(0x4)
	struct UCurveVector* VaultOverVelocityCurve;  // 0x668(0x8)
	struct UCurveVector* SprintVaultOverVelocityCurve;  // 0x670(0x8)
	struct UCurveVector* ClimbOntoVelocityCurve;  // 0x678(0x8)
	struct UCurveVector* SprintClimbOntoVelocityCurve;  // 0x680(0x8)
	float VaultViewPitch;  // 0x688(0x4)
	float VaultReachDistance;  // 0x68C(0x4)
	float SprintVaultReachDistance;  // 0x690(0x4)
	float VaultReachRadius;  // 0x694(0x4)
	float VaultCapsuleLOSRadius;  // 0x698(0x4)
	float MaxVaultObstacleVelocitySquared;  // 0x69C(0x4)
	float VaultOverDisplacementXOffset;  // 0x6A0(0x4)
	float ClimbOntoDisplacementXOffset;  // 0x6A4(0x4)
	float VaultOverDisplacementZOffset;  // 0x6A8(0x4)
	float ClimbOntoDisplacementZOffset;  // 0x6AC(0x4)
	float VaultOverLedgeSurfaceThreshold;  // 0x6B0(0x4)
	float ClimbOntoLedgeSurfaceThreshold;  // 0x6B4(0x4)
	float MinVaultOverLedgeHeight;  // 0x6B8(0x4)
	float MaxVaultOverLedgeHeight;  // 0x6BC(0x4)
	float MinClimbOntoLedgeHeight;  // 0x6C0(0x4)
	float MaxClimbOntoLedgeHeight;  // 0x6C4(0x4)
	char bWantsToSprint : 1;  // 0x6C8(0x1)
	char pad_1736_1 : 7;  // 0x6C8(0x1)
	char pad_1737[4];  // 0x6C9(0x4)
	float SprintSpeedMultiplier;  // 0x6CC(0x4)
	float SprintAccelerationMultiplier;  // 0x6D0(0x4)
	float SprintStrafingThreshold;  // 0x6D4(0x4)
	char bUseSprintStamina : 1;  // 0x6D8(0x1)
	char pad_1752_1 : 7;  // 0x6D8(0x1)
	char pad_1753[4];  // 0x6D9(0x4)
	float SprintMaxStamina;  // 0x6DC(0x4)
	float SprintStaminaDelta;  // 0x6E0(0x4)
	float SprintStaminaThreshold;  // 0x6E4(0x4)
	char bWantsToAim : 1;  // 0x6E8(0x1)
	char pad_1768_1 : 7;  // 0x6E8(0x1)
	char pad_1769[4];  // 0x6E9(0x4)
	float AimSpeedMultiplier;  // 0x6EC(0x4)
	char bWantsToLeanLeft : 1;  // 0x6F0(0x1)
	char bWantsToLeanRight : 1;  // 0x6F0(0x1)
	char pad_1776_1 : 6;  // 0x6F0(0x1)
	char pad_1777[4];  // 0x6F1(0x4)
	float ProneHalfHeight;  // 0x6F4(0x4)
	char bCanWalkOffLedgesWhenProne : 1;  // 0x6F8(0x1)
	char bProneMaintainsBaseLocation : 1;  // 0x6F8(0x1)
	char pad_1784_1 : 6;  // 0x6F8(0x1)
	char pad_1785[4];  // 0x6F9(0x4)
	float MaxWalkSpeedProne;  // 0x6FC(0x4)
	char bWantsToBeProne : 1;  // 0x700(0x1)
	char bCanSwimUnderwater : 1;  // 0x700(0x1)
	char pad_1792_1 : 6;  // 0x700(0x1)
	char pad_1793[4];  // 0x701(0x4)
	float JumpStamina;  // 0x704(0x4)
	char bCanSprint : 1;  // 0x708(0x1)
	char pad_1800_1 : 7;  // 0x708(0x1)
	char pad_1801[4];  // 0x709(0x4)
	float SprintStamina;  // 0x70C(0x4)
	char bCanAim : 1;  // 0x710(0x1)
	char bCanLean : 1;  // 0x710(0x1)
	char bCanBeProne : 1;  // 0x710(0x1)
	char bCanVault : 1;  // 0x710(0x1)
	char pad_1808_1 : 4;  // 0x710(0x1)
	char pad_1809[48];  // 0x711(0x30)
	char bJustLeftWater : 1;  // 0x740(0x1)
	char pad_1856_1 : 7;  // 0x740(0x1)
	char pad_1857[16];  // 0x741(0x10)

	struct FDFVaultTraceResult VaultTrace(); // Function DonkehFramework.DFCharacterMovementComponent.VaultTrace
	bool IsVaulting(); // Function DonkehFramework.DFCharacterMovementComponent.IsVaulting
	bool IsStrafing(float Threshold); // Function DonkehFramework.DFCharacterMovementComponent.IsStrafing
	bool IsStanding(); // Function DonkehFramework.DFCharacterMovementComponent.IsStanding
	bool IsSprinting(); // Function DonkehFramework.DFCharacterMovementComponent.IsSprinting
	bool IsReloading(); // Function DonkehFramework.DFCharacterMovementComponent.IsReloading
	bool IsProne(); // Function DonkehFramework.DFCharacterMovementComponent.IsProne
	bool IsMovingForward(); // Function DonkehFramework.DFCharacterMovementComponent.IsMovingForward
	bool IsMoving(bool bIgnoreZVel); // Function DonkehFramework.DFCharacterMovementComponent.IsMoving
	bool IsLeaning(); // Function DonkehFramework.DFCharacterMovementComponent.IsLeaning
	bool IsCrawling(); // Function DonkehFramework.DFCharacterMovementComponent.IsCrawling
	bool IsAlive(); // Function DonkehFramework.DFCharacterMovementComponent.IsAlive
	bool IsAiming(); // Function DonkehFramework.DFCharacterMovementComponent.IsAiming
	uint8_t  GetStance(); // Function DonkehFramework.DFCharacterMovementComponent.GetStance
	uint8_t  GetPreviousStance(); // Function DonkehFramework.DFCharacterMovementComponent.GetPreviousStance
	uint8_t  GetLeanDirection(); // Function DonkehFramework.DFCharacterMovementComponent.GetLeanDirection
	float GetLeanAmount(); // Function DonkehFramework.DFCharacterMovementComponent.GetLeanAmount
	struct ADFBaseCharacter* GetDFCharacterOwner(); // Function DonkehFramework.DFCharacterMovementComponent.GetDFCharacterOwner
	float ClampSpeedMultiplier(float MultValue); // Function DonkehFramework.DFCharacterMovementComponent.ClampSpeedMultiplier
}; 



// Class DonkehFramework.DFServerAdminSubsystem
// Size: 0x40(Inherited: 0x30) 
struct UDFServerAdminSubsystem : public UEngineSubsystem
{
	struct TArray<struct UDFCfgDataManager*> DataMgrs;  // 0x30(0x10)

}; 



// Class DonkehFramework.DFPrimaryDataAsset
// Size: 0x30(Inherited: 0x30) 
struct UDFPrimaryDataAsset : public UPrimaryDataAsset
{

}; 



// Class DonkehFramework.DFNavigationSystemConfig
// Size: 0x60(Inherited: 0x58) 
struct UDFNavigationSystemConfig : public UNavigationSystemModuleConfig
{
	char bGenerateNavigationOnlyAroundNavigationInvokers : 1;  // 0x58(0x1)
	char pad_88_1 : 7;  // 0x58(0x1)
	char pad_89[8];  // 0x59(0x8)

}; 



// Class DonkehFramework.DFFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UDFFunctionLibrary : public UObject
{

	void SetEnableAutoBlendOutForActiveMontage(struct UAnimMontage* AnimMontage, struct USkeletalMeshComponent* AnimSourceMesh, bool bNewEnableAutoBlendOut); // Function DonkehFramework.DFFunctionLibrary.SetEnableAutoBlendOutForActiveMontage
	void ClearMeshAnimInstance(struct USkeletalMeshComponent* MeshToClear); // Function DonkehFramework.DFFunctionLibrary.ClearMeshAnimInstance
}; 



// Class DonkehFramework.DFLoadout
// Size: 0x40(Inherited: 0x30) 
struct UDFLoadout : public UDataAsset
{
	struct TArray<ADFBaseItem*> ItemClasses;  // 0x30(0x10)

}; 



// Class DonkehFramework.DFGameEngine
// Size: 0xE30(Inherited: 0xE30) 
struct UDFGameEngine : public UGameEngine
{

}; 



// Class DonkehFramework.DFGameModeDefinition
// Size: 0xE8(Inherited: 0x30) 
struct UDFGameModeDefinition : public UPrimaryDataAsset
{
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bSupportsAllMaps : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct TSet<struct FPrimaryAssetId> SpecificMapsToSupport;  // 0x38(0x50)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bShowInFrontEnd : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FText Title;  // 0x90(0x18)
	struct FText Description;  // 0xA8(0x18)
	struct TSoftObjectPtr<UTexture2D> PreviewBannerImg;  // 0xC0(0x28)

}; 



// Class DonkehFramework.DFSingleLoadWeapAnimInstInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFSingleLoadWeapAnimInstInterface : public UInterface
{

	float PlayStartReloadMontage(struct UAnimMontage* MontageToPlay, bool bFullReload); // Function DonkehFramework.DFSingleLoadWeapAnimInstInterface.PlayStartReloadMontage
	float PlayEndReloadMontage(struct UAnimMontage* MontageToPlay, bool bFullReload); // Function DonkehFramework.DFSingleLoadWeapAnimInstInterface.PlayEndReloadMontage
}; 



// Class DonkehFramework.DFGameSession
// Size: 0x270(Inherited: 0x238) 
struct ADFGameSession : public AGameSession
{
	struct FString ServerName;  // 0x238(0x10)
	char pad_584[16];  // 0x248(0x10)
	int32_t MinPlayers;  // 0x258(0x4)
	char pad_604[4];  // 0x25C(0x4)
	struct FString Password;  // 0x260(0x10)

}; 



// Class DonkehFramework.DFIntrinsicCharAnimInstInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFIntrinsicCharAnimInstInterface : public UInterface
{

	float PlayDeathMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFIntrinsicCharAnimInstInterface.PlayDeathMontage
}; 



// Class DonkehFramework.DFIntrinsicWeapAnimInstInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFIntrinsicWeapAnimInstInterface : public UInterface
{

	float PlayUnEquipMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayUnEquipMontage
	float PlayReloadMontage(struct UAnimMontage* MontageToPlay, bool bFullReload); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayReloadMontage
	float PlayFireMontage(struct UAnimMontage* MontageToPlay, bool bFireLast, bool bAiming); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayFireMontage
	float PlayEquipMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFIntrinsicWeapAnimInstInterface.PlayEquipMontage
}; 



// Class DonkehFramework.DFInventoryComponent
// Size: 0xF0(Inherited: 0xB0) 
struct UDFInventoryComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnItemAdded;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnItemRemoved;  // 0xC0(0x10)
	struct TArray<struct ADFBaseItem*> Items;  // 0xD0(0x10)
	struct TArray<ADFBaseItem*> DefaultItemClasses;  // 0xE0(0x10)

	int32_t Size(); // Function DonkehFramework.DFInventoryComponent.Size
	bool RemoveItemAt(int32_t Index, struct ADFBaseItem*& OutRemovedItem, bool bDestroyItem); // Function DonkehFramework.DFInventoryComponent.RemoveItemAt
	bool Remove(struct ADFBaseItem* Item, bool bDestroyItem); // Function DonkehFramework.DFInventoryComponent.Remove
	bool IsValidIndex(int32_t Index); // Function DonkehFramework.DFInventoryComponent.IsValidIndex
	bool GetItem(int32_t Index, struct ADFBaseItem*& OutItem); // Function DonkehFramework.DFInventoryComponent.GetItem
	bool FindItemByClass(ADFBaseItem*& ItemClass, struct ADFBaseItem*& OutItem); // Function DonkehFramework.DFInventoryComponent.FindItemByClass
	bool Find(struct ADFBaseItem* ItemToCompare, int32_t& OutIndex); // Function DonkehFramework.DFInventoryComponent.Find
	void Clear(bool bDestroyItems); // Function DonkehFramework.DFInventoryComponent.Clear
	void AddDefaultInventoryItems(); // Function DonkehFramework.DFInventoryComponent.AddDefaultInventoryItems
	bool Add(struct ADFBaseItem* Item); // Function DonkehFramework.DFInventoryComponent.Add
}; 



// Class DonkehFramework.DFNavigationSystem
// Size: 0x538(Inherited: 0x538) 
struct UDFNavigationSystem : public UNavigationSystemV1
{

}; 



// Class DonkehFramework.DFNetworkEventSubsystem
// Size: 0xA0(Inherited: 0x30) 
struct UDFNetworkEventSubsystem : public UWorldSubsystem
{
	struct FMulticastInlineDelegate OnPlayersUpdatedDynamic;  // 0x30(0x10)
	struct FMulticastInlineDelegate OnTeamsUpdatedDynamic;  // 0x40(0x10)
	char pad_80[80];  // 0x50(0x50)

	void OnGameStateEventDynamic__DelegateSignature(struct AGameStateBase* GameState); // DelegateFunction DonkehFramework.DFNetworkEventSubsystem.OnGameStateEventDynamic__DelegateSignature
	struct UDFNetworkEventSubsystem* Get(struct UObject* WorldContextObject); // Function DonkehFramework.DFNetworkEventSubsystem.Get
}; 



// Class DonkehFramework.DFPhysicalMaterial
// Size: 0x90(Inherited: 0x80) 
struct UDFPhysicalMaterial : public UPhysicalMaterial
{
	struct UParticleSystem* CollisionFX;  // 0x80(0x8)
	struct USoundCue* CollisionSound;  // 0x88(0x8)

}; 



// Class DonkehFramework.DFPlayerCameraManager
// Size: 0x2740(Inherited: 0x2740) 
struct ADFPlayerCameraManager : public APlayerCameraManager
{
	float AimingFOV;  // 0x2738(0x4)
	float AimInterpSpeed;  // 0x273C(0x4)

}; 



// Class DonkehFramework.DFPlayerComponent
// Size: 0xC8(Inherited: 0xB0) 
struct UDFPlayerComponent : public UActorComponent
{
	struct AController* ControllerOwner;  // 0xB0(0x8)
	char bWantsToRestart : 1;  // 0xB8(0x1)
	char pad_184_1 : 7;  // 0xB8(0x1)
	char pad_185[16];  // 0xB9(0x10)

	void RestartPlayer(); // Function DonkehFramework.DFPlayerComponent.RestartPlayer
	void ReceiveSeamlessTravelToCommon(struct AController* NewC, struct UDFPlayerComponent* NewCPlayerComp); // Function DonkehFramework.DFPlayerComponent.ReceiveSeamlessTravelToCommon
	void ReceiveSeamlessTravelFromCommon(struct AController* OldC, struct UDFPlayerComponent* OldCPlayerComp); // Function DonkehFramework.DFPlayerComponent.ReceiveSeamlessTravelFromCommon
	void ReceivePawnLeavingGame(); // Function DonkehFramework.DFPlayerComponent.ReceivePawnLeavingGame
	void ReceiveGameHasEnded(struct AActor* EndGameFocus, bool bIsWinner); // Function DonkehFramework.DFPlayerComponent.ReceiveGameHasEnded
	bool IsPendingRestart(); // Function DonkehFramework.DFPlayerComponent.IsPendingRestart
	struct ADFTeamState* GetTeamState(); // Function DonkehFramework.DFPlayerComponent.GetTeamState
	struct APlayerState* GetPlayerState(); // Function DonkehFramework.DFPlayerComponent.GetPlayerState
	struct APawn* GetPawnOwner(); // Function DonkehFramework.DFPlayerComponent.GetPawnOwner
	float GetMinRestartDelay(); // Function DonkehFramework.DFPlayerComponent.GetMinRestartDelay
	bool CanRestartPlayer(); // Function DonkehFramework.DFPlayerComponent.CanRestartPlayer
}; 



// Class DonkehFramework.DFOnlineSessionClient
// Size: 0x1A8(Inherited: 0x190) 
struct UDFOnlineSessionClient : public UOnlineSessionClient
{
	char pad_400[24];  // 0x190(0x18)

}; 



// Class DonkehFramework.DFTeamAgentInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFTeamAgentInterface : public UGenericTeamAgentInterface
{

	void EventSetTeamNum(char NewTeamNum); // Function DonkehFramework.DFTeamAgentInterface.EventSetTeamNum
	char EventGetTeamNum(); // Function DonkehFramework.DFTeamAgentInterface.EventGetTeamNum
}; 



// Class DonkehFramework.DFProjectileSubsystem
// Size: 0x58(Inherited: 0x30) 
struct UDFProjectileSubsystem : public UWorldSubsystem
{
	struct TArray<struct ADFBaseProjectile*> PredictedProjectiles;  // 0x30(0x10)
	int32_t MaxFiredShots;  // 0x40(0x4)
	char pad_68[20];  // 0x44(0x14)

}; 



// Class DonkehFramework.DFReplInfo
// Size: 0x220(Inherited: 0x220) 
struct ADFReplInfo : public ADFInfo
{

}; 



// Class DonkehFramework.DFTableLibrary
// Size: 0x28(Inherited: 0x28) 
struct UDFTableLibrary : public UBlueprintFunctionLibrary
{

	int32_t GetRowInvFromIndex(int32_t Index, int32_t TableHeight); // Function DonkehFramework.DFTableLibrary.GetRowInvFromIndex
	int32_t GetRowFromIndex(int32_t Index, int32_t TableWidth); // Function DonkehFramework.DFTableLibrary.GetRowFromIndex
	int32_t GetIndexFromRowColumnPair(int32_t Row, int32_t Column, int32_t TableWidth); // Function DonkehFramework.DFTableLibrary.GetIndexFromRowColumnPair
	int32_t GetIndexFromColumnRowPair(int32_t Column, int32_t Row, int32_t TableHeight); // Function DonkehFramework.DFTableLibrary.GetIndexFromColumnRowPair
	int32_t GetColumnInvFromIndex(int32_t Index, int32_t TableHeight); // Function DonkehFramework.DFTableLibrary.GetColumnInvFromIndex
	int32_t GetColumnFromIndex(int32_t Index, int32_t TableWidth); // Function DonkehFramework.DFTableLibrary.GetColumnFromIndex
}; 



// Class DonkehFramework.SpawnPointStatics
// Size: 0x28(Inherited: 0x28) 
struct USpawnPointStatics : public UBlueprintFunctionLibrary
{

	bool SpawnPointExists(struct UObject* Target, int32_t SpawnPointID); // Function DonkehFramework.SpawnPointStatics.SpawnPointExists
	bool GetSpawnPointCollisionHandlingOverride(struct UObject* Target, struct FSpawnPointDef& SpawnPoint, uint8_t & OutSpawnCollisionMethod); // Function DonkehFramework.SpawnPointStatics.GetSpawnPointCollisionHandlingOverride
	int32_t GetAllSpawnPointTransforms(struct UObject* Target, struct TArray<struct FTransform>& SpawnPointTransforms); // Function DonkehFramework.SpawnPointStatics.GetAllSpawnPointTransforms
	int32_t GetAllSpawnPoints(struct UObject* Target, struct TArray<struct FSpawnPointDef>& SpawnPoints); // Function DonkehFramework.SpawnPointStatics.GetAllSpawnPoints
	bool FindSpawnPoint(struct UObject* Target, int32_t SpawnPointID, struct FSpawnPointDef& FoundSpawnPoint); // Function DonkehFramework.SpawnPointStatics.FindSpawnPoint
	bool CanSpawnActorFromSpawnPoint(struct UObject* Target, struct FSpawnPointDef& SpawnPoint, AActor*& SpawnActorClass); // Function DonkehFramework.SpawnPointStatics.CanSpawnActorFromSpawnPoint
	bool CanSpawnActorFromAnySpawnPoint(struct UObject* Target, AActor*& SpawnActorClass); // Function DonkehFramework.SpawnPointStatics.CanSpawnActorFromAnySpawnPoint
	bool CanRestartPlayerFromSpawnPoint(struct UObject* Target, struct FSpawnPointDef& SpawnPoint, struct AController* Player, APawn*& PlayerPawnClass); // Function DonkehFramework.SpawnPointStatics.CanRestartPlayerFromSpawnPoint
	bool CanRestartPlayerFromAnySpawnPoint(struct UObject* Target, struct AController* Player, APawn*& PlayerPawnClass); // Function DonkehFramework.SpawnPointStatics.CanRestartPlayerFromAnySpawnPoint
}; 



// Class DonkehFramework.DFTeamState
// Size: 0x250(Inherited: 0x220) 
struct ADFTeamState : public AInfo
{
	char pad_544[8];  // 0x220(0x8)
	char bInitialized : 1;  // 0x228(0x1)
	char pad_552_1 : 7;  // 0x228(0x1)
	char pad_553[8];  // 0x229(0x8)
	UDFFactionInfo* FactionInfoClass;  // 0x230(0x8)
	char TeamNum;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct FMulticastInlineDelegate OnPostInitTeam;  // 0x240(0x10)

	void ReceivePostInitTeam(); // Function DonkehFramework.DFTeamState.ReceivePostInitTeam
	void ReceiveInitTeam(struct UDFTeamDefinition* InTeamDef); // Function DonkehFramework.DFTeamState.ReceiveInitTeam
	bool IsReadyToInitialize(); // Function DonkehFramework.DFTeamState.IsReadyToInitialize
	bool IsPendingSetupBP(); // Function DonkehFramework.DFTeamState.IsPendingSetupBP
	struct UDFFactionInfo* GetFactionInfo(); // Function DonkehFramework.DFTeamState.GetFactionInfo
}; 



// Class DonkehFramework.DFThrowableWeapAnimInstInterface
// Size: 0x28(Inherited: 0x28) 
struct UDFThrowableWeapAnimInstInterface : public UInterface
{

	float PlayThrowUnderhandMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayThrowUnderhandMontage
	float PlayThrowOverhandMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayThrowOverhandMontage
	float PlayCockMontage(struct UAnimMontage* MontageToPlay); // Function DonkehFramework.DFThrowableWeapAnimInstInterface.PlayCockMontage
}; 



// Class DonkehFramework.DFTokenStore
// Size: 0xC8(Inherited: 0x78) 
struct UDFTokenStore : public UDFCfgDataManager
{
	char pad_120[80];  // 0x78(0x50)

}; 



// Class DonkehFramework.DFWorldSettings
// Size: 0x4C8(Inherited: 0x3A0) 
struct ADFWorldSettings : public AWorldSettings
{
	char bVisibleInMapSelectUI : 1;  // 0x3A0(0x1)
	char pad_928_1 : 7;  // 0x3A0(0x1)
	char pad_929[8];  // 0x3A1(0x8)
	struct FText MapDisplayName;  // 0x3A8(0x18)
	struct FText MapDescription;  // 0x3C0(0x18)
	struct TSoftObjectPtr<UTexture2D> MapPreviewImg;  // 0x3D8(0x28)
	struct TSoftObjectPtr<UTexture2D> MapPreviewBannerImg;  // 0x400(0x28)
	struct TSet<struct TSoftClassPtr<UObject>> SupportedGameModes;  // 0x428(0x50)
	struct TSet<struct TSoftClassPtr<UObject>> GameRulesetClasses;  // 0x478(0x50)

}; 



// Class DonkehFramework.GameSessionBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UGameSessionBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void RemoveAdmin(struct UObject* WorldContextObj, struct APlayerController* AdminPlayer); // Function DonkehFramework.GameSessionBlueprintLibrary.RemoveAdmin
	int32_t GetMinPlayers(struct UObject* WorldContextObj); // Function DonkehFramework.GameSessionBlueprintLibrary.GetMinPlayers
	int32_t GetMaxSpectators(struct UObject* WorldContextObj); // Function DonkehFramework.GameSessionBlueprintLibrary.GetMaxSpectators
	int32_t GetMaxPlayers(struct UObject* WorldContextObj); // Function DonkehFramework.GameSessionBlueprintLibrary.GetMaxPlayers
	void AddAdmin(struct UObject* WorldContextObj, struct APlayerController* AdminPlayer); // Function DonkehFramework.GameSessionBlueprintLibrary.AddAdmin
}; 



// Class DonkehFramework.SpawnPointProviderInterface
// Size: 0x28(Inherited: 0x28) 
struct USpawnPointProviderInterface : public UInterface
{

	bool GetSpawnPointCollisionHandlingOverrideBP(struct FSpawnPointDef& SpawnPoint, uint8_t & OutSpawnCollisionMethod); // Function DonkehFramework.SpawnPointProviderInterface.GetSpawnPointCollisionHandlingOverrideBP
	int32_t GetAllSpawnPointsBP(struct TArray<struct FSpawnPointDef>& SpawnPoints); // Function DonkehFramework.SpawnPointProviderInterface.GetAllSpawnPointsBP
	bool FindSpawnPointBP(int32_t SpawnPointID, struct FSpawnPointDef& FoundSpawnPoint); // Function DonkehFramework.SpawnPointProviderInterface.FindSpawnPointBP
	bool CanSpawnActorFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, AActor* SpawnActorClass); // Function DonkehFramework.SpawnPointProviderInterface.CanSpawnActorFromSpawnPointBP
	bool CanRestartPlayerFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, struct AController* Player, APawn* PlayerPawnClass); // Function DonkehFramework.SpawnPointProviderInterface.CanRestartPlayerFromSpawnPointBP
}; 



// Class DonkehFramework.UseableInterface
// Size: 0x28(Inherited: 0x28) 
struct UUseableInterface : public UInterface
{

	void Used(struct AActor* Invoker); // Function DonkehFramework.UseableInterface.Used
}; 



