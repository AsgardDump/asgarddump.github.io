#pragma once 
#include <BP_HDScopeWeaponBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C
// Size: 0x1070(Inherited: 0xA54) 
struct ABP_HDScopeWeaponBase_C : public ABP_HDWeaponBase_C
{
	char pad_2644[4];  // 0xA54(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA58(0x8)
	struct USphereComponent* RadiusDebugSphere;  // 0xA60(0x8)
	struct USceneComponent* RadiusDebugTopPoint;  // 0xA68(0x8)
	struct ABP_HDPlayerCharacterBase_C* PlayerCharOwner;  // 0xA70(0x8)
	struct UDFCharacterMovementComponent* PlayerCharOwnerMoveComp;  // 0xA78(0x8)
	struct AHDPlayerController* PCOwner;  // 0xA80(0x8)
	struct ADFPlayerCameraManager* PlayerOwnerCamMgr;  // 0xA88(0x8)
	float DefaultAimingFOV;  // 0xA90(0x4)
	float DefaultAimingDistance;  // 0xA94(0x4)
	float DefaultAimInterpSpeed;  // 0xA98(0x4)
	float DefaultFreeAimPitch;  // 0xA9C(0x4)
	float DefaultFreeAimYaw;  // 0xAA0(0x4)
	char pad_2724[12];  // 0xAA4(0xC)
	struct FPostProcessSettings DefaultCameraPostProcess;  // 0xAB0(0x540)
	struct UMaterialInstanceDynamic* ScopeMID;  // 0xFF0(0x8)
	struct UMaterialInstanceDynamic* ScopeMIDGlass;  // 0xFF8(0x8)
	char pad_4096_1 : 7;  // 0x1000(0x1)
	bool bUseOverlay : 1;  // 0x1000(0x1)
	char pad_4097[3];  // 0x1001(0x3)
	float AimingFOV;  // 0x1004(0x4)
	float AimInterpSpeed;  // 0x1008(0x4)
	float AimInDelay;  // 0x100C(0x4)
	float BlurEffectDelay;  // 0x1010(0x4)
	float ScopeRadius;  // 0x1014(0x4)
	float FreeAimMaxPitch;  // 0x1018(0x4)
	float FreeAimMaxYaw;  // 0x101C(0x4)
	int32_t ScopeMaterialIndex;  // 0x1020(0x4)
	char pad_4132[4];  // 0x1024(0x4)
	struct TArray<struct FWeightedBlendable> PostProcessMaterial;  // 0x1028(0x10)
	struct UMaterialInterface* ScopeGlassMaterial;  // 0x1038(0x8)
	struct UMaterialInterface* ScopeOpticMaterial;  // 0x1040(0x8)
	struct UUserWidget* ScopeOverlay;  // 0x1048(0x8)
	UUserWidget* ScopeOverlayClass;  // 0x1050(0x8)
	float ReticleOffsetY;  // 0x1058(0x4)
	float ReticleOffsetX;  // 0x105C(0x4)
	struct TArray<struct FWeightedBlendable> PostProcessRef;  // 0x1060(0x10)

	void ShouldUseScope(bool& bUseScope); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ShouldUseScope
	void SaveOwnerDefaultValues(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SaveOwnerDefaultValues
	void RestoreOwnerDefaultValues(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.RestoreOwnerDefaultValues
	void ScopeEffects(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ScopeEffects
	void AimOut(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.AimOut
	void AimIn(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.AimIn
	void HasLocallyPlayerControlledOwner(bool& bLocalPlayerOwner); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.HasLocallyPlayerControlledOwner
	void HasValidOwnerData(bool bCharAliveCheck, bool& bValidOwnerData); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.HasValidOwnerData
	void ResetDefaultValues(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ResetDefaultValues
	void CleanupOwnerData(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.CleanupOwnerData
	void SetupOwnerData(bool& bValidOwnerData); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SetupOwnerData
	void UserConstructionScript(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.UserConstructionScript
	void StartAimInScope(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.StartAimInScope
	void StartAimOutScope(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.StartAimOutScope
	void ReceiveTick(float DeltaSeconds); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveTick
	void ReceiveOnEquipFinished(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnEquipFinished
	void ReceiveOnUnEquip(bool bPlayAnimAndWait, bool bLeavingPawnInventory); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnUnEquip
	void ResetAimOutGate(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ResetAimOutGate
	void ReceiveOnLeaveInventory(struct ADFBaseCharacter* LastOwner); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnLeaveInventory
	void SetCurrentSight(struct USceneComponent* Sight); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SetCurrentSight
	void OnBraceAimEnd(); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.OnBraceAimEnd
	void ExecuteUbergraph_BP_HDScopeWeaponBase(int32_t EntryPoint); // Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ExecuteUbergraph_BP_HDScopeWeaponBase
}; 



