#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ExecuteUbergraph_BP_HDAIControllerBase
// Size: 0xD1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDAIControllerBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ADFBaseCharacter* K2Node_CustomEvent_Character;  // 0x8(0x8)
	struct ADFBaseItem* K2Node_CustomEvent_NewEquippedItem;  // 0x10(0x8)
	struct ADFBaseItem* K2Node_CustomEvent_PrevEquippedItem;  // 0x18(0x8)
	struct ABP_HDWeaponBase_C* K2Node_DynamicCast_AsBP_HDWeapon_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct ABP_HDWeaponBase_C* K2Node_DynamicCast_AsBP_HDWeapon_Base_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ADFBaseProjectile* K2Node_CustomEvent_OtherProjectile_2;  // 0x40(0x8)
	struct ADFBasePickup* K2Node_CustomEvent_Pickup_2;  // 0x48(0x8)
	struct ADFBaseProjectile* K2Node_CustomEvent_OtherProjectile;  // 0x50(0x8)
	struct ADFBasePickup* K2Node_CustomEvent_Pickup;  // 0x58(0x8)
	struct APawn* K2Node_Event_UnpossessedPawn;  // 0x60(0x8)
	struct APawn* K2Node_CustomEvent_VictimPawn;  // 0x68(0x8)
	struct AController* K2Node_CustomEvent_VictimController;  // 0x70(0x8)
	float K2Node_CustomEvent_KillingDamage;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct FDamageEvent K2Node_CustomEvent_DamageEvent;  // 0x80(0x10)
	struct APawn* K2Node_CustomEvent_InstigatingPawn;  // 0x90(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x98(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base_2;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct APawn* K2Node_Event_PossessedPawn;  // 0xC0(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base_3;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xD0(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ResetRecoilHandler
// Size: 0x11(Inherited: 0x0) 
struct FResetRecoilHandler
{
	struct ABP_HDWeaponBase_C* Weapon;  // 0x0(0x8)
	struct UBP_ViewPunchRecoilHandler_C* K2Node_DynamicCast_AsBP_View_Punch_Recoil_Handler;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ReceiveUnPossess
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnPossess : public FReceiveUnPossess
{
	struct APawn* UnpossessedPawn;  // 0x0(0x8)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.OnOwnerPawnDeath
// Size: 0x38(Inherited: 0x0) 
struct FOnOwnerPawnDeath
{
	struct APawn* VictimPawn;  // 0x0(0x8)
	struct AController* VictimController;  // 0x8(0x8)
	float KillingDamage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FDamageEvent DamageEvent;  // 0x18(0x10)
	struct APawn* InstigatingPawn;  // 0x28(0x8)
	struct AActor* DamageCauser;  // 0x30(0x8)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.HitDamageEvent
// Size: 0x10(Inherited: 0x0) 
struct FHitDamageEvent
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.GetFactionSpecifiedSquadMemberKit
// Size: 0x29(Inherited: 0x8) 
struct FGetFactionSpecifiedSquadMemberKit : public FGetFactionSpecifiedSquadMemberKit
{
	struct UHDKit* ReturnValue;  // 0x0(0x8)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x8(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x9(0x1)
	UBP_HDFactionInfoBase_C* CallFunc_GetHDFactionInfoForTeam_HDFactionInfoClass;  // 0x10(0x8)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x18(0x8)
	struct UHDKit* K2Node_DynamicCast_AsHD_Kit;  // 0x20(0x8)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SuppressionEvent
// Size: 0x10(Inherited: 0x0) 
struct FSuppressionEvent
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.GetFactionSpecifiedSquadLeaderKit
// Size: 0x29(Inherited: 0x8) 
struct FGetFactionSpecifiedSquadLeaderKit : public FGetFactionSpecifiedSquadLeaderKit
{
	struct UHDKit* ReturnValue;  // 0x0(0x8)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x8(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x9(0x1)
	UBP_HDFactionInfoBase_C* CallFunc_GetHDFactionInfoForTeam_HDFactionInfoClass;  // 0x10(0x8)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x18(0x8)
	struct UHDKit* K2Node_DynamicCast_AsHD_Kit;  // 0x20(0x8)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupVocalProfile
// Size: 0xBA(Inherited: 0x0) 
struct FSetupVocalProfile
{
	struct UDataTable* VocalProfiles;  // 0x0(0x8)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C(0x4)
	int32_t CallFunc_RandomInteger_ReturnValue;  // 0x20(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x24(0x8)
	char pad_44[4];  // 0x2C(0x4)
	struct FAICharacterVocalProfile CallFunc_GetDataTableRowFromName_OutRow;  // 0x30(0x68)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x98(0x1)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x99(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x9A(0x1)
	char pad_155[5];  // 0x9B(0x5)
	UBP_HDFactionInfoBase_C* CallFunc_GetHDFactionInfoForTeam_HDFactionInfoClass;  // 0xA0(0x8)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0xA8(0x8)
	struct UDataTable* K2Node_DynamicCast_AsData_Table;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xB9(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ReceivePossess
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossess : public FReceivePossess
{
	struct APawn* PossessedPawn;  // 0x0(0x8)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.OnOwnerPawnEquippedItemChange
// Size: 0x18(Inherited: 0x0) 
struct FOnOwnerPawnEquippedItemChange
{
	struct ADFBaseCharacter* Character;  // 0x0(0x8)
	struct ADFBaseItem* NewEquippedItem;  // 0x8(0x8)
	struct ADFBaseItem* PrevEquippedItem;  // 0x10(0x8)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.UnbindEventsFromCharacter
// Size: 0x48(Inherited: 0x0) 
struct FUnbindEventsFromCharacter
{
	struct ABP_HDPlayerCharacterBase_C* Character;  // 0x0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x18(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x28(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x38(0x10)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.WarnOfNoRecoilHandler
// Size: 0x28(Inherited: 0x0) 
struct FWarnOfNoRecoilHandler
{
	struct ABP_HDWeaponBase_C* EquippedWeapon;  // 0x0(0x8)
	struct FString CallFunc_GetPathName_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x18(0x10)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.BindEventsToCharacter
// Size: 0x48(Inherited: 0x0) 
struct FBindEventsToCharacter
{
	struct ABP_HDPlayerCharacterBase_C* Character;  // 0x0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x18(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x28(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x38(0x10)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.CharacterCleanup
// Size: 0x19(Inherited: 0x0) 
struct FCharacterCleanup
{
	struct ABP_HDPlayerCharacterBase_C* Character;  // 0x0(0x8)
	struct ADFBaseItem* CallFunc_GetEquippedItem_ReturnValue;  // 0x8(0x8)
	struct ABP_HDWeaponBase_C* K2Node_DynamicCast_AsBP_HDWeapon_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupRecoilHandler
// Size: 0x12(Inherited: 0x0) 
struct FSetupRecoilHandler
{
	struct ABP_HDWeaponBase_C* Weapon;  // 0x0(0x8)
	struct UBP_ViewPunchRecoilHandler_C* K2Node_DynamicCast_AsBP_View_Punch_Recoil_Handler;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SaveAndApplyNewValuesToWeapon
// Size: 0x9(Inherited: 0x0) 
struct FSaveAndApplyNewValuesToWeapon
{
	struct ABP_HDWeaponBase_C* Weapon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.RestorePreviousValuesForWeapon
// Size: 0x9(Inherited: 0x0) 
struct FRestorePreviousValuesForWeapon
{
	struct ABP_HDWeaponBase_C* Weapon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.SetupWeaponBase
// Size: 0xB(Inherited: 0x0) 
struct FSetupWeaponBase
{
	struct ABP_HDWeaponBase_C* Weapon;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0xA(0x1)

}; 
// Function BP_HDAIControllerBase.BP_HDAIControllerBase_C.ResetWeaponBase
// Size: 0x8(Inherited: 0x0) 
struct FResetWeaponBase
{
	struct ABP_HDWeaponBase_C* Weapon;  // 0x0(0x8)

}; 
