#pragma once 
#include <BPFL_HDUI_Structs.h>
 
 
 
// BlueprintGeneratedClass BPFL_HDUI.BPFL_HDUI_C
// Size: 0x28(Inherited: 0x28) 
struct UBPFL_HDUI_C : public UBlueprintFunctionLibrary
{

	void ParseServerBadgesFromTable(struct UDataTable* BadgeTable, struct UObject* __WorldContext, struct TArray<struct FFServerBadgeUIDefinition>& SortedBadgeDefs); // Function BPFL_HDUI.BPFL_HDUI_C.ParseServerBadgesFromTable
	void GetIconBrushForStanceState(uint8_t  State, struct UObject* __WorldContext, struct FSlateBrush& IconBrush); // Function BPFL_HDUI.BPFL_HDUI_C.GetIconBrushForStanceState
	void GetIconTextureForStanceState(uint8_t  State, struct UObject* __WorldContext, struct UTexture2D*& IconTex); // Function BPFL_HDUI.BPFL_HDUI_C.GetIconTextureForStanceState
	void GetNormHealthColorByRatio(float HealthValueNorm, struct UObject* __WorldContext, struct FLinearColor& ColorToUse); // Function BPFL_HDUI.BPFL_HDUI_C.GetNormHealthColorByRatio
	void GetHealthColorByRatio(float Health, float MaxHealth, struct UObject* __WorldContext, struct FLinearColor& ColorToUse); // Function BPFL_HDUI.BPFL_HDUI_C.GetHealthColorByRatio
}; 



