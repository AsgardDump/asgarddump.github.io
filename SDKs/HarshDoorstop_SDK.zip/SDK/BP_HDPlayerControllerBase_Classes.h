#pragma once 
#include <BP_HDPlayerControllerBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C
// Size: 0x710(Inherited: 0x6A0) 
struct ABP_HDPlayerControllerBase_C : public AHDPlayerController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x6A0(0x8)
	struct UWBP_DeployMenu_C* DeployMenu;  // 0x6A8(0x8)
	char pad_1712_1 : 7;  // 0x6B0(0x1)
	bool bInitialSpawn : 1;  // 0x6B0(0x1)
	char pad_1713_1 : 7;  // 0x6B1(0x1)
	bool bWantsToOpenDeployMenu : 1;  // 0x6B1(0x1)
	char pad_1714_1 : 7;  // 0x6B2(0x1)
	bool bDeployMenuShown : 1;  // 0x6B2(0x1)
	char pad_1715[5];  // 0x6B3(0x5)
	struct FMulticastInlineDelegate OnRepPlayerState;  // 0x6B8(0x10)
	char pad_1736_1 : 7;  // 0x6C8(0x1)
	bool bOpenDeployMenuOnBeginPlay : 1;  // 0x6C8(0x1)
	char pad_1737[7];  // 0x6C9(0x7)
	struct UUserWidget* DeathScreen;  // 0x6D0(0x8)
	char pad_1752_1 : 7;  // 0x6D8(0x1)
	bool bDeathScreenShown : 1;  // 0x6D8(0x1)
	char pad_1753[7];  // 0x6D9(0x7)
	struct UUserWidget* WatermarkWidget;  // 0x6E0(0x8)
	struct TSoftClassPtr<UObject> WatermarkWidgetClass;  // 0x6E8(0x28)

	void GetJoystickDirection(char EJoystickTypes Stick, struct FVector2D& StickInput); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetJoystickDirection
	void RestoreCamDefaultViewRotationYawLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationYawLimits
	void RestoreCamDefaultViewRotationPitchLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationPitchLimits
	void RestoreCamDefaultViewRotationRollLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationRollLimits
	void RestoreCamDefaultViewRotationLimits(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RestoreCamDefaultViewRotationLimits
	void SetCamViewRotationYawLimits(float ViewYawMin, float ViewYawMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationYawLimits
	void SetCamViewRotationPitchLimits(float ViewPitchMin, float ViewPitchMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationPitchLimits
	void SetCamViewRotationRollLimits(float ViewRollMin, float ViewRollMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationRollLimits
	void SetCamViewRotationLimits(struct FRotator ViewRotMin, struct FRotator ViewRotMax, bool bRelativeToPawnRotation); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetCamViewRotationLimits
	void SetSquadLockedState(struct AHDSquadState* Squad, bool bLocked); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SetSquadLockedState
	void KickSquadMember(struct AHDSquadState* Squad, struct AHDPlayerState* MemberToRemove, bool& bRemoveSuccess); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.KickSquadMember
	void LeaveCurrentSquad(bool& bLeaveSuccess); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LeaveCurrentSquad
	void IsSquadLeader(struct AHDSquadState* Squad, bool& bSquadLeader); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.IsSquadLeader
	void CanJoinSquad(struct AHDSquadState* SquadToJoin, bool& bJoinableSquad); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.CanJoinSquad
	void JoinSquad(struct AHDSquadState* SquadToJoin, bool& bJoinSuccess); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.JoinSquad
	void InternalCreateUnnamedSquad(struct AHDPlatoonState* ForPlatoon, bool bJoinSquadAfterCreation, bool bStartLocked, bool& bSuccess, struct AHDSquadState*& NewSquad); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InternalCreateUnnamedSquad
	void GetHDTeamState(struct AHDTeamState*& TeamState); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetHDTeamState
	void GetHDPlayerState(struct AHDPlayerState*& PlayerState); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetHDPlayerState
	void SpawnVehicleAtPlayer(ABP_HDVehicleBase_C* VehicleClass); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.SpawnVehicleAtPlayer
	void HideHUD(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.HideHUD
	void ShowHUD(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ShowHUD
	void GetTeamKits(struct TSet<struct UHDKit*>& TeamKits); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetTeamKits
	void GetMinimapWidget(struct UDFMinimap*& MinimapWidget); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.GetMinimapWidget
	void IsVictoryMenuShown(bool& bShown); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.IsVictoryMenuShown
	void DeathScreenToggle(bool bShow); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.DeathScreenToggle
	void UnloadDeathScreen(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.UnloadDeathScreen
	void LoadDeathScreen(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadDeathScreen
	void DeployMenuToggle(bool bShowMenu, bool bForce); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.DeployMenuToggle
	void UnloadDeployMenu(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.UnloadDeployMenu
	void LoadDeployMenu(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadDeployMenu
	void LoadAndActivateDeployMenu(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.LoadAndActivateDeployMenu
	void InpActEvt_Fire_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Fire_K2Node_InputActionEvent_5
	void InpActEvt_Fire_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Fire_K2Node_InputActionEvent_4
	void InpActEvt_DeployMenu_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_DeployMenu_K2Node_InputActionEvent_3
	void InpActEvt_F1_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F1_K2Node_InputKeyEvent_4
	void InpActEvt_F2_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F2_K2Node_InputKeyEvent_3
	void InpActEvt_F3_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F3_K2Node_InputKeyEvent_2
	void InpActEvt_Use_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_Use_K2Node_InputActionEvent_2
	void InpActEvt_F4_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_F4_K2Node_InputKeyEvent_1
	void OnLoaded_97A2A56D4425648AEE60ECA073085E53(UObject* Loaded); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnLoaded_97A2A56D4425648AEE60ECA073085E53
	void InpActEvt_ChatHistoryToggle_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.InpActEvt_ChatHistoryToggle_K2Node_InputActionEvent_1
	void ServerCreateAndJoinUserSquadUnnamed(struct AHDPlatoonState* ForPlatoon); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerCreateAndJoinUserSquadUnnamed
	void ServerLeaveCurrentSquad(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerLeaveCurrentSquad
	void ServerJoinSquad(struct AHDSquadState* SquadToJoin); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerJoinSquad
	void ServerSetSquadLockedState(struct AHDSquadState* Squad, bool bLocked); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerSetSquadLockedState
	void ServerKickSquadMember(struct AHDSquadState* Squad, struct AHDPlayerState* MemberToRemove); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ServerKickSquadMember
	void UpdatePlayerPOIs(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.UpdatePlayerPOIs
	void ReceiveBeginPlay(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveBeginPlay
	void OnDeployMenuPreloadFinished(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnDeployMenuPreloadFinished
	void ReceiveOnRepPlayerState(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveOnRepPlayerState
	void OnPlayerSpawnTimerElapsed(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnPlayerSpawnTimerElapsed
	void ReceivePlayerTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceivePlayerTeamNumUpdated
	void TryGetInVehicle(struct AArcBaseVehicle* Vehicle); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.TryGetInVehicle
	void RequestExitVehicle(struct AArcBaseVehicle* Vehicle); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.RequestExitVehicle
	void Server_RequestSeatChange(int32_t Seat); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.Server_RequestSeatChange
	void ReceivePossessPawn(struct APawn* NewPawn); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceivePossessPawn
	void CharacterDeath(struct APawn* VictimPawn, struct AController* VictimController, float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.CharacterDeath
	void Auth_SpawnVehicle(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.Auth_SpawnVehicle
	void ReceiveGameHasEnded(struct AActor* EndGameFocus, bool bIsWinner); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveGameHasEnded
	void ReceiveUnpossessPawn(struct APawn* UnpossessedPawn); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ReceiveUnpossessPawn
	void ExecuteUbergraph_BP_HDPlayerControllerBase(int32_t EntryPoint); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.ExecuteUbergraph_BP_HDPlayerControllerBase
	void OnRepPlayerState__DelegateSignature(); // Function BP_HDPlayerControllerBase.BP_HDPlayerControllerBase_C.OnRepPlayerState__DelegateSignature
}; 



