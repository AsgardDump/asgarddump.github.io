#pragma once 
#include <WBP_OptionMenu_CreateGame_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C
// Size: 0x368(Inherited: 0x238) 
struct UWBP_OptionMenu_CreateGame_C : public UDFBaseMenu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UTBListView* GMList;  // 0x240(0x8)
	struct UTBListView* MapList;  // 0x248(0x8)
	struct UImage* MapPreviewImg;  // 0x250(0x8)
	struct UScrollBox* ModifierListScrollBox;  // 0x258(0x8)
	struct UWBP_BotsGameModifierSettings_C* SettingsModifierBots;  // 0x260(0x8)
	struct UWBP_FactionGameModifierSettings_C* SettingsModifierFactions;  // 0x268(0x8)
	struct UButton* StartGameBtn;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool bAutoSelectFirstMap : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool bUsePredefinedMapList : 1;  // 0x279(0x1)
	char pad_634[6];  // 0x27A(0x6)
	struct TArray<struct FFMapInfo> PredefinedMapList;  // 0x280(0x10)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bAutoSelectFirstGame : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct UTexture2D* DefaultGMBanner;  // 0x298(0x8)
	struct TSoftClassPtr<UObject> LegacyAASGMClass;  // 0x2A0(0x28)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool bUsePredefinedGameList : 1;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)
	struct TArray<struct FFGameModeInfo> PredefinedGameList;  // 0x2D0(0x10)
	struct FMulticastInlineDelegate OnBuildTravelURL;  // 0x2E0(0x10)
	struct FString TravelURL;  // 0x2F0(0x10)
	struct TMap<struct FName, struct FText> PredefinedMapParentNameOverrides;  // 0x300(0x50)
	struct TArray<struct UHDGameModeDefinition*> SelectableGMDefs;  // 0x350(0x10)
	struct UHDGameModeDefinition* SelectedGM;  // 0x360(0x8)

	void GetValidDisplayNameForGMDefinition(struct UHDGameModeDefinition* GMDef, struct FText& DisplayName); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.GetValidDisplayNameForGMDefinition
	void FindGMDefinitionByClassName(struct FString& ClassName, struct UHDGameModeDefinition*& GMDef); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FindGMDefinitionByClassName
	void ContainsGMByClass(struct TSoftClassPtr<UObject> GMClass, bool& bContainsGM); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ContainsGMByClass
	void FilterExcludesGMClass(struct TSoftClassPtr<UObject> GMClass, bool bLegacyAASSupport, bool& bExcludeGM); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FilterExcludesGMClass
	void FilterExcludesMapPrefix(struct FString MapName, bool& bExcludePrefix); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FilterExcludesMapPrefix
	void SortGMList(struct TArray<struct FFGameModeInfo>& GMListToSort, bool bDescending); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SortGMList
	void SortMapList(struct TArray<struct FFMapInfo>& MapListToSort, bool bDescending); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SortMapList
	void UpdateStartButtonState(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.UpdateStartButtonState
	void ClearMapPreviewImage(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ClearMapPreviewImage
	void SetMapPreviewImage(struct UTexture2D* NewImg); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.SetMapPreviewImage
	void AddGMToList(struct FFGameModeInfo& GMInfo, struct UBP_GMListItemData_C*& NewGMItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AddGMToList
	void CreateGMListItem(struct FFGameModeInfo& GMInfo, struct UBP_GMListItemData_C*& GMItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.CreateGMListItem
	void HandleStartGame(struct FFMapInfo& SelectedMapInfo, struct FFGameModeInfo& SelectedGMInfo); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.HandleStartGame
	void AppendOptionsFromActiveModifiers(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AppendOptionsFromActiveModifiers
	void GetActiveModifiers(struct TArray<struct TScriptInterface<IBPI_GameModifierSettings_C>>& ActiveModifiers); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.GetActiveModifiers
	void AppendTravelURL(struct FString& OptionsToAdd); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AppendTravelURL
	void AddMapToList(struct FFMapInfo& MapInfo, struct UBP_MapListItemData_C*& NewMapItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.AddMapToList
	void CreateMapListItem(struct FFMapInfo& MapInfo, struct UBP_MapListItemData_C*& MapItem); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.CreateMapListItem
	void RepopulateMapListFromRegistry(struct UBP_GMListItemData_C* GMItemFilter); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.RepopulateMapListFromRegistry
	void RepopulateGameListFromRegistry(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.RepopulateGameListFromRegistry
	void ShouldAddGMListing(struct UHDGameModeDefinition* GMDef, bool& bAddListing); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ShouldAddGMListing
	void FetchGameModesFromRegistry(struct TArray<struct FFGameModeInfo>& GMsFound); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchGameModesFromRegistry
	void ShouldAddMapListing(struct FPrimaryAssetId& MapAssetId, bool& bAddListing); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ShouldAddMapListing
	void FetchMapsFromRegistry(struct TArray<struct FFMapInfo>& MapsFound); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchMapsFromRegistry
	void Completed_D5E8D9AE41A0DF3C4DEC0184D72FF481(struct TArray<struct UObject*>& Loaded); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.Completed_D5E8D9AE41A0DF3C4DEC0184D72FF481
	void BndEvt__CreateGameBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__CreateGameBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void OnInitialized(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.OnInitialized
	void BndEvt__GMList_K2Node_ComponentBoundEvent_2_OnListItemSelectionChangedDynamic__DelegateSignature(struct UObject* Item, bool bIsSelected); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__GMList_K2Node_ComponentBoundEvent_2_OnListItemSelectionChangedDynamic__DelegateSignature
	void BndEvt__GMList_K2Node_ComponentBoundEvent_3_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__GMList_K2Node_ComponentBoundEvent_3_OnListEntryInitializedDynamic__DelegateSignature
	void BndEvt__MapList_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature(struct UObject* Item, struct UUserWidget* Widget); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__MapList_K2Node_ComponentBoundEvent_5_OnListEntryInitializedDynamic__DelegateSignature
	void BndEvt__MapList_K2Node_ComponentBoundEvent_1_OnListItemSelectionChangedDynamic__DelegateSignature(struct UObject* Item, bool bIsSelected); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.BndEvt__MapList_K2Node_ComponentBoundEvent_1_OnListItemSelectionChangedDynamic__DelegateSignature
	void FetchGameModes(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.FetchGameModes
	void Destruct(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.Destruct
	void ExecuteUbergraph_WBP_OptionMenu_CreateGame(int32_t EntryPoint); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.ExecuteUbergraph_WBP_OptionMenu_CreateGame
	void OnBuildTravelURL__DelegateSignature(); // Function WBP_OptionMenu_CreateGame.WBP_OptionMenu_CreateGame_C.OnBuildTravelURL__DelegateSignature
}; 



