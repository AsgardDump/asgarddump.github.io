#pragma once 
#include "SDK.h" 
 
 
// Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.OnMouseButtonDown
// Size: 0x230(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)
	struct FKey CallFunc_PointerEvent_GetEffectingButton_ReturnValue;  // 0x218(0x18)

}; 
// Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.OnMouseWheel
// Size: 0x328(Inherited: 0x160) 
struct FOnMouseWheel : public FOnMouseWheel
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool Temp_bool_Variable : 1;  // 0x160(0x1)
	float CallFunc_PointerEvent_GetWheelDelta_ReturnValue;  // 0x164(0x4)
	struct FKey Temp_struct_Variable;  // 0x168(0x18)
	char pad_733_1 : 7;  // 0x2DD(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x180(0x1)
	struct FKey Temp_struct_Variable_2;  // 0x188(0x18)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x1A0(0xB8)
	struct FEventReply CallFunc_ClearUserFocus_ReturnValue;  // 0x258(0xB8)
	struct FKey K2Node_Select_Default;  // 0x310(0x18)

}; 
// Function WBP_MouseInputCatcherOverlay.WBP_MouseInputCatcherOverlay_C.SelectKey
// Size: 0x38(Inherited: 0x0) 
struct FSelectKey
{
	struct FKey Key;  // 0x0(0x18)
	struct FInputChord K2Node_MakeStruct_InputChord;  // 0x18(0x20)

}; 
