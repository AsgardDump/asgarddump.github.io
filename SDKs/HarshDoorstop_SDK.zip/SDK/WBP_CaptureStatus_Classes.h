#pragma once 
#include <WBP_CaptureStatus_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_CaptureStatus.WBP_CaptureStatus_C
// Size: 0x2F8(Inherited: 0x268) 
struct UWBP_CaptureStatus_C : public UHDUIUWCaptureStatus
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	struct UWidgetAnimation* DisplayCaptureUIAnim;  // 0x270(0x8)
	struct UProgressBar* ControlPointProgressBar;  // 0x278(0x8)
	struct UTextBlock* ControlPointText;  // 0x280(0x8)
	struct UHorizontalBox* GarrisonedUnitHBox;  // 0x288(0x8)
	struct UTextBlock* TeamOwnerText;  // 0x290(0x8)
	struct FLinearColor LocalOwnershipColorToUse;  // 0x298(0x10)
	int32_t PreviewNumFriendlies;  // 0x2A8(0x4)
	int32_t PreviewNumEnemies;  // 0x2AC(0x4)
	int32_t PreviewMinNumRequiredToCapture;  // 0x2B0(0x4)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool bFriendlyUnitsRightToLeft : 1;  // 0x2B4(0x1)
	char pad_693_1 : 7;  // 0x2B5(0x1)
	bool bEnemyUnitsRightToLeft : 1;  // 0x2B5(0x1)
	char pad_694_1 : 7;  // 0x2B6(0x1)
	bool bUseFriendlyOwnershipColor : 1;  // 0x2B6(0x1)
	char pad_695[1];  // 0x2B7(0x1)
	struct FMargin UnitPadding;  // 0x2B8(0x10)
	struct FLinearColor FriendlyOwnershipColor;  // 0x2C8(0x10)
	struct FLinearColor NeutralOwnershipColor;  // 0x2D8(0x10)
	struct FLinearColor EnemyOwnershipColor;  // 0x2E8(0x10)

	void UpdateActiveUnits(bool bFriendly, int32_t UnitCount, int32_t MinUnitsRequired); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateActiveUnits
	void SetMinCountToCapture(int32_t MinCount); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.SetMinCountToCapture
	void ResizeGarrisonContainer(int32_t NewUnitIconCount); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ResizeGarrisonContainer
	void UpdateTeamOwnerText(uint8_t  CaptureTeam); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateTeamOwnerText
	void UpdateProgressBarColor(uint8_t  OwningTeam); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateProgressBarColor
	void OwnerTouchingControlPoint(struct AHDBaseCapturePoint* OverlappingCP, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.OwnerTouchingControlPoint
	void OwnerNoControlPoint(); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.OwnerNoControlPoint
	void OnInitialized(); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.OnInitialized
	void ControlPointSetCaptureProgress(bool bContested, float NewValueNorm, float OldValueNorm, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetCaptureProgress
	void ControlPointSetOwnershipState(bool bCaptured, uint8_t  NewOwningTeam, uint8_t  OldOwningTeam, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetOwnershipState
	void ControlPointSetGarrisonedPlayerCount(int32_t NumFriendlies, int32_t NumEnemies, int32_t MinNumRequiredForCapture, bool bInitial); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetGarrisonedPlayerCount
	void PreConstruct(bool IsDesignTime); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.PreConstruct
	void ExecuteUbergraph_WBP_CaptureStatus(int32_t EntryPoint); // Function WBP_CaptureStatus.WBP_CaptureStatus_C.ExecuteUbergraph_WBP_CaptureStatus
}; 



