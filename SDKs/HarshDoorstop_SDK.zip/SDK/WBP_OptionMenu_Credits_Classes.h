#pragma once 
#include <WBP_OptionMenu_Credits_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C
// Size: 0x264(Inherited: 0x238) 
struct UWBP_OptionMenu_Credits_C : public UDFBaseMenu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UScrollBox* CreditsScrollBox;  // 0x240(0x8)
	struct UDataTable* CreditsEntriesTable;  // 0x248(0x8)
	struct FMargin EntryPadding;  // 0x250(0x10)
	float AutoScrollSpeed;  // 0x260(0x4)

	void GetCreditEntriesForHeader(struct FName HeaderRowName, struct TArray<struct FFGameCreditsEntry>& CreditEntries); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.GetCreditEntriesForHeader
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.PreConstruct
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.Tick
	void ExecuteUbergraph_WBP_OptionMenu_Credits(int32_t EntryPoint); // Function WBP_OptionMenu_Credits.WBP_OptionMenu_Credits_C.ExecuteUbergraph_WBP_OptionMenu_Credits
}; 



