#pragma once 
#include <CS_FiringCameraShake_Structs.h>
 
 
 
// BlueprintGeneratedClass CS_FiringCameraShake.CS_FiringCameraShake_C
// Size: 0x160(Inherited: 0x160) 
struct UCS_FiringCameraShake_C : public UCameraShake
{

}; 



