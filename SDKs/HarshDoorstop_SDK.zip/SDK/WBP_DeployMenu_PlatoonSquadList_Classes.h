#pragma once 
#include <WBP_DeployMenu_PlatoonSquadList_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C
// Size: 0x2D8(Inherited: 0x250) 
struct UWBP_DeployMenu_PlatoonSquadList_C : public UDeployMenu_PlatoonSquadListBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x250(0x8)
	struct UButton* CreateSquadBtn;  // 0x258(0x8)
	struct UImage* Image_11;  // 0x260(0x8)
	struct UTextBlock* PlatoonNameText;  // 0x268(0x8)
	struct UTextBlock* SquadCountText;  // 0x270(0x8)
	struct UVerticalBox* SquadsList;  // 0x278(0x8)
	struct UButton* ToggleListVisibilityBtn;  // 0x280(0x8)
	struct UImage* ToggleListVisibilityImg;  // 0x288(0x8)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bExpanded : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct FText PlatoonTextFormat;  // 0x298(0x18)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool bExpandListInDesigner : 1;  // 0x2B0(0x1)
	char pad_689[3];  // 0x2B1(0x3)
	int32_t NumFakeSquadItems;  // 0x2B4(0x4)
	struct FMargin SquadItemPadding;  // 0x2B8(0x10)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool bCollapsedByUser : 1;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)
	struct UWBP_DeployMenu_SquadSelectionPanel_C* ParentContainerWidget;  // 0x2D0(0x8)

	void IsPlatoonValid(bool& bValidPLTN); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.IsPlatoonValid
	void WasListCollapsedByUser(bool& bCollapsedByUser); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.WasListCollapsedByUser
	void HasAnySquads(bool& bValidSquadsPresent); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.HasAnySquads
	void SetPlatoonNameText(struct FText NewPlatoonName); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.SetPlatoonNameText
	void UpdateCreateBtnAvailability(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.UpdateCreateBtnAvailability
	void UpdateSquadCountText(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.UpdateSquadCountText
	void CollapseListIfEmpty(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.CollapseListIfEmpty
	void CollapseList(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.CollapseList
	void ExpandList(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.ExpandList
	void RemoveSquadItemWidgetFromList(struct USquadListEntry* RemovedSquadData, int32_t RemoveIdx); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.RemoveSquadItemWidgetFromList
	void AddNewSquadItemWidget(struct USquadListEntry* SquadData, struct UWBP_DeployMenu_SquadList_C*& SquadItemWidget); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.AddNewSquadItemWidget
	void GenerateSquad(struct USquadListEntry* SquadData); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.GenerateSquad
	void DeconstructSquad(struct USquadListEntry* RemovedSquadData, int32_t RemovedSquadIdx); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.DeconstructSquad
	void BndEvt__ListToggleBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.BndEvt__ListToggleBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.PreConstruct
	void SquadsListExpanded(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.SquadsListExpanded
	void SquadsListCollapsed(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.SquadsListCollapsed
	void BndEvt__CreateSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.BndEvt__CreateSquadBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void OnPlatoonSet(); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.OnPlatoonSet
	void ExecuteUbergraph_WBP_DeployMenu_PlatoonSquadList(int32_t EntryPoint); // Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.ExecuteUbergraph_WBP_DeployMenu_PlatoonSquadList
}; 



