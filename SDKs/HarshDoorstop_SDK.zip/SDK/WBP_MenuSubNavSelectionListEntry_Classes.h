#pragma once 
#include <WBP_MenuSubNavSelectionListEntry_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C
// Size: 0x270(Inherited: 0x230) 
struct UWBP_MenuSubNavSelectionListEntry_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_CreateGameSelectionListEntry_C* SelectionEntry;  // 0x238(0x8)
	struct FText ItemText;  // 0x240(0x18)
	int32_t SubMenuIndex;  // 0x258(0x4)
	char pad_604[4];  // 0x25C(0x4)
	struct FMulticastInlineDelegate ButtonClicked;  // 0x260(0x10)

	void SetSubMenuIndex(int32_t Idx); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.SetSubMenuIndex
	void PreConstruct(bool IsDesignTime); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.PreConstruct
	void OnItemSelectionChanged(bool bIsSelected); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.OnItemSelectionChanged
	void BndEvt__SelectionEntry_K2Node_ComponentBoundEvent_1_OnSelectionStateChanged__DelegateSignature(struct UWBP_CreateGameSelectionListEntry_C* Item, bool bSelected); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.BndEvt__SelectionEntry_K2Node_ComponentBoundEvent_1_OnSelectionStateChanged__DelegateSignature
	void ExecuteUbergraph_WBP_MenuSubNavSelectionListEntry(int32_t EntryPoint); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.ExecuteUbergraph_WBP_MenuSubNavSelectionListEntry
	void ButtonClicked__DelegateSignature(struct UWBP_MenuSubNavSelectionListEntry_C* ClickedBtn); // Function WBP_MenuSubNavSelectionListEntry.WBP_MenuSubNavSelectionListEntry_C.ButtonClicked__DelegateSignature
}; 



