#pragma once 
#include "SDK.h" 
 
 
// Function WBP_Checkbox.WBP_Checkbox_C.GetCheckedState
// Size: 0x2(Inherited: 0x0) 
struct FGetCheckedState
{
	uint8_t  CheckedState;  // 0x0(0x1)
	uint8_t  CallFunc_GetCheckedState_ReturnValue;  // 0x1(0x1)

}; 
// Function WBP_Checkbox.WBP_Checkbox_C.CheckStateChangedBool__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCheckStateChangedBool__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_Checkbox.WBP_Checkbox_C.CheckStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCheckStateChanged__DelegateSignature
{
	uint8_t  CheckedState;  // 0x0(0x1)

}; 
// Function WBP_Checkbox.WBP_Checkbox_C.ExecuteUbergraph_WBP_Checkbox
// Size: 0x6(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_Checkbox
{
	int32_t EntryPoint;  // 0x0(0x4)
	uint8_t  CallFunc_GetCheckedState_ReturnValue;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked : 1;  // 0x5(0x1)

}; 
// Function WBP_Checkbox.WBP_Checkbox_C.SetCheckedState
// Size: 0x1(Inherited: 0x0) 
struct FSetCheckedState
{
	uint8_t  NewCheckedState;  // 0x0(0x1)

}; 
// Function WBP_Checkbox.WBP_Checkbox_C.BndEvt__CBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__CBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function WBP_Checkbox.WBP_Checkbox_C.IsChecked
// Size: 0x2(Inherited: 0x0) 
struct FIsChecked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function WBP_Checkbox.WBP_Checkbox_C.SetIsChecked
// Size: 0x1(Inherited: 0x0) 
struct FSetIsChecked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bChecked : 1;  // 0x0(0x1)

}; 
