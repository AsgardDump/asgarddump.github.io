#pragma once 
#include <MovieScene_Structs.h>
 
 
 
// Class MovieScene.TestMovieSceneSequence
// Size: 0x350(Inherited: 0x348) 
struct UTestMovieSceneSequence : public UMovieSceneSequence
{
	struct UMovieScene* MovieScene;  // 0x348(0x8)

}; 



// Class MovieScene.MovieSceneSubSection
// Size: 0x158(Inherited: 0xE0) 
struct UMovieSceneSubSection : public UMovieSceneSection
{
	struct FMovieSceneSectionParameters Parameters;  // 0xE0(0x24)
	float StartOffset;  // 0x104(0x4)
	float TimeScale;  // 0x108(0x4)
	float PrerollTime;  // 0x10C(0x4)
	struct UMovieSceneSequence* SubSequence;  // 0x110(0x8)
	 ActorToRecord;  // 0x118(0x1C)
	char pad_308[4];  // 0x134(0x4)
	struct FString TargetSequenceName;  // 0x138(0x10)
	struct FDirectoryPath TargetPathToRecordTo;  // 0x148(0x10)

	void SetSequence(struct UMovieSceneSequence* Sequence); // Function MovieScene.MovieSceneSubSection.SetSequence
	struct UMovieSceneSequence* GetSequence(); // Function MovieScene.MovieSceneSubSection.GetSequence
}; 



// Class MovieScene.TestMovieSceneSubSection
// Size: 0x158(Inherited: 0x158) 
struct UTestMovieSceneSubSection : public UMovieSceneSubSection
{

}; 



// Class MovieScene.MovieSceneTrack
// Size: 0x58(Inherited: 0x50) 
struct UMovieSceneTrack : public UMovieSceneSignedObject
{
	struct FMovieSceneTrackEvalOptions EvalOptions;  // 0x50(0x4)
	char pad_84[1];  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool bIsEvalDisabled : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)

}; 



// Class MovieScene.MovieSceneSignedObject
// Size: 0x50(Inherited: 0x28) 
struct UMovieSceneSignedObject : public UObject
{
	struct FGuid Signature;  // 0x28(0x10)
	char pad_56[24];  // 0x38(0x18)

}; 



// Class MovieScene.MovieSceneSection
// Size: 0xE0(Inherited: 0x50) 
struct UMovieSceneSection : public UMovieSceneSignedObject
{
	struct FMovieSceneSectionEvalOptions EvalOptions;  // 0x50(0x2)
	char pad_82[6];  // 0x52(0x6)
	struct FMovieSceneEasingSettings Easing;  // 0x58(0x38)
	struct FMovieSceneFrameRange SectionRange;  // 0x90(0x10)
	struct FFrameNumber PreRollFrames;  // 0xA0(0x4)
	struct FFrameNumber PostRollFrames;  // 0xA4(0x4)
	int32_t RowIndex;  // 0xA8(0x4)
	int32_t OverlapPriority;  // 0xAC(0x4)
	char bIsActive : 1;  // 0xB0(0x1)
	char bIsLocked : 1;  // 0xB0(0x1)
	char pad_176_1 : 6;  // 0xB0(0x1)
	char pad_177[4];  // 0xB1(0x4)
	float StartTime;  // 0xB4(0x4)
	float EndTime;  // 0xB8(0x4)
	float PrerollTime;  // 0xBC(0x4)
	float PostrollTime;  // 0xC0(0x4)
	char bIsInfinite : 1;  // 0xC4(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	char pad_197[4];  // 0xC5(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bSupportsInfiniteRange : 1;  // 0xC8(0x1)
	struct FOptionalMovieSceneBlendType BlendType;  // 0xC9(0x2)
	char pad_203[21];  // 0xCB(0x15)

	void SetRowIndex(int32_t NewRowIndex); // Function MovieScene.MovieSceneSection.SetRowIndex
	void SetPreRollFrames(int32_t InPreRollFrames); // Function MovieScene.MovieSceneSection.SetPreRollFrames
	void SetPostRollFrames(int32_t InPostRollFrames); // Function MovieScene.MovieSceneSection.SetPostRollFrames
	void SetOverlapPriority(int32_t NewPriority); // Function MovieScene.MovieSceneSection.SetOverlapPriority
	void SetIsLocked(bool bInIsLocked); // Function MovieScene.MovieSceneSection.SetIsLocked
	void SetIsActive(bool bInIsActive); // Function MovieScene.MovieSceneSection.SetIsActive
	void SetCompletionMode(uint8_t  InCompletionMode); // Function MovieScene.MovieSceneSection.SetCompletionMode
	void SetBlendType(uint8_t  InBlendType); // Function MovieScene.MovieSceneSection.SetBlendType
	bool IsLocked(); // Function MovieScene.MovieSceneSection.IsLocked
	bool IsActive(); // Function MovieScene.MovieSceneSection.IsActive
	int32_t GetRowIndex(); // Function MovieScene.MovieSceneSection.GetRowIndex
	int32_t GetPreRollFrames(); // Function MovieScene.MovieSceneSection.GetPreRollFrames
	int32_t GetPostRollFrames(); // Function MovieScene.MovieSceneSection.GetPostRollFrames
	int32_t GetOverlapPriority(); // Function MovieScene.MovieSceneSection.GetOverlapPriority
	uint8_t  GetCompletionMode(); // Function MovieScene.MovieSceneSection.GetCompletionMode
	struct FOptionalMovieSceneBlendType GetBlendType(); // Function MovieScene.MovieSceneSection.GetBlendType
}; 



// Class MovieScene.MovieSceneNameableTrack
// Size: 0x58(Inherited: 0x58) 
struct UMovieSceneNameableTrack : public UMovieSceneTrack
{

}; 



// Class MovieScene.MovieSceneSequence
// Size: 0x348(Inherited: 0x50) 
struct UMovieSceneSequence : public UMovieSceneSignedObject
{
	struct FMovieSceneEvaluationTemplate PrecompiledEvaluationTemplate;  // 0x50(0x2F0)
	uint8_t  DefaultCompletionMode;  // 0x340(0x1)
	char pad_833_1 : 7;  // 0x341(0x1)
	bool bParentContextsAreSignificant : 1;  // 0x341(0x1)
	char pad_834_1 : 7;  // 0x342(0x1)
	bool bPlayableDirectly : 1;  // 0x342(0x1)
	char pad_835[5];  // 0x343(0x5)

	struct TArray<struct FMovieSceneObjectBindingID> FindBindingsByTag(struct FName InBindingName); // Function MovieScene.MovieSceneSequence.FindBindingsByTag
	struct FMovieSceneObjectBindingID FindBindingByTag(struct FName InBindingName); // Function MovieScene.MovieSceneSequence.FindBindingByTag
}; 



// Class MovieScene.MovieSceneSubTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneSubTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x58(0x10)

}; 



// Class MovieScene.MovieSceneSequencePlayer
// Size: 0x888(Inherited: 0x28) 
struct UMovieSceneSequencePlayer : public UObject
{
	char pad_40[992];  // 0x28(0x3E0)
	struct FMulticastInlineDelegate OnPlay;  // 0x408(0x10)
	struct FMulticastInlineDelegate OnPlayReverse;  // 0x418(0x10)
	struct FMulticastInlineDelegate OnStop;  // 0x428(0x10)
	struct FMulticastInlineDelegate OnPause;  // 0x438(0x10)
	struct FMulticastInlineDelegate OnFinished;  // 0x448(0x10)
	char EMovieScenePlayerStatus Status;  // 0x458(0x1)
	char pad_1113[3];  // 0x459(0x3)
	char bReversePlayback : 1;  // 0x45C(0x1)
	char pad_1116_1 : 7;  // 0x45C(0x1)
	char pad_1117[4];  // 0x45D(0x4)
	struct UMovieSceneSequence* Sequence;  // 0x460(0x8)
	struct FFrameNumber StartTime;  // 0x468(0x4)
	int32_t DurationFrames;  // 0x46C(0x4)
	int32_t CurrentNumLoops;  // 0x470(0x4)
	char pad_1140[20];  // 0x474(0x14)
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings;  // 0x488(0x14)
	char pad_1180[4];  // 0x49C(0x4)
	struct FMovieSceneRootEvaluationTemplateInstance RootTemplateInstance;  // 0x4A0(0x320)
	char pad_1984[104];  // 0x7C0(0x68)
	struct FMovieSceneSequenceReplProperties NetSyncProps;  // 0x828(0x10)
	struct TScriptInterface<IMovieScenePlaybackClient> PlaybackClient;  // 0x838(0x10)
	char pad_2120[64];  // 0x848(0x40)

	void StopAtCurrentTime(); // Function MovieScene.MovieSceneSequencePlayer.StopAtCurrentTime
	void Stop(); // Function MovieScene.MovieSceneSequencePlayer.Stop
	void SetTimeRange(float StartTime, float Duration); // Function MovieScene.MovieSceneSequencePlayer.SetTimeRange
	void SetPlayRate(float PlayRate); // Function MovieScene.MovieSceneSequencePlayer.SetPlayRate
	void SetPlaybackRange(float NewStartTime, float NewEndTime); // Function MovieScene.MovieSceneSequencePlayer.SetPlaybackRange
	void SetPlaybackPosition(float NewPlaybackPosition); // Function MovieScene.MovieSceneSequencePlayer.SetPlaybackPosition
	void SetFrameRate(struct FFrameRate FrameRate); // Function MovieScene.MovieSceneSequencePlayer.SetFrameRate
	void SetFrameRange(int32_t StartFrame, int32_t Duration); // Function MovieScene.MovieSceneSequencePlayer.SetFrameRange
	void SetDisableCameraCuts(bool bInDisableCameraCuts); // Function MovieScene.MovieSceneSequencePlayer.SetDisableCameraCuts
	void ScrubToSeconds(float TimeInSeconds); // Function MovieScene.MovieSceneSequencePlayer.ScrubToSeconds
	bool ScrubToMarkedFrame(struct FString InLabel); // Function MovieScene.MovieSceneSequencePlayer.ScrubToMarkedFrame
	void ScrubToFrame(struct FFrameTime NewPosition); // Function MovieScene.MovieSceneSequencePlayer.ScrubToFrame
	void Scrub(); // Function MovieScene.MovieSceneSequencePlayer.Scrub
	void RPC_OnStopEvent(struct FFrameTime StoppedTime); // Function MovieScene.MovieSceneSequencePlayer.RPC_OnStopEvent
	void RPC_ExplicitServerUpdateEvent(uint8_t  Method, struct FFrameTime RelevantTime); // Function MovieScene.MovieSceneSequencePlayer.RPC_ExplicitServerUpdateEvent
	void PlayToSeconds(float TimeInSeconds); // Function MovieScene.MovieSceneSequencePlayer.PlayToSeconds
	bool PlayToMarkedFrame(struct FString InLabel); // Function MovieScene.MovieSceneSequencePlayer.PlayToMarkedFrame
	void PlayToFrame(struct FFrameTime NewPosition); // Function MovieScene.MovieSceneSequencePlayer.PlayToFrame
	void PlayReverse(); // Function MovieScene.MovieSceneSequencePlayer.PlayReverse
	void PlayLooping(int32_t NumLoops); // Function MovieScene.MovieSceneSequencePlayer.PlayLooping
	void Play(); // Function MovieScene.MovieSceneSequencePlayer.Play
	void Pause(); // Function MovieScene.MovieSceneSequencePlayer.Pause
	void JumpToSeconds(float TimeInSeconds); // Function MovieScene.MovieSceneSequencePlayer.JumpToSeconds
	void JumpToPosition(float NewPlaybackPosition); // Function MovieScene.MovieSceneSequencePlayer.JumpToPosition
	bool JumpToMarkedFrame(struct FString InLabel); // Function MovieScene.MovieSceneSequencePlayer.JumpToMarkedFrame
	void JumpToFrame(struct FFrameTime NewPosition); // Function MovieScene.MovieSceneSequencePlayer.JumpToFrame
	bool IsReversed(); // Function MovieScene.MovieSceneSequencePlayer.IsReversed
	bool IsPlaying(); // Function MovieScene.MovieSceneSequencePlayer.IsPlaying
	bool IsPaused(); // Function MovieScene.MovieSceneSequencePlayer.IsPaused
	void GoToEndAndStop(); // Function MovieScene.MovieSceneSequencePlayer.GoToEndAndStop
	struct FQualifiedFrameTime GetStartTime(); // Function MovieScene.MovieSceneSequencePlayer.GetStartTime
	float GetPlayRate(); // Function MovieScene.MovieSceneSequencePlayer.GetPlayRate
	float GetPlaybackStart(); // Function MovieScene.MovieSceneSequencePlayer.GetPlaybackStart
	float GetPlaybackPosition(); // Function MovieScene.MovieSceneSequencePlayer.GetPlaybackPosition
	float GetPlaybackEnd(); // Function MovieScene.MovieSceneSequencePlayer.GetPlaybackEnd
	struct TArray<struct FMovieSceneObjectBindingID> GetObjectBindings(struct UObject* InObject); // Function MovieScene.MovieSceneSequencePlayer.GetObjectBindings
	float GetLength(); // Function MovieScene.MovieSceneSequencePlayer.GetLength
	struct FFrameRate GetFrameRate(); // Function MovieScene.MovieSceneSequencePlayer.GetFrameRate
	int32_t GetFrameDuration(); // Function MovieScene.MovieSceneSequencePlayer.GetFrameDuration
	struct FQualifiedFrameTime GetEndTime(); // Function MovieScene.MovieSceneSequencePlayer.GetEndTime
	struct FQualifiedFrameTime GetDuration(); // Function MovieScene.MovieSceneSequencePlayer.GetDuration
	bool GetDisableCameraCuts(); // Function MovieScene.MovieSceneSequencePlayer.GetDisableCameraCuts
	struct FQualifiedFrameTime GetCurrentTime(); // Function MovieScene.MovieSceneSequencePlayer.GetCurrentTime
	struct TArray<struct UObject*> GetBoundObjects(struct FMovieSceneObjectBindingID ObjectBinding); // Function MovieScene.MovieSceneSequencePlayer.GetBoundObjects
	void ChangePlaybackDirection(); // Function MovieScene.MovieSceneSequencePlayer.ChangePlaybackDirection
}; 



// Class MovieScene.MovieSceneCustomClockSource
// Size: 0x28(Inherited: 0x28) 
struct UMovieSceneCustomClockSource : public UInterface
{

	void OnTick(float DeltaSeconds, float InPlayRate); // Function MovieScene.MovieSceneCustomClockSource.OnTick
	void OnStopPlaying(struct FQualifiedFrameTime& InStopTime); // Function MovieScene.MovieSceneCustomClockSource.OnStopPlaying
	void OnStartPlaying(struct FQualifiedFrameTime& InStartTime); // Function MovieScene.MovieSceneCustomClockSource.OnStartPlaying
	struct FFrameTime OnRequestCurrentTime(struct FQualifiedFrameTime& InCurrentTime, float InPlayRate); // Function MovieScene.MovieSceneCustomClockSource.OnRequestCurrentTime
}; 



// Class MovieScene.MovieScenePlaybackClient
// Size: 0x28(Inherited: 0x28) 
struct UMovieScenePlaybackClient : public UInterface
{

}; 



// Class MovieScene.MovieScene
// Size: 0x148(Inherited: 0x50) 
struct UMovieScene : public UMovieSceneSignedObject
{
	struct TArray<struct FMovieSceneSpawnable> Spawnables;  // 0x50(0x10)
	struct TArray<struct FMovieScenePossessable> Possessables;  // 0x60(0x10)
	struct TArray<struct FMovieSceneBinding> ObjectBindings;  // 0x70(0x10)
	struct TMap<struct FName, struct FMovieSceneObjectBindingIDs> BindingGroups;  // 0x80(0x50)
	struct TArray<struct UMovieSceneTrack*> MasterTracks;  // 0xD0(0x10)
	struct UMovieSceneTrack* CameraCutTrack;  // 0xE0(0x8)
	struct FMovieSceneFrameRange SelectionRange;  // 0xE8(0x10)
	struct FMovieSceneFrameRange PlaybackRange;  // 0xF8(0x10)
	struct FFrameRate TickResolution;  // 0x108(0x8)
	struct FFrameRate DisplayRate;  // 0x110(0x8)
	uint8_t  EvaluationType;  // 0x118(0x1)
	uint8_t  ClockSource;  // 0x119(0x1)
	char pad_282[6];  // 0x11A(0x6)
	struct FSoftObjectPath CustomClockSourcePath;  // 0x120(0x18)
	struct TArray<struct FMovieSceneMarkedFrame> MarkedFrames;  // 0x138(0x10)

}; 



// Class MovieScene.MovieSceneBindingOverrides
// Size: 0x90(Inherited: 0x28) 
struct UMovieSceneBindingOverrides : public UObject
{
	struct TArray<struct FMovieSceneBindingOverrideData> BindingData;  // 0x28(0x10)
	char pad_56[88];  // 0x38(0x58)

}; 



// Class MovieScene.MovieSceneBindingOwnerInterface
// Size: 0x28(Inherited: 0x28) 
struct UMovieSceneBindingOwnerInterface : public UInterface
{

}; 



// Class MovieScene.MovieSceneBuiltInEasingFunction
// Size: 0x38(Inherited: 0x28) 
struct UMovieSceneBuiltInEasingFunction : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	uint8_t  Type;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 



// Class MovieScene.TestMovieSceneTrack
// Size: 0x70(Inherited: 0x58) 
struct UTestMovieSceneTrack : public UMovieSceneTrack
{
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bHighPassFilter : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct TArray<struct UMovieSceneSection*> SectionArray;  // 0x60(0x10)

}; 



// Class MovieScene.MovieSceneEasingExternalCurve
// Size: 0x38(Inherited: 0x28) 
struct UMovieSceneEasingExternalCurve : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UCurveFloat* Curve;  // 0x30(0x8)

}; 



// Class MovieScene.MovieSceneEasingFunction
// Size: 0x28(Inherited: 0x28) 
struct UMovieSceneEasingFunction : public UInterface
{

	float OnEvaluate(float Interp); // Function MovieScene.MovieSceneEasingFunction.OnEvaluate
}; 



// Class MovieScene.MovieSceneFolder
// Size: 0x70(Inherited: 0x28) 
struct UMovieSceneFolder : public UObject
{
	struct FName FolderName;  // 0x28(0x8)
	struct TArray<struct UMovieSceneFolder*> ChildFolders;  // 0x30(0x10)
	struct TArray<struct UMovieSceneTrack*> ChildMasterTracks;  // 0x40(0x10)
	struct TArray<struct FString> ChildObjectBindingStrings;  // 0x50(0x10)
	char pad_96[16];  // 0x60(0x10)

}; 



// Class MovieScene.MovieSceneKeyProxy
// Size: 0x28(Inherited: 0x28) 
struct UMovieSceneKeyProxy : public UInterface
{

}; 



// Class MovieScene.TestMovieSceneSection
// Size: 0xE0(Inherited: 0xE0) 
struct UTestMovieSceneSection : public UMovieSceneSection
{

}; 



// Class MovieScene.TestMovieSceneSubTrack
// Size: 0x78(Inherited: 0x68) 
struct UTestMovieSceneSubTrack : public UMovieSceneSubTrack
{
	struct TArray<struct UMovieSceneSection*> SectionArray;  // 0x68(0x10)

}; 



