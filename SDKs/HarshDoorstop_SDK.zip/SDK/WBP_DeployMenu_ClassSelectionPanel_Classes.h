#pragma once 
#include <WBP_DeployMenu_ClassSelectionPanel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C
// Size: 0x2B9(Inherited: 0x230) 
struct UWBP_DeployMenu_ClassSelectionPanel_C : public UDeployMenu_ClassSelectionPanel
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UScrollBox* ClassScrollBox;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool bPanelInitialized : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct ABP_HDPlayerControllerBase_C* HDOwningPlayer;  // 0x248(0x8)
	struct FTimerHandle TimerHandle_CheckRestrictions;  // 0x250(0x8)
	UWBP_DeployMenu_ClassSelectionListing_C* KitListingWidgetClass;  // 0x258(0x8)
	struct TSet<struct UHDKit*> DesignPreviewKits;  // 0x260(0x50)
	struct UHDKit* SelectedClass;  // 0x2B0(0x8)
	uint8_t  LastFaction;  // 0x2B8(0x1)

	void SetClassSelectionState(struct UHDKit* ClassToUpdate, bool bSelected, bool bMatchDisplayNames, bool& bClassUpdated); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SetClassSelectionState
	void InternalUpdateSelectionState(struct UDeployMenu_ClassSelectionListing* NewSelection); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalUpdateSelectionState
	void SelectFirstUnrestrictedClass(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SelectFirstUnrestrictedClass
	void InternalDeselectAllClasses(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalDeselectAllClasses
	void IsValidClassListingIndex(int32_t ChildIndex, bool& bValidIndex); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.IsValidClassListingIndex
	void SetClassSelectionStateByIndex(int32_t ChildIndex, bool bSelected); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.SetClassSelectionStateByIndex
	void ToggleRestrictionsTimer(bool bEnabled, bool bFireOnceImmediately); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.ToggleRestrictionsTimer
	void InternalCreateClassListingWidget(struct UHDKit* Kit, struct UWBP_DeployMenu_ClassSelectionListing_C*& NewKitListingWidget); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalCreateClassListingWidget
	void InternalPopulateListWithClasses(struct TSet<struct UHDKit*> TeamKits); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.InternalPopulateListWithClasses
	void RepopulateListByFaction(uint8_t  OwningPlayerTeam); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.RepopulateListByFaction
	void Construct(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.Construct
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.PreConstruct
	void LateInit_RepPlayerState(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.LateInit_RepPlayerState
	void CheckRestrictions(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.CheckRestrictions
	void Destruct(); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.Destruct
	void OnClassSelected(struct UWBP_DeployMenu_ClassSelectionListing_C* SelectedClassWidget); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.OnClassSelected
	void OnClassDeselected(struct UWBP_DeployMenu_ClassSelectionListing_C* DeselectedClassWidget); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.OnClassDeselected
	void ExecuteUbergraph_WBP_DeployMenu_ClassSelectionPanel(int32_t EntryPoint); // Function WBP_DeployMenu_ClassSelectionPanel.WBP_DeployMenu_ClassSelectionPanel_C.ExecuteUbergraph_WBP_DeployMenu_ClassSelectionPanel
}; 



