#pragma once 
#include <WBP_OptionsMenuItem_InputKeySelector_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C
// Size: 0x2C0(Inherited: 0x230) 
struct UWBP_OptionsMenuItem_InputKeySelector_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_InputKeySelector_C* OptionIKS;  // 0x238(0x8)
	struct UTextBlock* OptionText;  // 0x240(0x8)
	struct FText Text;  // 0x248(0x18)
	struct FText TextDescription;  // 0x260(0x18)
	struct FName InputName;  // 0x278(0x8)
	struct FMulticastInlineDelegate OnKeySelected;  // 0x280(0x10)
	float InputScale;  // 0x290(0x4)
	char pad_660[4];  // 0x294(0x4)
	struct FKey MappedKey;  // 0x298(0x18)
	struct FMulticastInlineDelegate OnIsSelectingKeyChanged;  // 0x2B0(0x10)

	void IsSelectingKey(bool& IsSelecting); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.IsSelectingKey
	void ClearSelectedKey(struct UWBP_OptionsMenuItem_InputKeySelector_C* IKS, struct FKey NewKey, bool bIsPlayerChangingKeyBindings); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.ClearSelectedKey
	void SetSelectedKey(struct FKey SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.SetSelectedKey
	void GetSelectedKey(struct FKey& SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.GetSelectedKey
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.PreConstruct
	void BndEvt__OptionIKS_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.BndEvt__OptionIKS_K2Node_ComponentBoundEvent_2_OnKeySelected__DelegateSignature
	void BndEvt__OptionIKS_K2Node_ComponentBoundEvent_0_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.BndEvt__OptionIKS_K2Node_ComponentBoundEvent_0_OnIsSelectingKeyChanged__DelegateSignature
	void ExecuteUbergraph_WBP_OptionsMenuItem_InputKeySelector(int32_t EntryPoint); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.ExecuteUbergraph_WBP_OptionsMenuItem_InputKeySelector
	void OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.OnIsSelectingKeyChanged__DelegateSignature
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_OptionsMenuItem_InputKeySelector.WBP_OptionsMenuItem_InputKeySelector_C.OnKeySelected__DelegateSignature
}; 



