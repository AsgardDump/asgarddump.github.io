#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.ExecuteUbergraph_BP_HDVehicleBase
// Size: 0xDC(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDVehicleBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputActionEvent_Key;  // 0x8(0x18)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x20(0x4)
	float K2Node_InputAxisEvent_AxisValue;  // 0x24(0x4)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x28(0x18)
	struct AActor* K2Node_Event_Invoker;  // 0x40(0x8)
	struct FKey Temp_struct_Variable;  // 0x48(0x18)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x70(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x88(0x18)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct APlayerState* K2Node_Event_Player;  // 0xA8(0x8)
	struct UArcVehicleSeatConfig* K2Node_Event_ToSeat;  // 0xB0(0x8)
	struct UArcVehicleSeatConfig* K2Node_Event_FromSeat;  // 0xB8(0x8)
	uint8_t  K2Node_Event_SeatChangeEvent;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xC1(0x1)
	char pad_194[6];  // 0xC2(0x6)
	struct UArcVehicleSeatConfig* CallFunc_GetDriverSeat_ReturnValue;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	float K2Node_Event_DeltaSeconds;  // 0xD4(0x4)
	float CallFunc_GetEngineRotationSpeed_ReturnValue;  // 0xD8(0x4)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpActEvt_Use_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Use_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.NotifyPlayerSeatChangeEvent
// Size: 0x19(Inherited: 0x20) 
struct FNotifyPlayerSeatChangeEvent : public FNotifyPlayerSeatChangeEvent
{
	struct APlayerState* Player;  // 0x0(0x8)
	struct UArcVehicleSeatConfig* ToSeat;  // 0x8(0x8)
	struct UArcVehicleSeatConfig* FromSeat;  // 0x10(0x8)
	uint8_t  SeatChangeEvent;  // 0x18(0x1)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.Used
// Size: 0x8(Inherited: 0x0) 
struct FUsed
{
	struct AActor* Invoker;  // 0x0(0x8)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpActEvt_Jump_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Jump_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpActEvt_Jump_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Jump_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
