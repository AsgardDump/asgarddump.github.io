#pragma once 
#include <WBP_Checkbox_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_Checkbox.WBP_Checkbox_C
// Size: 0x260(Inherited: 0x230) 
struct UWBP_Checkbox_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UCheckBox* CBox;  // 0x238(0x8)
	struct FMulticastInlineDelegate CheckStateChanged;  // 0x240(0x10)
	struct FMulticastInlineDelegate CheckStateChangedBool;  // 0x250(0x10)

	void SetCheckedState(uint8_t  NewCheckedState); // Function WBP_Checkbox.WBP_Checkbox_C.SetCheckedState
	void SetIsChecked(bool bChecked); // Function WBP_Checkbox.WBP_Checkbox_C.SetIsChecked
	void IsChecked(bool& bChecked); // Function WBP_Checkbox.WBP_Checkbox_C.IsChecked
	void GetCheckedState(uint8_t & CheckedState); // Function WBP_Checkbox.WBP_Checkbox_C.GetCheckedState
	void BndEvt__CBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_Checkbox.WBP_Checkbox_C.BndEvt__CBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
	void ExecuteUbergraph_WBP_Checkbox(int32_t EntryPoint); // Function WBP_Checkbox.WBP_Checkbox_C.ExecuteUbergraph_WBP_Checkbox
	void CheckStateChangedBool__DelegateSignature(bool bChecked); // Function WBP_Checkbox.WBP_Checkbox_C.CheckStateChangedBool__DelegateSignature
	void CheckStateChanged__DelegateSignature(uint8_t  CheckedState); // Function WBP_Checkbox.WBP_Checkbox_C.CheckStateChanged__DelegateSignature
}; 



