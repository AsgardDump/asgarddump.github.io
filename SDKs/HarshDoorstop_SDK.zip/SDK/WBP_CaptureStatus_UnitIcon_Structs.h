#pragma once 
#include "SDK.h" 
 
 
// Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.ExecuteUbergraph_WBP_CaptureStatus_UnitIcon
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_CaptureStatus_UnitIcon
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FLinearColor K2Node_Select_Default;  // 0x8(0x10)

}; 
// Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.SetIsMultipleUnit
// Size: 0x118(Inherited: 0x0) 
struct FSetIsMultipleUnit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewUnitMultiple : 1;  // 0x0(0x1)
	char ECaptureUnitType Temp_byte_Variable;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FSlateBrush K2Node_Select_Default;  // 0x8(0x88)
	struct FSlateBrush K2Node_Select_Default_2;  // 0x90(0x88)

}; 
// Function WBP_CaptureStatus_UnitIcon.WBP_CaptureStatus_UnitIcon_C.SetUnitType
// Size: 0xA0(Inherited: 0x0) 
struct FSetUnitType
{
	char ECaptureUnitType NewUnitType;  // 0x0(0x1)
	char ECaptureUnitType Temp_byte_Variable;  // 0x1(0x1)
	char ECaptureUnitType Temp_byte_Variable_2;  // 0x2(0x1)
	char pad_3[5];  // 0x3(0x5)
	struct FSlateBrush K2Node_Select_Default;  // 0x8(0x88)
	struct FLinearColor K2Node_Select_Default_2;  // 0x90(0x10)

}; 
