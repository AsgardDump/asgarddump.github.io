#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.ExecuteUbergraph_WBP_DeployMenu_PlatoonSquadList
// Size: 0x6E(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_PlatoonSquadList
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsPlatoonValid_bValidPLTN : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsPlatoonValid_bValidPLTN_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x1C(0x4)
	struct UWBP_DeployMenu_SquadList_C* CallFunc_AddNewSquadItemWidget_SquadItemWidget;  // 0x20(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x28(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_HasReachedMaxSquadLimit_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct USquadListEntry* K2Node_Event_RemovedSquadData;  // 0x40(0x8)
	int32_t K2Node_Event_RemovedSquadIdx;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct USquadListEntry* K2Node_Event_SquadData;  // 0x50(0x8)
	struct UWBP_DeployMenu_SquadList_C* CallFunc_AddNewSquadItemWidget_SquadItemWidget_2;  // 0x58(0x8)
	int32_t Temp_int_Variable;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x6D(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.CollapseListIfEmpty
// Size: 0x1(Inherited: 0x0) 
struct FCollapseListIfEmpty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_HasAnySquads_bValidSquadsPresent : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.RemoveSquadItemWidgetFromList
// Size: 0x63(Inherited: 0x0) 
struct FRemoveSquadItemWidgetFromList
{
	struct USquadListEntry* RemovedSquadData;  // 0x0(0x8)
	int32_t RemoveIdx;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_RemoveChildAt_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x18(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UWBP_DeployMenu_SquadList_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Squad_List;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x42(0x1)
	char pad_67[1];  // 0x43(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_RemoveChildAt_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x50(0x8)
	struct UWBP_DeployMenu_SquadList_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Squad_List_2;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x62(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.DeconstructSquad
// Size: 0xC(Inherited: 0x10) 
struct FDeconstructSquad : public FDeconstructSquad
{
	struct USquadListEntry* RemovedSquadData;  // 0x0(0x8)
	int32_t RemovedSquadIdx;  // 0x8(0x4)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.IsPlatoonValid
// Size: 0x11(Inherited: 0x0) 
struct FIsPlatoonValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidPLTN : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AHDPlatoonState* CallFunc_GetPlatoonStateFromData_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.UpdateSquadCountText
// Size: 0xB0(Inherited: 0x0) 
struct FUpdateSquadCountText
{
	int32_t CallFunc_GetNumSquads_ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_GetMaxSquadLimit_ReturnValue;  // 0x4(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x48(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x88(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x98(0x18)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.GenerateSquad
// Size: 0x8(Inherited: 0x8) 
struct FGenerateSquad : public FGenerateSquad
{
	struct USquadListEntry* SquadData;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.UpdateCreateBtnAvailability
// Size: 0x2(Inherited: 0x0) 
struct FUpdateCreateBtnAvailability
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_HasReachedMaxSquadLimit_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.AddNewSquadItemWidget
// Size: 0x21(Inherited: 0x0) 
struct FAddNewSquadItemWidget
{
	struct USquadListEntry* SquadData;  // 0x0(0x8)
	struct UWBP_DeployMenu_SquadList_C* SquadItemWidget;  // 0x8(0x8)
	struct UWBP_DeployMenu_SquadList_C* CallFunc_Create_ReturnValue;  // 0x10(0x8)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.ExpandList
// Size: 0x3(Inherited: 0x0) 
struct FExpandList
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_HasAnySquads_bValidSquadsPresent : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.SetPlatoonNameText
// Size: 0x98(Inherited: 0x0) 
struct FSetPlatoonNameText
{
	struct FText NewPlatoonName;  // 0x0(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x18(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x30(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x70(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x80(0x18)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.HasAnySquads
// Size: 0x15(Inherited: 0x0) 
struct FHasAnySquads
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidSquadsPresent : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsPlatoonValid_bValidPLTN : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct AHDPlatoonState* CallFunc_GetPlatoonStateFromData_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_GetNumSquads_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function WBP_DeployMenu_PlatoonSquadList.WBP_DeployMenu_PlatoonSquadList_C.WasListCollapsedByUser
// Size: 0x1(Inherited: 0x0) 
struct FWasListCollapsedByUser
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCollapsedByUser : 1;  // 0x0(0x1)

}; 
