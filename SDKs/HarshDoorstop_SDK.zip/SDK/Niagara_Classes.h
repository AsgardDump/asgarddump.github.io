#pragma once 
#include <Niagara_Structs.h>
 
 
 
// Class Niagara.MovieSceneNiagaraColorParameterTrack
// Size: 0x90(Inherited: 0x90) 
struct UMovieSceneNiagaraColorParameterTrack : public UMovieSceneNiagaraParameterTrack
{

}; 



// Class Niagara.NiagaraPreviewAxis_InterpParamLinearColor
// Size: 0x58(Inherited: 0x38) 
struct UNiagaraPreviewAxis_InterpParamLinearColor : public UNiagaraPreviewAxis_InterpParamBase
{
	struct FLinearColor Min;  // 0x38(0x10)
	struct FLinearColor Max;  // 0x48(0x10)

}; 



// Class Niagara.NiagaraPreviewAxis
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraPreviewAxis : public UObject
{

	int32_t Num(); // Function Niagara.NiagaraPreviewAxis.Num
	void ApplyToPreview(struct UNiagaraComponent* PreviewComponent, int32_t PreviewIndex, bool bIsXAxis, struct FString& OutLabelText); // Function Niagara.NiagaraPreviewAxis.ApplyToPreview
}; 



// Class Niagara.NiagaraPrecompileContainer
// Size: 0x40(Inherited: 0x28) 
struct UNiagaraPrecompileContainer : public UObject
{
	struct TArray<struct UNiagaraScript*> Scripts;  // 0x28(0x10)
	struct UNiagaraSystem* System;  // 0x38(0x8)

}; 



// Class Niagara.NiagaraDataInterface
// Size: 0x30(Inherited: 0x28) 
struct UNiagaraDataInterface : public UNiagaraDataInterfaceBase
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class Niagara.NiagaraMeshRendererProperties
// Size: 0x728(Inherited: 0x50) 
struct UNiagaraMeshRendererProperties : public UNiagaraRendererProperties
{
	struct UStaticMesh* ParticleMesh;  // 0x50(0x8)
	uint8_t  SortMode;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	char bOverrideMaterials : 1;  // 0x5C(0x1)
	char bSortOnlyWhenTranslucent : 1;  // 0x5C(0x1)
	char pad_92_1 : 6;  // 0x5C(0x1)
	char pad_93[4];  // 0x5D(0x4)
	struct TArray<struct FNiagaraMeshMaterialOverride> OverrideMaterials;  // 0x60(0x10)
	struct FVector2D SubImageSize;  // 0x70(0x8)
	char bSubImageBlend : 1;  // 0x78(0x1)
	char pad_120_1 : 7;  // 0x78(0x1)
	char pad_121[4];  // 0x79(0x4)
	uint8_t  FacingMode;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	char bLockedAxisEnable : 1;  // 0x80(0x1)
	char pad_128_1 : 7;  // 0x80(0x1)
	char pad_129[4];  // 0x81(0x4)
	struct FVector LockedAxis;  // 0x84(0xC)
	uint8_t  LockedAxisSpace;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FNiagaraVariableAttributeBinding PositionBinding;  // 0x98(0x78)
	struct FNiagaraVariableAttributeBinding ColorBinding;  // 0x110(0x78)
	struct FNiagaraVariableAttributeBinding VelocityBinding;  // 0x188(0x78)
	struct FNiagaraVariableAttributeBinding MeshOrientationBinding;  // 0x200(0x78)
	struct FNiagaraVariableAttributeBinding ScaleBinding;  // 0x278(0x78)
	struct FNiagaraVariableAttributeBinding SubImageIndexBinding;  // 0x2F0(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding;  // 0x368(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding;  // 0x3E0(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding;  // 0x458(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding;  // 0x4D0(0x78)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding;  // 0x548(0x78)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding;  // 0x5C0(0x78)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding;  // 0x638(0x78)
	struct FNiagaraVariableAttributeBinding CameraOffsetBinding;  // 0x6B0(0x78)

}; 



// Class Niagara.NiagaraDataInterfaceVector2DCurve
// Size: 0x158(Inherited: 0x58) 
struct UNiagaraDataInterfaceVector2DCurve : public UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve XCurve;  // 0x58(0x80)
	struct FRichCurve YCurve;  // 0xD8(0x80)

}; 



// Class Niagara.NiagaraDataInterfaceSimpleCounter
// Size: 0x30(Inherited: 0x30) 
struct UNiagaraDataInterfaceSimpleCounter : public UNiagaraDataInterface
{

}; 



// Class Niagara.MovieSceneNiagaraTrack
// Size: 0x68(Inherited: 0x58) 
struct UMovieSceneNiagaraTrack : public UMovieSceneNameableTrack
{
	struct TArray<struct UMovieSceneSection*> Sections;  // 0x58(0x10)

}; 



// Class Niagara.NiagaraPreviewAxis_InterpParamInt32
// Size: 0x40(Inherited: 0x38) 
struct UNiagaraPreviewAxis_InterpParamInt32 : public UNiagaraPreviewAxis_InterpParamBase
{
	int32_t Min;  // 0x38(0x4)
	int32_t Max;  // 0x3C(0x4)

}; 



// Class Niagara.MovieSceneNiagaraSystemSpawnSection
// Size: 0xF0(Inherited: 0xE0) 
struct UMovieSceneNiagaraSystemSpawnSection : public UMovieSceneSection
{
	uint8_t  SectionStartBehavior;  // 0xE0(0x4)
	uint8_t  SectionEvaluateBehavior;  // 0xE4(0x4)
	uint8_t  SectionEndBehavior;  // 0xE8(0x4)
	uint8_t  AgeUpdateMode;  // 0xEC(0x1)
	char pad_237[3];  // 0xED(0x3)

}; 



// Class Niagara.MovieSceneNiagaraParameterTrack
// Size: 0x90(Inherited: 0x68) 
struct UMovieSceneNiagaraParameterTrack : public UMovieSceneNiagaraTrack
{
	struct FNiagaraVariable Parameter;  // 0x68(0x28)

}; 



// Class Niagara.NiagaraDataInterfaceCurlNoise
// Size: 0x40(Inherited: 0x30) 
struct UNiagaraDataInterfaceCurlNoise : public UNiagaraDataInterface
{
	uint32_t Seed;  // 0x30(0x4)
	char pad_52[12];  // 0x34(0xC)

}; 



// Class Niagara.NiagaraDataInterfaceGrid2DCollection
// Size: 0x140(Inherited: 0xF0) 
struct UNiagaraDataInterfaceGrid2DCollection : public UNiagaraDataInterfaceGrid2D
{
	char pad_240[80];  // 0xF0(0x50)

	void GetTextureSize(struct UNiagaraComponent* Component, int32_t& SizeX, int32_t& SizeY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetTextureSize
	void GetRawTextureSize(struct UNiagaraComponent* Component, int32_t& SizeX, int32_t& SizeY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.GetRawTextureSize
	bool FillTexture2D(struct UNiagaraComponent* Component, struct UTextureRenderTarget2D* Dest, int32_t AttributeIndex); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillTexture2D
	bool FillRawTexture2D(struct UNiagaraComponent* Component, struct UTextureRenderTarget2D* Dest, int32_t& TilesX, int32_t& TilesY); // Function Niagara.NiagaraDataInterfaceGrid2DCollection.FillRawTexture2D
}; 



// Class Niagara.NiagaraDataInterfaceCollisionQuery
// Size: 0x40(Inherited: 0x30) 
struct UNiagaraDataInterfaceCollisionQuery : public UNiagaraDataInterface
{
	char pad_48[16];  // 0x30(0x10)

}; 



// Class Niagara.MovieSceneNiagaraFloatParameterTrack
// Size: 0x90(Inherited: 0x90) 
struct UMovieSceneNiagaraFloatParameterTrack : public UMovieSceneNiagaraParameterTrack
{

}; 



// Class Niagara.MovieSceneNiagaraIntegerParameterTrack
// Size: 0x90(Inherited: 0x90) 
struct UMovieSceneNiagaraIntegerParameterTrack : public UMovieSceneNiagaraParameterTrack
{

}; 



// Class Niagara.MovieSceneNiagaraBoolParameterTrack
// Size: 0x90(Inherited: 0x90) 
struct UMovieSceneNiagaraBoolParameterTrack : public UMovieSceneNiagaraParameterTrack
{

}; 



// Class Niagara.MovieSceneNiagaraSystemTrack
// Size: 0x68(Inherited: 0x68) 
struct UMovieSceneNiagaraSystemTrack : public UMovieSceneNiagaraTrack
{

}; 



// Class Niagara.NiagaraEventReceiverEmitterAction
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraEventReceiverEmitterAction : public UObject
{

}; 



// Class Niagara.MovieSceneNiagaraVectorParameterTrack
// Size: 0x98(Inherited: 0x90) 
struct UMovieSceneNiagaraVectorParameterTrack : public UMovieSceneNiagaraParameterTrack
{
	int32_t ChannelsUsed;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)

}; 



// Class Niagara.NiagaraActor
// Size: 0x230(Inherited: 0x220) 
struct ANiagaraActor : public AActor
{
	struct UNiagaraComponent* NiagaraComponent;  // 0x220(0x8)
	char bDestroyOnSystemFinish : 1;  // 0x228(0x1)
	char pad_552_1 : 7;  // 0x228(0x1)
	char pad_553[8];  // 0x229(0x8)

	void SetDestroyOnSystemFinish(bool bShouldDestroyOnSystemFinish); // Function Niagara.NiagaraActor.SetDestroyOnSystemFinish
	void OnNiagaraSystemFinished(struct UNiagaraComponent* FinishedComponent); // Function Niagara.NiagaraActor.OnNiagaraSystemFinished
}; 



// Class Niagara.NiagaraPreviewBase
// Size: 0x220(Inherited: 0x220) 
struct ANiagaraPreviewBase : public AActor
{

	void SetSystem(struct UNiagaraSystem* InSystem); // Function Niagara.NiagaraPreviewBase.SetSystem
	void SetLabelText(struct FText& InXAxisText, struct FText& InYAxisText); // Function Niagara.NiagaraPreviewBase.SetLabelText
}; 



// Class Niagara.NiagaraComponent
// Size: 0x5C0(Inherited: 0x410) 
struct UNiagaraComponent : public UFXSystemComponent
{
	struct UNiagaraSystem* Asset;  // 0x408(0x8)
	uint8_t  TickBehavior;  // 0x410(0x1)
	struct FNiagaraUserRedirectionParameterStore OverrideParameters;  // 0x418(0x108)
	char bForceSolo : 1;  // 0x520(0x1)
	char pad_1313_1 : 7;  // 0x521(0x1)
	char pad_1314[43];  // 0x522(0x2B)
	char bAutoDestroy : 1;  // 0x54C(0x1)
	char bRenderingEnabled : 1;  // 0x54C(0x1)
	char bAutoManageAttachment : 1;  // 0x54C(0x1)
	char bAutoAttachWeldSimulatedBodies : 1;  // 0x54C(0x1)
	char pad_1356_1 : 4;  // 0x54C(0x1)
	char pad_1357[4];  // 0x54D(0x4)
	float MaxTimeBeforeForceUpdateTransform;  // 0x550(0x4)
	char pad_1364[4];  // 0x554(0x4)
	struct FMulticastInlineDelegate OnSystemFinished;  // 0x558(0x10)
	struct TWeakObjectPtr<USceneComponent> AutoAttachParent;  // 0x568(0x8)
	struct FName AutoAttachSocketName;  // 0x570(0x8)
	uint8_t  AutoAttachLocationRule;  // 0x578(0x1)
	uint8_t  AutoAttachRotationRule;  // 0x579(0x1)
	uint8_t  AutoAttachScaleRule;  // 0x57A(0x1)
	char pad_1403[69];  // 0x57B(0x45)

	void SetVariableVec4(struct FName InVariableName, struct FVector4& InValue); // Function Niagara.NiagaraComponent.SetVariableVec4
	void SetVariableVec3(struct FName InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetVariableVec3
	void SetVariableVec2(struct FName InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraComponent.SetVariableVec2
	void SetVariableQuat(struct FName InVariableName, struct FQuat& InValue); // Function Niagara.NiagaraComponent.SetVariableQuat
	void SetVariableObject(struct FName InVariableName, struct UObject* Object); // Function Niagara.NiagaraComponent.SetVariableObject
	void SetVariableMaterial(struct FName InVariableName, struct UMaterialInterface* Object); // Function Niagara.NiagaraComponent.SetVariableMaterial
	void SetVariableLinearColor(struct FName InVariableName, struct FLinearColor& InValue); // Function Niagara.NiagaraComponent.SetVariableLinearColor
	void SetVariableInt(struct FName InVariableName, int32_t InValue); // Function Niagara.NiagaraComponent.SetVariableInt
	void SetVariableFloat(struct FName InVariableName, float InValue); // Function Niagara.NiagaraComponent.SetVariableFloat
	void SetVariableBool(struct FName InVariableName, bool InValue); // Function Niagara.NiagaraComponent.SetVariableBool
	void SetVariableActor(struct FName InVariableName, struct AActor* Actor); // Function Niagara.NiagaraComponent.SetVariableActor
	void SetSeekDelta(float InSeekDelta); // Function Niagara.NiagaraComponent.SetSeekDelta
	void SetRenderingEnabled(bool bInRenderingEnabled); // Function Niagara.NiagaraComponent.SetRenderingEnabled
	void SetPreviewLODDistance(bool bEnablePreviewLODDistance, float PreviewLODDistance); // Function Niagara.NiagaraComponent.SetPreviewLODDistance
	void SetPaused(bool bInPaused); // Function Niagara.NiagaraComponent.SetPaused
	void SetNiagaraVariableVec4(struct FString InVariableName, struct FVector4& InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec4
	void SetNiagaraVariableVec3(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec3
	void SetNiagaraVariableVec2(struct FString InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableVec2
	void SetNiagaraVariableQuat(struct FString InVariableName, struct FQuat& InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableQuat
	void SetNiagaraVariableObject(struct FString InVariableName, struct UObject* Object); // Function Niagara.NiagaraComponent.SetNiagaraVariableObject
	void SetNiagaraVariableLinearColor(struct FString InVariableName, struct FLinearColor& InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableLinearColor
	void SetNiagaraVariableInt(struct FString InVariableName, int32_t InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableInt
	void SetNiagaraVariableFloat(struct FString InVariableName, float InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableFloat
	void SetNiagaraVariableBool(struct FString InVariableName, bool InValue); // Function Niagara.NiagaraComponent.SetNiagaraVariableBool
	void SetNiagaraVariableActor(struct FString InVariableName, struct AActor* Actor); // Function Niagara.NiagaraComponent.SetNiagaraVariableActor
	void SetMaxSimTime(float InMaxTime); // Function Niagara.NiagaraComponent.SetMaxSimTime
	void SetForceSolo(bool bInForceSolo); // Function Niagara.NiagaraComponent.SetForceSolo
	void SetDesiredAge(float InDesiredAge); // Function Niagara.NiagaraComponent.SetDesiredAge
	void SetCanRenderWhileSeeking(bool bInCanRenderWhileSeeking); // Function Niagara.NiagaraComponent.SetCanRenderWhileSeeking
	void SetAutoDestroy(bool bInAutoDestroy); // Function Niagara.NiagaraComponent.SetAutoDestroy
	void SetAsset(struct UNiagaraSystem* InAsset); // Function Niagara.NiagaraComponent.SetAsset
	void SetAllowScalability(bool bAllow); // Function Niagara.NiagaraComponent.SetAllowScalability
	void SetAgeUpdateMode(uint8_t  InAgeUpdateMode); // Function Niagara.NiagaraComponent.SetAgeUpdateMode
	void SeekToDesiredAge(float InDesiredAge); // Function Niagara.NiagaraComponent.SeekToDesiredAge
	void ResetSystem(); // Function Niagara.NiagaraComponent.ResetSystem
	void ReinitializeSystem(); // Function Niagara.NiagaraComponent.ReinitializeSystem
	bool IsPaused(); // Function Niagara.NiagaraComponent.IsPaused
	float GetSeekDelta(); // Function Niagara.NiagaraComponent.GetSeekDelta
	bool GetPreviewLODDistanceEnabled(); // Function Niagara.NiagaraComponent.GetPreviewLODDistanceEnabled
	int32_t GetPreviewLODDistance(); // Function Niagara.NiagaraComponent.GetPreviewLODDistance
	struct TArray<struct FVector> GetNiagaraParticleValueVec3_DebugOnly(struct FString InEmitterName, struct FString InValueName); // Function Niagara.NiagaraComponent.GetNiagaraParticleValueVec3_DebugOnly
	struct TArray<float> GetNiagaraParticleValues_DebugOnly(struct FString InEmitterName, struct FString InValueName); // Function Niagara.NiagaraComponent.GetNiagaraParticleValues_DebugOnly
	struct TArray<struct FVector> GetNiagaraParticlePositions_DebugOnly(struct FString InEmitterName); // Function Niagara.NiagaraComponent.GetNiagaraParticlePositions_DebugOnly
	float GetMaxSimTime(); // Function Niagara.NiagaraComponent.GetMaxSimTime
	bool GetForceSolo(); // Function Niagara.NiagaraComponent.GetForceSolo
	float GetDesiredAge(); // Function Niagara.NiagaraComponent.GetDesiredAge
	struct UNiagaraDataInterface* GetDataInterface(struct FString Name); // Function Niagara.NiagaraComponent.GetDataInterface
	struct UNiagaraSystem* GetAsset(); // Function Niagara.NiagaraComponent.GetAsset
	uint8_t  GetAgeUpdateMode(); // Function Niagara.NiagaraComponent.GetAgeUpdateMode
	void AdvanceSimulationByTime(float SimulateTime, float TickDeltaSeconds); // Function Niagara.NiagaraComponent.AdvanceSimulationByTime
	void AdvanceSimulation(int32_t TickCount, float TickDeltaSeconds); // Function Niagara.NiagaraComponent.AdvanceSimulation
}; 



// Class Niagara.NiagaraComponentPool
// Size: 0x80(Inherited: 0x28) 
struct UNiagaraComponentPool : public UObject
{
	struct TMap<struct UNiagaraSystem*, struct FNCPool> WorldParticleSystemPools;  // 0x28(0x50)
	char pad_120[8];  // 0x78(0x8)

}; 



// Class Niagara.NiagaraConvertInPlaceUtilityBase
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraConvertInPlaceUtilityBase : public UObject
{

}; 



// Class Niagara.NiagaraDataInterfaceAudioSubmix
// Size: 0x38(Inherited: 0x30) 
struct UNiagaraDataInterfaceAudioSubmix : public UNiagaraDataInterface
{
	struct USoundSubmix* Submix;  // 0x30(0x8)

}; 



// Class Niagara.NiagaraDataInterfaceAudioOscilloscope
// Size: 0x40(Inherited: 0x30) 
struct UNiagaraDataInterfaceAudioOscilloscope : public UNiagaraDataInterface
{
	struct USoundSubmix* Submix;  // 0x30(0x8)
	int32_t Resolution;  // 0x38(0x4)
	float ScopeInMilliseconds;  // 0x3C(0x4)

}; 



// Class Niagara.NiagaraParameterCollection
// Size: 0x58(Inherited: 0x28) 
struct UNiagaraParameterCollection : public UObject
{
	struct FName Namespace;  // 0x28(0x8)
	struct TArray<struct FNiagaraVariable> Parameters;  // 0x30(0x10)
	struct UNiagaraParameterCollectionInstance* DefaultInstance;  // 0x40(0x8)
	struct FGuid CompileId;  // 0x48(0x10)

}; 



// Class Niagara.NiagaraDataInterfaceVolumeTexture
// Size: 0x38(Inherited: 0x30) 
struct UNiagaraDataInterfaceVolumeTexture : public UNiagaraDataInterface
{
	struct UVolumeTexture* Texture;  // 0x30(0x8)

}; 



// Class Niagara.NiagaraDataInterfaceAudioSpectrum
// Size: 0x48(Inherited: 0x38) 
struct UNiagaraDataInterfaceAudioSpectrum : public UNiagaraDataInterfaceAudioSubmix
{
	int32_t Resolution;  // 0x38(0x4)
	float MinimumFrequency;  // 0x3C(0x4)
	float MaximumFrequency;  // 0x40(0x4)
	float NoiseFloorDb;  // 0x44(0x4)

}; 



// Class Niagara.NiagaraDataInterfaceStaticMesh
// Size: 0x60(Inherited: 0x30) 
struct UNiagaraDataInterfaceStaticMesh : public UNiagaraDataInterface
{
	struct UStaticMesh* DefaultMesh;  // 0x30(0x8)
	struct AActor* Source;  // 0x38(0x8)
	struct UStaticMeshComponent* SourceComponent;  // 0x40(0x8)
	struct FNDIStaticMeshSectionFilter SectionFilter;  // 0x48(0x10)
	char pad_88[8];  // 0x58(0x8)

}; 



// Class Niagara.NiagaraDataInterfaceCurve
// Size: 0xD8(Inherited: 0x58) 
struct UNiagaraDataInterfaceCurve : public UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve Curve;  // 0x58(0x80)

}; 



// Class Niagara.NiagaraDataInterfaceCamera
// Size: 0x38(Inherited: 0x30) 
struct UNiagaraDataInterfaceCamera : public UNiagaraDataInterface
{
	int32_t PlayerControllerIndex;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 



// Class Niagara.NiagaraDataInterfaceCurveBase
// Size: 0x58(Inherited: 0x30) 
struct UNiagaraDataInterfaceCurveBase : public UNiagaraDataInterface
{
	struct TArray<float> ShaderLUT;  // 0x30(0x10)
	float LUTMinTime;  // 0x40(0x4)
	float LUTMaxTime;  // 0x44(0x4)
	float LUTInvTimeRange;  // 0x48(0x4)
	float LUTNumSamplesMinusOne;  // 0x4C(0x4)
	char bUseLUT : 1;  // 0x50(0x1)
	char pad_80_1 : 7;  // 0x50(0x1)
	char pad_81[8];  // 0x51(0x8)

}; 



// Class Niagara.NiagaraPreviewAxis_InterpParamVector
// Size: 0x50(Inherited: 0x38) 
struct UNiagaraPreviewAxis_InterpParamVector : public UNiagaraPreviewAxis_InterpParamBase
{
	struct FVector Min;  // 0x38(0xC)
	struct FVector Max;  // 0x44(0xC)

}; 



// Class Niagara.NiagaraDataInterfaceColorCurve
// Size: 0x258(Inherited: 0x58) 
struct UNiagaraDataInterfaceColorCurve : public UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve RedCurve;  // 0x58(0x80)
	struct FRichCurve GreenCurve;  // 0xD8(0x80)
	struct FRichCurve BlueCurve;  // 0x158(0x80)
	struct FRichCurve AlphaCurve;  // 0x1D8(0x80)

}; 



// Class Niagara.NiagaraDataInterfaceOcclusion
// Size: 0x30(Inherited: 0x30) 
struct UNiagaraDataInterfaceOcclusion : public UNiagaraDataInterface
{

}; 



// Class Niagara.NiagaraDataInterfaceVectorField
// Size: 0x40(Inherited: 0x30) 
struct UNiagaraDataInterfaceVectorField : public UNiagaraDataInterface
{
	struct UVectorField* Field;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bTileX : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bTileY : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool bTileZ : 1;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)

}; 



// Class Niagara.NiagaraDataInterfaceSpline
// Size: 0x38(Inherited: 0x30) 
struct UNiagaraDataInterfaceSpline : public UNiagaraDataInterface
{
	struct AActor* Source;  // 0x30(0x8)

}; 



// Class Niagara.NiagaraDataInterfaceGrid3D
// Size: 0xF0(Inherited: 0xD0) 
struct UNiagaraDataInterfaceGrid3D : public UNiagaraDataInterfaceRWBase
{
	struct FIntVector NumVoxels;  // 0xD0(0xC)
	float VoxelSize;  // 0xDC(0x4)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool SetGridFromVoxelSize : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FVector WorldBBoxSize;  // 0xE4(0xC)

}; 



// Class Niagara.NiagaraParticleCallbackHandler
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraParticleCallbackHandler : public UInterface
{

	void ReceiveParticleData(struct TArray<struct FBasicParticleData>& Data, struct UNiagaraSystem* NiagaraSystem); // Function Niagara.NiagaraParticleCallbackHandler.ReceiveParticleData
}; 



// Class Niagara.NiagaraLightRendererProperties
// Size: 0x338(Inherited: 0x50) 
struct UNiagaraLightRendererProperties : public UNiagaraRendererProperties
{
	char bUseInverseSquaredFalloff : 1;  // 0x50(0x1)
	char bAffectsTranslucency : 1;  // 0x50(0x1)
	char bOverrideRenderingEnabled : 1;  // 0x50(0x1)
	char pad_80_1 : 5;  // 0x50(0x1)
	char pad_81[4];  // 0x51(0x4)
	float RadiusScale;  // 0x54(0x4)
	struct FVector ColorAdd;  // 0x58(0xC)
	char pad_100[4];  // 0x64(0x4)
	struct FNiagaraVariableAttributeBinding LightRenderingEnabledBinding;  // 0x68(0x78)
	struct FNiagaraVariableAttributeBinding LightExponentBinding;  // 0xE0(0x78)
	struct FNiagaraVariableAttributeBinding PositionBinding;  // 0x158(0x78)
	struct FNiagaraVariableAttributeBinding ColorBinding;  // 0x1D0(0x78)
	struct FNiagaraVariableAttributeBinding RadiusBinding;  // 0x248(0x78)
	struct FNiagaraVariableAttributeBinding VolumetricScatteringBinding;  // 0x2C0(0x78)

}; 



// Class Niagara.NiagaraDataInterfaceRWBase
// Size: 0xD0(Inherited: 0x30) 
struct UNiagaraDataInterfaceRWBase : public UNiagaraDataInterface
{
	struct TSet<int32_t> OutputShaderStages;  // 0x30(0x50)
	struct TSet<int32_t> IterationShaderStages;  // 0x80(0x50)

}; 



// Class Niagara.NiagaraDataInterfaceExport
// Size: 0x58(Inherited: 0x30) 
struct UNiagaraDataInterfaceExport : public UNiagaraDataInterface
{
	struct FNiagaraUserParameterBinding CallbackHandlerParameter;  // 0x30(0x28)

}; 



// Class Niagara.NiagaraDataInterfaceGrid2D
// Size: 0xF0(Inherited: 0xD0) 
struct UNiagaraDataInterfaceGrid2D : public UNiagaraDataInterfaceRWBase
{
	int32_t NumCellsX;  // 0xD0(0x4)
	int32_t NumCellsY;  // 0xD4(0x4)
	int32_t NumCellsMaxAxis;  // 0xD8(0x4)
	int32_t NumAttributes;  // 0xDC(0x4)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool SetGridFromMaxAxis : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	struct FVector2D WorldBBoxSize;  // 0xE4(0x8)
	char pad_236[4];  // 0xEC(0x4)

}; 



// Class Niagara.NiagaraDataInterfaceNeighborGrid3D
// Size: 0xF8(Inherited: 0xF0) 
struct UNiagaraDataInterfaceNeighborGrid3D : public UNiagaraDataInterfaceGrid3D
{
	uint32_t MaxNeighborsPerVoxel;  // 0xF0(0x4)
	char pad_244[4];  // 0xF4(0x4)

}; 



// Class Niagara.NiagaraDataInterfaceParticleRead
// Size: 0x40(Inherited: 0x30) 
struct UNiagaraDataInterfaceParticleRead : public UNiagaraDataInterface
{
	struct FString EmitterName;  // 0x30(0x10)

}; 



// Class Niagara.NiagaraDataInterfaceSkeletalMesh
// Size: 0xB8(Inherited: 0x30) 
struct UNiagaraDataInterfaceSkeletalMesh : public UNiagaraDataInterface
{
	struct AActor* Source;  // 0x30(0x8)
	struct FNiagaraUserParameterBinding MeshUserParameter;  // 0x38(0x28)
	struct USkeletalMeshComponent* SourceComponent;  // 0x60(0x8)
	uint8_t  SkinningMode;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct TArray<struct FName> SamplingRegions;  // 0x70(0x10)
	int32_t WholeMeshLOD;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct TArray<struct FName> FilteredBones;  // 0x88(0x10)
	struct TArray<struct FName> FilteredSockets;  // 0x98(0x10)
	struct FName ExcludeBoneName;  // 0xA8(0x8)
	char bExcludeBone : 1;  // 0xB0(0x1)
	char pad_176_1 : 7;  // 0xB0(0x1)
	char pad_177[8];  // 0xB1(0x8)

}; 



// Class Niagara.NiagaraDataInterfaceTexture
// Size: 0x38(Inherited: 0x30) 
struct UNiagaraDataInterfaceTexture : public UNiagaraDataInterface
{
	struct UTexture* Texture;  // 0x30(0x8)

}; 



// Class Niagara.NiagaraDataInterfaceVector4Curve
// Size: 0x258(Inherited: 0x58) 
struct UNiagaraDataInterfaceVector4Curve : public UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve XCurve;  // 0x58(0x80)
	struct FRichCurve YCurve;  // 0xD8(0x80)
	struct FRichCurve ZCurve;  // 0x158(0x80)
	struct FRichCurve WCurve;  // 0x1D8(0x80)

}; 



// Class Niagara.NiagaraFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraFunctionLibrary : public UBlueprintFunctionLibrary
{

	struct UNiagaraComponent* SpawnSystemAttached(struct UNiagaraSystem* SystemTemplate, struct USceneComponent* AttachToComponent, struct FName AttachPointName, struct FVector Location, struct FRotator Rotation, char EAttachLocation LocationType, bool bAutoDestroy, bool bAutoActivate, uint8_t  PoolingMethod, bool bPreCullCheck); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAttached
	struct UNiagaraComponent* SpawnSystemAtLocation(struct UObject* WorldContextObject, struct UNiagaraSystem* SystemTemplate, struct FVector Location, struct FRotator Rotation, struct FVector Scale, bool bAutoDestroy, bool bAutoActivate, uint8_t  PoolingMethod, bool bPreCullCheck); // Function Niagara.NiagaraFunctionLibrary.SpawnSystemAtLocation
	void SetVolumeTextureObject(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UVolumeTexture* Texture); // Function Niagara.NiagaraFunctionLibrary.SetVolumeTextureObject
	void SetTextureObject(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UTexture* Texture); // Function Niagara.NiagaraFunctionLibrary.SetTextureObject
	void OverrideSystemUserVariableStaticMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMeshComponent* StaticMeshComponent); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMeshComponent
	void OverrideSystemUserVariableStaticMesh(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct UStaticMesh* StaticMesh); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableStaticMesh
	void OverrideSystemUserVariableSkeletalMeshComponent(struct UNiagaraComponent* NiagaraSystem, struct FString OverrideName, struct USkeletalMeshComponent* SkeletalMeshComponent); // Function Niagara.NiagaraFunctionLibrary.OverrideSystemUserVariableSkeletalMeshComponent
	struct UNiagaraParameterCollectionInstance* GetNiagaraParameterCollection(struct UObject* WorldContextObject, struct UNiagaraParameterCollection* Collection); // Function Niagara.NiagaraFunctionLibrary.GetNiagaraParameterCollection
}; 



// Class Niagara.NiagaraDataInterfaceVectorCurve
// Size: 0x1D8(Inherited: 0x58) 
struct UNiagaraDataInterfaceVectorCurve : public UNiagaraDataInterfaceCurveBase
{
	struct FRichCurve XCurve;  // 0x58(0x80)
	struct FRichCurve YCurve;  // 0xD8(0x80)
	struct FRichCurve ZCurve;  // 0x158(0x80)

}; 



// Class Niagara.NiagaraEmitter
// Size: 0x2B0(Inherited: 0x28) 
struct UNiagaraEmitter : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bLocalSpace : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bDeterminism : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t RandomSeed;  // 0x2C(0x4)
	uint8_t  AllocationMode;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t PreAllocationCount;  // 0x34(0x4)
	struct FNiagaraEmitterScriptProperties UpdateScriptProps;  // 0x38(0x28)
	struct FNiagaraEmitterScriptProperties SpawnScriptProps;  // 0x60(0x28)
	struct FNiagaraEmitterScriptProperties EmitterSpawnScriptProps;  // 0x88(0x28)
	struct FNiagaraEmitterScriptProperties EmitterUpdateScriptProps;  // 0xB0(0x28)
	uint8_t  SimTarget;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	struct FBox FixedBounds;  // 0xDC(0x1C)
	int32_t MinDetailLevel;  // 0xF8(0x4)
	int32_t MaxDetailLevel;  // 0xFC(0x4)
	struct FNiagaraDetailsLevelScaleOverrides GlobalSpawnCountScaleOverrides;  // 0x100(0x14)
	char pad_276[4];  // 0x114(0x4)
	struct FNiagaraPlatformSet Platforms;  // 0x118(0x20)
	struct FNiagaraEmitterScalabilityOverrides ScalabilityOverrides;  // 0x138(0x10)
	char bInterpolatedSpawning : 1;  // 0x148(0x1)
	char bFixedBounds : 1;  // 0x148(0x1)
	char bUseMinDetailLevel : 1;  // 0x148(0x1)
	char bUseMaxDetailLevel : 1;  // 0x148(0x1)
	char bOverrideGlobalSpawnCountScale : 1;  // 0x148(0x1)
	char bRequiresPersistentIDs : 1;  // 0x148(0x1)
	char pad_328_1 : 2;  // 0x148(0x1)
	char pad_329[4];  // 0x149(0x4)
	float MaxDeltaTimePerTick;  // 0x14C(0x4)
	uint32_t DefaultShaderStageIndex;  // 0x150(0x4)
	uint32_t MaxUpdateIterations;  // 0x154(0x4)
	struct TSet<uint32_t> SpawnStages;  // 0x158(0x50)
	char bSimulationStagesEnabled : 1;  // 0x1A8(0x1)
	char bDeprecatedShaderStagesEnabled : 1;  // 0x1A8(0x1)
	char bLimitDeltaTime : 1;  // 0x1A8(0x1)
	char pad_424_1 : 5;  // 0x1A8(0x1)
	char pad_425[8];  // 0x1A9(0x8)
	struct FString UniqueEmitterName;  // 0x1B0(0x10)
	struct TArray<struct UNiagaraRendererProperties*> RendererProperties;  // 0x1C0(0x10)
	struct TArray<struct FNiagaraEventScriptProperties> EventHandlerScriptProps;  // 0x1D0(0x10)
	struct TArray<struct UNiagaraSimulationStageBase*> SimulationStages;  // 0x1E0(0x10)
	struct UNiagaraScript* GPUComputeScript;  // 0x1F0(0x8)
	struct TArray<struct FName> SharedEventGeneratorIds;  // 0x1F8(0x10)
	char pad_520[168];  // 0x208(0xA8)

}; 



// Class Niagara.NiagaraEditorDataBase
// Size: 0x28(Inherited: 0x28) 
struct UNiagaraEditorDataBase : public UObject
{

}; 



// Class Niagara.NiagaraEffectType
// Size: 0x100(Inherited: 0x28) 
struct UNiagaraEffectType : public UObject
{
	uint8_t  UpdateFrequency;  // 0x28(0x4)
	uint8_t  CullReaction;  // 0x2C(0x4)
	struct TArray<struct FNiagaraSystemScalabilitySettings> DetailLevelScalabilitySettings;  // 0x30(0x10)
	struct FNiagaraSystemScalabilitySettingsArray SystemScalabilitySettings;  // 0x40(0x10)
	struct FNiagaraEmitterScalabilitySettingsArray EmitterScalabilitySettings;  // 0x50(0x10)
	char pad_96[160];  // 0x60(0xA0)

}; 



// Class Niagara.NiagaraEventReceiverEmitterAction_SpawnParticles
// Size: 0x30(Inherited: 0x28) 
struct UNiagaraEventReceiverEmitterAction_SpawnParticles : public UNiagaraEventReceiverEmitterAction
{
	uint32_t NumParticles;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 



// Class Niagara.NiagaraRendererProperties
// Size: 0x50(Inherited: 0x28) 
struct UNiagaraRendererProperties : public UNiagaraMergeable
{
	int32_t SortOrderHint;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bIsEnabled : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool bMotionBlurEnabled : 1;  // 0x2D(0x1)
	char pad_46[34];  // 0x2E(0x22)

}; 



// Class Niagara.NiagaraParameterCollectionInstance
// Size: 0xF8(Inherited: 0x28) 
struct UNiagaraParameterCollectionInstance : public UObject
{
	struct UNiagaraParameterCollection* Collection;  // 0x28(0x8)
	struct TArray<struct FNiagaraVariable> OverridenParameters;  // 0x30(0x10)
	struct FNiagaraParameterStore ParameterStorage;  // 0x40(0xB8)

	void SetVectorParameter(struct FString InVariableName, struct FVector InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVectorParameter
	void SetVector4Parameter(struct FString InVariableName, struct FVector4& InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVector4Parameter
	void SetVector2DParameter(struct FString InVariableName, struct FVector2D InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetVector2DParameter
	void SetQuatParameter(struct FString InVariableName, struct FQuat& InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetQuatParameter
	void SetIntParameter(struct FString InVariableName, int32_t InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetIntParameter
	void SetFloatParameter(struct FString InVariableName, float InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetFloatParameter
	void SetColorParameter(struct FString InVariableName, struct FLinearColor InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetColorParameter
	void SetBoolParameter(struct FString InVariableName, bool InValue); // Function Niagara.NiagaraParameterCollectionInstance.SetBoolParameter
	struct FVector GetVectorParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVectorParameter
	struct FVector4 GetVector4Parameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVector4Parameter
	struct FVector2D GetVector2DParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetVector2DParameter
	struct FQuat GetQuatParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetQuatParameter
	int32_t GetIntParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetIntParameter
	float GetFloatParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetFloatParameter
	struct FLinearColor GetColorParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetColorParameter
	bool GetBoolParameter(struct FString InVariableName); // Function Niagara.NiagaraParameterCollectionInstance.GetBoolParameter
}; 



// Class Niagara.NiagaraPreviewAxis_InterpParamBase
// Size: 0x38(Inherited: 0x28) 
struct UNiagaraPreviewAxis_InterpParamBase : public UNiagaraPreviewAxis
{
	struct FName Param;  // 0x28(0x8)
	int32_t Count;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 



// Class Niagara.NiagaraPreviewAxis_InterpParamFloat
// Size: 0x40(Inherited: 0x38) 
struct UNiagaraPreviewAxis_InterpParamFloat : public UNiagaraPreviewAxis_InterpParamBase
{
	float Min;  // 0x38(0x4)
	float Max;  // 0x3C(0x4)

}; 



// Class Niagara.NiagaraPreviewAxis_InterpParamVector2D
// Size: 0x48(Inherited: 0x38) 
struct UNiagaraPreviewAxis_InterpParamVector2D : public UNiagaraPreviewAxis_InterpParamBase
{
	struct FVector2D Min;  // 0x38(0x8)
	struct FVector2D Max;  // 0x40(0x8)

}; 



// Class Niagara.NiagaraPreviewGrid
// Size: 0x270(Inherited: 0x220) 
struct ANiagaraPreviewGrid : public AActor
{
	struct UNiagaraSystem* System;  // 0x220(0x8)
	uint8_t  ResetMode;  // 0x228(0x1)
	char pad_553[7];  // 0x229(0x7)
	struct UNiagaraPreviewAxis* PreviewAxisX;  // 0x230(0x8)
	struct UNiagaraPreviewAxis* PreviewAxisY;  // 0x238(0x8)
	ANiagaraPreviewBase* PreviewClass;  // 0x240(0x8)
	float SpacingX;  // 0x248(0x4)
	float SpacingY;  // 0x24C(0x4)
	int32_t NumX;  // 0x250(0x4)
	int32_t NumY;  // 0x254(0x4)
	struct TArray<struct UChildActorComponent*> PreviewComponents;  // 0x258(0x10)
	char pad_616[8];  // 0x268(0x8)

	void SetPaused(bool bPaused); // Function Niagara.NiagaraPreviewGrid.SetPaused
	void GetPreviews(struct TArray<struct UNiagaraComponent*>& OutPreviews); // Function Niagara.NiagaraPreviewGrid.GetPreviews
	void DeactivatePreviews(); // Function Niagara.NiagaraPreviewGrid.DeactivatePreviews
	void ActivatePreviews(bool bReset); // Function Niagara.NiagaraPreviewGrid.ActivatePreviews
}; 



// Class Niagara.NiagaraPreviewAxis_InterpParamVector4
// Size: 0x60(Inherited: 0x38) 
struct UNiagaraPreviewAxis_InterpParamVector4 : public UNiagaraPreviewAxis_InterpParamBase
{
	char pad_56[8];  // 0x38(0x8)
	struct FVector4 Min;  // 0x40(0x10)
	struct FVector4 Max;  // 0x50(0x10)

}; 



// Class Niagara.NiagaraRibbonRendererProperties
// Size: 0x760(Inherited: 0x50) 
struct UNiagaraRibbonRendererProperties : public UNiagaraRendererProperties
{
	struct UMaterialInterface* Material;  // 0x50(0x8)
	struct FNiagaraUserParameterBinding MaterialUserParamBinding;  // 0x58(0x28)
	uint8_t  FacingMode;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	float UV0TilingDistance;  // 0x84(0x4)
	struct FVector2D UV0Scale;  // 0x88(0x8)
	struct FVector2D UV0Offset;  // 0x90(0x8)
	uint8_t  UV0AgeOffsetMode;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	float UV1TilingDistance;  // 0x9C(0x4)
	struct FVector2D UV1Scale;  // 0xA0(0x8)
	struct FVector2D UV1Offset;  // 0xA8(0x8)
	uint8_t  UV1AgeOffsetMode;  // 0xB0(0x1)
	uint8_t  DrawDirection;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	float CurveTension;  // 0xB4(0x4)
	uint8_t  TessellationMode;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t TessellationFactor;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool bUseConstantFactor : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	float TessellationAngle;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bScreenSpaceTessellation : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct FNiagaraVariableAttributeBinding PositionBinding;  // 0xD0(0x78)
	struct FNiagaraVariableAttributeBinding ColorBinding;  // 0x148(0x78)
	struct FNiagaraVariableAttributeBinding VelocityBinding;  // 0x1C0(0x78)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding;  // 0x238(0x78)
	struct FNiagaraVariableAttributeBinding RibbonTwistBinding;  // 0x2B0(0x78)
	struct FNiagaraVariableAttributeBinding RibbonWidthBinding;  // 0x328(0x78)
	struct FNiagaraVariableAttributeBinding RibbonFacingBinding;  // 0x3A0(0x78)
	struct FNiagaraVariableAttributeBinding RibbonIdBinding;  // 0x418(0x78)
	struct FNiagaraVariableAttributeBinding RibbonLinkOrderBinding;  // 0x490(0x78)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding;  // 0x508(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding;  // 0x580(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding;  // 0x5F8(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding;  // 0x670(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding;  // 0x6E8(0x78)

}; 



// Class Niagara.NiagaraScript
// Size: 0x520(Inherited: 0x28) 
struct UNiagaraScript : public UObject
{
	uint8_t  Usage;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t UsageIndex;  // 0x2C(0x4)
	struct FGuid UsageId;  // 0x30(0x10)
	struct FNiagaraParameterStore RapidIterationParameters;  // 0x40(0xB8)
	struct FNiagaraScriptExecutionParameterStore ScriptExecutionParamStore;  // 0xF8(0xD8)
	struct TArray<struct FNiagaraBoundParameter> ScriptExecutionBoundParameters;  // 0x1D0(0x10)
	struct FNiagaraVMExecutableDataId CachedScriptVMId;  // 0x1E0(0x48)
	char pad_552[432];  // 0x228(0x1B0)
	struct FNiagaraVMExecutableData CachedScriptVM;  // 0x3D8(0x128)
	struct TArray<struct UNiagaraParameterCollection*> CachedParameterCollectionReferences;  // 0x500(0x10)
	struct TArray<struct FNiagaraScriptDataInterfaceInfo> CachedDefaultDataInterfaces;  // 0x510(0x10)

	void RaiseOnGPUCompilationComplete(); // Function Niagara.NiagaraScript.RaiseOnGPUCompilationComplete
}; 



// Class Niagara.NiagaraScriptSourceBase
// Size: 0x48(Inherited: 0x28) 
struct UNiagaraScriptSourceBase : public UObject
{
	char pad_40[32];  // 0x28(0x20)

}; 



// Class Niagara.NiagaraSettings
// Size: 0x98(Inherited: 0x38) 
struct UNiagaraSettings : public UDeveloperSettings
{
	struct TArray<struct FSoftObjectPath> AdditionalParameterTypes;  // 0x38(0x10)
	struct TArray<struct FSoftObjectPath> AdditionalPayloadTypes;  // 0x48(0x10)
	struct TArray<struct FSoftObjectPath> AdditionalParameterEnums;  // 0x58(0x10)
	struct FSoftObjectPath DefaultEffectType;  // 0x68(0x18)
	struct TArray<struct FText> QualityLevels;  // 0x80(0x10)
	struct UNiagaraEffectType* DefaultEffectTypePtr;  // 0x90(0x8)

}; 



// Class Niagara.NiagaraSimulationStageBase
// Size: 0x38(Inherited: 0x28) 
struct UNiagaraSimulationStageBase : public UNiagaraMergeable
{
	struct UNiagaraScript* Script;  // 0x28(0x8)
	struct FName SimulationStageName;  // 0x30(0x8)

}; 



// Class Niagara.NiagaraSimulationStageGeneric
// Size: 0x70(Inherited: 0x38) 
struct UNiagaraSimulationStageGeneric : public UNiagaraSimulationStageBase
{
	uint8_t  IterationSource;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t Iterations;  // 0x3C(0x4)
	char bSpawnOnly : 1;  // 0x40(0x1)
	char pad_64_1 : 7;  // 0x40(0x1)
	char pad_65[8];  // 0x41(0x8)
	struct FNiagaraVariableDataInterfaceBinding DataInterface;  // 0x48(0x28)

}; 



// Class Niagara.NiagaraSpriteRendererProperties
// Size: 0x8B0(Inherited: 0x50) 
struct UNiagaraSpriteRendererProperties : public UNiagaraRendererProperties
{
	struct UMaterialInterface* Material;  // 0x50(0x8)
	struct FNiagaraUserParameterBinding MaterialUserParamBinding;  // 0x58(0x28)
	uint8_t  Alignment;  // 0x80(0x1)
	uint8_t  FacingMode;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FVector2D PivotInUVSpace;  // 0x84(0x8)
	uint8_t  SortMode;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct FVector2D SubImageSize;  // 0x90(0x8)
	char bSubImageBlend : 1;  // 0x98(0x1)
	char bRemoveHMDRollInVR : 1;  // 0x98(0x1)
	char bSortOnlyWhenTranslucent : 1;  // 0x98(0x1)
	char pad_152_1 : 5;  // 0x98(0x1)
	char pad_153[4];  // 0x99(0x4)
	float MinFacingCameraBlendDistance;  // 0x9C(0x4)
	float MaxFacingCameraBlendDistance;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FNiagaraVariableAttributeBinding PositionBinding;  // 0xA8(0x78)
	struct FNiagaraVariableAttributeBinding ColorBinding;  // 0x120(0x78)
	struct FNiagaraVariableAttributeBinding VelocityBinding;  // 0x198(0x78)
	struct FNiagaraVariableAttributeBinding SpriteRotationBinding;  // 0x210(0x78)
	struct FNiagaraVariableAttributeBinding SpriteSizeBinding;  // 0x288(0x78)
	struct FNiagaraVariableAttributeBinding SpriteFacingBinding;  // 0x300(0x78)
	struct FNiagaraVariableAttributeBinding SpriteAlignmentBinding;  // 0x378(0x78)
	struct FNiagaraVariableAttributeBinding SubImageIndexBinding;  // 0x3F0(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterialBinding;  // 0x468(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial1Binding;  // 0x4E0(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial2Binding;  // 0x558(0x78)
	struct FNiagaraVariableAttributeBinding DynamicMaterial3Binding;  // 0x5D0(0x78)
	struct FNiagaraVariableAttributeBinding CameraOffsetBinding;  // 0x648(0x78)
	struct FNiagaraVariableAttributeBinding UVScaleBinding;  // 0x6C0(0x78)
	struct FNiagaraVariableAttributeBinding MaterialRandomBinding;  // 0x738(0x78)
	struct FNiagaraVariableAttributeBinding CustomSortingBinding;  // 0x7B0(0x78)
	struct FNiagaraVariableAttributeBinding NormalizedAgeBinding;  // 0x828(0x78)
	char pad_2208[16];  // 0x8A0(0x10)

}; 



// Class Niagara.NiagaraSystem
// Size: 0x478(Inherited: 0x30) 
struct UNiagaraSystem : public UFXSystemAsset
{
	char pad_48[1];  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bDumpDebugSystemInfo : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool bDumpDebugEmitterInfo : 1;  // 0x32(0x1)
	char pad_51[1];  // 0x33(0x1)
	char bFixedBounds : 1;  // 0x34(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	char pad_53[4];  // 0x35(0x4)
	struct UNiagaraEffectType* EffectType;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bOverrideScalabilitySettings : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TArray<struct FNiagaraSystemScalabilityOverride> ScalabilityOverrides;  // 0x48(0x10)
	struct FNiagaraSystemScalabilityOverrides SystemScalabilityOverrides;  // 0x58(0x10)
	struct TArray<struct FNiagaraEmitterHandle> EmitterHandles;  // 0x68(0x10)
	struct TArray<struct UNiagaraParameterCollectionInstance*> ParameterCollectionOverrides;  // 0x78(0x10)
	struct UNiagaraScript* SystemSpawnScript;  // 0x88(0x8)
	struct UNiagaraScript* SystemUpdateScript;  // 0x90(0x8)
	char pad_152[16];  // 0x98(0x10)
	struct FNiagaraSystemCompiledData SystemCompiledData;  // 0xA8(0x258)
	struct FNiagaraUserRedirectionParameterStore ExposedParameters;  // 0x300(0x108)
	struct FBox FixedBounds;  // 0x408(0x1C)
	char pad_1060_1 : 7;  // 0x424(0x1)
	bool bAutoDeactivate : 1;  // 0x424(0x1)
	char pad_1061[3];  // 0x425(0x3)
	float WarmupTime;  // 0x428(0x4)
	int32_t WarmupTickCount;  // 0x42C(0x4)
	float WarmupTickDelta;  // 0x430(0x4)
	char pad_1076_1 : 7;  // 0x434(0x1)
	bool bHasSystemScriptDIsWithPerInstanceData : 1;  // 0x434(0x1)
	char pad_1077[3];  // 0x435(0x3)
	struct TArray<struct FName> UserDINamesReadInSystemScripts;  // 0x438(0x10)
	char pad_1096[48];  // 0x448(0x30)

}; 



