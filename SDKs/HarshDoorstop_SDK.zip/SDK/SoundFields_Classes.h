#pragma once 
#include <SoundFields_Structs.h>
 
 
 
// Class SoundFields.AmbisonicsEncodingSettings
// Size: 0x30(Inherited: 0x28) 
struct UAmbisonicsEncodingSettings : public USoundfieldEncodingSettingsBase
{
	int32_t AmbisonicsOrder;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 



