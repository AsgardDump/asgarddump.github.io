#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.UpdateDirection
// Size: 0x50(Inherited: 0x0) 
struct FUpdateDirection
{
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x10(0x8)
	struct AHDPlayerCharacter* K2Node_DynamicCast_AsHDPlayer_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x24(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x30(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x34(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x38(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x40(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x44(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x48(0x8)

}; 
// Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.ExecuteUbergraph_WBP_HUDElement_Compass
// Size: 0x5C(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUDElement_Compass
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x8(0x38)
	float K2Node_Event_InDeltaTime;  // 0x40(0x4)
	struct FVector2D CallFunc_GetAbs2D_ReturnValue;  // 0x44(0x8)
	float CallFunc_BreakVector2D_X;  // 0x4C(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x50(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x54(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x58(0x4)

}; 
// Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_HUDElement_Compass.WBP_HUDElement_Compass_C.SetWidgetCanvasSlotSize
// Size: 0x18(Inherited: 0x0) 
struct FSetWidgetCanvasSlotSize
{
	struct UWidget* Widget;  // 0x0(0x8)
	struct FVector2D NewLayoutSize;  // 0x8(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x10(0x8)

}; 
