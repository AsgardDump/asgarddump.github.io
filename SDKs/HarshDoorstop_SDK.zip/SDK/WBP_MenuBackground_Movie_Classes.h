#pragma once 
#include <WBP_MenuBackground_Movie_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C
// Size: 0x2F0(Inherited: 0x230) 
struct UWBP_MenuBackground_Movie_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* BgFilterImg;  // 0x238(0x8)
	struct UImage* BgMovieImg;  // 0x240(0x8)
	struct UMediaPlayer* MoviePlayer;  // 0x248(0x8)
	struct UMediaPlaylist* MoviePlaylist;  // 0x250(0x8)
	struct FSlateBrush FilterImgBrush;  // 0x258(0x88)
	struct FLinearColor FilterImgColor;  // 0x2E0(0x10)

	void OnInitialized(); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.OnInitialized
	void PreConstruct(bool IsDesignTime); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.PreConstruct
	void Destruct(); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.Destruct
	void ExecuteUbergraph_WBP_MenuBackground_Movie(int32_t EntryPoint); // Function WBP_MenuBackground_Movie.WBP_MenuBackground_Movie_C.ExecuteUbergraph_WBP_MenuBackground_Movie
}; 



