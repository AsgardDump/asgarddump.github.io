#pragma once 
#include <RCON_Structs.h>
 
 
 
// Class RCON.RCONServerSystem
// Size: 0x70(Inherited: 0x28) 
struct URCONServerSystem : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEnabled : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString ListenAddress;  // 0x30(0x10)
	uint16_t ListenPort;  // 0x40(0x2)
	char pad_66[6];  // 0x42(0x6)
	struct FString Password;  // 0x48(0x10)
	uint32_t MaxActiveConnections;  // 0x58(0x4)
	uint32_t MaxAuthAttempts;  // 0x5C(0x4)
	char pad_96[16];  // 0x60(0x10)

	void Shutdown(); // Function RCON.RCONServerSystem.Shutdown
	void Init(); // Function RCON.RCONServerSystem.Init
}; 



