#pragma once 
#include <WBP_DeployMenu_SquadSelectionPanel_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C
// Size: 0x274(Inherited: 0x250) 
struct UWBP_DeployMenu_SquadSelectionPanel_C : public UDeployMenu_SquadSelectionWidgetBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x250(0x8)
	struct UScrollBox* PlatoonsList;  // 0x258(0x8)
	int32_t NumFakePlatoonItems;  // 0x260(0x4)
	struct FMargin PlatoonItemPadding;  // 0x264(0x10)

	void RemovePlatoonItemWidgetFromList(struct UPlatoonListEntry* RemovedPlatoonData, int32_t RemoveIdx); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.RemovePlatoonItemWidgetFromList
	void AddNewPlatoonItemWidget(struct UPlatoonListEntry* PlatoonData); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.AddNewPlatoonItemWidget
	void GeneratePlatoon(struct UPlatoonListEntry* PlatoonData); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.GeneratePlatoon
	void DeconstructPlatoon(struct UPlatoonListEntry* RemovedPlatoonData, int32_t RemovedPlatoonIdx); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.DeconstructPlatoon
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.PreConstruct
	void ExecuteUbergraph_WBP_DeployMenu_SquadSelectionPanel(int32_t EntryPoint); // Function WBP_DeployMenu_SquadSelectionPanel.WBP_DeployMenu_SquadSelectionPanel_C.ExecuteUbergraph_WBP_DeployMenu_SquadSelectionPanel
}; 



