#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.ExecuteUbergraph_WBP_DeployMenu_SquadList
// Size: 0xB1(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DeployMenu_SquadList
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USquadMemberInfo* K2Node_Event_MemberData;  // 0x8(0x8)
	struct USquadMemberInfo* K2Node_Event_RemovedMemberData;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_WasListCollapsedByUser_bCollapsedByUser : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_LeaveCurrentSquad_bLeaveSuccess : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_IsOwningPlayerRegisteredSquadMember_bRegisteredMember : 1;  // 0x4B(0x1)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsSquadValid_bValidSQ : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool CallFunc_IsSquadValid_bValidSQ_2 : 1;  // 0x4D(0x1)
	char pad_78_1 : 7;  // 0x4E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x4E(0x1)
	char pad_79_1 : 7;  // 0x4F(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4F(0x1)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FText K2Node_Event_NewSquadName;  // 0x58(0x18)
	struct FText K2Node_Event_PreviousSquadName;  // 0x70(0x18)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct AHDPlayerState* K2Node_Event_NewLeaderPS;  // 0x90(0x8)
	struct AHDPlayerState* K2Node_Event_PrevLeaderPS;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_Event_bNewLockedState : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	int32_t Temp_int_Variable;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_JoinSquad_bJoinSuccess : 1;  // 0xB0(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadNameUpdated
// Size: 0x30(Inherited: 0x30) 
struct FOnSquadNameUpdated : public FOnSquadNameUpdated
{
	struct FText NewSquadName;  // 0x0(0x18)
	struct FText PreviousSquadName;  // 0x18(0x18)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadLeaderUpdated
// Size: 0x10(Inherited: 0x10) 
struct FOnSquadLeaderUpdated : public FOnSquadLeaderUpdated
{
	struct AHDPlayerState* NewLeaderPS;  // 0x0(0x8)
	struct AHDPlayerState* PrevLeaderPS;  // 0x8(0x8)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.GenerateSquadMember
// Size: 0x8(Inherited: 0x8) 
struct FGenerateSquadMember : public FGenerateSquadMember
{
	struct USquadMemberInfo* MemberData;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnSquadLockStateUpdated
// Size: 0x1(Inherited: 0x1) 
struct FOnSquadLockStateUpdated : public FOnSquadLockStateUpdated
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bNewLockedState : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.DeconstructSquadMember
// Size: 0x8(Inherited: 0x8) 
struct FDeconstructSquadMember : public FDeconstructSquadMember
{
	struct USquadMemberInfo* RemovedMemberData;  // 0x0(0x8)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.ExpandList
// Size: 0x4(Inherited: 0x0) 
struct FExpandList
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bExpandParent : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasAnySquadMembers_bValidMembersPresent : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.CollapseList
// Size: 0x1(Inherited: 0x0) 
struct FCollapseList
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCollapseParent : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsSquadValid
// Size: 0x11(Inherited: 0x0) 
struct FIsSquadValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidSQ : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AHDSquadState* CallFunc_GetSquadStateFromData_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerInMemberWidgetList
// Size: 0x4D(Inherited: 0x0) 
struct FIsOwningPlayerInMemberWidgetList
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bOwnsMemberWidget : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x20(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UWBP_DeployMenu_SquadMemberListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Squad_Member_Listing;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4B(0x1)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x4C(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.AddNewSquadMemberItemWidget
// Size: 0x2A(Inherited: 0x0) 
struct FAddNewSquadMemberItemWidget
{
	struct USquadMemberInfo* MemberData;  // 0x0(0x8)
	struct UWBP_DeployMenu_SquadMemberListing_C* CallFunc_Create_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct UVerticalBoxSlot* CallFunc_AddChildToVerticalBox_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestPrereqsForAllMembers
// Size: 0x41(Inherited: 0x0) 
struct FTestPrereqsForAllMembers
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UWBP_DeployMenu_SquadMemberListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Squad_Member_Listing;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.RemoveSquadMemberItemWidgetFromList
// Size: 0x91(Inherited: 0x0) 
struct FRemoveSquadMemberItemWidgetFromList
{
	struct USquadMemberInfo* RemovedMemberData;  // 0x0(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_RemoveChildAt_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x28(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x38(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UWBP_DeployMenu_SquadMemberListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Squad_Member_Listing;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x5B(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x5C(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue_2;  // 0x60(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct UWidget* CallFunc_Array_Get_Item_2;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UWBP_DeployMenu_SquadMemberListing_C* K2Node_DynamicCast_AsWBP_Deploy_Menu_Squad_Member_Listing_2;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x90(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerRegisteredSquadLeader
// Size: 0x1C(Inherited: 0x0) 
struct FIsOwningPlayerRegisteredSquadLeader
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSquadLeader : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsPlayerRegisteredSquadMember_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1B(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetSquadNameText
// Size: 0x98(Inherited: 0x0) 
struct FSetSquadNameText
{
	struct FText NewSquadName;  // 0x0(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x18(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x30(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x70(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x80(0x18)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.CollapseListIfEmpty
// Size: 0x2(Inherited: 0x0) 
struct FCollapseListIfEmpty
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCollapseParentIfEmpty : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasAnySquadMembers_bValidMembersPresent : 1;  // 0x1(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.OnPaint
// Size: 0x30(Inherited: 0x30) 
struct FOnPaint : public FOnPaint
{
	struct FPaintContext Context;  // 0x0(0x30)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateSquadMemberCountText
// Size: 0xB0(Inherited: 0x0) 
struct FUpdateSquadMemberCountText
{
	int32_t CallFunc_GetNumSquadMembers_ReturnValue;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x8(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x48(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x88(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x98(0x18)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateJoinLeaveBtnState
// Size: 0x5D(Inherited: 0x0) 
struct FUpdateJoinLeaveBtnState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	struct FText Temp_text_Variable_2;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsOwningPlayerRegisteredSquadMember_bRegisteredMember : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FText K2Node_Select_Default;  // 0x40(0x18)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_HasReachedMaxSquadMemberLimit_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5B(0x1)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x5C(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.IsOwningPlayerRegisteredSquadMember
// Size: 0x1A(Inherited: 0x0) 
struct FIsOwningPlayerRegisteredSquadMember
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIgnorePendingRemoval : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bRegisteredMember : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsPlayerRegisteredSquadMember_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.TestSQPrereqs
// Size: 0x42(Inherited: 0x0) 
struct FTestSQPrereqs
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UDFContextualWidgetBase* K2Node_DynamicCast_AsDFContextual_Widget_Base;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_TestPrerequisites_ReturnValue : 1;  // 0x41(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetupSQOptions
// Size: 0x52(Inherited: 0x0) 
struct FSetupSQOptions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNoVisibleWidgets : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	uint8_t  Temp_byte_Variable_2;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TArray<struct UWidget*> CallFunc_GetAllChildren_ReturnValue;  // 0x18(0x10)
	struct UWidget* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UWBP_SQOption_C* K2Node_DynamicCast_AsWBP_SQOption;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x43(0x1)
	char pad_68[4];  // 0x44(0x4)
	struct UHorizontalBoxSlot* CallFunc_SlotAsHorizontalBoxSlot_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool Temp_bool_Variable : 1;  // 0x50(0x1)
	uint8_t  K2Node_Select_Default;  // 0x51(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.UpdateLockUnlockBtnState
// Size: 0x58(Inherited: 0x0) 
struct FUpdateLockUnlockBtnState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	struct FText Temp_text_Variable_2;  // 0x20(0x18)
	struct AHDSquadState* CallFunc_GetSquadStateFromData_ReturnValue;  // 0x38(0x8)
	struct FText K2Node_Select_Default;  // 0x40(0x18)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.HasAnySquadMembers
// Size: 0x15(Inherited: 0x0) 
struct FHasAnySquadMembers
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidMembersPresent : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsSquadValid_bValidSQ : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct AHDSquadState* CallFunc_GetSquadStateFromData_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_GetNumSquadMembers_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x14(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.WasListCollapsedByUser
// Size: 0x1(Inherited: 0x0) 
struct FWasListCollapsedByUser
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCollapsedByUser : 1;  // 0x0(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.KickSquadMember
// Size: 0x34(Inherited: 0x0) 
struct FKickSquadMember
{
	struct AHDPlayerState* MemberPSToKick;  // 0x0(0x8)
	struct AHDSquadState* CallFunc_GetSquadStateFromData_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsOwningPlayerRegisteredSquadLeader_bSquadLeader : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	struct AHDSquadState* CallFunc_GetSquadStateFromData_ReturnValue_2;  // 0x20(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsRegisteredSquadMember_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool CallFunc_KickSquadMember_bRemoveSuccess : 1;  // 0x33(0x1)

}; 
// Function WBP_DeployMenu_SquadList.WBP_DeployMenu_SquadList_C.SetSquadLockedState
// Size: 0x33(Inherited: 0x0) 
struct FSetSquadLockedState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewLocked : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AHDSquadState* CallFunc_GetSquadStateFromData_ReturnValue;  // 0x8(0x8)
	struct AHDSquadState* CallFunc_GetSquadStateFromData_ReturnValue_2;  // 0x10(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsOwningPlayerRegisteredSquadLeader_bSquadLeader : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x32(0x1)

}; 
