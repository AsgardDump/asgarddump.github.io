#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveEquippedItemChanged
// Size: 0x10(Inherited: 0x10) 
struct FReceiveEquippedItemChanged : public FReceiveEquippedItemChanged
{
	struct ADFBaseItem* NewEquippedItem;  // 0x0(0x8)
	struct ADFBaseItem* PrevEquippedItem;  // 0x8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidTeamState
// Size: 0x23(Inherited: 0x0) 
struct FGetMostValidTeamState
{
	struct ADFTeamState* TeamState;  // 0x0(0x8)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x22(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.K2_OnMovementModeChanged
// Size: 0x4(Inherited: 0x4) 
struct FK2_OnMovementModeChanged : public FK2_OnMovementModeChanged
{
	char EMovementMode PrevMovementMode;  // 0x0(0x1)
	char EMovementMode NewMovementMode;  // 0x1(0x1)
	char PrevCustomMode;  // 0x2(0x1)
	char NewCustomMode;  // 0x3(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveHealthChanged
// Size: 0x8(Inherited: 0x8) 
struct FReceiveHealthChanged : public FReceiveHealthChanged
{
	float NewHealthTotal;  // 0x0(0x4)
	float PrevHealthTotal;  // 0x4(0x4)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnSuppression__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSuppression__DelegateSignature
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateEquipmentItems
// Size: 0x59(Inherited: 0x0) 
struct FUpdateEquipmentItems
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AHDBaseWeapon* K2Node_DynamicCast_AsHDBase_Weapon;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x18(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x20(0x10)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x40(0x8)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x48(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x58(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidTeamFactionInfo
// Size: 0x12(Inherited: 0x0) 
struct FGetMostValidTeamFactionInfo
{
	UDFFactionInfo* FactionInfoClass;  // 0x0(0x8)
	struct ADFTeamState* CallFunc_GetMostValidTeamState_TeamState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x11(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.PlayerNameChanged
// Size: 0x18(Inherited: 0x0) 
struct FPlayerNameChanged
{
	struct APlayerState* PS;  // 0x0(0x8)
	struct FString NewPlayerName;  // 0x8(0x10)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SuppressionEffect
// Size: 0x18(Inherited: 0x0) 
struct FSuppressionEffect
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)
	struct UPrimitiveComponent* SuppressionVolume;  // 0x10(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnHitDamage__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnHitDamage__DelegateSignature
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectSpot
// Size: 0x3(Inherited: 0x0) 
struct FRadialMenuCanSelectSpot
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelectable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_CanSelectAnyRadialMenuOption_bSelectable : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ExecuteUbergraph_BP_HDPlayerCharacterBase
// Size: 0x232A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDPlayerCharacterBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputActionEvent_Key_10;  // 0x8(0x18)
	float CallFunc_GetTimeRange_MinTime;  // 0x20(0x4)
	float CallFunc_GetTimeRange_MaxTime;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	struct FLinearColor CallFunc_GetVectorParameterValue_ReturnValue;  // 0x2C(0x10)
	float CallFunc_BreakColor_R;  // 0x3C(0x4)
	float CallFunc_BreakColor_G;  // 0x40(0x4)
	float CallFunc_BreakColor_B;  // 0x44(0x4)
	float CallFunc_BreakColor_A;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x50(0xC)
	struct FLinearColor CallFunc_GetVectorParameterValue_ReturnValue_2;  // 0x5C(0x10)
	struct FLinearColor CallFunc_GetVectorParameterValue_ReturnValue_3;  // 0x6C(0x10)
	struct FLinearColor CallFunc_GetVectorParameterValue_ReturnValue_4;  // 0x7C(0x10)
	struct FLinearColor CallFunc_GetVectorParameterValue_ReturnValue_5;  // 0x8C(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xA4(0x4)
	float CallFunc_GetTimeRange_MinTime_2;  // 0xA8(0x4)
	float CallFunc_GetTimeRange_MaxTime_2;  // 0xAC(0x4)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables;  // 0xB0(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0xC0(0x4)
	char pad_196[12];  // 0xC4(0xC)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings;  // 0xD0(0x540)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x610(0x4)
	char pad_1556_1 : 7;  // 0x614(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x614(0x1)
	char pad_1557[3];  // 0x615(0x3)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables_2;  // 0x618(0x10)
	char pad_1576[8];  // 0x628(0x8)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings_2;  // 0x630(0x540)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables_3;  // 0xB70(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0xB80(0x4)
	char pad_2948[12];  // 0xB84(0xC)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings_3;  // 0xB90(0x540)
	int32_t CallFunc_Array_Find_ReturnValue_2;  // 0x10D0(0x4)
	char pad_4308_1 : 7;  // 0x10D4(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_2 : 1;  // 0x10D4(0x1)
	char pad_4309_1 : 7;  // 0x10D5(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x10D5(0x1)
	char pad_4310[2];  // 0x10D6(0x2)
	float CallFunc_GetTimelineLength_ReturnValue;  // 0x10D8(0x4)
	char pad_4316[4];  // 0x10DC(0x4)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables_4;  // 0x10E0(0x10)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings_4;  // 0x10F0(0x540)
	char pad_5680_1 : 7;  // 0x1630(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue_2 : 1;  // 0x1630(0x1)
	char pad_5681[3];  // 0x1631(0x3)
	float K2Node_Event_DeltaSeconds_2;  // 0x1634(0x4)
	float K2Node_Event_KillingDamage;  // 0x1638(0x4)
	char pad_5692[4];  // 0x163C(0x4)
	struct FDamageEvent K2Node_Event_DamageEvent_2;  // 0x1640(0x10)
	struct APawn* K2Node_Event_InstigatingPawn;  // 0x1650(0x8)
	struct AActor* K2Node_Event_DamageCauser_3;  // 0x1658(0x8)
	struct FKey K2Node_InputActionEvent_Key_11;  // 0x1660(0x18)
	struct FKey K2Node_InputActionEvent_Key_12;  // 0x1678(0x18)
	char pad_5776_1 : 7;  // 0x1690(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue_2 : 1;  // 0x1690(0x1)
	char pad_5777_1 : 7;  // 0x1691(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue_3 : 1;  // 0x1691(0x1)
	char pad_5778[6];  // 0x1692(0x6)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x1698(0x8)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x16A0(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x16A8(0x8)
	char pad_5808_1 : 7;  // 0x16B0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x16B0(0x1)
	char pad_5809[7];  // 0x16B1(0x7)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller_2;  // 0x16B8(0x8)
	char pad_5824_1 : 7;  // 0x16C0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x16C0(0x1)
	char pad_5825[7];  // 0x16C1(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x16C8(0x8)
	struct AHUD* CallFunc_GetHUD_ReturnValue_2;  // 0x16D0(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase;  // 0x16D8(0x8)
	char pad_5856_1 : 7;  // 0x16E0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x16E0(0x1)
	char pad_5857[7];  // 0x16E1(0x7)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase_2;  // 0x16E8(0x8)
	char pad_5872_1 : 7;  // 0x16F0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x16F0(0x1)
	char pad_5873_1 : 7;  // 0x16F1(0x1)
	bool CallFunc_IsAlive_ReturnValue_2 : 1;  // 0x16F1(0x1)
	char pad_5874[6];  // 0x16F2(0x6)
	struct AController* K2Node_Event_NewController;  // 0x16F8(0x8)
	struct AController* CallFunc_GetController_ReturnValue_3;  // 0x1700(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x1708(0x88)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller_3;  // 0x1790(0x8)
	char pad_6040_1 : 7;  // 0x1798(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x1798(0x1)
	char pad_6041[3];  // 0x1799(0x3)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x179C(0xC)
	struct AHUD* CallFunc_GetHUD_ReturnValue_3;  // 0x17A8(0x8)
	float CallFunc_BreakVector_X;  // 0x17B0(0x4)
	float CallFunc_BreakVector_Y;  // 0x17B4(0x4)
	float CallFunc_BreakVector_Z;  // 0x17B8(0x4)
	char pad_6076[4];  // 0x17BC(0x4)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase_3;  // 0x17C0(0x8)
	char pad_6088_1 : 7;  // 0x17C8(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x17C8(0x1)
	char pad_6089[3];  // 0x17C9(0x3)
	float CallFunc_Abs_ReturnValue;  // 0x17CC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x17D0(0x4)
	char pad_6100_1 : 7;  // 0x17D4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x17D4(0x1)
	char pad_6101[3];  // 0x17D5(0x3)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x17D8(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x17DC(0xC)
	struct FKey K2Node_InputActionEvent_Key_13;  // 0x17E8(0x18)
	char K2Node_Event_LastTeamNum;  // 0x1800(0x1)
	char K2Node_Event_NewTeamNum;  // 0x1801(0x1)
	char pad_6146[2];  // 0x1802(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x1804(0x4)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x1808(0x8)
	struct APlayerState* K2Node_Event_NewPlayerState;  // 0x1810(0x8)
	struct APlayerState* K2Node_Event_OldPlayerState;  // 0x1818(0x8)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State;  // 0x1820(0x8)
	char pad_6184_1 : 7;  // 0x1828(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x1828(0x1)
	char pad_6185[7];  // 0x1829(0x7)
	struct ADFBasePlayerState* K2Node_DynamicCast_AsDFBase_Player_State_2;  // 0x1830(0x8)
	char pad_6200_1 : 7;  // 0x1838(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x1838(0x1)
	char pad_6201_1 : 7;  // 0x1839(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1839(0x1)
	char pad_6202_1 : 7;  // 0x183A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x183A(0x1)
	char pad_6203_1 : 7;  // 0x183B(0x1)
	bool CallFunc_IsPlayInEditor_ReturnValue : 1;  // 0x183B(0x1)
	char pad_6204_1 : 7;  // 0x183C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x183C(0x1)
	char pad_6205[3];  // 0x183D(0x3)
	struct FKey K2Node_InputActionEvent_Key_14;  // 0x1840(0x18)
	char pad_6232_1 : 7;  // 0x1858(0x1)
	bool K2Node_CustomEvent_bFirstPerson : 1;  // 0x1858(0x1)
	char pad_6233_1 : 7;  // 0x1859(0x1)
	bool CallFunc_IsInVehicle_ReturnValue : 1;  // 0x1859(0x1)
	char pad_6234_1 : 7;  // 0x185A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x185A(0x1)
	char pad_6235_1 : 7;  // 0x185B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x185B(0x1)
	char pad_6236_1 : 7;  // 0x185C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x185C(0x1)
	char pad_6237_1 : 7;  // 0x185D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x185D(0x1)
	char pad_6238[2];  // 0x185E(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1860(0x10)
	struct APlayerState* K2Node_CustomEvent_PS;  // 0x1870(0x8)
	struct FString K2Node_CustomEvent_NewPlayerName;  // 0x1878(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1888(0x10)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x1898(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x18A0(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x18A8(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x18B0(0x4)
	char pad_6324_1 : 7;  // 0x18B4(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep_2 : 1;  // 0x18B4(0x1)
	char pad_6325[3];  // 0x18B5(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult_2;  // 0x18B8(0x88)
	struct ADFBaseProjectile* K2Node_DynamicCast_AsDFBase_Projectile;  // 0x1940(0x8)
	char pad_6472_1 : 7;  // 0x1948(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x1948(0x1)
	char EEndPlayReason K2Node_Event_EndPlayReason;  // 0x1949(0x1)
	char pad_6474[6];  // 0x194A(0x6)
	struct AController* K2Node_Event_OldController;  // 0x1950(0x8)
	char pad_6488_1 : 7;  // 0x1958(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x1958(0x1)
	char pad_6489[7];  // 0x1959(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_3;  // 0x1960(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_3;  // 0x1968(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_3;  // 0x1970(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_3;  // 0x1978(0x4)
	char pad_6524_1 : 7;  // 0x197C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep_3 : 1;  // 0x197C(0x1)
	char pad_6525[3];  // 0x197D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult_3;  // 0x1980(0x88)
	char pad_6664_1 : 7;  // 0x1A08(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x1A08(0x1)
	char pad_6665[7];  // 0x1A09(0x7)
	struct ADFBaseProjectile* K2Node_DynamicCast_AsDFBase_Projectile_2;  // 0x1A10(0x8)
	char pad_6680_1 : 7;  // 0x1A18(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x1A18(0x1)
	char pad_6681[3];  // 0x1A19(0x3)
	float K2Node_Event_Damage;  // 0x1A1C(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x1A20(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x1A28(0x8)
	struct AActor* K2Node_Event_DamageCauser_2;  // 0x1A30(0x8)
	char pad_6712_1 : 7;  // 0x1A38(0x1)
	bool CallFunc_CleanupVOIPTalker_bDestroyedComp : 1;  // 0x1A38(0x1)
	char pad_6713_1 : 7;  // 0x1A39(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x1A39(0x1)
	char pad_6714[6];  // 0x1A3A(0x6)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_4;  // 0x1A40(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_4;  // 0x1A48(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_4;  // 0x1A50(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_4;  // 0x1A58(0x4)
	char pad_6748_1 : 7;  // 0x1A5C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep_4 : 1;  // 0x1A5C(0x1)
	char pad_6749[3];  // 0x1A5D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult_4;  // 0x1A60(0x88)
	struct ADFBaseProjectile* K2Node_DynamicCast_AsDFBase_Projectile_3;  // 0x1AE8(0x8)
	char pad_6896_1 : 7;  // 0x1AF0(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0x1AF0(0x1)
	char pad_6897_1 : 7;  // 0x1AF1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x1AF1(0x1)
	char pad_6898_1 : 7;  // 0x1AF2(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x1AF2(0x1)
	char pad_6899_1 : 7;  // 0x1AF3(0x1)
	bool CallFunc_CleanupVOIPTalker_bDestroyedComp_2 : 1;  // 0x1AF3(0x1)
	char pad_6900_1 : 7;  // 0x1AF4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_5 : 1;  // 0x1AF4(0x1)
	char pad_6901_1 : 7;  // 0x1AF5(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x1AF5(0x1)
	char pad_6902_1 : 7;  // 0x1AF6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x1AF6(0x1)
	char pad_6903_1 : 7;  // 0x1AF7(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_6 : 1;  // 0x1AF7(0x1)
	struct FKey K2Node_InputActionEvent_Key;  // 0x1AF8(0x18)
	char pad_6928_1 : 7;  // 0x1B10(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // 0x1B10(0x1)
	char pad_6929_1 : 7;  // 0x1B11(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_7 : 1;  // 0x1B11(0x1)
	char pad_6930[2];  // 0x1B12(0x2)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x1B14(0x4)
	struct FKey K2Node_InputActionEvent_Key_15;  // 0x1B18(0x18)
	struct ADFTeamState* K2Node_Event_TeamStateBeforeUpdate;  // 0x1B30(0x8)
	struct ADFTeamState* K2Node_Event_NewTeamState;  // 0x1B38(0x8)
	char pad_6976_1 : 7;  // 0x1B40(0x1)
	bool K2Node_Event_bNewTeamStateInit : 1;  // 0x1B40(0x1)
	char pad_6977_1 : 7;  // 0x1B41(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1B41(0x1)
	char pad_6978_1 : 7;  // 0x1B42(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1B42(0x1)
	char pad_6979_1 : 7;  // 0x1B43(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x1B43(0x1)
	char EMovementMode K2Node_Event_PrevMovementMode;  // 0x1B44(0x1)
	char EMovementMode K2Node_Event_NewMovementMode;  // 0x1B45(0x1)
	char K2Node_Event_PrevCustomMode;  // 0x1B46(0x1)
	char K2Node_Event_NewCustomMode;  // 0x1B47(0x1)
	char pad_6984_1 : 7;  // 0x1B48(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1B48(0x1)
	char pad_6985_1 : 7;  // 0x1B49(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x1B49(0x1)
	char pad_6986[6];  // 0x1B4A(0x6)
	struct ABP_HDScopeWeaponBase_C* K2Node_DynamicCast_AsBP_HDScope_Weapon_Base;  // 0x1B50(0x8)
	char pad_7000_1 : 7;  // 0x1B58(0x1)
	bool K2Node_DynamicCast_bSuccess_12 : 1;  // 0x1B58(0x1)
	char pad_7001_1 : 7;  // 0x1B59(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x1B59(0x1)
	char pad_7002_1 : 7;  // 0x1B5A(0x1)
	bool CallFunc_IsEquipped_ReturnValue : 1;  // 0x1B5A(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1B5B(0x1)
	char pad_7004[4];  // 0x1B5C(0x4)
	struct ADFBaseGun* K2Node_DynamicCast_AsDFBase_Gun;  // 0x1B60(0x8)
	char pad_7016_1 : 7;  // 0x1B68(0x1)
	bool K2Node_DynamicCast_bSuccess_13 : 1;  // 0x1B68(0x1)
	char pad_7017_1 : 7;  // 0x1B69(0x1)
	bool CallFunc_IsReloading_ReturnValue : 1;  // 0x1B69(0x1)
	char pad_7018[6];  // 0x1B6A(0x6)
	struct ADFBaseProjectile* K2Node_CustomEvent_OtherProjectile_2;  // 0x1B70(0x8)
	struct ADFBasePickup* K2Node_CustomEvent_Pickup_2;  // 0x1B78(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1B80(0x4)
	char pad_7044_1 : 7;  // 0x1B84(0x1)
	bool CallFunc_IsEquipped_ReturnValue_2 : 1;  // 0x1B84(0x1)
	char pad_7045[3];  // 0x1B85(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1B88(0x4)
	int32_t CallFunc_Find_OutIndex;  // 0x1B8C(0x4)
	char pad_7056_1 : 7;  // 0x1B90(0x1)
	bool CallFunc_Find_ReturnValue : 1;  // 0x1B90(0x1)
	char pad_7057[7];  // 0x1B91(0x7)
	struct ADFBaseItem* CallFunc_GetItem_OutItem;  // 0x1B98(0x8)
	char pad_7072_1 : 7;  // 0x1BA0(0x1)
	bool CallFunc_GetItem_ReturnValue : 1;  // 0x1BA0(0x1)
	char pad_7073_1 : 7;  // 0x1BA1(0x1)
	bool CallFunc_EquipPrimaryItem_ReturnValue : 1;  // 0x1BA1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x1BA2(0x1)
	char pad_7075[5];  // 0x1BA3(0x5)
	struct UDFCommChannel* K2Node_Event_MsgTalkerChannel;  // 0x1BA8(0x8)
	struct APlayerState* K2Node_Event_MsgTalkerPS;  // 0x1BB0(0x8)
	char pad_7096_1 : 7;  // 0x1BB8(0x1)
	bool K2Node_Event_bMsgIsTalking : 1;  // 0x1BB8(0x1)
	char pad_7097_1 : 7;  // 0x1BB9(0x1)
	bool Temp_bool_Variable : 1;  // 0x1BB9(0x1)
	char pad_7098_1 : 7;  // 0x1BBA(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x1BBA(0x1)
	char pad_7099[5];  // 0x1BBB(0x5)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x1BC0(0x18)
	char pad_7128_1 : 7;  // 0x1BD8(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x1BD8(0x1)
	char pad_7129_1 : 7;  // 0x1BD9(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1BD9(0x1)
	char pad_7130_1 : 7;  // 0x1BDA(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x1BDA(0x1)
	char pad_7131_1 : 7;  // 0x1BDB(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x1BDB(0x1)
	char pad_7132[4];  // 0x1BDC(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x1BE0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x1BE8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x1BF0(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x1BF8(0x4)
	char pad_7164_1 : 7;  // 0x1BFC(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x1BFC(0x1)
	char pad_7165[3];  // 0x1BFD(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x1C00(0x88)
	char pad_7304_1 : 7;  // 0x1C88(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_3 : 1;  // 0x1C88(0x1)
	char pad_7305[7];  // 0x1C89(0x7)
	struct ADFBaseProjectile* K2Node_DynamicCast_AsDFBase_Projectile_4;  // 0x1C90(0x8)
	char pad_7320_1 : 7;  // 0x1C98(0x1)
	bool K2Node_DynamicCast_bSuccess_14 : 1;  // 0x1C98(0x1)
	char pad_7321_1 : 7;  // 0x1C99(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1C99(0x1)
	char pad_7322_1 : 7;  // 0x1C9A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x1C9A(0x1)
	char pad_7323_1 : 7;  // 0x1C9B(0x1)
	bool CallFunc_IsAlive_ReturnValue_3 : 1;  // 0x1C9B(0x1)
	char pad_7324_1 : 7;  // 0x1C9C(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue_4 : 1;  // 0x1C9C(0x1)
	char pad_7325_1 : 7;  // 0x1C9D(0x1)
	bool CallFunc_IsBotControlled_ReturnValue : 1;  // 0x1C9D(0x1)
	char pad_7326_1 : 7;  // 0x1C9E(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x1C9E(0x1)
	char pad_7327_1 : 7;  // 0x1C9F(0x1)
	bool CallFunc_IsBotControlled_ReturnValue_2 : 1;  // 0x1C9F(0x1)
	char pad_7328_1 : 7;  // 0x1CA0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_8 : 1;  // 0x1CA0(0x1)
	char pad_7329_1 : 7;  // 0x1CA1(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0x1CA1(0x1)
	char pad_7330_1 : 7;  // 0x1CA2(0x1)
	bool CallFunc_BooleanAND_ReturnValue_7 : 1;  // 0x1CA2(0x1)
	char pad_7331[5];  // 0x1CA3(0x5)
	struct ABP_HDScopeWeaponBase_C* K2Node_DynamicCast_AsBP_HDScope_Weapon_Base_2;  // 0x1CA8(0x8)
	char pad_7344_1 : 7;  // 0x1CB0(0x1)
	bool K2Node_DynamicCast_bSuccess_15 : 1;  // 0x1CB0(0x1)
	char pad_7345[7];  // 0x1CB1(0x7)
	struct ABP_HDScopeWeaponBase_C* K2Node_DynamicCast_AsBP_HDScope_Weapon_Base_3;  // 0x1CB8(0x8)
	char pad_7360_1 : 7;  // 0x1CC0(0x1)
	bool K2Node_DynamicCast_bSuccess_16 : 1;  // 0x1CC0(0x1)
	char pad_7361_1 : 7;  // 0x1CC1(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x1CC1(0x1)
	char pad_7362_1 : 7;  // 0x1CC2(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x1CC2(0x1)
	char pad_7363_1 : 7;  // 0x1CC3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_9 : 1;  // 0x1CC3(0x1)
	char pad_7364[4];  // 0x1CC4(0x4)
	struct FKey Temp_struct_Variable;  // 0x1CC8(0x18)
	struct FKey K2Node_InputActionEvent_Key_16;  // 0x1CE0(0x18)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x1CF8(0x18)
	struct FKey K2Node_InputActionEvent_Key_17;  // 0x1D10(0x18)
	struct AController* CallFunc_GetController_ReturnValue_4;  // 0x1D28(0x8)
	char pad_7472_1 : 7;  // 0x1D30(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1D30(0x1)
	char pad_7473[7];  // 0x1D31(0x7)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller_4;  // 0x1D38(0x8)
	char pad_7488_1 : 7;  // 0x1D40(0x1)
	bool K2Node_DynamicCast_bSuccess_17 : 1;  // 0x1D40(0x1)
	char pad_7489[7];  // 0x1D41(0x7)
	struct FKey K2Node_InputActionEvent_Key_4;  // 0x1D48(0x18)
	struct AController* CallFunc_GetController_ReturnValue_5;  // 0x1D60(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller_5;  // 0x1D68(0x8)
	char pad_7536_1 : 7;  // 0x1D70(0x1)
	bool K2Node_DynamicCast_bSuccess_18 : 1;  // 0x1D70(0x1)
	char pad_7537[3];  // 0x1D71(0x3)
	float CallFunc_Lerp_ReturnValue;  // 0x1D74(0x4)
	struct UWBP_HDRadialMenu_C* CallFunc_Create_ReturnValue;  // 0x1D78(0x8)
	float CallFunc_SelectFloat_ReturnValue;  // 0x1D80(0x4)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue;  // 0x1D84(0x10)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue_2;  // 0x1D94(0x10)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue_3;  // 0x1DA4(0x10)
	struct FLinearColor CallFunc_LinearColorLerp_ReturnValue_4;  // 0x1DB4(0x10)
	char pad_7620_1 : 7;  // 0x1DC4(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x1DC4(0x1)
	char pad_7621[3];  // 0x1DC5(0x3)
	float CallFunc_BreakVector_X_2;  // 0x1DC8(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x1DCC(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x1DD0(0x4)
	struct FLinearColor CallFunc_MakeColor_ReturnValue;  // 0x1DD4(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x1DE4(0x4)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_2;  // 0x1DE8(0x10)
	float CallFunc_BreakVector_X_3;  // 0x1DF8(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x1DFC(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x1E00(0x4)
	struct FLinearColor CallFunc_MakeColor_ReturnValue_3;  // 0x1E04(0x10)
	char pad_7700_1 : 7;  // 0x1E14(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x1E14(0x1)
	char pad_7701_1 : 7;  // 0x1E15(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x1E15(0x1)
	char pad_7702[2];  // 0x1E16(0x2)
	struct FName K2Node_CustomEvent_Category;  // 0x1E18(0x8)
	struct FName K2Node_CustomEvent_SubItem;  // 0x1E20(0x8)
	struct ADFBaseItem* K2Node_Event_NewEquippedItem;  // 0x1E28(0x8)
	struct ADFBaseItem* K2Node_Event_PrevEquippedItem;  // 0x1E30(0x8)
	struct ABP_HDWeaponBase_C* K2Node_DynamicCast_AsBP_HDWeapon_Base;  // 0x1E38(0x8)
	char pad_7744_1 : 7;  // 0x1E40(0x1)
	bool K2Node_DynamicCast_bSuccess_19 : 1;  // 0x1E40(0x1)
	char pad_7745_1 : 7;  // 0x1E41(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_4 : 1;  // 0x1E41(0x1)
	char pad_7746[2];  // 0x1E42(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x1E44(0x4)
	char pad_7752_1 : 7;  // 0x1E48(0x1)
	bool CallFunc_HasAuthority_ReturnValue_4 : 1;  // 0x1E48(0x1)
	char pad_7753_1 : 7;  // 0x1E49(0x1)
	bool CallFunc_HasAuthority_ReturnValue_5 : 1;  // 0x1E49(0x1)
	char pad_7754[2];  // 0x1E4A(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x1E4C(0x10)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1E5C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x1E60(0x10)
	char pad_7792_1 : 7;  // 0x1E70(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0x1E70(0x1)
	char pad_7793_1 : 7;  // 0x1E71(0x1)
	bool CallFunc_HasAuthority_ReturnValue_6 : 1;  // 0x1E71(0x1)
	char pad_7794[2];  // 0x1E72(0x2)
	float K2Node_Event_DamageTaken;  // 0x1E74(0x4)
	struct FDamageEvent K2Node_Event_DamageEvent;  // 0x1E78(0x10)
	struct APawn* K2Node_Event_PawnInstigator;  // 0x1E88(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x1E90(0x8)
	char pad_7832_1 : 7;  // 0x1E98(0x1)
	bool K2Node_Event_bKilled : 1;  // 0x1E98(0x1)
	char pad_7833_1 : 7;  // 0x1E99(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x1E99(0x1)
	char pad_7834[6];  // 0x1E9A(0x6)
	struct ADFBaseProjectile* K2Node_DynamicCast_AsDFBase_Projectile_5;  // 0x1EA0(0x8)
	char pad_7848_1 : 7;  // 0x1EA8(0x1)
	bool K2Node_DynamicCast_bSuccess_20 : 1;  // 0x1EA8(0x1)
	char pad_7849_1 : 7;  // 0x1EA9(0x1)
	bool CallFunc_IsAlive_ReturnValue_4 : 1;  // 0x1EA9(0x1)
	char pad_7850[6];  // 0x1EAA(0x6)
	struct FDFCharacterVariationData K2Node_Event_NewVariation;  // 0x1EB0(0x68)
	struct FDFCharacterVariationData K2Node_Event_PreviousVariation;  // 0x1F18(0x68)
	char pad_8064_1 : 7;  // 0x1F80(0x1)
	bool CallFunc_CharacterVariationIsValid_ReturnValue : 1;  // 0x1F80(0x1)
	char pad_8065_1 : 7;  // 0x1F81(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x1F81(0x1)
	char pad_8066_1 : 7;  // 0x1F82(0x1)
	bool CallFunc_IsAlive_ReturnValue_5 : 1;  // 0x1F82(0x1)
	char pad_8067[1];  // 0x1F83(0x1)
	float K2Node_Event_NewHealthTotal;  // 0x1F84(0x4)
	float K2Node_Event_PrevHealthTotal;  // 0x1F88(0x4)
	char pad_8076_1 : 7;  // 0x1F8C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x1F8C(0x1)
	char pad_8077[3];  // 0x1F8D(0x3)
	struct ADFBaseProjectile* K2Node_CustomEvent_OtherProjectile;  // 0x1F90(0x8)
	struct ADFBasePickup* K2Node_CustomEvent_Pickup;  // 0x1F98(0x8)
	struct UPrimitiveComponent* K2Node_CustomEvent_SuppressionVolume;  // 0x1FA0(0x8)
	ADFBasePickup* CallFunc_GetObjectClass_ReturnValue;  // 0x1FA8(0x8)
	char pad_8112_1 : 7;  // 0x1FB0(0x1)
	bool CallFunc_ClassIsChildOf_ReturnValue : 1;  // 0x1FB0(0x1)
	char pad_8113[7];  // 0x1FB1(0x7)
	ADFBaseProjectile* CallFunc_GetObjectClass_ReturnValue_2;  // 0x1FB8(0x8)
	char pad_8128_1 : 7;  // 0x1FC0(0x1)
	bool CallFunc_ClassIsChildOf_ReturnValue_2 : 1;  // 0x1FC0(0x1)
	char pad_8129_1 : 7;  // 0x1FC1(0x1)
	bool CallFunc_IsActive_ReturnValue : 1;  // 0x1FC1(0x1)
	char pad_8130_1 : 7;  // 0x1FC2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_10 : 1;  // 0x1FC2(0x1)
	char pad_8131[5];  // 0x1FC3(0x5)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x1FC8(0x8)
	char pad_8144_1 : 7;  // 0x1FD0(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0x1FD0(0x1)
	char pad_8145_1 : 7;  // 0x1FD1(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x1FD1(0x1)
	char pad_8146_1 : 7;  // 0x1FD2(0x1)
	bool CallFunc_BooleanOR_ReturnValue_5 : 1;  // 0x1FD2(0x1)
	char pad_8147_1 : 7;  // 0x1FD3(0x1)
	bool CallFunc_BooleanOR_ReturnValue_6 : 1;  // 0x1FD3(0x1)
	char pad_8148[4];  // 0x1FD4(0x4)
	struct ADFBaseItem* K2Node_DynamicCast_AsDFBase_Item;  // 0x1FD8(0x8)
	char pad_8160_1 : 7;  // 0x1FE0(0x1)
	bool K2Node_DynamicCast_bSuccess_21 : 1;  // 0x1FE0(0x1)
	char pad_8161_1 : 7;  // 0x1FE1(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x1FE1(0x1)
	char pad_8162_1 : 7;  // 0x1FE2(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x1FE2(0x1)
	uint8_t  K2Node_Select_Default;  // 0x1FE3(0x1)
	char pad_8164[4];  // 0x1FE4(0x4)
	struct UCurveVector* CallFunc_GetVaultCameraCurveForBehavior_CameraCurve;  // 0x1FE8(0x8)
	char pad_8176_1 : 7;  // 0x1FF0(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue_5 : 1;  // 0x1FF0(0x1)
	char pad_8177[3];  // 0x1FF1(0x3)
	float CallFunc_GetTimeRange_MinTime_3;  // 0x1FF4(0x4)
	float CallFunc_GetTimeRange_MaxTime_3;  // 0x1FF8(0x4)
	char pad_8188_1 : 7;  // 0x1FFC(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue_6 : 1;  // 0x1FFC(0x1)
	char pad_8189_1 : 7;  // 0x1FFD(0x1)
	bool CallFunc_IsPlaying_ReturnValue : 1;  // 0x1FFD(0x1)
	char pad_8190_1 : 7;  // 0x1FFE(0x1)
	bool CallFunc_BooleanOR_ReturnValue_7 : 1;  // 0x1FFE(0x1)
	char pad_8191[1];  // 0x1FFF(0x1)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x2000(0xC)
	char pad_8204_1 : 7;  // 0x200C(0x1)
	bool CallFunc_IsVaulting_ReturnValue : 1;  // 0x200C(0x1)
	char pad_8205[3];  // 0x200D(0x3)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x2010(0x88)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_2;  // 0x2098(0x88)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x2120(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x2124(0x4)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_3;  // 0x2128(0x88)
	ABP_HDPlayerCharacterBase_C* CallFunc_GetObjectClass_ReturnValue_3;  // 0x21B0(0x8)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x21B8(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult_4;  // 0x21C4(0x88)
	char pad_8780[4];  // 0x224C(0x4)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x2250(0x10)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x2260(0x8)
	char pad_8808_1 : 7;  // 0x2268(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0x2268(0x1)
	char pad_8809[3];  // 0x2269(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x226C(0x4)
	char pad_8816_1 : 7;  // 0x2270(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2270(0x1)
	char pad_8817[7];  // 0x2271(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x2278(0x8)
	struct FKey K2Node_InputActionEvent_Key_5;  // 0x2280(0x18)
	char pad_8856_1 : 7;  // 0x2298(0x1)
	bool CallFunc_IsValid_ReturnValue_14 : 1;  // 0x2298(0x1)
	char pad_8857[7];  // 0x2299(0x7)
	struct FKey K2Node_InputActionEvent_Key_6;  // 0x22A0(0x18)
	struct FKey K2Node_InputActionEvent_Key_7;  // 0x22B8(0x18)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue_2;  // 0x22D0(0x10)
	struct UMaterialInterface* CallFunc_Array_Get_Item_2;  // 0x22E0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x22E8(0x4)
	char pad_8940_1 : 7;  // 0x22EC(0x1)
	bool CallFunc_IsValid_ReturnValue_15 : 1;  // 0x22EC(0x1)
	char pad_8941_1 : 7;  // 0x22ED(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x22ED(0x1)
	char pad_8942[2];  // 0x22EE(0x2)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x22F0(0x8)
	struct FKey K2Node_InputActionEvent_Key_8;  // 0x22F8(0x18)
	struct FKey K2Node_InputActionEvent_Key_9;  // 0x2310(0x18)
	char pad_9000_1 : 7;  // 0x2328(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x2328(0x1)
	char pad_9001_1 : 7;  // 0x2329(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_11 : 1;  // 0x2329(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_PointAimToggle_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PointAimToggle_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveVariationDataChanged
// Size: 0xD0(Inherited: 0xD0) 
struct FReceiveVariationDataChanged : public FReceiveVariationDataChanged
{
	struct FDFCharacterVariationData NewVariation;  // 0x0(0x68)
	struct FDFCharacterVariationData PreviousVariation;  // 0x68(0x68)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePlayHit
// Size: 0x29(Inherited: 0x30) 
struct FReceivePlayHit : public FReceivePlayHit
{
	float DamageTaken;  // 0x0(0x4)
	struct FDamageEvent DamageEvent;  // 0x8(0x10)
	struct APawn* PawnInstigator;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bKilled : 1;  // 0x28(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_NextItem_K2Node_InputActionEvent_17
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_NextItem_K2Node_InputActionEvent_17
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot5_K2Node_InputActionEvent_9
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot5_K2Node_InputActionEvent_9
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SubmenuCommited
// Size: 0x10(Inherited: 0x0) 
struct FSubmenuCommited
{
	struct FName Category;  // 0x0(0x8)
	struct FName SubItem;  // 0x8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidPlayerState
// Size: 0xA(Inherited: 0x0) 
struct FGetMostValidPlayerState
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x9(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_R_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Suppression_R_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveVoipTalkerMsgReceived
// Size: 0x11(Inherited: 0x18) 
struct FReceiveVoipTalkerMsgReceived : public FReceiveVoipTalkerMsgReceived
{
	struct UDFCommChannel* MsgTalkerChannel;  // 0x0(0x8)
	struct APlayerState* MsgTalkerPS;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bMsgIsTalking : 1;  // 0x10(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EquipSelectedItemFromInventory
// Size: 0x4C(Inherited: 0x0) 
struct FEquipSelectedItemFromInventory
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSwitchFireModeForSelected : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x28(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AHDBaseWeapon* CallFunc_EquipmentGetSelectedItem_OutItemToEquip;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_EquipmentGetSelectedItem_bFoundItem : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsSelectableEquipment_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x4B(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.Hit Damage
// Size: 0x10(Inherited: 0x0) 
struct FHit Damage
{
	struct ADFBaseProjectile* OtherProjectile;  // 0x0(0x8)
	struct ADFBasePickup* Pickup;  // 0x8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_RadialMenu_K2Node_InputActionEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RadialMenu_K2Node_InputActionEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePawnTeamStateUpdated
// Size: 0x11(Inherited: 0x18) 
struct FReceivePawnTeamStateUpdated : public FReceivePawnTeamStateUpdated
{
	struct ADFTeamState* TeamStateBeforeUpdate;  // 0x0(0x8)
	struct ADFTeamState* NewTeamState;  // 0x8(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bNewTeamStateInit : 1;  // 0x10(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot7_K2Node_InputActionEvent_7
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot7_K2Node_InputActionEvent_7
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetSquadState
// Size: 0x19(Inherited: 0x0) 
struct FGetSquadState
{
	struct AHDSquadState* SquadState;  // 0x0(0x8)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x8(0x8)
	struct AHDPlayerState* K2Node_DynamicCast_AsHDPlayer_State;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnDeath
// Size: 0x28(Inherited: 0x28) 
struct FOnDeath : public FOnDeath
{
	float KillingDamage;  // 0x0(0x4)
	struct FDamageEvent DamageEvent;  // 0x8(0x10)
	struct APawn* InstigatingPawn;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveUnpossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceiveUnpossessed : public FReceiveUnpossessed
{
	struct AController* OldController;  // 0x0(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveEndPlay
// Size: 0x1(Inherited: 0x1) 
struct FReceiveEndPlay : public FReceiveEndPlay
{
	char EEndPlayReason EndPlayReason;  // 0x0(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.FirstPersonToggled
// Size: 0x1(Inherited: 0x0) 
struct FFirstPersonToggled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFirstPerson : 1;  // 0x0(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UserConstructionScript
// Size: 0x10(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot6_K2Node_InputActionEvent_8
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot6_K2Node_InputActionEvent_8
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.NotifyPlayerStateChanged
// Size: 0x10(Inherited: 0x10) 
struct FNotifyPlayerStateChanged : public FNotifyPlayerStateChanged
{
	struct APlayerState* NewPlayerState;  // 0x0(0x8)
	struct APlayerState* OldPlayerState;  // 0x8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_CycleWeaponSights_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_CycleWeaponSights_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetVaultCameraCurveForBehavior
// Size: 0x38(Inherited: 0x0) 
struct FGetVaultCameraCurveForBehavior
{
	uint8_t  VaultBehavior;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UCurveVector* CameraCurve;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x13(0x1)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_Less_ByteByte_ReturnValue : 1;  // 0x16(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x17(0x1)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	struct UCurveVector* K2Node_Select_Default;  // 0x20(0x8)
	struct UCurveVector* K2Node_Select_Default_2;  // 0x28(0x8)
	struct UCurveVector* K2Node_Select_Default_3;  // 0x30(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessed : public FReceivePossessed
{
	struct AController* NewController;  // 0x0(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveFreeAim
// Size: 0x4(Inherited: 0x4) 
struct FReceiveFreeAim : public FReceiveFreeAim
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePawnTeamNumUpdated
// Size: 0x2(Inherited: 0x2) 
struct FReceivePawnTeamNumUpdated : public FReceivePawnTeamNumUpdated
{
	char LastTeamNum;  // 0x0(0x1)
	char NewTeamNum;  // 0x1(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveGetDefaultPawnMesh1P
// Size: 0x29(Inherited: 0x8) 
struct FReceiveGetDefaultPawnMesh1P : public FReceiveGetDefaultPawnMesh1P
{
	struct USkeletalMesh* ReturnValue;  // 0x0(0x8)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x8(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x9(0x1)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x10(0x8)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x18(0x8)
	struct USkeletalMesh* K2Node_DynamicCast_AsSkeletal_Mesh;  // 0x20(0x8)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnLanded
// Size: 0x88(Inherited: 0x88) 
struct FOnLanded : public FOnLanded
{
	struct FHitResult Hit;  // 0x0(0x88)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_B_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Suppression_B_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMesh
// Size: 0x18(Inherited: 0x0) 
struct FUpdateCharMesh
{
	struct USkeletalMesh* NewMesh;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bUpdateFPPMesh : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct USkinnedMeshComponent* K2Node_Select_Default;  // 0x10(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_A_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Suppression_A_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdatePOIState
// Size: 0x9D9(Inherited: 0x0) 
struct FUpdatePOIState
{
	struct FLinearColor OtherPlayerPOITextColor;  // 0x0(0x10)
	struct FLinearColor OtherPlayerPOITint;  // 0x10(0x10)
	struct UTexture2D* OtherPlayerPOISymbol;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FSlateBrush Temp_struct_Variable;  // 0x40(0x88)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue;  // 0xC8(0x10)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue_2;  // 0xD8(0x10)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue_3;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	int32_t CallFunc_Blueprint_GetSizeY_ReturnValue;  // 0xFC(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x100(0x4)
	int32_t CallFunc_Blueprint_GetSizeX_ReturnValue;  // 0x104(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x108(0x4)
	char CallFunc_GetValidValue_ReturnValue;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x110(0x8)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue_2;  // 0x118(0x8)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue_3;  // 0x120(0x8)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface_2;  // 0x140(0x10)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct FSlateBrush CallFunc_GetIconBrush_ReturnValue;  // 0x158(0x88)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue_4;  // 0x1E8(0x8)
	struct UWBP_HDPOI_Player_C* K2Node_DynamicCast_AsWBP_HDPOI_Player;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x200(0x28)
	struct AHDSquadState* CallFunc_GetSquadState_SquadState;  // 0x228(0x8)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x230(0x1)
	char pad_561[3];  // 0x231(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x234(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x238(0x18)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool CallFunc_IsSquadLeader_bSquadLeader : 1;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue_5;  // 0x258(0x8)
	struct UWBP_HDPOI_Player_C* K2Node_DynamicCast_AsWBP_HDPOI_Player_2;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // 0x270(0x28)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x298(0x1)
	char pad_665[7];  // 0x299(0x7)
	struct FSlateBrush Temp_struct_Variable_2;  // 0x2A0(0x88)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x328(0x1)
	char pad_809[3];  // 0x329(0x3)
	int32_t CallFunc_Blueprint_GetSizeY_ReturnValue_2;  // 0x32C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_3;  // 0x330(0x4)
	int32_t CallFunc_Blueprint_GetSizeX_ReturnValue_2;  // 0x334(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_4;  // 0x338(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_2;  // 0x33C(0x8)
	char pad_836[4];  // 0x344(0x4)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue_6;  // 0x348(0x8)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface_3;  // 0x350(0x10)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x360(0x1)
	char pad_865[7];  // 0x361(0x7)
	struct FSlateColor K2Node_MakeStruct_SlateColor_3;  // 0x368(0x28)
	struct FSlateBrush CallFunc_GetIconBrush_ReturnValue_2;  // 0x390(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x418(0x88)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface_4;  // 0x4A0(0x10)
	char pad_1200_1 : 7;  // 0x4B0(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x4B0(0x1)
	char pad_1201[7];  // 0x4B1(0x7)
	struct FSlateBrush Temp_struct_Variable_3;  // 0x4B8(0x88)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue_7;  // 0x540(0x8)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface_5;  // 0x548(0x10)
	char pad_1368_1 : 7;  // 0x558(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x558(0x1)
	char pad_1369[7];  // 0x559(0x7)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface_6;  // 0x560(0x10)
	char pad_1392_1 : 7;  // 0x570(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x570(0x1)
	char pad_1393[7];  // 0x571(0x7)
	struct FSlateBrush CallFunc_GetIconBrush_ReturnValue_3;  // 0x578(0x88)
	struct FSlateBrush Temp_struct_Variable_4;  // 0x600(0x88)
	struct ABP_HDPlayerControllerBase_C* CallFunc_GetHDPlayerControllerBP_HDPC;  // 0x688(0x8)
	char pad_1680_1 : 7;  // 0x690(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue : 1;  // 0x690(0x1)
	char pad_1681_1 : 7;  // 0x691(0x1)
	bool CallFunc_IsSameSquad_bSameSquad : 1;  // 0x691(0x1)
	char pad_1682_1 : 7;  // 0x692(0x1)
	bool CallFunc_IsSameSquad_bSameSquad_2 : 1;  // 0x692(0x1)
	char pad_1683_1 : 7;  // 0x693(0x1)
	bool CallFunc_IsMatchingTeam_bMatchingTeam : 1;  // 0x693(0x1)
	char pad_1684[4];  // 0x694(0x4)
	struct UDFMinimap* CallFunc_GetMinimapWidget_MinimapWidget;  // 0x698(0x8)
	char pad_1696_1 : 7;  // 0x6A0(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x6A0(0x1)
	char pad_1697_1 : 7;  // 0x6A1(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x6A1(0x1)
	char pad_1698_1 : 7;  // 0x6A2(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x6A2(0x1)
	char pad_1699[5];  // 0x6A3(0x5)
	struct FSlateColor K2Node_MakeStruct_SlateColor_4;  // 0x6A8(0x28)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_2;  // 0x6D0(0x88)
	uint8_t  Temp_byte_Variable;  // 0x758(0x1)
	char pad_1881[3];  // 0x759(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x75C(0x10)
	char pad_1900[4];  // 0x76C(0x4)
	struct UDFPOIWidget* CallFunc_GetPOIWidget_ReturnValue_8;  // 0x770(0x8)
	struct FSlateColor K2Node_MakeStruct_SlateColor_5;  // 0x778(0x28)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface_7;  // 0x7A0(0x10)
	char pad_1968_1 : 7;  // 0x7B0(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x7B0(0x1)
	char pad_1969[7];  // 0x7B1(0x7)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_3;  // 0x7B8(0x88)
	struct FSlateBrush CallFunc_GetIconBrush_ReturnValue_4;  // 0x840(0x88)
	struct TScriptInterface<IPOIWidgetSlotInterface> K2Node_DynamicCast_AsPOIWidget_Slot_Interface_8;  // 0x8C8(0x10)
	char pad_2264_1 : 7;  // 0x8D8(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0x8D8(0x1)
	char pad_2265[7];  // 0x8D9(0x7)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x8E0(0x8)
	char pad_2280_1 : 7;  // 0x8E8(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x8E8(0x1)
	char pad_2281[7];  // 0x8E9(0x7)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x8F0(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x900(0x18)
	char pad_2328_1 : 7;  // 0x918(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x918(0x1)
	char pad_2329_1 : 7;  // 0x919(0x1)
	bool CallFunc_IsAlive_ReturnValue_2 : 1;  // 0x919(0x1)
	char pad_2330_1 : 7;  // 0x91A(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x91A(0x1)
	char pad_2331_1 : 7;  // 0x91B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x91B(0x1)
	int32_t CallFunc_Blueprint_GetSizeY_ReturnValue_3;  // 0x91C(0x4)
	int32_t CallFunc_Blueprint_GetSizeX_ReturnValue_3;  // 0x920(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_5;  // 0x924(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_6;  // 0x928(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_3;  // 0x92C(0x8)
	char pad_2356_1 : 7;  // 0x934(0x1)
	bool CallFunc_IsPOIRegistered_ReturnValue : 1;  // 0x934(0x1)
	char pad_2357[3];  // 0x935(0x3)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_4;  // 0x938(0x88)
	char pad_2496_1 : 7;  // 0x9C0(0x1)
	bool CallFunc_IsPOIRegistered_ReturnValue_2 : 1;  // 0x9C0(0x1)
	char pad_2497_1 : 7;  // 0x9C1(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x9C1(0x1)
	char pad_2498[6];  // 0x9C2(0x6)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x9C8(0x8)
	struct UDFMinimap* CallFunc_GetMinimapWidget_MinimapWidget_2;  // 0x9D0(0x8)
	char pad_2520_1 : 7;  // 0x9D8(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0x9D8(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_L_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Suppression_L_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcOutpostDistanceRestriction
// Size: 0x99(Inherited: 0x0) 
struct FCalcOutpostDistanceRestriction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsOutpostDistanceRestricted : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float DistanceRestrictionSquared;  // 0x4(0x4)
	struct FVector PlayerLocation;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	ABP_HDProj_OutpostBase_C* OutpostClass;  // 0x18(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x34(0xC)
	char CallFunc_GetValidValue_ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TArray<struct ABP_HDProj_OutpostBase_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x48(0x10)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x58(0x8)
	struct ABP_HDProj_OutpostBase_C* CallFunc_Array_Get_Item;  // 0x60(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x68(0xC)
	char pad_116[4];  // 0x74(0x4)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0x78(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	ABP_HDProj_OutpostBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Outpost_Base;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x91(0x1)
	char pad_146[2];  // 0x92(0x2)
	float CallFunc_Vector_DistanceSquared_ReturnValue;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x98(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_RadialMenu_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_RadialMenu_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot9_K2Node_InputActionEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot9_K2Node_InputActionEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot8_K2Node_InputActionEvent_6
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot8_K2Node_InputActionEvent_6
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMeshesFromFaction
// Size: 0x41(Inherited: 0x0) 
struct FUpdateCharMeshesFromFaction
{
	UDFFactionInfo* CallFunc_GetMostValidTeamFactionInfo_FactionInfoClass;  // 0x0(0x8)
	UBP_HDFactionInfoBase_C* K2Node_ClassDynamicCast_AsBP_HDFaction_Info_Base;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x18(0x8)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue_2;  // 0x20(0x8)
	struct USkeletalMesh* K2Node_DynamicCast_AsSkeletal_Mesh;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct USkeletalMesh* K2Node_DynamicCast_AsSkeletal_Mesh_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x40(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot4_K2Node_InputActionEvent_10
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot4_K2Node_InputActionEvent_10
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot3_K2Node_InputActionEvent_11
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot3_K2Node_InputActionEvent_11
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_CameraToggle_K2Node_InputActionEvent_15
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_CameraToggle_K2Node_InputActionEvent_15
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsSameSquad
// Size: 0x2B(Inherited: 0x0) 
struct FIsSameSquad
{
	struct ABP_HDPlayerControllerBase_C* LocalController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSameSquad : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AHDSquadState* CallFunc_GetSquadState_SquadState;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AHDPlayerState* K2Node_DynamicCast_AsHDPlayer_State;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2A(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot2_K2Node_InputActionEvent_12
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot2_K2Node_InputActionEvent_12
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot1_K2Node_InputActionEvent_13
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot1_K2Node_InputActionEvent_13
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot0_K2Node_InputActionEvent_14
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EqpSlot0_K2Node_InputActionEvent_14
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectOutpost
// Size: 0x52(Inherited: 0x0) 
struct FRadialMenuSelectOutpost
{
	ABP_HDProj_OutpostBase_C* OutpostType;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_CalcOutpostEnemiesNearbyRestriction_bAreEnemiesNearby : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_IsOutpostNumberLimitReached_bNumberLimitReached : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_CalcOutpostDistanceRestriction_bIsOutpostDistanceRestricted : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_GetIsSpawnedOutpostValid_bIsSpawnedOutpostValid : 1;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x10(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	float CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0x14(0x4)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_RadialMenuCanSelectOutpost_bSelectable : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	ABP_HDProj_OutpostBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Outpost_Base;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct ABP_HDProj_SPDeployableBase_C* CallFunc_SpawnAndInitDeployableSPAtPawn_SpawnedDeployableSP;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x51(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_PreviousItem_K2Node_InputActionEvent_16
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PreviousItem_K2Node_InputActionEvent_16
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.FreeAiming
// Size: 0xE4(Inherited: 0x0) 
struct FFreeAiming
{
	float SpringArmDeltaY;  // 0x0(0x4)
	float SpringArmDeltaX;  // 0x4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xC(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x10(0x4)
	float CallFunc_Abs_ReturnValue_2;  // 0x14(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x18(0xC)
	float CallFunc_GetMaxFreeAimYawToUse_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_GetMaxFreeAimPitchToUse_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x38(0x8)
	struct FHitResult CallFunc_K2_AddRelativeRotation_SweepHitResult;  // 0x40(0x88)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	float CallFunc_GetInputMouseDelta_DeltaX;  // 0xD4(0x4)
	float CallFunc_GetInputMouseDelta_DeltaY;  // 0xD8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0xDC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0xE0(0x4)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.StartEquipmentTimer
// Size: 0x29(Inherited: 0x0) 
struct FStartEquipmentTimer
{
	struct AController* CallFunc_GetController_ReturnValue;  // 0x0(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x18(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x28(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetEquipmentTimer
// Size: 0x20(Inherited: 0x0) 
struct FSetEquipmentTimer
{
	float CallFunc_GetGlobalTimeDilation_ReturnValue;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SelectEquipmentBySlotNum
// Size: 0x7D(Inherited: 0x0) 
struct FSelectEquipmentBySlotNum
{
	int32_t EquipSlotNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bEquipImmediately : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool bFromInput : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t PrevSlotNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UTBGameUserSettings* CallFunc_GetHDGameUserSettings_HDGameUserSettings;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_GetSwitchFireModeOnReselect_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x20(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue;  // 0x38(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x50(0x8)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller_2;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct AHUD* CallFunc_GetHUD_ReturnValue_2;  // 0x68(0x8)
	struct ABP_HDHUDBase_C* K2Node_DynamicCast_AsBP_HDHUDBase_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_EquipmentSelectItemBySlotNum_bOutNewSelection : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x7A(0x1)
	char pad_123_1 : 7;  // 0x7B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7B(0x1)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x7C(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMeshes
// Size: 0x10(Inherited: 0x0) 
struct FUpdateCharMeshes
{
	struct USkeletalMesh* MeshFPP;  // 0x0(0x8)
	struct USkeletalMesh* MeshTPP;  // 0x8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ApplyCharacterVariation
// Size: 0xC0(Inherited: 0x0) 
struct FApplyCharacterVariation
{
	struct FDFCharacterVariationDataHandle VariationHandle;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bApplyToFPP : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_Variable : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FDFCharacterVariationData CallFunc_CharacterVariationGetData_ReturnValue;  // 0x20(0x68)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue;  // 0x88(0x8)
	struct UObject* CallFunc_Conv_SoftObjectReferenceToObject_ReturnValue_2;  // 0x90(0x8)
	struct USkeletalMesh* K2Node_DynamicCast_AsSkeletal_Mesh;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct USkeletalMesh* K2Node_DynamicCast_AsSkeletal_Mesh_2;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct USkeletalMesh* K2Node_Select_Default;  // 0xB8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMinimapWidget
// Size: 0x28(Inherited: 0x0) 
struct FGetMinimapWidget
{
	struct AController* Controller;  // 0x0(0x8)
	struct UDFMinimap* MinimapWidget;  // 0x8(0x8)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UDFMinimap* CallFunc_GetMinimapWidget_MinimapWidget;  // 0x20(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidLoadout
// Size: 0x23(Inherited: 0x0) 
struct FGetMostValidLoadout
{
	struct UHDKit* PlayerLoadout;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x10(0x8)
	struct AHDPlayerState* K2Node_DynamicCast_AsHDPlayer_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x22(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetupVOIPTalker
// Size: 0x81(Inherited: 0x0) 
struct FSetupVOIPTalker
{
	struct FVoiceSettings SpatializedSettingsToUse;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct USoundAttenuation* Temp_object_Variable;  // 0x20(0x8)
	struct FVoiceSettings K2Node_MakeStruct_VoiceSettings;  // 0x28(0x18)
	struct USceneComponent* Temp_object_Variable_2;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)
	struct USoundAttenuation* K2Node_Select_Default;  // 0x50(0x8)
	struct USceneComponent* K2Node_Select_Default_2;  // 0x58(0x8)
	struct FVoiceSettings K2Node_MakeStruct_VoiceSettings_2;  // 0x60(0x18)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x78(0x8)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x80(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.AlignSights
// Size: 0x1DC(Inherited: 0x0) 
struct FAlignSights
{
	float MinSightDistance;  // 0x0(0x4)
	float SightDistance;  // 0x4(0x4)
	struct FVector Offset;  // 0x8(0xC)
	float ZRatio;  // 0x14(0x4)
	float YRatio;  // 0x18(0x4)
	float CallFunc_BreakVector_X;  // 0x1C(0x4)
	float CallFunc_BreakVector_Y;  // 0x20(0x4)
	float CallFunc_BreakVector_Z;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsReloading_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x39(0x1)
	char pad_58[2];  // 0x3A(0x2)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0x44(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x48(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x4C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x50(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float CallFunc_SelectFloat_ReturnValue_2;  // 0x64(0x4)
	char pad_104[8];  // 0x68(0x8)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x70(0x30)
	float CallFunc_FInterpTo_ReturnValue;  // 0xA0(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0xA4(0xC)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0xB0(0x4)
	struct FVector CallFunc_VInterp_To_Smooth_Return_Value;  // 0xB4(0xC)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_3;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct ADFBaseItem* CallFunc_GetRelevantEquippedItem_ReturnValue;  // 0xC8(0x8)
	struct ABP_HDWeaponBase_C* K2Node_DynamicCast_AsBP_HDWeapon_Base;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	struct FVector CallFunc_GetRightVector_ReturnValue;  // 0xDC(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xE8(0xC)
	struct FVector CallFunc_InverseTransformDirection_ReturnValue;  // 0xF4(0xC)
	struct FVector CallFunc_InverseTransformLocation_ReturnValue;  // 0x100(0xC)
	struct FVector CallFunc_VInterp_To_Smooth_Return_Value_2;  // 0x10C(0xC)
	float CallFunc_BreakVector_X_2;  // 0x118(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x11C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x120(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x124(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x128(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x12C(0xC)
	float CallFunc_FMax_ReturnValue;  // 0x138(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x13C(0xC)
	struct FVector CallFunc_VLerp_ReturnValue;  // 0x148(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x154(0x88)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CleanupVOIPTalker
// Size: 0x3(Inherited: 0x0) 
struct FCleanupVOIPTalker
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDestroyedComp : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.HealthRegenTimerElapsed
// Size: 0x11(Inherited: 0x0) 
struct FHealthRegenTimerElapsed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_FMin_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x10(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetHealthRegenTimerIfInvalid
// Size: 0x2C(Inherited: 0x0) 
struct FSetHealthRegenTimerIfInvalid
{
	float NewHealth;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_K2_IsTimerActiveHandle_ReturnValue : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x27(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0x2B(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ClearHealthRegenTimer
// Size: 0x1(Inherited: 0x0) 
struct FClearHealthRegenTimer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetPlayerFactionInfoClass
// Size: 0x29(Inherited: 0x0) 
struct FGetPlayerFactionInfoClass
{
	uint8_t  PlayerTeam;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	UBP_HDFactionInfoBase_C* FactionInfoClass;  // 0x8(0x8)
	struct AHDTeamState* CallFunc_GetHDTeamStateForTeam_HDTeamState;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	UBP_HDFactionInfoBase_C* K2Node_ClassDynamicCast_AsBP_HDFaction_Info_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsMatchingTeam
// Size: 0x10(Inherited: 0x0) 
struct FIsMatchingTeam
{
	struct AController* LocalController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bMatchingTeam : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x9(0x1)
	char CallFunc_GetTeamNum_ReturnValue;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xB(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xF(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.LeanDebug
// Size: 0x40(Inherited: 0x0) 
struct FLeanDebug
{
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FString CallFunc_Conv_RotatorToString_ReturnValue;  // 0x10(0x10)
	float CallFunc_GetLeanRollRot_ReturnValue;  // 0x20(0x4)
	float CallFunc_GetLeanYOffset_ReturnValue;  // 0x24(0x4)
	float CallFunc_GetLeanXOffset_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_IsLeaning_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x30(0x10)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SpawnAndInitDeployableSPAtPawn
// Size: 0xF0(Inherited: 0x0) 
struct FSpawnAndInitDeployableSPAtPawn
{
	ABP_HDProj_SPDeployableBase_C* SPDeployableClass;  // 0x0(0x8)
	struct FVector SpawnOffset;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct ABP_HDProj_SPDeployableBase_C* SpawnedDeployableSP;  // 0x18(0x8)
	float CallFunc_BreakVector_X;  // 0x20(0x4)
	float CallFunc_BreakVector_Y;  // 0x24(0x4)
	float CallFunc_BreakVector_Z;  // 0x28(0x4)
	struct FVector CallFunc_GetActorRightVector_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_GetActorUpVector_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x50(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x5C(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x68(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x74(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x80(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x8C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x98(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0xA4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xB0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xE0(0x8)
	struct ABP_HDProj_SPDeployableBase_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xE8(0x8)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SelectRadialMenuItem
// Size: 0x46(Inherited: 0x0) 
struct FSelectRadialMenuItem
{
	struct FName Category;  // 0x0(0x8)
	struct FName SubItem;  // 0x8(0x8)
	int32_t ItemIndex;  // 0x10(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x28(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x3C(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x45(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectSpot
// Size: 0x2(Inherited: 0x0) 
struct FRadialMenuSelectSpot
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_RadialMenuCanSelectSpot_bSelectable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectRallypoint
// Size: 0x55(Inherited: 0x0) 
struct FRadialMenuSelectRallypoint
{
	ABP_HDProj_RallyPointBase_C* RallypointType;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x8(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_CalcRallypointEnemiesNearbyRestriction_bAreEnemiesNearby : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xB(0x1)
	char pad_12[4];  // 0xC(0x4)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsRallypointNumberLimitReached_bNumberLimitReached : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_CalcRallypointDistanceRestriction_bIsRallypointDistanceRestricted : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	ABP_HDProj_RallyPointBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Rally_Point_Base;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct ABP_HDProj_SPDeployableBase_C* CallFunc_SpawnAndInitDeployableSPAtPawn_SpawnedDeployableSP;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_GetIsSpawnedRallypointValid_bIsSpawnedRallypointValid : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	float CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_RadialMenuCanSelectRallypoint_bSelectable : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x54(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectRallypoint
// Size: 0x7(Inherited: 0x0) 
struct FRadialMenuCanSelectRallypoint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelectable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasSquadLeaderKit_bUsingSquadLeaderKit : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsSquadLeader_bSquadLeader : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_CanSelectAnyRadialMenuOption_bSelectable : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x6(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcRallypointDistanceRestriction
// Size: 0xA1(Inherited: 0x0) 
struct FCalcRallypointDistanceRestriction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsRallypointDistanceRestricted : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float DistanceRestrictionSquared;  // 0x4(0x4)
	struct FVector PlayerLocation;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	ABP_HDProj_RallyPointBase_C* RallyPointClass;  // 0x18(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct AHDSquadState* CallFunc_GetSquadState_SquadState;  // 0x30(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct TArray<struct ABP_HDProj_RallyPointBase_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x40(0x10)
	struct ABP_HDProj_RallyPointBase_C* CallFunc_Array_Get_Item;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x5C(0xC)
	float CallFunc_Vector_DistanceSquared_ReturnValue;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x6D(0x1)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x6E(0x1)
	char pad_111[1];  // 0x6F(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x75(0x1)
	char pad_118[2];  // 0x76(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x78(0xC)
	char CallFunc_GetValidValue_ReturnValue;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x88(0x8)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0x90(0x8)
	ABP_HDProj_RallyPointBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Rally_Point_Base;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xA0(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectOutpost
// Size: 0x7(Inherited: 0x0) 
struct FRadialMenuCanSelectOutpost
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelectable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasSquadLeaderKit_bUsingSquadLeaderKit : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsSquadLeader_bSquadLeader : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_CanSelectAnyRadialMenuOption_bSelectable : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x6(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CanSelectAnyRadialMenuOption
// Size: 0x12(Inherited: 0x0) 
struct FCanSelectAnyRadialMenuOption
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSelectable : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x11(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsSquadLeader
// Size: 0x1B(Inherited: 0x0) 
struct FIsSquadLeader
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSquadLeader : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerState* CallFunc_GetMostValidPlayerState_PlayerState;  // 0x8(0x8)
	struct AHDSquadState* CallFunc_GetSquadState_SquadState;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1A(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.HasSquadLeaderKit
// Size: 0x6(Inherited: 0x0) 
struct FHasSquadLeaderKit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRequireRallyPointAbility : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bUsingSquadLeaderKit : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnRep_bSpatializedVOIPTalker
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_bSpatializedVOIPTalker
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_UpdateSettingsUsageForNextBeginTalk_bSettingsUpdated : 1;  // 0x0(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetSuppressionCompIsActive
// Size: 0xD(Inherited: 0x0) 
struct FSetSuppressionCompIsActive
{
	struct UPrimitiveComponent* PrimComp;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bNewActive : 1;  // 0x8(0x1)
	char ECollisionEnabled Temp_byte_Variable;  // 0x9(0x1)
	char ECollisionEnabled Temp_byte_Variable_2;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool Temp_bool_Variable : 1;  // 0xB(0x1)
	char ECollisionEnabled K2Node_Select_Default;  // 0xC(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMountPosition
// Size: 0x34A(Inherited: 0x0) 
struct FGetMountPosition
{
	struct FVector Direction;  // 0x0(0xC)
	float WallDistance;  // 0xC(0x4)
	float TraceRadius;  // 0x10(0x4)
	float CornerDistance;  // 0x14(0x4)
	float CapsuleHeight;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bCouldMount : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FVector Position;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)
	struct FTransform Transform;  // 0x30(0x30)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x60(0x10)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x70(0xC)
	char pad_124[4];  // 0x7C(0x4)
	struct TArray<struct AActor*> Temp_object_Variable_2;  // 0x80(0x10)
	struct FVector CallFunc_GetActorEyesViewPoint_OutLocation;  // 0x90(0xC)
	struct FRotator CallFunc_GetActorEyesViewPoint_OutRotation;  // 0x9C(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0xA8(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xB4(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xC0(0xC)
	struct FHitResult CallFunc_CapsuleTraceSingle_OutHit;  // 0xCC(0x88)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool CallFunc_CapsuleTraceSingle_ReturnValue : 1;  // 0x154(0x1)
	char pad_341_1 : 7;  // 0x155(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x155(0x1)
	char pad_342_1 : 7;  // 0x156(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x156(0x1)
	char pad_343[1];  // 0x157(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x158(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x15C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x160(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x16C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x178(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x184(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x190(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x198(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x1A0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x1A8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x1B0(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x1B4(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x1B8(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x1C4(0xC)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1D0(0x1)
	char pad_465[3];  // 0x1D1(0x3)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x1D4(0xC)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1E0(0x1)
	char pad_481[3];  // 0x1E1(0x3)
	struct FRotator CallFunc_MakeRotFromXZ_ReturnValue;  // 0x1E4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x1F0(0x30)
	struct FVector CallFunc_TransformDirection_ReturnValue;  // 0x220(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x22C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x238(0xC)
	struct FHitResult CallFunc_SphereTraceSingle_OutHit;  // 0x244(0x88)
	char pad_716_1 : 7;  // 0x2CC(0x1)
	bool CallFunc_SphereTraceSingle_ReturnValue : 1;  // 0x2CC(0x1)
	char pad_717_1 : 7;  // 0x2CD(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_2 : 1;  // 0x2CD(0x1)
	char pad_718_1 : 7;  // 0x2CE(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_2 : 1;  // 0x2CE(0x1)
	char pad_719[1];  // 0x2CF(0x1)
	float CallFunc_BreakHitResult_Time_2;  // 0x2D0(0x4)
	float CallFunc_BreakHitResult_Distance_2;  // 0x2D4(0x4)
	struct FVector CallFunc_BreakHitResult_Location_2;  // 0x2D8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_2;  // 0x2E4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_2;  // 0x2F0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_2;  // 0x2FC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_2;  // 0x308(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_2;  // 0x310(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_2;  // 0x318(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_2;  // 0x320(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_2;  // 0x328(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_2;  // 0x32C(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_2;  // 0x330(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_2;  // 0x33C(0xC)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x348(0x1)
	char pad_841_1 : 7;  // 0x349(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x349(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetProneMountPosition
// Size: 0x1E8(Inherited: 0x0) 
struct FGetProneMountPosition
{
	struct FVector BoxSize;  // 0x0(0xC)
	float Distance;  // 0xC(0x4)
	float MaxHeight;  // 0x10(0x4)
	float MinHeight;  // 0x14(0x4)
	float MinSpace;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bCouldMount : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FVector MountPosition;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x30(0x10)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x4C(0xC)
	struct FVector CallFunc_GetActorEyesViewPoint_OutLocation;  // 0x58(0xC)
	struct FRotator CallFunc_GetActorEyesViewPoint_OutRotation;  // 0x64(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x70(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x7C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x88(0xC)
	float CallFunc_BreakVector_X;  // 0x94(0x4)
	float CallFunc_BreakVector_Y;  // 0x98(0x4)
	float CallFunc_BreakVector_Z;  // 0x9C(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0xA0(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0xAC(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0xB8(0xC)
	struct FHitResult CallFunc_BoxTraceSingle_OutHit;  // 0xC4(0x88)
	char pad_332_1 : 7;  // 0x14C(0x1)
	bool CallFunc_BoxTraceSingle_ReturnValue : 1;  // 0x14C(0x1)
	char pad_333_1 : 7;  // 0x14D(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x14D(0x1)
	char pad_334_1 : 7;  // 0x14E(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x14E(0x1)
	char pad_335[1];  // 0x14F(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x150(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x154(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x158(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x164(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x170(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x17C(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x188(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x190(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x198(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x1A0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x1A8(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x1AC(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x1B0(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x1BC(0xC)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1C8(0x1)
	char pad_457[3];  // 0x1C9(0x3)
	float CallFunc_BreakVector_X_2;  // 0x1CC(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x1D0(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x1D4(0x4)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1D8(0x1)
	char pad_473[3];  // 0x1D9(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x1DC(0xC)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetIsSpawnedOutpostValid
// Size: 0x2(Inherited: 0x0) 
struct FGetIsSpawnedOutpostValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsSpawnedOutpostValid : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetIsSpawnedRallypointValid
// Size: 0x2(Inherited: 0x0) 
struct FGetIsSpawnedRallypointValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsSpawnedRallypointValid : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsRallypointNumberLimitReached
// Size: 0x59(Inherited: 0x0) 
struct FIsRallypointNumberLimitReached
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNumberLimitReached : 1;  // 0x0(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x8(0x8)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0x10(0x8)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue_2;  // 0x18(0x8)
	ABP_HDProj_RallyPointBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Rally_Point_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	ABP_HDProj_RallyPointBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Rally_Point_Base_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TArray<struct ABP_HDProj_RallyPointBase_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsOutpostNumberLimitReached
// Size: 0x59(Inherited: 0x0) 
struct FIsOutpostNumberLimitReached
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNumberLimitReached : 1;  // 0x0(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x8(0x8)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0x10(0x8)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue_2;  // 0x18(0x8)
	ABP_HDProj_OutpostBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Outpost_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	ABP_HDProj_OutpostBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Outpost_Base_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TArray<struct ABP_HDProj_OutpostBase_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcRallypointEnemiesNearbyRestriction
// Size: 0xC1(Inherited: 0x0) 
struct FCalcRallypointEnemiesNearbyRestriction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAreEnemiesNearby : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t MaxNumberofEnemies;  // 0x4(0x4)
	int32_t NumberOfEnemyChars;  // 0x8(0x4)
	float EnemyRadius;  // 0xC(0x4)
	struct FVector PlayerLocation;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	ABP_HDProj_RallyPointBase_C* RallyPointClass;  // 0x20(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x38(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x48(0x4)
	int32_t Temp_int_Variable;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x52(0x1)
	char pad_83[1];  // 0x53(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x54(0xC)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x60(0x10)
	struct TArray<struct AActor*> CallFunc_SphereOverlapActors_OutActors;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_SphereOverlapActors_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct AActor* CallFunc_Array_Get_Item;  // 0x88(0x8)
	char CallFunc_GetValidValue_ReturnValue;  // 0x90(0x1)
	char CallFunc_GetTeamNum_ReturnValue_2;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x92(0x1)
	char pad_147[5];  // 0x93(0x5)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0x98(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	ABP_HDProj_RallyPointBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Rally_Point_Base;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xC0(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcOutpostEnemiesNearbyRestriction
// Size: 0xB9(Inherited: 0x0) 
struct FCalcOutpostEnemiesNearbyRestriction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAreEnemiesNearby : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t MaxNumberofEnemies;  // 0x4(0x4)
	int32_t NumberOfEnemyChars;  // 0x8(0x4)
	float EnemyRadius;  // 0xC(0x4)
	struct FVector PlayerLocation;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	ABP_HDProj_OutpostBase_C* OutpostClass;  // 0x20(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x38(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x48(0x4)
	int32_t Temp_int_Variable;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x58(0x10)
	struct TArray<struct AActor*> CallFunc_SphereOverlapActors_OutActors;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_SphereOverlapActors_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct AActor* CallFunc_Array_Get_Item;  // 0x80(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	char CallFunc_GetTeamNum_ReturnValue_2;  // 0x8C(0x1)
	char pad_141_1 : 7;  // 0x8D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x8D(0x1)
	char pad_142_1 : 7;  // 0x8E(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x8E(0x1)
	char pad_143[1];  // 0x8F(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x90(0xC)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x9C(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x9D(0x1)
	char pad_158[2];  // 0x9E(0x2)
	UBP_HDFactionInfoBase_C* CallFunc_GetPlayerFactionInfoClass_FactionInfoClass;  // 0xA0(0x8)
	UObject* CallFunc_Conv_SoftClassReferenceToClass_ReturnValue;  // 0xA8(0x8)
	ABP_HDProj_OutpostBase_C* K2Node_ClassDynamicCast_AsBP_HDProj_Outpost_Base;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xB8(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EventGetFocalPoint
// Size: 0x5C(Inherited: 0x0) 
struct FEventGetFocalPoint
{
	struct FVector ReturnValue;  // 0x0(0xC)
	struct FVector CallFunc_GetTargetLocation_ReturnValue;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1C(0xC)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_BreakVector_X;  // 0x2C(0x4)
	float CallFunc_BreakVector_Y;  // 0x30(0x4)
	float CallFunc_BreakVector_Z;  // 0x34(0x4)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x38(0xC)
	float CallFunc_BreakVector_X_2;  // 0x44(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x48(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x4C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x50(0xC)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetSuppressionActive
// Size: 0x1(Inherited: 0x0) 
struct FSetSuppressionActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bActive : 1;  // 0x0(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetPCViewRotationYawLimits
// Size: 0x29(Inherited: 0x0) 
struct FSetPCViewRotationYawLimits
{
	float ViewYawMin;  // 0x0(0x4)
	float ViewYawMax;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bRelativeToActorRotation : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RestorePCViewRotationYawLimits
// Size: 0x19(Inherited: 0x0) 
struct FRestorePCViewRotationYawLimits
{
	struct AController* CallFunc_GetController_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABP_HDPlayerControllerBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Controller_Base;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
