#pragma once 
#include <BP_MenuPC_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MenuPC.BP_MenuPC_C
// Size: 0x6A0(Inherited: 0x6A0) 
struct ABP_MenuPC_C : public AHDPlayerController
{

}; 



