#pragma once 
#include "SDK.h" 
 
 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateProgressBarColor
// Size: 0x28(Inherited: 0x0) 
struct FUpdateProgressBarColor
{
	uint8_t  OwningTeam;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AHDPlayerController* CallFunc_GetOwningHDPlayer_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x10(0x1)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x18(0x10)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.ExecuteUbergraph_WBP_CaptureStatus
// Size: 0xB0(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_CaptureStatus
{
	int32_t EntryPoint;  // 0x0(0x4)
	float Temp_float_Variable;  // 0x4(0x4)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct AHDBaseCapturePoint* K2Node_Event_OverlappingCP;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_Event_bInitial_4 : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x20(0x18)
	float CallFunc_GetEndTime_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_Event_bContested : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	float K2Node_Event_NewValueNorm;  // 0x4C(0x4)
	float K2Node_Event_OldValueNorm;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool K2Node_Event_bInitial_3 : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool K2Node_Event_bCaptured : 1;  // 0x55(0x1)
	uint8_t  K2Node_Event_NewOwningTeam;  // 0x56(0x1)
	uint8_t  K2Node_Event_OldOwningTeam;  // 0x57(0x1)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_Event_bInitial_2 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t K2Node_Event_NumFriendlies;  // 0x5C(0x4)
	int32_t K2Node_Event_NumEnemies;  // 0x60(0x4)
	int32_t K2Node_Event_MinNumRequiredForCapture;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_Event_bInitial : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x6A(0x1)
	char pad_107_1 : 7;  // 0x6B(0x1)
	bool Temp_bool_Variable : 1;  // 0x6B(0x1)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	float K2Node_Select_Default;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x78(0x8)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x80(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x84(0x4)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct UWBP_CaptureStatus_UnitIcon_C* CallFunc_Create_ReturnValue;  // 0x90(0x8)
	struct FLinearColor K2Node_Select_Default_2;  // 0x98(0x10)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue;  // 0xA8(0x8)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetGarrisonedPlayerCount
// Size: 0xD(Inherited: 0x10) 
struct FControlPointSetGarrisonedPlayerCount : public FControlPointSetGarrisonedPlayerCount
{
	int32_t NumFriendlies;  // 0x0(0x4)
	int32_t NumEnemies;  // 0x4(0x4)
	int32_t MinNumRequiredForCapture;  // 0x8(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bInitial : 1;  // 0xC(0x1)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.OwnerTouchingControlPoint
// Size: 0x9(Inherited: 0x10) 
struct FOwnerTouchingControlPoint : public FOwnerTouchingControlPoint
{
	struct AHDBaseCapturePoint* OverlappingCP;  // 0x0(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bInitial : 1;  // 0x8(0x1)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetOwnershipState
// Size: 0x4(Inherited: 0x4) 
struct FControlPointSetOwnershipState : public FControlPointSetOwnershipState
{
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bCaptured : 1;  // 0x0(0x1)
	uint8_t  NewOwningTeam;  // 0x1(0x1)
	uint8_t  OldOwningTeam;  // 0x2(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool bInitial : 1;  // 0x3(0x1)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.ControlPointSetCaptureProgress
// Size: 0xD(Inherited: 0x10) 
struct FControlPointSetCaptureProgress : public FControlPointSetCaptureProgress
{
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bContested : 1;  // 0x0(0x1)
	float NewValueNorm;  // 0x4(0x4)
	float OldValueNorm;  // 0x8(0x4)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bInitial : 1;  // 0xC(0x1)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateTeamOwnerText
// Size: 0xC0(Inherited: 0x0) 
struct FUpdateTeamOwnerText
{
	uint8_t  CaptureTeam;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FText Temp_text_Variable_2;  // 0x28(0x18)
	uint8_t  Temp_byte_Variable;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FText Temp_text_Variable_3;  // 0x48(0x18)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct AHDGameState* CallFunc_GetHDGameState_HDGameState;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue_2 : 1;  // 0x71(0x1)
	char pad_114[6];  // 0x72(0x6)
	struct FText K2Node_Select_Default;  // 0x78(0x18)
	struct FText K2Node_Select_Default_2;  // 0x90(0x18)
	struct FText K2Node_Select_Default_3;  // 0xA8(0x18)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.ResizeGarrisonContainer
// Size: 0x35(Inherited: 0x0) 
struct FResizeGarrisonContainer
{
	int32_t NewUnitIconCount;  // 0x0(0x4)
	int32_t CallFunc_Max_ReturnValue;  // 0x4(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_RemoveChildAt_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_GetChildrenCount_ReturnValue_2;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UWBP_CaptureStatus_UnitIcon_C* CallFunc_Create_ReturnValue;  // 0x20(0x8)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue;  // 0x28(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue_3;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x34(0x1)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.SetMinCountToCapture
// Size: 0xD(Inherited: 0x0) 
struct FSetMinCountToCapture
{
	int32_t MinCount;  // 0x0(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x4(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0xC(0x1)

}; 
// Function WBP_CaptureStatus.WBP_CaptureStatus_C.UpdateActiveUnits
// Size: 0x8C(Inherited: 0x0) 
struct FUpdateActiveUnits
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFriendly : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t UnitCount;  // 0x4(0x4)
	int32_t MinUnitsRequired;  // 0x8(0x4)
	uint8_t  Temp_byte_Variable;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	int32_t Temp_int_Variable;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x1E(0x1)
	char pad_31[1];  // 0x1F(0x1)
	int32_t Temp_int_Variable_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x24(0x1)
	char ECaptureUnitType Temp_byte_Variable_2;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	int32_t K2Node_Select_Default;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x2C(0x1)
	char ECaptureUnitType Temp_byte_Variable_3;  // 0x2D(0x1)
	char ECaptureUnitType Temp_byte_Variable_4;  // 0x2E(0x1)
	char pad_47[1];  // 0x2F(0x1)
	int32_t Temp_int_Variable_3;  // 0x30(0x4)
	uint8_t  Temp_byte_Variable_5;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x3C(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x40(0x4)
	int32_t K2Node_Select_Default_2;  // 0x44(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_3;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	int32_t K2Node_Select_Default_3;  // 0x50(0x4)
	int32_t K2Node_Select_Default_4;  // 0x54(0x4)
	uint8_t  K2Node_Select_Default_5;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x59(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool Temp_bool_Variable_9 : 1;  // 0x5B(0x1)
	int32_t K2Node_Select_Default_6;  // 0x5C(0x4)
	char ECaptureUnitType K2Node_Select_Default_7;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_4;  // 0x64(0x4)
	int32_t CallFunc_Abs_Int_ReturnValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct UWidget* CallFunc_GetChildAt_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UWBP_CaptureStatus_UnitIcon_C* K2Node_DynamicCast_AsWBP_Capture_Status_Unit_Icon;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	char ECaptureUnitType K2Node_Select_Default_8;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x8A(0x1)
	uint8_t  K2Node_Select_Default_9;  // 0x8B(0x1)

}; 
