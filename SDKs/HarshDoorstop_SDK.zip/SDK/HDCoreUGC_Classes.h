#pragma once 
#include <HDCoreUGC_Structs.h>
 
 
 
// Class HDCoreUGC.HDCoreUGCSubsystem
// Size: 0x110(Inherited: 0x30) 
struct UHDCoreUGCSubsystem : public UEngineSubsystem
{
	char pad_48[48];  // 0x30(0x30)
	struct TMap<struct FString, struct UHDCoreUGCPluginStateMachine*> UGCPluginStateMachines;  // 0x60(0x50)
	char pad_176[80];  // 0xB0(0x50)
	struct UHDCoreUGCProjectPolicies* GameSpecificPolicies;  // 0x100(0x8)
	char pad_264[8];  // 0x108(0x8)

}; 



// Class HDCoreUGC.HDCoreUGCData
// Size: 0x30(Inherited: 0x30) 
struct UHDCoreUGCData : public UPrimaryDataAsset
{

}; 



// Class HDCoreUGC.HDCoreUGCProjectPolicies
// Size: 0x28(Inherited: 0x28) 
struct UHDCoreUGCProjectPolicies : public UObject
{

}; 



// Class HDCoreUGC.HDCoreDefaultUGCProjectPolicies
// Size: 0x28(Inherited: 0x28) 
struct UHDCoreDefaultUGCProjectPolicies : public UHDCoreUGCProjectPolicies
{

}; 



// Class HDCoreUGC.HDCoreUGCPluginStateMachine
// Size: 0x208(Inherited: 0x28) 
struct UHDCoreUGCPluginStateMachine : public UObject
{
	char pad_40[32];  // 0x28(0x20)
	struct FHDCoreUGCPluginStateMachineProperties StateProperties;  // 0x48(0xE8)
	char pad_304[216];  // 0x130(0xD8)

}; 



// Class HDCoreUGC.HDCoreUGCSubsystemSettings
// Size: 0x80(Inherited: 0x38) 
struct UHDCoreUGCSubsystemSettings : public UDeveloperSettings
{
	struct FSoftClassPath UGCManagerClassName;  // 0x38(0x18)
	struct TArray<struct FString> DisabledPlugins;  // 0x50(0x10)
	struct TArray<struct FString> AdditionalPluginMetadataKeys;  // 0x60(0x10)
	char pad_112[16];  // 0x70(0x10)

}; 



