#pragma once 
#include <BP_HDWeaponBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDWeaponBase.BP_HDWeaponBase_C
// Size: 0xA54(Inherited: 0x870) 
struct ABP_HDWeaponBase_C : public AHDBaseWeapon
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x870(0x8)
	struct USceneComponent* Muzzle;  // 0x878(0x8)
	struct USceneComponent* DefaultBipod;  // 0x880(0x8)
	struct USceneComponent* DefaultGrip;  // 0x888(0x8)
	struct USceneComponent* DefaultBarrel;  // 0x890(0x8)
	struct USceneComponent* DefaultSight;  // 0x898(0x8)
	struct TMap<struct FName, struct UAnimSequenceBase*> LocoAnimSet;  // 0x8A0(0x50)
	struct TMap<struct FName, struct UAnimSequenceBase*> LocoTPPAnimSet;  // 0x8F0(0x50)
	char pad_2368_1 : 7;  // 0x940(0x1)
	bool bUseMirroredLowerBodyLocomotion : 1;  // 0x940(0x1)
	char pad_2369[3];  // 0x941(0x3)
	struct FVector FirstPersonPositionOffset;  // 0x944(0xC)
	char pad_2384_1 : 7;  // 0x950(0x1)
	bool bHasGrip : 1;  // 0x950(0x1)
	char pad_2385_1 : 7;  // 0x951(0x1)
	bool bHasBipod : 1;  // 0x951(0x1)
	char pad_2386[2];  // 0x952(0x2)
	struct FVector BracedAimPosition;  // 0x954(0xC)
	struct USceneComponent* CurrentSight;  // 0x960(0x8)
	struct USceneComponent* CurrentBarrel;  // 0x968(0x8)
	struct USceneComponent* CurrentGrip;  // 0x970(0x8)
	struct USceneComponent* CurrentBipod;  // 0x978(0x8)
	struct TArray<struct USceneComponent*> Sights;  // 0x980(0x10)
	struct FMulticastInlineDelegate OnUpdateAttachments;  // 0x990(0x10)
	float ADSOffset;  // 0x9A0(0x4)
	float BipodPlayerDistance;  // 0x9A4(0x4)
	float BipodCameraHeight;  // 0x9A8(0x4)
	char pad_2476[4];  // 0x9AC(0x4)
	UCameraShake* FiringScreenShake;  // 0x9B0(0x8)
	float BracedAimTilt;  // 0x9B8(0x4)
	struct FVector ThirdPersonPositionOffset;  // 0x9BC(0xC)
	struct FVector ThirdPersonAimOffset;  // 0x9C8(0xC)
	float KickAmount;  // 0x9D4(0x4)
	float KickNoiseAmount;  // 0x9D8(0x4)
	char pad_2524[4];  // 0x9DC(0x4)
	struct TArray<struct FName> BasePoseBonesToHide;  // 0x9E0(0x10)
	struct FName SecondMagBoneName;  // 0x9F0(0x8)
	struct FName BulletBoneName;  // 0x9F8(0x8)
	struct FRotator LowReadyRotationOffset;  // 0xA00(0xC)
	struct FVector LowReadyPositionOffset;  // 0xA0C(0xC)
	struct FMulticastInlineDelegate OnUpdateSights;  // 0xA18(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> ThirdPersonMatArray;  // 0xA28(0x10)
	float AmmoPercent;  // 0xA38(0x4)
	char pad_2620[4];  // 0xA3C(0x4)
	struct TArray<struct UMaterialInstanceDynamic*> FirstPersonMatArray;  // 0xA40(0x10)
	float ResetAmmoPercentTime;  // 0xA50(0x4)

	void ShouldUseMirroredLowerBodyLoco(bool& bOutUseMirrored); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ShouldUseMirroredLowerBodyLoco
	void GetLocoTPPAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.GetLocoTPPAnimSet
	void GetLocoAnimSet(struct TMap<struct FName, struct UAnimSequenceBase*>& OutAnimSet); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.GetLocoAnimSet
	void SetAmmoPercent(struct ADFBaseAmmoClip* FromAmmoClip); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.SetAmmoPercent
	void OnRep_AmmoPercent(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.OnRep_AmmoPercent
	void FindNextMagazine(struct ADFBaseAmmoClip*& NextClip); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.FindNextMagazine
	bool CanFire(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.CanFire
	void InternalSetVisibilityForAttachment(struct USceneComponent* Attachment, bool bFirstPerson); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.InternalSetVisibilityForAttachment
	void UpdateAttachmentVisibility(bool bFirstPerson); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.UpdateAttachmentVisibility
	bool RemoveLegacyLocomotionAnims(bool bFPP); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.RemoveLegacyLocomotionAnims
	struct TMap<struct FName, struct UAnimSequenceBase*> GetLegacyLocomotionAnims(bool bFPP); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.GetLegacyLocomotionAnims
	void UserConstructionScript(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.UserConstructionScript
	void CycleSight(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.CycleSight
	void SetCurrentSight(struct USceneComponent* Sight); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.SetCurrentSight
	void ReceiveFire(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveFire
	void ReceiveVisibilityChanged(bool bFirstPerson); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveVisibilityChanged
	void ReceiveOnEquip(struct ADFBaseItem* LastItem); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveOnEquip
	void ResetBullets(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ResetBullets
	void ReceiveReloadFinished(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ReceiveReloadFinished
	void ServerResetAmmoPercent(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ServerResetAmmoPercent
	void ExecuteUbergraph_BP_HDWeaponBase(int32_t EntryPoint); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.ExecuteUbergraph_BP_HDWeaponBase
	void OnUpdateSights__DelegateSignature(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.OnUpdateSights__DelegateSignature
	void OnUpdateAttachments__DelegateSignature(); // Function BP_HDWeaponBase.BP_HDWeaponBase_C.OnUpdateAttachments__DelegateSignature
}; 



