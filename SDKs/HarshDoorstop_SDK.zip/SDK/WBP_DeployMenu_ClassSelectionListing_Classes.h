#pragma once 
#include <WBP_DeployMenu_ClassSelectionListing_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C
// Size: 0xA18(Inherited: 0x230) 
struct UWBP_DeployMenu_ClassSelectionListing_C : public UDeployMenu_ClassSelectionListing
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* ClassBg;  // 0x238(0x8)
	struct UTextBlock* ClassNameText;  // 0x240(0x8)
	struct UTextBlock* ClassRestrictedText;  // 0x248(0x8)
	struct UImage* ClassSymbol;  // 0x250(0x8)
	struct UUniformGridPanel* EqpGrid;  // 0x258(0x8)
	struct UImage* EqpSlot1;  // 0x260(0x8)
	struct UImage* EqpSlot2;  // 0x268(0x8)
	struct UImage* EqpSlot3;  // 0x270(0x8)
	struct UImage* EqpSlot4;  // 0x278(0x8)
	struct UImage* EqpSlot5;  // 0x280(0x8)
	struct UImage* EqpSlot6;  // 0x288(0x8)
	struct UImage* EqpSlot7;  // 0x290(0x8)
	struct UImage* EqpSlot8;  // 0x298(0x8)
	struct UImage* Image_11;  // 0x2A0(0x8)
	struct UImage* Image_12;  // 0x2A8(0x8)
	struct UImage* Image_13;  // 0x2B0(0x8)
	struct UImage* Image_14;  // 0x2B8(0x8)
	struct UImage* PrimaryWeaponIcon;  // 0x2C0(0x8)
	struct UOverlay* RestrictedOverlay;  // 0x2C8(0x8)
	struct UButton* SelectClassBtn;  // 0x2D0(0x8)
	struct UHDKit* Kit;  // 0x2D8(0x8)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool bListingInitialized : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)
	struct ABP_HDPlayerControllerBase_C* HDOwningPlayer;  // 0x2E8(0x8)
	struct FMulticastInlineDelegate OnClassSelected;  // 0x2F0(0x10)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool bSelected : 1;  // 0x300(0x1)
	char pad_769_1 : 7;  // 0x301(0x1)
	bool bRestricted : 1;  // 0x301(0x1)
	char pad_770[6];  // 0x302(0x6)
	struct FMulticastInlineDelegate OnClassDeselected;  // 0x308(0x10)
	struct FSlateBrush DefaultDisplaySymbolBrush;  // 0x318(0x88)
	struct FLinearColor NoSymbolColor;  // 0x3A0(0x10)
	struct FText DefaultDisplayNameText;  // 0x3B0(0x18)
	struct FButtonStyle SelectedBtnStyle;  // 0x3C8(0x278)
	struct FButtonStyle DeselectedBtnStyle;  // 0x640(0x278)
	struct FSlateColor ClassSymbolDisabledTint;  // 0x8B8(0x28)
	struct FSlateColor ClassSymbolEnabledTint;  // 0x8E0(0x28)
	struct TArray<struct FHDItemEntry> KitItemEntries;  // 0x908(0x10)
	struct FSlateBrush DefaultEqpSymbolBrush;  // 0x918(0x88)
	struct FLinearColor DefaultEqpSymbolColor;  // 0x9A0(0x10)
	struct FSlateColor RestrictedTextColor;  // 0x9B0(0x28)
	struct FSlateColor UnrestrictedTextColor;  // 0x9D8(0x28)
	struct FText KitLimitationDisplayText;  // 0xA00(0x18)

	void AreColorsNearlyEqual(struct FLinearColor ColorOne, struct FLinearColor ColorTwo, bool& bEqual); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.AreColorsNearlyEqual
	void InternalFillEqpSlots(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalFillEqpSlots
	void SortItemEntriesInPlaceBySlotNum(struct TArray<struct FHDItemEntry>& EntriesToSort); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SortItemEntriesInPlaceBySlotNum
	void InternalSetEqpDisplaySymbolBySlotNum(int32_t SlotNum, struct UTexture2D* SlotSymbolToUse, bool bDesignTime); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetEqpDisplaySymbolBySlotNum
	void InternalSetupKitDisplayEqpSlots(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplayEqpSlots
	void InternalGetEqpSlotImageWidgetByNum(int32_t SlotNum, struct UImage*& EqpSlotImage); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalGetEqpSlotImageWidgetByNum
	void InternalSetClassRestrictedState(bool bNewRestricted, struct FText& NewRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetClassRestrictedState
	void InternalUpdateClassRestrictedText(bool bKitRestricted, struct FText& KitRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalUpdateClassRestrictedText
	void InternalSetupKitRestrictionDisplay(bool bKitRestricted, struct FText& KitRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitRestrictionDisplay
	void InternalIsKitRestricted(bool& bKitRestricted, struct FText& KitRestrictionReason); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalIsKitRestricted
	void InternalSetupKitDisplayName(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplayName
	void InternalSetupKitDisplaySymbol(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupKitDisplaySymbol
	void SetSelected(bool bSelected); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SetSelected
	void ToggleClassSelection(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.ToggleClassSelection
	void InternalSetClassSelectionState(bool bNewSelected); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetClassSelectionState
	void DeselectClass(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.DeselectClass
	void SelectClass(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.SelectClass
	void InternalSetupPrimaryWeaponIcon(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalSetupPrimaryWeaponIcon
	void UpdateRestrictedState(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.UpdateRestrictedState
	void InternalKitDisplaySetup(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.InternalKitDisplaySetup
	void Init(struct UHDKit* Kit, struct ABP_HDPlayerControllerBase_C* OwningPC); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.Init
	void BndEvt__SelectClassBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.BndEvt__SelectClassBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.PreConstruct
	void Construct(); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.Construct
	void ExecuteUbergraph_WBP_DeployMenu_ClassSelectionListing(int32_t EntryPoint); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.ExecuteUbergraph_WBP_DeployMenu_ClassSelectionListing
	void OnClassDeselected__DelegateSignature(struct UWBP_DeployMenu_ClassSelectionListing_C* DeselectedClassWidget); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.OnClassDeselected__DelegateSignature
	void OnClassSelected__DelegateSignature(struct UWBP_DeployMenu_ClassSelectionListing_C* SelectedClassWidget); // Function WBP_DeployMenu_ClassSelectionListing.WBP_DeployMenu_ClassSelectionListing_C.OnClassSelected__DelegateSignature
}; 



