#pragma once 
#include <BP_HDKitPickupBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDKitPickupBase.BP_HDKitPickupBase_C
// Size: 0x278(Inherited: 0x278) 
struct ABP_HDKitPickupBase_C : public AHDBasePickup_Kit
{

	void UserConstructionScript(); // Function BP_HDKitPickupBase.BP_HDKitPickupBase_C.UserConstructionScript
}; 



