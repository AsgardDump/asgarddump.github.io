#pragma once 
#include <WBP_FactionGameModifierSettings_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C
// Size: 0x278(Inherited: 0x230) 
struct UWBP_FactionGameModifierSettings_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_ModifierSetting_ComboBox_C* FactionBlufor;  // 0x238(0x8)
	struct UWBP_ModifierSetting_ComboBox_C* FactionOpfor;  // 0x240(0x8)
	struct UWBP_ModifierSetting_CheckBox_C* KitRestrictionsToggle;  // 0x248(0x8)
	struct UWBP_GameModifierSettingsSection_C* SectionContainer;  // 0x250(0x8)
	struct UWBP_ModifierSetting_Numeric_C* TicketCountBlufor;  // 0x258(0x8)
	struct UWBP_ModifierSetting_Numeric_C* TicketCountOpfor;  // 0x260(0x8)
	struct TArray<struct FPrimaryAssetId> SelectableFactionAssetIds;  // 0x268(0x10)

	void GetTravelURLOptions(struct FString& Options); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.GetTravelURLOptions
	void IsEnabled(bool& bEnabled); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.IsEnabled
	void BuildTicketCountURLOption(uint8_t  Team, int32_t Count, struct FString& Pair); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.BuildTicketCountURLOption
	void BuildFactionURLOption(uint8_t  Team, struct FName PackageName, struct FString& Pair); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.BuildFactionURLOption
	void Completed_7DC7FCB348F23B6EEE29D0A8EBA2EF94(struct TArray<UObject*>& Loaded); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.Completed_7DC7FCB348F23B6EEE29D0A8EBA2EF94
	void SetupModifier(struct UWBP_OptionMenu_CreateGame_C* ParentMenu); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.SetupModifier
	void Destruct(); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.Destruct
	void ExecuteUbergraph_WBP_FactionGameModifierSettings(int32_t EntryPoint); // Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.ExecuteUbergraph_WBP_FactionGameModifierSettings
}; 



