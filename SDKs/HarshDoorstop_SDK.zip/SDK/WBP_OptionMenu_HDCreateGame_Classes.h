#pragma once 
#include <WBP_OptionMenu_HDCreateGame_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionMenu_HDCreateGame.WBP_OptionMenu_HDCreateGame_C
// Size: 0x368(Inherited: 0x368) 
struct UWBP_OptionMenu_HDCreateGame_C : public UWBP_OptionMenu_CreateGame_C
{

}; 



