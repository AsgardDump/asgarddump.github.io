#pragma once 
#include "SDK.h" 
 
 
// Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.WeaponUpperBody
// Size: 0x20(Inherited: 0x0) 
struct FWeaponUpperBody
{
	struct FPoseLink UpperBody;  // 0x0(0x10)
	struct FPoseLink WeaponUpperBody;  // 0x10(0x10)

}; 
// Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.WeaponAdditive
// Size: 0x10(Inherited: 0x0) 
struct FWeaponAdditive
{
	struct FPoseLink WeaponAdditive;  // 0x0(0x10)

}; 
// Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.Move
// Size: 0x20(Inherited: 0x0) 
struct FMove
{
	struct FPoseLink Move;  // 0x0(0x10)
	struct FPoseLink Move;  // 0x10(0x10)

}; 
// Function ABPI_WeaponAnimLayer.ABPI_WeaponAnimLayer_C.WeaponJumpLoop
// Size: 0x20(Inherited: 0x0) 
struct FWeaponJumpLoop
{
	struct FPoseLink LowerJumpLoop;  // 0x0(0x10)
	struct FPoseLink WeaponJumpLoop;  // 0x10(0x10)

}; 
