#pragma once 
#include <BP_HDVehicleBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDVehicleBase.BP_HDVehicleBase_C
// Size: 0x388(Inherited: 0x2C8) 
struct ABP_HDVehicleBase_C : public AArcBaseVehicle
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C8(0x8)
	struct UAudioComponent* EngineSound;  // 0x2D0(0x8)
	struct USkeletalMeshComponent* Mesh;  // 0x2D8(0x8)
	struct UWheeledVehicleMovementComponentNW* VehicleMovementOWI;  // 0x2E0(0x8)
	struct TMap<struct FName, struct UAnimSequenceBase*> DriverAnimSet;  // 0x2E8(0x50)
	struct TMap<struct FName, struct UAnimSequenceBase*> PassengerAnimSet;  // 0x338(0x50)

	void InpActEvt_Jump_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpActEvt_Jump_K2Node_InputActionEvent_3
	void InpActEvt_Jump_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpActEvt_Jump_K2Node_InputActionEvent_2
	void InpActEvt_Use_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpActEvt_Use_K2Node_InputActionEvent_1
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
	void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
	void Used(struct AActor* Invoker); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.Used
	void NotifyPlayerSeatChangeEvent(struct APlayerState* Player, struct UArcVehicleSeatConfig* ToSeat, struct UArcVehicleSeatConfig* FromSeat, uint8_t  SeatChangeEvent); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.NotifyPlayerSeatChangeEvent
	void ReceiveTick(float DeltaSeconds); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.ReceiveTick
	void ExecuteUbergraph_BP_HDVehicleBase(int32_t EntryPoint); // Function BP_HDVehicleBase.BP_HDVehicleBase_C.ExecuteUbergraph_BP_HDVehicleBase
}; 



