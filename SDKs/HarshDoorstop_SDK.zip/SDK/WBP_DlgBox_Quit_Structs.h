#pragma once 
#include "SDK.h" 
 
 
// Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.BndEvt__YesBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__YesBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature
{
	struct UWBP_DialogBox_Button_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.ExecuteUbergraph_WBP_DlgBox_Quit
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_DlgBox_Quit
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct UWBP_DialogBox_Button_C* K2Node_ComponentBoundEvent_ClickedBtn_2;  // 0x18(0x8)
	struct UWBP_DialogBox_Button_C* K2Node_ComponentBoundEvent_ClickedBtn;  // 0x20(0x8)

}; 
// Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.BndEvt__NoBtn_K2Node_ComponentBoundEvent_3_ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__NoBtn_K2Node_ComponentBoundEvent_3_ButtonClicked__DelegateSignature
{
	struct UWBP_DialogBox_Button_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.OnMouseButtonDown
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
