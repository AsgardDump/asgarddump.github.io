#pragma once 
#include <BP_Proj_DefaultWeap_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Proj_DefaultWeap.BP_Proj_DefaultWeap_C
// Size: 0x380(Inherited: 0x380) 
struct ABP_Proj_DefaultWeap_C : public ADFBaseProjectile
{

}; 



