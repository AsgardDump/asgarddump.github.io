#pragma once 
#include <Tinkerbox_Structs.h>
 
 
 
// Class Tinkerbox.TBGameInstance
// Size: 0x2D0(Inherited: 0x280) 
struct UTBGameInstance : public UDFBaseGameInstance
{
	struct UDFBaseMenu* MainMenu;  // 0x280(0x8)
	UDFBaseMenu* MainMenuClass;  // 0x288(0x8)
	struct FSoftClassPath MenuGameMode;  // 0x290(0x18)
	char bHidePlayerHUDInMainMenu : 1;  // 0x2A8(0x1)
	char bUseMenuBackgroundMaps : 1;  // 0x2A8(0x1)
	char pad_680_1 : 6;  // 0x2A8(0x1)
	char pad_681[8];  // 0x2A9(0x8)
	struct TArray<struct FSoftObjectPath> MenuBackgroundMaps;  // 0x2B0(0x10)
	char pad_704[8];  // 0x2C0(0x8)
	struct URCONServerSystem* RCONServerSystem;  // 0x2C8(0x8)

	void UnloadMainMenu(); // Function Tinkerbox.TBGameInstance.UnloadMainMenu
	void LoadMainMenu(bool bExclusive); // Function Tinkerbox.TBGameInstance.LoadMainMenu
	void HandleGoToMainMenu(); // Function Tinkerbox.TBGameInstance.HandleGoToMainMenu
	void GoToMainMenu(); // Function Tinkerbox.TBGameInstance.GoToMainMenu
	void GetGameBuildInfo(); // Function Tinkerbox.TBGameInstance.GetGameBuildInfo
	bool GetCurrentSessionHostAddressStr(struct FString& OutHostAddrStr, bool bPreferSteamP2PAddr, bool bAppendPort); // Function Tinkerbox.TBGameInstance.GetCurrentSessionHostAddressStr
}; 



// Class Tinkerbox.TBVoiceIndicator
// Size: 0x248(Inherited: 0x230) 
struct UTBVoiceIndicator : public UUserWidget
{
	UTBVoiceIndicatorListing* VoiceListingClass;  // 0x230(0x8)
	struct UPanelWidget* ActiveVoiceList;  // 0x238(0x8)
	int32_t MaxActiveVoices;  // 0x240(0x4)
	int32_t ActiveVoices;  // 0x244(0x4)

	void ActiveVoiceRemoved(struct APlayerState* PlayerState, struct UPanelSlot* NewVoiceWidget); // Function Tinkerbox.TBVoiceIndicator.ActiveVoiceRemoved
	void ActiveVoiceAdded(struct APlayerState* PlayerState, struct UPanelSlot* NewVoiceWidget); // Function Tinkerbox.TBVoiceIndicator.ActiveVoiceAdded
}; 



// Class Tinkerbox.TBLevelScriptActor
// Size: 0x228(Inherited: 0x228) 
struct ATBLevelScriptActor : public ADFLevelScriptActor
{

}; 



// Class Tinkerbox.TBWorldSettings
// Size: 0x518(Inherited: 0x4C8) 
struct ATBWorldSettings : public ADFWorldSettings
{
	struct FMinimapGenerationSettings MinimapSettings;  // 0x4C8(0x28)
	struct TSoftObjectPtr<UTexture2D> MinimapImg;  // 0x4F0(0x28)

}; 



// Class Tinkerbox.TBGameUserDeveloperSettings
// Size: 0x98(Inherited: 0x38) 
struct UTBGameUserDeveloperSettings : public UDeveloperSettings
{
	struct FSoftObjectPath SFXSoundMix;  // 0x38(0x18)
	struct FSoftObjectPath MusicSoundMix;  // 0x50(0x18)
	struct FSoftObjectPath VOSoundMix;  // 0x68(0x18)
	struct FSoftObjectPath VoiPSoundMix;  // 0x80(0x18)

}; 



// Class Tinkerbox.TBGameUserSettings
// Size: 0xA40(Inherited: 0x120) 
struct UTBGameUserSettings : public UGameUserSettings
{
	uint32_t CustomVersion;  // 0x120(0x4)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool bUseSmoothFrameRate : 1;  // 0x124(0x1)
	char pad_293[3];  // 0x125(0x3)
	float DesiredDisplayGamma;  // 0x128(0x4)
	float DesiredFOV;  // 0x12C(0x4)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool bUseMotionBlur : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	float DesiredMouseSensitivityX;  // 0x134(0x4)
	float DesiredMouseSensitivityY;  // 0x138(0x4)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool bInvertMousePitch : 1;  // 0x13C(0x1)
	char pad_317_1 : 7;  // 0x13D(0x1)
	bool bUseMouseSmoothing : 1;  // 0x13D(0x1)
	char pad_318_1 : 7;  // 0x13E(0x1)
	bool DesiredSwitchFireModeOnReselect : 1;  // 0x13E(0x1)
	char pad_319_1 : 7;  // 0x13F(0x1)
	bool LastConfirmedSwitchFireModeOnReselect : 1;  // 0x13F(0x1)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool bUseHeadphoneMode : 1;  // 0x140(0x1)
	char pad_321_1 : 7;  // 0x141(0x1)
	bool bAllowSoundInBackground : 1;  // 0x141(0x1)
	char pad_322[2];  // 0x142(0x2)
	float DesiredMasterVolumeLevel;  // 0x144(0x4)
	float LastConfirmedMasterVolumeLevel;  // 0x148(0x4)
	float DesiredSFXVolumeLevel;  // 0x14C(0x4)
	float LastConfirmedSFXVolumeLevel;  // 0x150(0x4)
	float DesiredMusicVolumeLevel;  // 0x154(0x4)
	float LastConfirmedMusicVolumeLevel;  // 0x158(0x4)
	float DesiredVOVolumeLevel;  // 0x15C(0x4)
	float LastConfirmedVOVolumeLevel;  // 0x160(0x4)
	float DesiredVoiPVolumeLevel;  // 0x164(0x4)
	float LastConfirmedVoiPVolumeLevel;  // 0x168(0x4)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool bPlayerIsChangingKeyBindings : 1;  // 0x16C(0x1)
	char pad_365[3];  // 0x16D(0x3)
	struct FKey DesiredMoveForwardKey;  // 0x170(0x18)
	struct FKey LastConfirmedMoveForwardKey;  // 0x188(0x18)
	struct FKey DesiredMoveBackwardKey;  // 0x1A0(0x18)
	struct FKey LastConfirmedMoveBackwardKey;  // 0x1B8(0x18)
	struct FKey DesiredMoveLeftKey;  // 0x1D0(0x18)
	struct FKey LastConfirmedMoveLeftKey;  // 0x1E8(0x18)
	struct FKey DesiredMoveRightKey;  // 0x200(0x18)
	struct FKey LastConfirmedMoveRightKey;  // 0x218(0x18)
	struct FKey DesiredLeanLeftKey;  // 0x230(0x18)
	struct FKey LastConfirmedLeanLeftKey;  // 0x248(0x18)
	struct FKey DesiredLeanLeftToggleKey;  // 0x260(0x18)
	struct FKey LastConfirmedLeanLeftToggleKey;  // 0x278(0x18)
	struct FKey DesiredLeanRightKey;  // 0x290(0x18)
	struct FKey LastConfirmedLeanRightKey;  // 0x2A8(0x18)
	struct FKey DesiredLeanRightToggleKey;  // 0x2C0(0x18)
	struct FKey LastConfirmedLeanRightToggleKey;  // 0x2D8(0x18)
	struct FKey DesiredSprintKey;  // 0x2F0(0x18)
	struct FKey LastConfirmedSprintKey;  // 0x308(0x18)
	struct FKey DesiredSprintToggleKey;  // 0x320(0x18)
	struct FKey LastConfirmedSprintToggleKey;  // 0x338(0x18)
	struct FKey DesiredCrouchKey;  // 0x350(0x18)
	struct FKey LastConfirmedCrouchKey;  // 0x368(0x18)
	struct FKey DesiredCrouchToggleKey;  // 0x380(0x18)
	struct FKey LastConfirmedCrouchToggleKey;  // 0x398(0x18)
	struct FKey DesiredProneKey;  // 0x3B0(0x18)
	struct FKey LastConfirmedProneKey;  // 0x3C8(0x18)
	struct FKey DesiredJumpVaultKey;  // 0x3E0(0x18)
	struct FKey LastConfirmedJumpVaultKey;  // 0x3F8(0x18)
	struct FKey DesiredJumpKey;  // 0x410(0x18)
	struct FKey LastConfirmedJumpKey;  // 0x428(0x18)
	struct FKey DesiredVaultKey;  // 0x440(0x18)
	struct FKey LastConfirmedVaultKey;  // 0x458(0x18)
	struct FKey DesiredFireKey;  // 0x470(0x18)
	struct FKey LastConfirmedFireKey;  // 0x488(0x18)
	struct FKey DesiredSwitchFireModeKey;  // 0x4A0(0x18)
	struct FKey LastConfirmedSwitchFireModeKey;  // 0x4B8(0x18)
	struct FKey DesiredReloadKey;  // 0x4D0(0x18)
	struct FKey LastConfirmedReloadKey;  // 0x4E8(0x18)
	struct FKey DesiredAimKey;  // 0x500(0x18)
	struct FKey LastConfirmedAimKey;  // 0x518(0x18)
	struct FKey DesiredAimToggleKey;  // 0x530(0x18)
	struct FKey LastConfirmedAimToggleKey;  // 0x548(0x18)
	struct FKey DesiredPointAimToggleKey;  // 0x560(0x18)
	struct FKey LastConfirmedPointAimToggleKey;  // 0x578(0x18)
	struct FKey DesiredCycleWeaponSightsKey;  // 0x590(0x18)
	struct FKey LastConfirmedCycleWeaponSightsKey;  // 0x5A8(0x18)
	struct FKey DesiredNextItemKey;  // 0x5C0(0x18)
	struct FKey LastConfirmedNextItemKey;  // 0x5D8(0x18)
	struct FKey DesiredPreviousItemKey;  // 0x5F0(0x18)
	struct FKey LastConfirmedPreviousItemKey;  // 0x608(0x18)
	struct FKey DesiredItemSlot0Key;  // 0x620(0x18)
	struct FKey LastConfirmedItemSlot0Key;  // 0x638(0x18)
	struct FKey DesiredItemSlot1Key;  // 0x650(0x18)
	struct FKey LastConfirmedItemSlot1Key;  // 0x668(0x18)
	struct FKey DesiredItemSlot2Key;  // 0x680(0x18)
	struct FKey LastConfirmedItemSlot2Key;  // 0x698(0x18)
	struct FKey DesiredItemSlot3Key;  // 0x6B0(0x18)
	struct FKey LastConfirmedItemSlot3Key;  // 0x6C8(0x18)
	struct FKey DesiredItemSlot4Key;  // 0x6E0(0x18)
	struct FKey LastConfirmedItemSlot4Key;  // 0x6F8(0x18)
	struct FKey DesiredItemSlot5Key;  // 0x710(0x18)
	struct FKey LastConfirmedItemSlot5Key;  // 0x728(0x18)
	struct FKey DesiredItemSlot6Key;  // 0x740(0x18)
	struct FKey LastConfirmedItemSlot6Key;  // 0x758(0x18)
	struct FKey DesiredItemSlot7Key;  // 0x770(0x18)
	struct FKey LastConfirmedItemSlot7Key;  // 0x788(0x18)
	struct FKey DesiredItemSlot8Key;  // 0x7A0(0x18)
	struct FKey LastConfirmedItemSlot8Key;  // 0x7B8(0x18)
	struct FKey DesiredItemSlot9Key;  // 0x7D0(0x18)
	struct FKey LastConfirmedItemSlot9Key;  // 0x7E8(0x18)
	struct FKey DesiredPushToTalkLocalKey;  // 0x800(0x18)
	struct FKey LastConfirmedPushToTalkLocalKey;  // 0x818(0x18)
	struct FKey DesiredPushToTalkSquadKey;  // 0x830(0x18)
	struct FKey LastConfirmedPushToTalkSquadKey;  // 0x848(0x18)
	struct FKey DesiredPushToTalkCommandKey;  // 0x860(0x18)
	struct FKey LastConfirmedPushToTalkCommandKey;  // 0x878(0x18)
	struct FKey DesiredSayAllKey;  // 0x890(0x18)
	struct FKey LastConfirmedSayAllKey;  // 0x8A8(0x18)
	struct FKey DesiredSayTeamKey;  // 0x8C0(0x18)
	struct FKey LastConfirmedSayTeamKey;  // 0x8D8(0x18)
	struct FKey DesiredSaySquadKey;  // 0x8F0(0x18)
	struct FKey LastConfirmedSaySquadKey;  // 0x908(0x18)
	struct FKey DesiredUseKey;  // 0x920(0x18)
	struct FKey LastConfirmedUseKey;  // 0x938(0x18)
	struct FKey DesiredShowScoreboardKey;  // 0x950(0x18)
	struct FKey LastConfirmedShowScoreboardKey;  // 0x968(0x18)
	struct FKey DesiredDeployMenuKey;  // 0x980(0x18)
	struct FKey LastConfirmedDeployMenuKey;  // 0x998(0x18)
	struct FKey DesiredRadialMenuKey;  // 0x9B0(0x18)
	struct FKey LastConfirmedRadialMenuKey;  // 0x9C8(0x18)
	struct FKey DesiredCameraToggleKey;  // 0x9E0(0x18)
	struct FKey LastConfirmedCameraToggleKey;  // 0x9F8(0x18)
	struct FKey DesiredConsoleKey;  // 0xA10(0x18)
	struct FKey LastConfirmedConsoleKey;  // 0xA28(0x18)

	void SetWeaponSlot9KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot9KeyBinding
	void SetWeaponSlot8KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot8KeyBinding
	void SetWeaponSlot7KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot7KeyBinding
	void SetWeaponSlot6KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot6KeyBinding
	void SetWeaponSlot5KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot5KeyBinding
	void SetWeaponSlot4KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot4KeyBinding
	void SetWeaponSlot3KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot3KeyBinding
	void SetWeaponSlot2KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot2KeyBinding
	void SetWeaponSlot1KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot1KeyBinding
	void SetWeaponSlot0KeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetWeaponSlot0KeyBinding
	void SetVoiceVolumeLevelNormalized(float NormVoiceVolume); // Function Tinkerbox.TBGameUserSettings.SetVoiceVolumeLevelNormalized
	void SetVoiceVolumeLevel(float VoiceVolume); // Function Tinkerbox.TBGameUserSettings.SetVoiceVolumeLevel
	void SetVaultKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetVaultKeyBinding
	void SetUseKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetUseKeyBinding
	void SetSwitchFireModeOnReselect(bool bEnable); // Function Tinkerbox.TBGameUserSettings.SetSwitchFireModeOnReselect
	void SetSwitchFireModeKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSwitchFireModeKeyBinding
	void SetSprintToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSprintToggleKeyBinding
	void SetSprintKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSprintKeyBinding
	void SetSoundEffectsVolumeLevelNormalized(float NormSFXVolume); // Function Tinkerbox.TBGameUserSettings.SetSoundEffectsVolumeLevelNormalized
	void SetSoundEffectsVolumeLevel(float SFXVolume); // Function Tinkerbox.TBGameUserSettings.SetSoundEffectsVolumeLevel
	void SetSmoothMouseEnabled(bool bEnable); // Function Tinkerbox.TBGameUserSettings.SetSmoothMouseEnabled
	void SetSmoothFrameRateEnabled(bool bEnabled); // Function Tinkerbox.TBGameUserSettings.SetSmoothFrameRateEnabled
	void SetShowScoreboardKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetShowScoreboardKeyBinding
	void SetSayTeamKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSayTeamKeyBinding
	void SetSaySquadKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSaySquadKeyBinding
	void SetSayAllKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetSayAllKeyBinding
	void SetReloadKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetReloadKeyBinding
	void SetRadialMenuKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetRadialMenuKeyBinding
	void SetPushToTalkSquadKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPushToTalkSquadKeyBinding
	void SetPushToTalkLocalKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPushToTalkLocalKeyBinding
	void SetPushToTalkCommandKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPushToTalkCommandKeyBinding
	void SetProneKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetProneKeyBinding
	void SetPreviousItemKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPreviousItemKeyBinding
	void SetPointAimToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetPointAimToggleKeyBinding
	void SetPlayerIsChangingKeyBindings(bool NewValue); // Function Tinkerbox.TBGameUserSettings.SetPlayerIsChangingKeyBindings
	void SetNextItemKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetNextItemKeyBinding
	void SetMusicVolumeLevelNormalized(float NormMusicVolume); // Function Tinkerbox.TBGameUserSettings.SetMusicVolumeLevelNormalized
	void SetMusicVolumeLevel(float MusicVolume); // Function Tinkerbox.TBGameUserSettings.SetMusicVolumeLevel
	void SetMoveRightKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveRightKeyBinding
	void SetMoveLeftKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveLeftKeyBinding
	void SetMoveForwardKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveForwardKeyBinding
	void SetMoveBackwardKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetMoveBackwardKeyBinding
	void SetMouseSensitivityNormalized(float NormSensitivityX, float NormSensitivityY); // Function Tinkerbox.TBGameUserSettings.SetMouseSensitivityNormalized
	void SetMouseSensitivity(float SensitivityX, float SensitivityY); // Function Tinkerbox.TBGameUserSettings.SetMouseSensitivity
	void SetMotionBlurEnabled(bool bEnabled); // Function Tinkerbox.TBGameUserSettings.SetMotionBlurEnabled
	void SetMasterVolumeLevelNormalized(float NormMasterVolume); // Function Tinkerbox.TBGameUserSettings.SetMasterVolumeLevelNormalized
	void SetMasterVolumeLevel(float MasterVolume); // Function Tinkerbox.TBGameUserSettings.SetMasterVolumeLevel
	void SetLeanRightToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanRightToggleKeyBinding
	void SetLeanRightKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanRightKeyBinding
	void SetLeanLeftToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanLeftToggleKeyBinding
	void SetLeanLeftKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetLeanLeftKeyBinding
	void SetJumpVaultKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetJumpVaultKeyBinding
	void SetJumpKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetJumpKeyBinding
	void SetInvertMousePitch(bool bInvertPitch); // Function Tinkerbox.TBGameUserSettings.SetInvertMousePitch
	void SetFireKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetFireKeyBinding
	void SetFieldOfView(float NewFOV); // Function Tinkerbox.TBGameUserSettings.SetFieldOfView
	void SetDisplayGamma(float NewGamma); // Function Tinkerbox.TBGameUserSettings.SetDisplayGamma
	void SetDialogueVolumeLevelNormalized(float NormDialogueVolume); // Function Tinkerbox.TBGameUserSettings.SetDialogueVolumeLevelNormalized
	void SetDialogueVolumeLevel(float DialogueVolume); // Function Tinkerbox.TBGameUserSettings.SetDialogueVolumeLevel
	void SetDeployMenuKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetDeployMenuKeyBinding
	void SetCycleWeaponSightsKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCycleWeaponSightsKeyBinding
	void SetCrouchToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCrouchToggleKeyBinding
	void SetCrouchKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCrouchKeyBinding
	void SetConsoleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetConsoleKeyBinding
	void SetCameraToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetCameraToggleKeyBinding
	void SetAllowSoundInBackground(bool bAllow); // Function Tinkerbox.TBGameUserSettings.SetAllowSoundInBackground
	void SetAimDownSightsToggleKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetAimDownSightsToggleKeyBinding
	void SetAimDownSightsKeyBinding(struct FInputChord NewKey); // Function Tinkerbox.TBGameUserSettings.SetAimDownSightsKeyBinding
	bool IsVoiceVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsVoiceVolumeLevelDirty
	bool IsSwitchFireModeOnReselectDirty(); // Function Tinkerbox.TBGameUserSettings.IsSwitchFireModeOnReselectDirty
	bool IsSoundInBackgroundAllowed(); // Function Tinkerbox.TBGameUserSettings.IsSoundInBackgroundAllowed
	bool IsSoundEffectsVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsSoundEffectsVolumeLevelDirty
	bool IsSmoothMouseEnabled(); // Function Tinkerbox.TBGameUserSettings.IsSmoothMouseEnabled
	bool IsSmoothMouseDirty(); // Function Tinkerbox.TBGameUserSettings.IsSmoothMouseDirty
	bool IsSmoothFrameRateEnabled(); // Function Tinkerbox.TBGameUserSettings.IsSmoothFrameRateEnabled
	bool IsSmoothFrameRateDirty(); // Function Tinkerbox.TBGameUserSettings.IsSmoothFrameRateDirty
	bool IsPlayerChangingKeyBindings(); // Function Tinkerbox.TBGameUserSettings.IsPlayerChangingKeyBindings
	bool IsMusicVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsMusicVolumeLevelDirty
	bool IsMouseSensitivityDirty(); // Function Tinkerbox.TBGameUserSettings.IsMouseSensitivityDirty
	bool IsMotionBlurEnabled(); // Function Tinkerbox.TBGameUserSettings.IsMotionBlurEnabled
	bool IsMotionBlurDirty(); // Function Tinkerbox.TBGameUserSettings.IsMotionBlurDirty
	bool IsMasterVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsMasterVolumeLevelDirty
	bool IsInvertMouseDirty(); // Function Tinkerbox.TBGameUserSettings.IsInvertMouseDirty
	bool IsHeadphoneModeEnabled(); // Function Tinkerbox.TBGameUserSettings.IsHeadphoneModeEnabled
	bool IsHeadphoneModeDirty(); // Function Tinkerbox.TBGameUserSettings.IsHeadphoneModeDirty
	bool IsFrameRateLimitDirty(); // Function Tinkerbox.TBGameUserSettings.IsFrameRateLimitDirty
	bool IsFieldOfViewDirty(); // Function Tinkerbox.TBGameUserSettings.IsFieldOfViewDirty
	bool IsDisplayGammaDirty(); // Function Tinkerbox.TBGameUserSettings.IsDisplayGammaDirty
	bool IsDialogueVolumeLevelDirty(); // Function Tinkerbox.TBGameUserSettings.IsDialogueVolumeLevelDirty
	bool IsAudioQualityDirty(); // Function Tinkerbox.TBGameUserSettings.IsAudioQualityDirty
	bool IsAnyInputKeyBindingDirty(); // Function Tinkerbox.TBGameUserSettings.IsAnyInputKeyBindingDirty
	bool IsAllowSoundInBackgroundDirty(); // Function Tinkerbox.TBGameUserSettings.IsAllowSoundInBackgroundDirty
	struct FKey GetWeaponSlot9KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot9KeyBinding
	struct FKey GetWeaponSlot8KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot8KeyBinding
	struct FKey GetWeaponSlot7KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot7KeyBinding
	struct FKey GetWeaponSlot6KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot6KeyBinding
	struct FKey GetWeaponSlot5KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot5KeyBinding
	struct FKey GetWeaponSlot4KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot4KeyBinding
	struct FKey GetWeaponSlot3KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot3KeyBinding
	struct FKey GetWeaponSlot2KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot2KeyBinding
	struct FKey GetWeaponSlot1KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot1KeyBinding
	struct FKey GetWeaponSlot0KeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetWeaponSlot0KeyBinding
	float GetVoiceVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetVoiceVolumeLevelNormalized
	float GetVoiceVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetVoiceVolumeLevel
	struct FKey GetVaultKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetVaultKeyBinding
	struct FKey GetUseKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetUseKeyBinding
	bool GetSwitchFireModeOnReselect(bool bLastConfirmed); // Function Tinkerbox.TBGameUserSettings.GetSwitchFireModeOnReselect
	struct FKey GetSwitchFireModeKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSwitchFireModeKeyBinding
	struct FKey GetSprintToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSprintToggleKeyBinding
	struct FKey GetSprintKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSprintKeyBinding
	float GetSoundEffectsVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetSoundEffectsVolumeLevelNormalized
	float GetSoundEffectsVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetSoundEffectsVolumeLevel
	struct FKey GetShowScoreboardKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetShowScoreboardKeyBinding
	struct FKey GetSayTeamKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSayTeamKeyBinding
	struct FKey GetSaySquadKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSaySquadKeyBinding
	struct FKey GetSayAllKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetSayAllKeyBinding
	struct FKey GetReloadKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetReloadKeyBinding
	struct FKey GetRadialMenuKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetRadialMenuKeyBinding
	struct FKey GetPushToTalkSquadKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPushToTalkSquadKeyBinding
	struct FKey GetPushToTalkLocalKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPushToTalkLocalKeyBinding
	struct FKey GetPushToTalkCommandKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPushToTalkCommandKeyBinding
	struct FKey GetProneKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetProneKeyBinding
	struct FKey GetPreviousItemKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPreviousItemKeyBinding
	struct FKey GetPointAimToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetPointAimToggleKeyBinding
	struct FKey GetNextItemKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetNextItemKeyBinding
	float GetMusicVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMusicVolumeLevelNormalized
	float GetMusicVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetMusicVolumeLevel
	struct FKey GetMoveRightKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveRightKeyBinding
	struct FKey GetMoveLeftKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveLeftKeyBinding
	struct FKey GetMoveForwardKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveForwardKeyBinding
	struct FKey GetMoveBackwardKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetMoveBackwardKeyBinding
	float GetMouseSensitivityYNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityYNormalized
	float GetMouseSensitivityY(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityY
	float GetMouseSensitivityXNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityXNormalized
	float GetMouseSensitivityX(); // Function Tinkerbox.TBGameUserSettings.GetMouseSensitivityX
	float GetMasterVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetMasterVolumeLevelNormalized
	float GetMasterVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetMasterVolumeLevel
	struct APlayerController* GetLocalPlayerControllerBP(); // Function Tinkerbox.TBGameUserSettings.GetLocalPlayerControllerBP
	struct FKey GetLeanRightKeyToggleBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanRightKeyToggleBinding
	struct FKey GetLeanRightKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanRightKeyBinding
	struct FKey GetLeanLeftToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanLeftToggleKeyBinding
	struct FKey GetLeanLeftKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetLeanLeftKeyBinding
	float GetLastConfirmedMasterVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetLastConfirmedMasterVolumeLevelNormalized
	float GetLastConfirmedMasterVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetLastConfirmedMasterVolumeLevel
	struct FKey GetJumpVaultKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetJumpVaultKeyBinding
	struct FKey GetJumpKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetJumpKeyBinding
	bool GetInvertMousePitch(); // Function Tinkerbox.TBGameUserSettings.GetInvertMousePitch
	float GetFrameRateLimitCurrent(); // Function Tinkerbox.TBGameUserSettings.GetFrameRateLimitCurrent
	struct FKey GetFireKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetFireKeyBinding
	float GetFieldOfView(); // Function Tinkerbox.TBGameUserSettings.GetFieldOfView
	float GetDisplayGamma(); // Function Tinkerbox.TBGameUserSettings.GetDisplayGamma
	float GetDialogueVolumeLevelNormalized(); // Function Tinkerbox.TBGameUserSettings.GetDialogueVolumeLevelNormalized
	float GetDialogueVolumeLevel(); // Function Tinkerbox.TBGameUserSettings.GetDialogueVolumeLevel
	struct FKey GetDeployMenuKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetDeployMenuKeyBinding
	struct FKey GetCycleWeaponSightsKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCycleWeaponSightsKeyBinding
	struct FKey GetCrouchToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCrouchToggleKeyBinding
	struct FKey GetCrouchKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCrouchKeyBinding
	struct FKey GetConsoleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetConsoleKeyBinding
	struct FKey GetCameraToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetCameraToggleKeyBinding
	struct FKey GetAimDownSightsToggleKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetAimDownSightsToggleKeyBinding
	struct FKey GetAimDownSightsKeyBinding(); // Function Tinkerbox.TBGameUserSettings.GetAimDownSightsKeyBinding
	bool FirstRunHardwareBenchmark(int32_t WorkScale, float CPUMultiplier, float GPUMultiplier); // Function Tinkerbox.TBGameUserSettings.FirstRunHardwareBenchmark
	void EnableHeadphoneMode(bool bEnabled); // Function Tinkerbox.TBGameUserSettings.EnableHeadphoneMode
}; 



// Class Tinkerbox.TBVoiceIndicatorListing
// Size: 0x258(Inherited: 0x230) 
struct UTBVoiceIndicatorListing : public UUserWidget
{
	struct UTextBlock* PlayerName;  // 0x230(0x8)
	struct UTBVoiceIndicator* ParentMenu;  // 0x238(0x8)
	char pad_576[24];  // 0x240(0x18)

	void Init(struct UTBVoiceIndicator* InParentMenu, struct FUniqueNetIdRepl& InUniqueNetId, struct FString& InPlayerName); // Function Tinkerbox.TBVoiceIndicatorListing.Init
}; 



