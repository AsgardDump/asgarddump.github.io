#pragma once 
#include <ConstructionSystemRuntime_Structs.h>
 
 
 
// Class ConstructionSystemRuntime.ConstructionSystemCursor
// Size: 0x60(Inherited: 0x28) 
struct UConstructionSystemCursor : public UObject
{
	struct APrefabActor* CursorGhostActor;  // 0x28(0x8)
	int32_t CursorSeed;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UMaterialInterface* CursorMaterial;  // 0x38(0x8)
	struct UMaterialInterface* CursorInvalidMaterial;  // 0x40(0x8)
	struct TArray<struct UPrefabricatorConstructionSnapComponent*> SnapComponents;  // 0x48(0x10)
	int32_t ActiveSnapComponentIndex;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)

}; 



// Class ConstructionSystemRuntime.ConstructionSystemTool
// Size: 0x30(Inherited: 0x28) 
struct UConstructionSystemTool : public UObject
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class ConstructionSystemRuntime.ConstructionSystemComponent
// Size: 0x150(Inherited: 0xB0) 
struct UConstructionSystemComponent : public UActorComponent
{
	struct UMaterialInterface* CursorMaterial;  // 0xB0(0x8)
	struct UMaterialInterface* CursorInvalidMaterial;  // 0xB8(0x8)
	float TraceStartDistance;  // 0xC0(0x4)
	float TraceSweepRadius;  // 0xC4(0x4)
	struct AActor* ConstructionCameraActor;  // 0xC8(0x8)
	float ConstructionCameraTransitionTime;  // 0xD0(0x4)
	float ConstructionCameraTransitionExp;  // 0xD4(0x4)
	UUserWidget* BuildMenuUI;  // 0xD8(0x8)
	struct UConstructionSystemUIAsset* BuildMenuData;  // 0xE0(0x8)
	struct UUserWidget* BuildMenuUIInstance;  // 0xE8(0x8)
	uint8_t  ActiveToolType;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct TMap<uint8_t , struct UConstructionSystemTool*> Tools;  // 0xF8(0x50)
	char pad_328[8];  // 0x148(0x8)

	void ToggleConstructionSystem(); // Function ConstructionSystemRuntime.ConstructionSystemComponent.ToggleConstructionSystem
	void ShowBuildMenu(); // Function ConstructionSystemRuntime.ConstructionSystemComponent.ShowBuildMenu
	void SetActiveTool(uint8_t  InToolType); // Function ConstructionSystemRuntime.ConstructionSystemComponent.SetActiveTool
	void HideBuildMenu(); // Function ConstructionSystemRuntime.ConstructionSystemComponent.HideBuildMenu
	struct UConstructionSystemTool* GetTool(uint8_t  InToolType); // Function ConstructionSystemRuntime.ConstructionSystemComponent.GetTool
	uint8_t  GetActiveToolType(); // Function ConstructionSystemRuntime.ConstructionSystemComponent.GetActiveToolType
	struct UConstructionSystemTool* GetActiveTool(); // Function ConstructionSystemRuntime.ConstructionSystemComponent.GetActiveTool
	void EnableConstructionSystem(uint8_t  InToolType); // Function ConstructionSystemRuntime.ConstructionSystemComponent.EnableConstructionSystem
	void DisableConstructionSystem(); // Function ConstructionSystemRuntime.ConstructionSystemComponent.DisableConstructionSystem
}; 



// Class ConstructionSystemRuntime.ConstructionSystemBuildTool
// Size: 0x168(Inherited: 0x30) 
struct UConstructionSystemBuildTool : public UConstructionSystemTool
{
	float TraceDistance;  // 0x30(0x4)
	float CursorRotationStepAngle;  // 0x34(0x4)
	struct UConstructionSystemCursor* Cursor;  // 0x38(0x8)
	struct UPrefabricatorAssetInterface* ActivePrefabAsset;  // 0x40(0x8)
	char pad_72[288];  // 0x48(0x120)

	void SetActivePrefab(struct UPrefabricatorAssetInterface* InActivePrefabAsset); // Function ConstructionSystemRuntime.ConstructionSystemBuildTool.SetActivePrefab
	void HandleInput_RotateCursorStep(float NumSteps); // Function ConstructionSystemRuntime.ConstructionSystemBuildTool.HandleInput_RotateCursorStep
	void HandleInput_CursorMovePrev(); // Function ConstructionSystemRuntime.ConstructionSystemBuildTool.HandleInput_CursorMovePrev
	void HandleInput_CursorMoveNext(); // Function ConstructionSystemRuntime.ConstructionSystemBuildTool.HandleInput_CursorMoveNext
	void HandleInput_ConstructAtCursor(); // Function ConstructionSystemRuntime.ConstructionSystemBuildTool.HandleInput_ConstructAtCursor
}; 



// Class ConstructionSystemRuntime.ConstructionSystemRemoveTool
// Size: 0x90(Inherited: 0x30) 
struct UConstructionSystemRemoveTool : public UConstructionSystemTool
{
	float TraceDistance;  // 0x30(0x4)
	struct TWeakObjectPtr<APrefabActor> FocusedActor;  // 0x34(0x8)
	char pad_60[84];  // 0x3C(0x54)

	void HandleInput_RemoveAtCursor(); // Function ConstructionSystemRuntime.ConstructionSystemRemoveTool.HandleInput_RemoveAtCursor
}; 



// Class ConstructionSystemRuntime.ConstructionSystemItemUserData
// Size: 0x30(Inherited: 0x28) 
struct UConstructionSystemItemUserData : public UAssetUserData
{
	int32_t Seed;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 



// Class ConstructionSystemRuntime.ConstructionSystemSaveSystem
// Size: 0x28(Inherited: 0x28) 
struct UConstructionSystemSaveSystem : public UBlueprintFunctionLibrary
{

	void SaveConstructionSystemLevel(struct UObject* WorldContextObject, struct FString SaveSlotName, int32_t UserIndex, bool bSavePlayerState); // Function ConstructionSystemRuntime.ConstructionSystemSaveSystem.SaveConstructionSystemLevel
	void LoadConstructionSystemLevel(struct UObject* WorldContextObject, struct FName& LevelName, bool bAbsolute, struct FString SaveSlotName, int32_t UserIndex); // Function ConstructionSystemRuntime.ConstructionSystemSaveSystem.LoadConstructionSystemLevel
	void HandleConstructionSystemLevelLoad(struct UObject* WorldContextObject); // Function ConstructionSystemRuntime.ConstructionSystemSaveSystem.HandleConstructionSystemLevelLoad
}; 



// Class ConstructionSystemRuntime.ConstructionSystemSaveGame
// Size: 0xA0(Inherited: 0x28) 
struct UConstructionSystemSaveGame : public USaveGame
{
	struct FString SaveSlotName;  // 0x28(0x10)
	uint32_t UserIndex;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FConstructionSystemSavePlayerInfo PlayerInfo;  // 0x40(0x50)
	struct TArray<struct FConstructionSystemSaveConstructedItem> ConstructedItems;  // 0x90(0x10)

}; 



// Class ConstructionSystemRuntime.PrefabricatorConstructionSnapComponent
// Size: 0x450(Inherited: 0x430) 
struct UPrefabricatorConstructionSnapComponent : public UBoxComponent
{
	uint8_t  SnapType;  // 0x430(0x1)
	struct FPCSnapConstraintFloor FloorConstraint;  // 0x431(0x6)
	struct FPCSnapConstraintWall WallConstraint;  // 0x437(0x4)
	char pad_1083_1 : 7;  // 0x43B(0x1)
	bool bAlignToGroundSlope : 1;  // 0x43B(0x1)
	char pad_1084_1 : 7;  // 0x43C(0x1)
	bool bUseMaxGroundSlopeConstraint : 1;  // 0x43C(0x1)
	char pad_1085[3];  // 0x43D(0x3)
	float MaxGroundPlacementSlope;  // 0x440(0x4)
	char pad_1092[12];  // 0x444(0xC)

}; 



// Class ConstructionSystemRuntime.PrefabricatorConstructionSnap
// Size: 0x228(Inherited: 0x220) 
struct APrefabricatorConstructionSnap : public AActor
{
	struct UPrefabricatorConstructionSnapComponent* ConstructionSnapComponent;  // 0x220(0x8)

}; 



// Class ConstructionSystemRuntime.ConstructionSystemBuildUI
// Size: 0x28(Inherited: 0x28) 
struct UConstructionSystemBuildUI : public UInterface
{

	void SetUIAsset(struct UConstructionSystemUIAsset* UIAsset); // Function ConstructionSystemRuntime.ConstructionSystemBuildUI.SetUIAsset
	void SetConstructionSystem(struct UConstructionSystemComponent* ConstructionSystem); // Function ConstructionSystemRuntime.ConstructionSystemBuildUI.SetConstructionSystem
}; 



// Class ConstructionSystemRuntime.ConstructionSystemUIAsset
// Size: 0x58(Inherited: 0x30) 
struct UConstructionSystemUIAsset : public UDataAsset
{
	struct FText MenuTitle;  // 0x30(0x18)
	struct TArray<struct FConstructionSystemUICategory> Categories;  // 0x48(0x10)

}; 



