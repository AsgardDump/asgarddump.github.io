#pragma once 
#include "SDK.h" 
 
 
// Function TinkerUI.TBButton.GetIsFocusable
// Size: 0x1(Inherited: 0x0) 
struct FGetIsFocusable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function TinkerUI.TBButton.IsInteractionEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsInteractionEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function TinkerUI.TBSlider.SetSliderFgBarColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderFgBarColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function TinkerUI.TBButton.SetIsFocusable
// Size: 0x1(Inherited: 0x0) 
struct FSetIsFocusable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsFocusable : 1;  // 0x0(0x1)

}; 
// Function TinkerUI.TBButton.SetIsInteractionEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetIsInteractionEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsInteractionEnabled : 1;  // 0x0(0x1)

}; 
// Function TinkerUI.TBSlider.SetMouseUsesStep
// Size: 0x1(Inherited: 0x0) 
struct FSetMouseUsesStep
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInValue : 1;  // 0x0(0x1)

}; 
