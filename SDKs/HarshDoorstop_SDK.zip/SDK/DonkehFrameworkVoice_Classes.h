#pragma once 
#include <DonkehFrameworkVoice_Structs.h>
 
 
 
// Class DonkehFrameworkVoice.DFVoiceStatics
// Size: 0x28(Inherited: 0x28) 
struct UDFVoiceStatics : public UBlueprintFunctionLibrary
{

}; 



