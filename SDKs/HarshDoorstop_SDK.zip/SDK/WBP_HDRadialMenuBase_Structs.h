#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnMouseButtonDoubleClick
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDoubleClick : public FOnMouseButtonDoubleClick
{
	struct FGeometry InMyGeometry;  // 0x0(0x38)
	struct FPointerEvent InMouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnKeyDown
// Size: 0x2B8(Inherited: 0x128) 
struct FOnKeyDown : public FOnKeyDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FKeyEvent InKeyEvent;  // 0x38(0x38)
	struct FEventReply ReturnValue;  // 0x70(0xB8)
	struct FEventReply CallFunc_Unhandled_ReturnValue;  // 0x128(0xB8)
	struct FKey CallFunc_GetKey_ReturnValue;  // 0x1E0(0x18)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x1F8(0x1)
	char pad_801_1 : 7;  // 0x321(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x1F9(0x1)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x200(0xB8)

}; 
// Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.OnMouseButtonDown
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.SubmenuCommit__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FSubmenuCommit__DelegateSignature
{
	struct FName Category;  // 0x0(0x8)
	struct FName SubItem;  // 0x8(0x8)

}; 
// Function WBP_HDRadialMenuBase.WBP_HDRadialMenuBase_C.ExecuteUbergraph_WBP_HDRadialMenuBase
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HDRadialMenuBase
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
