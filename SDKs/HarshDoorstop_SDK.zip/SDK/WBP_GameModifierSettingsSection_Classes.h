#pragma once 
#include <WBP_GameModifierSettingsSection_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C
// Size: 0x2A0(Inherited: 0x230) 
struct UWBP_GameModifierSettingsSection_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UNamedSlot* Content;  // 0x238(0x8)
	struct UCheckBox* SectionActiveToggleChkBox;  // 0x240(0x8)
	struct UImage* SectionExpansionArrow;  // 0x248(0x8)
	struct UButton* SectionExpansionToggleBtn;  // 0x250(0x8)
	struct UTextBlock* SectionTitleText;  // 0x258(0x8)
	struct FText TitleText;  // 0x260(0x18)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool bShowToggleBtn : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool bExpanded : 1;  // 0x279(0x1)
	char pad_634_1 : 7;  // 0x27A(0x1)
	bool bActive : 1;  // 0x27A(0x1)
	char pad_635[5];  // 0x27B(0x5)
	struct FMulticastInlineDelegate OnActivated;  // 0x280(0x10)
	struct FMulticastInlineDelegate OnDeactivated;  // 0x290(0x10)

	void InternalRecursiveSetContentIsEnabled(bool bInIsEnabled); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.InternalRecursiveSetContentIsEnabled
	void IsActive(bool& bActive); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.IsActive
	void IsExpanded(bool& bExpanded); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.IsExpanded
	void GetTitleText(struct FText& TitleText); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.GetTitleText
	void SetIsActive(bool bActive); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetIsActive
	void SetExpansionState(bool bExpanded); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetExpansionState
	void SetTitleText(struct FText InTitleText); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.SetTitleText
	void PreConstruct(bool IsDesignTime); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.PreConstruct
	void BndEvt__SectionExpansionToggleBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.BndEvt__SectionExpansionToggleBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void BndEvt__SectionActiveToggleChkBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.BndEvt__SectionActiveToggleChkBox_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
	void ExecuteUbergraph_WBP_GameModifierSettingsSection(int32_t EntryPoint); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.ExecuteUbergraph_WBP_GameModifierSettingsSection
	void OnDeactivated__DelegateSignature(); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.OnDeactivated__DelegateSignature
	void OnActivated__DelegateSignature(); // Function WBP_GameModifierSettingsSection.WBP_GameModifierSettingsSection_C.OnActivated__DelegateSignature
}; 



