#pragma once 
#include <BPI_OptionMenu_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_OptionMenu.BPI_OptionMenu_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_OptionMenu_C : public UInterface
{

	void GetDesiredVerticalAlignment(char EVerticalAlignment& Alignment); // Function BPI_OptionMenu.BPI_OptionMenu_C.GetDesiredVerticalAlignment
	void GetDesiredHorizontalAlignment(char EHorizontalAlignment& Alignment); // Function BPI_OptionMenu.BPI_OptionMenu_C.GetDesiredHorizontalAlignment
	void GetSubMenuOptions(struct TArray<struct FFSubMenuOption>& SubOptions); // Function BPI_OptionMenu.BPI_OptionMenu_C.GetSubMenuOptions
	void SetActiveSubMenuByIndex(int32_t SubMenuIndex); // Function BPI_OptionMenu.BPI_OptionMenu_C.SetActiveSubMenuByIndex
	void HasSubMenus(bool& bSubMenuOptions); // Function BPI_OptionMenu.BPI_OptionMenu_C.HasSubMenus
}; 



