#pragma once 
#include <UdpMessaging_Structs.h>
 
 
 
// Class UdpMessaging.UdpMessagingSettings
// Size: 0xA0(Inherited: 0x28) 
struct UUdpMessagingSettings : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool EnableTransport : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bAutoRepair : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bStopServiceWhenAppDeactivates : 1;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)
	struct FString UnicastEndpoint;  // 0x30(0x10)
	struct FString MulticastEndpoint;  // 0x40(0x10)
	uint8_t  MessageFormat;  // 0x50(0x1)
	char MulticastTimeToLive;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct TArray<struct FString> StaticEndpoints;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool EnableTunnel : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FString TunnelUnicastEndpoint;  // 0x70(0x10)
	struct FString TunnelMulticastEndpoint;  // 0x80(0x10)
	struct TArray<struct FString> RemoteTunnelEndpoints;  // 0x90(0x10)

}; 



