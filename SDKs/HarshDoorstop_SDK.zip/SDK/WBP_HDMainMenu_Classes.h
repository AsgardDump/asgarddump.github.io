#pragma once 
#include <WBP_HDMainMenu_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HDMainMenu.WBP_HDMainMenu_C
// Size: 0x3F8(Inherited: 0x3EC) 
struct UWBP_HDMainMenu_C : public UWBP_MainMenu_C
{
	char pad_1004[4];  // 0x3EC(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3F0(0x8)

	void PreConstruct(bool IsDesignTime); // Function WBP_HDMainMenu.WBP_HDMainMenu_C.PreConstruct
	void ExecuteUbergraph_WBP_HDMainMenu(int32_t EntryPoint); // Function WBP_HDMainMenu.WBP_HDMainMenu_C.ExecuteUbergraph_WBP_HDMainMenu
}; 



