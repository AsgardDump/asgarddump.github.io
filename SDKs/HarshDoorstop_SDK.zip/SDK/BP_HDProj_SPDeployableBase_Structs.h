#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetTransformOffsetBySpawnIndex
// Size: 0xE0(Inherited: 0x0) 
struct FGetTransformOffsetBySpawnIndex
{
	int32_t SpawnIdx;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform Transform;  // 0x10(0x30)
	struct FTransform NewTransform;  // 0x40(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x70(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x7C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x88(0xC)
	struct FVector CallFunc_Array_Get_Item;  // 0x94(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xA0(0xC)
	char pad_172[4];  // 0xAC(0x4)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xB0(0x30)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.OnSpawnPointActivationChanged__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FOnSpawnPointActivationChanged__DelegateSignature
{
	struct ABP_HDProj_SPDeployableBase_C* Deployable;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSpawnPointEnabled : 1;  // 0x8(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ExecuteUbergraph_BP_HDProj_SPDeployableBase
// Size: 0x229(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDProj_SPDeployableBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x18(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x28(0x88)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0xB0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xB8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xC0(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct ADFBaseCharacter* K2Node_DynamicCast_AsDFBase_Character;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct ADFBaseCharacter* K2Node_DynamicCast_AsDFBase_Character_2;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_IsEnemyChar_bEnemyChar : 1;  // 0xE9(0x1)
	char pad_234[2];  // 0xEA(0x2)
	float CallFunc_GetGameTimeSinceCreation_ReturnValue;  // 0xEC(0x4)
	char CallFunc_GetTeamNum_ReturnValue;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0xF1(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0xF2(0x1)
	char pad_243[1];  // 0xF3(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xF4(0x10)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x104(0x1)
	char pad_261_1 : 7;  // 0x105(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x105(0x1)
	char K2Node_CustomEvent_LastTeamNum;  // 0x106(0x1)
	char K2Node_CustomEvent_NewTeamNum;  // 0x107(0x1)
	struct FHitResult K2Node_Event_ImpactHitResult;  // 0x108(0x88)
	int32_t Temp_int_Variable;  // 0x190(0x4)
	float K2Node_Event_Damage;  // 0x194(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x198(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x1A0(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x1A8(0x8)
	struct ADFBaseProjectile* K2Node_DynamicCast_AsDFBase_Projectile;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1B8(0x1)
	char pad_441[3];  // 0x1B9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1BC(0x4)
	struct FTransform Temp_struct_Variable;  // 0x1C0(0x30)
	struct UDFPOIComponent* CallFunc_AddComponent_ReturnValue;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CallFunc_HasServerAuthority_bAuthority : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct AHDSquadState* K2Node_CustomEvent_Squad;  // 0x200(0x8)
	struct AHDPlayerState* K2Node_CustomEvent_MemberPS;  // 0x208(0x8)
	int32_t CallFunc_GetNumSquadMembers_ReturnValue;  // 0x210(0x4)
	char pad_532_1 : 7;  // 0x214(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x214(0x1)
	char pad_533_1 : 7;  // 0x215(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x215(0x1)
	char pad_534[2];  // 0x216(0x2)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x218(0x8)
	struct UPrimitiveComponent* K2Node_DynamicCast_AsPrimitive_Component;  // 0x220(0x8)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x228(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ReceivePayloadActivated
// Size: 0x88(Inherited: 0x88) 
struct FReceivePayloadActivated : public FReceivePayloadActivated
{
	struct FHitResult ImpactHitResult;  // 0x0(0x88)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.MemberPreUnregisteredFromOwnerSquad
// Size: 0x10(Inherited: 0x0) 
struct FMemberPreUnregisteredFromOwnerSquad
{
	struct AHDSquadState* Squad;  // 0x0(0x8)
	struct AHDPlayerState* MemberPS;  // 0x8(0x8)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.IsSpawnable
// Size: 0x1(Inherited: 0x0) 
struct FIsSpawnable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSpawnPointEnabled : 1;  // 0x0(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__SpawnSphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.OverlappingPawnTeamNumUpdated
// Size: 0x2(Inherited: 0x0) 
struct FOverlappingPawnTeamNumUpdated
{
	char LastTeamNum;  // 0x0(0x1)
	char NewTeamNum;  // 0x1(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.FindSpawnPointBP
// Size: 0x62(Inherited: 0x0) 
struct FFindSpawnPointBP
{
	int32_t SpawnPointID;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FSpawnPointDef FoundSpawnPoint;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x61(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__SpawnSphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.HasServerAuthority
// Size: 0x4(Inherited: 0x0) 
struct FHasServerAuthority
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAuthority : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.IsEnemyChar
// Size: 0x11(Inherited: 0x0) 
struct FIsEnemyChar
{
	struct ADFBaseCharacter* Char;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEnemyChar : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x9(0x1)
	char CallFunc_GetTeamNum_ReturnValue;  // 0xA(0x1)
	char CallFunc_GetTeamNum_ReturnValue_2;  // 0xB(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0xC(0x1)
	char CallFunc_GetValidValue_ReturnValue_2;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_2 : 1;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetSpawnPoint
// Size: 0x180(Inherited: 0x0) 
struct FGetSpawnPoint
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bMeshZOffset : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t SpawnPointIdx;  // 0x4(0x4)
	char pad_8[8];  // 0x8(0x8)
	struct FSpawnPointDef SpawnPoint;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Variable : 1;  // 0x60(0x1)
	char pad_97[15];  // 0x61(0xF)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x70(0x30)
	struct FTransform CallFunc_GetActorTransformOffsetByMeshZBounds_OffsetActorWorldXForm;  // 0xA0(0x30)
	struct FTransform K2Node_Select_Default;  // 0xD0(0x30)
	struct FTransform CallFunc_GetTransformOffsetBySpawnIndex_NewTransform;  // 0x100(0x30)
	struct FSpawnPointDef K2Node_MakeStruct_SpawnPointDef;  // 0x130(0x50)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.AreSpawnPointsEqual
// Size: 0xA6(Inherited: 0x0) 
struct FAreSpawnPointsEqual
{
	struct FSpawnPointDef SpawnPointOne;  // 0x0(0x50)
	struct FSpawnPointDef SpawnPointTwo;  // 0x50(0x50)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool bEqual : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xA2(0x1)
	char pad_163_1 : 7;  // 0xA3(0x1)
	bool CallFunc_EqualEqual_TransformTransform_ReturnValue : 1;  // 0xA3(0x1)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165_1 : 7;  // 0xA5(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xA5(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.SetIsSpawnable
// Size: 0x2(Inherited: 0x0) 
struct FSetIsSpawnable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewEnabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CheckForEnemyChars
// Size: 0x4B(Inherited: 0x0) 
struct FCheckForEnemyChars
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bFoundEnemyChar : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	int32_t Temp_int_Variable;  // 0x14(0x4)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x18(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x30(0x8)
	struct ADFBaseCharacter* K2Node_DynamicCast_AsDFBase_Character;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsEnemyChar_bEnemyChar : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4A(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetActorTransformOffsetByMeshZBounds
// Size: 0x100(Inherited: 0x0) 
struct FGetActorTransformOffsetByMeshZBounds
{
	struct FTransform OffsetActorWorldXForm;  // 0x0(0x30)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x30(0x30)
	struct FVector CallFunc_GetLocalBounds_Min;  // 0x60(0xC)
	struct FVector CallFunc_GetLocalBounds_Max;  // 0x6C(0xC)
	struct FVector CallFunc_BreakTransform_Location;  // 0x78(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x84(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x90(0xC)
	float CallFunc_BreakVector_X;  // 0x9C(0x4)
	float CallFunc_BreakVector_Y;  // 0xA0(0x4)
	float CallFunc_BreakVector_Z;  // 0xA4(0x4)
	float CallFunc_BreakVector_X_2;  // 0xA8(0x4)
	float CallFunc_BreakVector_Y_2;  // 0xAC(0x4)
	float CallFunc_BreakVector_Z_2;  // 0xB0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xB4(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xB8(0xC)
	char pad_196[12];  // 0xC4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xD0(0x30)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GenerateSpawnPointList
// Size: 0x132(Inherited: 0x0) 
struct FGenerateSpawnPointList
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FSpawnPointDef CallFunc_GetSpawnPoint_SpawnPoint;  // 0x10(0x50)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x64(0x4)
	int32_t Temp_int_Variable_2;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FSpawnPointDef CallFunc_GetSpawnPoint_SpawnPoint_2;  // 0x70(0x50)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xC0(0x4)
	char pad_196[12];  // 0xC4(0xC)
	struct FSpawnPointDef K2Node_MakeStruct_SpawnPointDef;  // 0xD0(0x50)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x120(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x124(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x128(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x12C(0x4)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x130(0x1)
	char pad_305_1 : 7;  // 0x131(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue_2 : 1;  // 0x131(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.HandleTakeDamageFromProjectile
// Size: 0x30(Inherited: 0x0) 
struct FHandleTakeDamageFromProjectile
{
	struct ADFBaseProjectile* InProjectile;  // 0x0(0x8)
	float InDamage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct ADFBaseWeapon* CallFunc_GetOwningWeapon_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct ADFBaseCharacter* CallFunc_GetPawnOwner_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsEnemyChar_bEnemyChar : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x2B(0x1)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x2C(0x4)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CheckEnemyOverrun
// Size: 0x4(Inherited: 0x0) 
struct FCheckEnemyOverrun
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.InitDeployable
// Size: 0x55(Inherited: 0x0) 
struct FInitDeployable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	ABP_HDProj_SPDeployableBase_C* CallFunc_GetObjectClass_ReturnValue;  // 0x8(0x8)
	struct TArray<struct ABP_HDProj_SPDeployableBase_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x10(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x20(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct ABP_HDProj_SPDeployableBase_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x42(0x1)
	char pad_67[1];  // 0x43(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x44(0x10)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x54(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanPlayerSpawnHere
// Size: 0x1B(Inherited: 0x0) 
struct FCanPlayerSpawnHere
{
	struct AController* InPlayer;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bPlayerCanSpawn : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AHDPlayerState* K2Node_DynamicCast_AsHDPlayer_State;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_IsRegisteredSquadMember_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanRestartPlayerFromSpawnPointBP
// Size: 0x6F(Inherited: 0x0) 
struct FCanRestartPlayerFromSpawnPointBP
{
	struct FSpawnPointDef SpawnPoint;  // 0x0(0x50)
	struct AController* Player;  // 0x50(0x8)
	APawn* PlayerPawnClass;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool bSameTeam : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool bFoundSpawnPoint : 1;  // 0x62(0x1)
	char pad_99_1 : 7;  // 0x63(0x1)
	bool CallFunc_CanPlayerSpawnHere_bPlayerCanSpawn : 1;  // 0x63(0x1)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_AreSpawnPointsEqual_bEqual : 1;  // 0x65(0x1)
	char CallFunc_GetTeamNum_ReturnValue;  // 0x66(0x1)
	char CallFunc_GetTeamNum_ReturnValue_2;  // 0x67(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x68(0x1)
	char CallFunc_GetValidValue_ReturnValue_2;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x6A(0x1)
	char CallFunc_GetTeamNum_ReturnValue_3;  // 0x6B(0x1)
	char CallFunc_GetValidValue_ReturnValue_3;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x6D(0x1)
	char pad_110_1 : 7;  // 0x6E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x6E(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetAllSpawnPointsBP
// Size: 0x2C(Inherited: 0x0) 
struct FGetAllSpawnPointsBP
{
	struct TArray<struct FSpawnPointDef> SpawnPoints;  // 0x0(0x10)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FSpawnPointDef> SpawnPointArr;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanSpawnActorFromSpawnPointBP
// Size: 0x59(Inherited: 0x0) 
struct FCanSpawnActorFromSpawnPointBP
{
	struct FSpawnPointDef SpawnPoint;  // 0x0(0x50)
	AActor* SpawnActorClass;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool ReturnValue : 1;  // 0x58(0x1)

}; 
// Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetSpawnPointCollisionHandlingOverrideBP
// Size: 0x52(Inherited: 0x0) 
struct FGetSpawnPointCollisionHandlingOverrideBP
{
	struct FSpawnPointDef SpawnPoint;  // 0x0(0x50)
	uint8_t  OutSpawnCollisionMethod;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool ReturnValue : 1;  // 0x51(0x1)

}; 
