#pragma once 
#include "SDK.h" 
 
 
// Function GOAPNPC.GOAPAction.EndAction
// Size: 0x8(Inherited: 0x0) 
struct FEndAction
{
	struct APawn* Pawn;  // 0x0(0x8)

}; 
// ScriptStruct GOAPNPC.Atom
// Size: 0x18(Inherited: 0x0) 
struct FAtom
{
	struct FString Name;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function GOAPNPC.GOAPComponent.HasPlan
// Size: 0x1(Inherited: 0x0) 
struct FHasPlan
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GOAPNPC.GOAPAction.HasCompleted
// Size: 0x10(Inherited: 0x0) 
struct FHasCompleted
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function GOAPNPC.GOAPComponent.GetPlanSnapshot
// Size: 0x10(Inherited: 0x0) 
struct FGetPlanSnapshot
{
	struct TArray<struct UGOAPAction*> ReturnValue;  // 0x0(0x10)

}; 
// Function GOAPNPC.GOAPComponent.GetDesiredWorldStateAtoms
// Size: 0x10(Inherited: 0x0) 
struct FGetDesiredWorldStateAtoms
{
	struct TArray<struct FAtom> ReturnValue;  // 0x0(0x10)

}; 
// Function GOAPNPC.GOAPAction.BeginAction
// Size: 0x8(Inherited: 0x0) 
struct FBeginAction
{
	struct APawn* Pawn;  // 0x0(0x8)

}; 
// Function GOAPNPC.GOAPAction.DoAction
// Size: 0x20(Inherited: 0x0) 
struct FDoAction
{
	struct APawn* Pawn;  // 0x0(0x8)
	struct FString FailureReason;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function GOAPNPC.GOAPGoal.RequiresNewPlan
// Size: 0x1(Inherited: 0x0) 
struct FRequiresNewPlan
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GOAPNPC.GOAPAction.CheckProceduralPrecondition
// Size: 0x10(Inherited: 0x0) 
struct FCheckProceduralPrecondition
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bPlanning : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function GOAPNPC.GOAPAction.GetTargetsList
// Size: 0x18(Inherited: 0x0) 
struct FGetTargetsList
{
	struct APawn* Pawn;  // 0x0(0x8)
	struct TArray<struct AActor*> ReturnValue;  // 0x8(0x10)

}; 
// Function GOAPNPC.GOAPAction.ReceiveIsActionInvalid
// Size: 0x10(Inherited: 0x0) 
struct FReceiveIsActionInvalid
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function GOAPNPC.GOAPAction.Validate
// Size: 0x10(Inherited: 0x0) 
struct FValidate
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function GOAPNPC.GOAPGoalManager.SetCurrentGoal
// Size: 0x10(Inherited: 0x0) 
struct FSetCurrentGoal
{
	struct UGOAPGoal* NewGoal;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bDeactivatePreviousGoal : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function GOAPNPC.GOAPComponent.ExecuteGOAP
// Size: 0x3(Inherited: 0x0) 
struct FExecuteGOAP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCreatePlan : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bRemoveActionOnComplete : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool ReturnValue : 1;  // 0x2(0x1)

}; 
// Function GOAPNPC.GOAPComponent.GeneratePlan
// Size: 0x1(Inherited: 0x0) 
struct FGeneratePlan
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GOAPNPC.GOAPComponent.GetCurrentWorldStateAtoms
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentWorldStateAtoms
{
	struct TArray<struct FAtom> ReturnValue;  // 0x0(0x10)

}; 
// Function GOAPNPC.GOAPComponent.IsPlanValid
// Size: 0x1(Inherited: 0x0) 
struct FIsPlanValid
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function GOAPNPC.GOAPComponent.SetCurrentWorld
// Size: 0x10(Inherited: 0x0) 
struct FSetCurrentWorld
{
	struct TArray<struct FAtom> NewCurrentWorld;  // 0x0(0x10)

}; 
// Function GOAPNPC.GOAPComponent.SetGoal
// Size: 0x8(Inherited: 0x0) 
struct FSetGoal
{
	struct UGOAPGoal* NewGoal;  // 0x0(0x8)

}; 
// Function GOAPNPC.GOAPComponent.UpdateCurrentWorld
// Size: 0x10(Inherited: 0x0) 
struct FUpdateCurrentWorld
{
	struct TArray<struct FAtom> Atoms;  // 0x0(0x10)

}; 
// Function GOAPNPC.GOAPGoalManager.SetGoalSet
// Size: 0x8(Inherited: 0x0) 
struct FSetGoalSet
{
	struct UGOAPGoalSet* InGoalSet;  // 0x0(0x8)

}; 
// Function GOAPNPC.GOAPGoal.GetOuterGoalManager
// Size: 0x8(Inherited: 0x0) 
struct FGetOuterGoalManager
{
	struct UGOAPGoalManager* ReturnValue;  // 0x0(0x8)

}; 
// Function GOAPNPC.GOAPGoalManager.AddGoal
// Size: 0x10(Inherited: 0x0) 
struct FAddGoal
{
	UGOAPGoal* GoalClass;  // 0x0(0x8)
	struct UGOAPGoal* ReturnValue;  // 0x8(0x8)

}; 
// Function GOAPNPC.GOAPGoalManager.FindGoal
// Size: 0x10(Inherited: 0x0) 
struct FFindGoal
{
	UGOAPGoal* GoalClass;  // 0x0(0x8)
	struct UGOAPGoal* ReturnValue;  // 0x8(0x8)

}; 
// Function GOAPNPC.GOAPGoalManager.GetCurrentGoalAtoms
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentGoalAtoms
{
	struct TArray<struct FAtom> ReturnValue;  // 0x0(0x10)

}; 
// Function GOAPNPC.GOAPGoalManager.GetOuterGOAPComp
// Size: 0x8(Inherited: 0x0) 
struct FGetOuterGOAPComp
{
	struct UGOAPComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function GOAPNPC.GOAPGoalManager.RemoveGoal
// Size: 0x8(Inherited: 0x0) 
struct FRemoveGoal
{
	UGOAPGoal* GoalClass;  // 0x0(0x8)

}; 
// Function GOAPNPC.GOAPGoalManager.UpdateGoalSet
// Size: 0x8(Inherited: 0x0) 
struct FUpdateGoalSet
{
	struct UGOAPGoalSet* InGoalSet;  // 0x0(0x8)

}; 
