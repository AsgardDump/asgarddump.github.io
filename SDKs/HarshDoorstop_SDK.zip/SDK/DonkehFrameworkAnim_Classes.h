#pragma once 
#include <DonkehFrameworkAnim_Structs.h>
 
 
 
// Class DonkehFrameworkAnim.AnimNotify_PlayFootstepFX
// Size: 0x150(Inherited: 0x38) 
struct UAnimNotify_PlayFootstepFX : public UAnimNotify
{
	struct TMap<char EPhysicalSurface, struct FPerspectiveSound> SoundsToPlay;  // 0x38(0x50)
	float VolumeMultiplier;  // 0x88(0x4)
	float PitchMultiplier;  // 0x8C(0x4)
	char bAttachSound : 1;  // 0x90(0x1)
	char bPlaySoundsWithPerspMeshOnly : 1;  // 0x90(0x1)
	char pad_144_1 : 6;  // 0x90(0x1)
	char pad_145[8];  // 0x91(0x8)
	struct TMap<char EPhysicalSurface, struct UFXSystemAsset*> EffectsToSpawn;  // 0x98(0x50)
	char bAttachEffect : 1;  // 0xE8(0x1)
	char pad_232_1 : 7;  // 0xE8(0x1)
	char pad_233[4];  // 0xE9(0x4)
	struct FVector EffectLocationOffset;  // 0xEC(0xC)
	struct FRotator EffectRotationOffset;  // 0xF8(0xC)
	char pad_260[28];  // 0x104(0x1C)
	struct FVector EffectScale;  // 0x120(0xC)
	char bSpawnEffectsWithPerspMeshOnly : 1;  // 0x12C(0x1)
	char pad_300_1 : 7;  // 0x12C(0x1)
	uint8_t  FootstepVariant;  // 0x12D(0x1)
	char pad_302[2];  // 0x12E(0x2)
	struct FName FootstepVariantParamName;  // 0x130(0x8)
	struct FName FootBoneName;  // 0x138(0x8)
	float FootTraceOffset;  // 0x140(0x4)
	char bDebug : 1;  // 0x144(0x1)
	char pad_324_1 : 7;  // 0x144(0x1)
	char pad_325[12];  // 0x145(0xC)

	void SetFootstepNotifyProps(struct FFootstepFXSettings& PropsToUse); // Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.SetFootstepNotifyProps
	struct FFootstepFXSettings GetFootstepNotifyProps(); // Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.GetFootstepNotifyProps
	bool EqualProps(struct FFootstepFXSettings& Props, struct FFootstepFXSettings& OtherProps); // Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.EqualProps
}; 



// Class DonkehFrameworkAnim.DFCharacterAnimInstance
// Size: 0x2C0(Inherited: 0x270) 
struct UDFCharacterAnimInstance : public UAnimInstance
{
	char bPreviewAnimInstance : 1;  // 0x268(0x1)
	struct APawn* CachedPawnOwner;  // 0x270(0x8)
	struct ADFBaseCharacter* DFCharOwner;  // 0x278(0x8)
	struct AController* ControllerOwner;  // 0x280(0x8)
	struct ADFBaseItem* EquippedWeapon;  // 0x288(0x8)
	char EMovementMode MoveMode;  // 0x290(0x1)
	uint8_t  MoveStance;  // 0x291(0x1)
	char pad_658_1 : 7;  // 0x292(0x1)
	char pad_659[2];  // 0x293(0x2)
	struct FVector MoveVelocity;  // 0x294(0xC)
	float MoveSpeed;  // 0x2A0(0x4)
	float MoveDirectionDeg;  // 0x2A4(0x4)
	char bMoving : 1;  // 0x2A8(0x1)
	char bInAir : 1;  // 0x2A8(0x1)
	char bJumped : 1;  // 0x2A8(0x1)
	char bSprinting : 1;  // 0x2A8(0x1)
	char bAiming : 1;  // 0x2A8(0x1)
	char bLeaning : 1;  // 0x2A8(0x1)
	char pad_680_1 : 2;  // 0x2A8(0x1)
	struct FDFCharStanceContext StandState;  // 0x2A9(0x1)
	struct FDFCharStanceContext CrouchState;  // 0x2AA(0x1)
	struct FDFCharStanceContext ProneState;  // 0x2AB(0x1)
	struct FRotator AimOffsets;  // 0x2AC(0xC)
	char pad_696[8];  // 0x2B8(0x8)

	struct ADFBaseItem* TryGetOwnerWeapon(); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.TryGetOwnerWeapon
	struct AController* TryGetControllerOwner(); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.TryGetControllerOwner
	void EquippedWeaponChanged(struct ADFBaseCharacter* Character, struct ADFBaseItem* NewEquippedWeap, struct ADFBaseItem* PrevEquippedWeap); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.EquippedWeaponChanged
	void BlueprintUpdatePawnOwnerRefs(struct APawn* NewPawn); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdatePawnOwnerRefs
	void BlueprintUpdateEquippedWeaponRefs(struct ADFBaseItem* NewWeap); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdateEquippedWeaponRefs
	void BlueprintUpdateControllerOwnerRefs(struct AController* NewC); // Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdateControllerOwnerRefs
}; 



// Class DonkehFrameworkAnim.DFWeaponAnimInstance
// Size: 0x280(Inherited: 0x270) 
struct UDFWeaponAnimInstance : public UAnimInstance
{
	char bPreviewAnimInstance : 1;  // 0x268(0x1)
	struct ADFBaseWeapon* WeaponOwner;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	char pad_633[8];  // 0x279(0x8)

	struct ADFBaseWeapon* TryGetWeaponOwner(); // Function DonkehFrameworkAnim.DFWeaponAnimInstance.TryGetWeaponOwner
	void BlueprintUpdateWeaponOwnerRefs(struct ADFBaseWeapon* NewWeap); // Function DonkehFrameworkAnim.DFWeaponAnimInstance.BlueprintUpdateWeaponOwnerRefs
}; 



