#pragma once 
#include "SDK.h" 
 
 
// Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.ButtonClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FButtonClicked__DelegateSignature
{
	struct UWBP_MainMenu_NavBarButton_C* ClickedBtn;  // 0x0(0x8)

}; 
// Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.UpdateAppearance
// Size: 0x538(Inherited: 0x0) 
struct FUpdateAppearance
{
	struct FSlateColor NewTint;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float Temp_float_Variable;  // 0x2C(0x4)
	float Temp_float_Variable_2;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	float K2Node_Select_Default;  // 0x38(0x4)
	struct FLinearColor K2Node_MakeStruct_LinearColor;  // 0x3C(0x10)
	char pad_76[4];  // 0x4C(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x50(0x28)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x78(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_2;  // 0x100(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_3;  // 0x188(0x88)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush_4;  // 0x210(0x88)
	struct FButtonStyle K2Node_MakeStruct_ButtonStyle;  // 0x298(0x278)
	struct FSlateColor K2Node_Select_Default_2;  // 0x510(0x28)

}; 
// Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.ExecuteUbergraph_WBP_MainMenu_NavBarButton
// Size: 0x61(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_MainMenu_NavBarButton
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_GetIsEnabled_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FSlateColor K2Node_Select_Default;  // 0x28(0x28)
	struct UButtonSlot* K2Node_DynamicCast_AsButton_Slot;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsDemoBuild_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5B(0x1)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_IsDemoBuild_ReturnValue_2 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x5D(0x1)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x5E(0x1)
	char pad_95_1 : 7;  // 0x5F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x5F(0x1)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x60(0x1)

}; 
// Function WBP_MainMenu_NavBarButton.WBP_MainMenu_NavBarButton_C.SetActive
// Size: 0x1(Inherited: 0x0) 
struct FSetActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewActive : 1;  // 0x0(0x1)

}; 
