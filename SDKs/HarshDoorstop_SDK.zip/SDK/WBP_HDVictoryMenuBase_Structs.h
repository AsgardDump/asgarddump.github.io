#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.ExecuteUbergraph_WBP_HDVictoryMenuBase
// Size: 0x39(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HDVictoryMenuBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AHDTeamState* CallFunc_GetHDTeamStateForTeam_HDTeamState;  // 0x8(0x8)
	struct AHDTeamState* CallFunc_GetHDTeamStateForTeam_HDTeamState_2;  // 0x10(0x8)
	struct AHDTeamState* CallFunc_GetHDTeamStateForTeam_HDTeamState_3;  // 0x18(0x8)
	UBP_HDFactionInfoBase_C* K2Node_ClassDynamicCast_AsBP_HDFaction_Info_Base;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	UBP_HDFactionInfoBase_C* K2Node_ClassDynamicCast_AsBP_HDFaction_Info_Base_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0x38(0x1)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupVictoryText
// Size: 0x38(Inherited: 0x0) 
struct FSetupVictoryText
{
	uint8_t  Temp_byte_Variable;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FText K2Node_Select_Default;  // 0x8(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x20(0x18)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupElapsedTimeText
// Size: 0xE0(Inherited: 0x0) 
struct FSetupElapsedTimeText
{
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x0(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x4(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x8(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x20(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x38(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0x78(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0xB8(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0xC8(0x18)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnMouseButtonDown
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDown : public FOnMouseButtonDown
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	struct FPointerEvent MouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.OnMouseButtonDoubleClick
// Size: 0x218(Inherited: 0x160) 
struct FOnMouseButtonDoubleClick : public FOnMouseButtonDoubleClick
{
	struct FGeometry InMyGeometry;  // 0x0(0x38)
	struct FPointerEvent InMouseEvent;  // 0x38(0x70)
	struct FEventReply ReturnValue;  // 0xA8(0xB8)
	struct FEventReply CallFunc_Handled_ReturnValue;  // 0x160(0xB8)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupTeamScoreText
// Size: 0x30(Inherited: 0x0) 
struct FSetupTeamScoreText
{
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x0(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue_2;  // 0x18(0x18)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupMapNameText
// Size: 0x78(Inherited: 0x0) 
struct FSetupMapNameText
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString CallFunc_GetMapName_ReturnValue;  // 0x8(0x10)
	struct AWorldSettings* CallFunc_GetWorldSettings_ReturnValue;  // 0x18(0x8)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x20(0x18)
	struct ATBWorldSettings* K2Node_DynamicCast_AsTBWorld_Settings;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct FText K2Node_Select_Default;  // 0x48(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x60(0x18)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.SetupGameModeNameText
// Size: 0x80(Inherited: 0x0) 
struct FSetupGameModeNameText
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x8(0x8)
	ADFBaseGameMode* K2Node_ClassDynamicCast_AsDFBase_Game_Mode;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString CallFunc_GetClassDisplayName_ReturnValue;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x38(0x18)
	struct FText K2Node_Select_Default;  // 0x50(0x18)
	struct FText CallFunc_TextToUpper_ReturnValue;  // 0x68(0x18)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.PlayWinLossMenuMusic
// Size: 0x50(Inherited: 0x0) 
struct FPlayWinLossMenuMusic
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x18(0x10)
	uint8_t  CallFunc_GetPlayerTeam_PlayerTeam;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x30(0x10)
	struct USoundBase* CallFunc_GetMusicTrackToUse_SoundToUse;  // 0x40(0x8)
	struct UAudioComponent* CallFunc_SpawnSound2D_ReturnValue;  // 0x48(0x8)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.GetMusicTrackToUse
// Size: 0x48(Inherited: 0x0) 
struct FGetMusicTrackToUse
{
	uint8_t  PlayerTeam;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bPlayerWon : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct USoundBase* SoundToUse;  // 0x8(0x8)
	struct USoundBase* Temp_object_Variable;  // 0x10(0x8)
	uint8_t  Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct USoundBase* Temp_object_Variable_2;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct USoundBase* K2Node_Select_Default;  // 0x30(0x8)
	struct USoundBase* K2Node_Select_Default_2;  // 0x38(0x8)
	struct USoundBase* K2Node_Select_Default_3;  // 0x40(0x8)

}; 
// Function WBP_HDVictoryMenuBase.WBP_HDVictoryMenuBase_C.GetPlayerTeam
// Size: 0xC(Inherited: 0x0) 
struct FGetPlayerTeam
{
	uint8_t  PlayerTeam;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_3;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x8(0x1)
	uint8_t  K2Node_Select_Default;  // 0x9(0x1)
	uint8_t  K2Node_Select_Default_2;  // 0xA(0x1)
	uint8_t  K2Node_Select_Default_3;  // 0xB(0x1)

}; 
