#pragma once 
#include <PrefabricatorRuntime_Structs.h>
 
 
 
// Class PrefabricatorRuntime.PrefabActor
// Size: 0x240(Inherited: 0x220) 
struct APrefabActor : public AActor
{
	struct UPrefabComponent* PrefabComponent;  // 0x220(0x8)
	struct FGuid LastUpdateID;  // 0x228(0x10)
	int32_t Seed;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)

	void SavePrefab(); // Function PrefabricatorRuntime.PrefabActor.SavePrefab
	void RandomizeSeed(struct FRandomStream& InRandom, bool bRecursive); // Function PrefabricatorRuntime.PrefabActor.RandomizeSeed
	void LoadPrefab(); // Function PrefabricatorRuntime.PrefabActor.LoadPrefab
	bool IsPrefabOutdated(); // Function PrefabricatorRuntime.PrefabActor.IsPrefabOutdated
	struct UPrefabricatorAsset* GetPrefabAsset(); // Function PrefabricatorRuntime.PrefabActor.GetPrefabAsset
}; 



// Class PrefabricatorRuntime.PrefabricatorEventListener
// Size: 0x28(Inherited: 0x28) 
struct UPrefabricatorEventListener : public UObject
{

	void PostSpawn(struct APrefabActor* Prefab); // Function PrefabricatorRuntime.PrefabricatorEventListener.PostSpawn
}; 



// Class PrefabricatorRuntime.PrefabDebugActor
// Size: 0x238(Inherited: 0x220) 
struct APrefabDebugActor : public AActor
{
	struct AActor* Actor;  // 0x220(0x8)
	struct TArray<char> ActorData;  // 0x228(0x10)

}; 



// Class PrefabricatorRuntime.ReplicablePrefabActor
// Size: 0x240(Inherited: 0x240) 
struct AReplicablePrefabActor : public APrefabActor
{

}; 



// Class PrefabricatorRuntime.PrefabricatorProperty
// Size: 0x70(Inherited: 0x28) 
struct UPrefabricatorProperty : public UObject
{
	struct FString PropertyName;  // 0x28(0x10)
	struct FString ExportedValue;  // 0x38(0x10)
	struct TArray<struct FPrefabricatorPropertyAssetMapping> AssetSoftReferenceMappings;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bIsCrossReferencedActor : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FGuid CrossReferencePrefabActorId;  // 0x5C(0x10)
	char pad_108[4];  // 0x6C(0x4)

}; 



// Class PrefabricatorRuntime.PrefabRandomizer
// Size: 0x270(Inherited: 0x220) 
struct APrefabRandomizer : public AActor
{
	char pad_544_1 : 7;  // 0x220(0x1)
	bool bRandomizeOnBeginPlay : 1;  // 0x220(0x1)
	char pad_545[3];  // 0x221(0x3)
	int32_t SeedOffset;  // 0x224(0x4)
	float MaxBuildTimePerFrame;  // 0x228(0x4)
	char pad_556[4];  // 0x22C(0x4)
	struct FMulticastInlineDelegate OnRandomizationComplete;  // 0x230(0x10)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool bFastSyncBuild : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct TArray<struct APrefabActor*> ActorsToRandomize;  // 0x248(0x10)
	char pad_600[24];  // 0x258(0x18)

	void Randomize(int32_t InSeed); // Function PrefabricatorRuntime.PrefabRandomizer.Randomize
}; 



// Class PrefabricatorRuntime.PrefabComponent
// Size: 0x220(Inherited: 0x1F0) 
struct UPrefabComponent : public USceneComponent
{
	struct TSoftObjectPtr<UPrefabricatorAssetInterface> PrefabAssetInterface;  // 0x1F0(0x28)
	char pad_536[8];  // 0x218(0x8)

}; 



// Class PrefabricatorRuntime.PrefabricatorAssetInterface
// Size: 0x38(Inherited: 0x28) 
struct UPrefabricatorAssetInterface : public UObject
{
	UPrefabricatorEventListener* EventListener;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bReplicates : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 



// Class PrefabricatorRuntime.PrefabricatorAsset
// Size: 0x70(Inherited: 0x38) 
struct UPrefabricatorAsset : public UPrefabricatorAssetInterface
{
	struct TArray<struct FPrefabricatorActorData> ActorData;  // 0x38(0x10)
	char EComponentMobility PrefabMobility;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FGuid LastUpdateID;  // 0x4C(0x10)
	char pad_92[4];  // 0x5C(0x4)
	struct UThumbnailInfo* ThumbnailInfo;  // 0x60(0x8)
	uint32_t Version;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)

}; 



// Class PrefabricatorRuntime.PrefabricatorAssetCollection
// Size: 0x50(Inherited: 0x38) 
struct UPrefabricatorAssetCollection : public UPrefabricatorAssetInterface
{
	struct TArray<struct FPrefabricatorAssetCollectionItem> Prefabs;  // 0x38(0x10)
	uint32_t Version;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 



// Class PrefabricatorRuntime.PrefabricatorAssetUserData
// Size: 0x40(Inherited: 0x28) 
struct UPrefabricatorAssetUserData : public UAssetUserData
{
	struct TWeakObjectPtr<APrefabActor> PrefabActor;  // 0x28(0x8)
	struct FGuid ItemId;  // 0x30(0x10)

}; 



// Class PrefabricatorRuntime.PrefabricatorBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UPrefabricatorBlueprintLibrary : public UBlueprintFunctionLibrary
{

	void UnlinkPrefab(struct APrefabActor* PrefabActor); // Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.UnlinkPrefab
	struct APrefabActor* SpawnPrefab(struct UObject* WorldContextObject, struct UPrefabricatorAssetInterface* Prefab, struct FTransform& Transform, int32_t Seed); // Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.SpawnPrefab
	void SetPrefabAsset(struct APrefabActor* PrefabActor, struct UPrefabricatorAssetInterface* Prefab, bool bReloadPrefab); // Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.SetPrefabAsset
	void RandomizePrefab(struct APrefabActor* PrefabActor, struct FRandomStream& InRandom); // Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.RandomizePrefab
	void GetAllAttachedActors(struct AActor* Prefab, struct TArray<struct AActor*>& AttachedActors); // Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.GetAllAttachedActors
	struct APrefabActor* FindTopMostPrefabActor(struct AActor* InActor); // Function PrefabricatorRuntime.PrefabricatorBlueprintLibrary.FindTopMostPrefabActor
}; 



// Class PrefabricatorRuntime.PrefabricatorSettings
// Size: 0xA0(Inherited: 0x38) 
struct UPrefabricatorSettings : public UDeveloperSettings
{
	uint8_t  PivotPosition;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bAllowDynamicUpdate : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	struct TSet<UObject*> IgnoreBoundingBoxForObjects;  // 0x40(0x50)
	float DefaultThumbnailPitch;  // 0x90(0x4)
	float DefaultThumbnailYaw;  // 0x94(0x4)
	float DefaultThumbnailZoom;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)

}; 



// Class PrefabricatorRuntime.PrefabSeedLinkerComponent
// Size: 0x1F0(Inherited: 0x1F0) 
struct UPrefabSeedLinkerComponent : public USceneComponent
{

}; 



// Class PrefabricatorRuntime.PrefabSeedLinker
// Size: 0x238(Inherited: 0x220) 
struct APrefabSeedLinker : public AActor
{
	struct TArray<struct TWeakObjectPtr<APrefabActor>> LinkedActors;  // 0x220(0x10)
	struct UPrefabSeedLinkerComponent* SeedLinkerComponent;  // 0x230(0x8)

}; 



