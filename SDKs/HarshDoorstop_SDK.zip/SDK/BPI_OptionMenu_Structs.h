#pragma once 
#include "SDK.h" 
 
 
// Function BPI_OptionMenu.BPI_OptionMenu_C.SetActiveSubMenuByIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetActiveSubMenuByIndex
{
	int32_t SubMenuIndex;  // 0x0(0x4)

}; 
// Function BPI_OptionMenu.BPI_OptionMenu_C.HasSubMenus
// Size: 0x1(Inherited: 0x0) 
struct FHasSubMenus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSubMenuOptions : 1;  // 0x0(0x1)

}; 
// Function BPI_OptionMenu.BPI_OptionMenu_C.GetSubMenuOptions
// Size: 0x10(Inherited: 0x0) 
struct FGetSubMenuOptions
{
	struct TArray<struct FFSubMenuOption> SubOptions;  // 0x0(0x10)

}; 
// Function BPI_OptionMenu.BPI_OptionMenu_C.GetDesiredHorizontalAlignment
// Size: 0x1(Inherited: 0x0) 
struct FGetDesiredHorizontalAlignment
{
	char EHorizontalAlignment Alignment;  // 0x0(0x1)

}; 
// Function BPI_OptionMenu.BPI_OptionMenu_C.GetDesiredVerticalAlignment
// Size: 0x1(Inherited: 0x0) 
struct FGetDesiredVerticalAlignment
{
	char EVerticalAlignment Alignment;  // 0x0(0x1)

}; 
