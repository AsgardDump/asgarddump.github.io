#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.AimIn
// Size: 0x593(Inherited: 0x0) 
struct FAimIn
{
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	struct FWeightedBlendable CallFunc_Array_Get_Item;  // 0x8(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables;  // 0x20(0x10)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x30(0x4)
	char pad_52[12];  // 0x34(0xC)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings;  // 0x40(0x540)
	char pad_1408_1 : 7;  // 0x580(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x580(0x1)
	char pad_1409[3];  // 0x581(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x584(0x4)
	char pad_1416_1 : 7;  // 0x588(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x588(0x1)
	char pad_1417[3];  // 0x589(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x58C(0x4)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x590(0x1)
	char pad_1425_1 : 7;  // 0x591(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x591(0x1)
	char pad_1426_1 : 7;  // 0x592(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x592(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SetupOwnerData
// Size: 0x42(Inherited: 0x0) 
struct FSetupOwnerData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValidOwnerData : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x8(0x8)
	struct ADFPlayerCameraManager* K2Node_DynamicCast_AsDFPlayer_Camera_Manager;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AHDPlayerController* K2Node_DynamicCast_AsHDPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct ADFBaseCharacter* CallFunc_GetPawnOwner_ReturnValue;  // 0x30(0x8)
	struct ABP_HDPlayerCharacterBase_C* K2Node_DynamicCast_AsBP_HDPlayer_Character_Base;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x41(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ExecuteUbergraph_BP_HDScopeWeaponBase
// Size: 0x16C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDScopeWeaponBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x10(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x18(0x8)
	struct ADFBaseCharacter* CallFunc_GetPawnOwner_ReturnValue;  // 0x20(0x8)
	struct ADFBaseCharacter* CallFunc_GetPawnOwner_ReturnValue_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue_2 : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool K2Node_Event_bPlayAnimAndWait : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool K2Node_Event_bLeavingPawnInventory : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_IsUnEquipping_ReturnValue : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_IsEquipping_ReturnValue : 1;  // 0x36(0x1)
	char pad_55_1 : 7;  // 0x37(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x37(0x1)
	struct UUserWidget* CallFunc_Create_ReturnValue;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsFalling_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsAiming_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_IsAiming_ReturnValue_2 : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_HasLocallyPlayerControlledOwner_bLocalPlayerOwner : 1;  // 0x43(0x1)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_SetupOwnerData_bValidOwnerData : 1;  // 0x44(0x1)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool CallFunc_HasValidOwnerData_bValidOwnerData : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)
	struct ADFBaseCharacter* K2Node_Event_LastOwner;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsEquipped_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsEquipping_ReturnValue_2 : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_IsLocallyPlayerControlled_ReturnValue_3 : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	struct USceneComponent* K2Node_Event_Sight;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_ShouldUseScope_bUseScope : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_ShouldUseScope_bUseScope_2 : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x62(0x1)
	char pad_99_1 : 7;  // 0x63(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x63(0x1)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x64(0xC)
	struct FVector2D CallFunc_ProjectWorldLocationToScreen_ScreenLocation;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_ProjectWorldLocationToScreen_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	float CallFunc_BreakVector2D_X;  // 0x7C(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x84(0x1)
	char pad_133_1 : 7;  // 0x85(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x85(0x1)
	char pad_134[2];  // 0x86(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x88(0xC)
	struct FVector2D CallFunc_ProjectWorldLocationToScreen_ScreenLocation_2;  // 0x94(0x8)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_ProjectWorldLocationToScreen_ReturnValue_2 : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	float CallFunc_Distance2D_ReturnValue;  // 0xA0(0x4)
	int32_t CallFunc_GetViewportSize_SizeX;  // 0xA4(0x4)
	int32_t CallFunc_GetViewportSize_SizeY;  // 0xA8(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0xAC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0xB8(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0xC0(0x4)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleNormalized;  // 0xC4(0x4)
	float CallFunc_GetResolutionScaleInformationEx_CurrentScaleValue;  // 0xC8(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MinScaleValue;  // 0xCC(0x4)
	float CallFunc_GetResolutionScaleInformationEx_MaxScaleValue;  // 0xD0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xD4(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xD8(0xC)
	struct FHitResult CallFunc_K2_AddRelativeLocation_SweepHitResult;  // 0xE4(0x88)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnUnEquip
// Size: 0x2(Inherited: 0x2) 
struct FReceiveOnUnEquip : public FReceiveOnUnEquip
{
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bPlayAnimAndWait : 1;  // 0x0(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool bLeavingPawnInventory : 1;  // 0x1(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.UserConstructionScript
// Size: 0xE4(Inherited: 0x98) 
struct FUserConstructionScript : public FUserConstructionScript
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC(0x1)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x10(0x10)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x30(0x8)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	struct UMaterial* CallFunc_GetBaseMaterial_ReturnValue;  // 0x40(0x8)
	char pad_210_1 : 7;  // 0xD2(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x48(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x50(0xC)
	struct FHitResult CallFunc_K2_AddRelativeLocation_SweepHitResult;  // 0x5C(0x88)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SetCurrentSight
// Size: 0x8(Inherited: 0x8) 
struct FSetCurrentSight : public FSetCurrentSight
{
	struct USceneComponent* Sight;  // 0x0(0x8)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveOnLeaveInventory
// Size: 0x8(Inherited: 0x8) 
struct FReceiveOnLeaveInventory : public FReceiveOnLeaveInventory
{
	struct ADFBaseCharacter* LastOwner;  // 0x0(0x8)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.HasValidOwnerData
// Size: 0xB(Inherited: 0x0) 
struct FHasValidOwnerData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCharAliveCheck : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bValidOwnerData : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsAlive_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xA(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.HasLocallyPlayerControlledOwner
// Size: 0x3(Inherited: 0x0) 
struct FHasLocallyPlayerControlledOwner
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLocalPlayerOwner : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.AimOut
// Size: 0x580(Inherited: 0x0) 
struct FAimOut
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FWeightedBlendable CallFunc_Array_Get_Item;  // 0x8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables;  // 0x20(0x10)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings;  // 0x30(0x540)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x570(0x4)
	char pad_1396_1 : 7;  // 0x574(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x574(0x1)
	char pad_1397[3];  // 0x575(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x578(0x4)
	char pad_1404_1 : 7;  // 0x57C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x57C(0x1)
	char pad_1405_1 : 7;  // 0x57D(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x57D(0x1)
	char pad_1406_1 : 7;  // 0x57E(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x57E(0x1)
	char pad_1407_1 : 7;  // 0x57F(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x57F(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ScopeEffects
// Size: 0x591(Inherited: 0x0) 
struct FScopeEffects
{
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_ShouldUseScope_bUseScope : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)
	struct FPostProcessSettings K2Node_MakeStruct_PostProcessSettings;  // 0x20(0x540)
	int32_t Temp_int_Array_Index_Variable;  // 0x560(0x4)
	char pad_1380_1 : 7;  // 0x564(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x564(0x1)
	char pad_1381[3];  // 0x565(0x3)
	struct FWeightedBlendable CallFunc_Array_Get_Item;  // 0x568(0x10)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x578(0x4)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x57C(0x4)
	char pad_1408_1 : 7;  // 0x580(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x580(0x1)
	char pad_1409[3];  // 0x581(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x584(0x4)
	char pad_1416_1 : 7;  // 0x588(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x588(0x1)
	char pad_1417[3];  // 0x589(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x58C(0x4)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x590(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.RestoreOwnerDefaultValues
// Size: 0x2(Inherited: 0x0) 
struct FRestoreOwnerDefaultValues
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.SaveOwnerDefaultValues
// Size: 0x2(Inherited: 0x0) 
struct FSaveOwnerDefaultValues
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1(0x1)

}; 
// Function BP_HDScopeWeaponBase.BP_HDScopeWeaponBase_C.ShouldUseScope
// Size: 0x7(Inherited: 0x0) 
struct FShouldUseScope
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseScope : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x6(0x1)

}; 
