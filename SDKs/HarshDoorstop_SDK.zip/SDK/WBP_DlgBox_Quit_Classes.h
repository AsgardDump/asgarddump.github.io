#pragma once 
#include <WBP_DlgBox_Quit_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DlgBox_Quit.WBP_DlgBox_Quit_C
// Size: 0x258(Inherited: 0x230) 
struct UWBP_DlgBox_Quit_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* DialogBg;  // 0x238(0x8)
	struct UImage* DialogDivider;  // 0x240(0x8)
	struct UWBP_DialogBox_Button_C* NoBtn;  // 0x248(0x8)
	struct UWBP_DialogBox_Button_C* YesBtn;  // 0x250(0x8)

	struct FEventReply OnMouseButtonDown(struct FGeometry MyGeometry, struct FPointerEvent& MouseEvent); // Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.OnMouseButtonDown
	void Construct(); // Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.Construct
	void BndEvt__YesBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature(struct UWBP_DialogBox_Button_C* ClickedBtn); // Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.BndEvt__YesBtn_K2Node_ComponentBoundEvent_2_ButtonClicked__DelegateSignature
	void BndEvt__NoBtn_K2Node_ComponentBoundEvent_3_ButtonClicked__DelegateSignature(struct UWBP_DialogBox_Button_C* ClickedBtn); // Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.BndEvt__NoBtn_K2Node_ComponentBoundEvent_3_ButtonClicked__DelegateSignature
	void DummyInput(); // Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.DummyInput
	void ExecuteUbergraph_WBP_DlgBox_Quit(int32_t EntryPoint); // Function WBP_DlgBox_Quit.WBP_DlgBox_Quit_C.ExecuteUbergraph_WBP_DlgBox_Quit
}; 



