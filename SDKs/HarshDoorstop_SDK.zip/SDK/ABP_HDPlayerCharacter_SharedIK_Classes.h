#pragma once 
#include <ABP_HDPlayerCharacter_SharedIK_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C
// Size: 0xECD(Inherited: 0x270) 
struct UABP_HDPlayerCharacter_SharedIK_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x270(0x8)
	struct FAnimNode_Root AnimGraphNode_Root_3;  // 0x278(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_3;  // 0x2A8(0x78)
	struct FAnimNode_Root AnimGraphNode_Root_2;  // 0x320(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose_2;  // 0x350(0x78)
	struct FAnimNode_HandIKRetargeting AnimGraphNode_HandIKRetargeting;  // 0x3C8(0x120)
	char pad_1256[8];  // 0x4E8(0x8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // 0x4F0(0x1E0)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // 0x6D0(0x1E0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x8B0(0x20)
	struct FAnimNode_Fabrik AnimGraphNode_Fabrik_2;  // 0x8D0(0x190)
	struct FAnimNode_Fabrik AnimGraphNode_Fabrik;  // 0xA60(0x190)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0xBF0(0x20)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0xC10(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;  // 0xC40(0x78)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer_2;  // 0xCB8(0xB0)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer;  // 0xD68(0xB0)
	char pad_3608[8];  // 0xE18(0x8)
	struct FTransform LeftHandIKTransform;  // 0xE20(0x30)
	struct FTransform RightHandIKTransform;  // 0xE50(0x30)
	char pad_3712_1 : 7;  // 0xE80(0x1)
	bool bUseLeftHandIK : 1;  // 0xE80(0x1)
	char pad_3713_1 : 7;  // 0xE81(0x1)
	bool bUseRightHandIK : 1;  // 0xE81(0x1)
	char pad_3714_1 : 7;  // 0xE82(0x1)
	bool bUseHandIKRetargeting : 1;  // 0xE82(0x1)
	char pad_3715[1];  // 0xE83(0x1)
	float HandFKWeight;  // 0xE84(0x4)
	char pad_3720_1 : 7;  // 0xE88(0x1)
	bool bPreventAOHandDriftFromWeapon : 1;  // 0xE88(0x1)
	char pad_3721[3];  // 0xE89(0x3)
	struct FVector FootIK_R_Displacement;  // 0xE8C(0xC)
	struct FVector FootIK_L_Displacement;  // 0xE98(0xC)
	struct FRotator FootIK_R_Rotation;  // 0xEA4(0xC)
	struct FRotator FootIK_L_Rotation;  // 0xEB0(0xC)
	char pad_3772_1 : 7;  // 0xEBC(0x1)
	bool bDoFootIK_L : 1;  // 0xEBC(0x1)
	char pad_3773_1 : 7;  // 0xEBD(0x1)
	bool bDoFootIK_R : 1;  // 0xEBD(0x1)
	char pad_3774[2];  // 0xEBE(0x2)
	struct FVector PelvisIK_Displacement;  // 0xEC0(0xC)
	char pad_3788_1 : 7;  // 0xECC(0x1)
	bool DoPelvisDisplacement : 1;  // 0xECC(0x1)

	void FootIK(struct FPoseLink InLocoPose, struct FPoseLink& FootIK); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.FootIK
	void HandIK(struct FPoseLink InLocoPose, struct FPoseLink& HandIK); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.HandIK
	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.AnimGraph
	void ExecuteUbergraph_ABP_HDPlayerCharacter_SharedIK(int32_t EntryPoint); // Function ABP_HDPlayerCharacter_SharedIK.ABP_HDPlayerCharacter_SharedIK_C.ExecuteUbergraph_ABP_HDPlayerCharacter_SharedIK
}; 



