#pragma once 
#include <WBP_InputKeySelector_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_InputKeySelector.WBP_InputKeySelector_C
// Size: 0x260(Inherited: 0x230) 
struct UWBP_InputKeySelector_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UInputKeySelector* IKS;  // 0x238(0x8)
	struct FMulticastInlineDelegate OnKeySelected;  // 0x240(0x10)
	struct FMulticastInlineDelegate OnIsSelectingKeyChanged;  // 0x250(0x10)

	void SetSelectedKey(struct FKey SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.SetSelectedKey
	void GetSelectedKey(struct FKey& SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.GetSelectedKey
	void BndEvt__IKS_K2Node_ComponentBoundEvent_2_OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.BndEvt__IKS_K2Node_ComponentBoundEvent_2_OnIsSelectingKeyChanged__DelegateSignature
	void BndEvt__IKS_K2Node_ComponentBoundEvent_1_OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.BndEvt__IKS_K2Node_ComponentBoundEvent_1_OnKeySelected__DelegateSignature
	void ExecuteUbergraph_WBP_InputKeySelector(int32_t EntryPoint); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.ExecuteUbergraph_WBP_InputKeySelector
	void OnIsSelectingKeyChanged__DelegateSignature(); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.OnIsSelectingKeyChanged__DelegateSignature
	void OnKeySelected__DelegateSignature(struct FInputChord SelectedKey); // Function WBP_InputKeySelector.WBP_InputKeySelector_C.OnKeySelected__DelegateSignature
}; 



