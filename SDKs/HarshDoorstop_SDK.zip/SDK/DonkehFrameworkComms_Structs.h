#pragma once 
#include "SDK.h" 
 
 
// Function DonkehFrameworkComms.DFCommChannelStateLibrary.GetOwningCommChannel
// Size: 0x18(Inherited: 0x0) 
struct FGetOwningCommChannel
{
	struct TScriptInterface<IDFCommChannelStateInterface> ChannelState;  // 0x0(0x10)
	struct UDFCommChannel* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct DonkehFrameworkComms.DFCommChannelMapItemEntry
// Size: 0x28(Inherited: 0xC) 
struct FDFCommChannelMapItemEntry : public FFastArraySerializerItem
{
	struct FName Key;  // 0xC(0x8)
	char pad_20[4];  // 0x14(0x4)
	struct UDFCommChannel* Value;  // 0x18(0x8)
	char pad_32[8];  // 0x20(0x8)

}; 
// ScriptStruct DonkehFrameworkComms.DFChannelMsgRecord
// Size: 0x48(Inherited: 0x0) 
struct FDFChannelMsgRecord
{
	struct FDFGenericChannelMsg Msg;  // 0x0(0x38)
	struct UDFCommsFormatBase* MsgFormat;  // 0x38(0x8)
	struct UDFCommChannel* MsgChannel;  // 0x40(0x8)

}; 
// ScriptStruct DonkehFrameworkComms.DFCommChannelEntry
// Size: 0x18(Inherited: 0x0) 
struct FDFCommChannelEntry
{
	struct FSoftObjectPath ChannelDefinition;  // 0x0(0x18)

}; 
// DelegateFunction DonkehFrameworkComms.DFTextCommsChatMsgReceivedDelegateMulti__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FDFTextCommsChatMsgReceivedDelegateMulti__DelegateSignature
{
	struct UDFCommChannel* MsgSourceChannel;  // 0x0(0x8)
	struct APlayerState* MsgSenderPS;  // 0x8(0x8)
	struct FString MsgContent;  // 0x10(0x10)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatUsesChannelByName
// Size: 0x14(Inherited: 0x0) 
struct FFormatUsesChannelByName
{
	struct FName FormatName;  // 0x0(0x8)
	struct FName ChannelNameToCheck;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function DonkehFrameworkComms.DFCommChannel.SetChannelState
// Size: 0x8(Inherited: 0x0) 
struct FSetChannelState
{
	struct UObject* NewChannelState;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatHasExclusiveChannelByName
// Size: 0xC(Inherited: 0x0) 
struct FFormatHasExclusiveChannelByName
{
	struct FName FormatName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.CanSendCommMsgViaChannel
// Size: 0x50(Inherited: 0x0) 
struct FCanSendCommMsgViaChannel
{
	struct UDFCommsFormatBase* ReceivingFormat;  // 0x0(0x8)
	struct UDFCommChannel* ReceivingChannel;  // 0x8(0x8)
	struct FDFGenericChannelMsg CommMsgToSend;  // 0x10(0x38)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bUseChannelAsNewExclusive : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool ReturnValue : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)

}; 
// DelegateFunction DonkehFrameworkComms.CommChannelCreationDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FCommChannelCreationDelegate__DelegateSignature
{
	struct UDFCommChannel* CreatedChannel;  // 0x0(0x8)

}; 
// ScriptStruct DonkehFrameworkComms.DFCommStateSetupParams
// Size: 0x18(Inherited: 0x0) 
struct FDFCommStateSetupParams
{
	struct UDFCommChannel* OwningChannel;  // 0x0(0x8)
	struct UDFCommChannelDefinition* OwningChannelDefinition;  // 0x8(0x8)
	struct UDFPlayerCommsComponent* OwningChannelCommsCompOwner;  // 0x10(0x8)

}; 
// Function DonkehFrameworkComms.DFCommWorldSubsystem.GameModePostLogin
// Size: 0x10(Inherited: 0x0) 
struct FGameModePostLogin
{
	struct AGameModeBase* GameMode;  // 0x0(0x8)
	struct APlayerController* NewPlayer;  // 0x8(0x8)

}; 
// DelegateFunction DonkehFrameworkComms.OnPlayerTalkingStateChangedOnChannelDelegateMulti__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnPlayerTalkingStateChangedOnChannelDelegateMulti__DelegateSignature
{
	struct UDFCommChannel* TalkerChannel;  // 0x0(0x8)
	struct APlayerState* TalkerPS;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsTalking : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFCommChannel.HasFormat
// Size: 0x10(Inherited: 0x0) 
struct FHasFormat
{
	struct UDFCommsFormatBase* Format;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct DonkehFrameworkComms.DFCommChannelMap
// Size: 0x170(Inherited: 0x108) 
struct FDFCommChannelMap : public FFastArraySerializer
{
	struct TArray<struct FDFCommChannelMapItemEntry> ChannelEntries;  // 0x108(0x10)
	struct TMap<struct FName, struct UDFCommChannel*> ChannelMap;  // 0x118(0x50)
	char pad_360[8];  // 0x168(0x8)

}; 
// Function DonkehFrameworkComms.DFCommsFormatBase.CanReadFromChannel
// Size: 0xC(Inherited: 0x0) 
struct FCanReadFromChannel
{
	struct FName ChannelName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function DonkehFrameworkComms.DFCommChannelStateLibrary.IsChannelStatePrepared
// Size: 0x18(Inherited: 0x0) 
struct FIsChannelStatePrepared
{
	struct TScriptInterface<IDFCommChannelStateInterface> ChannelState;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct DonkehFrameworkComms.DFGenericChannelMsg
// Size: 0x38(Inherited: 0x0) 
struct FDFGenericChannelMsg
{
	struct FString ChatMsgContent;  // 0x0(0x10)
	char bSenderIsTalking : 1;  // 0x10(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	char pad_17[8];  // 0x11(0x8)
	struct TArray<struct FString> OptionalMsgData;  // 0x18(0x10)
	struct APlayerState* SenderPS;  // 0x28(0x8)
	int32_t MsgID;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.ApplyVOIPTalkerSettingsForPlayer
// Size: 0x10(Inherited: 0x0) 
struct FApplyVOIPTalkerSettingsForPlayer
{
	struct APlayerState* TalkerPlayerState;  // 0x0(0x8)
	char ListenerLocalUserNum;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct DonkehFrameworkComms.DFCommsFormatEntry
// Size: 0x20(Inherited: 0x0) 
struct FDFCommsFormatEntry
{
	struct FName FormatName;  // 0x0(0x8)
	struct FSoftClassPath FormatClass;  // 0x8(0x18)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsCommChannelByName
// Size: 0xC(Inherited: 0x0) 
struct FContainsCommChannelByName
{
	struct FName ChannelNameToCheck;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.FindCommChannel
// Size: 0x18(Inherited: 0x0) 
struct FFindCommChannel
{
	struct FName ChannelName;  // 0x0(0x8)
	struct UDFCommChannel* OutChannelFound;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFVOIPCommsFormat.OnTalkerPSDestroyed
// Size: 0x8(Inherited: 0x0) 
struct FOnTalkerPSDestroyed
{
	struct AActor* DestroyedPS;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsCommChannel
// Size: 0x10(Inherited: 0x0) 
struct FContainsCommChannel
{
	struct UDFCommChannel* ChannelToCheck;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkComms.DFCommWorldSubsystem.InitPlayerComms
// Size: 0x10(Inherited: 0x0) 
struct FInitPlayerComms
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UDFPlayerCommsComponent* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFCommStatics.UpdateExclusiveChannelForFormatByName
// Size: 0x18(Inherited: 0x0) 
struct FUpdateExclusiveChannelForFormatByName
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName FormatNameToUpdate;  // 0x8(0x8)
	struct FName SingleChannelNameToUse;  // 0x10(0x8)

}; 
// ScriptStruct DonkehFrameworkComms.DFPlayerVOIPTalkingState
// Size: 0x10(Inherited: 0x0) 
struct FDFPlayerVOIPTalkingState
{
	char bWasTalking : 1;  // 0x0(0x1)
	char bIsTalking : 1;  // 0x0(0x1)
	char bPendingTalkerReset : 1;  // 0x0(0x1)
	char pad_0_1 : 5;  // 0x0(0x1)
	char pad_1[8];  // 0x1(0x8)
	struct UDFCommChannel* TalkerChannel;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.CreateCommChannelCallbackProxy.CreateCommChannelFor
// Size: 0x20(Inherited: 0x0) 
struct FCreateCommChannelFor
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UDFCommChannelDefinition* ChannelDef;  // 0x8(0x8)
	struct FName ChannelNameOverride;  // 0x10(0x8)
	struct UCreateCommChannelCallbackProxy* ReturnValue;  // 0x18(0x8)

}; 
// Function DonkehFrameworkComms.DFCommChannel.GetChannelDisplayName
// Size: 0x18(Inherited: 0x0) 
struct FGetChannelDisplayName
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function DonkehFrameworkComms.DFCommChannel.GetChannelGroupNameIfValid
// Size: 0x8(Inherited: 0x0) 
struct FGetChannelGroupNameIfValid
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ReceiveCommChannelAdded
// Size: 0x8(Inherited: 0x0) 
struct FReceiveCommChannelAdded
{
	struct UDFCommChannel* AddedChannel;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFCommStatics.SendCommsViaChannelByName
// Size: 0x58(Inherited: 0x0) 
struct FSendCommsViaChannelByName
{
	struct APlayerController* PlayerSender;  // 0x0(0x8)
	struct FName FormatName;  // 0x8(0x8)
	struct FName ReceivingChannelName;  // 0x10(0x8)
	struct FDFGenericChannelMsg MsgToSend;  // 0x18(0x38)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bUseChannelAsNewExclusive : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function DonkehFrameworkComms.DFCommChannel.GetChannelName
// Size: 0x8(Inherited: 0x0) 
struct FGetChannelName
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFCommStatics.ClearCurrentExclusiveChannelForFormat
// Size: 0x10(Inherited: 0x0) 
struct FClearCurrentExclusiveChannelForFormat
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UDFCommsFormatBase* FormatToUpdate;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFCommChannel.GetChannelNameStr
// Size: 0x10(Inherited: 0x0) 
struct FGetChannelNameStr
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function DonkehFrameworkComms.DFCommChannel.IsReady
// Size: 0x1(Inherited: 0x0) 
struct FIsReady
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientVerifyCommMsgFailed
// Size: 0x4(Inherited: 0x0) 
struct FClientVerifyCommMsgFailed
{
	int32_t VerifyMsgID;  // 0x0(0x4)

}; 
// Function DonkehFrameworkComms.DFCommStatics.UpdateExclusiveChannelForFormat
// Size: 0x18(Inherited: 0x0) 
struct FUpdateExclusiveChannelForFormat
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UDFCommsFormatBase* FormatToUpdate;  // 0x8(0x8)
	struct UDFCommChannel* SingleChannelToUse;  // 0x10(0x8)

}; 
// Function DonkehFrameworkComms.DFCommChannelDefinition.InstancesChannelWithGroup
// Size: 0x1(Inherited: 0x0) 
struct FInstancesChannelWithGroup
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DonkehFrameworkComms.DFCommChannelStateInterface.BP_OnSetupState
// Size: 0x18(Inherited: 0x0) 
struct FBP_OnSetupState
{
	struct FDFCommStateSetupParams SetupParams;  // 0x0(0x18)

}; 
// Function DonkehFrameworkComms.DFCommChannelStateLibrary.NotifyChannelOfPreparedState
// Size: 0x10(Inherited: 0x0) 
struct FNotifyChannelOfPreparedState
{
	struct TScriptInterface<IDFCommChannelStateInterface> ChannelState;  // 0x0(0x10)

}; 
// Function DonkehFrameworkComms.DFCommsFormatBase.CanWriteToChannel
// Size: 0xC(Inherited: 0x0) 
struct FCanWriteToChannel
{
	struct FName ChannelName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function DonkehFrameworkComms.DFCommStatics.PlayerHasCommChannel
// Size: 0x18(Inherited: 0x0) 
struct FPlayerHasCommChannel
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UDFCommChannel* Channel;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFCommsFormatBase.HasAccessToChannel
// Size: 0xC(Inherited: 0x0) 
struct FHasAccessToChannel
{
	struct FName ChannelName;  // 0x0(0x8)
	uint8_t  AccessRulesToCheck;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)

}; 
// Function DonkehFrameworkComms.DFCommStatics.ClearCurrentExclusiveChannelForFormatByName
// Size: 0x10(Inherited: 0x0) 
struct FClearCurrentExclusiveChannelForFormatByName
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName FormatNameToUpdate;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFCommStatics.CommsFormatGetExclusiveChannel
// Size: 0x10(Inherited: 0x0) 
struct FCommsFormatGetExclusiveChannel
{
	struct UDFCommsFormatBase* Format;  // 0x0(0x8)
	struct UDFCommChannel* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFCommStatics.CommsFormatUsesChannel
// Size: 0x20(Inherited: 0x0) 
struct FCommsFormatUsesChannel
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UDFCommsFormatBase* Format;  // 0x8(0x8)
	struct UDFCommChannel* ChannelToCheck;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFrameworkComms.DFCommStatics.CommsFormatGetExclusiveChannelByName
// Size: 0x18(Inherited: 0x0) 
struct FCommsFormatGetExclusiveChannelByName
{
	struct APlayerController* PlayerFormatOwner;  // 0x0(0x8)
	struct FName FormatName;  // 0x8(0x8)
	struct UDFCommChannel* ReturnValue;  // 0x10(0x8)

}; 
// Function DonkehFrameworkComms.DFCommStatics.CommsFormatUsesChannelByName
// Size: 0x20(Inherited: 0x0) 
struct FCommsFormatUsesChannelByName
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName FormatName;  // 0x8(0x8)
	struct FName ChannelNameToCheck;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveCommChannel
// Size: 0x8(Inherited: 0x0) 
struct FRemoveCommChannel
{
	struct UDFCommChannel* ChannelToRemove;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientClearCurrentExclusiveChannelForCommsFormat
// Size: 0x8(Inherited: 0x0) 
struct FClientClearCurrentExclusiveChannelForCommsFormat
{
	struct FName FormatName;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFCommStatics.CommsFormatHasExclusiveChannel
// Size: 0x10(Inherited: 0x0) 
struct FCommsFormatHasExclusiveChannel
{
	struct UDFCommsFormatBase* Format;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkComms.DFCommStatics.CommsFormatHasExclusiveChannelByName
// Size: 0x18(Inherited: 0x0) 
struct FCommsFormatHasExclusiveChannelByName
{
	struct APlayerController* PlayerFormatOwner;  // 0x0(0x8)
	struct FName FormatName;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFCommStatics.FindCommsComponentByPlayer
// Size: 0x18(Inherited: 0x0) 
struct FFindCommsComponentByPlayer
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UDFPlayerCommsComponent* OutPlayerCommsComp;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatUsesChannel
// Size: 0x18(Inherited: 0x0) 
struct FFormatUsesChannel
{
	struct UDFCommsFormatBase* Format;  // 0x0(0x8)
	struct UDFCommChannel* ChannelToCheck;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.FormatHasExclusiveChannel
// Size: 0x10(Inherited: 0x0) 
struct FFormatHasExclusiveChannel
{
	struct UDFCommsFormatBase* Format;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkComms.DFCommStatics.PlayerHasCommChannelByName
// Size: 0x18(Inherited: 0x0) 
struct FPlayerHasCommChannelByName
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct FName ChannelName;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFCommStatics.SendCommsViaChannel
// Size: 0x58(Inherited: 0x0) 
struct FSendCommsViaChannel
{
	struct APlayerController* PlayerSender;  // 0x0(0x8)
	struct UDFCommsFormatBase* FormatToUse;  // 0x8(0x8)
	struct UDFCommChannel* ReceivingChannel;  // 0x10(0x8)
	struct FDFGenericChannelMsg MsgToSend;  // 0x18(0x38)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bUseChannelAsNewExclusive : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function DonkehFrameworkComms.DFCommWorldSubsystem.PostSeamlessTravelPCDestroyed
// Size: 0x8(Inherited: 0x0) 
struct FPostSeamlessTravelPCDestroyed
{
	struct AActor* DestroyedPlayerActor;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.CanRecvCommMsgViaChannel
// Size: 0x50(Inherited: 0x0) 
struct FCanRecvCommMsgViaChannel
{
	struct FName SourceFormatName;  // 0x0(0x8)
	struct FName SourceChannelName;  // 0x8(0x8)
	struct FDFGenericChannelMsg CommMsgToReceive;  // 0x10(0x38)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.CanSendAndRecvCommMsgViaChannel
// Size: 0x50(Inherited: 0x0) 
struct FCanSendAndRecvCommMsgViaChannel
{
	struct FName FormatName;  // 0x0(0x8)
	struct FName ChannelName;  // 0x8(0x8)
	struct FDFGenericChannelMsg CommMsg;  // 0x10(0x38)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ClearCurrentExclusiveChannelForCommsFormat
// Size: 0x8(Inherited: 0x0) 
struct FClearCurrentExclusiveChannelForCommsFormat
{
	struct UDFCommsFormatBase* Format;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ClearCurrentExclusiveChannelForCommsFormatByName
// Size: 0x8(Inherited: 0x0) 
struct FClearCurrentExclusiveChannelForCommsFormatByName
{
	struct FName FormatName;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientRecvCommMsgFromChannel
// Size: 0x48(Inherited: 0x0) 
struct FClientRecvCommMsgFromChannel
{
	struct FName SourceFormatName;  // 0x0(0x8)
	struct UDFCommChannel* SourceChannel;  // 0x8(0x8)
	struct FDFGenericChannelMsg ReceivedCommMsg;  // 0x10(0x38)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ClientUpdateExclusiveChannelToUseForCommsFormat
// Size: 0x10(Inherited: 0x0) 
struct FClientUpdateExclusiveChannelToUseForCommsFormat
{
	struct FName FormatName;  // 0x0(0x8)
	struct UDFCommChannel* SingleChannelToUse;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ContainsAssociatedCommsFormat
// Size: 0xC(Inherited: 0x0) 
struct FContainsAssociatedCommsFormat
{
	struct FName FormatName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.FindAssociatedCommsFormat
// Size: 0x18(Inherited: 0x0) 
struct FFindAssociatedCommsFormat
{
	struct FName FormatName;  // 0x0(0x8)
	struct UDFCommsFormatBase* OutFormatFound;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ReceiveCommChannelPreRemoved
// Size: 0x8(Inherited: 0x0) 
struct FReceiveCommChannelPreRemoved
{
	struct UDFCommChannel* RemovedChannel;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.RemoveCommChannelByName
// Size: 0x8(Inherited: 0x0) 
struct FRemoveCommChannelByName
{
	struct FName ChannelNameToRemove;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.SendCommMsgViaChannel
// Size: 0x50(Inherited: 0x0) 
struct FSendCommMsgViaChannel
{
	struct UDFCommsFormatBase* FormatToUse;  // 0x0(0x8)
	struct UDFCommChannel* ReceivingChannel;  // 0x8(0x8)
	struct FDFGenericChannelMsg CommMsgToSend;  // 0x10(0x38)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bUseChannelAsNewExclusive : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.SendCommMsgViaChannelByName
// Size: 0x50(Inherited: 0x0) 
struct FSendCommMsgViaChannelByName
{
	struct FName FormatName;  // 0x0(0x8)
	struct FName ReceivingChannelName;  // 0x8(0x8)
	struct FDFGenericChannelMsg CommMsgToSend;  // 0x10(0x38)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bUseChannelAsNewExclusive : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerClearCurrentExclusiveChannelForCommsFormat
// Size: 0x8(Inherited: 0x0) 
struct FServerClearCurrentExclusiveChannelForCommsFormat
{
	struct FName FormatName;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerRequestExclusiveChannelUsedForCommsFormat
// Size: 0x8(Inherited: 0x0) 
struct FServerRequestExclusiveChannelUsedForCommsFormat
{
	struct FName RequestedFormatName;  // 0x0(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerSendCommMsgViaChannel
// Size: 0x48(Inherited: 0x0) 
struct FServerSendCommMsgViaChannel
{
	struct FName FormatName;  // 0x0(0x8)
	struct UDFCommChannel* ReceivingChannel;  // 0x8(0x8)
	struct FDFGenericChannelMsg CommMsg;  // 0x10(0x38)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerSendCommMsgViaExclChannel
// Size: 0x48(Inherited: 0x0) 
struct FServerSendCommMsgViaExclChannel
{
	struct FName FormatName;  // 0x0(0x8)
	struct UDFCommChannel* ReceivingChannel;  // 0x8(0x8)
	struct FDFGenericChannelMsg CommMsg;  // 0x10(0x38)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerUpdateExclusiveChannelToUseForCommsFormat
// Size: 0x10(Inherited: 0x0) 
struct FServerUpdateExclusiveChannelToUseForCommsFormat
{
	struct FName FormatName;  // 0x0(0x8)
	struct UDFCommChannel* SingleChannelToUse;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.ServerVerifyCommMsg
// Size: 0x4(Inherited: 0x0) 
struct FServerVerifyCommMsg
{
	int32_t VerifyMsgID;  // 0x0(0x4)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.UpdateExclusiveChannelToUseForCommsFormat
// Size: 0x10(Inherited: 0x0) 
struct FUpdateExclusiveChannelToUseForCommsFormat
{
	struct UDFCommsFormatBase* Format;  // 0x0(0x8)
	struct UDFCommChannel* SingleChannelToUse;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFPlayerCommsComponent.UpdateExclusiveChannelToUseForCommsFormatByName
// Size: 0x10(Inherited: 0x0) 
struct FUpdateExclusiveChannelToUseForCommsFormatByName
{
	struct FName FormatName;  // 0x0(0x8)
	struct FName SingleChannelNameToUse;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.GetValidVoiceEntryForPlayer
// Size: 0x18(Inherited: 0x0) 
struct FGetValidVoiceEntryForPlayer
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct FDFPlayerVOIPTalkingState ReturnValue;  // 0x8(0x10)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.GetVoiceSynthComponentForVOIPTalker
// Size: 0x10(Inherited: 0x0) 
struct FGetVoiceSynthComponentForVOIPTalker
{
	struct UVOIPTalker* Talker;  // 0x0(0x8)
	struct UVoipListenerSynthComponent* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.GetVoiceSynthOwnerOfAudioComponent
// Size: 0x10(Inherited: 0x0) 
struct FGetVoiceSynthOwnerOfAudioComponent
{
	struct UAudioComponent* TalkerAudioComp;  // 0x0(0x8)
	struct UVoipListenerSynthComponent* ReturnValue;  // 0x8(0x8)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalkerPendingReset
// Size: 0x10(Inherited: 0x0) 
struct FIsPlayerTalkerPendingReset
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalking
// Size: 0x10(Inherited: 0x0) 
struct FIsPlayerTalking
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.IsPlayerTalkingOverChannel
// Size: 0x18(Inherited: 0x0) 
struct FIsPlayerTalkingOverChannel
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct UDFCommChannel* TalkChannel;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function DonkehFrameworkComms.DFVOIPCommStatics.WasPlayerTalking
// Size: 0x10(Inherited: 0x0) 
struct FWasPlayerTalking
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
