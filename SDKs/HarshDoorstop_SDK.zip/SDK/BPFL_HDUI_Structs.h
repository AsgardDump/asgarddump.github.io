#pragma once 
#include "SDK.h" 
 
 
// Function BPFL_HDUI.BPFL_HDUI_C.GetHealthColorByRatio
// Size: 0x34(Inherited: 0x0) 
struct FGetHealthColorByRatio
{
	float Health;  // 0x0(0x4)
	float MaxHealth;  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor ColorToUse;  // 0x10(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x20(0x4)
	struct FLinearColor CallFunc_GetNormHealthColorByRatio_ColorToUse;  // 0x24(0x10)

}; 
// Function BPFL_HDUI.BPFL_HDUI_C.GetNormHealthColorByRatio
// Size: 0x31(Inherited: 0x0) 
struct FGetNormHealthColorByRatio
{
	float HealthValueNorm;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FLinearColor ColorToUse;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_3 : 1;  // 0x30(0x1)

}; 
// Function BPFL_HDUI.BPFL_HDUI_C.GetIconTextureForStanceState
// Size: 0x68(Inherited: 0x0) 
struct FGetIconTextureForStanceState
{
	uint8_t  State;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UTexture2D* IconTex;  // 0x10(0x8)
	uint8_t  Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UTexture2D* Temp_object_Variable;  // 0x20(0x8)
	struct UTexture2D* Temp_object_Variable_2;  // 0x28(0x8)
	struct UTexture2D* Temp_object_Variable_3;  // 0x30(0x8)
	struct UTexture2D* Temp_object_Variable_4;  // 0x38(0x8)
	struct UTexture2D* Temp_object_Variable_5;  // 0x40(0x8)
	struct UTexture2D* Temp_object_Variable_6;  // 0x48(0x8)
	struct UTexture2D* Temp_object_Variable_7;  // 0x50(0x8)
	struct UTexture2D* Temp_object_Variable_8;  // 0x58(0x8)
	struct UTexture2D* K2Node_Select_Default;  // 0x60(0x8)

}; 
// Function BPFL_HDUI.BPFL_HDUI_C.GetIconBrushForStanceState
// Size: 0x128(Inherited: 0x0) 
struct FGetIconBrushForStanceState
{
	uint8_t  State;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FSlateBrush IconBrush;  // 0x10(0x88)
	struct UTexture2D* CallFunc_GetIconTextureForStanceState_IconTex;  // 0x98(0x8)
	struct FSlateBrush CallFunc_MakeBrushFromTexture_ReturnValue;  // 0xA0(0x88)

}; 
// Function BPFL_HDUI.BPFL_HDUI_C.ParseServerBadgesFromTable
// Size: 0x2A0(Inherited: 0x0) 
struct FParseServerBadgesFromTable
{
	struct UDataTable* BadgeTable;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct TArray<struct FFServerBadgeUIDefinition> SortedBadgeDefs;  // 0x10(0x10)
	struct TArray<int32_t> BadgeOrderingIdxs;  // 0x20(0x10)
	struct TArray<struct FFServerBadgeUIDefinition> BadgeDefsSorted;  // 0x30(0x10)
	struct TArray<struct FFServerBadgeUIDefinition> BadgeDefs;  // 0x40(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x58(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x68(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x6C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x70(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x79(0x1)
	char pad_122[2];  // 0x7A(0x2)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x84(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x88(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x8C(0x8)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x94(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x98(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x9C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0xA0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0xA4(0x4)
	struct FFServerBadgeUIDefinition CallFunc_Array_Get_Item_2;  // 0xA8(0x98)
	int32_t CallFunc_Array_Get_Item_3;  // 0x140(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x144(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x148(0x4)
	char pad_332_1 : 7;  // 0x14C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x14C(0x1)
	char pad_333_1 : 7;  // 0x14D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x14D(0x1)
	char pad_334[2];  // 0x14E(0x2)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x150(0x4)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x154(0x1)
	char pad_341_1 : 7;  // 0x155(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x155(0x1)
	char pad_342[2];  // 0x156(0x2)
	struct FFServerBadgeUIDefinition CallFunc_Array_Get_Item_4;  // 0x158(0x98)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x1F0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x1F4(0x4)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x1F8(0x1)
	char pad_505[7];  // 0x1F9(0x7)
	struct FFServerBadgeUIDefinition CallFunc_GetDataTableRowFromName_OutRow;  // 0x200(0x98)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x298(0x1)
	char pad_665[3];  // 0x299(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0x29C(0x4)

}; 
