#pragma once 
#include <WBP_HUD_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUD.WBP_HUD_C
// Size: 0x27D(Inherited: 0x238) 
struct UWBP_HUD_C : public UHDUIUWHUD
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UWBP_CaptureStatus_C* CaptureStatus;  // 0x240(0x8)
	struct UWBP_HUDElement_Compass_C* Compass;  // 0x248(0x8)
	struct UWBP_HUDElement_EquipmentSelect_C* EquipmentSelect;  // 0x250(0x8)
	struct UWBP_PlayerStatus_C* PlayerStatus;  // 0x258(0x8)
	struct UWBP_HUDElement_TextChat_C* TextChat;  // 0x260(0x8)
	struct UWBP_HUDElement_VOIPIndicator_C* VOIPStatus;  // 0x268(0x8)
	struct UWBP_WeaponStatus_C* WeaponStatus;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool bShowCompass : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool bShowPlayerStatus : 1;  // 0x279(0x1)
	char pad_634_1 : 7;  // 0x27A(0x1)
	bool bShowWeaponStatus : 1;  // 0x27A(0x1)
	char pad_635_1 : 7;  // 0x27B(0x1)
	bool bShowCaptureStatus : 1;  // 0x27B(0x1)
	char pad_636_1 : 7;  // 0x27C(0x1)
	bool bShowEquipmentSelect : 1;  // 0x27C(0x1)

	void SetHUDElementVisibility(struct UWidget* Widget, bool bShown); // Function WBP_HUD.WBP_HUD_C.SetHUDElementVisibility
	void ToggleWeaponStatus(bool bVisible); // Function WBP_HUD.WBP_HUD_C.ToggleWeaponStatus
	void ToggleEquipmentSelect(bool bVisible); // Function WBP_HUD.WBP_HUD_C.ToggleEquipmentSelect
	void Construct(); // Function WBP_HUD.WBP_HUD_C.Construct
	void ExecuteUbergraph_WBP_HUD(int32_t EntryPoint); // Function WBP_HUD.WBP_HUD_C.ExecuteUbergraph_WBP_HUD
}; 



