#pragma once 
#include <WBP_DeployMenu_SpawnMapView_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C
// Size: 0x280(Inherited: 0x230) 
struct UWBP_DeployMenu_SpawnMapView_C : public UDeployMenu_SpawnMapView
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UWBP_DeployMenu_SpawnMinimap_C* Minimap;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool bMenuInitialized : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct FMulticastInlineDelegate OnPreloadFinished;  // 0x248(0x10)
	struct AActor* SelectedPOIActor;  // 0x258(0x8)
	struct FMulticastInlineDelegate OnSpawnPointSelected;  // 0x260(0x10)
	struct FMulticastInlineDelegate OnSpawnPointDeselected;  // 0x270(0x10)

	void UpdatePlayerPOIs(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.UpdatePlayerPOIs
	void GetMinimapData(bool& bSuccess, struct TSoftObjectPtr<UTexture2D>& MinimapImg, struct FMinimapGenerationSettings& MinimapSettings); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.GetMinimapData
	void PreloadContent(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.PreloadContent
	void Construct(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.Construct
	void BndEvt__Minimap_K2Node_ComponentBoundEvent_1_OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_1_OnPreloadFinished__DelegateSignature
	void OnPreloadFinished (SpawnMapView)(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnPreloadFinished (SpawnMapView)
	void BndEvt__Minimap_K2Node_ComponentBoundEvent_0_OnSpawnPointSelected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_0_OnSpawnPointSelected__DelegateSignature
	void BndEvt__Minimap_K2Node_ComponentBoundEvent_2_OnSpawnPointDeselected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.BndEvt__Minimap_K2Node_ComponentBoundEvent_2_OnSpawnPointDeselected__DelegateSignature
	void ExecuteUbergraph_WBP_DeployMenu_SpawnMapView(int32_t EntryPoint); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.ExecuteUbergraph_WBP_DeployMenu_SpawnMapView
	void OnSpawnPointDeselected__DelegateSignature(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnSpawnPointDeselected__DelegateSignature
	void OnSpawnPointSelected__DelegateSignature(struct AActor* POISpawnPointActor); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnSpawnPointSelected__DelegateSignature
	void OnPreloadFinished__DelegateSignature(); // Function WBP_DeployMenu_SpawnMapView.WBP_DeployMenu_SpawnMapView_C.OnPreloadFinished__DelegateSignature
}; 



