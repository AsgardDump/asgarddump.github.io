#pragma once 
#include <WBP_EntitlementBadge_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_EntitlementBadge.WBP_EntitlementBadge_C
// Size: 0x2D8(Inherited: 0x230) 
struct UWBP_EntitlementBadge_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UImage* BadgeIcon;  // 0x238(0x8)
	struct FFEntitlementBadgeUIDefinition BadgeUIDefinition;  // 0x240(0x98)

	void PreConstruct(bool IsDesignTime); // Function WBP_EntitlementBadge.WBP_EntitlementBadge_C.PreConstruct
	void ExecuteUbergraph_WBP_EntitlementBadge(int32_t EntryPoint); // Function WBP_EntitlementBadge.WBP_EntitlementBadge_C.ExecuteUbergraph_WBP_EntitlementBadge
}; 



