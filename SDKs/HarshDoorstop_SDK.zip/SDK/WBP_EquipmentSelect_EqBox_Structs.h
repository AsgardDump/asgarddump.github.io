#pragma once 
#include "SDK.h" 
 
 
// Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.ExecuteUbergraph_WBP_EquipmentSelect_EqBox
// Size: 0x68(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_EquipmentSelect_EqBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	uint8_t  Temp_byte_Variable;  // 0x5(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsSelectableEquipment_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x10(0x18)
	uint8_t  K2Node_Select_Default;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x2C(0x38)
	float K2Node_Event_InDeltaTime;  // 0x64(0x4)

}; 
// Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.SetEnabled
// Size: 0x6(Inherited: 0x0) 
struct FSetEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	uint8_t  Temp_byte_Variable;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool Temp_bool_Variable : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0x4(0x1)
	uint8_t  K2Node_Select_Default;  // 0x5(0x1)

}; 
// Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.IsHighlighted
// Size: 0x1(Inherited: 0x0) 
struct FIsHighlighted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHighlight : 1;  // 0x0(0x1)

}; 
// Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_EquipmentSelect_EqBox.WBP_EquipmentSelect_EqBox_C.SetHighlight
// Size: 0x8(Inherited: 0x0) 
struct FSetHighlight
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHighlighted : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float CallFunc_SelectFloat_ReturnValue;  // 0x4(0x4)

}; 
