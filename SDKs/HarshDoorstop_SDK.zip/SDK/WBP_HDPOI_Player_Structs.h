#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.ExecuteUbergraph_WBP_HDPOI_Player
// Size: 0xD4(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HDPOI_Player
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct FSlateBrush K2Node_Event_NewIconBrush;  // 0x8(0x88)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x90(0x38)
	float K2Node_Event_InDeltaTime;  // 0xC8(0x4)
	float CallFunc_GetRenderTransformAngle_ReturnValue;  // 0xCC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xD0(0x4)

}; 
// Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.SetIconBrush
// Size: 0x88(Inherited: 0x88) 
struct FSetIconBrush : public FSetIconBrush
{
	struct FSlateBrush NewIconBrush;  // 0x0(0x88)

}; 
// Function WBP_HDPOI_Player.WBP_HDPOI_Player_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
