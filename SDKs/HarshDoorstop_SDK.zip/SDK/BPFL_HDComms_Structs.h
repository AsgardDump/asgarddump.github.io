#pragma once 
#include "SDK.h" 
 
 
// Function BPFL_HDComms.BPFL_HDComms_C.GetValidCommsComponentForPlayer
// Size: 0x38(Inherited: 0x0) 
struct FGetValidCommsComponentForPlayer
{
	struct APlayerController* Player;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UDFPlayerCommsComponent* PlayerCommsComp;  // 0x10(0x8)
	struct UDFCommWorldSubsystem* CallFunc_GetWorldSubsystem_ReturnValue;  // 0x18(0x8)
	struct UDFPlayerCommsComponent* CallFunc_FindCommsComponentByPlayer_OutPlayerCommsComp;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_FindCommsComponentByPlayer_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UDFPlayerCommsComponent* CallFunc_InitPlayerComms_ReturnValue;  // 0x30(0x8)

}; 
// Function BPFL_HDComms.BPFL_HDComms_C.SetupNewTeamChannel
// Size: 0x21(Inherited: 0x0) 
struct FSetupNewTeamChannel
{
	struct UDFCommChannel* CreatedChannel;  // 0x0(0x8)
	struct AHDTeamState* TeamToAssociate;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UHDTeamCommChannelState* K2Node_DynamicCast_AsHDTeam_Comm_Channel_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_HDComms.BPFL_HDComms_C.GetColorForCommChannel
// Size: 0x120(Inherited: 0x0) 
struct FGetColorForCommChannel
{
	struct UDFCommChannel* Channel;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct FSlateColor ChannelColor;  // 0x10(0x28)
	struct FSlateColor CommandChannelGroupColor;  // 0x38(0x28)
	struct FSlateColor SquadChannelGroupColor;  // 0x60(0x28)
	struct FSlateColor TeamChannelColor;  // 0x88(0x28)
	struct FSlateColor LocalChannelGroupColor;  // 0xB0(0x28)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool Temp_bool_Variable : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	struct FName CallFunc_GetChannelName_ReturnValue;  // 0xDC(0x8)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_InstancesChannelWithGroup_ReturnValue : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	struct FName K2Node_Select_Default;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0xF8(0x28)

}; 
// Function BPFL_HDComms.BPFL_HDComms_C.SetupNewSquadChannel
// Size: 0x21(Inherited: 0x0) 
struct FSetupNewSquadChannel
{
	struct UDFCommChannel* CreatedChannel;  // 0x0(0x8)
	struct AHDSquadState* SquadToAssociate;  // 0x8(0x8)
	struct UObject* __WorldContext;  // 0x10(0x8)
	struct UHDSQCommChannelState* K2Node_DynamicCast_AsHDSQComm_Channel_State;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function BPFL_HDComms.BPFL_HDComms_C.GetTextChatIconForCommChannel
// Size: 0x51(Inherited: 0x0) 
struct FGetTextChatIconForCommChannel
{
	struct UDFCommChannel* Channel;  // 0x0(0x8)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UTexture2D* ChannelChatIcon;  // 0x10(0x8)
	struct UTexture2D* CommandChannelIcon;  // 0x18(0x8)
	struct UTexture2D* SquadChannelIcon;  // 0x20(0x8)
	struct UTexture2D* TeamChannelIcon;  // 0x28(0x8)
	struct UTexture2D* GlobalChannelIcon;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Temp_bool_Variable : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FName CallFunc_GetChannelName_ReturnValue;  // 0x3C(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_InstancesChannelWithGroup_ReturnValue : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FName K2Node_Select_Default;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0x50(0x1)

}; 
