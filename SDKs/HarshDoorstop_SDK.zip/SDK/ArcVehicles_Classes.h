#pragma once 
#include <ArcVehicles_Structs.h>
 
 
 
// Class ArcVehicles.ArcVehicleSeat
// Size: 0x288(Inherited: 0x280) 
struct AArcVehicleSeat : public AArcVehiclePawn
{
	struct UArcVehicleSeatConfig* SeatConfig;  // 0x280(0x8)

}; 



// Class ArcVehicles.ArcVehicleBPFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UArcVehicleBPFunctionLibrary : public UBlueprintFunctionLibrary
{

	bool IsSeatRefValid(struct FArcVehicleSeatReference SeatRef); // Function ArcVehicles.ArcVehicleBPFunctionLibrary.IsSeatRefValid
	struct UArcVehicleSeatConfig* GetVehicleSeatConfigFromRef(struct FArcVehicleSeatReference SeatRef); // Function ArcVehicles.ArcVehicleBPFunctionLibrary.GetVehicleSeatConfigFromRef
	struct AArcBaseVehicle* GetVehicleFromSeatConfig(struct FArcVehicleSeatReference SeatRef); // Function ArcVehicles.ArcVehicleBPFunctionLibrary.GetVehicleFromSeatConfig
}; 



// Class ArcVehicles.ArcVehiclePlayerSeatComponent
// Size: 0x198(Inherited: 0xB0) 
struct UArcVehiclePlayerSeatComponent : public UActorComponent
{
	struct FArcVehicleSeatReference CurrentSeatConfig;  // 0xB0(0x10)
	struct FArcVehicleSeatReference PreviousSeatConfig;  // 0xC0(0x10)
	struct APlayerState* StoredPlayerState;  // 0xD0(0x8)
	char pad_216[88];  // 0xD8(0x58)
	struct TArray<struct FString> ServerDebugStrings;  // 0x130(0x10)
	char pad_320[8];  // 0x140(0x8)
	struct TMap<struct UPrimitiveComponent*, char ECollisionResponse> PreviousVehicleCollisionResponses;  // 0x148(0x50)

	void ServerPrintDebug_Request(); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.ServerPrintDebug_Request
	void OnSeatChangeEvent(uint8_t  SeatChangeType); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnSeatChangeEvent
	void OnRep_StoredPlayerState(struct APlayerState* InPreviousPlayerState); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_StoredPlayerState
	void OnRep_ServerDebugStrings(); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_ServerDebugStrings
	void OnRep_SeatConfig(struct FArcVehicleSeatReference& InPreviousSeatConfig); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_SeatConfig
	void BP_OnRep_StoredPlayerState(struct APlayerState* InPreviousPlayerState); // Function ArcVehicles.ArcVehiclePlayerSeatComponent.BP_OnRep_StoredPlayerState
}; 



// Class ArcVehicles.ArcVehiclePawn
// Size: 0x280(Inherited: 0x280) 
struct AArcVehiclePawn : public APawn
{

	void NotifyPlayerSeatChangeEvent(struct APlayerState* Player, struct UArcVehicleSeatConfig* ToSeat, struct UArcVehicleSeatConfig* FromSeat, uint8_t  SeatChangeEvent); // Function ArcVehicles.ArcVehiclePawn.NotifyPlayerSeatChangeEvent
	struct UArcVehicleSeatConfig* GetSeatConfig(); // Function ArcVehicles.ArcVehiclePawn.GetSeatConfig
	struct AArcBaseVehicle* GetOwningVehicle(); // Function ArcVehicles.ArcVehiclePawn.GetOwningVehicle
}; 



// Class ArcVehicles.ArcBaseVehicle
// Size: 0x2C8(Inherited: 0x280) 
struct AArcBaseVehicle : public AArcVehiclePawn
{
	struct UArcVehicleSeatConfig* DriverSeatConfig;  // 0x280(0x8)
	struct TArray<struct UArcVehicleSeatConfig*> AdditionalSeatConfigs;  // 0x288(0x10)
	struct TArray<struct UArcVehicleSeatConfig*> ReplicatedSeatConfigs;  // 0x298(0x10)
	struct TArray<struct FArcVehicleSeatChangeEvent> SeatChangeQueue;  // 0x2A8(0x10)
	struct TArray<struct FString> ServerDebugStrings;  // 0x2B8(0x10)

	void SetupSeat(struct UArcVehicleSeatConfig* SeatConfig); // Function ArcVehicles.ArcBaseVehicle.SetupSeat
	void ServerPrintDebug_Request(); // Function ArcVehicles.ArcBaseVehicle.ServerPrintDebug_Request
	void RequestLeaveVehicle(struct APlayerState* InPlayerState); // Function ArcVehicles.ArcBaseVehicle.RequestLeaveVehicle
	void RequestEnterSeat(struct APlayerState* InPlayerState, int32_t RequestedSeatIndex, bool bIgnoreRestrictions); // Function ArcVehicles.ArcBaseVehicle.RequestEnterSeat
	void RequestEnterAnySeat(struct APlayerState* InPlayerState); // Function ArcVehicles.ArcBaseVehicle.RequestEnterAnySeat
	void OnRep_ServerDebugStrings(); // Function ArcVehicles.ArcBaseVehicle.OnRep_ServerDebugStrings
	bool IsValidSeatIndex(int32_t InSeatIndex); // Function ArcVehicles.ArcBaseVehicle.IsValidSeatIndex
	void GetSortedExitPoints(struct FTransform InputLocation, struct TArray<struct FTransform>& OutTransformArray); // Function ArcVehicles.ArcBaseVehicle.GetSortedExitPoints
	struct FTransform GetNearestExitTransform(struct FTransform InputLocation); // Function ArcVehicles.ArcBaseVehicle.GetNearestExitTransform
	struct UArcVehicleSeatConfig* GetDriverSeat(); // Function ArcVehicles.ArcBaseVehicle.GetDriverSeat
	void GetAllSeats(struct TArray<struct UArcVehicleSeatConfig*>& Seats); // Function ArcVehicles.ArcBaseVehicle.GetAllSeats
}; 



// Class ArcVehicles.ArcVehiclePlayerStateComponent
// Size: 0xB8(Inherited: 0xB0) 
struct UArcVehiclePlayerStateComponent : public UActorComponent
{
	struct APawn* StoredPlayerPawn;  // 0xB0(0x8)

}; 



// Class ArcVehicles.ArcVehicleEngineSubsystem
// Size: 0x40(Inherited: 0x30) 
struct UArcVehicleEngineSubsystem : public UEngineSubsystem
{
	char pad_48[16];  // 0x30(0x10)

}; 



// Class ArcVehicles.ArcVehicleDeveloperSettings
// Size: 0x48(Inherited: 0x38) 
struct UArcVehicleDeveloperSettings : public UDeveloperSettings
{
	UArcVehiclePlayerSeatComponent* PlayerSeatComponentClass;  // 0x38(0x8)
	UArcVehiclePlayerStateComponent* PlayerStateComponentClass;  // 0x40(0x8)

}; 



// Class ArcVehicles.ArcVehicleExitPoint
// Size: 0x1F0(Inherited: 0x1F0) 
struct UArcVehicleExitPoint : public USceneComponent
{

}; 



// Class ArcVehicles.ArcVehicleSeatConfig
// Size: 0xD8(Inherited: 0xB0) 
struct UArcVehicleSeatConfig : public UActorComponent
{
	struct FArcOwnerAttachmentReference AttachSeatToComponent;  // 0xB0(0x10)
	struct APlayerState* PlayerInSeat;  // 0xC0(0x8)
	struct UArcVehiclePlayerSeatComponent* PlayerSeatComponent;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bPlayerVisible : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)

	void UnAttachPlayerFromSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.UnAttachPlayerFromSeat
	void SetupSeatAttachment(); // Function ArcVehicles.ArcVehicleSeatConfig.SetupSeatAttachment
	bool IsOpenSeat(); // Function ArcVehicles.ArcVehicleSeatConfig.IsOpenSeat
	bool IsDriverSeat(); // Function ArcVehicles.ArcVehicleSeatConfig.IsDriverSeat
	struct AArcBaseVehicle* GetVehicleOwner(); // Function ArcVehicles.ArcVehicleSeatConfig.GetVehicleOwner
	void BP_UnAttachPlayerFromSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.BP_UnAttachPlayerFromSeat
	void BP_AttachPlayerToSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.BP_AttachPlayerToSeat
	void AttachPlayerToSeat(struct APlayerState* Player); // Function ArcVehicles.ArcVehicleSeatConfig.AttachPlayerToSeat
}; 



// Class ArcVehicles.ArcVehicleSeatConfig_PlayerAttachment
// Size: 0xD8(Inherited: 0xD8) 
struct UArcVehicleSeatConfig_PlayerAttachment : public UArcVehicleSeatConfig
{

}; 



// Class ArcVehicles.ArcVehicleSeatConfig_SeatPawn
// Size: 0x100(Inherited: 0xD8) 
struct UArcVehicleSeatConfig_SeatPawn : public UArcVehicleSeatConfig_PlayerAttachment
{
	AArcVehicleSeat* SeatPawnClass;  // 0xD8(0x8)
	struct FArcOwnerAttachmentReference PlayerCharacterAttachToComponent;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool bResetControlRotationOnEnter : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct AArcVehiclePawn* SeatPawn;  // 0xF8(0x8)

	void OnRep_SeatPawn(struct AArcVehiclePawn* OldSeatPawn); // Function ArcVehicles.ArcVehicleSeatConfig_SeatPawn.OnRep_SeatPawn
}; 



// Class ArcVehicles.ArcVehicleTurretMovementComp
// Size: 0x1C0(Inherited: 0x138) 
struct UArcVehicleTurretMovementComp : public UPawnMovementComponent
{
	char pad_312_1 : 7;  // 0x138(0x1)
	bool bIgnoreBaseRotation : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool bIgnorePitch : 1;  // 0x139(0x1)
	char pad_314_1 : 7;  // 0x13A(0x1)
	bool bIgnoreYaw : 1;  // 0x13A(0x1)
	char pad_315_1 : 7;  // 0x13B(0x1)
	bool bIgnoreRoll : 1;  // 0x13B(0x1)
	char pad_316[4];  // 0x13C(0x4)
	struct USceneComponent* UpdatedPitchComponent;  // 0x140(0x8)
	struct FRotator RotationRate;  // 0x148(0xC)
	char pad_340[44];  // 0x154(0x2C)
	struct USceneComponent* CurrentBase;  // 0x180(0x8)
	struct FArcVehicleTurretMovementPostPhysicsTickFunction PostPhysicsTickFunction;  // 0x188(0x30)
	char pad_440[8];  // 0x1B8(0x8)

	void Server_ServerMove(struct FRotator FullRotation); // Function ArcVehicles.ArcVehicleTurretMovementComp.Server_ServerMove
}; 



