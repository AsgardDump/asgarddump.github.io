#pragma once 
#include "SDK.h" 
 
 
// Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.ListenForTalkingStateChangedEvents
// Size: 0x39(Inherited: 0x0) 
struct FListenForTalkingStateChangedEvents
{
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x0(0x10)
	struct ABP_HDPlayerControllerBase_C* CallFunc_GetHDPlayerControllerBP_HDPC;  // 0x10(0x8)
	struct UDFPlayerCommsComponent* CallFunc_GetPlayerCommsComponent_ReturnValue;  // 0x18(0x8)
	struct UDFCommsFormatBase* CallFunc_FindAssociatedCommsFormat_OutFormatFound;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_FindAssociatedCommsFormat_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UDFVOIPCommsFormat* K2Node_DynamicCast_AsDFVOIPComms_Format;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)

}; 
// Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.ExecuteUbergraph_BP_HDVOIPTalker
// Size: 0x29D(Inherited: 0x0) 
struct FExecuteUbergraph_BP_HDVOIPTalker
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsPlayerTalkerPendingReset_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct UAudioComponent* K2Node_Event_AudioComponent;  // 0x8(0x8)
	struct FName CallFunc_GetAttachSocketName_ReturnValue;  // 0x10(0x8)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform CallFunc_GetRelativeTransform_ReturnValue;  // 0x20(0x30)
	struct FText CallFunc_Conv_NameToText_ReturnValue;  // 0x50(0x18)
	struct FText CallFunc_Conv_TransformToText_ReturnValue;  // 0x68(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x80(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xC0(0x40)
	struct USceneComponent* CallFunc_GetAttachParent_ReturnValue;  // 0x100(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x108(0x10)
	struct FString CallFunc_GetDisplayName_ReturnValue_2;  // 0x118(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x128(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x140(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_3;  // 0x158(0x40)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_4;  // 0x198(0x40)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x1D8(0x8)
	struct FString CallFunc_GetDisplayName_ReturnValue_3;  // 0x1E0(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_3;  // 0x1F0(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_5;  // 0x208(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x248(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x258(0x18)
	struct UDFCommChannel* K2Node_CustomEvent_MsgTalkerChannel;  // 0x270(0x8)
	struct APlayerState* K2Node_CustomEvent_MsgTalkerPS;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool K2Node_CustomEvent_bMsgIsTalking : 1;  // 0x280(0x1)
	char pad_641[7];  // 0x281(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x288(0x10)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x298(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	bool CallFunc_UpdateSettingsUsageForNextBeginTalk_bSettingsUpdated : 1;  // 0x299(0x1)
	char pad_666_1 : 7;  // 0x29A(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x29A(0x1)
	char pad_667_1 : 7;  // 0x29B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x29B(0x1)
	char pad_668_1 : 7;  // 0x29C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x29C(0x1)

}; 
// Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.TalkStateChangedOnChannel
// Size: 0x11(Inherited: 0x0) 
struct FTalkStateChangedOnChannel
{
	struct UDFCommChannel* MsgTalkerChannel;  // 0x0(0x8)
	struct APlayerState* MsgTalkerPS;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bMsgIsTalking : 1;  // 0x10(0x1)

}; 
// Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.BPOnTalkingBegin
// Size: 0x8(Inherited: 0x8) 
struct FBPOnTalkingBegin : public FBPOnTalkingBegin
{
	struct UAudioComponent* AudioComponent;  // 0x0(0x8)

}; 
// Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.RegisterTalker
// Size: 0x3A(Inherited: 0x0) 
struct FRegisterTalker
{
	struct APlayerState* InRegisteredPS;  // 0x0(0x8)
	struct FVoiceSettings InSpatializedSettings;  // 0x8(0x18)
	struct FVoiceSettings InNonSpatializedSettings;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bStartSpatialized : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_UpdateSettingsUsageForNextBeginTalk_bSettingsUpdated : 1;  // 0x39(0x1)

}; 
// Function BP_HDVOIPTalker.BP_HDVOIPTalker_C.UpdateSettingsUsageForNextBeginTalk
// Size: 0x155(Inherited: 0x0) 
struct FUpdateSettingsUsageForNextBeginTalk
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseSpatialized : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bSettingsUpdated : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString Temp_string_Variable;  // 0x8(0x10)
	struct FString Temp_string_Variable_2;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct FString K2Node_Select_Default;  // 0x30(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x40(0x18)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x58(0x10)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0x68(0x40)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0xA8(0x18)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData_2;  // 0xC0(0x40)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // 0x100(0x10)
	struct FVoiceSettings K2Node_Select_Default_2;  // 0x110(0x18)
	struct FText CallFunc_Format_ReturnValue;  // 0x128(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x140(0x10)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue_2 : 1;  // 0x151(0x1)
	char pad_338_1 : 7;  // 0x152(0x1)
	bool CallFunc_NotEqual_ObjectObject_ReturnValue_3 : 1;  // 0x152(0x1)
	char pad_339_1 : 7;  // 0x153(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x153(0x1)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x154(0x1)

}; 
