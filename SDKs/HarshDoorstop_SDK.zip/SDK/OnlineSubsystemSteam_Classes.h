#pragma once 
#include <OnlineSubsystemSteam_Structs.h>
 
 
 
// Class OnlineSubsystemSteam.SteamAuthComponentModuleInterface
// Size: 0x28(Inherited: 0x28) 
struct USteamAuthComponentModuleInterface : public UHandlerComponentFactory
{

}; 



// Class OnlineSubsystemSteam.SteamNetConnection
// Size: 0x1B28(Inherited: 0x1B20) 
struct USteamNetConnection : public UIpConnection
{
	char pad_6944_1 : 7;  // 0x1B20(0x1)
	bool bIsPassthrough : 1;  // 0x1B20(0x1)
	char pad_6945[7];  // 0x1B21(0x7)

}; 



// Class OnlineSubsystemSteam.SteamNetDriver
// Size: 0x7C0(Inherited: 0x7B8) 
struct USteamNetDriver : public UIpNetDriver
{
	char pad_1976[8];  // 0x7B8(0x8)

}; 



