#pragma once 
#include <FServerBadgeUIDefinition_Structs.h>
 
 
 
