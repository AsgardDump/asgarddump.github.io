#pragma once 
#include <BP_HDProj_SPDeployableBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C
// Size: 0x430(Inherited: 0x390) 
struct ABP_HDProj_SPDeployableBase_C : public AHDProj_SpawnPointDeployable
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x390(0x8)
	struct USphereComponent* HitDetectionSphere;  // 0x398(0x8)
	struct USphereComponent* SpawnSphere;  // 0x3A0(0x8)
	struct UStaticMeshComponent* ProjectileCollision;  // 0x3A8(0x8)
	struct UDFPOIComponent* POI;  // 0x3B0(0x8)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool bOnlySquadMembersCanSpawn : 1;  // 0x3B8(0x1)
	char pad_953[3];  // 0x3B9(0x3)
	float PostTriggerLifeSpan;  // 0x3BC(0x4)
	float PlacementRestrictionDistance;  // 0x3C0(0x4)
	char pad_964_1 : 7;  // 0x3C4(0x1)
	bool bSpawnable : 1;  // 0x3C4(0x1)
	char pad_965[3];  // 0x3C5(0x3)
	struct FMulticastInlineDelegate OnSpawnPointActivationChanged;  // 0x3C8(0x10)
	struct TArray<struct FVector> SpawnPointLocOffsets;  // 0x3D8(0x10)
	struct TArray<struct FSpawnPointDef> GeneratedSpawnPoints;  // 0x3E8(0x10)
	char pad_1016_1 : 7;  // 0x3F8(0x1)
	bool bIgnoreFriendlyFire : 1;  // 0x3F8(0x1)
	char pad_1017[3];  // 0x3F9(0x3)
	float Health;  // 0x3FC(0x4)
	char pad_1024_1 : 7;  // 0x400(0x1)
	bool bDisableWhenOverrun : 1;  // 0x400(0x1)
	char pad_1025[3];  // 0x401(0x3)
	int32_t NumberOfEnemiesToDisable;  // 0x404(0x4)
	char pad_1032_1 : 7;  // 0x408(0x1)
	bool bDestroyWhenOverrun : 1;  // 0x408(0x1)
	char pad_1033[3];  // 0x409(0x3)
	int32_t NumberOfEnemiesToDestroy;  // 0x40C(0x4)
	int32_t CurrentNumberOfEnemies;  // 0x410(0x4)
	char pad_1044[4];  // 0x414(0x4)
	struct AHDSquadState* OwnerSquadState;  // 0x418(0x8)
	char pad_1056_1 : 7;  // 0x420(0x1)
	bool bDestroyWhenSquadDisbands : 1;  // 0x420(0x1)
	char pad_1057_1 : 7;  // 0x421(0x1)
	bool bOnlyOnePerSquad : 1;  // 0x421(0x1)
	char pad_1058[2];  // 0x422(0x2)
	int32_t MaxNumberOfInstances;  // 0x424(0x4)
	float EnemyTolerance_Radius;  // 0x428(0x4)
	int32_t EnemyTolerance_MaxNumberOfChars;  // 0x42C(0x4)

	bool GetSpawnPointCollisionHandlingOverrideBP(struct FSpawnPointDef& SpawnPoint, uint8_t & OutSpawnCollisionMethod); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetSpawnPointCollisionHandlingOverrideBP
	bool CanRestartPlayerFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, struct AController* Player, APawn* PlayerPawnClass); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanRestartPlayerFromSpawnPointBP
	bool CanSpawnActorFromSpawnPointBP(struct FSpawnPointDef& SpawnPoint, AActor* SpawnActorClass); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanSpawnActorFromSpawnPointBP
	bool FindSpawnPointBP(int32_t SpawnPointID, struct FSpawnPointDef& FoundSpawnPoint); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.FindSpawnPointBP
	int32_t GetAllSpawnPointsBP(struct TArray<struct FSpawnPointDef>& SpawnPoints); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetAllSpawnPointsBP
	void CanPlayerSpawnHere(struct AController* InPlayer, bool& bPlayerCanSpawn); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CanPlayerSpawnHere
	void InitDeployable(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.InitDeployable
	void CheckEnemyOverrun(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CheckEnemyOverrun
	void HandleTakeDamageFromProjectile(struct ADFBaseProjectile* InProjectile, float InDamage); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.HandleTakeDamageFromProjectile
	void GenerateSpawnPointList(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GenerateSpawnPointList
	void GetTransformOffsetBySpawnIndex(int32_t& SpawnIdx, struct FTransform Transform, struct FTransform& NewTransform); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetTransformOffsetBySpawnIndex
	void GetActorTransformOffsetByMeshZBounds(struct FTransform& OffsetActorWorldXForm); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetActorTransformOffsetByMeshZBounds
	void CheckForEnemyChars(); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.CheckForEnemyChars
	void SetIsSpawnable(bool bNewEnabled); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.SetIsSpawnable
	void IsSpawnable(bool& bSpawnPointEnabled); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.IsSpawnable
	void AreSpawnPointsEqual(struct FSpawnPointDef& SpawnPointOne, struct FSpawnPointDef& SpawnPointTwo, bool& bEqual); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.AreSpawnPointsEqual
	void GetSpawnPoint(bool bMeshZOffset, int32_t SpawnPointIdx, struct FSpawnPointDef& SpawnPoint); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.GetSpawnPoint
	void IsEnemyChar(struct ADFBaseCharacter* Char, bool& bEnemyChar); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.IsEnemyChar
	void HasServerAuthority(bool& bAuthority); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.HasServerAuthority
	void ReceivePayloadActivated(struct FHitResult& ImpactHitResult); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ReceivePayloadActivated
	void BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.BndEvt__SpawnSphere_K2Node_ComponentBoundEvent_1_ComponentEndOverlapSignature__DelegateSignature
	void OverlappingPawnTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.OverlappingPawnTeamNumUpdated
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ReceiveAnyDamage
	void MemberPreUnregisteredFromOwnerSquad(struct AHDSquadState* Squad, struct AHDPlayerState* MemberPS); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.MemberPreUnregisteredFromOwnerSquad
	void ExecuteUbergraph_BP_HDProj_SPDeployableBase(int32_t EntryPoint); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.ExecuteUbergraph_BP_HDProj_SPDeployableBase
	void OnSpawnPointActivationChanged__DelegateSignature(struct ABP_HDProj_SPDeployableBase_C* Deployable, bool bSpawnPointEnabled); // Function BP_HDProj_SPDeployableBase.BP_HDProj_SPDeployableBase_C.OnSpawnPointActivationChanged__DelegateSignature
}; 



