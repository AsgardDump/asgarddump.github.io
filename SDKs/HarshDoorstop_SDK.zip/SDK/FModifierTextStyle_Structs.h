#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FModifierTextStyle.FModifierTextStyle
// Size: 0x78(Inherited: 0x0) 
struct FFModifierTextStyle
{
	struct FSlateColor TextColor_2_FEF6CC214B273F7EFDFE2F8445872AA0;  // 0x0(0x28)
	struct FSlateFontInfo Font_5_87B46F2C46D2565C1513CF97C15D83B5;  // 0x28(0x50)

}; 
