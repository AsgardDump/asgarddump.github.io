#pragma once 
#include "SDK.h" 
 
 
// Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdateEquippedWeaponRefs
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintUpdateEquippedWeaponRefs
{
	struct ADFBaseItem* NewWeap;  // 0x0(0x8)

}; 
// Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.GetFootstepNotifyProps
// Size: 0xF8(Inherited: 0x0) 
struct FGetFootstepNotifyProps
{
	struct FFootstepFXSettings ReturnValue;  // 0x0(0xF8)

}; 
// ScriptStruct DonkehFrameworkAnim.DFCharStanceContext
// Size: 0x1(Inherited: 0x0) 
struct FDFCharStanceContext
{
	char bWantsToBeInStance : 1;  // 0x0(0x1)
	char bIsInStance : 1;  // 0x0(0x1)
	char bFullyTransitionedIntoStance : 1;  // 0x0(0x1)
	char pad_0_1 : 5;  // 0x0(0x1)

}; 
// ScriptStruct DonkehFrameworkAnim.FootstepFXSettings
// Size: 0xF8(Inherited: 0x0) 
struct FFootstepFXSettings
{
	struct TMap<char EPhysicalSurface, struct FPerspectiveSound> SoundsToPlay;  // 0x0(0x50)
	float VolumeMultiplier;  // 0x50(0x4)
	float PitchMultiplier;  // 0x54(0x4)
	char bAttachSound : 1;  // 0x58(0x1)
	char bPlaySoundsWithPerspMeshOnly : 1;  // 0x58(0x1)
	char pad_88_1 : 6;  // 0x58(0x1)
	char pad_89[8];  // 0x59(0x8)
	struct TMap<char EPhysicalSurface, struct UFXSystemAsset*> EffectsToSpawn;  // 0x60(0x50)
	char bAttachEffect : 1;  // 0xB0(0x1)
	char pad_176_1 : 7;  // 0xB0(0x1)
	char pad_177[4];  // 0xB1(0x4)
	struct FVector EffectLocationOffset;  // 0xB4(0xC)
	struct FRotator EffectRotationOffset;  // 0xC0(0xC)
	struct FVector EffectScale;  // 0xCC(0xC)
	char bSpawnEffectsWithPerspMeshOnly : 1;  // 0xD8(0x1)
	char pad_216_1 : 7;  // 0xD8(0x1)
	uint8_t  FootstepVariant;  // 0xD9(0x1)
	char pad_218[2];  // 0xDA(0x2)
	struct FName FootstepVariantParamName;  // 0xDC(0x8)
	struct FName FootBoneName;  // 0xE4(0x8)
	float FootTraceOffset;  // 0xEC(0x4)
	char bDebug : 1;  // 0xF0(0x1)
	char pad_240_1 : 7;  // 0xF0(0x1)
	char pad_241[8];  // 0xF1(0x8)

}; 
// Function DonkehFrameworkAnim.DFWeaponAnimInstance.BlueprintUpdateWeaponOwnerRefs
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintUpdateWeaponOwnerRefs
{
	struct ADFBaseWeapon* NewWeap;  // 0x0(0x8)

}; 
// Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdateControllerOwnerRefs
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintUpdateControllerOwnerRefs
{
	struct AController* NewC;  // 0x0(0x8)

}; 
// Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.SetFootstepNotifyProps
// Size: 0xF8(Inherited: 0x0) 
struct FSetFootstepNotifyProps
{
	struct FFootstepFXSettings PropsToUse;  // 0x0(0xF8)

}; 
// ScriptStruct DonkehFrameworkAnim.BoneModifier
// Size: 0xC(Inherited: 0x0) 
struct FBoneModifier
{
	struct FName Bone;  // 0x0(0x8)
	float Offset;  // 0x8(0x4)

}; 
// Function DonkehFrameworkAnim.AnimNotify_PlayFootstepFX.EqualProps
// Size: 0x1F8(Inherited: 0x0) 
struct FEqualProps
{
	struct FFootstepFXSettings Props;  // 0x0(0xF8)
	struct FFootstepFXSettings OtherProps;  // 0xF8(0xF8)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool ReturnValue : 1;  // 0x1F0(0x1)
	char pad_497[7];  // 0x1F1(0x7)

}; 
// Function DonkehFrameworkAnim.DFCharacterAnimInstance.BlueprintUpdatePawnOwnerRefs
// Size: 0x8(Inherited: 0x0) 
struct FBlueprintUpdatePawnOwnerRefs
{
	struct APawn* NewPawn;  // 0x0(0x8)

}; 
// Function DonkehFrameworkAnim.DFCharacterAnimInstance.EquippedWeaponChanged
// Size: 0x18(Inherited: 0x0) 
struct FEquippedWeaponChanged
{
	struct ADFBaseCharacter* Character;  // 0x0(0x8)
	struct ADFBaseItem* NewEquippedWeap;  // 0x8(0x8)
	struct ADFBaseItem* PrevEquippedWeap;  // 0x10(0x8)

}; 
// Function DonkehFrameworkAnim.DFCharacterAnimInstance.TryGetControllerOwner
// Size: 0x8(Inherited: 0x0) 
struct FTryGetControllerOwner
{
	struct AController* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkAnim.DFCharacterAnimInstance.TryGetOwnerWeapon
// Size: 0x8(Inherited: 0x0) 
struct FTryGetOwnerWeapon
{
	struct ADFBaseItem* ReturnValue;  // 0x0(0x8)

}; 
// Function DonkehFrameworkAnim.DFWeaponAnimInstance.TryGetWeaponOwner
// Size: 0x8(Inherited: 0x0) 
struct FTryGetWeaponOwner
{
	struct ADFBaseWeapon* ReturnValue;  // 0x0(0x8)

}; 
