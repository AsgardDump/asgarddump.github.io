#pragma once 
#include <WBP_OptionsMenuItem_Arrow_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C
// Size: 0x2E0(Inherited: 0x230) 
struct UWBP_OptionsMenuItem_Arrow_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UButton* NextOptionBtn;  // 0x238(0x8)
	struct UTextBlock* OptionText;  // 0x240(0x8)
	struct UButton* PrevOptionBtn;  // 0x248(0x8)
	struct USizeBox* SelectedOptionSizeBox;  // 0x250(0x8)
	struct UTextBlock* SelectedOptionText;  // 0x258(0x8)
	struct FText Text;  // 0x260(0x18)
	struct TArray<struct FFOptionItemSelection> Options;  // 0x278(0x10)
	int32_t SelectedOptionIndex;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)
	struct FMulticastInlineDelegate OnSelectionChanged;  // 0x290(0x10)
	struct FText TextDescription;  // 0x2A0(0x18)
	float TextWidth;  // 0x2B8(0x4)
	char EArrowOptionsPreset OptionsPreset;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct TArray<struct FFOptionItemSelection> ScalabilityOptions;  // 0x2C0(0x10)
	struct FMulticastInlineDelegate OnSelectionChangedByUser;  // 0x2D0(0x10)

	void FindOptionIndex(struct FText OptionDisplayName, int32_t& Index); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.FindOptionIndex
	void SetSelectedOption(struct FText OptionDisplayName); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOption
	void SetSelectedOptionByValue(struct FString OptionValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOptionByValue
	void PopulateOptionsByPreset(char EArrowOptionsPreset Preset); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.PopulateOptionsByPreset
	void FindOptionValueIndex(struct FString OptionValue, int32_t& Index); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.FindOptionValueIndex
	void SetSelectedOptionByIndex(int32_t Index); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.SetSelectedOptionByIndex
	void ClearSelection(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.ClearSelection
	void INTERNAL_ClearSelection(char ESelectInfo DeselectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.INTERNAL_ClearSelection
	void RemoveOptionAtIndex(int32_t IndexToRemove, bool& bRemovalSuccess); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.RemoveOptionAtIndex
	void GetOptionCount(int32_t& OptionCount); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetOptionCount
	void AddOption(struct FFOptionItemSelection& NewOption); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.AddOption
	void GetOptionValueAtIndex(int32_t Index, struct FString& OptionValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetOptionValueAtIndex
	void GetSelectedOptionValue(struct FString& OptionValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.GetSelectedOptionValue
	void INTERNAL_SetSelectedOptionByIndex(int32_t Index, char ESelectInfo SelectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.INTERNAL_SetSelectedOptionByIndex
	void ClearOptions(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.ClearOptions
	void BndEvt__PrevOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.BndEvt__PrevOptionBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__NextOptionBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.BndEvt__NextOptionBtn_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void PreConstruct(bool IsDesignTime); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.PreConstruct
	void Construct(); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.Construct
	void OnItemSelectionChanged(struct FString SelectedItemValue, char ESelectInfo SelectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnItemSelectionChanged
	void ExecuteUbergraph_WBP_OptionsMenuItem_Arrow(int32_t EntryPoint); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.ExecuteUbergraph_WBP_OptionsMenuItem_Arrow
	void OnSelectionChangedByUser__DelegateSignature(struct FString SelectedItemValue); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnSelectionChangedByUser__DelegateSignature
	void OnSelectionChanged__DelegateSignature(struct FString SelectedItemValue, char ESelectInfo SelectionType); // Function WBP_OptionsMenuItem_Arrow.WBP_OptionsMenuItem_Arrow_C.OnSelectionChanged__DelegateSignature
}; 



