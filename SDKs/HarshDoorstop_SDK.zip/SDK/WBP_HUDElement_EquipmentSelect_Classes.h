#pragma once 
#include <WBP_HUDElement_EquipmentSelect_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C
// Size: 0x258(Inherited: 0x230) 
struct UWBP_HUDElement_EquipmentSelect_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UVerticalBox* SlotVBox;  // 0x238(0x8)
	int32_t CurrentSlotIndex;  // 0x240(0x4)
	int32_t CurrentSlotNum;  // 0x244(0x4)
	struct TArray<struct FFEqpSlotData> SlotData;  // 0x248(0x10)

	void SelectItemBySlotNum(int32_t SlotNum); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectItemBySlotNum
	void GetSelectedItem(struct FFEqpSlotData& OutSlotData, bool& bFoundItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.GetSelectedItem
	void GetMinSlotIndex(struct TArray<struct FFEqpSlotData>& SlotDataArray, int32_t& MinSlotIndex); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.GetMinSlotIndex
	void CreateAndAddEquipmentWidget(struct UTexture2D* Icon, int32_t SlotNum, bool bEnabled, struct AHDBaseWeapon* EqpItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.CreateAndAddEquipmentWidget
	void ClearEquipmentList(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.ClearEquipmentList
	void RemoveEquipmentAtSlotNum(int32_t SlotNum, bool& bRemoved); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.RemoveEquipmentAtSlotNum
	void RebuildEquipmentList(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.RebuildEquipmentList
	void AddEquipment(struct FHDItemEntry& EqpInfo, struct AHDBaseWeapon* EqpItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.AddEquipment
	void SelectItem(int32_t NewSlotIndex); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectItem
	void SelectPrevItem(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectPrevItem
	void SelectNextItem(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.SelectNextItem
	void OnLoaded_B4ECD00040B15A8A41EE1DA4CE775D64(struct UObject* Loaded); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.OnLoaded_B4ECD00040B15A8A41EE1DA4CE775D64
	void PreConstruct(bool IsDesignTime); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.PreConstruct
	void LoadEquipmentAsset(struct TSoftObjectPtr<UTexture2D> IconToLoad, int32_t SlotNum, struct AHDBaseWeapon* EqpItem); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.LoadEquipmentAsset
	void OnEquipmentListModified(); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.OnEquipmentListModified
	void ExecuteUbergraph_WBP_HUDElement_EquipmentSelect(int32_t EntryPoint); // Function WBP_HUDElement_EquipmentSelect.WBP_HUDElement_EquipmentSelect_C.ExecuteUbergraph_WBP_HUDElement_EquipmentSelect
}; 



