#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct FServerSortPreference.FServerSortPreference
// Size: 0x2(Inherited: 0x0) 
struct FFServerSortPreference
{
	char EHDListSortOrder Order_9_083C1029475FF29C3E8E84A4A2979A0C;  // 0x0(0x1)
	uint8_t  SortBy_2_BDA3B8F147C4E4C4C53B148171996893;  // 0x1(0x1)

}; 
