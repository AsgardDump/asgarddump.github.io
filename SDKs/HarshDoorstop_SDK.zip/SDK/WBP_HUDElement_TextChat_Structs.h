#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.ExecuteUbergraph_WBP_HUDElement_TextChat
// Size: 0xC4(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HUDElement_TextChat
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UHDTextChatMsgInfo* K2Node_Event_NewChatMsg;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UWidget* CallFunc_AddNewOutputListing_Listing;  // 0x18(0x8)
	struct UWidget* CallFunc_AddNewOutputListing_Listing_2;  // 0x20(0x8)
	int32_t CallFunc_Min_ReturnValue;  // 0x28(0x4)
	int32_t Temp_int_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UDFCommChannel* K2Node_Event_TalkChannel;  // 0x40(0x8)
	struct FText K2Node_ComponentBoundEvent_Text;  // 0x48(0x18)
	char ETextCommit K2Node_ComponentBoundEvent_CommitMethod;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x62(0x1)
	char pad_99[5];  // 0x63(0x5)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationReverse_ReturnValue;  // 0x68(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationForward_ReturnValue;  // 0x70(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationForward_ReturnValue_2;  // 0x78(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimationReverse_ReturnValue_2;  // 0x80(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_CustomEvent_bVisible : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_RemoveChildAt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	float CallFunc_GetScrollOffset_ReturnValue;  // 0xB4(0x4)
	float CallFunc_GetScrollOffsetOfEnd_ReturnValue;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_NotEqual_FloatFloat_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float K2Node_ComponentBoundEvent_CurrentOffset;  // 0xC0(0x4)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.DisplayChatMessage
// Size: 0x8(Inherited: 0x8) 
struct FDisplayChatMessage : public FDisplayChatMessage
{
	struct UHDTextChatMsgInfo* NewChatMsg;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.BndEvt__ChatMsgLogSBox_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FBndEvt__ChatMsgLogSBox_K2Node_ComponentBoundEvent_0_OnUserScrolledEvent__DelegateSignature
{
	float CurrentOffset;  // 0x0(0x4)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.SetChatHistoryIsVisible
// Size: 0x1(Inherited: 0x0) 
struct FSetChatHistoryIsVisible
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisible : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.BndEvt__WBP_TextChat_Input_K2Node_ComponentBoundEvent_2_OnInputTextCommitted__DelegateSignature
// Size: 0x19(Inherited: 0x0) 
struct FBndEvt__WBP_TextChat_Input_K2Node_ComponentBoundEvent_2_OnInputTextCommitted__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)
	char ETextCommit CommitMethod;  // 0x18(0x1)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.StartTalking
// Size: 0x8(Inherited: 0x8) 
struct FStartTalking : public FStartTalking
{
	struct UDFCommChannel* TalkChannel;  // 0x0(0x8)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.AddNewOutputListing
// Size: 0x29(Inherited: 0x0) 
struct FAddNewOutputListing
{
	struct UHDTextChatMsgInfo* ChatMsg;  // 0x0(0x8)
	struct UWidget* Listing;  // 0x8(0x8)
	struct UWBP_HUDElement_TextChat_OutputListing_C* CallFunc_Create_ReturnValue;  // 0x10(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x18(0x8)
	struct UScrollBoxSlot* K2Node_DynamicCast_AsScroll_Box_Slot;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.GetChatHistoryIsVisible
// Size: 0x1(Inherited: 0x0) 
struct FGetChatHistoryIsVisible
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisible : 1;  // 0x0(0x1)

}; 
// Function WBP_HUDElement_TextChat.WBP_HUDElement_TextChat_C.OnPaint
// Size: 0x40(Inherited: 0x30) 
struct FOnPaint : public FOnPaint
{
	struct FPaintContext Context;  // 0x0(0x30)
	char EOrientation Temp_byte_Variable;  // 0x30(0x1)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x38(0x4)
	float K2Node_Select_Default;  // 0x3C(0x4)

}; 
