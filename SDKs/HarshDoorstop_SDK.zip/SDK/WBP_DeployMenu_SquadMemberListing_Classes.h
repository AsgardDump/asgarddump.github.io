#pragma once 
#include <WBP_DeployMenu_SquadMemberListing_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C
// Size: 0x2C9(Inherited: 0x238) 
struct UWBP_DeployMenu_SquadMemberListing_C : public UDeployMenu_SquadMemberListingBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct USizeBox* DummyOption;  // 0x240(0x8)
	struct UButton* DummyOptionBtn;  // 0x248(0x8)
	struct UWBP_SQMemberOption_C* KickMemberOption;  // 0x250(0x8)
	struct UButton* KickMemberOptionBtn;  // 0x258(0x8)
	struct UButton* MemberBtn;  // 0x260(0x8)
	struct UImage* PlayerClassIcon;  // 0x268(0x8)
	struct UImage* PlayerClassIconBg;  // 0x270(0x8)
	struct UTextBlock* PlayerNameText;  // 0x278(0x8)
	struct UHorizontalBox* SQMOptionsHBox;  // 0x280(0x8)
	struct FLinearColor OddListingBtnBgColor;  // 0x288(0x10)
	struct FLinearColor OddListingIconBgColor;  // 0x298(0x10)
	struct FLinearColor EvenListingBgColor;  // 0x2A8(0x10)
	struct UWBP_DeployMenu_SquadList_C* ParentContainerWidget;  // 0x2B8(0x8)
	struct UHDKit* LastLoadout;  // 0x2C0(0x8)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool bMemberSet : 1;  // 0x2C8(0x1)

	void GetClassIconForLoadout(struct UHDKit* Loadout, struct FSlateBrush& ClassIconToUse); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.GetClassIconForLoadout
	void UpdatePlayerClassIcon(struct UHDKit* Loadout); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.UpdatePlayerClassIcon
	void SetupOptions(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.SetupOptions
	void TestOptionPrereqs(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.TestOptionPrereqs
	void UpdateColorOffset(bool bEvenNumberListing); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.UpdateColorOffset
	void SetPlayerNameText(struct FText NewPlayerName); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.SetPlayerNameText
	void BndEvt__KickMemberBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.BndEvt__KickMemberBtn_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void OnMemberSet(); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.OnMemberSet
	void OnMemberPlayerNameUpdated(struct FString NewPlayerName); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.OnMemberPlayerNameUpdated
	void PreConstruct(bool IsDesignTime); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.PreConstruct
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.Tick
	void ExecuteUbergraph_WBP_DeployMenu_SquadMemberListing(int32_t EntryPoint); // Function WBP_DeployMenu_SquadMemberListing.WBP_DeployMenu_SquadMemberListing_C.ExecuteUbergraph_WBP_DeployMenu_SquadMemberListing
}; 



