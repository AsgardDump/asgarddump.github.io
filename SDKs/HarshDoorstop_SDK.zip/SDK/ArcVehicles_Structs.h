#pragma once 
#include "SDK.h" 
 
 
// Function ArcVehicles.ArcVehiclePawn.NotifyPlayerSeatChangeEvent
// Size: 0x20(Inherited: 0x0) 
struct FNotifyPlayerSeatChangeEvent
{
	struct APlayerState* Player;  // 0x0(0x8)
	struct UArcVehicleSeatConfig* ToSeat;  // 0x8(0x8)
	struct UArcVehicleSeatConfig* FromSeat;  // 0x10(0x8)
	uint8_t  SeatChangeEvent;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function ArcVehicles.ArcVehiclePlayerSeatComponent.BP_OnRep_StoredPlayerState
// Size: 0x8(Inherited: 0x0) 
struct FBP_OnRep_StoredPlayerState
{
	struct APlayerState* InPreviousPlayerState;  // 0x0(0x8)

}; 
// ScriptStruct ArcVehicles.ArcVehicleSeatChangeEvent
// Size: 0x18(Inherited: 0x0) 
struct FArcVehicleSeatChangeEvent
{
	char pad_0[16];  // 0x0(0x10)
	struct APlayerState* Player;  // 0x10(0x8)

}; 
// Function ArcVehicles.ArcBaseVehicle.GetDriverSeat
// Size: 0x8(Inherited: 0x0) 
struct FGetDriverSeat
{
	struct UArcVehicleSeatConfig* ReturnValue;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcVehiclePawn.GetSeatConfig
// Size: 0x8(Inherited: 0x0) 
struct FGetSeatConfig
{
	struct UArcVehicleSeatConfig* ReturnValue;  // 0x0(0x8)

}; 
// ScriptStruct ArcVehicles.ArcVehicleTurretMovementPostPhysicsTickFunction
// Size: 0x30(Inherited: 0x28) 
struct FArcVehicleTurretMovementPostPhysicsTickFunction : public FTickFunction
{
	char pad_40[8];  // 0x28(0x8)

}; 
// ScriptStruct ArcVehicles.ArcOwnerAttachmentReference
// Size: 0x10(Inherited: 0x0) 
struct FArcOwnerAttachmentReference
{
	struct FName ComponentName;  // 0x0(0x8)
	struct FName SocketName;  // 0x8(0x8)

}; 
// Function ArcVehicles.ArcVehicleTurretMovementComp.Server_ServerMove
// Size: 0xC(Inherited: 0x0) 
struct FServer_ServerMove
{
	struct FRotator FullRotation;  // 0x0(0xC)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig.AttachPlayerToSeat
// Size: 0x8(Inherited: 0x0) 
struct FAttachPlayerToSeat
{
	struct APlayerState* Player;  // 0x0(0x8)

}; 
// ScriptStruct ArcVehicles.ArcVehicleSeatReference
// Size: 0x10(Inherited: 0x0) 
struct FArcVehicleSeatReference
{
	struct AArcBaseVehicle* Vehicle;  // 0x0(0x8)
	int32_t SeatID;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_StoredPlayerState
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_StoredPlayerState
{
	struct APlayerState* InPreviousPlayerState;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnRep_SeatConfig
// Size: 0x10(Inherited: 0x0) 
struct FOnRep_SeatConfig
{
	struct FArcVehicleSeatReference InPreviousSeatConfig;  // 0x0(0x10)

}; 
// Function ArcVehicles.ArcBaseVehicle.RequestLeaveVehicle
// Size: 0x8(Inherited: 0x0) 
struct FRequestLeaveVehicle
{
	struct APlayerState* InPlayerState;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcVehiclePlayerSeatComponent.OnSeatChangeEvent
// Size: 0x1(Inherited: 0x0) 
struct FOnSeatChangeEvent
{
	uint8_t  SeatChangeType;  // 0x0(0x1)

}; 
// Function ArcVehicles.ArcVehiclePawn.GetOwningVehicle
// Size: 0x8(Inherited: 0x0) 
struct FGetOwningVehicle
{
	struct AArcBaseVehicle* ReturnValue;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig.GetVehicleOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetVehicleOwner
{
	struct AArcBaseVehicle* ReturnValue;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcBaseVehicle.GetAllSeats
// Size: 0x10(Inherited: 0x0) 
struct FGetAllSeats
{
	struct TArray<struct UArcVehicleSeatConfig*> Seats;  // 0x0(0x10)

}; 
// Function ArcVehicles.ArcBaseVehicle.GetNearestExitTransform
// Size: 0x60(Inherited: 0x0) 
struct FGetNearestExitTransform
{
	struct FTransform InputLocation;  // 0x0(0x30)
	struct FTransform ReturnValue;  // 0x30(0x30)

}; 
// Function ArcVehicles.ArcBaseVehicle.GetSortedExitPoints
// Size: 0x40(Inherited: 0x0) 
struct FGetSortedExitPoints
{
	struct FTransform InputLocation;  // 0x0(0x30)
	struct TArray<struct FTransform> OutTransformArray;  // 0x30(0x10)

}; 
// Function ArcVehicles.ArcBaseVehicle.IsValidSeatIndex
// Size: 0x8(Inherited: 0x0) 
struct FIsValidSeatIndex
{
	int32_t InSeatIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig_SeatPawn.OnRep_SeatPawn
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_SeatPawn
{
	struct AArcVehiclePawn* OldSeatPawn;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcBaseVehicle.RequestEnterAnySeat
// Size: 0x8(Inherited: 0x0) 
struct FRequestEnterAnySeat
{
	struct APlayerState* InPlayerState;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcBaseVehicle.RequestEnterSeat
// Size: 0x10(Inherited: 0x0) 
struct FRequestEnterSeat
{
	struct APlayerState* InPlayerState;  // 0x0(0x8)
	int32_t RequestedSeatIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bIgnoreRestrictions : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function ArcVehicles.ArcBaseVehicle.SetupSeat
// Size: 0x8(Inherited: 0x0) 
struct FSetupSeat
{
	struct UArcVehicleSeatConfig* SeatConfig;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcVehicleBPFunctionLibrary.GetVehicleFromSeatConfig
// Size: 0x18(Inherited: 0x0) 
struct FGetVehicleFromSeatConfig
{
	struct FArcVehicleSeatReference SeatRef;  // 0x0(0x10)
	struct AArcBaseVehicle* ReturnValue;  // 0x10(0x8)

}; 
// Function ArcVehicles.ArcVehicleBPFunctionLibrary.GetVehicleSeatConfigFromRef
// Size: 0x18(Inherited: 0x0) 
struct FGetVehicleSeatConfigFromRef
{
	struct FArcVehicleSeatReference SeatRef;  // 0x0(0x10)
	struct UArcVehicleSeatConfig* ReturnValue;  // 0x10(0x8)

}; 
// Function ArcVehicles.ArcVehicleBPFunctionLibrary.IsSeatRefValid
// Size: 0x18(Inherited: 0x0) 
struct FIsSeatRefValid
{
	struct FArcVehicleSeatReference SeatRef;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig.BP_AttachPlayerToSeat
// Size: 0x8(Inherited: 0x0) 
struct FBP_AttachPlayerToSeat
{
	struct APlayerState* Player;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig.BP_UnAttachPlayerFromSeat
// Size: 0x8(Inherited: 0x0) 
struct FBP_UnAttachPlayerFromSeat
{
	struct APlayerState* Player;  // 0x0(0x8)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig.IsDriverSeat
// Size: 0x1(Inherited: 0x0) 
struct FIsDriverSeat
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig.IsOpenSeat
// Size: 0x1(Inherited: 0x0) 
struct FIsOpenSeat
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function ArcVehicles.ArcVehicleSeatConfig.UnAttachPlayerFromSeat
// Size: 0x8(Inherited: 0x0) 
struct FUnAttachPlayerFromSeat
{
	struct APlayerState* Player;  // 0x0(0x8)

}; 
