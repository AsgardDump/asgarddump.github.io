#pragma once 
#include "SDK.h" 
 
 
// Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.ExecuteUbergraph_WBP_FactionGameModifierSettings
// Size: 0xF8(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_FactionGameModifierSettings
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	struct TArray<struct FPrimaryAssetId> CallFunc_GetPrimaryAssetIdList_OutPrimaryAssetIdList;  // 0x10(0x10)
	struct TArray<struct FPrimaryAssetId> CallFunc_SplitLoadedPrimaryAssetClassIds_UnloadedAssetIds;  // 0x20(0x10)
	struct TArray<UObject*> CallFunc_SplitLoadedPrimaryAssetClassIds_LoadedAssetClasses;  // 0x30(0x10)
	UObject* CallFunc_Array_Get_Item;  // 0x40(0x8)
	struct FPrimaryAssetId CallFunc_GetPrimaryAssetIdFromClass_ReturnValue;  // 0x48(0x10)
	UHDFactionInfo* K2Node_ClassDynamicCast_AsFaction_Info__HD_;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x70(0x10)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x80(0x10)
	struct UAsyncActionLoadPrimaryAssetClassList* CallFunc_AsyncLoadPrimaryAssetClassList_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct TArray<UObject*> Temp_class_Variable;  // 0xA0(0x10)
	struct UWBP_OptionMenu_CreateGame_C* K2Node_Event_ParentMenu;  // 0xB0(0x8)
	struct TArray<UObject*> K2Node_CustomEvent_Loaded;  // 0xB8(0x10)
	int32_t CallFunc_GetOptionCount_ReturnValue;  // 0xC8(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0xCC(0x4)
	int32_t CallFunc_GetOptionCount_ReturnValue_2;  // 0xD0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xD4(0x10)
	char pad_228[4];  // 0xE4(0x4)
	struct TArray<struct FPrimaryAssetId> CallFunc_GetPrimaryAssetIdList_OutPrimaryAssetIdList_2;  // 0xE8(0x10)

}; 
// Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.BuildFactionURLOption
// Size: 0x60(Inherited: 0x0) 
struct FBuildFactionURLOption
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName PackageName;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct FString Pair;  // 0x10(0x10)
	struct FString CallFunc_GetFactionOptionName_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_Conv_NameToString_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x50(0x10)

}; 
// Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.SetupModifier
// Size: 0x8(Inherited: 0x0) 
struct FSetupModifier
{
	struct UWBP_OptionMenu_CreateGame_C* ParentMenu;  // 0x0(0x8)

}; 
// Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.GetTravelURLOptions
// Size: 0xA0(Inherited: 0x0) 
struct FGetTravelURLOptions
{
	struct FString Options;  // 0x0(0x10)
	struct FString OptionsStr;  // 0x10(0x10)
	struct FString CallFunc_GetDisableKitRestrictionsOptionName_ReturnValue;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float CallFunc_GetValue_Value;  // 0x34(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FString CallFunc_BuildTicketCountURLOption_Pair;  // 0x40(0x10)
	float CallFunc_GetValue_Value_2;  // 0x50(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FString CallFunc_BuildTicketCountURLOption_Pair_2;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_GetSelectedIndex_ReturnValue;  // 0x74(0x4)
	int32_t CallFunc_GetSelectedIndex_ReturnValue_2;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_2 : 1;  // 0x7D(0x1)
	char pad_126[2];  // 0x7E(0x2)
	struct FString CallFunc_BuildFactionURLOption_Pair;  // 0x80(0x10)
	struct FString CallFunc_BuildFactionURLOption_Pair_2;  // 0x90(0x10)

}; 
// Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.Completed_7DC7FCB348F23B6EEE29D0A8EBA2EF94
// Size: 0x10(Inherited: 0x0) 
struct FCompleted_7DC7FCB348F23B6EEE29D0A8EBA2EF94
{
	struct TArray<UObject*> Loaded;  // 0x0(0x10)

}; 
// Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.IsEnabled
// Size: 0x2(Inherited: 0x0) 
struct FIsEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsActive_bActive : 1;  // 0x1(0x1)

}; 
// Function WBP_FactionGameModifierSettings.WBP_FactionGameModifierSettings_C.BuildTicketCountURLOption
// Size: 0x58(Inherited: 0x0) 
struct FBuildTicketCountURLOption
{
	uint8_t  Team;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Count;  // 0x4(0x4)
	struct FString Pair;  // 0x8(0x10)
	struct FString CallFunc_GetNumTicketsOptionName_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)

}; 
