#pragma once 
#include <BP_HDPlayerCharacterBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C
// Size: 0xDB8(Inherited: 0xA40) 
struct ABP_HDPlayerCharacterBase_C : public AHDPlayerCharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA40(0x8)
	struct UHDAIPerceptionComponent* HDAIPerception;  // 0xA48(0x8)
	struct USceneComponent* TargetCameraPoint;  // 0xA50(0x8)
	struct USceneComponent* RefPoint;  // 0xA58(0x8)
	struct UNavigationInvokerComponent* NavigationInvoker;  // 0xA60(0x8)
	struct UBoxComponent* Suppression_B;  // 0xA68(0x8)
	struct UBoxComponent* Suppression_A;  // 0xA70(0x8)
	struct UBoxComponent* Suppression_L;  // 0xA78(0x8)
	struct UBoxComponent* Suppression_R;  // 0xA80(0x8)
	struct UBP_HDVOIPTalker_C* VOIPTalker;  // 0xA88(0x8)
	struct UTextRenderComponent* PlayerNameTextRender;  // 0xA90(0x8)
	struct UDFPOIComponent* POI;  // 0xA98(0x8)
	struct FVector VaultCameraTimeline_VaultCamera_22F2E311466556389CC02182AEE99CCA;  // 0xAA0(0xC)
	char ETimelineDirection VaultCameraTimeline__Direction_22F2E311466556389CC02182AEE99CCA;  // 0xAAC(0x1)
	char pad_2733[3];  // 0xAAD(0x3)
	struct UTimelineComponent* VaultCameraTimeline;  // 0xAB0(0x8)
	float LerpTimeline_Lerp_5E919E724A951192A68B8180576AB695;  // 0xAB8(0x4)
	char ETimelineDirection LerpTimeline__Direction_5E919E724A951192A68B8180576AB695;  // 0xABC(0x1)
	char pad_2749[3];  // 0xABD(0x3)
	struct UTimelineComponent* LerpTimeline;  // 0xAC0(0x8)
	struct FVector DamageEffectTimeline_DamageEffect_BEBC6E9841C4A26EF0A22DA008BD6CA4;  // 0xAC8(0xC)
	char ETimelineDirection DamageEffectTimeline__Direction_BEBC6E9841C4A26EF0A22DA008BD6CA4;  // 0xAD4(0x1)
	char pad_2773[3];  // 0xAD5(0x3)
	struct UTimelineComponent* DamageEffectTimeline;  // 0xAD8(0x8)
	struct FVector SuppressionTimeline_SuppressionCurve_83869DB54889A3FECCAF0E83EA19C04B;  // 0xAE0(0xC)
	char ETimelineDirection SuppressionTimeline__Direction_83869DB54889A3FECCAF0E83EA19C04B;  // 0xAEC(0x1)
	char pad_2797[3];  // 0xAED(0x3)
	struct UTimelineComponent* SuppressionTimeline;  // 0xAF0(0x8)
	float FallDamageDivisor;  // 0xAF8(0x4)
	float FallDamageThreshold;  // 0xAFC(0x4)
	float EquipmentTimerDelay;  // 0xB00(0x4)
	char pad_2820_1 : 7;  // 0xB04(0x1)
	bool bEquipmentKeyPressed : 1;  // 0xB04(0x1)
	char pad_2821_1 : 7;  // 0xB05(0x1)
	bool bSelectingEquipmentBySlot : 1;  // 0xB05(0x1)
	char pad_2822_1 : 7;  // 0xB06(0x1)
	bool bNextItem : 1;  // 0xB06(0x1)
	char pad_2823[1];  // 0xB07(0x1)
	struct APlayerState* LastValidPlayerState;  // 0xB08(0x8)
	char pad_2832_1 : 7;  // 0xB10(0x1)
	bool bTintTeamColorForPlayerPOIs : 1;  // 0xB10(0x1)
	char pad_2833_1 : 7;  // 0xB11(0x1)
	bool bUseSpecialSymbolForLocalPlayerPOIs : 1;  // 0xB11(0x1)
	char pad_2834[6];  // 0xB12(0x6)
	struct UTexture2D* LocalPlayerPOISymbol;  // 0xB18(0x8)
	struct USoundAttenuation* VOIPSpatializedAttenuation;  // 0xB20(0x8)
	struct USoundEffectSourcePresetChain* VOIPSpatializedSrcEffectChain;  // 0xB28(0x8)
	struct FTimerHandle HealthRegenTimer;  // 0xB30(0x8)
	char pad_2872_1 : 7;  // 0xB38(0x1)
	bool bHealthRegenEnabled : 1;  // 0xB38(0x1)
	char pad_2873[3];  // 0xB39(0x3)
	float HealthRegenAmount;  // 0xB3C(0x4)
	float HealthRegenTimerInterval;  // 0xB40(0x4)
	struct FLinearColor LocalPlayerPOITint;  // 0xB44(0x10)
	struct FColor RedTeamColor;  // 0xB54(0x4)
	struct FColor BlueTeamColor;  // 0xB58(0x4)
	struct FColor NoTeamColor;  // 0xB5C(0x4)
	char pad_2912_1 : 7;  // 0xB60(0x1)
	bool bRadialMenuEnabled : 1;  // 0xB60(0x1)
	char pad_2913[7];  // 0xB61(0x7)
	struct UWBP_HDRadialMenu_C* RadialMenu;  // 0xB68(0x8)
	struct USoundBase* RadialMenuExitSnd;  // 0xB70(0x8)
	struct UDataTable* RadialMenuOptions;  // 0xB78(0x8)
	char pad_2944_1 : 7;  // 0xB80(0x1)
	bool bRallypointsEnabled : 1;  // 0xB80(0x1)
	char pad_2945[3];  // 0xB81(0x3)
	float RadialMenuRallypointTimeDeployed;  // 0xB84(0x4)
	char pad_2952_1 : 7;  // 0xB88(0x1)
	bool bSpatializedVOIPTalker : 1;  // 0xB88(0x1)
	char pad_2953_1 : 7;  // 0xB89(0x1)
	bool bOutpostsEnabled : 1;  // 0xB89(0x1)
	char pad_2954[2];  // 0xB8A(0x2)
	float RadialMenuOutpostTimeDeployed;  // 0xB8C(0x4)
	struct USoundBase* SuppressionSound;  // 0xB90(0x8)
	float SuppressionSoundVolume;  // 0xB98(0x4)
	char pad_2972_1 : 7;  // 0xB9C(0x1)
	bool bBracedAim : 1;  // 0xB9C(0x1)
	char pad_2973_1 : 7;  // 0xB9D(0x1)
	bool bWantsMount : 1;  // 0xB9D(0x1)
	char pad_2974_1 : 7;  // 0xB9E(0x1)
	bool bMounted : 1;  // 0xB9E(0x1)
	char pad_2975[1];  // 0xB9F(0x1)
	struct FVector MountDirection;  // 0xBA0(0xC)
	struct FVector MountPosition;  // 0xBAC(0xC)
	char pad_3000[8];  // 0xBB8(0x8)
	struct FTransform MountTransform;  // 0xBC0(0x30)
	struct FVector SmoothSightDirection;  // 0xBF0(0xC)
	struct FVector SmoothSightOffset;  // 0xBFC(0xC)
	float AimSpeed;  // 0xC08(0x4)
	float SightDirectionSmoothingSpeed;  // 0xC0C(0x4)
	float SightPositionSmoothingSpeed;  // 0xC10(0x4)
	float MountDistance;  // 0xC14(0x4)
	float AimAlpha;  // 0xC18(0x4)
	float MountHeight;  // 0xC1C(0x4)
	struct ABP_HDWeaponBase_C* EquippedWeapon;  // 0xC20(0x8)
	struct ABP_HDProj_SPDeployableBase_C* SpawnedFOB;  // 0xC28(0x8)
	struct ABP_HDProj_SPDeployableBase_C* SpawnedRallypoint;  // 0xC30(0x8)
	struct FMulticastInlineDelegate OnSuppression;  // 0xC38(0x10)
	struct FMulticastInlineDelegate OnHitDamage;  // 0xC48(0x10)
	char pad_3160_1 : 7;  // 0xC58(0x1)
	bool bSpottingEnabled : 1;  // 0xC58(0x1)
	char pad_3161[7];  // 0xC59(0x7)
	struct UCurveVector* SuppressionCurve;  // 0xC60(0x8)
	struct UCurveVector* HitDamageCurve;  // 0xC68(0x8)
	UCameraShake* SuppressionCameraShake;  // 0xC70(0x8)
	UCameraShake* ReceiveDamageCameraShake;  // 0xC78(0x8)
	struct FLinearColor HitEffectValues;  // 0xC80(0x10)
	struct FLinearColor BleedingEffectValues;  // 0xC90(0x10)
	float DamageEffectStartPercent;  // 0xCA0(0x4)
	char pad_3236_1 : 7;  // 0xCA4(0x1)
	bool bVariationDataSet : 1;  // 0xCA4(0x1)
	char pad_3237[3];  // 0xCA5(0x3)
	float MinVaultViewYaw;  // 0xCA8(0x4)
	float MaxVaultViewYaw;  // 0xCAC(0x4)
	struct UCurveVector* VaultOverCameraCurve;  // 0xCB0(0x8)
	struct UCurveVector* SprintVaultOverCameraCurve;  // 0xCB8(0x8)
	struct UCurveVector* ClimbOntoCameraCurve;  // 0xCC0(0x8)
	struct UCurveVector* SprintClimbOntoCameraCurve;  // 0xCC8(0x8)
	struct FVector Camera1POffsetBeforeVault;  // 0xCD0(0xC)
	struct FVector Mesh1POffsetBeforeVault;  // 0xCDC(0xC)
	struct FWeightedBlendable SuppresionEffect;  // 0xCE8(0x10)
	struct FWeightedBlendable DamageEffect;  // 0xCF8(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> ThirdPersonCharMatArray;  // 0xD08(0x10)
	struct TArray<struct UMaterialInstanceDynamic*> FirstPersonCharMatArray;  // 0xD18(0x10)
	char pad_3368_1 : 7;  // 0xD28(0x1)
	bool bUseSpecialSymbolForSquadMatePOIs : 1;  // 0xD28(0x1)
	char pad_3369[7];  // 0xD29(0x7)
	struct UTexture2D* SquadMatePOISymbol;  // 0xD30(0x8)
	struct FLinearColor SquadMatePOITint;  // 0xD38(0x10)
	struct UTexture2D* NonSquadMatePOISymbol;  // 0xD48(0x8)
	struct FLinearColor NonSquadMatePOITint;  // 0xD50(0x10)
	char pad_3424_1 : 7;  // 0xD60(0x1)
	bool bUseSpecialSymbolForSquadLeaderPOIs : 1;  // 0xD60(0x1)
	char pad_3425[7];  // 0xD61(0x7)
	struct UTexture2D* SquadLeaderPOISymbol;  // 0xD68(0x8)
	struct FLinearColor SquadLeaderPOITint;  // 0xD70(0x10)
	struct FLinearColor SquadLeaderPOITextColor;  // 0xD80(0x10)
	struct UTexture2D* NonSquadLeaderPOISymbol;  // 0xD90(0x8)
	struct FLinearColor NonSquadLeaderPOITint;  // 0xD98(0x10)
	struct FLinearColor NonSquadLeaderPOITextColor;  // 0xDA8(0x10)

	struct FVector EventGetFocalPoint(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EventGetFocalPoint
	void IsSameSquad(struct ABP_HDPlayerControllerBase_C* LocalController, bool& bSameSquad); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsSameSquad
	void GetVaultCameraCurveForBehavior(uint8_t  VaultBehavior, struct UCurveVector*& CameraCurve); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetVaultCameraCurveForBehavior
	void RestorePCViewRotationYawLimits(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RestorePCViewRotationYawLimits
	void SetPCViewRotationYawLimits(float ViewYawMin, float ViewYawMax, bool bRelativeToActorRotation); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetPCViewRotationYawLimits
	void UpdateCharMesh(struct USkeletalMesh* NewMesh, bool bUpdateFPPMesh); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMesh
	void SetSuppressionCompIsActive(struct UPrimitiveComponent* PrimComp, bool bNewActive); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetSuppressionCompIsActive
	void SetSuppressionActive(bool bActive); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetSuppressionActive
	void CalcOutpostEnemiesNearbyRestriction(bool& bAreEnemiesNearby); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcOutpostEnemiesNearbyRestriction
	void CalcRallypointEnemiesNearbyRestriction(bool& bAreEnemiesNearby); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcRallypointEnemiesNearbyRestriction
	void IsOutpostNumberLimitReached(bool& bNumberLimitReached); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsOutpostNumberLimitReached
	void IsRallypointNumberLimitReached(bool& bNumberLimitReached); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsRallypointNumberLimitReached
	void CalcOutpostDistanceRestriction(bool& bIsOutpostDistanceRestricted); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcOutpostDistanceRestriction
	void CalcRallypointDistanceRestriction(bool& bIsRallypointDistanceRestricted); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CalcRallypointDistanceRestriction
	void GetIsSpawnedRallypointValid(bool& bIsSpawnedRallypointValid); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetIsSpawnedRallypointValid
	void GetIsSpawnedOutpostValid(bool& bIsSpawnedOutpostValid); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetIsSpawnedOutpostValid
	void GetProneMountPosition(struct FVector BoxSize, float Distance, float MaxHeight, float MinHeight, float MinSpace, bool& bCouldMount, struct FVector& MountPosition); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetProneMountPosition
	void AlignSights(float MinSightDistance); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.AlignSights
	void GetMountPosition(struct FVector Direction, float WallDistance, float TraceRadius, float CornerDistance, float CapsuleHeight, bool& bCouldMount, struct FVector& Position, struct FTransform& Transform); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMountPosition
	void OnRep_bSpatializedVOIPTalker(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnRep_bSpatializedVOIPTalker
	void HasSquadLeaderKit(bool bRequireRallyPointAbility, bool& bUsingSquadLeaderKit); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.HasSquadLeaderKit
	void IsSquadLeader(bool& bSquadLeader); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsSquadLeader
	void GetSquadState(struct AHDSquadState*& SquadState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetSquadState
	void CanSelectAnyRadialMenuOption(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CanSelectAnyRadialMenuOption
	void RadialMenuCanSelectOutpost(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectOutpost
	void RadialMenuCanSelectRallypoint(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectRallypoint
	void RadialMenuCanSelectSpot(bool& bSelectable); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuCanSelectSpot
	void RadialMenuSelectOutpost(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectOutpost
	void RadialMenuSelectRallypoint(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectRallypoint
	void RadialMenuSelectSpot(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RadialMenuSelectSpot
	void SelectRadialMenuItem(struct FName Category, struct FName SubItem); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SelectRadialMenuItem
	void SpawnAndInitDeployableSPAtPawn(ABP_HDProj_SPDeployableBase_C* SPDeployableClass, struct FVector SpawnOffset, struct ABP_HDProj_SPDeployableBase_C*& SpawnedDeployableSP); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SpawnAndInitDeployableSPAtPawn
	void LeanDebug(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.LeanDebug
	void IsMatchingTeam(struct AController* LocalController, bool& bMatchingTeam); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.IsMatchingTeam
	void GetPlayerFactionInfoClass(uint8_t  PlayerTeam, UBP_HDFactionInfoBase_C*& FactionInfoClass); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetPlayerFactionInfoClass
	void ClearHealthRegenTimer(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ClearHealthRegenTimer
	void SetHealthRegenTimerIfInvalid(float NewHealth); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetHealthRegenTimerIfInvalid
	void HealthRegenTimerElapsed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.HealthRegenTimerElapsed
	void CleanupVOIPTalker(bool& bDestroyedComp); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.CleanupVOIPTalker
	void SetupVOIPTalker(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetupVOIPTalker
	void EquipSelectedItemFromInventory(bool bSwitchFireModeForSelected); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EquipSelectedItemFromInventory
	void GetMostValidLoadout(struct UHDKit*& PlayerLoadout); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidLoadout
	void GetMostValidTeamFactionInfo(UDFFactionInfo*& FactionInfoClass); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidTeamFactionInfo
	void GetMostValidTeamState(struct ADFTeamState*& TeamState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidTeamState
	void GetMostValidPlayerState(struct APlayerState*& PlayerState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMostValidPlayerState
	struct USkeletalMesh* ReceiveGetDefaultPawnMesh1P(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveGetDefaultPawnMesh1P
	void UpdateEquipmentItems(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateEquipmentItems
	void UpdatePOIState(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdatePOIState
	void GetMinimapWidget(struct AController* Controller, struct UDFMinimap*& MinimapWidget); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GetMinimapWidget
	void ApplyCharacterVariation(struct FDFCharacterVariationDataHandle VariationHandle, bool bApplyToFPP); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ApplyCharacterVariation
	void UpdateCharMeshes(struct USkeletalMesh* MeshFPP, struct USkeletalMesh* MeshTPP); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMeshes
	void UpdateCharMeshesFromFaction(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UpdateCharMeshesFromFaction
	void SelectEquipmentBySlotNum(int32_t EquipSlotNum, bool bEquipImmediately, bool bFromInput); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SelectEquipmentBySlotNum
	void SetEquipmentTimer(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SetEquipmentTimer
	void StartEquipmentTimer(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.StartEquipmentTimer
	void FreeAiming(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.FreeAiming
	void UserConstructionScript(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.UserConstructionScript
	void SuppressionTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SuppressionTimeline__FinishedFunc
	void SuppressionTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SuppressionTimeline__UpdateFunc
	void DamageEffectTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.DamageEffectTimeline__FinishedFunc
	void DamageEffectTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.DamageEffectTimeline__UpdateFunc
	void LerpTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.LerpTimeline__FinishedFunc
	void LerpTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.LerpTimeline__UpdateFunc
	void VaultCameraTimeline__FinishedFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.VaultCameraTimeline__FinishedFunc
	void VaultCameraTimeline__UpdateFunc(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.VaultCameraTimeline__UpdateFunc
	void InpActEvt_NextItem_K2Node_InputActionEvent_17(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_NextItem_K2Node_InputActionEvent_17
	void InpActEvt_PreviousItem_K2Node_InputActionEvent_16(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_PreviousItem_K2Node_InputActionEvent_16
	void InpActEvt_CameraToggle_K2Node_InputActionEvent_15(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_CameraToggle_K2Node_InputActionEvent_15
	void InpActEvt_EqpSlot0_K2Node_InputActionEvent_14(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot0_K2Node_InputActionEvent_14
	void InpActEvt_EqpSlot1_K2Node_InputActionEvent_13(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot1_K2Node_InputActionEvent_13
	void InpActEvt_EqpSlot2_K2Node_InputActionEvent_12(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot2_K2Node_InputActionEvent_12
	void InpActEvt_EqpSlot3_K2Node_InputActionEvent_11(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot3_K2Node_InputActionEvent_11
	void InpActEvt_EqpSlot4_K2Node_InputActionEvent_10(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot4_K2Node_InputActionEvent_10
	void InpActEvt_EqpSlot5_K2Node_InputActionEvent_9(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot5_K2Node_InputActionEvent_9
	void InpActEvt_EqpSlot6_K2Node_InputActionEvent_8(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot6_K2Node_InputActionEvent_8
	void InpActEvt_EqpSlot7_K2Node_InputActionEvent_7(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot7_K2Node_InputActionEvent_7
	void InpActEvt_EqpSlot8_K2Node_InputActionEvent_6(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot8_K2Node_InputActionEvent_6
	void InpActEvt_EqpSlot9_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_EqpSlot9_K2Node_InputActionEvent_5
	void InpActEvt_RadialMenu_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_RadialMenu_K2Node_InputActionEvent_4
	void InpActEvt_RadialMenu_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_RadialMenu_K2Node_InputActionEvent_3
	void InpActEvt_CycleWeaponSights_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_CycleWeaponSights_K2Node_InputActionEvent_2
	void InpActEvt_PointAimToggle_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.InpActEvt_PointAimToggle_K2Node_InputActionEvent_1
	void BndEvt__Suppression_L_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_L_K2Node_ComponentBoundEvent_1_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Suppression_A_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_A_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
	void BndEvt__Suppression_B_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_B_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
	void EventResetHealthEffect(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EventResetHealthEffect
	void GenericDamageFeedback(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.GenericDamageFeedback
	void ReceiveTick(float DeltaSeconds); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveTick
	void OnDeath(float KillingDamage, struct FDamageEvent& DamageEvent, struct APawn* InstigatingPawn, struct AActor* DamageCauser); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnDeath
	void OnEquipmentTimerElapsed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnEquipmentTimerElapsed
	void ReceiveCurrentLoadout(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveCurrentLoadout
	void RetryLoadout(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.RetryLoadout
	void ReceivePossessed(struct AController* NewController); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePossessed
	void OnPCFirePressed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnPCFirePressed
	void OnLanded(struct FHitResult& Hit); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnLanded
	void ReceiveRestart(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveRestart
	void ReceiveDestroyed(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveDestroyed
	void ReceivePawnTeamNumUpdated(char LastTeamNum, char NewTeamNum); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePawnTeamNumUpdated
	void ReceiveFreeAim(float DeltaSeconds); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveFreeAim
	void NotifyPlayerStateChanged(struct APlayerState* NewPlayerState, struct APlayerState* OldPlayerState); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.NotifyPlayerStateChanged
	void ReceiveBeginPlay(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveBeginPlay
	void FirstPersonToggled(bool bFirstPerson); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.FirstPersonToggled
	void OnPCFireReleased(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnPCFireReleased
	void PlayerNameChanged(struct APlayerState* PS, struct FString NewPlayerName); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.PlayerNameChanged
	void ReceiveEndPlay(char EEndPlayReason EndPlayReason); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveEndPlay
	void ReceiveUnpossessed(struct AController* OldController); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveUnpossessed
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveAnyDamage
	void ReceivePawnTeamStateUpdated(struct ADFTeamState* TeamStateBeforeUpdate, struct ADFTeamState* NewTeamState, bool bNewTeamStateInit); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePawnTeamStateUpdated
	void K2_OnMovementModeChanged(char EMovementMode PrevMovementMode, char EMovementMode NewMovementMode, char PrevCustomMode, char NewCustomMode); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.K2_OnMovementModeChanged
	void Hit Damage(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.Hit Damage
	void ServerRadialMenuSelectOutpost(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ServerRadialMenuSelectOutpost
	void ServerRadialMenuSelectRallypoint(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ServerRadialMenuSelectRallypoint
	void ServerRadialMenuSelectSpot(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ServerRadialMenuSelectSpot
	void ReceiveVoipTalkerMsgReceived(struct UDFCommChannel* MsgTalkerChannel, struct APlayerState* MsgTalkerPS, bool bMsgIsTalking); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveVoipTalkerMsgReceived
	void BndEvt__Suppression_R_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.BndEvt__Suppression_R_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void ReceiveOnStartAim(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnStartAim
	void ReceiveOnEndAim(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnEndAim
	void EnterRadialMenu(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.EnterRadialMenu
	void ExitRadialMenu(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ExitRadialMenu
	void SubmenuCommited(struct FName Category, struct FName SubItem); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SubmenuCommited
	void ReceiveEquippedItemChanged(struct ADFBaseItem* NewEquippedItem, struct ADFBaseItem* PrevEquippedItem); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveEquippedItemChanged
	void ReceivePlayHit(float DamageTaken, struct FDamageEvent& DamageEvent, struct APawn* PawnInstigator, struct AActor* DamageCauser, bool bKilled); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceivePlayHit
	void ReceiveVariationDataChanged(struct FDFCharacterVariationData& NewVariation, struct FDFCharacterVariationData& PreviousVariation); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveVariationDataChanged
	void ReceiveHealthChanged(float NewHealthTotal, float PrevHealthTotal); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveHealthChanged
	void ReceiveOnStartVault(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnStartVault
	void ReceiveOnEndVault(); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ReceiveOnEndVault
	void SuppressionEffect(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup, struct UPrimitiveComponent* SuppressionVolume); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.SuppressionEffect
	void ExecuteUbergraph_BP_HDPlayerCharacterBase(int32_t EntryPoint); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.ExecuteUbergraph_BP_HDPlayerCharacterBase
	void OnHitDamage__DelegateSignature(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnHitDamage__DelegateSignature
	void OnSuppression__DelegateSignature(struct ADFBaseProjectile* OtherProjectile, struct ADFBasePickup* Pickup); // Function BP_HDPlayerCharacterBase.BP_HDPlayerCharacterBase_C.OnSuppression__DelegateSignature
}; 



