#pragma once 
#include "SDK.h" 
 
 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.PreConstruct
// Size: 0x1(Inherited: 0x1) 
struct FPreConstruct : public FPreConstruct
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsDesignTime : 1;  // 0x0(0x1)

}; 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnTextChanged__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnTextChanged__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.OnTextCommitted__DelegateSignature
// Size: 0x19(Inherited: 0x0) 
struct FOnTextCommitted__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)
	char ETextCommit CommitMethod;  // 0x18(0x1)

}; 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.ExecuteUbergraph_WBP_ModifierSetting_EditableText
// Size: 0x71(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_ModifierSetting_EditableText
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText Temp_text_Variable;  // 0x8(0x18)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_IsDesignTime : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_TextIsEmpty_ReturnValue : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool Temp_bool_Variable : 1;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)
	struct FText K2Node_Select_Default;  // 0x28(0x18)
	struct FText K2Node_ComponentBoundEvent_Text_2;  // 0x40(0x18)
	struct FText K2Node_ComponentBoundEvent_Text;  // 0x58(0x18)
	char ETextCommit K2Node_ComponentBoundEvent_CommitMethod;  // 0x70(0x1)

}; 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_3_OnEditableTextCommittedEvent__DelegateSignature
// Size: 0x19(Inherited: 0x0) 
struct FBndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_3_OnEditableTextCommittedEvent__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)
	char ETextCommit CommitMethod;  // 0x18(0x1)

}; 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.SetSettingLabel
// Size: 0x18(Inherited: 0x0) 
struct FSetSettingLabel
{
	struct FText InSettingText;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.BndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FBndEvt__ModifierEditableText_K2Node_ComponentBoundEvent_2_OnEditableTextChangedEvent__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)

}; 
// Function WBP_ModifierSetting_EditableText.WBP_ModifierSetting_EditableText_C.GetSettingLabel
// Size: 0x18(Inherited: 0x0) 
struct FGetSettingLabel
{
	struct FText SettingText;  // 0x0(0x18)

}; 
