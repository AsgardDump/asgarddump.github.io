#pragma once 
#include "SDK.h" 
 
 
// Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.ExecuteUbergraph_WBP_HDContextualWidgetBase
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_WBP_HDContextualWidgetBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UDFContextualWidgetPrerequisiteBase* K2Node_Event_FailedPrereq;  // 0x8(0x8)

}; 
// Function WBP_HDContextualWidgetBase.WBP_HDContextualWidgetBase_C.PrerequisiteNotMet
// Size: 0x8(Inherited: 0x8) 
struct FPrerequisiteNotMet : public FPrerequisiteNotMet
{
	struct UDFContextualWidgetPrerequisiteBase* FailedPrereq;  // 0x0(0x8)

}; 
