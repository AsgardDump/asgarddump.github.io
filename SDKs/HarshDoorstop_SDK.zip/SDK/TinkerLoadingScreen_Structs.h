#pragma once 
#include "SDK.h" 
 
 
// Function TinkerLoadingScreen.LoadingScreenWidgetInterface.SetLoadingScreenDescription
// Size: 0x38(Inherited: 0x0) 
struct FSetLoadingScreenDescription
{
	struct FLoadingScreenDescription Description;  // 0x0(0x38)

}; 
// ScriptStruct TinkerLoadingScreen.LoadScreenLevelData
// Size: 0x68(Inherited: 0x0) 
struct FLoadScreenLevelData
{
	struct FText MapFriendlyName;  // 0x0(0x18)
	struct FText GameModeFriendlyName;  // 0x18(0x18)
	struct TSoftObjectPtr<UTexture2D> MapLoadingImage;  // 0x30(0x28)
	char bMainMenuMap : 1;  // 0x58(0x1)
	char pad_88_1 : 7;  // 0x58(0x1)
	char pad_89[4];  // 0x59(0x4)
	int32_t StartingTicketsBlufor;  // 0x5C(0x4)
	int32_t StartingTicketsOpfor;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// ScriptStruct TinkerLoadingScreen.LoadingScreenDescription
// Size: 0x38(Inherited: 0x0) 
struct FLoadingScreenDescription
{
	float MinimumLoadingScreenDisplayTime;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bAutoCompleteWhenLoadingCompletes : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool bMoviesAreSkippable : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool bWaitForManualStop : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct TArray<struct FString> MoviePaths;  // 0x8(0x10)
	char EMoviePlaybackType PlaybackType;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bShowOverlayWidget : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FSoftClassPath OverlayWidgetClass;  // 0x20(0x18)

}; 
// Function TinkerLoadingScreen.LoadingScreenWidgetInterface.SetLevelLoadData
// Size: 0x68(Inherited: 0x0) 
struct FSetLevelLoadData
{
	struct FLoadScreenLevelData LevelData;  // 0x0(0x68)

}; 
