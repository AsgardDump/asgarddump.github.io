#pragma once 
#include "SDK.h" 
 
 
// Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintInt
// Size: 0x40(Inherited: 0x0) 
struct FPrintInt
{
	struct FString Name;  // 0x0(0x10)
	int32_t InInteger;  // 0x10(0x4)
	struct FLinearColor TextColor;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct UObject* __WorldContext;  // 0x28(0x8)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x30(0x10)

}; 
// Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintProperty
// Size: 0x58(Inherited: 0x0) 
struct FPrintProperty
{
	struct FString PropName;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	struct FLinearColor TextColor;  // 0x20(0x10)
	struct UObject* __WorldContext;  // 0x30(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)

}; 
// Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintStr
// Size: 0x38(Inherited: 0x0) 
struct FPrintStr
{
	struct FString Name;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	struct FLinearColor TextColor;  // 0x20(0x10)
	struct UObject* __WorldContext;  // 0x30(0x8)

}; 
// Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintBool
// Size: 0x40(Inherited: 0x0) 
struct FPrintBool
{
	struct FString Name;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bInBool : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor TextColor;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct UObject* __WorldContext;  // 0x28(0x8)
	struct FString CallFunc_Conv_BoolToString_ReturnValue;  // 0x30(0x10)

}; 
// Function BPFL_DebugUtils.BPFL_DebugUtils_C.PrintFloat
// Size: 0x40(Inherited: 0x0) 
struct FPrintFloat
{
	struct FString Name;  // 0x0(0x10)
	float InFloat;  // 0x10(0x4)
	struct FLinearColor TextColor;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct UObject* __WorldContext;  // 0x28(0x8)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x30(0x10)

}; 
