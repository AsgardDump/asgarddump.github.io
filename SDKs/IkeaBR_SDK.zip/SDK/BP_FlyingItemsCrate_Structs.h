#pragma once 
#include "SDK.h" 
 
 
// Function BP_FlyingItemsCrate.BP_FlyingItemsCrate_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_FlyingItemsCrate.BP_FlyingItemsCrate_C.ExecuteUbergraph_BP_FlyingItemsCrate
// Size: 0x17C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FlyingItemsCrate
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x8(0x4)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0xC(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x18(0x10)
	float CallFunc_BreakVector_X;  // 0x28(0x4)
	float CallFunc_BreakVector_Y;  // 0x2C(0x4)
	float CallFunc_BreakVector_Z;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x44(0xC)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x58(0x10)
	struct FHitResult CallFunc_SphereTraceSingleForObjects_OutHit;  // 0x68(0x88)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_SphereTraceSingleForObjects_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0xF4(0x88)

}; 
