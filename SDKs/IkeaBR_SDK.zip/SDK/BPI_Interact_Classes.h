#pragma once 
#include <BPI_Interact_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_Interact.BPI_Interact_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_Interact_C : public UInterface
{

	void RecieveServerLook(bool& Recieve?); // Function BPI_Interact.BPI_Interact_C.RecieveServerLook
	void ServerOnStopLook(struct AFirstPersonCharacter_C* Player); // Function BPI_Interact.BPI_Interact_C.ServerOnStopLook
	void ServerOnLook(struct AFirstPersonCharacter_C* Player); // Function BPI_Interact.BPI_Interact_C.ServerOnLook
	void OnChargeUpdate(float Charge, struct AFirstPersonCharacter_C* Caller); // Function BPI_Interact.BPI_Interact_C.OnChargeUpdate
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function BPI_Interact.BPI_Interact_C.OnStopLook
	void OnLook(struct AFirstPersonCharacter_C* Caller); // Function BPI_Interact.BPI_Interact_C.OnLook
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function BPI_Interact.BPI_Interact_C.OnInteract
}; 



