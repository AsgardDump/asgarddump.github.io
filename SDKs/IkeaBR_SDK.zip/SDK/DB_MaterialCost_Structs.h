#pragma once 
#include "SDK.h" 
 
 
// Function DB_MaterialCost.DB_MaterialCost_C.Get_I_WoodCost_2_Brush_1
// Size: 0x110(Inherited: 0x0) 
struct FGet_I_WoodCost_2_Brush_1
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)
	struct FSlateBrush CallFunc_MakeBrushFromTexture_ReturnValue;  // 0x88(0x88)

}; 
// Function DB_MaterialCost.DB_MaterialCost_C.Get_WoodCost_2_Text_1
// Size: 0x30(Inherited: 0x0) 
struct FGet_WoodCost_2_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x18(0x18)

}; 
