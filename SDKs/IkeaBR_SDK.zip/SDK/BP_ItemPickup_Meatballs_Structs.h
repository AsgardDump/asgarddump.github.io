#pragma once 
#include "SDK.h" 
 
 
// Function BP_ItemPickup_Meatballs.BP_ItemPickup_Meatballs_C.ExecuteUbergraph_BP_ItemPickup_Meatballs
// Size: 0xC1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ItemPickup_Meatballs
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x8(0x8)
	ABP_MeatballPack_C* K2Node_ClassDynamicCast_AsBP_Meatball_Pack;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_2;  // 0x20(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x28(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB5(0x1)
	char pad_182[2];  // 0xB6(0x2)
	ABP_MeatballLauncher_C* K2Node_ClassDynamicCast_AsBP_Meatball_Launcher;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0xC0(0x1)

}; 
// Function BP_ItemPickup_Meatballs.BP_ItemPickup_Meatballs_C.OnStopLook
// Size: 0x8(Inherited: 0x8) 
struct FOnStopLook : public FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function BP_ItemPickup_Meatballs.BP_ItemPickup_Meatballs_C.OnInteract
// Size: 0x94(Inherited: 0x94) 
struct FOnInteract : public FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
