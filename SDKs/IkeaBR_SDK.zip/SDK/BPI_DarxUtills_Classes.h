#pragma once 
#include <BPI_DarxUtills_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_DarxUtills.BPI_DarxUtills_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_DarxUtills_C : public UInterface
{

	void DestroySkeletalMesh(struct USkeletalMeshComponent* Mesh, struct USkeletalMesh*& Out); // Function BPI_DarxUtills.BPI_DarxUtills_C.DestroySkeletalMesh
	void AddSkeletalMesh(struct FName Tag, struct USkeletalMeshComponent*& Mesh); // Function BPI_DarxUtills.BPI_DarxUtills_C.AddSkeletalMesh
	void AddStaticMesh(struct FName Tag, struct UStaticMeshComponent*& Mesh); // Function BPI_DarxUtills.BPI_DarxUtills_C.AddStaticMesh
	void DestroyStaticMesh(struct UStaticMeshComponent* Mesh, struct UStaticMesh*& Out); // Function BPI_DarxUtills.BPI_DarxUtills_C.DestroyStaticMesh
}; 



