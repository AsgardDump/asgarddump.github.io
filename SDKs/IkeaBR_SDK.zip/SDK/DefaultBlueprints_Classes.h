#pragma once 
#include <DefaultBlueprints_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DefaultBlueprints.DefaultBlueprints_C
// Size: 0x2DC(Inherited: 0x260) 
struct UDefaultBlueprints_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UDB_ItemDesciption_C* DB_ItemDesciption;  // 0x268(0x8)
	struct UDB_Slot_C* DB_Slot_1;  // 0x270(0x8)
	struct UDB_Slot_C* DB_Slot_2;  // 0x278(0x8)
	struct UDB_Slot_C* DB_Slot_3;  // 0x280(0x8)
	struct UDB_Slot_C* DB_Slot_4;  // 0x288(0x8)
	struct UUniformGridPanel* ToSelect;  // 0x290(0x8)
	struct UVerticalBox* VerticalBox_2;  // 0x298(0x8)
	int32_t Selected1;  // 0x2A0(0x4)
	int32_t Selected2;  // 0x2A4(0x4)
	int32_t Selected3;  // 0x2A8(0x4)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool ShowSelection? : 1;  // 0x2AC(0x1)
	char pad_685[3];  // 0x2AD(0x3)
	int32_t LastSelectedIndex;  // 0x2B0(0x4)
	int32_t SelectionItemIndex;  // 0x2B4(0x4)
	struct ABP_RecipePreview_C* PreviewActor;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool Index : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)
	struct TArray<int32_t> NewVar_1;  // 0x2C8(0x10)
	int32_t Selected4;  // 0x2D8(0x4)

	uint8_t  ShouldShowSelection(); // Function DefaultBlueprints.DefaultBlueprints_C.ShouldShowSelection
	void Completed_6F07F8864F50B817CAEDB38530BE0042(struct USaveGame* SaveGame, bool bSuccess); // Function DefaultBlueprints.DefaultBlueprints_C.Completed_6F07F8864F50B817CAEDB38530BE0042
	void Completed_215CB37D43646A0095BC739722A6680E(struct USaveGame* SaveGame, bool bSuccess); // Function DefaultBlueprints.DefaultBlueprints_C.Completed_215CB37D43646A0095BC739722A6680E
	void Completed_0914B3504C491F3C20AD17967400C52E(struct USaveGame* SaveGame, bool bSuccess); // Function DefaultBlueprints.DefaultBlueprints_C.Completed_0914B3504C491F3C20AD17967400C52E
	void Completed_6F07F8864F50B817CAEDB3854EACD4F8(struct USaveGame* SaveGame, bool bSuccess); // Function DefaultBlueprints.DefaultBlueprints_C.Completed_6F07F8864F50B817CAEDB3854EACD4F8
	void Completed_6F07F8864F50B817CAEDB385507E4A95(struct USaveGame* SaveGame, bool bSuccess); // Function DefaultBlueprints.DefaultBlueprints_C.Completed_6F07F8864F50B817CAEDB385507E4A95
	void Completed_215CB37D43646A0095BC7397426622D9(struct USaveGame* SaveGame, bool bSuccess); // Function DefaultBlueprints.DefaultBlueprints_C.Completed_215CB37D43646A0095BC7397426622D9
	void Completed_215CB37D43646A0095BC73975CB4BCB4(struct USaveGame* SaveGame, bool bSuccess); // Function DefaultBlueprints.DefaultBlueprints_C.Completed_215CB37D43646A0095BC73975CB4BCB4
	void OnRecipeSelected(int32_t Recipe, int32_t SelectionIndex); // Function DefaultBlueprints.DefaultBlueprints_C.OnRecipeSelected
	void ShowSelection(int32_t Index); // Function DefaultBlueprints.DefaultBlueprints_C.ShowSelection
	void Construct(); // Function DefaultBlueprints.DefaultBlueprints_C.Construct
	void OnHoverRecipe(int32_t Recipe); // Function DefaultBlueprints.DefaultBlueprints_C.OnHoverRecipe
	void Destruct(); // Function DefaultBlueprints.DefaultBlueprints_C.Destruct
	void ExecuteUbergraph_DefaultBlueprints(int32_t EntryPoint); // Function DefaultBlueprints.DefaultBlueprints_C.ExecuteUbergraph_DefaultBlueprints
}; 



