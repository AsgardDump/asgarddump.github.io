#pragma once 
#include <BP_UpgradeItem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_UpgradeItem.BP_UpgradeItem_C
// Size: 0x270(Inherited: 0x268) 
struct ABP_UpgradeItem_C : public AItemBP_C
{
	UC_Upgrade_C* Upgrade;  // 0x268(0x8)

}; 



