#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction EOSCoreUtilities.OnRequestAppTicketResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnRequestAppTicketResponse__DelegateSignature
{
	struct FString Ticket;  // 0x0(0x10)

}; 
// DelegateFunction EOSCoreUtilities.OnRequestEncryptedAppTicketDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnRequestEncryptedAppTicketDelegate__DelegateSignature
{
	struct FString Ticket;  // 0x0(0x10)

}; 
// Function EOSCoreUtilities.EOSCoreUtilitiesLibrary.RequestEncryptedAppTicket
// Size: 0x10(Inherited: 0x0) 
struct FRequestEncryptedAppTicket
{
	struct FDelegate Callback;  // 0x0(0x10)

}; 
