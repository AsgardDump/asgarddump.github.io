#pragma once 
#include "SDK.h" 
 
 
// Function AmmoCounter.AmmoCounter_C.GetText_1
// Size: 0xE0(Inherited: 0x0) 
struct FGetText_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0x18(0x90)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0xA8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xB8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xC8(0x18)

}; 
