#pragma once 
#include <BP_Tracker_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Tracker.BP_Tracker_C
// Size: 0x280(Inherited: 0x268) 
struct ABP_Tracker_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool Ringing : 1;  // 0x270(0x1)
	char pad_625[3];  // 0x271(0x3)
	float MinDistance;  // 0x274(0x4)
	struct AFirstPersonCharacter_C* ClosestPlayer;  // 0x278(0x8)

	void LMB_Pure(bool Down); // Function BP_Tracker.BP_Tracker_C.LMB_Pure
	void Equip(); // Function BP_Tracker.BP_Tracker_C.Equip
	void Hit(struct AFirstPersonCharacter_C* Hitter, float Damage); // Function BP_Tracker.BP_Tracker_C.Hit
	void OnStunned_Event_1(); // Function BP_Tracker.BP_Tracker_C.OnStunned_Event_1
	void Stop(); // Function BP_Tracker.BP_Tracker_C.Stop
	void Unequip(); // Function BP_Tracker.BP_Tracker_C.Unequip
	void ExecuteUbergraph_BP_Tracker(int32_t EntryPoint); // Function BP_Tracker.BP_Tracker_C.ExecuteUbergraph_BP_Tracker
}; 



