#pragma once 
#include <BP_MetalArrow_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MetalArrow.BP_MetalArrow_C
// Size: 0x257(Inherited: 0x257) 
struct ABP_MetalArrow_C : public ABP_Projectile_C
{

}; 



