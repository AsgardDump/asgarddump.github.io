#pragma once 
#include "SDK.h" 
 
 
// Function CameraPawn.CameraPawn_C.ExecuteUbergraph_CameraPawn
// Size: 0xD9(Inherited: 0x0) 
struct FExecuteUbergraph_CameraPawn
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct ACameraPawn_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x8(0x10)
	struct ACameraPawn_C* CallFunc_Array_Get_Item;  // 0x18(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x20(0x30)
	struct FHitResult CallFunc_K2_SetActorTransform_SweepHitResult;  // 0x50(0x88)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_K2_SetActorTransform_ReturnValue : 1;  // 0xD8(0x1)

}; 
