#pragma once 
#include <Block_Structs.h>
 
 
 
// BlueprintGeneratedClass Block.Block_C
// Size: 0xB1(Inherited: 0xA8) 
struct UBlock_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool Block : 1;  // 0xB0(0x1)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Block.Block_C.ReceiveExecuteAI
	void ExecuteUbergraph_Block(int32_t EntryPoint); // Function Block.Block_C.ExecuteUbergraph_Block
}; 



