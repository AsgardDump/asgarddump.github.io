#pragma once 
#include "SDK.h" 
 
 
// Function CosmeticScrappingAction.CosmeticScrappingAction_C.OnScrapAdded
// Size: 0x11(Inherited: 0x0) 
struct FOnScrapAdded
{
	struct FString Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function CosmeticScrappingAction.CosmeticScrappingAction_C.ExecuteUbergraph_CosmeticScrappingAction
// Size: 0x16C(Inherited: 0x0) 
struct FExecuteUbergraph_CosmeticScrappingAction
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0x8(0x8)
	struct FString K2Node_CustomEvent_Data_2;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_2 : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0x28(0x10)
	int32_t CallFunc_Len_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_writeStringToFile_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x3D(0x1)
	char pad_62_1 : 7;  // 0x3E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3E(0x1)
	char pad_63[1];  // 0x3F(0x1)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR;  // 0x40(0x8)
	struct FString K2Node_CustomEvent_Data;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_CustomEvent_bWasSuccessful : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FSteamInventoryResult CallFunc_ConsumeItem_Result;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_ConsumeItem_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FString CallFunc_BreakSteamItemInstanceID_ValueString;  // 0x68(0x10)
	int64_t CallFunc_BreakSteamItemInstanceID_FakeBlueprintIntValue;  // 0x78(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x80(0x4)
	char E_Tier CallFunc_GetSteamTier_Tier;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	int32_t CallFunc_CosmeticTierToScrapAmount_ScrapAmount;  // 0x88(0x4)
	int32_t CallFunc_GetAppID_Pure_ReturnValue;  // 0x8C(0x4)
	struct FString CallFunc_SteamWebKey_Key;  // 0x90(0x10)
	struct FString CallFunc_RandomUInt64_ReturnValue;  // 0xA0(0x10)
	struct UWebInventoryService* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0xB0(0x8)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR_2;  // 0xB8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xC0(0x10)
	int32_t K2Node_CustomEvent_CosmeticSteamDefID;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct UObject* K2Node_CustomEvent_NewWorldContext;  // 0xD8(0x8)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0xE0(0x10)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_DoesSteamItemsArrayHaveInstance_Result : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	int32_t CallFunc_DoesSteamItemsArrayHaveInstance_Array_Index;  // 0xF4(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0xF8(0x10)
	struct TArray<struct FST_SteamItem> CallFunc_Get_Steam_Items_by_ID_out;  // 0x108(0x10)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool CallFunc_Get_Steam_Items_by_ID_Empty : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct FST_SteamItem CallFunc_Array_Get_Item;  // 0x120(0x38)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x158(0x4)
	char pad_348_1 : 7;  // 0x15C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x15C(0x1)
	char pad_349[3];  // 0x15D(0x3)
	int32_t Temp_int_Variable;  // 0x160(0x4)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x164(0x1)
	char pad_357[3];  // 0x165(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x168(0x4)

}; 
// Function CosmeticScrappingAction.CosmeticScrappingAction_C.OnCosmeticConsumed
// Size: 0x11(Inherited: 0x0) 
struct FOnCosmeticConsumed
{
	struct FString Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function CosmeticScrappingAction.CosmeticScrappingAction_C.ScrapCosmetic
// Size: 0x10(Inherited: 0x0) 
struct FScrapCosmetic
{
	int32_t CosmeticSteamDefID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* NewWorldContext;  // 0x8(0x8)

}; 
