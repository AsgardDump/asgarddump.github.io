#pragma once 
#include <BlobSerialization_Structs.h>
 
 
 
// Class BlobSerialization.BlobFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UBlobFunctionLibrary : public UBlueprintFunctionLibrary
{

	bool TypedBlobToStruct(struct FBlob& InBlob, int32_t& OutStruct, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.TypedBlobToStruct
	void StructToTypedBlob(int32_t& InStruct, struct FBlob& OutBlob, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.StructToTypedBlob
	void StructToJson(int32_t& Struct, struct FString& JsonString); // Function BlobSerialization.BlobFunctionLibrary.StructToJson
	void StructToBlob(int32_t& InStruct, struct FBlob& OutBlob, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.StructToBlob
	bool SaveStringToFile(struct FString Filename, struct FString FileContents); // Function BlobSerialization.BlobFunctionLibrary.SaveStringToFile
	bool SaveBlobToFile(struct FString Filename, struct FBlob& FileContents); // Function BlobSerialization.BlobFunctionLibrary.SaveBlobToFile
	void Reset(struct FBlob& Blob); // Function BlobSerialization.BlobFunctionLibrary.Reset
	void PolyObjectToBlob(struct UObject* InObject, struct FBlob& OutBlob, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.PolyObjectToBlob
	void PolyObjectArrayToBlob(struct TArray<struct UObject*>& InObjectArray, struct FBlob& OutBlob, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.PolyObjectArrayToBlob
	void ObjectToJson(struct UObject* InObject, struct FString& JsonString); // Function BlobSerialization.BlobFunctionLibrary.ObjectToJson
	void ObjectToBlob(struct UObject* InObject, struct FBlob& OutBlob, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.ObjectToBlob
	bool LoadFileToString(struct FString Filename, struct FString& FileContents); // Function BlobSerialization.BlobFunctionLibrary.LoadFileToString
	bool LoadFileToBlob(struct FString Filename, struct FBlob& FileContents); // Function BlobSerialization.BlobFunctionLibrary.LoadFileToBlob
	void JsonToStruct(struct FString JsonString, int32_t& Struct); // Function BlobSerialization.BlobFunctionLibrary.JsonToStruct
	void JsonToObject(struct FString JsonString, struct UObject* InObject); // Function BlobSerialization.BlobFunctionLibrary.JsonToObject
	bool IsEmpty(struct FBlob& Blob); // Function BlobSerialization.BlobFunctionLibrary.IsEmpty
	struct FBlob Conv_StringToBinaryBlob(struct FString a_base64String); // Function BlobSerialization.BlobFunctionLibrary.Conv_StringToBinaryBlob
	struct FString Conv_BinaryBlobToString(struct FBlob& Blob); // Function BlobSerialization.BlobFunctionLibrary.Conv_BinaryBlobToString
	void BlobToStruct(struct FBlob& InBlob, int32_t& OutStruct, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.BlobToStruct
	void BlobToPolyObjectArray(struct FBlob& InBlob, struct TArray<struct UObject*> InObjectArray, struct TArray<struct UObject*>& OutObjectArray, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.BlobToPolyObjectArray
	void BlobToPolyObject(struct FBlob& InBlob, struct UObject* InObject, struct UObject*& OutObject, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.BlobToPolyObject
	void BlobToObject(struct FBlob& InBlob, struct UObject* InObject, struct UObject*& OutObject, uint8_t  Behavior, struct UObject* NetContext); // Function BlobSerialization.BlobFunctionLibrary.BlobToObject
}; 



