#pragma once 
#include <ExplosionCS_Structs.h>
 
 
 
// BlueprintGeneratedClass ExplosionCS.ExplosionCS_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UExplosionCS_C : public UMatineeCameraShake
{

}; 



