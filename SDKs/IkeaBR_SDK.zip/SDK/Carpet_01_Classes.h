#pragma once 
#include <Carpet_01_Structs.h>
 
 
 
// BlueprintGeneratedClass Carpet_01.Carpet_01_C
// Size: 0x230(Inherited: 0x220) 
struct ACarpet_01_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)

}; 



