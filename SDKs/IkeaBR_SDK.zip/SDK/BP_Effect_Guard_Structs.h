#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Guard.BP_Effect_Guard_C.ExecuteUbergraph_BP_Effect_Guard
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Guard
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent_2;  // 0x10(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x18(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x1C(0x4)

}; 
