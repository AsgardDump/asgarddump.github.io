#pragma once 
#include <BP_EMP_Thrown_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EMP_Thrown.BP_EMP_Thrown_C
// Size: 0x260(Inherited: 0x257) 
struct ABP_EMP_Thrown_C : public ABP_Projectile_C
{
	char pad_599[1];  // 0x257(0x1)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x258(0x8)

	void Hit(struct AActor* other actor, struct FHitResult& HitResult); // Function BP_EMP_Thrown.BP_EMP_Thrown_C.Hit
	void ExecuteUbergraph_BP_EMP_Thrown(int32_t EntryPoint); // Function BP_EMP_Thrown.BP_EMP_Thrown_C.ExecuteUbergraph_BP_EMP_Thrown
}; 



