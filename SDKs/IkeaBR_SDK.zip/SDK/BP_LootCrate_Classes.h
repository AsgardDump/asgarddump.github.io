#pragma once 
#include <BP_LootCrate_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_LootCrate.BP_LootCrate_C
// Size: 0x2F1(Inherited: 0x230) 
struct ABP_LootCrate_C : public AStaticMeshActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x230(0x8)
	struct UAudioComponent* FastHum;  // 0x238(0x8)
	struct UAudioComponent* Hum;  // 0x240(0x8)
	struct UStaticMeshComponent* Plane;  // 0x248(0x8)
	struct UChildActorComponent* ChildActor;  // 0x250(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x258(0x8)
	float Alpha_Alpha_D2114A16444B47C5E41B3EA3F9EB0E00;  // 0x260(0x4)
	char ETimelineDirection Alpha__Direction_D2114A16444B47C5E41B3EA3F9EB0E00;  // 0x264(0x1)
	char pad_613[3];  // 0x265(0x3)
	struct UTimelineComponent* Alpha;  // 0x268(0x8)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool Opening? : 1;  // 0x270(0x1)
	char pad_625[7];  // 0x271(0x7)
	struct UMaterialInstanceDynamic* Mat;  // 0x278(0x8)
	struct FST_Cosmetic Item;  // 0x280(0x50)
	float TempVolume;  // 0x2D0(0x4)
	char pad_724[4];  // 0x2D4(0x4)
	struct UMaterialInstanceDynamic* PlaneMat;  // 0x2D8(0x8)
	struct FMulticastInlineDelegate OnDone;  // 0x2E0(0x10)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool HasReceivedItem : 1;  // 0x2F0(0x1)

	void UserConstructionScript(); // Function BP_LootCrate.BP_LootCrate_C.UserConstructionScript
	void Alpha__FinishedFunc(); // Function BP_LootCrate.BP_LootCrate_C.Alpha__FinishedFunc
	void Alpha__UpdateFunc(); // Function BP_LootCrate.BP_LootCrate_C.Alpha__UpdateFunc
	void StartOpen(); // Function BP_LootCrate.BP_LootCrate_C.StartOpen
	void ItemRecieved(struct FST_SteamItem Item); // Function BP_LootCrate.BP_LootCrate_C.ItemRecieved
	void ReceiveBeginPlay(); // Function BP_LootCrate.BP_LootCrate_C.ReceiveBeginPlay
	void WaitForItem(); // Function BP_LootCrate.BP_LootCrate_C.WaitForItem
	void SetupPreviewMesh(); // Function BP_LootCrate.BP_LootCrate_C.SetupPreviewMesh
	void ResetSetup(); // Function BP_LootCrate.BP_LootCrate_C.ResetSetup
	void ReceiveTick(float DeltaSeconds); // Function BP_LootCrate.BP_LootCrate_C.ReceiveTick
	void FadeGlow(float Time, float From, float To); // Function BP_LootCrate.BP_LootCrate_C.FadeGlow
	void OnLand(); // Function BP_LootCrate.BP_LootCrate_C.OnLand
	void ExecuteUbergraph_BP_LootCrate(int32_t EntryPoint); // Function BP_LootCrate.BP_LootCrate_C.ExecuteUbergraph_BP_LootCrate
	void OnDone__DelegateSignature(struct FST_Cosmetic Item); // Function BP_LootCrate.BP_LootCrate_C.OnDone__DelegateSignature
}; 



