#pragma once 
#include <BP_Spray_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Spray.BP_Spray_C
// Size: 0x265(Inherited: 0x220) 
struct ABP_Spray_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UDecalComponent* Decal;  // 0x228(0x8)
	struct UTexture2D* Texture;  // 0x230(0x8)
	struct UMaterialInstanceDynamic* MatInst;  // 0x238(0x8)
	struct UMaterialInterface* Material;  // 0x240(0x8)
	struct FString URL;  // 0x248(0x10)
	struct FVector BaseScale;  // 0x258(0xC)
	char pad_612_1 : 7;  // 0x264(0x1)
	bool DontCallBeginPlay : 1;  // 0x264(0x1)

	void OnRep_URL(); // Function BP_Spray.BP_Spray_C.OnRep_URL
	void OnRep_Texture(); // Function BP_Spray.BP_Spray_C.OnRep_Texture
	void OnFail_EE1F039D4F0C99455AEBD097D29CFBEC(struct UTexture2D* OutTexture); // Function BP_Spray.BP_Spray_C.OnFail_EE1F039D4F0C99455AEBD097D29CFBEC
	void OnSuccess_EE1F039D4F0C99455AEBD097D29CFBEC(struct UTexture2D* OutTexture); // Function BP_Spray.BP_Spray_C.OnSuccess_EE1F039D4F0C99455AEBD097D29CFBEC
	void ReceiveBeginPlay(); // Function BP_Spray.BP_Spray_C.ReceiveBeginPlay
	void UpdateTexture(struct UTexture2D* Texture); // Function BP_Spray.BP_Spray_C.UpdateTexture
	void DownloadURL(struct FString URL); // Function BP_Spray.BP_Spray_C.DownloadURL
	void ExecuteUbergraph_BP_Spray(int32_t EntryPoint); // Function BP_Spray.BP_Spray_C.ExecuteUbergraph_BP_Spray
}; 



