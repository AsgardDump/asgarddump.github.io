#pragma once 
#include <ChampionModeIntro_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ChampionModeIntro.ChampionModeIntro_C
// Size: 0x270(Inherited: 0x260) 
struct UChampionModeIntro_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* Intro;  // 0x268(0x8)

	void Construct(); // Function ChampionModeIntro.ChampionModeIntro_C.Construct
	void ExecuteUbergraph_ChampionModeIntro(int32_t EntryPoint); // Function ChampionModeIntro.ChampionModeIntro_C.ExecuteUbergraph_ChampionModeIntro
}; 



