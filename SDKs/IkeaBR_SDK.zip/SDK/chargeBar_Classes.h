#pragma once 
#include <chargeBar_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass chargeBar.chargeBar_C
// Size: 0x2A0(Inherited: 0x260) 
struct UchargeBar_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* Fade;  // 0x268(0x8)
	struct UProgressBar* ProgressBar_26;  // 0x270(0x8)
	float TimetoCharge;  // 0x278(0x4)
	float Charge;  // 0x27C(0x4)
	float Time;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool Reverse : 1;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct FLinearColor ColorOnEnd;  // 0x288(0x10)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool Active : 1;  // 0x298(0x1)
	char pad_665[3];  // 0x299(0x3)
	float ColorChangeLevel;  // 0x29C(0x4)

	struct FLinearColor GetFillColorAndOpacity_1(); // Function chargeBar.chargeBar_C.GetFillColorAndOpacity_1
	void Construct(); // Function chargeBar.chargeBar_C.Construct
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function chargeBar.chargeBar_C.Tick
	void Destruct(); // Function chargeBar.chargeBar_C.Destruct
	void Destroy(); // Function chargeBar.chargeBar_C.Destroy
	void ExecuteUbergraph_chargeBar(int32_t EntryPoint); // Function chargeBar.chargeBar_C.ExecuteUbergraph_chargeBar
}; 



