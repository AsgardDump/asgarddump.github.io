#pragma once 
#include <CafeteriaChair_Structs.h>
 
 
 
// BlueprintGeneratedClass CafeteriaChair.CafeteriaChair_C
// Size: 0x2B8(Inherited: 0x2B0) 
struct ACafeteriaChair_C : public AMovable_Object_Replicated_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B0(0x8)

	void ReceiveBeginPlay(); // Function CafeteriaChair.CafeteriaChair_C.ReceiveBeginPlay
	void ExecuteUbergraph_CafeteriaChair(int32_t EntryPoint); // Function CafeteriaChair.CafeteriaChair_C.ExecuteUbergraph_CafeteriaChair
}; 



