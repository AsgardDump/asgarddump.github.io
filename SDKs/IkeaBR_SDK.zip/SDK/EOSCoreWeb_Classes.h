#pragma once 
#include <EOSCoreWeb_Structs.h>
 
 
 
// Class EOSCoreWeb.EOSWebAuthLibrary
// Size: 0x28(Inherited: 0x28) 
struct UEOSWebAuthLibrary : public UObject
{

	void RequestAuthAccessToken(struct FDelegate& Callback, struct FRequestAuthAccessTokenRequest Request); // Function EOSCoreWeb.EOSWebAuthLibrary.RequestAuthAccessToken
	void InitiateEpicAuthentication(struct FDelegate& Callback, struct FInitiateEpicAuthenticationRequest Request); // Function EOSCoreWeb.EOSWebAuthLibrary.InitiateEpicAuthentication
}; 



// Class EOSCoreWeb.EOSWebVoiceLibrary
// Size: 0x28(Inherited: 0x28) 
struct UEOSWebVoiceLibrary : public UObject
{

	void RemoveParticipant(struct FString AccessToken, struct FString ProductUserId, struct FString DeploymentId, struct FString RoomName, struct FDelegate& Callback); // Function EOSCoreWeb.EOSWebVoiceLibrary.RemoveParticipant
	void ModifyParticipant(struct FString AccessToken, struct FString ProductUserId, struct FString DeploymentId, struct FString RoomName, bool bHardMuted, struct FDelegate& Callback); // Function EOSCoreWeb.EOSWebVoiceLibrary.ModifyParticipant
	void CreateRoomToken(struct FString AccessToken, struct TArray<struct FWebRequestParticipantData> Participants, struct FString DeploymentId, struct FString RoomName, struct FDelegate& Callback); // Function EOSCoreWeb.EOSWebVoiceLibrary.CreateRoomToken
}; 



// Class EOSCoreWeb.EOSWebShared
// Size: 0x28(Inherited: 0x28) 
struct UEOSWebShared : public UObject
{

	void GetPublicIp(struct FDelegate& Callback); // Function EOSCoreWeb.EOSWebShared.GetPublicIp
}; 



// Class EOSCoreWeb.EOSWebConnectLibrary
// Size: 0x28(Inherited: 0x28) 
struct UEOSWebConnectLibrary : public UObject
{

	void RequestAccessToken(struct FRequestAccessTokenRequest Request, struct FDelegate& Callback); // Function EOSCoreWeb.EOSWebConnectLibrary.RequestAccessToken
}; 



// Class EOSCoreWeb.EOSWebPlayerTicketLibrary
// Size: 0x28(Inherited: 0x28) 
struct UEOSWebPlayerTicketLibrary : public UObject
{

	void SubmitTicket(struct FString WebApiKey, struct FSubmitTicketRequest Request, struct FDelegate& Callback); // Function EOSCoreWeb.EOSWebPlayerTicketLibrary.SubmitTicket
}; 



