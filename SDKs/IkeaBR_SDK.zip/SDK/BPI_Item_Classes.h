#pragma once 
#include <BPI_Item_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_Item.BPI_Item_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_Item_C : public UInterface
{

	void LMB_Pure(bool Down); // Function BPI_Item.BPI_Item_C.LMB_Pure
	void LMB(bool Down); // Function BPI_Item.BPI_Item_C.LMB
	void Pickup(); // Function BPI_Item.BPI_Item_C.Pickup
	void Unequip(); // Function BPI_Item.BPI_Item_C.Unequip
	void Equip(); // Function BPI_Item.BPI_Item_C.Equip
}; 



