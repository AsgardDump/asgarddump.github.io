#pragma once 
#include <Cosmetics_Slot_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Cosmetics_Slot.Cosmetics_Slot_C
// Size: 0x2F0(Inherited: 0x260) 
struct UCosmetics_Slot_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct URR_Text_C* ItemName;  // 0x268(0x8)
	struct UImage* SelectedItem;  // 0x270(0x8)
	struct URR_Button_C* SlotButton;  // 0x278(0x8)
	struct URR_Text_C* SlotText;  // 0x280(0x8)
	struct UW_NewNotification_C* W_NewNotification;  // 0x288(0x8)
	char E_CosmeticSlot SelectedSlot;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct FST_Cosmetic SelectedSavedItem;  // 0x298(0x50)
	struct UMenu_CosmeticsMenu_C* MenuRef;  // 0x2E8(0x8)

	struct FText GetItemName(); // Function Cosmetics_Slot.Cosmetics_Slot_C.GetItemName
	struct FText SlotName(); // Function Cosmetics_Slot.Cosmetics_Slot_C.SlotName
	void Completed_215CB37D43646A0095BC73972F99A3A6(struct USaveGame* SaveGame, bool bSuccess); // Function Cosmetics_Slot.Cosmetics_Slot_C.Completed_215CB37D43646A0095BC73972F99A3A6
	void Completed_6F07F8864F50B817CAEDB3853D81CBEA(struct USaveGame* SaveGame, bool bSuccess); // Function Cosmetics_Slot.Cosmetics_Slot_C.Completed_6F07F8864F50B817CAEDB3853D81CBEA
	void OnFail_7ADC3D684F3D9BE49544449342590BAB(struct UTexture2D* OutTexture); // Function Cosmetics_Slot.Cosmetics_Slot_C.OnFail_7ADC3D684F3D9BE49544449342590BAB
	void OnSuccess_7ADC3D684F3D9BE49544449342590BAB(struct UTexture2D* OutTexture); // Function Cosmetics_Slot.Cosmetics_Slot_C.OnSuccess_7ADC3D684F3D9BE49544449342590BAB
	void BndEvt__SlotButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function Cosmetics_Slot.Cosmetics_Slot_C.BndEvt__SlotButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void Reload(); // Function Cosmetics_Slot.Cosmetics_Slot_C.Reload
	void Construct(); // Function Cosmetics_Slot.Cosmetics_Slot_C.Construct
	void UpdateNewVisibility(); // Function Cosmetics_Slot.Cosmetics_Slot_C.UpdateNewVisibility
	void ExecuteUbergraph_Cosmetics_Slot(int32_t EntryPoint); // Function Cosmetics_Slot.Cosmetics_Slot_C.ExecuteUbergraph_Cosmetics_Slot
}; 



