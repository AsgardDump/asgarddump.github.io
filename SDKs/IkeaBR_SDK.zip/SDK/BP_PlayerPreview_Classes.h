#pragma once 
#include <BP_PlayerPreview_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PlayerPreview.BP_PlayerPreview_C
// Size: 0x275(Inherited: 0x220) 
struct ABP_PlayerPreview_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x228(0x8)
	struct USceneComponent* Root;  // 0x230(0x8)
	float reset_time_F51C4ADE47315B5C77B529AB5DCF02FA;  // 0x238(0x4)
	char ETimelineDirection reset__Direction_F51C4ADE47315B5C77B529AB5DCF02FA;  // 0x23C(0x1)
	char pad_573[3];  // 0x23D(0x3)
	struct UTimelineComponent* Reset;  // 0x240(0x8)
	struct TArray<struct FString> Cosmetics;  // 0x248(0x10)
	struct TArray<struct USkeletalMeshComponent*> clothes;  // 0x258(0x10)
	struct FRotator initialRot;  // 0x268(0xC)
	char pad_628_1 : 7;  // 0x274(0x1)
	bool ShowPlane : 1;  // 0x274(0x1)

	void reset__FinishedFunc(); // Function BP_PlayerPreview.BP_PlayerPreview_C.reset__FinishedFunc
	void reset__UpdateFunc(); // Function BP_PlayerPreview.BP_PlayerPreview_C.reset__UpdateFunc
	void UpdateCosmetics(struct TArray<struct FST_Cosmetic>& Array); // Function BP_PlayerPreview.BP_PlayerPreview_C.UpdateCosmetics
	void PreviewCosmetics(); // Function BP_PlayerPreview.BP_PlayerPreview_C.PreviewCosmetics
	void ResetRot(); // Function BP_PlayerPreview.BP_PlayerPreview_C.ResetRot
	void ReceiveBeginPlay(); // Function BP_PlayerPreview.BP_PlayerPreview_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_PlayerPreview(int32_t EntryPoint); // Function BP_PlayerPreview.BP_PlayerPreview_C.ExecuteUbergraph_BP_PlayerPreview
}; 



