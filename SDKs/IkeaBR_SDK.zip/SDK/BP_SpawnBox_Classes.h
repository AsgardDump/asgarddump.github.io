#pragma once 
#include <BP_SpawnBox_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SpawnBox.BP_SpawnBox_C
// Size: 0x291(Inherited: 0x220) 
struct ABP_SpawnBox_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UReplicatedPhysics* ReplicatedPhysics;  // 0x228(0x8)
	struct UBoxComponent* test;  // 0x230(0x8)
	struct USceneComponent* PlayerSpot;  // 0x238(0x8)
	struct UStaticMeshComponent* Wall4;  // 0x240(0x8)
	struct UStaticMeshComponent* Wall3;  // 0x248(0x8)
	struct UStaticMeshComponent* Wall2;  // 0x250(0x8)
	struct UStaticMeshComponent* Wall1;  // 0x258(0x8)
	struct UStaticMeshComponent* Ceiling;  // 0x260(0x8)
	struct UStaticMeshComponent* Base;  // 0x268(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x270(0x8)
	float Curve_Alpha_EF6F2C6A41FF12A07DC5C5BCF58E3571;  // 0x278(0x4)
	char ETimelineDirection Curve__Direction_EF6F2C6A41FF12A07DC5C5BCF58E3571;  // 0x27C(0x1)
	char pad_637[3];  // 0x27D(0x3)
	struct UTimelineComponent* Curve;  // 0x280(0x8)
	struct AFirstPersonCharacter_C* Player;  // 0x288(0x8)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool Open? : 1;  // 0x290(0x1)

	void OnRep_Open?(); // Function BP_SpawnBox.BP_SpawnBox_C.OnRep_Open?
	void Curve__FinishedFunc(); // Function BP_SpawnBox.BP_SpawnBox_C.Curve__FinishedFunc
	void Curve__UpdateFunc(); // Function BP_SpawnBox.BP_SpawnBox_C.Curve__UpdateFunc
	void ReleasePlayer(); // Function BP_SpawnBox.BP_SpawnBox_C.ReleasePlayer
	void Release(); // Function BP_SpawnBox.BP_SpawnBox_C.Release
	void SpawnNormal(struct AFirstPersonCharacter_C* Player); // Function BP_SpawnBox.BP_SpawnBox_C.SpawnNormal
	void ReceiveTick(float DeltaSeconds); // Function BP_SpawnBox.BP_SpawnBox_C.ReceiveTick
	void PlacePlayer(struct AFirstPersonCharacter_C* Player); // Function BP_SpawnBox.BP_SpawnBox_C.PlacePlayer
	void ExecuteUbergraph_BP_SpawnBox(int32_t EntryPoint); // Function BP_SpawnBox.BP_SpawnBox_C.ExecuteUbergraph_BP_SpawnBox
}; 



