#pragma once 
#include <CheckForBanAction_Structs.h>
 
 
 
// BlueprintGeneratedClass CheckForBanAction.CheckForBanAction_C
// Size: 0x48(Inherited: 0x30) 
struct UCheckForBanAction_C : public URRObject
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)
	struct FMulticastInlineDelegate OnResult;  // 0x38(0x10)

	void OnCallback_53466DB84CBA8014C1B404A22803ADD6(struct FLeaderboardFindResult& Data, bool bWasSuccessful); // Function CheckForBanAction.CheckForBanAction_C.OnCallback_53466DB84CBA8014C1B404A22803ADD6
	void OnCallback_79FFEEA74A6DD8C0C1A499A17EF0F6EE(struct FLeaderboardScoresDownloadedForUsers& Data, bool bWasSuccessful); // Function CheckForBanAction.CheckForBanAction_C.OnCallback_79FFEEA74A6DD8C0C1A499A17EF0F6EE
	void CheckForBan(struct FSteamID SteamID); // Function CheckForBanAction.CheckForBanAction_C.CheckForBan
	void ExecuteUbergraph_CheckForBanAction(int32_t EntryPoint); // Function CheckForBanAction.CheckForBanAction_C.ExecuteUbergraph_CheckForBanAction
	void OnResult__DelegateSignature(bool success, bool IsBanned); // Function CheckForBanAction.CheckForBanAction_C.OnResult__DelegateSignature
}; 



