#pragma once 
#include <Bed_01_Structs.h>
 
 
 
// BlueprintGeneratedClass Bed_01.Bed_01_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct ABed_01_C : public AMovable_Object_Replicated_C
{

}; 



