#pragma once 
#include "SDK.h" 
 
 
// Function C_AntiCheat.C_AntiCheat_C.ExecuteUbergraph_C_AntiCheat
// Size: 0x1AA(Inherited: 0x0) 
struct FExecuteUbergraph_C_AntiCheat
{
	int32_t EntryPoint;  // 0x0(0x4)
	float Temp_float_Variable;  // 0x4(0x4)
	float CallFunc_Ping_In_S_ReturnValue;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xC(0x4)
	int32_t K2Node_CustomEvent_Slot;  // 0x10(0x4)
	int32_t K2Node_CustomEvent_ClientAmmo;  // 0x14(0x4)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x24(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x28(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x40(0x8)
	struct UDestroySessionCallbackProxy* CallFunc_DestroySession_ReturnValue;  // 0x48(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x68(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x7A(0x1)
	char pad_123[1];  // 0x7B(0x1)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x7C(0x4)
	int32_t CallFunc_Abs_Int_ReturnValue;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x88(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x98(0x4)
	float Temp_float_Variable_2;  // 0x9C(0x4)
	int32_t K2Node_CustomEvent_SlotForItemAmmo;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	int32_t Temp_int_Variable;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xAC(0x1)
	char pad_173_1 : 7;  // 0xAD(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_2 : 1;  // 0xAD(0x1)
	char pad_174_1 : 7;  // 0xAE(0x1)
	bool Temp_bool_Variable : 1;  // 0xAE(0x1)
	char pad_175[1];  // 0xAF(0x1)
	float CallFunc_Ping_In_S_ReturnValue_2;  // 0xB0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xB4(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0xB8(0x10)
	int32_t CallFunc_FCeil_ReturnValue_2;  // 0xC8(0x4)
	int32_t CallFunc_Clamp_ReturnValue_2;  // 0xCC(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_CustomEvent_Client_HasAntiCheatOn_ : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool K2Node_CustomEvent_Status : 1;  // 0xDA(0x1)
	char pad_219_1 : 7;  // 0xDB(0x1)
	bool CallFunc_EqualEqual_BoolBool_ReturnValue : 1;  // 0xDB(0x1)
	char pad_220[4];  // 0xDC(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0xE0(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc_2;  // 0xF8(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x110(0x1)
	char pad_273[3];  // 0x111(0x3)
	struct FST_Stats CallFunc_GetStats_stats;  // 0x114(0x24)
	struct FST_Stats K2Node_MakeStruct_ST_Stats;  // 0x138(0x24)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x15C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x160(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x164(0x10)
	char pad_372_1 : 7;  // 0x174(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x174(0x1)
	char pad_373[3];  // 0x175(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x178(0x4)
	char pad_380[4];  // 0x17C(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc_3;  // 0x180(0x8)
	float K2Node_Select_Default;  // 0x188(0x4)
	int32_t CallFunc_StatsToXP_XP;  // 0x18C(0x4)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_3 : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x1A0(0x1)
	char pad_417[3];  // 0x1A1(0x3)
	float CallFunc_GetFOVAngle_ReturnValue;  // 0x1A4(0x4)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1A9(0x1)

}; 
// Function C_AntiCheat.C_AntiCheat_C.ServerValidateShot
// Size: 0x8(Inherited: 0x0) 
struct FServerValidateShot
{
	int32_t Slot;  // 0x0(0x4)
	int32_t ClientAmmo;  // 0x4(0x4)

}; 
// Function C_AntiCheat.C_AntiCheat_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function C_AntiCheat.C_AntiCheat_C.ClientValidateShot
// Size: 0x4(Inherited: 0x0) 
struct FClientValidateShot
{
	int32_t SlotForItemAmmo;  // 0x0(0x4)

}; 
// Function C_AntiCheat.C_AntiCheat_C.ServerSetHasAntiCheatOn
// Size: 0x1(Inherited: 0x0) 
struct FServerSetHasAntiCheatOn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Client_HasAntiCheatOn? : 1;  // 0x0(0x1)

}; 
// Function C_AntiCheat.C_AntiCheat_C.ServerVerifyAntiCheatStatus
// Size: 0x1(Inherited: 0x0) 
struct FServerVerifyAntiCheatStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Status : 1;  // 0x0(0x1)

}; 
