#pragma once 
#include "SDK.h" 
 
 
// Function BP_StimBase.BP_StimBase_C.LMB
// Size: 0x1(Inherited: 0x1) 
struct FLMB : public FLMB
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
// Function BP_StimBase.BP_StimBase_C.ExecuteUbergraph_BP_StimBase
// Size: 0x79(Inherited: 0x0) 
struct FExecuteUbergraph_BP_StimBase
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_Event_Down : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_Delay_Ping_delay_ping;  // 0x14(0x4)
	float CallFunc_Delay_Ping_delay_ping_2;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FST_Effect CallFunc_EffectFromName_Effect;  // 0x20(0x38)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x58(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x78(0x1)

}; 
