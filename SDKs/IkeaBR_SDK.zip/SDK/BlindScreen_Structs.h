#pragma once 
#include "SDK.h" 
 
 
// Function BlindScreen.BlindScreen_C.GetColorAndOpacity_1
// Size: 0x10(Inherited: 0x0) 
struct FGetColorAndOpacity_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)

}; 
// Function BlindScreen.BlindScreen_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function BlindScreen.BlindScreen_C.ExecuteUbergraph_BlindScreen
// Size: 0x54(Inherited: 0x0) 
struct FExecuteUbergraph_BlindScreen
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x4(0x38)
	float K2Node_Event_InDeltaTime;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Temp_bool_Variable : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float Temp_float_Variable;  // 0x44(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float K2Node_Select_Default;  // 0x50(0x4)

}; 
