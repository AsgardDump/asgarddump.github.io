#pragma once 
#include "SDK.h" 
 
 
// Function GameOverScreen.GameOverScreen_C.ExecuteUbergraph_GameOverScreen
// Size: 0x2A1(Inherited: 0x0) 
struct FExecuteUbergraph_GameOverScreen
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUserStats* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x8(0x8)
	struct FString Temp_string_Variable;  // 0x10(0x10)
	int32_t CallFunc_GetStatInt_Data;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_GetStatInt_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FString Temp_string_Variable_2;  // 0x28(0x10)
	struct FString Temp_string_Variable_3;  // 0x38(0x10)
	struct FString Temp_string_Variable_4;  // 0x48(0x10)
	struct FString Temp_string_Variable_5;  // 0x58(0x10)
	struct FString Temp_string_Variable_6;  // 0x68(0x10)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x78(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x90(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_2;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	int32_t CallFunc_GetStatInt_Data_2;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_GetStatInt_ReturnValue_2 : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xA9(0x1)
	char pad_170[2];  // 0xAA(0x2)
	int32_t CallFunc_StatsToXP_XP;  // 0xAC(0x4)
	int32_t CallFunc_Player_AddXP_LevelIncrease;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_3;  // 0xB8(0x8)
	struct UDestroySessionCallbackProxy* CallFunc_DestroySession_ReturnValue;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC9(0x1)
	char pad_202[2];  // 0xCA(0x2)
	int32_t Temp_int_Variable;  // 0xCC(0x4)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xD4(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xD8(0x10)
	struct FST_SteamItem CallFunc_ItemDefIDtoItem_out;  // 0xE8(0x38)
	struct FST_SteamItem CallFunc_ItemDefIDtoItem_out_2;  // 0x120(0x38)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_4;  // 0x158(0x8)
	struct USteamItem_Unscaled_C* CallFunc_Create_ReturnValue;  // 0x160(0x8)
	struct USteamItem_Unscaled_C* CallFunc_Create_ReturnValue_2;  // 0x168(0x8)
	struct UPanelSlot* CallFunc_InsertChildAt_ReturnValue;  // 0x170(0x8)
	struct UPanelSlot* CallFunc_InsertChildAt_ReturnValue_2;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_CustomEvent_XP_animation_ : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x188(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x190(0x8)
	int32_t CallFunc_StatsToXP_XP_2;  // 0x198(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x19C(0x4)
	struct FString CallFunc_SecondsToClock_Minutes;  // 0x1A0(0x10)
	struct FString CallFunc_SecondsToClock_Sec;  // 0x1B0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x1C0(0x10)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x1D0(0x4)
	char pad_468[4];  // 0x1D4(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x1D8(0x10)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x1E8(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x200(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x210(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue;  // 0x220(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x230(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x234(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x238(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x248(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x258(0x10)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x268(0x1)
	char pad_617[7];  // 0x269(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue_4;  // 0x270(0x10)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x280(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x288(0x8)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x2A0(0x1)

}; 
// Function GameOverScreen.GameOverScreen_C.PlayAnimations
// Size: 0x1(Inherited: 0x0) 
struct FPlayAnimations
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool XP animation? : 1;  // 0x0(0x1)

}; 
// Function GameOverScreen.GameOverScreen_C.Get_Rank_3_Text_1
// Size: 0x70(Inherited: 0x0) 
struct FGet_Rank_3_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_SecondsToClock_Minutes;  // 0x18(0x10)
	struct FString CallFunc_SecondsToClock_Sec;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x58(0x18)

}; 
// Function GameOverScreen.GameOverScreen_C.Get_Rank_7_Text_1
// Size: 0x38(Inherited: 0x0) 
struct FGet_Rank_7_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x20(0x18)

}; 
// Function GameOverScreen.GameOverScreen_C.GetbIsEnabled_1
// Size: 0x22(Inherited: 0x0) 
struct FGetbIsEnabled_1
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x8(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1E(0x1)
	char pad_31_1 : 7;  // 0x1F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1F(0x1)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x21(0x1)

}; 
// Function GameOverScreen.GameOverScreen_C.GetText_1
// Size: 0x70(Inherited: 0x0) 
struct FGetText_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText Temp_text_Variable;  // 0x20(0x18)
	struct FText Temp_text_Variable_2;  // 0x38(0x18)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)
	struct FText K2Node_Select_Default;  // 0x58(0x18)

}; 
// Function GameOverScreen.GameOverScreen_C.GetText_2
// Size: 0x68(Inherited: 0x0) 
struct FGetText_2
{
	struct FText ReturnValue;  // 0x0(0x18)
	int32_t CallFunc_StatsToXP_XP;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue;  // 0x30(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue_2;  // 0x40(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x50(0x18)

}; 
// Function GameOverScreen.GameOverScreen_C.GetbIsEnabled_2
// Size: 0x3(Inherited: 0x0) 
struct FGetbIsEnabled_2
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function GameOverScreen.GameOverScreen_C.GetMaterialsXP
// Size: 0x38(Inherited: 0x0) 
struct FGetMaterialsXP
{
	struct FText ReturnValue;  // 0x0(0x18)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x1C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x20(0x18)

}; 
// Function GameOverScreen.GameOverScreen_C.VignetteColor
// Size: 0x48(Inherited: 0x0) 
struct FVignetteColor
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x35(0x1)
	char pad_54[2];  // 0x36(0x2)
	struct FLinearColor K2Node_Select_Default;  // 0x38(0x10)

}; 
// Function GameOverScreen.GameOverScreen_C.Get_KilledBy_Text_1
// Size: 0xC8(Inherited: 0x0) 
struct FGet_KilledBy_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString Temp_string_Variable;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x40(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Variable : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x68(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x78(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)
	struct FString K2Node_Select_Default;  // 0xA0(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xB0(0x18)

}; 
// Function GameOverScreen.GameOverScreen_C.RankText
// Size: 0x50(Inherited: 0x0) 
struct FRankText
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue;  // 0x28(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x38(0x18)

}; 
// Function GameOverScreen.GameOverScreen_C.ChampionTextVisibility
// Size: 0x6(Inherited: 0x0) 
struct FChampionTextVisibility
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x4(0x1)
	uint8_t  K2Node_Select_Default;  // 0x5(0x1)

}; 
// Function GameOverScreen.GameOverScreen_C.GetVisibility_1
// Size: 0x1A(Inherited: 0x0) 
struct FGetVisibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x8(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	uint8_t  K2Node_Select_Default;  // 0x19(0x1)

}; 
// Function GameOverScreen.GameOverScreen_C.GetVisibility_2
// Size: 0x13(Inherited: 0x0) 
struct FGetVisibility_2
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x11(0x1)
	uint8_t  K2Node_Select_Default;  // 0x12(0x1)

}; 
