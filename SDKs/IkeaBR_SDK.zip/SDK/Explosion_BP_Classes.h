#pragma once 
#include <Explosion_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Explosion_BP.Explosion_BP_C
// Size: 0x244(Inherited: 0x220) 
struct AExplosion_BP_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	float Intensity;  // 0x230(0x4)
	char pad_564[4];  // 0x234(0x4)
	struct AFirstPersonCharacter_C* Causer;  // 0x238(0x8)
	float Radius;  // 0x240(0x4)

	void ReceiveBeginPlay(); // Function Explosion_BP.Explosion_BP_C.ReceiveBeginPlay
	void MultiExplode(); // Function Explosion_BP.Explosion_BP_C.MultiExplode
	void ExecuteUbergraph_Explosion_BP(int32_t EntryPoint); // Function Explosion_BP.Explosion_BP_C.ExecuteUbergraph_Explosion_BP
}; 



