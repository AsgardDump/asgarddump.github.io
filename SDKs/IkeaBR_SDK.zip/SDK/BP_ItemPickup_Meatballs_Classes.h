#pragma once 
#include <BP_ItemPickup_Meatballs_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ItemPickup_Meatballs.BP_ItemPickup_Meatballs_C
// Size: 0x2E0(Inherited: 0x2D3) 
struct ABP_ItemPickup_Meatballs_C : public ABP_ItemPickup_C
{
	char pad_723[5];  // 0x2D3(0x5)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2D8(0x8)

	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function BP_ItemPickup_Meatballs.BP_ItemPickup_Meatballs_C.OnInteract
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function BP_ItemPickup_Meatballs.BP_ItemPickup_Meatballs_C.OnStopLook
	void ExecuteUbergraph_BP_ItemPickup_Meatballs(int32_t EntryPoint); // Function BP_ItemPickup_Meatballs.BP_ItemPickup_Meatballs_C.ExecuteUbergraph_BP_ItemPickup_Meatballs
}; 



