#pragma once 
#include "SDK.h" 
 
 
// Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.ExecuteUbergraph_Cosmetics_Item_Tooltip
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Cosmetics_Item_Tooltip
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.Get_CosmeticName_Text_1
// Size: 0x30(Inherited: 0x0) 
struct FGet_CosmeticName_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x18(0x18)

}; 
// Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.Get_CosmeticName_ColorAndOpacity_1
// Size: 0x68(Inherited: 0x0) 
struct FGet_CosmeticName_ColorAndOpacity_1
{
	struct FSlateColor ReturnValue;  // 0x0(0x28)
	char E_Tier CallFunc_GetSteamTier_Tier;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor CallFunc_TierColor_color;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x40(0x28)

}; 
// Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.Get_ScrapText_Text_1
// Size: 0x58(Inherited: 0x0) 
struct FGet_ScrapText_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	char E_Tier CallFunc_GetSteamTier_Tier;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_CosmeticTierToScrapAmount_ScrapAmount;  // 0x1C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x30(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x40(0x18)

}; 
