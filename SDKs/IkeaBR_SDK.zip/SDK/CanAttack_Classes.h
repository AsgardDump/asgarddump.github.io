#pragma once 
#include <CanAttack_Structs.h>
 
 
 
// BlueprintGeneratedClass CanAttack.CanAttack_C
// Size: 0xA0(Inherited: 0xA0) 
struct UCanAttack_C : public UBTDecorator_BlueprintBase
{

	bool PerformConditionCheckAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function CanAttack.CanAttack_C.PerformConditionCheckAI
}; 



