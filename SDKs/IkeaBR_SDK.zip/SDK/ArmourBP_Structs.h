#pragma once 
#include "SDK.h" 
 
 
// Function ArmourBP.ArmourBP_C.ExecuteUbergraph_ArmourBP
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_ArmourBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_Down : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString CallFunc_ReplaceInputsInText_OutText;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_CanDoStuff__ : 1;  // 0x18(0x1)

}; 
// Function ArmourBP.ArmourBP_C.LMB_Pure
// Size: 0x1(Inherited: 0x1) 
struct FLMB_Pure : public FLMB_Pure
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
