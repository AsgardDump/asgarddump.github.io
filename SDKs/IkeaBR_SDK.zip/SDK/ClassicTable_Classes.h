#pragma once 
#include <ClassicTable_Structs.h>
 
 
 
// BlueprintGeneratedClass ClassicTable.ClassicTable_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AClassicTable_C : public AMovable_Object_Replicated_C
{

}; 



