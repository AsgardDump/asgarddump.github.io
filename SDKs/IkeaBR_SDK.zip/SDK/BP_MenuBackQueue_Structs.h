#pragma once 
#include "SDK.h" 
 
 
// Function BP_MenuBackQueue.BP_MenuBackQueue_C.ExecuteUbergraph_BP_MenuBackQueue
// Size: 0x38(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MenuBackQueue
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UUserWidget* K2Node_CustomEvent_Widget;  // 0x20(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x28(0x4)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x2C(0x4)
	struct UUserWidget* CallFunc_Array_Get_Item;  // 0x30(0x8)

}; 
// Function BP_MenuBackQueue.BP_MenuBackQueue_C.Register
// Size: 0x8(Inherited: 0x0) 
struct FRegister
{
	struct UUserWidget* Widget;  // 0x0(0x8)

}; 
