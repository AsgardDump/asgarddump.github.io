#pragma once 
#include "SDK.h" 
 
 
// Function EasyVoiceChat.VoipManagerComponent.InitVoice
// Size: 0x20(Inherited: 0x0) 
struct FInitVoice
{
	struct AController* Controller;  // 0x0(0x8)
	struct FString DeviceName;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EasyVoiceChat.VoipAudioComponent.PlayVoiceData
// Size: 0x10(Inherited: 0x0) 
struct FPlayVoiceData
{
	struct TArray<char> CompressedVoiceData;  // 0x0(0x10)

}; 
// DelegateFunction EasyVoiceChat.VoiceGenerated__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FVoiceGenerated__DelegateSignature
{
	struct TArray<char> VoiceData;  // 0x0(0x10)
	float MicLevel;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function EasyVoiceChat.VoiceFunctionLibrary.GetAllPawnsFromState
// Size: 0x28(Inherited: 0x0) 
struct FGetAllPawnsFromState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct APawn* CurrentPlayer;  // 0x8(0x8)
	float Distance;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct APawn*> ReturnValue;  // 0x18(0x10)

}; 
// Function EasyVoiceChat.VoipManagerComponent.OnVoiceGeneratedBP
// Size: 0x18(Inherited: 0x0) 
struct FOnVoiceGeneratedBP
{
	struct TArray<char> VoiceBuffer;  // 0x0(0x10)
	float MicLevel;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
