#pragma once 
#include <BP_MeatballLauncher_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MeatballLauncher.BP_MeatballLauncher_C
// Size: 0x2B8(Inherited: 0x2A0) 
struct ABP_MeatballLauncher_C : public ABP_Throwable_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A0(0x8)
	struct USceneComponent* Shoot Location;  // 0x2A8(0x8)
	struct UAnimSequenceBase* ShootAnim;  // 0x2B0(0x8)

	void LMB(bool Down); // Function BP_MeatballLauncher.BP_MeatballLauncher_C.LMB
	void Equip(); // Function BP_MeatballLauncher.BP_MeatballLauncher_C.Equip
	void Unequip(); // Function BP_MeatballLauncher.BP_MeatballLauncher_C.Unequip
	void ExecuteUbergraph_BP_MeatballLauncher(int32_t EntryPoint); // Function BP_MeatballLauncher.BP_MeatballLauncher_C.ExecuteUbergraph_BP_MeatballLauncher
}; 



