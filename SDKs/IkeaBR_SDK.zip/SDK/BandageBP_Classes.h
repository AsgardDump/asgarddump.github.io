#pragma once 
#include <BandageBP_Structs.h>
 
 
 
// BlueprintGeneratedClass BandageBP.BandageBP_C
// Size: 0x2A8(Inherited: 0x2A8) 
struct ABandageBP_C : public AHealingItemBP_C
{

}; 



