#pragma once 
#include <BP_PencilGun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PencilGun.BP_PencilGun_C
// Size: 0x351(Inherited: 0x2A0) 
struct ABP_PencilGun_C : public ABP_Throwable_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A0(0x8)
	struct UStaticMeshComponent* PencilBunch;  // 0x2A8(0x8)
	struct USkeletalMeshComponent* PencilGunMesh;  // 0x2B0(0x8)
	struct USceneComponent* Shoot Location;  // 0x2B8(0x8)
	struct UAnimSequenceBase* ShootAnim;  // 0x2C0(0x8)
	struct TArray<float> TryShootDelays;  // 0x2C8(0x10)
	char pad_728_1 : 7;  // 0x2D8(0x1)
	bool IsTryingToShoot : 1;  // 0x2D8(0x1)
	char pad_729[3];  // 0x2D9(0x3)
	int32_t CurrentShootDelayIndex;  // 0x2DC(0x4)
	float ShootChance;  // 0x2E0(0x4)
	float TryShootPlayRate;  // 0x2E4(0x4)
	int32_t NeededPencils;  // 0x2E8(0x4)
	char pad_748[4];  // 0x2EC(0x4)
	struct TMap<int32_t, int32_t> InventoryPencilsAndAmmo;  // 0x2F0(0x50)
	int32_t CurrentGatheredPencils;  // 0x340(0x4)
	float TimeToReload;  // 0x344(0x4)
	struct UStaticMeshComponent* PencilBunchComponent;  // 0x348(0x8)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool IsReloading : 1;  // 0x350(0x1)

	void HasEnoughPencilsInInventory(bool& HasEnough); // Function BP_PencilGun.BP_PencilGun_C.HasEnoughPencilsInInventory
	void IsGunLoadedFunc(bool& Loaded); // Function BP_PencilGun.BP_PencilGun_C.IsGunLoadedFunc
	void LMB(bool Down); // Function BP_PencilGun.BP_PencilGun_C.LMB
	void Equip(); // Function BP_PencilGun.BP_PencilGun_C.Equip
	void Unequip(); // Function BP_PencilGun.BP_PencilGun_C.Unequip
	void StopTryingToShoot(); // Function BP_PencilGun.BP_PencilGun_C.StopTryingToShoot
	void Shoot(); // Function BP_PencilGun.BP_PencilGun_C.Shoot
	void TryShootEffects(); // Function BP_PencilGun.BP_PencilGun_C.TryShootEffects
	void ShootEffects(); // Function BP_PencilGun.BP_PencilGun_C.ShootEffects
	void Reload(bool Down); // Function BP_PencilGun.BP_PencilGun_C.Reload
	void ReceiveTick(float DeltaSeconds); // Function BP_PencilGun.BP_PencilGun_C.ReceiveTick
	void ExecuteUbergraph_BP_PencilGun(int32_t EntryPoint); // Function BP_PencilGun.BP_PencilGun_C.ExecuteUbergraph_BP_PencilGun
}; 



