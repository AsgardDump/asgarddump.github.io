#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Cripple.BP_Effect_Cripple_C.ExecuteUbergraph_BP_Effect_Cripple
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Cripple
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent_2;  // 0x10(0x8)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent_3;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsPendingKill_ReturnValue : 1;  // 0x20(0x1)

}; 
