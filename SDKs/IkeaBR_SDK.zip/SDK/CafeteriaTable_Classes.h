#pragma once 
#include <CafeteriaTable_Structs.h>
 
 
 
// BlueprintGeneratedClass CafeteriaTable.CafeteriaTable_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct ACafeteriaTable_C : public AMovable_Object_Replicated_C
{

}; 



