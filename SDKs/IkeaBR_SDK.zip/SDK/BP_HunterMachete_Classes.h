#pragma once 
#include <BP_HunterMachete_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_HunterMachete.BP_HunterMachete_C
// Size: 0x290(Inherited: 0x290) 
struct ABP_HunterMachete_C : public AWeaponBP_C
{

}; 



