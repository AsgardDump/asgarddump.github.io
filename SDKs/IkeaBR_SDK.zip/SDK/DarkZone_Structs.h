#pragma once 
#include "SDK.h" 
 
 
// Function DarkZone.DarkZone_C.ExecuteUbergraph_DarkZone
// Size: 0x738(Inherited: 0x0) 
struct FExecuteUbergraph_DarkZone
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	float K2Node_CustomEvent_Size_3;  // 0x10(0x4)
	float K2Node_CustomEvent_Time_3;  // 0x14(0x4)
	float K2Node_CustomEvent_CurrectSize_2;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x28(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x38(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x3C(0x4)
	struct AActor* K2Node_CustomEvent_Player_3;  // 0x40(0x8)
	char pad_72[8];  // 0x48(0x8)
	struct FPostProcessSettings K2Node_CustomEvent_PostProcessSettings;  // 0x50(0x560)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x5B0(0x8)
	char pad_1464_1 : 7;  // 0x5B8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x5B8(0x1)
	char pad_1465[3];  // 0x5B9(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x5BC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x5C0(0x4)
	float CallFunc_BreakVector_X;  // 0x5C4(0x4)
	float CallFunc_BreakVector_Y;  // 0x5C8(0x4)
	float CallFunc_BreakVector_Z;  // 0x5CC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x5D0(0x4)
	float K2Node_CustomEvent_Time_2;  // 0x5D4(0x4)
	float K2Node_CustomEvent_Size_2;  // 0x5D8(0x4)
	char pad_1500[4];  // 0x5DC(0x4)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item;  // 0x5E0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x5E8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x5F4(0xC)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x600(0x4)
	float CallFunc_GetPlayerOuterReverseDepth_NormalizedDistance;  // 0x604(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x608(0x4)
	float CallFunc_Lerp_ReturnValue_2;  // 0x60C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x610(0x10)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x620(0x4)
	char pad_1572[4];  // 0x624(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x628(0x8)
	char pad_1584_1 : 7;  // 0x630(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x630(0x1)
	char pad_1585[3];  // 0x631(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x634(0x4)
	char pad_1592_1 : 7;  // 0x638(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x638(0x1)
	char pad_1593[3];  // 0x639(0x3)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x63C(0xC)
	float K2Node_CustomEvent_Size;  // 0x648(0x4)
	float K2Node_CustomEvent_Time;  // 0x64C(0x4)
	float K2Node_CustomEvent_CurrectSize;  // 0x650(0x4)
	float CallFunc_BreakVector_X_2;  // 0x654(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x658(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x65C(0x4)
	char pad_1632_1 : 7;  // 0x660(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x660(0x1)
	char pad_1633[7];  // 0x661(0x7)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllOverlappingPlayers_Players;  // 0x668(0x10)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Player_2;  // 0x678(0x8)
	struct AActor* CallFunc_Array_Get_Item_2;  // 0x680(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x688(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x68C(0xC)
	char pad_1688_1 : 7;  // 0x698(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x698(0x1)
	char pad_1689[3];  // 0x699(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x69C(0xC)
	float CallFunc_GetPlayerOverlapDepth_NormalizedDepth;  // 0x6A8(0x4)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x6AC(0x4)
	float CallFunc_Lerp_ReturnValue_3;  // 0x6B0(0x4)
	char pad_1716_1 : 7;  // 0x6B4(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x6B4(0x1)
	char pad_1717[3];  // 0x6B5(0x3)
	float CallFunc_Lerp_ReturnValue_4;  // 0x6B8(0x4)
	char pad_1724_1 : 7;  // 0x6BC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x6BC(0x1)
	char pad_1725_1 : 7;  // 0x6BD(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x6BD(0x1)
	char pad_1726[2];  // 0x6BE(0x2)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Player;  // 0x6C0(0x8)
	char pad_1736_1 : 7;  // 0x6C8(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x6C8(0x1)
	char pad_1737[7];  // 0x6C9(0x7)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllOverlappingPlayers_Players_2;  // 0x6D0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x6E0(0x4)
	char pad_1764_1 : 7;  // 0x6E4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x6E4(0x1)
	char pad_1765[3];  // 0x6E5(0x3)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x6E8(0x8)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x6F0(0x4)
	char pad_1780[4];  // 0x6F4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item_3;  // 0x6F8(0x8)
	float CallFunc_Lerp_ReturnValue_5;  // 0x700(0x4)
	float CallFunc_ApplyDamage_ReturnValue_2;  // 0x704(0x4)
	float CallFunc_Lerp_ReturnValue_6;  // 0x708(0x4)
	float CallFunc_ApplyDamage_ReturnValue_3;  // 0x70C(0x4)
	struct FVector K2Node_CustomEvent_Location;  // 0x710(0xC)
	float K2Node_CustomEvent_PitchMultiplier;  // 0x71C(0x4)
	float K2Node_CustomEvent_VolumeMultiplier;  // 0x720(0x4)
	float CallFunc_Lerp_ReturnValue_7;  // 0x724(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x728(0xC)
	float CallFunc_ApplyDamage_ReturnValue_4;  // 0x734(0x4)

}; 
// Function DarkZone.DarkZone_C.MultiDamageSound
// Size: 0x14(Inherited: 0x0) 
struct FMultiDamageSound
{
	struct FVector Location;  // 0x0(0xC)
	float PitchMultiplier;  // 0xC(0x4)
	float VolumeMultiplier;  // 0x10(0x4)

}; 
// Function DarkZone.DarkZone_C.GetPostProcessSettingsForPlayerDepth
// Size: 0xAF0(Inherited: 0x0) 
struct FGetPostProcessSettingsForPlayerDepth
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct FPostProcessSettings Out;  // 0x10(0x560)
	struct FPostProcessSettings Copy;  // 0x570(0x560)
	float CallFunc_GetPlayerOuterReverseDepth_NormalizedDistance;  // 0xAD0(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0xAD4(0x4)
	char pad_2776[8];  // 0xAD8(0x8)
	struct FVector4 CallFunc_MakeVector4_ReturnValue;  // 0xAE0(0x10)

}; 
// Function DarkZone.DarkZone_C.OnBeginOverlap
// Size: 0x8(Inherited: 0x0) 
struct FOnBeginOverlap
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function DarkZone.DarkZone_C.OnEndOverlap
// Size: 0x8(Inherited: 0x0) 
struct FOnEndOverlap
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function DarkZone.DarkZone_C.Multi_Grow
// Size: 0xC(Inherited: 0x0) 
struct FMulti_Grow
{
	float Size;  // 0x0(0x4)
	float Time;  // 0x4(0x4)
	float CurrectSize;  // 0x8(0x4)

}; 
// Function DarkZone.DarkZone_C.ServerGrow
// Size: 0x8(Inherited: 0x0) 
struct FServerGrow
{
	float Time;  // 0x0(0x4)
	float Size;  // 0x4(0x4)

}; 
// Function DarkZone.DarkZone_C.ClientPostProccess
// Size: 0x570(Inherited: 0x0) 
struct FClientPostProccess
{
	struct AActor* Player;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FPostProcessSettings PostProcessSettings;  // 0x10(0x560)

}; 
// Function DarkZone.DarkZone_C.ClientGrow
// Size: 0xC(Inherited: 0x0) 
struct FClientGrow
{
	float Size;  // 0x0(0x4)
	float Time;  // 0x4(0x4)
	float CurrectSize;  // 0x8(0x4)

}; 
// Function DarkZone.DarkZone_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function DarkZone.DarkZone_C.OverlapVsPlayerCheck
// Size: 0x69(Inherited: 0x0) 
struct FOverlapVsPlayerCheck
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Overlapping : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xC(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x18(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x24(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_2;  // 0x30(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x3C(0x4)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x40(0xC)
	float CallFunc_BreakVector_X;  // 0x4C(0x4)
	float CallFunc_BreakVector_Y;  // 0x50(0x4)
	float CallFunc_BreakVector_Z;  // 0x54(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x58(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x5C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x60(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x68(0x1)

}; 
// Function DarkZone.DarkZone_C.GetAllOverlappingPlayers
// Size: 0x59(Inherited: 0x0) 
struct FGetAllOverlappingPlayers
{
	struct TArray<struct AFirstPersonCharacter_C*> Players;  // 0x0(0x10)
	struct TArray<struct AFirstPersonCharacter_C*> OverlappingPlayers;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_OverlapVsPlayerCheck_Overlapping : 1;  // 0x58(0x1)

}; 
// Function DarkZone.DarkZone_C.TickOverlapCheck
// Size: 0x61(Inherited: 0x0) 
struct FTickOverlapCheck
{
	struct TArray<struct AFirstPersonCharacter_C*> CurrentOverlap;  // 0x0(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x18(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x36(0x1)
	char pad_55[1];  // 0x37(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllOverlappingPlayers_Players;  // 0x40(0x10)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x59(0x1)
	char pad_90[2];  // 0x5A(0x2)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x60(0x1)

}; 
// Function DarkZone.DarkZone_C.GetPlayerOverlapDepth
// Size: 0x6C(Inherited: 0x0) 
struct FGetPlayerOverlapDepth
{
	struct FVector PlayerLoc;  // 0x0(0xC)
	float NormalizedDepth;  // 0xC(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x10(0xC)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x1C(0xC)
	float CallFunc_BreakVector_X;  // 0x28(0x4)
	float CallFunc_BreakVector_Y;  // 0x2C(0x4)
	float CallFunc_BreakVector_Z;  // 0x30(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x34(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x40(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_2;  // 0x44(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x50(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x54(0x4)
	float CallFunc_FMin_ReturnValue;  // 0x58(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x5C(0x4)
	float CallFunc_MultiplyMultiply_FloatFloat_ReturnValue;  // 0x60(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x64(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x68(0x4)

}; 
// Function DarkZone.DarkZone_C.GetPlayerOuterReverseDepth
// Size: 0x68(Inherited: 0x0) 
struct FGetPlayerOuterReverseDepth
{
	struct FVector Location;  // 0x0(0xC)
	float NormalizedDistance;  // 0xC(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x10(0xC)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x1C(0xC)
	float CallFunc_BreakVector_X;  // 0x28(0x4)
	float CallFunc_BreakVector_Y;  // 0x2C(0x4)
	float CallFunc_BreakVector_Z;  // 0x30(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x34(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x40(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_2;  // 0x44(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x50(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x54(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x58(0x4)
	float CallFunc_MultiplyMultiply_FloatFloat_ReturnValue;  // 0x5C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x60(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x64(0x4)

}; 
