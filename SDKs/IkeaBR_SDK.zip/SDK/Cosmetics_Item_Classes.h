#pragma once 
#include <Cosmetics_Item_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Cosmetics_Item.Cosmetics_Item_C
// Size: 0x348(Inherited: 0x260) 
struct UCosmetics_Item_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct URR_Text_C* AmountText;  // 0x268(0x8)
	struct URR_Button_C* Button;  // 0x270(0x8)
	struct UImage* Icon;  // 0x278(0x8)
	struct UThrobber* loading;  // 0x280(0x8)
	struct URR_ProgressBar_Plain_C* ScrapProgressBar;  // 0x288(0x8)
	struct UW_NewNotification_C* W_NewNotification;  // 0x290(0x8)
	struct UWidgetSwitcher* WidgetSwitcher_3;  // 0x298(0x8)
	struct UMenu_CosmeticsMenu_C* MenuRef;  // 0x2A0(0x8)
	struct FST_Cosmetic Item;  // 0x2A8(0x50)
	struct UCosmetics_Slot_C* ParentSlot;  // 0x2F8(0x8)
	int32_t Amount;  // 0x300(0x4)
	char pad_772[4];  // 0x304(0x4)
	struct TArray<struct FST_UndiscoveredItem> Temp;  // 0x308(0x10)
	struct USlotSave_C* Save;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool Hovering : 1;  // 0x320(0x1)
	char pad_801_1 : 7;  // 0x321(0x1)
	bool WasFDown : 1;  // 0x321(0x1)
	char pad_802[6];  // 0x322(0x6)
	struct UCosmetics_Item_Tooltip_C* CosmeticsToolTip;  // 0x328(0x8)
	struct UToolTip_Parent_C* ToolTipParent;  // 0x330(0x8)
	float ScrapProgress;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct UAudioComponent* ScrapCosmeticSound;  // 0x340(0x8)

	struct FText GetAmountText(); // Function Cosmetics_Item.Cosmetics_Item_C.GetAmountText
	struct FText GetName(); // Function Cosmetics_Item.Cosmetics_Item_C.GetName
	void Completed_6F07F8864F50B817CAEDB385FC3A0787(struct USaveGame* SaveGame, bool bSuccess); // Function Cosmetics_Item.Cosmetics_Item_C.Completed_6F07F8864F50B817CAEDB385FC3A0787
	void Completed_215CB37D43646A0095BC7397EE226FCB(struct USaveGame* SaveGame, bool bSuccess); // Function Cosmetics_Item.Cosmetics_Item_C.Completed_215CB37D43646A0095BC7397EE226FCB
	void Completed_0914B3504C491F3C20AD1796290733E2(struct USaveGame* SaveGame, bool bSuccess); // Function Cosmetics_Item.Cosmetics_Item_C.Completed_0914B3504C491F3C20AD1796290733E2
	void Completed_6F07F8864F50B817CAEDB38548FDDF0D(struct USaveGame* SaveGame, bool bSuccess); // Function Cosmetics_Item.Cosmetics_Item_C.Completed_6F07F8864F50B817CAEDB38548FDDF0D
	void OnFail_7ADC3D684F3D9BE495444493EA95A75F(struct UTexture2D* OutTexture); // Function Cosmetics_Item.Cosmetics_Item_C.OnFail_7ADC3D684F3D9BE495444493EA95A75F
	void OnSuccess_7ADC3D684F3D9BE495444493EA95A75F(struct UTexture2D* OutTexture); // Function Cosmetics_Item.Cosmetics_Item_C.OnSuccess_7ADC3D684F3D9BE495444493EA95A75F
	void Completed_215CB37D43646A0095BC73975AE5B741(struct USaveGame* SaveGame, bool bSuccess); // Function Cosmetics_Item.Cosmetics_Item_C.Completed_215CB37D43646A0095BC73975AE5B741
	void Construct(); // Function Cosmetics_Item.Cosmetics_Item_C.Construct
	void BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function Cosmetics_Item.Cosmetics_Item_C.BndEvt__Button_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__Cosmetics_Item_Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function Cosmetics_Item.Cosmetics_Item_C.BndEvt__Cosmetics_Item_Button_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function Cosmetics_Item.Cosmetics_Item_C.Tick
	void BndEvt__Cosmetics_Item_Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature(); // Function Cosmetics_Item.Cosmetics_Item_C.BndEvt__Cosmetics_Item_Button_K2Node_ComponentBoundEvent_2_OnButtonHoverEvent__DelegateSignature
	void RefreshItemsListForThisSlot(); // Function Cosmetics_Item.Cosmetics_Item_C.RefreshItemsListForThisSlot
	void ScrapCosmetic(int32_t SteamItemDef); // Function Cosmetics_Item.Cosmetics_Item_C.ScrapCosmetic
	void OnFinished_Scrapping(); // Function Cosmetics_Item.Cosmetics_Item_C.OnFinished_Scrapping
	void Destruct(); // Function Cosmetics_Item.Cosmetics_Item_C.Destruct
	void ExecuteUbergraph_Cosmetics_Item(int32_t EntryPoint); // Function Cosmetics_Item.Cosmetics_Item_C.ExecuteUbergraph_Cosmetics_Item
}; 



