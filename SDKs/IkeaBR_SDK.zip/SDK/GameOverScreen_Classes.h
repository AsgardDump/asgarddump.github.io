#pragma once 
#include <GameOverScreen_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass GameOverScreen.GameOverScreen_C
// Size: 0x324(Inherited: 0x260) 
struct UGameOverScreen_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* 0850_ShowRewardsAndButtons;  // 0x268(0x8)
	struct UWidgetAnimation* 1250_ShowTitleText;  // 0x270(0x8)
	struct UImage* Image;  // 0x278(0x8)
	struct UImage* Image_79;  // 0x280(0x8)
	struct UTextBlock* KilledBy;  // 0x288(0x8)
	struct UPlayer_Level_C* Player_Level;  // 0x290(0x8)
	struct UHorizontalBox* RewardsBox;  // 0x298(0x8)
	struct URR_Border_Plain_C* RR_Border_Plain_C_3;  // 0x2A0(0x8)
	struct URR_Button_C* RR_Button_C;  // 0x2A8(0x8)
	struct URR_Button_C* RR_Button_C_2;  // 0x2B0(0x8)
	struct URR_Button_C* RR_Button_C_122;  // 0x2B8(0x8)
	struct URR_Text_C* RR_Text_C_95;  // 0x2C0(0x8)
	struct USpacer* Spacer_286;  // 0x2C8(0x8)
	struct UTextBlock* TextBlock_88;  // 0x2D0(0x8)
	struct UImage* Vignette;  // 0x2D8(0x8)
	struct UW_LeaderboardVerticalBox_C* W_LeaderboardVerticalBox;  // 0x2E0(0x8)
	struct UW_ReportPlayer_C* W_ReportPlayer_111;  // 0x2E8(0x8)
	struct FST_Stats Stats;  // 0x2F0(0x24)
	char pad_788_1 : 7;  // 0x314(0x1)
	bool WinnerOverride : 1;  // 0x314(0x1)
	char pad_789_1 : 7;  // 0x315(0x1)
	bool GotRegularCopupon : 1;  // 0x315(0x1)
	char pad_790_1 : 7;  // 0x316(0x1)
	bool GotGoldenCoupon : 1;  // 0x316(0x1)
	char pad_791[1];  // 0x317(0x1)
	struct AFirstPersonCharacter_C* KIller;  // 0x318(0x8)
	float XPMultiplier;  // 0x320(0x4)

	uint8_t  GetVisibility_2(); // Function GameOverScreen.GameOverScreen_C.GetVisibility_2
	uint8_t  GetVisibility_1(); // Function GameOverScreen.GameOverScreen_C.GetVisibility_1
	uint8_t  ChampionTextVisibility(); // Function GameOverScreen.GameOverScreen_C.ChampionTextVisibility
	struct FText RankText(); // Function GameOverScreen.GameOverScreen_C.RankText
	struct FText Get_KilledBy_Text_1(); // Function GameOverScreen.GameOverScreen_C.Get_KilledBy_Text_1
	struct FLinearColor VignetteColor(); // Function GameOverScreen.GameOverScreen_C.VignetteColor
	struct FText GetMaterialsXP(); // Function GameOverScreen.GameOverScreen_C.GetMaterialsXP
	struct FText GetText_2(); // Function GameOverScreen.GameOverScreen_C.GetText_2
	bool GetbIsEnabled_2(); // Function GameOverScreen.GameOverScreen_C.GetbIsEnabled_2
	bool GetbIsEnabled_1(); // Function GameOverScreen.GameOverScreen_C.GetbIsEnabled_1
	struct FText GetText_1(); // Function GameOverScreen.GameOverScreen_C.GetText_1
	struct FText Get_Rank_7_Text_1(); // Function GameOverScreen.GameOverScreen_C.Get_Rank_7_Text_1
	struct FText Get_Rank_3_Text_1(); // Function GameOverScreen.GameOverScreen_C.Get_Rank_3_Text_1
	void OnFailure_8103C0DB4F73E9A09660F7A5C687827C(); // Function GameOverScreen.GameOverScreen_C.OnFailure_8103C0DB4F73E9A09660F7A5C687827C
	void OnSuccess_8103C0DB4F73E9A09660F7A5C687827C(); // Function GameOverScreen.GameOverScreen_C.OnSuccess_8103C0DB4F73E9A09660F7A5C687827C
	void Construct(); // Function GameOverScreen.GameOverScreen_C.Construct
	void BndEvt__RR_Button_C_121_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function GameOverScreen.GameOverScreen_C.BndEvt__RR_Button_C_121_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void BndEvt__RR_Button_C_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature(); // Function GameOverScreen.GameOverScreen_C.BndEvt__RR_Button_C_K2Node_ComponentBoundEvent_2_OnButtonClickedEvent__DelegateSignature
	void BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function GameOverScreen.GameOverScreen_C.BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void PlayAnimations(bool XP animation?); // Function GameOverScreen.GameOverScreen_C.PlayAnimations
	void AddLeaderboardStats(); // Function GameOverScreen.GameOverScreen_C.AddLeaderboardStats
	void ExecuteUbergraph_GameOverScreen(int32_t EntryPoint); // Function GameOverScreen.GameOverScreen_C.ExecuteUbergraph_GameOverScreen
}; 



