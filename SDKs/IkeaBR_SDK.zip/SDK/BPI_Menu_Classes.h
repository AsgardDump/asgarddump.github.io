#pragma once 
#include <BPI_Menu_Structs.h>
 
 
 
// BlueprintGeneratedClass BPI_Menu.BPI_Menu_C
// Size: 0x28(Inherited: 0x28) 
struct UBPI_Menu_C : public UInterface
{

	void ForceKill(); // Function BPI_Menu.BPI_Menu_C.ForceKill
}; 



