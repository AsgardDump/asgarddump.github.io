#pragma once 
#include <CosmeticScrappingAction_Structs.h>
 
 
 
// BlueprintGeneratedClass CosmeticScrappingAction.CosmeticScrappingAction_C
// Size: 0xAC(Inherited: 0x30) 
struct UCosmeticScrappingAction_C : public URRObject
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x30(0x8)
	struct FST_SteamItem ItemToScrap;  // 0x38(0x38)
	struct TArray<int32_t> ScapsItemList;  // 0x70(0x10)
	int32_t ScrapsItemDef;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct FMulticastInlineDelegate OnFinished;  // 0x88(0x10)
	struct FString ConsumeRequestID;  // 0x98(0x10)
	int32_t PreScramItemsArrayLength;  // 0xA8(0x4)

	void OnCosmeticConsumed(struct FString Data, bool bWasSuccessful); // Function CosmeticScrappingAction.CosmeticScrappingAction_C.OnCosmeticConsumed
	void OnScrapAdded(struct FString Data, bool bWasSuccessful); // Function CosmeticScrappingAction.CosmeticScrappingAction_C.OnScrapAdded
	void ScrapCosmetic(int32_t CosmeticSteamDefID, struct UObject* NewWorldContext); // Function CosmeticScrappingAction.CosmeticScrappingAction_C.ScrapCosmetic
	void RetryScrap(); // Function CosmeticScrappingAction.CosmeticScrappingAction_C.RetryScrap
	void ExecuteUbergraph_CosmeticScrappingAction(int32_t EntryPoint); // Function CosmeticScrappingAction.CosmeticScrappingAction_C.ExecuteUbergraph_CosmeticScrappingAction
	void OnFinished__DelegateSignature(); // Function CosmeticScrappingAction.CosmeticScrappingAction_C.OnFinished__DelegateSignature
}; 



