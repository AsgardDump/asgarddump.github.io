#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Regen.BP_Effect_Regen_C.ExecuteUbergraph_BP_Effect_Regen
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Regen
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)

}; 
