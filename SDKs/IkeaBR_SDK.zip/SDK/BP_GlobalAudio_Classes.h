#pragma once 
#include <BP_GlobalAudio_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_GlobalAudio.BP_GlobalAudio_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_GlobalAudio_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Audio;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)

	void PlaySound(struct USoundBase* NewSound, float fadeInDuration); // Function BP_GlobalAudio.BP_GlobalAudio_C.PlaySound
	void ExecuteUbergraph_BP_GlobalAudio(int32_t EntryPoint); // Function BP_GlobalAudio.BP_GlobalAudio_C.ExecuteUbergraph_BP_GlobalAudio
}; 



