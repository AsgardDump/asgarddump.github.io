#pragma once 
#include <CustomGames_EnterPassword_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomGames_EnterPassword.CustomGames_EnterPassword_C
// Size: 0x380(Inherited: 0x260) 
struct UCustomGames_EnterPassword_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct URR_Button_Transparent_C* RR_Button_Transparent_C_43;  // 0x268(0x8)
	struct URR_TextBox_C* RR_TextBox_C_201;  // 0x270(0x8)
	struct FBlueprintSessionResult Server;  // 0x278(0x108)

	void OnFailure_3747A33645E05B138578B1A9162AC56E(); // Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.OnFailure_3747A33645E05B138578B1A9162AC56E
	void OnSuccess_3747A33645E05B138578B1A9162AC56E(); // Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.OnSuccess_3747A33645E05B138578B1A9162AC56E
	void Construct(); // Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.Construct
	void BndEvt__RR_TextBox_C_200_K2Node_ComponentBoundEvent_0_OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.BndEvt__RR_TextBox_C_200_K2Node_ComponentBoundEvent_0_OnEditableTextBoxChangedEvent__DelegateSignature
	void BndEvt__RR_Button_Transparent_C_42_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.BndEvt__RR_Button_Transparent_C_42_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_CustomGames_EnterPassword(int32_t EntryPoint); // Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.ExecuteUbergraph_CustomGames_EnterPassword
}; 



