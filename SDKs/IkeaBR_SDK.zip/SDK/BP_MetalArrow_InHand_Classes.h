#pragma once 
#include <BP_MetalArrow_InHand_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MetalArrow_InHand.BP_MetalArrow_InHand_C
// Size: 0x268(Inherited: 0x268) 
struct ABP_MetalArrow_InHand_C : public AItemBP_C
{

}; 



