#pragma once 
#include <BP_Bow_Crafted_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Bow_Crafted.BP_Bow_Crafted_C
// Size: 0x2CD(Inherited: 0x2CD) 
struct ABP_Bow_Crafted_C : public ABP_Bow_Base_C
{

}; 



