#pragma once 
#include "SDK.h" 
 
 
// Function DefaultBlueprints.DefaultBlueprints_C.ExecuteUbergraph_DefaultBlueprints
// Size: 0x3CF(Inherited: 0x0) 
struct FExecuteUbergraph_DefaultBlueprints
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_5;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_CustomEvent_bSuccess_5 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_Variable : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct USaveGame* Temp_object_Variable;  // 0x18(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct USaveGame* K2Node_CustomEvent_SaveGame_4;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_CustomEvent_bSuccess_4 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x3C(0x10)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct USaveGame* Temp_object_Variable_2;  // 0x50(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_2;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x64(0x10)
	char pad_116[4];  // 0x74(0x4)
	struct TArray<int32_t> CallFunc_SortRecipiesByTier_Out;  // 0x78(0x10)
	struct USaveGame* K2Node_CustomEvent_SaveGame_3;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_CustomEvent_bSuccess_3 : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x94(0x4)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct USaveGame* Temp_object_Variable_3;  // 0xA0(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_3;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0xB4(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xC4(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_2;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_CustomEvent_bSuccess_2 : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0xD1(0x1)
	char pad_210[6];  // 0xD2(0x6)
	struct USaveGame* Temp_object_Variable_4;  // 0xD8(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool K2Node_CustomEvent_bSuccess : 1;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0xEC(0x10)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0xFC(0x1)
	char pad_253[3];  // 0xFD(0x3)
	struct USaveGame* Temp_object_Variable_5;  // 0x100(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x108(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10C(0x4)
	int32_t CallFunc_Array_Get_Item;  // 0x110(0x4)
	char pad_276_1 : 7;  // 0x114(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x114(0x1)
	char pad_277[3];  // 0x115(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x118(0x4)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x11C(0x1)
	char pad_285[3];  // 0x11D(0x3)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0x120(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x128(0x10)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0x138(0x10)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x148(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue;  // 0x150(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x161(0x1)
	char pad_354_1 : 7;  // 0x162(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x162(0x1)
	char pad_355[5];  // 0x163(0x5)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_2;  // 0x168(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_2;  // 0x170(0x10)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_3;  // 0x180(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_2;  // 0x188(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_3;  // 0x190(0x10)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_2 : 1;  // 0x1A0(0x1)
	char pad_417_1 : 7;  // 0x1A1(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1A1(0x1)
	char pad_418_1 : 7;  // 0x1A2(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_3 : 1;  // 0x1A2(0x1)
	char pad_419[5];  // 0x1A3(0x5)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_2;  // 0x1A8(0x8)
	struct USaveGame* Temp_object_Variable_6;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x1B8(0x1)
	char pad_441[7];  // 0x1B9(0x7)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_4;  // 0x1C0(0x8)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1C8(0x1)
	char pad_457[7];  // 0x1C9(0x7)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_4;  // 0x1D0(0x8)
	struct USaveGame* K2Node_Select_Default;  // 0x1D8(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_4;  // 0x1E0(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_2;  // 0x1F0(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_3;  // 0x1F8(0x8)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x200(0x1)
	char pad_513_1 : 7;  // 0x201(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x201(0x1)
	char pad_514_1 : 7;  // 0x202(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_4 : 1;  // 0x202(0x1)
	char pad_515[5];  // 0x203(0x5)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_3;  // 0x208(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_7;  // 0x210(0x8)
	char pad_536_1 : 7;  // 0x218(0x1)
	bool K2Node_CustomEvent_bSuccess_7 : 1;  // 0x218(0x1)
	char pad_537[7];  // 0x219(0x7)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_3;  // 0x220(0x8)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x228(0x1)
	char pad_553[7];  // 0x229(0x7)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_4;  // 0x230(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x238(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_4;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x250(0x1)
	char pad_593[3];  // 0x251(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x254(0x4)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x258(0x1)
	char pad_601[3];  // 0x259(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x25C(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x260(0x4)
	int32_t CallFunc_Array_Get_Item_2;  // 0x264(0x4)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x268(0x1)
	char pad_617[3];  // 0x269(0x3)
	int32_t K2Node_CustomEvent_recipe_2;  // 0x26C(0x4)
	int32_t K2Node_CustomEvent_SelectionIndex;  // 0x270(0x4)
	char pad_628_1 : 7;  // 0x274(0x1)
	bool K2Node_SwitchInteger_CmpSuccess_2 : 1;  // 0x274(0x1)
	char pad_629_1 : 7;  // 0x275(0x1)
	bool K2Node_SwitchInteger_CmpSuccess_3 : 1;  // 0x275(0x1)
	char pad_630[2];  // 0x276(0x2)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x278(0x8)
	struct UDB_Recipie_C* CallFunc_Create_ReturnValue;  // 0x280(0x8)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x288(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x28C(0x4)
	int32_t K2Node_CustomEvent_Index;  // 0x290(0x4)
	char pad_660[4];  // 0x294(0x4)
	struct USaveGame* Temp_object_Variable_7;  // 0x298(0x8)
	int32_t Temp_int_Variable;  // 0x2A0(0x4)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x2A4(0x4)
	struct UUniformGridSlot* CallFunc_AddChildToUniformGrid_ReturnValue;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x2B0(0x1)
	char pad_689_1 : 7;  // 0x2B1(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x2B1(0x1)
	char pad_690_1 : 7;  // 0x2B2(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_3 : 1;  // 0x2B2(0x1)
	char pad_691_1 : 7;  // 0x2B3(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x2B3(0x1)
	char pad_692_1 : 7;  // 0x2B4(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_4 : 1;  // 0x2B4(0x1)
	char pad_693_1 : 7;  // 0x2B5(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x2B5(0x1)
	char pad_694_1 : 7;  // 0x2B6(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_5 : 1;  // 0x2B6(0x1)
	char pad_695_1 : 7;  // 0x2B7(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2B7(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x2B8(0x4)
	int32_t K2Node_CustomEvent_recipe;  // 0x2BC(0x4)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_6 : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)
	struct FST_CraftRecipe CallFunc_GetRecipeFromID_Recipe;  // 0x2C8(0x28)
	struct TArray<struct ABP_RecipePreview_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x2F0(0x10)
	struct ABP_RecipePreview_C* CallFunc_Array_Get_Item_3;  // 0x300(0x8)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x308(0x90)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x398(0x8)
	struct UDB_RandomRecipe_C* CallFunc_Create_ReturnValue_2;  // 0x3A0(0x8)
	struct UUniformGridSlot* CallFunc_AddChildToUniformGrid_ReturnValue_2;  // 0x3A8(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_6;  // 0x3B0(0x8)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool K2Node_CustomEvent_bSuccess_6 : 1;  // 0x3B8(0x1)
	char pad_953[3];  // 0x3B9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x3BC(0x10)
	char pad_972_1 : 7;  // 0x3CC(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_7 : 1;  // 0x3CC(0x1)
	char pad_973_1 : 7;  // 0x3CD(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x3CD(0x1)
	char pad_974_1 : 7;  // 0x3CE(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3CE(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.Completed_215CB37D43646A0095BC73975CB4BCB4
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73975CB4BCB4
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.OnHoverRecipe
// Size: 0x4(Inherited: 0x0) 
struct FOnHoverRecipe
{
	int32_t Recipe;  // 0x0(0x4)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.Completed_215CB37D43646A0095BC7397426622D9
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC7397426622D9
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.Completed_6F07F8864F50B817CAEDB385507E4A95
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB385507E4A95
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.ShowSelection
// Size: 0x4(Inherited: 0x0) 
struct FShowSelection
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.OnRecipeSelected
// Size: 0x8(Inherited: 0x0) 
struct FOnRecipeSelected
{
	int32_t Recipe;  // 0x0(0x4)
	int32_t SelectionIndex;  // 0x4(0x4)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.Completed_6F07F8864F50B817CAEDB3854EACD4F8
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB3854EACD4F8
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.Completed_0914B3504C491F3C20AD17967400C52E
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_0914B3504C491F3C20AD17967400C52E
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.Completed_215CB37D43646A0095BC739722A6680E
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC739722A6680E
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.Completed_6F07F8864F50B817CAEDB38530BE0042
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB38530BE0042
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DefaultBlueprints.DefaultBlueprints_C.ShouldShowSelection
// Size: 0x5(Inherited: 0x0) 
struct FShouldShowSelection
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	uint8_t  K2Node_Select_Default;  // 0x4(0x1)

}; 
