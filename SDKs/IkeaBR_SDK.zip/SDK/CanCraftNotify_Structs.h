#pragma once 
#include "SDK.h" 
 
 
// Function CanCraftNotify.CanCraftNotify_C.GetBrushColor_1
// Size: 0xB0(Inherited: 0x0) 
struct FGetBrushColor_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x10(0x90)
	struct FLinearColor CallFunc_TierColor_color;  // 0xA0(0x10)

}; 
// Function CanCraftNotify.CanCraftNotify_C.GetBrush_1
// Size: 0x1A0(Inherited: 0x0) 
struct FGetBrush_1
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x88(0x90)
	struct FSlateBrush CallFunc_MakeBrushFromTexture_ReturnValue;  // 0x118(0x88)

}; 
// Function CanCraftNotify.CanCraftNotify_C.GetPercent_1
// Size: 0x28(Inherited: 0x0) 
struct FGetPercent_1
{
	float ReturnValue;  // 0x0(0x4)
	float Range;  // 0x4(0x4)
	float Progress;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x10(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_CanCraft_Can_Craft : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	float CallFunc_GetCraftingProgress_Percent_normalized_;  // 0x24(0x4)

}; 
// Function CanCraftNotify.CanCraftNotify_C.GetFillColorAndOpacity_1
// Size: 0x44(Inherited: 0x0) 
struct FGetFillColorAndOpacity_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x24(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x34(0x10)

}; 
