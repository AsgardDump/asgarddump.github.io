#pragma once 
#include "SDK.h" 
 
 
// Function BP_SpawnBillboard.BP_SpawnBillboard_C.ExecuteUbergraph_BP_SpawnBillboard
// Size: 0x79(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SpawnBillboard
{
	int32_t EntryPoint;  // 0x0(0x4)
	char E_LocationType Temp_byte_Variable;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct UTexture2D* Temp_object_Variable;  // 0x8(0x8)
	struct UTexture2D* Temp_object_Variable_2;  // 0x10(0x8)
	struct UTexture2D* Temp_object_Variable_3;  // 0x18(0x8)
	struct UTexture2D* Temp_object_Variable_4;  // 0x20(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct ABP_ROE_SpawnPawn_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x30(0x10)
	struct ABP_ROE_SpawnPawn_C* CallFunc_Array_Get_Item;  // 0x40(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x48(0x8)
	struct UTexture2D* K2Node_Select_Default;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x68(0x8)
	struct UW_LocationBillboard_C* K2Node_DynamicCast_AsW_Location_Billboard;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)

}; 
// Function BP_SpawnBillboard.BP_SpawnBillboard_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
