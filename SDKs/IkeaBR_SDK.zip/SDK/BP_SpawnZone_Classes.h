#pragma once 
#include <BP_SpawnZone_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SpawnZone.BP_SpawnZone_C
// Size: 0x298(Inherited: 0x220) 
struct ABP_SpawnZone_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UWidgetComponent* Widget;  // 0x228(0x8)
	struct UStaticMeshComponent* SpawnMesh;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	struct UStaticMesh* Mesh;  // 0x240(0x8)
	struct FString Name;  // 0x248(0x10)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool Enabled? : 1;  // 0x258(0x1)
	char pad_601[7];  // 0x259(0x7)
	struct UMaterialInstanceDynamic* MatInstance;  // 0x260(0x8)
	struct TArray<struct ABP_ROE_SpawnPawn_C*> PlayersSelectedMe;  // 0x268(0x10)
	int32_t TotalSlots;  // 0x278(0x4)
	struct FLinearColor UnavailableColor;  // 0x27C(0x10)
	char pad_652[4];  // 0x28C(0x4)
	struct UW_SpawnZone_C* SpawnZoneWidget;  // 0x290(0x8)

	bool IsUnavailable(); // Function BP_SpawnZone.BP_SpawnZone_C.IsUnavailable
	void OnRep_PlayersSelectedMe(); // Function BP_SpawnZone.BP_SpawnZone_C.OnRep_PlayersSelectedMe
	void OnRep_Enabled?(); // Function BP_SpawnZone.BP_SpawnZone_C.OnRep_Enabled?
	void UserConstructionScript(); // Function BP_SpawnZone.BP_SpawnZone_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_SpawnZone.BP_SpawnZone_C.ReceiveBeginPlay
	void Set Enabled(bool Enabled?); // Function BP_SpawnZone.BP_SpawnZone_C.Set Enabled
	void Client_OnRepEnabled(bool Enabled); // Function BP_SpawnZone.BP_SpawnZone_C.Client_OnRepEnabled
	void OnPlayerSelectMe(struct ABP_ROE_SpawnPawn_C* Player); // Function BP_SpawnZone.BP_SpawnZone_C.OnPlayerSelectMe
	void ReceiveTick(float DeltaSeconds); // Function BP_SpawnZone.BP_SpawnZone_C.ReceiveTick
	void ExecuteUbergraph_BP_SpawnZone(int32_t EntryPoint); // Function BP_SpawnZone.BP_SpawnZone_C.ExecuteUbergraph_BP_SpawnZone
}; 



