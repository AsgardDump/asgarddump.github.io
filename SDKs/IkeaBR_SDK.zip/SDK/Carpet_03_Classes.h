#pragma once 
#include <Carpet_03_Structs.h>
 
 
 
// BlueprintGeneratedClass Carpet_03.Carpet_03_C
// Size: 0x228(Inherited: 0x220) 
struct ACarpet_03_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)

}; 



