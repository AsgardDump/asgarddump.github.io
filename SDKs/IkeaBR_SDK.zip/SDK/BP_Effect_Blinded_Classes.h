#pragma once 
#include <BP_Effect_Blinded_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Effect_Blinded.BP_Effect_Blinded_C
// Size: 0x2B8(Inherited: 0x2B0) 
struct ABP_Effect_Blinded_C : public ABP_Effect_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B0(0x8)

	void Event On(); // Function BP_Effect_Blinded.BP_Effect_Blinded_C.Event On
	void Event Reset(); // Function BP_Effect_Blinded.BP_Effect_Blinded_C.Event Reset
	void Event Off(); // Function BP_Effect_Blinded.BP_Effect_Blinded_C.Event Off
	void ExecuteUbergraph_BP_Effect_Blinded(int32_t EntryPoint); // Function BP_Effect_Blinded.BP_Effect_Blinded_C.ExecuteUbergraph_BP_Effect_Blinded
}; 



