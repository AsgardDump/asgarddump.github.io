#pragma once 
#include "SDK.h" 
 
 
// Function AI_Bot.AI_Bot_C.ExecuteUbergraph_AI_Bot
// Size: 0x199(Inherited: 0x0) 
struct FExecuteUbergraph_AI_Bot
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x8(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x10(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x24(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x28(0x4)
	float K2Node_Event_Damage;  // 0x2C(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x30(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x38(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AAI_Bot_C* K2Node_DynamicCast_AsAI_Bot;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x60(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x68(0x8)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x80(0x8)
	struct UObject* CallFunc_GetValueAsObject_ReturnValue;  // 0x88(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x9C(0x8)
	char pad_164[4];  // 0xA4(0x4)
	struct AAIController* CallFunc_GetAIController_ReturnValue_2;  // 0xA8(0x8)
	struct TMap<int32_t, int32_t> K2Node_MakeMap_Map;  // 0xB0(0x50)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct FST_ItemBase CallFunc_GetRandomItem_Item;  // 0x108(0x90)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x198(0x1)

}; 
// Function AI_Bot.AI_Bot_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
