#pragma once 
#include <GardenRake_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass GardenRake_BP.GardenRake_BP_C
// Size: 0x290(Inherited: 0x290) 
struct AGardenRake_BP_C : public AWeaponBP_C
{

}; 



