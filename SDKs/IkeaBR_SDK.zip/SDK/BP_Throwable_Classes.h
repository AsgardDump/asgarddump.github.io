#pragma once 
#include <BP_Throwable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Throwable.BP_Throwable_C
// Size: 0x2A0(Inherited: 0x268) 
struct ABP_Throwable_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	struct USceneComponent* Scene;  // 0x270(0x8)
	struct FST_RangedInfo RangedInfo;  // 0x278(0x20)
	struct UAmmoCounter_C* AmmoCounter;  // 0x298(0x8)

	void Stop(); // Function BP_Throwable.BP_Throwable_C.Stop
	void LMB(bool Down); // Function BP_Throwable.BP_Throwable_C.LMB
	void ExecuteUbergraph_BP_Throwable(int32_t EntryPoint); // Function BP_Throwable.BP_Throwable_C.ExecuteUbergraph_BP_Throwable
}; 



