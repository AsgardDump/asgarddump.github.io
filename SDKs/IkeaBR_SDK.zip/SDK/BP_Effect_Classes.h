#pragma once 
#include <BP_Effect_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Effect.BP_Effect_C
// Size: 0x2B0(Inherited: 0x220) 
struct ABP_Effect_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct AFirstPersonCharacter_C* Parent;  // 0x230(0x8)
	float Time;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)
	struct FST_Effect Effect;  // 0x240(0x38)
	struct FMulticastInlineDelegate On;  // 0x278(0x10)
	struct FMulticastInlineDelegate Off;  // 0x288(0x10)
	struct AFirstPersonCharacter_C* caster;  // 0x298(0x8)
	struct FMulticastInlineDelegate EventReset;  // 0x2A0(0x10)

	void GetCaster(struct AFirstPersonCharacter_C*& caster); // Function BP_Effect.BP_Effect_C.GetCaster
	void GetParent(struct AFirstPersonCharacter_C*& Parent); // Function BP_Effect.BP_Effect_C.GetParent
	void ReceiveBeginPlay(); // Function BP_Effect.BP_Effect_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Effect.BP_Effect_C.ReceiveTick
	void Reset(); // Function BP_Effect.BP_Effect_C.Reset
	void ClientCallOff(); // Function BP_Effect.BP_Effect_C.ClientCallOff
	void ClientCallReset(); // Function BP_Effect.BP_Effect_C.ClientCallReset
	void ClientCallOn(); // Function BP_Effect.BP_Effect_C.ClientCallOn
	void Event On(); // Function BP_Effect.BP_Effect_C.Event On
	void Event Off(); // Function BP_Effect.BP_Effect_C.Event Off
	void Event Reset(); // Function BP_Effect.BP_Effect_C.Event Reset
	void ExecuteUbergraph_BP_Effect(int32_t EntryPoint); // Function BP_Effect.BP_Effect_C.ExecuteUbergraph_BP_Effect
	void EventReset__DelegateSignature(); // Function BP_Effect.BP_Effect_C.EventReset__DelegateSignature
	void Off__DelegateSignature(); // Function BP_Effect.BP_Effect_C.Off__DelegateSignature
	void On__DelegateSignature(); // Function BP_Effect.BP_Effect_C.On__DelegateSignature
}; 



