#pragma once 
#include "SDK.h" 
 
 
// Function CraftRecipe1.CraftRecipe1_C.ExecuteUbergraph_CraftRecipe1
// Size: 0xA2(Inherited: 0x0) 
struct FExecuteUbergraph_CraftRecipe1
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Temp_float_Variable;  // 0x8(0x4)
	float Temp_float_Variable_2;  // 0xC(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x10(0x38)
	float K2Node_Event_InDeltaTime;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x50(0x8)
	float CallFunc_GetMousePosition_LocationX;  // 0x58(0x4)
	float CallFunc_GetMousePosition_LocationY;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_GetMousePosition_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0x64(0x8)
	float CallFunc_BreakVector2D_X;  // 0x6C(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x70(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x74(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x78(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x7C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x80(0x4)
	float CallFunc_DegAtan2_ReturnValue;  // 0x84(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x88(0x4)
	float CallFunc_Percent_FloatFloat_ReturnValue;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x92(0x1)
	char pad_147_1 : 7;  // 0x93(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x93(0x1)
	float K2Node_Select_Default;  // 0x94(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0xA1(0x1)

}; 
// Function CraftRecipe1.CraftRecipe1_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function CraftRecipe1.CraftRecipe1_C.Get_Outline_ColorAndOpacity_1
// Size: 0x44(Inherited: 0x0) 
struct FGet_Outline_ColorAndOpacity_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x24(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x34(0x10)

}; 
// Function CraftRecipe1.CraftRecipe1_C.GetbIsEnabled_1
// Size: 0x2(Inherited: 0x0) 
struct FGetbIsEnabled_1
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function CraftRecipe1.CraftRecipe1_C.GetBrushColor_1
// Size: 0xA4(Inherited: 0x0) 
struct FGetBrushColor_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FLinearColor Temp_struct_Variable_3;  // 0x38(0x10)
	struct FLinearColor Temp_struct_Variable_4;  // 0x48(0x10)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x58(0x8)
	struct FLinearColor K2Node_Select_Default;  // 0x60(0x10)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x79(0x1)
	char pad_122_1 : 7;  // 0x7A(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x7A(0x1)
	char pad_123_1 : 7;  // 0x7B(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x7B(0x1)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_2 : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_3 : 1;  // 0x7D(0x1)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x7E(0x1)
	char pad_127_1 : 7;  // 0x7F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x7F(0x1)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	struct FLinearColor K2Node_Select_Default_2;  // 0x84(0x10)
	struct FLinearColor CallFunc_SelectColor_ReturnValue;  // 0x94(0x10)

}; 
// Function CraftRecipe1.CraftRecipe1_C.GetText_1
// Size: 0x40(Inherited: 0x0) 
struct FGetText_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x18(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x28(0x18)

}; 
// Function CraftRecipe1.CraftRecipe1_C.GetBrush_1
// Size: 0x1C0(Inherited: 0x0) 
struct FGetBrush_1
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x88(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x98(0x8)
	struct FST_ItemBase CallFunc_GetDataTableRowFromName_OutRow;  // 0xA0(0x90)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x138(0x88)

}; 
// Function CraftRecipe1.CraftRecipe1_C.GetVisibility_1
// Size: 0x5(Inherited: 0x0) 
struct FGetVisibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	uint8_t  K2Node_Select_Default;  // 0x4(0x1)

}; 
// Function CraftRecipe1.CraftRecipe1_C.GetPercent_1
// Size: 0x20(Inherited: 0x0) 
struct FGetPercent_1
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x8(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_GetCraftingProgress_Percent_normalized_;  // 0x1C(0x4)

}; 
// Function CraftRecipe1.CraftRecipe1_C.GetFillColorAndOpacity_1
// Size: 0x61(Inherited: 0x0) 
struct FGetFillColorAndOpacity_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x24(0x10)
	char pad_52[4];  // 0x34(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x38(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x4C(0x10)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_2 : 1;  // 0x5D(0x1)
	char pad_94_1 : 7;  // 0x5E(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_3 : 1;  // 0x5E(0x1)
	char pad_95_1 : 7;  // 0x5F(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5F(0x1)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x60(0x1)

}; 
