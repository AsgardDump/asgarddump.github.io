#pragma once 
#include "SDK.h" 
 
 
// Function BP_Trampoline.BP_Trampoline_C.PlayBounce
// Size: 0x8(Inherited: 0x0) 
struct FPlayBounce
{
	float NewPitchMultiplier;  // 0x0(0x4)
	float NewVolumeMultiplier;  // 0x4(0x4)

}; 
// Function BP_Trampoline.BP_Trampoline_C.ExecuteUbergraph_BP_Trampoline
// Size: 0x295(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Trampoline
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0x4(0xC)
	float CallFunc_BreakVector_X;  // 0x10(0x4)
	float CallFunc_BreakVector_Y;  // 0x14(0x4)
	float CallFunc_BreakVector_Z;  // 0x18(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x24(0x4)
	struct FVector CallFunc_GetUpVector_ReturnValue_2;  // 0x28(0xC)
	struct FVector CallFunc_GetUpVector_ReturnValue_3;  // 0x34(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x40(0xC)
	float CallFunc_BreakVector_X_2;  // 0x4C(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x50(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x54(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x58(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x5C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x65(0x1)
	char pad_102_1 : 7;  // 0x66(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x66(0x1)
	char pad_103[1];  // 0x67(0x1)
	float K2Node_Event_DeltaSeconds;  // 0x68(0x4)
	struct FVector CallFunc_GetUpVector_ReturnValue_4;  // 0x6C(0xC)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x78(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x80(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x88(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x90(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x9C(0x88)
	float CallFunc_Dot_VectorVector_ReturnValue;  // 0x124(0x4)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x139(0x1)
	char pad_314_1 : 7;  // 0x13A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x13A(0x1)
	char pad_315_1 : 7;  // 0x13B(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue : 1;  // 0x13B(0x1)
	char pad_316[4];  // 0x13C(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x148(0x1)
	char pad_329[3];  // 0x149(0x3)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x14C(0xC)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x158(0x8)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x160(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x16C(0xC)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_2;  // 0x17C(0xC)
	float CallFunc_BreakVector_X_3;  // 0x188(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x18C(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x190(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x194(0x4)
	struct FVector CallFunc_GetLastUpdateVelocity_ReturnValue;  // 0x198(0xC)
	float CallFunc_FClamp_ReturnValue_2;  // 0x1A4(0x4)
	float CallFunc_FClamp_ReturnValue_3;  // 0x1A8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x1AC(0xC)
	struct FVector CallFunc_GetUpVector_ReturnValue_5;  // 0x1B8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x1C4(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x1D0(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_3;  // 0x1DC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_4;  // 0x1E8(0xC)
	float CallFunc_RandomFloat_ReturnValue;  // 0x1F4(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0x1F8(0xC)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x204(0x1)
	char pad_517[3];  // 0x205(0x3)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_4;  // 0x208(0xC)
	float CallFunc_BreakVector_X_4;  // 0x214(0x4)
	float CallFunc_BreakVector_Y_4;  // 0x218(0x4)
	float CallFunc_BreakVector_Z_4;  // 0x21C(0x4)
	float CallFunc_FClamp_ReturnValue_4;  // 0x220(0x4)
	float CallFunc_FClamp_ReturnValue_5;  // 0x224(0x4)
	float CallFunc_FClamp_ReturnValue_6;  // 0x228(0x4)
	float K2Node_CustomEvent_NewPitchMultiplier_2;  // 0x22C(0x4)
	float K2Node_CustomEvent_NewVolumeMultiplier_2;  // 0x230(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x234(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_4;  // 0x240(0xC)
	float CallFunc_BreakVector_X_5;  // 0x24C(0x4)
	float CallFunc_BreakVector_Y_5;  // 0x250(0x4)
	float CallFunc_BreakVector_Z_5;  // 0x254(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x258(0x4)
	float K2Node_CustomEvent_NewPitchMultiplier;  // 0x25C(0x4)
	float K2Node_CustomEvent_NewVolumeMultiplier;  // 0x260(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x264(0xC)
	struct FDateTime CallFunc_Now_ReturnValue;  // 0x270(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_2;  // 0x278(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_3;  // 0x280(0x8)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue;  // 0x288(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue;  // 0x290(0x4)
	char pad_660_1 : 7;  // 0x294(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x294(0x1)

}; 
// Function BP_Trampoline.BP_Trampoline_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Trampoline.BP_Trampoline_C.ServerPlayBounce
// Size: 0x8(Inherited: 0x0) 
struct FServerPlayBounce
{
	float NewPitchMultiplier;  // 0x0(0x4)
	float NewVolumeMultiplier;  // 0x4(0x4)

}; 
// Function BP_Trampoline.BP_Trampoline_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0xAC) 
struct FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature : public FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
