#pragma once 
#include <FL_Ranked_Structs.h>
 
 
 
// BlueprintGeneratedClass FL_Ranked.FL_Ranked_C
// Size: 0x28(Inherited: 0x28) 
struct UFL_Ranked_C : public UBlueprintFunctionLibrary
{

	void RankToRankIcon(char E_Rank Rank, struct UObject* __WorldContext, struct UTexture2D*& Icon); // Function FL_Ranked.FL_Ranked_C.RankToRankIcon
	void RankedEnabled?(struct UObject* __WorldContext, bool& Value); // Function FL_Ranked.FL_Ranked_C.RankedEnabled?
	void RPTax(char E_Rank Rank, struct UObject* __WorldContext, int32_t& RPTax); // Function FL_Ranked.FL_Ranked_C.RPTax
	void StatsToRP(struct FST_Stats Stats, int32_t InitialPlayersInMatch, struct UObject* __WorldContext, int32_t& RP); // Function FL_Ranked.FL_Ranked_C.StatsToRP
	void RPToRank(int32_t RP, struct UObject* __WorldContext, char E_Rank& Rank); // Function FL_Ranked.FL_Ranked_C.RPToRank
}; 



