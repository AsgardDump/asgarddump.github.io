#pragma once 
#include <BP_FlashingLight_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlashingLight.BP_FlashingLight_C
// Size: 0x270(Inherited: 0x220) 
struct ABP_FlashingLight_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UPointLightComponent* PointLight;  // 0x228(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x230(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x238(0x8)
	float Timeline_0_light_C762DE5D40CF746EFFBD2183D18B7244;  // 0x240(0x4)
	char ETimelineDirection Timeline_0__Direction_C762DE5D40CF746EFFBD2183D18B7244;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x248(0x8)
	struct FLinearColor LightColor;  // 0x250(0x10)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool oscillate : 1;  // 0x260(0x1)
	char pad_609[3];  // 0x261(0x3)
	float Period;  // 0x264(0x4)
	struct UMaterialInstanceDynamic* LightMat;  // 0x268(0x8)

	void Start(); // Function BP_FlashingLight.BP_FlashingLight_C.Start
	void Timeline_0__FinishedFunc(); // Function BP_FlashingLight.BP_FlashingLight_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function BP_FlashingLight.BP_FlashingLight_C.Timeline_0__UpdateFunc
	void Begin Event(); // Function BP_FlashingLight.BP_FlashingLight_C.Begin Event
	void ExecuteUbergraph_BP_FlashingLight(int32_t EntryPoint); // Function BP_FlashingLight.BP_FlashingLight_C.ExecuteUbergraph_BP_FlashingLight
}; 



