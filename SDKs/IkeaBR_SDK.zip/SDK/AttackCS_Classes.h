#pragma once 
#include <AttackCS_Structs.h>
 
 
 
// BlueprintGeneratedClass AttackCS.AttackCS_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UAttackCS_C : public UMatineeCameraShake
{

}; 



