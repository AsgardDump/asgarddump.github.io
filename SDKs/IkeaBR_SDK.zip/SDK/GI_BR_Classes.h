#pragma once 
#include <GI_BR_Structs.h>
 
 
 
// BlueprintGeneratedClass GI_BR.GI_BR_C
// Size: 0x918(Inherited: 0x1F0) 
struct UGI_BR_C : public UGameInstance_Modified
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1F0(0x8)
	struct FST_ServerSettings ServerSettings;  // 0x1F8(0x8)
	struct FPostProcessSettings DefaultPostProcess;  // 0x200(0x560)
	struct TArray<struct FST_GlobalVar> GlobalVars;  // 0x760(0x10)
	struct TArray<struct FST_SteamItem> SteamItems;  // 0x770(0x10)
	struct FSteamID Teammate;  // 0x780(0x8)
	struct FMulticastInlineDelegate OnItemUpdate;  // 0x788(0x10)
	struct FST_PlayerSettings PlayerSettings;  // 0x798(0x30)
	struct FMulticastInlineDelegate OnPlayerSettingsChanged;  // 0x7C8(0x10)
	struct FSteamID CurrentLobby;  // 0x7D8(0x8)
	struct FSteamInventoryResult Handle_LastFullUpdate;  // 0x7E0(0x4)
	char pad_2020[4];  // 0x7E4(0x4)
	struct FMulticastInlineDelegate NewEventDispatcher_1;  // 0x7E8(0x10)
	struct FMulticastInlineDelegate E_OnNewItem;  // 0x7F8(0x10)
	struct FSteamInventoryResult Handle_Exchange;  // 0x808(0x4)
	struct FSteamInventoryResult Handle_Latest;  // 0x80C(0x4)
	struct TMap<int32_t, struct UTexture2D*> ImageCache;  // 0x810(0x50)
	char pad_2144_1 : 7;  // 0x860(0x1)
	bool ChoseChampionMode : 1;  // 0x860(0x1)
	char pad_2145[3];  // 0x861(0x3)
	int32_t PlayerLevelLimit;  // 0x864(0x4)
	struct TMap<struct FString, struct UTexture2D*> SprayImageCache;  // 0x868(0x50)
	struct TMap<struct FString, struct FString> SprayDynamicPropertyCache;  // 0x8B8(0x50)
	char pad_2312_1 : 7;  // 0x908(0x1)
	bool ShowCustomSprayPopup : 1;  // 0x908(0x1)
	char pad_2313[7];  // 0x909(0x7)
	struct UO_SuspensionChecker_C* SuspensionChecker;  // 0x910(0x8)

	void ForceNoFullscreenMode(char EWindowMode In, char EWindowMode& Out); // Function GI_BR.GI_BR_C.ForceNoFullscreenMode
	void GetPostProccessSettings(struct FPostProcessSettings& Settings); // Function GI_BR.GI_BR_C.GetPostProccessSettings
	void GetDynamicItemProperty(struct FST_SteamItem Item, struct FString Key, struct FString& Value, bool& Found?); // Function GI_BR.GI_BR_C.GetDynamicItemProperty
	void SteamItemsOnResult(struct FSteamInventoryResult Handle); // Function GI_BR.GI_BR_C.SteamItemsOnResult
	void SteamItemsFullUpdate(struct FSteamInventoryFullUpdate Handle); // Function GI_BR.GI_BR_C.SteamItemsFullUpdate
	void ApplyVideoSettings(struct FST_VideoSettings Settings); // Function GI_BR.GI_BR_C.ApplyVideoSettings
	void Completed_215CB37D43646A0095BC73978A83ED96(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_215CB37D43646A0095BC73978A83ED96
	void Completed_0914B3504C491F3C20AD1796D31AD75E(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_0914B3504C491F3C20AD1796D31AD75E
	void Completed_6F07F8864F50B817CAEDB385CD5CD748(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_6F07F8864F50B817CAEDB385CD5CD748
	void Completed_0914B3504C491F3C20AD17968266BFBA(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_0914B3504C491F3C20AD17968266BFBA
	void Completed_215CB37D43646A0095BC73976F8C07AD(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_215CB37D43646A0095BC73976F8C07AD
	void OnCallback_405B3A7A4235DB3AEBFD86B3AAECFC13(struct FLeaderboardFindResult& Data, bool bWasSuccessful); // Function GI_BR.GI_BR_C.OnCallback_405B3A7A4235DB3AEBFD86B3AAECFC13
	void OnCallback_9CEB70ED4957BA5DC3BEE4B2FA6157F5(struct FLeaderboardScoreUploaded& Data, bool bWasSuccessful); // Function GI_BR.GI_BR_C.OnCallback_9CEB70ED4957BA5DC3BEE4B2FA6157F5
	void OnFailure_333DD25D42BDA9F4C05B91A82A792EED(); // Function GI_BR.GI_BR_C.OnFailure_333DD25D42BDA9F4C05B91A82A792EED
	void OnSuccess_333DD25D42BDA9F4C05B91A82A792EED(); // Function GI_BR.GI_BR_C.OnSuccess_333DD25D42BDA9F4C05B91A82A792EED
	void Completed_215CB37D43646A0095BC7397DF44BF04(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_215CB37D43646A0095BC7397DF44BF04
	void Completed_6F07F8864F50B817CAEDB3857D946FE1(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_6F07F8864F50B817CAEDB3857D946FE1
	void OnCallback_257AC4FB4B227479878261897451C33A(struct FLeaderboardScoreUploaded& Data, bool bWasSuccessful); // Function GI_BR.GI_BR_C.OnCallback_257AC4FB4B227479878261897451C33A
	void OnCallback_B62C756D4B0FD845C1D073A93B2774FB(struct FLeaderboardFindResult& Data, bool bWasSuccessful); // Function GI_BR.GI_BR_C.OnCallback_B62C756D4B0FD845C1D073A93B2774FB
	void OnCallback_1032A81D49EF141A9F62E3A25FA977AD(struct FLeaderboardFindResult& Data, bool bWasSuccessful); // Function GI_BR.GI_BR_C.OnCallback_1032A81D49EF141A9F62E3A25FA977AD
	void OnCallback_20486EE64CB027631276EF85AF2F61E4(struct FLeaderboardFindResult& Data, bool bWasSuccessful); // Function GI_BR.GI_BR_C.OnCallback_20486EE64CB027631276EF85AF2F61E4
	void Completed_6F07F8864F50B817CAEDB385989B85DA(struct USaveGame* SaveGame, bool bSuccess); // Function GI_BR.GI_BR_C.Completed_6F07F8864F50B817CAEDB385989B85DA
	void Init EOS(); // Function GI_BR.GI_BR_C.Init EOS
	void OnReceiveEncryptedAppTicket(struct FString Ticket); // Function GI_BR.GI_BR_C.OnReceiveEncryptedAppTicket
	void OnLoginEOS(bool bWasSuccessful, struct FString ErrorStr); // Function GI_BR.GI_BR_C.OnLoginEOS
	void ModifyItemProperties(struct FString Key, struct FString Value, struct FST_SteamItem SteamItem); // Function GI_BR.GI_BR_C.ModifyItemProperties
	void DeleteSteamItem(int32_t ID); // Function GI_BR.GI_BR_C.DeleteSteamItem
	void ModifyItem(); // Function GI_BR.GI_BR_C.ModifyItem
	void ModifyItem_Callback(struct FString Data, bool bWasSuccessful); // Function GI_BR.GI_BR_C.ModifyItem_Callback
	void InitStats(); // Function GI_BR.GI_BR_C.InitStats
	void OnStatsinit(struct FUserStatsReceived& Data); // Function GI_BR.GI_BR_C.OnStatsinit
	void InitItems(); // Function GI_BR.GI_BR_C.InitItems
	void SteamInventoryFullUpdate_Event_1(struct FSteamInventoryFullUpdate& Data); // Function GI_BR.GI_BR_C.SteamInventoryFullUpdate_Event_1
	void AddRecipe(int32_t ID); // Function GI_BR.GI_BR_C.AddRecipe
	void GameInit(); // Function GI_BR.GI_BR_C.GameInit
	void ChangePlayerSettings(); // Function GI_BR.GI_BR_C.ChangePlayerSettings
	void ApplySavedSettings(bool IgnoreVideo); // Function GI_BR.GI_BR_C.ApplySavedSettings
	void ApplySoundSettings(struct FST_Settings& ST_Settings); // Function GI_BR.GI_BR_C.ApplySoundSettings
	void SetLobby(struct FSteamID CurrentLobby); // Function GI_BR.GI_BR_C.SetLobby
	void LeaveLobby(); // Function GI_BR.GI_BR_C.LeaveLobby
	void OpenLootCrate(bool GoldenCrate?); // Function GI_BR.GI_BR_C.OpenLootCrate
	void ClearAllItems(); // Function GI_BR.GI_BR_C.ClearAllItems
	void EventSteamInvetoryReady(struct FSteamInventoryResultReady& Data); // Function GI_BR.GI_BR_C.EventSteamInvetoryReady
	void AddOnItemsRecievedNotice(struct APlayerController* PC, struct TArray<struct FST_SteamItem>& Item); // Function GI_BR.GI_BR_C.AddOnItemsRecievedNotice
	void OnNewItem(struct FST_SteamItem Value); // Function GI_BR.GI_BR_C.OnNewItem
	void OpenLootCrateTemp(bool GoldenCrate?); // Function GI_BR.GI_BR_C.OpenLootCrateTemp
	void CorrectChosenCosmetics(); // Function GI_BR.GI_BR_C.CorrectChosenCosmetics
	void HostGame(char E_GameMode GameMode, bool Bots, struct FString Password, struct FString Name); // Function GI_BR.GI_BR_C.HostGame
	void Consume Steam Item(int32_t ID); // Function GI_BR.GI_BR_C.Consume Steam Item
	void WipeAccont(); // Function GI_BR.GI_BR_C.WipeAccont
	void ResetLeaderboards(); // Function GI_BR.GI_BR_C.ResetLeaderboards
	void Get Rid Of Cheaters(int32_t player level); // Function GI_BR.GI_BR_C.Get Rid Of Cheaters
	void DelayedLobbyLeave(struct FSteamID Lobby, float Delay); // Function GI_BR.GI_BR_C.DelayedLobbyLeave
	void MarkItemAsUndiscovered(struct FString CosmeticItemName); // Function GI_BR.GI_BR_C.MarkItemAsUndiscovered
	void OnReceivedCustomSprayItem(struct FST_SteamItem TargetSprayItem); // Function GI_BR.GI_BR_C.OnReceivedCustomSprayItem
	void Upload to Global Players Leaderbard(); // Function GI_BR.GI_BR_C.Upload to Global Players Leaderbard
	void OpenTierBag(char E_Tier Tier); // Function GI_BR.GI_BR_C.OpenTierBag
	void ForceUpdateSteamItems(); // Function GI_BR.GI_BR_C.ForceUpdateSteamItems
	void MuffleSound(float Duration); // Function GI_BR.GI_BR_C.MuffleSound
	void ReceiveInit(); // Function GI_BR.GI_BR_C.ReceiveInit
	void ApplyResolutionSettings(struct FST_VideoSettings& VideoSettings); // Function GI_BR.GI_BR_C.ApplyResolutionSettings
	void BeginLoadingScreen(struct FString MapName); // Function GI_BR.GI_BR_C.BeginLoadingScreen
	void EndLoadingScreen(struct UWorld* World); // Function GI_BR.GI_BR_C.EndLoadingScreen
	void ExecuteUbergraph_GI_BR(int32_t EntryPoint); // Function GI_BR.GI_BR_C.ExecuteUbergraph_GI_BR
	void E_OnNewItem__DelegateSignature(struct FST_SteamItem Value); // Function GI_BR.GI_BR_C.E_OnNewItem__DelegateSignature
	void NewEventDispatcher_0__DelegateSignature(); // Function GI_BR.GI_BR_C.NewEventDispatcher_0__DelegateSignature
	void OnPlayerSettingsChanged__DelegateSignature(struct FST_PlayerSettings New Settings); // Function GI_BR.GI_BR_C.OnPlayerSettingsChanged__DelegateSignature
	void OnItemUpdate__DelegateSignature(); // Function GI_BR.GI_BR_C.OnItemUpdate__DelegateSignature
}; 



