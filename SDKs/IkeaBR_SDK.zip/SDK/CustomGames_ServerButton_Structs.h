#pragma once 
#include "SDK.h" 
 
 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_2
// Size: 0x72(Inherited: 0x0) 
struct FGetText_2
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct TArray<struct FSessionPropertyKeyPair> CallFunc_GetExtraSettings_ExtraSettings;  // 0x18(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x28(0x18)
	uint8_t  CallFunc_GetSessionPropertyString_SearchResult;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString CallFunc_GetSessionPropertyString_SettingValue;  // 0x48(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x58(0x18)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x71(0x1)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.ExecuteUbergraph_CustomGames_ServerButton
// Size: 0xB8(Inherited: 0x0) 
struct FExecuteUbergraph_CustomGames_ServerButton
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsDev_Value : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	struct TArray<struct FSessionPropertyKeyPair> CallFunc_GetExtraSettings_ExtraSettings;  // 0x20(0x10)
	struct UJoinSessionCallbackProxy* CallFunc_JoinSession_ReturnValue;  // 0x30(0x8)
	uint8_t  CallFunc_GetSessionPropertyString_SearchResult;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString CallFunc_GetSessionPropertyString_SettingValue;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_StringIsEmpty_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x53(0x1)
	char pad_84[4];  // 0x54(0x4)
	struct UCustomGames_EnterPassword_C* CallFunc_Create_ReturnValue;  // 0x58(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x60(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x70(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x80(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0xA8(0x10)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_1
// Size: 0x18(Inherited: 0x0) 
struct FGetText_1
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetVisibility_1
// Size: 0x6(Inherited: 0x0) 
struct FGetVisibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x4(0x1)
	uint8_t  K2Node_Select_Default;  // 0x5(0x1)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_3
// Size: 0x98(Inherited: 0x0) 
struct FGetText_3
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TArray<struct FSessionPropertyKeyPair> CallFunc_GetExtraSettings_ExtraSettings;  // 0x20(0x10)
	uint8_t  CallFunc_GetSessionPropertyString_SearchResult;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_GetSessionPropertyString_SettingValue;  // 0x38(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x48(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x60(0x18)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct FText K2Node_Select_Default;  // 0x80(0x18)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_4
// Size: 0x100(Inherited: 0x0) 
struct FGetText_4
{
	struct FText ReturnValue;  // 0x0(0x18)
	int32_t CallFunc_GetMaxPlayersInMatch_Count;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x20(0x10)
	struct FST_ServerMatchmakingTags CallFunc_DeserializeMatchmakingTags_Tags;  // 0x30(0x38)
	struct TArray<struct FSessionPropertyKeyPair> CallFunc_GetExtraSettings_ExtraSettings;  // 0x68(0x10)
	uint8_t  CallFunc_GetSessionPropertyInt_SearchResult;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_GetSessionPropertyInt_SettingValue;  // 0x7C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x80(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)
	struct FString CallFunc_SelectString_ReturnValue;  // 0xA8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xB8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0xC8(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0xD8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xE8(0x18)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_5
// Size: 0x80(Inherited: 0x0) 
struct FGetText_5
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_GetPingInMs_ReturnValue;  // 0x1C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString K2Node_Select_Default;  // 0x48(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x58(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x68(0x18)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_6
// Size: 0x158(Inherited: 0x0) 
struct FGetText_6
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString Temp_string_Variable;  // 0x18(0x10)
	struct FString Temp_string_Variable_2;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Temp_bool_Variable : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString Temp_string_Variable_3;  // 0x40(0x10)
	struct FString Temp_string_Variable_4;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct TArray<struct FSessionPropertyKeyPair> CallFunc_GetExtraSettings_ExtraSettings;  // 0x68(0x10)
	struct FST_ServerMatchmakingTags CallFunc_DeserializeMatchmakingTags_Tags;  // 0x78(0x38)
	uint8_t  CallFunc_GetSessionPropertyBool_SearchResult;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_GetSessionPropertyBool_SettingValue : 1;  // 0xB1(0x1)
	char pad_178[6];  // 0xB2(0x6)
	struct FString K2Node_Select_Default;  // 0xB8(0x10)
	struct FString K2Node_Select_Default_2;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xE0(0x10)
	uint8_t  CallFunc_GetSessionPropertyByte_SearchResult;  // 0xF0(0x1)
	char CallFunc_GetSessionPropertyByte_SettingValue;  // 0xF1(0x1)
	char pad_242[6];  // 0xF2(0x6)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xF8(0x18)
	char CallFunc_GetValidValue_ReturnValue;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x111(0x1)
	char pad_274[6];  // 0x112(0x6)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x118(0x10)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_IsValidSession_ReturnValue : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x130(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x140(0x18)

}; 
// Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetVisibility_2
// Size: 0x32(Inherited: 0x0) 
struct FGetVisibility_2
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValidSession_ReturnValue : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct TArray<struct FSessionPropertyKeyPair> CallFunc_GetExtraSettings_ExtraSettings;  // 0x8(0x10)
	uint8_t  CallFunc_GetSessionPropertyString_SearchResult;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString CallFunc_GetSessionPropertyString_SettingValue;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_StringIsEmpty_ReturnValue : 1;  // 0x31(0x1)

}; 
