#pragma once 
#include <C_PlayerLoot_Structs.h>
 
 
 
// BlueprintGeneratedClass C_PlayerLoot.C_PlayerLoot_C
// Size: 0xC0(Inherited: 0xB0) 
struct UC_PlayerLoot_C : public UActorComponent
{
	struct TArray<struct FST_RandomDeck> Decks;  // 0xB0(0x10)

	void ShuffleNewDeck(struct FString DeckName, struct TArray<char E_Tier>& RarityTypes, struct TMap<char E_Tier, int32_t> RarityWeightMap); // Function C_PlayerLoot.C_PlayerLoot_C.ShuffleNewDeck
	void GetRandomRarity(struct FString DeckName, struct TArray<char E_Tier>& Types, struct TMap<char E_Tier, int32_t> RarityWeights, char E_Tier& Rarity); // Function C_PlayerLoot.C_PlayerLoot_C.GetRandomRarity
}; 



