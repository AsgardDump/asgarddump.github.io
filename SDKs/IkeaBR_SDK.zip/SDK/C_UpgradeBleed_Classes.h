#pragma once 
#include <C_UpgradeBleed_Structs.h>
 
 
 
// BlueprintGeneratedClass C_UpgradeBleed.C_UpgradeBleed_C
// Size: 0x110(Inherited: 0x108) 
struct UC_UpgradeBleed_C : public UC_WeaponUpgrade_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x108(0x8)

	void ReceiveTick(float DeltaSeconds); // Function C_UpgradeBleed.C_UpgradeBleed_C.ReceiveTick
	void Attack_Event(struct AFirstPersonCharacter_C* Hit, float Damage); // Function C_UpgradeBleed.C_UpgradeBleed_C.Attack_Event
	void ReceiveBeginPlay(); // Function C_UpgradeBleed.C_UpgradeBleed_C.ReceiveBeginPlay
	void ExecuteUbergraph_C_UpgradeBleed(int32_t EntryPoint); // Function C_UpgradeBleed.C_UpgradeBleed_C.ExecuteUbergraph_C_UpgradeBleed
}; 



