#pragma once 
#include <C_ROE_SpawnController_Structs.h>
 
 
 
// BlueprintGeneratedClass C_ROE_SpawnController.C_ROE_SpawnController_C
// Size: 0xD2(Inherited: 0xB0) 
struct UC_ROE_SpawnController_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	int32_t DefaultCountdownTime;  // 0xB8(0x4)
	int32_t CurrentCountdownTime;  // 0xBC(0x4)
	struct TArray<struct ABP_ROE_SpawnPawn_C*> SpawnedROE;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool SpawnByPlayerStarts : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool DebugMode : 1;  // 0xD1(0x1)

	void GetOverlappingPlayerStarts(struct ABP_SpawnZone_C* zone, struct TArray<struct AAI_Start_C*>& Player Starts); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.GetOverlappingPlayerStarts
	void SpawnPlayersByRandomPoint(); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.SpawnPlayersByRandomPoint
	void GenASpawnMap(struct TMap<struct APlayerBRController_C*, struct APlayerStart*>& Spawns); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.GenASpawnMap
	void StartSpawning(struct AGM_BR_C* GameMode); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.StartSpawning
	void ShowAllSpawnZones(bool Show?); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.ShowAllSpawnZones
	void StartCountdown(); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.StartCountdown
	void FinishUpSpawning(); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.FinishUpSpawning
	void StartTheGame(struct TMap<struct APlayerBRController_C*, struct APlayerStart*> PCToPlayerStart); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.StartTheGame
	void TrySetupTeammates(); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.TrySetupTeammates
	void SpawnController(struct APlayerBRController_C* Target); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.SpawnController
	void ExecuteUbergraph_C_ROE_SpawnController(int32_t EntryPoint); // Function C_ROE_SpawnController.C_ROE_SpawnController_C.ExecuteUbergraph_C_ROE_SpawnController
}; 



