#pragma once 
#include <DistanceToTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass DistanceToTarget.DistanceToTarget_C
// Size: 0xF8(Inherited: 0x98) 
struct UDistanceToTarget_C : public UBTService_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x98(0x8)
	struct FBlackboardKeySelector Target;  // 0xA0(0x28)
	float Radius;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct FBlackboardKeySelector Bool;  // 0xD0(0x28)

	void ReceiveActivationAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function DistanceToTarget.DistanceToTarget_C.ReceiveActivationAI
	void ReceiveTick(struct AActor* OwnerActor, float DeltaSeconds); // Function DistanceToTarget.DistanceToTarget_C.ReceiveTick
	void ExecuteUbergraph_DistanceToTarget(int32_t EntryPoint); // Function DistanceToTarget.DistanceToTarget_C.ExecuteUbergraph_DistanceToTarget
}; 



