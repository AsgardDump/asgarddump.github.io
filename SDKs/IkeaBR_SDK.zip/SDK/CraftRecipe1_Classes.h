#pragma once 
#include <CraftRecipe1_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CraftRecipe1.CraftRecipe1_C
// Size: 0x2E2(Inherited: 0x260) 
struct UCraftRecipe1_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UBorder* Border_131;  // 0x268(0x8)
	struct UButton* Button_61;  // 0x270(0x8)
	struct UImage* Image;  // 0x278(0x8)
	struct UImage* Image_43;  // 0x280(0x8)
	struct UOverlay* Overlay_39;  // 0x288(0x8)
	struct URR_ProgressBar_Plain_C* RR_ProgressBar_Plain_C_130;  // 0x290(0x8)
	struct USizeBox* SizeBox_50;  // 0x298(0x8)
	struct FST_CraftRecipe Recipe;  // 0x2A0(0x28)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool Selected : 1;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)
	struct UCraftingMenu2_C* Parent;  // 0x2D0(0x8)
	float Anglelow;  // 0x2D8(0x4)
	float AngleHigh;  // 0x2DC(0x4)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool CanCraft : 1;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool Valid : 1;  // 0x2E1(0x1)

	struct FLinearColor GetFillColorAndOpacity_1(); // Function CraftRecipe1.CraftRecipe1_C.GetFillColorAndOpacity_1
	float GetPercent_1(); // Function CraftRecipe1.CraftRecipe1_C.GetPercent_1
	uint8_t  GetVisibility_1(); // Function CraftRecipe1.CraftRecipe1_C.GetVisibility_1
	struct FLinearColor Get_Outline_ColorAndOpacity_1(); // Function CraftRecipe1.CraftRecipe1_C.Get_Outline_ColorAndOpacity_1
	struct FSlateBrush GetBrush_1(); // Function CraftRecipe1.CraftRecipe1_C.GetBrush_1
	bool GetbIsEnabled_1(); // Function CraftRecipe1.CraftRecipe1_C.GetbIsEnabled_1
	struct FLinearColor GetBrushColor_1(); // Function CraftRecipe1.CraftRecipe1_C.GetBrushColor_1
	struct FText GetText_1(); // Function CraftRecipe1.CraftRecipe1_C.GetText_1
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function CraftRecipe1.CraftRecipe1_C.Tick
	void Construct(); // Function CraftRecipe1.CraftRecipe1_C.Construct
	void Click(); // Function CraftRecipe1.CraftRecipe1_C.Click
	void Destruct(); // Function CraftRecipe1.CraftRecipe1_C.Destruct
	void ExecuteUbergraph_CraftRecipe1(int32_t EntryPoint); // Function CraftRecipe1.CraftRecipe1_C.ExecuteUbergraph_CraftRecipe1
}; 



