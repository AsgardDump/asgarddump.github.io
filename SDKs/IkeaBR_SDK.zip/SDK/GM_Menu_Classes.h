#pragma once 
#include <GM_Menu_Structs.h>
 
 
 
// BlueprintGeneratedClass GM_Menu.GM_Menu_C
// Size: 0x2C8(Inherited: 0x2C0) 
struct AGM_Menu_C : public AGameModeBase
{
	struct USceneComponent* DefaultSceneRoot;  // 0x2C0(0x8)

}; 



