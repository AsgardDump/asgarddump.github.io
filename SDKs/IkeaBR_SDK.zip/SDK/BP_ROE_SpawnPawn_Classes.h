#pragma once 
#include <BP_ROE_SpawnPawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C
// Size: 0x320(Inherited: 0x280) 
struct ABP_ROE_SpawnPawn_C : public APawn
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UAudioComponent* Wind;  // 0x288(0x8)
	struct USphereComponent* Sphere;  // 0x290(0x8)
	struct UCameraComponent* Camera;  // 0x298(0x8)
	struct TArray<struct AActor*> HiddenActors;  // 0x2A0(0x10)
	struct FVector MoveVelocity;  // 0x2B0(0xC)
	float MoveSpeed;  // 0x2BC(0x4)
	float Drag;  // 0x2C0(0x4)
	float MaxSpeed;  // 0x2C4(0x4)
	struct ABP_SpawnZone_C* CurrentlyHoveredSpawnZone;  // 0x2C8(0x8)
	struct FLinearColor SpawnZoneDefaultColor;  // 0x2D0(0x10)
	struct FLinearColor SpawnZoneHoveredColor;  // 0x2E0(0x10)
	struct ABP_SpawnZone_C* SelectedSpawnZone;  // 0x2F0(0x8)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool CanSelectZone : 1;  // 0x2F8(0x1)
	char pad_761[7];  // 0x2F9(0x7)
	struct UW_ROE_HUD_C* ROE_HUD;  // 0x300(0x8)
	struct ABP_ROE_SpawnPawn_C* TeammatePawn;  // 0x308(0x8)
	struct FLinearColor SpawnZoneUnavailableColor;  // 0x310(0x10)

	void PC(struct APlayerBRController_C*& AsPlayer BRController); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.PC
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_1
	void ReceiveBeginPlay(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.ReceiveBeginPlay
	void ActuallyStart(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.ActuallyStart
	void HideCeiling(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.HideCeiling
	void ReceiveTick(float DeltaSeconds); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.ReceiveTick
	void CalcMoveForward(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.CalcMoveForward
	void CalcMoveRight(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.CalcMoveRight
	void ScanForHoveredZone(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.ScanForHoveredZone
	void MovementTick(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.MovementTick
	void SelectASpawnZone(struct ABP_SpawnZone_C* zone); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.SelectASpawnZone
	void Server_SelectZone(struct ABP_SpawnZone_C* zone); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.Server_SelectZone
	void FinishUp(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.FinishUp
	void ReceiveDestroyed(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.ReceiveDestroyed
	void ShowCeiling(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.ShowCeiling
	void Add Arrow Text ("YOU", "TEAMMATE")(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.Add Arrow Text ("YOU", "TEAMMATE")
	void SetZoneUnavailable(); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.SetZoneUnavailable
	void ExecuteUbergraph_BP_ROE_SpawnPawn(int32_t EntryPoint); // Function BP_ROE_SpawnPawn.BP_ROE_SpawnPawn_C.ExecuteUbergraph_BP_ROE_SpawnPawn
}; 



