#pragma once 
#include <BP_RecurveBow_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RecurveBow.BP_RecurveBow_C
// Size: 0x2CD(Inherited: 0x2CD) 
struct ABP_RecurveBow_C : public ABP_Bow_Base_C
{

}; 



