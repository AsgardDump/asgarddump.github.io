#pragma once 
#include <C_AntiCheat_Structs.h>
 
 
 
// BlueprintGeneratedClass C_AntiCheat.C_AntiCheat_C
// Size: 0xE4(Inherited: 0xB0) 
struct UC_AntiCheat_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct AFirstPersonCharacter_C* Parent;  // 0xB8(0x8)
	int32_t Const_MaxIllegalShots;  // 0xC0(0x4)
	int32_t LastSlot;  // 0xC4(0x4)
	int32_t CurrentIllegalShots;  // 0xC8(0x4)
	int32_t MaxIllegalGap;  // 0xCC(0x4)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool Server_HasAntiCheatOn? : 1;  // 0xD0(0x1)
	char pad_209[3];  // 0xD1(0x3)
	float Server_IllegalKillRate;  // 0xD4(0x4)
	float Server_IllegalDamageRate;  // 0xD8(0x4)
	int32_t Server_IllegalXP;  // 0xDC(0x4)
	float Server_IllegalFOV;  // 0xE0(0x4)

	void OnFailure_BC1D563A4F2D1F2C47CD26A594CDF8EA(); // Function C_AntiCheat.C_AntiCheat_C.OnFailure_BC1D563A4F2D1F2C47CD26A594CDF8EA
	void OnSuccess_BC1D563A4F2D1F2C47CD26A594CDF8EA(); // Function C_AntiCheat.C_AntiCheat_C.OnSuccess_BC1D563A4F2D1F2C47CD26A594CDF8EA
	void ServerValidateShot(int32_t Slot, int32_t ClientAmmo); // Function C_AntiCheat.C_AntiCheat_C.ServerValidateShot
	void Kick(); // Function C_AntiCheat.C_AntiCheat_C.Kick
	void ReceiveBeginPlay(); // Function C_AntiCheat.C_AntiCheat_C.ReceiveBeginPlay
	void ClientValidateShot(int32_t SlotForItemAmmo); // Function C_AntiCheat.C_AntiCheat_C.ClientValidateShot
	void MakeSureAntiCheatIsEnabled(); // Function C_AntiCheat.C_AntiCheat_C.MakeSureAntiCheatIsEnabled
	void ServerSetHasAntiCheatOn(bool Client_HasAntiCheatOn?); // Function C_AntiCheat.C_AntiCheat_C.ServerSetHasAntiCheatOn
	void ServerVerifyAntiCheatStatus(bool Status); // Function C_AntiCheat.C_AntiCheat_C.ServerVerifyAntiCheatStatus
	void ServerValidateCurrentStats(); // Function C_AntiCheat.C_AntiCheat_C.ServerValidateCurrentStats
	void ReceiveTick(float DeltaSeconds); // Function C_AntiCheat.C_AntiCheat_C.ReceiveTick
	void ServerKickAndBan(); // Function C_AntiCheat.C_AntiCheat_C.ServerKickAndBan
	void ClientVerifyStatus(); // Function C_AntiCheat.C_AntiCheat_C.ClientVerifyStatus
	void ExecuteUbergraph_C_AntiCheat(int32_t EntryPoint); // Function C_AntiCheat.C_AntiCheat_C.ExecuteUbergraph_C_AntiCheat
}; 



