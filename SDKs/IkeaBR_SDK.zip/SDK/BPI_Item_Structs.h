#pragma once 
#include "SDK.h" 
 
 
// Function BPI_Item.BPI_Item_C.LMB
// Size: 0x1(Inherited: 0x0) 
struct FLMB
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
// Function BPI_Item.BPI_Item_C.LMB_Pure
// Size: 0x1(Inherited: 0x0) 
struct FLMB_Pure
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
