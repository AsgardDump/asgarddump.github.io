#pragma once 
#include <C_BattleRoyale_Structs.h>
 
 
 
// BlueprintGeneratedClass C_BattleRoyale.C_BattleRoyale_C
// Size: 0x110(Inherited: 0xB0) 
struct UC_BattleRoyale_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct FMulticastInlineDelegate UpdateZone;  // 0xB8(0x10)
	float StartZoneSize;  // 0xC8(0x4)
	int32_t Stage1 Time;  // 0xCC(0x4)
	int32_t Stage2 Time;  // 0xD0(0x4)
	int32_t Stage3 Time (Old);  // 0xD4(0x4)
	int32_t TotalMatchTime;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)
	struct ADarkZone_C* zone;  // 0xE0(0x8)
	int32_t CurrectStageIndex;  // 0xE8(0x4)
	int32_t AirdropTime_2;  // 0xEC(0x4)
	float DebugTimeMultiplier;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool DebugMode : 1;  // 0xF4(0x1)
	char pad_245_1 : 7;  // 0xF5(0x1)
	bool SpawnBlueprints : 1;  // 0xF5(0x1)
	char pad_246[2];  // 0xF6(0x2)
	int32_t AirdropTime_3;  // 0xF8(0x4)
	int32_t AirdropTime_4;  // 0xFC(0x4)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool RemoveCenterDismantleStations : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool ScaleMatchTimeToPlayerCount : 1;  // 0x101(0x1)
	char pad_258_1 : 7;  // 0x102(0x1)
	bool LootSpotWorkbenches? : 1;  // 0x102(0x1)
	char pad_259[5];  // 0x103(0x5)
	struct ABP_DazGlobalIntercom_C* DazIntercom;  // 0x108(0x8)

	void PlayZoneShrinkVoiceline(); // Function C_BattleRoyale.C_BattleRoyale_C.PlayZoneShrinkVoiceline
	void FuncScaleMatchTime(); // Function C_BattleRoyale.C_BattleRoyale_C.FuncScaleMatchTime
	void UpdateTime(int32_t new time); // Function C_BattleRoyale.C_BattleRoyale_C.UpdateTime
	void Begin(); // Function C_BattleRoyale.C_BattleRoyale_C.Begin
	void ReceiveBeginPlay(); // Function C_BattleRoyale.C_BattleRoyale_C.ReceiveBeginPlay
	void ScaleMatchTime(); // Function C_BattleRoyale.C_BattleRoyale_C.ScaleMatchTime
	void LootSpotWorkbenches(); // Function C_BattleRoyale.C_BattleRoyale_C.LootSpotWorkbenches
	void ExecuteUbergraph_C_BattleRoyale(int32_t EntryPoint); // Function C_BattleRoyale.C_BattleRoyale_C.ExecuteUbergraph_C_BattleRoyale
	void UpdateZone__DelegateSignature(float Size); // Function C_BattleRoyale.C_BattleRoyale_C.UpdateZone__DelegateSignature
}; 



