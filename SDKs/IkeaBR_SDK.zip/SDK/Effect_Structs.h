#pragma once 
#include "SDK.h" 
 
 
// Function Effect.Effect_C.GetText_1
// Size: 0x98(Inherited: 0x0) 
struct FGetText_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString Temp_string_Variable;  // 0x20(0x10)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x50(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x60(0x10)
	struct FString K2Node_Select_Default;  // 0x70(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x80(0x18)

}; 
// Function Effect.Effect_C.ExecuteUbergraph_Effect
// Size: 0x44(Inherited: 0x0) 
struct FExecuteUbergraph_Effect
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x4(0x38)
	float K2Node_Event_InDeltaTime;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x41(0x1)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x42(0x1)
	char pad_67_1 : 7;  // 0x43(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x43(0x1)

}; 
// Function Effect.Effect_C.GetPercent_1
// Size: 0x10(Inherited: 0x0) 
struct FGetPercent_1
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x8(0x4)
	float K2Node_Select_Default;  // 0xC(0x4)

}; 
// Function Effect.Effect_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function Effect.Effect_C.GetBrush_1
// Size: 0x120(Inherited: 0x0) 
struct FGetBrush_1
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool Temp_bool_Variable : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct UObject* K2Node_Select_Default;  // 0x90(0x8)
	struct FSlateBrush K2Node_MakeStruct_SlateBrush;  // 0x98(0x88)

}; 
// Function Effect.Effect_C.GetFillColorAndOpacity_1
// Size: 0x24(Inherited: 0x0) 
struct FGetFillColorAndOpacity_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	struct FLinearColor K2Node_Select_Default;  // 0x14(0x10)

}; 
