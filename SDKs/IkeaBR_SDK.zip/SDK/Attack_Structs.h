#pragma once 
#include "SDK.h" 
 
 
// Function Attack.Attack_C.ExecuteUbergraph_Attack
// Size: 0x21(Inherited: 0x0) 
struct FExecuteUbergraph_Attack
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct AAI_Bot_C* K2Node_DynamicCast_AsAI_Bot;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
// Function Attack.Attack_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
