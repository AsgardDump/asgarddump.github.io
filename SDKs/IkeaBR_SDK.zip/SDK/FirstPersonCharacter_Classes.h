#pragma once 
#include <FirstPersonCharacter_Structs.h>
 
 
 
// BlueprintGeneratedClass FirstPersonCharacter.FirstPersonCharacter_C
// Size: 0x15C0(Inherited: 0x4D0) 
struct AFirstPersonCharacter_C : public AMyCharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4D0(0x8)
	struct UC_PlayerAntiTeaming_C* C_PlayerAntiTeaming;  // 0x4D8(0x8)
	struct UC_PlayerCompass_C* C_PlayerCompass;  // 0x4E0(0x8)
	struct UAudioComponent* Whoosh;  // 0x4E8(0x8)
	struct UC_RandomDeckManager_C* C_RandomDeckManager;  // 0x4F0(0x8)
	struct UC_PlayerLoot_C* C_PlayerLoot;  // 0x4F8(0x8)
	struct UAudioComponent* HeartBeat;  // 0x500(0x8)
	struct UBoxComponent* PropPivotBox;  // 0x508(0x8)
	struct USpringArmComponent* PropPivotSpring;  // 0x510(0x8)
	struct UC_AntiCheat_C* C_AntiCheat;  // 0x518(0x8)
	struct UPhysicalAnimationComponent* PhysicalAnimation;  // 0x520(0x8)
	struct UAudioComponent* GeneralAudio;  // 0x528(0x8)
	struct UReplicatedMeshes_C* RM_Arrows;  // 0x530(0x8)
	struct UReplicatedMeshes_C* RM_ConstAttachments;  // 0x538(0x8)
	struct UReplicatedSounds_C* ReplicatedSounds;  // 0x540(0x8)
	struct UPlayerStats_Component_C* PlayerStats_Component;  // 0x548(0x8)
	struct UCapsuleComponent* DoorCollider;  // 0x550(0x8)
	struct UAudioComponent* VoidAudio;  // 0x558(0x8)
	struct UVoipAudioComponent* VoipAudio;  // 0x560(0x8)
	struct UVoipManagerComponent* VoipManager;  // 0x568(0x8)
	struct UAudioComponent* Charge_Cue(Deprecated);  // 0x570(0x8)
	struct USceneComponent* Spectator;  // 0x578(0x8)
	struct UAIPerceptionStimuliSourceComponent* AIPerceptionStimuliSource;  // 0x580(0x8)
	struct UParticleSystemComponent* Dust;  // 0x588(0x8)
	struct UChildActorComponent* EquipedActor;  // 0x590(0x8)
	struct UCapsuleComponent* ItemTrace;  // 0x598(0x8)
	struct UCameraComponent* FirstPersonCamera;  // 0x5A0(0x8)
	float DamageEffectTimeline_NewTrack_0_3889E3994235F86EE15D01830AF0F895;  // 0x5A8(0x4)
	char ETimelineDirection DamageEffectTimeline__Direction_3889E3994235F86EE15D01830AF0F895;  // 0x5AC(0x1)
	char pad_1453[3];  // 0x5AD(0x3)
	struct UTimelineComponent* DamageEffectTimeline;  // 0x5B0(0x8)
	float Spread_Curve_Back_Spread_3240CF6E4F4400B12FF8D1AEAE082519;  // 0x5B8(0x4)
	char ETimelineDirection Spread_Curve_Back__Direction_3240CF6E4F4400B12FF8D1AEAE082519;  // 0x5BC(0x1)
	char pad_1469[3];  // 0x5BD(0x3)
	struct UTimelineComponent* Spread Curve Back;  // 0x5C0(0x8)
	float Spread_curve_Spread_F7CB7C9A4723F6B295229882C19216FC;  // 0x5C8(0x4)
	char ETimelineDirection Spread_curve__Direction_F7CB7C9A4723F6B295229882C19216FC;  // 0x5CC(0x1)
	char pad_1485[3];  // 0x5CD(0x3)
	struct UTimelineComponent* Spread curve;  // 0x5D0(0x8)
	float RecoilCurve_NewTrack_0_0E79061E46DA1285B0C354910D7F3D0C;  // 0x5D8(0x4)
	char ETimelineDirection RecoilCurve__Direction_0E79061E46DA1285B0C354910D7F3D0C;  // 0x5DC(0x1)
	char pad_1501[3];  // 0x5DD(0x3)
	struct UTimelineComponent* RecoilCurve;  // 0x5E0(0x8)
	float Blur_NewTrack_0_7C10680C42804F6544BB359CBD12C84E;  // 0x5E8(0x4)
	char ETimelineDirection Blur__Direction_7C10680C42804F6544BB359CBD12C84E;  // 0x5EC(0x1)
	char pad_1517[3];  // 0x5ED(0x3)
	struct UTimelineComponent* Blur;  // 0x5F0(0x8)
	struct AMovable_Object_Replicated_C* GrabbedObject;  // 0x5F8(0x8)
	struct TArray<struct FST_ItemBase> Inventory;  // 0x600(0x10)
	int32_t SelectedInventorySlot;  // 0x610(0x4)
	float Health;  // 0x614(0x4)
	float MouseAlpha;  // 0x618(0x4)
	float AttackDelay;  // 0x61C(0x4)
	char pad_1568_1 : 7;  // 0x620(0x1)
	bool Sprinting? : 1;  // 0x620(0x1)
	char pad_1569_1 : 7;  // 0x621(0x1)
	bool Stunned : 1;  // 0x621(0x1)
	char pad_1570_1 : 7;  // 0x622(0x1)
	bool Blocking : 1;  // 0x622(0x1)
	char pad_1571[1];  // 0x623(0x1)
	float SpineRotationX;  // 0x624(0x4)
	float Stamina;  // 0x628(0x4)
	float StaminaGainPerSecond;  // 0x62C(0x4)
	float StaminaBuffer;  // 0x630(0x4)
	int32_t Wood;  // 0x634(0x4)
	int32_t Metal;  // 0x638(0x4)
	int32_t Binder;  // 0x63C(0x4)
	char pad_1600_1 : 7;  // 0x640(0x1)
	bool LMBD : 1;  // 0x640(0x1)
	char pad_1601[3];  // 0x641(0x3)
	float DamageMultiplier;  // 0x644(0x4)
	float Sensitivity;  // 0x648(0x4)
	char pad_1612[4];  // 0x64C(0x4)
	struct ABP_ItemPickup_C* FocusedItemPickup;  // 0x650(0x8)
	char pad_1624_1 : 7;  // 0x658(0x1)
	bool Charging : 1;  // 0x658(0x1)
	char pad_1625[7];  // 0x659(0x7)
	struct TArray<struct FST_CraftRecipe> Recipies;  // 0x660(0x10)
	char pad_1648_1 : 7;  // 0x670(0x1)
	bool XkeyDown? : 1;  // 0x670(0x1)
	char pad_1649_1 : 7;  // 0x671(0x1)
	bool Interacting : 1;  // 0x671(0x1)
	char pad_1650[14];  // 0x672(0xE)
	struct FPostProcessSettings DefaultPostProcess;  // 0x680(0x560)
	float ArmourIncomingDamageMultiplier;  // 0xBE0(0x4)
	float ArmourHealth;  // 0xBE4(0x4)
	char pad_3048_1 : 7;  // 0xBE8(0x1)
	bool Throwing? : 1;  // 0xBE8(0x1)
	char pad_3049[7];  // 0xBE9(0x7)
	struct UAnimSequenceBase* idleAnim;  // 0xBF0(0x8)
	struct UAnimSequenceBase* ChargeAnim;  // 0xBF8(0x8)
	struct UAnimSequenceBase* BlockAnim;  // 0xC00(0x8)
	struct TArray<struct UWidgetComponent*> HitWidgets;  // 0xC08(0x10)
	struct FST_ItemBase FistItem;  // 0xC18(0x90)
	char pad_3240_1 : 7;  // 0xCA8(0x1)
	bool RMBD : 1;  // 0xCA8(0x1)
	char pad_3241[3];  // 0xCA9(0x3)
	float MaxWalkSpeed;  // 0xCAC(0x4)
	float MaxSprintSpeed;  // 0xCB0(0x4)
	float ForwardAxis;  // 0xCB4(0x4)
	float RightAxis;  // 0xCB8(0x4)
	char pad_3260_1 : 7;  // 0xCBC(0x1)
	bool ShiftDown : 1;  // 0xCBC(0x1)
	char pad_3261[3];  // 0xCBD(0x3)
	struct FST_PlayerRepInfo Info;  // 0xCC0(0x38)
	struct TArray<struct ABP_Effect_C*> Effects;  // 0xCF8(0x10)
	float ConstDamageMultiplier;  // 0xD08(0x4)
	char pad_3340_1 : 7;  // 0xD0C(0x1)
	bool CanMoveFurniture : 1;  // 0xD0C(0x1)
	char pad_3341_1 : 7;  // 0xD0D(0x1)
	bool Crouched : 1;  // 0xD0D(0x1)
	char pad_3342[2];  // 0xD0E(0x2)
	float CrouchSpeed;  // 0xD10(0x4)
	char pad_3348[4];  // 0xD14(0x4)
	struct FMulticastInlineDelegate OnEquip;  // 0xD18(0x10)
	char pad_3368_1 : 7;  // 0xD28(0x1)
	bool MoveIfStunned : 1;  // 0xD28(0x1)
	char pad_3369_1 : 7;  // 0xD29(0x1)
	bool CanMoveHeavyFurniture : 1;  // 0xD29(0x1)
	char pad_3370[6];  // 0xD2A(0x6)
	struct FMulticastInlineDelegate OnMeleeHit;  // 0xD30(0x10)
	struct TArray<struct UC_Upgrade_C*> CurrentUpgrades;  // 0xD40(0x10)
	struct TArray<struct UDecalComponent*> BloodStains;  // 0xD50(0x10)
	struct AFirstPersonCharacter_C* LastAttacker;  // 0xD60(0x8)
	struct FMulticastInlineDelegate OnClick;  // 0xD68(0x10)
	char pad_3448_1 : 7;  // 0xD78(0x1)
	bool CanSprint : 1;  // 0xD78(0x1)
	char pad_3449[7];  // 0xD79(0x7)
	struct TArray<struct UStaticMeshComponent*> AttachedSockets;  // 0xD80(0x10)
	char pad_3472_1 : 7;  // 0xD90(0x1)
	bool Talking? : 1;  // 0xD90(0x1)
	char pad_3473_1 : 7;  // 0xD91(0x1)
	bool InWorkbench : 1;  // 0xD91(0x1)
	char pad_3474[2];  // 0xD92(0x2)
	float ConstIncomingDamageMultiplier;  // 0xD94(0x4)
	float Spread;  // 0xD98(0x4)
	float SpreadMultiplier;  // 0xD9C(0x4)
	float BaseSpread;  // 0xDA0(0x4)
	float RadialBlurIntensity;  // 0xDA4(0x4)
	char pad_3496_1 : 7;  // 0xDA8(0x1)
	bool Healing : 1;  // 0xDA8(0x1)
	char pad_3497[7];  // 0xDA9(0x7)
	struct TArray<struct FST_RepCosmetic> Cosmetics_Meshes;  // 0xDB0(0x10)
	struct FMulticastInlineDelegate OnGetHit;  // 0xDC0(0x10)
	struct TArray<struct FName> BloodBones;  // 0xDD0(0x10)
	struct FMulticastInlineDelegate LMB;  // 0xDE0(0x10)
	char pad_3568_1 : 7;  // 0xDF0(0x1)
	bool CanMove : 1;  // 0xDF0(0x1)
	char pad_3569_1 : 7;  // 0xDF1(0x1)
	bool CanCallLMB : 1;  // 0xDF1(0x1)
	char pad_3570[2];  // 0xDF2(0x2)
	struct FVector2D TempVec;  // 0xDF4(0x8)
	float ChargeSpeed;  // 0xDFC(0x4)
	struct TArray<struct FHitResult> LongHits;  // 0xE00(0x10)
	float LongHit_Time;  // 0xE10(0x4)
	float SensitivityMultiplier;  // 0xE14(0x4)
	char pad_3608_1 : 7;  // 0xE18(0x1)
	bool HoldingThrowFurniture : 1;  // 0xE18(0x1)
	char pad_3609[7];  // 0xE19(0x7)
	struct AFirstPersonCharacter_C* Teammate;  // 0xE20(0x8)
	struct TMap<struct FString, struct UTexture2DDynamic*> CustomSpraysCache;  // 0xE28(0x50)
	int32_t SpectatorCount;  // 0xE78(0x4)
	char pad_3708[4];  // 0xE7C(0x4)
	struct TArray<struct FST_CraftRecipe> DefaultRecipies(Read Only);  // 0xE80(0x10)
	struct FMulticastInlineDelegate OnInteractPure;  // 0xE90(0x10)
	struct FString CurrentChargeWidgetTag;  // 0xEA0(0x10)
	char pad_3760_1 : 7;  // 0xEB0(0x1)
	bool GodMode : 1;  // 0xEB0(0x1)
	char pad_3761[3];  // 0xEB1(0x3)
	float HoldingPropStaminaMultipler;  // 0xEB4(0x4)
	char pad_3768_1 : 7;  // 0xEB8(0x1)
	bool EquippedItemRecieveInput : 1;  // 0xEB8(0x1)
	char pad_3769[3];  // 0xEB9(0x3)
	struct FPhysicalAnimationData PhysicalAnimationData;  // 0xEBC(0x24)
	float StaminaMultiplierWhenBlocking;  // 0xEE0(0x4)
	char pad_3812_1 : 7;  // 0xEE4(0x1)
	bool ChampionMode : 1;  // 0xEE4(0x1)
	char pad_3813_1 : 7;  // 0xEE5(0x1)
	bool ShoveButtonDown : 1;  // 0xEE5(0x1)
	char pad_3814_1 : 7;  // 0xEE6(0x1)
	bool Debug_Dead : 1;  // 0xEE6(0x1)
	char pad_3815[1];  // 0xEE7(0x1)
	struct FMulticastInlineDelegate OnStunned;  // 0xEE8(0x10)
	struct FDateTime LastFootstepTime;  // 0xEF8(0x8)
	float SprintingStaminaLossPerTick;  // 0xF00(0x4)
	char pad_3844[4];  // 0xF04(0x4)
	struct USoundBase* LastPlayedFootstep;  // 0xF08(0x8)
	struct AFirstPersonCharacter_C* Tracker_CurrentlyRingingPlayer;  // 0xF10(0x8)
	char pad_3864[8];  // 0xF18(0x8)
	struct FPostProcessSettings PreEffectPostProccessSettings;  // 0xF20(0x560)
	char pad_5248_1 : 7;  // 0x1480(0x1)
	bool InvertMouseY : 1;  // 0x1480(0x1)
	char pad_5249[3];  // 0x1481(0x3)
	float SprintSpeedMultiplier_Stims;  // 0x1484(0x4)
	float SprintSpeedMultiplier_Bolt;  // 0x1488(0x4)
	float BaseMaxSprintSpeed;  // 0x148C(0x4)
	float SprayDelay;  // 0x1490(0x4)
	float DefaultSprayDelay;  // 0x1494(0x4)
	struct FVector TempVelocitySave;  // 0x1498(0xC)
	float SprintSpeedMultiplier_Explosion;  // 0x14A4(0x4)
	struct TArray<struct UStaticMeshComponent*> AttachedItemMeshes;  // 0x14A8(0x10)
	float SinceNoAttackDelay;  // 0x14B8(0x4)
	float TimeToHoldForSlotSwitch;  // 0x14BC(0x4)
	struct FTimerHandle SlotSwitchTimer;  // 0x14C0(0x8)
	char pad_5320_1 : 7;  // 0x14C8(0x1)
	bool IsShowingDarkZoneEffects : 1;  // 0x14C8(0x1)
	char pad_5321[3];  // 0x14C9(0x3)
	int32_t ReplicatedSelectedSlot;  // 0x14CC(0x4)
	struct FTimerHandle Timer_CheckForRing;  // 0x14D0(0x8)
	struct FMulticastInlineDelegate OnDamageSomeone;  // 0x14D8(0x10)
	int32_t BonusKillMetal;  // 0x14E8(0x4)
	int32_t BonusKillBinder;  // 0x14EC(0x4)
	char pad_5360_1 : 7;  // 0x14F0(0x1)
	bool AntiCheatEnabled : 1;  // 0x14F0(0x1)
	char pad_5361[3];  // 0x14F1(0x3)
	float MaxMeleeRange;  // 0x14F4(0x4)
	float MaxRangedRange;  // 0x14F8(0x4)
	float MaxRangedDamage;  // 0x14FC(0x4)
	struct AFirstPersonCharacter_C* FocusedRemotePlayer;  // 0x1500(0x8)
	struct AActor* FocusedInteractable;  // 0x1508(0x8)
	float FocusRadius;  // 0x1510(0x4)
	float FocusLength;  // 0x1514(0x4)
	struct FString CurrentToolTipTag;  // 0x1518(0x10)
	struct FMulticastInlineDelegate OnFocus;  // 0x1528(0x10)
	struct FMulticastInlineDelegate OnLoseFocus;  // 0x1538(0x10)
	float CurrentPropPickupDelay;  // 0x1548(0x4)
	char pad_5452[4];  // 0x154C(0x4)
	struct FMulticastInlineDelegate OnTick;  // 0x1550(0x10)
	float StaminaMultiplierWhenCharging;  // 0x1560(0x4)
	float LastMicLevel;  // 0x1564(0x4)
	struct FRotator LastCameraRotation;  // 0x1568(0xC)
	char pad_5492[12];  // 0x1574(0xC)
	struct FQuat FinalCameraSwayDeltaRot;  // 0x1580(0x10)
	float CameraSwayDrag;  // 0x1590(0x4)
	char pad_5524_1 : 7;  // 0x1594(0x1)
	bool EnableFallDamage : 1;  // 0x1594(0x1)
	char pad_5525[3];  // 0x1595(0x3)
	float FallDamageScale;  // 0x1598(0x4)
	float FallDamageVelocityThreashold;  // 0x159C(0x4)
	float MaxFallDamage;  // 0x15A0(0x4)
	char pad_5540_1 : 7;  // 0x15A4(0x1)
	bool StreamerModeEnabled? : 1;  // 0x15A4(0x1)
	char pad_5541_1 : 7;  // 0x15A5(0x1)
	bool HasRecentlyShoved : 1;  // 0x15A5(0x1)
	char pad_5542[2];  // 0x15A6(0x2)
	float RecentlyShovedTime;  // 0x15A8(0x4)
	char pad_5548[4];  // 0x15AC(0x4)
	struct FMulticastInlineDelegate Reload;  // 0x15B0(0x10)

	void DestroySkeletalMesh(struct USkeletalMeshComponent* Mesh, struct USkeletalMesh*& Out); // Function FirstPersonCharacter.FirstPersonCharacter_C.DestroySkeletalMesh
	void AddSkeletalMesh(struct FName Tag, struct USkeletalMeshComponent*& Mesh); // Function FirstPersonCharacter.FirstPersonCharacter_C.AddSkeletalMesh
	void DestroyStaticMesh(struct UStaticMeshComponent* Mesh, struct UStaticMesh*& Out); // Function FirstPersonCharacter.FirstPersonCharacter_C.DestroyStaticMesh
	void AddStaticMesh(struct FName Tag, struct UStaticMeshComponent*& Mesh); // Function FirstPersonCharacter.FirstPersonCharacter_C.AddStaticMesh
	void RecieveServerLook(bool& Recieve?); // Function FirstPersonCharacter.FirstPersonCharacter_C.RecieveServerLook
	void ShouldReceiveFallDamage(struct FHitResult Hit, bool& Result); // Function FirstPersonCharacter.FirstPersonCharacter_C.ShouldReceiveFallDamage
	void SetStencilForMeshAndCosmetics(bool Render Custom Depth, int32_t Stencil Value); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetStencilForMeshAndCosmetics
	void Add Camera Sway(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Add Camera Sway
	bool CanThrowHeldProp(); // Function FirstPersonCharacter.FirstPersonCharacter_C.CanThrowHeldProp
	void ServerSide_Death(struct AFirstPersonCharacter_C* KIller); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSide_Death
	void KickAndBan(struct AFirstPersonCharacter_C* Player); // Function FirstPersonCharacter.FirstPersonCharacter_C.KickAndBan
	void ApplyFrenzyEffects(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ApplyFrenzyEffects
	void OnRep_Effects(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_Effects
	void IsInteractableActorInFocus(struct AActor* InteractableActor, bool& Value); // Function FirstPersonCharacter.FirstPersonCharacter_C.IsInteractableActorInFocus
	bool InteractionTrace(char ETraceTypeQuery TraceChannel, char EDrawDebugTrace DrawDebugType, struct FHitResult& OutHit); // Function FirstPersonCharacter.FirstPersonCharacter_C.InteractionTrace
	void OnRep_Inventory(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_Inventory
	void OnRep_ReplicatedSelectedSlot(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_ReplicatedSelectedSlot
	void ReplaceWithFistIfEmpty(struct FST_ItemBase Item, struct FST_ItemBase& Out); // Function FirstPersonCharacter.FirstPersonCharacter_C.ReplaceWithFistIfEmpty
	bool VerifyMaxMeleeRange(struct AActor* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.VerifyMaxMeleeRange
	void SetAttackDelayOnSwitchingSlots(struct FST_ItemBase Item); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetAttackDelayOnSwitchingSlots
	float GetTotalModifiedMaxSprintSpeed(); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetTotalModifiedMaxSprintSpeed
	void TickDarkZoneEffects(); // Function FirstPersonCharacter.FirstPersonCharacter_C.TickDarkZoneEffects
	void TrySwitchSlotsAfterHold(); // Function FirstPersonCharacter.FirstPersonCharacter_C.TrySwitchSlotsAfterHold
	void GetHeldDownSlotKeyIndex(int32_t& SlotIndex); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetHeldDownSlotKeyIndex
	void StartSlotSwitchTimer(); // Function FirstPersonCharacter.FirstPersonCharacter_C.StartSlotSwitchTimer
	void GetRandomWorkbenchBlueprint(struct TArray<struct FST_CraftRecipe>& Current, struct FST_CraftRecipe& RandomRecipe); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetRandomWorkbenchBlueprint
	bool InteractTrace(struct FHitResult& OutHit); // Function FirstPersonCharacter.FirstPersonCharacter_C.InteractTrace
	void IsLookingAtActor(struct AActor* Actor, bool& Looking); // Function FirstPersonCharacter.FirstPersonCharacter_C.IsLookingAtActor
	void GetClosestPlayer(struct AFirstPersonCharacter_C*& ClosestPlayer1); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetClosestPlayer
	void WalkingSurfaceTrace(char EPhysicalSurface& SurfaceType); // Function FirstPersonCharacter.FirstPersonCharacter_C.WalkingSurfaceTrace
	void Add Death Impulse(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Add Death Impulse
	void Set Heartbeat Volume Tick(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Set Heartbeat Volume Tick
	void Set Prop Spring Length(struct AMovable_Object_Replicated_C* Prop); // Function FirstPersonCharacter.FirstPersonCharacter_C.Set Prop Spring Length
	void F_CallOnLook(bool Start Look?, bool Server, struct UObject* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.F_CallOnLook
	void HandleIncomingDamage(float Damage, struct UDamageType* Type, struct AActor* DamageCauser); // Function FirstPersonCharacter.FirstPersonCharacter_C.HandleIncomingDamage
	void ToolTipForPickup(struct FST_ItemBase& Item, struct FString& tool tip, struct FString& sub tip); // Function FirstPersonCharacter.FirstPersonCharacter_C.ToolTipForPickup
	void GetMeleeChargePitch(float& Pitch); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetMeleeChargePitch
	void OnGrabProp(struct AMovable_Object_Replicated_C* Prop, struct FVector Teleport Location); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnGrabProp
	void SoundDampenTick_Fucntion(); // Function FirstPersonCharacter.FirstPersonCharacter_C.SoundDampenTick_Fucntion
	void OnRep_ChampionMode(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_ChampionMode
	void OnRep_GrabbedObject(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_GrabbedObject
	void GetFaceDir(struct FVector Incoming, bool& FacingFront?); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetFaceDir
	void GetSpineRotationX(float& X (Roll)); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetSpineRotationX
	void PC(struct APlayerBRController_C*& PC); // Function FirstPersonCharacter.FirstPersonCharacter_C.PC
	void NumOfSpectators(int32_t& Num); // Function FirstPersonCharacter.FirstPersonCharacter_C.NumOfSpectators
	void MeshNames(struct TArray<struct FST_AttachedMesh>& attached meshes, struct TArray<struct FName>& Names); // Function FirstPersonCharacter.FirstPersonCharacter_C.MeshNames
	void WorkbenchOnlyRecipies(struct TArray<struct FST_CraftRecipe>& Array, struct TArray<struct FST_CraftRecipe>& Out); // Function FirstPersonCharacter.FirstPersonCharacter_C.WorkbenchOnlyRecipies
	void OnRep_Teammate(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_Teammate
	void GameInstance(struct UGI_BR_C*& AsGI BR); // Function FirstPersonCharacter.FirstPersonCharacter_C.GameInstance
	void ID(int32_t& ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.ID
	void LongHitTrace(float Time, float Length, struct TArray<struct FHitResult>& OutHits); // Function FirstPersonCharacter.FirstPersonCharacter_C.LongHitTrace
	void ClientChangeStamina(float +, float StaminaBuffer); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientChangeStamina
	void CheckObjectBlock(struct FVector HitLocation, struct AActor* Actor to ignore, bool& bLocked, struct FHitResult& OutHit); // Function FirstPersonCharacter.FirstPersonCharacter_C.CheckObjectBlock
	void FindItemsInInventory(struct FString Name, struct TMap<int32_t, struct FST_ItemBase>& Items, bool& Found?); // Function FirstPersonCharacter.FirstPersonCharacter_C.FindItemsInInventory
	void OnRep_Cosmetics_Meshes(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_Cosmetics_Meshes
	void PlayersInRadius(struct FVector Start, float Radius, bool Spectators?, bool Ignore Self?, bool& Found?, struct TArray<struct AFirstPersonCharacter_C*>& Players, struct TArray<struct ASpectatorPawn_C*>& Spectactors); // Function FirstPersonCharacter.FirstPersonCharacter_C.PlayersInRadius
	void MeleeWeapon(struct FST_MeleeWeaponInfo& Weapon); // Function FirstPersonCharacter.FirstPersonCharacter_C.MeleeWeapon
	void CanDoStuff(bool& ?); // Function FirstPersonCharacter.FirstPersonCharacter_C.CanDoStuff
	float Ping In S(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Ping In S
	void GetHitDirection(struct AFirstPersonCharacter_C* Hitter, char E_HitDirection& Direction); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetHitDirection
	void ThrowItem(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ThrowItem
	void Delay-Ping(float Delay, float Max -, float& Delay-Ping); // Function FirstPersonCharacter.FirstPersonCharacter_C.Delay-Ping
	void CanAiAttack(bool& Attack); // Function FirstPersonCharacter.FirstPersonCharacter_C.CanAiAttack
	void splitSlotMap(struct TMap<struct FName, struct UStaticMesh*> Map, struct TArray<struct FName>& Name, struct TArray<struct UStaticMesh*>& Mesh); // Function FirstPersonCharacter.FirstPersonCharacter_C.splitSlotMap
	void GetAttachSlots(int32_t NewSlot, struct TArray<struct FST_AttachedMesh>& Meshes); // Function FirstPersonCharacter.FirstPersonCharacter_C.GetAttachSlots
	void EffectRep(struct TArray<struct ABP_Effect_C*>& Effects, struct TArray<struct FST_EffectRep>& Rep); // Function FirstPersonCharacter.FirstPersonCharacter_C.EffectRep
	void SetUpgrades(struct TArray<UC_Upgrade_C*>& Array); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetUpgrades
	void HUD(struct UBaseHUD_C*& AsBase HUD, bool& Valid); // Function FirstPersonCharacter.FirstPersonCharacter_C.HUD
	bool ShouldPlayhit(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ShouldPlayhit
	void ItemEquipped(bool& Bool); // Function FirstPersonCharacter.FirstPersonCharacter_C.ItemEquipped
	bool Can Attack(float Attack delay Threshold, bool Ignore Blocking?); // Function FirstPersonCharacter.FirstPersonCharacter_C.Can Attack
	void FindItemInInventory(struct FString Item Name, int32_t& Index, struct FST_ItemBase& Item, bool& found); // Function FirstPersonCharacter.FirstPersonCharacter_C.FindItemInInventory
	void SetNewChargeSpeed(struct FST_ItemBase& Item); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetNewChargeSpeed
	void Item Anim Type(struct FST_ItemBase& Item, char E_AnimType& Type); // Function FirstPersonCharacter.FirstPersonCharacter_C.Item Anim Type
	void FindIDininventory(struct TArray<int32_t>& ID, struct TMap<int32_t, int32_t>& Found ID's, struct TArray<int32_t>& Not Found ID's, bool& Found?); // Function FirstPersonCharacter.FirstPersonCharacter_C.FindIDininventory
	void ThrowFurniture(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ThrowFurniture
	void AddCharge(float TimetoCharge, bool Reverse, bool Color on end, float ColorChangeLevel, struct FString Tag, struct UchargeBar_C*& Widget); // Function FirstPersonCharacter.FirstPersonCharacter_C.AddCharge
	void LineTraceFromCamera(float Length, struct TArray<char EObjectTypeQuery>& ObjectTypes, struct USceneComponent* Camera, struct FHitResult& Hit, bool& Hit?); // Function FirstPersonCharacter.FirstPersonCharacter_C.LineTraceFromCamera
	void Blur__FinishedFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Blur__FinishedFunc
	void Blur__UpdateFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Blur__UpdateFunc
	void DamageEffectTimeline__FinishedFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.DamageEffectTimeline__FinishedFunc
	void DamageEffectTimeline__UpdateFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.DamageEffectTimeline__UpdateFunc
	void RecoilCurve__FinishedFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.RecoilCurve__FinishedFunc
	void RecoilCurve__UpdateFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.RecoilCurve__UpdateFunc
	void Spread Curve Back__FinishedFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Spread Curve Back__FinishedFunc
	void Spread Curve Back__UpdateFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Spread Curve Back__UpdateFunc
	void Spread curve__FinishedFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Spread curve__FinishedFunc
	void Spread curve__UpdateFunc(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Spread curve__UpdateFunc
	void Completed_6F07F8864F50B817CAEDB385958C1072(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB385958C1072
	void Completed_215CB37D43646A0095BC73978794783E(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC73978794783E
	void Completed_6F07F8864F50B817CAEDB38580F86485(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB38580F86485
	void Completed_215CB37D43646A0095BC739792E00CC9(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC739792E00CC9
	void Completed_6F07F8864F50B817CAEDB385691AEB13(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB385691AEB13
	void Completed_215CB37D43646A0095BC73977B02835F(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC73977B02835F
	void InpActEvt_Jump_K2Node_InputActionEvent_46(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Jump_K2Node_InputActionEvent_46
	void InpActEvt_Jump_K2Node_InputActionEvent_45(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Jump_K2Node_InputActionEvent_45
	void InpActEvt_Interact_K2Node_InputActionEvent_44(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Interact_K2Node_InputActionEvent_44
	void InpActEvt_Interact_K2Node_InputActionEvent_43(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Interact_K2Node_InputActionEvent_43
	void Completed_0914B3504C491F3C20AD179693CF6C05(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_0914B3504C491F3C20AD179693CF6C05
	void Completed_215CB37D43646A0095BC7397EBF085C9(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC7397EBF085C9
	void Completed_6F07F8864F50B817CAEDB385F9E8ED85(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB385F9E8ED85
	void InpActEvt_Text Chat_K2Node_InputActionEvent_42(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Text Chat_K2Node_InputActionEvent_42
	void InpActEvt_ToggleHUD_K2Node_InputActionEvent_41(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ToggleHUD_K2Node_InputActionEvent_41
	void Completed_215CB37D43646A0095BC73977101874C(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC73977101874C
	void Completed_6F07F8864F50B817CAEDB3856319EF00(struct USaveGame* SaveGame, bool bSuccess); // Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB3856319EF00
	void InpActEvt_Attack_K2Node_InputActionEvent_40(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_40
	void InpActEvt_Attack_K2Node_InputActionEvent_39(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_39
	void InpActEvt_Attack_K2Node_InputActionEvent_38(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_38
	void InpActEvt_Attack_K2Node_InputActionEvent_37(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_37
	void InpActEvt_Shove_K2Node_InputActionEvent_36(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Shove_K2Node_InputActionEvent_36
	void InpActEvt_Shove_K2Node_InputActionEvent_35(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Shove_K2Node_InputActionEvent_35
	void InpActEvt_block_K2Node_InputActionEvent_34(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_block_K2Node_InputActionEvent_34
	void InpActEvt_block_K2Node_InputActionEvent_33(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_block_K2Node_InputActionEvent_33
	void InpActEvt_Slot 6_K2Node_InputActionEvent_32(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 6_K2Node_InputActionEvent_32
	void InpActEvt_Slot 6_K2Node_InputActionEvent_31(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 6_K2Node_InputActionEvent_31
	void InpActEvt_Slot 5_K2Node_InputActionEvent_30(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 5_K2Node_InputActionEvent_30
	void InpActEvt_Slot 5_K2Node_InputActionEvent_29(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 5_K2Node_InputActionEvent_29
	void InpActEvt_Slot 4_K2Node_InputActionEvent_28(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 4_K2Node_InputActionEvent_28
	void InpActEvt_Slot 4_K2Node_InputActionEvent_27(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 4_K2Node_InputActionEvent_27
	void InpActEvt_Slot 3_K2Node_InputActionEvent_26(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 3_K2Node_InputActionEvent_26
	void InpActEvt_Slot 3_K2Node_InputActionEvent_25(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 3_K2Node_InputActionEvent_25
	void InpActEvt_Slot 2_K2Node_InputActionEvent_24(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 2_K2Node_InputActionEvent_24
	void InpActEvt_Slot 2_K2Node_InputActionEvent_23(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 2_K2Node_InputActionEvent_23
	void InpActEvt_Slot 1_K2Node_InputActionEvent_22(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 1_K2Node_InputActionEvent_22
	void InpActEvt_Slot 1_K2Node_InputActionEvent_21(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 1_K2Node_InputActionEvent_21
	void InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_2(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_2
	void InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_1(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_1
	void InpActEvt_Drop_K2Node_InputActionEvent_20(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Drop_K2Node_InputActionEvent_20
	void InpActEvt_sprint_K2Node_InputActionEvent_19(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_sprint_K2Node_InputActionEvent_19
	void InpActEvt_sprint_K2Node_InputActionEvent_18(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_sprint_K2Node_InputActionEvent_18
	void InpActEvt_CraftingMenu_K2Node_InputActionEvent_17(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_CraftingMenu_K2Node_InputActionEvent_17
	void InpActEvt_CraftingMenu_K2Node_InputActionEvent_16(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_CraftingMenu_K2Node_InputActionEvent_16
	void InpActEvt_ThrowProp_K2Node_InputActionEvent_15(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowProp_K2Node_InputActionEvent_15
	void InpActEvt_ThrowProp_K2Node_InputActionEvent_14(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowProp_K2Node_InputActionEvent_14
	void InpActEvt_Crouch_K2Node_InputActionEvent_13(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Crouch_K2Node_InputActionEvent_13
	void InpActEvt_Crouch_K2Node_InputActionEvent_12(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Crouch_K2Node_InputActionEvent_12
	void InpActEvt_ThrowWeapon_K2Node_InputActionEvent_11(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowWeapon_K2Node_InputActionEvent_11
	void InpActEvt_ThrowWeapon_K2Node_InputActionEvent_10(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowWeapon_K2Node_InputActionEvent_10
	void InpActEvt_ToggleDevMode_K2Node_InputActionEvent_9(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ToggleDevMode_K2Node_InputActionEvent_9
	void InpActEvt_VoiceChat_K2Node_InputActionEvent_8(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_VoiceChat_K2Node_InputActionEvent_8
	void InpActEvt_VoiceChat_K2Node_InputActionEvent_7(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_VoiceChat_K2Node_InputActionEvent_7
	void InpActEvt_Reload_K2Node_InputActionEvent_6(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Reload_K2Node_InputActionEvent_6
	void InpActEvt_Reload_K2Node_InputActionEvent_5(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Reload_K2Node_InputActionEvent_5
	void InpActEvt_Attack_K2Node_InputActionEvent_4(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_4
	void InpActEvt_Attack_K2Node_InputActionEvent_3(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_3
	void OnLoaded_AABEDF7046651F2141E4228B1A1613B1(struct UObject* Loaded); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoaded_AABEDF7046651F2141E4228B1A1613B1
	void OnLoaded_FE24A16848CBD59DA5C1EA9AF9FCF33C(struct UObject* Loaded); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoaded_FE24A16848CBD59DA5C1EA9AF9FCF33C
	void InpActEvt_Spray_K2Node_InputActionEvent_2(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Spray_K2Node_InputActionEvent_2
	void InpActEvt_Spray_K2Node_InputActionEvent_1(struct FKey Key); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Spray_K2Node_InputActionEvent_1
	void OnFail_C4A8050440B47C9C595135BBAA0CF89B(struct UTexture2DDynamic* Texture); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnFail_C4A8050440B47C9C595135BBAA0CF89B
	void OnSuccess_C4A8050440B47C9C595135BBAA0CF89B(struct UTexture2DDynamic* Texture); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnSuccess_C4A8050440B47C9C595135BBAA0CF89B
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnInteract
	void OnLook(struct AFirstPersonCharacter_C* Caller); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnLook
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnStopLook
	void OnChargeUpdate(float Charge, struct AFirstPersonCharacter_C* Caller); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnChargeUpdate
	void ServerOnLook(struct AFirstPersonCharacter_C* Player); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerOnLook
	void ServerOnStopLook(struct AFirstPersonCharacter_C* Player); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerOnStopLook
	void ServerConsumeCurrentHealingItem(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerConsumeCurrentHealingItem
	void ClientSetStun(bool Stunned); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetStun
	void ServerSetStun(bool Stun); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetStun
	void ServerHitByProjectile(struct AFirstPersonCharacter_C* Causer, struct AFirstPersonCharacter_C* HitTarget, struct FHitResult Hit, bool Headshot, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerHitByProjectile
	void ServerDoDamageDev(float BaseDamage); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDoDamageDev
	void ClientHitSomeoneWithProjectile(struct AFirstPersonCharacter_C* OtherPlayer, struct FHitResult Hit, bool Headshot, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientHitSomeoneWithProjectile
	void ServerTryScrapGarbagePile(struct AGarbagePile_C* Pile); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryScrapGarbagePile
	void ServerTryAddingBleedEffectFromUpgrade(struct AFirstPersonCharacter_C* AttackedTarget, float BleedScale); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingBleedEffectFromUpgrade
	void ServerDoLocalBleedDamage(struct AFirstPersonCharacter_C* DamageCauser); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDoLocalBleedDamage
	void ServerTryAddingBoltEffectFromUpgrade(struct AFirstPersonCharacter_C* AttackedTarget, float BoltScale); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingBoltEffectFromUpgrade
	void ServerTryAddingDrainEffectFromUpgrade(struct AFirstPersonCharacter_C* AttackedTarget, float DrainScale); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingDrainEffectFromUpgrade
	void ServerTryAddingVampireEffectFromUpgrade(struct AFirstPersonCharacter_C* AttackedTarget, float VampireScale); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingVampireEffectFromUpgrade
	void ServerLocalHealFromRegenEffect(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerLocalHealFromRegenEffect
	void ServerTryHealingFromVampireEffect(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryHealingFromVampireEffect
	void ServerTryAddingBlindEffectFromFireExtinguisher(struct AFirstPersonCharacter_C* BlindedTarget); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingBlindEffectFromFireExtinguisher
	void ServerTryUseFrenzy(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryUseFrenzy
	void ServerDoPoolBlastFromEffect(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDoPoolBlastFromEffect
	void Server Use Current Stim(int32_t SelectedSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Use Current Stim
	void Server Spawn Projectile And Remove Current Item(ABP_Projectile_C* Class, struct FTransform SpawnTransform, struct APawn* Instigator, float Damage, int32_t SlotIndex); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Projectile And Remove Current Item
	void ServerAddMaterials_Dev(int32_t +wood, int32_t +metal, int32_t +binder); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddMaterials_Dev
	void ServerThrowDynamite(struct FTransform SpawnTransform, float Time, struct FVector Launch); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerThrowDynamite
	void ServerDynamiteExplodeInHands(float Intensity, float Radius); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDynamiteExplodeInHands
	void ServerExplodeExplosiveArrow(struct FTransform ExplosiveArrow); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerExplodeExplosiveArrow
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_158(float AxisValue); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_158
	void InpAxisEvt_LookUp_K2Node_InputAxisEvent_173(float AxisValue); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_173
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_182(float AxisValue); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_182
	void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_193(float AxisValue); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_193
	void ReceiveTick(float DeltaSeconds); // Function FirstPersonCharacter.FirstPersonCharacter_C.ReceiveTick
	void ServerSetSpineRotation(float SpineRotationX); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetSpineRotation
	void ClientHideHead(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientHideHead
	void ReceiveBeginPlay(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ReceiveBeginPlay
	void Server Spawn Placable(ABP_Placable_C* Class, struct FTransform SpawnTransform); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Placable
	void ClientViewOffeset(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientViewOffeset
	void ServerKeycardOpen(struct AKeyCardReader_BP_C* reader); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerKeycardOpen
	void ClientHighlightTeammate(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientHighlightTeammate
	void ServerSetTeamMate(struct AFirstPersonCharacter_C* Teammate); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetTeamMate
	void SetTeammateFromID(struct FString ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetTeammateFromID
	void OnClientPossessed(struct APlayerBRController_C* PC); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnClientPossessed
	void ReceivePossessed(struct AController* NewController); // Function FirstPersonCharacter.FirstPersonCharacter_C.ReceivePossessed
	void OtherBeginPlayStuff(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OtherBeginPlayStuff
	void OnLanded(struct FHitResult& Hit); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnLanded
	void ServerBonusForNoTeammate(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerBonusForNoTeammate
	void OnPlayerSettingsChanged(struct FST_PlayerSettings New Settings); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnPlayerSettingsChanged
	void SettingsSetup(); // Function FirstPersonCharacter.FirstPersonCharacter_C.SettingsSetup
	void ServerSetGodMode(bool GodMode); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetGodMode
	void SetHudVisibility(bool Index); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetHudVisibility
	void ClientTakeScreenshot(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientTakeScreenshot
	void ClientPlayLocalAudio(struct USoundBase* NewSound, float fadeInDuration); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPlayLocalAudio
	void ClientTryLoadMeatballLauncher(struct ABP_ItemPickup_C* Pickup); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientTryLoadMeatballLauncher
	void SoundDampenTick(); // Function FirstPersonCharacter.FirstPersonCharacter_C.SoundDampenTick
	void ClientPlayFootstep(float VolumeMultiplier, float PitchMultiplier, bool Priority, char EPhysicalSurface SurfaceType); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPlayFootstep
	void SpeedHackDelegate_Event(); // Function FirstPersonCharacter.FirstPersonCharacter_C.SpeedHackDelegate_Event
	void Init Speedhack detection(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Init Speedhack detection
	void ServerAddAmmoAndDestroyActor(int32_t Slot, int32_t Ammo, struct AActor* Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddAmmoAndDestroyActor
	void Server Start Ringing closest player(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Start Ringing closest player
	void Server Stop Ringing Closest Player(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Stop Ringing Closest Player
	void DiscoverNewRecipe(int32_t ItemId); // Function FirstPersonCharacter.FirstPersonCharacter_C.DiscoverNewRecipe
	void CheckForRing(); // Function FirstPersonCharacter.FirstPersonCharacter_C.CheckForRing
	void TickAddWhooshToPlayerSpeed(); // Function FirstPersonCharacter.FirstPersonCharacter_C.TickAddWhooshToPlayerSpeed
	void FadeCamera(float FromAlpha, float ToAlpha, float Duration); // Function FirstPersonCharacter.FirstPersonCharacter_C.FadeCamera
	void OnSpeedhackDetected(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnSpeedhackDetected
	void OnControllerLeaveGame(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnControllerLeaveGame
	void BindSomeTickFunctions(); // Function FirstPersonCharacter.FirstPersonCharacter_C.BindSomeTickFunctions
	void OnLanded_FallDamage(struct FHitResult Hit); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnLanded_FallDamage
	void UnStun(); // Function FirstPersonCharacter.FirstPersonCharacter_C.UnStun
	void ServerInteract(bool Interacting); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerInteract
	void ClientInteract(bool Interact); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientInteract
	void Release_Server(struct AMovable_Object_Replicated_C* Prop, struct FVector ThrowVector); // Function FirstPersonCharacter.FirstPersonCharacter_C.Release_Server
	void Server E press(struct FHitResult Hit, int32_t InventorySlot, struct AActor* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server E press
	void ClientScanObjects(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientScanObjects
	void ClientAddBP(struct FST_CraftRecipe Recipe); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddBP
	void Multi_Grab(struct AMovable_Object_Replicated_C* Mesh, struct FVector Teleport Loaction); // Function FirstPersonCharacter.FirstPersonCharacter_C.Multi_Grab
	void Server_Grab(struct AMovable_Object_Replicated_C* Mesh, struct FVector Teleport Loaction); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server_Grab
	void ServerStopLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStopLoopedAnimation
	void MultiStopLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStopLoopedAnimation
	void ClientStopLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStopLoopedAnimation
	void MultiStartLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate, int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStartLoopedAnimation
	void ServerStartLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate, int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStartLoopedAnimation
	void ClientStartLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStartLoopedAnimation
	void TickShoveInput(); // Function FirstPersonCharacter.FirstPersonCharacter_C.TickShoveInput
	void ClientBloodSplatter(struct FVector Location, struct FVector Scale); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientBloodSplatter
	void TickBlockInput(); // Function FirstPersonCharacter.FirstPersonCharacter_C.TickBlockInput
	void ClientCancelCharge(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCancelCharge
	void Do Launch(struct FVector LaunchVelocity); // Function FirstPersonCharacter.FirstPersonCharacter_C.Do Launch
	void StartLongTrace(float Time, float Length); // Function FirstPersonCharacter.FirstPersonCharacter_C.StartLongTrace
	void OnGetHitClient(struct AFirstPersonCharacter_C* Hitter, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnGetHitClient
	void ServerSpawnDynamite(struct FTransform SpawnTransform, float Time, struct FVector Launch); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnDynamite
	void ServerSpawnExplosion(struct FTransform SpawnTransform, struct APawn* Instigator, float Intensity, float Radius); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnExplosion
	void ClientStartShove(float Length); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStartShove
	void StopLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName); // Function FirstPersonCharacter.FirstPersonCharacter_C.StopLoopedAnimation
	void StartLoopedAnimation(struct UAnimSequenceBase* Asset, struct FName SlotNodeName, float BlendInTime, float BlendOutTime, float InPlayRate); // Function FirstPersonCharacter.FirstPersonCharacter_C.StartLoopedAnimation
	void ServerDoMeleeHit(struct AFirstPersonCharacter_C*& Attacker, struct AFirstPersonCharacter_C*& Target, struct FVector& HitLocation, struct FString Validation); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDoMeleeHit
	void ServerDamageFurniture(struct FVector Location, struct FVector Normal, float Damage, struct AMovable_Object_Replicated_C* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDamageFurniture
	void ServerStunEffects(struct FVector Location, struct FVector Scale, float VolumeMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStunEffects
	void ClientStartMeleeHit(float Distance); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStartMeleeHit
	void ClientBlurCurve(float Time, float MaxIntensity, float StartTime); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientBlurCurve
	void ServerMeleeHitEffects(struct FVector Location, struct FVector Scale); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerMeleeHitEffects
	void MultiProjectile(struct FTransform SpawnTransform, struct APawn* Instigator, float Damage, int32_t ID, ABP_Projectile_C* Class); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiProjectile
	void ServerProjectile(int32_t ID, float Damage, struct APawn* Instigator, struct FTransform SpawnTransform, ABP_Projectile_C* Class); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerProjectile
	void ServerAnimReliable(int32_t initiator, struct UAnimSequenceBase* Asset, float BlendInTime, float BlendOutTime, struct FName SlotNodeName, float InPlayRate); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAnimReliable
	void MultiAnimReliable(int32_t initiator, struct UAnimSequenceBase* Asset, float BlendInTime, float BlendOutTime, struct FName SlotNodeName, float InPlayRate); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAnimReliable
	void ClientHitsomeone(struct AFirstPersonCharacter_C* Hit, float ResultingDamage, bool CriticalHit); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientHitsomeone
	void ServerSetConstDamageMultiplier(float ConstDamageMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetConstDamageMultiplier
	void AI_Block(bool Blocking); // Function FirstPersonCharacter.FirstPersonCharacter_C.AI_Block
	void ClientStopChargeSound(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStopChargeSound
	void MultiChargeSound(int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiChargeSound
	void ServerChargeSound(int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerChargeSound
	void ClientChargeSound(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientChargeSound
	void BloodDecal(struct FName EventName, float EmitterTime, int32_t ParticleTime, struct FVector Location, struct FVector Velocity, struct FVector Direction, struct FVector Normal, struct FName BoneName, struct UPhysicalMaterial* PhysMat); // Function FirstPersonCharacter.FirstPersonCharacter_C.BloodDecal
	void MultiStunEffects(struct FVector Location, struct FVector Scale, float VolumeMultiplier, float PitchMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStunEffects
	void SetChargingServer(bool Charging); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetChargingServer
	void ServerSetDamageMultiplier(float DamageMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetDamageMultiplier
	void MeleeAttack(float BlendOutTime, float BlendInTime, bool Charging, struct FString Validation); // Function FirstPersonCharacter.FirstPersonCharacter_C.MeleeAttack
	void executeChargedAttack(); // Function FirstPersonCharacter.FirstPersonCharacter_C.executeChargedAttack
	void CheckMeleeHitTime(); // Function FirstPersonCharacter.FirstPersonCharacter_C.CheckMeleeHitTime
	void Hitmarker(bool HeadShot?); // Function FirstPersonCharacter.FirstPersonCharacter_C.Hitmarker
	void ServerSpawnProjectile(ABP_Projectile_C* Class, struct FTransform SpawnTransform, float Damage, struct APawn* Instigator); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnProjectile
	void ClientStun(struct FVector Stun Location, float Duration, float KnockbackMultiplier, bool ShortStun?); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStun
	void ServerShove(struct AActor* Hit); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerShove
	void ClientShove(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientShove
	void ClientSlotAnim(struct UAnimSequenceBase* Asset, float BlendInTime, float BlendOutTime, struct FName SlotName, float InPlayRate, bool Exclusive, bool reliable); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSlotAnim
	void ClientMelee(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientMelee
	void Do Block(bool Blocking); // Function FirstPersonCharacter.FirstPersonCharacter_C.Do Block
	void ServerBlock(bool Blocking); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerBlock
	void MultiAnim(int32_t initiator, struct UAnimSequenceBase* Asset, float BlendInTime, float BlendOutTime, struct FName SlotNodeName, float InPlayRate); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAnim
	void ServerAnim(int32_t initiator, struct UAnimSequenceBase* Asset, float BlendInTime, float BlendOutTime, struct FName SlotNodeName, float InPlayRate); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAnim
	void MultiMeleeHit(struct FVector Location, struct FVector Scale); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiMeleeHit
	void Server Switch with pickup(int32_t SlotIndex, struct ABP_ItemPickup_C* pickup Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Switch with pickup
	void Try Switch with pickup(int32_t inventory slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.Try Switch with pickup
	void ServerSetSelectedSlot(int32_t SelectedInventorySlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetSelectedSlot
	void ClientCallOnStopLook(struct AActor* TargetActor); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCallOnStopLook
	void ServerPickupActor(struct ABP_ItemPickup_C* Pickup); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerPickupActor
	void ClientUpdateEquippedItemOnInventoryChanged(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientUpdateEquippedItemOnInventoryChanged
	void ClientRemoteEquip(int32_t EquipSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientRemoteEquip
	void ServerSwapInventorySlots(int32_t FirstIndex, int32_t SecondIndex); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSwapInventorySlots
	void Server Remove Item(int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Remove Item
	void Equip Slot(int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.Equip Slot
	void Server Pickup(struct ABP_ItemPickup_C* Pickup, struct FST_ItemBase (Optional) Item Override); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Pickup
	void Server Actually Drop Item(int32_t invenotry slot, struct FVector throw vector, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Actually Drop Item
	void ClientOwnerEquip(int32_t NewSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientOwnerEquip
	void ServerPickupAmmo(struct ABP_ItemPickup_C* PickupActor, struct FST_ItemBase Item); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerPickupAmmo
	void Client Drop Item(int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client Drop Item
	void OnEquip_Event(int32_t NewSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnEquip_Event
	void ServerSpawnNewItem(struct FST_ItemBase Item); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnNewItem
	void Client drop current item(struct FVector ThrowVector, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client drop current item
	void ServerChangeInventory(struct FST_ItemBase Item, int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerChangeInventory
	void ClientPickup(struct AActor* Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPickup
	void ClientAddAmmo(int32_t Slot, int32_t Ammo, bool Destroy on 0, bool Equip?); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddAmmo
	void RemoveCurrentItem(int32_t SlotIndex, bool Equip?); // Function FirstPersonCharacter.FirstPersonCharacter_C.RemoveCurrentItem
	void ServerEquip(int32_t ReplicatedSelectedSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerEquip
	void ServerAnimSet(char E_AnimType Enumerator); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAnimSet
	void ClientAnimSet(char E_AnimType Type); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAnimSet
	void ServerAddMaterials(int32_t +wood, int32_t +metal, int32_t +binder); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddMaterials
	void ClientAddMaterialsEffect(int32_t Wood, int32_t Metal, int32_t Binder); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddMaterialsEffect
	void ClientDismantle(int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientDismantle
	void Dismantle(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Dismantle
	void ServerDismantle(int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDismantle
	void ServerDropItem(struct FST_ItemBase Item, struct FVector ThrowVector, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDropItem
	void AddRecipe(struct FST_CraftRecipe NewItem); // Function FirstPersonCharacter.FirstPersonCharacter_C.AddRecipe
	void MultiEquip(int32_t ID, AActor* inClass, struct FName SocketName); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiEquip
	void Equip(int32_t SlotIndex); // Function FirstPersonCharacter.FirstPersonCharacter_C.Equip
	void AddToInventory(struct FST_ItemBase Item, int32_t SlotIndex, bool Equip?); // Function FirstPersonCharacter.FirstPersonCharacter_C.AddToInventory
	void PlayGlobalDeathSound(); // Function FirstPersonCharacter.FirstPersonCharacter_C.PlayGlobalDeathSound
	void Client Chromatic Abberation Curve(float Time, float MaxIntensity, float Start Time); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client Chromatic Abberation Curve
	void ClientOnDeath(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientOnDeath
	void ClientDisableInput(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientDisableInput
	void ClientDestroyComponent(struct UActorComponent* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientDestroyComponent
	void Server Heal Other(float +, struct AFirstPersonCharacter_C* Healing Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Heal Other
	void ClientOnHitSomeone(struct FTransform SpawnTransform, float Damage, bool HeadShot?, struct AFirstPersonCharacter_C* DamagedTarget); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientOnHitSomeone
	void MultiRemoveDecals(); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiRemoveDecals
	void MultispawnDecals(); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultispawnDecals
	void ServerDie(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDie
	void ShowHitDamage(struct FTransform SpawnTransform, float Damage, bool HeadShot?); // Function FirstPersonCharacter.FirstPersonCharacter_C.ShowHitDamage
	void ClientGetHit(struct FVector AttackerLoc); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientGetHit
	void ClientDamageIndicator(struct FVector AttackerLoc); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientDamageIndicator
	void ServerCommitHeal(float + Health); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerCommitHeal
	void MultiDie(); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiDie
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function FirstPersonCharacter.FirstPersonCharacter_C.ReceiveAnyDamage
	void ClientUpdateSprintSpeed(float MaxWalkSpeed); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientUpdateSprintSpeed
	void Server set Bolt Sprint Multiplier(float Stims Sprint Speed Multiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server set Bolt Sprint Multiplier
	void Server Set Stims Sprint Multiplier(float Stims Sprint Speed Multiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Set Stims Sprint Multiplier
	void ServerUpdateMaxSprintSpeed(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerUpdateMaxSprintSpeed
	void OnStopSprinting(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnStopSprinting
	void Clientsprint(float MaxWalkSpeed, bool Sprinting?, bool Force); // Function FirstPersonCharacter.FirstPersonCharacter_C.Clientsprint
	void SprintMulti(float MaxWalkSpeed, int32_t initiator, bool sprinting); // Function FirstPersonCharacter.FirstPersonCharacter_C.SprintMulti
	void SprintServer(float MaxWalkSpeed, bool Sprinting?, int32_t initiator, bool Should Change Speed); // Function FirstPersonCharacter.FirstPersonCharacter_C.SprintServer
	void ClientVerifySprintSpeed(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientVerifySprintSpeed
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1(float AxisValue); // Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
	void ClientChangeSaturation(float X); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientChangeSaturation
	void Open Crafting Menu(bool Workbench, struct AWorkbench_C* WorkbenchActor); // Function FirstPersonCharacter.FirstPersonCharacter_C.Open Crafting Menu
	void RemoveCraftingMenu(); // Function FirstPersonCharacter.FirstPersonCharacter_C.RemoveCraftingMenu
	void Server_CraftInHand_Stop(bool Exclusive); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server_CraftInHand_Stop
	void Local_CraftInHand_Stop(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Local_CraftInHand_Stop
	void Local_CraftInHand_Start(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Local_CraftInHand_Start
	void Server_CraftInHand_Start(bool Exclusive); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server_CraftInHand_Start
	void Multi_CraftInHand_Stop(bool Exclusive); // Function FirstPersonCharacter.FirstPersonCharacter_C.Multi_CraftInHand_Stop
	void Multi_CraftInHand_Start(bool Exclusive); // Function FirstPersonCharacter.FirstPersonCharacter_C.Multi_CraftInHand_Start
	void ClientCancellCraft(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCancellCraft
	void OnStunned_Event(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnStunned_Event
	void ClientSetActorHidden(struct AActor* Actor, bool bNewHidden); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetActorHidden
	void MultiSetActorHidden(struct AActor* Target, bool bNewHidden); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSetActorHidden
	void ServerSetActorHidden(struct AActor* Actor, bool bNewHidden); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetActorHidden
	void MultiSpawnParticleAttached(struct UParticleSystem* EmitterTemplate, struct USceneComponent* AttachToComponent, struct FVector Scale, struct FVector Location, struct FRotator Rotation); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSpawnParticleAttached
	void Server Spawn Particle(struct UParticleSystem* EmitterTemplate, struct FVector Location, struct FVector Scale, struct USceneComponent* AttachToComponent, struct FRotator Rotation); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Particle
	void MultiRemoveParticles(); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiRemoveParticles
	void MultiParticles(struct UParticleSystem* EmitterTemplate, struct FVector Location, struct FVector Scale); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiParticles
	void MultiRemoveCraftEffects(); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiRemoveCraftEffects
	void MultiCraftEffects(); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiCraftEffects
	void WorkbenchCraft(struct FST_CraftRecipe Recipe, struct AWorkbench_C* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.WorkbenchCraft
	void ClientCraft(struct FST_CraftRecipe Recipe); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCraft
	void ServerCraft(struct FST_CraftRecipe Recipe); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerCraft
	void HidePlayerInfo(struct AActor* Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.HidePlayerInfo
	void ClientInvalidateFocusedRemotePlayer(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientInvalidateFocusedRemotePlayer
	void ClientInvalidateFocusedItemPickup(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientInvalidateFocusedItemPickup
	void ClientInvalidateFocusedInteractable(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientInvalidateFocusedInteractable
	void Tick_ClientScanForObjects(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Tick_ClientScanForObjects
	void _ServerCallOnLook(bool Start Look?, struct UObject* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C._ServerCallOnLook
	void _ClientCallOnLook(bool Start Look?, struct UObject* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C._ClientCallOnLook
	void CallOnLook(bool Start Look?, struct UObject* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.CallOnLook
	void LookAtObject(bool Look?, struct UObject* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.LookAtObject
	void ShowPlayerInfo(struct AFirstPersonCharacter_C* Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.ShowPlayerInfo
	void BndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function FirstPersonCharacter.FirstPersonCharacter_C.BndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void OutlinePickup(bool bValue, struct UPrimitiveComponent* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.OutlinePickup
	void BndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function FirstPersonCharacter.FirstPersonCharacter_C.BndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentEndOverlapSignature__DelegateSignature
	void HideToolTip(struct FString Tag); // Function FirstPersonCharacter.FirstPersonCharacter_C.HideToolTip
	void ShowToolTip(struct FString inString, struct FString SubText, struct FString Tag); // Function FirstPersonCharacter.FirstPersonCharacter_C.ShowToolTip
	void RemoveCharge(struct FString Tag); // Function FirstPersonCharacter.FirstPersonCharacter_C.RemoveCharge
	void ClientCharge(float TimetoCharge, struct AActor* Ref, struct FString Tag); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCharge
	void Tick_DecreasePropDelay(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Tick_DecreasePropDelay
	void ClientThrowingFurniture(bool Throwing?); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientThrowingFurniture
	void SetThrowingServer(bool Throwing?); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetThrowingServer
	void MultiSoundEffect(struct FVector Location, struct USoundBase* Sound, int32_t ID, float VolumeMultiplier, float PitchMultiplier, struct USoundAttenuation* AttenuationSettings); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSoundEffect
	void ServerSoundEffect(struct FVector Location, struct USoundBase* Sound, int32_t ID, float VolumeMultiplier, float PitchMultiplier, struct USoundAttenuation* AttenuationSettings); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSoundEffect
	void ClientSoundEffect(struct FVector Location, struct USoundBase* Sound, float VolumeMultiplier, float PitchMultiplier, struct USoundAttenuation* AttenuationSettings); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSoundEffect
	void ClientAddArmour(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddArmour
	void ServerAddArmour(int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddArmour
	void Server update info(struct FST_PlayerRepInfo Info); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server update info
	void Update Client Info(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Update Client Info
	void ClientUpdateHUDEffects(struct TArray<struct ABP_Effect_C*>& Effects); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientUpdateHUDEffects
	void SetConstIncomingDamageMultiplier(float IncomingDamageMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetConstIncomingDamageMultiplier
	void ServerSetCanMoveHeavyFurniture(bool CanMoveHeavyFurniture); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetCanMoveHeavyFurniture
	void ServerSetMoveFurniture(bool CanMoveFurniture); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetMoveFurniture
	void Server Add Effect(struct FST_Effect& Effect, float New Scale, struct AFirstPersonCharacter_C* caster); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Add Effect
	void Server Remove Effect(struct FString Name); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Remove Effect
	void ClientCrouch(bool Crouched); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCrouch
	void MultiCrouch(bool Crouch); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiCrouch
	void ServerCrouch(bool Crouched); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerCrouch
	void ClientCancelItemThrow(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCancelItemThrow
	void EEVent(int32_t NewSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.EEVent
	void ClientSetClothingClip(float Clipping Distance); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetClothingClip
	void ServerAddClothing(struct TArray<struct FST_RepCosmetic>& SourceArray); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddClothing
	void ClientConfirmCurrentEquippedUpgrades(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientConfirmCurrentEquippedUpgrades
	void OnLoseFocus_Event_Upgrade(struct AActor* Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoseFocus_Event_Upgrade
	void ServerTryApplyUpgrade(struct ABP_ItemPickup_C* Pickup, UC_Upgrade_C*& Upgrade, int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryApplyUpgrade
	void Client Set Upgrades(struct TArray<UC_Upgrade_C*>& Array); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client Set Upgrades
	void ServerAddUpgrade(UC_Upgrade_C*& Upgrade, int32_t Slot); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddUpgrade
	void ClientAddUpgrade(UC_Upgrade_C*& Upgrade, struct ABP_ItemPickup_C* Pickup); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddUpgrade
	void AttachCosmetic(struct TSoftObjectPtr<USkeletalMesh> Mesh, struct TArray<struct TSoftObjectPtr<UMaterialInterface>>& Materials); // Function FirstPersonCharacter.FirstPersonCharacter_C.AttachCosmetic
	void MultiAddSkeletalMesh(struct USkeletalMesh* NewMesh); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAddSkeletalMesh
	void ServerAddSkeletalMesh(struct USkeletalMesh* NewMesh); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddSkeletalMesh
	void Client Load Cosmetics Async(struct TArray<struct FST_RepCosmetic>& clothes); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client Load Cosmetics Async
	void Client Add Cosmetics(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client Add Cosmetics
	void Add Clothing(); // Function FirstPersonCharacter.FirstPersonCharacter_C.Add Clothing
	void ClientSetAttachSockets(struct TArray<struct FST_AttachedMesh>& Array); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetAttachSockets
	void Client Refresh Sockets(int32_t NewSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client Refresh Sockets
	void DevSpawn(struct FString Name); // Function FirstPersonCharacter.FirstPersonCharacter_C.DevSpawn
	void ClientRemovePath(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientRemovePath
	void ClientAddPath(float Velocity, struct AActor* Ignore, float OverrideGravityZ); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddPath
	void ClientPlayVoice(struct TArray<char>& CompressedVoiceData, struct AActor* Target); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPlayVoice
	void ServerSendVoice(struct TArray<char>& CompressedVoiceData); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSendVoice
	void BndEvt__VoipManager_K2Node_ComponentBoundEvent_0_VoiceGenerated__DelegateSignature(struct TArray<char>& VoiceData, float MicLevel); // Function FirstPersonCharacter.FirstPersonCharacter_C.BndEvt__VoipManager_K2Node_ComponentBoundEvent_0_VoiceGenerated__DelegateSignature
	void ClientEnableVoice(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientEnableVoice
	void ServerPouch(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerPouch
	void MultiBackpack(); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiBackpack
	void ServerBackpack(); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerBackpack
	void ServerSpawnDarkZone(struct FTransform SpawnTransform, float timeToGrow, float Time, float TargetSize); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnDarkZone
	void ServerDamage Prop(struct AMovable_Object_Replicated_C* Prop, float Damage, struct FVector Location, struct FVector Normal); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDamage Prop
	void ClientMuffleSound(float Time); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientMuffleSound
	void StopVoidAudio(); // Function FirstPersonCharacter.FirstPersonCharacter_C.StopVoidAudio
	void StartVoidAudio(); // Function FirstPersonCharacter.FirstPersonCharacter_C.StartVoidAudio
	void ClientSpawnSound(struct USoundBase* Sound, struct FVector Location, struct USceneComponent* AttachToComponent, float PitchMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSpawnSound
	void MultiAudioComponentPlay(struct USoundBase* Sound, struct FVector Location, int32_t ID, struct USceneComponent* AttachToComponent, float PitchMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAudioComponentPlay
	void ServerAudioComponentPlay(struct USoundBase* Sound, struct FVector Location, int32_t ID, struct USceneComponent* AttachToComponent, float PitchMultiplier); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAudioComponentPlay
	void ServerLMB(bool Down); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerLMB
	void AddRecoil(struct FVector2D Dir, float Random, float Scale, float Delay); // Function FirstPersonCharacter.FirstPersonCharacter_C.AddRecoil
	void Multi Spawn Decal(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct USceneComponent* AttachToComponent, struct FVector Location, struct FRotator Rotation, struct FName AttachPointName); // Function FirstPersonCharacter.FirstPersonCharacter_C.Multi Spawn Decal
	void Server Spawn Decal(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct USceneComponent* AttachToComponent, struct FVector Location, struct FRotator Rotation, struct FName AttachPointName); // Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Decal
	void Client Spread Curve(float Spread Amount, float Time); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client Spread Curve
	void MultiStopSlotAnimation(float InBlendOutTime, struct FName SlotNodeName, int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStopSlotAnimation
	void ServerStopSlotAnimation(float InBlendOutTime, struct FName SlotNodeName, int32_t ID); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStopSlotAnimation
	void ClientStopSlotAnimation(float InBlendOutTime, struct FName SlotNodeName); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStopSlotAnimation
	void SetWorkbenchDefaultBlueprints(struct TArray<int32_t>& Array); // Function FirstPersonCharacter.FirstPersonCharacter_C.SetWorkbenchDefaultBlueprints
	void AddDefaultRecipies(bool Override, struct TArray<int32_t>& OverrideRecipeIDs); // Function FirstPersonCharacter.FirstPersonCharacter_C.AddDefaultRecipies
	void ServerSpray_Texture(struct TSoftObjectPtr<UTexture2D> Texture, struct TSoftObjectPtr<UMaterialInterface> MaterialClass, struct FTransform Transform, struct FString CustomURL); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpray_Texture
	void Client_SprayItem(struct FST_SprayItem Spray); // Function FirstPersonCharacter.FirstPersonCharacter_C.Client_SprayItem
	void CloseSprayMenu(struct FST_SprayItem SelectedSpray); // Function FirstPersonCharacter.FirstPersonCharacter_C.CloseSprayMenu
	void OpenSprayMenu(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OpenSprayMenu
	void MultiSpray_Link(struct FVector Location, struct FRotator Rotation, struct FString Link); // Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSpray_Link
	void ServerSpray_Link(struct FVector Location, struct FRotator Rotation, struct FString Link); // Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpray_Link
	void ClientSpray(struct FString Link); // Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSpray
	void ExecuteUbergraph_FirstPersonCharacter(int32_t EntryPoint); // Function FirstPersonCharacter.FirstPersonCharacter_C.ExecuteUbergraph_FirstPersonCharacter
	void Reload__DelegateSignature(bool Down); // Function FirstPersonCharacter.FirstPersonCharacter_C.Reload__DelegateSignature
	void OnTick__DelegateSignature(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnTick__DelegateSignature
	void OnLoseFocus__DelegateSignature(struct AActor* Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoseFocus__DelegateSignature
	void OnFocus__DelegateSignature(struct AActor* Actor); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnFocus__DelegateSignature
	void OnDamageSomeone__DelegateSignature(struct AFirstPersonCharacter_C* DamagedTarget, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnDamageSomeone__DelegateSignature
	void OnStunned__DelegateSignature(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnStunned__DelegateSignature
	void OnInteractPure__DelegateSignature(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnInteractPure__DelegateSignature
	void LMB__DelegateSignature(bool Down); // Function FirstPersonCharacter.FirstPersonCharacter_C.LMB__DelegateSignature
	void OnGetHit__DelegateSignature(struct AFirstPersonCharacter_C* Hitter, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnGetHit__DelegateSignature
	void OnClick__DelegateSignature(); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnClick__DelegateSignature
	void OnMeleeHit__DelegateSignature(struct AFirstPersonCharacter_C* Hit, float Damage); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnMeleeHit__DelegateSignature
	void OnEquip__DelegateSignature(int32_t NewSlot); // Function FirstPersonCharacter.FirstPersonCharacter_C.OnEquip__DelegateSignature
}; 



