#pragma once 
#include <DamageIndicator_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DamageIndicator.DamageIndicator_C
// Size: 0x27C(Inherited: 0x260) 
struct UDamageIndicator_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* FadeOut;  // 0x268(0x8)
	struct UImage* Image_33;  // 0x270(0x8)
	float Angle;  // 0x278(0x4)

	void Construct(); // Function DamageIndicator.DamageIndicator_C.Construct
	void ExecuteUbergraph_DamageIndicator(int32_t EntryPoint); // Function DamageIndicator.DamageIndicator_C.ExecuteUbergraph_DamageIndicator
}; 



