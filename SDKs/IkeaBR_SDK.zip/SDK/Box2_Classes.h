#pragma once 
#include <Box2_Structs.h>
 
 
 
// BlueprintGeneratedClass Box2.Box2_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct ABox2_C : public AMovable_Object_Replicated_C
{

}; 



