#pragma once 
#include "SDK.h" 
 
 
// Function BetterMoveTo.BetterMoveTo_C.ExecuteUbergraph_BetterMoveTo
// Size: 0x24(Inherited: 0x0) 
struct FExecuteUbergraph_BetterMoveTo
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct FVector CallFunc_GetBlackboardValueAsVector_ReturnValue;  // 0x18(0xC)

}; 
// Function BetterMoveTo.BetterMoveTo_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
