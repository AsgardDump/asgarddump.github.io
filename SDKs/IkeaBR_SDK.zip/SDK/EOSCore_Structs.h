#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction EOSCore.OnQueryFileListCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryFileListCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageQueryFileListCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreP2P.EOSP2PSendPacket
// Size: 0x90(Inherited: 0x0) 
struct FEOSP2PSendPacket
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PSendPacketOptions Options;  // 0x8(0x80)
	uint8_t  ReturnValue;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 
// DelegateFunction EOSCore.OnAchievementsQueryDefinitionsCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAchievementsQueryDefinitionsCallback__DelegateSignature
{
	struct FEOSAchievementsOnQueryDefinitionsCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSUserInfoQueryUserInfoOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerEndSessionOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatServerEndSessionOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// DelegateFunction EOSCore.OnAchievementsUnlockAchievementsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAchievementsUnlockAchievementsCallbackDelegate__DelegateSignature
{
	struct FEOSAchievementsOnUnlockAchievementsCompleteCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSAchievementsOnQueryDefinitionsCompleteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSAchievementsOnQueryDefinitionsCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// Function EOSCore.EOSCoreLibrary.EOSProductUserIdIsValid
// Size: 0x22(Inherited: 0x0) 
struct FEOSProductUserIdIsValid
{
	struct FEOSProductUserId ID;  // 0x0(0x21)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)

}; 
// ScriptStruct EOSCore.EOSAuthPinGrantInfo
// Size: 0x40(Inherited: 0x0) 
struct FEOSAuthPinGrantInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString UserCode;  // 0x8(0x10)
	struct FString VerificationURI;  // 0x18(0x10)
	int32_t ExpiresIn;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct FString VerificationURIComplete;  // 0x30(0x10)

}; 
// DelegateFunction EOSCore.OnAntiCheatServerOnClientAuthStatusChangedCallbackDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnAntiCheatServerOnClientAuthStatusChangedCallbackDelegate__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientAuthStatusChangedCallbackInfo Data;  // 0x0(0x18)

}; 
// ScriptStruct EOSCore.EOSProductUserId
// Size: 0x21(Inherited: 0x0) 
struct FEOSProductUserId
{
	char pad_0[33];  // 0x0(0x21)

}; 
// DelegateFunction EOSCore.OnAchievementsQueryPlayerAchievementsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAchievementsQueryPlayerAchievementsCallback__DelegateSignature
{
	struct FEOSAchievementsOnQueryPlayerAchievementsCompleteCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnAchievementsUnlockAchievementsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAchievementsUnlockAchievementsCallback__DelegateSignature
{
	struct FEOSAchievementsOnUnlockAchievementsCompleteCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSAchievementsOnQueryPlayerAchievementsCompleteCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSAchievementsOnQueryPlayerAchievementsCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId UserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSEcomGetOfferCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSEcomGetOfferCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// DelegateFunction EOSCore.OnAchievementsUnlockedV2Callback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnAchievementsUnlockedV2Callback__DelegateSignature
{
	struct FEOSAchievementsOnAchievementsUnlockedCallbackV2Info Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientOnMessageToServerCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSAntiCheatClientOnMessageToServerCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString MessageData;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSAchievementsOnUnlockAchievementsCompleteCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSAchievementsOnUnlockAchievementsCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId UserId;  // 0x10(0x21)
	char pad_49[3];  // 0x31(0x3)
	int32_t AchievementsCount;  // 0x34(0x4)

}; 
// DelegateFunction EOSCore.OnLinkAccountCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnLinkAccountCallback__DelegateSignature
{
	struct FEOSConnectLinkAccountCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreSessions.EOSSessionsQueryInvites
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionsQueryInvites
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsQueryInvitesOptions Options;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate Callback;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionsCopySessionHandleByInviteId
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionsCopySessionHandleByInviteId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsCopySessionHandleByInviteIdOptions Options;  // 0x8(0x10)
	struct FEOSHSessionDetails OutSessionHandle;  // 0x18(0x8)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyInviteAcceptedCallbackInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSLobbyInviteAcceptedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString InviteId;  // 0x8(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x18(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x39(0x21)
	char pad_90[6];  // 0x5A(0x6)
	struct FString LobbyID;  // 0x60(0x10)

}; 
// ScriptStruct EOSCore.EOSAchievementsOnAchievementsUnlockedCallbackV2Info
// Size: 0x58(Inherited: 0x0) 
struct FEOSAchievementsOnAchievementsUnlockedCallbackV2Info
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId UserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString AchievementId;  // 0x30(0x10)
	struct FString UnlockTime;  // 0x40(0x10)
	struct FEOSNotificationId NotificationID;  // 0x50(0x8)

}; 
// ScriptStruct EOSCore.EOSNotificationId
// Size: 0x8(Inherited: 0x0) 
struct FEOSNotificationId
{
	char pad_0[8];  // 0x0(0x8)

}; 
// DelegateFunction EOSCore.OnAchievementsQueryDefinitionsCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAchievementsQueryDefinitionsCallbackDelegate__DelegateSignature
{
	struct FEOSAchievementsOnQueryDefinitionsCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.CoreRTC.GetRTC
// Size: 0x10(Inherited: 0x0) 
struct FGetRTC
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreRTC* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreRTC.EOSRTCJoinRoom
// Size: 0xA0(Inherited: 0x0) 
struct FEOSRTCJoinRoom
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FJoinRoomOptions Options;  // 0x8(0x88)
	struct FDelegate Callback;  // 0x90(0x10)

}; 
// DelegateFunction EOSCore.OnAchievementsQueryPlayerAchievementsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAchievementsQueryPlayerAchievementsCallbackDelegate__DelegateSignature
{
	struct FEOSAchievementsOnQueryPlayerAchievementsCompleteCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSSessionsCopySessionHandleByUiEventIdOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSSessionsCopySessionHandleByUiEventIdOptions
{
	struct FEOSUIEventId UiEventId;  // 0x0(0x8)

}; 
// Function EOSCore.EOSCoreStatsQueryStats.EOSStatsQueryStatsAsync
// Size: 0x90(Inherited: 0x0) 
struct FEOSStatsQueryStatsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSStatsQueryStatsOptions Options;  // 0x8(0x80)
	struct UEOSCoreStatsQueryStats* ReturnValue;  // 0x88(0x8)

}; 
// DelegateFunction EOSCore.OnQueryProductUserIdMappingsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryProductUserIdMappingsCallback__DelegateSignature
{
	struct FEOSConnectQueryProductUserIdMappingsCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnInstallModCallbackDelegate__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnInstallModCallbackDelegate__DelegateSignature
{
	struct FEOSModsInstallModCallbackInfo Data;  // 0x0(0x88)

}; 
// ScriptStruct EOSCore.EOSAchievementsQueryDefinitionsOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSAchievementsQueryDefinitionsOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// DelegateFunction EOSCore.OnPresenceQueryPresenceCompleteCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnPresenceQueryPresenceCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPresenceQueryPresenceCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnAchievementsUnlockedCallbackV2Delegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnAchievementsUnlockedCallbackV2Delegate__DelegateSignature
{
	struct FEOSAchievementsOnAchievementsUnlockedCallbackV2Info Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSFriendsGetFriendAtIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSFriendsGetFriendAtIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t Index;  // 0x28(0x4)

}; 
// DelegateFunction EOSCore.OnCustomInvitesOnSendCustomInviteCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnCustomInvitesOnSendCustomInviteCallback__DelegateSignature
{
	struct FEOSCustomInvitesOnSendCustomInviteCallbackInfo Data;  // 0x0(0x48)

}; 
// Function EOSCore.CoreFriends.EOSFriendsRemoveNotifyFriendsUpdate
// Size: 0x10(Inherited: 0x0) 
struct FEOSFriendsRemoveNotifyFriendsUpdate
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnAntiCheatServerOnMessageToClientCallback__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatServerOnMessageToClientCallback__DelegateSignature
{
	struct FEOSAntiCheatCommonOnMessageToClientCallbackInfo Data;  // 0x0(0x28)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnMessageToServerCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnAntiCheatClientOnMessageToServerCallback__DelegateSignature
{
	struct FEOSAntiCheatClientOnMessageToServerCallbackInfo Data;  // 0x0(0x20)

}; 
// DelegateFunction EOSCore.OnLoginCallback__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnLoginCallback__DelegateSignature
{
	struct FEOSConnectLoginCallbackInfo Data;  // 0x0(0x40)

}; 
// DelegateFunction EOSCore.OnFileTransferProgressCallbackDelegate__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnFileTransferProgressCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageFileTransferProgressCallbackInfo Data;  // 0x0(0x48)

}; 
// ScriptStruct EOSCore.EOSSetParticipantHardMuteCompleteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSetParticipantHardMuteCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnMessageToPeerCallback__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatClientOnMessageToPeerCallback__DelegateSignature
{
	struct FEOSAntiCheatCommonOnMessageToClientCallbackInfo Data;  // 0x0(0x28)

}; 
// DelegateFunction EOSCore.OnAntiCheatServerOnClientActionRequiredCallback__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatServerOnClientActionRequiredCallback__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientActionRequiredCallbackInfo Data;  // 0x0(0x28)

}; 
// Function EOSCore.EOSCoreLibrary.GetInteger
// Size: 0x40(Inherited: 0x0) 
struct FGetInteger
{
	struct FEOSSessionSetting Settings;  // 0x0(0x28)
	struct FString Key;  // 0x28(0x10)
	int32_t ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function EOSCore.EOSCoreAuthLogin.EOSAuthLoginAsync
// Size: 0x50(Inherited: 0x0) 
struct FEOSAuthLoginAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthLoginOptions Options;  // 0x8(0x40)
	struct UEOSCoreAuthLogin* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction EOSCore.OnLobbyCreateLobbyCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyCreateLobbyCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyCreateLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSSessionDetailsSettings
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionDetailsSettings
{
	struct FString BucketId;  // 0x0(0x10)
	int32_t NumPublicConnections;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool bAllowJoinInProgress : 1;  // 0x14(0x1)
	uint8_t  PermissionLevel;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool bInvitesAllowed : 1;  // 0x16(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool bSanctionsEnabled : 1;  // 0x17(0x1)

}; 
// ScriptStruct EOSCore.EOSModsEnumerateModsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSModsEnumerateModsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	struct FEOSEpicAccountId LocalUserId;  // 0x1(0x21)
	char pad_34[14];  // 0x22(0xE)
	uint8_t  Type;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientReceiveMessageFromServer
// Size: 0x20(Inherited: 0x0) 
struct FEOSAntiCheatClientReceiveMessageFromServer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientReceiveMessageFromServerOptions Options;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonOnMessageToClientCallbackInfo
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatCommonOnMessageToClientCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x8(0x8)
	struct FString MessageData;  // 0x10(0x10)
	char pad_32[8];  // 0x20(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonClientHandle
// Size: 0x8(Inherited: 0x0) 
struct FEOSAntiCheatCommonClientHandle
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonOnClientActionRequiredCallbackInfo
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatCommonOnClientActionRequiredCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x8(0x8)
	uint8_t  ClientAction;  // 0x10(0x1)
	uint8_t  ActionReasonCode;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct FString ActionReasonDetailsString;  // 0x18(0x10)

}; 
// ScriptStruct EOSCore.EOSActiveSessionGetRegisteredPlayerCountOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSActiveSessionGetRegisteredPlayerCountOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// DelegateFunction EOSCore.OnLobbyQueryInvitesCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnLobbyQueryInvitesCallback__DelegateSignature
{
	struct FEOSLobbyQueryInvitesCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnPeerActionRequiredCallback__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatClientOnPeerActionRequiredCallback__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientActionRequiredCallbackInfo Data;  // 0x0(0x28)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogGameRoundEndOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogGameRoundEndOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t WinningTeamId;  // 0x4(0x4)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnPeerAuthStatusChangedCallback__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnAntiCheatClientOnPeerAuthStatusChangedCallback__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientAuthStatusChangedCallbackInfo Data;  // 0x0(0x18)

}; 
// DelegateFunction EOSCore.OnEcomQueryCheckoutCallbackDelegate__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnEcomQueryCheckoutCallbackDelegate__DelegateSignature
{
	struct FEOSEcomCheckoutCallbackInfo Data;  // 0x0(0x48)

}; 
// DelegateFunction EOSCore.OnSessionEndSessionCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionEndSessionCallback__DelegateSignature
{
	struct FEOSSessionsEndSessionCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnCreateDeviceIdCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnCreateDeviceIdCallback__DelegateSignature
{
	struct FEOSConnectCreateDeviceIdCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAuthLoginOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSAuthLoginOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAuthCredentials Credentials;  // 0x8(0x30)
	int32_t ScopeFlags;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// DelegateFunction EOSCore.OnLobbyFindCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnLobbyFindCallback__DelegateSignature
{
	struct FEOSLobbySearchFindCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonOnClientAuthStatusChangedCallbackInfo
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatCommonOnClientAuthStatusChangedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x8(0x8)
	uint8_t  ClientAuthStatus;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSAchievementsGetPlayerAchievementCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSAchievementsGetPlayerAchievementCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId UserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// DelegateFunction EOSCore.OnFriendsUpdateCallbackDelegate__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnFriendsUpdateCallbackDelegate__DelegateSignature
{
	struct FEOSFriendsOnFriendsUpdateInfo Data;  // 0x0(0x50)

}; 
// ScriptStruct EOSCore.EOSUISetDisplayPreferenceOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSUISetDisplayPreferenceOptions
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  NotificationLocation;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// DelegateFunction EOSCore.OnAntiCheatServerOnMessageToClientCallbackDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatServerOnMessageToClientCallbackDelegate__DelegateSignature
{
	struct FEOSAntiCheatCommonOnMessageToClientCallbackInfo Data;  // 0x0(0x28)

}; 
// ScriptStruct EOSCore.EOSAddNotifyAudioInputStateOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAddNotifyAudioInputStateOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSTitleStorageDeleteCacheCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageDeleteCacheCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesOnSendCustomInviteCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSCustomInvitesOnSendCustomInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct TArray<struct FEOSProductUserId> TargetUserIds;  // 0x38(0x10)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnMessageToServerCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnAntiCheatClientOnMessageToServerCallbackDelegate__DelegateSignature
{
	struct FEOSAntiCheatClientOnMessageToServerCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.EOSCoreFriendsAcceptInvite.EOSFriendsAcceptInviteAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsAcceptInviteAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsAcceptInviteOptions Options;  // 0x8(0x48)
	struct UEOSCoreFriendsAcceptInvite* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.EOSCoreLibrary.EOSEResultIsOperationComplete
// Size: 0x2(Inherited: 0x0) 
struct FEOSEResultIsOperationComplete
{
	uint8_t  Result;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// ScriptStruct EOSCore.EOSAuthIdToken
// Size: 0x38(Inherited: 0x0) 
struct FEOSAuthIdToken
{
	struct FEOSEpicAccountId AccountId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString JsonWebToken;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnLoginCallbackDelegate__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnLoginCallbackDelegate__DelegateSignature
{
	struct FEOSConnectLoginCallbackInfo Data;  // 0x0(0x40)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnMessageToPeerCallbackDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatClientOnMessageToPeerCallbackDelegate__DelegateSignature
{
	struct FEOSAntiCheatCommonOnMessageToClientCallbackInfo Data;  // 0x0(0x28)

}; 
// DelegateFunction EOSCore.OnAntiCheatServerOnClientActionRequiredCallbackDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatServerOnClientActionRequiredCallbackDelegate__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientActionRequiredCallbackInfo Data;  // 0x0(0x28)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsRemoveNotifyAchievementsUnlocked
// Size: 0x10(Inherited: 0x0) 
struct FEOSAchievementsRemoveNotifyAchievementsUnlocked
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnPeerActionRequiredCallbackDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnAntiCheatClientOnPeerActionRequiredCallbackDelegate__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientActionRequiredCallbackInfo Data;  // 0x0(0x28)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardRecordByUserId
// Size: 0x78(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardRecordByUserId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsCopyLeaderboardRecordByUserIdOptions Options;  // 0x8(0x28)
	struct FEOSLeaderboardsLeaderboardRecord OutLeaderboardRecord;  // 0x30(0x40)
	uint8_t  ReturnValue;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct EOSCore.EOSConnectCreateDeviceIdCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSConnectCreateDeviceIdCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyParticipantUpdated
// Size: 0x18(Inherited: 0x0) 
struct FEOSRTCAudioRemoveNotifyParticipantUpdated
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSNotificationId NotificationID;  // 0x10(0x8)

}; 
// ScriptStruct EOSCore.EOSAuthLogoutOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSAuthLogoutOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// DelegateFunction EOSCore.OnAntiCheatClientOnPeerAuthStatusChangedCallbackDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnAntiCheatClientOnPeerAuthStatusChangedCallbackDelegate__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientAuthStatusChangedCallbackInfo Data;  // 0x0(0x18)

}; 
// DelegateFunction EOSCore.OnLobbyMemberUpdateReceivedCallback__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnLobbyMemberUpdateReceivedCallback__DelegateSignature
{
	struct FEOSLobbyMemberUpdateReceivedCallbackInfo Data;  // 0x0(0x40)

}; 
// ScriptStruct EOSCore.EOSSessionsSessionInviteAcceptedCallbackInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSSessionsSessionInviteAcceptedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString SessionID;  // 0x8(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x18(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x39(0x21)
	char pad_90[6];  // 0x5A(0x6)
	struct FString InviteId;  // 0x60(0x10)

}; 
// ScriptStruct EOSCore.EOSPresenceModificationDeleteDataOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSPresenceModificationDeleteDataOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct FEOSPresenceModificationDataRecordId> Records;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnAntiCheatServerOnClientAuthStatusChangedCallback__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnAntiCheatServerOnClientAuthStatusChangedCallback__DelegateSignature
{
	struct FEOSAntiCheatCommonOnClientAuthStatusChangedCallbackInfo Data;  // 0x0(0x18)

}; 
// Function EOSCore.CoreMods.EOSModsEnumerateMods
// Size: 0x40(Inherited: 0x0) 
struct FEOSModsEnumerateMods
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSModsEnumerateModsOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// DelegateFunction EOSCore.OnAuthLinkAccountCallbackDelegate__DelegateSignature
// Size: 0xA0(Inherited: 0x0) 
struct FOnAuthLinkAccountCallbackDelegate__DelegateSignature
{
	struct FEOSAuthLinkAccountCallbackInfo Data;  // 0x0(0xA0)

}; 
// ScriptStruct EOSCore.EOSHLobbyModification
// Size: 0x8(Inherited: 0x0) 
struct FEOSHLobbyModification
{
	char pad_0[8];  // 0x0(0x8)

}; 
// DelegateFunction EOSCore.OnUnlinkAccountCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnUnlinkAccountCallback__DelegateSignature
{
	struct FEOSConnectUnlinkAccountCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreP2P.EOSP2PSetRelayControl
// Size: 0x18(Inherited: 0x0) 
struct FEOSP2PSetRelayControl
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PSetRelayControlOptions Options;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSConnectLoginCallbackInfo
// Size: 0x40(Inherited: 0x0) 
struct FEOSConnectLoginCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FContinuanceToken ContinuanceToken;  // 0x38(0x8)

}; 
// DelegateFunction EOSCore.OnQueryExternalAccountMappingsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryExternalAccountMappingsCallbackDelegate__DelegateSignature
{
	struct FEOSConnectQueryExternalAccountMappingsCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.ContinuanceToken
// Size: 0x8(Inherited: 0x0) 
struct FContinuanceToken
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyAddNotifyJoinLobbyAccepted
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyAddNotifyJoinLobbyAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyAddNotifyJoinLobbyAcceptedOptions Options;  // 0x8(0x4)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreConnect.EOSConnectAddNotifyAuthExpiration
// Size: 0x20(Inherited: 0x0) 
struct FEOSConnectAddNotifyAuthExpiration
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbySendInvite
// Size: 0x70(Inherited: 0x0) 
struct FEOSLobbySendInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbySendInviteOptions Options;  // 0x8(0x58)
	struct FDelegate Callback;  // 0x60(0x10)

}; 
// DelegateFunction EOSCore.OnCreateUserCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnCreateUserCallback__DelegateSignature
{
	struct FEOSConnectCreateUserCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSConnectCreateUserCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectCreateUserCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionsUpdateSessionModificationOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsUpdateSessionModificationOptions
{
	struct FString SessionName;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectLinkAccountCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectLinkAccountCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionsRemoveNotifySessionInviteReceived
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsRemoveNotifySessionInviteReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionsGetInviteIdByIndex
// Size: 0x48(Inherited: 0x0) 
struct FEOSSessionsGetInviteIdByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsGetInviteIdByIndexOptions Options;  // 0x8(0x28)
	struct FString OutBuffer;  // 0x30(0x10)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct EOSCore.EOSAchievementsCopyAchievementDefinitionV2ByIndexOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSAchievementsCopyAchievementDefinitionV2ByIndexOptions
{
	int32_t AchievementIndex;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSUserInfoQueryUserInfoByDisplayNameOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByDisplayNameOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString DisplayName;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnFriendsQueryFriendsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnFriendsQueryFriendsCallback__DelegateSignature
{
	struct FEOSFriendsQueryFriendsCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreConnect.EOSConnectLogin
// Size: 0x48(Inherited: 0x0) 
struct FEOSConnectLogin
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectLoginOptions Options;  // 0x8(0x30)
	struct FDelegate Callback;  // 0x38(0x10)

}; 
// DelegateFunction EOSCore.OnTransferDeviceIdAccountCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTransferDeviceIdAccountCallback__DelegateSignature
{
	struct FEOSConnectTransferDeviceIdAccountCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsGetMemberCount
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyDetailsGetMemberCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsGetMemberCountOptions Options;  // 0x10(0x4)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// ScriptStruct EOSCore.EOSAuthToken
// Size: 0xB0(Inherited: 0x0) 
struct FEOSAuthToken
{
	struct FString App;  // 0x0(0x10)
	struct FString ClientId;  // 0x10(0x10)
	struct FEOSEpicAccountId AccountId;  // 0x20(0x21)
	char pad_65[7];  // 0x41(0x7)
	struct FString AccessToken;  // 0x48(0x10)
	struct FString ExpiresIn;  // 0x58(0x10)
	struct FString ExpiresAt;  // 0x68(0x10)
	uint8_t  AuthType;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct FString RefreshToken;  // 0x80(0x10)
	struct FString RefreshExpiresIn;  // 0x90(0x10)
	struct FString RefreshExpiresAt;  // 0xA0(0x10)

}; 
// ScriptStruct EOSCore.EOSFriendsQueryFriendsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSFriendsQueryFriendsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSConnectUnlinkAccountCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectUnlinkAccountCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientEndSession
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatClientEndSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientEndSessionOptions Options;  // 0x8(0x1)
	uint8_t  ReturnValue;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function EOSCore.EOSCoreLibrary.EOSByteArrayToString
// Size: 0x30(Inherited: 0x0) 
struct FEOSByteArrayToString
{
	struct TArray<char> Array;  // 0x0(0x10)
	int32_t Length;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString String;  // 0x18(0x10)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// DelegateFunction EOSCore.OnDeleteDeviceIdCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnDeleteDeviceIdCallback__DelegateSignature
{
	struct FEOSConnectDeleteDeviceIdCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectDeleteDeviceIdCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSConnectDeleteDeviceIdCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnAuthVerifyUserAuthCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAuthVerifyUserAuthCallbackDelegate__DelegateSignature
{
	struct FEOSAuthVerifyUserAuthCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsOnQueryLeaderboardUserScoresCompleteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSLeaderboardsOnQueryLeaderboardUserScoresCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct EOSCore.EOSConnectTransferDeviceIdAccountCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectTransferDeviceIdAccountCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction EOSCore.OnAuthDeletePersistentAuthCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAuthDeletePersistentAuthCallbackDelegate__DelegateSignature
{
	struct FEOSAuthDeletePersistentAuthCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnAuthLinkAccountCallback__DelegateSignature
// Size: 0xA0(Inherited: 0x0) 
struct FOnAuthLinkAccountCallback__DelegateSignature
{
	struct FEOSAuthLinkAccountCallbackInfo Data;  // 0x0(0xA0)

}; 
// DelegateFunction EOSCore.OnQueryExternalAccountMappingsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryExternalAccountMappingsCallback__DelegateSignature
{
	struct FEOSConnectQueryExternalAccountMappingsCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSConnectCopyProductUserExternalAccountByAccountIdOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectCopyProductUserExternalAccountByAccountIdOptions
{
	struct FEOSProductUserId TargetUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString AccountId;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectQueryExternalAccountMappingsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectQueryExternalAccountMappingsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSConnectQueryProductUserIdMappingsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectQueryProductUserIdMappingsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.EOSCoreLobbySearchFind.EOSLobbySearchFindAsync
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbySearchFindAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchFindOptions Options;  // 0x10(0x28)
	struct UEOSCoreLobbySearchFind* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct EOSCore.EOSUpdateSendingOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSUpdateSendingOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)
	uint8_t  AudioStatus;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// DelegateFunction EOSCore.OnLoginStatusChangedCallback__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnLoginStatusChangedCallback__DelegateSignature
{
	struct FEOSConnectLoginStatusChangedCallbackInfo Data;  // 0x0(0x30)

}; 
// ScriptStruct EOSCore.EOSHPresenceModification
// Size: 0x8(Inherited: 0x0) 
struct FEOSHPresenceModification
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerUseWeaponData
// Size: 0x40(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerUseWeaponData
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle PlayerHandle;  // 0x8(0x8)
	struct FEOSAntiCheatCommonVec3f PlayerPosition;  // 0x10(0xC)
	struct FEOSAntiCheatCommonQuat PlayerViewRotation;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bIsPlayerViewZoomed : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool bIsMeleeAttack : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	struct FString WeaponName;  // 0x30(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectLoginStatusChangedCallbackInfo
// Size: 0x30(Inherited: 0x0) 
struct FEOSConnectLoginStatusChangedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	uint8_t  PreviousStatus;  // 0x29(0x1)
	uint8_t  CurrentStatus;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)

}; 
// ScriptStruct EOSCore.EOSAchievementsAddNotifyAchievementsUnlockedV2Options
// Size: 0x4(Inherited: 0x0) 
struct FEOSAchievementsAddNotifyAchievementsUnlockedV2Options
{
	char pad_0[4];  // 0x0(0x4)

}; 
// DelegateFunction EOSCore.OnCustomInvitesOnCustomInviteReceivedCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnCustomInvitesOnCustomInviteReceivedCallback__DelegateSignature
{
	struct FEOSCustomInvitesOnCustomInviteReceivedCallbackInfo Data;  // 0x0(0x70)

}; 
// DelegateFunction EOSCore.OnAuthExpirationCallback__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnAuthExpirationCallback__DelegateSignature
{
	struct FEOSConnectAuthExpirationCallbackInfo Data;  // 0x0(0x30)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerBeginSessionOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSAntiCheatServerBeginSessionOptions
{
	int32_t RegisterTimeoutSeconds;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ServerName;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bEnableGameplayData : 1;  // 0x18(0x1)
	struct FEOSProductUserId LocalUserId;  // 0x19(0x21)
	char pad_58[6];  // 0x3A(0x6)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerGetProtectMessageOutputLengthOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSAntiCheatServerGetProtectMessageOutputLengthOptions
{
	int32_t DataLengthBytes;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSConnectAuthExpirationCallbackInfo
// Size: 0x30(Inherited: 0x0) 
struct FEOSConnectAuthExpirationCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct EOSCore.EOSUIEventId
// Size: 0x8(Inherited: 0x0) 
struct FEOSUIEventId
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerSetClientDetails
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerSetClientDetails
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonSetClientDetailsOptions Options;  // 0x8(0x18)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyTransactionById
// Size: 0x50(Inherited: 0x0) 
struct FEOSEcomCopyTransactionById
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyTransactionByIdOptions Options;  // 0x8(0x38)
	struct FEOSEcomHTransaction OutTransaction;  // 0x40(0x8)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction EOSCore.OnConnectVerifyIdTokenCallback__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FOnConnectVerifyIdTokenCallback__DelegateSignature
{
	struct FEOSConnectOnVerifyIdTokenCallback Data;  // 0x0(0xA8)

}; 
// Function EOSCore.CoreSessions.EOSSessionsRejectInvite
// Size: 0x50(Inherited: 0x0) 
struct FEOSSessionsRejectInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsRejectInviteOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// DelegateFunction EOSCore.OnSessionJoinSessionCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionJoinSessionCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsJoinSessionCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectOnVerifyIdTokenCallback
// Size: 0xA8(Inherited: 0x0) 
struct FEOSConnectOnVerifyIdTokenCallback
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId ProductUserId;  // 0x10(0x21)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bIsAccountInfoPresent : 1;  // 0x31(0x1)
	uint8_t  AccountIdType;  // 0x32(0x1)
	char pad_51[5];  // 0x33(0x5)
	struct FString AccountId;  // 0x38(0x10)
	struct FString platform;  // 0x48(0x10)
	struct FString DeviceType;  // 0x58(0x10)
	struct FString ClientId;  // 0x68(0x10)
	struct FString ProductId;  // 0x78(0x10)
	struct FString SandboxId;  // 0x88(0x10)
	struct FString DeploymentId;  // 0x98(0x10)

}; 
// ScriptStruct EOSCore.EOSSanctionsQueryActivePlayerSanctionsCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSSanctionsQueryActivePlayerSanctionsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId TargetUserId;  // 0x10(0x21)
	struct FEOSProductUserId LocalUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// Function EOSCore.CoreSanctions.EOSSanctionsCopyPlayerSanctionByIndex
// Size: 0x60(Inherited: 0x0) 
struct FEOSSanctionsCopyPlayerSanctionByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSanctionsCopyPlayerSanctionByIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSSanctionsPlayerSanction OutSanction;  // 0x38(0x20)
	uint8_t  ReturnValue;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// DelegateFunction EOSCore.OnCreateUserCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnCreateUserCallbackDelegate__DelegateSignature
{
	struct FEOSConnectCreateUserCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreFriends.GetFriends
// Size: 0x10(Inherited: 0x0) 
struct FGetFriends
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreFriends* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.EOSCoreEcomQueryOwnershipToken.EOSEcomQueryOwnershipTokenAsync
// Size: 0x60(Inherited: 0x0) 
struct FEOSEcomQueryOwnershipTokenAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryOwnershipTokenOptions Options;  // 0x8(0x50)
	struct UEOSCoreEcomQueryOwnershipToken* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction EOSCore.OnLinkAccountCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnLinkAccountCallbackDelegate__DelegateSignature
{
	struct FEOSConnectLinkAccountCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSUserInfoQueryUserInfoCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoCallbackInfo
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  ResultCode;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// DelegateFunction EOSCore.OnUnlinkAccountCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnUnlinkAccountCallbackDelegate__DelegateSignature
{
	struct FEOSConnectUnlinkAccountCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnSessionEndSessionCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionEndSessionCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsEndSessionCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnCreateDeviceIdCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnCreateDeviceIdCallbackDelegate__DelegateSignature
{
	struct FEOSConnectCreateDeviceIdCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnDeleteDeviceIdCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnDeleteDeviceIdCallbackDelegate__DelegateSignature
{
	struct FEOSConnectDeleteDeviceIdCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnStatsQueryStatsCompleteCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnStatsQueryStatsCompleteCallback__DelegateSignature
{
	struct FEOSStatsOnQueryStatsCompleteCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnTransferDeviceIdAccountCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTransferDeviceIdAccountCallbackDelegate__DelegateSignature
{
	struct FEOSConnectTransferDeviceIdAccountCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnFriendsUpdateCallback__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnFriendsUpdateCallback__DelegateSignature
{
	struct FEOSFriendsOnFriendsUpdateInfo Data;  // 0x0(0x50)

}; 
// Function EOSCore.EOSCoreSessionsJoinSession.EOSSessionsJoinSessionAsync
// Size: 0x50(Inherited: 0x0) 
struct FEOSSessionsJoinSessionAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsJoinSessionOptions Options;  // 0x8(0x40)
	struct UEOSCoreSessionsJoinSession* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction EOSCore.OnSessionJoinSessionAcceptedCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnSessionJoinSessionAcceptedCallback__DelegateSignature
{
	struct FEOSSessionsJoinSessionAcceptedCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnQueryProductUserIdMappingsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryProductUserIdMappingsCallbackDelegate__DelegateSignature
{
	struct FEOSConnectQueryProductUserIdMappingsCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreConnect.GetConnect
// Size: 0x10(Inherited: 0x0) 
struct FGetConnect
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreConnect* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSTitleStorageFileTransferProgressCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSTitleStorageFileTransferProgressCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString Filename;  // 0x30(0x10)
	int32_t bytesTransferred;  // 0x40(0x4)
	int32_t TotalFileSizeBytes;  // 0x44(0x4)

}; 
// ScriptStruct EOSCore.EOSTitleStorageCopyFileMetadataAtIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSTitleStorageCopyFileMetadataAtIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t Index;  // 0x28(0x4)

}; 
// DelegateFunction EOSCore.OnAuthExpirationCallbackDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnAuthExpirationCallbackDelegate__DelegateSignature
{
	struct FEOSConnectAuthExpirationCallbackInfo Data;  // 0x0(0x30)

}; 
// DelegateFunction EOSCore.OnLoginStatusChangedCallbackDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnLoginStatusChangedCallbackDelegate__DelegateSignature
{
	struct FEOSConnectLoginStatusChangedCallbackInfo Data;  // 0x0(0x30)

}; 
// ScriptStruct EOSCore.EOSHSessionSearch
// Size: 0x8(Inherited: 0x0) 
struct FEOSHSessionSearch
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function EOSCore.CoreSessions.EOSActiveSessionCopyInfo
// Size: 0x98(Inherited: 0x0) 
struct FEOSActiveSessionCopyInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHActiveSession Handle;  // 0x8(0x8)
	struct FEOSActiveSessionCopyInfoOptions Options;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FEOSActiveSessionInfo OutActiveSessionInfo;  // 0x18(0x78)
	uint8_t  ReturnValue;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
// Function EOSCore.CoreP2P.EOSP2PReceivePacket
// Size: 0x98(Inherited: 0x0) 
struct FEOSP2PReceivePacket
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PReceivePacketOptions Options;  // 0x8(0x30)
	struct FEOSProductUserId OutPeerId;  // 0x38(0x21)
	char pad_89[7];  // 0x59(0x7)
	struct FEOSP2PSocketId OutSocketId;  // 0x60(0x18)
	int32_t OutChannel;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct TArray<char> OutData;  // 0x80(0x10)
	int32_t OutBytesWritten;  // 0x90(0x4)
	uint8_t  ReturnValue;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsCopyInfoOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyInfoOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageQueryFile
// Size: 0x50(Inherited: 0x0) 
struct FEOSTitleStorageQueryFile
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageQueryFileOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientBeginSessionOptions
// Size: 0x22(Inherited: 0x0) 
struct FEOSAntiCheatClientBeginSessionOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	uint8_t  Mode;  // 0x21(0x1)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientGetProtectMessageOutputLengthOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSAntiCheatClientGetProtectMessageOutputLengthOptions
{
	int32_t DataLengthBytes;  // 0x0(0x4)

}; 
// DelegateFunction EOSCore.OnAuthLoginCallback__DelegateSignature
// Size: 0x90(Inherited: 0x0) 
struct FOnAuthLoginCallback__DelegateSignature
{
	struct FEOSAuthLoginCallbackInfo Data;  // 0x0(0x90)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesAddNotifyCustomInviteReceivedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSCustomInvitesAddNotifyCustomInviteReceivedOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSTitleStorageFileMetadata
// Size: 0x28(Inherited: 0x0) 
struct FEOSTitleStorageFileMetadata
{
	char pad_0[4];  // 0x0(0x4)
	int32_t FileSizeBytes;  // 0x4(0x4)
	struct FString MD5Hash;  // 0x8(0x10)
	struct FString Filename;  // 0x18(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerProtectMessageOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerProtectMessageOptions
{
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x0(0x8)
	int32_t DataLengthBytes;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<char> Data;  // 0x10(0x10)
	int32_t OutBufferSizeBytes;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct EOSCore.EOSAuthLoginCallbackInfo
// Size: 0x90(Inherited: 0x0) 
struct FEOSAuthLoginCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FEOSAuthPinGrantInfo PinGrantInfo;  // 0x38(0x40)
	struct FEOSAuthAccountFeatureRestrictedInfo AccountFeatureRestrictedInfo;  // 0x78(0x18)

}; 
// ScriptStruct EOSCore.EOSLobbyMemberStatusReceivedCallbackInfo
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbyMemberStatusReceivedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString LobbyID;  // 0x8(0x10)
	struct FEOSProductUserId TargetUserId;  // 0x18(0x21)
	uint8_t  CurrentStatus;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// DelegateFunction EOSCore.OnLobbyLeaveLobbyCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyLeaveLobbyCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyLeaveLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.EOSCoreLibrary.EOSProductUserIdFromString
// Size: 0x38(Inherited: 0x0) 
struct FEOSProductUserIdFromString
{
	struct FString String;  // 0x0(0x10)
	struct FEOSProductUserId ReturnValue;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSAuthAccountFeatureRestrictedInfo
// Size: 0x18(Inherited: 0x0) 
struct FEOSAuthAccountFeatureRestrictedInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString VerificationURI;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnPresenceSetPresenceCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnPresenceSetPresenceCompleteCallback__DelegateSignature
{
	struct FEOSPresenceSetPresenceCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSEpicAccountId
// Size: 0x21(Inherited: 0x0) 
struct FEOSEpicAccountId
{
	char pad_0[33];  // 0x0(0x21)

}; 
// DelegateFunction EOSCore.OnEcomQueryOwnershipTokenCallbackDelegate__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnEcomQueryOwnershipTokenCallbackDelegate__DelegateSignature
{
	struct FEOSEcomQueryOwnershipTokenCallbackInfo Data;  // 0x0(0x48)

}; 
// Function EOSCore.EOSCoreUserInfoByExternalAccount.HandleCallback
// Size: 0x78(Inherited: 0x0) 
struct FHandleCallback
{
	struct FEOSUserInfoQueryUserInfoByExternalAccountCallbackInfo Data;  // 0x0(0x70)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bWasSuccessful : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesAddNotifyCustomInviteAcceptedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSCustomInvitesAddNotifyCustomInviteAcceptedOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// DelegateFunction EOSCore.OnFriendsAcceptInviteCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsAcceptInviteCallback__DelegateSignature
{
	struct FEOSFriendsAcceptInviteCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnAuthLogoutCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAuthLogoutCallback__DelegateSignature
{
	struct FEOSAuthLogoutCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.AddNotifyDisconnectedOptions
// Size: 0x38(Inherited: 0x0) 
struct FAddNotifyDisconnectedOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSHAuth
// Size: 0x8(Inherited: 0x0) 
struct FEOSHAuth
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageCopyFileMetadataByFilenameOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageCopyFileMetadataByFilenameOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Filename;  // 0x28(0x10)

}; 
// Function EOSCore.CoreConnect.EOSConnectQueryExternalAccountMappings
// Size: 0x50(Inherited: 0x0) 
struct FEOSConnectQueryExternalAccountMappings
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectQueryExternalAccountMappingsOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSAuthLogoutCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSAuthLogoutCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerSpawnOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerSpawnOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle SpawnedPlayerHandle;  // 0x8(0x8)
	int32_t TeamId;  // 0x10(0x4)
	int32_t CharacterId;  // 0x14(0x4)

}; 
// ScriptStruct EOSCore.EOSAuthLinkAccountCallbackInfo
// Size: 0xA0(Inherited: 0x0) 
struct FEOSAuthLinkAccountCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FEOSAuthPinGrantInfo PinGrantInfo;  // 0x38(0x40)
	struct FEOSEpicAccountId SelectedAccountId;  // 0x78(0x21)
	char pad_153[7];  // 0x99(0x7)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsLeaderboardRecord
// Size: 0x40(Inherited: 0x0) 
struct FEOSLeaderboardsLeaderboardRecord
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId UserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t Rank;  // 0x28(0x4)
	int32_t Score;  // 0x2C(0x4)
	struct FString UserDisplayName;  // 0x30(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyJoinLobbyAccepted
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyRemoveNotifyJoinLobbyAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnQueryLeaderboardUserScoresCompleteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnQueryLeaderboardUserScoresCompleteCallback__DelegateSignature
{
	struct FEOSLeaderboardsOnQueryLeaderboardUserScoresCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnAuthVerifyUserAuthCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAuthVerifyUserAuthCallback__DelegateSignature
{
	struct FEOSAuthVerifyUserAuthCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAuthVerifyUserAuthCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSAuthVerifyUserAuthCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnAuthDeletePersistentAuthCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnAuthDeletePersistentAuthCallback__DelegateSignature
{
	struct FEOSAuthDeletePersistentAuthCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.EOSCoreEcomQueryEntitlements.EOSEcomQueryEntitlementsAsync
// Size: 0x50(Inherited: 0x0) 
struct FEOSEcomQueryEntitlementsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryEntitlementsOptions Options;  // 0x8(0x40)
	struct UEOSCoreEcomQueryEntitlements* ReturnValue;  // 0x48(0x8)

}; 
// ScriptStruct EOSCore.EOSAuthDeletePersistentAuthCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSAuthDeletePersistentAuthCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct EOSCore.EOSFriendsSendInviteCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsSendInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// DelegateFunction EOSCore.OnLobbyRejectInviteCallbacDelegatek__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyRejectInviteCallbacDelegatek__DelegateSignature
{
	struct FEOSLobbyRejectInviteCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSLobbyCopyLobbyDetailsHandleByUiEventIdOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyCopyLobbyDetailsHandleByUiEventIdOptions
{
	struct FEOSUIEventId UiEventId;  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSGetAudioInputDeviceByIndexOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSGetAudioInputDeviceByIndexOptions
{
	int32_t DeviceInfoIndex;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSUserInfoCopyExternalUserInfoByAccountIdOptions
// Size: 0x58(Inherited: 0x0) 
struct FEOSUserInfoCopyExternalUserInfoByAccountIdOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)
	struct FString AccountId;  // 0x48(0x10)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthVerifyIdToken
// Size: 0x50(Inherited: 0x0) 
struct FEOSAuthVerifyIdToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthVerifyIdTokenOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// DelegateFunction EOSCore.OnAuthLoginStatusChangedCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAuthLoginStatusChangedCallback__DelegateSignature
{
	struct FEOSAuthLoginStatusChangedCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotEndSnapshot
// Size: 0x10(Inherited: 0x0) 
struct FEOSProgressionSnapshotEndSnapshot
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProgressionSnapshotEndSnapshotOptions Options;  // 0x8(0x4)
	uint8_t  ReturnValue;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeString
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddAttributeString
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  Visibility;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.EOSCoreEcomCheckout.EOSEcomCheckoutAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSEcomCheckoutAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCheckoutOptions Options;  // 0x8(0x48)
	struct UEOSCoreEcomCheckout* ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct EOSCore.EOSEcomQueryOffersCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomQueryOffersCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSAuthLoginStatusChangedCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSAuthLoginStatusChangedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	uint8_t  PrevStatus;  // 0x29(0x1)
	uint8_t  CurrentStatus;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)
	struct FEOSNotificationId NotificationID;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerReviveOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerReviveOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle RevivedPlayerHandle;  // 0x8(0x8)
	struct FEOSAntiCheatCommonClientHandle ReviverPlayerHandle;  // 0x10(0x8)

}; 
// DelegateFunction EOSCore.OnAuthQueryIdTokenCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnAuthQueryIdTokenCallback__DelegateSignature
{
	struct FEOSAuthQueryIdTokenCallbackInfo Data;  // 0x0(0x58)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsCopyAttributeByKey
// Size: 0x68(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyAttributeByKey
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsCopyAttributeByKeyOptions Options;  // 0x10(0x18)
	struct FEOSLobbyAttribute OutAttribute;  // 0x28(0x38)
	uint8_t  ReturnValue;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// DelegateFunction EOSCore.OnQueryUserInfoByDisplayNameCallback__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FOnQueryUserInfoByDisplayNameCallback__DelegateSignature
{
	struct FEOSUserInfoQueryUserInfoByDisplayNameCallbackInfo Data;  // 0x0(0x68)

}; 
// ScriptStruct EOSCore.EOSAuthQueryIdTokenCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSAuthQueryIdTokenCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetAccountId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// ScriptStruct EOSCore.EOSConnectCopyProductUserExternalAccountByAccountTypeOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSConnectCopyProductUserExternalAccountByAccountTypeOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	uint8_t  AccountIdType;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)

}; 
// DelegateFunction EOSCore.OnAuthVerifyIdTokenCallback__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FOnAuthVerifyIdTokenCallback__DelegateSignature
{
	struct FEOSAuthVerifyIdTokenCallbackInfo Data;  // 0x0(0xA8)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageQueryFileList
// Size: 0x40(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFileList
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageQueryFileListOptions QueryFileListOptions;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// ScriptStruct EOSCore.EOSProgressionSnapshotSubmitSnapshotCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSProgressionSnapshotSubmitSnapshotCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t SnapshotId;  // 0x4(0x4)
	char pad_8[8];  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnP2PQueryNATTypeCompleteCallback__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnP2PQueryNATTypeCompleteCallback__DelegateSignature
{
	struct FEOSP2POnQueryNATTypeCompleteInfo Data;  // 0x0(0x18)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeDouble
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddAttributeDouble
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  Visibility;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// ScriptStruct EOSCore.EOSAuthVerifyIdTokenCallbackInfo
// Size: 0xA8(Inherited: 0x0) 
struct FEOSAuthVerifyIdTokenCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString ApplicationId;  // 0x10(0x10)
	struct FString ClientId;  // 0x20(0x10)
	struct FString ProductId;  // 0x30(0x10)
	struct FString SandboxId;  // 0x40(0x10)
	struct FString DeploymentId;  // 0x50(0x10)
	struct FString DisplayName;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bIsExternalAccountInfoPresent : 1;  // 0x70(0x1)
	uint8_t  ExternalAccountIdType;  // 0x71(0x1)
	char pad_114[6];  // 0x72(0x6)
	struct FString ExternalAccountId;  // 0x78(0x10)
	struct FString ExternalAccountDisplayName;  // 0x88(0x10)
	struct FString platform;  // 0x98(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogEventOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogEventOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x8(0x8)
	int32_t EventId;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct FEOSAntiCheatCommonLogEventParamPair> Params;  // 0x18(0x10)

}; 
// DelegateFunction EOSCore.OnAuthLoginCallbackDelegate__DelegateSignature
// Size: 0x90(Inherited: 0x0) 
struct FOnAuthLoginCallbackDelegate__DelegateSignature
{
	struct FEOSAuthLoginCallbackInfo Data;  // 0x0(0x90)

}; 
// DelegateFunction EOSCore.OnFriendsAcceptInviteCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsAcceptInviteCallbackDelegate__DelegateSignature
{
	struct FEOSFriendsAcceptInviteCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnAuthLogoutCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAuthLogoutCallbackDelegate__DelegateSignature
{
	struct FEOSAuthLogoutCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSSessionsUpdateSessionCallbackInfo
// Size: 0x30(Inherited: 0x0) 
struct FEOSSessionsUpdateSessionCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString SessionName;  // 0x10(0x10)
	struct FString SessionID;  // 0x20(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectQueryProductUserIdMappingsOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectQueryProductUserIdMappingsOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FEOSProductUserId> ProductUserIds;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnAuthLoginStatusChangedCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnAuthLoginStatusChangedCallbackDelegate__DelegateSignature
{
	struct FEOSAuthLoginStatusChangedCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSRTCBlockParticipantCallbackInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSRTCBlockParticipantCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString RoomName;  // 0x38(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x48(0x21)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool bBlocked : 1;  // 0x69(0x1)
	char pad_106[6];  // 0x6A(0x6)

}; 
// DelegateFunction EOSCore.OnP2PIncomingConnectionRequestCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnP2PIncomingConnectionRequestCallback__DelegateSignature
{
	struct FEOSP2POnIncomingConnectionRequestInfo Data;  // 0x0(0x68)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bWasSuccessful : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationSetPermissionLevelOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyModificationSetPermissionLevelOptions
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  PermissionLevel;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function EOSCore.EOSCoreConnectCreateDeviceId.EOSConnectCreateDeviceIdAsync
// Size: 0x20(Inherited: 0x0) 
struct FEOSConnectCreateDeviceIdAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCreateDeviceIdOptions Options;  // 0x8(0x10)
	struct UEOSCoreConnectCreateDeviceId* ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreEcom.EOSEcomTransaction_GetTransactionId
// Size: 0x28(Inherited: 0x0) 
struct FEOSEcomTransaction_GetTransactionId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomHTransaction Handle;  // 0x8(0x8)
	struct FString OutTransactionId;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSP2POnIncomingConnectionRequestInfo
// Size: 0x68(Inherited: 0x0) 
struct FEOSP2POnIncomingConnectionRequestInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	struct FEOSProductUserId RemoteUserId;  // 0x29(0x21)
	char pad_74[6];  // 0x4A(0x6)
	struct FEOSP2PSocketId SocketId;  // 0x50(0x18)

}; 
// Function EOSCore.EOSCorePresenceSetPresence.EOSPresenceSetPresenceAsync
// Size: 0x40(Inherited: 0x0) 
struct FEOSPresenceSetPresenceAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceSetPresenceOptions Options;  // 0x8(0x30)
	struct UEOSCorePresenceSetPresence* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct EOSCore.EOSTitleStorageReadFileCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSTitleStorageReadFileCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString Filename;  // 0x38(0x10)

}; 
// ScriptStruct EOSCore.EOSP2PSocketId
// Size: 0x18(Inherited: 0x0) 
struct FEOSP2PSocketId
{
	char pad_0[8];  // 0x0(0x8)
	struct FString SocketName;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnP2PRemoteConnectionClosedCallback__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnP2PRemoteConnectionClosedCallback__DelegateSignature
{
	struct FEOSP2POnRemoteConnectionClosedInfo Data;  // 0x0(0x70)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool bWasSuccessful : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct EOSCore.EOSRTCParticipantStatusChangedCallbackInfo
// Size: 0x78(Inherited: 0x0) 
struct FEOSRTCParticipantStatusChangedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString RoomName;  // 0x30(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x40(0x21)
	uint8_t  ParticipantStatus;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct TArray<struct FEOSRTCParticipantMetadata> ParticipantMetadata;  // 0x68(0x10)

}; 
// DelegateFunction EOSCore.OnReadFileCompleteCallback__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnReadFileCompleteCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageReadFileCallbackInfo Data;  // 0x0(0x50)

}; 
// ScriptStruct EOSCore.EOSSessionsStartSessionOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsStartSessionOptions
{
	struct FString SessionName;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSP2POnRemoteConnectionClosedInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSP2POnRemoteConnectionClosedInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	struct FEOSProductUserId RemoteUserId;  // 0x29(0x21)
	char pad_74[6];  // 0x4A(0x6)
	struct FEOSP2PSocketId SocketId;  // 0x50(0x18)
	uint8_t  Reason;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct EOSCore.EOSP2POnQueryNATTypeCompleteInfo
// Size: 0x18(Inherited: 0x0) 
struct FEOSP2POnQueryNATTypeCompleteInfo
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  ResultCode;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	uint8_t  NATType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSRTCJoinRoomCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSRTCJoinRoomCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString RoomName;  // 0x38(0x10)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageFileTransferProgressCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSPlayerDataStorageFileTransferProgressCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString Filename;  // 0x30(0x10)
	int32_t bytesTransferred;  // 0x40(0x4)
	int32_t TotalFileSizeBytes;  // 0x44(0x4)

}; 
// DelegateFunction EOSCore.OnP2POnIncomingPacketQueueFullCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnP2POnIncomingPacketQueueFullCallback__DelegateSignature
{
	struct FEOSP2POnIncomingPacketQueueFullInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnAudioInputStateCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnAudioInputStateCallback__DelegateSignature
{
	struct FEOSAudioInputStateCallbackInfo Data;  // 0x0(0x48)

}; 
// ScriptStruct EOSCore.EOSP2POnIncomingPacketQueueFullInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSP2POnIncomingPacketQueueFullInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString PacketQueueMaxSizeBytes;  // 0x8(0x10)
	struct FString PacketQueueCurrentSizeBytes;  // 0x18(0x10)
	struct FEOSProductUserId OverflowPacketLocalUserId;  // 0x28(0x21)
	char pad_73[3];  // 0x49(0x3)
	int32_t OverflowPacketChannel;  // 0x4C(0x4)
	int32_t OverflowPacketSizeBytes;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// DelegateFunction EOSCore.OnP2PIncomingConnectionRequestCallbackDelegate__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FOnP2PIncomingConnectionRequestCallbackDelegate__DelegateSignature
{
	struct FEOSP2POnIncomingConnectionRequestInfo Data;  // 0x0(0x68)

}; 
// DelegateFunction EOSCore.OnP2PRemoteConnectionClosedCallbackDelegate__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnP2PRemoteConnectionClosedCallbackDelegate__DelegateSignature
{
	struct FEOSP2POnRemoteConnectionClosedInfo Data;  // 0x0(0x70)

}; 
// DelegateFunction EOSCore.OnP2PQueryNATTypeCompleteCallbackDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnP2PQueryNATTypeCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSP2POnQueryNATTypeCompleteInfo Data;  // 0x0(0x18)

}; 
// DelegateFunction EOSCore.OnLobbyDestroyLobbyCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyDestroyLobbyCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyDestroyLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerUnregisterClient
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatServerUnregisterClient
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerUnregisterClientOptions Options;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// DelegateFunction EOSCore.OnChatMessageReceived__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnChatMessageReceived__DelegateSignature
{
	struct FEOSProductUserId sender;  // 0x0(0x21)
	struct FEOSProductUserId receiver;  // 0x21(0x21)
	char pad_66[6];  // 0x42(0x6)
	struct FString Message;  // 0x48(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.UpdateUniqueNetIdFromOSS
// Size: 0x10(Inherited: 0x0) 
struct FUpdateUniqueNetIdFromOSS
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct EOSCore.EOSConnectCredentials
// Size: 0x18(Inherited: 0x0) 
struct FEOSConnectCredentials
{
	struct FString AccessToken;  // 0x0(0x10)
	uint8_t  Type;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// DelegateFunction EOSCore.OnChatMessageReceivedCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnChatMessageReceivedCallback__DelegateSignature
{
	struct FEOSProductUserId sender;  // 0x0(0x21)
	struct FEOSProductUserId receiver;  // 0x21(0x21)
	char pad_66[6];  // 0x42(0x6)
	struct FString Message;  // 0x48(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.ListenForEOSMessages
// Size: 0x18(Inherited: 0x0) 
struct FListenForEOSMessages
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnSessionSessionSendInviteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionSessionSendInviteCallback__DelegateSignature
{
	struct FEOSSessionsSendInviteCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyJoinLobbyCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyJoinLobbyCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsGetLeaderboardRecordCountOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLeaderboardsGetLeaderboardRecordCountOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSFriendsDeleteFriendCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsDeleteFriendCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// ScriptStruct EOSCore.EOSSessionsSendInviteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsSendInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct EOSCore.EOSLobbyPromoteMemberOptions
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbyPromoteMemberOptions
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationRemoveAttribute
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionModificationRemoveAttribute
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	struct FEOSSessionModificationRemoveAttributeOptions Options;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// DelegateFunction EOSCore.OnSessionRejectInviteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionRejectInviteCallback__DelegateSignature
{
	struct FEOSSessionsRejectInviteCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.EOSCoreFriendsQueryFriends.EOSFriendsQueryFriendsAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSFriendsQueryFriendsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsQueryFriendsOptions Options;  // 0x8(0x28)
	struct UEOSCoreFriendsQueryFriends* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionsRejectInviteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsRejectInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// Function EOSCore.EOSCoreConnectUnlinkAccount.EOSConnectUnlinkAccountAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectUnlinkAccountAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectUnlinkAccountOptions Options;  // 0x8(0x28)
	struct UEOSCoreConnectUnlinkAccount* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSFriendsOnFriendsUpdateInfo
// Size: 0x50(Inherited: 0x0) 
struct FEOSFriendsOnFriendsUpdateInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x29(0x21)
	uint8_t  PreviousStatus;  // 0x4A(0x1)
	uint8_t  CurrentStatus;  // 0x4B(0x1)
	char pad_76[4];  // 0x4C(0x4)

}; 
// DelegateFunction EOSCore.OnSessionQueryInvitesCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnSessionQueryInvitesCallback__DelegateSignature
{
	struct FEOSSessionsQueryInvitesCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreEcom.EOSEcomQueryEntitlements
// Size: 0x58(Inherited: 0x0) 
struct FEOSEcomQueryEntitlements
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryEntitlementsOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// Function EOSCore.CoreMods.EOSModsCopyModInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSModsCopyModInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSModsCopyModInfoOptions Options;  // 0x8(0x28)
	struct FEOSModsModInfo OutEnumeratedMods;  // 0x30(0x20)
	uint8_t  ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// ScriptStruct EOSCore.EOSActiveSessionGetRegisteredPlayerByIndexOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSActiveSessionGetRegisteredPlayerByIndexOptions
{
	int32_t PlayerIndex;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomCopyItemImageInfoByIndexOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomCopyItemImageInfoByIndexOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString ItemId;  // 0x28(0x10)
	int32_t ImageInfoIndex;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSSessionsQueryInvitesCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionsQueryInvitesCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientProtectMessageOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatClientProtectMessageOptions
{
	struct TArray<char> Data;  // 0x0(0x10)
	int32_t OutBufferSizeBytes;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function EOSCore.EOSCoreConnectLinkAccount.EOSConnectLinkAccountAsync
// Size: 0x40(Inherited: 0x0) 
struct FEOSConnectLinkAccountAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectLinkAccountOptions Options;  // 0x8(0x30)
	struct UEOSCoreConnectLinkAccount* ReturnValue;  // 0x38(0x8)

}; 
// DelegateFunction EOSCore.OnSessionUpdateSessionCallback__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnSessionUpdateSessionCallback__DelegateSignature
{
	struct FEOSSessionsUpdateSessionCallbackInfo Data;  // 0x0(0x30)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsGetMemberAttributeCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyDetailsGetMemberAttributeCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// DelegateFunction EOSCore.OnTitleStorageFileTransferProgressCallbackDelegate__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnTitleStorageFileTransferProgressCallbackDelegate__DelegateSignature
{
	struct FEOSTitleStorageFileTransferProgressCallbackInfo Data;  // 0x0(0x48)

}; 
// DelegateFunction EOSCore.OnDeleteFileCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnDeleteFileCompleteCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageDeleteFileCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSUIAddNotifyDisplaySettingsUpdatedOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSUIAddNotifyDisplaySettingsUpdatedOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// DelegateFunction EOSCore.OnSessionDestroySessionCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionDestroySessionCallback__DelegateSignature
{
	struct FEOSSessionsDestroySessionCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.CoreMods.EOSModsUpdateMod
// Size: 0x98(Inherited: 0x0) 
struct FEOSModsUpdateMod
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSModsUpdateModOptions Options;  // 0x8(0x80)
	struct FDelegate Callback;  // 0x88(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsDestroySessionCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsDestroySessionCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct EOSCore.EOSAudioInputDeviceInfo
// Size: 0x28(Inherited: 0x0) 
struct FEOSAudioInputDeviceInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDefaultDevice : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString DeviceID;  // 0x8(0x10)
	struct FString DeviceName;  // 0x18(0x10)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthDeletePersistentAuth
// Size: 0x28(Inherited: 0x0) 
struct FEOSAuthDeletePersistentAuth
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthDeletePersistentAuthOptions Options;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EOSCore.CoreSessions.EOSSessionsAddNotifyJoinSessionAccepted
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsAddNotifyJoinSessionAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreP2P.EOSP2PAcceptConnection
// Size: 0x70(Inherited: 0x0) 
struct FEOSP2PAcceptConnection
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PAcceptConnectionOptions Options;  // 0x8(0x60)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function EOSCore.CoreFriends.EOSFriendsSendInvite
// Size: 0x60(Inherited: 0x0) 
struct FEOSFriendsSendInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsSendInviteOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// DelegateFunction EOSCore.OnSessionJoinSessionCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionJoinSessionCallback__DelegateSignature
{
	struct FEOSSessionsJoinSessionCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.EOSCoreAuthLogout.EOSAuthLogoutAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSAuthLogoutAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthLogoutOptions Options;  // 0x8(0x28)
	struct UEOSCoreAuthLogout* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionsJoinSessionCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsJoinSessionCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnSessionStartSessionCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionStartSessionCallback__DelegateSignature
{
	struct FEOSSessionsStartSessionCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsStartSessionCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsStartSessionCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyInviteReceived
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyRemoveNotifyLobbyInviteReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionsEndSessionCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsEndSessionCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnTitleStorageDeleteCacheCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTitleStorageDeleteCacheCompleteCallback__DelegateSignature
{
	struct FEOSTitleStorageDeleteCacheCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyPeerActionRequired
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyPeerActionRequired
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientAddNotifyPeerActionRequiredOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// DelegateFunction EOSCore.OnSessionRegisterPlayersCallback__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnSessionRegisterPlayersCallback__DelegateSignature
{
	struct FEOSSessionsRegisterPlayersCallbackInfo Data;  // 0x0(0x30)

}; 
// ScriptStruct EOSCore.EOSPresenceModificationSetStatusOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSPresenceModificationSetStatusOptions
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  Status;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct EOSCore.EOSSessionsRegisterPlayersCallbackInfo
// Size: 0x30(Inherited: 0x0) 
struct FEOSSessionsRegisterPlayersCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct TArray<struct FEOSProductUserId> RegisteredPlayers;  // 0x10(0x10)
	struct TArray<struct FEOSProductUserId> SanctionedPlayers;  // 0x20(0x10)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioBeforeSend
// Size: 0x60(Inherited: 0x0) 
struct FEOSRTCAudioAddNotifyAudioBeforeSend
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSAddNotifyAudioBeforeSendOptions Options;  // 0x10(0x38)
	struct FDelegate Callback;  // 0x48(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction EOSCore.OnSessionUnregisterPlayersCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnSessionUnregisterPlayersCallback__DelegateSignature
{
	struct FEOSSessionsUnregisterPlayersCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageDuplicateFileCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageDuplicateFileCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction EOSCore.OnEcomQueryOwnershipTokenCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnEcomQueryOwnershipTokenCallback__DelegateSignature
{
	struct FEOSEcomQueryOwnershipTokenCallbackInfo Data;  // 0x0(0x48)

}; 
// Function EOSCore.EOSCoreLibrary.RemoveListenForEOSMessages
// Size: 0x8(Inherited: 0x0) 
struct FRemoveListenForEOSMessages
{
	struct UObject* worldContextObject;  // 0x0(0x8)

}; 
// Function EOSCore.CoreReports.EOSReportsSendPlayerBehaviorReport
// Size: 0x80(Inherited: 0x0) 
struct FEOSReportsSendPlayerBehaviorReport
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSReportsSendPlayerBehaviorReportOptions Options;  // 0x8(0x68)
	struct FDelegate Callback;  // 0x70(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomItemOwnership
// Size: 0x20(Inherited: 0x0) 
struct FEOSEcomItemOwnership
{
	char pad_0[8];  // 0x0(0x8)
	struct FString ID;  // 0x8(0x10)
	uint8_t  OwnershipStatus;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct EOSCore.EOSPresenceDataRecord
// Size: 0x28(Inherited: 0x0) 
struct FEOSPresenceDataRecord
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Key;  // 0x8(0x10)
	struct FString Value;  // 0x18(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsUnregisterPlayersCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsUnregisterPlayersCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct TArray<struct FEOSProductUserId> UnregisteredPlayers;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectQueryExternalAccountMappingsOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectQueryExternalAccountMappingsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	uint8_t  AccountIdType;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)
	struct TArray<struct FString> ExternalAccountIds;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnSessionFindCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionFindCallback__DelegateSignature
{
	struct FEOSSessionSearchFindCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyAddNotifyLobbyInviteAcceptedOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyInviteAcceptedOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerSetClientNetworkState
// Size: 0x20(Inherited: 0x0) 
struct FEOSAntiCheatServerSetClientNetworkState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerSetClientNetworkStateOptions Options;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreStats.EOSStatsQueryStats
// Size: 0x98(Inherited: 0x0) 
struct FEOSStatsQueryStats
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSStatsQueryStatsOptions Options;  // 0x8(0x80)
	struct FDelegate Callback;  // 0x88(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionSearchFindCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionSearchFindCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnSessionInviteReceivedCallback__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FOnSessionInviteReceivedCallback__DelegateSignature
{
	struct FEOSSessionsSessionInviteReceivedCallbackInfo Data;  // 0x0(0x60)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientReceiveMessageFromPeer
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatClientReceiveMessageFromPeer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientReceiveMessageFromPeerOptions Options;  // 0x8(0x18)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionsSessionInviteReceivedCallbackInfo
// Size: 0x60(Inherited: 0x0) 
struct FEOSSessionsSessionInviteReceivedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x29(0x21)
	char pad_74[6];  // 0x4A(0x6)
	struct FString InviteId;  // 0x50(0x10)

}; 
// DelegateFunction EOSCore.OnSessionInviteAcceptedCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnSessionInviteAcceptedCallback__DelegateSignature
{
	struct FEOSSessionsSessionInviteAcceptedCallbackInfo Data;  // 0x0(0x70)

}; 
// ScriptStruct EOSCore.EOSSessionsCopyActiveSessionHandleOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsCopyActiveSessionHandleOptions
{
	struct FString SessionName;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsJoinSessionAcceptedCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionsJoinSessionAcceptedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FEOSUIEventId UiEventId;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSGetAudioOutputDevicesCountOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSGetAudioOutputDevicesCountOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchSetParameterDouble
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbySearchSetParameterDouble
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  ComparisonOp;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// DelegateFunction EOSCore.OnSessionSessionSendInviteCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionSessionSendInviteCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsSendInviteCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyPeerActionRequired
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatClientRemoveNotifyPeerActionRequired
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerUnprotectMessageOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerUnprotectMessageOptions
{
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x0(0x8)
	int32_t DataLengthBytes;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<char> Data;  // 0x10(0x10)
	int32_t OutBufferSizeBytes;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageGetFileMetadataCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageGetFileMetadataCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageGetFileMetadataCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// DelegateFunction EOSCore.OnSessionRejectInviteCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionRejectInviteCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsRejectInviteCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyOfferImageInfoByIndex
// Size: 0x80(Inherited: 0x0) 
struct FEOSEcomCopyOfferImageInfoByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyOfferImageInfoByIndexOptions Options;  // 0x8(0x40)
	struct FEOSEcomKeyImageInfo OutImageInfo;  // 0x48(0x30)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdIsValid
// Size: 0x22(Inherited: 0x0) 
struct FEOSEpicAccountIdIsValid
{
	struct FEOSEpicAccountId ID;  // 0x0(0x21)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)

}; 
// ScriptStruct EOSCore.EOSLobbyPromoteMemberCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyPromoteMemberCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// DelegateFunction EOSCore.OnSessionQueryInvitesCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnSessionQueryInvitesCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsQueryInvitesCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnSessionUpdateSessionCallbackDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnSessionUpdateSessionCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsUpdateSessionCallbackInfo Data;  // 0x0(0x30)

}; 
// DelegateFunction EOSCore.OnDeleteFileCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnDeleteFileCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageDeleteFileCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreConnect.EOSConnectAddNotifyLoginStatusChanged
// Size: 0x20(Inherited: 0x0) 
struct FEOSConnectAddNotifyLoginStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSUserInfoCopyExternalUserInfoByIndexOptions
// Size: 0x4C(Inherited: 0x0) 
struct FEOSUserInfoCopyExternalUserInfoByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)
	int32_t Index;  // 0x48(0x4)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsGetAchievementDefinitionCount
// Size: 0x10(Inherited: 0x0) 
struct FEOSAchievementsGetAchievementDefinitionCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsGetAchievementDefinitionCountOptions Options;  // 0x8(0x4)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// DelegateFunction EOSCore.OnSessionDestroySessionCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionDestroySessionCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsDestroySessionCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageCopyFileMetadataAtIndex
// Size: 0x78(Inherited: 0x0) 
struct FEOSPlayerDataStorageCopyFileMetadataAtIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageCopyFileMetadataAtIndexOptions CopyFileMetadataOptions;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSPlayerDataStorageFileMetadata OutMetadata;  // 0x38(0x38)
	uint8_t  ReturnValue;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct EOSCore.EOSTitleStorageQueryFileListOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageQueryFileListOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct TArray<struct FString> ListOfTags;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnSessionStartSessionCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionStartSessionCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsStartSessionCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnTitleStorageDeleteCacheCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTitleStorageDeleteCacheCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSTitleStorageDeleteCacheCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSReportsSendPlayerBehaviorReportCompleteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSReportsSendPlayerBehaviorReportCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct EOSCore.EOSSessionModificationSetHostAddressOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionModificationSetHostAddressOptions
{
	struct FString HostAddress;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSUISetToggleFriendsKeyOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSUISetToggleFriendsKeyOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t keyCombination;  // 0x4(0x4)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageDeleteFileCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageDeleteFileCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction EOSCore.OnSessionRegisterPlayersCallbackDelegate__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnSessionRegisterPlayersCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsRegisterPlayersCallbackInfo Data;  // 0x0(0x30)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageReadFileCallbackInfo
// Size: 0x50(Inherited: 0x0) 
struct FEOSPlayerDataStorageReadFileCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString Filename;  // 0x38(0x10)
	struct FEOSHPlayerDataStorageFileTransferRequest Handle;  // 0x48(0x8)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthCopyUserAuthToken
// Size: 0xE8(Inherited: 0x0) 
struct FEOSAuthCopyUserAuthToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthCopyUserAuthTokenOptions Options;  // 0x8(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0xC(0x21)
	char pad_45[3];  // 0x2D(0x3)
	struct FEOSAuthToken OutUserAuthToken;  // 0x30(0xB0)
	uint8_t  ReturnValue;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)

}; 
// DelegateFunction EOSCore.OnSessionUnregisterPlayersCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnSessionUnregisterPlayersCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsUnregisterPlayersCallbackInfo Data;  // 0x0(0x20)

}; 
// DelegateFunction EOSCore.OnSessionFindCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSessionFindCallbackDelegate__DelegateSignature
{
	struct FEOSSessionSearchFindCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomCopyOfferByIdOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomCopyOfferByIdOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString OfferId;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnSessionInviteReceivedCallbackDelegate__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FOnSessionInviteReceivedCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsSessionInviteReceivedCallbackInfo Data;  // 0x0(0x60)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonRegisterEventOptions
// Size: 0x30(Inherited: 0x0) 
struct FEOSAntiCheatCommonRegisterEventOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t EventId;  // 0x4(0x4)
	struct FString EventName;  // 0x8(0x10)
	uint8_t  EventType;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TArray<struct FEOSAntiCheatCommonRegisterEventParamDef> ParamDefs;  // 0x20(0x10)

}; 
// DelegateFunction EOSCore.OnSessionInviteAcceptedCallbackDelegate__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnSessionInviteAcceptedCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsSessionInviteAcceptedCallbackInfo Data;  // 0x0(0x70)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsOnQueryLeaderboardDefinitionsCompleteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSLeaderboardsOnQueryLeaderboardDefinitionsCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnSessionJoinSessionAcceptedCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnSessionJoinSessionAcceptedCallbackDelegate__DelegateSignature
{
	struct FEOSSessionsJoinSessionAcceptedCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsCopyLeaderboardRecordByIndexOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardRecordByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t LeaderboardRecordIndex;  // 0x4(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionsEndSession
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionsEndSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsEndSessionOptions Options;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// DelegateFunction EOSCore.OnLobbyCreateLobbyCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyCreateLobbyCallback__DelegateSignature
{
	struct FEOSLobbyCreateLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.EOSCoreLobbyLeaveLobby.EOSLobbyLeaveLobbyAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSLobbyLeaveLobbyAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyLeaveLobbyOptions Options;  // 0x8(0x38)
	struct UEOSCoreLobbyLeaveLobby* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesSetCustomInviteOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSCustomInvitesSetCustomInviteOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString Payload;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsIsUserInSessionOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionsIsUserInSessionOptions
{
	struct FString SessionName;  // 0x0(0x10)
	struct FEOSProductUserId TargetUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetItemReleaseCount
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomGetItemReleaseCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetItemReleaseCountOptions Options;  // 0x8(0x38)
	int32_t ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyCreateLobbyCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyCreateLobbyCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomRedeemEntitlementsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomRedeemEntitlementsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction EOSCore.OnEcomQueryEntitlementsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEcomQueryEntitlementsCallbackDelegate__DelegateSignature
{
	struct FEOSEcomQueryEntitlementsCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnReadFileCompleteCallbackDelegate__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnReadFileCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageReadFileCallbackInfo Data;  // 0x0(0x50)

}; 
// DelegateFunction EOSCore.OnLobbyDestroyLobbyCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyDestroyLobbyCallback__DelegateSignature
{
	struct FEOSLobbyDestroyLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSSanctionsGetPlayerSanctionCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSSanctionsGetPlayerSanctionCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbyDestroyLobbyCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyDestroyLobbyCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomGetOfferItemCountOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetOfferItemCountOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString OfferId;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyCopyLobbyDetailsHandleByInviteIdOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyCopyLobbyDetailsHandleByInviteIdOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString InviteId;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnLobbyJoinLobbyCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyJoinLobbyCallback__DelegateSignature
{
	struct FEOSLobbyJoinLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// DelegateFunction EOSCore.OnLobbyLeaveLobbyCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyLeaveLobbyCallback__DelegateSignature
{
	struct FEOSLobbyLeaveLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSTitleStorageFileTransferRequestHandle
// Size: 0x8(Inherited: 0x0) 
struct FEOSTitleStorageFileTransferRequestHandle
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function EOSCore.EOSCorePlayerDataStorageDeleteFile.EOSPlayerDataStorageDeleteFileAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSPlayerDataStorageDeleteFileAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageDeleteFileOptions DeleteOptions;  // 0x8(0x38)
	struct UEOSCorePlayerDataStorageDeleteFile* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction EOSCore.OnAudioBeforeRenderCallback__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnAudioBeforeRenderCallback__DelegateSignature
{
	struct FEOSBeforeRenderCallbackInfo Data;  // 0x0(0x78)

}; 
// ScriptStruct EOSCore.EOSLobbyLeaveLobbyCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyLeaveLobbyCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// DelegateFunction EOSCore.OnFriendsRejectInviteCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsRejectInviteCallbackDelegate__DelegateSignature
{
	struct FEOSFriendsRejectInviteCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnLobbyUpdateLobbyCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyUpdateLobbyCallback__DelegateSignature
{
	struct FEOSLobbyUpdateLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSEcomCopyEntitlementByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSEcomCopyEntitlementByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t EntitlementIndex;  // 0x28(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyUpdateLobbyCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyUpdateLobbyCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// DelegateFunction EOSCore.OnLobbyPromoteMemberCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyPromoteMemberCallback__DelegateSignature
{
	struct FEOSLobbyPromoteMemberCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSActiveSessionInfo
// Size: 0x78(Inherited: 0x0) 
struct FEOSActiveSessionInfo
{
	struct FString SessionName;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	uint8_t  State;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct FEOSSessionDetailsInfo SessionDetails;  // 0x38(0x40)

}; 
// DelegateFunction EOSCore.OnLobbyKickMemberCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyKickMemberCallback__DelegateSignature
{
	struct FEOSLobbyKickMemberCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSLobbyKickMemberCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyKickMemberCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// DelegateFunction EOSCore.OnDeleteCacheCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnDeleteCacheCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageDeleteCacheCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnQueryLeaderboardDefinitionsCompleteCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnQueryLeaderboardDefinitionsCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSLeaderboardsOnQueryLeaderboardDefinitionsCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsDestroySessionOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsDestroySessionOptions
{
	struct FString SessionName;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnUninstallModCallback__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnUninstallModCallback__DelegateSignature
{
	struct FEOSModsUninstallModCallbackInfo Data;  // 0x0(0x88)

}; 
// DelegateFunction EOSCore.OnLobbyUpdateReceivedCallback__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnLobbyUpdateReceivedCallback__DelegateSignature
{
	struct FEOSLobbyUpdateReceivedCallbackInfo Data;  // 0x0(0x18)

}; 
// ScriptStruct EOSCore.EOSLobbyUpdateReceivedCallbackInfo
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyUpdateReceivedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString LobbyID;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnQueryFileCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryFileCompleteCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageQueryFileCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreConnect.EOSConnectGetLoginStatusPure
// Size: 0x30(Inherited: 0x0) 
struct FEOSConnectGetLoginStatusPure
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	uint8_t  ReturnValue;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// DelegateFunction EOSCore.OnAudioDevicesChangedCallback__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnAudioDevicesChangedCallback__DelegateSignature
{
	struct FEOSAudioDevicesChangedCallbackInfo Data;  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbyMemberUpdateReceivedCallbackInfo
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbyMemberUpdateReceivedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString LobbyID;  // 0x8(0x10)
	struct FEOSProductUserId TargetUserId;  // 0x18(0x21)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsGetMemberByIndexOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyDetailsGetMemberByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t MemberIndex;  // 0x4(0x4)

}; 
// DelegateFunction EOSCore.OnUpdateModCallback__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnUpdateModCallback__DelegateSignature
{
	struct FEOSModsUpdateModCallbackInfo Data;  // 0x0(0x88)

}; 
// Function EOSCore.EOSCoreLibrary.FromUnixTimestamp
// Size: 0x18(Inherited: 0x0) 
struct FFromUnixTimestamp
{
	struct FString Timestamp;  // 0x0(0x10)
	struct FDateTime ReturnValue;  // 0x10(0x8)

}; 
// DelegateFunction EOSCore.OnEnumerateModsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEnumerateModsCallback__DelegateSignature
{
	struct FEOSModsEnumerateModsCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyEntitlementByIndex
// Size: 0x90(Inherited: 0x0) 
struct FEOSEcomCopyEntitlementByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyEntitlementByIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSEcomEntitlement OutEntitlement;  // 0x38(0x50)
	uint8_t  ReturnValue;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 
// DelegateFunction EOSCore.OnLobbyMemberStatusReceivedCallback__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnLobbyMemberStatusReceivedCallback__DelegateSignature
{
	struct FEOSLobbyMemberStatusReceivedCallbackInfo Data;  // 0x0(0x40)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerRegisterClientOptions
// Size: 0x30(Inherited: 0x0) 
struct FEOSAntiCheatServerRegisterClientOptions
{
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x0(0x8)
	uint8_t  ClientType;  // 0x8(0x1)
	uint8_t  ClientPlatform;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString AccountId;  // 0x10(0x10)
	struct FString IpAddress;  // 0x20(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.MakeString
// Size: 0x38(Inherited: 0x0) 
struct FMakeString
{
	struct FString Value;  // 0x0(0x10)
	struct FEOSSessionSetting ReturnValue;  // 0x10(0x28)

}; 
// DelegateFunction EOSCore.OnLobbyInviteReceivedCallback__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FOnLobbyInviteReceivedCallback__DelegateSignature
{
	struct FEOSLobbyInviteReceivedCallbackInfo Data;  // 0x0(0x60)

}; 
// ScriptStruct EOSCore.EOSLobbyInviteReceivedCallbackInfo
// Size: 0x60(Inherited: 0x0) 
struct FEOSLobbyInviteReceivedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString InviteId;  // 0x8(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x18(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x39(0x21)
	char pad_90[6];  // 0x5A(0x6)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerReceiveMessageFromClientOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatServerReceiveMessageFromClientOptions
{
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x0(0x8)
	struct TArray<char> Data;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnQueryUserInfoByExternalAccountCallbackDelegate__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnQueryUserInfoByExternalAccountCallbackDelegate__DelegateSignature
{
	struct FEOSUserInfoQueryUserInfoByExternalAccountCallbackInfo Data;  // 0x0(0x70)

}; 
// ScriptStruct EOSCore.EOSSessionsCopySessionHandleByInviteIdOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsCopySessionHandleByInviteIdOptions
{
	struct FString InviteId;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsQueryInvitesOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSSessionsQueryInvitesOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// Function EOSCore.CoreAntiCheatClient.GetAntiCheatClient
// Size: 0x10(Inherited: 0x0) 
struct FGetAntiCheatClient
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreAntiCheatClient* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnLobbySendInviteCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbySendInviteCallback__DelegateSignature
{
	struct FEOSLobbySendInviteCallbackInfo Data;  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSLobbySendInviteCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbySendInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString LobbyID;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageWriteFileCallbackInfo
// Size: 0x50(Inherited: 0x0) 
struct FEOSPlayerDataStorageWriteFileCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString Filename;  // 0x38(0x10)
	struct FEOSHPlayerDataStorageFileTransferRequest Handle;  // 0x48(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogGameRoundStart
// Size: 0x50(Inherited: 0x0) 
struct FEOSAntiCheatServerLogGameRoundStart
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogGameRoundStartOptions Options;  // 0x8(0x40)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction EOSCore.OnLobbyRejectInviteCallback__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyRejectInviteCallback__DelegateSignature
{
	struct FEOSLobbyRejectInviteCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.CoreConnect.EOSConnectCreateDeviceId
// Size: 0x28(Inherited: 0x0) 
struct FEOSConnectCreateDeviceId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCreateDeviceIdOptions Options;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyRejectInviteCallbackInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyRejectInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString InviteId;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonSetGameSessionIdOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatCommonSetGameSessionIdOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString GameSessionId;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyQueryInvitesCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyQueryInvitesCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbySearchFindCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbySearchFindCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct EOSCore.EOSEcomHTransaction
// Size: 0x8(Inherited: 0x0) 
struct FEOSEcomHTransaction
{
	char pad_0[8];  // 0x0(0x8)

}; 
// DelegateFunction EOSCore.OnLobbyInviteAcceptedCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnLobbyInviteAcceptedCallback__DelegateSignature
{
	struct FEOSLobbyInviteAcceptedCallbackInfo Data;  // 0x0(0x70)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsGetLeaderboardUserScoreCount
// Size: 0x28(Inherited: 0x0) 
struct FEOSLeaderboardsGetLeaderboardUserScoreCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsGetLeaderboardUserScoreCountOptions Options;  // 0x8(0x18)
	int32_t ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PQueryNATTypeOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSP2PQueryNATTypeOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// Function EOSCore.EOSCoreLibrary.MakeBool
// Size: 0x30(Inherited: 0x0) 
struct FMakeBool
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FEOSSessionSetting ReturnValue;  // 0x8(0x28)

}; 
// DelegateFunction EOSCore.OnJoinLobbyAcceptedCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnJoinLobbyAcceptedCallback__DelegateSignature
{
	struct FEOSLobbyJoinLobbyAcceptedCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreP2P.EOSP2PAddNotifyIncomingPacketQueueFull
// Size: 0x28(Inherited: 0x0) 
struct FEOSP2PAddNotifyIncomingPacketQueueFull
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PAddNotifyIncomingPacketQueueFullOptions Options;  // 0x8(0x4)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbyJoinLobbyAcceptedCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyJoinLobbyAcceptedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FEOSUIEventId UiEventId;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerDespawnOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerDespawnOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle DespawnedPlayerHandle;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnOnRTCRoomConnectionChangedCallback__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnOnRTCRoomConnectionChangedCallback__DelegateSignature
{
	struct FEOSLobbyRTCRoomConnectionChangedCallbackInfo Data;  // 0x0(0x40)

}; 
// Function EOSCore.CorePresence.EOSPresenceAddNotifyOnPresenceChanged
// Size: 0x20(Inherited: 0x0) 
struct FEOSPresenceAddNotifyOnPresenceChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbySearchSetTargetUserIdOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbySearchSetTargetUserIdOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// DelegateFunction EOSCore.OnEcomQueryRedeemEntitlementsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEcomQueryRedeemEntitlementsCallbackDelegate__DelegateSignature
{
	struct FEOSEcomRedeemEntitlementsCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchCopySearchResultByIndex
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbySearchCopySearchResultByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchCopySearchResultByIndexOptions Options;  // 0x10(0x8)
	struct FEOSHLobbyDetails OutLobbyDetailsHandle;  // 0x18(0x8)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyRTCRoomConnectionChangedCallbackInfo
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbyRTCRoomConnectionChangedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString LobbyID;  // 0x8(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x18(0x21)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bIsConnected : 1;  // 0x39(0x1)
	uint8_t  DisconnectReason;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)

}; 
// DelegateFunction EOSCore.OnLobbyJoinLobbyCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyJoinLobbyCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyJoinLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// DelegateFunction EOSCore.OnEcomQueryEntitlementsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEcomQueryEntitlementsCallback__DelegateSignature
{
	struct FEOSEcomQueryEntitlementsCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnLobbyUpdateLobbyCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyUpdateLobbyCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyUpdateLobbyCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.EOSCoreLibrary.CoreStringToByte
// Size: 0x20(Inherited: 0x0) 
struct FCoreStringToByte
{
	struct FString String;  // 0x0(0x10)
	struct TArray<char> ReturnValue;  // 0x10(0x10)

}; 
// DelegateFunction EOSCore.OnLobbyPromoteMemberCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyPromoteMemberCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyPromoteMemberCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.CoreEcom.GetEcom
// Size: 0x10(Inherited: 0x0) 
struct FGetEcom
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreEcom* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSAuthCopyUserAuthTokenOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSAuthCopyUserAuthTokenOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// DelegateFunction EOSCore.OnQueryUserInfoCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnQueryUserInfoCallback__DelegateSignature
{
	struct FEOSUserInfoQueryUserInfoCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnPresenceOnJoinGameAcceptedCallback__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FOnPresenceOnJoinGameAcceptedCallback__DelegateSignature
{
	struct FEOSPresenceJoinGameAcceptedCallbackInfo Data;  // 0x0(0x68)

}; 
// DelegateFunction EOSCore.OnLobbyKickMemberCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbyKickMemberCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyKickMemberCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.EOSCoreUIHideFriends.EOSUIHideFriendsAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSUIHideFriendsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIHideFriendsOptions Options;  // 0x8(0x28)
	struct UEOSCoreUIHideFriends* ReturnValue;  // 0x30(0x8)

}; 
// DelegateFunction EOSCore.OnLobbyUpdateReceivedCallbackDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnLobbyUpdateReceivedCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyUpdateReceivedCallbackInfo Data;  // 0x0(0x18)

}; 
// DelegateFunction EOSCore.OnKickCompleteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnKickCompleteCallback__DelegateSignature
{
	struct FEOSKickCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnUninstallModCallbackDelegate__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnUninstallModCallbackDelegate__DelegateSignature
{
	struct FEOSModsUninstallModCallbackInfo Data;  // 0x0(0x88)

}; 
// Function EOSCore.CoreSessions.EOSSessionsDestroySession
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionsDestroySession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsDestroySessionOptions Options;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// DelegateFunction EOSCore.OnLobbyMemberUpdateReceivedCallbackDelegate__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnLobbyMemberUpdateReceivedCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyMemberUpdateReceivedCallbackInfo Data;  // 0x0(0x40)

}; 
// DelegateFunction EOSCore.OnUpdateModCallbackDelegate__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnUpdateModCallbackDelegate__DelegateSignature
{
	struct FEOSModsUpdateModCallbackInfo Data;  // 0x0(0x88)

}; 
// DelegateFunction EOSCore.OnLobbyMemberStatusReceivedCallbackDelegate__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnLobbyMemberStatusReceivedCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyMemberStatusReceivedCallbackInfo Data;  // 0x0(0x40)

}; 
// DelegateFunction EOSCore.OnEnumerateModsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEnumerateModsCallbackDelegate__DelegateSignature
{
	struct FEOSModsEnumerateModsCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnLobbyInviteReceivedCallbackDelegate__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FOnLobbyInviteReceivedCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyInviteReceivedCallbackInfo Data;  // 0x0(0x60)

}; 
// DelegateFunction EOSCore.OnCustomInvitesOnCustomInviteAcceptedCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnCustomInvitesOnCustomInviteAcceptedCallback__DelegateSignature
{
	struct FEOSCustomInvitesOnCustomInviteAcceptedCallbackInfo Data;  // 0x0(0x70)

}; 
// DelegateFunction EOSCore.OnLobbySendInviteCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnLobbySendInviteCallbackDelegate__DelegateSignature
{
	struct FEOSLobbySendInviteCallbackInfo Data;  // 0x0(0x20)

}; 
// Function EOSCore.EOSCoreLobbySendInvite.EOSLobbySendInviteAsync
// Size: 0x68(Inherited: 0x0) 
struct FEOSLobbySendInviteAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbySendInviteOptions Options;  // 0x8(0x58)
	struct UEOSCoreLobbySendInvite* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction EOSCore.OnLobbyQueryInvitesCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnLobbyQueryInvitesCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyQueryInvitesCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnLobbyFindCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnLobbyFindCallbackDelegate__DelegateSignature
{
	struct FEOSLobbySearchFindCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnLobbyInviteAcceptedCallbackDelegate__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnLobbyInviteAcceptedCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyInviteAcceptedCallbackInfo Data;  // 0x0(0x70)

}; 
// Function EOSCore.CoreP2P.EOSP2PCloseConnections
// Size: 0x50(Inherited: 0x0) 
struct FEOSP2PCloseConnections
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PCloseConnectionsOptions Options;  // 0x8(0x40)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction EOSCore.OnAudioBeforeSendCallback__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnAudioBeforeSendCallback__DelegateSignature
{
	struct FEOSBeforeSendCallbackInfo Data;  // 0x0(0x50)

}; 
// ScriptStruct EOSCore.EOSEcomQueryOwnershipTokenOptions
// Size: 0x50(Inherited: 0x0) 
struct FEOSEcomQueryOwnershipTokenOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FString> CatalogItemIds;  // 0x28(0x10)
	char pad_56[8];  // 0x38(0x8)
	struct FString CatalogNamespace;  // 0x40(0x10)

}; 
// DelegateFunction EOSCore.OnOnRTCRoomConnectionChangedCallbackDelegate__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnOnRTCRoomConnectionChangedCallbackDelegate__DelegateSignature
{
	struct FEOSLobbyRTCRoomConnectionChangedCallbackInfo Data;  // 0x0(0x40)

}; 
// Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdToString
// Size: 0x40(Inherited: 0x0) 
struct FEOSEpicAccountIdToString
{
	struct FEOSEpicAccountId ID;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString String;  // 0x28(0x10)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionsStartSession
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionsStartSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsStartSessionOptions Options;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// DelegateFunction EOSCore.OnEcomQueryOwnershipCallback__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnEcomQueryOwnershipCallback__DelegateSignature
{
	struct FEOSEcomQueryOwnershipCallbackInfo Data;  // 0x0(0x50)

}; 
// ScriptStruct EOSCore.EOSEcomQueryOwnershipCallbackInfo
// Size: 0x50(Inherited: 0x0) 
struct FEOSEcomQueryOwnershipCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct TArray<struct FEOSEcomItemOwnership> ItemOwnership;  // 0x38(0x10)
	char pad_72[8];  // 0x48(0x8)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestRelease
// Size: 0x10(Inherited: 0x0) 
struct FEOSPlayerDataStorageFileTransferRequestRelease
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPlayerDataStorageFileTransferRequest Handle;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnStatsIngestStatCompleteCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnStatsIngestStatCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSStatsIngestStatCompleteCallbackInfo Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSEcomQueryOwnershipTokenCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomQueryOwnershipTokenCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString OwnershipToken;  // 0x38(0x10)

}; 
// ScriptStruct EOSCore.EOSAchievementsPlayerStatInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSAchievementsPlayerStatInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Name;  // 0x8(0x10)
	int32_t CurrentValue;  // 0x18(0x4)
	int32_t ThresholdValue;  // 0x1C(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomQueryEntitlementsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomQueryEntitlementsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSConnectLoginOptions
// Size: 0x30(Inherited: 0x0) 
struct FEOSConnectLoginOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSConnectCredentials Credentials;  // 0x8(0x18)
	struct FEOSConnectUserLoginInfo UserLoginInfo;  // 0x20(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsRejectInviteOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionsRejectInviteOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString InviteId;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnFriendsQueryFriendsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnFriendsQueryFriendsCallbackDelegate__DelegateSignature
{
	struct FEOSFriendsQueryFriendsCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSPresenceModificationSetJoinInfoOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSPresenceModificationSetJoinInfoOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString JoinInfo;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnEcomQueryQueryOffersCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEcomQueryQueryOffersCallback__DelegateSignature
{
	struct FEOSEcomQueryOffersCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSSessionModificationRemoveAttributeOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionModificationRemoveAttributeOptions
{
	struct FString Key;  // 0x0(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.EOSContinuanceTokenToString
// Size: 0x20(Inherited: 0x0) 
struct FEOSContinuanceTokenToString
{
	struct FContinuanceToken ID;  // 0x0(0x8)
	struct FString String;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// DelegateFunction EOSCore.OnEcomQueryCheckoutCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnEcomQueryCheckoutCallback__DelegateSignature
{
	struct FEOSEcomCheckoutCallbackInfo Data;  // 0x0(0x48)

}; 
// DelegateFunction EOSCore.OnQueryJoinRoomTokenCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryJoinRoomTokenCompleteCallback__DelegateSignature
{
	struct FEOSQueryJoinRoomTokenCompleteCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSModIdentifier
// Size: 0x58(Inherited: 0x0) 
struct FEOSModIdentifier
{
	char pad_0[8];  // 0x0(0x8)
	struct FString NamespaceId;  // 0x8(0x10)
	struct FString ItemId;  // 0x18(0x10)
	struct FString ArtifactId;  // 0x28(0x10)
	struct FString Title;  // 0x38(0x10)
	struct FString Version;  // 0x48(0x10)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageQueryFileCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFileCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSEcomCheckoutCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomCheckoutCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString TransactionId;  // 0x38(0x10)

}; 
// DelegateFunction EOSCore.OnEcomQueryRedeemEntitlementsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEcomQueryRedeemEntitlementsCallback__DelegateSignature
{
	struct FEOSEcomRedeemEntitlementsCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnEcomQueryOwnershipCallbackDelegate__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnEcomQueryOwnershipCallbackDelegate__DelegateSignature
{
	struct FEOSEcomQueryOwnershipCallbackInfo Data;  // 0x0(0x50)

}; 
// DelegateFunction EOSCore.OnEcomQueryQueryOffersCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnEcomQueryQueryOffersCallbackDelegate__DelegateSignature
{
	struct FEOSEcomQueryOffersCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.EOSLoginCallback__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FEOSLoginCallback__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ErrorStr;  // 0x8(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddAttribute
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyModificationAddAttribute
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FEOSLobbyModificationAddAttributeOptions Options;  // 0x10(0x38)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction EOSCore.OnEOSLogging__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnEOSLogging__DelegateSignature
{
	struct FString Category;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)
	uint8_t  EOSLogLevel;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyOfferByIndex
// Size: 0xF8(Inherited: 0x0) 
struct FEOSEcomCopyOfferByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyOfferByIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSEcomCatalogOffer OutOffer;  // 0x38(0xB8)
	uint8_t  ReturnValue;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesOnCustomInviteReceivedCallbackInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSCustomInvitesOnCustomInviteReceivedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId TargetUserId;  // 0x8(0x21)
	struct FEOSProductUserId LocalUserId;  // 0x29(0x21)
	char pad_74[6];  // 0x4A(0x6)
	struct FString CustomInviteId;  // 0x50(0x10)
	struct FString Payload;  // 0x60(0x10)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesOnCustomInviteAcceptedCallbackInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSCustomInvitesOnCustomInviteAcceptedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId TargetUserId;  // 0x8(0x21)
	struct FEOSProductUserId LocalUserId;  // 0x29(0x21)
	char pad_74[6];  // 0x4A(0x6)
	struct FString CustomInviteId;  // 0x50(0x10)
	struct FString Payload;  // 0x60(0x10)

}; 
// DelegateFunction EOSCore.OnQueryActivePlayerSanctionsCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnQueryActivePlayerSanctionsCallbackDelegate__DelegateSignature
{
	struct FEOSSanctionsQueryActivePlayerSanctionsCallbackInfo Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSBeforeSendCallbackInfo
// Size: 0x50(Inherited: 0x0) 
struct FEOSBeforeSendCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString RoomName;  // 0x30(0x10)
	struct FEOSRTCAudioAudioBuffer Buffer;  // 0x40(0x10)

}; 
// DelegateFunction EOSCore.OnFriendsSendInviteCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsSendInviteCallback__DelegateSignature
{
	struct FEOSFriendsSendInviteCallbackInfo Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSLobbyLocalRTCOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyLocalRTCOptions
{
	int32_t Flags;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bUseManualAudioInput : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool bUseManualAudioOutput : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool bLocalAudioDeviceInputStartsMuted : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)

}; 
// ScriptStruct EOSCore.EOSEcomGetEntitlementsCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSEcomGetEntitlementsCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbyUpdateLobbyOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyUpdateLobbyOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSHLobbyModification LobbyModificationHandle;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSFriendsAcceptInviteCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsAcceptInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsGetMemberByIndex
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbyDetailsGetMemberByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsGetMemberByIndexOptions Options;  // 0x10(0x8)
	struct FEOSProductUserId ReturnValue;  // 0x18(0x21)
	char pad_57[7];  // 0x39(0x7)

}; 
// DelegateFunction EOSCore.OnFriendsRejectInviteCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsRejectInviteCallback__DelegateSignature
{
	struct FEOSFriendsRejectInviteCallbackInfo Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSFriendsRejectInviteCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsRejectInviteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationRemoveMemberAttributeOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyModificationRemoveMemberAttributeOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Key;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnFriendsDeleteFriendCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsDeleteFriendCallback__DelegateSignature
{
	struct FEOSFriendsDeleteFriendCallbackInfo Data;  // 0x0(0x58)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageDeleteCache
// Size: 0x48(Inherited: 0x0) 
struct FEOSPlayerDataStorageDeleteCache
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageDeleteCacheOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// DelegateFunction EOSCore.OnFriendsSendInviteCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsSendInviteCallbackDelegate__DelegateSignature
{
	struct FEOSFriendsSendInviteCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnFriendsDeleteFriendCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnFriendsDeleteFriendCallbackDelegate__DelegateSignature
{
	struct FEOSFriendsDeleteFriendCallbackInfo Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonQuat
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatCommonQuat
{
	float W;  // 0x0(0x4)
	float X;  // 0x4(0x4)
	float Y;  // 0x8(0x4)
	float Z;  // 0xC(0x4)

}; 
// DelegateFunction EOSCore.OnDeleteCacheCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnDeleteCacheCompleteCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageDeleteCacheCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnQueryLeaderboardDefinitionsCompleteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnQueryLeaderboardDefinitionsCompleteCallback__DelegateSignature
{
	struct FEOSLeaderboardsOnQueryLeaderboardDefinitionsCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.CoreSanctions.EOSSanctionsGetPlayerSanctionCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSSanctionsGetPlayerSanctionCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSanctionsGetPlayerSanctionCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomCopyOfferImageInfoByIndexOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomCopyOfferImageInfoByIndexOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString OfferId;  // 0x28(0x10)
	int32_t ImageInfoIndex;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSTitleStorageGetFileMetadataCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSTitleStorageGetFileMetadataCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// DelegateFunction EOSCore.OnQueryLeaderboardRanksCompleteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnQueryLeaderboardRanksCompleteCallback__DelegateSignature
{
	struct FEOSLeaderboardsOnQueryLeaderboardRanksCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSPresenceInfo
// Size: 0x90(Inherited: 0x0) 
struct FEOSPresenceInfo
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  Status;  // 0x4(0x1)
	struct FEOSEpicAccountId UserId;  // 0x5(0x21)
	char pad_38[2];  // 0x26(0x2)
	struct FString ProductId;  // 0x28(0x10)
	struct FString ProductVersion;  // 0x38(0x10)
	struct FString platform;  // 0x48(0x10)
	struct FString RichText;  // 0x58(0x10)
	char pad_104[8];  // 0x68(0x8)
	struct TArray<struct FEOSPresenceDataRecord> Records;  // 0x70(0x10)
	struct FString ProductName;  // 0x80(0x10)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthGetLoginStatus
// Size: 0x30(Inherited: 0x0) 
struct FEOSAuthGetLoginStatus
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	uint8_t  ReturnValue;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsGetAttributeCount
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyDetailsGetAttributeCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsGetAttributeCountOptions Options;  // 0x10(0x4)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsOnQueryLeaderboardRanksCompleteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSLeaderboardsOnQueryLeaderboardRanksCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// ScriptStruct EOSCore.EOSSessionSearchSetSessionIdOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionSearchSetSessionIdOptions
{
	struct FString SessionID;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnQueryLeaderboardUserScoresCompleteCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnQueryLeaderboardUserScoresCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSLeaderboardsOnQueryLeaderboardUserScoresCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetTransactionCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetTransactionCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetTransactionCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CorePresence.EOSPresenceRemoveNotifyOnPresenceChanged
// Size: 0x10(Inherited: 0x0) 
struct FEOSPresenceRemoveNotifyOnPresenceChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnQueryLeaderboardRanksCompleteCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnQueryLeaderboardRanksCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSLeaderboardsOnQueryLeaderboardRanksCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnInstallModCallback__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnInstallModCallback__DelegateSignature
{
	struct FEOSModsInstallModCallbackInfo Data;  // 0x0(0x88)

}; 
// Function EOSCore.CoreP2P.EOSP2PRemoveNotifyIncomingPacketQueueFull
// Size: 0x10(Inherited: 0x0) 
struct FEOSP2PRemoveNotifyIncomingPacketQueueFull
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSPresencePresenceChangedCallbackInfo
// Size: 0x50(Inherited: 0x0) 
struct FEOSPresencePresenceChangedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	struct FEOSEpicAccountId PresenceUserId;  // 0x29(0x21)
	char pad_74[6];  // 0x4A(0x6)

}; 
// ScriptStruct EOSCore.EOSModsUpdateModCallbackInfo
// Size: 0x88(Inherited: 0x0) 
struct FEOSModsUpdateModCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	struct FEOSEpicAccountId LocalUserId;  // 0x1(0x21)
	char pad_34[14];  // 0x22(0xE)
	struct FEOSModIdentifier Mod;  // 0x30(0x58)

}; 
// ScriptStruct EOSCore.EOSModsInstallModCallbackInfo
// Size: 0x88(Inherited: 0x0) 
struct FEOSModsInstallModCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	struct FEOSEpicAccountId LocalUserId;  // 0x1(0x21)
	char pad_34[14];  // 0x22(0xE)
	struct FEOSModIdentifier Mod;  // 0x30(0x58)

}; 
// ScriptStruct EOSCore.EOSTitleStorageQueryFileListCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageQueryFileListCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[3];  // 0x31(0x3)
	int32_t FileCount;  // 0x34(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomKeyImageInfo
// Size: 0x30(Inherited: 0x0) 
struct FEOSEcomKeyImageInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Type;  // 0x8(0x10)
	struct FString URL;  // 0x18(0x10)
	int32_t Width;  // 0x28(0x4)
	int32_t Height;  // 0x2C(0x4)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageReadFile
// Size: 0x78(Inherited: 0x0) 
struct FEOSPlayerDataStorageReadFile
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageReadFileOptions ReadOptions;  // 0x8(0x60)
	struct FDelegate Callback;  // 0x68(0x10)

}; 
// ScriptStruct EOSCore.EOSModsUninstallModCallbackInfo
// Size: 0x88(Inherited: 0x0) 
struct FEOSModsUninstallModCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	struct FEOSEpicAccountId LocalUserId;  // 0x1(0x21)
	char pad_34[14];  // 0x22(0xE)
	struct FEOSModIdentifier Mod;  // 0x30(0x58)

}; 
// Function EOSCore.CoreRTC.EOSRTCBlockParticipant
// Size: 0x78(Inherited: 0x0) 
struct FEOSRTCBlockParticipant
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FBlockParticipantOptions Options;  // 0x8(0x60)
	struct FDelegate Callback;  // 0x68(0x10)

}; 
// DelegateFunction EOSCore.OnShowFriendsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnShowFriendsCallbackDelegate__DelegateSignature
{
	struct FEOSUIShowFriendsCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnQueryFileListCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryFileListCompleteCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageQueryFileListCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageQueryFileListCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFileListCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[3];  // 0x31(0x3)
	int32_t FileCount;  // 0x34(0x4)

}; 
// ScriptStruct EOSCore.EOSAuthQueryIdTokenOptions
// Size: 0x42(Inherited: 0x0) 
struct FEOSAuthQueryIdTokenOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	struct FEOSEpicAccountId TargetAccountId;  // 0x21(0x21)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRemoveNotifyClientAuthStatusChanged
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatServerRemoveNotifyClientAuthStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CorePresence.EOSPresenceModificationDeleteData
// Size: 0x30(Inherited: 0x0) 
struct FEOSPresenceModificationDeleteData
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPresenceModification Handle;  // 0x8(0x8)
	struct FEOSPresenceModificationDeleteDataOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogEvent
// Size: 0x38(Inherited: 0x0) 
struct FEOSAntiCheatServerLogEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogEventOptions Options;  // 0x8(0x28)
	uint8_t  ReturnValue;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSUpdateSendingCallbackInfo
// Size: 0x50(Inherited: 0x0) 
struct FEOSUpdateSendingCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString RoomName;  // 0x38(0x10)
	uint8_t  AudioStatus;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction EOSCore.OnDuplicateFileCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnDuplicateFileCompleteCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageDuplicateFileCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreSessions.EOSSessionsUpdateSessionModification
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionsUpdateSessionModification
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsUpdateSessionModificationOptions Options;  // 0x8(0x10)
	struct FEOSHSessionModification OutSessionModificationHandle;  // 0x18(0x8)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// DelegateFunction EOSCore.OnFileTransferProgressCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnFileTransferProgressCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageFileTransferProgressCallbackInfo Data;  // 0x0(0x48)

}; 
// ScriptStruct EOSCore.EOSHPlayerDataStorageFileTransferRequest
// Size: 0x8(Inherited: 0x0) 
struct FEOSHPlayerDataStorageFileTransferRequest
{
	char pad_0[8];  // 0x0(0x8)

}; 
// DelegateFunction EOSCore.OnDisplaySettingsUpdatedCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnDisplaySettingsUpdatedCallback__DelegateSignature
{
	struct FEOSUIOnDisplaySettingsUpdatedCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientAddNotifyPeerAuthStatusChangedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyPeerAuthStatusChangedOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function EOSCore.CoreConnect.EOSConnectCopyProductUserExternalAccountByIndex
// Size: 0xA0(Inherited: 0x0) 
struct FEOSConnectCopyProductUserExternalAccountByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCopyProductUserExternalAccountByIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSConnectExternalAccountInfo OutExternalAccountInfo;  // 0x38(0x60)
	uint8_t  ReturnValue;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 
// DelegateFunction EOSCore.OnWriteFileCompleteCallback__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnWriteFileCompleteCallback__DelegateSignature
{
	struct FEOSPlayerDataStorageWriteFileCallbackInfo Data;  // 0x0(0x50)

}; 
// ScriptStruct EOSCore.EOSEcomCopyItemByIdOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomCopyItemByIdOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString ItemId;  // 0x28(0x10)

}; 
// DelegateFunction EOSCore.OnFileTransferProgressUpdated__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnFileTransferProgressUpdated__DelegateSignature
{
	struct FEOSOnFileTransferProgressUpdated Data;  // 0x0(0x50)

}; 
// ScriptStruct EOSCore.EOSOnFileTransferProgressUpdated
// Size: 0x50(Inherited: 0x0) 
struct FEOSOnFileTransferProgressUpdated
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString Filename;  // 0x30(0x10)
	int32_t bytesTransferred;  // 0x40(0x4)
	int32_t TotalFileSizeBytes;  // 0x44(0x4)
	struct FEOSHPlayerDataStorageFileTransferRequest Handle;  // 0x48(0x8)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageDeleteCacheCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageDeleteCacheCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSQueryJoinRoomTokenCompleteCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSQueryJoinRoomTokenCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FString RoomName;  // 0x10(0x10)
	struct FString ClientBaseUrl;  // 0x20(0x10)
	int32_t QueryId;  // 0x30(0x4)
	int32_t TokenCount;  // 0x34(0x4)

}; 
// DelegateFunction EOSCore.OnQueryFileCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnQueryFileCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageQueryFileCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyEntitlementById
// Size: 0x98(Inherited: 0x0) 
struct FEOSEcomCopyEntitlementById
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyEntitlementByIdOptions Options;  // 0x8(0x38)
	struct FEOSEcomEntitlement OutEntitlement;  // 0x40(0x50)
	uint8_t  ReturnValue;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
// DelegateFunction EOSCore.OnDuplicateFileCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnDuplicateFileCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageDuplicateFileCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSSessionModificationSetPermissionLevelOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionModificationSetPermissionLevelOptions
{
	uint8_t  PermissionLevel;  // 0x0(0x1)

}; 
// DelegateFunction EOSCore.OnWriteFileCompleteCallbackDelegate__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnWriteFileCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPlayerDataStorageWriteFileCallbackInfo Data;  // 0x0(0x50)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerUnprotectMessage
// Size: 0x48(Inherited: 0x0) 
struct FEOSAntiCheatServerUnprotectMessage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerUnprotectMessageOptions Options;  // 0x8(0x28)
	struct TArray<char> OutBuffer;  // 0x30(0x10)
	int32_t OutBufferLengthBytes;  // 0x40(0x4)
	uint8_t  ReturnValue;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)

}; 
// Function EOSCore.EOSCoreEcomQueryOffers.EOSEcomQueryOffersAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomQueryOffersAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryOffersOptions Options;  // 0x8(0x38)
	struct UEOSCoreEcomQueryOffers* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct EOSCore.EOSPresenceSetPresenceCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSPresenceSetPresenceCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction EOSCore.OnPresenceQueryPresenceCompleteCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnPresenceQueryPresenceCompleteCallback__DelegateSignature
{
	struct FEOSPresenceQueryPresenceCallbackInfo Data;  // 0x0(0x58)

}; 
// Function EOSCore.CoreMetrics.EOSMetricsEndPlayerSession
// Size: 0x48(Inherited: 0x0) 
struct FEOSMetricsEndPlayerSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSMetricsEndPlayerSessionOptions Options;  // 0x8(0x38)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct EOSCore.EOSPresenceQueryPresenceCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSPresenceQueryPresenceCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// ScriptStruct EOSCore.EOSPresenceJoinGameAcceptedCallbackInfo
// Size: 0x68(Inherited: 0x0) 
struct FEOSPresenceJoinGameAcceptedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString JoinInfo;  // 0x8(0x10)
	struct FEOSEpicAccountId LocalUserId;  // 0x18(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x39(0x21)
	char pad_90[6];  // 0x5A(0x6)
	struct FEOSUIEventId UiEventId;  // 0x60(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionDetailsGetSessionAttributeCountOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionDetailsGetSessionAttributeCountOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// DelegateFunction EOSCore.OnPresenceChangedCallback__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPresenceChangedCallback__DelegateSignature
{
	struct FEOSPresencePresenceChangedCallbackInfo Data;  // 0x0(0x50)

}; 
// DelegateFunction EOSCore.OnPresenceSetPresenceCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnPresenceSetPresenceCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSPresenceSetPresenceCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnQueryUserInfoCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnQueryUserInfoCallbackDelegate__DelegateSignature
{
	struct FEOSUserInfoQueryUserInfoCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnPresenceOnJoinGameAcceptedCallbackDelegate__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FOnPresenceOnJoinGameAcceptedCallbackDelegate__DelegateSignature
{
	struct FEOSPresenceJoinGameAcceptedCallbackInfo Data;  // 0x0(0x68)

}; 
// DelegateFunction EOSCore.OnLeaveRoomCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnLeaveRoomCallback__DelegateSignature
{
	struct FEOSRTCLeaveRoomCallbackInfo Data;  // 0x0(0x48)

}; 
// ScriptStruct EOSCore.EOSConnectCopyProductUserExternalAccountByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSConnectCopyProductUserExternalAccountByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t ExternalAccountInfoIndex;  // 0x28(0x4)

}; 
// ScriptStruct EOSCore.EOSHLobbyDetails
// Size: 0x8(Inherited: 0x0) 
struct FEOSHLobbyDetails
{
	char pad_0[8];  // 0x0(0x8)

}; 
// DelegateFunction EOSCore.OnPresenceChangedCallbackDelegate__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnPresenceChangedCallbackDelegate__DelegateSignature
{
	struct FEOSPresencePresenceChangedCallbackInfo Data;  // 0x0(0x50)

}; 
// Function EOSCore.CoreMetrics.GetMetrics
// Size: 0x10(Inherited: 0x0) 
struct FGetMetrics
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreMetrics* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnTitleStorageQueryFileListCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTitleStorageQueryFileListCompleteCallback__DelegateSignature
{
	struct FEOSTitleStorageQueryFileListCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsUserScoresQueryStatInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSLeaderboardsUserScoresQueryStatInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FString StatName;  // 0x8(0x10)
	uint8_t  Aggregation;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// DelegateFunction EOSCore.OnSubmitSnapshotCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSubmitSnapshotCallback__DelegateSignature
{
	struct FEOSProgressionSnapshotSubmitSnapshotCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSPresenceGetJoinInfoOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSPresenceGetJoinInfoOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.EOSCoreLibrary.EOSProductUserIdIsValidPure
// Size: 0x22(Inherited: 0x0) 
struct FEOSProductUserIdIsValidPure
{
	struct FEOSProductUserId ID;  // 0x0(0x21)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)

}; 
// DelegateFunction EOSCore.OnDeleteSnapshotCallback__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnDeleteSnapshotCallback__DelegateSignature
{
	struct FEOSProgressionSnapshotDeleteSnapshotCallbackInfo Data;  // 0x0(0x30)

}; 
// ScriptStruct EOSCore.EOSProgressionSnapshotDeleteSnapshotCallbackInfo
// Size: 0x30(Inherited: 0x0) 
struct FEOSProgressionSnapshotDeleteSnapshotCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	struct FEOSProductUserId LocalUserId;  // 0x1(0x21)
	char pad_34[14];  // 0x22(0xE)

}; 
// Function EOSCore.EOSCoreEcomQueryOwnership.EOSEcomQueryOwnershipAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSEcomQueryOwnershipAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryOwnershipOptions Options;  // 0x8(0x48)
	struct UEOSCoreEcomQueryOwnership* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction EOSCore.OnSendPlayerBehaviorReportCompleteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSendPlayerBehaviorReportCompleteCallback__DelegateSignature
{
	struct FEOSReportsSendPlayerBehaviorReportCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnSendPlayerBehaviorReportCompleteDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSendPlayerBehaviorReportCompleteDelegate__DelegateSignature
{
	struct FEOSReportsSendPlayerBehaviorReportCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerTakeDamageOptions
// Size: 0xB0(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerTakeDamageOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle VictimPlayerHandle;  // 0x8(0x8)
	struct FEOSAntiCheatCommonVec3f VictimPlayerPosition;  // 0x10(0xC)
	struct FEOSAntiCheatCommonQuat VictimPlayerViewRotation;  // 0x1C(0x10)
	char pad_44[4];  // 0x2C(0x4)
	struct FEOSAntiCheatCommonClientHandle AttackerPlayerHandle;  // 0x30(0x8)
	struct FEOSAntiCheatCommonVec3f AttackerPlayerPosition;  // 0x38(0xC)
	struct FEOSAntiCheatCommonQuat AttackerPlayerViewRotation;  // 0x44(0x10)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool bIsHitscanAttack : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool bHasLineOfSight : 1;  // 0x55(0x1)
	char pad_86_1 : 7;  // 0x56(0x1)
	bool bIsCriticalHit : 1;  // 0x56(0x1)
	char pad_87[1];  // 0x57(0x1)
	float DamageTaken;  // 0x58(0x4)
	float HealthRemaining;  // 0x5C(0x4)
	uint8_t  DamageSource;  // 0x60(0x1)
	uint8_t  DamageType;  // 0x61(0x1)
	uint8_t  DamageResult;  // 0x62(0x1)
	char pad_99[5];  // 0x63(0x5)
	struct FEOSAntiCheatCommonLogPlayerUseWeaponData PlayerUseWeaponData;  // 0x68(0x40)
	int32_t TimeSincePlayerUseWeaponMs;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)

}; 
// DelegateFunction EOSCore.OnJoinRoomCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnJoinRoomCallback__DelegateSignature
{
	struct FEOSRTCJoinRoomCallbackInfo Data;  // 0x0(0x48)

}; 
// Function EOSCore.CoreConnect.EOSConnectGetProductUserIdMapping
// Size: 0x68(Inherited: 0x0) 
struct FEOSConnectGetProductUserIdMapping
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectGetProductUserIdMappingOptions Options;  // 0x8(0x48)
	struct FString OutString;  // 0x50(0x10)
	uint8_t  ReturnValue;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// ScriptStruct EOSCore.EOSRTCLeaveRoomCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSRTCLeaveRoomCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[71];  // 0x1(0x47)

}; 
// DelegateFunction EOSCore.OnBlockParticipantCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnBlockParticipantCallback__DelegateSignature
{
	struct FEOSRTCBlockParticipantCallbackInfo Data;  // 0x0(0x70)

}; 
// DelegateFunction EOSCore.OnDisconnectedCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnDisconnectedCallback__DelegateSignature
{
	struct FEOSRTCDisconnectedCallbackInfo Data;  // 0x0(0x48)

}; 
// ScriptStruct EOSCore.EOSRTCDisconnectedCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSRTCDisconnectedCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString RoomName;  // 0x38(0x10)

}; 
// DelegateFunction EOSCore.OnParticipantStatusChangedCallback__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnParticipantStatusChangedCallback__DelegateSignature
{
	struct FEOSRTCParticipantStatusChangedCallbackInfo Data;  // 0x0(0x78)

}; 
// ScriptStruct EOSCore.EOSRTCParticipantMetadata
// Size: 0x20(Inherited: 0x0) 
struct FEOSRTCParticipantMetadata
{
	struct FString Key;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerTickOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerTickOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle PlayerHandle;  // 0x8(0x8)
	struct FEOSAntiCheatCommonVec3f PlayerPosition;  // 0x10(0xC)
	struct FEOSAntiCheatCommonQuat PlayerViewRotation;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bIsPlayerViewZoomed : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	float PlayerHealth;  // 0x30(0x4)
	uint8_t  PlayerMovementState;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function EOSCore.EOSCoreLibrary.MakeParamInt32
// Size: 0x20(Inherited: 0x0) 
struct FMakeParamInt32
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FEOSAntiCheatCommonLogEventParamPair ReturnValue;  // 0x8(0x18)

}; 
// ScriptStruct EOSCore.EOSKickCompleteCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSKickCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)

}; 
// DelegateFunction EOSCore.OnSetParticipantHardMuteCompleteCallback__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnSetParticipantHardMuteCompleteCallback__DelegateSignature
{
	struct FEOSSetParticipantHardMuteCompleteCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectUserLoginInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSConnectUserLoginInfo
{
	struct FString DisplayName;  // 0x0(0x10)

}; 
// DelegateFunction EOSCore.OnParticipantUpdatedCallback__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FOnParticipantUpdatedCallback__DelegateSignature
{
	struct FEOSJoinRoomCallbackInfo Data;  // 0x0(0x68)

}; 
// Function EOSCore.CorePresence.GetPresence
// Size: 0x10(Inherited: 0x0) 
struct FGetPresence
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCorePresence* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSEcomCopyTransactionByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSEcomCopyTransactionByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t TransactionIndex;  // 0x28(0x4)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeInt64
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddAttributeInt64
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  Visibility;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// ScriptStruct EOSCore.EOSJoinRoomCallbackInfo
// Size: 0x68(Inherited: 0x0) 
struct FEOSJoinRoomCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString RoomName;  // 0x30(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x40(0x21)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool bSpeaking : 1;  // 0x61(0x1)
	uint8_t  AudioStatus;  // 0x62(0x1)
	char pad_99[5];  // 0x63(0x5)

}; 
// ScriptStruct EOSCore.EOSAudioInputStateCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSAudioInputStateCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString RoomName;  // 0x30(0x10)
	uint8_t  Status;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyUpdateReceived
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyUpdateReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerAddNotifyClientActionRequiredOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatServerAddNotifyClientActionRequiredOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// DelegateFunction EOSCore.OnAudioOutputStateCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnAudioOutputStateCallback__DelegateSignature
{
	struct FEOSOutputStateCallbackInfo Data;  // 0x0(0x48)

}; 
// ScriptStruct EOSCore.EOSSessionDetailsInfo
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionDetailsInfo
{
	struct FString SessionID;  // 0x0(0x10)
	struct FString HostAddress;  // 0x10(0x10)
	int32_t NumOpenPublicConnections;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FEOSSessionDetailsSettings Settings;  // 0x28(0x18)

}; 
// ScriptStruct EOSCore.EOSOutputStateCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSOutputStateCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString RoomName;  // 0x30(0x10)
	uint8_t  Status;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyLeaveLobbyOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyLeaveLobbyOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString LobbyID;  // 0x28(0x10)

}; 
// Function EOSCore.CoreAchievements.GetAchievements
// Size: 0x10(Inherited: 0x0) 
struct FGetAchievements
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreAchievements* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreRTC.EOSRTCLeaveRoom
// Size: 0x50(Inherited: 0x0) 
struct FEOSRTCLeaveRoom
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FLeaveRoomOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.CoreP2P.EOSP2PGetPacketQueueInfo
// Size: 0x78(Inherited: 0x0) 
struct FEOSP2PGetPacketQueueInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PGetPacketQueueInfoOptions Options;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FEOSP2PPacketQueueInfo OutPacketQueueInfo;  // 0x10(0x60)
	uint8_t  ReturnValue;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct EOSCore.EOSRTCAudioAudioBuffer
// Size: 0x10(Inherited: 0x0) 
struct FEOSRTCAudioAudioBuffer
{
	int32_t SampleRate;  // 0x0(0x4)
	int32_t Channels;  // 0x4(0x4)
	char pad_8[8];  // 0x8(0x8)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthQueryIdToken
// Size: 0x60(Inherited: 0x0) 
struct FEOSAuthQueryIdToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthQueryIdTokenOptions Options;  // 0x8(0x42)
	char pad_74[2];  // 0x4A(0x2)
	struct FDelegate Callback;  // 0x4C(0x10)
	char pad_92[4];  // 0x5C(0x4)

}; 
// ScriptStruct EOSCore.EOSBeforeRenderCallbackInfo
// Size: 0x78(Inherited: 0x0) 
struct FEOSBeforeRenderCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString RoomName;  // 0x30(0x10)
	struct FEOSRTCAudioAudioBuffer Buffer;  // 0x40(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x50(0x21)
	char pad_113[7];  // 0x71(0x7)

}; 
// Function EOSCore.EOSCoreLibrary.GetSessionAttributeBool
// Size: 0x28(Inherited: 0x0) 
struct FGetSessionAttributeBool
{
	struct FEOSSessionsAttributeData Data;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// DelegateFunction EOSCore.OnUpdateSendingCallback__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnUpdateSendingCallback__DelegateSignature
{
	struct FEOSUpdateSendingCallbackInfo Data;  // 0x0(0x50)

}; 
// DelegateFunction EOSCore.OnUpdateReceivingCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnUpdateReceivingCallback__DelegateSignature
{
	struct FEOSUpdateReceivingCallbackInfo Data;  // 0x0(0x70)

}; 
// ScriptStruct EOSCore.EOSUpdateReceivingCallbackInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSUpdateReceivingCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString RoomName;  // 0x38(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x48(0x21)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool bAudioEnabled : 1;  // 0x69(0x1)
	char pad_106[6];  // 0x6A(0x6)

}; 
// ScriptStruct EOSCore.EOSAudioDevicesChangedCallbackInfo
// Size: 0x8(Inherited: 0x0) 
struct FEOSAudioDevicesChangedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)

}; 
// DelegateFunction EOSCore.OnQueryActivePlayerSanctionsCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnQueryActivePlayerSanctionsCallback__DelegateSignature
{
	struct FEOSSanctionsQueryActivePlayerSanctionsCallbackInfo Data;  // 0x0(0x58)

}; 
// DelegateFunction EOSCore.OnStatsIngestStatCompleteCallback__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnStatsIngestStatCompleteCallback__DelegateSignature
{
	struct FEOSStatsIngestStatCompleteCallbackInfo Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSStatsIngestStatCompleteCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSStatsIngestStatCompleteCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsQueryPlayerAchievements
// Size: 0x60(Inherited: 0x0) 
struct FEOSAchievementsQueryPlayerAchievements
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsQueryPlayerAchievementsOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// ScriptStruct EOSCore.EOSStatsOnQueryStatsCompleteCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSStatsOnQueryStatsCompleteCallbackInfo
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  ResultCode;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// DelegateFunction EOSCore.OnStatsQueryStatsCompleteCallbackDelegate__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnStatsQueryStatsCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSStatsOnQueryStatsCompleteCallbackInfo Data;  // 0x0(0x58)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsLeaderboardUserScore
// Size: 0x2C(Inherited: 0x0) 
struct FEOSLeaderboardsLeaderboardUserScore
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId UserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t Score;  // 0x28(0x4)

}; 
// Function EOSCore.EOSCoreLibrary.EOSEResultToString
// Size: 0x18(Inherited: 0x0) 
struct FEOSEResultToString
{
	uint8_t  Result;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction EOSCore.OnTitleStorageQueryFileCompleteCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTitleStorageQueryFileCompleteCallback__DelegateSignature
{
	struct FEOSTitleStorageQueryFileCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSSanctionsCopyPlayerSanctionByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSSanctionsCopyPlayerSanctionByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t SanctionIndex;  // 0x28(0x4)

}; 
// ScriptStruct EOSCore.EOSTitleStorageQueryFileCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageQueryFileCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction EOSCore.OnTitleStorageFileTransferProgressCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnTitleStorageFileTransferProgressCallback__DelegateSignature
{
	struct FEOSTitleStorageFileTransferProgressCallbackInfo Data;  // 0x0(0x48)

}; 
// Function EOSCore.CoreProgressionSnapshot.GetProgressionSnapshot
// Size: 0x10(Inherited: 0x0) 
struct FGetProgressionSnapshot
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreProgressionSnapshot* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction EOSCore.OnTitleStorageReadFileCompleteCallback__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnTitleStorageReadFileCompleteCallback__DelegateSignature
{
	struct FEOSTitleStorageReadFileCallbackInfo Data;  // 0x0(0x48)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerDespawn
// Size: 0x20(Inherited: 0x0) 
struct FEOSAntiCheatServerLogPlayerDespawn
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerDespawnOptions Options;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// DelegateFunction EOSCore.OnTitleStorageQueryFileCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTitleStorageQueryFileCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSTitleStorageQueryFileCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnTitleStorageQueryFileListCompleteCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnTitleStorageQueryFileListCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSTitleStorageQueryFileListCallbackInfo Data;  // 0x0(0x38)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerBeginSession
// Size: 0x50(Inherited: 0x0) 
struct FEOSAntiCheatServerBeginSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerBeginSessionOptions Options;  // 0x8(0x40)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerGetProtectMessageOutputLength
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatServerGetProtectMessageOutputLength
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerGetProtectMessageOutputLengthOptions Options;  // 0x8(0x4)
	int32_t OutBufferLengthBytes;  // 0xC(0x4)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerAddNotifyMessageToClientOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatServerAddNotifyMessageToClientOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsAddNotifyAchievementsUnlockedV2
// Size: 0x20(Inherited: 0x0) 
struct FEOSAchievementsAddNotifyAchievementsUnlockedV2
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.EOSCoreLibrary.EOSProductUserIdToString
// Size: 0x40(Inherited: 0x0) 
struct FEOSProductUserIdToString
{
	struct FEOSProductUserId ID;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString String;  // 0x28(0x10)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// DelegateFunction EOSCore.OnTitleStorageReadFileCompleteCallbackDelegate__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnTitleStorageReadFileCompleteCallbackDelegate__DelegateSignature
{
	struct FEOSTitleStorageReadFileCallbackInfo Data;  // 0x0(0x48)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeInt64
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionModificationAddAttributeInt64
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	uint8_t  AdvertisementType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Key;  // 0x18(0x10)
	struct FString Value;  // 0x28(0x10)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// DelegateFunction EOSCore.OnShowFriendsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnShowFriendsCallback__DelegateSignature
{
	struct FEOSUIShowFriendsCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSUIShowFriendsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSUIShowFriendsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction EOSCore.OnHideFriendsCallback__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnHideFriendsCallback__DelegateSignature
{
	struct FEOSUIHideFriendsCallbackInfo Data;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSUIHideFriendsCallbackInfo
// Size: 0x38(Inherited: 0x0) 
struct FEOSUIHideFriendsCallbackInfo
{
	uint8_t  ResultCode;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSUIOnDisplaySettingsUpdatedCallbackInfo
// Size: 0x10(Inherited: 0x0) 
struct FEOSUIOnDisplaySettingsUpdatedCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsVisible : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bIsExclusiveInput : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// DelegateFunction EOSCore.OnHideFriendsCallbackDelegate__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnHideFriendsCallbackDelegate__DelegateSignature
{
	struct FEOSUIHideFriendsCallbackInfo Data;  // 0x0(0x38)

}; 
// DelegateFunction EOSCore.OnDisplaySettingsUpdatedCallbackDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnDisplaySettingsUpdatedCallbackDelegate__DelegateSignature
{
	struct FEOSUIOnDisplaySettingsUpdatedCallbackInfo Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSUserInfoQueryUserInfoByDisplayNameCallbackInfo
// Size: 0x68(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByDisplayNameCallbackInfo
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  ResultCode;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)
	struct FString DisplayName;  // 0x58(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsAttributeData
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsAttributeData
{
	char pad_0[32];  // 0x0(0x20)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerUseWeaponOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerUseWeaponOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerUseWeaponData UseWeaponData;  // 0x8(0x40)

}; 
// ScriptStruct EOSCore.EOSLobbyKickMemberOptions
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbyKickMemberOptions
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardUserScoreByIndex
// Size: 0x50(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardUserScoreByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsCopyLeaderboardUserScoreByIndexOptions Options;  // 0x8(0x18)
	struct FEOSLeaderboardsLeaderboardUserScore OutLeaderboardUserScore;  // 0x20(0x2C)
	uint8_t  ReturnValue;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)

}; 
// DelegateFunction EOSCore.OnQueryUserInfoByExternalAccountCallback__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnQueryUserInfoByExternalAccountCallback__DelegateSignature
{
	struct FEOSUserInfoQueryUserInfoByExternalAccountCallbackInfo Data;  // 0x0(0x70)

}; 
// ScriptStruct EOSCore.EOSUserInfoQueryUserInfoByExternalAccountCallbackInfo
// Size: 0x70(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByExternalAccountCallbackInfo
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  ResultCode;  // 0x4(0x1)
	char pad_5[11];  // 0x5(0xB)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct FString ExternalAccountId;  // 0x38(0x10)
	uint8_t  AccountType;  // 0x48(0x1)
	struct FEOSEpicAccountId TargetUserId;  // 0x49(0x21)
	char pad_106[6];  // 0x6A(0x6)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthVerifyUserAuth
// Size: 0xC8(Inherited: 0x0) 
struct FEOSAuthVerifyUserAuth
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthVerifyUserAuthOptions Options;  // 0x8(0xB0)
	struct FDelegate Callback;  // 0xB8(0x10)

}; 
// DelegateFunction EOSCore.OnQueryUserInfoByDisplayNameCallbackDelegate__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FOnQueryUserInfoByDisplayNameCallbackDelegate__DelegateSignature
{
	struct FEOSUserInfoQueryUserInfoByDisplayNameCallbackInfo Data;  // 0x0(0x68)

}; 
// ScriptStruct EOSCore.EOSAchievementsUnlockAchievementsOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAchievementsUnlockAchievementsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId UserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct TArray<struct FString> AchievementIds;  // 0x28(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsCopyMemberAttributeByIndex
// Size: 0x80(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyMemberAttributeByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsCopyMemberAttributeByIndexOptions Options;  // 0x10(0x2C)
	char pad_60[4];  // 0x3C(0x4)
	struct FEOSLobbyAttribute OutAttribute;  // 0x40(0x38)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// ScriptStruct EOSCore.EOSAchievementsCopyPlayerAchievementByAchievementIdOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSAchievementsCopyPlayerAchievementByAchievementIdOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString AchievementId;  // 0x28(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x38(0x21)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardUserScoreByUserId
// Size: 0x70(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardUserScoreByUserId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsCopyLeaderboardUserScoreByUserIdOptions Options;  // 0x8(0x38)
	struct FEOSLeaderboardsLeaderboardUserScore OutLeaderboardUserScore;  // 0x40(0x2C)
	uint8_t  ReturnValue;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)

}; 
// ScriptStruct EOSCore.EOSAchievementsCopyPlayerAchievementByIndexOptions
// Size: 0x50(Inherited: 0x0) 
struct FEOSAchievementsCopyPlayerAchievementByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t AchievementIndex;  // 0x28(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x2C(0x21)
	char pad_77[3];  // 0x4D(0x3)

}; 
// ScriptStruct EOSCore.EOSConnectDeleteDeviceIdOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSConnectDeleteDeviceIdOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSUserToken
// Size: 0x38(Inherited: 0x0) 
struct FEOSUserToken
{
	struct FEOSProductUserId ProductUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString token;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientUnregisterPeerOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSAntiCheatClientUnregisterPeerOptions
{
	struct FEOSAntiCheatCommonClientHandle PeerHandle;  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSAchievementsPlayerAchievement
// Size: 0x88(Inherited: 0x0) 
struct FEOSAchievementsPlayerAchievement
{
	char pad_0[8];  // 0x0(0x8)
	struct FString AchievementId;  // 0x8(0x10)
	float Progress;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString UnlockTime;  // 0x20(0x10)
	int32_t StatInfoCount;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct TArray<struct FEOSAchievementsPlayerStatInfo> StatInfo;  // 0x38(0x10)
	struct FString DisplayName;  // 0x48(0x10)
	struct FString Description;  // 0x58(0x10)
	struct FString IconURL;  // 0x68(0x10)
	struct FString FlavorText;  // 0x78(0x10)

}; 
// ScriptStruct EOSCore.EOSAchievementsQueryPlayerAchievementsOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSAchievementsQueryPlayerAchievementsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	struct FEOSProductUserId LocalUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyMessageToPeer
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyMessageToPeer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientAddNotifyMessageToPeerOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// ScriptStruct EOSCore.EOSAchievementsCopyAchievementDefinitionV2ByAchievementIdOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSAchievementsCopyAchievementDefinitionV2ByAchievementIdOptions
{
	struct FString AchievementId;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAchievementsGetAchievementDefinitionCountOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSAchievementsGetAchievementDefinitionCountOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSConnectAddNotifyLoginStatusChangedOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSConnectAddNotifyLoginStatusChangedOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonVec3f
// Size: 0xC(Inherited: 0x0) 
struct FEOSAntiCheatCommonVec3f
{
	float X;  // 0x0(0x4)
	float Y;  // 0x4(0x4)
	float Z;  // 0x8(0x4)

}; 
// Function EOSCore.EOSCoreConnectQueryExternalAccountMappings.EOSConnectQueryExternalAccountMappingsAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSConnectQueryExternalAccountMappingsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectQueryExternalAccountMappingsOptions Options;  // 0x8(0x38)
	struct UEOSCoreConnectQueryExternalAccountMappings* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct EOSCore.EOSAchievementsDefinitionV2
// Size: 0xA0(Inherited: 0x0) 
struct FEOSAchievementsDefinitionV2
{
	char pad_0[8];  // 0x0(0x8)
	struct FString AchievementId;  // 0x8(0x10)
	struct FString UnlockedDisplayName;  // 0x18(0x10)
	struct FString UnlockedDescription;  // 0x28(0x10)
	struct FString LockedDisplayName;  // 0x38(0x10)
	struct FString LockedDescription;  // 0x48(0x10)
	struct FString FlavorText;  // 0x58(0x10)
	struct FString UnlockedIconURL;  // 0x68(0x10)
	struct FString LockedIconURL;  // 0x78(0x10)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bIsHidden : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t StatThresholdsCount;  // 0x8C(0x4)
	struct TArray<struct FEOSAchievementsStatThresholds> StatThresholds;  // 0x90(0x10)

}; 
// Function EOSCore.CoreConnect.EOSConnectDeleteDeviceId
// Size: 0x20(Inherited: 0x0) 
struct FEOSConnectDeleteDeviceId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectDeleteDeviceIdOptions Options;  // 0x8(0x4)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct EOSCore.EOSAchievementsStatThresholds
// Size: 0x20(Inherited: 0x0) 
struct FEOSAchievementsStatThresholds
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Name;  // 0x8(0x10)
	int32_t Threshold;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientReceiveMessageFromPeerOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatClientReceiveMessageFromPeerOptions
{
	struct FEOSAntiCheatCommonClientHandle PeerHandle;  // 0x0(0x8)
	struct TArray<char> Data;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientRegisterPeerOptions
// Size: 0x30(Inherited: 0x0) 
struct FEOSAntiCheatClientRegisterPeerOptions
{
	struct FEOSAntiCheatCommonClientHandle PeerHandle;  // 0x0(0x8)
	uint8_t  ClientType;  // 0x8(0x1)
	uint8_t  ClientPlatform;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct FString AccountId;  // 0x10(0x10)
	struct FString IpAddress;  // 0x20(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientUnprotectMessageOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatClientUnprotectMessageOptions
{
	struct TArray<char> Data;  // 0x0(0x10)
	int32_t OutBufferSizeBytes;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientReceiveMessageFromServerOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatClientReceiveMessageFromServerOptions
{
	struct TArray<char> Data;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientAddExternalIntegrityCatalogOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatClientAddExternalIntegrityCatalogOptions
{
	struct FString PathToBinFile;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyDestroyLobbyOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyDestroyLobbyOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString LobbyID;  // 0x28(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsGetMemberAttributeCount
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbyDetailsGetMemberAttributeCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsGetMemberAttributeCountOptions Options;  // 0x10(0x28)
	int32_t ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientPollStatusOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSAntiCheatClientPollStatusOptions
{
	int32_t OutMessageLength;  // 0x0(0x4)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsGetPlayerAchievementCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSAchievementsGetPlayerAchievementCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsGetPlayerAchievementCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientEndSessionOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatClientEndSessionOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsGetMemberCountOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLobbyDetailsGetMemberCountOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageReadFileDataCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSPlayerDataStorageReadFileDataCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString Filename;  // 0x30(0x10)
	int32_t TotalFileSizeBytes;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bIsLastChunk : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	int32_t DataChunkLengthBytes;  // 0x48(0x4)
	char pad_76[12];  // 0x4C(0xC)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientAddNotifyPeerActionRequiredOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyPeerActionRequiredOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientAddNotifyMessageToPeerOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyMessageToPeerOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSAntiCheatClientAddNotifyMessageToServerOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyMessageToServerOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioInputState
// Size: 0x60(Inherited: 0x0) 
struct FEOSRTCAudioAddNotifyAudioInputState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSAddNotifyAudioInputStateOptions Options;  // 0x10(0x38)
	struct FDelegate Callback;  // 0x48(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct EOSCore.EOSStatsQueryStatsOptions
// Size: 0x80(Inherited: 0x0) 
struct FEOSStatsQueryStatsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString StartTime;  // 0x28(0x10)
	struct FString EndTime;  // 0x38(0x10)
	struct TArray<struct FString> StatNames;  // 0x48(0x10)
	char pad_88[4];  // 0x58(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x5C(0x21)
	char pad_125[3];  // 0x7D(0x3)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerSetClientNetworkStateOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatServerSetClientNetworkStateOptions
{
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsNetworkActive : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerUnregisterClientOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSAntiCheatServerUnregisterClientOptions
{
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatServerAddNotifyClientAuthStatusChangedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAntiCheatServerAddNotifyClientAuthStatusChangedOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageDeleteFile
// Size: 0x50(Inherited: 0x0) 
struct FEOSPlayerDataStorageDeleteFile
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageDeleteFileOptions DeleteOptions;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSAuthCopyIdTokenOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSAuthCopyIdTokenOptions
{
	struct FEOSEpicAccountId AccountId;  // 0x0(0x21)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchSetTargetUserId
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbySearchSetTargetUserId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchSetTargetUserIdOptions Options;  // 0x10(0x28)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSHRTCAudio
// Size: 0x8(Inherited: 0x0) 
struct FEOSHRTCAudio
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSAuthVerifyIdTokenOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAuthVerifyIdTokenOptions
{
	struct FEOSAuthIdToken IdToken;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSFriendsSendInviteOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSFriendsSendInviteOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// ScriptStruct EOSCore.EOSP2PAcceptConnectionOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSP2PAcceptConnectionOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	struct FEOSProductUserId RemoteUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)
	struct FEOSP2PSocketId SocketId;  // 0x48(0x18)

}; 
// ScriptStruct EOSCore.EOSAuthDeletePersistentAuthOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSAuthDeletePersistentAuthOptions
{
	struct FString RefreshToken;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSAuthAddNotifyLoginStatusChangedOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSAuthAddNotifyLoginStatusChangedOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSAuthVerifyUserAuthOptions
// Size: 0xB0(Inherited: 0x0) 
struct FEOSAuthVerifyUserAuthOptions
{
	struct FEOSAuthToken AuthToken;  // 0x0(0xB0)

}; 
// ScriptStruct EOSCore.EOSAuthLinkAccountOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAuthLinkAccountOptions
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  LinkAccountFlags;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FContinuanceToken ContinuanceToken;  // 0x8(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionModificationAddAttributeOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionModificationAddAttributeOptions
{
	struct FEOSSessionsAttributeData Data;  // 0x0(0x20)
	uint8_t  AdvertisementType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSAuthCredentials
// Size: 0x30(Inherited: 0x0) 
struct FEOSAuthCredentials
{
	char pad_0[8];  // 0x0(0x8)
	struct FString ID;  // 0x8(0x10)
	struct FString token;  // 0x18(0x10)
	uint8_t  Type;  // 0x28(0x1)
	uint8_t  ExternalType;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationSetPermissionLevel
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyModificationSetPermissionLevel
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FEOSLobbyModificationSetPermissionLevelOptions Options;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct EOSCore.EOSConnectVerifyIdTokenOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectVerifyIdTokenOptions
{
	struct FEOSConnectIdToken IdToken;  // 0x0(0x38)

}; 
// ScriptStruct EOSCore.EOSSessionsCreateSessionSearchOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSSessionsCreateSessionSearchOptions
{
	int32_t MaxSearchResults;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomTransactionCopyEntitlementByIndexOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSEcomTransactionCopyEntitlementByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t EntitlementIndex;  // 0x4(0x4)

}; 
// ScriptStruct EOSCore.EOSConnectIdToken
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectIdToken
{
	struct FEOSProductUserId ProductUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString JsonWebToken;  // 0x28(0x10)

}; 
// Function EOSCore.CoreCustomInvites.EOSCustomInvitesAddNotifyCustomInviteAccepted
// Size: 0x20(Inherited: 0x0) 
struct FEOSCustomInvitesAddNotifyCustomInviteAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSConnectCopyIdTokenOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSConnectCopyIdTokenOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// ScriptStruct EOSCore.EOSConnectAddNotifyAuthExpirationOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSConnectAddNotifyAuthExpirationOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyAddNotifyJoinLobbyAcceptedOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLobbyAddNotifyJoinLobbyAcceptedOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbySendInviteOptions
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbySendInviteOptions
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// Function EOSCore.EOSCoreLibrary.GetCurrentProductId
// Size: 0x30(Inherited: 0x0) 
struct FGetCurrentProductId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	int32_t UserIndex;  // 0x8(0x4)
	struct FEOSProductUserId ReturnValue;  // 0xC(0x21)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoQueryUserInfoByDisplayName
// Size: 0x50(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByDisplayName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoQueryUserInfoByDisplayNameOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectExternalAccountInfo
// Size: 0x60(Inherited: 0x0) 
struct FEOSConnectExternalAccountInfo
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId ProductUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString DisplayName;  // 0x28(0x10)
	struct FString AccountId;  // 0x38(0x10)
	uint8_t  AccountIdType;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString LastLoginTime;  // 0x50(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectCopyProductUserInfoOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSConnectCopyProductUserInfoOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSConnectGetProductUserExternalAccountCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSConnectGetProductUserExternalAccountCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSConnectGetProductUserIdMappingOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSConnectGetProductUserIdMappingOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	uint8_t  AccountIdType;  // 0x25(0x1)
	struct FEOSProductUserId TargetProductUserId;  // 0x26(0x21)
	char pad_71[1];  // 0x47(0x1)

}; 
// ScriptStruct EOSCore.EOSConnectGetExternalAccountMappingsOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectGetExternalAccountMappingsOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	uint8_t  AccountIdType;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct FString TargetExternalUserId;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectTransferDeviceIdAccountOptions
// Size: 0x63(Inherited: 0x0) 
struct FEOSConnectTransferDeviceIdAccountOptions
{
	struct FEOSProductUserId PrimaryLocalUserId;  // 0x0(0x21)
	struct FEOSProductUserId LocalDeviceUserId;  // 0x21(0x21)
	struct FEOSProductUserId ProductUserIdToPreserve;  // 0x42(0x21)

}; 
// Function EOSCore.EOSCoreConnectLogin.EOSConnectLoginAsync
// Size: 0x40(Inherited: 0x0) 
struct FEOSConnectLoginAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectLoginOptions Options;  // 0x8(0x30)
	struct UEOSCoreConnectLogin* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct EOSCore.EOSConnectCreateDeviceIdOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSConnectCreateDeviceIdOptions
{
	struct FString DeviceModel;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.LeaveRoomOptions
// Size: 0x38(Inherited: 0x0) 
struct FLeaveRoomOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectUnlinkAccountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSConnectUnlinkAccountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSFriendsQueryFriendsOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSFriendsQueryFriendsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSConnectLinkAccountOptions
// Size: 0x30(Inherited: 0x0) 
struct FEOSConnectLinkAccountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FContinuanceToken ContinuanceToken;  // 0x28(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioInputState
// Size: 0x18(Inherited: 0x0) 
struct FEOSRTCAudioRemoveNotifyAudioInputState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSNotificationId NotificationID;  // 0x10(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonRegisterEventParamDef
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatCommonRegisterEventParamDef
{
	struct FString ParamName;  // 0x0(0x10)
	uint8_t  ParamType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyAddNotifyLobbyMemberStatusReceivedOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyMemberStatusReceivedOptions
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSConnectCreateUserOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSConnectCreateUserOptions
{
	struct FContinuanceToken ContinuanceToken;  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogPlayerUseAbilityOptions
// Size: 0x20(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogPlayerUseAbilityOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle PlayerHandle;  // 0x8(0x8)
	int32_t AbilityId;  // 0x10(0x4)
	int32_t AbilityDurationMs;  // 0x14(0x4)
	int32_t AbilityCooldownMs;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogGameRoundStartOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogGameRoundStartOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString SessionIdentifier;  // 0x8(0x10)
	struct FString LevelName;  // 0x18(0x10)
	struct FString ModeName;  // 0x28(0x10)
	int32_t RoundTimeSeconds;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonLogEventParamPair
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatCommonLogEventParamPair
{
	char pad_0[24];  // 0x0(0x18)

}; 
// Function EOSCore.CoreP2P.EOSP2PQueryNATType
// Size: 0x18(Inherited: 0x0) 
struct FEOSP2PQueryNATType
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationAddAttributeOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddAttributeOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSLobbyAttributeData Attribute;  // 0x8(0x28)
	uint8_t  Visibility;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSAntiCheatCommonSetClientDetailsOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatCommonSetClientDetailsOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSAntiCheatCommonClientHandle ClientHandle;  // 0x8(0x8)
	uint8_t  ClientFlags;  // 0x10(0x1)
	uint8_t  ClientInputMethod;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesFinalizeInviteOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSCustomInvitesFinalizeInviteOptions
{
	struct FEOSProductUserId TargetUserId;  // 0x0(0x21)
	struct FEOSProductUserId LocalUserId;  // 0x21(0x21)
	char pad_66[6];  // 0x42(0x6)
	struct FString CustomInviteId;  // 0x48(0x10)
	uint8_t  ProcessingResult;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// ScriptStruct EOSCore.EOSEcomGetItemImageInfoCountOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetItemImageInfoCountOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString ItemId;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSModsModInfo
// Size: 0x20(Inherited: 0x0) 
struct FEOSModsModInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct FEOSModIdentifier> Mods;  // 0x8(0x10)
	uint8_t  Type;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionsAddNotifySessionInviteAcceptedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionsAddNotifySessionInviteAcceptedOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSCustomInvitesSendCustomInviteOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSCustomInvitesSendCustomInviteOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FEOSProductUserId> TargetUserIds;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomTransactionGetEntitlementsCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSEcomTransactionGetEntitlementsCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSEcomCopyTransactionByIdOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomCopyTransactionByIdOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString TransactionId;  // 0x28(0x10)

}; 
// Function EOSCore.CoreLobby.GetLobby
// Size: 0x10(Inherited: 0x0) 
struct FGetLobby
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreLobby* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSEcomGetTransactionCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSEcomGetTransactionCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSEcomCopyItemReleaseByIndexOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomCopyItemReleaseByIndexOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString ItemId;  // 0x28(0x10)
	int32_t ReleaseIndex;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomGetItemReleaseCountOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetItemReleaseCountOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString ItemId;  // 0x28(0x10)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientPollStatus
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatClientPollStatus
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientPollStatusOptions Options;  // 0x8(0x4)
	uint8_t  ViolationType;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FString OutMessage;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSEcomGetOfferImageInfoCountOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetOfferImageInfoCountOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString OfferId;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomCopyOfferItemByIndexOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomCopyOfferItemByIndexOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString OfferId;  // 0x28(0x10)
	int32_t ItemIndex;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomCopyOfferByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSEcomCopyOfferByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t OfferIndex;  // 0x28(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomCopyEntitlementByIdOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomCopyEntitlementByIdOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FEOSEcomEntitlementId EntitlementId;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomEntitlementId
// Size: 0x10(Inherited: 0x0) 
struct FEOSEcomEntitlementId
{
	struct FString EntitlementId;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSMetricsBeginPlayerSessionOptions
// Size: 0x70(Inherited: 0x0) 
struct FEOSMetricsBeginPlayerSessionOptions
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  AccountIdType;  // 0x4(0x1)
	struct FEOSEpicAccountId Epic;  // 0x5(0x21)
	char pad_38[2];  // 0x26(0x2)
	struct FString External;  // 0x28(0x10)
	struct FString DisplayName;  // 0x38(0x10)
	uint8_t  ControllerType;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString ServerIp;  // 0x50(0x10)
	struct FString GameSessionId;  // 0x60(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomCopyEntitlementByNameAndIndexOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomCopyEntitlementByNameAndIndexOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FEOSEcomEntitlementName EntitlementName;  // 0x28(0x10)
	int32_t Index;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSEcomEntitlementName
// Size: 0x10(Inherited: 0x0) 
struct FEOSEcomEntitlementName
{
	struct FString Name;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbySearchSetLobbyIdOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbySearchSetLobbyIdOptions
{
	struct FString LobbyID;  // 0x0(0x10)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyOfferItemByIndex
// Size: 0xF0(Inherited: 0x0) 
struct FEOSEcomCopyOfferItemByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyOfferItemByIndexOptions Options;  // 0x8(0x40)
	struct FEOSEcomCatalogItem OutItem;  // 0x48(0xA0)
	uint8_t  ReturnValue;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)

}; 
// ScriptStruct EOSCore.EOSEcomGetEntitlementsByNameCountOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetEntitlementsByNameCountOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FEOSEcomEntitlementName EntitlementName;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomRedeemEntitlementsOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomRedeemEntitlementsOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FEOSEcomEntitlementId> EntitlementIds;  // 0x28(0x10)

}; 
// Function EOSCore.EOSCoreAuthDeletePersistentAuth.EOSAuthDeletePersistentAuthAsync
// Size: 0x20(Inherited: 0x0) 
struct FEOSAuthDeletePersistentAuthAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthDeletePersistentAuthOptions Options;  // 0x8(0x10)
	struct UEOSCoreAuthDeletePersistentAuth* ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSEcomCheckoutOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomCheckoutOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString OverrideCatalogNamespace;  // 0x28(0x10)
	struct TArray<struct FEOSEcomCheckoutEntry> Entries;  // 0x38(0x10)

}; 
// ScriptStruct EOSCore.EOSUserInfoGetExternalUserInfoCountOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSUserInfoGetExternalUserInfoCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.EOSReportsSendPlayerBehaviorReport.EOSReportsSendPlayerBehaviorReportAsync
// Size: 0x78(Inherited: 0x0) 
struct FEOSReportsSendPlayerBehaviorReportAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSReportsSendPlayerBehaviorReportOptions Options;  // 0x8(0x68)
	struct UEOSReportsSendPlayerBehaviorReport* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct EOSCore.EOSEcomCheckoutEntry
// Size: 0x18(Inherited: 0x0) 
struct FEOSEcomCheckoutEntry
{
	char pad_0[8];  // 0x0(0x8)
	struct FString OfferId;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomQueryOffersOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomQueryOffersOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString OverrideCatalogNamespace;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomQueryEntitlementsOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomQueryEntitlementsOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FEOSEcomEntitlementName> EntitlementNames;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bIncludeRedeemed : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthGetLoggedInAccountsCount
// Size: 0x10(Inherited: 0x0) 
struct FEOSAuthGetLoggedInAccountsCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchSetParameterDouble
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionSearchSetParameterDouble
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  ComparisonOp;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// ScriptStruct EOSCore.EOSModsCopyModInfoOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSModsCopyModInfoOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	uint8_t  Type;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)

}; 
// ScriptStruct EOSCore.EOSEcomQueryOwnershipOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomQueryOwnershipOptions
{
	struct FEOSEpicAccountId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FString> CatalogItemIds;  // 0x28(0x10)
	struct FString CatalogNamespace;  // 0x38(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomCatalogRelease
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomCatalogRelease
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct FString> CompatibleAppIds;  // 0x8(0x10)
	char pad_24[8];  // 0x18(0x8)
	struct TArray<struct FString> CompatiblePlatforms;  // 0x20(0x10)
	struct FString ReleaseNote;  // 0x30(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomCatalogOffer
// Size: 0xB8(Inherited: 0x0) 
struct FEOSEcomCatalogOffer
{
	char pad_0[4];  // 0x0(0x4)
	int32_t ServerIndex;  // 0x4(0x4)
	struct FString CatalogNamespace;  // 0x8(0x10)
	struct FString ID;  // 0x18(0x10)
	struct FString TitleText;  // 0x28(0x10)
	struct FString DescriptionText;  // 0x38(0x10)
	struct FString LongDescriptionText;  // 0x48(0x10)
	struct FString TechnicalDetailsText;  // 0x58(0x10)
	struct FString CurrencyCode;  // 0x68(0x10)
	uint8_t  PriceResult;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	int64_t OriginalPrice;  // 0x80(0x8)
	int64_t CurrentPrice;  // 0x88(0x8)
	int32_t DiscountPercentage;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct FString ExpirationTimestamp;  // 0x98(0x10)
	int32_t PurchasedCount;  // 0xA8(0x4)
	int32_t PurchaseLimit;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool bAvailableForPurchase : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 
// ScriptStruct EOSCore.EOSEcomCatalogItem
// Size: 0xA0(Inherited: 0x0) 
struct FEOSEcomCatalogItem
{
	char pad_0[8];  // 0x0(0x8)
	struct FString CatalogNamespace;  // 0x8(0x10)
	struct FString ID;  // 0x18(0x10)
	struct FEOSEcomEntitlementName EntitlementName;  // 0x28(0x10)
	struct FString TitleText;  // 0x38(0x10)
	struct FString DescriptionText;  // 0x48(0x10)
	struct FString LongDescriptionText;  // 0x58(0x10)
	struct FString TechnicalDetailsText;  // 0x68(0x10)
	struct FString DeveloperText;  // 0x78(0x10)
	uint8_t  ItemType;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct FString EntitlementEndTimestamp;  // 0x90(0x10)

}; 
// ScriptStruct EOSCore.EOSEcomEntitlement
// Size: 0x50(Inherited: 0x0) 
struct FEOSEcomEntitlement
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSEcomEntitlementName EntitlementName;  // 0x8(0x10)
	struct FEOSEcomEntitlementId EntitlementId;  // 0x18(0x10)
	struct FString CatalogItemId;  // 0x28(0x10)
	int32_t ServerIndex;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bRedeemed : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FString EndTimestamp;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSFriendsAddNotifyFriendsUpdateOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSFriendsAddNotifyFriendsUpdateOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSStatsCopyStatByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSStatsCopyStatByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t StatIndex;  // 0x28(0x4)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthLinkAccount
// Size: 0x50(Inherited: 0x0) 
struct FEOSAuthLinkAccount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthLinkAccountOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSFriendsGetStatusOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSFriendsGetStatusOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// ScriptStruct EOSCore.EOSFriendsGetFriendsCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSFriendsGetFriendsCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthLogin
// Size: 0x58(Inherited: 0x0) 
struct FEOSAuthLogin
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthLoginOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// ScriptStruct EOSCore.EOSFriendsDeleteFriendOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSFriendsDeleteFriendOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// ScriptStruct EOSCore.EOSSessionsSendInviteOptions
// Size: 0x58(Inherited: 0x0) 
struct FEOSSessionsSendInviteOptions
{
	struct FString SessionName;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	struct FEOSProductUserId TargetUserId;  // 0x31(0x21)
	char pad_82[6];  // 0x52(0x6)

}; 
// Function EOSCore.CoreConnect.EOSConnectQueryProductUserIdMappings
// Size: 0x50(Inherited: 0x0) 
struct FEOSConnectQueryProductUserIdMappings
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectQueryProductUserIdMappingsOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSFriendsRejectInviteOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSFriendsRejectInviteOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// ScriptStruct EOSCore.EOSFriendsAcceptInviteOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSFriendsAcceptInviteOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsCopyLeaderboardRecordByUserIdOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardRecordByUserIdOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId UserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.EOSCoreUserInfoQueryUserInfoByDisplayName.EOSUserInfoQueryUserInfoByDisplayNameAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByDisplayNameAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoQueryUserInfoByDisplayNameOptions Options;  // 0x8(0x38)
	struct UEOSCoreUserInfoQueryUserInfoByDisplayName* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsQueryLeaderboardRanksOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardRanksOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString LeaderboardId;  // 0x8(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x18(0x21)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSAddNotifyParticipantUpdatedOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAddNotifyParticipantUpdatedOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)

}; 
// Function EOSCore.EOSCoreTitleStorageDeleteCache.EOSTitleStorageDeleteCacheAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageDeleteCacheAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageDeleteCacheOptions Options;  // 0x8(0x28)
	struct UEOSCoreTitleStorageDeleteCache* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsCopyLeaderboardUserScoreByUserIdOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardUserScoreByUserIdOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId UserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString StatName;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsCopyLeaderboardUserScoreByIndexOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardUserScoreByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t LeaderboardUserScoreIndex;  // 0x4(0x4)
	struct FString StatName;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsGetLeaderboardUserScoreCountOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLeaderboardsGetLeaderboardUserScoreCountOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString StatName;  // 0x8(0x10)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientBeginSession
// Size: 0x30(Inherited: 0x0) 
struct FEOSAntiCheatClientBeginSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientBeginSessionOptions Options;  // 0x8(0x22)
	uint8_t  ReturnValue;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientGetProtectMessageOutputLength
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatClientGetProtectMessageOutputLength
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientGetProtectMessageOutputLengthOptions Options;  // 0x8(0x4)
	int32_t OutBufferLengthBytes;  // 0xC(0x4)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsCopyInfo
// Size: 0x78(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsCopyInfoOptions Options;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FEOSLobbyDetailsInfo OutLobbyDetailsInfo;  // 0x18(0x58)
	uint8_t  ReturnValue;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsQueryLeaderboardUserScoresOptions
// Size: 0x70(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardUserScoresOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct FEOSProductUserId> UserIds;  // 0x8(0x10)
	struct TArray<struct FEOSLeaderboardsUserScoresQueryStatInfo> StatInfo;  // 0x18(0x10)
	struct FString StartTime;  // 0x28(0x10)
	struct FString EndTime;  // 0x38(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x48(0x21)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardIdOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardIdOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString LeaderboardId;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsCopyLeaderboardDefinitionByIndexOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardDefinitionByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t LeaderboardIndex;  // 0x4(0x4)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioInputDevicesCount
// Size: 0x10(Inherited: 0x0) 
struct FEOSRTCAudioGetAudioInputDevicesCount
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSGetAudioInputDevicesCountOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsGetLeaderboardDefinitionCountOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLeaderboardsGetLeaderboardDefinitionCountOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsDefinition
// Size: 0x50(Inherited: 0x0) 
struct FEOSLeaderboardsDefinition
{
	char pad_0[8];  // 0x0(0x8)
	struct FString LeaderboardId;  // 0x8(0x10)
	struct FString StatName;  // 0x18(0x10)
	uint8_t  Aggregation;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString StartTime;  // 0x30(0x10)
	struct FString EndTime;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageFileMetadata
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageFileMetadata
{
	char pad_0[4];  // 0x0(0x4)
	int32_t FileSizeBytes;  // 0x4(0x4)
	struct FString MD5Hash;  // 0x8(0x10)
	struct FString Filename;  // 0x18(0x10)
	struct FDateTime LastModifiedTime;  // 0x28(0x8)
	int32_t UnencryptedDataSizeBytes;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CoreEcom.EOSEcomQueryOffers
// Size: 0x50(Inherited: 0x0) 
struct FEOSEcomQueryOffers
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryOffersOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSLeaderboardsQueryLeaderboardDefinitionsOptions
// Size: 0x50(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardDefinitionsOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString StartTime;  // 0x8(0x10)
	struct FString EndTime;  // 0x18(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x28(0x21)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageCopyFileMetadataAtIndex
// Size: 0x68(Inherited: 0x0) 
struct FEOSTitleStorageCopyFileMetadataAtIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageCopyFileMetadataAtIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSTitleStorageFileMetadata OutMetadata;  // 0x38(0x28)
	uint8_t  ReturnValue;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// ScriptStruct EOSCore.EOSHLobbySearch
// Size: 0x8(Inherited: 0x0) 
struct FEOSHLobbySearch
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbySearchCopySearchResultByIndexOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbySearchCopySearchResultByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t LobbyIndex;  // 0x4(0x4)

}; 
// Function EOSCore.EOSCoreLibrary.MakeParamString
// Size: 0x28(Inherited: 0x0) 
struct FMakeParamString
{
	struct FString String;  // 0x0(0x10)
	struct FEOSAntiCheatCommonLogEventParamPair ReturnValue;  // 0x10(0x18)

}; 
// ScriptStruct EOSCore.EOSLobbySearchGetSearchResultCountOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLobbySearchGetSearchResultCountOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbySearchSetMaxResultsOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbySearchSetMaxResultsOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t MaxResults;  // 0x4(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbySearchRemoveParameterOptions
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbySearchRemoveParameterOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Key;  // 0x8(0x10)
	uint8_t  ComparisonOp;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbySearchSetParameterOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbySearchSetParameterOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSLobbyAttributeData Parameter;  // 0x8(0x28)
	uint8_t  ComparisonOp;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyAttributeData
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyAttributeData
{
	char pad_0[40];  // 0x0(0x28)

}; 
// Function EOSCore.CoreLobby.EOSLobbyGetRTCRoomName
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbyGetRTCRoomName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyGetRTCRoomNameOptions Options;  // 0x8(0x38)
	struct FString OutBuffer;  // 0x40(0x10)
	int32_t InOutBufferLength;  // 0x50(0x4)
	uint8_t  ReturnValue;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbySearchFindOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbySearchFindOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsCopyMemberAttributeByKeyOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyMemberAttributeByKeyOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString AttrKey;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsCopyMemberAttributeByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyMemberAttributeByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t AttrIndex;  // 0x28(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsCopyAttributeByKeyOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyAttributeByKeyOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString AttrKey;  // 0x8(0x10)

}; 
// Function EOSCore.EOSCoreLobbyDestroyLobby.EOSLobbyDestroyLobbyAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSLobbyDestroyLobbyAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyDestroyLobbyOptions Options;  // 0x8(0x38)
	struct UEOSCoreLobbyDestroyLobby* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsCopyAttributeByIndexOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyAttributeByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t AttrIndex;  // 0x4(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyCreateLobbySearchOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyCreateLobbySearchOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t MaxResults;  // 0x4(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsGetAttributeCountOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLobbyDetailsGetAttributeCountOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsGetLobbyOwnerOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSLobbyDetailsGetLobbyOwnerOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRegisterPeer
// Size: 0x40(Inherited: 0x0) 
struct FEOSAntiCheatClientRegisterPeer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientRegisterPeerOptions Options;  // 0x8(0x30)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSPresenceAddNotifyOnPresenceChangedOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSPresenceAddNotifyOnPresenceChangedOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationAddMemberAttributeOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddMemberAttributeOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSLobbyAttributeData Attribute;  // 0x8(0x28)
	uint8_t  Visibility;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSUIShowFriendsOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSUIShowFriendsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationRemoveAttributeOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyModificationRemoveAttributeOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Key;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationSetInvitesAllowedOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyModificationSetInvitesAllowedOptions
{
	char pad_0[4];  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bInvitesAllowed : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function EOSCore.CoreCustomInvites.EOSCustomInvitesRemoveNotifyCustomInviteAccepted
// Size: 0x10(Inherited: 0x0) 
struct FEOSCustomInvitesRemoveNotifyCustomInviteAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationSetMaxMembersOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyModificationSetMaxMembersOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t MaxMembers;  // 0x4(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyAttribute
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyAttribute
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSLobbyAttributeData Data;  // 0x8(0x28)
	uint8_t  Visbility;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSPresenceAddNotifyJoinGameAcceptedOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSPresenceAddNotifyJoinGameAcceptedOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSLobbyModificationSetBucketIdOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbyModificationSetBucketIdOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString BucketId;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyCopyLobbyDetailsHandleOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyCopyLobbyDetailsHandleOptions
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyGetInviteIdByIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSLobbyGetInviteIdByIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t Index;  // 0x28(0x4)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerEndSession
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatServerEndSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerEndSessionOptions Options;  // 0x8(0x1)
	uint8_t  ReturnValue;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// ScriptStruct EOSCore.EOSLobbyGetInviteCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyGetInviteCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbyJoinLobbyOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyJoinLobbyOptions
{
	struct FEOSHLobbyDetails LobbyDetailsHandle;  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bPresenceEnabled : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	struct FEOSLobbyLocalRTCOptions LocalRTCOptions;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct EOSCore.EOSQueryJoinRoomTokenOptions
// Size: 0x58(Inherited: 0x0) 
struct FEOSQueryJoinRoomTokenOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)
	struct TArray<struct FEOSProductUserId> TargetUserIds;  // 0x38(0x10)
	struct TArray<struct FString> TargetUserIpAddresses;  // 0x48(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionSearchSetMaxResultsOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSSessionSearchSetMaxResultsOptions
{
	int32_t MaxSearchResults;  // 0x0(0x4)

}; 
// Function EOSCore.CoreMods.EOSModsInstallMod
// Size: 0xA0(Inherited: 0x0) 
struct FEOSModsInstallMod
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSModsInstallModOptions Options;  // 0x8(0x88)
	struct FDelegate Callback;  // 0x90(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyQueryInvitesOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyQueryInvitesOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSLobbyRejectInviteOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbyRejectInviteOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString InviteId;  // 0x8(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x18(0x21)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyAddNotifyRTCRoomConnectionChangedOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyAddNotifyRTCRoomConnectionChangedOptions
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyIsRTCRoomConnectedOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyIsRTCRoomConnectedOptions
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.EOSCoreTitleStorageReadFile.EOSTitleStorageReadFileAsync
// Size: 0x68(Inherited: 0x0) 
struct FEOSTitleStorageReadFileAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageReadFileOptions Options;  // 0x8(0x58)
	struct UEOSCoreTitleStorageReadFile* ReturnValue;  // 0x60(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbyGetRTCRoomNameOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyGetRTCRoomNameOptions
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LocalUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyAddNotifyLobbyInviteReceivedOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyInviteReceivedOptions
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyAddNotifyLobbyMemberUpdateReceivedOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyMemberUpdateReceivedOptions
{
	char pad_0[16];  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsDumpSessionStateOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsDumpSessionStateOptions
{
	struct FString SessionName;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyAddNotifyLobbyUpdateReceivedOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyUpdateReceivedOptions
{
	char pad_0[16];  // 0x0(0x10)

}; 
// Function EOSCore.EOSCoreSessionsStartSession.EOSSessionsStartSessionAsync
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsStartSessionAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsStartSessionOptions Options;  // 0x8(0x10)
	struct UEOSCoreSessionsStartSession* ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSLobbyUpdateLobbyModificationOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyUpdateLobbyModificationOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString LobbyID;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSLobbyCreateLobbyOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSLobbyCreateLobbyOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[3];  // 0x21(0x3)
	int32_t MaxLobbyMembers;  // 0x24(0x4)
	uint8_t  PermissionLevel;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bPresenceEnabled : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bAllowInvites : 1;  // 0x2A(0x1)
	char pad_43[5];  // 0x2B(0x5)
	struct FString BucketId;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bDisableHostMigration : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool bEnableRTCRoom : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	struct FEOSLobbyLocalRTCOptions LocalRTCOptions;  // 0x44(0x8)
	char pad_76[4];  // 0x4C(0x4)
	struct FString LobbyID;  // 0x50(0x10)

}; 
// Function EOSCore.CoreChat.SendChatMessage
// Size: 0x68(Inherited: 0x0) 
struct FSendChatMessage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	struct FEOSProductUserId Target;  // 0x29(0x21)
	char pad_74[6];  // 0x4A(0x6)
	struct FString Message;  // 0x50(0x10)
	uint8_t  Reliability;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// ScriptStruct EOSCore.EOSLobbyDetailsInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbyDetailsInfo
{
	struct FString LobbyID;  // 0x0(0x10)
	struct FEOSProductUserId LobbyOwnerUserId;  // 0x10(0x21)
	uint8_t  PermissionLevel;  // 0x31(0x1)
	char pad_50[2];  // 0x32(0x2)
	int32_t AvailableSlots;  // 0x34(0x4)
	int32_t MaxMembers;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bAllowInvites : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FString BucketId;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bAllowHostMigration : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool bRTCRoomEnabled : 1;  // 0x51(0x1)
	char pad_82[6];  // 0x52(0x6)

}; 
// ScriptStruct EOSCore.EOSSendAudioOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSSendAudioOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)
	struct FEOSRTCAudioAudioBuffer Buffer;  // 0x38(0x10)

}; 
// Function EOSCore.CoreUI.EOSUIRemoveNotifyDisplaySettingsUpdated
// Size: 0x10(Inherited: 0x0) 
struct FEOSUIRemoveNotifyDisplaySettingsUpdated
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSMetricsEndPlayerSessionOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSMetricsEndPlayerSessionOptions
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  AccountIdType;  // 0x4(0x1)
	struct FEOSEpicAccountId Epic;  // 0x5(0x21)
	char pad_38[2];  // 0x26(0x2)
	struct FString External;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSModsUpdateModOptions
// Size: 0x80(Inherited: 0x0) 
struct FEOSModsUpdateModOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FEOSModIdentifier Mod;  // 0x28(0x58)

}; 
// ScriptStruct EOSCore.EOSModsEnumerateModsOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSModsEnumerateModsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	uint8_t  Type;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)

}; 
// ScriptStruct EOSCore.EOSModsUninstallModOptions
// Size: 0x80(Inherited: 0x0) 
struct FEOSModsUninstallModOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FEOSModIdentifier Mod;  // 0x28(0x58)

}; 
// Function EOSCore.CoreP2P.EOSP2PSetPortRange
// Size: 0x18(Inherited: 0x0) 
struct FEOSP2PSetPortRange
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PSetPortRangeOptions Options;  // 0x8(0xC)
	uint8_t  ReturnValue;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// ScriptStruct EOSCore.EOSModsInstallModOptions
// Size: 0x88(Inherited: 0x0) 
struct FEOSModsInstallModOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FEOSModIdentifier Mod;  // 0x28(0x58)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bRemoveAfterExit : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomTransaction_GetEntitlementsCount
// Size: 0x40(Inherited: 0x0) 
struct FEOSEcomTransaction_GetEntitlementsCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomHTransaction Handle;  // 0x8(0x8)
	struct FEOSEcomTransactionGetEntitlementsCountOptions Options;  // 0x10(0x28)
	int32_t ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PAddNotifyIncomingPacketQueueFullOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSP2PAddNotifyIncomingPacketQueueFullOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PPacketQueueInfo
// Size: 0x60(Inherited: 0x0) 
struct FEOSP2PPacketQueueInfo
{
	struct FString IncomingPacketQueueMaxSizeBytes;  // 0x0(0x10)
	struct FString IncomingPacketQueueCurrentSizeBytes;  // 0x10(0x10)
	struct FString IncomingPacketQueueCurrentPacketCount;  // 0x20(0x10)
	struct FString OutgoingPacketQueueMaxSizeBytes;  // 0x30(0x10)
	struct FString OutgoingPacketQueueCurrentSizeBytes;  // 0x40(0x10)
	struct FString OutgoingPacketQueueCurrentPacketCount;  // 0x50(0x10)

}; 
// ScriptStruct EOSCore.EOSP2PGetPacketQueueInfoOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSP2PGetPacketQueueInfoOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PSetPacketQueueSizeOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSP2PSetPacketQueueSizeOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString IncomingPacketQueueMaxSizeBytes;  // 0x8(0x10)
	struct FString OutgoingPacketQueueMaxSizeBytes;  // 0x18(0x10)

}; 
// ScriptStruct EOSCore.EOSP2PGetPortRangeOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSP2PGetPortRangeOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthLogout
// Size: 0x40(Inherited: 0x0) 
struct FEOSAuthLogout
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthLogoutOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageQueryFile
// Size: 0x50(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFile
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageQueryFileOptions QueryFileOptions;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.GetLobbyAttributeString
// Size: 0x38(Inherited: 0x0) 
struct FGetLobbyAttributeString
{
	struct FEOSLobbyAttributeData Data;  // 0x0(0x28)
	struct FString ReturnValue;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSP2PSetPortRangeOptions
// Size: 0xC(Inherited: 0x0) 
struct FEOSP2PSetPortRangeOptions
{
	char pad_0[4];  // 0x0(0x4)
	int32_t Port;  // 0x4(0x4)
	int32_t MaxAdditionalPortsToTry;  // 0x8(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PGetRelayControlOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSP2PGetRelayControlOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsCopyAchievementDefinitionV2ByAchievementId
// Size: 0xC0(Inherited: 0x0) 
struct FEOSAchievementsCopyAchievementDefinitionV2ByAchievementId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsCopyAchievementDefinitionV2ByAchievementIdOptions Options;  // 0x8(0x10)
	struct FEOSAchievementsDefinitionV2 OutDefinition;  // 0x18(0xA0)
	uint8_t  ReturnValue;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)

}; 
// ScriptStruct EOSCore.EOSP2PSetRelayControlOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSP2PSetRelayControlOptions
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  RelayControl;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function EOSCore.CoreLobby.EOSLobbyCopyLobbyDetailsHandle
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyCopyLobbyDetailsHandle
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyCopyLobbyDetailsHandleOptions Options;  // 0x8(0x38)
	struct FEOSHLobbyDetails OutLobbyDetailsHandle;  // 0x40(0x8)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// ScriptStruct EOSCore.EOSP2PGetNATTypeOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSP2PGetNATTypeOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PCloseConnectionsOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSP2PCloseConnectionsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FEOSP2PSocketId SocketId;  // 0x28(0x18)

}; 
// ScriptStruct EOSCore.EOSStatsIngestData
// Size: 0x20(Inherited: 0x0) 
struct FEOSStatsIngestData
{
	char pad_0[8];  // 0x0(0x8)
	struct FString StatName;  // 0x8(0x10)
	int32_t IngestAmount;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PCloseConnectionOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSP2PCloseConnectionOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	struct FEOSProductUserId RemoteUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)
	struct FEOSP2PSocketId SocketId;  // 0x48(0x18)

}; 
// Function EOSCore.EOSCoreLibrary.GetSessionAttributeString
// Size: 0x30(Inherited: 0x0) 
struct FGetSessionAttributeString
{
	struct FEOSSessionsAttributeData Data;  // 0x0(0x20)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchSetParameterInt64
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbySearchSetParameterInt64
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  ComparisonOp;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// ScriptStruct EOSCore.EOSP2PAddNotifyPeerConnectionClosedOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSP2PAddNotifyPeerConnectionClosedOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FEOSP2PSocketId SocketId;  // 0x28(0x18)

}; 
// Function EOSCore.CoreEcom.EOSEcomQueryOwnership
// Size: 0x60(Inherited: 0x0) 
struct FEOSEcomQueryOwnership
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryOwnershipOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// ScriptStruct EOSCore.EOSP2PAddNotifyPeerConnectionRequestOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSP2PAddNotifyPeerConnectionRequestOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FEOSP2PSocketId SocketId;  // 0x28(0x18)

}; 
// ScriptStruct EOSCore.EOSTitleStorageQueryFileOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageQueryFileOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Filename;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSP2PReceivePacketOptions
// Size: 0x30(Inherited: 0x0) 
struct FEOSP2PReceivePacketOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t MaxDataSizeBytes;  // 0x28(0x4)
	int32_t RequestedChannel;  // 0x2C(0x4)

}; 
// ScriptStruct EOSCore.EOSActiveSessionCopyInfoOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSActiveSessionCopyInfoOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSP2PGetNextReceivedPacketSizeOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSP2PGetNextReceivedPacketSizeOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t RequestedChannel;  // 0x28(0x4)

}; 
// ScriptStruct EOSCore.EOSP2PSendPacketOptions
// Size: 0x80(Inherited: 0x0) 
struct FEOSP2PSendPacketOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	struct FEOSProductUserId RemoteUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)
	struct FEOSP2PSocketId SocketId;  // 0x48(0x18)
	int32_t Channel;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct TArray<char> Data;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bAllowDelayedDelivery : 1;  // 0x78(0x1)
	uint8_t  Reliability;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)

}; 
// Function EOSCore.CoreConnect.EOSConnectCopyProductUserExternalAccountByAccountId
// Size: 0xA8(Inherited: 0x0) 
struct FEOSConnectCopyProductUserExternalAccountByAccountId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCopyProductUserExternalAccountByAccountIdOptions Options;  // 0x8(0x38)
	struct FEOSConnectExternalAccountInfo OutExternalAccountInfo;  // 0x40(0x60)
	uint8_t  ReturnValue;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestGetFilename
// Size: 0x30(Inherited: 0x0) 
struct FEOSPlayerDataStorageFileTransferRequestGetFilename
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPlayerDataStorageFileTransferRequest Handle;  // 0x8(0x8)
	int32_t FilenameStringBufferSizeBytes;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString OutStringBuffer;  // 0x18(0x10)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageDeleteCacheOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSPlayerDataStorageDeleteCacheOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.CoreConnect.EOSConnectCopyProductUserExternalAccountByAccountType
// Size: 0x98(Inherited: 0x0) 
struct FEOSConnectCopyProductUserExternalAccountByAccountType
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCopyProductUserExternalAccountByAccountTypeOptions Options;  // 0x8(0x28)
	struct FEOSConnectExternalAccountInfo OutExternalAccountInfo;  // 0x30(0x60)
	uint8_t  ReturnValue;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageWriteFileOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSPlayerDataStorageWriteFileOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString LocalFile;  // 0x28(0x10)
	struct FString RemoteFile;  // 0x38(0x10)
	int32_t ChunkLengthBytes;  // 0x48(0x4)
	char pad_76[20];  // 0x4C(0x14)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageWriteFileDataCallbackInfo
// Size: 0x48(Inherited: 0x0) 
struct FEOSPlayerDataStorageWriteFileDataCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString Filename;  // 0x30(0x10)
	int32_t DataBufferLengthBytes;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageReadFileOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSPlayerDataStorageReadFileOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString LocalFile;  // 0x28(0x10)
	struct FString RemoteFile;  // 0x38(0x10)
	int32_t ReadChunkLengthBytes;  // 0x48(0x4)
	char pad_76[20];  // 0x4C(0x14)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageDeleteFileOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageDeleteFileOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Filename;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageDuplicateFileOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSPlayerDataStorageDuplicateFileOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString SourceFilename;  // 0x28(0x10)
	struct FString DestinationFilename;  // 0x38(0x10)

}; 
// Function EOSCore.CoreChat.ListenForChatMessages
// Size: 0x40(Inherited: 0x0) 
struct FListenForChatMessages
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate Callback;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageCopyFileMetadataAtIndexOptions
// Size: 0x2C(Inherited: 0x0) 
struct FEOSPlayerDataStorageCopyFileMetadataAtIndexOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	int32_t Index;  // 0x28(0x4)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageGetFileMetadataCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSPlayerDataStorageGetFileMetadataCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyTransactionByIndex
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomCopyTransactionByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyTransactionByIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSEcomHTransaction OutTransaction;  // 0x38(0x8)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageQueryFileListOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFileListOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.CoreRTC.EOSRTCAddNotifyParticipantStatusChanged
// Size: 0x58(Inherited: 0x0) 
struct FEOSRTCAddNotifyParticipantStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FAddNotifyParticipantStatusChangedOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct EOSCore.EOSPlayerDataStorageQueryFileOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFileOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Filename;  // 0x28(0x10)

}; 
// Function EOSCore.CoreEcom.EOSEcomTransaction_CopyEntitlementByIndex
// Size: 0x70(Inherited: 0x0) 
struct FEOSEcomTransaction_CopyEntitlementByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomHTransaction Handle;  // 0x8(0x8)
	struct FEOSEcomTransactionCopyEntitlementByIndexOptions Options;  // 0x10(0x8)
	struct FEOSEcomEntitlement OutEntitlement;  // 0x18(0x50)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct EOSCore.EOSPresenceModificationDataRecordId
// Size: 0x18(Inherited: 0x0) 
struct FEOSPresenceModificationDataRecordId
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Key;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSPresenceModificationSetDataOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSPresenceModificationSetDataOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct TArray<struct FEOSPresenceDataRecord> Records;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSPresenceModificationSetRawRichTextOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSPresenceModificationSetRawRichTextOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FString RichText;  // 0x8(0x10)

}; 
// ScriptStruct EOSCore.EOSPresenceSetPresenceOptions
// Size: 0x30(Inherited: 0x0) 
struct FEOSPresenceSetPresenceOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FEOSHPresenceModification PresenceModificationHandle;  // 0x28(0x8)

}; 
// ScriptStruct EOSCore.EOSPresenceCreatePresenceModificationOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSPresenceCreatePresenceModificationOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageCopyFileMetadataByFilename
// Size: 0x70(Inherited: 0x0) 
struct FEOSTitleStorageCopyFileMetadataByFilename
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageCopyFileMetadataByFilenameOptions Options;  // 0x8(0x38)
	struct FEOSTitleStorageFileMetadata OutMetadata;  // 0x40(0x28)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct EOSCore.EOSPresenceCopyPresenceOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSPresenceCopyPresenceOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.CoreRTCAdmin.EOSRTCAdminKick
// Size: 0x50(Inherited: 0x0) 
struct FEOSRTCAdminKick
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSKickOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCore.EOSPresenceHasPresenceOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSPresenceHasPresenceOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.EOSCoreLibrary.BreakUIEventIdStruct
// Size: 0x18(Inherited: 0x0) 
struct FBreakUIEventIdStruct
{
	struct FEOSUIEventId EventId;  // 0x0(0x8)
	struct FString outEventId;  // 0x8(0x10)

}; 
// Function EOSCore.CoreFriends.EOSFriendsQueryFriends
// Size: 0x40(Inherited: 0x0) 
struct FEOSFriendsQueryFriends
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsQueryFriendsOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// Function EOSCore.CoreConnect.EOSConnectUnlinkAccount
// Size: 0x40(Inherited: 0x0) 
struct FEOSConnectUnlinkAccount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectUnlinkAccountOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyCopyLobbyDetailsHandleByInviteId
// Size: 0x30(Inherited: 0x0) 
struct FEOSLobbyCopyLobbyDetailsHandleByInviteId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyCopyLobbyDetailsHandleByInviteIdOptions Options;  // 0x8(0x18)
	struct FEOSHLobbyDetails OutLobbyDetailsHandle;  // 0x20(0x8)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// ScriptStruct EOSCore.EOSPresenceQueryPresenceOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSPresenceQueryPresenceOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetOfferItemCount
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomGetOfferItemCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetOfferItemCountOptions Options;  // 0x8(0x38)
	int32_t ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// ScriptStruct EOSCore.EOSAudioOutputDeviceInfo
// Size: 0x28(Inherited: 0x0) 
struct FEOSAudioOutputDeviceInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDefaultDevice : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString DeviceID;  // 0x8(0x10)
	struct FString DeviceName;  // 0x18(0x10)

}; 
// Function EOSCore.EOSCoreSessionsQueryInvites.EOSSessionsQueryInvitesAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionsQueryInvitesAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsQueryInvitesOptions Options;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct UEOSCoreSessionsQueryInvites* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSHPresence
// Size: 0x8(Inherited: 0x0) 
struct FEOSHPresence
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSCopyUserTokenByUserIdOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSCopyUserTokenByUserIdOptions
{
	struct FEOSProductUserId TargetUserId;  // 0x0(0x21)
	char pad_33[3];  // 0x21(0x3)
	int32_t QueryId;  // 0x24(0x4)

}; 
// ScriptStruct EOSCore.EOSProgressionSnapshotDeleteSnapshotOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSProgressionSnapshotDeleteSnapshotOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// ScriptStruct EOSCore.EOSProgressionSnapshotEndSnapshotOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSProgressionSnapshotEndSnapshotOptions
{
	int32_t SnapshotId;  // 0x0(0x4)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsRelease
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyDetailsRelease
{
	struct FEOSHLobbyDetails LobbyHandle;  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSProgressionSnapshotSubmitSnapshotOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSProgressionSnapshotSubmitSnapshotOptions
{
	int32_t SnapshotId;  // 0x0(0x4)

}; 
// Function EOSCore.EOSCoreSessionsUnregisterPlayers.EOSSessionsUnregisterPlayersAsync
// Size: 0x30(Inherited: 0x0) 
struct FEOSSessionsUnregisterPlayersAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsUnregisterPlayersOptions Options;  // 0x8(0x20)
	struct UEOSCoreSessionsUnregisterPlayers* ReturnValue;  // 0x28(0x8)

}; 
// ScriptStruct EOSCore.EOSProgressionSnapshotAddProgressionOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSProgressionSnapshotAddProgressionOptions
{
	int32_t SnapshotId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Key;  // 0x8(0x10)
	struct FString Value;  // 0x18(0x10)

}; 
// ScriptStruct EOSCore.EOSGetAudioOutputDeviceByIndexOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSGetAudioOutputDeviceByIndexOptions
{
	int32_t DeviceInfoIndex;  // 0x0(0x4)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientUnregisterPeer
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatClientUnregisterPeer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientUnregisterPeerOptions Options;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSProgressionSnapshotBeginSnapshotOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSProgressionSnapshotBeginSnapshotOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// ScriptStruct EOSCore.EOSReportsSendPlayerBehaviorReportOptions
// Size: 0x68(Inherited: 0x0) 
struct FEOSReportsSendPlayerBehaviorReportOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId ReporterUserId;  // 0x4(0x21)
	struct FEOSProductUserId ReportedUserId;  // 0x25(0x21)
	uint8_t  ReportCategory;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)
	struct FString Message;  // 0x48(0x10)
	struct FString Context;  // 0x58(0x10)

}; 
// ScriptStruct EOSCore.EOSUpdateReceivingOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSUpdateReceivingOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x38(0x21)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool bAudioEnabled : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)

}; 
// ScriptStruct EOSCore.EOSSetParticipantHardMuteOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSSetParticipantHardMuteOptions
{
	struct FString RoomName;  // 0x0(0x10)
	struct FEOSProductUserId TargetUserId;  // 0x10(0x21)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bMute : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionsCopySessionHandleForPresence
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionsCopySessionHandleForPresence
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsCopySessionHandleForPresenceOptions Options;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FEOSHSessionDetails OutSessionHandle;  // 0x30(0x8)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSKickOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSKickOptions
{
	struct FString RoomName;  // 0x0(0x10)
	struct FEOSProductUserId TargetUserId;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreCustomInvites.EOSCustomInvitesFinalizeInvite
// Size: 0x70(Inherited: 0x0) 
struct FEOSCustomInvitesFinalizeInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSCustomInvitesFinalizeInviteOptions Options;  // 0x8(0x60)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function EOSCore.CoreRTC.EOSRTCAddNotifyDisconnected
// Size: 0x58(Inherited: 0x0) 
struct FEOSRTCAddNotifyDisconnected
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FAddNotifyDisconnectedOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x50(0x8)

}; 
// ScriptStruct EOSCore.EOSCopyUserTokenByIndexOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSCopyUserTokenByIndexOptions
{
	int32_t UserTokenIndex;  // 0x0(0x4)
	int32_t QueryId;  // 0x4(0x4)

}; 
// Function EOSCore.EOSCoreLibrary.IsProductUserIdIdenticalWith
// Size: 0x43(Inherited: 0x0) 
struct FIsProductUserIdIdenticalWith
{
	struct FEOSProductUserId A;  // 0x0(0x21)
	struct FEOSProductUserId B;  // 0x21(0x21)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool ReturnValue : 1;  // 0x42(0x1)

}; 
// ScriptStruct EOSCore.EOSAddNotifyAudioBeforeRenderOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSAddNotifyAudioBeforeRenderOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bUnmixedAudio : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionsUnregisterPlayersOptions
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsUnregisterPlayersOptions
{
	struct FString SessionName;  // 0x0(0x10)
	struct TArray<struct FEOSProductUserId> PlayersToUnregister;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSAddNotifyAudioBeforeSendOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAddNotifyAudioBeforeSendOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)

}; 
// Function EOSCore.CoreConnect.EOSConnectGetLoginStatus
// Size: 0x30(Inherited: 0x0) 
struct FEOSConnectGetLoginStatus
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	uint8_t  ReturnValue;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// ScriptStruct EOSCore.EOSAddNotifyAudioOutputStateOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSAddNotifyAudioOutputStateOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)

}; 
// Function EOSCore.CoreP2P.EOSP2PGetRelayControl
// Size: 0x10(Inherited: 0x0) 
struct FEOSP2PGetRelayControl
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PGetRelayControlOptions Options;  // 0x8(0x4)
	uint8_t  OutRelayControl;  // 0xC(0x1)
	uint8_t  ReturnValue;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)

}; 
// Function EOSCore.EOSCoreLibrary.GetLobbyAttributeInt64
// Size: 0x38(Inherited: 0x0) 
struct FGetLobbyAttributeInt64
{
	struct FEOSLobbyAttributeData Data;  // 0x0(0x28)
	struct FString ReturnValue;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSSetAudioOutputSettingsOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSSetAudioOutputSettingsOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString DeviceID;  // 0x28(0x10)
	float Volume;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionsUnregisterPlayers
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionsUnregisterPlayers
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsUnregisterPlayersOptions Options;  // 0x8(0x20)
	struct FDelegate Callback;  // 0x28(0x10)

}; 
// ScriptStruct EOSCore.EOSSetAudioInputSettingsOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSSetAudioInputSettingsOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString DeviceID;  // 0x28(0x10)
	float Volume;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bPlatformAEC : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)

}; 
// ScriptStruct EOSCore.EOSGetAudioInputDevicesCountOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSGetAudioInputDevicesCountOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyMessageToServer
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatClientRemoveNotifyMessageToServer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionsGetInviteCountOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSSessionsGetInviteCountOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// ScriptStruct EOSCore.EOSAddNotifyAudioDevicesChangedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSAddNotifyAudioDevicesChangedOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSUnregisterPlatformAudioUserOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSUnregisterPlatformAudioUserOptions
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSRegisterPlatformAudioUserOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSRegisterPlatformAudioUserOptions
{
	struct FString UserId;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.AddNotifyParticipantStatusChangedOptions
// Size: 0x38(Inherited: 0x0) 
struct FAddNotifyParticipantStatusChangedOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)

}; 
// Function EOSCore.EOSCoreSessionsDestroySession.EOSSessionsDestroySessionAsync
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsDestroySessionAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsDestroySessionOptions Options;  // 0x8(0x10)
	struct UEOSCoreSessionsDestroySession* ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerTakeDamage
// Size: 0xC0(Inherited: 0x0) 
struct FEOSAntiCheatServerLogPlayerTakeDamage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerTakeDamageOptions Options;  // 0x8(0xB0)
	uint8_t  ReturnValue;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)

}; 
// ScriptStruct EOSCore.BlockParticipantOptions
// Size: 0x60(Inherited: 0x0) 
struct FBlockParticipantOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x38(0x21)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool bBlocked : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)

}; 
// ScriptStruct EOSCore.JoinRoomOptions
// Size: 0x88(Inherited: 0x0) 
struct FJoinRoomOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[7];  // 0x21(0x7)
	struct FString RoomName;  // 0x28(0x10)
	struct FString ClientBaseUrl;  // 0x38(0x10)
	struct FString ParticipantToken;  // 0x48(0x10)
	struct FEOSProductUserId ParticipantId;  // 0x58(0x21)
	char pad_121[3];  // 0x79(0x3)
	int32_t Flags;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bManualAudioInputEnabled : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool bManualAudioOutputEnabled : 1;  // 0x81(0x1)
	char pad_130[6];  // 0x82(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyMemberStatusReceived
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyMemberStatusReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct EOSCore.EOSSanctionsQueryActivePlayerSanctionsOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSSanctionsQueryActivePlayerSanctionsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	struct FEOSProductUserId LocalUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.EOSCoreLibrary.MakeParamInt64
// Size: 0x20(Inherited: 0x0) 
struct FMakeParamInt64
{
	int64_t Value;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogEventParamPair ReturnValue;  // 0x8(0x18)

}; 
// Function EOSCore.CoreConnect.EOSConnectCreateUser
// Size: 0x20(Inherited: 0x0) 
struct FEOSConnectCreateUser
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCreateUserOptions Options;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSSanctionsPlayerSanction
// Size: 0x20(Inherited: 0x0) 
struct FEOSSanctionsPlayerSanction
{
	char pad_0[8];  // 0x0(0x8)
	struct FDateTime TimePlaced;  // 0x8(0x8)
	struct FString Action;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsCopySessionHandleForPresenceOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSSessionsCopySessionHandleForPresenceOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// ScriptStruct EOSCore.EOSSessionsAddNotifySessionInviteReceivedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionsAddNotifySessionInviteReceivedOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSSessionDetailsCopySessionAttributeByKeyOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionDetailsCopySessionAttributeByKeyOptions
{
	struct FString AttrKey;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionDetailsCopySessionAttributeByIndexOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSSessionDetailsCopySessionAttributeByIndexOptions
{
	int32_t AttrIndex;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSSessionDetailsCopyInfoOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionDetailsCopyInfoOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSSessionSearchCopySearchResultByIndexOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSSessionSearchCopySearchResultByIndexOptions
{
	int32_t SessionIndex;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSSessionSearchRemoveParameterOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionSearchRemoveParameterOptions
{
	struct FString Key;  // 0x0(0x10)
	uint8_t  ComparisonOp;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionSearchSetParameterOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionSearchSetParameterOptions
{
	struct FEOSSessionsAttributeData Parameter;  // 0x0(0x20)
	uint8_t  ComparisonOp;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionSearchSetTargetUserIdOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSSessionSearchSetTargetUserIdOptions
{
	struct FEOSProductUserId TargetUserId;  // 0x0(0x21)

}; 
// Function EOSCore.CoreConnect.EOSConnectGetProductUserExternalAccountCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSConnectGetProductUserExternalAccountCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectGetProductUserExternalAccountCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioOutputDevicesCount
// Size: 0x10(Inherited: 0x0) 
struct FEOSRTCAudioGetAudioOutputDevicesCount
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSGetAudioOutputDevicesCountOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function EOSCore.CoreEcom.EOSEcomQueryOwnershipToken
// Size: 0x68(Inherited: 0x0) 
struct FEOSEcomQueryOwnershipToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomQueryOwnershipTokenOptions Options;  // 0x8(0x50)
	struct FDelegate Callback;  // 0x58(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionSearchGetSearchResultCountOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionSearchGetSearchResultCountOptions
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function EOSCore.CoreSessions.EOSSessionsJoinSession
// Size: 0x58(Inherited: 0x0) 
struct FEOSSessionsJoinSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsJoinSessionOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionSearchFindOptions
// Size: 0x21(Inherited: 0x0) 
struct FEOSSessionSearchFindOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)

}; 
// ScriptStruct EOSCore.EOSSessionDetailsAttribute
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionDetailsAttribute
{
	struct FEOSSessionsAttributeData Data;  // 0x0(0x20)
	uint8_t  AdvertisementType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionModificationSetInvitesAllowedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionModificationSetInvitesAllowedOptions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInvitesAllowed : 1;  // 0x0(0x1)

}; 
// ScriptStruct EOSCore.EOSSessionModificationSetMaxPlayersOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSSessionModificationSetMaxPlayersOptions
{
	int32_t MaxPlayers;  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSSessionModificationSetJoinInProgressAllowedOptions
// Size: 0x1(Inherited: 0x0) 
struct FEOSSessionModificationSetJoinInProgressAllowedOptions
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllowJoinInProgress : 1;  // 0x0(0x1)

}; 
// Function EOSCore.CoreUI.EOSUIHideFriends
// Size: 0x40(Inherited: 0x0) 
struct FEOSUIHideFriends
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIHideFriendsOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// Function EOSCore.CoreSessions.EOSActiveSessionRelease
// Size: 0x10(Inherited: 0x0) 
struct FEOSActiveSessionRelease
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHActiveSession ActiveSessionHandle;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionModificationSetBucketIdOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionModificationSetBucketIdOptions
{
	struct FString BucketId;  // 0x0(0x10)

}; 
// Function EOSCore.EOSCoreSessionsUpdateSession.EOSSessionsUpdateSessionAsync
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionsUpdateSessionAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsUpdateSessionOptions Options;  // 0x8(0x8)
	struct UEOSCoreSessionsUpdateSession* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionsRegisterPlayersOptions
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsRegisterPlayersOptions
{
	struct FString SessionName;  // 0x0(0x10)
	struct TArray<struct FEOSProductUserId> PlayersToRegister;  // 0x10(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsEndSessionOptions
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsEndSessionOptions
{
	struct FString SessionName;  // 0x0(0x10)

}; 
// ScriptStruct EOSCore.EOSSessionsJoinSessionOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionsJoinSessionOptions
{
	struct FString SessionName;  // 0x0(0x10)
	struct FEOSHSessionDetails SessionHandle;  // 0x10(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x18(0x21)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool bPresenceEnabled : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// Function EOSCore.EOSCoreLobbyQueryInvites.EOSLobbyQueryInvitesAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyQueryInvitesAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyQueryInvitesOptions Options;  // 0x8(0x28)
	struct UEOSCoreLobbyQueryInvites* ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct EOSCore.EOSHSessionDetails
// Size: 0x8(Inherited: 0x0) 
struct FEOSHSessionDetails
{
	char pad_0[8];  // 0x0(0x8)

}; 
// Function EOSCore.CoreConnect.EOSConnectGetExternalAccountMapping
// Size: 0x68(Inherited: 0x0) 
struct FEOSConnectGetExternalAccountMapping
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectGetExternalAccountMappingsOptions Options;  // 0x8(0x38)
	struct FEOSProductUserId ReturnValue;  // 0x40(0x21)
	char pad_97[7];  // 0x61(0x7)

}; 
// ScriptStruct EOSCore.EOSSessionsUpdateSessionOptions
// Size: 0x8(Inherited: 0x0) 
struct FEOSSessionsUpdateSessionOptions
{
	struct FEOSHSessionModification SessionModificationHandle;  // 0x0(0x8)

}; 
// Function EOSCore.CoreP2P.EOSP2PRemoveNotifyPeerConnectionRequest
// Size: 0x10(Inherited: 0x0) 
struct FEOSP2PRemoveNotifyPeerConnectionRequest
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// ScriptStruct EOSCore.EOSHSessionModification
// Size: 0x8(Inherited: 0x0) 
struct FEOSHSessionModification
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSSessionsGetInviteIdByIndexOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionsGetInviteIdByIndexOptions
{
	struct FEOSProductUserId LocalUserId;  // 0x0(0x21)
	char pad_33[3];  // 0x21(0x3)
	int32_t Index;  // 0x24(0x4)

}; 
// ScriptStruct EOSCore.EOSSessionsCreateSessionModificationOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSSessionsCreateSessionModificationOptions
{
	struct FString SessionName;  // 0x0(0x10)
	struct FString BucketId;  // 0x10(0x10)
	int32_t MaxPlayers;  // 0x20(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x24(0x21)
	char pad_69_1 : 7;  // 0x45(0x1)
	bool bPresenceEnabled : 1;  // 0x45(0x1)
	char pad_70[2];  // 0x46(0x2)

}; 
// Function EOSCore.EOSCoreSessionsEndSession.EOSSessionsEndSessionAsync
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsEndSessionAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsEndSessionOptions Options;  // 0x8(0x10)
	struct UEOSCoreSessionsEndSession* ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CorePresence.EOSPresenceQueryPresence
// Size: 0x60(Inherited: 0x0) 
struct FEOSPresenceQueryPresence
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceQueryPresenceOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// ScriptStruct EOSCore.EOSHActiveSession
// Size: 0x8(Inherited: 0x0) 
struct FEOSHActiveSession
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSHSessions
// Size: 0x8(Inherited: 0x0) 
struct FEOSHSessions
{
	char pad_0[8];  // 0x0(0x8)

}; 
// ScriptStruct EOSCore.EOSStatsCopyStatByNameOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSStatsCopyStatByNameOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Name;  // 0x28(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyCreateLobby
// Size: 0x78(Inherited: 0x0) 
struct FEOSLobbyCreateLobby
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyCreateLobbyOptions Options;  // 0x8(0x60)
	struct FDelegate Callback;  // 0x68(0x10)

}; 
// ScriptStruct EOSCore.EOSStatsGetStatCountOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSStatsGetStatCountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.EOSCoreLibrary.GetBool
// Size: 0x40(Inherited: 0x0) 
struct FGetBool
{
	struct FEOSSessionSetting Settings;  // 0x0(0x28)
	struct FString Key;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct EOSCore.EOSStatsStat
// Size: 0x40(Inherited: 0x0) 
struct FEOSStatsStat
{
	char pad_0[8];  // 0x0(0x8)
	struct FString Name;  // 0x8(0x10)
	struct FString StartTime;  // 0x18(0x10)
	struct FString EndTime;  // 0x28(0x10)
	int32_t Value;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct EOSCore.EOSStatsIngestStatOptions
// Size: 0x60(Inherited: 0x0) 
struct FEOSStatsIngestStatOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct TArray<struct FEOSStatsIngestData> Stats;  // 0x28(0x10)
	char pad_56[4];  // 0x38(0x4)
	struct FEOSProductUserId TargetUserId;  // 0x3C(0x21)
	char pad_93[3];  // 0x5D(0x3)

}; 
// ScriptStruct EOSCore.EOSTitleStorageDeleteCacheOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSTitleStorageDeleteCacheOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyOfferById
// Size: 0x100(Inherited: 0x0) 
struct FEOSEcomCopyOfferById
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyOfferByIdOptions Options;  // 0x8(0x38)
	struct FEOSEcomCatalogOffer OutOffer;  // 0x40(0xB8)
	uint8_t  ReturnValue;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)

}; 
// ScriptStruct EOSCore.EOSTitleStorageReadFileOptions
// Size: 0x58(Inherited: 0x0) 
struct FEOSTitleStorageReadFileOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Filename;  // 0x28(0x10)
	struct FString SaveFileName;  // 0x38(0x10)
	char pad_72[16];  // 0x48(0x10)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioRegisterPlatformAudioUser
// Size: 0x20(Inherited: 0x0) 
struct FEOSRTCAudioRegisterPlatformAudioUser
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSRegisterPlatformAudioUserOptions Options;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// ScriptStruct EOSCore.EOSTitleStorageReadFileDataCallbackInfo
// Size: 0x58(Inherited: 0x0) 
struct FEOSTitleStorageReadFileDataCallbackInfo
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSProductUserId LocalUserId;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FString Filename;  // 0x30(0x10)
	int32_t TotalFileSizeBytes;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bIsLastChunk : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	int32_t DataChunkLengthBytes;  // 0x48(0x4)
	char pad_76[12];  // 0x4C(0xC)

}; 
// ScriptStruct EOSCore.EOSTitleStorageCopyFileMetadataByFilenameOptions
// Size: 0x38(Inherited: 0x0) 
struct FEOSTitleStorageCopyFileMetadataByFilenameOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSProductUserId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Filename;  // 0x28(0x10)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientUnprotectMessage
// Size: 0x38(Inherited: 0x0) 
struct FEOSAntiCheatClientUnprotectMessage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientUnprotectMessageOptions Options;  // 0x8(0x18)
	struct TArray<char> OutBuffer;  // 0x20(0x10)
	uint8_t  ReturnValue;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardDefinitions.EOSLeaderboardsQueryLeaderboardDefinitionsAsync
// Size: 0x60(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardDefinitionsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsQueryLeaderboardDefinitionsOptions Options;  // 0x8(0x50)
	struct UEOSCoreLeaderboardsQueryLeaderboardDefinitions* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct EOSCore.EOSPageQuery
// Size: 0x8(Inherited: 0x0) 
struct FEOSPageQuery
{
	int32_t StartIndex;  // 0x0(0x4)
	int32_t MaxCount;  // 0x4(0x4)

}; 
// ScriptStruct EOSCore.EOSUIAcknowledgeEventIdOptions
// Size: 0x18(Inherited: 0x0) 
struct FEOSUIAcknowledgeEventIdOptions
{
	char pad_0[8];  // 0x0(0x8)
	struct FEOSUIEventId UiEventId;  // 0x8(0x8)
	uint8_t  Result;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct EOSCore.EOSUIGetToggleFriendsKeyOptions
// Size: 0x4(Inherited: 0x0) 
struct FEOSUIGetToggleFriendsKeyOptions
{
	char pad_0[4];  // 0x0(0x4)

}; 
// ScriptStruct EOSCore.EOSUIGetFriendsVisibleOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSUIGetFriendsVisibleOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSUIHideFriendsOptions
// Size: 0x28(Inherited: 0x0) 
struct FEOSUIHideFriendsOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)

}; 
// ScriptStruct EOSCore.EOSUserInfoCopyExternalUserInfoByAccountTypeOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSUserInfoCopyExternalUserInfoByAccountTypeOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	uint8_t  AccountType;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)

}; 
// ScriptStruct EOSCore.EOSUserInfoExternalUserInfo
// Size: 0x28(Inherited: 0x0) 
struct FEOSUserInfoExternalUserInfo
{
	char pad_0[4];  // 0x0(0x4)
	uint8_t  AccountType;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString AccountId;  // 0x8(0x10)
	struct FString DisplayName;  // 0x18(0x10)

}; 
// ScriptStruct EOSCore.EOSUserInfoCopyUserInfoOptions
// Size: 0x48(Inherited: 0x0) 
struct FEOSUserInfoCopyUserInfoOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	struct FEOSEpicAccountId TargetUserId;  // 0x25(0x21)
	char pad_70[2];  // 0x46(0x2)

}; 
// ScriptStruct EOSCore.EOSUserInfo
// Size: 0x68(Inherited: 0x0) 
struct FEOSUserInfo
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId UserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString Country;  // 0x28(0x10)
	struct FString DisplayName;  // 0x38(0x10)
	struct FString PreferredLanguage;  // 0x48(0x10)
	struct FString Nickname;  // 0x58(0x10)

}; 
// ScriptStruct EOSCore.EOSUserInfoQueryUserInfoByExternalAccountOptions
// Size: 0x40(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByExternalAccountOptions
{
	char pad_0[4];  // 0x0(0x4)
	struct FEOSEpicAccountId LocalUserId;  // 0x4(0x21)
	char pad_37[3];  // 0x25(0x3)
	struct FString ExternalAccountId;  // 0x28(0x10)
	uint8_t  AccountType;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsCopyAchievementDefinitionV2ByIndex
// Size: 0xB8(Inherited: 0x0) 
struct FEOSAchievementsCopyAchievementDefinitionV2ByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsCopyAchievementDefinitionV2ByIndexOptions Options;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FEOSAchievementsDefinitionV2 OutDefinition;  // 0x10(0xA0)
	uint8_t  ReturnValue;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)

}; 
// Function EOSCore.EOSCoreLibrary.GetLobbyAttributeDouble
// Size: 0x38(Inherited: 0x0) 
struct FGetLobbyAttributeDouble
{
	struct FEOSLobbyAttributeData Data;  // 0x0(0x28)
	struct FString ReturnValue;  // 0x28(0x10)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsCopyPlayerAchievementByIndex
// Size: 0xE8(Inherited: 0x0) 
struct FEOSAchievementsCopyPlayerAchievementByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsCopyPlayerAchievementByIndexOptions Options;  // 0x8(0x50)
	struct FEOSAchievementsPlayerAchievement OutAchievement;  // 0x58(0x88)
	uint8_t  ReturnValue;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)

}; 
// Function EOSCore.CoreAchievements.EOSAchievementsQueryDefinitions
// Size: 0x40(Inherited: 0x0) 
struct FEOSAchievementsQueryDefinitions
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsQueryDefinitionsOptions Options;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate Callback;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function EOSCore.EOSCoreAchievementsUnlockAchievements.EOSAchievementsUnlockAchievements
// Size: 0x48(Inherited: 0x0) 
struct FEOSAchievementsUnlockAchievements
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsUnlockAchievementsOptions Options;  // 0x8(0x38)
	struct UEOSCoreAchievementsUnlockAchievements* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.EOSCoreAchievementsQueryDefinitions.EOSAchievementsQueryDefinitionsAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSAchievementsQueryDefinitionsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsQueryDefinitionsOptions Options;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct UEOSCoreAchievementsQueryDefinitions* ReturnValue;  // 0x30(0x8)

}; 
// Function EOSCore.EOSCoreAchievementsQueryPlayerAchievements.EOSAchievementsQueryPlayerAchievementsAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSAchievementsQueryPlayerAchievementsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAchievementsQueryPlayerAchievementsOptions Options;  // 0x8(0x48)
	struct UEOSCoreAchievementsQueryPlayerAchievements* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDestroyLobby
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyDestroyLobby
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyDestroyLobbyOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddExternalIntegrityCatalog
// Size: 0x20(Inherited: 0x0) 
struct FEOSAntiCheatClientAddExternalIntegrityCatalog
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientAddExternalIntegrityCatalogOptions Options;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionDetailsRelease
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionDetailsRelease
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionDetails SessionHandle;  // 0x8(0x8)

}; 
// Function EOSCore.EOSCoreConnectCreateUser.EOSConnectCreateUserAsync
// Size: 0x18(Inherited: 0x0) 
struct FEOSConnectCreateUserAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCreateUserOptions Options;  // 0x8(0x8)
	struct UEOSCoreConnectCreateUser* ReturnValue;  // 0x10(0x8)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyMessageToServer
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyMessageToServer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientAddNotifyMessageToServerOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyPeerAuthStatusChanged
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatClientAddNotifyPeerAuthStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientAddNotifyPeerAuthStatusChangedOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientProtectMessage
// Size: 0x38(Inherited: 0x0) 
struct FEOSAntiCheatClientProtectMessage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatClientProtectMessageOptions Options;  // 0x8(0x18)
	struct TArray<char> OutBuffer;  // 0x20(0x10)
	uint8_t  ReturnValue;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyMessageToPeer
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatClientRemoveNotifyMessageToPeer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyPeerAuthStatusChanged
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatClientRemoveNotifyPeerAuthStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRegisterEvent
// Size: 0x40(Inherited: 0x0) 
struct FEOSAntiCheatServerRegisterEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonRegisterEventOptions Options;  // 0x8(0x30)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerAddNotifyClientActionRequired
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerAddNotifyClientActionRequired
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerAddNotifyClientActionRequiredOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerAddNotifyClientAuthStatusChanged
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerAddNotifyClientAuthStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerAddNotifyClientAuthStatusChangedOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerAddNotifyMessageToClient
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerAddNotifyMessageToClient
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerAddNotifyMessageToClientOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoCopyExternalUserInfoByIndex
// Size: 0x88(Inherited: 0x0) 
struct FEOSUserInfoCopyExternalUserInfoByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoCopyExternalUserInfoByIndexOptions Options;  // 0x8(0x4C)
	char pad_84[4];  // 0x54(0x4)
	struct FEOSUserInfoExternalUserInfo OutExternalUserInfo;  // 0x58(0x28)
	uint8_t  ReturnValue;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogGameRoundEnd
// Size: 0x18(Inherited: 0x0) 
struct FEOSAntiCheatServerLogGameRoundEnd
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogGameRoundEndOptions Options;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerRevive
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerLogPlayerRevive
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerReviveOptions Options;  // 0x8(0x18)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerSpawn
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerLogPlayerSpawn
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerSpawnOptions Options;  // 0x8(0x18)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerTick
// Size: 0x48(Inherited: 0x0) 
struct FEOSAntiCheatServerLogPlayerTick
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerTickOptions Options;  // 0x8(0x38)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerUseAbility
// Size: 0x30(Inherited: 0x0) 
struct FEOSAntiCheatServerLogPlayerUseAbility
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerUseAbilityOptions Options;  // 0x8(0x20)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerUseWeapon
// Size: 0x58(Inherited: 0x0) 
struct FEOSAntiCheatServerLogPlayerUseWeapon
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonLogPlayerUseWeaponOptions Options;  // 0x8(0x48)
	uint8_t  ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EOSCore.CoreCustomInvites.EOSCustomInvitesAddNotifyCustomInviteReceived
// Size: 0x28(Inherited: 0x0) 
struct FEOSCustomInvitesAddNotifyCustomInviteReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSCustomInvitesAddNotifyCustomInviteReceivedOptions Options;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreRTCAdmin.EOSRTCAdminQueryJoinRoomToken
// Size: 0x70(Inherited: 0x0) 
struct FEOSRTCAdminQueryJoinRoomToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSQueryJoinRoomTokenOptions Options;  // 0x8(0x58)
	struct FDelegate Callback;  // 0x60(0x10)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerProtectMessage
// Size: 0x48(Inherited: 0x0) 
struct FEOSAntiCheatServerProtectMessage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerProtectMessageOptions Options;  // 0x8(0x28)
	struct TArray<char> OutBuffer;  // 0x30(0x10)
	int32_t OutBufferLengthBytes;  // 0x40(0x4)
	uint8_t  ReturnValue;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerReceiveMessageFromClient
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerReceiveMessageFromClient
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerReceiveMessageFromClientOptions Options;  // 0x8(0x18)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRegisterClient
// Size: 0x40(Inherited: 0x0) 
struct FEOSAntiCheatServerRegisterClient
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatServerRegisterClientOptions Options;  // 0x8(0x30)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.EOSCoreAuthVerifyUserAuth.EOSAuthVerifyUserAuthAsync
// Size: 0xC0(Inherited: 0x0) 
struct FEOSAuthVerifyUserAuthAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthVerifyUserAuthOptions Options;  // 0x8(0xB0)
	struct UEOSCoreAuthVerifyUserAuth* ReturnValue;  // 0xB8(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRemoveNotifyClientActionRequired
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatServerRemoveNotifyClientActionRequired
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRemoveNotifyMessageToClient
// Size: 0x10(Inherited: 0x0) 
struct FEOSAntiCheatServerRemoveNotifyMessageToClient
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerSetGameSessionId
// Size: 0x28(Inherited: 0x0) 
struct FEOSAntiCheatServerSetGameSessionId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAntiCheatCommonSetGameSessionIdOptions Options;  // 0x8(0x18)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreAntiCheatServer.GetAntiCheatServer
// Size: 0x10(Inherited: 0x0) 
struct FGetAntiCheatServer
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreAntiCheatServer* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthAddNotifyLoginStatusChanged
// Size: 0x20(Inherited: 0x0) 
struct FEOSAuthAddNotifyLoginStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthCopyIdToken
// Size: 0x70(Inherited: 0x0) 
struct FEOSAuthCopyIdToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSAuthCopyIdTokenOptions Options;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FEOSAuthIdToken OutIdToken;  // 0x30(0x38)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthGetLoggedInAccountByIndex
// Size: 0x30(Inherited: 0x0) 
struct FEOSAuthGetLoggedInAccountByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	struct FEOSEpicAccountId ReturnValue;  // 0xC(0x21)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthGetLoginStatusPure
// Size: 0x30(Inherited: 0x0) 
struct FEOSAuthGetLoginStatusPure
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	uint8_t  ReturnValue;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthGetMergedAccountByIndex
// Size: 0x58(Inherited: 0x0) 
struct FEOSAuthGetMergedAccountByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	int32_t Index;  // 0x2C(0x4)
	struct FEOSEpicAccountId ReturnValue;  // 0x30(0x21)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthGetMergedAccountsCount
// Size: 0x30(Inherited: 0x0) 
struct FEOSAuthGetMergedAccountsCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	int32_t ReturnValue;  // 0x2C(0x4)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthGetSelectedAccountId
// Size: 0x50(Inherited: 0x0) 
struct FEOSAuthGetSelectedAccountId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEpicAccountId LocalUserId;  // 0x8(0x21)
	struct FEOSEpicAccountId OutSelectedAccountId;  // 0x29(0x21)
	uint8_t  ReturnValue;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)

}; 
// Function EOSCore.CoreAuthentication.EOSAuthRemoveNotifyLoginStatusChanged
// Size: 0x10(Inherited: 0x0) 
struct FEOSAuthRemoveNotifyLoginStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.EOSCoreSessionsSearchFind.EOSSessionSearchFindAsync
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionSearchFindAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch SearchHandle;  // 0x8(0x8)
	struct FEOSSessionSearchFindOptions Options;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)
	struct UEOSCoreSessionsSearchFind* ReturnValue;  // 0x38(0x8)

}; 
// Function EOSCore.CoreAuthentication.GetAuthentication
// Size: 0x10(Inherited: 0x0) 
struct FGetAuthentication
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreAuthentication* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreChat.GetChat
// Size: 0x8(Inherited: 0x0) 
struct FGetChat
{
	struct UCoreChat* ReturnValue;  // 0x0(0x8)

}; 
// Function EOSCore.CoreConnect.EOSConnectCopyIdToken
// Size: 0x70(Inherited: 0x0) 
struct FEOSConnectCopyIdToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCopyIdTokenOptions Options;  // 0x8(0x21)
	char pad_41[7];  // 0x29(0x7)
	struct FEOSConnectIdToken OutIdToken;  // 0x30(0x38)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function EOSCore.CoreConnect.EOSConnectCopyProductUserInfo
// Size: 0x98(Inherited: 0x0) 
struct FEOSConnectCopyProductUserInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectCopyProductUserInfoOptions Options;  // 0x8(0x28)
	struct FEOSConnectExternalAccountInfo OutExternalAccountInfo;  // 0x30(0x60)
	uint8_t  ReturnValue;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)

}; 
// Function EOSCore.CoreConnect.EOSConnectGetLoggedInUserByIndex
// Size: 0x30(Inherited: 0x0) 
struct FEOSConnectGetLoggedInUserByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	struct FEOSProductUserId ReturnValue;  // 0xC(0x21)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function EOSCore.CoreConnect.EOSConnectGetLoggedInUsersCount
// Size: 0x10(Inherited: 0x0) 
struct FEOSConnectGetLoggedInUsersCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function EOSCore.CoreConnect.EOSConnectLinkAccount
// Size: 0x48(Inherited: 0x0) 
struct FEOSConnectLinkAccount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectLinkAccountOptions Options;  // 0x8(0x30)
	struct FDelegate Callback;  // 0x38(0x10)

}; 
// Function EOSCore.CoreConnect.EOSConnectRemoveNotifyAuthExpiration
// Size: 0x10(Inherited: 0x0) 
struct FEOSConnectRemoveNotifyAuthExpiration
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreConnect.EOSConnectRemoveNotifyLoginStatusChanged
// Size: 0x10(Inherited: 0x0) 
struct FEOSConnectRemoveNotifyLoginStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreConnect.EOSConnectTransferDeviceIdAccount
// Size: 0x80(Inherited: 0x0) 
struct FEOSConnectTransferDeviceIdAccount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectTransferDeviceIdAccountOptions Options;  // 0x8(0x63)
	char pad_107[1];  // 0x6B(0x1)
	struct FDelegate Callback;  // 0x6C(0x10)
	char pad_124[4];  // 0x7C(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionsCreateSessionSearch
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsCreateSessionSearch
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsCreateSessionSearchOptions Options;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FEOSHSessionSearch OutSessionSearchHandle;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreConnect.EOSConnectVerifyIdToken
// Size: 0x50(Inherited: 0x0) 
struct FEOSConnectVerifyIdToken
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectVerifyIdTokenOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.EOSCoreConnectTransferDeviceIdAccount.EOSConnectTransferDeviceIdAccountAsync
// Size: 0x78(Inherited: 0x0) 
struct FEOSConnectTransferDeviceIdAccountAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectTransferDeviceIdAccountOptions Options;  // 0x8(0x63)
	char pad_107[5];  // 0x6B(0x5)
	struct UEOSCoreConnectTransferDeviceIdAccount* ReturnValue;  // 0x70(0x8)

}; 
// Function EOSCore.EOSCoreConnectDeleteDeviceId.EOSConnectDeleteDeviceIdAsync
// Size: 0x18(Inherited: 0x0) 
struct FEOSConnectDeleteDeviceIdAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectDeleteDeviceIdOptions Options;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UEOSCoreConnectDeleteDeviceId* ReturnValue;  // 0x10(0x8)

}; 
// Function EOSCore.EOSCoreConnectQueryProductUserIdMappings.EOSConnectQueryProductUserIdMappingsAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSConnectQueryProductUserIdMappingsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSConnectQueryProductUserIdMappingsOptions Options;  // 0x8(0x38)
	struct UEOSCoreConnectQueryProductUserIdMappings* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.EOSCoreLibrary.CoreBytesToString
// Size: 0x20(Inherited: 0x0) 
struct FCoreBytesToString
{
	struct TArray<char> Data;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.EOS_Initialized
// Size: 0x10(Inherited: 0x0) 
struct FEOS_Initialized
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function EOSCore.EOSCoreLibrary.EOS_Success
// Size: 0x2(Inherited: 0x0) 
struct FEOS_Success
{
	uint8_t  Status;  // 0x0(0x1)
	uint8_t  Result;  // 0x1(0x1)

}; 
// Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdFromString
// Size: 0x38(Inherited: 0x0) 
struct FEOSEpicAccountIdFromString
{
	struct FString String;  // 0x0(0x10)
	struct FEOSEpicAccountId ReturnValue;  // 0x10(0x21)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdIsValidPure
// Size: 0x22(Inherited: 0x0) 
struct FEOSEpicAccountIdIsValidPure
{
	struct FEOSEpicAccountId ID;  // 0x0(0x21)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)

}; 
// Function EOSCore.EOSCoreLibrary.GetCurrentAccountId
// Size: 0x30(Inherited: 0x0) 
struct FGetCurrentAccountId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	int32_t UserIndex;  // 0x8(0x4)
	struct FEOSEpicAccountId ReturnValue;  // 0xC(0x21)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function EOSCore.EOSCoreLibrary.GetLobbyAttributeBool
// Size: 0x30(Inherited: 0x0) 
struct FGetLobbyAttributeBool
{
	struct FEOSLobbyAttributeData Data;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.EOSCoreLibrary.GetSessionAttributeDouble
// Size: 0x30(Inherited: 0x0) 
struct FGetSessionAttributeDouble
{
	struct FEOSSessionsAttributeData Data;  // 0x0(0x20)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.GetSessionAttributeInt64
// Size: 0x30(Inherited: 0x0) 
struct FGetSessionAttributeInt64
{
	struct FEOSSessionsAttributeData Data;  // 0x0(0x20)
	struct FString ReturnValue;  // 0x20(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.GetString
// Size: 0x48(Inherited: 0x0) 
struct FGetString
{
	struct FEOSSessionSetting Settings;  // 0x0(0x28)
	struct FString Key;  // 0x28(0x10)
	struct FString ReturnValue;  // 0x38(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.IsEpicAccountIdIdenticalWith
// Size: 0x43(Inherited: 0x0) 
struct FIsEpicAccountIdIdenticalWith
{
	struct FEOSEpicAccountId A;  // 0x0(0x21)
	struct FEOSEpicAccountId B;  // 0x21(0x21)
	char pad_66_1 : 7;  // 0x42(0x1)
	bool ReturnValue : 1;  // 0x42(0x1)

}; 
// Function EOSCore.EOSCoreLibrary.Login
// Size: 0x58(Inherited: 0x0) 
struct FLogin
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct APlayerController* PlayerController;  // 0x8(0x8)
	struct FString LoginId;  // 0x10(0x10)
	struct FString Password;  // 0x20(0x10)
	uint8_t  AuthType;  // 0x30(0x1)
	uint8_t  CredentialsType;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct FString AdditionalData;  // 0x38(0x10)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// Function EOSCore.EOSCoreLibrary.MakeInteger
// Size: 0x30(Inherited: 0x0) 
struct FMakeInteger
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FEOSSessionSetting ReturnValue;  // 0x8(0x28)

}; 
// Function EOSCore.EOSCoreLibrary.MakeSearchBool
// Size: 0x28(Inherited: 0x0) 
struct FMakeSearchBool
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FEOSSessionSearchSetting ReturnValue;  // 0x8(0x20)

}; 
// Function EOSCore.CoreSessions.EOSSessionsAddNotifySessionInviteReceived
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsAddNotifySessionInviteReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionDetailsCopySessionAttributeByKey
// Size: 0x50(Inherited: 0x0) 
struct FEOSSessionDetailsCopySessionAttributeByKey
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionDetails Handle;  // 0x8(0x8)
	struct FEOSSessionDetailsCopySessionAttributeByKeyOptions Options;  // 0x10(0x10)
	struct FEOSSessionDetailsAttribute OutSessionAttribute;  // 0x20(0x28)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.EOSCoreLibrary.MakeSearchInteger
// Size: 0x28(Inherited: 0x0) 
struct FMakeSearchInteger
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FEOSSessionSearchSetting ReturnValue;  // 0x8(0x20)

}; 
// Function EOSCore.EOSCoreLibrary.MakeSearchString
// Size: 0x30(Inherited: 0x0) 
struct FMakeSearchString
{
	struct FString Value;  // 0x0(0x10)
	struct FEOSSessionSearchSetting ReturnValue;  // 0x10(0x20)

}; 
// Function EOSCore.CoreCustomInvites.EOSCustomInvitesRemoveNotifyCustomInviteReceived
// Size: 0x10(Inherited: 0x0) 
struct FEOSCustomInvitesRemoveNotifyCustomInviteReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreCustomInvites.EOSCustomInvitesSendCustomInvite
// Size: 0x50(Inherited: 0x0) 
struct FEOSCustomInvitesSendCustomInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSCustomInvitesSendCustomInviteOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.CoreSessions.EOSSessionsIsUserInSession
// Size: 0x48(Inherited: 0x0) 
struct FEOSSessionsIsUserInSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsIsUserInSessionOptions Options;  // 0x8(0x38)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function EOSCore.CoreCustomInvites.EOSCustomInvitesSetCustomInvite
// Size: 0x48(Inherited: 0x0) 
struct FEOSCustomInvitesSetCustomInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSCustomInvitesSetCustomInviteOptions Options;  // 0x8(0x38)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function EOSCore.CoreCustomInvites.GetCustomInvites
// Size: 0x10(Inherited: 0x0) 
struct FGetCustomInvites
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreCustomInvites* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoGetExternalUserInfoCount
// Size: 0x58(Inherited: 0x0) 
struct FEOSUserInfoGetExternalUserInfoCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoGetExternalUserInfoCountOptions Options;  // 0x8(0x48)
	int32_t ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// Function EOSCore.CoreEcom.EOSEcomCheckout
// Size: 0x60(Inherited: 0x0) 
struct FEOSEcomCheckout
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCheckoutOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyEntitlementByNameAndIndex
// Size: 0xA0(Inherited: 0x0) 
struct FEOSEcomCopyEntitlementByNameAndIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyEntitlementByNameAndIndexOptions Options;  // 0x8(0x40)
	struct FEOSEcomEntitlement OutEntitlement;  // 0x48(0x50)
	uint8_t  ReturnValue;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyItemById
// Size: 0xE8(Inherited: 0x0) 
struct FEOSEcomCopyItemById
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyItemByIdOptions Options;  // 0x8(0x38)
	struct FEOSEcomCatalogItem OutItem;  // 0x40(0xA0)
	uint8_t  ReturnValue;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyItemImageInfoByIndex
// Size: 0x80(Inherited: 0x0) 
struct FEOSEcomCopyItemImageInfoByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyItemImageInfoByIndexOptions Options;  // 0x8(0x40)
	struct FEOSEcomKeyImageInfo OutImageInfo;  // 0x48(0x30)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomCopyItemReleaseByIndex
// Size: 0x90(Inherited: 0x0) 
struct FEOSEcomCopyItemReleaseByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomCopyItemReleaseByIndexOptions Options;  // 0x8(0x40)
	struct FEOSEcomCatalogRelease OutRelease;  // 0x48(0x40)
	uint8_t  ReturnValue;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetEntitlementsByNameCount
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomGetEntitlementsByNameCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetEntitlementsByNameCountOptions Options;  // 0x8(0x38)
	int32_t ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// Function EOSCore.CoreLobby.EOSLobbyUpdateLobby
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyUpdateLobby
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyUpdateLobbyOptions Options;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetEntitlementsCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetEntitlementsCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetEntitlementsCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetItemImageInfoCount
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomGetItemImageInfoCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetItemImageInfoCountOptions Options;  // 0x8(0x38)
	int32_t ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetOfferCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSEcomGetOfferCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetOfferCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CoreEcom.EOSEcomGetOfferImageInfoCount
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomGetOfferImageInfoCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomGetOfferImageInfoCountOptions Options;  // 0x8(0x38)
	int32_t ReturnValue;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)

}; 
// Function EOSCore.CoreEcom.EOSEcomRedeemEntitlements
// Size: 0x50(Inherited: 0x0) 
struct FEOSEcomRedeemEntitlements
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomRedeemEntitlementsOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.EOSCoreEcomRedeemEntitlements.EOSEcomRedeemEntitlementsAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSEcomRedeemEntitlementsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSEcomRedeemEntitlementsOptions Options;  // 0x8(0x38)
	struct UEOSCoreEcomRedeemEntitlements* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.CoreFriends.EOSFriendsAcceptInvite
// Size: 0x60(Inherited: 0x0) 
struct FEOSFriendsAcceptInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsAcceptInviteOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// Function EOSCore.CoreStats.EOSStatsCopyStatByIndex
// Size: 0x80(Inherited: 0x0) 
struct FEOSStatsCopyStatByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSStatsCopyStatByIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FEOSStatsStat OutStat;  // 0x38(0x40)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function EOSCore.CoreFriends.EOSFriendsAddNotifyFriendsUpdate
// Size: 0x20(Inherited: 0x0) 
struct FEOSFriendsAddNotifyFriendsUpdate
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreFriends.EOSFriendsGetFriendAtIndex
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsGetFriendAtIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsGetFriendAtIndexOptions Options;  // 0x8(0x2C)
	struct FEOSEpicAccountId ReturnValue;  // 0x34(0x21)
	char pad_85[3];  // 0x55(0x3)

}; 
// Function EOSCore.CoreFriends.EOSFriendsGetFriendsCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSFriendsGetFriendsCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsGetFriendsCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioSetAudioOutputSettings
// Size: 0x50(Inherited: 0x0) 
struct FEOSRTCAudioSetAudioOutputSettings
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSSetAudioOutputSettingsOptions Options;  // 0x8(0x40)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.CoreFriends.EOSFriendsGetStatus
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsGetStatus
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsGetStatusOptions Options;  // 0x8(0x48)
	uint8_t  ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EOSCore.CoreFriends.EOSFriendsRejectInvite
// Size: 0x60(Inherited: 0x0) 
struct FEOSFriendsRejectInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsRejectInviteOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// Function EOSCore.EOSCoreFriendsSendInvite.EOSFriendsSendInviteAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsSendInviteAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsSendInviteOptions Options;  // 0x8(0x48)
	struct UEOSCoreFriendsSendInvite* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.EOSCoreFriendsRejectInvite.EOSFriendsRejectInviteAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSFriendsRejectInviteAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSFriendsRejectInviteOptions Options;  // 0x8(0x48)
	struct UEOSCoreFriendsRejectInvite* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardDefinitionByIndex
// Size: 0x68(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardDefinitionByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsCopyLeaderboardDefinitionByIndexOptions Options;  // 0x8(0x8)
	struct FEOSLeaderboardsDefinition OutLeaderboardDefinition;  // 0x10(0x50)
	uint8_t  ReturnValue;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardId
// Size: 0x78(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardIdOptions Options;  // 0x8(0x18)
	struct FEOSLeaderboardsDefinition OutLeaderboardDefinition;  // 0x20(0x50)
	uint8_t  ReturnValue;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardRecordByIndex
// Size: 0x58(Inherited: 0x0) 
struct FEOSLeaderboardsCopyLeaderboardRecordByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsCopyLeaderboardRecordByIndexOptions Options;  // 0x8(0x8)
	struct FEOSLeaderboardsLeaderboardRecord OutLeaderboardRecord;  // 0x10(0x40)
	uint8_t  ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsGetLeaderboardDefinitionCount
// Size: 0x10(Inherited: 0x0) 
struct FEOSLeaderboardsGetLeaderboardDefinitionCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsGetLeaderboardDefinitionCountOptions Options;  // 0x8(0x4)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsGetLeaderboardRecordCount
// Size: 0x10(Inherited: 0x0) 
struct FEOSLeaderboardsGetLeaderboardRecordCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsGetLeaderboardRecordCountOptions Options;  // 0x8(0x4)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsQueryLeaderboardDefinitions
// Size: 0x68(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardDefinitions
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsQueryLeaderboardDefinitionsOptions Options;  // 0x8(0x50)
	struct FDelegate Callback;  // 0x58(0x10)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsQueryLeaderboardRanks
// Size: 0x58(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardRanks
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsQueryLeaderboardRanksOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// Function EOSCore.CoreLeaderboards.EOSLeaderboardsQueryLeaderboardUserScores
// Size: 0x88(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardUserScores
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsQueryLeaderboardUserScoresOptions Options;  // 0x8(0x70)
	struct FDelegate Callback;  // 0x78(0x10)

}; 
// Function EOSCore.CoreLeaderboards.GetLeaderboards
// Size: 0x10(Inherited: 0x0) 
struct FGetLeaderboards
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreLeaderboards* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoQueryUserInfo
// Size: 0x60(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoQueryUserInfoOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardRanks.EOSLeaderboardsQueryLeaderboardRanksAsync
// Size: 0x50(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardRanksAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsQueryLeaderboardRanksOptions Options;  // 0x8(0x40)
	struct UEOSCoreLeaderboardsQueryLeaderboardRanks* ReturnValue;  // 0x48(0x8)

}; 
// Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardUserScores.EOSLeaderboardsQueryLeaderboardUserScoresAsync
// Size: 0x80(Inherited: 0x0) 
struct FEOSLeaderboardsQueryLeaderboardUserScoresAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLeaderboardsQueryLeaderboardUserScoresOptions Options;  // 0x8(0x70)
	struct UEOSCoreLeaderboardsQueryLeaderboardUserScores* ReturnValue;  // 0x78(0x8)

}; 
// Function EOSCore.CoreTitleStorage.GetTitleStorage
// Size: 0x10(Inherited: 0x0) 
struct FGetTitleStorage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreTitleStorage* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyInviteAccepted
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyInviteAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyAddNotifyLobbyInviteAcceptedOptions Options;  // 0x8(0x4)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyInviteReceived
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyInviteReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionsDumpSessionState
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsDumpSessionState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsDumpSessionStateOptions Options;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyMemberUpdateReceived
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyAddNotifyLobbyMemberUpdateReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyAddNotifyRTCRoomConnectionChanged
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbyAddNotifyRTCRoomConnectionChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyAddNotifyRTCRoomConnectionChangedOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoCopyExternalUserInfoByAccountId
// Size: 0x90(Inherited: 0x0) 
struct FEOSUserInfoCopyExternalUserInfoByAccountId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoCopyExternalUserInfoByAccountIdOptions Options;  // 0x8(0x58)
	struct FEOSUserInfoExternalUserInfo OutExternalUserInfo;  // 0x60(0x28)
	uint8_t  ReturnValue;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyCopyLobbyDetailsHandleByUiEventId
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyCopyLobbyDetailsHandleByUiEventId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyCopyLobbyDetailsHandleByUiEventIdOptions Options;  // 0x8(0x8)
	struct FEOSHLobbyDetails OutLobbyDetailsHandle;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsCopyAttributeByIndex
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyAttributeByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsCopyAttributeByIndexOptions Options;  // 0x10(0x8)
	struct FEOSLobbyAttribute OutAttribute;  // 0x18(0x38)
	uint8_t  ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyCreateLobbySearch
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyCreateLobbySearch
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyCreateLobbySearchOptions Options;  // 0x8(0x8)
	struct FEOSHLobbySearch OutLobbySearchHandle;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsCopyMemberAttributeByKey
// Size: 0x88(Inherited: 0x0) 
struct FEOSLobbyDetailsCopyMemberAttributeByKey
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsCopyMemberAttributeByKeyOptions Options;  // 0x10(0x38)
	struct FEOSLobbyAttribute OutAttribute;  // 0x48(0x38)
	uint8_t  ReturnValue;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyDetailsGetLobbyOwner
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyDetailsGetLobbyOwner
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyDetails Handle;  // 0x8(0x8)
	struct FEOSLobbyDetailsGetLobbyOwnerOptions Options;  // 0x10(0x4)
	struct FEOSProductUserId ReturnValue;  // 0x14(0x21)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchSetMaxResults
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionSearchSetMaxResults
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FEOSSessionSearchSetMaxResultsOptions Options;  // 0x10(0x4)
	uint8_t  ReturnValue;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function EOSCore.CoreLobby.EOSLobbyJoinLobby
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyJoinLobby
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyJoinLobbyOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyGetInviteCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyGetInviteCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyGetInviteCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CoreLobby.EOSLobbyGetInviteIdByIndex
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyGetInviteIdByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyGetInviteIdByIndexOptions Options;  // 0x8(0x2C)
	char pad_52[4];  // 0x34(0x4)
	struct FString OutInviteId;  // 0x38(0x10)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyIsRTCRoomConnected
// Size: 0x48(Inherited: 0x0) 
struct FEOSLobbyIsRTCRoomConnected
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyIsRTCRoomConnectedOptions Options;  // 0x8(0x38)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bOutIsConnected : 1;  // 0x40(0x1)
	uint8_t  ReturnValue;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyKickMember
// Size: 0x70(Inherited: 0x0) 
struct FEOSLobbyKickMember
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyKickMemberOptions Options;  // 0x8(0x58)
	struct FDelegate Callback;  // 0x60(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyLeaveLobby
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyLeaveLobby
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyLeaveLobbyOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.CoreRTC.EOSRTCRemoveNotifyDisconnected
// Size: 0x10(Inherited: 0x0) 
struct FEOSRTCRemoveNotifyDisconnected
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeBool
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyModificationAddAttributeBool
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bValue : 1;  // 0x20(0x1)
	uint8_t  Visibility;  // 0x21(0x1)
	uint8_t  ReturnValue;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeBool
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbyModificationAddMemberAttributeBool
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bValue : 1;  // 0x20(0x1)
	uint8_t  Visibility;  // 0x21(0x1)
	uint8_t  ReturnValue;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeDouble
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddMemberAttributeDouble
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  Visibility;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeInt64
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddMemberAttributeInt64
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  Visibility;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeString
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbyModificationAddMemberAttributeString
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  Visibility;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationRelease
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbyModificationRelease
{
	struct FEOSHLobbyModification LobbyModificationHandle;  // 0x0(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationRemoveAttribute
// Size: 0x30(Inherited: 0x0) 
struct FEOSLobbyModificationRemoveAttribute
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FEOSLobbyModificationRemoveAttributeOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationRemoveMemberAttribute
// Size: 0x30(Inherited: 0x0) 
struct FEOSLobbyModificationRemoveMemberAttribute
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FEOSLobbyModificationRemoveMemberAttributeOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationSetBucketId
// Size: 0x30(Inherited: 0x0) 
struct FEOSLobbyModificationSetBucketId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FEOSLobbyModificationSetBucketIdOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationSetInvitesAllowed
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyModificationSetInvitesAllowed
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FEOSLobbyModificationSetInvitesAllowedOptions Options;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyModificationSetMaxMembers
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyModificationSetMaxMembers
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbyModification Handle;  // 0x8(0x8)
	struct FEOSLobbyModificationSetMaxMembersOptions Options;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbyPromoteMember
// Size: 0x70(Inherited: 0x0) 
struct FEOSLobbyPromoteMember
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyPromoteMemberOptions Options;  // 0x8(0x58)
	struct FDelegate Callback;  // 0x60(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyQueryInvites
// Size: 0x40(Inherited: 0x0) 
struct FEOSLobbyQueryInvites
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyQueryInvitesOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRejectInvite
// Size: 0x58(Inherited: 0x0) 
struct FEOSLobbyRejectInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyRejectInviteOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyInviteAccepted
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyRemoveNotifyLobbyInviteAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyMemberStatusReceived
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyRemoveNotifyLobbyMemberStatusReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyMemberUpdateReceived
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyRemoveNotifyLobbyMemberUpdateReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyUpdateReceived
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyRemoveNotifyLobbyUpdateReceived
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyRTCRoomConnectionChanged
// Size: 0x10(Inherited: 0x0) 
struct FEOSLobbyRemoveNotifyRTCRoomConnectionChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchFind
// Size: 0x48(Inherited: 0x0) 
struct FEOSLobbySearchFind
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchFindOptions Options;  // 0x10(0x28)
	struct FDelegate Callback;  // 0x38(0x10)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchGetSearchResultCount
// Size: 0x18(Inherited: 0x0) 
struct FEOSLobbySearchGetSearchResultCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchGetSearchResultCountOptions Options;  // 0x10(0x4)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioDevicesChanged
// Size: 0x18(Inherited: 0x0) 
struct FEOSRTCAudioRemoveNotifyAudioDevicesChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSNotificationId NotificationID;  // 0x10(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchRelease
// Size: 0x8(Inherited: 0x0) 
struct FEOSLobbySearchRelease
{
	struct FEOSHLobbySearch LobbySearchHandle;  // 0x0(0x8)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchRemoveParameter
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbySearchRemoveParameter
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchRemoveParameterOptions Options;  // 0x10(0x20)
	uint8_t  ReturnValue;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchSetLobbyId
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbySearchSetLobbyId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchSetLobbyIdOptions Options;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchSetMaxResults
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbySearchSetMaxResults
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FEOSLobbySearchSetMaxResultsOptions Options;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchSetParameterBool
// Size: 0x28(Inherited: 0x0) 
struct FEOSLobbySearchSetParameterBool
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bValue : 1;  // 0x20(0x1)
	uint8_t  ComparisonOp;  // 0x21(0x1)
	uint8_t  ReturnValue;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
// Function EOSCore.CoreLobby.EOSLobbySearchSetParameterString
// Size: 0x38(Inherited: 0x0) 
struct FEOSLobbySearchSetParameterString
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHLobbySearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  ComparisonOp;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreLobby.EOSLobbyUpdateLobbyModification
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyUpdateLobbyModification
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyUpdateLobbyModificationOptions Options;  // 0x8(0x38)
	struct FEOSHLobbyModification OutLobbyModificationHandle;  // 0x40(0x8)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchGetSearchResultCount
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionSearchGetSearchResultCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FEOSSessionSearchGetSearchResultCountOptions Options;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function EOSCore.EOSCoreLobbyCreateLobby.EOSLobbyCreateLobbyAsync
// Size: 0x70(Inherited: 0x0) 
struct FEOSLobbyCreateLobbyAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyCreateLobbyOptions Options;  // 0x8(0x60)
	struct UEOSCoreLobbyCreateLobby* ReturnValue;  // 0x68(0x8)

}; 
// Function EOSCore.EOSCoreLobbyJoinLobby.EOSLobbyJoinLobbyAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSLobbyJoinLobbyAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyJoinLobbyOptions Options;  // 0x8(0x38)
	struct UEOSCoreLobbyJoinLobby* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.EOSCoreLobbyUpdateLobby.EOSLobbyUpdateLobbyAsync
// Size: 0x20(Inherited: 0x0) 
struct FEOSLobbyUpdateLobbyAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyUpdateLobbyOptions Options;  // 0x8(0x10)
	struct UEOSCoreLobbyUpdateLobby* ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.EOSCoreLobbyPromoteMember.EOSLobbyPromoteMemberAsync
// Size: 0x68(Inherited: 0x0) 
struct FEOSLobbyPromoteMemberAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyPromoteMemberOptions Options;  // 0x8(0x58)
	struct UEOSCoreLobbyPromoteMember* ReturnValue;  // 0x60(0x8)

}; 
// Function EOSCore.EOSCoreLobbyKickMember.EOSLobbyKickMemberAsync
// Size: 0x68(Inherited: 0x0) 
struct FEOSLobbyKickMemberAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyKickMemberOptions Options;  // 0x8(0x58)
	struct UEOSCoreLobbyKickMember* ReturnValue;  // 0x60(0x8)

}; 
// Function EOSCore.EOSCoreLobbyRejectInvite.EOSLobbyRejectInviteAsync
// Size: 0x50(Inherited: 0x0) 
struct FEOSLobbyRejectInviteAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSLobbyRejectInviteOptions Options;  // 0x8(0x40)
	struct UEOSCoreLobbyRejectInvite* ReturnValue;  // 0x48(0x8)

}; 
// Function EOSCore.CoreMetrics.EOSMetricsBeginPlayerSession
// Size: 0x80(Inherited: 0x0) 
struct FEOSMetricsBeginPlayerSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSMetricsBeginPlayerSessionOptions Options;  // 0x8(0x70)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function EOSCore.CoreMods.EOSModsUninstallMod
// Size: 0x98(Inherited: 0x0) 
struct FEOSModsUninstallMod
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSModsUninstallModOptions Options;  // 0x8(0x80)
	struct FDelegate Callback;  // 0x88(0x10)

}; 
// Function EOSCore.CoreMods.GetMods
// Size: 0x10(Inherited: 0x0) 
struct FGetMods
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreMods* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreP2P.EOSP2PAddNotifyPeerConnectionClosed
// Size: 0x50(Inherited: 0x0) 
struct FEOSP2PAddNotifyPeerConnectionClosed
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PAddNotifyPeerConnectionClosedOptions Options;  // 0x8(0x40)
	struct FEOSNotificationId ReturnValue;  // 0x48(0x8)

}; 
// Function EOSCore.CoreP2P.EOSP2PAddNotifyPeerConnectionRequest
// Size: 0x60(Inherited: 0x0) 
struct FEOSP2PAddNotifyPeerConnectionRequest
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PAddNotifyPeerConnectionRequestOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x58(0x8)

}; 
// Function EOSCore.CoreP2P.EOSP2PCloseConnection
// Size: 0x70(Inherited: 0x0) 
struct FEOSP2PCloseConnection
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PCloseConnectionOptions Options;  // 0x8(0x60)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function EOSCore.CoreP2P.EOSP2PGetNATType
// Size: 0x10(Inherited: 0x0) 
struct FEOSP2PGetNATType
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PGetNATTypeOptions Options;  // 0x8(0x4)
	uint8_t  OutNatType;  // 0xC(0x1)
	uint8_t  ReturnValue;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)

}; 
// Function EOSCore.CoreP2P.EOSP2PGetNextReceivedPacketSize
// Size: 0x40(Inherited: 0x0) 
struct FEOSP2PGetNextReceivedPacketSize
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PGetNextReceivedPacketSizeOptions Options;  // 0x8(0x2C)
	int32_t OutPacketSizeBytes;  // 0x34(0x4)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.EOSCoreUserInfoQueryUserInfo.EOSUserInfoQueryUserInfoAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoQueryUserInfoOptions Options;  // 0x8(0x48)
	struct UEOSCoreUserInfoQueryUserInfo* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.CoreP2P.EOSP2PGetPortRange
// Size: 0x18(Inherited: 0x0) 
struct FEOSP2PGetPortRange
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PGetPortRangeOptions Options;  // 0x8(0x4)
	int32_t OutPort;  // 0xC(0x4)
	int32_t OutNumAdditionalPortsToTry;  // 0x10(0x4)
	uint8_t  ReturnValue;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function EOSCore.CoreP2P.EOSP2PRemoveNotifyPeerConnectionClosed
// Size: 0x10(Inherited: 0x0) 
struct FEOSP2PRemoveNotifyPeerConnectionClosed
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreP2P.EOSP2PSetPacketQueueSize
// Size: 0x38(Inherited: 0x0) 
struct FEOSP2PSetPacketQueueSize
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSP2PSetPacketQueueSizeOptions Options;  // 0x8(0x28)
	uint8_t  ReturnValue;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageDuplicateFile
// Size: 0x60(Inherited: 0x0) 
struct FEOSPlayerDataStorageDuplicateFile
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageDuplicateFileOptions DuplicateOptions;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// Function EOSCore.CoreP2P.GetP2P
// Size: 0x10(Inherited: 0x0) 
struct FGetP2P
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreP2P* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageCopyFileMetadataByFilename
// Size: 0x80(Inherited: 0x0) 
struct FEOSPlayerDataStorageCopyFileMetadataByFilename
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageCopyFileMetadataByFilenameOptions CopyFileMetadataOptions;  // 0x8(0x38)
	struct FEOSPlayerDataStorageFileMetadata OutMetadata;  // 0x40(0x38)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestCancelRequest
// Size: 0x18(Inherited: 0x0) 
struct FEOSPlayerDataStorageFileTransferRequestCancelRequest
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPlayerDataStorageFileTransferRequest Handle;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestGetFileRequestState
// Size: 0x18(Inherited: 0x0) 
struct FEOSPlayerDataStorageFileTransferRequestGetFileRequestState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPlayerDataStorageFileTransferRequest Handle;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageGetFileMetadataCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageGetFileMetadataCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageGetFileMetadataCountOptions GetFileMetadataCountOptions;  // 0x8(0x28)
	int32_t OutFileMetadataCount;  // 0x30(0x4)
	uint8_t  ReturnValue;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageWriteFile
// Size: 0x78(Inherited: 0x0) 
struct FEOSPlayerDataStorageWriteFile
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageWriteFileOptions WriteOptions;  // 0x8(0x60)
	struct FDelegate Callback;  // 0x68(0x10)

}; 
// Function EOSCore.CorePlayerDataStorage.GetPlayerDataStorage
// Size: 0x10(Inherited: 0x0) 
struct FGetPlayerDataStorage
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCorePlayerDataStorage* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.EOSCorePlayerDataStorageQueryFile.EOSPlayerDataStorageQueryFileAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFileAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageQueryFileOptions QueryFileOptions;  // 0x8(0x38)
	struct UEOSCorePlayerDataStorageQueryFile* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.EOSCorePlayerDataStorageQueryFileList.EOSPlayerDataStorageQueryFileListAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSPlayerDataStorageQueryFileListAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageQueryFileListOptions QueryFileListOptions;  // 0x8(0x28)
	struct UEOSCorePlayerDataStorageQueryFileList* ReturnValue;  // 0x30(0x8)

}; 
// Function EOSCore.EOSCorePlayerDataStorageDuplicateFile.EOSPlayerDataStorageDuplicateFileAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSPlayerDataStorageDuplicateFileAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageDuplicateFileOptions DuplicateOptions;  // 0x8(0x48)
	struct UEOSCorePlayerDataStorageDuplicateFile* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.EOSCorePlayerDataStorageReadFile.EOSPlayerDataStorageReadFileAsync
// Size: 0x70(Inherited: 0x0) 
struct FEOSPlayerDataStorageReadFileAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageReadFileOptions ReadOptions;  // 0x8(0x60)
	struct UEOSCorePlayerDataStorageReadFile* ReturnValue;  // 0x68(0x8)

}; 
// Function EOSCore.EOSCorePlayerDataStorageWriteFile.EOSPlayerDataStorageWriteFileAsync
// Size: 0x70(Inherited: 0x0) 
struct FEOSPlayerDataStorageWriteFileAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPlayerDataStorageWriteFileOptions WriteOptions;  // 0x8(0x60)
	struct UEOSCorePlayerDataStorageWriteFile* ReturnValue;  // 0x68(0x8)

}; 
// Function EOSCore.CorePresence.EOSPresenceAddNotifyJoinGameAccepted
// Size: 0x20(Inherited: 0x0) 
struct FEOSPresenceAddNotifyJoinGameAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CorePresence.EOSPresenceCopyPresence
// Size: 0xE8(Inherited: 0x0) 
struct FEOSPresenceCopyPresence
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceCopyPresenceOptions Options;  // 0x8(0x48)
	struct FEOSPresenceInfo OutPresence;  // 0x50(0x90)
	uint8_t  ReturnValue;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceCreatePresenceModification
// Size: 0x40(Inherited: 0x0) 
struct FEOSPresenceCreatePresenceModification
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceCreatePresenceModificationOptions Options;  // 0x8(0x28)
	struct FEOSHPresenceModification OutPresenceModificationHandle;  // 0x30(0x8)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceGetJoinInfo
// Size: 0x68(Inherited: 0x0) 
struct FEOSPresenceGetJoinInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceGetJoinInfoOptions Options;  // 0x8(0x48)
	struct FString OutInfo;  // 0x50(0x10)
	uint8_t  ReturnValue;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceHasPresence
// Size: 0x58(Inherited: 0x0) 
struct FEOSPresenceHasPresence
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceHasPresenceOptions Options;  // 0x8(0x48)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoCopyExternalUserInfoByAccountType
// Size: 0x80(Inherited: 0x0) 
struct FEOSUserInfoCopyExternalUserInfoByAccountType
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoCopyExternalUserInfoByAccountTypeOptions Options;  // 0x8(0x48)
	struct FEOSUserInfoExternalUserInfo OutExternalUserInfo;  // 0x50(0x28)
	uint8_t  ReturnValue;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceModificationRelease
// Size: 0x10(Inherited: 0x0) 
struct FEOSPresenceModificationRelease
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPresenceModification PresenceModificationHandle;  // 0x8(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchSetParameterBool
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionSearchSetParameterBool
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bValue : 1;  // 0x20(0x1)
	uint8_t  ComparisonOp;  // 0x21(0x1)
	uint8_t  ReturnValue;  // 0x22(0x1)
	char pad_35[5];  // 0x23(0x5)

}; 
// Function EOSCore.CorePresence.EOSPresenceModificationSetData
// Size: 0x30(Inherited: 0x0) 
struct FEOSPresenceModificationSetData
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPresenceModification Handle;  // 0x8(0x8)
	struct FEOSPresenceModificationSetDataOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceModificationSetJoinInfo
// Size: 0x30(Inherited: 0x0) 
struct FEOSPresenceModificationSetJoinInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPresenceModification Handle;  // 0x8(0x8)
	struct FEOSPresenceModificationSetJoinInfoOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceModificationSetRawRichText
// Size: 0x30(Inherited: 0x0) 
struct FEOSPresenceModificationSetRawRichText
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPresenceModification Handle;  // 0x8(0x8)
	struct FEOSPresenceModificationSetRawRichTextOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceModificationSetStatus
// Size: 0x20(Inherited: 0x0) 
struct FEOSPresenceModificationSetStatus
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHPresenceModification Handle;  // 0x8(0x8)
	struct FEOSPresenceModificationSetStatusOptions Options;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CorePresence.EOSPresenceRemoveNotifyJoinGameAccepted
// Size: 0x10(Inherited: 0x0) 
struct FEOSPresenceRemoveNotifyJoinGameAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CorePresence.EOSPresenceSetPresence
// Size: 0x48(Inherited: 0x0) 
struct FEOSPresenceSetPresence
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceSetPresenceOptions Options;  // 0x8(0x30)
	struct FDelegate Callback;  // 0x38(0x10)

}; 
// Function EOSCore.EOSCorePresenceQueryPresence.EOSPresenceQueryPresenceAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSPresenceQueryPresenceAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSPresenceQueryPresenceOptions Options;  // 0x8(0x48)
	struct UEOSCorePresenceQueryPresence* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotAddProgression
// Size: 0x38(Inherited: 0x0) 
struct FEOSProgressionSnapshotAddProgression
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProgressionSnapshotAddProgressionOptions Options;  // 0x8(0x28)
	uint8_t  ReturnValue;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotBeginSnapshot
// Size: 0x38(Inherited: 0x0) 
struct FEOSProgressionSnapshotBeginSnapshot
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProgressionSnapshotBeginSnapshotOptions Options;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	int32_t OutSnapshotId;  // 0x2C(0x4)
	uint8_t  ReturnValue;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotDeleteSnapshot
// Size: 0x40(Inherited: 0x0) 
struct FEOSProgressionSnapshotDeleteSnapshot
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProgressionSnapshotDeleteSnapshotOptions Options;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate Callback;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotSubmitSnapshot
// Size: 0x20(Inherited: 0x0) 
struct FEOSProgressionSnapshotSubmitSnapshot
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSProgressionSnapshotSubmitSnapshotOptions Options;  // 0x8(0x4)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function EOSCore.CoreReports.GetReports
// Size: 0x10(Inherited: 0x0) 
struct FGetReports
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreReports* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreRTC.EOSRTCGetAudioInterface
// Size: 0x10(Inherited: 0x0) 
struct FEOSRTCGetAudioInterface
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreRTC.EOSRTCRemoveNotifyParticipantStatusChanged
// Size: 0x10(Inherited: 0x0) 
struct FEOSRTCRemoveNotifyParticipantStatusChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId NotificationID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreRTCAdmin.EOSRTCAdminCopyUserTokenByIndex
// Size: 0x50(Inherited: 0x0) 
struct FEOSRTCAdminCopyUserTokenByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSCopyUserTokenByIndexOptions Options;  // 0x8(0x8)
	struct FEOSUserToken OutUserToken;  // 0x10(0x38)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.CoreRTCAdmin.EOSRTCAdminCopyUserTokenByUserId
// Size: 0x70(Inherited: 0x0) 
struct FEOSRTCAdminCopyUserTokenByUserId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSCopyUserTokenByUserIdOptions Options;  // 0x8(0x28)
	struct FEOSUserToken OutUserToken;  // 0x30(0x38)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function EOSCore.CoreRTCAdmin.EOSRTCAdminSetParticipantHardMute
// Size: 0x50(Inherited: 0x0) 
struct FEOSRTCAdminSetParticipantHardMute
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSetParticipantHardMuteOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.CoreRTCAdmin.GetRTCAdmin
// Size: 0x10(Inherited: 0x0) 
struct FGetRTCAdmin
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreRTCAdmin* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioBeforeRender
// Size: 0x68(Inherited: 0x0) 
struct FEOSRTCAudioAddNotifyAudioBeforeRender
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSAddNotifyAudioBeforeRenderOptions Options;  // 0x10(0x40)
	struct FDelegate Callback;  // 0x50(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x60(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioDevicesChanged
// Size: 0x30(Inherited: 0x0) 
struct FEOSRTCAudioAddNotifyAudioDevicesChanged
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSAddNotifyAudioDevicesChangedOptions Options;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate Callback;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x28(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchSetTargetUserId
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionSearchSetTargetUserId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FEOSSessionSearchSetTargetUserIdOptions Options;  // 0x10(0x21)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioOutputState
// Size: 0x60(Inherited: 0x0) 
struct FEOSRTCAudioAddNotifyAudioOutputState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSAddNotifyAudioOutputStateOptions Options;  // 0x10(0x38)
	struct FDelegate Callback;  // 0x48(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x58(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyParticipantUpdated
// Size: 0x60(Inherited: 0x0) 
struct FEOSRTCAudioAddNotifyParticipantUpdated
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSAddNotifyParticipantUpdatedOptions Options;  // 0x10(0x38)
	struct FDelegate Callback;  // 0x48(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x58(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioInputDeviceByIndex
// Size: 0x38(Inherited: 0x0) 
struct FEOSRTCAudioGetAudioInputDeviceByIndex
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSGetAudioOutputDeviceByIndexOptions Options;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FEOSAudioInputDeviceInfo ReturnValue;  // 0x10(0x28)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioOutputDeviceByIndex
// Size: 0x38(Inherited: 0x0) 
struct FEOSRTCAudioGetAudioOutputDeviceByIndex
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSGetAudioOutputDeviceByIndexOptions Options;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FEOSAudioOutputDeviceInfo ReturnValue;  // 0x10(0x28)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioBeforeRender
// Size: 0x18(Inherited: 0x0) 
struct FEOSRTCAudioRemoveNotifyAudioBeforeRender
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSNotificationId NotificationID;  // 0x10(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioBeforeSend
// Size: 0x18(Inherited: 0x0) 
struct FEOSRTCAudioRemoveNotifyAudioBeforeSend
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSNotificationId NotificationID;  // 0x10(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioOutputState
// Size: 0x18(Inherited: 0x0) 
struct FEOSRTCAudioRemoveNotifyAudioOutputState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHRTCAudio Handle;  // 0x8(0x8)
	struct FEOSNotificationId NotificationID;  // 0x10(0x8)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioSendAudio
// Size: 0x58(Inherited: 0x0) 
struct FEOSRTCAudioSendAudio
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSSendAudioOptions Options;  // 0x8(0x48)
	uint8_t  ReturnValue;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioSetAudioInputSettings
// Size: 0x50(Inherited: 0x0) 
struct FEOSRTCAudioSetAudioInputSettings
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSSetAudioInputSettingsOptions Options;  // 0x8(0x40)
	uint8_t  ReturnValue;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioUnregisterPlatformAudioUser
// Size: 0x20(Inherited: 0x0) 
struct FEOSRTCAudioUnregisterPlatformAudioUser
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSUnregisterPlatformAudioUserOptions Options;  // 0x8(0x10)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioUpdateReceiving
// Size: 0x78(Inherited: 0x0) 
struct FEOSRTCAudioUpdateReceiving
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSUpdateReceivingOptions Options;  // 0x8(0x60)
	struct FDelegate Callback;  // 0x68(0x10)

}; 
// Function EOSCore.CoreRTCAudio.EOSRTCAudioUpdateSending
// Size: 0x58(Inherited: 0x0) 
struct FEOSRTCAudioUpdateSending
{
	struct FEOSHRTCAudio Handle;  // 0x0(0x8)
	struct FEOSUpdateSendingOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// Function EOSCore.CoreRTCAudio.GetRTCAudio
// Size: 0x10(Inherited: 0x0) 
struct FGetRTCAudio
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreRTCAudio* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreSanctions.EOSSanctionsQueryActivePlayerSanctions
// Size: 0x60(Inherited: 0x0) 
struct FEOSSanctionsQueryActivePlayerSanctions
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSanctionsQueryActivePlayerSanctionsOptions Options;  // 0x8(0x48)
	struct FDelegate Callback;  // 0x50(0x10)

}; 
// Function EOSCore.CoreSanctions.GetSanctions
// Size: 0x10(Inherited: 0x0) 
struct FGetSanctions
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreSanctions* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.EOSSanctionsQueryActivePlayerSanctions.EOSSanctionsQueryActivePlayerSanctionsAsync
// Size: 0x58(Inherited: 0x0) 
struct FEOSSanctionsQueryActivePlayerSanctionsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSanctionsQueryActivePlayerSanctionsOptions Options;  // 0x8(0x48)
	struct UEOSSanctionsQueryActivePlayerSanctions* ReturnValue;  // 0x50(0x8)

}; 
// Function EOSCore.CoreSessions.EOSActiveSessionGetRegisteredPlayerByIndex
// Size: 0x38(Inherited: 0x0) 
struct FEOSActiveSessionGetRegisteredPlayerByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHActiveSession Handle;  // 0x8(0x8)
	struct FEOSActiveSessionGetRegisteredPlayerByIndexOptions Options;  // 0x10(0x4)
	struct FEOSProductUserId ReturnValue;  // 0x14(0x21)
	char pad_53[3];  // 0x35(0x3)

}; 
// Function EOSCore.CoreSessions.EOSActiveSessionGetRegisteredPlayerCount
// Size: 0x18(Inherited: 0x0) 
struct FEOSActiveSessionGetRegisteredPlayerCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHActiveSession Handle;  // 0x8(0x8)
	struct FEOSActiveSessionGetRegisteredPlayerCountOptions Options;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchCopySearchResultByIndex
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionSearchCopySearchResultByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FEOSSessionSearchCopySearchResultByIndexOptions Options;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FEOSHSessionDetails OutSessionHandle;  // 0x18(0x8)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionDetailsCopyInfo
// Size: 0x60(Inherited: 0x0) 
struct FEOSSessionDetailsCopyInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionDetails Handle;  // 0x8(0x8)
	struct FEOSSessionDetailsCopyInfoOptions Options;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FEOSSessionDetailsInfo outSessionInfo;  // 0x18(0x40)
	uint8_t  ReturnValue;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionDetailsCopySessionAttributeByIndex
// Size: 0x48(Inherited: 0x0) 
struct FEOSSessionDetailsCopySessionAttributeByIndex
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionDetails Handle;  // 0x8(0x8)
	struct FEOSSessionDetailsCopySessionAttributeByIndexOptions Options;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FEOSSessionDetailsAttribute OutSessionAttribute;  // 0x18(0x28)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionDetailsGetSessionAttributeCount
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionDetailsGetSessionAttributeCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionDetails Handle;  // 0x8(0x8)
	struct FEOSSessionDetailsGetSessionAttributeCountOptions Options;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t ReturnValue;  // 0x14(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeBool
// Size: 0x30(Inherited: 0x0) 
struct FEOSSessionModificationAddAttributeBool
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	uint8_t  AdvertisementType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Key;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bValue : 1;  // 0x28(0x1)
	uint8_t  ReturnValue;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeDouble
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionModificationAddAttributeDouble
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	uint8_t  AdvertisementType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Key;  // 0x18(0x10)
	struct FString Value;  // 0x28(0x10)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeString
// Size: 0x40(Inherited: 0x0) 
struct FEOSSessionModificationAddAttributeString
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	uint8_t  AdvertisementType;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString Key;  // 0x18(0x10)
	struct FString Value;  // 0x28(0x10)
	uint8_t  ReturnValue;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationRelease
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionModificationRelease
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification SessionModificationHandle;  // 0x8(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationSetBucketId
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionModificationSetBucketId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	struct FEOSSessionModificationSetBucketIdOptions Options;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreUI.EOSUISetToggleFriendsKey
// Size: 0x18(Inherited: 0x0) 
struct FEOSUISetToggleFriendsKey
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUISetToggleFriendsKeyOptions Options;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationSetHostAddress
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionModificationSetHostAddress
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	struct FEOSSessionModificationSetHostAddressOptions Options;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationSetInvitesAllowed
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionModificationSetInvitesAllowed
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	struct FEOSSessionModificationSetInvitesAllowedOptions Options;  // 0x10(0x1)
	uint8_t  ReturnValue;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationSetJoinInProgressAllowed
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionModificationSetJoinInProgressAllowed
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	struct FEOSSessionModificationSetJoinInProgressAllowedOptions Options;  // 0x10(0x1)
	uint8_t  ReturnValue;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationSetMaxPlayers
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionModificationSetMaxPlayers
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	struct FEOSSessionModificationSetMaxPlayersOptions Options;  // 0x10(0x4)
	uint8_t  ReturnValue;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function EOSCore.CoreSessions.EOSSessionModificationSetPermissionLevel
// Size: 0x18(Inherited: 0x0) 
struct FEOSSessionModificationSetPermissionLevel
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionModification Handle;  // 0x8(0x8)
	struct FEOSSessionModificationSetPermissionLevelOptions Options;  // 0x10(0x1)
	uint8_t  ReturnValue;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionsAddNotifySessionInviteAccepted
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsAddNotifySessionInviteAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FDelegate Callback;  // 0x8(0x10)
	struct FEOSNotificationId ReturnValue;  // 0x18(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionsCopyActiveSessionHandle
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionsCopyActiveSessionHandle
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsCopyActiveSessionHandleOptions Options;  // 0x8(0x10)
	struct FEOSHActiveSession OutSessionHandle;  // 0x18(0x8)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionsCopySessionHandleByUiEventId
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsCopySessionHandleByUiEventId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsCopySessionHandleByUiEventIdOptions Options;  // 0x8(0x8)
	struct FEOSHSessionDetails OutSessionHandle;  // 0x10(0x8)
	uint8_t  ReturnValue;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionsCreateSessionModification
// Size: 0x60(Inherited: 0x0) 
struct FEOSSessionsCreateSessionModification
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsCreateSessionModificationOptions Options;  // 0x8(0x48)
	struct FEOSHSessionModification OutSessionModificationHandle;  // 0x50(0x8)
	uint8_t  ReturnValue;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchFind
// Size: 0x48(Inherited: 0x0) 
struct FEOSSessionSearchFind
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FEOSSessionSearchFindOptions Options;  // 0x10(0x21)
	char pad_49[3];  // 0x31(0x3)
	struct FDelegate Callback;  // 0x34(0x10)
	char pad_68[4];  // 0x44(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchRelease
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionSearchRelease
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch SessionSearchHandle;  // 0x8(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchRemoveParameter
// Size: 0x30(Inherited: 0x0) 
struct FEOSSessionSearchRemoveParameter
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FEOSSessionSearchRemoveParameterOptions Options;  // 0x10(0x18)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchSetParameterInt64
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionSearchSetParameterInt64
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  ComparisonOp;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchSetParameterString
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionSearchSetParameterString
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FString Key;  // 0x10(0x10)
	struct FString Value;  // 0x20(0x10)
	uint8_t  ComparisonOp;  // 0x30(0x1)
	uint8_t  ReturnValue;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// Function EOSCore.CoreSessions.EOSSessionSearchSetSessionId
// Size: 0x28(Inherited: 0x0) 
struct FEOSSessionSearchSetSessionId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSHSessionSearch Handle;  // 0x8(0x8)
	struct FEOSSessionSearchSetSessionIdOptions Options;  // 0x10(0x10)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreSessions.EOSSessionsGetInviteCount
// Size: 0x30(Inherited: 0x0) 
struct FEOSSessionsGetInviteCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsGetInviteCountOptions Options;  // 0x8(0x21)
	char pad_41[3];  // 0x29(0x3)
	int32_t ReturnValue;  // 0x2C(0x4)

}; 
// Function EOSCore.CoreSessions.EOSSessionsRegisterPlayers
// Size: 0x38(Inherited: 0x0) 
struct FEOSSessionsRegisterPlayers
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsRegisterPlayersOptions Options;  // 0x8(0x20)
	struct FDelegate Callback;  // 0x28(0x10)

}; 
// Function EOSCore.CoreSessions.EOSSessionsRemoveNotifyJoinSessionAccepted
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsRemoveNotifyJoinSessionAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionsRemoveNotifySessionInviteAccepted
// Size: 0x10(Inherited: 0x0) 
struct FEOSSessionsRemoveNotifySessionInviteAccepted
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSNotificationId ID;  // 0x8(0x8)

}; 
// Function EOSCore.CoreSessions.EOSSessionsSendInvite
// Size: 0x70(Inherited: 0x0) 
struct FEOSSessionsSendInvite
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsSendInviteOptions Options;  // 0x8(0x58)
	struct FDelegate Callback;  // 0x60(0x10)

}; 
// Function EOSCore.CoreSessions.EOSSessionsUpdateSession
// Size: 0x20(Inherited: 0x0) 
struct FEOSSessionsUpdateSession
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsUpdateSessionOptions Options;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EOSCore.CoreSessions.GetSessions
// Size: 0x10(Inherited: 0x0) 
struct FGetSessions
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreSessions* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.EOSCoreSessionsRegisterPlayers.EOSSessionsRegisterPlayersAsync
// Size: 0x30(Inherited: 0x0) 
struct FEOSSessionsRegisterPlayersAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsRegisterPlayersOptions Options;  // 0x8(0x20)
	struct UEOSCoreSessionsRegisterPlayers* ReturnValue;  // 0x28(0x8)

}; 
// Function EOSCore.EOSCoreSessionsSendInvite.EOSSessionsSendInviteAsync
// Size: 0x68(Inherited: 0x0) 
struct FEOSSessionsSendInviteAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsSendInviteOptions Options;  // 0x8(0x58)
	struct UEOSCoreSessionsSendInvite* ReturnValue;  // 0x60(0x8)

}; 
// Function EOSCore.EOSCoreSessionsRejectInvite.EOSSessionsRejectInviteAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSSessionsRejectInviteAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSSessionsRejectInviteOptions Options;  // 0x8(0x38)
	struct UEOSCoreSessionsRejectInvite* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.CoreUserInfo.GetUserInfo
// Size: 0x10(Inherited: 0x0) 
struct FGetUserInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreUserInfo* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.CoreStats.EOSStatsCopyStatByName
// Size: 0x88(Inherited: 0x0) 
struct FEOSStatsCopyStatByName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSStatsCopyStatByNameOptions Options;  // 0x8(0x38)
	struct FEOSStatsStat OutStat;  // 0x40(0x40)
	uint8_t  ReturnValue;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// Function EOSCore.CoreStats.EOSStatsGetStatsCount
// Size: 0x38(Inherited: 0x0) 
struct FEOSStatsGetStatsCount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSStatsGetStatCountOptions Options;  // 0x8(0x28)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function EOSCore.CoreStats.EOSStatsIngestStat
// Size: 0x78(Inherited: 0x0) 
struct FEOSStatsIngestStat
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSStatsIngestStatOptions Options;  // 0x8(0x60)
	struct FDelegate Callback;  // 0x68(0x10)

}; 
// Function EOSCore.CoreStats.GetStats
// Size: 0x10(Inherited: 0x0) 
struct FGetStats
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreStats* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.EOSCoreStatsIngestStat.EOSStatsIngestStatAsync
// Size: 0x70(Inherited: 0x0) 
struct FEOSStatsIngestStatAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSStatsIngestStatOptions Options;  // 0x8(0x60)
	struct UEOSCoreStatsIngestStat* ReturnValue;  // 0x68(0x8)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageDeleteCache
// Size: 0x48(Inherited: 0x0) 
struct FEOSTitleStorageDeleteCache
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageDeleteCacheOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageFileTransferRequestCancelRequest
// Size: 0x18(Inherited: 0x0) 
struct FEOSTitleStorageFileTransferRequestCancelRequest
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageFileTransferRequestHandle Handle;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageFileTransferRequestGetFilename
// Size: 0x30(Inherited: 0x0) 
struct FEOSTitleStorageFileTransferRequestGetFilename
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageFileTransferRequestHandle Handle;  // 0x8(0x8)
	int32_t FilenameStringBufferSizeBytes;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString OutStringBuffer;  // 0x18(0x10)
	uint8_t  ReturnValue;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageFileTransferRequestGetFileRequestState
// Size: 0x18(Inherited: 0x0) 
struct FEOSTitleStorageFileTransferRequestGetFileRequestState
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageFileTransferRequestHandle Handle;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageQueryFileList
// Size: 0x50(Inherited: 0x0) 
struct FEOSTitleStorageQueryFileList
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageQueryFileListOptions Options;  // 0x8(0x38)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCore.CoreTitleStorage.EOSTitleStorageReadFile
// Size: 0x78(Inherited: 0x0) 
struct FEOSTitleStorageReadFile
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageReadFileOptions Options;  // 0x8(0x58)
	struct FDelegate Callback;  // 0x60(0x10)
	struct FEOSTitleStorageFileTransferRequestHandle ReturnValue;  // 0x70(0x8)

}; 
// Function EOSCore.EOSCoreTitleStorageQueryFile.EOSTitleStorageQueryFileAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSTitleStorageQueryFileAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageQueryFileOptions Options;  // 0x8(0x38)
	struct UEOSCoreTitleStorageQueryFile* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.EOSCoreTitleStorageQueryFileList.EOSTitleStorageQueryFileListAsync
// Size: 0x48(Inherited: 0x0) 
struct FEOSTitleStorageQueryFileListAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSTitleStorageQueryFileListOptions Options;  // 0x8(0x38)
	struct UEOSCoreTitleStorageQueryFileList* ReturnValue;  // 0x40(0x8)

}; 
// Function EOSCore.CoreUI.EOSUIAcknowledgeEventId
// Size: 0x28(Inherited: 0x0) 
struct FEOSUIAcknowledgeEventId
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIAcknowledgeEventIdOptions Options;  // 0x8(0x18)
	uint8_t  ReturnValue;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCore.CoreUI.EOSUIAddNotifyDisplaySettingsUpdated
// Size: 0x28(Inherited: 0x0) 
struct FEOSUIAddNotifyDisplaySettingsUpdated
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIAddNotifyDisplaySettingsUpdatedOptions Options;  // 0x8(0x4)
	struct FDelegate Callback;  // 0xC(0x10)
	char pad_28[4];  // 0x1C(0x4)
	struct FEOSNotificationId ReturnValue;  // 0x20(0x8)

}; 
// Function EOSCore.CoreUI.EOSUIGetFriendsVisible
// Size: 0x38(Inherited: 0x0) 
struct FEOSUIGetFriendsVisible
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIGetFriendsVisibleOptions Options;  // 0x8(0x28)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function EOSCore.CoreUI.EOSUIGetNotificationLocationPreference
// Size: 0x10(Inherited: 0x0) 
struct FEOSUIGetNotificationLocationPreference
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function EOSCore.CoreUI.EOSUIGetToggleFriendsKey
// Size: 0x10(Inherited: 0x0) 
struct FEOSUIGetToggleFriendsKey
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIGetToggleFriendsKeyOptions Options;  // 0x8(0x4)
	int32_t ReturnValue;  // 0xC(0x4)

}; 
// Function EOSCore.CoreUI.EOSUIIsValidKeyCombination
// Size: 0x10(Inherited: 0x0) 
struct FEOSUIIsValidKeyCombination
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	int32_t keyCombination;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function EOSCore.CoreUI.EOSUISetDisplayPreference
// Size: 0x18(Inherited: 0x0) 
struct FEOSUISetDisplayPreference
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUISetDisplayPreferenceOptions Options;  // 0x8(0x8)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function EOSCore.CoreUI.EOSUIShowFriends
// Size: 0x40(Inherited: 0x0) 
struct FEOSUIShowFriends
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIShowFriendsOptions Options;  // 0x8(0x28)
	struct FDelegate Callback;  // 0x30(0x10)

}; 
// Function EOSCore.CoreUI.GetUI
// Size: 0x10(Inherited: 0x0) 
struct FGetUI
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UCoreUI* ReturnValue;  // 0x8(0x8)

}; 
// Function EOSCore.EOSCoreUIShowFriends.EOSUIShowFriendsAsync
// Size: 0x38(Inherited: 0x0) 
struct FEOSUIShowFriendsAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUIShowFriendsOptions Options;  // 0x8(0x28)
	struct UEOSCoreUIShowFriends* ReturnValue;  // 0x30(0x8)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoCopyUserInfo
// Size: 0xC0(Inherited: 0x0) 
struct FEOSUserInfoCopyUserInfo
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoCopyUserInfoOptions Options;  // 0x8(0x48)
	struct FEOSUserInfo OutUserInfo;  // 0x50(0x68)
	uint8_t  ReturnValue;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)

}; 
// Function EOSCore.CoreUserInfo.EOSUserInfoQueryUserInfoByExternalAccount
// Size: 0x58(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByExternalAccount
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoQueryUserInfoByExternalAccountOptions Options;  // 0x8(0x40)
	struct FDelegate Callback;  // 0x48(0x10)

}; 
// Function EOSCore.EOSCoreUserInfoByExternalAccount.EOSUserInfoQueryUserInfoByExternalAccountAsync
// Size: 0x50(Inherited: 0x0) 
struct FEOSUserInfoQueryUserInfoByExternalAccountAsync
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FEOSUserInfoQueryUserInfoByExternalAccountOptions Options;  // 0x8(0x40)
	struct UEOSCoreUserInfoByExternalAccount* ReturnValue;  // 0x48(0x8)

}; 
