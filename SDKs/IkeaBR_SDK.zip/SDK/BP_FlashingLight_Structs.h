#pragma once 
#include "SDK.h" 
 
 
// Function BP_FlashingLight.BP_FlashingLight_C.ExecuteUbergraph_BP_FlashingLight
// Size: 0xC(Inherited: 0x0) 
struct FExecuteUbergraph_BP_FlashingLight
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x8(0x4)

}; 
// Function BP_FlashingLight.BP_FlashingLight_C.Start
// Size: 0x8(Inherited: 0x0) 
struct FStart
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)

}; 
