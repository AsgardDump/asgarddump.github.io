#pragma once 
#include <FireAxe_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass FireAxe_BP.FireAxe_BP_C
// Size: 0x290(Inherited: 0x290) 
struct AFireAxe_BP_C : public AWeaponBP_C
{

}; 



