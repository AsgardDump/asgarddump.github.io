#pragma once 
#include "SDK.h" 
 
 
// Function BP_Dynamite_Thrown.BP_Dynamite_Thrown_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_Dynamite_Thrown.BP_Dynamite_Thrown_C.ExecuteUbergraph_BP_Dynamite_Thrown
// Size: 0x11C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Dynamite_Thrown
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x10(0x30)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FVector K2Node_CustomEvent_Impulse;  // 0x5C(0xC)
	float K2Node_CustomEvent_B;  // 0x68(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x6C(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x70(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x78(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x80(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x88(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x94(0x88)

}; 
// Function BP_Dynamite_Thrown.BP_Dynamite_Thrown_C.MutliStart
// Size: 0x10(Inherited: 0x0) 
struct FMutliStart
{
	struct FVector Impulse;  // 0x0(0xC)
	float B;  // 0xC(0x4)

}; 
