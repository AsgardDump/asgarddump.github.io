#pragma once 
#include "SDK.h" 
 
 
// Function BR_PS.BR_PS_C.ServerSetPlayer
// Size: 0x8(Inherited: 0x0) 
struct FServerSetPlayer
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BR_PS.BR_PS_C.ServerSetTeammateID
// Size: 0x10(Inherited: 0x0) 
struct FServerSetTeammateID
{
	struct FString TeammateID;  // 0x0(0x10)

}; 
// Function BR_PS.BR_PS_C.ExecuteUbergraph_BR_PS
// Size: 0xA9(Inherited: 0x0) 
struct FExecuteUbergraph_BR_PS
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x20(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x32(0x1)
	char pad_51[1];  // 0x33(0x1)
	int32_t K2Node_CustomEvent___kills;  // 0x34(0x4)
	int32_t K2Node_CustomEvent__ChampionKills;  // 0x38(0x4)
	float K2Node_CustomEvent___Damage;  // 0x3C(0x4)
	int32_t K2Node_CustomEvent__wood;  // 0x40(0x4)
	int32_t K2Node_CustomEvent__binder;  // 0x44(0x4)
	int32_t K2Node_CustomEvent__metal;  // 0x48(0x4)
	int32_t K2Node_CustomEvent__RpBonus;  // 0x4C(0x4)
	struct TArray<struct FSteamItemDetails> K2Node_CustomEvent_SteamItems;  // 0x50(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x64(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x68(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x6C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x70(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x74(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Player;  // 0x80(0x8)
	struct FString K2Node_CustomEvent_SteamID;  // 0x88(0x10)
	struct FString K2Node_CustomEvent_TeammateID;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0xA8(0x1)

}; 
// Function BR_PS.BR_PS_C.Set Steam Items
// Size: 0x10(Inherited: 0x0) 
struct FSet Steam Items
{
	struct TArray<struct FSteamItemDetails> SteamItems;  // 0x0(0x10)

}; 
// Function BR_PS.BR_PS_C.ServerSetID
// Size: 0x10(Inherited: 0x0) 
struct FServerSetID
{
	struct FString SteamID;  // 0x0(0x10)

}; 
// Function BR_PS.BR_PS_C.ChangeStats
// Size: 0x1C(Inherited: 0x0) 
struct FChangeStats
{
	int32_t + kills;  // 0x0(0x4)
	int32_t +ChampionKills;  // 0x4(0x4)
	float + Damage;  // 0x8(0x4)
	int32_t +wood;  // 0xC(0x4)
	int32_t +binder;  // 0x10(0x4)
	int32_t +metal;  // 0x14(0x4)
	int32_t +RpBonus;  // 0x18(0x4)

}; 
// Function BR_PS.BR_PS_C.GetStats
// Size: 0x74(Inherited: 0x0) 
struct FGetStats
{
	struct APlayerBRController_C* Controller;  // 0x0(0x8)
	struct FST_Stats Stats;  // 0x8(0x24)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x30(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[2];  // 0x42(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x48(0x4)
	int32_t K2Node_Select_Default;  // 0x4C(0x4)
	struct FST_Stats K2Node_MakeStruct_ST_Stats;  // 0x50(0x24)

}; 
