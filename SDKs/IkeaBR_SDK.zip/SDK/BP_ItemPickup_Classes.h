#pragma once 
#include <BP_ItemPickup_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ItemPickup.BP_ItemPickup_C
// Size: 0x2D3(Inherited: 0x220) 
struct ABP_ItemPickup_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* OutlineMesh (DEPRECATED);  // 0x228(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x230(0x8)
	struct FST_ItemBase Item;  // 0x238(0x90)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool BP? : 1;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	float Damage;  // 0x2CC(0x4)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Static : 1;  // 0x2D0(0x1)
	char pad_721_1 : 7;  // 0x2D1(0x1)
	bool AlreadyTriedGettingItem? : 1;  // 0x2D1(0x1)
	char pad_722_1 : 7;  // 0x2D2(0x1)
	bool AvailableForPickup : 1;  // 0x2D2(0x1)

	void RecieveServerLook(bool& Recieve?); // Function BP_ItemPickup.BP_ItemPickup_C.RecieveServerLook
	void ToolTipOnLook(struct AFirstPersonCharacter_C* Caller, struct FString& tool tip, struct FString& sub tip); // Function BP_ItemPickup.BP_ItemPickup_C.ToolTipOnLook
	void SetCantPickup(bool Cant Pickup); // Function BP_ItemPickup.BP_ItemPickup_C.SetCantPickup
	void CanPickup(bool& CanPickup); // Function BP_ItemPickup.BP_ItemPickup_C.CanPickup
	void GetItem(struct FST_ItemBase& Item); // Function BP_ItemPickup.BP_ItemPickup_C.GetItem
	void TryPickup(struct AFirstPersonCharacter_C* Player); // Function BP_ItemPickup.BP_ItemPickup_C.TryPickup
	void OnRep_Item(); // Function BP_ItemPickup.BP_ItemPickup_C.OnRep_Item
	void OnRep_Damage(); // Function BP_ItemPickup.BP_ItemPickup_C.OnRep_Damage
	void UserConstructionScript(); // Function BP_ItemPickup.BP_ItemPickup_C.UserConstructionScript
	void OnChargeUpdate(float Charge, struct AFirstPersonCharacter_C* Caller); // Function BP_ItemPickup.BP_ItemPickup_C.OnChargeUpdate
	void ServerOnLook(struct AFirstPersonCharacter_C* Player); // Function BP_ItemPickup.BP_ItemPickup_C.ServerOnLook
	void ServerOnStopLook(struct AFirstPersonCharacter_C* Player); // Function BP_ItemPickup.BP_ItemPickup_C.ServerOnStopLook
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function BP_ItemPickup.BP_ItemPickup_C.OnInteract
	void Server_Pickup(struct AActor*& Caller, struct AActor* Target); // Function BP_ItemPickup.BP_ItemPickup_C.Server_Pickup
	void Server_Destroy(); // Function BP_ItemPickup.BP_ItemPickup_C.Server_Destroy
	void MultiSetMesh(struct UStaticMesh* NewMesh, bool bSimulate); // Function BP_ItemPickup.BP_ItemPickup_C.MultiSetMesh
	void ReceiveBeginPlay(); // Function BP_ItemPickup.BP_ItemPickup_C.ReceiveBeginPlay
	void BndEvt__StaticMesh_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_ItemPickup.BP_ItemPickup_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
	void MultiSound(struct FVector Location); // Function BP_ItemPickup.BP_ItemPickup_C.MultiSound
	void ServerSetAmmo(int32_t Ammo); // Function BP_ItemPickup.BP_ItemPickup_C.ServerSetAmmo
	void ServerChangeAmmo(int32_t Ammo); // Function BP_ItemPickup.BP_ItemPickup_C.ServerChangeAmmo
	void OnLook(struct AFirstPersonCharacter_C* Caller); // Function BP_ItemPickup.BP_ItemPickup_C.OnLook
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function BP_ItemPickup.BP_ItemPickup_C.OnStopLook
	void ReceiveTick(float DeltaSeconds); // Function BP_ItemPickup.BP_ItemPickup_C.ReceiveTick
	void PlaySound(); // Function BP_ItemPickup.BP_ItemPickup_C.PlaySound
	void MultiSetPhysics(bool bSimulate); // Function BP_ItemPickup.BP_ItemPickup_C.MultiSetPhysics
	void MultiSetCollision(float Damage); // Function BP_ItemPickup.BP_ItemPickup_C.MultiSetCollision
	void BndEvt__StaticMesh_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_ItemPickup.BP_ItemPickup_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
	void LoadActorState(); // Function BP_ItemPickup.BP_ItemPickup_C.LoadActorState
	void PlayerTryPickup(struct AFirstPersonCharacter_C* Player); // Function BP_ItemPickup.BP_ItemPickup_C.PlayerTryPickup
	void ReceiveDestroyed(); // Function BP_ItemPickup.BP_ItemPickup_C.ReceiveDestroyed
	void ExecuteUbergraph_BP_ItemPickup(int32_t EntryPoint); // Function BP_ItemPickup.BP_ItemPickup_C.ExecuteUbergraph_BP_ItemPickup
}; 



