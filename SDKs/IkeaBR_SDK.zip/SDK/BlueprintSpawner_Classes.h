#pragma once 
#include <BlueprintSpawner_Structs.h>
 
 
 
// BlueprintGeneratedClass BlueprintSpawner.BlueprintSpawner_C
// Size: 0x2FD(Inherited: 0x220) 
struct ABlueprintSpawner_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBillboardComponent* Billboard;  // 0x228(0x8)
	struct USphereComponent* Sphere;  // 0x230(0x8)
	struct USceneComponent* LootSpawn1;  // 0x238(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x240(0x8)
	struct TMap<int32_t, int32_t> CustomLootTable;  // 0x248(0x50)
	float ChanceToSpawn;  // 0x298(0x4)
	char pad_668_1 : 7;  // 0x29C(0x1)
	bool Static? : 1;  // 0x29C(0x1)
	char pad_669[3];  // 0x29D(0x3)
	struct TArray<int32_t> CommonRecipeIDs;  // 0x2A0(0x10)
	struct TArray<int32_t> UncommonRecipeIDs;  // 0x2B0(0x10)
	struct TArray<int32_t> RareRecipeIDs;  // 0x2C0(0x10)
	struct TArray<int32_t> LegendaryRecipeIDs;  // 0x2D0(0x10)
	struct AFirstPersonCharacter_C* Player;  // 0x2E0(0x8)
	struct FString RandomDeckName;  // 0x2E8(0x10)
	float SpawnRadius;  // 0x2F8(0x4)
	char pad_764_1 : 7;  // 0x2FC(0x1)
	bool RandomOffset : 1;  // 0x2FC(0x1)

	void GetRandomRecipeFromID's(char E_Tier Rarity, struct TArray<int32_t>& RecipeID's, int32_t& Value); // Function BlueprintSpawner.BlueprintSpawner_C.GetRandomRecipeFromID's
	void GetWeightMap(struct TArray<int32_t>& RecipeID's, struct TMap<int32_t, int32_t>& Out1); // Function BlueprintSpawner.BlueprintSpawner_C.GetWeightMap
	void SpawnRarety(int32_t& RecipeID); // Function BlueprintSpawner.BlueprintSpawner_C.SpawnRarety
	void UserConstructionScript(); // Function BlueprintSpawner.BlueprintSpawner_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BlueprintSpawner.BlueprintSpawner_C.ReceiveBeginPlay
	void Spawn(); // Function BlueprintSpawner.BlueprintSpawner_C.Spawn
	void ExecuteUbergraph_BlueprintSpawner(int32_t EntryPoint); // Function BlueprintSpawner.BlueprintSpawner_C.ExecuteUbergraph_BlueprintSpawner
}; 



