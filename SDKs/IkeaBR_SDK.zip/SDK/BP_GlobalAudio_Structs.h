#pragma once 
#include "SDK.h" 
 
 
// Function BP_GlobalAudio.BP_GlobalAudio_C.ExecuteUbergraph_BP_GlobalAudio
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_BP_GlobalAudio
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USoundBase* K2Node_CustomEvent_NewSound;  // 0x8(0x8)
	float K2Node_CustomEvent_FadeInDuration;  // 0x10(0x4)

}; 
// Function BP_GlobalAudio.BP_GlobalAudio_C.PlaySound
// Size: 0xC(Inherited: 0x0) 
struct FPlaySound
{
	struct USoundBase* NewSound;  // 0x0(0x8)
	float fadeInDuration;  // 0x8(0x4)

}; 
