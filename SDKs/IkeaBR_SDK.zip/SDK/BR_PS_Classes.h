#pragma once 
#include <BR_PS_Structs.h>
 
 
 
// BlueprintGeneratedClass BR_PS.BR_PS_C
// Size: 0x398(Inherited: 0x320) 
struct ABR_PS_C : public APlayerState
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x320(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x328(0x8)
	struct FST_Stats Stats;  // 0x330(0x24)
	char pad_852[4];  // 0x354(0x4)
	struct TArray<struct FSteamItemDetails> SteamItems;  // 0x358(0x10)
	struct AFirstPersonCharacter_C* Player;  // 0x368(0x8)
	struct FString SteamID;  // 0x370(0x10)
	struct FString TeammateID;  // 0x380(0x10)
	struct APlayerBRController_C* PlayerController;  // 0x390(0x8)

	void GetStats(struct APlayerBRController_C* Controller, struct FST_Stats& Stats); // Function BR_PS.BR_PS_C.GetStats
	void ChangeStats(int32_t + kills, int32_t +ChampionKills, float + Damage, int32_t +wood, int32_t +binder, int32_t +metal, int32_t +RpBonus); // Function BR_PS.BR_PS_C.ChangeStats
	void Set Steam Items(struct TArray<struct FSteamItemDetails>& SteamItems); // Function BR_PS.BR_PS_C.Set Steam Items
	void ServerSetPlayer(struct AFirstPersonCharacter_C* Player); // Function BR_PS.BR_PS_C.ServerSetPlayer
	void ServerSetID(struct FString SteamID); // Function BR_PS.BR_PS_C.ServerSetID
	void ServerSetTeammateID(struct FString TeammateID); // Function BR_PS.BR_PS_C.ServerSetTeammateID
	void ExecuteUbergraph_BR_PS(int32_t EntryPoint); // Function BR_PS.BR_PS_C.ExecuteUbergraph_BR_PS
}; 



