#pragma once 
#include <BP_Trampoline_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Trampoline.BP_Trampoline_C
// Size: 0x2E4(Inherited: 0x2B0) 
struct ABP_Trampoline_C : public AMovable_Object_Replicated_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B0(0x8)
	struct UAudioComponent* BounceSound;  // 0x2B8(0x8)
	float LaunchStrength;  // 0x2C0(0x4)
	float Clamp;  // 0x2C4(0x4)
	float SpawnChance;  // 0x2C8(0x4)
	struct FVector IncomingVelocityMultiplier;  // 0x2CC(0xC)
	struct FDateTime LastBounceTime;  // 0x2D8(0x8)
	float MinTimeBetweenBounces;  // 0x2E0(0x4)

	void ReceiveBeginPlay(); // Function BP_Trampoline.BP_Trampoline_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_Trampoline.BP_Trampoline_C.ReceiveTick
	void BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Trampoline.BP_Trampoline_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void PlayBounce(float NewPitchMultiplier, float NewVolumeMultiplier); // Function BP_Trampoline.BP_Trampoline_C.PlayBounce
	void ServerPlayBounce(float NewPitchMultiplier, float NewVolumeMultiplier); // Function BP_Trampoline.BP_Trampoline_C.ServerPlayBounce
	void ExecuteUbergraph_BP_Trampoline(int32_t EntryPoint); // Function BP_Trampoline.BP_Trampoline_C.ExecuteUbergraph_BP_Trampoline
}; 



