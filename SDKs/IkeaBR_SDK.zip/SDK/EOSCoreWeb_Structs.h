#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct EOSCoreWeb.AuthAccessTokenCallbackData
// Size: 0x98(Inherited: 0x0) 
struct FAuthAccessTokenCallbackData
{
	struct FString AccessToken;  // 0x0(0x10)
	int32_t ExpiresIn;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString ExpiresAt;  // 0x18(0x10)
	struct FString AccountId;  // 0x28(0x10)
	struct FString ClientId;  // 0x38(0x10)
	struct FString ApplicationId;  // 0x48(0x10)
	struct FString TokenId;  // 0x58(0x10)
	struct FString RefreshToken;  // 0x68(0x10)
	struct FString RefreshExpires;  // 0x78(0x10)
	struct FString RefreshExpiresAt;  // 0x88(0x10)

}; 
// DelegateFunction EOSCoreWeb.AccessTokenCallbackDelegate__DelegateSignature
// Size: 0xB8(Inherited: 0x0) 
struct FAccessTokenCallbackDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FAccessTokenCallbackData Data;  // 0x8(0x98)
	struct FWebResponse WebResponse;  // 0xA0(0x18)

}; 
// DelegateFunction EOSCoreWeb.SubmitTicketCallbackDelegate__DelegateSignature
// Size: 0xE0(Inherited: 0x0) 
struct FSubmitTicketCallbackDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FSubmitTicketResponse Response;  // 0x8(0xC0)
	struct FWebResponse WebResponse;  // 0xC8(0x18)

}; 
// ScriptStruct EOSCoreWeb.WebResponse
// Size: 0x18(Inherited: 0x0) 
struct FWebResponse
{
	int32_t Code;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString Message;  // 0x8(0x10)

}; 
// DelegateFunction EOSCoreWeb.AuthAccessTokenCallbackDelegate__DelegateSignature
// Size: 0xB8(Inherited: 0x0) 
struct FAuthAccessTokenCallbackDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FAuthAccessTokenCallbackData Data;  // 0x8(0x98)
	struct FWebResponse WebResponse;  // 0xA0(0x18)

}; 
// ScriptStruct EOSCoreWeb.AccessTokenCallbackData
// Size: 0x98(Inherited: 0x0) 
struct FAccessTokenCallbackData
{
	struct FString AccessToken;  // 0x0(0x10)
	struct FString TokenType;  // 0x10(0x10)
	struct FString ExpiresAt;  // 0x20(0x10)
	int32_t ExpiresIn;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FString Nonce;  // 0x38(0x10)
	struct TArray<struct FString> Features;  // 0x48(0x10)
	struct FString OrganizationId;  // 0x58(0x10)
	struct FString ProductId;  // 0x68(0x10)
	struct FString SandboxId;  // 0x78(0x10)
	struct FString DeploymentId;  // 0x88(0x10)

}; 
// DelegateFunction EOSCoreWeb.OnPublicIpResponse__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnPublicIpResponse__DelegateSignature
{
	struct FString Response;  // 0x0(0x10)

}; 
// ScriptStruct EOSCoreWeb.CreateRoomTokenCallback
// Size: 0x50(Inherited: 0x0) 
struct FCreateRoomTokenCallback
{
	struct FString RoomName;  // 0x0(0x10)
	struct FString DeploymentId;  // 0x10(0x10)
	struct FString ClientBaseUrl;  // 0x20(0x10)
	struct FString token;  // 0x30(0x10)
	struct FString Puid;  // 0x40(0x10)

}; 
// DelegateFunction EOSCoreWeb.CreateRoomTokenCallbackDelegate__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FCreateRoomTokenCallbackDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FCreateRoomTokenCallback Data;  // 0x8(0x50)
	struct FWebResponse WebResponse;  // 0x58(0x18)

}; 
// DelegateFunction EOSCoreWeb.RemoveParticipantCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FRemoveParticipantCallbackDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FWebResponse WebResponse;  // 0x8(0x18)

}; 
// DelegateFunction EOSCoreWeb.ModifyParticipantCallbackDelegate__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FModifyParticipantCallbackDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FWebResponse WebResponse;  // 0x8(0x18)

}; 
// Function EOSCoreWeb.EOSWebVoiceLibrary.RemoveParticipant
// Size: 0x50(Inherited: 0x0) 
struct FRemoveParticipant
{
	struct FString AccessToken;  // 0x0(0x10)
	struct FString ProductUserId;  // 0x10(0x10)
	struct FString DeploymentId;  // 0x20(0x10)
	struct FString RoomName;  // 0x30(0x10)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// ScriptStruct EOSCoreWeb.SubmitTicketResponse
// Size: 0xC0(Inherited: 0x0) 
struct FSubmitTicketResponse
{
	struct FString ProdName;  // 0x0(0x10)
	struct FString ProdSlug;  // 0x10(0x10)
	struct FString Guid;  // 0x20(0x10)
	struct FString SenderName;  // 0x30(0x10)
	struct FString SenderEmail;  // 0x40(0x10)
	struct FString Subject;  // 0x50(0x10)
	struct FString Message;  // 0x60(0x10)
	struct FString ErrorCode;  // 0x70(0x10)
	struct FString SystemOS;  // 0x80(0x10)
	struct FString SystemAntiMalware;  // 0x90(0x10)
	struct FString SystemOther;  // 0xA0(0x10)
	struct FString Timestamp;  // 0xB0(0x10)

}; 
// ScriptStruct EOSCoreWeb.InitiateEpicAuthenticationRequest
// Size: 0x38(Inherited: 0x0) 
struct FInitiateEpicAuthenticationRequest
{
	struct FString ClientId;  // 0x0(0x10)
	struct FString RedirectURI;  // 0x10(0x10)
	struct FString Scope;  // 0x20(0x10)
	int32_t Timeout;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// DelegateFunction EOSCoreWeb.InitiateEpicAuthenticationCallbackDelegate__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FInitiateEpicAuthenticationCallbackDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString AuthenticationCode;  // 0x8(0x10)
	struct FString errorMessage;  // 0x18(0x10)

}; 
// ScriptStruct EOSCoreWeb.RequestAuthAccessTokenRequest
// Size: 0x88(Inherited: 0x0) 
struct FRequestAuthAccessTokenRequest
{
	uint8_t  GrantType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString DeploymentId;  // 0x8(0x10)
	struct FString Username;  // 0x18(0x10)
	struct FString Password;  // 0x28(0x10)
	struct FString ExchangeCode;  // 0x38(0x10)
	struct FString Code;  // 0x48(0x10)
	struct FWebClientCredentials Credentials;  // 0x58(0x20)
	struct FString Scope;  // 0x78(0x10)

}; 
// ScriptStruct EOSCoreWeb.WebClientCredentials
// Size: 0x20(Inherited: 0x0) 
struct FWebClientCredentials
{
	struct FString ClientId;  // 0x0(0x10)
	struct FString ClientSecret;  // 0x10(0x10)

}; 
// ScriptStruct EOSCoreWeb.RequestAccessTokenRequest
// Size: 0x40(Inherited: 0x0) 
struct FRequestAccessTokenRequest
{
	struct FWebClientCredentials Credentials;  // 0x0(0x20)
	struct FString DeploymentId;  // 0x20(0x10)
	struct FString AdditionalData;  // 0x30(0x10)

}; 
// ScriptStruct EOSCoreWeb.SubmitTicketRequest
// Size: 0x88(Inherited: 0x0) 
struct FSubmitTicketRequest
{
	uint8_t  Subject;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Message;  // 0x8(0x10)
	struct FString SenderEmail;  // 0x18(0x10)
	struct FString SenderName;  // 0x28(0x10)
	struct FString Guid;  // 0x38(0x10)
	struct FString ErrorCode;  // 0x48(0x10)
	struct FString SystemOS;  // 0x58(0x10)
	struct FString SystemAntiMalware;  // 0x68(0x10)
	struct FString SystemOther;  // 0x78(0x10)

}; 
// ScriptStruct EOSCoreWeb.WebRequestParticipantData
// Size: 0x28(Inherited: 0x0) 
struct FWebRequestParticipantData
{
	struct FString ProductUserId;  // 0x0(0x10)
	struct FString ClientIp;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bHardMuted : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EOSCoreWeb.EOSWebAuthLibrary.InitiateEpicAuthentication
// Size: 0x48(Inherited: 0x0) 
struct FInitiateEpicAuthentication
{
	struct FDelegate Callback;  // 0x0(0x10)
	struct FInitiateEpicAuthenticationRequest Request;  // 0x10(0x38)

}; 
// Function EOSCoreWeb.EOSWebAuthLibrary.RequestAuthAccessToken
// Size: 0x98(Inherited: 0x0) 
struct FRequestAuthAccessToken
{
	struct FDelegate Callback;  // 0x0(0x10)
	struct FRequestAuthAccessTokenRequest Request;  // 0x10(0x88)

}; 
// Function EOSCoreWeb.EOSWebConnectLibrary.RequestAccessToken
// Size: 0x50(Inherited: 0x0) 
struct FRequestAccessToken
{
	struct FRequestAccessTokenRequest Request;  // 0x0(0x40)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCoreWeb.EOSWebPlayerTicketLibrary.SubmitTicket
// Size: 0xA8(Inherited: 0x0) 
struct FSubmitTicket
{
	struct FString WebApiKey;  // 0x0(0x10)
	struct FSubmitTicketRequest Request;  // 0x10(0x88)
	struct FDelegate Callback;  // 0x98(0x10)

}; 
// Function EOSCoreWeb.EOSWebShared.GetPublicIp
// Size: 0x10(Inherited: 0x0) 
struct FGetPublicIp
{
	struct FDelegate Callback;  // 0x0(0x10)

}; 
// Function EOSCoreWeb.EOSWebVoiceLibrary.CreateRoomToken
// Size: 0x50(Inherited: 0x0) 
struct FCreateRoomToken
{
	struct FString AccessToken;  // 0x0(0x10)
	struct TArray<struct FWebRequestParticipantData> Participants;  // 0x10(0x10)
	struct FString DeploymentId;  // 0x20(0x10)
	struct FString RoomName;  // 0x30(0x10)
	struct FDelegate Callback;  // 0x40(0x10)

}; 
// Function EOSCoreWeb.EOSWebVoiceLibrary.ModifyParticipant
// Size: 0x58(Inherited: 0x0) 
struct FModifyParticipant
{
	struct FString AccessToken;  // 0x0(0x10)
	struct FString ProductUserId;  // 0x10(0x10)
	struct FString DeploymentId;  // 0x20(0x10)
	struct FString RoomName;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bHardMuted : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FDelegate Callback;  // 0x44(0x10)
	char pad_84[4];  // 0x54(0x4)

}; 
