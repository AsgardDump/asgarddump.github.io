#pragma once 
#include <EOSCore_Structs.h>
 
 
 
// Class EOSCore.EOSCoreSubsystem
// Size: 0x30(Inherited: 0x30) 
struct UEOSCoreSubsystem : public UGameInstanceSubsystem
{

}; 



// Class EOSCore.CoreLeaderboards
// Size: 0x30(Inherited: 0x30) 
struct UCoreLeaderboards : public UEOSCoreSubsystem
{

	struct UCoreLeaderboards* GetLeaderboards(struct UObject* worldContextObject); // Function EOSCore.CoreLeaderboards.GetLeaderboards
	void EOSLeaderboardsQueryLeaderboardUserScores(struct UObject* worldContextObject, struct FEOSLeaderboardsQueryLeaderboardUserScoresOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsQueryLeaderboardUserScores
	void EOSLeaderboardsQueryLeaderboardRanks(struct UObject* worldContextObject, struct FEOSLeaderboardsQueryLeaderboardRanksOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsQueryLeaderboardRanks
	void EOSLeaderboardsQueryLeaderboardDefinitions(struct UObject* worldContextObject, struct FEOSLeaderboardsQueryLeaderboardDefinitionsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsQueryLeaderboardDefinitions
	int32_t EOSLeaderboardsGetLeaderboardUserScoreCount(struct UObject* worldContextObject, struct FEOSLeaderboardsGetLeaderboardUserScoreCountOptions Options); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsGetLeaderboardUserScoreCount
	int32_t EOSLeaderboardsGetLeaderboardRecordCount(struct UObject* worldContextObject, struct FEOSLeaderboardsGetLeaderboardRecordCountOptions Options); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsGetLeaderboardRecordCount
	int32_t EOSLeaderboardsGetLeaderboardDefinitionCount(struct UObject* worldContextObject, struct FEOSLeaderboardsGetLeaderboardDefinitionCountOptions Options); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsGetLeaderboardDefinitionCount
	uint8_t  EOSLeaderboardsCopyLeaderboardUserScoreByUserId(struct UObject* worldContextObject, struct FEOSLeaderboardsCopyLeaderboardUserScoreByUserIdOptions Options, struct FEOSLeaderboardsLeaderboardUserScore& OutLeaderboardUserScore); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardUserScoreByUserId
	uint8_t  EOSLeaderboardsCopyLeaderboardUserScoreByIndex(struct UObject* worldContextObject, struct FEOSLeaderboardsCopyLeaderboardUserScoreByIndexOptions Options, struct FEOSLeaderboardsLeaderboardUserScore& OutLeaderboardUserScore); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardUserScoreByIndex
	uint8_t  EOSLeaderboardsCopyLeaderboardRecordByUserId(struct UObject* worldContextObject, struct FEOSLeaderboardsCopyLeaderboardRecordByUserIdOptions Options, struct FEOSLeaderboardsLeaderboardRecord& OutLeaderboardRecord); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardRecordByUserId
	uint8_t  EOSLeaderboardsCopyLeaderboardRecordByIndex(struct UObject* worldContextObject, struct FEOSLeaderboardsCopyLeaderboardRecordByIndexOptions Options, struct FEOSLeaderboardsLeaderboardRecord& OutLeaderboardRecord); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardRecordByIndex
	uint8_t  EOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardId(struct UObject* worldContextObject, struct FEOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardIdOptions Options, struct FEOSLeaderboardsDefinition& OutLeaderboardDefinition); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardDefinitionByLeaderboardId
	uint8_t  EOSLeaderboardsCopyLeaderboardDefinitionByIndex(struct UObject* worldContextObject, struct FEOSLeaderboardsCopyLeaderboardDefinitionByIndexOptions Options, struct FEOSLeaderboardsDefinition& OutLeaderboardDefinition); // Function EOSCore.CoreLeaderboards.EOSLeaderboardsCopyLeaderboardDefinitionByIndex
}; 



// Class EOSCore.EOSCoreEcomQueryOwnershipToken
// Size: 0xA8(Inherited: 0x38) 
struct UEOSCoreEcomQueryOwnershipToken : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[96];  // 0x48(0x60)

	void HandleCallback(struct FEOSEcomQueryOwnershipTokenCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreEcomQueryOwnershipToken.HandleCallback
	struct UEOSCoreEcomQueryOwnershipToken* EOSEcomQueryOwnershipTokenAsync(struct UObject* worldContextObject, struct FEOSEcomQueryOwnershipTokenOptions Options); // Function EOSCore.EOSCoreEcomQueryOwnershipToken.EOSEcomQueryOwnershipTokenAsync
}; 



// Class EOSCore.CoreAchievements
// Size: 0x80(Inherited: 0x30) 
struct UCoreAchievements : public UEOSCoreSubsystem
{
	char pad_48[80];  // 0x30(0x50)

	struct UCoreAchievements* GetAchievements(struct UObject* worldContextObject); // Function EOSCore.CoreAchievements.GetAchievements
	void EOSAchievementsUnlockAchievements(struct UObject* worldContextObject, struct FEOSAchievementsUnlockAchievementsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAchievements.EOSAchievementsUnlockAchievements
	void EOSAchievementsRemoveNotifyAchievementsUnlocked(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreAchievements.EOSAchievementsRemoveNotifyAchievementsUnlocked
	void EOSAchievementsQueryPlayerAchievements(struct UObject* worldContextObject, struct FEOSAchievementsQueryPlayerAchievementsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAchievements.EOSAchievementsQueryPlayerAchievements
	void EOSAchievementsQueryDefinitions(struct UObject* worldContextObject, struct FEOSAchievementsQueryDefinitionsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAchievements.EOSAchievementsQueryDefinitions
	int32_t EOSAchievementsGetPlayerAchievementCount(struct UObject* worldContextObject, struct FEOSAchievementsGetPlayerAchievementCountOptions Options); // Function EOSCore.CoreAchievements.EOSAchievementsGetPlayerAchievementCount
	int32_t EOSAchievementsGetAchievementDefinitionCount(struct UObject* worldContextObject, struct FEOSAchievementsGetAchievementDefinitionCountOptions Options); // Function EOSCore.CoreAchievements.EOSAchievementsGetAchievementDefinitionCount
	uint8_t  EOSAchievementsCopyPlayerAchievementByIndex(struct UObject* worldContextObject, struct FEOSAchievementsCopyPlayerAchievementByIndexOptions Options, struct FEOSAchievementsPlayerAchievement& OutAchievement); // Function EOSCore.CoreAchievements.EOSAchievementsCopyPlayerAchievementByIndex
	uint8_t  EOSAchievementsCopyAchievementDefinitionV2ByIndex(struct UObject* worldContextObject, struct FEOSAchievementsCopyAchievementDefinitionV2ByIndexOptions Options, struct FEOSAchievementsDefinitionV2& OutDefinition); // Function EOSCore.CoreAchievements.EOSAchievementsCopyAchievementDefinitionV2ByIndex
	uint8_t  EOSAchievementsCopyAchievementDefinitionV2ByAchievementId(struct UObject* worldContextObject, struct FEOSAchievementsCopyAchievementDefinitionV2ByAchievementIdOptions Options, struct FEOSAchievementsDefinitionV2& OutDefinition); // Function EOSCore.CoreAchievements.EOSAchievementsCopyAchievementDefinitionV2ByAchievementId
	struct FEOSNotificationId EOSAchievementsAddNotifyAchievementsUnlockedV2(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreAchievements.EOSAchievementsAddNotifyAchievementsUnlockedV2
}; 



// Class EOSCore.EOSCoreUserInfoByExternalAccount
// Size: 0x98(Inherited: 0x38) 
struct UEOSCoreUserInfoByExternalAccount : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[80];  // 0x48(0x50)

	void HandleCallback(struct FEOSUserInfoQueryUserInfoByExternalAccountCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreUserInfoByExternalAccount.HandleCallback
	struct UEOSCoreUserInfoByExternalAccount* EOSUserInfoQueryUserInfoByExternalAccountAsync(struct UObject* worldContextObject, struct FEOSUserInfoQueryUserInfoByExternalAccountOptions Options); // Function EOSCore.EOSCoreUserInfoByExternalAccount.EOSUserInfoQueryUserInfoByExternalAccountAsync
}; 



// Class EOSCore.EOSCoreFriendsAcceptInvite
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCoreFriendsAcceptInvite : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSFriendsAcceptInviteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreFriendsAcceptInvite.HandleCallback
	struct UEOSCoreFriendsAcceptInvite* EOSFriendsAcceptInviteAsync(struct UObject* worldContextObject, struct FEOSFriendsAcceptInviteOptions Options); // Function EOSCore.EOSCoreFriendsAcceptInvite.EOSFriendsAcceptInviteAsync
}; 



// Class EOSCore.EOSCoreEcomRedeemEntitlements
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreEcomRedeemEntitlements : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSEcomRedeemEntitlementsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreEcomRedeemEntitlements.HandleCallback
	struct UEOSCoreEcomRedeemEntitlements* EOSEcomRedeemEntitlementsAsync(struct UObject* worldContextObject, struct FEOSEcomRedeemEntitlementsOptions Options); // Function EOSCore.EOSCoreEcomRedeemEntitlements.EOSEcomRedeemEntitlementsAsync
}; 



// Class EOSCore.EOSCoreAchievementsUnlockAchievements
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreAchievementsUnlockAchievements : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSAchievementsOnUnlockAchievementsCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAchievementsUnlockAchievements.HandleCallback
	struct UEOSCoreAchievementsUnlockAchievements* EOSAchievementsUnlockAchievements(struct UObject* worldContextObject, struct FEOSAchievementsUnlockAchievementsOptions Options); // Function EOSCore.EOSCoreAchievementsUnlockAchievements.EOSAchievementsUnlockAchievements
}; 



// Class EOSCore.CoreAntiCheatServer
// Size: 0x120(Inherited: 0x30) 
struct UCoreAntiCheatServer : public UEOSCoreSubsystem
{
	char pad_48[240];  // 0x30(0xF0)

	struct UCoreAntiCheatServer* GetAntiCheatServer(struct UObject* worldContextObject); // Function EOSCore.CoreAntiCheatServer.GetAntiCheatServer
	uint8_t  EOSAntiCheatServerUnregisterClient(struct UObject* worldContextObject, struct FEOSAntiCheatServerUnregisterClientOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerUnregisterClient
	uint8_t  EOSAntiCheatServerUnprotectMessage(struct UObject* worldContextObject, struct FEOSAntiCheatServerUnprotectMessageOptions Options, struct TArray<char>& OutBuffer, int32_t& OutBufferLengthBytes); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerUnprotectMessage
	uint8_t  EOSAntiCheatServerSetGameSessionId(struct UObject* worldContextObject, struct FEOSAntiCheatCommonSetGameSessionIdOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerSetGameSessionId
	uint8_t  EOSAntiCheatServerSetClientNetworkState(struct UObject* worldContextObject, struct FEOSAntiCheatServerSetClientNetworkStateOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerSetClientNetworkState
	uint8_t  EOSAntiCheatServerSetClientDetails(struct UObject* worldContextObject, struct FEOSAntiCheatCommonSetClientDetailsOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerSetClientDetails
	void EOSAntiCheatServerRemoveNotifyMessageToClient(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRemoveNotifyMessageToClient
	void EOSAntiCheatServerRemoveNotifyClientAuthStatusChanged(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRemoveNotifyClientAuthStatusChanged
	void EOSAntiCheatServerRemoveNotifyClientActionRequired(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRemoveNotifyClientActionRequired
	uint8_t  EOSAntiCheatServerRegisterEvent(struct UObject* worldContextObject, struct FEOSAntiCheatCommonRegisterEventOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRegisterEvent
	uint8_t  EOSAntiCheatServerRegisterClient(struct UObject* worldContextObject, struct FEOSAntiCheatServerRegisterClientOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerRegisterClient
	uint8_t  EOSAntiCheatServerReceiveMessageFromClient(struct UObject* worldContextObject, struct FEOSAntiCheatServerReceiveMessageFromClientOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerReceiveMessageFromClient
	uint8_t  EOSAntiCheatServerProtectMessage(struct UObject* worldContextObject, struct FEOSAntiCheatServerProtectMessageOptions Options, struct TArray<char>& OutBuffer, int32_t& OutBufferLengthBytes); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerProtectMessage
	uint8_t  EOSAntiCheatServerLogPlayerUseWeapon(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogPlayerUseWeaponOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerUseWeapon
	uint8_t  EOSAntiCheatServerLogPlayerUseAbility(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogPlayerUseAbilityOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerUseAbility
	uint8_t  EOSAntiCheatServerLogPlayerTick(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogPlayerTickOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerTick
	uint8_t  EOSAntiCheatServerLogPlayerTakeDamage(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogPlayerTakeDamageOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerTakeDamage
	uint8_t  EOSAntiCheatServerLogPlayerSpawn(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogPlayerSpawnOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerSpawn
	uint8_t  EOSAntiCheatServerLogPlayerRevive(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogPlayerReviveOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerRevive
	uint8_t  EOSAntiCheatServerLogPlayerDespawn(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogPlayerDespawnOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogPlayerDespawn
	uint8_t  EOSAntiCheatServerLogGameRoundStart(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogGameRoundStartOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogGameRoundStart
	uint8_t  EOSAntiCheatServerLogGameRoundEnd(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogGameRoundEndOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogGameRoundEnd
	uint8_t  EOSAntiCheatServerLogEvent(struct UObject* worldContextObject, struct FEOSAntiCheatCommonLogEventOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerLogEvent
	uint8_t  EOSAntiCheatServerGetProtectMessageOutputLength(struct UObject* worldContextObject, struct FEOSAntiCheatServerGetProtectMessageOutputLengthOptions Options, int32_t& OutBufferLengthBytes); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerGetProtectMessageOutputLength
	uint8_t  EOSAntiCheatServerEndSession(struct UObject* worldContextObject, struct FEOSAntiCheatServerEndSessionOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerEndSession
	uint8_t  EOSAntiCheatServerBeginSession(struct UObject* worldContextObject, struct FEOSAntiCheatServerBeginSessionOptions Options); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerBeginSession
	struct FEOSNotificationId EOSAntiCheatServerAddNotifyMessageToClient(struct UObject* worldContextObject, struct FEOSAntiCheatServerAddNotifyMessageToClientOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerAddNotifyMessageToClient
	struct FEOSNotificationId EOSAntiCheatServerAddNotifyClientAuthStatusChanged(struct UObject* worldContextObject, struct FEOSAntiCheatServerAddNotifyClientAuthStatusChangedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerAddNotifyClientAuthStatusChanged
	struct FEOSNotificationId EOSAntiCheatServerAddNotifyClientActionRequired(struct UObject* worldContextObject, struct FEOSAntiCheatServerAddNotifyClientActionRequiredOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAntiCheatServer.EOSAntiCheatServerAddNotifyClientActionRequired
}; 



// Class EOSCore.EOSCorePlayerDataStorageQueryFileList
// Size: 0x80(Inherited: 0x38) 
struct UEOSCorePlayerDataStorageQueryFileList : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSPlayerDataStorageQueryFileListCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePlayerDataStorageQueryFileList.HandleCallback
	struct UEOSCorePlayerDataStorageQueryFileList* EOSPlayerDataStorageQueryFileListAsync(struct UObject* worldContextObject, struct FEOSPlayerDataStorageQueryFileListOptions QueryFileListOptions); // Function EOSCore.EOSCorePlayerDataStorageQueryFileList.EOSPlayerDataStorageQueryFileListAsync
}; 



// Class EOSCore.EOSCoreAsyncAction
// Size: 0x38(Inherited: 0x30) 
struct UEOSCoreAsyncAction : public UBlueprintAsyncActionBase
{
	char pad_48[8];  // 0x30(0x8)

}; 



// Class EOSCore.CoreLobby
// Size: 0x260(Inherited: 0x30) 
struct UCoreLobby : public UEOSCoreSubsystem
{
	char pad_48[560];  // 0x30(0x230)

	struct UCoreLobby* GetLobby(struct UObject* worldContextObject); // Function EOSCore.CoreLobby.GetLobby
	uint8_t  EOSLobbyUpdateLobbyModification(struct UObject* worldContextObject, struct FEOSLobbyUpdateLobbyModificationOptions Options, struct FEOSHLobbyModification& OutLobbyModificationHandle); // Function EOSCore.CoreLobby.EOSLobbyUpdateLobbyModification
	void EOSLobbyUpdateLobby(struct UObject* worldContextObject, struct FEOSLobbyUpdateLobbyOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyUpdateLobby
	void EOSLobbySendInvite(struct UObject* worldContextObject, struct FEOSLobbySendInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbySendInvite
	uint8_t  EOSLobbySearchSetTargetUserId(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchSetTargetUserIdOptions Options); // Function EOSCore.CoreLobby.EOSLobbySearchSetTargetUserId
	uint8_t  EOSLobbySearchSetParameterString(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FString Key, struct FString Value, uint8_t  ComparisonOp); // Function EOSCore.CoreLobby.EOSLobbySearchSetParameterString
	uint8_t  EOSLobbySearchSetParameterInt64(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FString Key, struct FString Value, uint8_t  ComparisonOp); // Function EOSCore.CoreLobby.EOSLobbySearchSetParameterInt64
	uint8_t  EOSLobbySearchSetParameterDouble(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FString Key, struct FString Value, uint8_t  ComparisonOp); // Function EOSCore.CoreLobby.EOSLobbySearchSetParameterDouble
	uint8_t  EOSLobbySearchSetParameterBool(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FString Key, bool bValue, uint8_t  ComparisonOp); // Function EOSCore.CoreLobby.EOSLobbySearchSetParameterBool
	uint8_t  EOSLobbySearchSetMaxResults(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchSetMaxResultsOptions Options); // Function EOSCore.CoreLobby.EOSLobbySearchSetMaxResults
	uint8_t  EOSLobbySearchSetLobbyId(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchSetLobbyIdOptions Options); // Function EOSCore.CoreLobby.EOSLobbySearchSetLobbyId
	uint8_t  EOSLobbySearchRemoveParameter(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchRemoveParameterOptions Options); // Function EOSCore.CoreLobby.EOSLobbySearchRemoveParameter
	void EOSLobbySearchRelease(struct FEOSHLobbySearch LobbySearchHandle); // Function EOSCore.CoreLobby.EOSLobbySearchRelease
	int32_t EOSLobbySearchGetSearchResultCount(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchGetSearchResultCountOptions Options); // Function EOSCore.CoreLobby.EOSLobbySearchGetSearchResultCount
	void EOSLobbySearchFind(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchFindOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbySearchFind
	uint8_t  EOSLobbySearchCopySearchResultByIndex(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchCopySearchResultByIndexOptions Options, struct FEOSHLobbyDetails& OutLobbyDetailsHandle); // Function EOSCore.CoreLobby.EOSLobbySearchCopySearchResultByIndex
	void EOSLobbyRemoveNotifyRTCRoomConnectionChanged(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyRTCRoomConnectionChanged
	void EOSLobbyRemoveNotifyLobbyUpdateReceived(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyUpdateReceived
	void EOSLobbyRemoveNotifyLobbyMemberUpdateReceived(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyMemberUpdateReceived
	void EOSLobbyRemoveNotifyLobbyMemberStatusReceived(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyMemberStatusReceived
	void EOSLobbyRemoveNotifyLobbyInviteReceived(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyInviteReceived
	void EOSLobbyRemoveNotifyLobbyInviteAccepted(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyLobbyInviteAccepted
	void EOSLobbyRemoveNotifyJoinLobbyAccepted(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreLobby.EOSLobbyRemoveNotifyJoinLobbyAccepted
	void EOSLobbyRejectInvite(struct UObject* worldContextObject, struct FEOSLobbyRejectInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyRejectInvite
	void EOSLobbyQueryInvites(struct UObject* worldContextObject, struct FEOSLobbyQueryInvitesOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyQueryInvites
	void EOSLobbyPromoteMember(struct UObject* worldContextObject, struct FEOSLobbyPromoteMemberOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyPromoteMember
	uint8_t  EOSLobbyModificationSetPermissionLevel(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FEOSLobbyModificationSetPermissionLevelOptions Options); // Function EOSCore.CoreLobby.EOSLobbyModificationSetPermissionLevel
	uint8_t  EOSLobbyModificationSetMaxMembers(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FEOSLobbyModificationSetMaxMembersOptions Options); // Function EOSCore.CoreLobby.EOSLobbyModificationSetMaxMembers
	uint8_t  EOSLobbyModificationSetInvitesAllowed(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FEOSLobbyModificationSetInvitesAllowedOptions Options); // Function EOSCore.CoreLobby.EOSLobbyModificationSetInvitesAllowed
	uint8_t  EOSLobbyModificationSetBucketId(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FEOSLobbyModificationSetBucketIdOptions Options); // Function EOSCore.CoreLobby.EOSLobbyModificationSetBucketId
	uint8_t  EOSLobbyModificationRemoveMemberAttribute(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FEOSLobbyModificationRemoveMemberAttributeOptions Options); // Function EOSCore.CoreLobby.EOSLobbyModificationRemoveMemberAttribute
	uint8_t  EOSLobbyModificationRemoveAttribute(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FEOSLobbyModificationRemoveAttributeOptions Options); // Function EOSCore.CoreLobby.EOSLobbyModificationRemoveAttribute
	void EOSLobbyModificationRelease(struct FEOSHLobbyModification LobbyModificationHandle); // Function EOSCore.CoreLobby.EOSLobbyModificationRelease
	uint8_t  EOSLobbyModificationAddMemberAttributeString(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, struct FString Value, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeString
	uint8_t  EOSLobbyModificationAddMemberAttributeInt64(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, struct FString Value, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeInt64
	uint8_t  EOSLobbyModificationAddMemberAttributeDouble(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, struct FString Value, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeDouble
	uint8_t  EOSLobbyModificationAddMemberAttributeBool(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, bool bValue, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddMemberAttributeBool
	uint8_t  EOSLobbyModificationAddAttributeString(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, struct FString Value, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeString
	uint8_t  EOSLobbyModificationAddAttributeInt64(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, struct FString Value, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeInt64
	uint8_t  EOSLobbyModificationAddAttributeDouble(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, struct FString Value, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeDouble
	uint8_t  EOSLobbyModificationAddAttributeBool(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FString Key, bool bValue, uint8_t  Visibility); // Function EOSCore.CoreLobby.EOSLobbyModificationAddAttributeBool
	uint8_t  EOSLobbyModificationAddAttribute(struct UObject* worldContextObject, struct FEOSHLobbyModification& Handle, struct FEOSLobbyModificationAddAttributeOptions Options); // Function EOSCore.CoreLobby.EOSLobbyModificationAddAttribute
	void EOSLobbyLeaveLobby(struct UObject* worldContextObject, struct FEOSLobbyLeaveLobbyOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyLeaveLobby
	void EOSLobbyKickMember(struct UObject* worldContextObject, struct FEOSLobbyKickMemberOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyKickMember
	void EOSLobbyJoinLobby(struct UObject* worldContextObject, struct FEOSLobbyJoinLobbyOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyJoinLobby
	uint8_t  EOSLobbyIsRTCRoomConnected(struct UObject* worldContextObject, struct FEOSLobbyIsRTCRoomConnectedOptions Options, bool& bOutIsConnected); // Function EOSCore.CoreLobby.EOSLobbyIsRTCRoomConnected
	uint8_t  EOSLobbyGetRTCRoomName(struct UObject* worldContextObject, struct FEOSLobbyGetRTCRoomNameOptions Options, struct FString& OutBuffer, int32_t InOutBufferLength); // Function EOSCore.CoreLobby.EOSLobbyGetRTCRoomName
	uint8_t  EOSLobbyGetInviteIdByIndex(struct UObject* worldContextObject, struct FEOSLobbyGetInviteIdByIndexOptions Options, struct FString& OutInviteId); // Function EOSCore.CoreLobby.EOSLobbyGetInviteIdByIndex
	int32_t EOSLobbyGetInviteCount(struct UObject* worldContextObject, struct FEOSLobbyGetInviteCountOptions Options); // Function EOSCore.CoreLobby.EOSLobbyGetInviteCount
	void EOSLobbyDetailsRelease(struct FEOSHLobbyDetails LobbyHandle); // Function EOSCore.CoreLobby.EOSLobbyDetailsRelease
	int32_t EOSLobbyDetailsGetMemberCount(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsGetMemberCountOptions Options); // Function EOSCore.CoreLobby.EOSLobbyDetailsGetMemberCount
	struct FEOSProductUserId EOSLobbyDetailsGetMemberByIndex(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsGetMemberByIndexOptions Options); // Function EOSCore.CoreLobby.EOSLobbyDetailsGetMemberByIndex
	int32_t EOSLobbyDetailsGetMemberAttributeCount(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsGetMemberAttributeCountOptions Options); // Function EOSCore.CoreLobby.EOSLobbyDetailsGetMemberAttributeCount
	struct FEOSProductUserId EOSLobbyDetailsGetLobbyOwner(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsGetLobbyOwnerOptions Options); // Function EOSCore.CoreLobby.EOSLobbyDetailsGetLobbyOwner
	int32_t EOSLobbyDetailsGetAttributeCount(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsGetAttributeCountOptions Options); // Function EOSCore.CoreLobby.EOSLobbyDetailsGetAttributeCount
	uint8_t  EOSLobbyDetailsCopyMemberAttributeByKey(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsCopyMemberAttributeByKeyOptions Options, struct FEOSLobbyAttribute& OutAttribute); // Function EOSCore.CoreLobby.EOSLobbyDetailsCopyMemberAttributeByKey
	uint8_t  EOSLobbyDetailsCopyMemberAttributeByIndex(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsCopyMemberAttributeByIndexOptions Options, struct FEOSLobbyAttribute& OutAttribute); // Function EOSCore.CoreLobby.EOSLobbyDetailsCopyMemberAttributeByIndex
	uint8_t  EOSLobbyDetailsCopyInfo(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsCopyInfoOptions Options, struct FEOSLobbyDetailsInfo& OutLobbyDetailsInfo); // Function EOSCore.CoreLobby.EOSLobbyDetailsCopyInfo
	uint8_t  EOSLobbyDetailsCopyAttributeByKey(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsCopyAttributeByKeyOptions Options, struct FEOSLobbyAttribute& OutAttribute); // Function EOSCore.CoreLobby.EOSLobbyDetailsCopyAttributeByKey
	uint8_t  EOSLobbyDetailsCopyAttributeByIndex(struct UObject* worldContextObject, struct FEOSHLobbyDetails& Handle, struct FEOSLobbyDetailsCopyAttributeByIndexOptions Options, struct FEOSLobbyAttribute& OutAttribute); // Function EOSCore.CoreLobby.EOSLobbyDetailsCopyAttributeByIndex
	void EOSLobbyDestroyLobby(struct UObject* worldContextObject, struct FEOSLobbyDestroyLobbyOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyDestroyLobby
	uint8_t  EOSLobbyCreateLobbySearch(struct UObject* worldContextObject, struct FEOSLobbyCreateLobbySearchOptions Options, struct FEOSHLobbySearch& OutLobbySearchHandle); // Function EOSCore.CoreLobby.EOSLobbyCreateLobbySearch
	void EOSLobbyCreateLobby(struct UObject* worldContextObject, struct FEOSLobbyCreateLobbyOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyCreateLobby
	uint8_t  EOSLobbyCopyLobbyDetailsHandleByUiEventId(struct UObject* worldContextObject, struct FEOSLobbyCopyLobbyDetailsHandleByUiEventIdOptions Options, struct FEOSHLobbyDetails& OutLobbyDetailsHandle); // Function EOSCore.CoreLobby.EOSLobbyCopyLobbyDetailsHandleByUiEventId
	uint8_t  EOSLobbyCopyLobbyDetailsHandleByInviteId(struct UObject* worldContextObject, struct FEOSLobbyCopyLobbyDetailsHandleByInviteIdOptions Options, struct FEOSHLobbyDetails& OutLobbyDetailsHandle); // Function EOSCore.CoreLobby.EOSLobbyCopyLobbyDetailsHandleByInviteId
	uint8_t  EOSLobbyCopyLobbyDetailsHandle(struct UObject* worldContextObject, struct FEOSLobbyCopyLobbyDetailsHandleOptions Options, struct FEOSHLobbyDetails& OutLobbyDetailsHandle); // Function EOSCore.CoreLobby.EOSLobbyCopyLobbyDetailsHandle
	struct FEOSNotificationId EOSLobbyAddNotifyRTCRoomConnectionChanged(struct UObject* worldContextObject, struct FEOSLobbyAddNotifyRTCRoomConnectionChangedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyAddNotifyRTCRoomConnectionChanged
	struct FEOSNotificationId EOSLobbyAddNotifyLobbyUpdateReceived(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyUpdateReceived
	struct FEOSNotificationId EOSLobbyAddNotifyLobbyMemberUpdateReceived(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyMemberUpdateReceived
	struct FEOSNotificationId EOSLobbyAddNotifyLobbyMemberStatusReceived(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyMemberStatusReceived
	struct FEOSNotificationId EOSLobbyAddNotifyLobbyInviteReceived(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyInviteReceived
	struct FEOSNotificationId EOSLobbyAddNotifyLobbyInviteAccepted(struct UObject* worldContextObject, struct FEOSLobbyAddNotifyLobbyInviteAcceptedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyAddNotifyLobbyInviteAccepted
	struct FEOSNotificationId EOSLobbyAddNotifyJoinLobbyAccepted(struct UObject* worldContextObject, struct FEOSLobbyAddNotifyJoinLobbyAcceptedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreLobby.EOSLobbyAddNotifyJoinLobbyAccepted
}; 



// Class EOSCore.EOSCoreLeaderboardsQueryLeaderboardRanks
// Size: 0x98(Inherited: 0x38) 
struct UEOSCoreLeaderboardsQueryLeaderboardRanks : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[80];  // 0x48(0x50)

	void HandleCallback(struct FEOSLeaderboardsOnQueryLeaderboardRanksCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardRanks.HandleCallback
	struct UEOSCoreLeaderboardsQueryLeaderboardRanks* EOSLeaderboardsQueryLeaderboardRanksAsync(struct UObject* worldContextObject, struct FEOSLeaderboardsQueryLeaderboardRanksOptions Options); // Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardRanks.EOSLeaderboardsQueryLeaderboardRanksAsync
}; 



// Class EOSCore.EOSCoreAchievementsQueryDefinitions
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreAchievementsQueryDefinitions : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSAchievementsOnQueryDefinitionsCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAchievementsQueryDefinitions.HandleCallback
	struct UEOSCoreAchievementsQueryDefinitions* EOSAchievementsQueryDefinitionsAsync(struct UObject* worldContextObject, struct FEOSAchievementsQueryDefinitionsOptions Options); // Function EOSCore.EOSCoreAchievementsQueryDefinitions.EOSAchievementsQueryDefinitionsAsync
}; 



// Class EOSCore.EOSCoreLibrary
// Size: 0x28(Inherited: 0x28) 
struct UEOSCoreLibrary : public UBlueprintFunctionLibrary
{

	bool UpdateUniqueNetIdFromOSS(struct APlayerController* PlayerController); // Function EOSCore.EOSCoreLibrary.UpdateUniqueNetIdFromOSS
	void RemoveListenForEOSMessages(struct UObject* worldContextObject); // Function EOSCore.EOSCoreLibrary.RemoveListenForEOSMessages
	struct FEOSSessionSetting MakeString(struct FString Value); // Function EOSCore.EOSCoreLibrary.MakeString
	struct FEOSSessionSearchSetting MakeSearchString(struct FString Value); // Function EOSCore.EOSCoreLibrary.MakeSearchString
	struct FEOSSessionSearchSetting MakeSearchInteger(int32_t Value); // Function EOSCore.EOSCoreLibrary.MakeSearchInteger
	struct FEOSSessionSearchSetting MakeSearchBool(bool Value); // Function EOSCore.EOSCoreLibrary.MakeSearchBool
	struct FEOSAntiCheatCommonLogEventParamPair MakeParamString(struct FString String); // Function EOSCore.EOSCoreLibrary.MakeParamString
	struct FEOSAntiCheatCommonLogEventParamPair MakeParamInt64(int64_t Value); // Function EOSCore.EOSCoreLibrary.MakeParamInt64
	struct FEOSAntiCheatCommonLogEventParamPair MakeParamInt32(int32_t Value); // Function EOSCore.EOSCoreLibrary.MakeParamInt32
	struct FEOSSessionSetting MakeInteger(int32_t Value); // Function EOSCore.EOSCoreLibrary.MakeInteger
	struct FEOSSessionSetting MakeBool(bool Value); // Function EOSCore.EOSCoreLibrary.MakeBool
	void Login(struct UObject* worldContextObject, struct APlayerController* PlayerController, struct FString LoginId, struct FString Password, uint8_t  AuthType, uint8_t  CredentialsType, struct FString AdditionalData, struct FDelegate& Callback); // Function EOSCore.EOSCoreLibrary.Login
	void ListenForEOSMessages(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.EOSCoreLibrary.ListenForEOSMessages
	bool IsProductUserIdIdenticalWith(struct FEOSProductUserId A, struct FEOSProductUserId B); // Function EOSCore.EOSCoreLibrary.IsProductUserIdIdenticalWith
	bool IsEpicAccountIdIdenticalWith(struct FEOSEpicAccountId A, struct FEOSEpicAccountId B); // Function EOSCore.EOSCoreLibrary.IsEpicAccountIdIdenticalWith
	struct FString GetString(struct FEOSSessionSetting Settings, struct FString& Key); // Function EOSCore.EOSCoreLibrary.GetString
	struct FString GetSessionAttributeString(struct FEOSSessionsAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetSessionAttributeString
	struct FString GetSessionAttributeInt64(struct FEOSSessionsAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetSessionAttributeInt64
	struct FString GetSessionAttributeDouble(struct FEOSSessionsAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetSessionAttributeDouble
	bool GetSessionAttributeBool(struct FEOSSessionsAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetSessionAttributeBool
	struct FString GetLobbyAttributeString(struct FEOSLobbyAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetLobbyAttributeString
	struct FString GetLobbyAttributeInt64(struct FEOSLobbyAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetLobbyAttributeInt64
	struct FString GetLobbyAttributeDouble(struct FEOSLobbyAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetLobbyAttributeDouble
	bool GetLobbyAttributeBool(struct FEOSLobbyAttributeData& Data); // Function EOSCore.EOSCoreLibrary.GetLobbyAttributeBool
	int32_t GetInteger(struct FEOSSessionSetting Settings, struct FString& Key); // Function EOSCore.EOSCoreLibrary.GetInteger
	struct FEOSProductUserId GetCurrentProductId(struct UObject* worldContextObject, int32_t UserIndex); // Function EOSCore.EOSCoreLibrary.GetCurrentProductId
	struct FEOSEpicAccountId GetCurrentAccountId(struct UObject* worldContextObject, int32_t UserIndex); // Function EOSCore.EOSCoreLibrary.GetCurrentAccountId
	bool GetBool(struct FEOSSessionSetting Settings, struct FString& Key); // Function EOSCore.EOSCoreLibrary.GetBool
	struct FDateTime FromUnixTimestamp(struct FString Timestamp); // Function EOSCore.EOSCoreLibrary.FromUnixTimestamp
	uint8_t  EOSProductUserIdToString(struct FEOSProductUserId ID, struct FString& String); // Function EOSCore.EOSCoreLibrary.EOSProductUserIdToString
	bool EOSProductUserIdIsValidPure(struct FEOSProductUserId ID); // Function EOSCore.EOSCoreLibrary.EOSProductUserIdIsValidPure
	bool EOSProductUserIdIsValid(struct FEOSProductUserId ID); // Function EOSCore.EOSCoreLibrary.EOSProductUserIdIsValid
	struct FEOSProductUserId EOSProductUserIdFromString(struct FString String); // Function EOSCore.EOSCoreLibrary.EOSProductUserIdFromString
	struct FString EOSEResultToString(uint8_t  Result); // Function EOSCore.EOSCoreLibrary.EOSEResultToString
	bool EOSEResultIsOperationComplete(uint8_t  Result); // Function EOSCore.EOSCoreLibrary.EOSEResultIsOperationComplete
	uint8_t  EOSEpicAccountIdToString(struct FEOSEpicAccountId ID, struct FString& String); // Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdToString
	bool EOSEpicAccountIdIsValidPure(struct FEOSEpicAccountId ID); // Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdIsValidPure
	bool EOSEpicAccountIdIsValid(struct FEOSEpicAccountId ID); // Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdIsValid
	struct FEOSEpicAccountId EOSEpicAccountIdFromString(struct FString String); // Function EOSCore.EOSCoreLibrary.EOSEpicAccountIdFromString
	uint8_t  EOSContinuanceTokenToString(struct FContinuanceToken ID, struct FString& String); // Function EOSCore.EOSCoreLibrary.EOSContinuanceTokenToString
	uint8_t  EOSByteArrayToString(struct TArray<char> Array, int32_t Length, struct FString& String); // Function EOSCore.EOSCoreLibrary.EOSByteArrayToString
	void EOS_Success(uint8_t  Status, uint8_t & Result); // Function EOSCore.EOSCoreLibrary.EOS_Success
	bool EOS_Initialized(struct UObject* worldContextObject); // Function EOSCore.EOSCoreLibrary.EOS_Initialized
	struct TArray<char> CoreStringToByte(struct FString String); // Function EOSCore.EOSCoreLibrary.CoreStringToByte
	struct FString CoreBytesToString(struct TArray<char>& Data); // Function EOSCore.EOSCoreLibrary.CoreBytesToString
	void BreakUIEventIdStruct(struct FEOSUIEventId EventId, struct FString& outEventId); // Function EOSCore.EOSCoreLibrary.BreakUIEventIdStruct
}; 



// Class EOSCore.EOSCoreAchievementsQueryPlayerAchievements
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCoreAchievementsQueryPlayerAchievements : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSAchievementsOnQueryPlayerAchievementsCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAchievementsQueryPlayerAchievements.HandleCallback
	struct UEOSCoreAchievementsQueryPlayerAchievements* EOSAchievementsQueryPlayerAchievementsAsync(struct UObject* worldContextObject, struct FEOSAchievementsQueryPlayerAchievementsOptions Options); // Function EOSCore.EOSCoreAchievementsQueryPlayerAchievements.EOSAchievementsQueryPlayerAchievementsAsync
}; 



// Class EOSCore.EOSCorePlayerDataStorageQueryFile
// Size: 0x90(Inherited: 0x38) 
struct UEOSCorePlayerDataStorageQueryFile : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSPlayerDataStorageQueryFileCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePlayerDataStorageQueryFile.HandleCallback
	struct UEOSCorePlayerDataStorageQueryFile* EOSPlayerDataStorageQueryFileAsync(struct UObject* worldContextObject, struct FEOSPlayerDataStorageQueryFileOptions QueryFileOptions); // Function EOSCore.EOSCorePlayerDataStorageQueryFile.EOSPlayerDataStorageQueryFileAsync
}; 



// Class EOSCore.CoreChat
// Size: 0x48(Inherited: 0x30) 
struct UCoreChat : public UEOSCoreSubsystem
{
	struct FMulticastInlineDelegate OnChatMessageReceived;  // 0x30(0x10)
	char pad_64[8];  // 0x40(0x8)

	void SendChatMessage(struct UObject* worldContextObject, struct FEOSProductUserId LocalUserId, struct FEOSProductUserId Target, struct FString Message, uint8_t  Reliability); // Function EOSCore.CoreChat.SendChatMessage
	void ListenForChatMessages(struct UObject* worldContextObject, struct FEOSProductUserId LocalUserId, struct FDelegate& Callback); // Function EOSCore.CoreChat.ListenForChatMessages
	struct UCoreChat* GetChat(); // Function EOSCore.CoreChat.GetChat
	void ClearAllChatListeners(); // Function EOSCore.CoreChat.ClearAllChatListeners
}; 



// Class EOSCore.CoreAntiCheatClient
// Size: 0x170(Inherited: 0x30) 
struct UCoreAntiCheatClient : public UEOSCoreSubsystem
{
	char pad_48[320];  // 0x30(0x140)

	struct UCoreAntiCheatClient* GetAntiCheatClient(struct UObject* worldContextObject); // Function EOSCore.CoreAntiCheatClient.GetAntiCheatClient
	uint8_t  EOSAntiCheatClientUnregisterPeer(struct UObject* worldContextObject, struct FEOSAntiCheatClientUnregisterPeerOptions Options); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientUnregisterPeer
	uint8_t  EOSAntiCheatClientUnprotectMessage(struct UObject* worldContextObject, struct FEOSAntiCheatClientUnprotectMessageOptions Options, struct TArray<char> OutBuffer); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientUnprotectMessage
	void EOSAntiCheatClientRemoveNotifyPeerAuthStatusChanged(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyPeerAuthStatusChanged
	void EOSAntiCheatClientRemoveNotifyPeerActionRequired(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyPeerActionRequired
	void EOSAntiCheatClientRemoveNotifyMessageToServer(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyMessageToServer
	void EOSAntiCheatClientRemoveNotifyMessageToPeer(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRemoveNotifyMessageToPeer
	uint8_t  EOSAntiCheatClientRegisterPeer(struct UObject* worldContextObject, struct FEOSAntiCheatClientRegisterPeerOptions Options); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientRegisterPeer
	uint8_t  EOSAntiCheatClientReceiveMessageFromServer(struct UObject* worldContextObject, struct FEOSAntiCheatClientReceiveMessageFromServerOptions Options); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientReceiveMessageFromServer
	uint8_t  EOSAntiCheatClientReceiveMessageFromPeer(struct UObject* worldContextObject, struct FEOSAntiCheatClientReceiveMessageFromPeerOptions Options); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientReceiveMessageFromPeer
	uint8_t  EOSAntiCheatClientProtectMessage(struct UObject* worldContextObject, struct FEOSAntiCheatClientProtectMessageOptions Options, struct TArray<char>& OutBuffer); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientProtectMessage
	uint8_t  EOSAntiCheatClientPollStatus(struct UObject* worldContextObject, struct FEOSAntiCheatClientPollStatusOptions Options, uint8_t & ViolationType, struct FString& OutMessage); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientPollStatus
	uint8_t  EOSAntiCheatClientGetProtectMessageOutputLength(struct UObject* worldContextObject, struct FEOSAntiCheatClientGetProtectMessageOutputLengthOptions Options, int32_t& OutBufferLengthBytes); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientGetProtectMessageOutputLength
	uint8_t  EOSAntiCheatClientEndSession(struct UObject* worldContextObject, struct FEOSAntiCheatClientEndSessionOptions Options); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientEndSession
	uint8_t  EOSAntiCheatClientBeginSession(struct UObject* worldContextObject, struct FEOSAntiCheatClientBeginSessionOptions Options); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientBeginSession
	struct FEOSNotificationId EOSAntiCheatClientAddNotifyPeerAuthStatusChanged(struct UObject* worldContextObject, struct FEOSAntiCheatClientAddNotifyPeerAuthStatusChangedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyPeerAuthStatusChanged
	struct FEOSNotificationId EOSAntiCheatClientAddNotifyPeerActionRequired(struct UObject* worldContextObject, struct FEOSAntiCheatClientAddNotifyPeerActionRequiredOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyPeerActionRequired
	struct FEOSNotificationId EOSAntiCheatClientAddNotifyMessageToServer(struct UObject* worldContextObject, struct FEOSAntiCheatClientAddNotifyMessageToServerOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyMessageToServer
	struct FEOSNotificationId EOSAntiCheatClientAddNotifyMessageToPeer(struct UObject* worldContextObject, struct FEOSAntiCheatClientAddNotifyMessageToPeerOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddNotifyMessageToPeer
	uint8_t  EOSAntiCheatClientAddExternalIntegrityCatalog(struct UObject* worldContextObject, struct FEOSAntiCheatClientAddExternalIntegrityCatalogOptions Options); // Function EOSCore.CoreAntiCheatClient.EOSAntiCheatClientAddExternalIntegrityCatalog
}; 



// Class EOSCore.EOSCorePlayerDataStorageDeleteFile
// Size: 0x90(Inherited: 0x38) 
struct UEOSCorePlayerDataStorageDeleteFile : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSPlayerDataStorageDeleteFileCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePlayerDataStorageDeleteFile.HandleCallback
	struct UEOSCorePlayerDataStorageDeleteFile* EOSPlayerDataStorageDeleteFileAsync(struct UObject* worldContextObject, struct FEOSPlayerDataStorageDeleteFileOptions DeleteOptions); // Function EOSCore.EOSCorePlayerDataStorageDeleteFile.EOSPlayerDataStorageDeleteFileAsync
}; 



// Class EOSCore.EOSCoreAuthLogin
// Size: 0x98(Inherited: 0x38) 
struct UEOSCoreAuthLogin : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[80];  // 0x48(0x50)

	void HandleCallback(struct FEOSAuthLoginCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAuthLogin.HandleCallback
	struct UEOSCoreAuthLogin* EOSAuthLoginAsync(struct UObject* worldContextObject, struct FEOSAuthLoginOptions Options); // Function EOSCore.EOSCoreAuthLogin.EOSAuthLoginAsync
}; 



// Class EOSCore.EOSCoreAuthLogout
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreAuthLogout : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSAuthLogoutCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAuthLogout.HandleCallback
	struct UEOSCoreAuthLogout* EOSAuthLogoutAsync(struct UObject* worldContextObject, struct FEOSAuthLogoutOptions Options); // Function EOSCore.EOSCoreAuthLogout.EOSAuthLogoutAsync
}; 



// Class EOSCore.EOSCoreAuthLinkAccount
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreAuthLinkAccount : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSAuthLinkAccountCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAuthLinkAccount.HandleCallback
	struct UEOSCoreAuthLinkAccount* EOSAuthLinkAccount(struct UObject* worldContextObject, struct FEOSAuthLinkAccountOptions Options); // Function EOSCore.EOSCoreAuthLinkAccount.EOSAuthLinkAccount
}; 



// Class EOSCore.EOSCoreAuthDeletePersistentAuth
// Size: 0x68(Inherited: 0x38) 
struct UEOSCoreAuthDeletePersistentAuth : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[32];  // 0x48(0x20)

	void HandleCallback(struct FEOSAuthDeletePersistentAuthCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAuthDeletePersistentAuth.HandleCallback
	struct UEOSCoreAuthDeletePersistentAuth* EOSAuthDeletePersistentAuthAsync(struct UObject* worldContextObject, struct FEOSAuthDeletePersistentAuthOptions& Options); // Function EOSCore.EOSCoreAuthDeletePersistentAuth.EOSAuthDeletePersistentAuthAsync
}; 



// Class EOSCore.EOSCoreAuthVerifyUserAuth
// Size: 0x108(Inherited: 0x38) 
struct UEOSCoreAuthVerifyUserAuth : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[192];  // 0x48(0xC0)

	void HandleCallback(struct FEOSAuthVerifyUserAuthCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreAuthVerifyUserAuth.HandleCallback
	struct UEOSCoreAuthVerifyUserAuth* EOSAuthVerifyUserAuthAsync(struct UObject* worldContextObject, struct FEOSAuthVerifyUserAuthOptions Options); // Function EOSCore.EOSCoreAuthVerifyUserAuth.EOSAuthVerifyUserAuthAsync
}; 



// Class EOSCore.CoreP2P
// Size: 0x80(Inherited: 0x30) 
struct UCoreP2P : public UEOSCoreSubsystem
{
	char pad_48[80];  // 0x30(0x50)

	struct UCoreP2P* GetP2P(struct UObject* worldContextObject); // Function EOSCore.CoreP2P.GetP2P
	uint8_t  EOSP2PSetRelayControl(struct UObject* worldContextObject, struct FEOSP2PSetRelayControlOptions Options); // Function EOSCore.CoreP2P.EOSP2PSetRelayControl
	uint8_t  EOSP2PSetPortRange(struct UObject* worldContextObject, struct FEOSP2PSetPortRangeOptions Options); // Function EOSCore.CoreP2P.EOSP2PSetPortRange
	uint8_t  EOSP2PSetPacketQueueSize(struct UObject* worldContextObject, struct FEOSP2PSetPacketQueueSizeOptions Options); // Function EOSCore.CoreP2P.EOSP2PSetPacketQueueSize
	uint8_t  EOSP2PSendPacket(struct UObject* worldContextObject, struct FEOSP2PSendPacketOptions Options); // Function EOSCore.CoreP2P.EOSP2PSendPacket
	void EOSP2PRemoveNotifyPeerConnectionRequest(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreP2P.EOSP2PRemoveNotifyPeerConnectionRequest
	void EOSP2PRemoveNotifyPeerConnectionClosed(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreP2P.EOSP2PRemoveNotifyPeerConnectionClosed
	void EOSP2PRemoveNotifyIncomingPacketQueueFull(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreP2P.EOSP2PRemoveNotifyIncomingPacketQueueFull
	uint8_t  EOSP2PReceivePacket(struct UObject* worldContextObject, struct FEOSP2PReceivePacketOptions Options, struct FEOSProductUserId& OutPeerId, struct FEOSP2PSocketId& OutSocketId, int32_t& OutChannel, struct TArray<char>& OutData, int32_t& OutBytesWritten); // Function EOSCore.CoreP2P.EOSP2PReceivePacket
	void EOSP2PQueryNATType(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreP2P.EOSP2PQueryNATType
	uint8_t  EOSP2PGetRelayControl(struct UObject* worldContextObject, struct FEOSP2PGetRelayControlOptions Options, uint8_t & OutRelayControl); // Function EOSCore.CoreP2P.EOSP2PGetRelayControl
	uint8_t  EOSP2PGetPortRange(struct UObject* worldContextObject, struct FEOSP2PGetPortRangeOptions Options, int32_t& OutPort, int32_t OutNumAdditionalPortsToTry); // Function EOSCore.CoreP2P.EOSP2PGetPortRange
	uint8_t  EOSP2PGetPacketQueueInfo(struct UObject* worldContextObject, struct FEOSP2PGetPacketQueueInfoOptions Options, struct FEOSP2PPacketQueueInfo& OutPacketQueueInfo); // Function EOSCore.CoreP2P.EOSP2PGetPacketQueueInfo
	uint8_t  EOSP2PGetNextReceivedPacketSize(struct UObject* worldContextObject, struct FEOSP2PGetNextReceivedPacketSizeOptions Options, int32_t& OutPacketSizeBytes); // Function EOSCore.CoreP2P.EOSP2PGetNextReceivedPacketSize
	uint8_t  EOSP2PGetNATType(struct UObject* worldContextObject, struct FEOSP2PGetNATTypeOptions Options, uint8_t & OutNatType); // Function EOSCore.CoreP2P.EOSP2PGetNATType
	uint8_t  EOSP2PCloseConnections(struct UObject* worldContextObject, struct FEOSP2PCloseConnectionsOptions Options); // Function EOSCore.CoreP2P.EOSP2PCloseConnections
	uint8_t  EOSP2PCloseConnection(struct UObject* worldContextObject, struct FEOSP2PCloseConnectionOptions Options); // Function EOSCore.CoreP2P.EOSP2PCloseConnection
	struct FEOSNotificationId EOSP2PAddNotifyPeerConnectionRequest(struct UObject* worldContextObject, struct FEOSP2PAddNotifyPeerConnectionRequestOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreP2P.EOSP2PAddNotifyPeerConnectionRequest
	struct FEOSNotificationId EOSP2PAddNotifyPeerConnectionClosed(struct UObject* worldContextObject, struct FEOSP2PAddNotifyPeerConnectionClosedOptions Options); // Function EOSCore.CoreP2P.EOSP2PAddNotifyPeerConnectionClosed
	struct FEOSNotificationId EOSP2PAddNotifyIncomingPacketQueueFull(struct UObject* worldContextObject, struct FEOSP2PAddNotifyIncomingPacketQueueFullOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreP2P.EOSP2PAddNotifyIncomingPacketQueueFull
	uint8_t  EOSP2PAcceptConnection(struct UObject* worldContextObject, struct FEOSP2PAcceptConnectionOptions Options); // Function EOSCore.CoreP2P.EOSP2PAcceptConnection
}; 



// Class EOSCore.CoreConnect
// Size: 0xD0(Inherited: 0x30) 
struct UCoreConnect : public UEOSCoreSubsystem
{
	char pad_48[160];  // 0x30(0xA0)

	struct UCoreConnect* GetConnect(struct UObject* worldContextObject); // Function EOSCore.CoreConnect.GetConnect
	void EOSConnectVerifyIdToken(struct UObject* worldContextObject, struct FEOSConnectVerifyIdTokenOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectVerifyIdToken
	void EOSConnectUnlinkAccount(struct UObject* worldContextObject, struct FEOSConnectUnlinkAccountOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectUnlinkAccount
	void EOSConnectTransferDeviceIdAccount(struct UObject* worldContextObject, struct FEOSConnectTransferDeviceIdAccountOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectTransferDeviceIdAccount
	void EOSConnectRemoveNotifyLoginStatusChanged(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreConnect.EOSConnectRemoveNotifyLoginStatusChanged
	void EOSConnectRemoveNotifyAuthExpiration(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreConnect.EOSConnectRemoveNotifyAuthExpiration
	void EOSConnectQueryProductUserIdMappings(struct UObject* worldContextObject, struct FEOSConnectQueryProductUserIdMappingsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectQueryProductUserIdMappings
	void EOSConnectQueryExternalAccountMappings(struct UObject* worldContextObject, struct FEOSConnectQueryExternalAccountMappingsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectQueryExternalAccountMappings
	void EOSConnectLogin(struct UObject* worldContextObject, struct FEOSConnectLoginOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectLogin
	void EOSConnectLinkAccount(struct UObject* worldContextObject, struct FEOSConnectLinkAccountOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectLinkAccount
	uint8_t  EOSConnectGetProductUserIdMapping(struct UObject* worldContextObject, struct FEOSConnectGetProductUserIdMappingOptions Options, struct FString& OutString); // Function EOSCore.CoreConnect.EOSConnectGetProductUserIdMapping
	int32_t EOSConnectGetProductUserExternalAccountCount(struct UObject* worldContextObject, struct FEOSConnectGetProductUserExternalAccountCountOptions Options); // Function EOSCore.CoreConnect.EOSConnectGetProductUserExternalAccountCount
	uint8_t  EOSConnectGetLoginStatusPure(struct UObject* worldContextObject, struct FEOSProductUserId LocalUserId); // Function EOSCore.CoreConnect.EOSConnectGetLoginStatusPure
	uint8_t  EOSConnectGetLoginStatus(struct UObject* worldContextObject, struct FEOSProductUserId LocalUserId); // Function EOSCore.CoreConnect.EOSConnectGetLoginStatus
	int32_t EOSConnectGetLoggedInUsersCount(struct UObject* worldContextObject); // Function EOSCore.CoreConnect.EOSConnectGetLoggedInUsersCount
	struct FEOSProductUserId EOSConnectGetLoggedInUserByIndex(struct UObject* worldContextObject, int32_t Index); // Function EOSCore.CoreConnect.EOSConnectGetLoggedInUserByIndex
	struct FEOSProductUserId EOSConnectGetExternalAccountMapping(struct UObject* worldContextObject, struct FEOSConnectGetExternalAccountMappingsOptions Options); // Function EOSCore.CoreConnect.EOSConnectGetExternalAccountMapping
	void EOSConnectDeleteDeviceId(struct UObject* worldContextObject, struct FEOSConnectDeleteDeviceIdOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectDeleteDeviceId
	void EOSConnectCreateUser(struct UObject* worldContextObject, struct FEOSConnectCreateUserOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectCreateUser
	void EOSConnectCreateDeviceId(struct UObject* worldContextObject, struct FEOSConnectCreateDeviceIdOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectCreateDeviceId
	uint8_t  EOSConnectCopyProductUserInfo(struct UObject* worldContextObject, struct FEOSConnectCopyProductUserInfoOptions Options, struct FEOSConnectExternalAccountInfo& OutExternalAccountInfo); // Function EOSCore.CoreConnect.EOSConnectCopyProductUserInfo
	uint8_t  EOSConnectCopyProductUserExternalAccountByIndex(struct UObject* worldContextObject, struct FEOSConnectCopyProductUserExternalAccountByIndexOptions Options, struct FEOSConnectExternalAccountInfo& OutExternalAccountInfo); // Function EOSCore.CoreConnect.EOSConnectCopyProductUserExternalAccountByIndex
	uint8_t  EOSConnectCopyProductUserExternalAccountByAccountType(struct UObject* worldContextObject, struct FEOSConnectCopyProductUserExternalAccountByAccountTypeOptions Options, struct FEOSConnectExternalAccountInfo& OutExternalAccountInfo); // Function EOSCore.CoreConnect.EOSConnectCopyProductUserExternalAccountByAccountType
	uint8_t  EOSConnectCopyProductUserExternalAccountByAccountId(struct UObject* worldContextObject, struct FEOSConnectCopyProductUserExternalAccountByAccountIdOptions Options, struct FEOSConnectExternalAccountInfo& OutExternalAccountInfo); // Function EOSCore.CoreConnect.EOSConnectCopyProductUserExternalAccountByAccountId
	uint8_t  EOSConnectCopyIdToken(struct UObject* worldContextObject, struct FEOSConnectCopyIdTokenOptions Options, struct FEOSConnectIdToken& OutIdToken); // Function EOSCore.CoreConnect.EOSConnectCopyIdToken
	struct FEOSNotificationId EOSConnectAddNotifyLoginStatusChanged(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectAddNotifyLoginStatusChanged
	struct FEOSNotificationId EOSConnectAddNotifyAuthExpiration(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreConnect.EOSConnectAddNotifyAuthExpiration
}; 



// Class EOSCore.CoreAuthentication
// Size: 0x80(Inherited: 0x30) 
struct UCoreAuthentication : public UEOSCoreSubsystem
{
	char pad_48[80];  // 0x30(0x50)

	struct UCoreAuthentication* GetAuthentication(struct UObject* worldContextObject); // Function EOSCore.CoreAuthentication.GetAuthentication
	void EOSAuthVerifyUserAuth(struct UObject* worldContextObject, struct FEOSAuthVerifyUserAuthOptions& Options, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthVerifyUserAuth
	void EOSAuthVerifyIdToken(struct UObject* worldContextObject, struct FEOSAuthVerifyIdTokenOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthVerifyIdToken
	void EOSAuthRemoveNotifyLoginStatusChanged(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreAuthentication.EOSAuthRemoveNotifyLoginStatusChanged
	void EOSAuthQueryIdToken(struct UObject* worldContextObject, struct FEOSAuthQueryIdTokenOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthQueryIdToken
	void EOSAuthLogout(struct UObject* worldContextObject, struct FEOSAuthLogoutOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthLogout
	void EOSAuthLogin(struct UObject* worldContextObject, struct FEOSAuthLoginOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthLogin
	void EOSAuthLinkAccount(struct UObject* worldContextObject, struct FEOSAuthLinkAccountOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthLinkAccount
	uint8_t  EOSAuthGetSelectedAccountId(struct UObject* worldContextObject, struct FEOSEpicAccountId LocalUserId, struct FEOSEpicAccountId& OutSelectedAccountId); // Function EOSCore.CoreAuthentication.EOSAuthGetSelectedAccountId
	int32_t EOSAuthGetMergedAccountsCount(struct UObject* worldContextObject, struct FEOSEpicAccountId LocalUserId); // Function EOSCore.CoreAuthentication.EOSAuthGetMergedAccountsCount
	struct FEOSEpicAccountId EOSAuthGetMergedAccountByIndex(struct UObject* worldContextObject, struct FEOSEpicAccountId LocalUserId, int32_t Index); // Function EOSCore.CoreAuthentication.EOSAuthGetMergedAccountByIndex
	uint8_t  EOSAuthGetLoginStatusPure(struct UObject* worldContextObject, struct FEOSEpicAccountId LocalUserId); // Function EOSCore.CoreAuthentication.EOSAuthGetLoginStatusPure
	uint8_t  EOSAuthGetLoginStatus(struct UObject* worldContextObject, struct FEOSEpicAccountId LocalUserId); // Function EOSCore.CoreAuthentication.EOSAuthGetLoginStatus
	int32_t EOSAuthGetLoggedInAccountsCount(struct UObject* worldContextObject); // Function EOSCore.CoreAuthentication.EOSAuthGetLoggedInAccountsCount
	struct FEOSEpicAccountId EOSAuthGetLoggedInAccountByIndex(struct UObject* worldContextObject, int32_t Index); // Function EOSCore.CoreAuthentication.EOSAuthGetLoggedInAccountByIndex
	void EOSAuthDeletePersistentAuth(struct UObject* worldContextObject, struct FEOSAuthDeletePersistentAuthOptions& Options, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthDeletePersistentAuth
	uint8_t  EOSAuthCopyUserAuthToken(struct UObject* worldContextObject, struct FEOSAuthCopyUserAuthTokenOptions Options, struct FEOSEpicAccountId LocalUserId, struct FEOSAuthToken& OutUserAuthToken); // Function EOSCore.CoreAuthentication.EOSAuthCopyUserAuthToken
	uint8_t  EOSAuthCopyIdToken(struct UObject* worldContextObject, struct FEOSAuthCopyIdTokenOptions Options, struct FEOSAuthIdToken& OutIdToken); // Function EOSCore.CoreAuthentication.EOSAuthCopyIdToken
	struct FEOSNotificationId EOSAuthAddNotifyLoginStatusChanged(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreAuthentication.EOSAuthAddNotifyLoginStatusChanged
}; 



// Class EOSCore.EOSCoreLeaderboardsQueryLeaderboardDefinitions
// Size: 0xA8(Inherited: 0x38) 
struct UEOSCoreLeaderboardsQueryLeaderboardDefinitions : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[96];  // 0x48(0x60)

	void HandleCallback(struct FEOSLeaderboardsOnQueryLeaderboardDefinitionsCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardDefinitions.HandleCallback
	struct UEOSCoreLeaderboardsQueryLeaderboardDefinitions* EOSLeaderboardsQueryLeaderboardDefinitionsAsync(struct UObject* worldContextObject, struct FEOSLeaderboardsQueryLeaderboardDefinitionsOptions Options); // Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardDefinitions.EOSLeaderboardsQueryLeaderboardDefinitionsAsync
}; 



// Class EOSCore.EOSCoreConnectLogin
// Size: 0x88(Inherited: 0x38) 
struct UEOSCoreConnectLogin : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[64];  // 0x48(0x40)

	void HandleCallback(struct FEOSConnectLoginCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectLogin.HandleCallback
	struct UEOSCoreConnectLogin* EOSConnectLoginAsync(struct UObject* worldContextObject, struct FEOSConnectLoginOptions Options); // Function EOSCore.EOSCoreConnectLogin.EOSConnectLoginAsync
}; 



// Class EOSCore.EOSCoreFriendsRejectInvite
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCoreFriendsRejectInvite : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSFriendsRejectInviteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreFriendsRejectInvite.HandleCallback
	struct UEOSCoreFriendsRejectInvite* EOSFriendsRejectInviteAsync(struct UObject* worldContextObject, struct FEOSFriendsRejectInviteOptions Options); // Function EOSCore.EOSCoreFriendsRejectInvite.EOSFriendsRejectInviteAsync
}; 



// Class EOSCore.CoreCustomInvites
// Size: 0xD0(Inherited: 0x30) 
struct UCoreCustomInvites : public UEOSCoreSubsystem
{
	char pad_48[160];  // 0x30(0xA0)

	struct UCoreCustomInvites* GetCustomInvites(struct UObject* worldContextObject); // Function EOSCore.CoreCustomInvites.GetCustomInvites
	uint8_t  EOSCustomInvitesSetCustomInvite(struct UObject* worldContextObject, struct FEOSCustomInvitesSetCustomInviteOptions Options); // Function EOSCore.CoreCustomInvites.EOSCustomInvitesSetCustomInvite
	void EOSCustomInvitesSendCustomInvite(struct UObject* worldContextObject, struct FEOSCustomInvitesSendCustomInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreCustomInvites.EOSCustomInvitesSendCustomInvite
	void EOSCustomInvitesRemoveNotifyCustomInviteReceived(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreCustomInvites.EOSCustomInvitesRemoveNotifyCustomInviteReceived
	void EOSCustomInvitesRemoveNotifyCustomInviteAccepted(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreCustomInvites.EOSCustomInvitesRemoveNotifyCustomInviteAccepted
	uint8_t  EOSCustomInvitesFinalizeInvite(struct UObject* worldContextObject, struct FEOSCustomInvitesFinalizeInviteOptions Options); // Function EOSCore.CoreCustomInvites.EOSCustomInvitesFinalizeInvite
	struct FEOSNotificationId EOSCustomInvitesAddNotifyCustomInviteReceived(struct UObject* worldContextObject, struct FEOSCustomInvitesAddNotifyCustomInviteReceivedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreCustomInvites.EOSCustomInvitesAddNotifyCustomInviteReceived
	struct FEOSNotificationId EOSCustomInvitesAddNotifyCustomInviteAccepted(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreCustomInvites.EOSCustomInvitesAddNotifyCustomInviteAccepted
}; 



// Class EOSCore.EOSCoreConnectCreateUser
// Size: 0x60(Inherited: 0x38) 
struct UEOSCoreConnectCreateUser : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[24];  // 0x48(0x18)

	void HandleCallback(struct FEOSConnectCreateUserCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectCreateUser.HandleCallback
	struct UEOSCoreConnectCreateUser* EOSConnectCreateUserAsync(struct UObject* worldContextObject, struct FEOSConnectCreateUserOptions Options); // Function EOSCore.EOSCoreConnectCreateUser.EOSConnectCreateUserAsync
}; 



// Class EOSCore.EOSCoreConnectLinkAccount
// Size: 0x88(Inherited: 0x38) 
struct UEOSCoreConnectLinkAccount : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[64];  // 0x48(0x40)

	void HandleCallback(struct FEOSConnectLinkAccountCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectLinkAccount.HandleCallback
	struct UEOSCoreConnectLinkAccount* EOSConnectLinkAccountAsync(struct UObject* worldContextObject, struct FEOSConnectLinkAccountOptions Options); // Function EOSCore.EOSCoreConnectLinkAccount.EOSConnectLinkAccountAsync
}; 



// Class EOSCore.EOSCorePlayerDataStorageReadFile
// Size: 0xC8(Inherited: 0x38) 
struct UEOSCorePlayerDataStorageReadFile : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[128];  // 0x48(0x80)

	void HandleCallback(struct FEOSPlayerDataStorageReadFileCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePlayerDataStorageReadFile.HandleCallback
	struct UEOSCorePlayerDataStorageReadFile* EOSPlayerDataStorageReadFileAsync(struct UObject* worldContextObject, struct FEOSPlayerDataStorageReadFileOptions ReadOptions); // Function EOSCore.EOSCorePlayerDataStorageReadFile.EOSPlayerDataStorageReadFileAsync
}; 



// Class EOSCore.EOSCoreFriendsQueryFriends
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreFriendsQueryFriends : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSFriendsQueryFriendsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreFriendsQueryFriends.HandleCallback
	struct UEOSCoreFriendsQueryFriends* EOSFriendsQueryFriendsAsync(struct UObject* worldContextObject, struct FEOSFriendsQueryFriendsOptions Options); // Function EOSCore.EOSCoreFriendsQueryFriends.EOSFriendsQueryFriendsAsync
}; 



// Class EOSCore.EOSCoreUIShowFriends
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreUIShowFriends : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSUIShowFriendsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreUIShowFriends.HandleCallback
	struct UEOSCoreUIShowFriends* EOSUIShowFriendsAsync(struct UObject* worldContextObject, struct FEOSUIShowFriendsOptions Options); // Function EOSCore.EOSCoreUIShowFriends.EOSUIShowFriendsAsync
}; 



// Class EOSCore.EOSCoreConnectUnlinkAccount
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreConnectUnlinkAccount : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSConnectUnlinkAccountCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectUnlinkAccount.HandleCallback
	struct UEOSCoreConnectUnlinkAccount* EOSConnectUnlinkAccountAsync(struct UObject* worldContextObject, struct FEOSConnectUnlinkAccountOptions Options); // Function EOSCore.EOSCoreConnectUnlinkAccount.EOSConnectUnlinkAccountAsync
}; 



// Class EOSCore.EOSCoreConnectCreateDeviceId
// Size: 0x68(Inherited: 0x38) 
struct UEOSCoreConnectCreateDeviceId : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[32];  // 0x48(0x20)

	void HandleCallback(struct FEOSConnectCreateDeviceIdCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectCreateDeviceId.HandleCallback
	struct UEOSCoreConnectCreateDeviceId* EOSConnectCreateDeviceIdAsync(struct UObject* worldContextObject, struct FEOSConnectCreateDeviceIdOptions Options); // Function EOSCore.EOSCoreConnectCreateDeviceId.EOSConnectCreateDeviceIdAsync
}; 



// Class EOSCore.EOSCoreLobbyQueryInvites
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreLobbyQueryInvites : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSLobbyQueryInvitesCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyQueryInvites.HandleCallback
	struct UEOSCoreLobbyQueryInvites* EOSLobbyQueryInvitesAsync(struct UObject* worldContextObject, struct FEOSLobbyQueryInvitesOptions Options); // Function EOSCore.EOSCoreLobbyQueryInvites.EOSLobbyQueryInvitesAsync
}; 



// Class EOSCore.EOSCoreSessionsSearchFind
// Size: 0x88(Inherited: 0x38) 
struct UEOSCoreSessionsSearchFind : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[64];  // 0x48(0x40)

	void HandleCallback(struct FEOSSessionSearchFindCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsSearchFind.HandleCallback
	struct UEOSCoreSessionsSearchFind* EOSSessionSearchFindAsync(struct UObject* worldContextObject, struct FEOSHSessionSearch SearchHandle, struct FEOSSessionSearchFindOptions Options); // Function EOSCore.EOSCoreSessionsSearchFind.EOSSessionSearchFindAsync
}; 



// Class EOSCore.EOSCoreLobbyRejectInvite
// Size: 0x98(Inherited: 0x38) 
struct UEOSCoreLobbyRejectInvite : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[80];  // 0x48(0x50)

	void HandleCallback(struct FEOSLobbyRejectInviteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyRejectInvite.HandleCallback
	struct UEOSCoreLobbyRejectInvite* EOSLobbyRejectInviteAsync(struct UObject* worldContextObject, struct FEOSLobbyRejectInviteOptions Options); // Function EOSCore.EOSCoreLobbyRejectInvite.EOSLobbyRejectInviteAsync
}; 



// Class EOSCore.EOSCoreConnectDeleteDeviceId
// Size: 0x60(Inherited: 0x38) 
struct UEOSCoreConnectDeleteDeviceId : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[24];  // 0x48(0x18)

	void HandleCallback(struct FEOSConnectDeleteDeviceIdCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectDeleteDeviceId.HandleCallback
	struct UEOSCoreConnectDeleteDeviceId* EOSConnectDeleteDeviceIdAsync(struct UObject* worldContextObject, struct FEOSConnectDeleteDeviceIdOptions Options); // Function EOSCore.EOSCoreConnectDeleteDeviceId.EOSConnectDeleteDeviceIdAsync
}; 



// Class EOSCore.EOSCoreConnectTransferDeviceIdAccount
// Size: 0xC0(Inherited: 0x38) 
struct UEOSCoreConnectTransferDeviceIdAccount : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[120];  // 0x48(0x78)

	void HandleCallback(struct FEOSConnectTransferDeviceIdAccountCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectTransferDeviceIdAccount.HandleCallback
	struct UEOSCoreConnectTransferDeviceIdAccount* EOSConnectTransferDeviceIdAccountAsync(struct UObject* worldContextObject, struct FEOSConnectTransferDeviceIdAccountOptions Options); // Function EOSCore.EOSCoreConnectTransferDeviceIdAccount.EOSConnectTransferDeviceIdAccountAsync
}; 



// Class EOSCore.EOSCoreConnectQueryExternalAccountMappings
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreConnectQueryExternalAccountMappings : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSConnectQueryExternalAccountMappingsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectQueryExternalAccountMappings.HandleCallback
	struct UEOSCoreConnectQueryExternalAccountMappings* EOSConnectQueryExternalAccountMappingsAsync(struct UObject* worldContextObject, struct FEOSConnectQueryExternalAccountMappingsOptions Options); // Function EOSCore.EOSCoreConnectQueryExternalAccountMappings.EOSConnectQueryExternalAccountMappingsAsync
}; 



// Class EOSCore.EOSCoreEcomQueryEntitlements
// Size: 0x98(Inherited: 0x38) 
struct UEOSCoreEcomQueryEntitlements : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[80];  // 0x48(0x50)

	void HandleCallback(struct FEOSEcomQueryEntitlementsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreEcomQueryEntitlements.HandleCallback
	struct UEOSCoreEcomQueryEntitlements* EOSEcomQueryEntitlementsAsync(struct UObject* worldContextObject, struct FEOSEcomQueryEntitlementsOptions Options); // Function EOSCore.EOSCoreEcomQueryEntitlements.EOSEcomQueryEntitlementsAsync
}; 



// Class EOSCore.EOSCoreConnectQueryProductUserIdMappings
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreConnectQueryProductUserIdMappings : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSConnectQueryProductUserIdMappingsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreConnectQueryProductUserIdMappings.HandleCallback
	struct UEOSCoreConnectQueryProductUserIdMappings* EOSConnectQueryProductUserIdMappingsAsync(struct UObject* worldContextObject, struct FEOSConnectQueryProductUserIdMappingsOptions Options); // Function EOSCore.EOSCoreConnectQueryProductUserIdMappings.EOSConnectQueryProductUserIdMappingsAsync
}; 



// Class EOSCore.CoreEcom
// Size: 0x30(Inherited: 0x30) 
struct UCoreEcom : public UEOSCoreSubsystem
{

	struct UCoreEcom* GetEcom(struct UObject* worldContextObject); // Function EOSCore.CoreEcom.GetEcom
	uint8_t  EOSEcomTransaction_GetTransactionId(struct UObject* worldContextObject, struct FEOSEcomHTransaction& Handle, struct FString& OutTransactionId); // Function EOSCore.CoreEcom.EOSEcomTransaction_GetTransactionId
	int32_t EOSEcomTransaction_GetEntitlementsCount(struct UObject* worldContextObject, struct FEOSEcomHTransaction& Handle, struct FEOSEcomTransactionGetEntitlementsCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomTransaction_GetEntitlementsCount
	uint8_t  EOSEcomTransaction_CopyEntitlementByIndex(struct UObject* worldContextObject, struct FEOSEcomHTransaction& Handle, struct FEOSEcomTransactionCopyEntitlementByIndexOptions Options, struct FEOSEcomEntitlement& OutEntitlement); // Function EOSCore.CoreEcom.EOSEcomTransaction_CopyEntitlementByIndex
	void EOSEcomRedeemEntitlements(struct UObject* worldContextObject, struct FEOSEcomRedeemEntitlementsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreEcom.EOSEcomRedeemEntitlements
	void EOSEcomQueryOwnershipToken(struct UObject* worldContextObject, struct FEOSEcomQueryOwnershipTokenOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreEcom.EOSEcomQueryOwnershipToken
	void EOSEcomQueryOwnership(struct UObject* worldContextObject, struct FEOSEcomQueryOwnershipOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreEcom.EOSEcomQueryOwnership
	void EOSEcomQueryOffers(struct UObject* worldContextObject, struct FEOSEcomQueryOffersOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreEcom.EOSEcomQueryOffers
	void EOSEcomQueryEntitlements(struct UObject* worldContextObject, struct FEOSEcomQueryEntitlementsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreEcom.EOSEcomQueryEntitlements
	int32_t EOSEcomGetTransactionCount(struct UObject* worldContextObject, struct FEOSEcomGetTransactionCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetTransactionCount
	int32_t EOSEcomGetOfferItemCount(struct UObject* worldContextObject, struct FEOSEcomGetOfferItemCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetOfferItemCount
	int32_t EOSEcomGetOfferImageInfoCount(struct UObject* worldContextObject, struct FEOSEcomGetOfferImageInfoCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetOfferImageInfoCount
	int32_t EOSEcomGetOfferCount(struct UObject* worldContextObject, struct FEOSEcomGetOfferCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetOfferCount
	int32_t EOSEcomGetItemReleaseCount(struct UObject* worldContextObject, struct FEOSEcomGetItemReleaseCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetItemReleaseCount
	int32_t EOSEcomGetItemImageInfoCount(struct UObject* worldContextObject, struct FEOSEcomGetItemImageInfoCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetItemImageInfoCount
	int32_t EOSEcomGetEntitlementsCount(struct UObject* worldContextObject, struct FEOSEcomGetEntitlementsCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetEntitlementsCount
	int32_t EOSEcomGetEntitlementsByNameCount(struct UObject* worldContextObject, struct FEOSEcomGetEntitlementsByNameCountOptions Options); // Function EOSCore.CoreEcom.EOSEcomGetEntitlementsByNameCount
	uint8_t  EOSEcomCopyTransactionByIndex(struct UObject* worldContextObject, struct FEOSEcomCopyTransactionByIndexOptions Options, struct FEOSEcomHTransaction& OutTransaction); // Function EOSCore.CoreEcom.EOSEcomCopyTransactionByIndex
	uint8_t  EOSEcomCopyTransactionById(struct UObject* worldContextObject, struct FEOSEcomCopyTransactionByIdOptions Options, struct FEOSEcomHTransaction& OutTransaction); // Function EOSCore.CoreEcom.EOSEcomCopyTransactionById
	uint8_t  EOSEcomCopyOfferItemByIndex(struct UObject* worldContextObject, struct FEOSEcomCopyOfferItemByIndexOptions Options, struct FEOSEcomCatalogItem& OutItem); // Function EOSCore.CoreEcom.EOSEcomCopyOfferItemByIndex
	uint8_t  EOSEcomCopyOfferImageInfoByIndex(struct UObject* worldContextObject, struct FEOSEcomCopyOfferImageInfoByIndexOptions Options, struct FEOSEcomKeyImageInfo& OutImageInfo); // Function EOSCore.CoreEcom.EOSEcomCopyOfferImageInfoByIndex
	uint8_t  EOSEcomCopyOfferByIndex(struct UObject* worldContextObject, struct FEOSEcomCopyOfferByIndexOptions Options, struct FEOSEcomCatalogOffer& OutOffer); // Function EOSCore.CoreEcom.EOSEcomCopyOfferByIndex
	uint8_t  EOSEcomCopyOfferById(struct UObject* worldContextObject, struct FEOSEcomCopyOfferByIdOptions Options, struct FEOSEcomCatalogOffer& OutOffer); // Function EOSCore.CoreEcom.EOSEcomCopyOfferById
	uint8_t  EOSEcomCopyItemReleaseByIndex(struct UObject* worldContextObject, struct FEOSEcomCopyItemReleaseByIndexOptions Options, struct FEOSEcomCatalogRelease& OutRelease); // Function EOSCore.CoreEcom.EOSEcomCopyItemReleaseByIndex
	uint8_t  EOSEcomCopyItemImageInfoByIndex(struct UObject* worldContextObject, struct FEOSEcomCopyItemImageInfoByIndexOptions Options, struct FEOSEcomKeyImageInfo& OutImageInfo); // Function EOSCore.CoreEcom.EOSEcomCopyItemImageInfoByIndex
	uint8_t  EOSEcomCopyItemById(struct UObject* worldContextObject, struct FEOSEcomCopyItemByIdOptions Options, struct FEOSEcomCatalogItem& OutItem); // Function EOSCore.CoreEcom.EOSEcomCopyItemById
	uint8_t  EOSEcomCopyEntitlementByNameAndIndex(struct UObject* worldContextObject, struct FEOSEcomCopyEntitlementByNameAndIndexOptions Options, struct FEOSEcomEntitlement& OutEntitlement); // Function EOSCore.CoreEcom.EOSEcomCopyEntitlementByNameAndIndex
	uint8_t  EOSEcomCopyEntitlementByIndex(struct UObject* worldContextObject, struct FEOSEcomCopyEntitlementByIndexOptions Options, struct FEOSEcomEntitlement& OutEntitlement); // Function EOSCore.CoreEcom.EOSEcomCopyEntitlementByIndex
	uint8_t  EOSEcomCopyEntitlementById(struct UObject* worldContextObject, struct FEOSEcomCopyEntitlementByIdOptions Options, struct FEOSEcomEntitlement& OutEntitlement); // Function EOSCore.CoreEcom.EOSEcomCopyEntitlementById
	void EOSEcomCheckout(struct UObject* worldContextObject, struct FEOSEcomCheckoutOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreEcom.EOSEcomCheckout
}; 



// Class EOSCore.EOSCorePlayerDataStorageDuplicateFile
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCorePlayerDataStorageDuplicateFile : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSPlayerDataStorageDuplicateFileCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePlayerDataStorageDuplicateFile.HandleCallback
	struct UEOSCorePlayerDataStorageDuplicateFile* EOSPlayerDataStorageDuplicateFileAsync(struct UObject* worldContextObject, struct FEOSPlayerDataStorageDuplicateFileOptions DuplicateOptions); // Function EOSCore.EOSCorePlayerDataStorageDuplicateFile.EOSPlayerDataStorageDuplicateFileAsync
}; 



// Class EOSCore.EOSCoreEcomQueryOwnership
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCoreEcomQueryOwnership : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSEcomQueryOwnershipCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreEcomQueryOwnership.HandleCallback
	struct UEOSCoreEcomQueryOwnership* EOSEcomQueryOwnershipAsync(struct UObject* worldContextObject, struct FEOSEcomQueryOwnershipOptions Options); // Function EOSCore.EOSCoreEcomQueryOwnership.EOSEcomQueryOwnershipAsync
}; 



// Class EOSCore.CoreMods
// Size: 0x30(Inherited: 0x30) 
struct UCoreMods : public UEOSCoreSubsystem
{

	struct UCoreMods* GetMods(struct UObject* worldContextObject); // Function EOSCore.CoreMods.GetMods
	void EOSModsUpdateMod(struct UObject* worldContextObject, struct FEOSModsUpdateModOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreMods.EOSModsUpdateMod
	void EOSModsUninstallMod(struct UObject* worldContextObject, struct FEOSModsUninstallModOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreMods.EOSModsUninstallMod
	void EOSModsInstallMod(struct UObject* worldContextObject, struct FEOSModsInstallModOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreMods.EOSModsInstallMod
	void EOSModsEnumerateMods(struct UObject* worldContextObject, struct FEOSModsEnumerateModsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreMods.EOSModsEnumerateMods
	uint8_t  EOSModsCopyModInfo(struct UObject* worldContextObject, struct FEOSModsCopyModInfoOptions Options, struct FEOSModsModInfo& OutEnumeratedMods); // Function EOSCore.CoreMods.EOSModsCopyModInfo
}; 



// Class EOSCore.EOSCoreEcomQueryOffers
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreEcomQueryOffers : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSEcomQueryOffersCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreEcomQueryOffers.HandleCallback
	struct UEOSCoreEcomQueryOffers* EOSEcomQueryOffersAsync(struct UObject* worldContextObject, struct FEOSEcomQueryOffersOptions Options); // Function EOSCore.EOSCoreEcomQueryOffers.EOSEcomQueryOffersAsync
}; 



// Class EOSCore.EOSCoreEcomCheckout
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCoreEcomCheckout : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSEcomCheckoutCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreEcomCheckout.HandleCallback
	struct UEOSCoreEcomCheckout* EOSEcomCheckoutAsync(struct UObject* worldContextObject, struct FEOSEcomCheckoutOptions Options); // Function EOSCore.EOSCoreEcomCheckout.EOSEcomCheckoutAsync
}; 



// Class EOSCore.CoreMetrics
// Size: 0x30(Inherited: 0x30) 
struct UCoreMetrics : public UEOSCoreSubsystem
{

	struct UCoreMetrics* GetMetrics(struct UObject* worldContextObject); // Function EOSCore.CoreMetrics.GetMetrics
	uint8_t  EOSMetricsEndPlayerSession(struct UObject* worldContextObject, struct FEOSMetricsEndPlayerSessionOptions Options); // Function EOSCore.CoreMetrics.EOSMetricsEndPlayerSession
	uint8_t  EOSMetricsBeginPlayerSession(struct UObject* worldContextObject, struct FEOSMetricsBeginPlayerSessionOptions Options); // Function EOSCore.CoreMetrics.EOSMetricsBeginPlayerSession
}; 



// Class EOSCore.EOSCoreTitleStorageReadFile
// Size: 0xB0(Inherited: 0x38) 
struct UEOSCoreTitleStorageReadFile : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[104];  // 0x48(0x68)

	void HandleCallback(struct FEOSTitleStorageReadFileCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreTitleStorageReadFile.HandleCallback
	struct UEOSCoreTitleStorageReadFile* EOSTitleStorageReadFileAsync(struct UObject* worldContextObject, struct FEOSTitleStorageReadFileOptions Options); // Function EOSCore.EOSCoreTitleStorageReadFile.EOSTitleStorageReadFileAsync
}; 



// Class EOSCore.CoreFriends
// Size: 0x80(Inherited: 0x30) 
struct UCoreFriends : public UEOSCoreSubsystem
{
	char pad_48[80];  // 0x30(0x50)

	struct UCoreFriends* GetFriends(struct UObject* worldContextObject); // Function EOSCore.CoreFriends.GetFriends
	void EOSFriendsSendInvite(struct UObject* worldContextObject, struct FEOSFriendsSendInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreFriends.EOSFriendsSendInvite
	void EOSFriendsRemoveNotifyFriendsUpdate(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreFriends.EOSFriendsRemoveNotifyFriendsUpdate
	void EOSFriendsRejectInvite(struct UObject* worldContextObject, struct FEOSFriendsRejectInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreFriends.EOSFriendsRejectInvite
	void EOSFriendsQueryFriends(struct UObject* worldContextObject, struct FEOSFriendsQueryFriendsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreFriends.EOSFriendsQueryFriends
	uint8_t  EOSFriendsGetStatus(struct UObject* worldContextObject, struct FEOSFriendsGetStatusOptions Options); // Function EOSCore.CoreFriends.EOSFriendsGetStatus
	int32_t EOSFriendsGetFriendsCount(struct UObject* worldContextObject, struct FEOSFriendsGetFriendsCountOptions Options); // Function EOSCore.CoreFriends.EOSFriendsGetFriendsCount
	struct FEOSEpicAccountId EOSFriendsGetFriendAtIndex(struct UObject* worldContextObject, struct FEOSFriendsGetFriendAtIndexOptions Options); // Function EOSCore.CoreFriends.EOSFriendsGetFriendAtIndex
	struct FEOSNotificationId EOSFriendsAddNotifyFriendsUpdate(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreFriends.EOSFriendsAddNotifyFriendsUpdate
	void EOSFriendsAcceptInvite(struct UObject* worldContextObject, struct FEOSFriendsAcceptInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreFriends.EOSFriendsAcceptInvite
}; 



// Class EOSCore.EOSCoreLobbyDestroyLobby
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreLobbyDestroyLobby : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSLobbyDestroyLobbyCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyDestroyLobby.HandleCallback
	struct UEOSCoreLobbyDestroyLobby* EOSLobbyDestroyLobbyAsync(struct UObject* worldContextObject, struct FEOSLobbyDestroyLobbyOptions Options); // Function EOSCore.EOSCoreLobbyDestroyLobby.EOSLobbyDestroyLobbyAsync
}; 



// Class EOSCore.EOSCoreFriendsSendInvite
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCoreFriendsSendInvite : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSFriendsSendInviteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreFriendsSendInvite.HandleCallback
	struct UEOSCoreFriendsSendInvite* EOSFriendsSendInviteAsync(struct UObject* worldContextObject, struct FEOSFriendsSendInviteOptions Options); // Function EOSCore.EOSCoreFriendsSendInvite.EOSFriendsSendInviteAsync
}; 



// Class EOSCore.EOSCoreLeaderboardsQueryLeaderboardUserScores
// Size: 0xC8(Inherited: 0x38) 
struct UEOSCoreLeaderboardsQueryLeaderboardUserScores : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[128];  // 0x48(0x80)

	void HandleCallback(struct FEOSLeaderboardsOnQueryLeaderboardUserScoresCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardUserScores.HandleCallback
	struct UEOSCoreLeaderboardsQueryLeaderboardUserScores* EOSLeaderboardsQueryLeaderboardUserScoresAsync(struct UObject* worldContextObject, struct FEOSLeaderboardsQueryLeaderboardUserScoresOptions Options); // Function EOSCore.EOSCoreLeaderboardsQueryLeaderboardUserScores.EOSLeaderboardsQueryLeaderboardUserScoresAsync
}; 



// Class EOSCore.EOSCoreLobbyCreateLobby
// Size: 0xB8(Inherited: 0x38) 
struct UEOSCoreLobbyCreateLobby : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[112];  // 0x48(0x70)

	void HandleCallback(struct FEOSLobbyCreateLobbyCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyCreateLobby.HandleCallback
	struct UEOSCoreLobbyCreateLobby* EOSLobbyCreateLobbyAsync(struct UObject* worldContextObject, struct FEOSLobbyCreateLobbyOptions Options); // Function EOSCore.EOSCoreLobbyCreateLobby.EOSLobbyCreateLobbyAsync
}; 



// Class EOSCore.CoreUI
// Size: 0x80(Inherited: 0x30) 
struct UCoreUI : public UEOSCoreSubsystem
{
	char pad_48[80];  // 0x30(0x50)

	struct UCoreUI* GetUI(struct UObject* worldContextObject); // Function EOSCore.CoreUI.GetUI
	void EOSUIShowFriends(struct UObject* worldContextObject, struct FEOSUIShowFriendsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreUI.EOSUIShowFriends
	uint8_t  EOSUISetToggleFriendsKey(struct UObject* worldContextObject, struct FEOSUISetToggleFriendsKeyOptions Options); // Function EOSCore.CoreUI.EOSUISetToggleFriendsKey
	uint8_t  EOSUISetDisplayPreference(struct UObject* worldContextObject, struct FEOSUISetDisplayPreferenceOptions Options); // Function EOSCore.CoreUI.EOSUISetDisplayPreference
	void EOSUIRemoveNotifyDisplaySettingsUpdated(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreUI.EOSUIRemoveNotifyDisplaySettingsUpdated
	bool EOSUIIsValidKeyCombination(struct UObject* worldContextObject, int32_t keyCombination); // Function EOSCore.CoreUI.EOSUIIsValidKeyCombination
	void EOSUIHideFriends(struct UObject* worldContextObject, struct FEOSUIHideFriendsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreUI.EOSUIHideFriends
	int32_t EOSUIGetToggleFriendsKey(struct UObject* worldContextObject, struct FEOSUIGetToggleFriendsKeyOptions Options); // Function EOSCore.CoreUI.EOSUIGetToggleFriendsKey
	uint8_t  EOSUIGetNotificationLocationPreference(struct UObject* worldContextObject); // Function EOSCore.CoreUI.EOSUIGetNotificationLocationPreference
	bool EOSUIGetFriendsVisible(struct UObject* worldContextObject, struct FEOSUIGetFriendsVisibleOptions Options); // Function EOSCore.CoreUI.EOSUIGetFriendsVisible
	struct FEOSNotificationId EOSUIAddNotifyDisplaySettingsUpdated(struct UObject* worldContextObject, struct FEOSUIAddNotifyDisplaySettingsUpdatedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreUI.EOSUIAddNotifyDisplaySettingsUpdated
	uint8_t  EOSUIAcknowledgeEventId(struct UObject* worldContextObject, struct FEOSUIAcknowledgeEventIdOptions Options); // Function EOSCore.CoreUI.EOSUIAcknowledgeEventId
}; 



// Class EOSCore.EOSCoreLobbyJoinLobby
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreLobbyJoinLobby : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSLobbyJoinLobbyCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyJoinLobby.HandleCallback
	struct UEOSCoreLobbyJoinLobby* EOSLobbyJoinLobbyAsync(struct UObject* worldContextObject, struct FEOSLobbyJoinLobbyOptions Options); // Function EOSCore.EOSCoreLobbyJoinLobby.EOSLobbyJoinLobbyAsync
}; 



// Class EOSCore.EOSCoreLobbyLeaveLobby
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreLobbyLeaveLobby : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSLobbyLeaveLobbyCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyLeaveLobby.HandleCallback
	struct UEOSCoreLobbyLeaveLobby* EOSLobbyLeaveLobbyAsync(struct UObject* worldContextObject, struct FEOSLobbyLeaveLobbyOptions Options); // Function EOSCore.EOSCoreLobbyLeaveLobby.EOSLobbyLeaveLobbyAsync
}; 



// Class EOSCore.EOSCoreLobbyUpdateLobby
// Size: 0x68(Inherited: 0x38) 
struct UEOSCoreLobbyUpdateLobby : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[32];  // 0x48(0x20)

	void HandleCallback(struct FEOSLobbyUpdateLobbyCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyUpdateLobby.HandleCallback
	struct UEOSCoreLobbyUpdateLobby* EOSLobbyUpdateLobbyAsync(struct UObject* worldContextObject, struct FEOSLobbyUpdateLobbyOptions Options); // Function EOSCore.EOSCoreLobbyUpdateLobby.EOSLobbyUpdateLobbyAsync
}; 



// Class EOSCore.EOSCoreLobbyPromoteMember
// Size: 0xB0(Inherited: 0x38) 
struct UEOSCoreLobbyPromoteMember : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[104];  // 0x48(0x68)

	void HandleCallback(struct FEOSLobbyPromoteMemberCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyPromoteMember.HandleCallback
	struct UEOSCoreLobbyPromoteMember* EOSLobbyPromoteMemberAsync(struct UObject* worldContextObject, struct FEOSLobbyPromoteMemberOptions Options); // Function EOSCore.EOSCoreLobbyPromoteMember.EOSLobbyPromoteMemberAsync
}; 



// Class EOSCore.EOSCoreLobbyKickMember
// Size: 0xB0(Inherited: 0x38) 
struct UEOSCoreLobbyKickMember : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[104];  // 0x48(0x68)

	void HandleCallback(struct FEOSLobbyKickMemberCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbyKickMember.HandleCallback
	struct UEOSCoreLobbyKickMember* EOSLobbyKickMemberAsync(struct UObject* worldContextObject, struct FEOSLobbyKickMemberOptions Options); // Function EOSCore.EOSCoreLobbyKickMember.EOSLobbyKickMemberAsync
}; 



// Class EOSCore.EOSCoreLobbySendInvite
// Size: 0xB0(Inherited: 0x38) 
struct UEOSCoreLobbySendInvite : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[104];  // 0x48(0x68)

	void HandleCallback(struct FEOSLobbySendInviteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbySendInvite.HandleCallback
	struct UEOSCoreLobbySendInvite* EOSLobbySendInviteAsync(struct UObject* worldContextObject, struct FEOSLobbySendInviteOptions Options); // Function EOSCore.EOSCoreLobbySendInvite.EOSLobbySendInviteAsync
}; 



// Class EOSCore.EOSCoreLobbySearchFind
// Size: 0x88(Inherited: 0x38) 
struct UEOSCoreLobbySearchFind : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[64];  // 0x48(0x40)

	void HandleCallback(struct FEOSLobbySearchFindCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreLobbySearchFind.HandleCallback
	struct UEOSCoreLobbySearchFind* EOSLobbySearchFindAsync(struct UObject* worldContextObject, struct FEOSHLobbySearch& Handle, struct FEOSLobbySearchFindOptions Options); // Function EOSCore.EOSCoreLobbySearchFind.EOSLobbySearchFindAsync
}; 



// Class EOSCore.CorePlayerDataStorage
// Size: 0x30(Inherited: 0x30) 
struct UCorePlayerDataStorage : public UEOSCoreSubsystem
{

	struct UCorePlayerDataStorage* GetPlayerDataStorage(struct UObject* worldContextObject); // Function EOSCore.CorePlayerDataStorage.GetPlayerDataStorage
	void EOSPlayerDataStorageWriteFile(struct UObject* worldContextObject, struct FEOSPlayerDataStorageWriteFileOptions WriteOptions, struct FDelegate& Callback); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageWriteFile
	void EOSPlayerDataStorageReadFile(struct UObject* worldContextObject, struct FEOSPlayerDataStorageReadFileOptions ReadOptions, struct FDelegate& Callback); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageReadFile
	void EOSPlayerDataStorageQueryFileList(struct UObject* worldContextObject, struct FEOSPlayerDataStorageQueryFileListOptions QueryFileListOptions, struct FDelegate& Callback); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageQueryFileList
	void EOSPlayerDataStorageQueryFile(struct UObject* worldContextObject, struct FEOSPlayerDataStorageQueryFileOptions QueryFileOptions, struct FDelegate& Callback); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageQueryFile
	uint8_t  EOSPlayerDataStorageGetFileMetadataCount(struct UObject* worldContextObject, struct FEOSPlayerDataStorageGetFileMetadataCountOptions GetFileMetadataCountOptions, int32_t& OutFileMetadataCount); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageGetFileMetadataCount
	void EOSPlayerDataStorageFileTransferRequestRelease(struct UObject* worldContextObject, struct FEOSHPlayerDataStorageFileTransferRequest& Handle); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestRelease
	uint8_t  EOSPlayerDataStorageFileTransferRequestGetFileRequestState(struct UObject* worldContextObject, struct FEOSHPlayerDataStorageFileTransferRequest& Handle); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestGetFileRequestState
	uint8_t  EOSPlayerDataStorageFileTransferRequestGetFilename(struct UObject* worldContextObject, struct FEOSHPlayerDataStorageFileTransferRequest& Handle, int32_t FilenameStringBufferSizeBytes, struct FString& OutStringBuffer); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestGetFilename
	uint8_t  EOSPlayerDataStorageFileTransferRequestCancelRequest(struct UObject* worldContextObject, struct FEOSHPlayerDataStorageFileTransferRequest& Handle); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageFileTransferRequestCancelRequest
	void EOSPlayerDataStorageDuplicateFile(struct UObject* worldContextObject, struct FEOSPlayerDataStorageDuplicateFileOptions DuplicateOptions, struct FDelegate& Callback); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageDuplicateFile
	void EOSPlayerDataStorageDeleteFile(struct UObject* worldContextObject, struct FEOSPlayerDataStorageDeleteFileOptions DeleteOptions, struct FDelegate& Callback); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageDeleteFile
	uint8_t  EOSPlayerDataStorageDeleteCache(struct UObject* worldContextObject, struct FEOSPlayerDataStorageDeleteCacheOptions Options, struct FDelegate& Callback); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageDeleteCache
	uint8_t  EOSPlayerDataStorageCopyFileMetadataByFilename(struct UObject* worldContextObject, struct FEOSPlayerDataStorageCopyFileMetadataByFilenameOptions CopyFileMetadataOptions, struct FEOSPlayerDataStorageFileMetadata& OutMetadata); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageCopyFileMetadataByFilename
	uint8_t  EOSPlayerDataStorageCopyFileMetadataAtIndex(struct UObject* worldContextObject, struct FEOSPlayerDataStorageCopyFileMetadataAtIndexOptions CopyFileMetadataOptions, struct FEOSPlayerDataStorageFileMetadata& OutMetadata); // Function EOSCore.CorePlayerDataStorage.EOSPlayerDataStorageCopyFileMetadataAtIndex
}; 



// Class EOSCore.EOSCorePlayerDataStorageWriteFile
// Size: 0xC8(Inherited: 0x38) 
struct UEOSCorePlayerDataStorageWriteFile : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[128];  // 0x48(0x80)

	void HandleCallback(struct FEOSPlayerDataStorageWriteFileCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePlayerDataStorageWriteFile.HandleCallback
	struct UEOSCorePlayerDataStorageWriteFile* EOSPlayerDataStorageWriteFileAsync(struct UObject* worldContextObject, struct FEOSPlayerDataStorageWriteFileOptions WriteOptions); // Function EOSCore.EOSCorePlayerDataStorageWriteFile.EOSPlayerDataStorageWriteFileAsync
}; 



// Class EOSCore.CorePresence
// Size: 0xD0(Inherited: 0x30) 
struct UCorePresence : public UEOSCoreSubsystem
{
	char pad_48[160];  // 0x30(0xA0)

	struct UCorePresence* GetPresence(struct UObject* worldContextObject); // Function EOSCore.CorePresence.GetPresence
	void EOSPresenceSetPresence(struct UObject* worldContextObject, struct FEOSPresenceSetPresenceOptions Options, struct FDelegate& Callback); // Function EOSCore.CorePresence.EOSPresenceSetPresence
	void EOSPresenceRemoveNotifyOnPresenceChanged(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CorePresence.EOSPresenceRemoveNotifyOnPresenceChanged
	void EOSPresenceRemoveNotifyJoinGameAccepted(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CorePresence.EOSPresenceRemoveNotifyJoinGameAccepted
	void EOSPresenceQueryPresence(struct UObject* worldContextObject, struct FEOSPresenceQueryPresenceOptions Options, struct FDelegate& Callback); // Function EOSCore.CorePresence.EOSPresenceQueryPresence
	uint8_t  EOSPresenceModificationSetStatus(struct UObject* worldContextObject, struct FEOSHPresenceModification& Handle, struct FEOSPresenceModificationSetStatusOptions Options); // Function EOSCore.CorePresence.EOSPresenceModificationSetStatus
	uint8_t  EOSPresenceModificationSetRawRichText(struct UObject* worldContextObject, struct FEOSHPresenceModification& Handle, struct FEOSPresenceModificationSetRawRichTextOptions Options); // Function EOSCore.CorePresence.EOSPresenceModificationSetRawRichText
	uint8_t  EOSPresenceModificationSetJoinInfo(struct UObject* worldContextObject, struct FEOSHPresenceModification& Handle, struct FEOSPresenceModificationSetJoinInfoOptions Options); // Function EOSCore.CorePresence.EOSPresenceModificationSetJoinInfo
	uint8_t  EOSPresenceModificationSetData(struct UObject* worldContextObject, struct FEOSHPresenceModification& Handle, struct FEOSPresenceModificationSetDataOptions Options); // Function EOSCore.CorePresence.EOSPresenceModificationSetData
	void EOSPresenceModificationRelease(struct UObject* worldContextObject, struct FEOSHPresenceModification& PresenceModificationHandle); // Function EOSCore.CorePresence.EOSPresenceModificationRelease
	uint8_t  EOSPresenceModificationDeleteData(struct UObject* worldContextObject, struct FEOSHPresenceModification& Handle, struct FEOSPresenceModificationDeleteDataOptions Options); // Function EOSCore.CorePresence.EOSPresenceModificationDeleteData
	bool EOSPresenceHasPresence(struct UObject* worldContextObject, struct FEOSPresenceHasPresenceOptions Options); // Function EOSCore.CorePresence.EOSPresenceHasPresence
	uint8_t  EOSPresenceGetJoinInfo(struct UObject* worldContextObject, struct FEOSPresenceGetJoinInfoOptions Options, struct FString& OutInfo); // Function EOSCore.CorePresence.EOSPresenceGetJoinInfo
	uint8_t  EOSPresenceCreatePresenceModification(struct UObject* worldContextObject, struct FEOSPresenceCreatePresenceModificationOptions Options, struct FEOSHPresenceModification& OutPresenceModificationHandle); // Function EOSCore.CorePresence.EOSPresenceCreatePresenceModification
	uint8_t  EOSPresenceCopyPresence(struct UObject* worldContextObject, struct FEOSPresenceCopyPresenceOptions Options, struct FEOSPresenceInfo& OutPresence); // Function EOSCore.CorePresence.EOSPresenceCopyPresence
	struct FEOSNotificationId EOSPresenceAddNotifyOnPresenceChanged(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CorePresence.EOSPresenceAddNotifyOnPresenceChanged
	struct FEOSNotificationId EOSPresenceAddNotifyJoinGameAccepted(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CorePresence.EOSPresenceAddNotifyJoinGameAccepted
}; 



// Class EOSCore.EOSCorePresenceQueryPresence
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCorePresenceQueryPresence : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSPresenceQueryPresenceCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePresenceQueryPresence.HandleCallback
	struct UEOSCorePresenceQueryPresence* EOSPresenceQueryPresenceAsync(struct UObject* worldContextObject, struct FEOSPresenceQueryPresenceOptions Options); // Function EOSCore.EOSCorePresenceQueryPresence.EOSPresenceQueryPresenceAsync
}; 



// Class EOSCore.EOSCorePresenceSetPresence
// Size: 0x88(Inherited: 0x38) 
struct UEOSCorePresenceSetPresence : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[64];  // 0x48(0x40)

	void HandleCallback(struct FEOSPresenceSetPresenceCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCorePresenceSetPresence.HandleCallback
	struct UEOSCorePresenceSetPresence* EOSPresenceSetPresenceAsync(struct UObject* worldContextObject, struct FEOSPresenceSetPresenceOptions Options); // Function EOSCore.EOSCorePresenceSetPresence.EOSPresenceSetPresenceAsync
}; 



// Class EOSCore.CoreProgressionSnapshot
// Size: 0x30(Inherited: 0x30) 
struct UCoreProgressionSnapshot : public UEOSCoreSubsystem
{

	struct UCoreProgressionSnapshot* GetProgressionSnapshot(struct UObject* worldContextObject); // Function EOSCore.CoreProgressionSnapshot.GetProgressionSnapshot
	void EOSProgressionSnapshotSubmitSnapshot(struct UObject* worldContextObject, struct FEOSProgressionSnapshotSubmitSnapshotOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotSubmitSnapshot
	uint8_t  EOSProgressionSnapshotEndSnapshot(struct UObject* worldContextObject, struct FEOSProgressionSnapshotEndSnapshotOptions Options); // Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotEndSnapshot
	void EOSProgressionSnapshotDeleteSnapshot(struct UObject* worldContextObject, struct FEOSProgressionSnapshotDeleteSnapshotOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotDeleteSnapshot
	uint8_t  EOSProgressionSnapshotBeginSnapshot(struct UObject* worldContextObject, struct FEOSProgressionSnapshotBeginSnapshotOptions Options, int32_t& OutSnapshotId); // Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotBeginSnapshot
	uint8_t  EOSProgressionSnapshotAddProgression(struct UObject* worldContextObject, struct FEOSProgressionSnapshotAddProgressionOptions Options); // Function EOSCore.CoreProgressionSnapshot.EOSProgressionSnapshotAddProgression
}; 



// Class EOSCore.CoreReports
// Size: 0x30(Inherited: 0x30) 
struct UCoreReports : public UEOSCoreSubsystem
{

	struct UCoreReports* GetReports(struct UObject* worldContextObject); // Function EOSCore.CoreReports.GetReports
	void EOSReportsSendPlayerBehaviorReport(struct UObject* worldContextObject, struct FEOSReportsSendPlayerBehaviorReportOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreReports.EOSReportsSendPlayerBehaviorReport
}; 



// Class EOSCore.EOSReportsSendPlayerBehaviorReport
// Size: 0xC0(Inherited: 0x38) 
struct UEOSReportsSendPlayerBehaviorReport : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[120];  // 0x48(0x78)

	void HandleCallback(struct FEOSReportsSendPlayerBehaviorReportCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSReportsSendPlayerBehaviorReport.HandleCallback
	struct UEOSReportsSendPlayerBehaviorReport* EOSReportsSendPlayerBehaviorReportAsync(struct UObject* worldContextObject, struct FEOSReportsSendPlayerBehaviorReportOptions Options); // Function EOSCore.EOSReportsSendPlayerBehaviorReport.EOSReportsSendPlayerBehaviorReportAsync
}; 



// Class EOSCore.CoreRTC
// Size: 0xD0(Inherited: 0x30) 
struct UCoreRTC : public UEOSCoreSubsystem
{
	char pad_48[160];  // 0x30(0xA0)

	struct UCoreRTC* GetRTC(struct UObject* worldContextObject); // Function EOSCore.CoreRTC.GetRTC
	void EOSRTCRemoveNotifyParticipantStatusChanged(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTC.EOSRTCRemoveNotifyParticipantStatusChanged
	void EOSRTCRemoveNotifyDisconnected(struct UObject* worldContextObject, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTC.EOSRTCRemoveNotifyDisconnected
	void EOSRTCLeaveRoom(struct UObject* worldContextObject, struct FLeaveRoomOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTC.EOSRTCLeaveRoom
	void EOSRTCJoinRoom(struct UObject* worldContextObject, struct FJoinRoomOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTC.EOSRTCJoinRoom
	struct FEOSHRTCAudio EOSRTCGetAudioInterface(struct UObject* worldContextObject); // Function EOSCore.CoreRTC.EOSRTCGetAudioInterface
	void EOSRTCBlockParticipant(struct UObject* worldContextObject, struct FBlockParticipantOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTC.EOSRTCBlockParticipant
	struct FEOSNotificationId EOSRTCAddNotifyParticipantStatusChanged(struct UObject* worldContextObject, struct FAddNotifyParticipantStatusChangedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTC.EOSRTCAddNotifyParticipantStatusChanged
	struct FEOSNotificationId EOSRTCAddNotifyDisconnected(struct UObject* worldContextObject, struct FAddNotifyDisconnectedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTC.EOSRTCAddNotifyDisconnected
}; 



// Class EOSCore.CoreRTCAdmin
// Size: 0x30(Inherited: 0x30) 
struct UCoreRTCAdmin : public UEOSCoreSubsystem
{

	struct UCoreRTCAdmin* GetRTCAdmin(struct UObject* worldContextObject); // Function EOSCore.CoreRTCAdmin.GetRTCAdmin
	void EOSRTCAdminSetParticipantHardMute(struct UObject* worldContextObject, struct FEOSSetParticipantHardMuteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAdmin.EOSRTCAdminSetParticipantHardMute
	void EOSRTCAdminQueryJoinRoomToken(struct UObject* worldContextObject, struct FEOSQueryJoinRoomTokenOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAdmin.EOSRTCAdminQueryJoinRoomToken
	void EOSRTCAdminKick(struct UObject* worldContextObject, struct FEOSKickOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAdmin.EOSRTCAdminKick
	uint8_t  EOSRTCAdminCopyUserTokenByUserId(struct UObject* worldContextObject, struct FEOSCopyUserTokenByUserIdOptions Options, struct FEOSUserToken& OutUserToken); // Function EOSCore.CoreRTCAdmin.EOSRTCAdminCopyUserTokenByUserId
	uint8_t  EOSRTCAdminCopyUserTokenByIndex(struct UObject* worldContextObject, struct FEOSCopyUserTokenByIndexOptions Options, struct FEOSUserToken& OutUserToken); // Function EOSCore.CoreRTCAdmin.EOSRTCAdminCopyUserTokenByIndex
}; 



// Class EOSCore.CoreRTCAudio
// Size: 0x210(Inherited: 0x30) 
struct UCoreRTCAudio : public UEOSCoreSubsystem
{
	char pad_48[480];  // 0x30(0x1E0)

	struct UCoreRTCAudio* GetRTCAudio(struct UObject* worldContextObject); // Function EOSCore.CoreRTCAudio.GetRTCAudio
	void EOSRTCAudioUpdateSending(struct FEOSHRTCAudio Handle, struct FEOSUpdateSendingOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioUpdateSending
	void EOSRTCAudioUpdateReceiving(struct FEOSHRTCAudio Handle, struct FEOSUpdateReceivingOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioUpdateReceiving
	uint8_t  EOSRTCAudioUnregisterPlatformAudioUser(struct FEOSHRTCAudio Handle, struct FEOSUnregisterPlatformAudioUserOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioUnregisterPlatformAudioUser
	uint8_t  EOSRTCAudioSetAudioOutputSettings(struct FEOSHRTCAudio Handle, struct FEOSSetAudioOutputSettingsOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioSetAudioOutputSettings
	uint8_t  EOSRTCAudioSetAudioInputSettings(struct FEOSHRTCAudio Handle, struct FEOSSetAudioInputSettingsOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioSetAudioInputSettings
	uint8_t  EOSRTCAudioSendAudio(struct FEOSHRTCAudio Handle, struct FEOSSendAudioOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioSendAudio
	void EOSRTCAudioRemoveNotifyParticipantUpdated(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyParticipantUpdated
	void EOSRTCAudioRemoveNotifyAudioOutputState(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioOutputState
	void EOSRTCAudioRemoveNotifyAudioInputState(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioInputState
	void EOSRTCAudioRemoveNotifyAudioDevicesChanged(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioDevicesChanged
	void EOSRTCAudioRemoveNotifyAudioBeforeSend(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioBeforeSend
	void EOSRTCAudioRemoveNotifyAudioBeforeRender(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSNotificationId NotificationID); // Function EOSCore.CoreRTCAudio.EOSRTCAudioRemoveNotifyAudioBeforeRender
	uint8_t  EOSRTCAudioRegisterPlatformAudioUser(struct FEOSHRTCAudio Handle, struct FEOSRegisterPlatformAudioUserOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioRegisterPlatformAudioUser
	int32_t EOSRTCAudioGetAudioOutputDevicesCount(struct FEOSHRTCAudio Handle, struct FEOSGetAudioOutputDevicesCountOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioOutputDevicesCount
	struct FEOSAudioOutputDeviceInfo EOSRTCAudioGetAudioOutputDeviceByIndex(struct FEOSHRTCAudio Handle, struct FEOSGetAudioOutputDeviceByIndexOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioOutputDeviceByIndex
	int32_t EOSRTCAudioGetAudioInputDevicesCount(struct FEOSHRTCAudio Handle, struct FEOSGetAudioInputDevicesCountOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioInputDevicesCount
	struct FEOSAudioInputDeviceInfo EOSRTCAudioGetAudioInputDeviceByIndex(struct FEOSHRTCAudio Handle, struct FEOSGetAudioOutputDeviceByIndexOptions Options); // Function EOSCore.CoreRTCAudio.EOSRTCAudioGetAudioInputDeviceByIndex
	struct FEOSNotificationId EOSRTCAudioAddNotifyParticipantUpdated(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSAddNotifyParticipantUpdatedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyParticipantUpdated
	struct FEOSNotificationId EOSRTCAudioAddNotifyAudioOutputState(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSAddNotifyAudioOutputStateOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioOutputState
	struct FEOSNotificationId EOSRTCAudioAddNotifyAudioInputState(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSAddNotifyAudioInputStateOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioInputState
	struct FEOSNotificationId EOSRTCAudioAddNotifyAudioDevicesChanged(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSAddNotifyAudioDevicesChangedOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioDevicesChanged
	struct FEOSNotificationId EOSRTCAudioAddNotifyAudioBeforeSend(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSAddNotifyAudioBeforeSendOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioBeforeSend
	struct FEOSNotificationId EOSRTCAudioAddNotifyAudioBeforeRender(struct UObject* worldContextObject, struct FEOSHRTCAudio Handle, struct FEOSAddNotifyAudioBeforeRenderOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreRTCAudio.EOSRTCAudioAddNotifyAudioBeforeRender
}; 



// Class EOSCore.CoreSanctions
// Size: 0x30(Inherited: 0x30) 
struct UCoreSanctions : public UEOSCoreSubsystem
{

	struct UCoreSanctions* GetSanctions(struct UObject* worldContextObject); // Function EOSCore.CoreSanctions.GetSanctions
	void EOSSanctionsQueryActivePlayerSanctions(struct UObject* worldContextObject, struct FEOSSanctionsQueryActivePlayerSanctionsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSanctions.EOSSanctionsQueryActivePlayerSanctions
	int32_t EOSSanctionsGetPlayerSanctionCount(struct UObject* worldContextObject, struct FEOSSanctionsGetPlayerSanctionCountOptions Options); // Function EOSCore.CoreSanctions.EOSSanctionsGetPlayerSanctionCount
	uint8_t  EOSSanctionsCopyPlayerSanctionByIndex(struct UObject* worldContextObject, struct FEOSSanctionsCopyPlayerSanctionByIndexOptions Options, struct FEOSSanctionsPlayerSanction& OutSanction); // Function EOSCore.CoreSanctions.EOSSanctionsCopyPlayerSanctionByIndex
}; 



// Class EOSCore.EOSSanctionsQueryActivePlayerSanctions
// Size: 0xA0(Inherited: 0x38) 
struct UEOSSanctionsQueryActivePlayerSanctions : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSSanctionsQueryActivePlayerSanctionsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSSanctionsQueryActivePlayerSanctions.HandleCallback
	struct UEOSSanctionsQueryActivePlayerSanctions* EOSSanctionsQueryActivePlayerSanctionsAsync(struct UObject* worldContextObject, struct FEOSSanctionsQueryActivePlayerSanctionsOptions Options); // Function EOSCore.EOSSanctionsQueryActivePlayerSanctions.EOSSanctionsQueryActivePlayerSanctionsAsync
}; 



// Class EOSCore.CoreSessions
// Size: 0x120(Inherited: 0x30) 
struct UCoreSessions : public UEOSCoreSubsystem
{
	char pad_48[240];  // 0x30(0xF0)

	struct UCoreSessions* GetSessions(struct UObject* worldContextObject); // Function EOSCore.CoreSessions.GetSessions
	uint8_t  EOSSessionsUpdateSessionModification(struct UObject* worldContextObject, struct FEOSSessionsUpdateSessionModificationOptions Options, struct FEOSHSessionModification& OutSessionModificationHandle); // Function EOSCore.CoreSessions.EOSSessionsUpdateSessionModification
	void EOSSessionsUpdateSession(struct UObject* worldContextObject, struct FEOSSessionsUpdateSessionOptions& Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsUpdateSession
	void EOSSessionsUnregisterPlayers(struct UObject* worldContextObject, struct FEOSSessionsUnregisterPlayersOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsUnregisterPlayers
	void EOSSessionsStartSession(struct UObject* worldContextObject, struct FEOSSessionsStartSessionOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsStartSession
	void EOSSessionsSendInvite(struct UObject* worldContextObject, struct FEOSSessionsSendInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsSendInvite
	void EOSSessionsRemoveNotifySessionInviteReceived(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreSessions.EOSSessionsRemoveNotifySessionInviteReceived
	void EOSSessionsRemoveNotifySessionInviteAccepted(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreSessions.EOSSessionsRemoveNotifySessionInviteAccepted
	void EOSSessionsRemoveNotifyJoinSessionAccepted(struct UObject* worldContextObject, struct FEOSNotificationId ID); // Function EOSCore.CoreSessions.EOSSessionsRemoveNotifyJoinSessionAccepted
	void EOSSessionsRejectInvite(struct UObject* worldContextObject, struct FEOSSessionsRejectInviteOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsRejectInvite
	void EOSSessionsRegisterPlayers(struct UObject* worldContextObject, struct FEOSSessionsRegisterPlayersOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsRegisterPlayers
	void EOSSessionsQueryInvites(struct UObject* worldContextObject, struct FEOSSessionsQueryInvitesOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsQueryInvites
	void EOSSessionsJoinSession(struct UObject* worldContextObject, struct FEOSSessionsJoinSessionOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsJoinSession
	uint8_t  EOSSessionsIsUserInSession(struct UObject* worldContextObject, struct FEOSSessionsIsUserInSessionOptions Options); // Function EOSCore.CoreSessions.EOSSessionsIsUserInSession
	uint8_t  EOSSessionsGetInviteIdByIndex(struct UObject* worldContextObject, struct FEOSSessionsGetInviteIdByIndexOptions Options, struct FString& OutBuffer); // Function EOSCore.CoreSessions.EOSSessionsGetInviteIdByIndex
	int32_t EOSSessionsGetInviteCount(struct UObject* worldContextObject, struct FEOSSessionsGetInviteCountOptions Options); // Function EOSCore.CoreSessions.EOSSessionsGetInviteCount
	void EOSSessionsEndSession(struct UObject* worldContextObject, struct FEOSSessionsEndSessionOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsEndSession
	uint8_t  EOSSessionSearchSetTargetUserId(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FEOSSessionSearchSetTargetUserIdOptions Options); // Function EOSCore.CoreSessions.EOSSessionSearchSetTargetUserId
	uint8_t  EOSSessionSearchSetSessionId(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FEOSSessionSearchSetSessionIdOptions Options); // Function EOSCore.CoreSessions.EOSSessionSearchSetSessionId
	uint8_t  EOSSessionSearchSetParameterString(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FString Key, struct FString Value, uint8_t  ComparisonOp); // Function EOSCore.CoreSessions.EOSSessionSearchSetParameterString
	uint8_t  EOSSessionSearchSetParameterInt64(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FString Key, struct FString Value, uint8_t  ComparisonOp); // Function EOSCore.CoreSessions.EOSSessionSearchSetParameterInt64
	uint8_t  EOSSessionSearchSetParameterDouble(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FString Key, struct FString Value, uint8_t  ComparisonOp); // Function EOSCore.CoreSessions.EOSSessionSearchSetParameterDouble
	uint8_t  EOSSessionSearchSetParameterBool(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FString Key, bool bValue, uint8_t  ComparisonOp); // Function EOSCore.CoreSessions.EOSSessionSearchSetParameterBool
	uint8_t  EOSSessionSearchSetMaxResults(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FEOSSessionSearchSetMaxResultsOptions Options); // Function EOSCore.CoreSessions.EOSSessionSearchSetMaxResults
	uint8_t  EOSSessionSearchRemoveParameter(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FEOSSessionSearchRemoveParameterOptions Options); // Function EOSCore.CoreSessions.EOSSessionSearchRemoveParameter
	void EOSSessionSearchRelease(struct UObject* worldContextObject, struct FEOSHSessionSearch& SessionSearchHandle); // Function EOSCore.CoreSessions.EOSSessionSearchRelease
	int32_t EOSSessionSearchGetSearchResultCount(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FEOSSessionSearchGetSearchResultCountOptions Options); // Function EOSCore.CoreSessions.EOSSessionSearchGetSearchResultCount
	void EOSSessionSearchFind(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FEOSSessionSearchFindOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionSearchFind
	uint8_t  EOSSessionSearchCopySearchResultByIndex(struct UObject* worldContextObject, struct FEOSHSessionSearch& Handle, struct FEOSSessionSearchCopySearchResultByIndexOptions& Options, struct FEOSHSessionDetails& OutSessionHandle); // Function EOSCore.CoreSessions.EOSSessionSearchCopySearchResultByIndex
	uint8_t  EOSSessionsDumpSessionState(struct UObject* worldContextObject, struct FEOSSessionsDumpSessionStateOptions Options); // Function EOSCore.CoreSessions.EOSSessionsDumpSessionState
	void EOSSessionsDestroySession(struct UObject* worldContextObject, struct FEOSSessionsDestroySessionOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsDestroySession
	uint8_t  EOSSessionsCreateSessionSearch(struct UObject* worldContextObject, struct FEOSSessionsCreateSessionSearchOptions Options, struct FEOSHSessionSearch& OutSessionSearchHandle); // Function EOSCore.CoreSessions.EOSSessionsCreateSessionSearch
	uint8_t  EOSSessionsCreateSessionModification(struct UObject* worldContextObject, struct FEOSSessionsCreateSessionModificationOptions Options, struct FEOSHSessionModification& OutSessionModificationHandle); // Function EOSCore.CoreSessions.EOSSessionsCreateSessionModification
	uint8_t  EOSSessionsCopySessionHandleForPresence(struct UObject* worldContextObject, struct FEOSSessionsCopySessionHandleForPresenceOptions Options, struct FEOSHSessionDetails& OutSessionHandle); // Function EOSCore.CoreSessions.EOSSessionsCopySessionHandleForPresence
	uint8_t  EOSSessionsCopySessionHandleByUiEventId(struct UObject* worldContextObject, struct FEOSSessionsCopySessionHandleByUiEventIdOptions Options, struct FEOSHSessionDetails& OutSessionHandle); // Function EOSCore.CoreSessions.EOSSessionsCopySessionHandleByUiEventId
	uint8_t  EOSSessionsCopySessionHandleByInviteId(struct UObject* worldContextObject, struct FEOSSessionsCopySessionHandleByInviteIdOptions Options, struct FEOSHSessionDetails& OutSessionHandle); // Function EOSCore.CoreSessions.EOSSessionsCopySessionHandleByInviteId
	uint8_t  EOSSessionsCopyActiveSessionHandle(struct UObject* worldContextObject, struct FEOSSessionsCopyActiveSessionHandleOptions Options, struct FEOSHActiveSession& OutSessionHandle); // Function EOSCore.CoreSessions.EOSSessionsCopyActiveSessionHandle
	struct FEOSNotificationId EOSSessionsAddNotifySessionInviteReceived(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsAddNotifySessionInviteReceived
	struct FEOSNotificationId EOSSessionsAddNotifySessionInviteAccepted(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsAddNotifySessionInviteAccepted
	struct FEOSNotificationId EOSSessionsAddNotifyJoinSessionAccepted(struct UObject* worldContextObject, struct FDelegate& Callback); // Function EOSCore.CoreSessions.EOSSessionsAddNotifyJoinSessionAccepted
	uint8_t  EOSSessionModificationSetPermissionLevel(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, struct FEOSSessionModificationSetPermissionLevelOptions Options); // Function EOSCore.CoreSessions.EOSSessionModificationSetPermissionLevel
	uint8_t  EOSSessionModificationSetMaxPlayers(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, struct FEOSSessionModificationSetMaxPlayersOptions Options); // Function EOSCore.CoreSessions.EOSSessionModificationSetMaxPlayers
	uint8_t  EOSSessionModificationSetJoinInProgressAllowed(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, struct FEOSSessionModificationSetJoinInProgressAllowedOptions Options); // Function EOSCore.CoreSessions.EOSSessionModificationSetJoinInProgressAllowed
	uint8_t  EOSSessionModificationSetInvitesAllowed(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, struct FEOSSessionModificationSetInvitesAllowedOptions Options); // Function EOSCore.CoreSessions.EOSSessionModificationSetInvitesAllowed
	uint8_t  EOSSessionModificationSetHostAddress(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, struct FEOSSessionModificationSetHostAddressOptions Options); // Function EOSCore.CoreSessions.EOSSessionModificationSetHostAddress
	uint8_t  EOSSessionModificationSetBucketId(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, struct FEOSSessionModificationSetBucketIdOptions Options); // Function EOSCore.CoreSessions.EOSSessionModificationSetBucketId
	uint8_t  EOSSessionModificationRemoveAttribute(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, struct FEOSSessionModificationRemoveAttributeOptions& Options); // Function EOSCore.CoreSessions.EOSSessionModificationRemoveAttribute
	void EOSSessionModificationRelease(struct UObject* worldContextObject, struct FEOSHSessionModification& SessionModificationHandle); // Function EOSCore.CoreSessions.EOSSessionModificationRelease
	uint8_t  EOSSessionModificationAddAttributeString(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, uint8_t  AdvertisementType, struct FString Key, struct FString Value); // Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeString
	uint8_t  EOSSessionModificationAddAttributeInt64(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, uint8_t  AdvertisementType, struct FString Key, struct FString Value); // Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeInt64
	uint8_t  EOSSessionModificationAddAttributeDouble(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, uint8_t  AdvertisementType, struct FString Key, struct FString Value); // Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeDouble
	uint8_t  EOSSessionModificationAddAttributeBool(struct UObject* worldContextObject, struct FEOSHSessionModification& Handle, uint8_t  AdvertisementType, struct FString Key, bool bValue); // Function EOSCore.CoreSessions.EOSSessionModificationAddAttributeBool
	void EOSSessionDetailsRelease(struct UObject* worldContextObject, struct FEOSHSessionDetails& SessionHandle); // Function EOSCore.CoreSessions.EOSSessionDetailsRelease
	int32_t EOSSessionDetailsGetSessionAttributeCount(struct UObject* worldContextObject, struct FEOSHSessionDetails& Handle, struct FEOSSessionDetailsGetSessionAttributeCountOptions Options); // Function EOSCore.CoreSessions.EOSSessionDetailsGetSessionAttributeCount
	uint8_t  EOSSessionDetailsCopySessionAttributeByKey(struct UObject* worldContextObject, struct FEOSHSessionDetails& Handle, struct FEOSSessionDetailsCopySessionAttributeByKeyOptions Options, struct FEOSSessionDetailsAttribute& OutSessionAttribute); // Function EOSCore.CoreSessions.EOSSessionDetailsCopySessionAttributeByKey
	uint8_t  EOSSessionDetailsCopySessionAttributeByIndex(struct UObject* worldContextObject, struct FEOSHSessionDetails& Handle, struct FEOSSessionDetailsCopySessionAttributeByIndexOptions Options, struct FEOSSessionDetailsAttribute& OutSessionAttribute); // Function EOSCore.CoreSessions.EOSSessionDetailsCopySessionAttributeByIndex
	uint8_t  EOSSessionDetailsCopyInfo(struct UObject* worldContextObject, struct FEOSHSessionDetails& Handle, struct FEOSSessionDetailsCopyInfoOptions Options, struct FEOSSessionDetailsInfo& outSessionInfo); // Function EOSCore.CoreSessions.EOSSessionDetailsCopyInfo
	void EOSActiveSessionRelease(struct UObject* worldContextObject, struct FEOSHActiveSession& ActiveSessionHandle); // Function EOSCore.CoreSessions.EOSActiveSessionRelease
	int32_t EOSActiveSessionGetRegisteredPlayerCount(struct UObject* worldContextObject, struct FEOSHActiveSession& Handle, struct FEOSActiveSessionGetRegisteredPlayerCountOptions Options); // Function EOSCore.CoreSessions.EOSActiveSessionGetRegisteredPlayerCount
	struct FEOSProductUserId EOSActiveSessionGetRegisteredPlayerByIndex(struct UObject* worldContextObject, struct FEOSHActiveSession& Handle, struct FEOSActiveSessionGetRegisteredPlayerByIndexOptions Options); // Function EOSCore.CoreSessions.EOSActiveSessionGetRegisteredPlayerByIndex
	uint8_t  EOSActiveSessionCopyInfo(struct UObject* worldContextObject, struct FEOSHActiveSession& Handle, struct FEOSActiveSessionCopyInfoOptions Options, struct FEOSActiveSessionInfo& OutActiveSessionInfo); // Function EOSCore.CoreSessions.EOSActiveSessionCopyInfo
}; 



// Class EOSCore.EOSCoreSessionsUpdateSession
// Size: 0x60(Inherited: 0x38) 
struct UEOSCoreSessionsUpdateSession : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[24];  // 0x48(0x18)

	void HandleCallback(struct FEOSSessionsUpdateSessionCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsUpdateSession.HandleCallback
	struct UEOSCoreSessionsUpdateSession* EOSSessionsUpdateSessionAsync(struct UObject* worldContextObject, struct FEOSSessionsUpdateSessionOptions Options); // Function EOSCore.EOSCoreSessionsUpdateSession.EOSSessionsUpdateSessionAsync
}; 



// Class EOSCore.EOSCoreSessionsDestroySession
// Size: 0x68(Inherited: 0x38) 
struct UEOSCoreSessionsDestroySession : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[32];  // 0x48(0x20)

	void HandleCallback(struct FEOSSessionsDestroySessionCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsDestroySession.HandleCallback
	struct UEOSCoreSessionsDestroySession* EOSSessionsDestroySessionAsync(struct UObject* worldContextObject, struct FEOSSessionsDestroySessionOptions Options); // Function EOSCore.EOSCoreSessionsDestroySession.EOSSessionsDestroySessionAsync
}; 



// Class EOSCore.EOSCoreSessionsJoinSession
// Size: 0x98(Inherited: 0x38) 
struct UEOSCoreSessionsJoinSession : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[80];  // 0x48(0x50)

	void HandleCallback(struct FEOSSessionsJoinSessionCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsJoinSession.HandleCallback
	struct UEOSCoreSessionsJoinSession* EOSSessionsJoinSessionAsync(struct UObject* worldContextObject, struct FEOSSessionsJoinSessionOptions Options); // Function EOSCore.EOSCoreSessionsJoinSession.EOSSessionsJoinSessionAsync
}; 



// Class EOSCore.EOSCoreSessionsStartSession
// Size: 0x68(Inherited: 0x38) 
struct UEOSCoreSessionsStartSession : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[32];  // 0x48(0x20)

	void HandleCallback(struct FEOSSessionsStartSessionCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsStartSession.HandleCallback
	struct UEOSCoreSessionsStartSession* EOSSessionsStartSessionAsync(struct UObject* worldContextObject, struct FEOSSessionsStartSessionOptions Options); // Function EOSCore.EOSCoreSessionsStartSession.EOSSessionsStartSessionAsync
}; 



// Class EOSCore.EOSCoreSessionsEndSession
// Size: 0x68(Inherited: 0x38) 
struct UEOSCoreSessionsEndSession : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[32];  // 0x48(0x20)

	void HandleCallback(struct FEOSSessionsEndSessionCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsEndSession.HandleCallback
	struct UEOSCoreSessionsEndSession* EOSSessionsEndSessionAsync(struct UObject* worldContextObject, struct FEOSSessionsEndSessionOptions Options); // Function EOSCore.EOSCoreSessionsEndSession.EOSSessionsEndSessionAsync
}; 



// Class EOSCore.EOSCoreSessionsRegisterPlayers
// Size: 0x78(Inherited: 0x38) 
struct UEOSCoreSessionsRegisterPlayers : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[48];  // 0x48(0x30)

	void HandleCallback(struct FEOSSessionsRegisterPlayersCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsRegisterPlayers.HandleCallback
	struct UEOSCoreSessionsRegisterPlayers* EOSSessionsRegisterPlayersAsync(struct UObject* worldContextObject, struct FEOSSessionsRegisterPlayersOptions Options); // Function EOSCore.EOSCoreSessionsRegisterPlayers.EOSSessionsRegisterPlayersAsync
}; 



// Class EOSCore.EOSCoreSessionsUnregisterPlayers
// Size: 0x78(Inherited: 0x38) 
struct UEOSCoreSessionsUnregisterPlayers : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[48];  // 0x48(0x30)

	void HandleCallback(struct FEOSSessionsUnregisterPlayersCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsUnregisterPlayers.HandleCallback
	struct UEOSCoreSessionsUnregisterPlayers* EOSSessionsUnregisterPlayersAsync(struct UObject* worldContextObject, struct FEOSSessionsUnregisterPlayersOptions Options); // Function EOSCore.EOSCoreSessionsUnregisterPlayers.EOSSessionsUnregisterPlayersAsync
}; 



// Class EOSCore.EOSCoreSessionsSendInvite
// Size: 0xB0(Inherited: 0x38) 
struct UEOSCoreSessionsSendInvite : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[104];  // 0x48(0x68)

	void HandleCallback(struct FEOSSessionsSendInviteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsSendInvite.HandleCallback
	struct UEOSCoreSessionsSendInvite* EOSSessionsSendInviteAsync(struct UObject* worldContextObject, struct FEOSSessionsSendInviteOptions Options); // Function EOSCore.EOSCoreSessionsSendInvite.EOSSessionsSendInviteAsync
}; 



// Class EOSCore.EOSCoreSessionsRejectInvite
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreSessionsRejectInvite : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSSessionsRejectInviteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsRejectInvite.HandleCallback
	struct UEOSCoreSessionsRejectInvite* EOSSessionsRejectInviteAsync(struct UObject* worldContextObject, struct FEOSSessionsRejectInviteOptions Options); // Function EOSCore.EOSCoreSessionsRejectInvite.EOSSessionsRejectInviteAsync
}; 



// Class EOSCore.EOSCoreSessionsQueryInvites
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreSessionsQueryInvites : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSSessionsQueryInvitesCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreSessionsQueryInvites.HandleCallback
	struct UEOSCoreSessionsQueryInvites* EOSSessionsQueryInvitesAsync(struct UObject* worldContextObject, struct FEOSSessionsQueryInvitesOptions Options); // Function EOSCore.EOSCoreSessionsQueryInvites.EOSSessionsQueryInvitesAsync
}; 



// Class EOSCore.CoreStats
// Size: 0x30(Inherited: 0x30) 
struct UCoreStats : public UEOSCoreSubsystem
{

	struct UCoreStats* GetStats(struct UObject* worldContextObject); // Function EOSCore.CoreStats.GetStats
	void EOSStatsQueryStats(struct UObject* worldContextObject, struct FEOSStatsQueryStatsOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreStats.EOSStatsQueryStats
	void EOSStatsIngestStat(struct UObject* worldContextObject, struct FEOSStatsIngestStatOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreStats.EOSStatsIngestStat
	int32_t EOSStatsGetStatsCount(struct UObject* worldContextObject, struct FEOSStatsGetStatCountOptions Options); // Function EOSCore.CoreStats.EOSStatsGetStatsCount
	uint8_t  EOSStatsCopyStatByName(struct UObject* worldContextObject, struct FEOSStatsCopyStatByNameOptions Options, struct FEOSStatsStat& OutStat); // Function EOSCore.CoreStats.EOSStatsCopyStatByName
	uint8_t  EOSStatsCopyStatByIndex(struct UObject* worldContextObject, struct FEOSStatsCopyStatByIndexOptions Options, struct FEOSStatsStat& OutStat); // Function EOSCore.CoreStats.EOSStatsCopyStatByIndex
}; 



// Class EOSCore.EOSCoreStatsIngestStat
// Size: 0xB8(Inherited: 0x38) 
struct UEOSCoreStatsIngestStat : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[112];  // 0x48(0x70)

	void HandleCallback(struct FEOSStatsIngestStatCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreStatsIngestStat.HandleCallback
	struct UEOSCoreStatsIngestStat* EOSStatsIngestStatAsync(struct UObject* worldContextObject, struct FEOSStatsIngestStatOptions Options); // Function EOSCore.EOSCoreStatsIngestStat.EOSStatsIngestStatAsync
}; 



// Class EOSCore.EOSCoreStatsQueryStats
// Size: 0xD8(Inherited: 0x38) 
struct UEOSCoreStatsQueryStats : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[144];  // 0x48(0x90)

	void HandleCallback(struct FEOSStatsOnQueryStatsCompleteCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreStatsQueryStats.HandleCallback
	struct UEOSCoreStatsQueryStats* EOSStatsQueryStatsAsync(struct UObject* worldContextObject, struct FEOSStatsQueryStatsOptions Options); // Function EOSCore.EOSCoreStatsQueryStats.EOSStatsQueryStatsAsync
}; 



// Class EOSCore.CoreTitleStorage
// Size: 0x30(Inherited: 0x30) 
struct UCoreTitleStorage : public UEOSCoreSubsystem
{

	struct UCoreTitleStorage* GetTitleStorage(struct UObject* worldContextObject); // Function EOSCore.CoreTitleStorage.GetTitleStorage
	struct FEOSTitleStorageFileTransferRequestHandle EOSTitleStorageReadFile(struct UObject* worldContextObject, struct FEOSTitleStorageReadFileOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreTitleStorage.EOSTitleStorageReadFile
	void EOSTitleStorageQueryFileList(struct UObject* worldContextObject, struct FEOSTitleStorageQueryFileListOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreTitleStorage.EOSTitleStorageQueryFileList
	void EOSTitleStorageQueryFile(struct UObject* worldContextObject, struct FEOSTitleStorageQueryFileOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreTitleStorage.EOSTitleStorageQueryFile
	int32_t EOSTitleStorageGetFileMetadataCount(struct UObject* worldContextObject, struct FEOSTitleStorageGetFileMetadataCountOptions Options); // Function EOSCore.CoreTitleStorage.EOSTitleStorageGetFileMetadataCount
	uint8_t  EOSTitleStorageFileTransferRequestGetFileRequestState(struct UObject* worldContextObject, struct FEOSTitleStorageFileTransferRequestHandle& Handle); // Function EOSCore.CoreTitleStorage.EOSTitleStorageFileTransferRequestGetFileRequestState
	uint8_t  EOSTitleStorageFileTransferRequestGetFilename(struct UObject* worldContextObject, struct FEOSTitleStorageFileTransferRequestHandle& Handle, int32_t FilenameStringBufferSizeBytes, struct FString& OutStringBuffer); // Function EOSCore.CoreTitleStorage.EOSTitleStorageFileTransferRequestGetFilename
	uint8_t  EOSTitleStorageFileTransferRequestCancelRequest(struct UObject* worldContextObject, struct FEOSTitleStorageFileTransferRequestHandle& Handle); // Function EOSCore.CoreTitleStorage.EOSTitleStorageFileTransferRequestCancelRequest
	uint8_t  EOSTitleStorageDeleteCache(struct UObject* worldContextObject, struct FEOSTitleStorageDeleteCacheOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreTitleStorage.EOSTitleStorageDeleteCache
	uint8_t  EOSTitleStorageCopyFileMetadataByFilename(struct UObject* worldContextObject, struct FEOSTitleStorageCopyFileMetadataByFilenameOptions Options, struct FEOSTitleStorageFileMetadata& OutMetadata); // Function EOSCore.CoreTitleStorage.EOSTitleStorageCopyFileMetadataByFilename
	uint8_t  EOSTitleStorageCopyFileMetadataAtIndex(struct UObject* worldContextObject, struct FEOSTitleStorageCopyFileMetadataAtIndexOptions Options, struct FEOSTitleStorageFileMetadata& OutMetadata); // Function EOSCore.CoreTitleStorage.EOSTitleStorageCopyFileMetadataAtIndex
}; 



// Class EOSCore.EOSCoreTitleStorageQueryFile
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreTitleStorageQueryFile : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSTitleStorageQueryFileCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreTitleStorageQueryFile.HandleCallback
	struct UEOSCoreTitleStorageQueryFile* EOSTitleStorageQueryFileAsync(struct UObject* worldContextObject, struct FEOSTitleStorageQueryFileOptions Options); // Function EOSCore.EOSCoreTitleStorageQueryFile.EOSTitleStorageQueryFileAsync
}; 



// Class EOSCore.EOSCoreTitleStorageQueryFileList
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreTitleStorageQueryFileList : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSTitleStorageQueryFileListCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreTitleStorageQueryFileList.HandleCallback
	struct UEOSCoreTitleStorageQueryFileList* EOSTitleStorageQueryFileListAsync(struct UObject* worldContextObject, struct FEOSTitleStorageQueryFileListOptions Options); // Function EOSCore.EOSCoreTitleStorageQueryFileList.EOSTitleStorageQueryFileListAsync
}; 



// Class EOSCore.EOSCoreTitleStorageDeleteCache
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreTitleStorageDeleteCache : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSTitleStorageDeleteCacheCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreTitleStorageDeleteCache.HandleCallback
	struct UEOSCoreTitleStorageDeleteCache* EOSTitleStorageDeleteCacheAsync(struct UObject* worldContextObject, struct FEOSTitleStorageDeleteCacheOptions Options); // Function EOSCore.EOSCoreTitleStorageDeleteCache.EOSTitleStorageDeleteCacheAsync
}; 



// Class EOSCore.EOSCoreUIHideFriends
// Size: 0x80(Inherited: 0x38) 
struct UEOSCoreUIHideFriends : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[56];  // 0x48(0x38)

	void HandleCallback(struct FEOSUIHideFriendsCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreUIHideFriends.HandleCallback
	struct UEOSCoreUIHideFriends* EOSUIHideFriendsAsync(struct UObject* worldContextObject, struct FEOSUIHideFriendsOptions Options); // Function EOSCore.EOSCoreUIHideFriends.EOSUIHideFriendsAsync
}; 



// Class EOSCore.CoreUserInfo
// Size: 0x30(Inherited: 0x30) 
struct UCoreUserInfo : public UEOSCoreSubsystem
{

	struct UCoreUserInfo* GetUserInfo(struct UObject* worldContextObject); // Function EOSCore.CoreUserInfo.GetUserInfo
	void EOSUserInfoQueryUserInfoByExternalAccount(struct UObject* worldContextObject, struct FEOSUserInfoQueryUserInfoByExternalAccountOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreUserInfo.EOSUserInfoQueryUserInfoByExternalAccount
	void EOSUserInfoQueryUserInfoByDisplayName(struct UObject* worldContextObject, struct FEOSUserInfoQueryUserInfoByDisplayNameOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreUserInfo.EOSUserInfoQueryUserInfoByDisplayName
	void EOSUserInfoQueryUserInfo(struct UObject* worldContextObject, struct FEOSUserInfoQueryUserInfoOptions Options, struct FDelegate& Callback); // Function EOSCore.CoreUserInfo.EOSUserInfoQueryUserInfo
	int32_t EOSUserInfoGetExternalUserInfoCount(struct UObject* worldContextObject, struct FEOSUserInfoGetExternalUserInfoCountOptions Options); // Function EOSCore.CoreUserInfo.EOSUserInfoGetExternalUserInfoCount
	uint8_t  EOSUserInfoCopyUserInfo(struct UObject* worldContextObject, struct FEOSUserInfoCopyUserInfoOptions Options, struct FEOSUserInfo& OutUserInfo); // Function EOSCore.CoreUserInfo.EOSUserInfoCopyUserInfo
	uint8_t  EOSUserInfoCopyExternalUserInfoByIndex(struct UObject* worldContextObject, struct FEOSUserInfoCopyExternalUserInfoByIndexOptions Options, struct FEOSUserInfoExternalUserInfo& OutExternalUserInfo); // Function EOSCore.CoreUserInfo.EOSUserInfoCopyExternalUserInfoByIndex
	uint8_t  EOSUserInfoCopyExternalUserInfoByAccountType(struct UObject* worldContextObject, struct FEOSUserInfoCopyExternalUserInfoByAccountTypeOptions Options, struct FEOSUserInfoExternalUserInfo& OutExternalUserInfo); // Function EOSCore.CoreUserInfo.EOSUserInfoCopyExternalUserInfoByAccountType
	uint8_t  EOSUserInfoCopyExternalUserInfoByAccountId(struct UObject* worldContextObject, struct FEOSUserInfoCopyExternalUserInfoByAccountIdOptions Options, struct FEOSUserInfoExternalUserInfo& OutExternalUserInfo); // Function EOSCore.CoreUserInfo.EOSUserInfoCopyExternalUserInfoByAccountId
}; 



// Class EOSCore.EOSCoreUserInfoQueryUserInfo
// Size: 0xA0(Inherited: 0x38) 
struct UEOSCoreUserInfoQueryUserInfo : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[88];  // 0x48(0x58)

	void HandleCallback(struct FEOSUserInfoQueryUserInfoCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreUserInfoQueryUserInfo.HandleCallback
	struct UEOSCoreUserInfoQueryUserInfo* EOSUserInfoQueryUserInfoAsync(struct UObject* worldContextObject, struct FEOSUserInfoQueryUserInfoOptions Options); // Function EOSCore.EOSCoreUserInfoQueryUserInfo.EOSUserInfoQueryUserInfoAsync
}; 



// Class EOSCore.EOSCoreUserInfoQueryUserInfoByDisplayName
// Size: 0x90(Inherited: 0x38) 
struct UEOSCoreUserInfoQueryUserInfoByDisplayName : public UEOSCoreAsyncAction
{
	struct FMulticastInlineDelegate OnCallback;  // 0x38(0x10)
	char pad_72[72];  // 0x48(0x48)

	void HandleCallback(struct FEOSUserInfoQueryUserInfoByDisplayNameCallbackInfo& Data, bool bWasSuccessful); // Function EOSCore.EOSCoreUserInfoQueryUserInfoByDisplayName.HandleCallback
	struct UEOSCoreUserInfoQueryUserInfoByDisplayName* EOSUserInfoQueryUserInfoByDisplayNameAsync(struct UObject* worldContextObject, struct FEOSUserInfoQueryUserInfoByDisplayNameOptions Options); // Function EOSCore.EOSCoreUserInfoQueryUserInfoByDisplayName.EOSUserInfoQueryUserInfoByDisplayNameAsync
}; 



