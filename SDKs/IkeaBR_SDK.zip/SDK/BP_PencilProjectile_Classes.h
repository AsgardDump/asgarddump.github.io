#pragma once 
#include <BP_PencilProjectile_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PencilProjectile.BP_PencilProjectile_C
// Size: 0x257(Inherited: 0x257) 
struct ABP_PencilProjectile_C : public ABP_Projectile_C
{

}; 



