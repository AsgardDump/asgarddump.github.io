#pragma once 
#include <CrateOpenCinematic_Structs.h>
 
 
 
// BlueprintGeneratedClass CrateOpenCinematic.SequenceDirector_C
// Size: 0x40(Inherited: 0x38) 
struct USequenceDirector_C : public ULevelSequenceDirector
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x38(0x8)

	void SequenceEvent__ENTRYPOINTSequenceDirector_3(struct ABP_LootCrate_C* BP_LootCrate); // Function CrateOpenCinematic.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_3
	void SequenceEvent__ENTRYPOINTSequenceDirector_2(struct ABP_LootCrate_C* BP_LootCrate); // Function CrateOpenCinematic.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
	void SequenceEvent__ENTRYPOINTSequenceDirector_1(struct ABP_LootCrate_C* BP_LootCrate); // Function CrateOpenCinematic.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
	void BP_LootCrate_Event_1(struct ABP_LootCrate_C* BP_LootCrate); // Function CrateOpenCinematic.SequenceDirector_C.BP_LootCrate_Event_1
	void BP_LootCrate_Event_2(struct ABP_LootCrate_C* BP_LootCrate); // Function CrateOpenCinematic.SequenceDirector_C.BP_LootCrate_Event_2
	void BP_LootCrate_Event_3(struct ABP_LootCrate_C* BP_LootCrate); // Function CrateOpenCinematic.SequenceDirector_C.BP_LootCrate_Event_3
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function CrateOpenCinematic.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
}; 



