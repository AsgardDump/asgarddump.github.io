#pragma once 
#include "SDK.h" 
 
 
// Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.ExecuteUbergraph_BP_DazGlobalIntercom
// Size: 0x71(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DazGlobalIntercom
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_3 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_4 : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue_5;  // 0x24(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_6;  // 0x28(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_7;  // 0x2C(0x4)
	struct TArray<struct USoundBase*> K2Node_CustomEvent_Sounds;  // 0x30(0x10)
	struct USoundBase* K2Node_CustomEvent_Sound;  // 0x40(0x8)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x48(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x4C(0x4)
	struct USoundBase* CallFunc_Array_Get_Item;  // 0x50(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_IsPlaying_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93[3];  // 0x5D(0x3)
	int32_t K2Node_CustomEvent_Num_Players_Left;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x65(0x1)
	char pad_102_1 : 7;  // 0x66(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_3 : 1;  // 0x66(0x1)
	char pad_103_1 : 7;  // 0x67(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_4 : 1;  // 0x67(0x1)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_5 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_6 : 1;  // 0x69(0x1)
	char pad_106_1 : 7;  // 0x6A(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_7 : 1;  // 0x6A(0x1)
	char pad_107[1];  // 0x6B(0x1)
	float CallFunc_RandomFloatInRange_ReturnValue_8;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_8 : 1;  // 0x70(0x1)

}; 
// Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayRandomPlayersRemainingVoiceline
// Size: 0x4(Inherited: 0x0) 
struct FPlayRandomPlayersRemainingVoiceline
{
	int32_t Num Players Left;  // 0x0(0x4)

}; 
// Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayRandomVoiceline
// Size: 0x10(Inherited: 0x0) 
struct FPlayRandomVoiceline
{
	struct TArray<struct USoundBase*> Sounds;  // 0x0(0x10)

}; 
// Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.MultiPlaySound
// Size: 0x8(Inherited: 0x0) 
struct FMultiPlaySound
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
