#pragma once 
#include <BP_Stim_Regen_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Stim_Regen.BP_Stim_Regen_C
// Size: 0x280(Inherited: 0x280) 
struct ABP_Stim_Regen_C : public ABP_StimBase_C
{

}; 



