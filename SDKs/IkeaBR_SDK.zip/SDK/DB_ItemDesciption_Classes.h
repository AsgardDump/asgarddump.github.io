#pragma once 
#include <DB_ItemDesciption_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DB_ItemDesciption.DB_ItemDesciption_C
// Size: 0x2CC(Inherited: 0x260) 
struct UDB_ItemDesciption_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct USizeBox* Cost_size;  // 0x268(0x8)
	struct UHorizontalBox* Costs;  // 0x270(0x8)
	struct URR_ProgressBar_Plain_C* DamageBar;  // 0x278(0x8)
	struct UTextBlock* DamageNumber;  // 0x280(0x8)
	struct UTextBlock* DescriptionText;  // 0x288(0x8)
	struct URR_ProgressBar_Plain_C* DrainBar;  // 0x290(0x8)
	struct UTextBlock* DrainText;  // 0x298(0x8)
	struct UWidgetSwitcher* Item;  // 0x2A0(0x8)
	struct UTextBlock* NameText;  // 0x2A8(0x8)
	struct UWidgetSwitcher* RandomItem_Switcher;  // 0x2B0(0x8)
	struct URR_ProgressBar_Plain_C* SpeedBar;  // 0x2B8(0x8)
	struct UTextBlock* SpeedText;  // 0x2C0(0x8)
	int32_t ItemId;  // 0x2C8(0x4)

	void UpdateItem(); // Function DB_ItemDesciption.DB_ItemDesciption_C.UpdateItem
	void ExecuteUbergraph_DB_ItemDesciption(int32_t EntryPoint); // Function DB_ItemDesciption.DB_ItemDesciption_C.ExecuteUbergraph_DB_ItemDesciption
}; 



