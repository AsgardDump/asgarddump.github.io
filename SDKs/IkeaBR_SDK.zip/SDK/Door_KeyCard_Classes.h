#pragma once 
#include <Door_KeyCard_Structs.h>
 
 
 
// BlueprintGeneratedClass Door_KeyCard.Door_KeyCard_C
// Size: 0x251(Inherited: 0x220) 
struct ADoor_KeyCard_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* Scene1;  // 0x230(0x8)
	struct USceneComponent* Scene;  // 0x238(0x8)
	float Timeline_0_rotation_EFB8E5D44E7C585497402588014965E0;  // 0x240(0x4)
	char ETimelineDirection Timeline_0__Direction_EFB8E5D44E7C585497402588014965E0;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool Open : 1;  // 0x250(0x1)

	void RecieveServerLook(bool& Recieve?); // Function Door_KeyCard.Door_KeyCard_C.RecieveServerLook
	void OnRep_Open(); // Function Door_KeyCard.Door_KeyCard_C.OnRep_Open
	void Timeline_0__FinishedFunc(); // Function Door_KeyCard.Door_KeyCard_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function Door_KeyCard.Door_KeyCard_C.Timeline_0__UpdateFunc
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function Door_KeyCard.Door_KeyCard_C.OnInteract
	void OnChargeUpdate(float Charge, struct AFirstPersonCharacter_C* Caller); // Function Door_KeyCard.Door_KeyCard_C.OnChargeUpdate
	void ServerOnLook(struct AFirstPersonCharacter_C* Player); // Function Door_KeyCard.Door_KeyCard_C.ServerOnLook
	void ServerOnStopLook(struct AFirstPersonCharacter_C* Player); // Function Door_KeyCard.Door_KeyCard_C.ServerOnStopLook
	void Open Server(struct AFirstPersonCharacter_C* opener); // Function Door_KeyCard.Door_KeyCard_C.Open Server
	void open Multi(); // Function Door_KeyCard.Door_KeyCard_C.open Multi
	void OpenClient(); // Function Door_KeyCard.Door_KeyCard_C.OpenClient
	void CloseMulti(); // Function Door_KeyCard.Door_KeyCard_C.CloseMulti
	void Closeclient(); // Function Door_KeyCard.Door_KeyCard_C.Closeclient
	void OnLook(struct AFirstPersonCharacter_C* Caller); // Function Door_KeyCard.Door_KeyCard_C.OnLook
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function Door_KeyCard.Door_KeyCard_C.OnStopLook
	void ExecuteUbergraph_Door_KeyCard(int32_t EntryPoint); // Function Door_KeyCard.Door_KeyCard_C.ExecuteUbergraph_Door_KeyCard
}; 



