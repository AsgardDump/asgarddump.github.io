#pragma once 
#include "SDK.h" 
 
 
// Function GI_BR.GI_BR_C.OnNewItem
// Size: 0x38(Inherited: 0x0) 
struct FOnNewItem
{
	struct FST_SteamItem Value;  // 0x0(0x38)

}; 
// Function GI_BR.GI_BR_C.OnPlayerSettingsChanged__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnPlayerSettingsChanged__DelegateSignature
{
	struct FST_PlayerSettings New Settings;  // 0x0(0x30)

}; 
// Function GI_BR.GI_BR_C.GetPostProccessSettings
// Size: 0x582(Inherited: 0x0) 
struct FGetPostProccessSettings
{
	struct FPostProcessSettings Settings;  // 0x0(0x560)
	struct TArray<struct APostProcessVolume*> CallFunc_GetAllActorsOfClassWithTag_OutActors;  // 0x560(0x10)
	struct APostProcessVolume* CallFunc_Array_Get_Item;  // 0x570(0x8)
	struct APostProcessVolume* K2Node_DynamicCast_AsPost_Process_Volume;  // 0x578(0x8)
	char pad_1408_1 : 7;  // 0x580(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x580(0x1)
	char pad_1409_1 : 7;  // 0x581(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x581(0x1)

}; 
// Function GI_BR.GI_BR_C.E_OnNewItem__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FE_OnNewItem__DelegateSignature
{
	struct FST_SteamItem Value;  // 0x0(0x38)

}; 
// Function GI_BR.GI_BR_C.OnCallback_405B3A7A4235DB3AEBFD86B3AAECFC13
// Size: 0x11(Inherited: 0x0) 
struct FOnCallback_405B3A7A4235DB3AEBFD86B3AAECFC13
{
	struct FLeaderboardFindResult Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function GI_BR.GI_BR_C.Completed_6F07F8864F50B817CAEDB3857D946FE1
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB3857D946FE1
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.ExecuteUbergraph_GI_BR
// Size: 0xF82(Inherited: 0x0) 
struct FExecuteUbergraph_GI_BR
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UO_SuspensionChecker_C* CallFunc_SpawnObject_ReturnValue;  // 0x8(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_5;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_CustomEvent_bSuccess_5 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct USaveGame* Temp_object_Variable;  // 0x30(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x44(0x10)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	int32_t Temp_int_Variable;  // 0x58(0x4)
	int32_t Temp_int_Variable_2;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t Temp_int_Variable_3;  // 0x64(0x4)
	int32_t Temp_int_Variable_4;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct UInventory* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x70(0x8)
	struct UInventory* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x78(0x8)
	struct FSteamInventoryResult CallFunc_GetAllItems_Handle;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_GetAllItems_ReturnValue : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	struct UInventory* CallFunc_GetGameInstanceSubsystem_ReturnValue_3;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_LoadItemDefinitions_ReturnValue : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x94(0x10)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	int32_t Temp_int_Variable_5;  // 0xA8(0x4)
	int32_t Temp_int_Variable_6;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	int32_t Temp_int_Variable_7;  // 0xB4(0x4)
	int32_t Temp_int_Variable_8;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_4;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool K2Node_CustomEvent_bSuccess_4 : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0xCC(0x10)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	struct USaveGame* Temp_object_Variable_2;  // 0xE0(0x8)
	struct FLeaderboardFindResult K2Node_CustomEvent_Data_10;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_8 : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0xFC(0x10)
	char pad_268_1 : 7;  // 0x10C(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x10C(0x1)
	char pad_269[3];  // 0x10D(0x3)
	struct FLeaderboardFindResult Temp_struct_Variable;  // 0x110(0x10)
	struct USteamCoreUserStatsAsyncActionFindLeaderboard* CallFunc_FindLeaderboardAsync_ReturnValue;  // 0x120(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x128(0x10)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct FLeaderboardScoreUploaded K2Node_CustomEvent_Data_9;  // 0x140(0x20)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_7 : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x161(0x1)
	char pad_354[6];  // 0x162(0x6)
	struct FLeaderboardScoreUploaded Temp_struct_Variable_2;  // 0x168(0x20)
	struct UUserStats* CallFunc_GetGameInstanceSubsystem_ReturnValue_4;  // 0x188(0x8)
	int32_t CallFunc_GetStatInt_Data;  // 0x190(0x4)
	char pad_404_1 : 7;  // 0x194(0x1)
	bool CallFunc_GetStatInt_ReturnValue : 1;  // 0x194(0x1)
	char pad_405[3];  // 0x195(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x198(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0x1A8(0x10)
	struct USaveGame* K2Node_CustomEvent_SaveGame_3;  // 0x1B8(0x8)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool K2Node_CustomEvent_bSuccess_3 : 1;  // 0x1C0(0x1)
	char pad_449[3];  // 0x1C1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0x1C4(0x10)
	char pad_468_1 : 7;  // 0x1D4(0x1)
	bool Temp_bool_Variable_9 : 1;  // 0x1D4(0x1)
	char pad_469[3];  // 0x1D5(0x3)
	struct USaveGame* Temp_object_Variable_3;  // 0x1D8(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_2;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool K2Node_CustomEvent_bSuccess_2 : 1;  // 0x1E8(0x1)
	char pad_489[3];  // 0x1E9(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10;  // 0x1EC(0x10)
	char pad_508_1 : 7;  // 0x1FC(0x1)
	bool Temp_bool_Variable_10 : 1;  // 0x1FC(0x1)
	char pad_509[3];  // 0x1FD(0x3)
	struct USaveGame* Temp_object_Variable_4;  // 0x200(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_2;  // 0x208(0x8)
	char pad_528_1 : 7;  // 0x210(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x210(0x1)
	char pad_529[3];  // 0x211(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11;  // 0x214(0x10)
	char pad_548[4];  // 0x224(0x4)
	struct FLeaderboardScoreUploaded K2Node_CustomEvent_Data_8;  // 0x228(0x20)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_6 : 1;  // 0x248(0x1)
	char pad_585_1 : 7;  // 0x249(0x1)
	bool Temp_bool_Variable_11 : 1;  // 0x249(0x1)
	char pad_586[6];  // 0x24A(0x6)
	struct FLeaderboardScoreUploaded Temp_struct_Variable_3;  // 0x250(0x20)
	struct FLeaderboardFindResult K2Node_CustomEvent_Data_7;  // 0x270(0x10)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_5 : 1;  // 0x280(0x1)
	char pad_641[3];  // 0x281(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12;  // 0x284(0x10)
	char pad_660_1 : 7;  // 0x294(0x1)
	bool Temp_bool_Variable_12 : 1;  // 0x294(0x1)
	char pad_661[3];  // 0x295(0x3)
	struct FLeaderboardFindResult Temp_struct_Variable_4;  // 0x298(0x10)
	int32_t Temp_int_Variable_9;  // 0x2A8(0x4)
	char pad_684[4];  // 0x2AC(0x4)
	struct FString Temp_string_Variable;  // 0x2B0(0x10)
	struct FString Temp_string_Variable_2;  // 0x2C0(0x10)
	struct FString Temp_string_Variable_3;  // 0x2D0(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13;  // 0x2E0(0x10)
	struct FLeaderboardFindResult K2Node_CustomEvent_Data_6;  // 0x2F0(0x10)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_4 : 1;  // 0x300(0x1)
	char pad_769_1 : 7;  // 0x301(0x1)
	bool Temp_bool_Variable_13 : 1;  // 0x301(0x1)
	char pad_770[6];  // 0x302(0x6)
	struct FLeaderboardFindResult Temp_struct_Variable_5;  // 0x308(0x10)
	struct USteamCoreUserStatsAsyncActionFindLeaderboard* CallFunc_FindLeaderboardAsync_ReturnValue_2;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool Temp_bool_Variable_14 : 1;  // 0x320(0x1)
	char pad_801_1 : 7;  // 0x321(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x321(0x1)
	char pad_802[2];  // 0x322(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14;  // 0x324(0x10)
	char pad_820[4];  // 0x334(0x4)
	struct FLeaderboardFindResult K2Node_CustomEvent_Data_5;  // 0x338(0x10)
	char pad_840_1 : 7;  // 0x348(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_3 : 1;  // 0x348(0x1)
	char pad_841_1 : 7;  // 0x349(0x1)
	bool Temp_bool_Variable_15 : 1;  // 0x349(0x1)
	char pad_842[6];  // 0x34A(0x6)
	struct FLeaderboardFindResult Temp_struct_Variable_6;  // 0x350(0x10)
	struct USteamCoreUserStatsAsyncActionFindLeaderboard* CallFunc_FindLeaderboardAsync_ReturnValue_3;  // 0x360(0x8)
	char E_Tier Temp_byte_Variable;  // 0x368(0x1)
	char pad_873_1 : 7;  // 0x369(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x369(0x1)
	char pad_874[2];  // 0x36A(0x2)
	int32_t Temp_int_Variable_10;  // 0x36C(0x4)
	int32_t Temp_int_Variable_11;  // 0x370(0x4)
	int32_t Temp_int_Variable_12;  // 0x374(0x4)
	int32_t Temp_int_Variable_13;  // 0x378(0x4)
	int32_t Temp_int_Variable_14;  // 0x37C(0x4)
	int32_t Temp_int_Variable_15;  // 0x380(0x4)
	int32_t Temp_int_Variable_16;  // 0x384(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame;  // 0x388(0x8)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool K2Node_CustomEvent_bSuccess : 1;  // 0x390(0x1)
	char pad_913[3];  // 0x391(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15;  // 0x394(0x10)
	char pad_932_1 : 7;  // 0x3A4(0x1)
	bool Temp_bool_Variable_16 : 1;  // 0x3A4(0x1)
	char pad_933[3];  // 0x3A5(0x3)
	struct USaveGame* Temp_object_Variable_5;  // 0x3A8(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_3;  // 0x3B0(0x8)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x3B8(0x1)
	char pad_953[7];  // 0x3B9(0x7)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0x3C0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16;  // 0x3C8(0x10)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0x3D8(0x10)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x3E8(0x8)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x3F0(0x1)
	char pad_1009[7];  // 0x3F1(0x7)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_2;  // 0x3F8(0x8)
	char pad_1024_1 : 7;  // 0x400(0x1)
	bool Temp_bool_Variable_17 : 1;  // 0x400(0x1)
	char pad_1025[7];  // 0x401(0x7)
	struct FString CallFunc_BreakSteamID_ReturnValue_2;  // 0x408(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x418(0x4)
	char pad_1052[4];  // 0x41C(0x4)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue;  // 0x420(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x428(0x4)
	char pad_1068_1 : 7;  // 0x42C(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x42C(0x1)
	char pad_1069_1 : 7;  // 0x42D(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_2 : 1;  // 0x42D(0x1)
	char pad_1070[2];  // 0x42E(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x430(0x4)
	char pad_1076[4];  // 0x434(0x4)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_2;  // 0x438(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_17;  // 0x440(0x10)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x450(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x454(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x458(0x4)
	int32_t Temp_int_Variable_17;  // 0x45C(0x4)
	struct FString K2Node_Select_Default;  // 0x460(0x10)
	char pad_1136_1 : 7;  // 0x470(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x470(0x1)
	char pad_1137[7];  // 0x471(0x7)
	struct USteamCoreUserStatsAsyncActionFindLeaderboard* CallFunc_FindLeaderboardAsync_ReturnValue_4;  // 0x478(0x8)
	char pad_1152_1 : 7;  // 0x480(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x480(0x1)
	char pad_1153[3];  // 0x481(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x484(0x4)
	char pad_1160_1 : 7;  // 0x488(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x488(0x1)
	char pad_1161_1 : 7;  // 0x489(0x1)
	bool CallFunc_IsSteamAvailable_ReturnValue : 1;  // 0x489(0x1)
	char pad_1162_1 : 7;  // 0x48A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x48A(0x1)
	char pad_1163[5];  // 0x48B(0x5)
	struct FString K2Node_CustomEvent_ticket;  // 0x490(0x10)
	char pad_1184_1 : 7;  // 0x4A0(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4A0(0x1)
	char pad_1185[7];  // 0x4A1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x4A8(0x8)
	char pad_1200_1 : 7;  // 0x4B0(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_2 : 1;  // 0x4B0(0x1)
	char pad_1201[7];  // 0x4B1(0x7)
	struct FString K2Node_CustomEvent_ErrorStr;  // 0x4B8(0x10)
	struct FString K2Node_CustomEvent_Key;  // 0x4C8(0x10)
	struct FString K2Node_CustomEvent_Value_2;  // 0x4D8(0x10)
	struct FST_SteamItem K2Node_CustomEvent_SteamItem;  // 0x4E8(0x38)
	struct UInventory* CallFunc_GetGameInstanceSubsystem_ReturnValue_5;  // 0x520(0x8)
	int32_t K2Node_CustomEvent_ID_3;  // 0x528(0x4)
	struct FSteamInventoryResult CallFunc_GetAllItems_Handle_2;  // 0x52C(0x4)
	char pad_1328_1 : 7;  // 0x530(0x1)
	bool CallFunc_GetAllItems_ReturnValue_2 : 1;  // 0x530(0x1)
	char pad_1329[7];  // 0x531(0x7)
	struct TArray<struct FSteamItemDetails> CallFunc_GetResultItems_Items;  // 0x538(0x10)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool CallFunc_GetResultItems_ReturnValue : 1;  // 0x548(0x1)
	char pad_1353[3];  // 0x549(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x54C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_18;  // 0x550(0x10)
	struct FString CallFunc_SteamWebKey_Key;  // 0x560(0x10)
	int32_t CallFunc_GetAppID_Pure_ReturnValue;  // 0x570(0x4)
	char pad_1396[4];  // 0x574(0x4)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_3;  // 0x578(0x8)
	struct FString K2Node_CustomEvent_Data_4;  // 0x580(0x10)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool K2Node_CustomEvent_bWasSuccessful : 1;  // 0x590(0x1)
	char pad_1425[7];  // 0x591(0x7)
	struct FString CallFunc_BreakSteamID_ReturnValue_3;  // 0x598(0x10)
	struct FUserStatsReceived K2Node_CustomEvent_Data_3;  // 0x5A8(0x18)
	char pad_1472_1 : 7;  // 0x5C0(0x1)
	bool CallFunc_RequestCurrentStats_ReturnValue : 1;  // 0x5C0(0x1)
	char pad_1473[7];  // 0x5C1(0x7)
	struct UUserStats* CallFunc_GetGameInstanceSubsystem_ReturnValue_6;  // 0x5C8(0x8)
	struct FSteamInventoryFullUpdate K2Node_CustomEvent_Data_2;  // 0x5D0(0x4)
	int32_t K2Node_CustomEvent_ID_2;  // 0x5D4(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x5D8(0x4)
	char pad_1500_1 : 7;  // 0x5DC(0x1)
	bool K2Node_CustomEvent_IgnoreVideo : 1;  // 0x5DC(0x1)
	char pad_1501[3];  // 0x5DD(0x3)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_4;  // 0x5E0(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_4;  // 0x5E8(0x10)
	char pad_1528_1 : 7;  // 0x5F8(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_3 : 1;  // 0x5F8(0x1)
	char pad_1529[7];  // 0x5F9(0x7)
	struct USaveGame* K2Node_Select_Default_2;  // 0x600(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue;  // 0x608(0x8)
	char pad_1552_1 : 7;  // 0x610(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x610(0x1)
	char pad_1553[7];  // 0x611(0x7)
	struct FST_Settings K2Node_CustomEvent_ST_Settings;  // 0x618(0x70)
	char pad_1672_1 : 7;  // 0x688(0x1)
	bool Temp_bool_Variable_18 : 1;  // 0x688(0x1)
	char pad_1673[7];  // 0x689(0x7)
	struct USaveGame* K2Node_Select_Default_3;  // 0x690(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_2;  // 0x698(0x8)
	char pad_1696_1 : 7;  // 0x6A0(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x6A0(0x1)
	char pad_1697[3];  // 0x6A1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_19;  // 0x6A4(0x10)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x6B4(0x4)
	struct FSteamID K2Node_CustomEvent_CurrentLobby;  // 0x6B8(0x8)
	char pad_1728_1 : 7;  // 0x6C0(0x1)
	bool K2Node_CustomEvent_GoldenCrate__2 : 1;  // 0x6C0(0x1)
	char pad_1729[3];  // 0x6C1(0x3)
	int32_t K2Node_Select_Default_4;  // 0x6C4(0x4)
	int32_t K2Node_Select_Default_5;  // 0x6C8(0x4)
	char pad_1740[4];  // 0x6CC(0x4)
	struct TArray<struct FST_SteamItem> CallFunc_AllSteamItems_items;  // 0x6D0(0x10)
	char pad_1760_1 : 7;  // 0x6E0(0x1)
	bool CallFunc_AllSteamItems_empty : 1;  // 0x6E0(0x1)
	char pad_1761[3];  // 0x6E1(0x3)
	struct FSteamItemDef K2Node_MakeStruct_SteamItemDef;  // 0x6E4(0x4)
	struct TArray<struct FSteamItemDef> K2Node_MakeArray_Array;  // 0x6E8(0x10)
	struct TArray<struct FST_SteamItem> CallFunc_Get_Steam_Items_by_ID_out;  // 0x6F8(0x10)
	char pad_1800_1 : 7;  // 0x708(0x1)
	bool CallFunc_Get_Steam_Items_by_ID_Empty : 1;  // 0x708(0x1)
	char pad_1801[7];  // 0x709(0x7)
	struct TArray<int32_t> K2Node_MakeArray_Array_2;  // 0x710(0x10)
	struct FST_SteamItem CallFunc_Array_Get_Item;  // 0x720(0x38)
	struct FSteamInventoryResultReady K2Node_CustomEvent_Data;  // 0x758(0x8)
	struct TArray<struct FSteamItemInstanceID> K2Node_MakeArray_Array_3;  // 0x760(0x10)
	struct FSteamInventoryResult CallFunc_ExchangeItems_Result;  // 0x770(0x4)
	char pad_1908_1 : 7;  // 0x774(0x1)
	bool CallFunc_ExchangeItems_ReturnValue : 1;  // 0x774(0x1)
	char pad_1909[3];  // 0x775(0x3)
	struct APlayerController* K2Node_CustomEvent_PC;  // 0x778(0x8)
	struct TArray<struct FST_SteamItem> K2Node_CustomEvent_Item;  // 0x780(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x790(0x4)
	char pad_1940[4];  // 0x794(0x4)
	struct UMenu_OnItemRecieved_C* CallFunc_Create_ReturnValue;  // 0x798(0x8)
	char pad_1952_1 : 7;  // 0x7A0(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x7A0(0x1)
	char pad_1953[7];  // 0x7A1(0x7)
	struct UWebInventoryService* CallFunc_GetGameInstanceSubsystem_ReturnValue_7;  // 0x7A8(0x8)
	struct UInventory* CallFunc_GetGameInstanceSubsystem_ReturnValue_8;  // 0x7B0(0x8)
	struct UInventory* CallFunc_GetGameInstanceSubsystem_ReturnValue_9;  // 0x7B8(0x8)
	struct FST_SteamItem K2Node_CustomEvent_Value;  // 0x7C0(0x38)
	struct FSteamInventoryUpdateHandle CallFunc_StartUpdateProperties_ReturnValue;  // 0x7F8(0x8)
	struct FSteamInventoryResult CallFunc_SubmitUpdateProperties_ResultHandle;  // 0x800(0x4)
	char pad_2052_1 : 7;  // 0x804(0x1)
	bool CallFunc_SubmitUpdateProperties_ReturnValue : 1;  // 0x804(0x1)
	char pad_2053_1 : 7;  // 0x805(0x1)
	bool CallFunc_SetPropertyString_ReturnValue : 1;  // 0x805(0x1)
	char pad_2054_1 : 7;  // 0x806(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x806(0x1)
	char pad_2055[1];  // 0x807(0x1)
	struct TArray<struct FST_SteamItem> K2Node_MakeArray_Array_4;  // 0x808(0x10)
	struct USaveGame* Temp_object_Variable_6;  // 0x818(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x820(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_4;  // 0x828(0x8)
	char pad_2096_1 : 7;  // 0x830(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x830(0x1)
	char pad_2097_1 : 7;  // 0x831(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x831(0x1)
	char pad_2098_1 : 7;  // 0x832(0x1)
	bool K2Node_CustomEvent_GoldenCrate_ : 1;  // 0x832(0x1)
	char pad_2099[1];  // 0x833(0x1)
	int32_t K2Node_Select_Default_6;  // 0x834(0x4)
	int32_t K2Node_Select_Default_7;  // 0x838(0x4)
	char pad_2108_1 : 7;  // 0x83C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x83C(0x1)
	char pad_2109[3];  // 0x83D(0x3)
	struct FSteamItemDef K2Node_MakeStruct_SteamItemDef_2;  // 0x840(0x4)
	char pad_2116[4];  // 0x844(0x4)
	struct TArray<struct FSteamItemDef> K2Node_MakeArray_Array_5;  // 0x848(0x10)
	struct TArray<struct FST_SteamItem> CallFunc_AllSteamItems_items_2;  // 0x858(0x10)
	char pad_2152_1 : 7;  // 0x868(0x1)
	bool CallFunc_AllSteamItems_empty_2 : 1;  // 0x868(0x1)
	char pad_2153[3];  // 0x869(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_20;  // 0x86C(0x10)
	char pad_2172[4];  // 0x87C(0x4)
	struct TArray<struct FST_SteamItem> CallFunc_Get_Steam_Items_by_ID_out_2;  // 0x880(0x10)
	char pad_2192_1 : 7;  // 0x890(0x1)
	bool CallFunc_Get_Steam_Items_by_ID_Empty_2 : 1;  // 0x890(0x1)
	char pad_2193[7];  // 0x891(0x7)
	struct FST_SteamItem CallFunc_Array_Get_Item_2;  // 0x898(0x38)
	struct TArray<int32_t> K2Node_MakeArray_Array_6;  // 0x8D0(0x10)
	struct TArray<int32_t> K2Node_MakeArray_Array_7;  // 0x8E0(0x10)
	struct TArray<struct FSteamItemInstanceID> K2Node_MakeArray_Array_8;  // 0x8F0(0x10)
	struct FSteamInventoryResult CallFunc_ExchangeItems_Result_2;  // 0x900(0x4)
	char pad_2308_1 : 7;  // 0x904(0x1)
	bool CallFunc_ExchangeItems_ReturnValue_2 : 1;  // 0x904(0x1)
	uint8_t  CallFunc_GetResultStatus_ReturnValue;  // 0x905(0x1)
	char pad_2310_1 : 7;  // 0x906(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x906(0x1)
	char pad_2311_1 : 7;  // 0x907(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x907(0x1)
	char pad_2312_1 : 7;  // 0x908(0x1)
	bool Temp_bool_Variable_19 : 1;  // 0x908(0x1)
	char pad_2313[7];  // 0x909(0x7)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_3;  // 0x910(0x8)
	struct TArray<int32_t> K2Node_MakeArray_Array_9;  // 0x918(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_21;  // 0x928(0x10)
	struct USteamCoreUserStatsAsyncActionUploadLeaderboardScore* CallFunc_UploadLeaderboardScoreAsync_ReturnValue;  // 0x938(0x8)
	char pad_2368_1 : 7;  // 0x940(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0x940(0x1)
	char pad_2369[3];  // 0x941(0x3)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x944(0x4)
	char E_GameMode K2Node_CustomEvent_GameMode;  // 0x948(0x1)
	char pad_2377_1 : 7;  // 0x949(0x1)
	bool K2Node_CustomEvent_Bots : 1;  // 0x949(0x1)
	char pad_2378[6];  // 0x94A(0x6)
	struct FString K2Node_CustomEvent_Password;  // 0x950(0x10)
	struct FString K2Node_CustomEvent_Name;  // 0x960(0x10)
	char pad_2416_1 : 7;  // 0x970(0x1)
	bool CallFunc_StringIsEmpty_ReturnValue : 1;  // 0x970(0x1)
	char pad_2417[7];  // 0x971(0x7)
	struct FSessionPropertyKeyPair CallFunc_MakeLiteralSessionPropertyString_ReturnValue;  // 0x978(0x20)
	struct FSessionPropertyKeyPair CallFunc_MakeLiteralSessionPropertyBool_ReturnValue;  // 0x998(0x20)
	struct FSessionPropertyKeyPair CallFunc_MakeLiteralSessionPropertyByte_ReturnValue;  // 0x9B8(0x20)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x9D8(0x4)
	char pad_2524[4];  // 0x9DC(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_7;  // 0x9E0(0x8)
	char pad_2536_1 : 7;  // 0x9E8(0x1)
	bool K2Node_CustomEvent_bSuccess_7 : 1;  // 0x9E8(0x1)
	char pad_2537[7];  // 0x9E9(0x7)
	struct FSessionPropertyKeyPair CallFunc_MakeLiteralSessionPropertyInt_ReturnValue;  // 0x9F0(0x20)
	struct APlayerController* CallFunc_GetLocalPlayerController_Controller;  // 0xA10(0x8)
	struct FST_SteamItem CallFunc_Array_Get_Item_3;  // 0xA18(0x38)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0xA50(0x10)
	struct FString K2Node_Select_Default_8;  // 0xA60(0x10)
	struct FSessionPropertyKeyPair CallFunc_MakeLiteralSessionPropertyString_ReturnValue_2;  // 0xA70(0x20)
	struct FSteamInventoryResult CallFunc_ConsumeItem_Result;  // 0xA90(0x4)
	char pad_2708_1 : 7;  // 0xA94(0x1)
	bool CallFunc_ConsumeItem_ReturnValue : 1;  // 0xA94(0x1)
	char pad_2709[3];  // 0xA95(0x3)
	struct TArray<struct FSessionPropertyKeyPair> K2Node_MakeArray_Array_10;  // 0xA98(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0xAA8(0x4)
	int32_t K2Node_CustomEvent_ID;  // 0xAAC(0x4)
	char pad_2736_1 : 7;  // 0xAB0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xAB0(0x1)
	char pad_2737_1 : 7;  // 0xAB1(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0xAB1(0x1)
	char pad_2738_1 : 7;  // 0xAB2(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0xAB2(0x1)
	char pad_2739[1];  // 0xAB3(0x1)
	int32_t CallFunc_GetMaxPlayersInMatch_Count;  // 0xAB4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0xAB8(0x4)
	char pad_2748[4];  // 0xABC(0x4)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_5;  // 0xAC0(0x8)
	struct UCreateSessionCallbackProxyAdvanced* CallFunc_CreateAdvancedSession_ReturnValue;  // 0xAC8(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_5;  // 0xAD0(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_3;  // 0xAE0(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_2;  // 0xAE8(0x8)
	char pad_2800_1 : 7;  // 0xAF0(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0xAF0(0x1)
	char pad_2801_1 : 7;  // 0xAF1(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0xAF1(0x1)
	char pad_2802_1 : 7;  // 0xAF2(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_4 : 1;  // 0xAF2(0x1)
	char pad_2803_1 : 7;  // 0xAF3(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0xAF3(0x1)
	char pad_2804[4];  // 0xAF4(0x4)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_4;  // 0xAF8(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_4;  // 0xB00(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_22;  // 0xB08(0x10)
	char pad_2840_1 : 7;  // 0xB18(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0xB18(0x1)
	char pad_2841[7];  // 0xB19(0x7)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_6;  // 0xB20(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_6;  // 0xB28(0x10)
	struct FSteamInventoryResult CallFunc_GetAllItems_Handle_3;  // 0xB38(0x4)
	char pad_2876_1 : 7;  // 0xB3C(0x1)
	bool CallFunc_GetAllItems_ReturnValue_3 : 1;  // 0xB3C(0x1)
	char pad_2877_1 : 7;  // 0xB3D(0x1)
	bool CallFunc_DeleteGameInSlot_ReturnValue : 1;  // 0xB3D(0x1)
	char pad_2878[2];  // 0xB3E(0x2)
	struct TArray<int32_t> K2Node_MakeArray_Array_11;  // 0xB40(0x10)
	struct USaveGame* Temp_object_Variable_7;  // 0xB50(0x8)
	struct USteamCoreUserStatsAsyncActionUploadLeaderboardScore* CallFunc_UploadLeaderboardScoreAsync_ReturnValue_2;  // 0xB58(0x8)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0xB60(0x4)
	char pad_2916_1 : 7;  // 0xB64(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xB64(0x1)
	char pad_2917[3];  // 0xB65(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0xB68(0x4)
	char pad_2924_1 : 7;  // 0xB6C(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0xB6C(0x1)
	char pad_2925[3];  // 0xB6D(0x3)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_5;  // 0xB70(0x8)
	char pad_2936_1 : 7;  // 0xB78(0x1)
	bool Temp_bool_Variable_20 : 1;  // 0xB78(0x1)
	char pad_2937[3];  // 0xB79(0x3)
	int32_t Temp_int_Array_Index_Variable_4;  // 0xB7C(0x4)
	struct FSteamItemDetails CallFunc_Array_Get_Item_4;  // 0xB80(0x20)
	int32_t K2Node_CustomEvent_player_level;  // 0xBA0(0x4)
	struct FSteamInventoryResult CallFunc_ConsumeItem_Result_2;  // 0xBA4(0x4)
	char pad_2984_1 : 7;  // 0xBA8(0x1)
	bool CallFunc_ConsumeItem_ReturnValue_2 : 1;  // 0xBA8(0x1)
	char pad_2985[7];  // 0xBA9(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0xBB0(0x10)
	char pad_3008_1 : 7;  // 0xBC0(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_3 : 1;  // 0xBC0(0x1)
	char pad_3009_1 : 7;  // 0xBC1(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0xBC1(0x1)
	char pad_3010[2];  // 0xBC2(0x2)
	int32_t Temp_int_Array_Index_Variable_5;  // 0xBC4(0x4)
	struct FSteamID K2Node_CustomEvent_Lobby;  // 0xBC8(0x8)
	float K2Node_CustomEvent_delay;  // 0xBD0(0x4)
	char pad_3028[4];  // 0xBD4(0x4)
	struct FST_SteamItem CallFunc_Array_Get_Item_5;  // 0xBD8(0x38)
	uint8_t  CallFunc_IsSteamIDValid_Exec_Result;  // 0xC10(0x1)
	char pad_3089_1 : 7;  // 0xC11(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xC11(0x1)
	char pad_3090[2];  // 0xC12(0x2)
	int32_t CallFunc_Min_ReturnValue;  // 0xC14(0x4)
	struct FSteamInventoryResult CallFunc_ConsumeItem_Result_3;  // 0xC18(0x4)
	char pad_3100_1 : 7;  // 0xC1C(0x1)
	bool CallFunc_ConsumeItem_ReturnValue_3 : 1;  // 0xC1C(0x1)
	char pad_3101[3];  // 0xC1D(0x3)
	struct FString K2Node_CustomEvent_CosmeticItemName;  // 0xC20(0x10)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0xC30(0x4)
	char pad_3124[4];  // 0xC34(0x4)
	struct FST_Cosmetic CallFunc_GetCosmetic_cosmetic;  // 0xC38(0x50)
	char pad_3208_1 : 7;  // 0xC88(0x1)
	bool CallFunc_GetCosmetic_Exists : 1;  // 0xC88(0x1)
	char pad_3209_1 : 7;  // 0xC89(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0xC89(0x1)
	char pad_3210[6];  // 0xC8A(0x6)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0xC90(0x10)
	struct FST_UndiscoveredItem K2Node_MakeStruct_ST_UndiscoveredItem;  // 0xCA0(0x30)
	int32_t CallFunc_Add_IntInt_ReturnValue_7;  // 0xCD0(0x4)
	char pad_3284[4];  // 0xCD4(0x4)
	struct USaveGame* Temp_object_Variable_8;  // 0xCD8(0x8)
	struct TArray<struct ABP_LootCrate_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0xCE0(0x10)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_5;  // 0xCF0(0x8)
	char pad_3320_1 : 7;  // 0xCF8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xCF8(0x1)
	char pad_3321[7];  // 0xCF9(0x7)
	struct ABP_LootCrate_C* CallFunc_Array_Get_Item_6;  // 0xD00(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0xD08(0x4)
	char pad_3340_1 : 7;  // 0xD0C(0x1)
	bool Temp_bool_Variable_21 : 1;  // 0xD0C(0x1)
	char pad_3341_1 : 7;  // 0xD0D(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // 0xD0D(0x1)
	char pad_3342[2];  // 0xD0E(0x2)
	struct FST_SteamItem K2Node_CustomEvent_TargetSprayItem;  // 0xD10(0x38)
	struct USaveGame* K2Node_CustomEvent_SaveGame_8;  // 0xD48(0x8)
	char pad_3408_1 : 7;  // 0xD50(0x1)
	bool K2Node_CustomEvent_bSuccess_8 : 1;  // 0xD50(0x1)
	char pad_3409[7];  // 0xD51(0x7)
	struct APlayerController* CallFunc_GetLocalPlayerController_Controller_2;  // 0xD58(0x8)
	struct UW_CustomSpraySelector_C* CallFunc_Create_ReturnValue_2;  // 0xD60(0x8)
	char pad_3432_1 : 7;  // 0xD68(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0xD68(0x1)
	char pad_3433[3];  // 0xD69(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_23;  // 0xD6C(0x10)
	char pad_3452_1 : 7;  // 0xD7C(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // 0xD7C(0x1)
	char E_Tier K2Node_CustomEvent_Tier;  // 0xD7D(0x1)
	char pad_3454[2];  // 0xD7E(0x2)
	struct TArray<struct FST_SteamItem> CallFunc_AllSteamItems_items_3;  // 0xD80(0x10)
	char pad_3472_1 : 7;  // 0xD90(0x1)
	bool CallFunc_AllSteamItems_empty_3 : 1;  // 0xD90(0x1)
	char pad_3473[3];  // 0xD91(0x3)
	int32_t K2Node_Select_Default_9;  // 0xD94(0x4)
	struct TArray<struct FST_SteamItem> CallFunc_Get_Steam_Items_by_ID_out_3;  // 0xD98(0x10)
	char pad_3496_1 : 7;  // 0xDA8(0x1)
	bool CallFunc_Get_Steam_Items_by_ID_Empty_3 : 1;  // 0xDA8(0x1)
	char pad_3497[3];  // 0xDA9(0x3)
	struct FSteamItemDef K2Node_MakeStruct_SteamItemDef_3;  // 0xDAC(0x4)
	struct TArray<struct FSteamItemDef> K2Node_MakeArray_Array_12;  // 0xDB0(0x10)
	struct FST_SteamItem CallFunc_Array_Get_Item_7;  // 0xDC0(0x38)
	int32_t CallFunc_TierBagCostInScrap_CostInScrap;  // 0xDF8(0x4)
	char pad_3580[4];  // 0xDFC(0x4)
	struct TArray<int32_t> K2Node_MakeArray_Array_13;  // 0xE00(0x10)
	struct USaveGame* K2Node_CustomEvent_SaveGame_6;  // 0xE10(0x8)
	char pad_3608_1 : 7;  // 0xE18(0x1)
	bool K2Node_CustomEvent_bSuccess_6 : 1;  // 0xE18(0x1)
	char pad_3609[7];  // 0xE19(0x7)
	struct TArray<struct FSteamItemInstanceID> K2Node_MakeArray_Array_14;  // 0xE20(0x10)
	struct TArray<int32_t> K2Node_MakeArray_Array_15;  // 0xE30(0x10)
	struct FSteamInventoryResult CallFunc_ExchangeItems_Result_3;  // 0xE40(0x4)
	char pad_3652_1 : 7;  // 0xE44(0x1)
	bool CallFunc_ExchangeItems_ReturnValue_3 : 1;  // 0xE44(0x1)
	char pad_3653[3];  // 0xE45(0x3)
	struct FSteamInventoryResult CallFunc_GetAllItems_Handle_4;  // 0xE48(0x4)
	char pad_3660_1 : 7;  // 0xE4C(0x1)
	bool CallFunc_GetAllItems_ReturnValue_4 : 1;  // 0xE4C(0x1)
	char pad_3661[3];  // 0xE4D(0x3)
	struct TArray<struct FSteamItemDetails> CallFunc_GetResultItems_Items_2;  // 0xE50(0x10)
	char pad_3680_1 : 7;  // 0xE60(0x1)
	bool CallFunc_GetResultItems_ReturnValue_2 : 1;  // 0xE60(0x1)
	char pad_3681[7];  // 0xE61(0x7)
	struct FSteamItemDetails CallFunc_Array_Get_Item_8;  // 0xE68(0x20)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0xE88(0x4)
	char pad_3724[4];  // 0xE8C(0x4)
	struct FST_SteamItem CallFunc_ItemDetailToSteamItem_out;  // 0xE90(0x38)
	char pad_3784_1 : 7;  // 0xEC8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0xEC8(0x1)
	char pad_3785[3];  // 0xEC9(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xECC(0x4)
	char pad_3792_1 : 7;  // 0xED0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xED0(0x1)
	char pad_3793[3];  // 0xED1(0x3)
	float K2Node_CustomEvent_Duration;  // 0xED4(0x4)
	struct TArray<struct UUserWidget*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0xED8(0x10)
	struct UUserWidget* CallFunc_Array_Get_Item_9;  // 0xEE8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_6;  // 0xEF0(0x4)
	char pad_3828[4];  // 0xEF4(0x4)
	struct UW_LoadingScreen_C* K2Node_DynamicCast_AsW_Loading_Screen;  // 0xEF8(0x8)
	char pad_3840_1 : 7;  // 0xF00(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0xF00(0x1)
	char pad_3841_1 : 7;  // 0xF01(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0xF01(0x1)
	char pad_3842[2];  // 0xF02(0x2)
	struct FST_VideoSettings K2Node_CustomEvent_VideoSettings;  // 0xF04(0x30)
	char pad_3892_1 : 7;  // 0xF34(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xF34(0x1)
	char pad_3893[3];  // 0xF35(0x3)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_7;  // 0xF38(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_7;  // 0xF40(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_5;  // 0xF50(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_3;  // 0xF58(0x8)
	char pad_3936_1 : 7;  // 0xF60(0x1)
	bool CallFunc_IsValid_ReturnValue_14 : 1;  // 0xF60(0x1)
	char pad_3937_1 : 7;  // 0xF61(0x1)
	bool CallFunc_IsValid_ReturnValue_15 : 1;  // 0xF61(0x1)
	char pad_3938_1 : 7;  // 0xF62(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_5 : 1;  // 0xF62(0x1)
	char pad_3939[5];  // 0xF63(0x5)
	struct FString K2Node_Event_MapName;  // 0xF68(0x10)
	struct UWorld* K2Node_Event_world;  // 0xF78(0x8)
	char pad_3968_1 : 7;  // 0xF80(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_3 : 1;  // 0xF80(0x1)
	char pad_3969_1 : 7;  // 0xF81(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue_4 : 1;  // 0xF81(0x1)

}; 
// Function GI_BR.GI_BR_C.BeginLoadingScreen
// Size: 0x10(Inherited: 0x10) 
struct FBeginLoadingScreen : public FBeginLoadingScreen
{
	struct FString MapName;  // 0x0(0x10)

}; 
// Function GI_BR.GI_BR_C.EndLoadingScreen
// Size: 0x8(Inherited: 0x8) 
struct FEndLoadingScreen : public FEndLoadingScreen
{
	struct UWorld* World;  // 0x0(0x8)

}; 
// Function GI_BR.GI_BR_C.ApplyResolutionSettings
// Size: 0x30(Inherited: 0x0) 
struct FApplyResolutionSettings
{
	struct FST_VideoSettings VideoSettings;  // 0x0(0x30)

}; 
// Function GI_BR.GI_BR_C.MuffleSound
// Size: 0x4(Inherited: 0x0) 
struct FMuffleSound
{
	float Duration;  // 0x0(0x4)

}; 
// Function GI_BR.GI_BR_C.ForceNoFullscreenMode
// Size: 0x6(Inherited: 0x0) 
struct FForceNoFullscreenMode
{
	char EWindowMode In;  // 0x0(0x1)
	char EWindowMode Out;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool Temp_bool_Variable : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x3(0x1)
	char EWindowMode Temp_byte_Variable;  // 0x4(0x1)
	char EWindowMode K2Node_Select_Default;  // 0x5(0x1)

}; 
// Function GI_BR.GI_BR_C.ModifyItemProperties
// Size: 0x58(Inherited: 0x0) 
struct FModifyItemProperties
{
	struct FString Key;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	struct FST_SteamItem SteamItem;  // 0x20(0x38)

}; 
// Function GI_BR.GI_BR_C.OpenTierBag
// Size: 0x1(Inherited: 0x0) 
struct FOpenTierBag
{
	char E_Tier Tier;  // 0x0(0x1)

}; 
// Function GI_BR.GI_BR_C.OnReceivedCustomSprayItem
// Size: 0x38(Inherited: 0x0) 
struct FOnReceivedCustomSprayItem
{
	struct FST_SteamItem TargetSprayItem;  // 0x0(0x38)

}; 
// Function GI_BR.GI_BR_C.GetDynamicItemProperty
// Size: 0xDA(Inherited: 0x0) 
struct FGetDynamicItemProperty
{
	struct FST_SteamItem Item;  // 0x0(0x38)
	struct FString Key;  // 0x38(0x10)
	struct FString Value;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool Found? : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FSteamInventoryResult CallFunc_GetAllItems_Handle;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_GetAllItems_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct TArray<struct FSteamItemDetails> CallFunc_GetResultItems_Items;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_GetResultItems_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_FindSteamItemFromSteamItemDetails_Index;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_FindSteamItemFromSteamItemDetails_Found : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct FString CallFunc_BreakSteamItemInstanceID_ValueString;  // 0x88(0x10)
	int64_t CallFunc_BreakSteamItemInstanceID_FakeBlueprintIntValue;  // 0x98(0x8)
	struct FString CallFunc_GetResultItemProperty_Value;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_GetResultItemProperty_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0xB8(0x10)
	struct FString CallFunc_FindJsonString_Value;  // 0xC8(0x10)
	uint8_t  CallFunc_FindJsonString_Result;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xD9(0x1)

}; 
// Function GI_BR.GI_BR_C.ModifyItem_Callback
// Size: 0x11(Inherited: 0x0) 
struct FModifyItem_Callback
{
	struct FString Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function GI_BR.GI_BR_C.OpenLootCrate
// Size: 0x1(Inherited: 0x0) 
struct FOpenLootCrate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool GoldenCrate? : 1;  // 0x0(0x1)

}; 
// Function GI_BR.GI_BR_C.MarkItemAsUndiscovered
// Size: 0x10(Inherited: 0x0) 
struct FMarkItemAsUndiscovered
{
	struct FString CosmeticItemName;  // 0x0(0x10)

}; 
// Function GI_BR.GI_BR_C.DelayedLobbyLeave
// Size: 0xC(Inherited: 0x0) 
struct FDelayedLobbyLeave
{
	struct FSteamID Lobby;  // 0x0(0x8)
	float Delay;  // 0x8(0x4)

}; 
// Function GI_BR.GI_BR_C.OnReceiveEncryptedAppTicket
// Size: 0x10(Inherited: 0x0) 
struct FOnReceiveEncryptedAppTicket
{
	struct FString Ticket;  // 0x0(0x10)

}; 
// Function GI_BR.GI_BR_C.Get Rid Of Cheaters
// Size: 0x4(Inherited: 0x0) 
struct FGet Rid Of Cheaters
{
	int32_t player level;  // 0x0(0x4)

}; 
// Function GI_BR.GI_BR_C.Consume Steam Item
// Size: 0x4(Inherited: 0x0) 
struct FConsume Steam Item
{
	int32_t ID;  // 0x0(0x4)

}; 
// Function GI_BR.GI_BR_C.SteamItemsFullUpdate
// Size: 0x18(Inherited: 0x0) 
struct FSteamItemsFullUpdate
{
	struct FSteamInventoryFullUpdate Handle;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bfound? : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TArray<struct FSteamItemDetails> Details;  // 0x8(0x10)

}; 
// Function GI_BR.GI_BR_C.HostGame
// Size: 0x28(Inherited: 0x0) 
struct FHostGame
{
	char E_GameMode GameMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Bots : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString Password;  // 0x8(0x10)
	struct FString Name;  // 0x18(0x10)

}; 
// Function GI_BR.GI_BR_C.OpenLootCrateTemp
// Size: 0x1(Inherited: 0x0) 
struct FOpenLootCrateTemp
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool GoldenCrate? : 1;  // 0x0(0x1)

}; 
// Function GI_BR.GI_BR_C.AddOnItemsRecievedNotice
// Size: 0x18(Inherited: 0x0) 
struct FAddOnItemsRecievedNotice
{
	struct APlayerController* PC;  // 0x0(0x8)
	struct TArray<struct FST_SteamItem> Item;  // 0x8(0x10)

}; 
// Function GI_BR.GI_BR_C.EventSteamInvetoryReady
// Size: 0x8(Inherited: 0x0) 
struct FEventSteamInvetoryReady
{
	struct FSteamInventoryResultReady Data;  // 0x0(0x8)

}; 
// Function GI_BR.GI_BR_C.SetLobby
// Size: 0x8(Inherited: 0x0) 
struct FSetLobby
{
	struct FSteamID CurrentLobby;  // 0x0(0x8)

}; 
// Function GI_BR.GI_BR_C.ApplySoundSettings
// Size: 0x70(Inherited: 0x0) 
struct FApplySoundSettings
{
	struct FST_Settings ST_Settings;  // 0x0(0x70)

}; 
// Function GI_BR.GI_BR_C.ApplySavedSettings
// Size: 0x1(Inherited: 0x0) 
struct FApplySavedSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IgnoreVideo : 1;  // 0x0(0x1)

}; 
// Function GI_BR.GI_BR_C.SteamInventoryFullUpdate_Event_1
// Size: 0x4(Inherited: 0x0) 
struct FSteamInventoryFullUpdate_Event_1
{
	struct FSteamInventoryFullUpdate Data;  // 0x0(0x4)

}; 
// Function GI_BR.GI_BR_C.AddRecipe
// Size: 0x4(Inherited: 0x0) 
struct FAddRecipe
{
	int32_t ID;  // 0x0(0x4)

}; 
// Function GI_BR.GI_BR_C.OnStatsinit
// Size: 0x18(Inherited: 0x0) 
struct FOnStatsinit
{
	struct FUserStatsReceived Data;  // 0x0(0x18)

}; 
// Function GI_BR.GI_BR_C.DeleteSteamItem
// Size: 0x4(Inherited: 0x0) 
struct FDeleteSteamItem
{
	int32_t ID;  // 0x0(0x4)

}; 
// Function GI_BR.GI_BR_C.OnLoginEOS
// Size: 0x18(Inherited: 0x0) 
struct FOnLoginEOS
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ErrorStr;  // 0x8(0x10)

}; 
// Function GI_BR.GI_BR_C.Completed_0914B3504C491F3C20AD1796D31AD75E
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_0914B3504C491F3C20AD1796D31AD75E
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.Completed_6F07F8864F50B817CAEDB385989B85DA
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB385989B85DA
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.OnCallback_20486EE64CB027631276EF85AF2F61E4
// Size: 0x11(Inherited: 0x0) 
struct FOnCallback_20486EE64CB027631276EF85AF2F61E4
{
	struct FLeaderboardFindResult Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function GI_BR.GI_BR_C.OnCallback_1032A81D49EF141A9F62E3A25FA977AD
// Size: 0x11(Inherited: 0x0) 
struct FOnCallback_1032A81D49EF141A9F62E3A25FA977AD
{
	struct FLeaderboardFindResult Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function GI_BR.GI_BR_C.OnCallback_B62C756D4B0FD845C1D073A93B2774FB
// Size: 0x11(Inherited: 0x0) 
struct FOnCallback_B62C756D4B0FD845C1D073A93B2774FB
{
	struct FLeaderboardFindResult Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function GI_BR.GI_BR_C.OnCallback_257AC4FB4B227479878261897451C33A
// Size: 0x21(Inherited: 0x0) 
struct FOnCallback_257AC4FB4B227479878261897451C33A
{
	struct FLeaderboardScoreUploaded Data;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bWasSuccessful : 1;  // 0x20(0x1)

}; 
// Function GI_BR.GI_BR_C.Completed_215CB37D43646A0095BC7397DF44BF04
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC7397DF44BF04
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.OnCallback_9CEB70ED4957BA5DC3BEE4B2FA6157F5
// Size: 0x21(Inherited: 0x0) 
struct FOnCallback_9CEB70ED4957BA5DC3BEE4B2FA6157F5
{
	struct FLeaderboardScoreUploaded Data;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bWasSuccessful : 1;  // 0x20(0x1)

}; 
// Function GI_BR.GI_BR_C.Completed_215CB37D43646A0095BC73976F8C07AD
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73976F8C07AD
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.Completed_0914B3504C491F3C20AD17968266BFBA
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_0914B3504C491F3C20AD17968266BFBA
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.Completed_6F07F8864F50B817CAEDB385CD5CD748
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB385CD5CD748
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.Completed_215CB37D43646A0095BC73978A83ED96
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73978A83ED96
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function GI_BR.GI_BR_C.ApplyVideoSettings
// Size: 0x44(Inherited: 0x0) 
struct FApplyVideoSettings
{
	struct FST_VideoSettings Settings;  // 0x0(0x30)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x30(0x8)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x38(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x3C(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x40(0x4)

}; 
// Function GI_BR.GI_BR_C.SteamItemsOnResult
// Size: 0x2E2(Inherited: 0x0) 
struct FSteamItemsOnResult
{
	struct FSteamInventoryResult Handle;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FST_SteamItem> SteamItemsToRemove;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bAddNewItem : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct TArray<struct FSteamItemDetails> NewItemsToAdd;  // 0x20(0x10)
	struct TArray<int32_t> SteamItemIndiciesToRemove;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bDestroy : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FSteamInventoryResult LocalHandle;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bfound? : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct TArray<struct FSteamItemDetails> Details;  // 0x50(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x60(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x74(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x78(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x7C(0x4)
	char ESteamCoreItemFlags Temp_byte_Variable;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x84(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x88(0x10)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x98(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x9C(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0xA0(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0xA4(0x4)
	char ESteamCoreItemFlags Temp_byte_Variable_2;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FST_SteamItem CallFunc_Array_Get_Item;  // 0xB0(0x38)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xE8(0x4)
	int32_t Temp_int_Array_Index_Variable_5;  // 0xEC(0x4)
	struct FST_SteamItem CallFunc_Array_Get_Item_2;  // 0xF0(0x38)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x128(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x12C(0x4)
	char ESteamCoreItemFlags Temp_byte_Variable_3;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct FSteamItemDetails CallFunc_Array_Get_Item_3;  // 0x138(0x20)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x158(0x4)
	char pad_348[4];  // 0x15C(0x4)
	struct FST_SteamItem CallFunc_ItemDetailToSteamItem_out;  // 0x160(0x38)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x198(0x1)
	char pad_409_1 : 7;  // 0x199(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x199(0x1)
	char pad_410_1 : 7;  // 0x19A(0x1)
	bool CallFunc_DoesSteamItemsArrayHaveInstance_Result : 1;  // 0x19A(0x1)
	char pad_411[1];  // 0x19B(0x1)
	int32_t CallFunc_DoesSteamItemsArrayHaveInstance_Array_Index;  // 0x19C(0x4)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x1A0(0x1)
	char pad_417[7];  // 0x1A1(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x1A8(0x10)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x1B8(0x1)
	char pad_441[7];  // 0x1B9(0x7)
	struct FString CallFunc_BreakSteamItemInstanceID_ValueString;  // 0x1C0(0x10)
	int64_t CallFunc_BreakSteamItemInstanceID_FakeBlueprintIntValue;  // 0x1D0(0x8)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x1D8(0x1)
	char ESteamCoreItemFlags Temp_byte_Variable_4;  // 0x1D9(0x1)
	char pad_474[2];  // 0x1DA(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x1DC(0x4)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x1E0(0x1)
	char pad_481[3];  // 0x1E1(0x3)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x1E4(0x4)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x1E8(0x1)
	char pad_489_1 : 7;  // 0x1E9(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1E9(0x1)
	char pad_490_1 : 7;  // 0x1EA(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x1EA(0x1)
	char pad_491_1 : 7;  // 0x1EB(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1EB(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x1EC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0x1F0(0x4)
	int32_t Temp_int_Array_Index_Variable_6;  // 0x1F4(0x4)
	struct FSteamItemDetails CallFunc_Array_Get_Item_4;  // 0x1F8(0x20)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x218(0x4)
	char pad_540_1 : 7;  // 0x21C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x21C(0x1)
	char pad_541_1 : 7;  // 0x21D(0x1)
	bool CallFunc_SteamItemInstanceID_Equals_ReturnValue : 1;  // 0x21D(0x1)
	char pad_542[2];  // 0x21E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x220(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0x224(0x4)
	struct FSteamItemDetails CallFunc_Array_Get_Item_5;  // 0x228(0x20)
	struct FST_SteamItem CallFunc_Array_Get_Item_6;  // 0x248(0x38)
	int32_t CallFunc_Array_Add_ReturnValue_4;  // 0x280(0x4)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool CallFunc_Array_Contains_ReturnValue_3 : 1;  // 0x284(0x1)
	char pad_645_1 : 7;  // 0x285(0x1)
	bool CallFunc_SteamItemInstanceID_Equals_ReturnValue_2 : 1;  // 0x285(0x1)
	char pad_646_1 : 7;  // 0x286(0x1)
	bool CallFunc_Array_Contains_ReturnValue_4 : 1;  // 0x286(0x1)
	char pad_647_1 : 7;  // 0x287(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x287(0x1)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue_2 : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x289(0x1)
	char pad_650[6];  // 0x28A(0x6)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x290(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_6;  // 0x2A0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_7;  // 0x2A4(0x4)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x2A8(0x1)
	char pad_681_1 : 7;  // 0x2A9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0x2A9(0x1)
	char pad_682_1 : 7;  // 0x2AA(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x2AA(0x1)
	char pad_683[5];  // 0x2AB(0x5)
	struct TArray<struct FSteamItemDetails> CallFunc_GetResultItems_Items;  // 0x2B0(0x10)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool CallFunc_GetResultItems_ReturnValue : 1;  // 0x2C0(0x1)
	char pad_705[3];  // 0x2C1(0x3)
	int32_t Temp_int_Loop_Counter_Variable_6;  // 0x2C4(0x4)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_6 : 1;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0x2CC(0x4)
	struct TArray<struct FSteamItemDetails> CallFunc_FilterSteamItems_out;  // 0x2D0(0x10)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool CallFunc_FilterSteamItems_Empty : 1;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x2E1(0x1)

}; 
