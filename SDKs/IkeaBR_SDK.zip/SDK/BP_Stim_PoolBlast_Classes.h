#pragma once 
#include <BP_Stim_PoolBlast_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Stim_PoolBlast.BP_Stim_PoolBlast_C
// Size: 0x288(Inherited: 0x280) 
struct ABP_Stim_PoolBlast_C : public ABP_StimBase_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)

	void Equip(); // Function BP_Stim_PoolBlast.BP_Stim_PoolBlast_C.Equip
	void Unequip(); // Function BP_Stim_PoolBlast.BP_Stim_PoolBlast_C.Unequip
	void ExecuteUbergraph_BP_Stim_PoolBlast(int32_t EntryPoint); // Function BP_Stim_PoolBlast.BP_Stim_PoolBlast_C.ExecuteUbergraph_BP_Stim_PoolBlast
}; 



