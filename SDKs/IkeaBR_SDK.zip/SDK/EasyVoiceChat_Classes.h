#pragma once 
#include <EasyVoiceChat_Structs.h>
 
 
 
// Class EasyVoiceChat.VoiceFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UVoiceFunctionLibrary : public UBlueprintFunctionLibrary
{

	struct TArray<struct APawn*> GetAllPawnsFromState(struct UObject* worldContextObject, struct APawn* CurrentPlayer, float Distance); // Function EasyVoiceChat.VoiceFunctionLibrary.GetAllPawnsFromState
}; 



// Class EasyVoiceChat.VoipAudioComponent
// Size: 0x740(Inherited: 0x720) 
struct UVoipAudioComponent : public UVoipListenerSynthComponent
{
	char pad_1824[32];  // 0x720(0x20)

	void PlayVoiceData(struct TArray<char>& CompressedVoiceData); // Function EasyVoiceChat.VoipAudioComponent.PlayVoiceData
}; 



// Class EasyVoiceChat.VoipManagerComponent
// Size: 0x188(Inherited: 0xB0) 
struct UVoipManagerComponent : public UActorComponent
{
	struct FMulticastInlineDelegate VoiceGenerated;  // 0xB0(0x10)
	struct FMulticastInlineDelegate PlayerTalking;  // 0xC0(0x10)
	struct FMulticastInlineDelegate PlayerStopTalking;  // 0xD0(0x10)
	char pad_224[140];  // 0xE0(0x8C)
	float StopTalkingThreshold;  // 0x16C(0x4)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool bAutoSetConsoleVariables : 1;  // 0x170(0x1)
	char pad_369[3];  // 0x171(0x3)
	float SilenceDetectionThreshold;  // 0x174(0x4)
	float NoiseGateThreshold;  // 0x178(0x4)
	float VoiceBufferDelay;  // 0x17C(0x4)
	char pad_384[8];  // 0x180(0x8)

	void OnVoiceGeneratedBP(struct TArray<char>& VoiceBuffer, float MicLevel); // Function EasyVoiceChat.VoipManagerComponent.OnVoiceGeneratedBP
	void OnPlayerStopTalking(); // Function EasyVoiceChat.VoipManagerComponent.OnPlayerStopTalking
	void OnPlayerStartTalking(); // Function EasyVoiceChat.VoipManagerComponent.OnPlayerStartTalking
	bool InitVoice(struct AController* Controller, struct FString DeviceName); // Function EasyVoiceChat.VoipManagerComponent.InitVoice
}; 



