#pragma once 
#include <focusOnTarget_Structs.h>
 
 
 
// BlueprintGeneratedClass focusOnTarget.focusOnTarget_C
// Size: 0xD8(Inherited: 0xA8) 
struct UfocusOnTarget_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector Target;  // 0xB0(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function focusOnTarget.focusOnTarget_C.ReceiveExecuteAI
	void ExecuteUbergraph_focusOnTarget(int32_t EntryPoint); // Function focusOnTarget.focusOnTarget_C.ExecuteUbergraph_focusOnTarget
}; 



