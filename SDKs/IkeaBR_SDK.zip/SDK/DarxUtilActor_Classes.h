#pragma once 
#include <DarxUtilActor_Structs.h>
 
 
 
// BlueprintGeneratedClass DarxUtilActor.DarxUtilActor_C
// Size: 0x228(Inherited: 0x220) 
struct ADarxUtilActor_C : public AActor
{
	struct USceneComponent* DefaultSceneRoot;  // 0x220(0x8)

	void DestroyStaticMesh(struct UStaticMeshComponent* Mesh); // Function DarxUtilActor.DarxUtilActor_C.DestroyStaticMesh
	struct UStaticMeshComponent* CreateStaticMesh(struct AActor* Parent); // Function DarxUtilActor.DarxUtilActor_C.CreateStaticMesh
}; 



