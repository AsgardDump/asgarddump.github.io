#pragma once 
#include <DarkZone_Structs.h>
 
 
 
// BlueprintGeneratedClass DarkZone.DarkZone_C
// Size: 0x29C(Inherited: 0x220) 
struct ADarkZone_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UPostProcessComponent* PostProcess;  // 0x228(0x8)
	struct UAudioComponent* Audio;  // 0x230(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x238(0x8)
	float FadeOut_alpha_87B000F2435F740C8C2C7D81409FB323;  // 0x240(0x4)
	char ETimelineDirection FadeOut__Direction_87B000F2435F740C8C2C7D81409FB323;  // 0x244(0x1)
	char pad_581[3];  // 0x245(0x3)
	struct UTimelineComponent* FadeOut;  // 0x248(0x8)
	float Timeline_0_NewTrack_0_0050ED514A777F2EB192E7BE7B9F1E30;  // 0x250(0x4)
	char ETimelineDirection Timeline_0__Direction_0050ED514A777F2EB192E7BE7B9F1E30;  // 0x254(0x1)
	char pad_597[3];  // 0x255(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x258(0x8)
	float TargetSize;  // 0x260(0x4)
	float timeToGrow;  // 0x264(0x4)
	struct AFirstPersonCharacter_C* Trigger;  // 0x268(0x8)
	float Time;  // 0x270(0x4)
	char pad_628_1 : 7;  // 0x274(0x1)
	bool Reverse : 1;  // 0x274(0x1)
	char pad_629[3];  // 0x275(0x3)
	float CurrentSize;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	struct TArray<struct AFirstPersonCharacter_C*> LastOverlappingPlayers;  // 0x280(0x10)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool ExponentialDamage : 1;  // 0x290(0x1)
	char pad_657[3];  // 0x291(0x3)
	float MaxExponentialDamage;  // 0x294(0x4)
	float DefaultDamage;  // 0x298(0x4)

	void GetPostProcessSettingsForPlayerDepth(struct FVector Location, struct FPostProcessSettings& Out); // Function DarkZone.DarkZone_C.GetPostProcessSettingsForPlayerDepth
	void GetPlayerOuterReverseDepth(struct FVector Location, float& NormalizedDistance); // Function DarkZone.DarkZone_C.GetPlayerOuterReverseDepth
	void GetPlayerOverlapDepth(struct FVector PlayerLoc, float& NormalizedDepth); // Function DarkZone.DarkZone_C.GetPlayerOverlapDepth
	void TickOverlapCheck(); // Function DarkZone.DarkZone_C.TickOverlapCheck
	void GetAllOverlappingPlayers(struct TArray<struct AFirstPersonCharacter_C*>& Players); // Function DarkZone.DarkZone_C.GetAllOverlappingPlayers
	void OverlapVsPlayerCheck(struct AFirstPersonCharacter_C* Player, bool& Overlapping); // Function DarkZone.DarkZone_C.OverlapVsPlayerCheck
	void Timeline_0__FinishedFunc(); // Function DarkZone.DarkZone_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function DarkZone.DarkZone_C.Timeline_0__UpdateFunc
	void FadeOut__FinishedFunc(); // Function DarkZone.DarkZone_C.FadeOut__FinishedFunc
	void FadeOut__UpdateFunc(); // Function DarkZone.DarkZone_C.FadeOut__UpdateFunc
	void ReceiveBeginPlay(); // Function DarkZone.DarkZone_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function DarkZone.DarkZone_C.ReceiveTick
	void ClientGrow(float Size, float Time, float CurrectSize); // Function DarkZone.DarkZone_C.ClientGrow
	void ClientPostProccess(struct AActor* Player, struct FPostProcessSettings PostProcessSettings); // Function DarkZone.DarkZone_C.ClientPostProccess
	void ServerGrow(float Time, float Size); // Function DarkZone.DarkZone_C.ServerGrow
	void DamagePlayers(); // Function DarkZone.DarkZone_C.DamagePlayers
	void Multi_Grow(float Size, float Time, float CurrectSize); // Function DarkZone.DarkZone_C.Multi_Grow
	void OnBeginOverlap(struct AFirstPersonCharacter_C* Player); // Function DarkZone.DarkZone_C.OnBeginOverlap
	void OnEndOverlap(struct AFirstPersonCharacter_C* Player); // Function DarkZone.DarkZone_C.OnEndOverlap
	void MultiFadeOut(); // Function DarkZone.DarkZone_C.MultiFadeOut
	void MultiDamageSound(struct FVector Location, float PitchMultiplier, float VolumeMultiplier); // Function DarkZone.DarkZone_C.MultiDamageSound
	void ExecuteUbergraph_DarkZone(int32_t EntryPoint); // Function DarkZone.DarkZone_C.ExecuteUbergraph_DarkZone
}; 



