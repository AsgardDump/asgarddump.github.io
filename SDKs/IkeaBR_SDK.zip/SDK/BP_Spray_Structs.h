#pragma once 
#include "SDK.h" 
 
 
// Function BP_Spray.BP_Spray_C.OnRep_URL
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_URL
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_CanLaunchURL_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Spray.BP_Spray_C.OnFail_EE1F039D4F0C99455AEBD097D29CFBEC
// Size: 0x8(Inherited: 0x0) 
struct FOnFail_EE1F039D4F0C99455AEBD097D29CFBEC
{
	struct UTexture2D* OutTexture;  // 0x0(0x8)

}; 
// Function BP_Spray.BP_Spray_C.ExecuteUbergraph_BP_Spray
// Size: 0x125(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Spray
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct UTexture2D* K2Node_CustomEvent_OutTexture;  // 0x18(0x8)
	struct UTexture2D* Temp_object_Variable;  // 0x20(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)
	struct UTexture2D* K2Node_CustomEvent_Texture;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0x50(0x10)
	int32_t CallFunc_Blueprint_GetSizeY_ReturnValue;  // 0x60(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x64(0x4)
	int32_t CallFunc_Blueprint_GetSizeX_ReturnValue;  // 0x68(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x74(0x4)
	struct UTexture2D* K2Node_CustomEvent_OutTexture_2;  // 0x78(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x80(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x88(0xC)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x94(0xC)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0xA0(0x8)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0xA8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0xB0(0xC)
	char pad_188[4];  // 0xBC(0x4)
	struct FString K2Node_CustomEvent_URL;  // 0xC0(0x10)
	struct UAsyncDownloadImageCustom* CallFunc_DownloadImageCustom_ReturnValue;  // 0xD0(0x8)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR;  // 0xD8(0x8)
	struct UTexture2D* CallFunc_Map_Find_Value;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xE9(0x1)
	char pad_234[6];  // 0xEA(0x6)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR_2;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_CanLaunchURL_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float CallFunc_BreakVector_X;  // 0xFC(0x4)
	float CallFunc_BreakVector_Y;  // 0x100(0x4)
	float CallFunc_BreakVector_Z;  // 0x104(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x108(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x10C(0xC)
	struct FVector CallFunc_K2_GetComponentScale_ReturnValue;  // 0x118(0xC)
	char pad_292_1 : 7;  // 0x124(0x1)
	bool CallFunc_CanLaunchURL_ReturnValue_2 : 1;  // 0x124(0x1)

}; 
// Function BP_Spray.BP_Spray_C.DownloadURL
// Size: 0x10(Inherited: 0x0) 
struct FDownloadURL
{
	struct FString URL;  // 0x0(0x10)

}; 
// Function BP_Spray.BP_Spray_C.UpdateTexture
// Size: 0x8(Inherited: 0x0) 
struct FUpdateTexture
{
	struct UTexture2D* Texture;  // 0x0(0x8)

}; 
// Function BP_Spray.BP_Spray_C.OnSuccess_EE1F039D4F0C99455AEBD097D29CFBEC
// Size: 0x8(Inherited: 0x0) 
struct FOnSuccess_EE1F039D4F0C99455AEBD097D29CFBEC
{
	struct UTexture2D* OutTexture;  // 0x0(0x8)

}; 
