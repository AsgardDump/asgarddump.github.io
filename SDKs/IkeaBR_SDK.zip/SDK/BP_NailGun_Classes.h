#pragma once 
#include <BP_NailGun_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_NailGun.BP_NailGun_C
// Size: 0x2B8(Inherited: 0x2A0) 
struct ABP_NailGun_C : public ABP_Throwable_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A0(0x8)
	struct USceneComponent* Scene_1;  // 0x2A8(0x8)
	struct UAnimSequenceBase* ShootAnim;  // 0x2B0(0x8)

	void LMB(bool Down); // Function BP_NailGun.BP_NailGun_C.LMB
	void Equip(); // Function BP_NailGun.BP_NailGun_C.Equip
	void Unequip(); // Function BP_NailGun.BP_NailGun_C.Unequip
	void ExecuteUbergraph_BP_NailGun(int32_t EntryPoint); // Function BP_NailGun.BP_NailGun_C.ExecuteUbergraph_BP_NailGun
}; 



