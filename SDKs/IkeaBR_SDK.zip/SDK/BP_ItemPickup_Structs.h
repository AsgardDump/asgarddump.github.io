#pragma once 
#include "SDK.h" 
 
 
// Function BP_ItemPickup.BP_ItemPickup_C.ExecuteUbergraph_BP_ItemPickup
// Size: 0x4D3(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ItemPickup
{
	int32_t EntryPoint;  // 0x0(0x4)
	char ECollisionChannel Temp_byte_Variable;  // 0x4(0x1)
	char ECollisionChannel Temp_byte_Variable_2;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x6(0x1)
	char ECollisionResponse Temp_byte_Variable_3;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_Variable : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x10(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)
	float Temp_float_Variable;  // 0x24(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x2C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_2 : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x35(0x1)
	char pad_54_1 : 7;  // 0x36(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x36(0x1)
	char pad_55_1 : 7;  // 0x37(0x1)
	bool CallFunc_HasAuthority_ReturnValue_4 : 1;  // 0x37(0x1)
	float K2Node_Event_Charge;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_4;  // 0x40(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player_2;  // 0x48(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player;  // 0x50(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_3;  // 0x58(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x60(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct AActor* K2Node_CustomEvent_Caller;  // 0xF0(0x8)
	struct AActor* K2Node_CustomEvent_Target;  // 0xF8(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct UStaticMesh* K2Node_CustomEvent_NewMesh;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_CustomEvent_bSimulate_2 : 1;  // 0x118(0x1)
	char pad_281_1 : 7;  // 0x119(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x119(0x1)
	char pad_282[6];  // 0x11A(0x6)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0x120(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x128(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x130(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0x138(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x144(0x88)
	struct FVector K2Node_CustomEvent_Location;  // 0x1CC(0xC)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1D8(0x1)
	char pad_473_1 : 7;  // 0x1D9(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x1D9(0x1)
	char pad_474[2];  // 0x1DA(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x1DC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1E0(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1E4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1F0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1FC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x208(0xC)
	char pad_532[4];  // 0x214(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x218(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x220(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x228(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x230(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x238(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x23C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x240(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x244(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x250(0xC)
	char pad_604[4];  // 0x25C(0x4)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated;  // 0x260(0x8)
	char pad_616_1 : 7;  // 0x268(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x268(0x1)
	char pad_617[3];  // 0x269(0x3)
	int32_t K2Node_CustomEvent_Ammo_2;  // 0x26C(0x4)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x270(0x1)
	char pad_625[3];  // 0x271(0x3)
	int32_t K2Node_CustomEvent_Ammo;  // 0x274(0x4)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x278(0x1)
	char pad_633[7];  // 0x279(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x288(0x1)
	char pad_649_1 : 7;  // 0x289(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x289(0x1)
	char pad_650[2];  // 0x28A(0x2)
	float K2Node_Select_Default;  // 0x28C(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_2;  // 0x290(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	struct FString CallFunc_ToolTipOnLook_tool_tip;  // 0x2A0(0x10)
	struct FString CallFunc_ToolTipOnLook_sub_tip;  // 0x2B0(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x2C0(0x4)
	char pad_708[4];  // 0x2C4(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x2C8(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x2D0(0x4)
	char pad_724_1 : 7;  // 0x2D4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x2D4(0x1)
	char pad_725_1 : 7;  // 0x2D5(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x2D5(0x1)
	char pad_726_1 : 7;  // 0x2D6(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue_2 : 1;  // 0x2D6(0x1)
	char pad_727[1];  // 0x2D7(0x1)
	struct ABP_Blueprint_C* K2Node_DynamicCast_AsBP_Blueprint;  // 0x2D8(0x8)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x2E0(0x1)
	char pad_737[3];  // 0x2E1(0x3)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0x2E4(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2F0(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x2FC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x300(0x4)
	char pad_772_1 : 7;  // 0x304(0x1)
	bool K2Node_CustomEvent_bSimulate : 1;  // 0x304(0x1)
	char pad_773_1 : 7;  // 0x305(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x305(0x1)
	char pad_774[2];  // 0x306(0x2)
	float K2Node_CustomEvent_Damage;  // 0x308(0x4)
	char pad_780_1 : 7;  // 0x30C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x30C(0x1)
	char pad_781[3];  // 0x30D(0x3)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x310(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x318(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x320(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x328(0x4)
	char pad_812_1 : 7;  // 0x32C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x32C(0x1)
	char pad_813[3];  // 0x32D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x330(0x88)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_3;  // 0x3B8(0x8)
	char pad_960_1 : 7;  // 0x3C0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x3C0(0x1)
	char ECollisionChannel K2Node_Select_Default_2;  // 0x3C1(0x1)
	char pad_962[2];  // 0x3C2(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x3C4(0xC)
	char pad_976_1 : 7;  // 0x3D0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x3D0(0x1)
	char pad_977[7];  // 0x3D1(0x7)
	struct APawn* CallFunc_GetInstigator_ReturnValue_2;  // 0x3D8(0x8)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue_2;  // 0x3E0(0xC)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x3EC(0x4)
	float CallFunc_VSize_ReturnValue_2;  // 0x3F0(0x4)
	char pad_1012_1 : 7;  // 0x3F4(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x3F4(0x1)
	char pad_1013_1 : 7;  // 0x3F5(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x3F5(0x1)
	char pad_1014[2];  // 0x3F6(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x3F8(0xC)
	char pad_1028_1 : 7;  // 0x404(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x404(0x1)
	char pad_1029[3];  // 0x405(0x3)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x408(0x10)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_2;  // 0x418(0x10)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool CallFunc_ActorsInRadius_Found : 1;  // 0x428(0x1)
	char pad_1065[7];  // 0x429(0x7)
	struct TArray<struct AActor*> CallFunc_ActorsInRadius_Out_Actors;  // 0x430(0x10)
	char pad_1088_1 : 7;  // 0x440(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x440(0x1)
	char pad_1089[7];  // 0x441(0x7)
	struct AActor* CallFunc_Array_Get_Item;  // 0x448(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x450(0x4)
	char pad_1108_1 : 7;  // 0x454(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x454(0x1)
	char pad_1109[3];  // 0x455(0x3)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Player;  // 0x458(0x8)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0x460(0x10)
	struct FString CallFunc_GetObjectName_ReturnValue_2;  // 0x470(0x10)
	struct FString CallFunc_GetObjectName_ReturnValue_3;  // 0x480(0x10)
	char ECollisionResponse Temp_byte_Variable_4;  // 0x490(0x1)
	char pad_1169[7];  // 0x491(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x498(0x8)
	char ECollisionResponse K2Node_Select_Default_3;  // 0x4A0(0x1)
	char pad_1185[7];  // 0x4A1(0x7)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x4A8(0x8)
	char pad_1200_1 : 7;  // 0x4B0(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x4B0(0x1)
	char pad_1201[7];  // 0x4B1(0x7)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x4B8(0x8)
	char pad_1216_1 : 7;  // 0x4C0(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x4C0(0x1)
	char pad_1217[7];  // 0x4C1(0x7)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_4;  // 0x4C8(0x8)
	char pad_1232_1 : 7;  // 0x4D0(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x4D0(0x1)
	char pad_1233_1 : 7;  // 0x4D1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4D1(0x1)
	char pad_1234_1 : 7;  // 0x4D2(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_3 : 1;  // 0x4D2(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_4_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.PlayerTryPickup
// Size: 0x8(Inherited: 0x0) 
struct FPlayerTryPickup
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.MultiSetCollision
// Size: 0x4(Inherited: 0x0) 
struct FMultiSetCollision
{
	float Damage;  // 0x0(0x4)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.OnLook
// Size: 0x8(Inherited: 0x0) 
struct FOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.OnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.OnRep_Item
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_Item
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.MultiSetPhysics
// Size: 0x1(Inherited: 0x0) 
struct FMultiSetPhysics
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSimulate : 1;  // 0x0(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.GetItem
// Size: 0x90(Inherited: 0x0) 
struct FGetItem
{
	struct FST_ItemBase Item;  // 0x0(0x90)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.ServerChangeAmmo
// Size: 0x4(Inherited: 0x0) 
struct FServerChangeAmmo
{
	int32_t Ammo;  // 0x0(0x4)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.ServerSetAmmo
// Size: 0x4(Inherited: 0x0) 
struct FServerSetAmmo
{
	int32_t Ammo;  // 0x0(0x4)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.MultiSound
// Size: 0xC(Inherited: 0x0) 
struct FMultiSound
{
	struct FVector Location;  // 0x0(0xC)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.MultiSetMesh
// Size: 0x9(Inherited: 0x0) 
struct FMultiSetMesh
{
	struct UStaticMesh* NewMesh;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSimulate : 1;  // 0x8(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.Server_Pickup
// Size: 0x10(Inherited: 0x0) 
struct FServer_Pickup
{
	struct AActor* Caller;  // 0x0(0x8)
	struct AActor* Target;  // 0x8(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.RecieveServerLook
// Size: 0x1(Inherited: 0x0) 
struct FRecieveServerLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Recieve? : 1;  // 0x0(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.OnInteract
// Size: 0x94(Inherited: 0x0) 
struct FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.ServerOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnStopLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.UserConstructionScript
// Size: 0x2(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.ServerOnLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.CanPickup
// Size: 0x2(Inherited: 0x0) 
struct FCanPickup
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanPickup : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.OnChargeUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOnChargeUpdate
{
	float Charge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Caller;  // 0x8(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.TryPickup
// Size: 0x8(Inherited: 0x0) 
struct FTryPickup
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.SetCantPickup
// Size: 0x1(Inherited: 0x0) 
struct FSetCantPickup
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Cant Pickup : 1;  // 0x0(0x1)

}; 
// Function BP_ItemPickup.BP_ItemPickup_C.ToolTipOnLook
// Size: 0x48(Inherited: 0x0) 
struct FToolTipOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FString tool tip;  // 0x8(0x10)
	struct FString sub tip;  // 0x18(0x10)
	struct FString CallFunc_ToolTipForPickup_tool_tip;  // 0x28(0x10)
	struct FString CallFunc_ToolTipForPickup_sub_tip;  // 0x38(0x10)

}; 
