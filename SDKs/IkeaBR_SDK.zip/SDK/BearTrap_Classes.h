#pragma once 
#include <BearTrap_Structs.h>
 
 
 
// BlueprintGeneratedClass BearTrap.BearTrap_C
// Size: 0x298(Inherited: 0x298) 
struct ABearTrap_C : public APlacable_C
{

}; 



