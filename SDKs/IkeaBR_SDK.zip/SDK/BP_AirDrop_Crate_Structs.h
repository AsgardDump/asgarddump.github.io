#pragma once 
#include "SDK.h" 
 
 
// Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ExecuteUbergraph_BP_AirDrop_Crate
// Size: 0x461(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AirDrop_Crate
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x10(0x30)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x40(0x4)
	float K2Node_CustomEvent_NewRate;  // 0x44(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x50(0x8)
	struct ABP_FlyingItemsCrate_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x58(0x8)
	float CallFunc_BreakVector_X;  // 0x60(0x4)
	float CallFunc_BreakVector_Y;  // 0x64(0x4)
	float CallFunc_BreakVector_Z;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x7C(0xC)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	float CallFunc_BreakRotator_Roll;  // 0x8C(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x90(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x94(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x98(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0xA4(0x88)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x12C(0x1)
	char pad_301_1 : 7;  // 0x12D(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x12D(0x1)
	char pad_302_1 : 7;  // 0x12E(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x12E(0x1)
	char pad_303[1];  // 0x12F(0x1)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x130(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_3;  // 0x13C(0xC)
	float CallFunc_BreakVector_X_2;  // 0x148(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x14C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x150(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x154(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x158(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_4;  // 0x164(0xC)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x170(0x4)
	float CallFunc_BreakVector_X_3;  // 0x174(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x178(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x17C(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x180(0x10)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue_2;  // 0x190(0xC)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue_3;  // 0x19C(0xC)
	struct FRotator CallFunc_RInterpTo_ReturnValue;  // 0x1A8(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult_2;  // 0x1B4(0x88)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_5;  // 0x23C(0xC)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x248(0x10)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x258(0x88)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x2E0(0x1)
	char pad_737_1 : 7;  // 0x2E1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2E1(0x1)
	char pad_738_1 : 7;  // 0x2E2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2E2(0x1)
	char pad_739[1];  // 0x2E3(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x2E4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x2E8(0x4)
	char pad_748_1 : 7;  // 0x2EC(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x2EC(0x1)
	char pad_749[3];  // 0x2ED(0x3)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x2F0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x2F8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x300(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x308(0x4)
	char pad_780_1 : 7;  // 0x30C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x30C(0x1)
	char pad_781[3];  // 0x30D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x310(0x88)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated;  // 0x398(0x8)
	char pad_928_1 : 7;  // 0x3A0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x3A0(0x1)
	char pad_929[3];  // 0x3A1(0x3)
	float CallFunc_VSize_ReturnValue;  // 0x3A4(0x4)
	char pad_936_1 : 7;  // 0x3A8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x3A8(0x1)
	char pad_937[3];  // 0x3A9(0x3)
	float CallFunc_Lerp_ReturnValue;  // 0x3AC(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x3B0(0xC)
	struct FVector CallFunc_VInterpTo_ReturnValue;  // 0x3BC(0xC)
	struct FHitResult CallFunc_K2_SetWorldLocation_SweepHitResult;  // 0x3C8(0x88)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_6;  // 0x450(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x45C(0x4)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x460(0x1)

}; 
// Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ServerDescend
// Size: 0x4(Inherited: 0x0) 
struct FServerDescend
{
	float NewRate;  // 0x0(0x4)

}; 
// Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.BndEvt__PropCollisionBox_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__PropCollisionBox_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.UpdateHook
// Size: 0x24(Inherited: 0x0) 
struct FUpdateHook
{
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0xC(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x18(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x20(0x4)

}; 
