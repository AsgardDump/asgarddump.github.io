#pragma once 
#include <Box1_Structs.h>
 
 
 
// BlueprintGeneratedClass Box1.Box1_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct ABox1_C : public AMovable_Object_Replicated_C
{

}; 



