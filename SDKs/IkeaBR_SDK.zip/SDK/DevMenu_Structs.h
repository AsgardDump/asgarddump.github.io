#pragma once 
#include "SDK.h" 
 
 
// Function DevMenu.DevMenu_C.BndEvt__HC_K2Node_ComponentBoundEvent_1_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__HC_K2Node_ComponentBoundEvent_1_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function DevMenu.DevMenu_C.ExecuteUbergraph_DevMenu
// Size: 0xD1(Inherited: 0x0) 
struct FExecuteUbergraph_DevMenu
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_GetGlobalVar_bool : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_GetGlobalVar_bool_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked_3 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked_2 : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool K2Node_ComponentBoundEvent_bIsChecked : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString K2Node_ComponentBoundEvent_SelectedItem;  // 0x10(0x10)
	char ESelectInfo K2Node_ComponentBoundEvent_SelectionType;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UGameUserSettings* CallFunc_GetGameUserSettings_ReturnValue;  // 0x28(0x8)
	int32_t CallFunc_SettingToInt_int;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x38(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FText CallFunc_GetText_ReturnValue;  // 0x50(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x68(0x10)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_2;  // 0x78(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_3;  // 0x90(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_3;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_4;  // 0xA8(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_4;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0xC0(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0xC8(0x8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0xD0(0x1)

}; 
// Function DevMenu.DevMenu_C.BndEvt__ComboBoxString_149_K2Node_ComponentBoundEvent_3_OnSelectionChangedEvent__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FBndEvt__ComboBoxString_149_K2Node_ComponentBoundEvent_3_OnSelectionChangedEvent__DelegateSignature
{
	struct FString SelectedItem;  // 0x0(0x10)
	char ESelectInfo SelectionType;  // 0x10(0x1)

}; 
// Function DevMenu.DevMenu_C.BndEvt__S_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__S_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function DevMenu.DevMenu_C.BndEvt__GM_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__GM_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
