#pragma once 
#include <DismantleStaion_Structs.h>
 
 
 
// BlueprintGeneratedClass DismantleStaion.DismantleStaion_C
// Size: 0x248(Inherited: 0x220) 
struct ADismantleStaion_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* MedStationAmbient_Cue;  // 0x228(0x8)
	struct UChildActorComponent* Light;  // 0x230(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x238(0x8)
	struct AFirstPersonCharacter_C* User;  // 0x240(0x8)

	void RecieveServerLook(bool& Recieve?); // Function DismantleStaion.DismantleStaion_C.RecieveServerLook
	void OnChargeUpdate(float Charge, struct AFirstPersonCharacter_C* Caller); // Function DismantleStaion.DismantleStaion_C.OnChargeUpdate
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function DismantleStaion.DismantleStaion_C.OnInteract
	void ClientStart(struct AFirstPersonCharacter_C* Character); // Function DismantleStaion.DismantleStaion_C.ClientStart
	void OnLook(struct AFirstPersonCharacter_C* Caller); // Function DismantleStaion.DismantleStaion_C.OnLook
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function DismantleStaion.DismantleStaion_C.OnStopLook
	void Stop(struct AFirstPersonCharacter_C* User); // Function DismantleStaion.DismantleStaion_C.Stop
	void ServerStop(struct AFirstPersonCharacter_C* User); // Function DismantleStaion.DismantleStaion_C.ServerStop
	void ReceiveBeginPlay(); // Function DismantleStaion.DismantleStaion_C.ReceiveBeginPlay
	void ServerOnLook(struct AFirstPersonCharacter_C* Player); // Function DismantleStaion.DismantleStaion_C.ServerOnLook
	void ServerOnStopLook(struct AFirstPersonCharacter_C* Player); // Function DismantleStaion.DismantleStaion_C.ServerOnStopLook
	void ReceiveDestroyed(); // Function DismantleStaion.DismantleStaion_C.ReceiveDestroyed
	void ExecuteUbergraph_DismantleStaion(int32_t EntryPoint); // Function DismantleStaion.DismantleStaion_C.ExecuteUbergraph_DismantleStaion
}; 



