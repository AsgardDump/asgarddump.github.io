#pragma once 
#include <ClassicRoundTable_Structs.h>
 
 
 
// BlueprintGeneratedClass ClassicRoundTable.ClassicRoundTable_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AClassicRoundTable_C : public AMovable_Object_Replicated_C
{

}; 



