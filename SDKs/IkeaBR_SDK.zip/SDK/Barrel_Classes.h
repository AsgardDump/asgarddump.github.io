#pragma once 
#include <Barrel_Structs.h>
 
 
 
// BlueprintGeneratedClass Barrel.Barrel_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct ABarrel_C : public AMovable_Object_Replicated_C
{

}; 



