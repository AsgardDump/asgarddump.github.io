#pragma once 
#include "SDK.h" 
 
 
// Function FireExtinguisher_BP.FireExtinguisher_BP_C.ExecuteUbergraph_FireExtinguisher_BP
// Size: 0x1A6(Inherited: 0x0) 
struct FExecuteUbergraph_FireExtinguisher_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool K2Node_Event_Down : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x18(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x24(0xC)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x30(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x38(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x40(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x50(0x88)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xE1(0x1)
	char pad_226[6];  // 0xE2(0x6)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0xE8(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0xF8(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x109(0x1)
	char pad_266[6];  // 0x10A(0x6)
	struct FST_ItemBase CallFunc_Array_Get_Item_2;  // 0x110(0x90)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1A0(0x4)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1A4(0x1)
	char pad_421_1 : 7;  // 0x1A5(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x1A5(0x1)

}; 
// Function FireExtinguisher_BP.FireExtinguisher_BP_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function FireExtinguisher_BP.FireExtinguisher_BP_C.LMB
// Size: 0x1(Inherited: 0x1) 
struct FLMB : public FLMB
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
