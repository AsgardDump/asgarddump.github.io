#pragma once 
#include <DevMenu_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DevMenu.DevMenu_C
// Size: 0x2A8(Inherited: 0x260) 
struct UDevMenu_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UButton* Button;  // 0x268(0x8)
	struct UButton* Button_2;  // 0x270(0x8)
	struct UButton* Button_3;  // 0x278(0x8)
	struct UButton* Button_4;  // 0x280(0x8)
	struct UButton* Button_228;  // 0x288(0x8)
	struct UEditableTextBox* EditableTextBox_130;  // 0x290(0x8)
	struct UCheckBox* GM;  // 0x298(0x8)
	struct UCheckBox* S;  // 0x2A0(0x8)

	void Construct(); // Function DevMenu.DevMenu_C.Construct
	void BndEvt__GM_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function DevMenu.DevMenu_C.BndEvt__GM_K2Node_ComponentBoundEvent_0_OnCheckBoxComponentStateChanged__DelegateSignature
	void BndEvt__HC_K2Node_ComponentBoundEvent_1_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function DevMenu.DevMenu_C.BndEvt__HC_K2Node_ComponentBoundEvent_1_OnCheckBoxComponentStateChanged__DelegateSignature
	void BndEvt__S_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature(bool bIsChecked); // Function DevMenu.DevMenu_C.BndEvt__S_K2Node_ComponentBoundEvent_2_OnCheckBoxComponentStateChanged__DelegateSignature
	void BndEvt__ComboBoxString_149_K2Node_ComponentBoundEvent_3_OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, char ESelectInfo SelectionType); // Function DevMenu.DevMenu_C.BndEvt__ComboBoxString_149_K2Node_ComponentBoundEvent_3_OnSelectionChangedEvent__DelegateSignature
	void BndEvt__Button_227_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature(); // Function DevMenu.DevMenu_C.BndEvt__Button_227_K2Node_ComponentBoundEvent_4_OnButtonClickedEvent__DelegateSignature
	void BndEvt__Button_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature(); // Function DevMenu.DevMenu_C.BndEvt__Button_K2Node_ComponentBoundEvent_5_OnButtonClickedEvent__DelegateSignature
	void BndEvt__Button_1_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature(); // Function DevMenu.DevMenu_C.BndEvt__Button_1_K2Node_ComponentBoundEvent_6_OnButtonClickedEvent__DelegateSignature
	void BndEvt__Button_2_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature(); // Function DevMenu.DevMenu_C.BndEvt__Button_2_K2Node_ComponentBoundEvent_7_OnButtonClickedEvent__DelegateSignature
	void BndEvt__Button_3_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature(); // Function DevMenu.DevMenu_C.BndEvt__Button_3_K2Node_ComponentBoundEvent_8_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_DevMenu(int32_t EntryPoint); // Function DevMenu.DevMenu_C.ExecuteUbergraph_DevMenu
}; 



