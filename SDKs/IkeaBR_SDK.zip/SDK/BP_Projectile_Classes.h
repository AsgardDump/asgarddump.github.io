#pragma once 
#include <BP_Projectile_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Projectile.BP_Projectile_C
// Size: 0x257(Inherited: 0x220) 
struct ABP_Projectile_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Fly;  // 0x228(0x8)
	struct UCapsuleComponent* Capsule;  // 0x230(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x238(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x240(0x8)
	struct UProjectileMovementComponent* ProjectileMovement;  // 0x248(0x8)
	float Damage;  // 0x250(0x4)
	char pad_596_1 : 7;  // 0x254(0x1)
	bool Dealer : 1;  // 0x254(0x1)
	char pad_597_1 : 7;  // 0x255(0x1)
	bool Override : 1;  // 0x255(0x1)
	char pad_598_1 : 7;  // 0x256(0x1)
	bool StickToHitObject : 1;  // 0x256(0x1)

	void Stop(struct FHitResult& HitResult); // Function BP_Projectile.BP_Projectile_C.Stop
	void ReceiveBeginPlay(); // Function BP_Projectile.BP_Projectile_C.ReceiveBeginPlay
	void Hit(struct AActor* other actor, struct FHitResult& HitResult); // Function BP_Projectile.BP_Projectile_C.Hit
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Projectile.BP_Projectile_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
	void FlySound(); // Function BP_Projectile.BP_Projectile_C.FlySound
	void ReceiveTick(float DeltaSeconds); // Function BP_Projectile.BP_Projectile_C.ReceiveTick
	void BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature(struct FHitResult& ImpactResult); // Function BP_Projectile.BP_Projectile_C.BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature
	void ExecuteUbergraph_BP_Projectile(int32_t EntryPoint); // Function BP_Projectile.BP_Projectile_C.ExecuteUbergraph_BP_Projectile
}; 



