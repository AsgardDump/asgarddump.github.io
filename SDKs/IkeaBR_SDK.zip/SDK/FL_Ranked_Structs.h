#pragma once 
#include "SDK.h" 
 
 
// Function FL_Ranked.FL_Ranked_C.RankedEnabled?
// Size: 0x9(Inherited: 0x0) 
struct FRankedEnabled?
{
	struct UObject* __WorldContext;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)

}; 
// Function FL_Ranked.FL_Ranked_C.RPToRank
// Size: 0x32(Inherited: 0x0) 
struct FRPToRank
{
	int32_t RP;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* __WorldContext;  // 0x8(0x8)
	char E_Rank Rank;  // 0x10(0x1)
	char E_Rank Temp_byte_Variable;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_2 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_3 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_4 : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_5 : 1;  // 0x16(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_6 : 1;  // 0x17(0x1)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_7 : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_8 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_Variable : 1;  // 0x1A(0x1)
	char E_Rank Temp_byte_Variable_2;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x1C(0x1)
	char E_Rank Temp_byte_Variable_3;  // 0x1D(0x1)
	char pad_30_1 : 7;  // 0x1E(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x1E(0x1)
	char E_Rank Temp_byte_Variable_4;  // 0x1F(0x1)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x20(0x1)
	char E_Rank Temp_byte_Variable_5;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x22(0x1)
	char E_Rank Temp_byte_Variable_6;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0x24(0x1)
	char E_Rank Temp_byte_Variable_7;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0x26(0x1)
	char E_Rank Temp_byte_Variable_8;  // 0x27(0x1)
	char E_Rank Temp_byte_Variable_9;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0x29(0x1)
	char E_Rank K2Node_Select_Default;  // 0x2A(0x1)
	char E_Rank K2Node_Select_Default_2;  // 0x2B(0x1)
	char E_Rank K2Node_Select_Default_3;  // 0x2C(0x1)
	char E_Rank K2Node_Select_Default_4;  // 0x2D(0x1)
	char E_Rank K2Node_Select_Default_5;  // 0x2E(0x1)
	char E_Rank K2Node_Select_Default_6;  // 0x2F(0x1)
	char E_Rank K2Node_Select_Default_7;  // 0x30(0x1)
	char E_Rank K2Node_Select_Default_8;  // 0x31(0x1)

}; 
// Function FL_Ranked.FL_Ranked_C.StatsToRP
// Size: 0x64(Inherited: 0x0) 
struct FStatsToRP
{
	struct FST_Stats Stats;  // 0x0(0x24)
	int32_t InitialPlayersInMatch;  // 0x24(0x4)
	struct UObject* __WorldContext;  // 0x28(0x8)
	int32_t RP;  // 0x30(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x34(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	int32_t CallFunc_Multiply_IntInt_ReturnValue_2;  // 0x40(0x4)
	int32_t CallFunc_Conv_BoolToInt_ReturnValue;  // 0x44(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x48(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue_3;  // 0x4C(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x54(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x58(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x5C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x60(0x4)

}; 
// Function FL_Ranked.FL_Ranked_C.RPTax
// Size: 0x3C(Inherited: 0x0) 
struct FRPTax
{
	char E_Rank Rank;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	int32_t RPTax;  // 0x10(0x4)
	char E_Rank Temp_byte_Variable;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t Temp_int_Variable;  // 0x18(0x4)
	int32_t Temp_int_Variable_2;  // 0x1C(0x4)
	int32_t Temp_int_Variable_3;  // 0x20(0x4)
	int32_t Temp_int_Variable_4;  // 0x24(0x4)
	int32_t Temp_int_Variable_5;  // 0x28(0x4)
	int32_t Temp_int_Variable_6;  // 0x2C(0x4)
	int32_t Temp_int_Variable_7;  // 0x30(0x4)
	int32_t Temp_int_Variable_8;  // 0x34(0x4)
	int32_t K2Node_Select_Default;  // 0x38(0x4)

}; 
// Function FL_Ranked.FL_Ranked_C.RankToRankIcon
// Size: 0x68(Inherited: 0x0) 
struct FRankToRankIcon
{
	char E_Rank Rank;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* __WorldContext;  // 0x8(0x8)
	struct UTexture2D* Icon;  // 0x10(0x8)
	char E_Rank Temp_byte_Variable;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UTexture2D* Temp_object_Variable;  // 0x20(0x8)
	struct UTexture2D* Temp_object_Variable_2;  // 0x28(0x8)
	struct UTexture2D* Temp_object_Variable_3;  // 0x30(0x8)
	struct UTexture2D* Temp_object_Variable_4;  // 0x38(0x8)
	struct UTexture2D* Temp_object_Variable_5;  // 0x40(0x8)
	struct UTexture2D* Temp_object_Variable_6;  // 0x48(0x8)
	struct UTexture2D* Temp_object_Variable_7;  // 0x50(0x8)
	struct UTexture2D* Temp_object_Variable_8;  // 0x58(0x8)
	struct UTexture2D* K2Node_Select_Default;  // 0x60(0x8)

}; 
