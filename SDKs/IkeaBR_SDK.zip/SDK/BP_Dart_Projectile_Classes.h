#pragma once 
#include <BP_Dart_Projectile_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Dart_Projectile.BP_Dart_Projectile_C
// Size: 0x257(Inherited: 0x257) 
struct ABP_Dart_Projectile_C : public ABP_Projectile_C
{

}; 



