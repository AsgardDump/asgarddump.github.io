#pragma once 
#include "SDK.h" 
 
 
// Function BP_Tracker.BP_Tracker_C.ExecuteUbergraph_BP_Tracker
// Size: 0x178(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Tracker
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_Down : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Hitter;  // 0x8(0x8)
	float K2Node_CustomEvent_Damage;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	ABP_Tracker_C* CallFunc_GetObjectClass_ReturnValue;  // 0x18(0x8)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0x20(0x90)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FST_ItemBase CallFunc_Array_Get_Item_2;  // 0xB8(0x90)
	ABP_Tracker_C* CallFunc_GetObjectClass_ReturnValue_2;  // 0x148(0x8)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_2 : 1;  // 0x150(0x1)
	char pad_337_1 : 7;  // 0x151(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x151(0x1)
	char pad_338[2];  // 0x152(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x154(0x10)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_CanDoStuff__ : 1;  // 0x164(0x1)
	char pad_357_1 : 7;  // 0x165(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x165(0x1)
	char pad_358_1 : 7;  // 0x166(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x166(0x1)
	char pad_359_1 : 7;  // 0x167(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x167(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x168(0x10)

}; 
// Function BP_Tracker.BP_Tracker_C.Hit
// Size: 0xC(Inherited: 0x0) 
struct FHit
{
	struct AFirstPersonCharacter_C* Hitter;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function BP_Tracker.BP_Tracker_C.LMB_Pure
// Size: 0x1(Inherited: 0x1) 
struct FLMB_Pure : public FLMB_Pure
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
