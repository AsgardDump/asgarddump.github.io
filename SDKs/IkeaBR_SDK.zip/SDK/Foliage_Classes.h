#pragma once 
#include <Foliage_Structs.h>
 
 
 
// Class Foliage.FoliageType
// Size: 0x3B0(Inherited: 0x28) 
struct UFoliageType : public UObject
{
	struct FGuid UpdateGuid;  // 0x28(0x10)
	float Density;  // 0x38(0x4)
	float DensityAdjustmentFactor;  // 0x3C(0x4)
	float Radius;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bSingleInstanceModeOverrideRadius : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	float SingleInstanceModeRadius;  // 0x48(0x4)
	uint8_t  Scaling;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FFloatInterval ScaleX;  // 0x50(0x8)
	struct FFloatInterval ScaleY;  // 0x58(0x8)
	struct FFloatInterval ScaleZ;  // 0x60(0x8)
	struct FFoliageVertexColorChannelMask VertexColorMaskByChannel[4];  // 0x68(0x30)
	char FoliageVertexColorMask VertexColorMask;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	float VertexColorMaskThreshold;  // 0x9C(0x4)
	char VertexColorMaskInvert : 1;  // 0xA0(0x1)
	char pad_160_1 : 7;  // 0xA0(0x1)
	char pad_161[4];  // 0xA1(0x4)
	struct FFloatInterval ZOffset;  // 0xA4(0x8)
	char AlignToNormal : 1;  // 0xAC(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	char pad_173[4];  // 0xAD(0x4)
	float AlignMaxAngle;  // 0xB0(0x4)
	char RandomYaw : 1;  // 0xB4(0x1)
	char pad_180_1 : 7;  // 0xB4(0x1)
	char pad_181[4];  // 0xB5(0x4)
	float RandomPitchAngle;  // 0xB8(0x4)
	struct FFloatInterval GroundSlopeAngle;  // 0xBC(0x8)
	struct FFloatInterval Height;  // 0xC4(0x8)
	char pad_204[4];  // 0xCC(0x4)
	struct TArray<struct FName> LandscapeLayers;  // 0xD0(0x10)
	float MinimumLayerWeight;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct TArray<struct FName> ExclusionLandscapeLayers;  // 0xE8(0x10)
	float MinimumExclusionLayerWeight;  // 0xF8(0x4)
	struct FName LandscapeLayer;  // 0xFC(0x8)
	char CollisionWithWorld : 1;  // 0x104(0x1)
	char pad_260_1 : 7;  // 0x104(0x1)
	char pad_261[4];  // 0x105(0x4)
	struct FVector CollisionScale;  // 0x108(0xC)
	struct FBoxSphereBounds MeshBounds;  // 0x114(0x1C)
	struct FVector LowBoundOriginRadius;  // 0x130(0xC)
	char EComponentMobility Mobility;  // 0x13C(0x1)
	char pad_317[3];  // 0x13D(0x3)
	struct FInt32Interval CullDistance;  // 0x140(0x8)
	char bEnableStaticLighting : 1;  // 0x148(0x1)
	char CastShadow : 1;  // 0x148(0x1)
	char bAffectDynamicIndirectLighting : 1;  // 0x148(0x1)
	char bAffectDistanceFieldLighting : 1;  // 0x148(0x1)
	char bCastDynamicShadow : 1;  // 0x148(0x1)
	char bCastStaticShadow : 1;  // 0x148(0x1)
	char bCastShadowAsTwoSided : 1;  // 0x148(0x1)
	char bReceivesDecals : 1;  // 0x148(0x1)
	char bOverrideLightMapRes : 1;  // 0x149(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	char pad_330[3];  // 0x14A(0x3)
	int32_t OverriddenLightMapRes;  // 0x14C(0x4)
	uint8_t  LightmapType;  // 0x150(0x1)
	char pad_337[3];  // 0x151(0x3)
	char bUseAsOccluder : 1;  // 0x154(0x1)
	char pad_340_1 : 7;  // 0x154(0x1)
	char pad_341[4];  // 0x155(0x4)
	char bVisibleInRayTracing : 1;  // 0x158(0x1)
	char bEvaluateWorldPositionOffset : 1;  // 0x158(0x1)
	char pad_344_1 : 6;  // 0x158(0x1)
	char pad_345[8];  // 0x159(0x8)
	struct FBodyInstance BodyInstance;  // 0x160(0x158)
	char EHasCustomNavigableGeometry CustomNavigableGeometry;  // 0x2B8(0x1)
	struct FLightingChannels LightingChannels;  // 0x2B9(0x1)
	char pad_698[2];  // 0x2BA(0x2)
	char bRenderCustomDepth : 1;  // 0x2BC(0x1)
	char pad_700_1 : 7;  // 0x2BC(0x1)
	char pad_701[4];  // 0x2BD(0x4)
	uint8_t  CustomDepthStencilWriteMask;  // 0x2C0(0x1)
	char pad_705[3];  // 0x2C1(0x3)
	int32_t CustomDepthStencilValue;  // 0x2C4(0x4)
	int32_t TranslucencySortPriority;  // 0x2C8(0x4)
	float CollisionRadius;  // 0x2CC(0x4)
	float ShadeRadius;  // 0x2D0(0x4)
	int32_t NumSteps;  // 0x2D4(0x4)
	float InitialSeedDensity;  // 0x2D8(0x4)
	float AverageSpreadDistance;  // 0x2DC(0x4)
	float SpreadVariance;  // 0x2E0(0x4)
	int32_t SeedsPerStep;  // 0x2E4(0x4)
	int32_t DistributionSeed;  // 0x2E8(0x4)
	float MaxInitialSeedOffset;  // 0x2EC(0x4)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool bCanGrowInShade : 1;  // 0x2F0(0x1)
	char pad_753_1 : 7;  // 0x2F1(0x1)
	bool bSpawnsInShade : 1;  // 0x2F1(0x1)
	char pad_754[2];  // 0x2F2(0x2)
	float MaxInitialAge;  // 0x2F4(0x4)
	float MaxAge;  // 0x2F8(0x4)
	float OverlapPriority;  // 0x2FC(0x4)
	struct FFloatInterval ProceduralScale;  // 0x300(0x8)
	struct FRuntimeFloatCurve ScaleCurve;  // 0x308(0x88)
	int32_t ChangeCount;  // 0x390(0x4)
	char ReapplyDensity : 1;  // 0x394(0x1)
	char ReapplyRadius : 1;  // 0x394(0x1)
	char ReapplyAlignToNormal : 1;  // 0x394(0x1)
	char ReapplyRandomYaw : 1;  // 0x394(0x1)
	char ReapplyScaling : 1;  // 0x394(0x1)
	char ReapplyScaleX : 1;  // 0x394(0x1)
	char ReapplyScaleY : 1;  // 0x394(0x1)
	char ReapplyScaleZ : 1;  // 0x394(0x1)
	char ReapplyRandomPitchAngle : 1;  // 0x395(0x1)
	char ReapplyGroundSlope : 1;  // 0x395(0x1)
	char ReapplyHeight : 1;  // 0x395(0x1)
	char ReapplyLandscapeLayers : 1;  // 0x395(0x1)
	char ReapplyZOffset : 1;  // 0x395(0x1)
	char ReapplyCollisionWithWorld : 1;  // 0x395(0x1)
	char ReapplyVertexColorMask : 1;  // 0x395(0x1)
	char bEnableDensityScaling : 1;  // 0x395(0x1)
	char bEnableDiscardOnLoad : 1;  // 0x396(0x1)
	char pad_918_1 : 7;  // 0x396(0x1)
	char pad_919[2];  // 0x397(0x2)
	struct TArray<struct URuntimeVirtualTexture*> RuntimeVirtualTextures;  // 0x398(0x10)
	int32_t VirtualTextureCullMips;  // 0x3A8(0x4)
	uint8_t  VirtualTextureRenderPassType;  // 0x3AC(0x1)
	char pad_941[3];  // 0x3AD(0x3)

}; 



// Class Foliage.FoliageType_Actor
// Size: 0x3C0(Inherited: 0x3B0) 
struct UFoliageType_Actor : public UFoliageType
{
	AActor* ActorClass;  // 0x3B0(0x8)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool bShouldAttachToBaseComponent : 1;  // 0x3B8(0x1)
	char pad_953[7];  // 0x3B9(0x7)

}; 



// Class Foliage.FoliageStatistics
// Size: 0x28(Inherited: 0x28) 
struct UFoliageStatistics : public UBlueprintFunctionLibrary
{

	int32_t FoliageOverlappingSphereCount(struct UObject* worldContextObject, struct UStaticMesh* StaticMesh, struct FVector CenterPosition, float Radius); // Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount
	int32_t FoliageOverlappingBoxCount(struct UObject* worldContextObject, struct UStaticMesh* StaticMesh, struct FBox Box); // Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount
}; 



// Class Foliage.FoliageInstancedStaticMeshComponent
// Size: 0x6B0(Inherited: 0x680) 
struct UFoliageInstancedStaticMeshComponent : public UHierarchicalInstancedStaticMeshComponent
{
	struct FMulticastInlineDelegate OnInstanceTakePointDamage;  // 0x678(0x10)
	struct FMulticastInlineDelegate OnInstanceTakeRadialDamage;  // 0x688(0x10)
	struct FGuid GenerationGuid;  // 0x698(0x10)

}; 



// Class Foliage.FoliageType_InstancedStaticMesh
// Size: 0x3D0(Inherited: 0x3B0) 
struct UFoliageType_InstancedStaticMesh : public UFoliageType
{
	struct UStaticMesh* Mesh;  // 0x3B0(0x8)
	struct TArray<struct UMaterialInterface*> OverrideMaterials;  // 0x3B8(0x10)
	UFoliageInstancedStaticMeshComponent* ComponentClass;  // 0x3C8(0x8)

}; 



// Class Foliage.InstancedFoliageActor
// Size: 0x270(Inherited: 0x220) 
struct AInstancedFoliageActor : public AActor
{
	char pad_544[80];  // 0x220(0x50)

}; 



// Class Foliage.InteractiveFoliageActor
// Size: 0x290(Inherited: 0x230) 
struct AInteractiveFoliageActor : public AStaticMeshActor
{
	struct UCapsuleComponent* CapsuleComponent;  // 0x230(0x8)
	struct FVector TouchingActorEntryPosition;  // 0x238(0xC)
	struct FVector FoliageVelocity;  // 0x244(0xC)
	struct FVector FoliageForce;  // 0x250(0xC)
	struct FVector FoliagePosition;  // 0x25C(0xC)
	float FoliageDamageImpulseScale;  // 0x268(0x4)
	float FoliageTouchImpulseScale;  // 0x26C(0x4)
	float FoliageStiffness;  // 0x270(0x4)
	float FoliageStiffnessQuadratic;  // 0x274(0x4)
	float FoliageDamping;  // 0x278(0x4)
	float MaxDamageImpulse;  // 0x27C(0x4)
	float MaxTouchImpulse;  // 0x280(0x4)
	float MaxForce;  // 0x284(0x4)
	float Mass;  // 0x288(0x4)
	char pad_652[4];  // 0x28C(0x4)

	void CapsuleTouched(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& OverlapInfo); // Function Foliage.InteractiveFoliageActor.CapsuleTouched
}; 



// Class Foliage.InteractiveFoliageComponent
// Size: 0x4F0(Inherited: 0x4E0) 
struct UInteractiveFoliageComponent : public UStaticMeshComponent
{
	char pad_1248[16];  // 0x4E0(0x10)

}; 



// Class Foliage.ProceduralFoliageBlockingVolume
// Size: 0x260(Inherited: 0x258) 
struct AProceduralFoliageBlockingVolume : public AVolume
{
	struct AProceduralFoliageVolume* ProceduralFoliageVolume;  // 0x258(0x8)

}; 



// Class Foliage.ProceduralFoliageComponent
// Size: 0xD8(Inherited: 0xB0) 
struct UProceduralFoliageComponent : public UActorComponent
{
	struct UProceduralFoliageSpawner* FoliageSpawner;  // 0xB0(0x8)
	float TileOverlap;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct AVolume* SpawningVolume;  // 0xC0(0x8)
	struct FGuid ProceduralGuid;  // 0xC8(0x10)

}; 



// Class Foliage.ProceduralFoliageSpawner
// Size: 0x68(Inherited: 0x28) 
struct UProceduralFoliageSpawner : public UObject
{
	int32_t RandomSeed;  // 0x28(0x4)
	float TileSize;  // 0x2C(0x4)
	int32_t NumUniqueTiles;  // 0x30(0x4)
	float MinimumQuadTreeSize;  // 0x34(0x4)
	char pad_56[8];  // 0x38(0x8)
	struct TArray<struct FFoliageTypeObject> FoliageTypes;  // 0x40(0x10)
	char pad_80[24];  // 0x50(0x18)

	void Simulate(int32_t NumSteps); // Function Foliage.ProceduralFoliageSpawner.Simulate
}; 



// Class Foliage.ProceduralFoliageTile
// Size: 0x158(Inherited: 0x28) 
struct UProceduralFoliageTile : public UObject
{
	struct UProceduralFoliageSpawner* FoliageSpawner;  // 0x28(0x8)
	char pad_48[160];  // 0x30(0xA0)
	struct TArray<struct FProceduralFoliageInstance> InstancesArray;  // 0xD0(0x10)
	char pad_224[120];  // 0xE0(0x78)

}; 



// Class Foliage.ProceduralFoliageVolume
// Size: 0x260(Inherited: 0x258) 
struct AProceduralFoliageVolume : public AVolume
{
	struct UProceduralFoliageComponent* ProceduralComponent;  // 0x258(0x8)

}; 



