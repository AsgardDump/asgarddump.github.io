#pragma once 
#include <BP_Blueprint_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Blueprint.BP_Blueprint_C
// Size: 0x2EC(Inherited: 0x2D3) 
struct ABP_Blueprint_C : public ABP_ItemPickup_C
{
	char pad_723[5];  // 0x2D3(0x5)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2D8(0x8)
	struct UDecalComponent* Decal;  // 0x2E0(0x8)
	int32_t RecipeID;  // 0x2E8(0x4)

	void ToolTipOnLook(struct AFirstPersonCharacter_C* Caller, struct FString& tool tip, struct FString& sub tip); // Function BP_Blueprint.BP_Blueprint_C.ToolTipOnLook
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function BP_Blueprint.BP_Blueprint_C.OnInteract
	void ReceiveBeginPlay(); // Function BP_Blueprint.BP_Blueprint_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Blueprint(int32_t EntryPoint); // Function BP_Blueprint.BP_Blueprint_C.ExecuteUbergraph_BP_Blueprint
}; 



