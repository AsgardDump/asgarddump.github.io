#pragma once 
#include <AxeBP_Structs.h>
 
 
 
// BlueprintGeneratedClass AxeBP.AxeBP_C
// Size: 0x290(Inherited: 0x290) 
struct AAxeBP_C : public AWeaponBP_C
{

}; 



