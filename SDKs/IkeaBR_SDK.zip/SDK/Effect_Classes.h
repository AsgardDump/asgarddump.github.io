#pragma once 
#include <Effect_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Effect.Effect_C
// Size: 0x2B0(Inherited: 0x260) 
struct UEffect_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UBorder* Border_59;  // 0x268(0x8)
	struct UImage* Image_122;  // 0x270(0x8)
	struct UProgressBar* ProgressBar_107;  // 0x278(0x8)
	struct UTextBlock* TextBlock_43;  // 0x280(0x8)
	struct ABP_Effect_C* Effect;  // 0x288(0x8)
	struct FST_EffectRep EffectRep;  // 0x290(0x20)

	struct FText GetText_1(); // Function Effect.Effect_C.GetText_1
	struct FLinearColor GetFillColorAndOpacity_1(); // Function Effect.Effect_C.GetFillColorAndOpacity_1
	struct FSlateBrush GetBrush_1(); // Function Effect.Effect_C.GetBrush_1
	float GetPercent_1(); // Function Effect.Effect_C.GetPercent_1
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function Effect.Effect_C.Tick
	void ExecuteUbergraph_Effect(int32_t EntryPoint); // Function Effect.Effect_C.ExecuteUbergraph_Effect
}; 



