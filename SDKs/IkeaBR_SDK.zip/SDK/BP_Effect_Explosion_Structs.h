#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Explosion.BP_Effect_Explosion_C.ExecuteUbergraph_BP_Effect_Explosion
// Size: 0x58(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Explosion
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x14(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x20(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsPendingKill_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent_2;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent_3;  // 0x48(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x50(0x8)

}; 
