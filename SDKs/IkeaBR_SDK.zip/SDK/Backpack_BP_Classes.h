#pragma once 
#include <Backpack_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Backpack_BP.Backpack_BP_C
// Size: 0x270(Inherited: 0x268) 
struct ABackpack_BP_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)

	void Equip(); // Function Backpack_BP.Backpack_BP_C.Equip
	void Unequip(); // Function Backpack_BP.Backpack_BP_C.Unequip
	void LMB(bool Down); // Function Backpack_BP.Backpack_BP_C.LMB
	void ExecuteUbergraph_Backpack_BP(int32_t EntryPoint); // Function Backpack_BP.Backpack_BP_C.ExecuteUbergraph_Backpack_BP
}; 



