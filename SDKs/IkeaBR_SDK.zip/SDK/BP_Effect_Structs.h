#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect.BP_Effect_C.ExecuteUbergraph_BP_Effect
// Size: 0x3A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x28(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x39(0x1)

}; 
// Function BP_Effect.BP_Effect_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Effect.BP_Effect_C.GetCaster
// Size: 0x8(Inherited: 0x0) 
struct FGetCaster
{
	struct AFirstPersonCharacter_C* caster;  // 0x0(0x8)

}; 
// Function BP_Effect.BP_Effect_C.GetParent
// Size: 0x8(Inherited: 0x0) 
struct FGetParent
{
	struct AFirstPersonCharacter_C* Parent;  // 0x0(0x8)

}; 
