#pragma once 
#include <C_PlayerCompass_Structs.h>
 
 
 
// BlueprintGeneratedClass C_PlayerCompass.C_PlayerCompass_C
// Size: 0x138(Inherited: 0xB0) 
struct UC_PlayerCompass_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct AFirstPersonCharacter_C* Owner;  // 0xB8(0x8)
	struct TArray<struct FVector> CurrentlyShowingLootSpots;  // 0xC0(0x10)
	struct TArray<struct FVector> CurrentlyShowingWorkbenches;  // 0xD0(0x10)
	int32_t ShowLimit;  // 0xE0(0x4)
	float MaxSenseDistance;  // 0xE4(0x4)
	struct TArray<struct UW_Compass_LootSpot_C*> LootSpotWidgets;  // 0xE8(0x10)
	struct TArray<struct UW_Compass_Workbench_C*> WorkbenchWidgets;  // 0xF8(0x10)
	struct UCanvasPanel* CompassBox;  // 0x108(0x8)
	float OpacityBoost;  // 0x110(0x4)
	float SizeBoost;  // 0x114(0x4)
	struct TArray<struct FVector> CurrentlyShowingTeammates;  // 0x118(0x10)
	struct TArray<struct UW_Compass_Teammate_C*> TeammateWidgets;  // 0x128(0x10)

	void IsBehind(struct FVector ObjectToCameraForward, struct FVector CameraForward, bool& Value); // Function C_PlayerCompass.C_PlayerCompass_C.IsBehind
	void Draw Focus PointsV2(struct TArray<struct FVector>& Positions, struct TArray<struct UWidget*>& CompassWidgets, float MaxSenseDistance, float OpacityBoost, float SizeBoost); // Function C_PlayerCompass.C_PlayerCompass_C.Draw Focus PointsV2
	void PopulateNearbyFocusPoints(); // Function C_PlayerCompass.C_PlayerCompass_C.PopulateNearbyFocusPoints
	void Draw Focus Points(struct TArray<struct FVector>& Positions, struct TArray<struct UWidget*>& CompassWidgets, float MaxSenseDistance, float OpacityBoost, float SizeBoost); // Function C_PlayerCompass.C_PlayerCompass_C.Draw Focus Points
	void GetCloseActors(float DistanceLimit, AActor* Class, struct TArray<struct AActor*>& Actors); // Function C_PlayerCompass.C_PlayerCompass_C.GetCloseActors
	void ReceiveBeginPlay(); // Function C_PlayerCompass.C_PlayerCompass_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function C_PlayerCompass.C_PlayerCompass_C.ReceiveTick
	void CreateInitialWidgets(); // Function C_PlayerCompass.C_PlayerCompass_C.CreateInitialWidgets
	void ExecuteUbergraph_C_PlayerCompass(int32_t EntryPoint); // Function C_PlayerCompass.C_PlayerCompass_C.ExecuteUbergraph_C_PlayerCompass
}; 



