#pragma once 
#include <DB_ItemCost_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DB_ItemCost.DB_ItemCost_C
// Size: 0x274(Inherited: 0x260) 
struct UDB_ItemCost_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UHorizontalBox* HorizontalBox_47;  // 0x268(0x8)
	int32_t ItemId;  // 0x270(0x4)

	void Construct(); // Function DB_ItemCost.DB_ItemCost_C.Construct
	void Start(); // Function DB_ItemCost.DB_ItemCost_C.Start
	void ExecuteUbergraph_DB_ItemCost(int32_t EntryPoint); // Function DB_ItemCost.DB_ItemCost_C.ExecuteUbergraph_DB_ItemCost
}; 



