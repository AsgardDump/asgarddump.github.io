#pragma once 
#include "SDK.h" 
 
 
// Function BlueprintSpawner.BlueprintSpawner_C.ExecuteUbergraph_BlueprintSpawner
// Size: 0x120(Inherited: 0x0) 
struct FExecuteUbergraph_BlueprintSpawner
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x8(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x14(0xC)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x20(0x1)
	char pad_33[15];  // 0x21(0xF)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x30(0x30)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x62(0x1)
	char pad_99[1];  // 0x63(0x1)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_SpawnRarety_RecipeID;  // 0x6C(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x70(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x7C(0x4)
	struct FVector CallFunc_K2_GetRandomPointInNavigableRadius_RandomLocation;  // 0x80(0xC)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_K2_GetRandomPointInNavigableRadius_ReturnValue : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x90(0xC)
	struct FVector K2Node_Select_Default;  // 0x9C(0xC)
	char pad_168[8];  // 0xA8(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0xB0(0x30)
	struct FTransform K2Node_Select_Default_2;  // 0xE0(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x110(0x8)
	struct ABP_Blueprint_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x118(0x8)

}; 
// Function BlueprintSpawner.BlueprintSpawner_C.UserConstructionScript
// Size: 0xA8(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct TArray<int32_t> CallFunc_Map_Keys_Keys;  // 0x0(0x10)
	int32_t CallFunc_Array_Get_Item;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x18(0x90)

}; 
// Function BlueprintSpawner.BlueprintSpawner_C.SpawnRarety
// Size: 0xBD(Inherited: 0x0) 
struct FSpawnRarety
{
	int32_t RecipeID;  // 0x0(0x4)
	char E_Tier Rarity;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TArray<char E_Tier> Types;  // 0x8(0x10)
	struct FST_ItemBase Item;  // 0x18(0x90)
	struct TArray<char E_Tier> K2Node_MakeArray_Array;  // 0xA8(0x10)
	int32_t CallFunc_GetRandomRecipeFromID_s_Value;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xBC(0x1)

}; 
// Function BlueprintSpawner.BlueprintSpawner_C.GetWeightMap
// Size: 0xCC(Inherited: 0x0) 
struct FGetWeightMap
{
	struct TArray<int32_t> RecipeID's;  // 0x0(0x10)
	struct TMap<int32_t, int32_t> Out1;  // 0x10(0x50)
	struct TMap<int32_t, int32_t> Out;  // 0x60(0x50)
	int32_t Temp_int_Variable;  // 0xB0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xB4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xB8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xBC(0x4)
	int32_t CallFunc_Array_Get_Item;  // 0xC0(0x4)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC8(0x4)

}; 
// Function BlueprintSpawner.BlueprintSpawner_C.GetRandomRecipeFromID's
// Size: 0x94(Inherited: 0x0) 
struct FGetRandomRecipeFromID's
{
	char E_Tier Rarity;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<int32_t> RecipeID's;  // 0x8(0x10)
	int32_t Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TMap<int32_t, int32_t> CallFunc_GetWeightMap_Out1;  // 0x20(0x50)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x70(0x10)
	struct FString CallFunc_AppendMultiple_ReturnValue;  // 0x80(0x10)
	int32_t CallFunc_GetDeckValue_Value;  // 0x90(0x4)

}; 
