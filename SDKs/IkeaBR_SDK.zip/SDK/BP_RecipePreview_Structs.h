#pragma once 
#include "SDK.h" 
 
 
// Function BP_RecipePreview.BP_RecipePreview_C.ExecuteUbergraph_BP_RecipePreview
// Size: 0x1A8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_RecipePreview
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)
	struct UStaticMesh* K2Node_CustomEvent_Mesh;  // 0x8(0x8)
	struct FBoxSphereBounds CallFunc_GetBounds_ReturnValue;  // 0x10(0x1C)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x30(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x34(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x4C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x58(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x64(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x68(0xC)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x74(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x80(0xC)
	struct FHitResult CallFunc_K2_AddRelativeRotation_SweepHitResult;  // 0x8C(0x88)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0x114(0xC)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x120(0x88)

}; 
// Function BP_RecipePreview.BP_RecipePreview_C.UpdateMesh
// Size: 0x8(Inherited: 0x0) 
struct FUpdateMesh
{
	struct UStaticMesh* Mesh;  // 0x0(0x8)

}; 
// Function BP_RecipePreview.BP_RecipePreview_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
