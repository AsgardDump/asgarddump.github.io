#pragma once 
#include <C_Weaponupgrade_Structs.h>
 
 
 
// BlueprintGeneratedClass C_Weaponupgrade.C_WeaponUpgrade_C
// Size: 0x108(Inherited: 0xF0) 
struct UC_WeaponUpgrade_C : public UC_Upgrade_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xF0(0x8)
	struct FMulticastInlineDelegate Attack;  // 0xF8(0x10)

	void ReceiveBeginPlay(); // Function C_Weaponupgrade.C_WeaponUpgrade_C.ReceiveBeginPlay
	void ExecuteUbergraph_C_WeaponUpgrade(int32_t EntryPoint); // Function C_Weaponupgrade.C_WeaponUpgrade_C.ExecuteUbergraph_C_WeaponUpgrade
	void Attack__DelegateSignature(struct AFirstPersonCharacter_C* Hit, float Damage); // Function C_Weaponupgrade.C_WeaponUpgrade_C.Attack__DelegateSignature
}; 



