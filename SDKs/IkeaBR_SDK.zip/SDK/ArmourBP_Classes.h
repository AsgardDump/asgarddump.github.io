#pragma once 
#include <ArmourBP_Structs.h>
 
 
 
// BlueprintGeneratedClass ArmourBP.ArmourBP_C
// Size: 0x281(Inherited: 0x268) 
struct AArmourBP_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	struct FST_Armour armour;  // 0x270(0x8)
	struct USkeletalMesh* ArmorMesh;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool Using : 1;  // 0x280(0x1)

	void Equip(); // Function ArmourBP.ArmourBP_C.Equip
	void Unequip(); // Function ArmourBP.ArmourBP_C.Unequip
	void Stop(); // Function ArmourBP.ArmourBP_C.Stop
	void LMB_Pure(bool Down); // Function ArmourBP.ArmourBP_C.LMB_Pure
	void ExecuteUbergraph_ArmourBP(int32_t EntryPoint); // Function ArmourBP.ArmourBP_C.ExecuteUbergraph_ArmourBP
}; 



