#pragma once 
#include "SDK.h" 
 
 
// Function ChampionModeIntro.ChampionModeIntro_C.ExecuteUbergraph_ChampionModeIntro
// Size: 0x10(Inherited: 0x0) 
struct FExecuteUbergraph_ChampionModeIntro
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x8(0x8)

}; 
