#pragma once 
#include <BP_MenuBackQueue_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_MenuBackQueue.BP_MenuBackQueue_C
// Size: 0x240(Inherited: 0x220) 
struct ABP_MenuBackQueue_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct TArray<struct UUserWidget*> WidgetStack;  // 0x230(0x10)

	void ForceKill(); // Function BP_MenuBackQueue.BP_MenuBackQueue_C.ForceKill
	void TryReturn(); // Function BP_MenuBackQueue.BP_MenuBackQueue_C.TryReturn
	void Register(struct UUserWidget* Widget); // Function BP_MenuBackQueue.BP_MenuBackQueue_C.Register
	void OnBack(); // Function BP_MenuBackQueue.BP_MenuBackQueue_C.OnBack
	void ExecuteUbergraph_BP_MenuBackQueue(int32_t EntryPoint); // Function BP_MenuBackQueue.BP_MenuBackQueue_C.ExecuteUbergraph_BP_MenuBackQueue
}; 



