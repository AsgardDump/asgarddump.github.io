#pragma once 
#include "SDK.h" 
 
 
// Function C_Weaponupgrade.C_WeaponUpgrade_C.Attack__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FAttack__DelegateSignature
{
	struct AFirstPersonCharacter_C* Hit;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function C_Weaponupgrade.C_WeaponUpgrade_C.ExecuteUbergraph_C_WeaponUpgrade
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_C_WeaponUpgrade
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
