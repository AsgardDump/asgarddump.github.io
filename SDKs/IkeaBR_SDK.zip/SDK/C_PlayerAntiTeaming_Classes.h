#pragma once 
#include <C_PlayerAntiTeaming_Structs.h>
 
 
 
// BlueprintGeneratedClass C_PlayerAntiTeaming.C_PlayerAntiTeaming_C
// Size: 0x118(Inherited: 0xB0) 
struct UC_PlayerAntiTeaming_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xB0(0x8)
	struct AFirstPersonCharacter_C* Owner;  // 0xB8(0x8)
	struct TArray<struct FST_TeamingStats> RemotePlayersMap;  // 0xC0(0x10)
	float ProximityDistance;  // 0xD0(0x4)
	float CriticalTimeSpentInProximity;  // 0xD4(0x4)
	float CriticalDistanceTravelledTogether;  // 0xD8(0x4)
	float InverseCriticalDamageDone;  // 0xDC(0x4)
	float BeingSteamFriendsScore;  // 0xE0(0x4)
	float CriticalTeamingScore;  // 0xE4(0x4)
	struct TArray<struct FST_TeamingStats> RemoteCriticalTeamers;  // 0xE8(0x10)
	struct FMulticastInlineDelegate OnNewRemoteTeamerDetected;  // 0xF8(0x10)
	struct TArray<struct FST_TeamingStats> Last_RemoteCriticalTeamers;  // 0x108(0x10)

	void Is Teamer Valid(struct AFirstPersonCharacter_C* Remote, bool& Valid); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.Is Teamer Valid
	void OnRep_RemoteCriticalTeamers(); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.OnRep_RemoteCriticalTeamers
	void ClientOnUpdatedRemoteCriticalTeamers(); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ClientOnUpdatedRemoteCriticalTeamers
	void GetProbabiltyOfTeaming(struct FST_TeamingStats TeamingStats, float& ProbabiltyScore); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.GetProbabiltyOfTeaming
	void FindRemotePlayerInMap(struct AFirstPersonCharacter_C* Player, int32_t& Index); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.FindRemotePlayerInMap
	void ReceiveBeginPlay(); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ReceiveTick
	void ServerGenTeamingStatsForPlayer(struct AFirstPersonCharacter_C* RemotePlayer); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerGenTeamingStatsForPlayer
	void OnDamageSomeone(struct AFirstPersonCharacter_C* DamagedTarget, float Damage); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.OnDamageSomeone
	void ServerOnDamageSomeone(struct AFirstPersonCharacter_C*& DamagedTarget, float& Damage); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerOnDamageSomeone
	void ServerGenTeamingStatsForRemotePlayers(); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerGenTeamingStatsForRemotePlayers
	void ServerUpdateRemoteCriticalTeamers(); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerUpdateRemoteCriticalTeamers
	void OnNewRemoteTeamerDetected_Event(struct FST_TeamingStats Teamer); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.OnNewRemoteTeamerDetected_Event
	void ServerUploadAsPossiblyTeaming(struct FString SteamID); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerUploadAsPossiblyTeaming
	void ExecuteUbergraph_C_PlayerAntiTeaming(int32_t EntryPoint); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ExecuteUbergraph_C_PlayerAntiTeaming
	void OnNewRemoteTeamerDetected__DelegateSignature(struct FST_TeamingStats Teamer); // Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.OnNewRemoteTeamerDetected__DelegateSignature
}; 



