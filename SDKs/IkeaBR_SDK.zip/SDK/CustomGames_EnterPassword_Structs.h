#pragma once 
#include "SDK.h" 
 
 
// Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.ExecuteUbergraph_CustomGames_EnterPassword
// Size: 0xB8(Inherited: 0x0) 
struct FExecuteUbergraph_CustomGames_EnterPassword
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct FText K2Node_ComponentBoundEvent_Text;  // 0x28(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x40(0x10)
	struct TArray<struct FSessionPropertyKeyPair> CallFunc_GetExtraSettings_ExtraSettings;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValidSession_ReturnValue : 1;  // 0x60(0x1)
	uint8_t  CallFunc_GetSessionPropertyString_SearchResult;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct FString CallFunc_GetSessionPropertyString_SettingValue;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR;  // 0x80(0x8)
	struct APlayerController* CallFunc_GetLocalPlayerController_Controller;  // 0x88(0x8)
	struct UJoinSessionCallbackProxy* CallFunc_JoinSession_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct TArray<struct ABP_MenuBackQueue_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0xA0(0x10)
	struct ABP_MenuBackQueue_C* CallFunc_Array_Get_Item;  // 0xB0(0x8)

}; 
// Function CustomGames_EnterPassword.CustomGames_EnterPassword_C.BndEvt__RR_TextBox_C_200_K2Node_ComponentBoundEvent_0_OnEditableTextBoxChangedEvent__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FBndEvt__RR_TextBox_C_200_K2Node_ComponentBoundEvent_0_OnEditableTextBoxChangedEvent__DelegateSignature
{
	struct FText Text;  // 0x0(0x18)

}; 
