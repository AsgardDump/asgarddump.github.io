#pragma once 
#include "SDK.h" 
 
 
// Function CraftingMenu2.CraftingMenu2_C.RecipeSelected
// Size: 0x28(Inherited: 0x0) 
struct FRecipeSelected
{
	struct FST_CraftRecipe Recipe;  // 0x0(0x28)

}; 
// Function CraftingMenu2.CraftingMenu2_C.ExecuteUbergraph_CraftingMenu2
// Size: 0x3F8(Inherited: 0x0) 
struct FExecuteUbergraph_CraftingMenu2
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x18(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x24(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x2C(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x30(0x38)
	float K2Node_Event_InDeltaTime;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x70(0x8)
	struct FST_CraftRecipe CallFunc_Array_Get_Item;  // 0x78(0x28)
	struct UCraftRecipe1_C* CallFunc_Create_ReturnValue;  // 0xA0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xAC(0x4)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0xB4(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0xB8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xBC(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xC0(0x4)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0xC4(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xCC(0x4)
	float CallFunc_VSize2D_ReturnValue;  // 0xD0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xD4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xD8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0xDC(0x4)
	float CallFunc_BreakVector2D_X;  // 0xE0(0x4)
	float CallFunc_BreakVector2D_Y;  // 0xE4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xE8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0xEC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0xF0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0xF4(0x4)
	float CallFunc_DegreesToRadians_ReturnValue;  // 0xF8(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xFC(0x4)
	float CallFunc_Sin_ReturnValue;  // 0x100(0x4)
	float CallFunc_Cos_ReturnValue;  // 0x104(0x4)
	struct UWidget* CallFunc_Array_Get_Item_2;  // 0x108(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x110(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x114(0x8)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x11C(0x1)
	char pad_285[3];  // 0x11D(0x3)
	float CallFunc_VSize2D_ReturnValue_2;  // 0x120(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_5;  // 0x124(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x128(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x130(0x4)
	float CallFunc_GetMousePosition_LocationX;  // 0x134(0x4)
	float CallFunc_GetMousePosition_LocationY;  // 0x138(0x4)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool CallFunc_GetMousePosition_ReturnValue : 1;  // 0x13C(0x1)
	char pad_317[3];  // 0x13D(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x140(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x144(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_5;  // 0x148(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_6;  // 0x14C(0x4)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue_2;  // 0x150(0x8)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_2;  // 0x158(0x8)
	float CallFunc_BreakVector2D_X_2;  // 0x160(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0x164(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_6;  // 0x168(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_7;  // 0x16C(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_3;  // 0x170(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x178(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_7;  // 0x17C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x180(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_8;  // 0x184(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x188(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x18C(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x190(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x194(0x4)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x198(0x8)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x1A0(0x4)
	char pad_420[4];  // 0x1A4(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1B0(0x1)
	char pad_433_1 : 7;  // 0x1B1(0x1)
	bool CallFunc_IsInViewport_ReturnValue : 1;  // 0x1B1(0x1)
	char pad_434_1 : 7;  // 0x1B2(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_4 : 1;  // 0x1B2(0x1)
	char pad_435[5];  // 0x1B3(0x5)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_2;  // 0x1B8(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x1C0(0x8)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1C8(0x1)
	char pad_457_1 : 7;  // 0x1C9(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1C9(0x1)
	char pad_458[6];  // 0x1CA(0x6)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue_3;  // 0x1D0(0x8)
	struct FST_CraftRecipe K2Node_CustomEvent_recipe;  // 0x1D8(0x28)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_3;  // 0x200(0x8)
	char pad_520_1 : 7;  // 0x208(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x208(0x1)
	char pad_521[7];  // 0x209(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x210(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x220(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x230(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_4;  // 0x240(0x10)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_4;  // 0x250(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x258(0x10)
	struct UMaterialCost_C* CallFunc_Create_ReturnValue_2;  // 0x268(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x270(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x280(0x10)
	int32_t CallFunc_GetStringHash_ReturnValue;  // 0x290(0x4)
	char pad_660[4];  // 0x294(0x4)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue;  // 0x298(0x8)
	struct UMaterialCost_C* CallFunc_Create_ReturnValue_3;  // 0x2A0(0x8)
	struct UMaterialCost_C* CallFunc_Create_ReturnValue_4;  // 0x2A8(0x8)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue_2;  // 0x2B0(0x8)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue_3;  // 0x2B8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x2C0(0x10)
	struct FST_CraftRecipe CallFunc_Array_Get_Item_3;  // 0x2D0(0x28)
	struct FString CallFunc_Conv_IntToString_ReturnValue_5;  // 0x2F8(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_6;  // 0x308(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_7;  // 0x318(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_8;  // 0x328(0x10)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_5;  // 0x338(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x340(0x10)
	float CallFunc_GetMousePosition_LocationX_2;  // 0x350(0x4)
	float CallFunc_GetMousePosition_LocationY_2;  // 0x354(0x4)
	char pad_856_1 : 7;  // 0x358(0x1)
	bool CallFunc_GetMousePosition_ReturnValue_2 : 1;  // 0x358(0x1)
	char pad_857[7];  // 0x359(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x360(0x10)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue_3;  // 0x370(0x8)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x378(0x10)
	float CallFunc_BreakVector2D_X_3;  // 0x388(0x4)
	float CallFunc_BreakVector2D_Y_3;  // 0x38C(0x4)
	int32_t CallFunc_GetStringHash_ReturnValue_2;  // 0x390(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_8;  // 0x394(0x4)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x398(0x1)
	char pad_921[3];  // 0x399(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue_4;  // 0x39C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_9;  // 0x3A0(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_5;  // 0x3A4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x3A8(0x4)
	float CallFunc_DegAtan2_ReturnValue;  // 0x3AC(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0x3B0(0x4)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue_4;  // 0x3B4(0x8)
	float CallFunc_BreakVector2D_X_4;  // 0x3BC(0x4)
	float CallFunc_BreakVector2D_Y_4;  // 0x3C0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_10;  // 0x3C4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x3C8(0x4)
	float CallFunc_FClamp_ReturnValue_3;  // 0x3CC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x3D0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x3D4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_11;  // 0x3D8(0x4)
	char pad_988_1 : 7;  // 0x3DC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x3DC(0x1)
	char pad_989[3];  // 0x3DD(0x3)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue_3;  // 0x3E0(0x8)
	char pad_1000_1 : 7;  // 0x3E8(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3E8(0x1)
	char pad_1001[7];  // 0x3E9(0x7)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_6;  // 0x3F0(0x8)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_1
// Size: 0x88(Inherited: 0x0) 
struct FGetColorAndOpacity_1
{
	struct FSlateColor ReturnValue;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x2C(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x3C(0x10)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x50(0x10)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x60(0x28)

}; 
// Function CraftingMenu2.CraftingMenu2_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetText_1
// Size: 0x70(Inherited: 0x0) 
struct FGetText_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x58(0x18)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetText_2
// Size: 0x70(Inherited: 0x0) 
struct FGetText_2
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x58(0x18)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetText_3
// Size: 0x70(Inherited: 0x0) 
struct FGetText_3
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x58(0x18)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_2
// Size: 0x88(Inherited: 0x0) 
struct FGetColorAndOpacity_2
{
	struct FSlateColor ReturnValue;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x2C(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x3C(0x10)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x50(0x10)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x60(0x28)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_3
// Size: 0x88(Inherited: 0x0) 
struct FGetColorAndOpacity_3
{
	struct FSlateColor ReturnValue;  // 0x0(0x28)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x2C(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x3C(0x10)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x50(0x10)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x60(0x28)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetText_4
// Size: 0xC0(Inherited: 0x0) 
struct FGetText_4
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x18(0x90)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xA8(0x18)

}; 
// Function CraftingMenu2.CraftingMenu2_C.sortRecipies
// Size: 0xB0(Inherited: 0x0) 
struct FsortRecipies
{
	struct TArray<struct FST_CraftRecipe> In;  // 0x0(0x10)
	struct TArray<struct FST_CraftRecipe> Out;  // 0x10(0x10)
	struct TArray<struct FST_CraftRecipe> Other;  // 0x20(0x10)
	struct TArray<struct FST_CraftRecipe> Available;  // 0x30(0x10)
	struct TArray<struct FST_CraftRecipe> HandCraft;  // 0x40(0x10)
	struct TArray<struct FST_CraftRecipe> WorkbenchR;  // 0x50(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x64(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FST_CraftRecipe CallFunc_Array_Get_Item;  // 0x70(0x28)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x9C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xA0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_CanCraft_Can_Craft : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0xAC(0x4)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetBrush_1
// Size: 0x1A0(Inherited: 0x0) 
struct FGetBrush_1
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x88(0x90)
	struct FSlateBrush CallFunc_MakeBrushFromTexture_ReturnValue;  // 0x118(0x88)

}; 
// Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_4
// Size: 0x48(Inherited: 0x0) 
struct FGetColorAndOpacity_4
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_CanCraft_Can_Craft : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x38(0x10)

}; 
