#pragma once 
#include <BP_DazGlobalIntercom_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DazGlobalIntercom.BP_DazGlobalIntercom_C
// Size: 0x2C8(Inherited: 0x220) 
struct ABP_DazGlobalIntercom_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UAudioComponent* Audio;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	struct TArray<struct USoundBase*> MatchStartVoicelines;  // 0x238(0x10)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool Talking : 1;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct TArray<struct USoundBase*> ZoneShrinkVoicelines;  // 0x250(0x10)
	struct TArray<struct USoundBase*> AirdropVoicelines;  // 0x260(0x10)
	float ChanceToSayPlayersRemainingVoiceline;  // 0x270(0x4)
	char pad_628[4];  // 0x274(0x4)
	struct TArray<struct USoundBase*> PlayersRemainingVoicelines_3;  // 0x278(0x10)
	struct TArray<struct USoundBase*> PlayersRemainingVoicelines_4;  // 0x288(0x10)
	struct TArray<struct USoundBase*> PlayersRemainingVoicelines_6;  // 0x298(0x10)
	struct TArray<struct USoundBase*> PlayersRemainingVoicelines_8;  // 0x2A8(0x10)
	struct TArray<struct USoundBase*> VictoryVoicelines;  // 0x2B8(0x10)

	void PlayMatchStartVoiceline(); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayMatchStartVoiceline
	void PlayRandomVoiceline(struct TArray<struct USoundBase*>& Sounds); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayRandomVoiceline
	void MultiPlaySound(struct USoundBase* Sound); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.MultiPlaySound
	void ReceiveTick(float DeltaSeconds); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.ReceiveTick
	void PlayZoneShrinkVoiceline(); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayZoneShrinkVoiceline
	void PlayAirdropVoiceline(); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayAirdropVoiceline
	void PlayRandomPlayersRemainingVoiceline(int32_t Num Players Left); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayRandomPlayersRemainingVoiceline
	void PlayVictoryVoiceline(); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.PlayVictoryVoiceline
	void ExecuteUbergraph_BP_DazGlobalIntercom(int32_t EntryPoint); // Function BP_DazGlobalIntercom.BP_DazGlobalIntercom_C.ExecuteUbergraph_BP_DazGlobalIntercom
}; 



