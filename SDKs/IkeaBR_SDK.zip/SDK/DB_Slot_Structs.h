#pragma once 
#include "SDK.h" 
 
 
// Function DB_Slot.DB_Slot_C.Get_Name1_Text_1
// Size: 0x18(Inherited: 0x0) 
struct FGet_Name1_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function DB_Slot.DB_Slot_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function DB_Slot.DB_Slot_C.ExecuteUbergraph_DB_Slot
// Size: 0x288(Inherited: 0x0) 
struct FExecuteUbergraph_DB_Slot
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FLinearColor CallFunc_TierColor_color;  // 0x4(0x10)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Variable : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct USaveGame* Temp_object_Variable;  // 0x18(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_3;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_CustomEvent_bSuccess_3 : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x2C(0x10)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct USaveGame* Temp_object_Variable_2;  // 0x40(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x54(0x10)
	char pad_100[4];  // 0x64(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_2;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_CustomEvent_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x71(0x1)
	char pad_114[6];  // 0x72(0x6)
	struct USaveGame* Temp_object_Variable_3;  // 0x78(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool K2Node_CustomEvent_bSuccess : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x8C(0x10)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	struct USaveGame* Temp_object_Variable_4;  // 0xA0(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_2;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0xB8(0x8)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0xC0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0xC8(0x10)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0xD8(0x10)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_2;  // 0xE8(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue;  // 0xF0(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_2;  // 0xF8(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x111(0x1)
	char pad_274_1 : 7;  // 0x112(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x112(0x1)
	char pad_275[5];  // 0x113(0x5)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_2;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_2 : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_2;  // 0x128(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_2;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x139(0x1)
	char pad_314[6];  // 0x13A(0x6)
	struct FST_CraftRecipe CallFunc_GetRecipeFromID_Recipe;  // 0x140(0x28)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x168(0x90)
	struct FLinearColor CallFunc_TierColor_color_2;  // 0x1F8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x208(0x18)
	struct USaveGame* K2Node_CustomEvent_SaveGame_4;  // 0x220(0x8)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool K2Node_CustomEvent_bSuccess_4 : 1;  // 0x228(0x1)
	char pad_553[3];  // 0x229(0x3)
	int32_t CallFunc_Array_Get_Item;  // 0x22C(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x230(0x38)
	float K2Node_Event_InDeltaTime;  // 0x268(0x4)
	char pad_620_1 : 7;  // 0x26C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x26C(0x1)
	char pad_621_1 : 7;  // 0x26D(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x26D(0x1)
	char pad_622[2];  // 0x26E(0x2)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x270(0x18)

}; 
// Function DB_Slot.DB_Slot_C.Completed_6F07F8864F50B817CAEDB38570C2733A
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB38570C2733A
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Slot.DB_Slot_C.Completed_6F07F8864F50B817CAEDB3855D4EDA25
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB3855D4EDA25
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Slot.DB_Slot_C.Completed_215CB37D43646A0095BC739762DA1B76
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC739762DA1B76
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Slot.DB_Slot_C.Completed_215CB37D43646A0095BC73974F56B269
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73974F56B269
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
