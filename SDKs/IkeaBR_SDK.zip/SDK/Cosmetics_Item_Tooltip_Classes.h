#pragma once 
#include <Cosmetics_Item_Tooltip_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C
// Size: 0x2D0(Inherited: 0x260) 
struct UCosmetics_Item_Tooltip_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct URR_Text_C* CosmeticName;  // 0x268(0x8)
	struct UImage* Image_46;  // 0x270(0x8)
	struct URR_Text_C* ScrapText;  // 0x278(0x8)
	struct FST_Cosmetic CosmeticInfo;  // 0x280(0x50)

	struct FText Get_ScrapText_Text_1(); // Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.Get_ScrapText_Text_1
	struct FSlateColor Get_CosmeticName_ColorAndOpacity_1(); // Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.Get_CosmeticName_ColorAndOpacity_1
	struct FText Get_CosmeticName_Text_1(); // Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.Get_CosmeticName_Text_1
	void ExecuteUbergraph_Cosmetics_Item_Tooltip(int32_t EntryPoint); // Function Cosmetics_Item_Tooltip.Cosmetics_Item_Tooltip_C.ExecuteUbergraph_Cosmetics_Item_Tooltip
}; 



