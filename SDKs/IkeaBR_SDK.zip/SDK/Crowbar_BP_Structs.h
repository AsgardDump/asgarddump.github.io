#pragma once 
#include "SDK.h" 
 
 
// Function Crowbar_BP.Crowbar_BP_C.ExecuteUbergraph_Crowbar_BP
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_Crowbar_BP
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
