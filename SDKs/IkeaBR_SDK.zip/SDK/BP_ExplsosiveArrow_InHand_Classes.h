#pragma once 
#include <BP_ExplsosiveArrow_InHand_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ExplsosiveArrow_InHand.BP_ExplsosiveArrow_InHand_C
// Size: 0x268(Inherited: 0x268) 
struct ABP_ExplsosiveArrow_InHand_C : public AItemBP_C
{

}; 



