#pragma once 
#include <DB_Slot_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DB_Slot.DB_Slot_C
// Size: 0x2A4(Inherited: 0x260) 
struct UDB_Slot_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UImage* Image_168;  // 0x268(0x8)
	struct UImage* Legendary;  // 0x270(0x8)
	struct URR_Text_C* Name1;  // 0x278(0x8)
	struct URR_Border_Plain_C* RR_Border_Plain_C_2;  // 0x280(0x8)
	struct URR_Button_C* RR_Button_C_3;  // 0x288(0x8)
	struct USizeBox* SizeBox_4;  // 0x290(0x8)
	struct UDefaultBlueprints_C* Parent;  // 0x298(0x8)
	int32_t MySlot;  // 0x2A0(0x4)

	struct FText Get_Name1_Text_1(); // Function DB_Slot.DB_Slot_C.Get_Name1_Text_1
	void Completed_215CB37D43646A0095BC73974F56B269(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Slot.DB_Slot_C.Completed_215CB37D43646A0095BC73974F56B269
	void Completed_6F07F8864F50B817CAEDB38570C2733A(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Slot.DB_Slot_C.Completed_6F07F8864F50B817CAEDB38570C2733A
	void Completed_215CB37D43646A0095BC739762DA1B76(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Slot.DB_Slot_C.Completed_215CB37D43646A0095BC739762DA1B76
	void Completed_6F07F8864F50B817CAEDB3855D4EDA25(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Slot.DB_Slot_C.Completed_6F07F8864F50B817CAEDB3855D4EDA25
	void UpdateSelection(); // Function DB_Slot.DB_Slot_C.UpdateSelection
	void Construct(); // Function DB_Slot.DB_Slot_C.Construct
	void BndEvt__RR_Button_C_2_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DB_Slot.DB_Slot_C.BndEvt__RR_Button_C_2_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__RR_Button_C_2_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function DB_Slot.DB_Slot_C.BndEvt__RR_Button_C_2_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function DB_Slot.DB_Slot_C.Tick
	void ExecuteUbergraph_DB_Slot(int32_t EntryPoint); // Function DB_Slot.DB_Slot_C.ExecuteUbergraph_DB_Slot
}; 



