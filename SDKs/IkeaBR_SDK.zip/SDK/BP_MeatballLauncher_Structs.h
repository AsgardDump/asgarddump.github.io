#pragma once 
#include "SDK.h" 
 
 
// Function BP_MeatballLauncher.BP_MeatballLauncher_C.ExecuteUbergraph_BP_MeatballLauncher
// Size: 0xC0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_MeatballLauncher
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool K2Node_Event_Down : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xC(0xC)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x18(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x20(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x28(0xC)
	char pad_52[4];  // 0x34(0x4)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_3;  // 0x44(0xC)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x50(0x8)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x58(0x10)
	float CallFunc_PlaySlotAnimation_ReturnValue;  // 0x68(0x4)
	struct FRotator CallFunc_MakeShootTransform_Rotation;  // 0x6C(0xC)
	struct FVector CallFunc_MakeShootTransform_Location;  // 0x78(0xC)
	char pad_132[12];  // 0x84(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x90(0x30)

}; 
// Function BP_MeatballLauncher.BP_MeatballLauncher_C.LMB
// Size: 0x1(Inherited: 0x1) 
struct FLMB : public FLMB
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
