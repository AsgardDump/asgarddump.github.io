#pragma once 
#include <DB_RandomRecipe_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DB_RandomRecipe.DB_RandomRecipe_C
// Size: 0x28C(Inherited: 0x260) 
struct UDB_RandomRecipe_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UImage* Image_102;  // 0x268(0x8)
	struct URR_Border_Plain_C* RR_Border_Plain_C_2;  // 0x270(0x8)
	struct URR_Button_C* RR_Button_C_2;  // 0x278(0x8)
	struct UDefaultBlueprints_C* Parent;  // 0x280(0x8)
	int32_t Index;  // 0x288(0x4)

	void BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DB_RandomRecipe.DB_RandomRecipe_C.BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function DB_RandomRecipe.DB_RandomRecipe_C.BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	void ExecuteUbergraph_DB_RandomRecipe(int32_t EntryPoint); // Function DB_RandomRecipe.DB_RandomRecipe_C.ExecuteUbergraph_DB_RandomRecipe
}; 



