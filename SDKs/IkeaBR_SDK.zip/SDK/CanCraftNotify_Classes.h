#pragma once 
#include <CanCraftNotify_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CanCraftNotify.CanCraftNotify_C
// Size: 0x2A9(Inherited: 0x260) 
struct UCanCraftNotify_C : public UUserWidget
{
	struct UWidgetAnimation* Start;  // 0x260(0x8)
	struct UImage* Image_144;  // 0x268(0x8)
	struct URR_ProgressBar_Plain_C* RR_ProgressBar_Plain_C_93;  // 0x270(0x8)
	int32_t ID;  // 0x278(0x4)
	char pad_636[4];  // 0x27C(0x4)
	struct FST_CraftRecipe Recipe;  // 0x280(0x28)
	char pad_680_1 : 7;  // 0x2A8(0x1)
	bool CanCraft : 1;  // 0x2A8(0x1)

	struct FLinearColor GetFillColorAndOpacity_1(); // Function CanCraftNotify.CanCraftNotify_C.GetFillColorAndOpacity_1
	float GetPercent_1(); // Function CanCraftNotify.CanCraftNotify_C.GetPercent_1
	struct FSlateBrush GetBrush_1(); // Function CanCraftNotify.CanCraftNotify_C.GetBrush_1
	struct FLinearColor GetBrushColor_1(); // Function CanCraftNotify.CanCraftNotify_C.GetBrushColor_1
}; 



