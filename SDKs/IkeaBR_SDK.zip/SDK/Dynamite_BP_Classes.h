#pragma once 
#include <Dynamite_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Dynamite_BP.Dynamite_BP_C
// Size: 0x284(Inherited: 0x268) 
struct ADynamite_BP_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool Held : 1;  // 0x278(0x1)
	char pad_633[3];  // 0x279(0x3)
	float Time;  // 0x27C(0x4)
	float TimeToFuse;  // 0x280(0x4)

	void LMB(bool Down); // Function Dynamite_BP.Dynamite_BP_C.LMB
	void Equip(); // Function Dynamite_BP.Dynamite_BP_C.Equip
	void ReceiveBeginPlay(); // Function Dynamite_BP.Dynamite_BP_C.ReceiveBeginPlay
	void Unequip(); // Function Dynamite_BP.Dynamite_BP_C.Unequip
	void ExecuteUbergraph_Dynamite_BP(int32_t EntryPoint); // Function Dynamite_BP.Dynamite_BP_C.ExecuteUbergraph_Dynamite_BP
}; 



