#pragma once 
#include "SDK.h" 
 
 
// Function BP_Projectile.BP_Projectile_C.ExecuteUbergraph_BP_Projectile
// Size: 0x3A0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Projectile
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x18(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x2C(0x4)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0x30(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x3C(0x4)
	struct FHitResult K2Node_ComponentBoundEvent_ImpactResult;  // 0x40(0x88)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xC8(0x4)
	char pad_204_1 : 7;  // 0xCC(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0xCC(0x1)
	char pad_205[3];  // 0xCD(0x3)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0xD0(0x4)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0xD4(0xC)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0xE0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xE8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xF0(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0xF8(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0x104(0x88)
	char pad_396[4];  // 0x18C(0x4)
	struct APawn* CallFunc_GetInstigator_ReturnValue_2;  // 0x190(0x8)
	struct AActor* K2Node_CustomEvent_other_actor;  // 0x198(0x8)
	struct FHitResult K2Node_CustomEvent_HitResult;  // 0x1A0(0x88)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x228(0x1)
	char pad_553_1 : 7;  // 0x229(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x229(0x1)
	char pad_554[2];  // 0x22A(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x22C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x230(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x234(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x240(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x24C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x258(0xC)
	char pad_612[4];  // 0x264(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x268(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x270(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x278(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x280(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x288(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x28C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x290(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x294(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x2A0(0xC)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_2 : 1;  // 0x2AC(0x1)
	char pad_685_1 : 7;  // 0x2AD(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_2 : 1;  // 0x2AD(0x1)
	char pad_686[2];  // 0x2AE(0x2)
	float CallFunc_BreakHitResult_Time_2;  // 0x2B0(0x4)
	float CallFunc_BreakHitResult_Distance_2;  // 0x2B4(0x4)
	struct FVector CallFunc_BreakHitResult_Location_2;  // 0x2B8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_2;  // 0x2C4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_2;  // 0x2D0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_2;  // 0x2DC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_2;  // 0x2E8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_2;  // 0x2F0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_2;  // 0x2F8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_2;  // 0x300(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_2;  // 0x308(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_2;  // 0x30C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_2;  // 0x310(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_2;  // 0x314(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_2;  // 0x320(0xC)
	char ECollisionChannel CallFunc_GetCollisionObjectType_ReturnValue;  // 0x32C(0x1)
	char pad_813_1 : 7;  // 0x32D(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x32D(0x1)
	char pad_814_1 : 7;  // 0x32E(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x32E(0x1)
	char pad_815[1];  // 0x32F(0x1)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x330(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_3;  // 0x338(0x8)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x340(0x1)
	char pad_833[7];  // 0x341(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x348(0x8)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated;  // 0x350(0x8)
	char pad_856_1 : 7;  // 0x358(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x358(0x1)
	char pad_857_1 : 7;  // 0x359(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x359(0x1)
	char pad_858[6];  // 0x35A(0x6)
	struct APawn* CallFunc_GetInstigator_ReturnValue_3;  // 0x360(0x8)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x368(0x1)
	char pad_873[7];  // 0x369(0x7)
	struct APawn* CallFunc_GetInstigator_ReturnValue_4;  // 0x370(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_4;  // 0x378(0x8)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x380(0x1)
	char pad_897[7];  // 0x381(0x7)
	struct APawn* CallFunc_GetInstigator_ReturnValue_5;  // 0x388(0x8)
	float Temp_float_Variable;  // 0x390(0x4)
	char pad_916_1 : 7;  // 0x394(0x1)
	bool Temp_bool_Variable : 1;  // 0x394(0x1)
	char pad_917[3];  // 0x395(0x3)
	float K2Node_Select_Default;  // 0x398(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x39C(0x4)

}; 
// Function BP_Projectile.BP_Projectile_C.Hit
// Size: 0x90(Inherited: 0x0) 
struct FHit
{
	struct AActor* other actor;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x88)

}; 
// Function BP_Projectile.BP_Projectile_C.BndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FBndEvt__ProjectileMovement_K2Node_ComponentBoundEvent_0_OnProjectileStopDelegate__DelegateSignature
{
	struct FHitResult ImpactResult;  // 0x0(0x88)

}; 
// Function BP_Projectile.BP_Projectile_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__Capsule_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_Projectile.BP_Projectile_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Projectile.BP_Projectile_C.Stop
// Size: 0x88(Inherited: 0x0) 
struct FStop
{
	struct FHitResult HitResult;  // 0x0(0x88)

}; 
