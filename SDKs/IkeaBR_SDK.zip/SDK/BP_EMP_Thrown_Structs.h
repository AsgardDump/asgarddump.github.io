#pragma once 
#include "SDK.h" 
 
 
// Function BP_EMP_Thrown.BP_EMP_Thrown_C.ExecuteUbergraph_BP_EMP_Thrown
// Size: 0x194(Inherited: 0x0) 
struct FExecuteUbergraph_BP_EMP_Thrown
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x8(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1C(0xC)
	float CallFunc_BreakVector_X;  // 0x28(0x4)
	float CallFunc_BreakVector_Y;  // 0x2C(0x4)
	float CallFunc_BreakVector_Z;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct AActor* K2Node_Event_other_actor;  // 0x38(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0x40(0x88)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0xC8(0xC)
	char pad_212_1 : 7;  // 0xD4(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xD4(0x1)
	char pad_213_1 : 7;  // 0xD5(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xD5(0x1)
	char pad_214[2];  // 0xD6(0x2)
	float CallFunc_BreakHitResult_Time;  // 0xD8(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xDC(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xE0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xEC(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xF8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x104(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x110(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x118(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x120(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x128(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x130(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x134(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x138(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x13C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x148(0xC)
	char pad_340[12];  // 0x154(0xC)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue;  // 0x160(0x30)
	char ECollisionChannel CallFunc_GetCollisionObjectType_ReturnValue;  // 0x190(0x1)
	char pad_401_1 : 7;  // 0x191(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x191(0x1)
	char pad_402_1 : 7;  // 0x192(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x192(0x1)
	char pad_403_1 : 7;  // 0x193(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x193(0x1)

}; 
// Function BP_EMP_Thrown.BP_EMP_Thrown_C.Hit
// Size: 0x90(Inherited: 0x90) 
struct FHit : public FHit
{
	struct AActor* other actor;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x88)

}; 
