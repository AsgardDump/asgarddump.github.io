#pragma once 
#include <BP_Bow_Base_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Bow_Base.BP_Bow_Base_C
// Size: 0x2CD(Inherited: 0x2A0) 
struct ABP_Bow_Base_C : public ABP_Throwable_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A0(0x8)
	struct USceneComponent* Scene1;  // 0x2A8(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x2B0(0x8)
	struct UchargeBar_C* ChargeWidget;  // 0x2B8(0x8)
	struct FDateTime ChargeTime;  // 0x2C0(0x8)
	float CurrentDelay;  // 0x2C8(0x4)
	char pad_716_1 : 7;  // 0x2CC(0x1)
	bool LMBD : 1;  // 0x2CC(0x1)

	void LMB(bool Down); // Function BP_Bow_Base.BP_Bow_Base_C.LMB
	void SpawnProjectile(struct FTransform SpawnTransform); // Function BP_Bow_Base.BP_Bow_Base_C.SpawnProjectile
	void Unequip(); // Function BP_Bow_Base.BP_Bow_Base_C.Unequip
	void ReceiveTick(float DeltaSeconds); // Function BP_Bow_Base.BP_Bow_Base_C.ReceiveTick
	void MouseCheckTick(); // Function BP_Bow_Base.BP_Bow_Base_C.MouseCheckTick
	void Cancel(); // Function BP_Bow_Base.BP_Bow_Base_C.Cancel
	void ExecuteUbergraph_BP_Bow_Base(int32_t EntryPoint); // Function BP_Bow_Base.BP_Bow_Base_C.ExecuteUbergraph_BP_Bow_Base
}; 



