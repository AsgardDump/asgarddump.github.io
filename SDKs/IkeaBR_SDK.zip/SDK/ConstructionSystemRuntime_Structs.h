#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ConstructionSystemRuntime.ConstructionSystemSavePlayerInfo
// Size: 0x50(Inherited: 0x0) 
struct FConstructionSystemSavePlayerInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRestorePlayerInfo : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FTransform Transform;  // 0x10(0x30)
	struct FRotator ControlRotation;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemBuildUI.SetConstructionSystem
// Size: 0x8(Inherited: 0x0) 
struct FSetConstructionSystem
{
	struct UConstructionSystemComponent* ConstructionSystem;  // 0x0(0x8)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemSaveSystem.HandleConstructionSystemLevelLoad
// Size: 0x8(Inherited: 0x0) 
struct FHandleConstructionSystemLevelLoad
{
	struct UObject* worldContextObject;  // 0x0(0x8)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemBuildTool.SetActivePrefab
// Size: 0x8(Inherited: 0x0) 
struct FSetActivePrefab
{
	struct UPrefabricatorAssetInterface* InActivePrefabAsset;  // 0x0(0x8)

}; 
// ScriptStruct ConstructionSystemRuntime.ConstructionSystemUIPrefabEntry
// Size: 0x40(Inherited: 0x0) 
struct FConstructionSystemUIPrefabEntry
{
	struct FText DisplayName;  // 0x0(0x18)
	struct FText Tooltip;  // 0x18(0x18)
	struct UTexture2D* Icon;  // 0x30(0x8)
	struct UPrefabricatorAssetInterface* Prefab;  // 0x38(0x8)

}; 
// ScriptStruct ConstructionSystemRuntime.PCSnapConstraintFloor
// Size: 0x6(Inherited: 0x0) 
struct FPCSnapConstraintFloor
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool AttachX : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool AttachXNegative : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool AttachY : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool AttachYNegative : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool AttachZ : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool AttachZNegative : 1;  // 0x5(0x1)

}; 
// ScriptStruct ConstructionSystemRuntime.PCSnapConstraintWall
// Size: 0x4(Inherited: 0x0) 
struct FPCSnapConstraintWall
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool AttachTop : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool AttachBottom : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool AttachLeft : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool AttachRight : 1;  // 0x3(0x1)

}; 
// ScriptStruct ConstructionSystemRuntime.ConstructionSystemSaveConstructedItem
// Size: 0x40(Inherited: 0x0) 
struct FConstructionSystemSaveConstructedItem
{
	struct UPrefabricatorAssetInterface* PrefabAsset;  // 0x0(0x8)
	int32_t Seed;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FTransform Transform;  // 0x10(0x30)

}; 
// ScriptStruct ConstructionSystemRuntime.ConstructionSystemUICategory
// Size: 0x30(Inherited: 0x0) 
struct FConstructionSystemUICategory
{
	struct FText DisplayName;  // 0x0(0x18)
	struct UTexture2D* Icon;  // 0x18(0x8)
	struct TArray<struct FConstructionSystemUIPrefabEntry> PrefabEntries;  // 0x20(0x10)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemBuildTool.HandleInput_RotateCursorStep
// Size: 0x4(Inherited: 0x0) 
struct FHandleInput_RotateCursorStep
{
	float NumSteps;  // 0x0(0x4)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemComponent.EnableConstructionSystem
// Size: 0x1(Inherited: 0x0) 
struct FEnableConstructionSystem
{
	uint8_t  InToolType;  // 0x0(0x1)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemComponent.GetActiveTool
// Size: 0x8(Inherited: 0x0) 
struct FGetActiveTool
{
	struct UConstructionSystemTool* ReturnValue;  // 0x0(0x8)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemComponent.GetActiveToolType
// Size: 0x1(Inherited: 0x0) 
struct FGetActiveToolType
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemComponent.GetTool
// Size: 0x10(Inherited: 0x0) 
struct FGetTool
{
	uint8_t  InToolType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UConstructionSystemTool* ReturnValue;  // 0x8(0x8)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemComponent.SetActiveTool
// Size: 0x1(Inherited: 0x0) 
struct FSetActiveTool
{
	uint8_t  InToolType;  // 0x0(0x1)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemSaveSystem.LoadConstructionSystemLevel
// Size: 0x30(Inherited: 0x0) 
struct FLoadConstructionSystemLevel
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FName LevelName;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bAbsolute : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString SaveSlotName;  // 0x18(0x10)
	int32_t UserIndex;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemSaveSystem.SaveConstructionSystemLevel
// Size: 0x20(Inherited: 0x0) 
struct FSaveConstructionSystemLevel
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString SaveSlotName;  // 0x8(0x10)
	int32_t UserIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bSavePlayerState : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function ConstructionSystemRuntime.ConstructionSystemBuildUI.SetUIAsset
// Size: 0x8(Inherited: 0x0) 
struct FSetUIAsset
{
	struct UConstructionSystemUIAsset* UIAsset;  // 0x0(0x8)

}; 
