#pragma once 
#include <EOSCoreUtilities_Structs.h>
 
 
 
// Class EOSCoreUtilities.EOSCoreUtilitiesLibrary
// Size: 0x28(Inherited: 0x28) 
struct UEOSCoreUtilitiesLibrary : public UBlueprintFunctionLibrary
{

	void RequestEncryptedAppTicket(struct FDelegate& Callback); // Function EOSCoreUtilities.EOSCoreUtilitiesLibrary.RequestEncryptedAppTicket
}; 



// Class EOSCoreUtilities.TestClass
// Size: 0x28(Inherited: 0x28) 
struct UTestClass : public UObject
{

}; 



// Class EOSCoreUtilities.EmptyClass
// Size: 0x28(Inherited: 0x28) 
struct UEmptyClass : public UObject
{

}; 



