#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Drain.BP_Effect_Drain_C.ExecuteUbergraph_BP_Effect_Drain
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Drain
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)

}; 
