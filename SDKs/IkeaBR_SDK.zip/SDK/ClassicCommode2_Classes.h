#pragma once 
#include <ClassicCommode2_Structs.h>
 
 
 
// BlueprintGeneratedClass ClassicCommode2.ClassicCommode2_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AClassicCommode2_C : public AMovable_Object_Replicated_C
{

}; 



