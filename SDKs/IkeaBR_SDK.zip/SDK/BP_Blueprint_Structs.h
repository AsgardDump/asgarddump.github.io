#pragma once 
#include "SDK.h" 
 
 
// Function BP_Blueprint.BP_Blueprint_C.ExecuteUbergraph_BP_Blueprint
// Size: 0x1B9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Blueprint
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x8(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x10(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0xB0(0x8)
	struct FST_CraftRecipe CallFunc_GetRecipeFromID_Recipe;  // 0xB8(0x28)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0xE0(0x4)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	struct FST_CraftRecipe CallFunc_GetRecipeFromID_Recipe_2;  // 0xE8(0x28)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x110(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x120(0x8)
	struct FST_ItemBase CallFunc_GetDataTableRowFromName_OutRow;  // 0x128(0x90)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x1B8(0x1)

}; 
// Function BP_Blueprint.BP_Blueprint_C.OnInteract
// Size: 0x94(Inherited: 0x94) 
struct FOnInteract : public FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
// Function BP_Blueprint.BP_Blueprint_C.ToolTipOnLook
// Size: 0x169(Inherited: 0x48) 
struct FToolTipOnLook : public FToolTipOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FString tool tip;  // 0x8(0x10)
	struct FString sub tip;  // 0x18(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Found? : 1;  // 0x28(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x29(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	char pad_118_1 : 7;  // 0x76(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x30(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	struct FST_CraftRecipe CallFunc_Array_Get_Item;  // 0x40(0x28)
	char pad_167_1 : 7;  // 0xA7(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)
	int32_t CallFunc_FindRecipeIDFromResultingItem_Recipe_ID;  // 0x6C(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x70(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x74(0x4)
	struct FString CallFunc_ReplaceInputsInText_OutText;  // 0x78(0x10)
	struct FString CallFunc_ReplaceInputsInText_OutText_2;  // 0x88(0x10)
	struct FST_CraftRecipe CallFunc_GetRecipeFromID_Recipe;  // 0x98(0x28)
	char pad_249_1 : 7;  // 0xF9(0x1)
	bool Temp_bool_Variable : 1;  // 0xC0(0x1)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0xC8(0x90)
	struct FString K2Node_Select_Default;  // 0x158(0x10)
	char pad_410_1 : 7;  // 0x19A(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x168(0x1)

}; 
