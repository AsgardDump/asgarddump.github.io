#pragma once 
#include <Carpet_02_Structs.h>
 
 
 
// BlueprintGeneratedClass Carpet_02.Carpet_02_C
// Size: 0x230(Inherited: 0x220) 
struct ACarpet_02_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)

}; 



