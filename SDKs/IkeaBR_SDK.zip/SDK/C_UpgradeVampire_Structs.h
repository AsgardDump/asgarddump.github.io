#pragma once 
#include "SDK.h" 
 
 
// Function C_UpgradeVampire.C_UpgradeVampire_C.ExecuteUbergraph_C_UpgradeVampire
// Size: 0x54(Inherited: 0x0) 
struct FExecuteUbergraph_C_UpgradeVampire
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	float K2Node_Event_DeltaSeconds;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Hit;  // 0x20(0x8)
	float K2Node_CustomEvent_Damage;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct TArray<struct UC_Upgrade_C*> CallFunc_GetUpgradesByName_Upgrades;  // 0x30(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x44(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x50(0x4)

}; 
// Function C_UpgradeVampire.C_UpgradeVampire_C.Attack_Event
// Size: 0xC(Inherited: 0x0) 
struct FAttack_Event
{
	struct AFirstPersonCharacter_C* Hit;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function C_UpgradeVampire.C_UpgradeVampire_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
