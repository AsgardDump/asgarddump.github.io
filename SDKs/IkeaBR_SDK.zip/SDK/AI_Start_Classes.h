#pragma once 
#include <AI_Start_Structs.h>
 
 
 
// BlueprintGeneratedClass AI_Start.AI_Start_C
// Size: 0x258(Inherited: 0x250) 
struct AAI_Start_C : public APlayerStart
{
	struct UBoxComponent* Collider;  // 0x250(0x8)

}; 



