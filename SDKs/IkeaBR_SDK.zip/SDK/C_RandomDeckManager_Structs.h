#pragma once 
#include "SDK.h" 
 
 
// Function C_RandomDeckManager.C_RandomDeckManager_C.GetDeckValue
// Size: 0x231(Inherited: 0x0) 
struct FGetDeckValue
{
	struct FString DeckName;  // 0x0(0x10)
	struct TMap<int32_t, int32_t> ValueWeightMap;  // 0x10(0x50)
	int32_t Value;  // 0x60(0x4)
	int32_t OutputValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool found : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_GetDeckValue_Value;  // 0x6C(0x4)
	struct TArray<int32_t> CallFunc_GenDeck_Deck;  // 0x70(0x10)
	struct FST_RandomDeck K2Node_MakeStruct_ST_RandomDeck;  // 0x80(0x78)
	int32_t CallFunc_GetDeckValue_Value_2;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0xFC(0x1)
	char pad_253_1 : 7;  // 0xFD(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xFD(0x1)
	char pad_254[2];  // 0xFE(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x100(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x104(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x108(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x10C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x110(0x4)
	char pad_276[4];  // 0x114(0x4)
	struct FST_RandomDeck CallFunc_Array_Get_Item;  // 0x118(0x78)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x190(0x1)
	char pad_401_1 : 7;  // 0x191(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x191(0x1)
	char pad_402[2];  // 0x192(0x2)
	int32_t CallFunc_Array_Get_Item_2;  // 0x194(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x198(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x19C(0x4)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x1A0(0x1)
	char pad_417[7];  // 0x1A1(0x7)
	struct TArray<int32_t> CallFunc_GenDeck_Deck_2;  // 0x1A8(0x10)
	struct FST_RandomDeck K2Node_MakeStruct_ST_RandomDeck_2;  // 0x1B8(0x78)
	char pad_560_1 : 7;  // 0x230(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x230(0x1)

}; 
// Function C_RandomDeckManager.C_RandomDeckManager_C.GenDeck
// Size: 0x70(Inherited: 0x0) 
struct FGenDeck
{
	struct TMap<int32_t, int32_t> ValueWeightMap;  // 0x0(0x50)
	struct TArray<int32_t> Deck;  // 0x50(0x10)
	struct TArray<int32_t> CallFunc_GenRandomDeck_Deck;  // 0x60(0x10)

}; 
