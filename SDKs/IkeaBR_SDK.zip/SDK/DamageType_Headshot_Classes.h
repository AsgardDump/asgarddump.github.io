#pragma once 
#include <DamageType_Headshot_Structs.h>
 
 
 
// BlueprintGeneratedClass DamageType_Headshot.DamageType_Headshot_C
// Size: 0x40(Inherited: 0x40) 
struct UDamageType_Headshot_C : public UDamageType
{

}; 



