#pragma once 
#include <BetterMoveTo_Structs.h>
 
 
 
// BlueprintGeneratedClass BetterMoveTo.BetterMoveTo_C
// Size: 0xD8(Inherited: 0xA8) 
struct UBetterMoveTo_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector Location;  // 0xB0(0x28)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function BetterMoveTo.BetterMoveTo_C.ReceiveExecuteAI
	void ExecuteUbergraph_BetterMoveTo(int32_t EntryPoint); // Function BetterMoveTo.BetterMoveTo_C.ExecuteUbergraph_BetterMoveTo
}; 



