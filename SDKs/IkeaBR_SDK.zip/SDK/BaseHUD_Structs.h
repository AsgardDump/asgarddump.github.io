#pragma once 
#include "SDK.h" 
 
 
// Function BaseHUD.BaseHUD_C.Alert
// Size: 0x28(Inherited: 0x0) 
struct FAlert
{
	struct FText InText;  // 0x0(0x18)
	struct FLinearColor Specified Color;  // 0x18(0x10)

}; 
// Function BaseHUD.BaseHUD_C.PropNotify
// Size: 0x1(Inherited: 0x0) 
struct FPropNotify
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool pickup? : 1;  // 0x0(0x1)

}; 
// Function BaseHUD.BaseHUD_C.OnDiscoverNewRecipe
// Size: 0x4(Inherited: 0x0) 
struct FOnDiscoverNewRecipe
{
	int32_t RecipeID;  // 0x0(0x4)

}; 
// Function BaseHUD.BaseHUD_C.VisibleIfRanged
// Size: 0x9(Inherited: 0x0) 
struct FVisibleIfRanged
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x7(0x1)
	uint8_t  K2Node_Select_Default;  // 0x8(0x1)

}; 
// Function BaseHUD.BaseHUD_C.ExecuteUbergraph_BaseHUD
// Size: 0x3B0(Inherited: 0x0) 
struct FExecuteUbergraph_BaseHUD
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x8(0x8)
	struct UW_NewBlueprintNotify_C* CallFunc_Create_ReturnValue;  // 0x10(0x8)
	uint8_t  Temp_byte_Variable;  // 0x18(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_Variable : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	uint8_t  Temp_byte_Variable_3;  // 0x2C(0x1)
	uint8_t  Temp_byte_Variable_4;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x2E(0x1)
	uint8_t  Temp_byte_Variable_5;  // 0x2F(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FText K2Node_CustomEvent_InText_2;  // 0x38(0x18)
	struct FText K2Node_CustomEvent_SubText;  // 0x50(0x18)
	struct FText K2Node_CustomEvent_Text1;  // 0x68(0x18)
	struct FText K2Node_CustomEvent_Text2;  // 0x80(0x18)
	struct UTexture2D* K2Node_CustomEvent_Image;  // 0x98(0x8)
	struct UTexture2D* K2Node_CustomEvent_Image2;  // 0xA0(0x8)
	int32_t Temp_int_Variable;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0xB0(0x8)
	float K2Node_CustomEvent_Health;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct UItemNotify_C* CallFunc_Create_ReturnValue_2;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201_1 : 7;  // 0xC9(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0xC9(0x1)
	char pad_202[2];  // 0xCA(0x2)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xCC(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xD0(0x4)
	float CallFunc_SelectFloat_ReturnValue;  // 0xD4(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0xD8(0x8)
	struct ABP_Effect_C* K2Node_CustomEvent_Effect;  // 0xE0(0x8)
	int32_t Temp_int_Variable_2;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_3;  // 0xF0(0x8)
	struct UEffect_C* CallFunc_Create_ReturnValue_3;  // 0xF8(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_2;  // 0x100(0x8)
	struct FText CallFunc_MakeLiteralText_ReturnValue;  // 0x108(0x18)
	int32_t K2Node_CustomEvent__wood;  // 0x120(0x4)
	int32_t K2Node_CustomEvent__metal;  // 0x124(0x4)
	int32_t K2Node_CustomEvent__binder;  // 0x128(0x4)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool CallFunc_EqualEqual_TextText_ReturnValue : 1;  // 0x12C(0x1)
	char pad_301[3];  // 0x12D(0x3)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x130(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x138(0x8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x144(0x38)
	float K2Node_Event_InDeltaTime;  // 0x17C(0x4)
	int32_t Temp_int_Variable_3;  // 0x180(0x4)
	char pad_388_1 : 7;  // 0x184(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x184(0x1)
	char pad_389[3];  // 0x185(0x3)
	int32_t K2Node_CustomEvent_Slot;  // 0x188(0x4)
	char pad_396[4];  // 0x18C(0x4)
	struct FST_Upgrade K2Node_CustomEvent_upgrade;  // 0x190(0x30)
	int32_t K2Node_Select_Default;  // 0x1C0(0x4)
	char pad_452[4];  // 0x1C4(0x4)
	struct FString K2Node_CustomEvent_KIller;  // 0x1C8(0x10)
	struct FString K2Node_CustomEvent_Killed;  // 0x1D8(0x10)
	struct UItemBox_C* K2Node_Select_Default_2;  // 0x1E8(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_4;  // 0x1F0(0x8)
	struct UKillFeedElement_C* CallFunc_Create_ReturnValue_4;  // 0x1F8(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_3;  // 0x200(0x8)
	struct FLinearColor K2Node_CustomEvent_color;  // 0x208(0x10)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x218(0x8)
	struct UCanvasPanelSlot* CallFunc_SlotAsCanvasSlot_ReturnValue;  // 0x220(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x228(0x4)
	char pad_556_1 : 7;  // 0x22C(0x1)
	bool K2Node_CustomEvent_pickup_ : 1;  // 0x22C(0x1)
	char pad_557[3];  // 0x22D(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x230(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x234(0x8)
	char pad_572[4];  // 0x23C(0x4)
	struct FText K2Node_CustomEvent_InText;  // 0x240(0x18)
	struct FLinearColor K2Node_CustomEvent_Specified_Color;  // 0x258(0x10)
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // 0x268(0x28)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x290(0x8)
	int32_t K2Node_CustomEvent_NewSlot;  // 0x298(0x4)
	struct FST_ItemCosts CallFunc_GetItemCost_Cost;  // 0x29C(0xC)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_5;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x2B0(0x1)
	char pad_689[7];  // 0x2B1(0x7)
	struct UHUD_ItemCost_C* CallFunc_Create_ReturnValue_5;  // 0x2B8(0x8)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue;  // 0x2C0(0x8)
	struct UHUD_ItemCost_C* CallFunc_Create_ReturnValue_6;  // 0x2C8(0x8)
	struct UHUD_ItemCost_C* CallFunc_Create_ReturnValue_7;  // 0x2D0(0x8)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue_2;  // 0x2D8(0x8)
	struct UHorizontalBoxSlot* CallFunc_AddChildToHorizontalBox_ReturnValue_3;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x2E8(0x1)
	char pad_745_1 : 7;  // 0x2E9(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // 0x2E9(0x1)
	char pad_746[2];  // 0x2EA(0x2)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x2EC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0x2F0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x2F4(0x4)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x2F9(0x1)
	char pad_762_1 : 7;  // 0x2FA(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x2FA(0x1)
	char pad_763_1 : 7;  // 0x2FB(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x2FB(0x1)
	char pad_764_1 : 7;  // 0x2FC(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2FC(0x1)
	char pad_765_1 : 7;  // 0x2FD(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x2FD(0x1)
	uint8_t  K2Node_Select_Default_3;  // 0x2FE(0x1)
	uint8_t  K2Node_Select_Default_4;  // 0x2FF(0x1)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x300(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x308(0x8)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x310(0x1)
	char pad_785_1 : 7;  // 0x311(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x311(0x1)
	char pad_786_1 : 7;  // 0x312(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x312(0x1)
	char pad_787[5];  // 0x313(0x5)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_6;  // 0x318(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x320(0x4)
	char pad_804[4];  // 0x324(0x4)
	struct UCanCraftNotify_C* CallFunc_Create_ReturnValue_8;  // 0x328(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x330(0x4)
	char pad_820[4];  // 0x334(0x4)
	struct FST_CraftRecipe CallFunc_Array_Get_Item;  // 0x338(0x28)
	int32_t CallFunc_Percent_IntInt_ReturnValue;  // 0x360(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x364(0x10)
	char pad_884_1 : 7;  // 0x374(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x374(0x1)
	char pad_885[3];  // 0x375(0x3)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x378(0x8)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0x380(0x1)
	char pad_897_1 : 7;  // 0x381(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x381(0x1)
	char pad_898_1 : 7;  // 0x382(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x382(0x1)
	char pad_899_1 : 7;  // 0x383(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x383(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x384(0x4)
	uint8_t  K2Node_Select_Default_5;  // 0x388(0x1)
	char pad_905_1 : 7;  // 0x389(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x389(0x1)
	char pad_906[2];  // 0x38A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x38C(0x4)
	int32_t CallFunc_GetChildrenCount_ReturnValue;  // 0x390(0x4)
	int32_t CallFunc_Divide_IntInt_ReturnValue;  // 0x394(0x4)
	struct UUniformGridSlot* CallFunc_AddChildToUniformGrid_ReturnValue;  // 0x398(0x8)
	int32_t K2Node_CustomEvent_RecipeID;  // 0x3A0(0x4)
	char pad_932[4];  // 0x3A4(0x4)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_4;  // 0x3A8(0x8)

}; 
// Function BaseHUD.BaseHUD_C.ItemNotify
// Size: 0x40(Inherited: 0x0) 
struct FItemNotify
{
	struct FText Text1;  // 0x0(0x18)
	struct FText Text2;  // 0x18(0x18)
	struct UTexture2D* Image;  // 0x30(0x8)
	struct UTexture2D* Image2;  // 0x38(0x8)

}; 
// Function BaseHUD.BaseHUD_C.Equip
// Size: 0x4(Inherited: 0x0) 
struct FEquip
{
	int32_t NewSlot;  // 0x0(0x4)

}; 
// Function BaseHUD.BaseHUD_C.StimVignette
// Size: 0x10(Inherited: 0x0) 
struct FStimVignette
{
	struct FLinearColor Color;  // 0x0(0x10)

}; 
// Function BaseHUD.BaseHUD_C.ShowKill
// Size: 0x20(Inherited: 0x0) 
struct FShowKill
{
	struct FString KIller;  // 0x0(0x10)
	struct FString Killed;  // 0x10(0x10)

}; 
// Function BaseHUD.BaseHUD_C.GetTeammateName
// Size: 0x98(Inherited: 0x0) 
struct FGetTeammateName
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString Temp_string_Variable;  // 0x20(0x10)
	struct APawn* CallFunc_GetOwningPlayerPawn_ReturnValue;  // 0x30(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x48(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x59(0x1)
	char pad_90[6];  // 0x5A(0x6)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x60(0x10)
	struct FString K2Node_Select_Default;  // 0x70(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x80(0x18)

}; 
// Function BaseHUD.BaseHUD_C.AddUpgrade
// Size: 0x38(Inherited: 0x0) 
struct FAddUpgrade
{
	int32_t Slot;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FST_Upgrade Upgrade;  // 0x8(0x30)

}; 
// Function BaseHUD.BaseHUD_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function BaseHUD.BaseHUD_C.Damage
// Size: 0x4(Inherited: 0x0) 
struct FDamage
{
	float Health;  // 0x0(0x4)

}; 
// Function BaseHUD.BaseHUD_C.CanCraftNotify
// Size: 0xC(Inherited: 0x0) 
struct FCanCraftNotify
{
	int32_t +wood;  // 0x0(0x4)
	int32_t +metal;  // 0x4(0x4)
	int32_t +binder;  // 0x8(0x4)

}; 
// Function BaseHUD.BaseHUD_C.Add Effect
// Size: 0x8(Inherited: 0x0) 
struct FAdd Effect
{
	struct ABP_Effect_C* Effect;  // 0x0(0x8)

}; 
// Function BaseHUD.BaseHUD_C.Get_Stamina_Percent
// Size: 0xC(Inherited: 0x0) 
struct FGet_Stamina_Percent
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x8(0x4)

}; 
// Function BaseHUD.BaseHUD_C.ShowToolTip
// Size: 0x30(Inherited: 0x0) 
struct FShowToolTip
{
	struct FText InText;  // 0x0(0x18)
	struct FText SubText;  // 0x18(0x18)

}; 
// Function BaseHUD.BaseHUD_C.Get_MicProgressBar_Percent_1
// Size: 0x8(Inherited: 0x0) 
struct FGet_MicProgressBar_Percent_1
{
	float ReturnValue;  // 0x0(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x4(0x4)

}; 
// Function BaseHUD.BaseHUD_C.GetHealthBarPercent
// Size: 0xC(Inherited: 0x0) 
struct FGetHealthBarPercent
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x8(0x4)

}; 
// Function BaseHUD.BaseHUD_C.GetHealthText
// Size: 0x38(Inherited: 0x0) 
struct FGetHealthText
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x20(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetPing
// Size: 0x70(Inherited: 0x0) 
struct FGetPing
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0x20(0x4)
	int32_t CallFunc_Multiply_IntInt_ReturnValue;  // 0x24(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x58(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetNumAlive
// Size: 0x48(Inherited: 0x0) 
struct FGetNumAlive
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x18(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x2C(0x4)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetKills
// Size: 0x48(Inherited: 0x0) 
struct FGetKills
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x18(0x8)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0x30(0x18)

}; 
// Function BaseHUD.BaseHUD_C.Get_ItemDescription_Visibility
// Size: 0x7(Inherited: 0x0) 
struct FGet_ItemDescription_Visibility
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x5(0x1)
	uint8_t  K2Node_Select_Default;  // 0x6(0x1)

}; 
// Function BaseHUD.BaseHUD_C.GetItemName
// Size: 0x38(Inherited: 0x0) 
struct FGetItemName
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x20(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetWeaponDamagePercent
// Size: 0x2C(Inherited: 0x0) 
struct FGetWeaponDamagePercent
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	ABP_Throwable_C* K2Node_ClassDynamicCast_AsBP_Throwable;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x28(0x4)

}; 
// Function BaseHUD.BaseHUD_C.GetStaminaText
// Size: 0x38(Inherited: 0x0) 
struct FGetStaminaText
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x20(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetWeaponSpeedPercent
// Size: 0x3C(Inherited: 0x0) 
struct FGetWeaponSpeedPercent
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	ABP_Throwable_C* K2Node_ClassDynamicCast_AsBP_Throwable;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	float CallFunc_MeleeSpeed_Hit_Delay;  // 0x24(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay;  // 0x28(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x2C(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x30(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x34(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x38(0x4)

}; 
// Function BaseHUD.BaseHUD_C.GetDrainPercent
// Size: 0x18(Inherited: 0x0) 
struct FGetDrainPercent
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x14(0x4)

}; 
// Function BaseHUD.BaseHUD_C.VisibleIfThereAreSpectators
// Size: 0x3A(Inherited: 0x0) 
struct FVisibleIfThereAreSpectators
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4[4];  // 0x4(0x4)
	struct FText CallFunc_MakeLiteralText_ReturnValue;  // 0x8(0x18)
	struct FText CallFunc_GetSpectatorCount_ReturnValue;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_EqualEqual_TextText_ReturnValue : 1;  // 0x38(0x1)
	uint8_t  K2Node_Select_Default;  // 0x39(0x1)

}; 
// Function BaseHUD.BaseHUD_C.GetArmorHealth
// Size: 0xC(Inherited: 0x0) 
struct FGetArmorHealth
{
	float ReturnValue;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x8(0x4)

}; 
// Function BaseHUD.BaseHUD_C.GetDamageText
// Size: 0xC0(Inherited: 0x0) 
struct FGetDamageText
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	ABP_Throwable_C* K2Node_ClassDynamicCast_AsBP_Throwable;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x3C(0x4)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x40(0x18)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x60(0x10)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x78(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x88(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x98(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xA8(0x18)

}; 
// Function BaseHUD.BaseHUD_C.Get_Crosshair_Visibility_1
// Size: 0x9(Inherited: 0x0) 
struct FGet_Crosshair_Visibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x7(0x1)
	uint8_t  K2Node_Select_Default;  // 0x8(0x1)

}; 
// Function BaseHUD.BaseHUD_C.GetSpeedText
// Size: 0xA0(Inherited: 0x0) 
struct FGetSpeedText
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	ABP_Throwable_C* K2Node_ClassDynamicCast_AsBP_Throwable;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x40(0x10)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x58(0x18)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // 0x78(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x88(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetDrainText
// Size: 0x48(Inherited: 0x0) 
struct FGetDrainText
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FText CallFunc_Conv_FloatToText_ReturnValue;  // 0x30(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetItemDescription
// Size: 0x58(Inherited: 0x0) 
struct FGetItemDescription
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x20(0x10)
	struct FString CallFunc_ReplaceInputsInText_OutText;  // 0x30(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x40(0x18)

}; 
// Function BaseHUD.BaseHUD_C.GetGameTimeClock
// Size: 0xB0(Inherited: 0x0) 
struct FGetGameTimeClock
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x38(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FString CallFunc_SecondsToClock_Minutes;  // 0x58(0x10)
	struct FString CallFunc_SecondsToClock_Sec;  // 0x68(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x78(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x88(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x98(0x18)

}; 
// Function BaseHUD.BaseHUD_C.Get_ChampionModeIcon_Visibility_1
// Size: 0x5(Inherited: 0x0) 
struct FGet_ChampionModeIcon_Visibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	uint8_t  K2Node_Select_Default;  // 0x4(0x1)

}; 
// Function BaseHUD.BaseHUD_C.GetMicBrush
// Size: 0x6C(Inherited: 0x0) 
struct FGetMicBrush
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor Temp_struct_Variable;  // 0x14(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FLinearColor Temp_struct_Variable_3;  // 0x38(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FLinearColor K2Node_Select_Default_2;  // 0x5C(0x10)

}; 
// Function BaseHUD.BaseHUD_C.GetSpectatorCount
// Size: 0x88(Inherited: 0x0) 
struct FGetSpectatorCount
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FText Temp_text_Variable;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x58(0x18)
	struct FText K2Node_Select_Default;  // 0x70(0x18)

}; 
// Function BaseHUD.BaseHUD_C.Get_ChampionModeIcon_bIsEnabled_1
// Size: 0x1(Inherited: 0x0) 
struct FGet_ChampionModeIcon_bIsEnabled_1
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BaseHUD.BaseHUD_C.Get_MicProgressBar_Visibility_1
// Size: 0x5(Inherited: 0x0) 
struct FGet_MicProgressBar_Visibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	uint8_t  K2Node_Select_Default;  // 0x4(0x1)

}; 
