#pragma once 
#include <AI_PC_Structs.h>
 
 
 
// BlueprintGeneratedClass AI_PC.AI_PC_C
// Size: 0x338(Inherited: 0x328) 
struct AAI_PC_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x328(0x8)
	struct UAIPerceptionComponent* AIPerception;  // 0x330(0x8)

	void ForgetTarget(); // Function AI_PC.AI_PC_C.ForgetTarget
	void ReceiveBeginPlay(); // Function AI_PC.AI_PC_C.ReceiveBeginPlay
	void BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature(struct AActor* Actor, struct FAIStimulus Stimulus); // Function AI_PC.AI_PC_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature
	void BndEvt__AIPerception_K2Node_ComponentBoundEvent_0_PerceptionUpdatedDelegate__DelegateSignature(struct TArray<struct AActor*>& UpdatedActors); // Function AI_PC.AI_PC_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_0_PerceptionUpdatedDelegate__DelegateSignature
	void ExecuteUbergraph_AI_PC(int32_t EntryPoint); // Function AI_PC.AI_PC_C.ExecuteUbergraph_AI_PC
}; 



