#pragma once 
#include <ExplosiveBarrel_Structs.h>
 
 
 
// BlueprintGeneratedClass ExplosiveBarrel.ExplosiveBarrel_C
// Size: 0x2BC(Inherited: 0x2B0) 
struct AExplosiveBarrel_C : public AMovable_Object_Replicated_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B0(0x8)
	float SpawnChance;  // 0x2B8(0x4)

	void ReceiveBeginPlay(); // Function ExplosiveBarrel.ExplosiveBarrel_C.ReceiveBeginPlay
	void GetDamaged(float Damage, struct AFirstPersonCharacter_C* Causer, struct FVector Location, struct FVector Normal); // Function ExplosiveBarrel.ExplosiveBarrel_C.GetDamaged
	void ExplodeServer(struct FTransform SpawnTransform, struct AFirstPersonCharacter_C* Causer); // Function ExplosiveBarrel.ExplosiveBarrel_C.ExplodeServer
	void ExecuteUbergraph_ExplosiveBarrel(int32_t EntryPoint); // Function ExplosiveBarrel.ExplosiveBarrel_C.ExecuteUbergraph_ExplosiveBarrel
}; 



