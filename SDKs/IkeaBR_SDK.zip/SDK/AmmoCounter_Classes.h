#pragma once 
#include <AmmoCounter_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AmmoCounter.AmmoCounter_C
// Size: 0x270(Inherited: 0x260) 
struct UAmmoCounter_C : public UUserWidget
{
	struct UTextBlock* TextBlock_43;  // 0x260(0x8)
	struct AFirstPersonCharacter_C* Parent;  // 0x268(0x8)

	struct FText GetText_1(); // Function AmmoCounter.AmmoCounter_C.GetText_1
}; 



