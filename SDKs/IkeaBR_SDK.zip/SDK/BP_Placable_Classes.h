#pragma once 
#include <BP_Placable_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Placable.BP_Placable_C
// Size: 0x238(Inherited: 0x220) 
struct ABP_Placable_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x228(0x8)
	struct UStaticMesh* Mesh;  // 0x230(0x8)

	void UserConstructionScript(); // Function BP_Placable.BP_Placable_C.UserConstructionScript
}; 



