#pragma once 
#include "SDK.h" 
 
 
// Function Dynamite_BP.Dynamite_BP_C.ExecuteUbergraph_Dynamite_BP
// Size: 0x1A8(Inherited: 0x0) 
struct FExecuteUbergraph_Dynamite_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_Down : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_Delay_Ping_delay_ping;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AWorldSettings* CallFunc_GetWorldSettings_World_Settings;  // 0x10(0x8)
	int32_t CallFunc_FindItemInInventory_index;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item;  // 0x20(0x90)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_FindItemInInventory_Found : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xB4(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xC0(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xCC(0xC)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0xD8(0x10)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xE8(0xC)
	char pad_244[12];  // 0xF4(0xC)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue;  // 0x100(0x30)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x130(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x13C(0x4)
	struct FVector CallFunc_GetForwardVector_ReturnValue_2;  // 0x140(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x14C(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x158(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x164(0xC)
	struct UchargeBar_C* CallFunc_AddCharge_widget;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x17C(0x4)
	struct FRotator CallFunc_MakeShootTransform_Rotation;  // 0x180(0xC)
	struct FVector CallFunc_MakeShootTransform_Location;  // 0x18C(0xC)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x198(0x1)
	char pad_409[7];  // 0x199(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x1A0(0x8)

}; 
// Function Dynamite_BP.Dynamite_BP_C.LMB
// Size: 0x1(Inherited: 0x1) 
struct FLMB : public FLMB
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
