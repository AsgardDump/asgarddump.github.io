#pragma once 
#include <BP_RecipePreview_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_RecipePreview.BP_RecipePreview_C
// Size: 0x23C(Inherited: 0x220) 
struct ABP_RecipePreview_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	float Speed;  // 0x238(0x4)

	void ReceiveBeginPlay(); // Function BP_RecipePreview.BP_RecipePreview_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_RecipePreview.BP_RecipePreview_C.ReceiveTick
	void UpdateMesh(struct UStaticMesh* Mesh); // Function BP_RecipePreview.BP_RecipePreview_C.UpdateMesh
	void ExecuteUbergraph_BP_RecipePreview(int32_t EntryPoint); // Function BP_RecipePreview.BP_RecipePreview_C.ExecuteUbergraph_BP_RecipePreview
}; 



