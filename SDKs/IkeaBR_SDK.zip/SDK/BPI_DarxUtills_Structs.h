#pragma once 
#include "SDK.h" 
 
 
// Function BPI_DarxUtills.BPI_DarxUtills_C.DestroyStaticMesh
// Size: 0x10(Inherited: 0x0) 
struct FDestroyStaticMesh
{
	struct UStaticMeshComponent* Mesh;  // 0x0(0x8)
	struct UStaticMesh* Out;  // 0x8(0x8)

}; 
// Function BPI_DarxUtills.BPI_DarxUtills_C.AddStaticMesh
// Size: 0x10(Inherited: 0x0) 
struct FAddStaticMesh
{
	struct FName Tag;  // 0x0(0x8)
	struct UStaticMeshComponent* Mesh;  // 0x8(0x8)

}; 
// Function BPI_DarxUtills.BPI_DarxUtills_C.AddSkeletalMesh
// Size: 0x10(Inherited: 0x0) 
struct FAddSkeletalMesh
{
	struct FName Tag;  // 0x0(0x8)
	struct USkeletalMeshComponent* Mesh;  // 0x8(0x8)

}; 
// Function BPI_DarxUtills.BPI_DarxUtills_C.DestroySkeletalMesh
// Size: 0x10(Inherited: 0x0) 
struct FDestroySkeletalMesh
{
	struct USkeletalMeshComponent* Mesh;  // 0x0(0x8)
	struct USkeletalMesh* Out;  // 0x8(0x8)

}; 
