#pragma once 
#include <BP_WoodenArrow_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_WoodenArrow.BP_WoodenArrow_C
// Size: 0x257(Inherited: 0x257) 
struct ABP_WoodenArrow_C : public ABP_Projectile_C
{

}; 



