#pragma once 
#include <CustomGames_ServerButton_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomGames_ServerButton.CustomGames_ServerButton_C
// Size: 0x448(Inherited: 0x260) 
struct UCustomGames_ServerButton_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UImage* Image_115;  // 0x268(0x8)
	struct URR_Button_C* RR_Button_C_2;  // 0x270(0x8)
	struct UTextBlock* Text012players;  // 0x278(0x8)
	struct UTextBlock* TextBlock_3;  // 0x280(0x8)
	struct UTextBlock* TextBlock_42;  // 0x288(0x8)
	struct FBlueprintSessionResult Server;  // 0x290(0x108)
	struct FGameServerItem SteamServer;  // 0x398(0xB0)

	uint8_t  GetVisibility_2(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetVisibility_2
	struct FText GetText_6(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_6
	struct FText GetText_5(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_5
	struct FText GetText_4(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_4
	struct FText GetText_3(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_3
	uint8_t  GetVisibility_1(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetVisibility_1
	struct FText GetText_2(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_2
	struct FText GetText_1(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.GetText_1
	void OnFailure_889FABFA42F9352C49DAD3AFFD579EEA(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.OnFailure_889FABFA42F9352C49DAD3AFFD579EEA
	void OnSuccess_889FABFA42F9352C49DAD3AFFD579EEA(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.OnSuccess_889FABFA42F9352C49DAD3AFFD579EEA
	void BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_CustomGames_ServerButton(int32_t EntryPoint); // Function CustomGames_ServerButton.CustomGames_ServerButton_C.ExecuteUbergraph_CustomGames_ServerButton
}; 



