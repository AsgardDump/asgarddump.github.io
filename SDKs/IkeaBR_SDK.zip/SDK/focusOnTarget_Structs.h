#pragma once 
#include "SDK.h" 
 
 
// Function focusOnTarget.focusOnTarget_C.ExecuteUbergraph_focusOnTarget
// Size: 0x38(Inherited: 0x0) 
struct FExecuteUbergraph_focusOnTarget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UObject* CallFunc_GetBlackboardValueAsObject_ReturnValue;  // 0x8(0x8)
	struct AAIController* K2Node_Event_OwnerController;  // 0x10(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x18(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x30(0x8)

}; 
// Function focusOnTarget.focusOnTarget_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
