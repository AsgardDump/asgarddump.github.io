#pragma once 
#include <C_Upgrade_Structs.h>
 
 
 
// BlueprintGeneratedClass C_Upgrade.C_Upgrade_C
// Size: 0xF0(Inherited: 0xB0) 
struct UC_Upgrade_C : public UActorComponent
{
	struct AFirstPersonCharacter_C* Parent;  // 0xB0(0x8)
	char E_ItemType TargetType;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct FST_Upgrade Upgrade;  // 0xC0(0x30)

}; 



