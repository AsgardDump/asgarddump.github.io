#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Bleed.BP_Effect_Bleed_C.ExecuteUbergraph_BP_Effect_Bleed
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Bleed
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)
	struct AFirstPersonCharacter_C* CallFunc_GetCaster_caster;  // 0x10(0x8)

}; 
