#pragma once 
#include <BroomStick_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BroomStick_BP.BroomStick_BP_C
// Size: 0x290(Inherited: 0x290) 
struct ABroomStick_BP_C : public AWeaponBP_C
{

}; 



