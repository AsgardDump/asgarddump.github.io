#pragma once 
#include <BP_WoodenArrow_InHand_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_WoodenArrow_InHand.BP_WoodenArrow_InHand_C
// Size: 0x268(Inherited: 0x268) 
struct ABP_WoodenArrow_InHand_C : public AItemBP_C
{

}; 



