#pragma once 
#include <Bow_AnimBP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass Bow_AnimBP.Bow_AnimBP_C
// Size: 0x6B8(Inherited: 0x2C0) 
struct UBow_AnimBP_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // 0x2F8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x320(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x348(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x370(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x398(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x3C0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0x440(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x470(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x4F0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x520(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x5A0(0x30)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x5D0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x600(0xB0)
	char pad_1712_1 : 7;  // 0x6B0(0x1)
	bool Drawing : 1;  // 0x6B0(0x1)
	char pad_1713[3];  // 0x6B1(0x3)
	float ChargeTime;  // 0x6B4(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function Bow_AnimBP.Bow_AnimBP_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Bow_AnimBP_AnimGraphNode_SequencePlayer_D4695A764D7A3BF1D6ADE0AAC9318A11(); // Function Bow_AnimBP.Bow_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Bow_AnimBP_AnimGraphNode_SequencePlayer_D4695A764D7A3BF1D6ADE0AAC9318A11
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Bow_AnimBP_AnimGraphNode_TransitionResult_9E841B6545F81034E29548AD191676B0(); // Function Bow_AnimBP.Bow_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Bow_AnimBP_AnimGraphNode_TransitionResult_9E841B6545F81034E29548AD191676B0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Bow_AnimBP_AnimGraphNode_TransitionResult_B3F625624D48275534D130BED48E66C3(); // Function Bow_AnimBP.Bow_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Bow_AnimBP_AnimGraphNode_TransitionResult_B3F625624D48275534D130BED48E66C3
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function Bow_AnimBP.Bow_AnimBP_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_Bow_AnimBP(int32_t EntryPoint); // Function Bow_AnimBP.Bow_AnimBP_C.ExecuteUbergraph_Bow_AnimBP
}; 



