#pragma once 
#include <BP_Stim_Charge_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Stim_Charge.BP_Stim_Charge_C
// Size: 0x280(Inherited: 0x280) 
struct ABP_Stim_Charge_C : public ABP_StimBase_C
{

}; 



