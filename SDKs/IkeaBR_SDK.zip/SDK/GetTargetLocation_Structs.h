#pragma once 
#include "SDK.h" 
 
 
// Function GetTargetLocation.GetTargetLocation_C.ExecuteUbergraph_GetTargetLocation
// Size: 0x45(Inherited: 0x0) 
struct FExecuteUbergraph_GetTargetLocation
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct UObject* CallFunc_GetBlackboardValueAsObject_ReturnValue;  // 0x18(0x8)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_K2_GetRandomPointInNavigableRadius_RandomLocation;  // 0x38(0xC)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool CallFunc_K2_GetRandomPointInNavigableRadius_ReturnValue : 1;  // 0x44(0x1)

}; 
// Function GetTargetLocation.GetTargetLocation_C.ReceiveExecuteAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveExecuteAI : public FReceiveExecuteAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
