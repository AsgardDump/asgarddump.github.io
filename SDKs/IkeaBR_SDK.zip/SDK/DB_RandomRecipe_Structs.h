#pragma once 
#include "SDK.h" 
 
 
// Function DB_RandomRecipe.DB_RandomRecipe_C.ExecuteUbergraph_DB_RandomRecipe
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_DB_RandomRecipe
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
