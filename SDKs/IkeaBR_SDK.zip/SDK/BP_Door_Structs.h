#pragma once 
#include "SDK.h" 
 
 
// Function BP_Door.BP_Door_C.ExecuteUbergraph_BP_Door
// Size: 0x1C5(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Door
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent_2;  // 0x8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x18(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse_2;  // 0x20(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit_2;  // 0x2C(0x88)
	char pad_180[4];  // 0xB4(0x4)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_HitComponent;  // 0xB8(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xC0(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xC8(0x8)
	struct FVector K2Node_ComponentBoundEvent_NormalImpulse;  // 0xD0(0xC)
	struct FHitResult K2Node_ComponentBoundEvent_Hit;  // 0xDC(0x88)
	char pad_356[4];  // 0x164(0x4)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x178(0x8)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x180(0x1)
	char ECollisionChannel CallFunc_GetCollisionObjectType_ReturnValue;  // 0x181(0x1)
	char pad_386_1 : 7;  // 0x182(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x182(0x1)
	char pad_387_1 : 7;  // 0x183(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x183(0x1)
	char pad_388[4];  // 0x184(0x4)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated_2;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x190(0x1)
	char pad_401_1 : 7;  // 0x191(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x191(0x1)
	char pad_402[6];  // 0x192(0x6)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1A0(0x1)
	char pad_417_1 : 7;  // 0x1A1(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x1A1(0x1)
	char ECollisionChannel CallFunc_GetCollisionObjectType_ReturnValue_2;  // 0x1A2(0x1)
	char pad_419_1 : 7;  // 0x1A3(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue_2 : 1;  // 0x1A3(0x1)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1A4(0x1)
	char pad_421[3];  // 0x1A5(0x3)
	struct FVector K2Node_CustomEvent_Vel;  // 0x1A8(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x1B4(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1B8(0xC)
	char pad_452_1 : 7;  // 0x1C4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1C4(0x1)

}; 
// Function BP_Door.BP_Door_C.OnHit
// Size: 0xC(Inherited: 0x0) 
struct FOnHit
{
	struct FVector Vel;  // 0x0(0xC)

}; 
// Function BP_Door.BP_Door_C.BndEvt__StaticMesh1_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__StaticMesh1_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
// Function BP_Door.BP_Door_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
// Size: 0xAC(Inherited: 0x0) 
struct FBndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0xC)
	struct FHitResult Hit;  // 0x24(0x88)

}; 
