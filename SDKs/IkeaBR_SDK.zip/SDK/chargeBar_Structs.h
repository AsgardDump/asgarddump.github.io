#pragma once 
#include "SDK.h" 
 
 
// Function chargeBar.chargeBar_C.ExecuteUbergraph_chargeBar
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_chargeBar
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float Temp_float_Variable;  // 0x8(0x4)
	float Temp_float_Variable_2;  // 0xC(0x4)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x10(0x38)
	float K2Node_Event_InDeltaTime;  // 0x48(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x50(0x4)
	float K2Node_Select_Default;  // 0x54(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x58(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x5C(0x4)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue;  // 0x60(0x8)
	struct UUMGSequencePlayer* CallFunc_PlayAnimation_ReturnValue_2;  // 0x68(0x8)

}; 
// Function chargeBar.chargeBar_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function chargeBar.chargeBar_C.GetFillColorAndOpacity_1
// Size: 0x38(Inherited: 0x0) 
struct FGetFillColorAndOpacity_1
{
	struct FLinearColor ReturnValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FLinearColor K2Node_MakeStruct_LinearColor;  // 0x14(0x10)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FLinearColor K2Node_Select_Default;  // 0x28(0x10)

}; 
