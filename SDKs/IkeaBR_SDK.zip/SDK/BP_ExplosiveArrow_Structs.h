#pragma once 
#include "SDK.h" 
 
 
// Function BP_ExplosiveArrow.BP_ExplosiveArrow_C.Hit
// Size: 0x90(Inherited: 0x90) 
struct FHit : public FHit
{
	struct AActor* other actor;  // 0x0(0x8)
	struct FHitResult HitResult;  // 0x8(0x88)

}; 
// Function BP_ExplosiveArrow.BP_ExplosiveArrow_C.ExecuteUbergraph_BP_ExplosiveArrow
// Size: 0x11D(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ExplosiveArrow
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct APawn* CallFunc_GetInstigator_ReturnValue;  // 0x10(0x8)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x20(0x30)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct AActor* K2Node_Event_other_actor;  // 0x60(0x8)
	struct FHitResult K2Node_Event_HitResult;  // 0x68(0x88)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xFC(0x4)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x100(0x10)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item;  // 0x110(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x118(0x4)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x11C(0x1)

}; 
