#pragma once 
#include <BP_BearTrap_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BearTrap.BP_BearTrap_C
// Size: 0x258(Inherited: 0x238) 
struct ABP_BearTrap_C : public ABP_Placable_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x238(0x8)
	struct UBoxComponent* Box;  // 0x240(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x248(0x8)
	struct AFirstPersonCharacter_C* Caught;  // 0x250(0x8)

	void RecieveServerLook(bool& Recieve?); // Function BP_BearTrap.BP_BearTrap_C.RecieveServerLook
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function BP_BearTrap.BP_BearTrap_C.OnInteract
	void OnLook(struct AFirstPersonCharacter_C* Caller); // Function BP_BearTrap.BP_BearTrap_C.OnLook
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function BP_BearTrap.BP_BearTrap_C.OnStopLook
	void ServerOnLook(struct AFirstPersonCharacter_C* Player); // Function BP_BearTrap.BP_BearTrap_C.ServerOnLook
	void ServerOnStopLook(struct AFirstPersonCharacter_C* Player); // Function BP_BearTrap.BP_BearTrap_C.ServerOnStopLook
	void BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BearTrap.BP_BearTrap_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void Damage(struct AActor* DamagedActor, float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function BP_BearTrap.BP_BearTrap_C.Damage
	void Release(); // Function BP_BearTrap.BP_BearTrap_C.Release
	void LMB(bool Down); // Function BP_BearTrap.BP_BearTrap_C.LMB
	void MultiClose(); // Function BP_BearTrap.BP_BearTrap_C.MultiClose
	void ReceiveTick(float DeltaSeconds); // Function BP_BearTrap.BP_BearTrap_C.ReceiveTick
	void OnChargeUpdate(float Charge, struct AFirstPersonCharacter_C* Caller); // Function BP_BearTrap.BP_BearTrap_C.OnChargeUpdate
	void ExecuteUbergraph_BP_BearTrap(int32_t EntryPoint); // Function BP_BearTrap.BP_BearTrap_C.ExecuteUbergraph_BP_BearTrap
}; 



