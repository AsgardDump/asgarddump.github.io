#pragma once 
#include <CustomGames_CreateGame_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CustomGames_CreateGame.CustomGames_CreateGame_C
// Size: 0x2A0(Inherited: 0x260) 
struct UCustomGames_CreateGame_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct URR_Checkbox_C* BotsCheckbox;  // 0x268(0x8)
	struct URR_Button_C* CreateButton;  // 0x270(0x8)
	struct URR_Button_Transparent_C* ExitButton;  // 0x278(0x8)
	struct URR_ComboBox_C* ModeComboBox;  // 0x280(0x8)
	struct URR_TextBox_C* NameTextBox;  // 0x288(0x8)
	struct URR_TextBox_C* PasswordTextBox;  // 0x290(0x8)
	struct URR_Checkbox_C* PrivateCheckbow;  // 0x298(0x8)

	uint8_t  Get_PasswordTextBox_Visibility_1(); // Function CustomGames_CreateGame.CustomGames_CreateGame_C.Get_PasswordTextBox_Visibility_1
	void ForceKill(); // Function CustomGames_CreateGame.CustomGames_CreateGame_C.ForceKill
	void Construct(); // Function CustomGames_CreateGame.CustomGames_CreateGame_C.Construct
	void BndEvt__ExitButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function CustomGames_CreateGame.CustomGames_CreateGame_C.BndEvt__ExitButton_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void BndEvt__CreateButton_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature(); // Function CustomGames_CreateGame.CustomGames_CreateGame_C.BndEvt__CreateButton_K2Node_ComponentBoundEvent_1_OnButtonClickedEvent__DelegateSignature
	void ExecuteUbergraph_CustomGames_CreateGame(int32_t EntryPoint); // Function CustomGames_CreateGame.CustomGames_CreateGame_C.ExecuteUbergraph_CustomGames_CreateGame
}; 



