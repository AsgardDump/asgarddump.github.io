#pragma once 
#include "SDK.h" 
 
 
// Function DismantleStaion.DismantleStaion_C.ServerOnLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function DismantleStaion.DismantleStaion_C.ServerOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnStopLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function DismantleStaion.DismantleStaion_C.ExecuteUbergraph_DismantleStaion
// Size: 0x1EA(Inherited: 0x0) 
struct FExecuteUbergraph_DismantleStaion
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0x8(0x10)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_2;  // 0x18(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_ItemEquipped_bool : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	struct FST_ItemCosts CallFunc_GetItemCost_Cost;  // 0x2C(0xC)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_character;  // 0x38(0x8)
	float CallFunc_Delay_Ping_delay_ping;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x48(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x58(0x10)
	float CallFunc_Delay_Ping_delay_ping_2;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x6C(0x1)
	char pad_109_1 : 7;  // 0x6D(0x1)
	bool CallFunc_ItemValid__Valid : 1;  // 0x6D(0x1)
	char pad_110[2];  // 0x6E(0x2)
	struct FString CallFunc_AddInputToString_out;  // 0x70(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x80(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x90(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0xA0(0x10)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0xB8(0x10)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_user_2;  // 0xC8(0x8)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_user;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct AFirstPersonCharacter_C* K2Node_Event_Player_2;  // 0xE0(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_3;  // 0xE8(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0xF0(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0x178(0x4)
	char pad_380[4];  // 0x17C(0x4)
	struct ABP_FlashingLight_C* K2Node_DynamicCast_AsBP_Flashing_Light;  // 0x180(0x8)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x188(0x1)
	char pad_393_1 : 7;  // 0x189(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x189(0x1)
	char pad_394[6];  // 0x18A(0x6)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x190(0x8)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x198(0x1)
	char pad_409[3];  // 0x199(0x3)
	float K2Node_Event_Charge;  // 0x19C(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_4;  // 0x1A0(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x1B0(0x1)
	char pad_433_1 : 7;  // 0x1B1(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x1B1(0x1)
	char pad_434[6];  // 0x1B2(0x6)
	struct FString CallFunc_GetObjectName_ReturnValue_2;  // 0x1B8(0x10)
	struct FString CallFunc_GetObjectName_ReturnValue_3;  // 0x1C8(0x10)
	struct FString CallFunc_GetObjectName_ReturnValue_4;  // 0x1D8(0x10)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_IsInteractableActorInFocus_Value : 1;  // 0x1E8(0x1)
	char pad_489_1 : 7;  // 0x1E9(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1E9(0x1)

}; 
// Function DismantleStaion.DismantleStaion_C.ServerStop
// Size: 0x8(Inherited: 0x0) 
struct FServerStop
{
	struct AFirstPersonCharacter_C* User;  // 0x0(0x8)

}; 
// Function DismantleStaion.DismantleStaion_C.Stop
// Size: 0x8(Inherited: 0x0) 
struct FStop
{
	struct AFirstPersonCharacter_C* User;  // 0x0(0x8)

}; 
// Function DismantleStaion.DismantleStaion_C.OnLook
// Size: 0x8(Inherited: 0x0) 
struct FOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function DismantleStaion.DismantleStaion_C.OnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function DismantleStaion.DismantleStaion_C.RecieveServerLook
// Size: 0x1(Inherited: 0x0) 
struct FRecieveServerLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Recieve? : 1;  // 0x0(0x1)

}; 
// Function DismantleStaion.DismantleStaion_C.OnInteract
// Size: 0x94(Inherited: 0x0) 
struct FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
// Function DismantleStaion.DismantleStaion_C.ClientStart
// Size: 0x8(Inherited: 0x0) 
struct FClientStart
{
	struct AFirstPersonCharacter_C* Character;  // 0x0(0x8)

}; 
// Function DismantleStaion.DismantleStaion_C.OnChargeUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOnChargeUpdate
{
	float Charge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Caller;  // 0x8(0x8)

}; 
