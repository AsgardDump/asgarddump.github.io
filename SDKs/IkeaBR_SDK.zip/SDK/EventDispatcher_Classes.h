#pragma once 
#include <EventDispatcher_Structs.h>
 
 
 
// Class EventDispatcher.EventIdentifier
// Size: 0x48(Inherited: 0x30) 
struct UEventIdentifier : public UDataAsset
{
	struct FText EventDescription;  // 0x30(0x18)

}; 



// Class EventDispatcher.EventDispatcherSettings
// Size: 0x40(Inherited: 0x38) 
struct UEventDispatcherSettings : public UDeveloperSettings
{
	float PollingRate;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class EventDispatcher.EventManager
// Size: 0x6F0(Inherited: 0x30) 
struct UEventManager : public UGameInstanceSubsystem
{
	char pad_48[1728];  // 0x30(0x6C0)

	void UnregisterEvents(struct UObject* worldContextObject); // Function EventDispatcher.EventManager.UnregisterEvents
	void UnregisterEventName(struct UObject* worldContextObject, struct FString EventIdentifier); // Function EventDispatcher.EventManager.UnregisterEventName
	void UnregisterEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier); // Function EventDispatcher.EventManager.UnregisterEvent
	void RegisterVectorEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterVectorEventName
	void RegisterVectorEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterVectorEvent
	void RegisterStringIntEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterStringIntEventName
	void RegisterStringIntEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterStringIntEvent
	void RegisterStringFloatEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterStringFloatEventName
	void RegisterStringFloatEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterStringFloatEvent
	void RegisterStringEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterStringEventName
	void RegisterStringEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterStringEvent
	void RegisterSimpleEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterSimpleEventName
	void RegisterSimpleEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterSimpleEvent
	void RegisterPayloadEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterPayloadEventName
	void RegisterPayloadEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterPayloadEvent
	void RegisterIntEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterIntEventName
	void RegisterIntEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterIntEvent
	void RegisterFloatEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterFloatEventName
	void RegisterFloatEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterFloatEvent
	void RegisterBoolEventName(struct UObject* worldContextObject, struct FString EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterBoolEventName
	void RegisterBoolEvent(struct UObject* worldContextObject, struct UEventIdentifier* EventIdentifier, struct FDelegate& Callback); // Function EventDispatcher.EventManager.RegisterBoolEvent
	void InvokeVectorEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, struct FVector Data); // Function EventDispatcher.EventManager.InvokeVectorEventName
	void InvokeVectorEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, struct FVector Data); // Function EventDispatcher.EventManager.InvokeVectorEvent
	void InvokeStringIntEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, struct FStringInt Data); // Function EventDispatcher.EventManager.InvokeStringIntEventName
	void InvokeStringIntEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, struct FStringInt Data); // Function EventDispatcher.EventManager.InvokeStringIntEvent
	void InvokeStringFloatEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, struct FStringFloat Data); // Function EventDispatcher.EventManager.InvokeStringFloatEventName
	void InvokeStringFloatEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, struct FStringFloat Data); // Function EventDispatcher.EventManager.InvokeStringFloatEvent
	void InvokeStringEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, struct FString String); // Function EventDispatcher.EventManager.InvokeStringEventName
	void InvokeStringEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, struct FString String); // Function EventDispatcher.EventManager.InvokeStringEvent
	void InvokeSimpleEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier); // Function EventDispatcher.EventManager.InvokeSimpleEventName
	void InvokeSimpleEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier); // Function EventDispatcher.EventManager.InvokeSimpleEvent
	void InvokePayloadEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, struct UObject* Payload); // Function EventDispatcher.EventManager.InvokePayloadEventName
	void InvokePayloadEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, struct UObject* Payload); // Function EventDispatcher.EventManager.InvokePayloadEvent
	void InvokeIntEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, int32_t Value); // Function EventDispatcher.EventManager.InvokeIntEventName
	void InvokeIntEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, int32_t Value); // Function EventDispatcher.EventManager.InvokeIntEvent
	void InvokeFloatEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, float Value); // Function EventDispatcher.EventManager.InvokeFloatEventName
	void InvokeFloatEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, float Value); // Function EventDispatcher.EventManager.InvokeFloatEvent
	void InvokeBoolEventName(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct FString EventIdentifier, bool bValue); // Function EventDispatcher.EventManager.InvokeBoolEventName
	void InvokeBoolEvent(struct UObject* worldContextObject, struct UObject* OptionalTarget, struct UEventIdentifier* EventIdentifier, bool bValue); // Function EventDispatcher.EventManager.InvokeBoolEvent
	void DebugEventManager(struct UObject* worldContextObject); // Function EventDispatcher.EventManager.DebugEventManager
}; 



// Class EventDispatcher.PayloadObject
// Size: 0x28(Inherited: 0x28) 
struct UPayloadObject : public UObject
{

}; 



