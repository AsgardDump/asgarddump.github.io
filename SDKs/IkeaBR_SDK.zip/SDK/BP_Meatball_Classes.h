#pragma once 
#include <BP_Meatball_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Meatball.BP_Meatball_C
// Size: 0x257(Inherited: 0x257) 
struct ABP_Meatball_C : public ABP_Projectile_C
{

}; 



