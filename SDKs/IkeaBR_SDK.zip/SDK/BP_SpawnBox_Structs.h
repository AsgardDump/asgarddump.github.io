#pragma once 
#include "SDK.h" 
 
 
// Function BP_SpawnBox.BP_SpawnBox_C.ExecuteUbergraph_BP_SpawnBox
// Size: 0x340(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SpawnBox
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Player_2;  // 0x8(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Player;  // 0x18(0x8)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x20(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue_2;  // 0x2C(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue_3;  // 0x38(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue_4;  // 0x44(0xC)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x54(0x4)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0x58(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x64(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x70(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x7C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x88(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x94(0x88)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x11C(0x1)
	char pad_285[3];  // 0x11D(0x3)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x120(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x1A8(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_3;  // 0x230(0x88)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_4;  // 0x2B8(0x88)

}; 
// Function BP_SpawnBox.BP_SpawnBox_C.PlacePlayer
// Size: 0x8(Inherited: 0x0) 
struct FPlacePlayer
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BP_SpawnBox.BP_SpawnBox_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_SpawnBox.BP_SpawnBox_C.SpawnNormal
// Size: 0x8(Inherited: 0x0) 
struct FSpawnNormal
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
