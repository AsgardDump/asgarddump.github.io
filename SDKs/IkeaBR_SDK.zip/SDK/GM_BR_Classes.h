#pragma once 
#include <GM_BR_Structs.h>
 
 
 
// BlueprintGeneratedClass GM_BR.GM_BR_C
// Size: 0x508(Inherited: 0x2C0) 
struct AGM_BR_C : public AGameModeBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2C8(0x8)
	struct UC_PlayerLoot_C* C_PlayerLoot;  // 0x2D0(0x8)
	struct UC_RandomDeckManager_C* C_RandomDeckManager;  // 0x2D8(0x8)
	struct TArray<struct APlayerBRController_C*> ALL_PC;  // 0x2E0(0x10)
	char pad_752_1 : 7;  // 0x2F0(0x1)
	bool Lobby? : 1;  // 0x2F0(0x1)
	char pad_753[3];  // 0x2F1(0x3)
	int32_t SpawnIndex;  // 0x2F4(0x4)
	struct FST_ServerSettings ServerSettings;  // 0x2F8(0x8)
	struct FMulticastInlineDelegate StartEvent;  // 0x300(0x10)
	char E_GameMode GameMode;  // 0x310(0x1)
	char pad_785[7];  // 0x311(0x7)
	struct TMap<struct APlayerBRController_C*, struct APlayerBRController_C*> TeamPairs;  // 0x318(0x50)
	struct TMap<struct APlayerController*, struct APlayerStart*> PlayerStarts;  // 0x368(0x50)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool UseSpawnBoxes? : 1;  // 0x3B8(0x1)
	char pad_953_1 : 7;  // 0x3B9(0x1)
	bool Restarting : 1;  // 0x3B9(0x1)
	char pad_954_1 : 7;  // 0x3BA(0x1)
	bool ROE_Spawn? : 1;  // 0x3BA(0x1)
	char pad_955[5];  // 0x3BB(0x5)
	struct TMap<struct FString, int32_t> LeaderBoardIDMap;  // 0x3C0(0x50)
	struct TMap<struct FString, int32_t> LeaderBoardIDMap_Release;  // 0x410(0x50)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool SafeToQuitServer : 1;  // 0x460(0x1)
	char pad_1121_1 : 7;  // 0x461(0x1)
	bool KickAllPlayersOnMatchEnd : 1;  // 0x461(0x1)
	char pad_1122[6];  // 0x462(0x6)
	struct TMap<struct FString, int32_t> PendingSteamIDLeaderboard+Score;  // 0x468(0x50)
	struct TMap<struct FString, int32_t> PendingSteamIDLeaderboardFinalScore;  // 0x4B8(0x50)

	void UpdateOfficialScoreForPendingSteamID(int32_t LeaderboardId, int32_t InitialScore, struct FString SteamID); // Function GM_BR.GM_BR_C.UpdateOfficialScoreForPendingSteamID
	void LeaderboardID_ToLeaderboardName(int32_t ID, struct FString& Name); // Function GM_BR.GM_BR_C.LeaderboardID_ToLeaderboardName
	void MakeRewardsItemArray(int32_t +Level, bool Won, struct TArray<int32_t>& Out); // Function GM_BR.GM_BR_C.MakeRewardsItemArray
	void ParseUserStatsJson(struct FString Json, int32_t& XP1, int32_t& Level1, int32_t& Matches1, int32_t& Wins1, int32_t& Kills1, int32_t& RP 1, struct FString& SteamID); // Function GM_BR.GM_BR_C.ParseUserStatsJson
	void F_SetupTeammates(); // Function GM_BR.GM_BR_C.F_SetupTeammates
	void SetGameMode(char E_GameMode GameMode); // Function GM_BR.GM_BR_C.SetGameMode
	void BalancePlayerStarts(struct TArray<struct APlayerStart*>& Array, struct TMap<struct APlayerController*, struct APlayerStart*>& Out); // Function GM_BR.GM_BR_C.BalancePlayerStarts
	void InProgress(bool& Bool); // Function GM_BR.GM_BR_C.InProgress
	void OnFailure_A0B7B5EF4D8A5F241D4C4C8EA7F59572(); // Function GM_BR.GM_BR_C.OnFailure_A0B7B5EF4D8A5F241D4C4C8EA7F59572
	void OnSuccess_A0B7B5EF4D8A5F241D4C4C8EA7F59572(); // Function GM_BR.GM_BR_C.OnSuccess_A0B7B5EF4D8A5F241D4C4C8EA7F59572
	void OnFailure_BB55049D4938F8C60C8B5DAF275493FE(); // Function GM_BR.GM_BR_C.OnFailure_BB55049D4938F8C60C8B5DAF275493FE
	void OnSuccess_BB55049D4938F8C60C8B5DAF275493FE(); // Function GM_BR.GM_BR_C.OnSuccess_BB55049D4938F8C60C8B5DAF275493FE
	void OnFailure_DA9504F84D4BE40451FFE5B290498C67(); // Function GM_BR.GM_BR_C.OnFailure_DA9504F84D4BE40451FFE5B290498C67
	void OnSuccess_DA9504F84D4BE40451FFE5B290498C67(); // Function GM_BR.GM_BR_C.OnSuccess_DA9504F84D4BE40451FFE5B290498C67
	void K2_PostLogin(struct APlayerController* NewPlayer); // Function GM_BR.GM_BR_C.K2_PostLogin
	void K2_OnLogout(struct AController* ExitingController); // Function GM_BR.GM_BR_C.K2_OnLogout
	void Start(); // Function GM_BR.GM_BR_C.Start
	void EndGame(struct TArray<struct APlayerBRController_C*>& Winners); // Function GM_BR.GM_BR_C.EndGame
	void DedicatedServerEndGame(); // Function GM_BR.GM_BR_C.DedicatedServerEndGame
	void ReceiveBeginPlay(); // Function GM_BR.GM_BR_C.ReceiveBeginPlay
	void MultiKillFeed(struct FString KIller, struct FString Killed); // Function GM_BR.GM_BR_C.MultiKillFeed
	void ReceiveTick(float DeltaSeconds); // Function GM_BR.GM_BR_C.ReceiveTick
	void SetupTeams(); // Function GM_BR.GM_BR_C.SetupTeams
	void SetServerTags(bool CanJoin?); // Function GM_BR.GM_BR_C.SetServerTags
	void SetTeammatesOnPlayers(); // Function GM_BR.GM_BR_C.SetTeammatesOnPlayers
	void LoadActorState(); // Function GM_BR.GM_BR_C.LoadActorState
	void ServerGiveCoupon(struct APlayerBRController_C* Controller); // Function GM_BR.GM_BR_C.ServerGiveCoupon
	void ServerGiveGoldenCoupon(struct APlayerBRController_C* Controller); // Function GM_BR.GM_BR_C.ServerGiveGoldenCoupon
	void ShowEndgameScreenForPlayers(struct TArray<struct APlayerBRController_C*>& Winners); // Function GM_BR.GM_BR_C.ShowEndgameScreenForPlayers
	void ServerWinnerLogic(struct APlayerBRController_C* Winner); // Function GM_BR.GM_BR_C.ServerWinnerLogic
	void AddPlayerToSpawnBox(struct FVector Spawn Loc, struct AFirstPersonCharacter_C* Player); // Function GM_BR.GM_BR_C.AddPlayerToSpawnBox
	void UpdateSessionInfo(); // Function GM_BR.GM_BR_C.UpdateSessionInfo
	void StartTagLoop(); // Function GM_BR.GM_BR_C.StartTagLoop
	void SpawnPlayersRandom(); // Function GM_BR.GM_BR_C.SpawnPlayersRandom
	void StartBattleRoyale(); // Function GM_BR.GM_BR_C.StartBattleRoyale
	void SpawnPlayersByStarts(struct TMap<struct APlayerController*, struct APlayerStart*> PlayerStarts); // Function GM_BR.GM_BR_C.SpawnPlayersByStarts
	void SpawnPlayerByTransform(struct APlayerBRController_C* Player, struct FTransform& InTransform); // Function GM_BR.GM_BR_C.SpawnPlayerByTransform
	void OnControllerLogin(struct APlayerBRController_C* Controller); // Function GM_BR.GM_BR_C.OnControllerLogin
	void XP + Stats for player(struct APlayerBRController_C* PC, bool Win?); // Function GM_BR.GM_BR_C.XP + Stats for player
	void OnGetUserStats(struct FString Data, bool bWasSuccessful); // Function GM_BR.GM_BR_C.OnGetUserStats
	void OnUserStatsUploaded(struct FString Data, bool bWasSuccessful); // Function GM_BR.GM_BR_C.OnUserStatsUploaded
	void SetPlayerLeaderboardScores(struct FString SteamID, int32_t New Kills, int32_t New Level, int32_t New Wins); // Function GM_BR.GM_BR_C.SetPlayerLeaderboardScores
	void Server_GetLeaderboards(); // Function GM_BR.GM_BR_C.Server_GetLeaderboards
	void OnReceivedLeaderboardIDs(struct FString Data, bool bWasSuccessful); // Function GM_BR.GM_BR_C.OnReceivedLeaderboardIDs
	void OnLeaderboardScoreSet(struct FString Data, bool bWasSuccessful); // Function GM_BR.GM_BR_C.OnLeaderboardScoreSet
	void Server_GivePlayerRewards(int32_t +Level, bool Won, struct FString SteamID); // Function GM_BR.GM_BR_C.Server_GivePlayerRewards
	void OnPlayerGiveItem(struct FString Data, bool bWasSuccessful); // Function GM_BR.GM_BR_C.OnPlayerGiveItem
	void ServerDoRankedStats(int32_t InitialRP, struct APlayerBRController_C* PC, struct FString SteamID); // Function GM_BR.GM_BR_C.ServerDoRankedStats
	void DebugRestartServer(); // Function GM_BR.GM_BR_C.DebugRestartServer
	void PreStart(); // Function GM_BR.GM_BR_C.PreStart
	void UpdateOfficialLeaderboardScore(struct FString SteamID, struct FString LeaderboardName, int32_t +Score); // Function GM_BR.GM_BR_C.UpdateOfficialLeaderboardScore
	void KickAndBan(struct FString SteamID, struct APlayerBRController_C* PC); // Function GM_BR.GM_BR_C.KickAndBan
	void SetServerTags_New(bool CanJoin); // Function GM_BR.GM_BR_C.SetServerTags_New
	void OnGetLeaderboardEntries(struct FString Data, bool bWasSuccessful); // Function GM_BR.GM_BR_C.OnGetLeaderboardEntries
	void SetOfficialLeaderboardScore(struct FString SteamID, struct FString LeaderboardName, int32_t Score); // Function GM_BR.GM_BR_C.SetOfficialLeaderboardScore
	void OnSetOfficialLeaderboardScore(struct FString Data, bool bWasSuccessful); // Function GM_BR.GM_BR_C.OnSetOfficialLeaderboardScore
	void ServerValidate+Level(int32_t +Level, struct APlayerBRController_C* PC); // Function GM_BR.GM_BR_C.ServerValidate+Level
	void ExecuteUbergraph_GM_BR(int32_t EntryPoint); // Function GM_BR.GM_BR_C.ExecuteUbergraph_GM_BR
	void StartEvent__DelegateSignature(); // Function GM_BR.GM_BR_C.StartEvent__DelegateSignature
}; 



