#pragma once 
#include "SDK.h" 
 
 
// Function BP_Placable.BP_Placable_C.UserConstructionScript
// Size: 0x1(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x0(0x1)

}; 
