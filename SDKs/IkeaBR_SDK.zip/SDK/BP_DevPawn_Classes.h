#pragma once 
#include <BP_DevPawn_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_DevPawn.BP_DevPawn_C
// Size: 0x2A4(Inherited: 0x280) 
struct ABP_DevPawn_C : public APawn
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x288(0x8)
	struct UCameraComponent* Camera1;  // 0x290(0x8)
	struct UFloatingPawnMovement* FloatingPawnMovement;  // 0x298(0x8)
	float Sensitivity;  // 0x2A0(0x4)

	void InpActEvt_Debug_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_DevPawn.BP_DevPawn_C.InpActEvt_Debug_K2Node_InputActionEvent_1
	void ReceiveBeginPlay(); // Function BP_DevPawn.BP_DevPawn_C.ReceiveBeginPlay
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
	void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
	void InpAxisEvt_Turn_K2Node_InputAxisEvent_158(float AxisValue); // Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_158
	void InpAxisEvt_LookUp_K2Node_InputAxisEvent_173(float AxisValue); // Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_173
	void ReceiveTick(float DeltaSeconds); // Function BP_DevPawn.BP_DevPawn_C.ReceiveTick
	void ExecuteUbergraph_BP_DevPawn(int32_t EntryPoint); // Function BP_DevPawn.BP_DevPawn_C.ExecuteUbergraph_BP_DevPawn
}; 



