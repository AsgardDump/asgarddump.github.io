#pragma once 
#include "SDK.h" 
 
 
// Function BP_PlayerPreview.BP_PlayerPreview_C.ExecuteUbergraph_BP_PlayerPreview
// Size: 0x189(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PlayerPreview
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x40(0xC)
	char pad_76[4];  // 0x4C(0x4)
	struct USkeletalMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x50(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x58(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x5C(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x60(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x64(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x68(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x6C(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x70(0x4)
	char pad_116[4];  // 0x74(0x4)
	struct TArray<struct FST_Cosmetic> K2Node_CustomEvent_Array;  // 0x78(0x10)
	struct FST_Cosmetic CallFunc_Array_Get_Item;  // 0x88(0x50)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xD8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0xDC(0x4)
	struct TSoftObjectPtr<UMaterialInterface> CallFunc_Array_Get_Item_2;  // 0xE0(0x28)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct UMaterialInterface* K2Node_DynamicCast_AsMaterial_Interface;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x124(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue_2;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct USkeletalMesh* K2Node_DynamicCast_AsSkeletal_Mesh;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x148(0x1)
	char pad_329[3];  // 0x149(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x14C(0x4)
	struct USkeletalMeshComponent* CallFunc_Array_Get_Item_3;  // 0x150(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x158(0x4)
	char pad_348_1 : 7;  // 0x15C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x15C(0x1)
	char pad_349[3];  // 0x15D(0x3)
	struct TArray<struct FST_Cosmetic> CallFunc_StringsToCosmetics_cos;  // 0x160(0x10)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x170(0xC)
	struct FRotator CallFunc_RLerp_ReturnValue;  // 0x17C(0xC)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool CallFunc_K2_SetActorRotation_ReturnValue : 1;  // 0x188(0x1)

}; 
// Function BP_PlayerPreview.BP_PlayerPreview_C.UpdateCosmetics
// Size: 0x10(Inherited: 0x0) 
struct FUpdateCosmetics
{
	struct TArray<struct FST_Cosmetic> Array;  // 0x0(0x10)

}; 
