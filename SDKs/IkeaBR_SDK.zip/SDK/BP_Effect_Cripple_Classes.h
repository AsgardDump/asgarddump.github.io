#pragma once 
#include <BP_Effect_Cripple_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Effect_Cripple.BP_Effect_Cripple_C
// Size: 0x2B8(Inherited: 0x2B0) 
struct ABP_Effect_Cripple_C : public ABP_Effect_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B0(0x8)

	void Event On(); // Function BP_Effect_Cripple.BP_Effect_Cripple_C.Event On
	void Event Reset(); // Function BP_Effect_Cripple.BP_Effect_Cripple_C.Event Reset
	void Event Off(); // Function BP_Effect_Cripple.BP_Effect_Cripple_C.Event Off
	void ExecuteUbergraph_BP_Effect_Cripple(int32_t EntryPoint); // Function BP_Effect_Cripple.BP_Effect_Cripple_C.ExecuteUbergraph_BP_Effect_Cripple
}; 



