#pragma once 
#include "SDK.h" 
 
 
// Function BPI_Interact.BPI_Interact_C.RecieveServerLook
// Size: 0x1(Inherited: 0x0) 
struct FRecieveServerLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Recieve? : 1;  // 0x0(0x1)

}; 
// Function BPI_Interact.BPI_Interact_C.OnInteract
// Size: 0x94(Inherited: 0x0) 
struct FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
// Function BPI_Interact.BPI_Interact_C.OnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function BPI_Interact.BPI_Interact_C.OnLook
// Size: 0x8(Inherited: 0x0) 
struct FOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function BPI_Interact.BPI_Interact_C.OnChargeUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOnChargeUpdate
{
	float Charge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Caller;  // 0x8(0x8)

}; 
// Function BPI_Interact.BPI_Interact_C.ServerOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnStopLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BPI_Interact.BPI_Interact_C.ServerOnLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
