#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction EventDispatcher.BoolEventDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBoolEventDelegate__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function EventDispatcher.EventManager.RegisterPayloadEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterPayloadEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// DelegateFunction EventDispatcher.FloatEventDelegate__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FFloatEventDelegate__DelegateSignature
{
	float Value;  // 0x0(0x4)

}; 
// Function EventDispatcher.EventManager.UnregisterEvent
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)

}; 
// DelegateFunction EventDispatcher.PayloadEventDelegate__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FPayloadEventDelegate__DelegateSignature
{
	struct UObject* Payload;  // 0x0(0x8)

}; 
// DelegateFunction EventDispatcher.StringEventDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FStringEventDelegate__DelegateSignature
{
	struct FString String;  // 0x0(0x10)

}; 
// DelegateFunction EventDispatcher.IntEventDelegate__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FIntEventDelegate__DelegateSignature
{
	int32_t Value;  // 0x0(0x4)

}; 
// ScriptStruct EventDispatcher.StringFloat
// Size: 0x18(Inherited: 0x0) 
struct FStringFloat
{
	struct FString String;  // 0x0(0x10)
	float Float;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function EventDispatcher.EventManager.RegisterPayloadEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterPayloadEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// DelegateFunction EventDispatcher.VectorEventDelegate__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FVectorEventDelegate__DelegateSignature
{
	struct FVector Data;  // 0x0(0xC)

}; 
// DelegateFunction EventDispatcher.StringFloatEventDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FStringFloatEventDelegate__DelegateSignature
{
	struct FStringFloat Data;  // 0x0(0x18)

}; 
// Function EventDispatcher.EventManager.RegisterFloatEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterFloatEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// DelegateFunction EventDispatcher.StringIntEventDelegate__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FStringIntEventDelegate__DelegateSignature
{
	struct FStringInt Data;  // 0x0(0x18)

}; 
// ScriptStruct EventDispatcher.StringInt
// Size: 0x18(Inherited: 0x0) 
struct FStringInt
{
	struct FString String;  // 0x0(0x10)
	int32_t Value;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function EventDispatcher.EventManager.DebugEventManager
// Size: 0x8(Inherited: 0x0) 
struct FDebugEventManager
{
	struct UObject* worldContextObject;  // 0x0(0x8)

}; 
// Function EventDispatcher.EventManager.InvokeBoolEvent
// Size: 0x20(Inherited: 0x0) 
struct FInvokeBoolEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function EventDispatcher.EventManager.InvokeBoolEventName
// Size: 0x28(Inherited: 0x0) 
struct FInvokeBoolEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function EventDispatcher.EventManager.InvokeFloatEvent
// Size: 0x20(Inherited: 0x0) 
struct FInvokeFloatEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	float Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function EventDispatcher.EventManager.InvokeFloatEventName
// Size: 0x28(Inherited: 0x0) 
struct FInvokeFloatEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	float Value;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function EventDispatcher.EventManager.InvokeIntEvent
// Size: 0x20(Inherited: 0x0) 
struct FInvokeIntEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	int32_t Value;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function EventDispatcher.EventManager.InvokeIntEventName
// Size: 0x28(Inherited: 0x0) 
struct FInvokeIntEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	int32_t Value;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function EventDispatcher.EventManager.InvokePayloadEvent
// Size: 0x20(Inherited: 0x0) 
struct FInvokePayloadEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	struct UObject* Payload;  // 0x18(0x8)

}; 
// Function EventDispatcher.EventManager.InvokePayloadEventName
// Size: 0x28(Inherited: 0x0) 
struct FInvokePayloadEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	struct UObject* Payload;  // 0x20(0x8)

}; 
// Function EventDispatcher.EventManager.RegisterVectorEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterVectorEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterStringIntEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterStringIntEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.InvokeStringFloatEventName
// Size: 0x38(Inherited: 0x0) 
struct FInvokeStringFloatEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	struct FStringFloat Data;  // 0x20(0x18)

}; 
// Function EventDispatcher.EventManager.InvokeSimpleEvent
// Size: 0x18(Inherited: 0x0) 
struct FInvokeSimpleEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)

}; 
// Function EventDispatcher.EventManager.RegisterVectorEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterVectorEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterStringIntEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterStringIntEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.InvokeStringFloatEvent
// Size: 0x30(Inherited: 0x0) 
struct FInvokeStringFloatEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	struct FStringFloat Data;  // 0x18(0x18)

}; 
// Function EventDispatcher.EventManager.InvokeSimpleEventName
// Size: 0x20(Inherited: 0x0) 
struct FInvokeSimpleEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterBoolEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterBoolEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.InvokeStringEvent
// Size: 0x28(Inherited: 0x0) 
struct FInvokeStringEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	struct FString String;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterBoolEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterBoolEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.InvokeStringEventName
// Size: 0x30(Inherited: 0x0) 
struct FInvokeStringEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	struct FString String;  // 0x20(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterStringEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterStringEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.InvokeStringIntEvent
// Size: 0x30(Inherited: 0x0) 
struct FInvokeStringIntEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	struct FStringInt Data;  // 0x18(0x18)

}; 
// Function EventDispatcher.EventManager.RegisterStringEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterStringEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.InvokeStringIntEventName
// Size: 0x38(Inherited: 0x0) 
struct FInvokeStringIntEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	struct FStringInt Data;  // 0x20(0x18)

}; 
// Function EventDispatcher.EventManager.InvokeVectorEvent
// Size: 0x28(Inherited: 0x0) 
struct FInvokeVectorEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x10(0x8)
	struct FVector Data;  // 0x18(0xC)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function EventDispatcher.EventManager.InvokeVectorEventName
// Size: 0x30(Inherited: 0x0) 
struct FInvokeVectorEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UObject* OptionalTarget;  // 0x8(0x8)
	struct FString EventIdentifier;  // 0x10(0x10)
	struct FVector Data;  // 0x20(0xC)
	char pad_44[4];  // 0x2C(0x4)

}; 
// Function EventDispatcher.EventManager.RegisterFloatEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterFloatEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterIntEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterIntEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterIntEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterIntEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterSimpleEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterSimpleEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterSimpleEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterSimpleEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterStringFloatEvent
// Size: 0x20(Inherited: 0x0) 
struct FRegisterStringFloatEvent
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct UEventIdentifier* EventIdentifier;  // 0x8(0x8)
	struct FDelegate Callback;  // 0x10(0x10)

}; 
// Function EventDispatcher.EventManager.RegisterStringFloatEventName
// Size: 0x28(Inherited: 0x0) 
struct FRegisterStringFloatEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)
	struct FDelegate Callback;  // 0x18(0x10)

}; 
// Function EventDispatcher.EventManager.UnregisterEventName
// Size: 0x18(Inherited: 0x0) 
struct FUnregisterEventName
{
	struct UObject* worldContextObject;  // 0x0(0x8)
	struct FString EventIdentifier;  // 0x8(0x10)

}; 
// Function EventDispatcher.EventManager.UnregisterEvents
// Size: 0x8(Inherited: 0x0) 
struct FUnregisterEvents
{
	struct UObject* worldContextObject;  // 0x0(0x8)

}; 
