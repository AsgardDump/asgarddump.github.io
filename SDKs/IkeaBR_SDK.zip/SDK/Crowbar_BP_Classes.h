#pragma once 
#include <Crowbar_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Crowbar_BP.Crowbar_BP_C
// Size: 0x298(Inherited: 0x290) 
struct ACrowbar_BP_C : public AWeaponBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)

	void ExecuteUbergraph_Crowbar_BP(int32_t EntryPoint); // Function Crowbar_BP.Crowbar_BP_C.ExecuteUbergraph_Crowbar_BP
}; 



