#pragma once 
#include <BoxCutter_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass BoxCutter_BP.BoxCutter_BP_C
// Size: 0x290(Inherited: 0x290) 
struct ABoxCutter_BP_C : public AWeaponBP_C
{

}; 



