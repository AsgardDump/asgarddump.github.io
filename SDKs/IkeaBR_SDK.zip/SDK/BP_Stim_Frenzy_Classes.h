#pragma once 
#include <BP_Stim_Frenzy_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Stim_Frenzy.BP_Stim_Frenzy_C
// Size: 0x278(Inherited: 0x268) 
struct ABP_Stim_Frenzy_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	float Duration;  // 0x270(0x4)
	int32_t CurrentSlot;  // 0x274(0x4)

	void LMB(bool Down); // Function BP_Stim_Frenzy.BP_Stim_Frenzy_C.LMB
	void ExecuteUbergraph_BP_Stim_Frenzy(int32_t EntryPoint); // Function BP_Stim_Frenzy.BP_Stim_Frenzy_C.ExecuteUbergraph_BP_Stim_Frenzy
}; 



