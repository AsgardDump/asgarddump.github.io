#pragma once 
#include "SDK.h" 
 
 
// Function DB_Recipie.DB_Recipie_C.ExecuteUbergraph_DB_Recipie
// Size: 0x399(Inherited: 0x0) 
struct FExecuteUbergraph_DB_Recipie
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USaveGame* Temp_object_Variable;  // 0x8(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_4;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_CustomEvent_bSuccess_4 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct USaveGame* Temp_object_Variable_2;  // 0x30(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct USaveGame* K2Node_CustomEvent_SaveGame_3;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_CustomEvent_bSuccess_3 : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x54(0x10)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	struct USaveGame* Temp_object_Variable_3;  // 0x68(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_CustomEvent_bSuccess_2 : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x7C(0x10)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct USaveGame* Temp_object_Variable_4;  // 0x90(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_2;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0xA1(0x1)
	char pad_162[6];  // 0xA2(0x6)
	struct USaveGame* K2Node_CustomEvent_SaveGame;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_CustomEvent_bSuccess : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0xB4(0x10)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	struct USaveGame* Temp_object_Variable_5;  // 0xC8(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_3;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0xE0(0x8)
	struct TArray<struct FST_UndiscoveredItem> CallFunc_GetUndiscoveredItems_Items;  // 0xE8(0x10)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0xF8(0x1)
	char pad_249[3];  // 0xF9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xFC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x100(0x4)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x104(0x1)
	char pad_261[3];  // 0x105(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x108(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x10C(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_5;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_CustomEvent_bSuccess_5 : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)
	struct FST_UndiscoveredItem CallFunc_Array_Get_Item;  // 0x120(0x30)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0x158(0x8)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_2;  // 0x160(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0x168(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue;  // 0x178(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x180(0x10)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1A0(0x1)
	char pad_417_1 : 7;  // 0x1A1(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x1A1(0x1)
	char pad_418[6];  // 0x1A2(0x6)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_2;  // 0x1A8(0x8)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_3;  // 0x1B0(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_2;  // 0x1B8(0x10)
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_2 : 1;  // 0x1C8(0x1)
	char pad_457[7];  // 0x1C9(0x7)
	struct USaveGame* K2Node_Select_Default;  // 0x1D0(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_2;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1E0(0x1)
	char pad_481[7];  // 0x1E1(0x7)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x1E8(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x1F8(0x8)
	struct FST_CraftRecipe CallFunc_GetDataTableRowFromName_OutRow;  // 0x200(0x28)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x228(0x1)
	char pad_553[7];  // 0x229(0x7)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x230(0x90)
	struct FGeometry K2Node_Event_MyGeometry;  // 0x2C0(0x38)
	float K2Node_Event_InDeltaTime;  // 0x2F8(0x4)
	struct FLinearColor CallFunc_TierColor_color;  // 0x2FC(0x10)
	char pad_780[4];  // 0x30C(0x4)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_3;  // 0x310(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_3;  // 0x318(0x10)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x328(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_3;  // 0x338(0x8)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0x340(0x1)
	char pad_833_1 : 7;  // 0x341(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x341(0x1)
	char pad_834_1 : 7;  // 0x342(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x342(0x1)
	char pad_835[5];  // 0x343(0x5)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_2;  // 0x348(0x8)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x350(0x1)
	char pad_849_1 : 7;  // 0x351(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_3 : 1;  // 0x351(0x1)
	char pad_850[6];  // 0x352(0x6)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x358(0x10)
	struct FST_UndiscoveredItem K2Node_MakeStruct_ST_UndiscoveredItem;  // 0x368(0x30)
	char pad_920_1 : 7;  // 0x398(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x398(0x1)

}; 
// Function DB_Recipie.DB_Recipie_C.Completed_215CB37D43646A0095BC739773FE2E90
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC739773FE2E90
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Recipie.DB_Recipie_C.Tick
// Size: 0x3C(Inherited: 0x3C) 
struct FTick : public FTick
{
	struct FGeometry MyGeometry;  // 0x0(0x38)
	float InDeltaTime;  // 0x38(0x4)

}; 
// Function DB_Recipie.DB_Recipie_C.Completed_6F07F8864F50B817CAEDB38561E646DC
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB38561E646DC
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Recipie.DB_Recipie_C.Completed_0914B3504C491F3C20AD179670FD4FF1
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_0914B3504C491F3C20AD179670FD4FF1
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Recipie.DB_Recipie_C.Completed_215CB37D43646A0095BC739780A98E07
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC739780A98E07
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Recipie.DB_Recipie_C.GetBrush_1
// Size: 0x1E8(Inherited: 0x0) 
struct FGetBrush_1
{
	struct FSlateBrush ReturnValue;  // 0x0(0x88)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x88(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x98(0x8)
	struct FST_CraftRecipe CallFunc_GetDataTableRowFromName_OutRow;  // 0xA0(0x28)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0xD0(0x90)
	struct FSlateBrush CallFunc_MakeBrushFromTexture_ReturnValue;  // 0x160(0x88)

}; 
// Function DB_Recipie.DB_Recipie_C.Completed_6F07F8864F50B817CAEDB38592B1E64B
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB38592B1E64B
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function DB_Recipie.DB_Recipie_C.GetbIsEnabled_1
// Size: 0x1(Inherited: 0x0) 
struct FGetbIsEnabled_1
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function DB_Recipie.DB_Recipie_C.Get_ItemName_Text_1
// Size: 0x108(Inherited: 0x0) 
struct FGet_ItemName_Text_1
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x18(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x28(0x8)
	struct FST_CraftRecipe CallFunc_GetDataTableRowFromName_OutRow;  // 0x30(0x28)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x60(0x90)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0xF0(0x18)

}; 
