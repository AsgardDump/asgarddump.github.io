#pragma once 
#include <BP_StimBase_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_StimBase.BP_StimBase_C
// Size: 0x280(Inherited: 0x268) 
struct ABP_StimBase_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	struct FString Effect;  // 0x270(0x10)

	void LMB(bool Down); // Function BP_StimBase.BP_StimBase_C.LMB
	void ExecuteUbergraph_BP_StimBase(int32_t EntryPoint); // Function BP_StimBase.BP_StimBase_C.ExecuteUbergraph_BP_StimBase
}; 



