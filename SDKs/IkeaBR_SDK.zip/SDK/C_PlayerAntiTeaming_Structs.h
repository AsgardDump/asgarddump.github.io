#pragma once 
#include "SDK.h" 
 
 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.OnNewRemoteTeamerDetected__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnNewRemoteTeamerDetected__DelegateSignature
{
	struct FST_TeamingStats Teamer;  // 0x0(0x20)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ExecuteUbergraph_C_PlayerAntiTeaming
// Size: 0x1A1(Inherited: 0x0) 
struct FExecuteUbergraph_C_PlayerAntiTeaming
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0x8(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x2C(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x30(0x8)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_RemotePlayer;  // 0x38(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x4C(0xC)
	int32_t CallFunc_FindRemotePlayerInMap_Index;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_Is_Teamer_Valid_valid : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x60(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x74(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x78(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_DamagedTarget_2;  // 0x88(0x8)
	float K2Node_CustomEvent_Damage_2;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_DamagedTarget;  // 0x98(0x8)
	float K2Node_CustomEvent_Damage;  // 0xA0(0x4)
	int32_t CallFunc_FindRemotePlayerInMap_Index_2;  // 0xA4(0x4)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_2;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xC1(0x1)
	char pad_194[2];  // 0xC2(0x2)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xC4(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xC8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xCC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0xD8(0x10)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item;  // 0xE8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xF0(0x10)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_Is_Teamer_Valid_valid_2 : 1;  // 0x100(0x1)
	char pad_257[3];  // 0x101(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x104(0x4)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x10C(0x4)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct FST_TeamingStats CallFunc_Array_Get_Item_2;  // 0x118(0x20)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x138(0x4)
	float CallFunc_GetProbabiltyOfTeaming_ProbabiltyScore;  // 0x13C(0x4)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x140(0x1)
	char pad_321_1 : 7;  // 0x141(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x141(0x1)
	char pad_322[2];  // 0x142(0x2)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x144(0x4)
	struct FST_TeamingStats K2Node_CustomEvent_Teamer;  // 0x148(0x20)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x168(0x10)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x178(0x1)
	char pad_377_1 : 7;  // 0x179(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0x179(0x1)
	char pad_378[6];  // 0x17A(0x6)
	struct FString K2Node_CustomEvent_SteamID;  // 0x180(0x10)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x190(0x8)
	struct AGM_BR_C* K2Node_DynamicCast_AsGM_BR;  // 0x198(0x8)
	char pad_416_1 : 7;  // 0x1A0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1A0(0x1)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.GetProbabiltyOfTeaming
// Size: 0xCC(Inherited: 0x0) 
struct FGetProbabiltyOfTeaming
{
	struct FST_TeamingStats TeamingStats;  // 0x0(0x20)
	float ProbabiltyScore;  // 0x20(0x4)
	float DistanceTravelledTogether;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool AreSteamFriends? : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float Temp_float_Variable;  // 0x2C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x34(0x4)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x44(0x4)
	struct FVector CallFunc_Array_Get_Item;  // 0x48(0xC)
	char pad_84[4];  // 0x54(0x4)
	struct FSteamID CallFunc_MakeSteamID_ReturnValue;  // 0x58(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	struct FVector CallFunc_Array_Get_Item_2;  // 0x68(0xC)
	float CallFunc_Vector_Distance_ReturnValue;  // 0x74(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool Temp_bool_Variable : 1;  // 0x7C(0x1)
	char pad_125_1 : 7;  // 0x7D(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7D(0x1)
	char pad_126[2];  // 0x7E(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x80(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x84(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x88(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x8C(0x4)
	float K2Node_Select_Default;  // 0x90(0x4)
	float CallFunc_FMin_ReturnValue;  // 0x94(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x98(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x9C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct TArray<uint8_t > K2Node_MakeArray_Array;  // 0xA8(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_HasFriend_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xC0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0xC4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0xC8(0x4)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerUploadAsPossiblyTeaming
// Size: 0x10(Inherited: 0x0) 
struct FServerUploadAsPossiblyTeaming
{
	struct FString SteamID;  // 0x0(0x10)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.OnDamageSomeone
// Size: 0xC(Inherited: 0x0) 
struct FOnDamageSomeone
{
	struct AFirstPersonCharacter_C* DamagedTarget;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.OnNewRemoteTeamerDetected_Event
// Size: 0x20(Inherited: 0x0) 
struct FOnNewRemoteTeamerDetected_Event
{
	struct FST_TeamingStats Teamer;  // 0x0(0x20)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerOnDamageSomeone
// Size: 0xC(Inherited: 0x0) 
struct FServerOnDamageSomeone
{
	struct AFirstPersonCharacter_C* DamagedTarget;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ServerGenTeamingStatsForPlayer
// Size: 0x8(Inherited: 0x0) 
struct FServerGenTeamingStatsForPlayer
{
	struct AFirstPersonCharacter_C* RemotePlayer;  // 0x0(0x8)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.FindRemotePlayerInMap
// Size: 0x76(Inherited: 0x0) 
struct FFindRemotePlayerInMap
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)
	int32_t Index;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	struct TArray<struct FVector> K2Node_MakeArray_Array;  // 0x18(0x10)
	struct FST_TeamingStats K2Node_MakeStruct_ST_TeamingStats;  // 0x28(0x20)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FST_TeamingStats CallFunc_Array_Get_Item;  // 0x50(0x20)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x70(0x4)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x75(0x1)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.ClientOnUpdatedRemoteCriticalTeamers
// Size: 0x93(Inherited: 0x0) 
struct FClientOnUpdatedRemoteCriticalTeamers
{
	struct FST_TeamingStats NewTeamer;  // 0x0(0x20)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Found? : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x38(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x3C(0x4)
	struct FST_TeamingStats CallFunc_Array_Get_Item;  // 0x40(0x20)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x68(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x6C(0x4)
	struct FST_TeamingStats CallFunc_Array_Get_Item_2;  // 0x70(0x20)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x92(0x1)

}; 
// Function C_PlayerAntiTeaming.C_PlayerAntiTeaming_C.Is Teamer Valid
// Size: 0x33(Inherited: 0x0) 
struct FIs Teamer Valid
{
	struct AFirstPersonCharacter_C* Remote;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Valid : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_StringIsEmpty_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct FSteamID CallFunc_MakeSteamID_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_5 : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x2F(0x1)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0x32(0x1)

}; 
