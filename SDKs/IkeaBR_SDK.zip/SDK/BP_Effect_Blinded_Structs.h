#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Blinded.BP_Effect_Blinded_C.ExecuteUbergraph_BP_Effect_Blinded
// Size: 0x44(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Blinded
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct UBlindScreen_C* CallFunc_Create_ReturnValue;  // 0x30(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x38(0xC)

}; 
