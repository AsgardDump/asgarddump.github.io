#pragma once 
#include "SDK.h" 
 
 
// Function CustomGames_CreateGame.CustomGames_CreateGame_C.Get_PasswordTextBox_Visibility_1
// Size: 0x6(Inherited: 0x0) 
struct FGet_PasswordTextBox_Visibility_1
{
	uint8_t  ReturnValue;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	uint8_t  Temp_byte_Variable;  // 0x2(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x4(0x1)
	uint8_t  K2Node_Select_Default;  // 0x5(0x1)

}; 
// Function CustomGames_CreateGame.CustomGames_CreateGame_C.ExecuteUbergraph_CustomGames_CreateGame
// Size: 0x9B(Inherited: 0x0) 
struct FExecuteUbergraph_CustomGames_CreateGame
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsReleaseMode_value : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC(0x1)
	char E_GameMode Temp_byte_Variable;  // 0xD(0x1)
	char E_GameMode Temp_byte_Variable_2;  // 0xE(0x1)
	char E_GameMode Temp_byte_Variable_3;  // 0xF(0x1)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR;  // 0x10(0x8)
	struct FText CallFunc_GetText_ReturnValue;  // 0x18(0x18)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsChecked_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x38(0x10)
	int32_t CallFunc_GetSelectedIndex_ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct FText CallFunc_GetText_ReturnValue_2;  // 0x50(0x18)
	struct FString CallFunc_Conv_TextToString_ReturnValue_2;  // 0x68(0x10)
	char E_GameMode K2Node_Select_Default;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct TArray<struct ABP_MenuBackQueue_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x80(0x10)
	struct ABP_MenuBackQueue_C* CallFunc_Array_Get_Item;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_RemoveOption_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_IsDev_Value : 1;  // 0x99(0x1)
	char pad_154_1 : 7;  // 0x9A(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x9A(0x1)

}; 
