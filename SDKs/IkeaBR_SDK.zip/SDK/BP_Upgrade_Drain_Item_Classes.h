#pragma once 
#include <BP_Upgrade_Drain_Item_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Upgrade_Drain_Item.BP_Upgrade_Drain_Item_C
// Size: 0x270(Inherited: 0x270) 
struct ABP_Upgrade_Drain_Item_C : public ABP_UpgradeItem_C
{

}; 



