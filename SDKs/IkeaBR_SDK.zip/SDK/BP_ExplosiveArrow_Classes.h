#pragma once 
#include <BP_ExplosiveArrow_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ExplosiveArrow.BP_ExplosiveArrow_C
// Size: 0x278(Inherited: 0x257) 
struct ABP_ExplosiveArrow_C : public ABP_Projectile_C
{
	char pad_599[1];  // 0x257(0x1)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x258(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x260(0x8)
	struct UAudioComponent* Audio;  // 0x268(0x8)
	float ProjectileSpeed;  // 0x270(0x4)
	float DelayToExplosion;  // 0x274(0x4)

	void UserConstructionScript(); // Function BP_ExplosiveArrow.BP_ExplosiveArrow_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_ExplosiveArrow.BP_ExplosiveArrow_C.ReceiveBeginPlay
	void Hit(struct AActor* other actor, struct FHitResult& HitResult); // Function BP_ExplosiveArrow.BP_ExplosiveArrow_C.Hit
	void ExecuteUbergraph_BP_ExplosiveArrow(int32_t EntryPoint); // Function BP_ExplosiveArrow.BP_ExplosiveArrow_C.ExecuteUbergraph_BP_ExplosiveArrow
}; 



