#pragma once 
#include <C_RandomDeckManager_Structs.h>
 
 
 
// BlueprintGeneratedClass C_RandomDeckManager.C_RandomDeckManager_C
// Size: 0xC0(Inherited: 0xB0) 
struct UC_RandomDeckManager_C : public UActorComponent
{
	struct TArray<struct FST_RandomDeck> Decks;  // 0xB0(0x10)

	void GenDeck(struct TMap<int32_t, int32_t> ValueWeightMap, struct TArray<int32_t>& Deck); // Function C_RandomDeckManager.C_RandomDeckManager_C.GenDeck
	void GetDeckValue(struct FString DeckName, struct TMap<int32_t, int32_t> ValueWeightMap, int32_t& Value); // Function C_RandomDeckManager.C_RandomDeckManager_C.GetDeckValue
}; 



