#pragma once 
#include <FireExtinguisher_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass FireExtinguisher_BP.FireExtinguisher_BP_C
// Size: 0x281(Inherited: 0x268) 
struct AFireExtinguisher_BP_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	struct UCapsuleComponent* Capsule;  // 0x270(0x8)
	struct USceneComponent* Scene;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool Active : 1;  // 0x280(0x1)

	void LMB(bool Down); // Function FireExtinguisher_BP.FireExtinguisher_BP_C.LMB
	void BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function FireExtinguisher_BP.FireExtinguisher_BP_C.BndEvt__Capsule_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
	void Unequip(); // Function FireExtinguisher_BP.FireExtinguisher_BP_C.Unequip
	void ReceiveDestroyed(); // Function FireExtinguisher_BP.FireExtinguisher_BP_C.ReceiveDestroyed
	void ExecuteUbergraph_FireExtinguisher_BP(int32_t EntryPoint); // Function FireExtinguisher_BP.FireExtinguisher_BP_C.ExecuteUbergraph_FireExtinguisher_BP
}; 



