#pragma once 
#include "SDK.h" 
 
 
// Function DB_ItemCost.DB_ItemCost_C.ExecuteUbergraph_DB_ItemCost
// Size: 0xB0(Inherited: 0x0) 
struct FExecuteUbergraph_DB_ItemCost
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x18(0x10)
	struct FName CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FST_CraftRecipe CallFunc_GetDataTableRowFromName_OutRow;  // 0x38(0x28)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x62(0x1)
	char pad_99_1 : 7;  // 0x63(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x63(0x1)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x64(0x1)
	char pad_101_1 : 7;  // 0x65(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // 0x65(0x1)
	char pad_102_1 : 7;  // 0x66(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x66(0x1)
	char pad_103[1];  // 0x67(0x1)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x68(0x8)
	struct UDB_MaterialCost_C* CallFunc_Create_ReturnValue;  // 0x70(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_2;  // 0x78(0x8)
	struct UDB_MaterialCost_C* CallFunc_Create_ReturnValue_2;  // 0x80(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue;  // 0x88(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_2;  // 0x90(0x8)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue_3;  // 0x98(0x8)
	struct UDB_MaterialCost_C* CallFunc_Create_ReturnValue_3;  // 0xA0(0x8)
	struct UPanelSlot* CallFunc_AddChild_ReturnValue_3;  // 0xA8(0x8)

}; 
