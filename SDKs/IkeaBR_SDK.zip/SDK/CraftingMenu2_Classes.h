#pragma once 
#include <CraftingMenu2_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass CraftingMenu2.CraftingMenu2_C
// Size: 0x2FC(Inherited: 0x260) 
struct UCraftingMenu2_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UCanvasPanel* CanvasPanel_42;  // 0x268(0x8)
	struct UHorizontalBox* Costs;  // 0x270(0x8)
	struct UImage* Image;  // 0x278(0x8)
	struct UImage* Image_61;  // 0x280(0x8)
	struct UTextBlock* TextBlock;  // 0x288(0x8)
	struct TArray<struct FST_CraftRecipe> Recipies;  // 0x290(0x10)
	float Radius;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct TArray<struct UWidget*> Craft Widgets;  // 0x2A8(0x10)
	struct FST_CraftRecipe SelectedRecipe;  // 0x2B8(0x28)
	struct AFirstPersonCharacter_C* Owner;  // 0x2E0(0x8)
	char pad_744_1 : 7;  // 0x2E8(0x1)
	bool Workbench : 1;  // 0x2E8(0x1)
	char pad_745[7];  // 0x2E9(0x7)
	struct AWorkbench_C* WorkbenchActor;  // 0x2F0(0x8)
	float Bounds;  // 0x2F8(0x4)

	struct FLinearColor GetColorAndOpacity_4(); // Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_4
	struct FSlateBrush GetBrush_1(); // Function CraftingMenu2.CraftingMenu2_C.GetBrush_1
	void sortRecipies(struct TArray<struct FST_CraftRecipe>& In, struct TArray<struct FST_CraftRecipe>& Out); // Function CraftingMenu2.CraftingMenu2_C.sortRecipies
	struct FText GetText_4(); // Function CraftingMenu2.CraftingMenu2_C.GetText_4
	struct FSlateColor GetColorAndOpacity_3(); // Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_3
	struct FSlateColor GetColorAndOpacity_2(); // Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_2
	struct FSlateColor GetColorAndOpacity_1(); // Function CraftingMenu2.CraftingMenu2_C.GetColorAndOpacity_1
	struct FText GetText_3(); // Function CraftingMenu2.CraftingMenu2_C.GetText_3
	struct FText GetText_2(); // Function CraftingMenu2.CraftingMenu2_C.GetText_2
	struct FText GetText_1(); // Function CraftingMenu2.CraftingMenu2_C.GetText_1
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function CraftingMenu2.CraftingMenu2_C.Tick
	void Destruct(); // Function CraftingMenu2.CraftingMenu2_C.Destruct
	void Click(); // Function CraftingMenu2.CraftingMenu2_C.Click
	void RecipeSelected(struct FST_CraftRecipe Recipe); // Function CraftingMenu2.CraftingMenu2_C.RecipeSelected
	void OnInteractPure_Event_1(); // Function CraftingMenu2.CraftingMenu2_C.OnInteractPure_Event_1
	void Create(); // Function CraftingMenu2.CraftingMenu2_C.Create
	void Construct(); // Function CraftingMenu2.CraftingMenu2_C.Construct
	void ExecuteUbergraph_CraftingMenu2(int32_t EntryPoint); // Function CraftingMenu2.CraftingMenu2_C.ExecuteUbergraph_CraftingMenu2
}; 



