#pragma once 
#include <BP_Nail_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Nail.BP_Nail_C
// Size: 0x257(Inherited: 0x257) 
struct ABP_Nail_C : public ABP_Projectile_C
{

}; 



