#pragma once 
#include <Character_AnimBP_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass Character_AnimBP.Character_AnimBP_C
// Size: 0x234C(Inherited: 0x2C0) 
struct UCharacter_AnimBP_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_3;  // 0x2C8(0xC0)
	struct FAnimNode_Slot AnimGraphNode_Slot_4;  // 0x388(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16;  // 0x3D0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15;  // 0x3F8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14;  // 0x420(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13;  // 0x448(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12;  // 0x470(0x28)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3;  // 0x498(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_13;  // 0x580(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_13;  // 0x5B0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_12;  // 0x630(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_12;  // 0x660(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_11;  // 0x6E0(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2;  // 0x710(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_10;  // 0x7F8(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2;  // 0x828(0xB0)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;  // 0x8D8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;  // 0x900(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;  // 0x928(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;  // 0x950(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;  // 0x978(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;  // 0x9A0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // 0x9C8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x9F0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0xA18(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0xA40(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0xA68(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_11;  // 0xA90(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9;  // 0xB10(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_10;  // 0xB40(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8;  // 0xBC0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_9;  // 0xBF0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7;  // 0xC70(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_8;  // 0xCA0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6;  // 0xD20(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_7;  // 0xD50(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5;  // 0xDD0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0xE00(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0xE80(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0xEB0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0xF30(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0xF60(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0xFE0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x1010(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x1090(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x10C0(0xB0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0x1170(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x1278(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x1298(0x20)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x12B8(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x1410(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x1438(0xC0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x14F8(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // 0x1520(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x1568(0xC0)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x1628(0x48)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // 0x1670(0xA0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x1710(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x1868(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x1890(0x28)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x18B8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x18E8(0x48)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // 0x1930(0xA0)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x19D0(0xE8)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x1AB8(0xA0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x1B58(0x80)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0x1BD8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0x1CE0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x1DE8(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x1EF0(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x1F10(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x2018(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x2038(0x80)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x20B8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x21C0(0x108)
	float Speed;  // 0x22C8(0x4)
	struct FRotator Spinerotation;  // 0x22CC(0xC)
	char pad_8920_1 : 7;  // 0x22D8(0x1)
	bool Blocking : 1;  // 0x22D8(0x1)
	char pad_8921_1 : 7;  // 0x22D9(0x1)
	bool Charging : 1;  // 0x22D9(0x1)
	char pad_8922_1 : 7;  // 0x22DA(0x1)
	bool bInteracting : 1;  // 0x22DA(0x1)
	char pad_8923_1 : 7;  // 0x22DB(0x1)
	bool Throwing? : 1;  // 0x22DB(0x1)
	char pad_8924[4];  // 0x22DC(0x4)
	struct UAnimSequenceBase* BlockAnim;  // 0x22E0(0x8)
	struct UAnimSequenceBase* ChargeAnim;  // 0x22E8(0x8)
	struct UAnimSequenceBase* idleAnim;  // 0x22F0(0x8)
	char pad_8952_1 : 7;  // 0x22F8(0x1)
	bool InAir : 1;  // 0x22F8(0x1)
	char pad_8953_1 : 7;  // 0x22F9(0x1)
	bool Crouched : 1;  // 0x22F9(0x1)
	char pad_8954[2];  // 0x22FA(0x2)
	float ChargeSpeed;  // 0x22FC(0x4)
	char pad_8960_1 : 7;  // 0x2300(0x1)
	bool Holding : 1;  // 0x2300(0x1)
	char pad_8961[3];  // 0x2301(0x3)
	struct FRotator PreviousSpineRotation;  // 0x2304(0xC)
	float Direction;  // 0x2310(0x4)
	struct FVector ViewOffset;  // 0x2314(0xC)
	float BlockTime;  // 0x2320(0x4)
	char pad_8996[4];  // 0x2324(0x4)
	struct AFirstPersonCharacter_C* Owner;  // 0x2328(0x8)
	struct FRotator SwaySpineRotation;  // 0x2330(0xC)
	struct FVector RandomVector;  // 0x233C(0xC)
	float RandomVectorLength;  // 0x2348(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function Character_AnimBP.Character_AnimBP_C.AnimGraph
	void WalkingSurfaceTrace(struct AFirstPersonCharacter_C* Player, char EPhysicalSurface& SurfaceType); // Function Character_AnimBP.Character_AnimBP_C.WalkingSurfaceTrace
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_ModifyBone_A46AFDDD41AC8D5FE933E5951F5411AC(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_ModifyBone_A46AFDDD41AC8D5FE933E5951F5411AC
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_ModifyBone_5762686D43FDE79BEFB8F982DD2C6BE8(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_ModifyBone_5762686D43FDE79BEFB8F982DD2C6BE8
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_SequencePlayer_1407555E41A0A95A5B1EB09D41DDCBF3(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_SequencePlayer_1407555E41A0A95A5B1EB09D41DDCBF3
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_ModifyBone_CC819DD14E20B49BAEEF0C996F30249E(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_ModifyBone_CC819DD14E20B49BAEEF0C996F30249E
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_9D38FF6642A9F9EDEFAC128243E7371B(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_9D38FF6642A9F9EDEFAC128243E7371B
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_F27759C947FBA7E92E9710B13C382B3A(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_F27759C947FBA7E92E9710B13C382B3A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_FA36C90E468061DF451EE6BF29648117(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_FA36C90E468061DF451EE6BF29648117
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_224AC12D4733BAE320912ABACA33B205(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_224AC12D4733BAE320912ABACA33B205
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_FE52866546C20B65C2A080AC7B5FEEE3(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_FE52866546C20B65C2A080AC7B5FEEE3
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_BlendSpacePlayer_DC62C8284D071DB0F505B1920349F530(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_BlendSpacePlayer_DC62C8284D071DB0F505B1920349F530
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_BlendSpacePlayer_A6F4C76446B2039A16C507850E03C3F5(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_BlendSpacePlayer_A6F4C76446B2039A16C507850E03C3F5
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_B5E152E542DD63D64A4A5C83CC79D343(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_B5E152E542DD63D64A4A5C83CC79D343
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_39E20A844FB5AECF711F5BA3E5770A65(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_39E20A844FB5AECF711F5BA3E5770A65
	void EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_E1EB0C464DD39BA4A1874AA4F04FE7E0(); // Function Character_AnimBP.Character_AnimBP_C.EvaluateGraphExposedInputs_ExecuteUbergraph_Character_AnimBP_AnimGraphNode_TransitionResult_E1EB0C464DD39BA4A1874AA4F04FE7E0
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function Character_AnimBP.Character_AnimBP_C.BlueprintUpdateAnimation
	void AnimNotify_Footstep(); // Function Character_AnimBP.Character_AnimBP_C.AnimNotify_Footstep
	void SR(float X (Roll)); // Function Character_AnimBP.Character_AnimBP_C.SR
	void SetBlockTime(struct APawn* Pawn); // Function Character_AnimBP.Character_AnimBP_C.SetBlockTime
	void GenRandomVector(); // Function Character_AnimBP.Character_AnimBP_C.GenRandomVector
	void ExecuteUbergraph_Character_AnimBP(int32_t EntryPoint); // Function Character_AnimBP.Character_AnimBP_C.ExecuteUbergraph_Character_AnimBP
}; 



