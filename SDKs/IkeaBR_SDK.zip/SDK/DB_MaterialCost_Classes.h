#pragma once 
#include <DB_MaterialCost_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DB_MaterialCost.DB_MaterialCost_C
// Size: 0x27C(Inherited: 0x260) 
struct UDB_MaterialCost_C : public UUserWidget
{
	struct UImage* I_WoodCost_3;  // 0x260(0x8)
	struct UTextBlock* WoodCost_3;  // 0x268(0x8)
	struct UTexture2D* Image;  // 0x270(0x8)
	int32_t Amount;  // 0x278(0x4)

	struct FText Get_WoodCost_2_Text_1(); // Function DB_MaterialCost.DB_MaterialCost_C.Get_WoodCost_2_Text_1
	struct FSlateBrush Get_I_WoodCost_2_Brush_1(); // Function DB_MaterialCost.DB_MaterialCost_C.Get_I_WoodCost_2_Brush_1
}; 



