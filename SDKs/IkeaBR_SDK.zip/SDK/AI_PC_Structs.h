#pragma once 
#include "SDK.h" 
 
 
// Function AI_PC.AI_PC_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature
// Size: 0x44(Inherited: 0x0) 
struct FBndEvt__AIPerception_K2Node_ComponentBoundEvent_1_ActorPerceptionUpdatedDelegate__DelegateSignature
{
	struct AActor* Actor;  // 0x0(0x8)
	struct FAIStimulus Stimulus;  // 0x8(0x3C)

}; 
// Function AI_PC.AI_PC_C.BndEvt__AIPerception_K2Node_ComponentBoundEvent_0_PerceptionUpdatedDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FBndEvt__AIPerception_K2Node_ComponentBoundEvent_0_PerceptionUpdatedDelegate__DelegateSignature
{
	struct TArray<struct AActor*> UpdatedActors;  // 0x0(0x10)

}; 
// Function AI_PC.AI_PC_C.ExecuteUbergraph_AI_PC
// Size: 0xC1(Inherited: 0x0) 
struct FExecuteUbergraph_AI_PC
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_RunBehaviorTree_ReturnValue : 1;  // 0x6(0x1)
	char pad_7[1];  // 0x7(0x1)
	struct AActor* K2Node_ComponentBoundEvent_Actor;  // 0x8(0x8)
	struct FAIStimulus K2Node_ComponentBoundEvent_Stimulus;  // 0x10(0x3C)
	char pad_76[4];  // 0x4C(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x50(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x64(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x6C(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x80(0x8)
	char EPathFollowingStatus CallFunc_GetMoveStatus_ReturnValue;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct UObject* CallFunc_GetValueAsObject_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0xAC(0x4)
	struct TArray<struct AActor*> K2Node_ComponentBoundEvent_UpdatedActors;  // 0xB0(0x10)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xC0(0x1)

}; 
// Function AI_PC.AI_PC_C.ForgetTarget
// Size: 0x69(Inherited: 0x0) 
struct FForgetTarget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool TargetVisible : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x10(0x8)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x18(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x20(0x8)
	struct AAIController* CallFunc_GetAIController_ReturnValue_2;  // 0x28(0x8)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x30(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x38(0x8)
	struct TArray<struct AActor*> CallFunc_GetPerceivedActors_OutActors;  // 0x40(0x10)
	struct UObject* CallFunc_GetValueAsObject_ReturnValue;  // 0x50(0x8)
	struct AActor* CallFunc_Array_Get_Item;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)

}; 
