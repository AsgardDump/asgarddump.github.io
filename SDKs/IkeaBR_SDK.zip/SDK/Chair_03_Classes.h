#pragma once 
#include <Chair_03_Structs.h>
 
 
 
// BlueprintGeneratedClass Chair_03.Chair_03_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AChair_03_C : public AMovable_Object_Replicated_C
{

}; 



