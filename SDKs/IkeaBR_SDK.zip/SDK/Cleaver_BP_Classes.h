#pragma once 
#include <Cleaver_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass Cleaver_BP.Cleaver_BP_C
// Size: 0x290(Inherited: 0x290) 
struct ACleaver_BP_C : public AWeaponBP_C
{

}; 



