#pragma once 
#include <GarbagePile_Structs.h>
 
 
 
// BlueprintGeneratedClass GarbagePile.GarbagePile_C
// Size: 0x260(Inherited: 0x220) 
struct AGarbagePile_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x228(0x8)
	struct UAudioComponent* Audio;  // 0x230(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x238(0x8)
	struct UchargeBar_C* Charge;  // 0x240(0x8)
	float chargeref;  // 0x248(0x4)
	char pad_588[4];  // 0x24C(0x4)
	struct TArray<struct AFirstPersonCharacter_C*> Users;  // 0x250(0x10)

	void RecieveServerLook(bool& Recieve?); // Function GarbagePile.GarbagePile_C.RecieveServerLook
	void ServerDestroy(); // Function GarbagePile.GarbagePile_C.ServerDestroy
	void ReceiveBeginPlay(); // Function GarbagePile.GarbagePile_C.ReceiveBeginPlay
	void OnChargeUpdate(float Charge, struct AFirstPersonCharacter_C* Caller); // Function GarbagePile.GarbagePile_C.OnChargeUpdate
	void OnLook(struct AFirstPersonCharacter_C* Caller); // Function GarbagePile.GarbagePile_C.OnLook
	void ServerOnStopLook(struct AFirstPersonCharacter_C* Player); // Function GarbagePile.GarbagePile_C.ServerOnStopLook
	void ServerOnLook(struct AFirstPersonCharacter_C* Player); // Function GarbagePile.GarbagePile_C.ServerOnLook
	void OnInteract(struct AFirstPersonCharacter_C* Caller, struct FHitResult Hit, int32_t InventorySlot); // Function GarbagePile.GarbagePile_C.OnInteract
	void OnStopLook(struct AFirstPersonCharacter_C* Caller); // Function GarbagePile.GarbagePile_C.OnStopLook
	void ReceiveDestroyed(); // Function GarbagePile.GarbagePile_C.ReceiveDestroyed
	void ExecuteUbergraph_GarbagePile(int32_t EntryPoint); // Function GarbagePile.GarbagePile_C.ExecuteUbergraph_GarbagePile
}; 



