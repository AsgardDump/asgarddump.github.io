#pragma once 
#include "SDK.h" 
 
 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server_Grab
// Size: 0x14(Inherited: 0x0) 
struct FServer_Grab
{
	struct AMovable_Object_Replicated_C* Mesh;  // 0x0(0x8)
	struct FVector Teleport Loaction;  // 0x8(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Reload__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FReload__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnEquip__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnEquip__DelegateSignature
{
	int32_t NewSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SprintServer
// Size: 0xD(Inherited: 0x0) 
struct FSprintServer
{
	float MaxWalkSpeed;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Sprinting? : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t initiator;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool Should Change Speed : 1;  // 0xC(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnGetHit__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnGetHit__DelegateSignature
{
	struct AFirstPersonCharacter_C* Hitter;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client Load Cosmetics Async
// Size: 0x10(Inherited: 0x0) 
struct FClient Load Cosmetics Async
{
	struct TArray<struct FST_RepCosmetic> clothes;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSendVoice
// Size: 0x10(Inherited: 0x0) 
struct FServerSendVoice
{
	struct TArray<char> CompressedVoiceData;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientMuffleSound
// Size: 0x4(Inherited: 0x0) 
struct FClientMuffleSound
{
	float Time;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnMeleeHit__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnMeleeHit__DelegateSignature
{
	struct AFirstPersonCharacter_C* Hit;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_0914B3504C491F3C20AD179693CF6C05
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_0914B3504C491F3C20AD179693CF6C05
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerProjectile
// Size: 0x48(Inherited: 0x0) 
struct FServerProjectile
{
	int32_t ID;  // 0x0(0x4)
	float Damage;  // 0x4(0x4)
	struct APawn* Instigator;  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x30)
	ABP_Projectile_C* Class;  // 0x40(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.LMB__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FLMB__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_sprint_K2Node_InputActionEvent_18
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_sprint_K2Node_InputActionEvent_18
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowWeapon_K2Node_InputActionEvent_10
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ThrowWeapon_K2Node_InputActionEvent_10
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiChargeSound
// Size: 0x4(Inherited: 0x0) 
struct FMultiChargeSound
{
	int32_t ID;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnFocus__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnFocus__DelegateSignature
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiCrouch
// Size: 0x1(Inherited: 0x0) 
struct FMultiCrouch
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Crouch : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSide_Death
// Size: 0xA3(Inherited: 0x0) 
struct FServerSide_Death
{
	struct AFirstPersonCharacter_C* KIller;  // 0x0(0x8)
	struct AGS_BR_C* GameState;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x18(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1C(0xC)
	struct AAI_Bot_C* K2Node_DynamicCast_AsAI_Bot;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x38(0x8)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc_2;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FST_Stats CallFunc_GetStats_stats;  // 0x64(0x24)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x88(0x8)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x90(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xA2(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC73978794783E
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73978794783E
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoseFocus__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnLoseFocus__DelegateSignature
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientDamageIndicator
// Size: 0xC(Inherited: 0x0) 
struct FClientDamageIndicator
{
	struct FVector AttackerLoc;  // 0x0(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnDamageSomeone__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnDamageSomeone__DelegateSignature
{
	struct AFirstPersonCharacter_C* DamagedTarget;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSoundEffect
// Size: 0x30(Inherited: 0x0) 
struct FServerSoundEffect
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct USoundBase* Sound;  // 0x10(0x8)
	int32_t ID;  // 0x18(0x4)
	float VolumeMultiplier;  // 0x1C(0x4)
	float PitchMultiplier;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct USoundAttenuation* AttenuationSettings;  // 0x28(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiMeleeHit
// Size: 0x18(Inherited: 0x0) 
struct FMultiMeleeHit
{
	struct FVector Location;  // 0x0(0xC)
	struct FVector Scale;  // 0xC(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client Refresh Sockets
// Size: 0x4(Inherited: 0x0) 
struct FClient Refresh Sockets
{
	int32_t NewSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Shove_K2Node_InputActionEvent_35
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Shove_K2Node_InputActionEvent_35
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.CloseSprayMenu
// Size: 0x38(Inherited: 0x0) 
struct FCloseSprayMenu
{
	struct FST_SprayItem SelectedSpray;  // 0x0(0x38)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDamageFurniture
// Size: 0x28(Inherited: 0x0) 
struct FServerDamageFurniture
{
	struct FVector Location;  // 0x0(0xC)
	struct FVector Normal;  // 0xC(0xC)
	float Damage;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AMovable_Object_Replicated_C* Target;  // 0x20(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ExecuteUbergraph_FirstPersonCharacter
// Size: 0x7CC0(Inherited: 0x0) 
struct FExecuteUbergraph_FirstPersonCharacter
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x8(0x8)
	struct FKey K2Node_InputKeyEvent_Key;  // 0x10(0x18)
	struct APlayerBRController_C* CallFunc_PC_pc_2;  // 0x28(0x8)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x30(0x18)
	struct FKey Temp_struct_Variable;  // 0x48(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x60(0xC)
	char pad_108[4];  // 0x6C(0x4)
	struct FKey K2Node_InputActionEvent_Key_21;  // 0x70(0x18)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Can_Attack_ReturnValue : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x94(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	struct FKey K2Node_InputActionEvent_Key_22;  // 0xA0(0x18)
	struct FKey Temp_struct_Variable_2;  // 0xB8(0x18)
	struct FKey K2Node_InputActionEvent_Key_23;  // 0xD0(0x18)
	struct FKey K2Node_InputActionEvent_Key_24;  // 0xE8(0x18)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	struct FDateTime Temp_wildcard_Variable;  // 0x108(0x8)
	struct FDateTime CallFunc_Now_ReturnValue;  // 0x110(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_2;  // 0x118(0x8)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue;  // 0x120(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue;  // 0x128(0x4)
	char pad_300[4];  // 0x12C(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_3;  // 0x130(0x8)
	struct APlayerBRController_C* CallFunc_PC_pc_3;  // 0x138(0x8)
	struct FKey Temp_struct_Variable_3;  // 0x140(0x18)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x158(0x1)
	char pad_345[7];  // 0x159(0x7)
	struct FKey K2Node_InputActionEvent_Key_25;  // 0x160(0x18)
	struct FKey K2Node_InputActionEvent_Key_26;  // 0x178(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x190(0xC)
	char pad_412_1 : 7;  // 0x19C(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0x19C(0x1)
	char pad_413_1 : 7;  // 0x19D(0x1)
	bool CallFunc_HasAuthority_ReturnValue_4 : 1;  // 0x19D(0x1)
	char pad_414[2];  // 0x19E(0x2)
	struct FKey Temp_struct_Variable_4;  // 0x1A0(0x18)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_HasAuthority_ReturnValue_5 : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue : 1;  // 0x1B9(0x1)
	char pad_442[6];  // 0x1BA(0x6)
	struct FKey K2Node_InputActionEvent_Key_27;  // 0x1C0(0x18)
	struct APlayerBRController_C* CallFunc_PC_pc_4;  // 0x1D8(0x8)
	char pad_480_1 : 7;  // 0x1E0(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue_2 : 1;  // 0x1E0(0x1)
	char pad_481_1 : 7;  // 0x1E1(0x1)
	bool CallFunc_HasAuthority_ReturnValue_6 : 1;  // 0x1E1(0x1)
	char pad_482_1 : 7;  // 0x1E2(0x1)
	bool CallFunc_HasAuthority_ReturnValue_7 : 1;  // 0x1E2(0x1)
	char pad_483[5];  // 0x1E3(0x5)
	struct FKey K2Node_InputActionEvent_Key_28;  // 0x1E8(0x18)
	int32_t Temp_int_Array_Index_Variable;  // 0x200(0x4)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool CallFunc_HasAuthority_ReturnValue_8 : 1;  // 0x204(0x1)
	char pad_517_1 : 7;  // 0x205(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x205(0x1)
	char pad_518[2];  // 0x206(0x2)
	struct FKey Temp_struct_Variable_5;  // 0x208(0x18)
	char pad_544_1 : 7;  // 0x220(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue_3 : 1;  // 0x220(0x1)
	char pad_545_1 : 7;  // 0x221(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x221(0x1)
	char pad_546[6];  // 0x222(0x6)
	struct FKey K2Node_InputActionEvent_Key_29;  // 0x228(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_3;  // 0x240(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_4;  // 0x24C(0xC)
	struct FKey K2Node_InputActionEvent_Key_30;  // 0x258(0x18)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0x270(0x1)
	char pad_625[3];  // 0x271(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_5;  // 0x274(0xC)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x280(0x1)
	char pad_641[7];  // 0x281(0x7)
	struct FKey Temp_struct_Variable_6;  // 0x288(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_6;  // 0x2A0(0xC)
	char pad_684_1 : 7;  // 0x2AC(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue_4 : 1;  // 0x2AC(0x1)
	char pad_685[3];  // 0x2AD(0x3)
	struct FKey K2Node_InputActionEvent_Key_31;  // 0x2B0(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_7;  // 0x2C8(0xC)
	char pad_724_1 : 7;  // 0x2D4(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0x2D4(0x1)
	char pad_725[3];  // 0x2D5(0x3)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x2D8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x2DC(0x4)
	struct FKey K2Node_InputActionEvent_Key_32;  // 0x2E0(0x18)
	float Temp_float_Variable;  // 0x2F8(0x4)
	float Temp_float_Variable_2;  // 0x2FC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x300(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x304(0x4)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_2 : 1;  // 0x308(0x1)
	char pad_777[3];  // 0x309(0x3)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x30C(0x4)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x310(0x1)
	char pad_785[3];  // 0x311(0x3)
	float Temp_float_Variable_3;  // 0x314(0x4)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x318(0x1)
	char pad_793_1 : 7;  // 0x319(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x319(0x1)
	char pad_794[6];  // 0x31A(0x6)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x320(0x8)
	char pad_808_1 : 7;  // 0x328(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_3 : 1;  // 0x328(0x1)
	char pad_809[7];  // 0x329(0x7)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x330(0x8)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x338(0x1)
	char pad_825[3];  // 0x339(0x3)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue;  // 0x33C(0x4)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x340(0x1)
	char pad_833[3];  // 0x341(0x3)
	int32_t CallFunc_SelectInt_ReturnValue;  // 0x344(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x348(0x4)
	char pad_844[4];  // 0x34C(0x4)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x350(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x358(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x35C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x360(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x364(0x4)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool CallFunc_HasAuthority_ReturnValue_9 : 1;  // 0x368(0x1)
	char pad_873[7];  // 0x369(0x7)
	struct FKey Temp_struct_Variable_7;  // 0x370(0x18)
	struct FDateTime Temp_wildcard_Variable_2;  // 0x388(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_4;  // 0x390(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_5;  // 0x398(0x8)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_2;  // 0x3A0(0x8)
	struct APlayerBRController_C* CallFunc_PC_pc_5;  // 0x3A8(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_2;  // 0x3B0(0x4)
	char pad_948_1 : 7;  // 0x3B4(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue_5 : 1;  // 0x3B4(0x1)
	char pad_949[3];  // 0x3B5(0x3)
	struct FKey K2Node_InputActionEvent_Key_33;  // 0x3B8(0x18)
	struct FDateTime CallFunc_Now_ReturnValue_6;  // 0x3D0(0x8)
	char pad_984_1 : 7;  // 0x3D8(0x1)
	bool Temp_bool_Variable : 1;  // 0x3D8(0x1)
	char pad_985[7];  // 0x3D9(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc_6;  // 0x3E0(0x8)
	char pad_1000_1 : 7;  // 0x3E8(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue_6 : 1;  // 0x3E8(0x1)
	char pad_1001[3];  // 0x3E9(0x3)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x3EC(0x4)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x3F0(0x1)
	char pad_1009_1 : 7;  // 0x3F1(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x3F1(0x1)
	char pad_1010[6];  // 0x3F2(0x6)
	struct FKey K2Node_InputActionEvent_Key_34;  // 0x3F8(0x18)
	struct FKey Temp_struct_Variable_8;  // 0x410(0x18)
	struct FKey K2Node_InputActionEvent_Key_35;  // 0x428(0x18)
	struct FKey K2Node_InputActionEvent_Key_36;  // 0x440(0x18)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0x458(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x45C(0x4)
	int32_t Temp_int_Array_Index_Variable_5;  // 0x460(0x4)
	int32_t Temp_int_Array_Index_Variable_6;  // 0x464(0x4)
	int32_t Temp_int_Loop_Counter_Variable_6;  // 0x468(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_6;  // 0x46C(0x4)
	int32_t Temp_int_Array_Index_Variable_7;  // 0x470(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x474(0x10)
	char pad_1156[4];  // 0x484(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x488(0x8)
	struct UMyCharacterMovementComponent* CallFunc_GetMyMovementComponent_ReturnValue;  // 0x490(0x8)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x498(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_2;  // 0x4A0(0x8)
	char pad_1192_1 : 7;  // 0x4A8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x4A8(0x1)
	char pad_1193[3];  // 0x4A9(0x3)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_2;  // 0x4AC(0x4)
	struct AController* CallFunc_GetController_ReturnValue_3;  // 0x4B0(0x8)
	int32_t CallFunc_SelectInt_ReturnValue_2;  // 0x4B8(0x4)
	char pad_1212[4];  // 0x4BC(0x4)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_3;  // 0x4C0(0x8)
	char pad_1224_1 : 7;  // 0x4C8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x4C8(0x1)
	char pad_1225_1 : 7;  // 0x4C9(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x4C9(0x1)
	char pad_1226[2];  // 0x4CA(0x2)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_3;  // 0x4CC(0x4)
	int32_t CallFunc_SelectInt_ReturnValue_3;  // 0x4D0(0x4)
	char pad_1236[4];  // 0x4D4(0x4)
	struct AController* CallFunc_GetController_ReturnValue_4;  // 0x4D8(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_4;  // 0x4E0(0x8)
	char pad_1256_1 : 7;  // 0x4E8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x4E8(0x1)
	char pad_1257[3];  // 0x4E9(0x3)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_4;  // 0x4EC(0x4)
	int32_t CallFunc_SelectInt_ReturnValue_4;  // 0x4F0(0x4)
	int32_t Temp_int_Loop_Counter_Variable_7;  // 0x4F4(0x4)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0x4F8(0x90)
	int32_t CallFunc_Add_IntInt_ReturnValue_7;  // 0x588(0x4)
	char pad_1420_1 : 7;  // 0x58C(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x58C(0x1)
	char pad_1421_1 : 7;  // 0x58D(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x58D(0x1)
	char pad_1422_1 : 7;  // 0x58E(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x58E(0x1)
	char pad_1423[1];  // 0x58F(0x1)
	int32_t Temp_int_Array_Index_Variable_8;  // 0x590(0x4)
	char pad_1428[4];  // 0x594(0x4)
	struct AController* CallFunc_GetController_ReturnValue_5;  // 0x598(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_5;  // 0x5A0(0x8)
	char pad_1448_1 : 7;  // 0x5A8(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x5A8(0x1)
	char pad_1449[3];  // 0x5A9(0x3)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_5;  // 0x5AC(0x4)
	int32_t CallFunc_SelectInt_ReturnValue_5;  // 0x5B0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x5B4(0x10)
	char pad_1476_1 : 7;  // 0x5C4(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0x5C4(0x1)
	char pad_1477_1 : 7;  // 0x5C5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x5C5(0x1)
	char pad_1478_1 : 7;  // 0x5C6(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_5 : 1;  // 0x5C6(0x1)
	char pad_1479[1];  // 0x5C7(0x1)
	struct FDateTime CallFunc_Now_ReturnValue_7;  // 0x5C8(0x8)
	char pad_1488_1 : 7;  // 0x5D0(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_2 : 1;  // 0x5D0(0x1)
	char pad_1489_1 : 7;  // 0x5D1(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x5D1(0x1)
	char pad_1490_1 : 7;  // 0x5D2(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_4 : 1;  // 0x5D2(0x1)
	char pad_1491[1];  // 0x5D3(0x1)
	int32_t Temp_int_Loop_Counter_Variable_8;  // 0x5D4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_8;  // 0x5D8(0x4)
	int32_t Temp_int_Array_Index_Variable_9;  // 0x5DC(0x4)
	float Temp_float_Variable_4;  // 0x5E0(0x4)
	char pad_1508[4];  // 0x5E4(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_8;  // 0x5E8(0x8)
	char pad_1520_1 : 7;  // 0x5F0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_5 : 1;  // 0x5F0(0x1)
	char pad_1521_1 : 7;  // 0x5F1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_6 : 1;  // 0x5F1(0x1)
	char pad_1522[2];  // 0x5F2(0x2)
	float Temp_float_Variable_5;  // 0x5F4(0x4)
	char pad_1528_1 : 7;  // 0x5F8(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_7 : 1;  // 0x5F8(0x1)
	char pad_1529[7];  // 0x5F9(0x7)
	struct FDateTime CallFunc_Now_ReturnValue_9;  // 0x600(0x8)
	char pad_1544_1 : 7;  // 0x608(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_8 : 1;  // 0x608(0x1)
	char pad_1545_1 : 7;  // 0x609(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x609(0x1)
	char pad_1546[6];  // 0x60A(0x6)
	struct FDateTime Temp_wildcard_Variable_3;  // 0x610(0x8)
	char pad_1560_1 : 7;  // 0x618(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_9 : 1;  // 0x618(0x1)
	char pad_1561[7];  // 0x619(0x7)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_3;  // 0x620(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_3;  // 0x628(0x4)
	char pad_1580[4];  // 0x62C(0x4)
	struct FST_ItemBase CallFunc_Array_Get_Item_2;  // 0x630(0x90)
	char pad_1728_1 : 7;  // 0x6C0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_10 : 1;  // 0x6C0(0x1)
	char pad_1729_1 : 7;  // 0x6C1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x6C1(0x1)
	char pad_1730_1 : 7;  // 0x6C2(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_2 : 1;  // 0x6C2(0x1)
	char pad_1731_1 : 7;  // 0x6C3(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x6C3(0x1)
	char pad_1732_1 : 7;  // 0x6C4(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x6C4(0x1)
	char pad_1733[3];  // 0x6C5(0x3)
	struct FDateTime CallFunc_Now_ReturnValue_10;  // 0x6C8(0x8)
	char pad_1744_1 : 7;  // 0x6D0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_3 : 1;  // 0x6D0(0x1)
	char pad_1745[7];  // 0x6D1(0x7)
	struct AFirstPersonCharacter_C* Temp_object_Variable;  // 0x6D8(0x8)
	char pad_1760_1 : 7;  // 0x6E0(0x1)
	bool Temp_bool_IsClosed_Variable_3 : 1;  // 0x6E0(0x1)
	char pad_1761[3];  // 0x6E1(0x3)
	int32_t Temp_int_Loop_Counter_Variable_9;  // 0x6E4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_9;  // 0x6E8(0x4)
	int32_t Temp_int_Array_Index_Variable_10;  // 0x6EC(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_11;  // 0x6F0(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_12;  // 0x6F8(0x8)
	struct FDateTime Temp_wildcard_Variable_4;  // 0x700(0x8)
	int32_t Temp_int_Loop_Counter_Variable_10;  // 0x708(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_10;  // 0x70C(0x4)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_4;  // 0x710(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_4;  // 0x718(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x71C(0x4)
	int32_t Temp_int_Array_Index_Variable_11;  // 0x720(0x4)
	char pad_1828_1 : 7;  // 0x724(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x724(0x1)
	char pad_1829[3];  // 0x725(0x3)
	float CallFunc_Delay_Ping_delay_ping;  // 0x728(0x4)
	char pad_1836_1 : 7;  // 0x72C(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_4 : 1;  // 0x72C(0x1)
	char pad_1837_1 : 7;  // 0x72D(0x1)
	bool Temp_bool_IsClosed_Variable_4 : 1;  // 0x72D(0x1)
	char pad_1838[2];  // 0x72E(0x2)
	struct AController* CallFunc_GetController_ReturnValue_6;  // 0x730(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_6;  // 0x738(0x8)
	char pad_1856_1 : 7;  // 0x740(0x1)
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // 0x740(0x1)
	char pad_1857[7];  // 0x741(0x7)
	struct AController* CallFunc_GetController_ReturnValue_7;  // 0x748(0x8)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_6;  // 0x750(0x4)
	char pad_1876[4];  // 0x754(0x4)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_7;  // 0x758(0x8)
	char pad_1888_1 : 7;  // 0x760(0x1)
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // 0x760(0x1)
	char pad_1889[3];  // 0x761(0x3)
	int32_t CallFunc_SelectInt_ReturnValue_6;  // 0x764(0x4)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_7;  // 0x768(0x4)
	int32_t CallFunc_SelectInt_ReturnValue_7;  // 0x76C(0x4)
	char pad_1904_1 : 7;  // 0x770(0x1)
	bool CallFunc_HasAuthority_ReturnValue_10 : 1;  // 0x770(0x1)
	char pad_1905[7];  // 0x771(0x7)
	struct AController* CallFunc_GetController_ReturnValue_8;  // 0x778(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_8;  // 0x780(0x8)
	char pad_1928_1 : 7;  // 0x788(0x1)
	bool K2Node_DynamicCast_bSuccess_8 : 1;  // 0x788(0x1)
	char pad_1929[3];  // 0x789(0x3)
	int32_t Temp_int_Loop_Counter_Variable_11;  // 0x78C(0x4)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_8;  // 0x790(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_11;  // 0x794(0x4)
	int32_t CallFunc_SelectInt_ReturnValue_8;  // 0x798(0x4)
	char pad_1948_1 : 7;  // 0x79C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_2 : 1;  // 0x79C(0x1)
	char pad_1949[3];  // 0x79D(0x3)
	int32_t Temp_int_Array_Index_Variable_12;  // 0x7A0(0x4)
	char pad_1956[4];  // 0x7A4(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_13;  // 0x7A8(0x8)
	char pad_1968_1 : 7;  // 0x7B0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_11 : 1;  // 0x7B0(0x1)
	char pad_1969_1 : 7;  // 0x7B1(0x1)
	bool CallFunc_HasAuthority_ReturnValue_11 : 1;  // 0x7B1(0x1)
	char pad_1970_1 : 7;  // 0x7B2(0x1)
	bool CallFunc_HasAuthority_ReturnValue_12 : 1;  // 0x7B2(0x1)
	char pad_1971_1 : 7;  // 0x7B3(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_3 : 1;  // 0x7B3(0x1)
	char pad_1972_1 : 7;  // 0x7B4(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_4 : 1;  // 0x7B4(0x1)
	char pad_1973[3];  // 0x7B5(0x3)
	float Temp_float_Variable_6;  // 0x7B8(0x4)
	char pad_1980_1 : 7;  // 0x7BC(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x7BC(0x1)
	char pad_1981[3];  // 0x7BD(0x3)
	float CallFunc_Delay_Ping_delay_ping_2;  // 0x7C0(0x4)
	int32_t Temp_int_Loop_Counter_Variable_12;  // 0x7C4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_12;  // 0x7C8(0x4)
	int32_t Temp_int_Array_Index_Variable_13;  // 0x7CC(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_14;  // 0x7D0(0x8)
	int32_t Temp_int_Loop_Counter_Variable_13;  // 0x7D8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_13;  // 0x7DC(0x4)
	int32_t Temp_int_Array_Index_Variable_14;  // 0x7E0(0x4)
	char pad_2020[4];  // 0x7E4(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_15;  // 0x7E8(0x8)
	float Temp_float_Variable_7;  // 0x7F0(0x4)
	char pad_2036_1 : 7;  // 0x7F4(0x1)
	bool Temp_bool_IsClosed_Variable_5 : 1;  // 0x7F4(0x1)
	char pad_2037_1 : 7;  // 0x7F5(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_5 : 1;  // 0x7F5(0x1)
	char pad_2038[2];  // 0x7F6(0x2)
	struct FDateTime Temp_wildcard_Variable_5;  // 0x7F8(0x8)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_5;  // 0x800(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_5;  // 0x808(0x4)
	float Temp_float_Variable_8;  // 0x80C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x810(0x4)
	char pad_2068_1 : 7;  // 0x814(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_2 : 1;  // 0x814(0x1)
	char pad_2069_1 : 7;  // 0x815(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_6 : 1;  // 0x815(0x1)
	char pad_2070_1 : 7;  // 0x816(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x816(0x1)
	char pad_2071[1];  // 0x817(0x1)
	float CallFunc_Delay_Ping_delay_ping_3;  // 0x818(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x81C(0x10)
	char pad_2092_1 : 7;  // 0x82C(0x1)
	bool Temp_bool_IsClosed_Variable_6 : 1;  // 0x82C(0x1)
	char pad_2093[3];  // 0x82D(0x3)
	struct FDateTime CallFunc_Now_ReturnValue_16;  // 0x830(0x8)
	struct FKey Temp_struct_Variable_9;  // 0x838(0x18)
	char pad_2128_1 : 7;  // 0x850(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_12 : 1;  // 0x850(0x1)
	char pad_2129[7];  // 0x851(0x7)
	struct FKey K2Node_InputActionEvent_Key_37;  // 0x858(0x18)
	struct FDateTime CallFunc_Now_ReturnValue_17;  // 0x870(0x8)
	int32_t Temp_int_Loop_Counter_Variable_14;  // 0x878(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_14;  // 0x87C(0x4)
	int32_t Temp_int_Array_Index_Variable_15;  // 0x880(0x4)
	char pad_2180[4];  // 0x884(0x4)
	struct FKey K2Node_InputActionEvent_Key_38;  // 0x888(0x18)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0x8A0(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0x8A8(0x10)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x8B8(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue;  // 0x8C0(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue;  // 0x8C8(0x8)
	char pad_2256_1 : 7;  // 0x8D0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8D0(0x1)
	char pad_2257_1 : 7;  // 0x8D1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x8D1(0x1)
	char pad_2258_1 : 7;  // 0x8D2(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x8D2(0x1)
	char pad_2259[5];  // 0x8D3(0x5)
	struct FKey Temp_struct_Variable_10;  // 0x8D8(0x18)
	struct FKey K2Node_InputActionEvent_Key_39;  // 0x8F0(0x18)
	char pad_2312_1 : 7;  // 0x908(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_5 : 1;  // 0x908(0x1)
	char pad_2313_1 : 7;  // 0x909(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_7 : 1;  // 0x909(0x1)
	char pad_2314_1 : 7;  // 0x90A(0x1)
	bool Temp_bool_IsClosed_Variable_7 : 1;  // 0x90A(0x1)
	char pad_2315[5];  // 0x90B(0x5)
	struct FKey K2Node_InputActionEvent_Key_40;  // 0x910(0x18)
	struct FDateTime CallFunc_Now_ReturnValue_18;  // 0x928(0x8)
	struct FDateTime Temp_wildcard_Variable_6;  // 0x930(0x8)
	int32_t Temp_int_Loop_Counter_Variable_15;  // 0x938(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_15;  // 0x93C(0x4)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_6;  // 0x940(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_6;  // 0x948(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0x94C(0x4)
	int32_t Temp_int_Array_Index_Variable_16;  // 0x950(0x4)
	char pad_2388_1 : 7;  // 0x954(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_3 : 1;  // 0x954(0x1)
	char pad_2389[3];  // 0x955(0x3)
	struct FST_ItemBase CallFunc_Array_Get_Item_3;  // 0x958(0x90)
	struct AController* CallFunc_GetController_ReturnValue_9;  // 0x9E8(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_9;  // 0x9F0(0x8)
	char pad_2552_1 : 7;  // 0x9F8(0x1)
	bool K2Node_DynamicCast_bSuccess_9 : 1;  // 0x9F8(0x1)
	char pad_2553_1 : 7;  // 0x9F9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x9F9(0x1)
	char pad_2554[2];  // 0x9FA(0x2)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_9;  // 0x9FC(0x4)
	char pad_2560_1 : 7;  // 0xA00(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_3 : 1;  // 0xA00(0x1)
	char pad_2561[3];  // 0xA01(0x3)
	int32_t CallFunc_SelectInt_ReturnValue_9;  // 0xA04(0x4)
	char pad_2568_1 : 7;  // 0xA08(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0xA08(0x1)
	char pad_2569[3];  // 0xA09(0x3)
	int32_t Temp_int_Loop_Counter_Variable_16;  // 0xA0C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_16;  // 0xA10(0x4)
	int32_t Temp_int_Array_Index_Variable_17;  // 0xA14(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_19;  // 0xA18(0x8)
	int32_t Temp_int_Loop_Counter_Variable_17;  // 0xA20(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_17;  // 0xA24(0x4)
	int32_t Temp_int_Array_Index_Variable_18;  // 0xA28(0x4)
	char pad_2604[4];  // 0xA2C(0x4)
	struct AController* CallFunc_GetController_ReturnValue_10;  // 0xA30(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_10;  // 0xA38(0x8)
	char pad_2624_1 : 7;  // 0xA40(0x1)
	bool K2Node_DynamicCast_bSuccess_10 : 1;  // 0xA40(0x1)
	char pad_2625[3];  // 0xA41(0x3)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_10;  // 0xA44(0x4)
	int32_t CallFunc_SelectInt_ReturnValue_10;  // 0xA48(0x4)
	char pad_2636[4];  // 0xA4C(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_20;  // 0xA50(0x8)
	int32_t Temp_int_Loop_Counter_Variable_18;  // 0xA58(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_18;  // 0xA5C(0x4)
	int32_t Temp_int_Array_Index_Variable_19;  // 0xA60(0x4)
	char pad_2660[4];  // 0xA64(0x4)
	struct USoundBase* Temp_object_Variable_2;  // 0xA68(0x8)
	char pad_2672_1 : 7;  // 0xA70(0x1)
	bool Temp_bool_Variable_6 : 1;  // 0xA70(0x1)
	char pad_2673[7];  // 0xA71(0x7)
	struct USoundBase* Temp_object_Variable_3;  // 0xA78(0x8)
	char pad_2688_1 : 7;  // 0xA80(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_6 : 1;  // 0xA80(0x1)
	char pad_2689[7];  // 0xA81(0x7)
	struct FDateTime CallFunc_Now_ReturnValue_21;  // 0xA88(0x8)
	struct FDateTime Temp_wildcard_Variable_7;  // 0xA90(0x8)
	int32_t Temp_int_Loop_Counter_Variable_19;  // 0xA98(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_19;  // 0xA9C(0x4)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_7;  // 0xAA0(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_7;  // 0xAA8(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_4;  // 0xAAC(0x4)
	int32_t Temp_int_Array_Index_Variable_20;  // 0xAB0(0x4)
	char pad_2740_1 : 7;  // 0xAB4(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_4 : 1;  // 0xAB4(0x1)
	char pad_2741_1 : 7;  // 0xAB5(0x1)
	bool Temp_bool_Variable_7 : 1;  // 0xAB5(0x1)
	char pad_2742_1 : 7;  // 0xAB6(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_8 : 1;  // 0xAB6(0x1)
	char pad_2743[1];  // 0xAB7(0x1)
	struct TArray<struct AActor*> Temp_object_Variable_4;  // 0xAB8(0x10)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_2;  // 0xAC8(0x8)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_2;  // 0xAD0(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_2;  // 0xAD8(0x10)
	struct UAnimSequenceBase* Temp_object_Variable_5;  // 0xAE8(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_2;  // 0xAF0(0x8)
	char pad_2808_1 : 7;  // 0xAF8(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0xAF8(0x1)
	char pad_2809[7];  // 0xAF9(0x7)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_2;  // 0xB00(0x8)
	char pad_2824_1 : 7;  // 0xB08(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0xB08(0x1)
	char pad_2825_1 : 7;  // 0xB09(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_2 : 1;  // 0xB09(0x1)
	char pad_2826[6];  // 0xB0A(0x6)
	struct UAnimSequenceBase* Temp_object_Variable_6;  // 0xB10(0x8)
	char pad_2840_1 : 7;  // 0xB18(0x1)
	bool Temp_bool_IsClosed_Variable_8 : 1;  // 0xB18(0x1)
	char pad_2841[3];  // 0xB19(0x3)
	int32_t Temp_int_Loop_Counter_Variable_20;  // 0xB1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_20;  // 0xB20(0x4)
	int32_t Temp_int_Array_Index_Variable_21;  // 0xB24(0x4)
	char pad_2856_1 : 7;  // 0xB28(0x1)
	bool Temp_bool_Variable_8 : 1;  // 0xB28(0x1)
	char pad_2857[7];  // 0xB29(0x7)
	struct FDateTime Temp_wildcard_Variable_8;  // 0xB30(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_22;  // 0xB38(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_23;  // 0xB40(0x8)
	char pad_2888_1 : 7;  // 0xB48(0x1)
	bool Temp_bool_IsClosed_Variable_9 : 1;  // 0xB48(0x1)
	char pad_2889[7];  // 0xB49(0x7)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_8;  // 0xB50(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_8;  // 0xB58(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_5;  // 0xB5C(0x4)
	char pad_2912_1 : 7;  // 0xB60(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_5 : 1;  // 0xB60(0x1)
	char pad_2913[7];  // 0xB61(0x7)
	struct FDateTime CallFunc_Now_ReturnValue_24;  // 0xB68(0x8)
	int32_t Temp_int_Array_Index_Variable_22;  // 0xB70(0x4)
	char pad_2932_1 : 7;  // 0xB74(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_4 : 1;  // 0xB74(0x1)
	char pad_2933[3];  // 0xB75(0x3)
	UMatineeCameraShake* Temp_class_Variable;  // 0xB78(0x8)
	char pad_2944_1 : 7;  // 0xB80(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_7 : 1;  // 0xB80(0x1)
	char pad_2945[7];  // 0xB81(0x7)
	struct AController* CallFunc_GetController_ReturnValue_11;  // 0xB88(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_25;  // 0xB90(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_11;  // 0xB98(0x8)
	char pad_2976_1 : 7;  // 0xBA0(0x1)
	bool K2Node_DynamicCast_bSuccess_11 : 1;  // 0xBA0(0x1)
	char pad_2977[7];  // 0xBA1(0x7)
	struct AController* CallFunc_GetController_ReturnValue_12;  // 0xBA8(0x8)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_11;  // 0xBB0(0x4)
	char pad_2996[4];  // 0xBB4(0x4)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_12;  // 0xBB8(0x8)
	char pad_3008_1 : 7;  // 0xBC0(0x1)
	bool K2Node_DynamicCast_bSuccess_12 : 1;  // 0xBC0(0x1)
	char pad_3009[3];  // 0xBC1(0x3)
	int32_t CallFunc_SelectInt_ReturnValue_11;  // 0xBC4(0x4)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue_12;  // 0xBC8(0x4)
	char pad_3020[4];  // 0xBCC(0x4)
	UMatineeCameraShake* Temp_class_Variable_2;  // 0xBD0(0x8)
	int32_t CallFunc_SelectInt_ReturnValue_12;  // 0xBD8(0x4)
	char pad_3036_1 : 7;  // 0xBDC(0x1)
	bool Temp_bool_Variable_9 : 1;  // 0xBDC(0x1)
	char pad_3037_1 : 7;  // 0xBDD(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_6 : 1;  // 0xBDD(0x1)
	char pad_3038_1 : 7;  // 0xBDE(0x1)
	bool Temp_bool_IsClosed_Variable_10 : 1;  // 0xBDE(0x1)
	char pad_3039_1 : 7;  // 0xBDF(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_9 : 1;  // 0xBDF(0x1)
	char pad_3040_1 : 7;  // 0xBE0(0x1)
	bool Temp_bool_IsClosed_Variable_11 : 1;  // 0xBE0(0x1)
	char pad_3041_1 : 7;  // 0xBE1(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_10 : 1;  // 0xBE1(0x1)
	char pad_3042_1 : 7;  // 0xBE2(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_13 : 1;  // 0xBE2(0x1)
	char pad_3043[5];  // 0xBE3(0x5)
	struct FDateTime CallFunc_Now_ReturnValue_26;  // 0xBE8(0x8)
	int32_t Temp_int_Loop_Counter_Variable_21;  // 0xBF0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_21;  // 0xBF4(0x4)
	int32_t Temp_int_Array_Index_Variable_23;  // 0xBF8(0x4)
	char pad_3068_1 : 7;  // 0xBFC(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_11 : 1;  // 0xBFC(0x1)
	char pad_3069[3];  // 0xBFD(0x3)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_3;  // 0xC00(0x8)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_3;  // 0xC08(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_3;  // 0xC10(0x10)
	float Temp_float_Variable_9;  // 0xC20(0x4)
	char pad_3108[4];  // 0xC24(0x4)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_3;  // 0xC28(0x8)
	char pad_3120_1 : 7;  // 0xC30(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0xC30(0x1)
	char pad_3121[7];  // 0xC31(0x7)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_3;  // 0xC38(0x8)
	char pad_3136_1 : 7;  // 0xC40(0x1)
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // 0xC40(0x1)
	char pad_3137_1 : 7;  // 0xC41(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_3 : 1;  // 0xC41(0x1)
	char pad_3138[6];  // 0xC42(0x6)
	struct FDateTime CallFunc_Now_ReturnValue_27;  // 0xC48(0x8)
	struct FDateTime Temp_wildcard_Variable_9;  // 0xC50(0x8)
	float Temp_float_Variable_10;  // 0xC58(0x4)
	char pad_3164[4];  // 0xC5C(0x4)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_9;  // 0xC60(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_9;  // 0xC68(0x4)
	int32_t Temp_int_Loop_Counter_Variable_22;  // 0xC6C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_6;  // 0xC70(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_22;  // 0xC74(0x4)
	char pad_3192_1 : 7;  // 0xC78(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_6 : 1;  // 0xC78(0x1)
	char pad_3193[3];  // 0xC79(0x3)
	int32_t Temp_int_Array_Index_Variable_24;  // 0xC7C(0x4)
	int32_t Temp_int_Loop_Counter_Variable_23;  // 0xC80(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_23;  // 0xC84(0x4)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0xC88(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xC94(0xC)
	float CallFunc_BreakRotator_Roll;  // 0xCA0(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0xCA4(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xCA8(0x4)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0xCAC(0xC)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xCB8(0x4)
	float CallFunc_BreakRotator_Roll_2;  // 0xCBC(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0xCC0(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0xCC4(0x4)
	char pad_3272_1 : 7;  // 0xCC8(0x1)
	bool Temp_bool_Variable_10 : 1;  // 0xCC8(0x1)
	char pad_3273[3];  // 0xCC9(0x3)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xCCC(0xC)
	char pad_3288_1 : 7;  // 0xCD8(0x1)
	bool Temp_bool_IsClosed_Variable_12 : 1;  // 0xCD8(0x1)
	char pad_3289_1 : 7;  // 0xCD9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_12 : 1;  // 0xCD9(0x1)
	char pad_3290[6];  // 0xCDA(0x6)
	struct FDateTime CallFunc_Now_ReturnValue_28;  // 0xCE0(0x8)
	int32_t Temp_int_Loop_Counter_Variable_24;  // 0xCE8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_24;  // 0xCEC(0x4)
	int32_t Temp_int_Array_Index_Variable_25;  // 0xCF0(0x4)
	char pad_3316[4];  // 0xCF4(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_4;  // 0xCF8(0x8)
	struct FHitResult K2Node_Event_Hit_2;  // 0xD00(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0xD88(0x4)
	char pad_3468[4];  // 0xD8C(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_3;  // 0xD90(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_2;  // 0xD98(0x8)
	float K2Node_Event_Charge;  // 0xDA0(0x4)
	char pad_3492[4];  // 0xDA4(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0xDA8(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player_2;  // 0xDB0(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player;  // 0xDB8(0x8)
	AHealingItemBP_C* K2Node_ClassDynamicCast_AsHealing_Item_BP;  // 0xDC0(0x8)
	char pad_3528_1 : 7;  // 0xDC8(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xDC8(0x1)
	char pad_3529_1 : 7;  // 0xDC9(0x1)
	bool K2Node_CustomEvent_Stunned : 1;  // 0xDC9(0x1)
	char pad_3530[6];  // 0xDCA(0x6)
	AMedInjectorBP_C* K2Node_ClassDynamicCast_AsMed_Injector_BP;  // 0xDD0(0x8)
	char pad_3544_1 : 7;  // 0xDD8(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0xDD8(0x1)
	char pad_3545_1 : 7;  // 0xDD9(0x1)
	bool K2Node_CustomEvent_Stun : 1;  // 0xDD9(0x1)
	char pad_3546[6];  // 0xDDA(0x6)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Causer;  // 0xDE0(0x8)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_HitTarget;  // 0xDE8(0x8)
	struct FHitResult K2Node_CustomEvent_Hit_6;  // 0xDF0(0x88)
	char pad_3704_1 : 7;  // 0xE78(0x1)
	bool K2Node_CustomEvent_Headshot_2 : 1;  // 0xE78(0x1)
	char pad_3705[3];  // 0xE79(0x3)
	float K2Node_CustomEvent_Damage_14;  // 0xE7C(0x4)
	char pad_3712_1 : 7;  // 0xE80(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xE80(0x1)
	char pad_3713_1 : 7;  // 0xE81(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xE81(0x1)
	char pad_3714[2];  // 0xE82(0x2)
	float CallFunc_BreakHitResult_Time;  // 0xE84(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xE88(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xE8C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xE98(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xEA4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xEB0(0xC)
	char pad_3772[4];  // 0xEBC(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xEC0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xEC8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0xED0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0xED8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0xEE0(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0xEE4(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xEE8(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0xEEC(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0xEF8(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xF04(0xC)
	char pad_3856_1 : 7;  // 0xF10(0x1)
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // 0xF10(0x1)
	char pad_3857[3];  // 0xF11(0x3)
	float CallFunc_Vector_Distance_ReturnValue;  // 0xF14(0x4)
	float K2Node_CustomEvent_BaseDamage;  // 0xF18(0x4)
	char pad_3868[4];  // 0xF1C(0x4)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0xF20(0x8)
	char pad_3880_1 : 7;  // 0xF28(0x1)
	bool K2Node_DynamicCast_bSuccess_13 : 1;  // 0xF28(0x1)
	char pad_3881[3];  // 0xF29(0x3)
	float CallFunc_ApplyDamage_ReturnValue;  // 0xF2C(0x4)
	char pad_3888_1 : 7;  // 0xF30(0x1)
	bool CallFunc_IsDev_Server_ReturnValue : 1;  // 0xF30(0x1)
	char pad_3889_1 : 7;  // 0xF31(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0xF31(0x1)
	char pad_3890[6];  // 0xF32(0x6)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_OtherPlayer;  // 0xF38(0x8)
	struct FHitResult K2Node_CustomEvent_Hit_5;  // 0xF40(0x88)
	char pad_4040_1 : 7;  // 0xFC8(0x1)
	bool K2Node_CustomEvent_Headshot : 1;  // 0xFC8(0x1)
	char pad_4041[3];  // 0xFC9(0x3)
	float K2Node_CustomEvent_Damage_13;  // 0xFCC(0x4)
	char pad_4048_1 : 7;  // 0xFD0(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_7 : 1;  // 0xFD0(0x1)
	char pad_4049[7];  // 0xFD1(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0xFD8(0x10)
	char pad_4072_1 : 7;  // 0xFE8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_3 : 1;  // 0xFE8(0x1)
	char pad_4073[7];  // 0xFE9(0x7)
	struct AGarbagePile_C* K2Node_CustomEvent_Pile;  // 0xFF0(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xFF8(0x4)
	char pad_4092_1 : 7;  // 0xFFC(0x1)
	bool CallFunc_IsValid_ReturnValue_8 : 1;  // 0xFFC(0x1)
	char pad_4093[3];  // 0xFFD(0x3)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x1000(0x4)
	char pad_4100_1 : 7;  // 0x1004(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_13 : 1;  // 0x1004(0x1)
	char pad_4101_1 : 7;  // 0x1005(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1005(0x1)
	char pad_4102[2];  // 0x1006(0x2)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_AttackedTarget_4;  // 0x1008(0x8)
	float K2Node_CustomEvent_BleedScale;  // 0x1010(0x4)
	char pad_4116_1 : 7;  // 0x1014(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0x1014(0x1)
	char pad_4117[3];  // 0x1015(0x3)
	float CallFunc_GetDistanceTo_ReturnValue_2;  // 0x1018(0x4)
	char pad_4124_1 : 7;  // 0x101C(0x1)
	bool CallFunc_IsValid_ReturnValue_9 : 1;  // 0x101C(0x1)
	char pad_4125_1 : 7;  // 0x101D(0x1)
	bool Temp_bool_IsClosed_Variable_13 : 1;  // 0x101D(0x1)
	char pad_4126[2];  // 0x101E(0x2)
	float Temp_float_Variable_11;  // 0x1020(0x4)
	char pad_4132_1 : 7;  // 0x1024(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_3 : 1;  // 0x1024(0x1)
	char pad_4133[3];  // 0x1025(0x3)
	UC_Upgrade_C* CallFunc_Array_Get_Item_4;  // 0x1028(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x1030(0x4)
	char pad_4148[4];  // 0x1034(0x4)
	UC_UpgradeBleed_C* K2Node_ClassDynamicCast_AsC_Upgrade_Bleed;  // 0x1038(0x8)
	char pad_4160_1 : 7;  // 0x1040(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_3 : 1;  // 0x1040(0x1)
	char pad_4161_1 : 7;  // 0x1041(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1041(0x1)
	char pad_4162[6];  // 0x1042(0x6)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x1048(0x8)
	char pad_4176_1 : 7;  // 0x1050(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_4 : 1;  // 0x1050(0x1)
	char pad_4177_1 : 7;  // 0x1051(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1051(0x1)
	char pad_4178[6];  // 0x1052(0x6)
	struct FST_Effect CallFunc_EffectFromName_Effect;  // 0x1058(0x38)
	struct FST_Effect K2Node_MakeStruct_ST_Effect;  // 0x1090(0x38)
	int32_t Temp_int_Array_Index_Variable_26;  // 0x10C8(0x4)
	char pad_4300[4];  // 0x10CC(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_DamageCauser;  // 0x10D0(0x8)
	struct ABP_Effect_C* CallFunc_Array_Get_Item_5;  // 0x10D8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x10E0(0x4)
	char pad_4324[4];  // 0x10E4(0x4)
	struct ABP_Effect_Bleed_C* K2Node_DynamicCast_AsBP_Effect_Bleed;  // 0x10E8(0x8)
	char pad_4336_1 : 7;  // 0x10F0(0x1)
	bool K2Node_DynamicCast_bSuccess_14 : 1;  // 0x10F0(0x1)
	char pad_4337_1 : 7;  // 0x10F1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x10F1(0x1)
	char pad_4338[6];  // 0x10F2(0x6)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_AttackedTarget_3;  // 0x10F8(0x8)
	float K2Node_CustomEvent_BoltScale;  // 0x1100(0x4)
	float CallFunc_ApplyDamage_ReturnValue_2;  // 0x1104(0x4)
	char pad_4360_1 : 7;  // 0x1108(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_4 : 1;  // 0x1108(0x1)
	char pad_4361_1 : 7;  // 0x1109(0x1)
	bool CallFunc_IsValid_ReturnValue_10 : 1;  // 0x1109(0x1)
	char pad_4362[2];  // 0x110A(0x2)
	float CallFunc_GetDistanceTo_ReturnValue_3;  // 0x110C(0x4)
	char pad_4368_1 : 7;  // 0x1110(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_5 : 1;  // 0x1110(0x1)
	char pad_4369[7];  // 0x1111(0x7)
	UC_Upgrade_C* CallFunc_Array_Get_Item_6;  // 0x1118(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x1120(0x4)
	char pad_4388[4];  // 0x1124(0x4)
	UC_UpgradeBolt_C* K2Node_ClassDynamicCast_AsC_Upgrade_Bolt;  // 0x1128(0x8)
	char pad_4400_1 : 7;  // 0x1130(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_5 : 1;  // 0x1130(0x1)
	char pad_4401[7];  // 0x1131(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP_2;  // 0x1138(0x8)
	char pad_4416_1 : 7;  // 0x1140(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_6 : 1;  // 0x1140(0x1)
	char pad_4417[7];  // 0x1141(0x7)
	struct FST_Effect CallFunc_EffectFromName_Effect_2;  // 0x1148(0x38)
	char pad_4480_1 : 7;  // 0x1180(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_5 : 1;  // 0x1180(0x1)
	char pad_4481[7];  // 0x1181(0x7)
	struct FST_Effect K2Node_MakeStruct_ST_Effect_2;  // 0x1188(0x38)
	char pad_4544_1 : 7;  // 0x11C0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_8 : 1;  // 0x11C0(0x1)
	char pad_4545[7];  // 0x11C1(0x7)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_AttackedTarget_2;  // 0x11C8(0x8)
	float K2Node_CustomEvent_DrainScale;  // 0x11D0(0x4)
	char pad_4564_1 : 7;  // 0x11D4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_6 : 1;  // 0x11D4(0x1)
	char pad_4565[3];  // 0x11D5(0x3)
	float CallFunc_GetDistanceTo_ReturnValue_4;  // 0x11D8(0x4)
	char pad_4572_1 : 7;  // 0x11DC(0x1)
	bool CallFunc_IsValid_ReturnValue_11 : 1;  // 0x11DC(0x1)
	char pad_4573_1 : 7;  // 0x11DD(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_7 : 1;  // 0x11DD(0x1)
	char pad_4574_1 : 7;  // 0x11DE(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_7 : 1;  // 0x11DE(0x1)
	char pad_4575[1];  // 0x11DF(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x11E0(0x4)
	char pad_4580[4];  // 0x11E4(0x4)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP_3;  // 0x11E8(0x8)
	char pad_4592_1 : 7;  // 0x11F0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_7 : 1;  // 0x11F0(0x1)
	char pad_4593[7];  // 0x11F1(0x7)
	struct FST_Effect CallFunc_EffectFromName_Effect_3;  // 0x11F8(0x38)
	int32_t Temp_int_Loop_Counter_Variable_25;  // 0x1230(0x4)
	char pad_4660[4];  // 0x1234(0x4)
	struct FST_Effect K2Node_MakeStruct_ST_Effect_3;  // 0x1238(0x38)
	int32_t CallFunc_Add_IntInt_ReturnValue_25;  // 0x1270(0x4)
	char pad_4724[4];  // 0x1274(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_AttackedTarget;  // 0x1278(0x8)
	float K2Node_CustomEvent_VampireScale;  // 0x1280(0x4)
	char pad_4740_1 : 7;  // 0x1284(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_8 : 1;  // 0x1284(0x1)
	char pad_4741[3];  // 0x1285(0x3)
	float CallFunc_GetDistanceTo_ReturnValue_5;  // 0x1288(0x4)
	char pad_4748_1 : 7;  // 0x128C(0x1)
	bool CallFunc_IsValid_ReturnValue_12 : 1;  // 0x128C(0x1)
	char pad_4749[3];  // 0x128D(0x3)
	struct FDateTime CallFunc_Now_ReturnValue_29;  // 0x1290(0x8)
	char pad_4760_1 : 7;  // 0x1298(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_9 : 1;  // 0x1298(0x1)
	char pad_4761[7];  // 0x1299(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x12A0(0x10)
	struct FST_Effect CallFunc_EffectFromName_Effect_4;  // 0x12B0(0x38)
	int32_t CallFunc_Array_Length_ReturnValue_6;  // 0x12E8(0x4)
	char pad_4844[4];  // 0x12EC(0x4)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP_4;  // 0x12F0(0x8)
	char pad_4856_1 : 7;  // 0x12F8(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_8 : 1;  // 0x12F8(0x1)
	char pad_4857[7];  // 0x12F9(0x7)
	struct FST_Effect K2Node_MakeStruct_ST_Effect_4;  // 0x1300(0x38)
	struct FST_ItemBase CallFunc_Array_Get_Item_7;  // 0x1338(0x90)
	char pad_5064_1 : 7;  // 0x13C8(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_8 : 1;  // 0x13C8(0x1)
	char pad_5065_1 : 7;  // 0x13C9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0x13C9(0x1)
	char pad_5066_1 : 7;  // 0x13CA(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_4 : 1;  // 0x13CA(0x1)
	char pad_5067_1 : 7;  // 0x13CB(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0x13CB(0x1)
	int32_t CallFunc_Array_Length_ReturnValue_7;  // 0x13CC(0x4)
	float Temp_float_Variable_12;  // 0x13D0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_8;  // 0x13D4(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_BlindedTarget;  // 0x13D8(0x8)
	struct FST_Effect CallFunc_EffectFromName_Effect_5;  // 0x13E0(0x38)
	AFireExtinguisher_BP_C* K2Node_ClassDynamicCast_AsFire_Extinguisher_BP;  // 0x1418(0x8)
	char pad_5152_1 : 7;  // 0x1420(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_9 : 1;  // 0x1420(0x1)
	char pad_5153[7];  // 0x1421(0x7)
	ABP_Stim_Frenzy_C* K2Node_ClassDynamicCast_AsBP_Stim_Frenzy;  // 0x1428(0x8)
	char pad_5168_1 : 7;  // 0x1430(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_10 : 1;  // 0x1430(0x1)
	char pad_5169[3];  // 0x1431(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_8;  // 0x1434(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_9;  // 0x1440(0x4)
	int32_t K2Node_CustomEvent_SelectedSlot;  // 0x1444(0x4)
	struct FHitResult CallFunc_Array_Get_Item_8;  // 0x1448(0x88)
	char pad_5328_1 : 7;  // 0x14D0(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_2 : 1;  // 0x14D0(0x1)
	char pad_5329_1 : 7;  // 0x14D1(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_2 : 1;  // 0x14D1(0x1)
	char pad_5330[2];  // 0x14D2(0x2)
	float CallFunc_BreakHitResult_Time_2;  // 0x14D4(0x4)
	float CallFunc_BreakHitResult_Distance_2;  // 0x14D8(0x4)
	struct FVector CallFunc_BreakHitResult_Location_2;  // 0x14DC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_2;  // 0x14E8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_2;  // 0x14F4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_2;  // 0x1500(0xC)
	char pad_5388[4];  // 0x150C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_2;  // 0x1510(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_2;  // 0x1518(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_2;  // 0x1520(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_2;  // 0x1528(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_2;  // 0x1530(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_2;  // 0x1534(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_2;  // 0x1538(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_2;  // 0x153C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_2;  // 0x1548(0xC)
	char pad_5460[4];  // 0x1554(0x4)
	ABP_StimBase_C* K2Node_ClassDynamicCast_AsBP_Stim_Base;  // 0x1558(0x8)
	char pad_5472_1 : 7;  // 0x1560(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_11 : 1;  // 0x1560(0x1)
	char pad_5473[7];  // 0x1561(0x7)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated;  // 0x1568(0x8)
	char pad_5488_1 : 7;  // 0x1570(0x1)
	bool K2Node_DynamicCast_bSuccess_15 : 1;  // 0x1570(0x1)
	char pad_5489_1 : 7;  // 0x1571(0x1)
	bool CallFunc_CanBePunched_Can_Hit_ : 1;  // 0x1571(0x1)
	char pad_5490[6];  // 0x1572(0x6)
	struct FST_Effect CallFunc_EffectFromName_Effect_6;  // 0x1578(0x38)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x15B0(0x8)
	char pad_5560_1 : 7;  // 0x15B8(0x1)
	bool K2Node_DynamicCast_bSuccess_16 : 1;  // 0x15B8(0x1)
	char pad_5561[3];  // 0x15B9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_10;  // 0x15BC(0x4)
	ABP_Projectile_C* K2Node_CustomEvent_Class_5;  // 0x15C0(0x8)
	char pad_5576[8];  // 0x15C8(0x8)
	struct FTransform K2Node_CustomEvent_SpawnTransform_11;  // 0x15D0(0x30)
	struct APawn* K2Node_CustomEvent_Instigator_5;  // 0x1600(0x8)
	float K2Node_CustomEvent_Damage_12;  // 0x1608(0x4)
	int32_t K2Node_CustomEvent_SlotIndex_5;  // 0x160C(0x4)
	char pad_5648_1 : 7;  // 0x1610(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x1610(0x1)
	char pad_5649_1 : 7;  // 0x1611(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1611(0x1)
	char pad_5650[2];  // 0x1612(0x2)
	int32_t K2Node_CustomEvent__wood_2;  // 0x1614(0x4)
	int32_t K2Node_CustomEvent__metal_2;  // 0x1618(0x4)
	int32_t K2Node_CustomEvent__binder_2;  // 0x161C(0x4)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS_2;  // 0x1620(0x8)
	char pad_5672_1 : 7;  // 0x1628(0x1)
	bool K2Node_DynamicCast_bSuccess_17 : 1;  // 0x1628(0x1)
	char pad_5673_1 : 7;  // 0x1629(0x1)
	bool CallFunc_IsDev_Server_ReturnValue_2 : 1;  // 0x1629(0x1)
	char pad_5674[6];  // 0x162A(0x6)
	struct FTransform K2Node_CustomEvent_SpawnTransform_10;  // 0x1630(0x30)
	float K2Node_CustomEvent_Time_8;  // 0x1660(0x4)
	struct FVector K2Node_CustomEvent_Launch_2;  // 0x1664(0xC)
	float K2Node_CustomEvent_Intensity_2;  // 0x1670(0x4)
	float K2Node_CustomEvent_Radius_2;  // 0x1674(0x4)
	ADynamite_BP_C* K2Node_ClassDynamicCast_AsDynamite_BP;  // 0x1678(0x8)
	char pad_5760_1 : 7;  // 0x1680(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_12 : 1;  // 0x1680(0x1)
	char pad_5761[15];  // 0x1681(0xF)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x1690(0x30)
	ADynamite_BP_C* K2Node_ClassDynamicCast_AsDynamite_BP_2;  // 0x16C0(0x8)
	char pad_5832_1 : 7;  // 0x16C8(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_13 : 1;  // 0x16C8(0x1)
	char pad_5833[7];  // 0x16C9(0x7)
	struct FTransform K2Node_CustomEvent_ExplosiveArrow;  // 0x16D0(0x30)
	char pad_5888_1 : 7;  // 0x1700(0x1)
	bool Temp_bool_Variable_11 : 1;  // 0x1700(0x1)
	char pad_5889[3];  // 0x1701(0x3)
	int32_t Temp_int_Loop_Counter_Variable_26;  // 0x1704(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_30;  // 0x1708(0x8)
	char pad_5904_1 : 7;  // 0x1710(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x1710(0x1)
	char pad_5905[3];  // 0x1711(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_26;  // 0x1714(0x4)
	struct FDateTime Temp_wildcard_Variable_10;  // 0x1718(0x8)
	float K2Node_InputAxisEvent_AxisValue_5;  // 0x1720(0x4)
	char pad_5924[4];  // 0x1724(0x4)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_10;  // 0x1728(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_10;  // 0x1730(0x4)
	float K2Node_InputAxisEvent_AxisValue_4;  // 0x1734(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_7;  // 0x1738(0x4)
	float K2Node_InputAxisEvent_AxisValue_3;  // 0x173C(0x4)
	char pad_5952_1 : 7;  // 0x1740(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_8 : 1;  // 0x1740(0x1)
	char pad_5953[3];  // 0x1741(0x3)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x1744(0x4)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x1748(0xC)
	struct FVector CallFunc_GetActorRightVector_ReturnValue;  // 0x1754(0xC)
	float K2Node_Event_DeltaSeconds;  // 0x1760(0x4)
	float Temp_float_Variable_13;  // 0x1764(0x4)
	float K2Node_CustomEvent_SpineRotationX;  // 0x1768(0x4)
	char pad_5996_1 : 7;  // 0x176C(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_6 : 1;  // 0x176C(0x1)
	char pad_5997[3];  // 0x176D(0x3)
	float Temp_float_Variable_14;  // 0x1770(0x4)
	char pad_6004_1 : 7;  // 0x1774(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_9 : 1;  // 0x1774(0x1)
	char pad_6005_1 : 7;  // 0x1775(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x1775(0x1)
	char pad_6006[2];  // 0x1776(0x2)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x1778(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x177C(0x4)
	char pad_6016_1 : 7;  // 0x1780(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_9 : 1;  // 0x1780(0x1)
	char pad_6017_1 : 7;  // 0x1781(0x1)
	bool Temp_bool_Variable_12 : 1;  // 0x1781(0x1)
	char pad_6018_1 : 7;  // 0x1782(0x1)
	bool CallFunc_HasAuthority_ReturnValue_13 : 1;  // 0x1782(0x1)
	char pad_6019_1 : 7;  // 0x1783(0x1)
	bool CallFunc_IsValid_ReturnValue_13 : 1;  // 0x1783(0x1)
	char pad_6020[4];  // 0x1784(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x1788(0x8)
	struct UGI_BR_C* K2Node_DynamicCast_AsGI_BR;  // 0x1790(0x8)
	char pad_6040_1 : 7;  // 0x1798(0x1)
	bool K2Node_DynamicCast_bSuccess_18 : 1;  // 0x1798(0x1)
	char pad_6041[7];  // 0x1799(0x7)
	struct USaveGame* Temp_object_Variable_7;  // 0x17A0(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save;  // 0x17A8(0x8)
	char pad_6064_1 : 7;  // 0x17B0(0x1)
	bool K2Node_DynamicCast_bSuccess_19 : 1;  // 0x17B0(0x1)
	char pad_6065_1 : 7;  // 0x17B1(0x1)
	bool Temp_bool_Variable_13 : 1;  // 0x17B1(0x1)
	char pad_6066_1 : 7;  // 0x17B2(0x1)
	bool CallFunc_HasAuthority_ReturnValue_14 : 1;  // 0x17B2(0x1)
	char pad_6067_1 : 7;  // 0x17B3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_10 : 1;  // 0x17B3(0x1)
	char pad_6068_1 : 7;  // 0x17B4(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x17B4(0x1)
	char pad_6069_1 : 7;  // 0x17B5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_11 : 1;  // 0x17B5(0x1)
	char pad_6070_1 : 7;  // 0x17B6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x17B6(0x1)
	char pad_6071[1];  // 0x17B7(0x1)
	struct USaveGame* K2Node_CustomEvent_SaveGame;  // 0x17B8(0x8)
	char pad_6080_1 : 7;  // 0x17C0(0x1)
	bool K2Node_CustomEvent_bSuccess : 1;  // 0x17C0(0x1)
	char pad_6081[3];  // 0x17C1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x17C4(0x10)
	char pad_6100_1 : 7;  // 0x17D4(0x1)
	bool CallFunc_HasAuthority_ReturnValue_15 : 1;  // 0x17D4(0x1)
	char pad_6101[3];  // 0x17D5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x17D8(0x10)
	char pad_6120_1 : 7;  // 0x17E8(0x1)
	bool CallFunc_CanDoStuff__ : 1;  // 0x17E8(0x1)
	char pad_6121_1 : 7;  // 0x17E9(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_9 : 1;  // 0x17E9(0x1)
	uint8_t  Temp_byte_Variable;  // 0x17EA(0x1)
	char pad_6123_1 : 7;  // 0x17EB(0x1)
	bool CallFunc_IsFalling_ReturnValue : 1;  // 0x17EB(0x1)
	int32_t Temp_int_Array_Index_Variable_27;  // 0x17EC(0x4)
	UC_Upgrade_C* CallFunc_Array_Get_Item_9;  // 0x17F0(0x8)
	UC_UpgradeDrain_C* K2Node_ClassDynamicCast_AsC_Upgrade_Drain;  // 0x17F8(0x8)
	char pad_6144_1 : 7;  // 0x1800(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_14 : 1;  // 0x1800(0x1)
	uint8_t  Temp_byte_Variable_2;  // 0x1801(0x1)
	char pad_6146_1 : 7;  // 0x1802(0x1)
	bool Temp_bool_Variable_14 : 1;  // 0x1802(0x1)
	char pad_6147[5];  // 0x1803(0x5)
	ABP_Placable_C* K2Node_CustomEvent_Class_4;  // 0x1808(0x8)
	struct FTransform K2Node_CustomEvent_SpawnTransform_9;  // 0x1810(0x30)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x1840(0x10)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x1850(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0x1858(0x8)
	struct ABP_Placable_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0x1860(0x8)
	struct USaveGame* Temp_object_Variable_8;  // 0x1868(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0x1870(0x8)
	char pad_6264_1 : 7;  // 0x1878(0x1)
	bool Temp_bool_Variable_15 : 1;  // 0x1878(0x1)
	char pad_6265[7];  // 0x1879(0x7)
	struct UCharacter_AnimBP_C* K2Node_DynamicCast_AsCharacter_Anim_BP;  // 0x1880(0x8)
	char pad_6280_1 : 7;  // 0x1888(0x1)
	bool K2Node_DynamicCast_bSuccess_20 : 1;  // 0x1888(0x1)
	char pad_6281[7];  // 0x1889(0x7)
	struct USaveGame* K2Node_CustomEvent_SaveGame_2;  // 0x1890(0x8)
	char pad_6296_1 : 7;  // 0x1898(0x1)
	bool K2Node_CustomEvent_bSuccess_2 : 1;  // 0x1898(0x1)
	char pad_6297[7];  // 0x1899(0x7)
	struct AKeyCardReader_BP_C* K2Node_CustomEvent_reader;  // 0x18A0(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0x18A8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_4;  // 0x18AC(0x4)
	char pad_6320_1 : 7;  // 0x18B0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_14 : 1;  // 0x18B0(0x1)
	char pad_6321_1 : 7;  // 0x18B1(0x1)
	bool CallFunc_IsValid_ReturnValue_14 : 1;  // 0x18B1(0x1)
	char pad_6322[6];  // 0x18B2(0x6)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x18B8(0x10)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Teammate;  // 0x18C8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_11;  // 0x18D0(0x4)
	char pad_6356_1 : 7;  // 0x18D4(0x1)
	bool CallFunc_IsValid_ReturnValue_15 : 1;  // 0x18D4(0x1)
	char pad_6357_1 : 7;  // 0x18D5(0x1)
	bool CallFunc_IsValid_ReturnValue_16 : 1;  // 0x18D5(0x1)
	char pad_6358_1 : 7;  // 0x18D6(0x1)
	bool Temp_bool_Variable_16 : 1;  // 0x18D6(0x1)
	char pad_6359_1 : 7;  // 0x18D7(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_12 : 1;  // 0x18D7(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x18D8(0x10)
	struct APlayerBRController_C* CallFunc_PC_pc_7;  // 0x18E8(0x8)
	char pad_6384_1 : 7;  // 0x18F0(0x1)
	bool CallFunc_IsValid_ReturnValue_17 : 1;  // 0x18F0(0x1)
	char pad_6385[7];  // 0x18F1(0x7)
	struct FString K2Node_CustomEvent_ID_16;  // 0x18F8(0x10)
	char pad_6408_1 : 7;  // 0x1908(0x1)
	bool CallFunc_IsValid_ReturnValue_18 : 1;  // 0x1908(0x1)
	char pad_6409[7];  // 0x1909(0x7)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // 0x1910(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR;  // 0x1918(0x8)
	char pad_6432_1 : 7;  // 0x1920(0x1)
	bool K2Node_DynamicCast_bSuccess_21 : 1;  // 0x1920(0x1)
	char pad_6433[3];  // 0x1921(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_12;  // 0x1924(0x4)
	char pad_6440_1 : 7;  // 0x1928(0x1)
	bool CallFunc_IsValid_ReturnValue_19 : 1;  // 0x1928(0x1)
	char pad_6441[7];  // 0x1929(0x7)
	struct APlayerBRController_C* K2Node_CustomEvent_PC;  // 0x1930(0x8)
	struct AController* K2Node_Event_NewController;  // 0x1938(0x8)
	char pad_6464_1 : 7;  // 0x1940(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_15 : 1;  // 0x1940(0x1)
	char pad_6465[7];  // 0x1941(0x7)
	struct AAI_PC_C* K2Node_DynamicCast_AsAI_PC;  // 0x1948(0x8)
	char pad_6480_1 : 7;  // 0x1950(0x1)
	bool K2Node_DynamicCast_bSuccess_22 : 1;  // 0x1950(0x1)
	char pad_6481[7];  // 0x1951(0x7)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS_3;  // 0x1958(0x8)
	char pad_6496_1 : 7;  // 0x1960(0x1)
	bool K2Node_DynamicCast_bSuccess_23 : 1;  // 0x1960(0x1)
	char pad_6497[3];  // 0x1961(0x3)
	float CallFunc_GetSpineRotationX_X__Roll_;  // 0x1964(0x4)
	struct FHitResult K2Node_Event_Hit;  // 0x1968(0x88)
	struct APlayerBRController_C* CallFunc_PC_pc_8;  // 0x19F0(0x8)
	char pad_6648_1 : 7;  // 0x19F8(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_16 : 1;  // 0x19F8(0x1)
	char pad_6649[3];  // 0x19F9(0x3)
	float CallFunc_GetGravityZ_ReturnValue;  // 0x19FC(0x4)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x1A00(0xC)
	float CallFunc_Abs_ReturnValue;  // 0x1A0C(0x4)
	float CallFunc_BreakVector_X;  // 0x1A10(0x4)
	float CallFunc_BreakVector_Y;  // 0x1A14(0x4)
	float CallFunc_BreakVector_Z;  // 0x1A18(0x4)
	char pad_6684[4];  // 0x1A1C(0x4)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x1A20(0x10)
	float CallFunc_Abs_ReturnValue_2;  // 0x1A30(0x4)
	char pad_6708[4];  // 0x1A34(0x4)
	struct TArray<struct FST_Cosmetic> CallFunc_StringsToCosmetics_cos;  // 0x1A38(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue_8;  // 0x1A48(0x4)
	char pad_6732[4];  // 0x1A4C(0x4)
	struct TArray<struct FST_RepCosmetic> CallFunc_CosmeticsToRep_Meshes;  // 0x1A50(0x10)
	char pad_6752_1 : 7;  // 0x1A60(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_10 : 1;  // 0x1A60(0x1)
	char pad_6753[3];  // 0x1A61(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_5;  // 0x1A64(0x4)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR;  // 0x1A68(0x8)
	struct FST_PlayerSettings K2Node_CustomEvent_New_Settings;  // 0x1A70(0x30)
	float CallFunc_Divide_FloatFloat_ReturnValue_9;  // 0x1AA0(0x4)
	float K2Node_Select_Default;  // 0x1AA4(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x1AA8(0x4)
	uint8_t  K2Node_Select_Default_2;  // 0x1AAC(0x1)
	char pad_6829[3];  // 0x1AAD(0x3)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_4;  // 0x1AB0(0x8)
	struct UBaseHUD_C* CallFunc_HUD_AsBase_HUD;  // 0x1AB8(0x8)
	char pad_6848_1 : 7;  // 0x1AC0(0x1)
	bool CallFunc_HUD_valid : 1;  // 0x1AC0(0x1)
	char pad_6849[3];  // 0x1AC1(0x3)
	float CallFunc_GetSpineRotationX_X__Roll__2;  // 0x1AC4(0x4)
	char pad_6856_1 : 7;  // 0x1AC8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_13 : 1;  // 0x1AC8(0x1)
	char pad_6857_1 : 7;  // 0x1AC9(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_17 : 1;  // 0x1AC9(0x1)
	char pad_6858_1 : 7;  // 0x1ACA(0x1)
	bool CallFunc_BooleanAND_ReturnValue_6 : 1;  // 0x1ACA(0x1)
	char pad_6859_1 : 7;  // 0x1ACB(0x1)
	bool CallFunc_GetGlobalVar_bool : 1;  // 0x1ACB(0x1)
	char pad_6860_1 : 7;  // 0x1ACC(0x1)
	bool K2Node_CustomEvent_GodMode : 1;  // 0x1ACC(0x1)
	char pad_6861_1 : 7;  // 0x1ACD(0x1)
	bool CallFunc_EqualEqual_BoolBool_ReturnValue : 1;  // 0x1ACD(0x1)
	char pad_6862_1 : 7;  // 0x1ACE(0x1)
	bool CallFunc_GetGlobalVar_bool_2 : 1;  // 0x1ACE(0x1)
	char pad_6863[1];  // 0x1ACF(0x1)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_4;  // 0x1AD0(0x8)
	char pad_6872_1 : 7;  // 0x1AD8(0x1)
	bool K2Node_CustomEvent_Index : 1;  // 0x1AD8(0x1)
	char pad_6873[7];  // 0x1AD9(0x7)
	struct FString CallFunc_BreakSteamID_ReturnValue_4;  // 0x1AE0(0x10)
	struct UBaseHUD_C* CallFunc_HUD_AsBase_HUD_2;  // 0x1AF0(0x8)
	char pad_6904_1 : 7;  // 0x1AF8(0x1)
	bool CallFunc_HUD_valid_2 : 1;  // 0x1AF8(0x1)
	char pad_6905_1 : 7;  // 0x1AF9(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_4 : 1;  // 0x1AF9(0x1)
	char pad_6906_1 : 7;  // 0x1AFA(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_18 : 1;  // 0x1AFA(0x1)
	char pad_6907[5];  // 0x1AFB(0x5)
	struct FKey K2Node_InputActionEvent_Key_41;  // 0x1B00(0x18)
	char pad_6936_1 : 7;  // 0x1B18(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_10 : 1;  // 0x1B18(0x1)
	char pad_6937[7];  // 0x1B19(0x7)
	struct FKey K2Node_InputActionEvent_Key_42;  // 0x1B20(0x18)
	float Temp_float_Variable_15;  // 0x1B38(0x4)
	char pad_6972[4];  // 0x1B3C(0x4)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_5;  // 0x1B40(0x8)
	struct USoundBase* K2Node_CustomEvent_NewSound;  // 0x1B48(0x8)
	float K2Node_CustomEvent_FadeInDuration;  // 0x1B50(0x4)
	char pad_6996_1 : 7;  // 0x1B54(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_19 : 1;  // 0x1B54(0x1)
	char pad_6997[3];  // 0x1B55(0x3)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_5;  // 0x1B58(0x8)
	struct APlayerBRController_C* CallFunc_PC_pc_9;  // 0x1B60(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_5;  // 0x1B68(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_4;  // 0x1B78(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_4;  // 0x1B80(0x8)
	char pad_7048_1 : 7;  // 0x1B88(0x1)
	bool CallFunc_IsValid_ReturnValue_20 : 1;  // 0x1B88(0x1)
	char pad_7049_1 : 7;  // 0x1B89(0x1)
	bool CallFunc_IsValid_ReturnValue_21 : 1;  // 0x1B89(0x1)
	char pad_7050_1 : 7;  // 0x1B8A(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_5 : 1;  // 0x1B8A(0x1)
	char pad_7051[5];  // 0x1B8B(0x5)
	struct ABP_ItemPickup_C* K2Node_CustomEvent_Pickup_5;  // 0x1B90(0x8)
	char pad_7064_1 : 7;  // 0x1B98(0x1)
	bool CallFunc_IsValid_ReturnValue_22 : 1;  // 0x1B98(0x1)
	char pad_7065[7];  // 0x1B99(0x7)
	struct UchargeBar_C* CallFunc_AddCharge_widget;  // 0x1BA0(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_2;  // 0x1BA8(0x4)
	char pad_7084_1 : 7;  // 0x1BAC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0x1BAC(0x1)
	char pad_7085[3];  // 0x1BAD(0x3)
	int32_t CallFunc_Min_ReturnValue;  // 0x1BB0(0x4)
	char pad_7092_1 : 7;  // 0x1BB4(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0x1BB4(0x1)
	char pad_7093[3];  // 0x1BB5(0x3)
	int32_t CallFunc_MakeLiteralInt_ReturnValue;  // 0x1BB8(0x4)
	char pad_7100_1 : 7;  // 0x1BBC(0x1)
	bool CallFunc_BooleanAND_ReturnValue_7 : 1;  // 0x1BBC(0x1)
	char pad_7101[3];  // 0x1BBD(0x3)
	float Temp_float_Variable_16;  // 0x1BC0(0x4)
	char pad_7108_1 : 7;  // 0x1BC4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_14 : 1;  // 0x1BC4(0x1)
	char pad_7109[3];  // 0x1BC5(0x3)
	float K2Node_CustomEvent_VolumeMultiplier_6;  // 0x1BC8(0x4)
	float K2Node_CustomEvent_PitchMultiplier_8;  // 0x1BCC(0x4)
	char pad_7120_1 : 7;  // 0x1BD0(0x1)
	bool K2Node_CustomEvent_Priority : 1;  // 0x1BD0(0x1)
	char EPhysicalSurface K2Node_CustomEvent_SurfaceType;  // 0x1BD1(0x1)
	char pad_7122[2];  // 0x1BD2(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x1BD4(0xC)
	struct FDateTime CallFunc_Now_ReturnValue_31;  // 0x1BE0(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_32;  // 0x1BE8(0x8)
	char pad_7152_1 : 7;  // 0x1BF0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_20 : 1;  // 0x1BF0(0x1)
	char pad_7153[7];  // 0x1BF1(0x7)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_11;  // 0x1BF8(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_11;  // 0x1C00(0x4)
	char pad_7172[4];  // 0x1C04(0x4)
	struct TArray<int32_t> K2Node_MakeArray_Array_2;  // 0x1C08(0x10)
	char pad_7192_1 : 7;  // 0x1C18(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_10 : 1;  // 0x1C18(0x1)
	char pad_7193_1 : 7;  // 0x1C19(0x1)
	bool Temp_bool_Variable_17 : 1;  // 0x1C19(0x1)
	char pad_7194[6];  // 0x1C1A(0x6)
	struct AController* CallFunc_GetController_ReturnValue_13;  // 0x1C20(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_13;  // 0x1C28(0x8)
	char pad_7216_1 : 7;  // 0x1C30(0x1)
	bool K2Node_DynamicCast_bSuccess_24 : 1;  // 0x1C30(0x1)
	char pad_7217[3];  // 0x1C31(0x3)
	int32_t K2Node_CustomEvent_Slot_11;  // 0x1C34(0x4)
	int32_t K2Node_CustomEvent_Ammo_2;  // 0x1C38(0x4)
	char pad_7228[4];  // 0x1C3C(0x4)
	struct AActor* K2Node_CustomEvent_actor_7;  // 0x1C40(0x8)
	char EPhysicalSurface CallFunc_WalkingSurfaceTrace_SurfaceType;  // 0x1C48(0x1)
	char pad_7241_1 : 7;  // 0x1C49(0x1)
	bool CallFunc_IsValid_ReturnValue_23 : 1;  // 0x1C49(0x1)
	char EPhysicalSurface CallFunc_WalkingSurfaceTrace_SurfaceType_2;  // 0x1C4A(0x1)
	char pad_7243[5];  // 0x1C4B(0x5)
	struct AFirstPersonCharacter_C* CallFunc_GetClosestPlayer_ClosestPlayer1;  // 0x1C50(0x8)
	char pad_7256_1 : 7;  // 0x1C58(0x1)
	bool Temp_bool_IsClosed_Variable_14 : 1;  // 0x1C58(0x1)
	char pad_7257_1 : 7;  // 0x1C59(0x1)
	bool CallFunc_IsValid_ReturnValue_24 : 1;  // 0x1C59(0x1)
	char pad_7258_1 : 7;  // 0x1C5A(0x1)
	bool CallFunc_IsValid_ReturnValue_25 : 1;  // 0x1C5A(0x1)
	char pad_7259[1];  // 0x1C5B(0x1)
	float K2Node_Select_Default_3;  // 0x1C5C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_6;  // 0x1C60(0x4)
	char pad_7268[4];  // 0x1C64(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc_10;  // 0x1C68(0x8)
	char pad_7280_1 : 7;  // 0x1C70(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_11 : 1;  // 0x1C70(0x1)
	char pad_7281[7];  // 0x1C71(0x7)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD;  // 0x1C78(0x8)
	char pad_7296_1 : 7;  // 0x1C80(0x1)
	bool K2Node_DynamicCast_bSuccess_25 : 1;  // 0x1C80(0x1)
	char pad_7297_1 : 7;  // 0x1C81(0x1)
	bool CallFunc_IsValid_ReturnValue_26 : 1;  // 0x1C81(0x1)
	char pad_7298_1 : 7;  // 0x1C82(0x1)
	bool CallFunc_BooleanAND_ReturnValue_8 : 1;  // 0x1C82(0x1)
	char pad_7299[5];  // 0x1C83(0x5)
	struct APlayerBRController_C* CallFunc_PC_pc_11;  // 0x1C88(0x8)
	int32_t K2Node_CustomEvent_ItemID;  // 0x1C90(0x4)
	char pad_7316[4];  // 0x1C94(0x4)
	struct FST_CraftRecipe CallFunc_GetRecipeFromResultingID_Recipe;  // 0x1C98(0x28)
	int32_t CallFunc_FindRecipeIDFromResultingItem_Recipe_ID;  // 0x1CC0(0x4)
	char pad_7364[4];  // 0x1CC4(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc_12;  // 0x1CC8(0x8)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x1CD0(0x10)
	struct FST_UndiscoveredItem K2Node_MakeStruct_ST_UndiscoveredItem;  // 0x1CE0(0x30)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD_2;  // 0x1D10(0x8)
	char pad_7448_1 : 7;  // 0x1D18(0x1)
	bool K2Node_DynamicCast_bSuccess_26 : 1;  // 0x1D18(0x1)
	char pad_7449[7];  // 0x1D19(0x7)
	struct USoundBase* Temp_object_Variable_9;  // 0x1D20(0x8)
	char pad_7464_1 : 7;  // 0x1D28(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_21 : 1;  // 0x1D28(0x1)
	char pad_7465[7];  // 0x1D29(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc_13;  // 0x1D30(0x8)
	struct USoundBase* Temp_object_Variable_10;  // 0x1D38(0x8)
	char pad_7488_1 : 7;  // 0x1D40(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_15 : 1;  // 0x1D40(0x1)
	char pad_7489_1 : 7;  // 0x1D41(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_22 : 1;  // 0x1D41(0x1)
	char EPhysicalSurface Temp_byte_Variable_3;  // 0x1D42(0x1)
	char pad_7491_1 : 7;  // 0x1D43(0x1)
	bool Temp_bool_IsClosed_Variable_15 : 1;  // 0x1D43(0x1)
	char pad_7492[4];  // 0x1D44(0x4)
	struct USoundBase* K2Node_Select_Default_4;  // 0x1D48(0x8)
	struct USaveGame* Temp_object_Variable_11;  // 0x1D50(0x8)
	char pad_7512_1 : 7;  // 0x1D58(0x1)
	bool Temp_bool_Variable_18 : 1;  // 0x1D58(0x1)
	char pad_7513[7];  // 0x1D59(0x7)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_2;  // 0x1D60(0x8)
	char pad_7528_1 : 7;  // 0x1D68(0x1)
	bool K2Node_DynamicCast_bSuccess_27 : 1;  // 0x1D68(0x1)
	char pad_7529[3];  // 0x1D69(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x1D6C(0x4)
	char pad_7536_1 : 7;  // 0x1D70(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x1D70(0x1)
	char pad_7537[3];  // 0x1D71(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x1D74(0x4)
	char pad_7544_1 : 7;  // 0x1D78(0x1)
	bool CallFunc_K2_IsValidTimerHandle_ReturnValue : 1;  // 0x1D78(0x1)
	char pad_7545[7];  // 0x1D79(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x1D80(0x10)
	char pad_7568_1 : 7;  // 0x1D90(0x1)
	bool CallFunc_IsValid_ReturnValue_27 : 1;  // 0x1D90(0x1)
	char pad_7569[3];  // 0x1D91(0x3)
	struct FHitResult CallFunc_Array_Get_Item_10;  // 0x1D94(0x88)
	char pad_7708_1 : 7;  // 0x1E1C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_14 : 1;  // 0x1E1C(0x1)
	char pad_7709_1 : 7;  // 0x1E1D(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_3 : 1;  // 0x1E1D(0x1)
	char pad_7710_1 : 7;  // 0x1E1E(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_3 : 1;  // 0x1E1E(0x1)
	char pad_7711[1];  // 0x1E1F(0x1)
	float CallFunc_BreakHitResult_Time_3;  // 0x1E20(0x4)
	float CallFunc_BreakHitResult_Distance_3;  // 0x1E24(0x4)
	struct FVector CallFunc_BreakHitResult_Location_3;  // 0x1E28(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_3;  // 0x1E34(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_3;  // 0x1E40(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_3;  // 0x1E4C(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_3;  // 0x1E58(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_3;  // 0x1E60(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_3;  // 0x1E68(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_3;  // 0x1E70(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_3;  // 0x1E78(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_3;  // 0x1E7C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_3;  // 0x1E80(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_3;  // 0x1E84(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_3;  // 0x1E90(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_13;  // 0x1E9C(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x1EA0(0x8)
	char pad_7848_1 : 7;  // 0x1EA8(0x1)
	bool K2Node_DynamicCast_bSuccess_28 : 1;  // 0x1EA8(0x1)
	char pad_7849_1 : 7;  // 0x1EA9(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_6 : 1;  // 0x1EA9(0x1)
	char pad_7850_1 : 7;  // 0x1EAA(0x1)
	bool CallFunc_BooleanAND_ReturnValue_9 : 1;  // 0x1EAA(0x1)
	char pad_7851[1];  // 0x1EAB(0x1)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0x1EAC(0xC)
	float CallFunc_VSize_ReturnValue;  // 0x1EB8(0x4)
	float CallFunc_MapRangeClamped_ReturnValue;  // 0x1EBC(0x4)
	float CallFunc_MapRangeClamped_ReturnValue_2;  // 0x1EC0(0x4)
	float K2Node_CustomEvent_FromAlpha;  // 0x1EC4(0x4)
	float K2Node_CustomEvent_ToAlpha;  // 0x1EC8(0x4)
	float K2Node_CustomEvent_Duration_2;  // 0x1ECC(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc_14;  // 0x1ED0(0x8)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue_6;  // 0x1ED8(0x8)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_6;  // 0x1EE0(0x8)
	char pad_7912_1 : 7;  // 0x1EE8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_16 : 1;  // 0x1EE8(0x1)
	char pad_7913[7];  // 0x1EE9(0x7)
	struct FString CallFunc_BreakSteamID_ReturnValue_6;  // 0x1EF0(0x10)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_5;  // 0x1F00(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue_5;  // 0x1F08(0x8)
	char pad_7952_1 : 7;  // 0x1F10(0x1)
	bool CallFunc_IsValid_ReturnValue_28 : 1;  // 0x1F10(0x1)
	char pad_7953_1 : 7;  // 0x1F11(0x1)
	bool CallFunc_IsValid_ReturnValue_29 : 1;  // 0x1F11(0x1)
	char pad_7954_1 : 7;  // 0x1F12(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue_6 : 1;  // 0x1F12(0x1)
	char pad_7955[5];  // 0x1F13(0x5)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS_4;  // 0x1F18(0x8)
	char pad_7968_1 : 7;  // 0x1F20(0x1)
	bool K2Node_DynamicCast_bSuccess_29 : 1;  // 0x1F20(0x1)
	char pad_7969_1 : 7;  // 0x1F21(0x1)
	bool CallFunc_IsDev_Server_ReturnValue_3 : 1;  // 0x1F21(0x1)
	char pad_7970_1 : 7;  // 0x1F22(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_2 : 1;  // 0x1F22(0x1)
	char pad_7971_1 : 7;  // 0x1F23(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_15 : 1;  // 0x1F23(0x1)
	char pad_7972_1 : 7;  // 0x1F24(0x1)
	bool CallFunc_BooleanOR_ReturnValue_5 : 1;  // 0x1F24(0x1)
	char pad_7973[3];  // 0x1F25(0x3)
	struct APlayerBRController_C* CallFunc_PC_pc_15;  // 0x1F28(0x8)
	char pad_7984_1 : 7;  // 0x1F30(0x1)
	bool CallFunc_BooleanOR_ReturnValue_6 : 1;  // 0x1F30(0x1)
	char pad_7985[7];  // 0x1F31(0x7)
	struct USaveGame* K2Node_CustomEvent_SaveGame_3;  // 0x1F38(0x8)
	char pad_8000_1 : 7;  // 0x1F40(0x1)
	bool K2Node_CustomEvent_bSuccess_3 : 1;  // 0x1F40(0x1)
	char pad_8001_1 : 7;  // 0x1F41(0x1)
	bool Temp_bool_IsClosed_Variable_16 : 1;  // 0x1F41(0x1)
	char pad_8002_1 : 7;  // 0x1F42(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1F42(0x1)
	char pad_8003[1];  // 0x1F43(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0x1F44(0x10)
	char pad_8020_1 : 7;  // 0x1F54(0x1)
	bool CallFunc_BooleanAND_ReturnValue_10 : 1;  // 0x1F54(0x1)
	char pad_8021[3];  // 0x1F55(0x3)
	struct APlayerBRController_C* CallFunc_PC_pc_16;  // 0x1F58(0x8)
	char pad_8032_1 : 7;  // 0x1F60(0x1)
	bool CallFunc_IsValid_ReturnValue_30 : 1;  // 0x1F60(0x1)
	char pad_8033_1 : 7;  // 0x1F61(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_17 : 1;  // 0x1F61(0x1)
	char pad_8034[2];  // 0x1F62(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0x1F64(0x10)
	char pad_8052_1 : 7;  // 0x1F74(0x1)
	bool Temp_bool_IsClosed_Variable_17 : 1;  // 0x1F74(0x1)
	char pad_8053[3];  // 0x1F75(0x3)
	struct FHitResult K2Node_CustomEvent_Hit_4;  // 0x1F78(0x88)
	char pad_8192_1 : 7;  // 0x2000(0x1)
	bool CallFunc_ShouldReceiveFallDamage_Result : 1;  // 0x2000(0x1)
	char pad_8193[7];  // 0x2001(0x7)
	struct FST_Effect CallFunc_EffectFromName_Effect_7;  // 0x2008(0x38)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_9;  // 0x2040(0xC)
	struct FVector CallFunc_GetLastUpdateVelocity_ReturnValue;  // 0x204C(0xC)
	float CallFunc_BreakVector_X_2;  // 0x2058(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x205C(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x2060(0x4)
	float CallFunc_Abs_ReturnValue_3;  // 0x2064(0x4)
	char pad_8296_1 : 7;  // 0x2068(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_11 : 1;  // 0x2068(0x1)
	char pad_8297[3];  // 0x2069(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue_10;  // 0x206C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_7;  // 0x2070(0x4)
	char pad_8308_1 : 7;  // 0x2074(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_12 : 1;  // 0x2074(0x1)
	char pad_8309[3];  // 0x2075(0x3)
	float CallFunc_FMin_ReturnValue;  // 0x2078(0x4)
	char pad_8316_1 : 7;  // 0x207C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_11 : 1;  // 0x207C(0x1)
	char pad_8317[3];  // 0x207D(0x3)
	float CallFunc_ApplyDamage_ReturnValue_3;  // 0x2080(0x4)
	char pad_8324_1 : 7;  // 0x2084(0x1)
	bool K2Node_CustomEvent_Interacting : 1;  // 0x2084(0x1)
	char pad_8325_1 : 7;  // 0x2085(0x1)
	bool K2Node_CustomEvent_interact : 1;  // 0x2085(0x1)
	char pad_8326[2];  // 0x2086(0x2)
	struct AMovable_Object_Replicated_C* K2Node_CustomEvent_prop_2;  // 0x2088(0x8)
	struct FVector K2Node_CustomEvent_ThrowVector_3;  // 0x2090(0xC)
	char pad_8348_1 : 7;  // 0x209C(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_18 : 1;  // 0x209C(0x1)
	char pad_8349_1 : 7;  // 0x209D(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x209D(0x1)
	char pad_8350[2];  // 0x209E(0x2)
	struct USaveGame* Temp_object_Variable_12;  // 0x20A0(0x8)
	char pad_8360_1 : 7;  // 0x20A8(0x1)
	bool Temp_bool_Variable_19 : 1;  // 0x20A8(0x1)
	char pad_8361[3];  // 0x20A9(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x20AC(0xC)
	struct FVector CallFunc_GetLastUpdateVelocity_ReturnValue_2;  // 0x20B8(0xC)
	struct FHitResult CallFunc_InteractTrace_OutHit;  // 0x20C4(0x88)
	char pad_8524_1 : 7;  // 0x214C(0x1)
	bool CallFunc_InteractTrace_ReturnValue : 1;  // 0x214C(0x1)
	char pad_8525_1 : 7;  // 0x214D(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_4 : 1;  // 0x214D(0x1)
	char pad_8526_1 : 7;  // 0x214E(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_4 : 1;  // 0x214E(0x1)
	char pad_8527[1];  // 0x214F(0x1)
	float CallFunc_BreakHitResult_Time_4;  // 0x2150(0x4)
	float CallFunc_BreakHitResult_Distance_4;  // 0x2154(0x4)
	struct FVector CallFunc_BreakHitResult_Location_4;  // 0x2158(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_4;  // 0x2164(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_4;  // 0x2170(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_4;  // 0x217C(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_4;  // 0x2188(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_4;  // 0x2190(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_4;  // 0x2198(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_4;  // 0x21A0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_4;  // 0x21A8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_4;  // 0x21AC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_4;  // 0x21B0(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_4;  // 0x21B4(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_4;  // 0x21C0(0xC)
	char pad_8652_1 : 7;  // 0x21CC(0x1)
	bool CallFunc_CheckObjectBlock_Blocked : 1;  // 0x21CC(0x1)
	char pad_8653[3];  // 0x21CD(0x3)
	struct FHitResult CallFunc_CheckObjectBlock_OutHit;  // 0x21D0(0x88)
	char pad_8792_1 : 7;  // 0x2258(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x2258(0x1)
	char pad_8793_1 : 7;  // 0x2259(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_23 : 1;  // 0x2259(0x1)
	char pad_8794[2];  // 0x225A(0x2)
	struct FHitResult K2Node_CustomEvent_Hit_3;  // 0x225C(0x88)
	int32_t K2Node_CustomEvent_InventorySlot;  // 0x22E4(0x4)
	struct AActor* K2Node_CustomEvent_Target_12;  // 0x22E8(0x8)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact;  // 0x22F0(0x10)
	char pad_8960_1 : 7;  // 0x2300(0x1)
	bool K2Node_DynamicCast_bSuccess_30 : 1;  // 0x2300(0x1)
	char pad_8961_1 : 7;  // 0x2301(0x1)
	bool CallFunc_IsValid_ReturnValue_31 : 1;  // 0x2301(0x1)
	char pad_8962_1 : 7;  // 0x2302(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_16 : 1;  // 0x2302(0x1)
	char pad_8963[1];  // 0x2303(0x1)
	struct FVector CallFunc_GetComponentBounds_Origin;  // 0x2304(0xC)
	struct FVector CallFunc_GetComponentBounds_BoxExtent;  // 0x2310(0xC)
	float CallFunc_GetComponentBounds_SphereRadius;  // 0x231C(0x4)
	char pad_8992_1 : 7;  // 0x2320(0x1)
	bool CallFunc_CheckObjectBlock_Blocked_2 : 1;  // 0x2320(0x1)
	char pad_8993[3];  // 0x2321(0x3)
	struct FHitResult CallFunc_CheckObjectBlock_OutHit_2;  // 0x2324(0x88)
	int32_t Temp_int_Loop_Counter_Variable_27;  // 0x23AC(0x4)
	struct TArray<struct UBaseHUD_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x23B0(0x10)
	struct UBaseHUD_C* CallFunc_Array_Get_Item_11;  // 0x23C0(0x8)
	char pad_9160_1 : 7;  // 0x23C8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_7 : 1;  // 0x23C8(0x1)
	char pad_9161_1 : 7;  // 0x23C9(0x1)
	bool CallFunc_BooleanAND_ReturnValue_12 : 1;  // 0x23C9(0x1)
	char pad_9162[2];  // 0x23CA(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_27;  // 0x23CC(0x4)
	struct FST_CraftRecipe K2Node_CustomEvent_recipe_4;  // 0x23D0(0x28)
	struct AMovable_Object_Replicated_C* K2Node_CustomEvent_Mesh_3;  // 0x23F8(0x8)
	struct FVector K2Node_CustomEvent_Teleport_Loaction_2;  // 0x2400(0xC)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x240C(0x4)
	struct AMovable_Object_Replicated_C* K2Node_CustomEvent_Mesh_2;  // 0x2410(0x8)
	struct FVector K2Node_CustomEvent_Teleport_Loaction;  // 0x2418(0xC)
	char pad_9252[4];  // 0x2424(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue_2;  // 0x2428(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x2438(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_4;  // 0x2440(0x8)
	char pad_9288_1 : 7;  // 0x2448(0x1)
	bool K2Node_CustomEvent_bSuccess_4 : 1;  // 0x2448(0x1)
	char pad_9289[7];  // 0x2449(0x7)
	struct FST_ItemBase CallFunc_GetDataTableRowFromName_OutRow;  // 0x2450(0x90)
	char pad_9440_1 : 7;  // 0x24E0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x24E0(0x1)
	char pad_9441[7];  // 0x24E1(0x7)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x24E8(0x18)
	int32_t Temp_int_Array_Index_Variable_28;  // 0x2500(0x4)
	char pad_9476[4];  // 0x2504(0x4)
	struct APlayerState* CallFunc_Array_Get_Item_12;  // 0x2508(0x8)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS_5;  // 0x2510(0x8)
	char pad_9496_1 : 7;  // 0x2518(0x1)
	bool K2Node_DynamicCast_bSuccess_31 : 1;  // 0x2518(0x1)
	char pad_9497[3];  // 0x2519(0x3)
	int32_t CallFunc_ID_ID;  // 0x251C(0x4)
	char pad_9504_1 : 7;  // 0x2520(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_5 : 1;  // 0x2520(0x1)
	char pad_9505[7];  // 0x2521(0x7)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_13;  // 0x2528(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_15;  // 0x2530(0x8)
	int32_t K2Node_CustomEvent_ID_15;  // 0x2538(0x4)
	int32_t CallFunc_ID_ID_2;  // 0x253C(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_12;  // 0x2540(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_14;  // 0x2548(0x8)
	int32_t K2Node_CustomEvent_ID_14;  // 0x2550(0x4)
	char pad_9556_1 : 7;  // 0x2554(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_3 : 1;  // 0x2554(0x1)
	char pad_9557_1 : 7;  // 0x2555(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x2555(0x1)
	char pad_9558_1 : 7;  // 0x2556(0x1)
	bool CallFunc_BooleanOR_ReturnValue_7 : 1;  // 0x2556(0x1)
	char pad_9559[1];  // 0x2557(0x1)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_11;  // 0x2558(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_13;  // 0x2560(0x8)
	int32_t CallFunc_ID_ID_3;  // 0x2568(0x4)
	int32_t CallFunc_ID_ID_4;  // 0x256C(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_10;  // 0x2570(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_12;  // 0x2578(0x8)
	float K2Node_CustomEvent_BlendInTime_10;  // 0x2580(0x4)
	float K2Node_CustomEvent_BlendOutTime_10;  // 0x2584(0x4)
	float K2Node_CustomEvent_InPlayRate_9;  // 0x2588(0x4)
	int32_t K2Node_CustomEvent_ID_13;  // 0x258C(0x4)
	char pad_9616_1 : 7;  // 0x2590(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_4 : 1;  // 0x2590(0x1)
	char pad_9617_1 : 7;  // 0x2591(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_2 : 1;  // 0x2591(0x1)
	char pad_9618_1 : 7;  // 0x2592(0x1)
	bool CallFunc_BooleanOR_ReturnValue_8 : 1;  // 0x2592(0x1)
	char pad_9619[5];  // 0x2593(0x5)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_9;  // 0x2598(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_11;  // 0x25A0(0x8)
	float K2Node_CustomEvent_BlendInTime_9;  // 0x25A8(0x4)
	float K2Node_CustomEvent_BlendOutTime_9;  // 0x25AC(0x4)
	float K2Node_CustomEvent_InPlayRate_8;  // 0x25B0(0x4)
	int32_t K2Node_CustomEvent_ID_12;  // 0x25B4(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_8;  // 0x25B8(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_10;  // 0x25C0(0x8)
	float K2Node_CustomEvent_BlendInTime_8;  // 0x25C8(0x4)
	float K2Node_CustomEvent_BlendOutTime_8;  // 0x25CC(0x4)
	float K2Node_CustomEvent_InPlayRate_7;  // 0x25D0(0x4)
	char pad_9684[4];  // 0x25D4(0x4)
	struct TArray<struct AActor*> Temp_object_Variable_13;  // 0x25D8(0x10)
	struct UTexture2DDynamic* Temp_object_Variable_14;  // 0x25E8(0x8)
	struct UTexture2DDynamic* K2Node_CustomEvent_Texture_2;  // 0x25F0(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_10;  // 0x25F8(0xC)
	char pad_9732_1 : 7;  // 0x2604(0x1)
	bool Temp_bool_IsClosed_Variable_18 : 1;  // 0x2604(0x1)
	char pad_9733[3];  // 0x2605(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10;  // 0x2608(0x10)
	char pad_9752_1 : 7;  // 0x2618(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_7 : 1;  // 0x2618(0x1)
	char pad_9753[3];  // 0x2619(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11;  // 0x261C(0x10)
	char pad_9772_1 : 7;  // 0x262C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_17 : 1;  // 0x262C(0x1)
	char pad_9773_1 : 7;  // 0x262D(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_19 : 1;  // 0x262D(0x1)
	char E_AnimType CallFunc_Item_Anim_Type_Type;  // 0x262E(0x1)
	char pad_9775[1];  // 0x262F(0x1)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_AttackAnim;  // 0x2630(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_BlockAnim;  // 0x2638(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ShoveAnim;  // 0x2640(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ChargeAnim;  // 0x2648(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_idleAnim;  // 0x2650(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ThrowAnim;  // 0x2658(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_EquipAnim;  // 0x2660(0x8)
	char E_AnimType CallFunc_Item_Anim_Type_Type_2;  // 0x2668(0x1)
	char pad_9833[7];  // 0x2669(0x7)
	struct UTexture2DDynamic* K2Node_CustomEvent_Texture_3;  // 0x2670(0x8)
	char pad_9848_1 : 7;  // 0x2678(0x1)
	bool Temp_bool_IsClosed_Variable_19 : 1;  // 0x2678(0x1)
	char pad_9849[3];  // 0x2679(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12;  // 0x267C(0x10)
	char pad_9868[4];  // 0x268C(0x4)
	struct FKey Temp_struct_Variable_11;  // 0x2690(0x18)
	struct FKey K2Node_InputActionEvent_Key;  // 0x26A8(0x18)
	char pad_9920_1 : 7;  // 0x26C0(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_18 : 1;  // 0x26C0(0x1)
	char pad_9921[7];  // 0x26C1(0x7)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x26C8(0x18)
	char pad_9952_1 : 7;  // 0x26E0(0x1)
	bool Temp_bool_Variable_20 : 1;  // 0x26E0(0x1)
	char pad_9953[15];  // 0x26E1(0xF)
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // 0x26F0(0x30)
	char pad_10016_1 : 7;  // 0x2720(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_13 : 1;  // 0x2720(0x1)
	char pad_10017[7];  // 0x2721(0x7)
	struct UObject* Temp_object_Variable_15;  // 0x2728(0x8)
	struct UObject* K2Node_CustomEvent_Loaded;  // 0x2730(0x8)
	struct UTexture2D* K2Node_DynamicCast_AsTexture_2D;  // 0x2738(0x8)
	char pad_10048_1 : 7;  // 0x2740(0x1)
	bool K2Node_DynamicCast_bSuccess_32 : 1;  // 0x2740(0x1)
	char pad_10049[3];  // 0x2741(0x3)
	int32_t Temp_int_Loop_Counter_Variable_28;  // 0x2744(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x2748(0x4)
	char pad_10060_1 : 7;  // 0x274C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_8 : 1;  // 0x274C(0x1)
	char pad_10061[3];  // 0x274D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_28;  // 0x2750(0x4)
	char pad_10068_1 : 7;  // 0x2754(0x1)
	bool CallFunc_BooleanAND_ReturnValue_13 : 1;  // 0x2754(0x1)
	char pad_10069[3];  // 0x2755(0x3)
	struct TScriptInterface<IBPI_Item_C> K2Node_DynamicCast_AsBPI_Item;  // 0x2758(0x10)
	char pad_10088_1 : 7;  // 0x2768(0x1)
	bool K2Node_DynamicCast_bSuccess_33 : 1;  // 0x2768(0x1)
	char pad_10089[7];  // 0x2769(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0x2770(0x8)
	int32_t Temp_int_Loop_Counter_Variable_29;  // 0x2778(0x4)
	char pad_10108[4];  // 0x277C(0x4)
	struct AAI_Bot_C* K2Node_DynamicCast_AsAI_Bot;  // 0x2780(0x8)
	char pad_10120_1 : 7;  // 0x2788(0x1)
	bool K2Node_DynamicCast_bSuccess_34 : 1;  // 0x2788(0x1)
	char pad_10121_1 : 7;  // 0x2789(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_9 : 1;  // 0x2789(0x1)
	char pad_10122[2];  // 0x278A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_29;  // 0x278C(0x4)
	char pad_10128_1 : 7;  // 0x2790(0x1)
	bool CallFunc_Can_Attack_ReturnValue_2 : 1;  // 0x2790(0x1)
	char pad_10129[7];  // 0x2791(0x7)
	struct USaveGame* Temp_object_Variable_16;  // 0x2798(0x8)
	char pad_10144_1 : 7;  // 0x27A0(0x1)
	bool CallFunc_BooleanAND_ReturnValue_14 : 1;  // 0x27A0(0x1)
	char pad_10145[7];  // 0x27A1(0x7)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_3;  // 0x27A8(0x8)
	char pad_10160_1 : 7;  // 0x27B0(0x1)
	bool K2Node_DynamicCast_bSuccess_35 : 1;  // 0x27B0(0x1)
	char pad_10161_1 : 7;  // 0x27B1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_24 : 1;  // 0x27B1(0x1)
	char pad_10162_1 : 7;  // 0x27B2(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_25 : 1;  // 0x27B2(0x1)
	char pad_10163[5];  // 0x27B3(0x5)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_4;  // 0x27B8(0x8)
	float CallFunc_GetMeleeChargePitch_Pitch;  // 0x27C0(0x4)
	struct FVector CallFunc_RandomUnitVector_ReturnValue;  // 0x27C4(0xC)
	struct FVector CallFunc_RandomUnitVector_ReturnValue_2;  // 0x27D0(0xC)
	struct FVector CallFunc_Vector_GetAbs_ReturnValue;  // 0x27DC(0xC)
	char pad_10216_1 : 7;  // 0x27E8(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_26 : 1;  // 0x27E8(0x1)
	char pad_10217[7];  // 0x27E9(0x7)
	struct UMyCharacterMovementComponent* CallFunc_GetMyMovementComponent_ReturnValue_2;  // 0x27F0(0x8)
	struct FVector K2Node_CustomEvent_Location_21;  // 0x27F8(0xC)
	struct FVector K2Node_CustomEvent_Scale_9;  // 0x2804(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x2810(0x30)
	struct APlayerBRController_C* CallFunc_PC_pc_17;  // 0x2840(0x8)
	char pad_10312[8];  // 0x2848(0x8)
	struct FTransform CallFunc_MakeRelativeTransform_ReturnValue;  // 0x2850(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x2880(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x288C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x2898(0xC)
	char pad_10404[4];  // 0x28A4(0x4)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0x28A8(0x8)
	char pad_10416_1 : 7;  // 0x28B0(0x1)
	bool Temp_bool_Variable_21 : 1;  // 0x28B0(0x1)
	char pad_10417_1 : 7;  // 0x28B1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_27 : 1;  // 0x28B1(0x1)
	char pad_10418[6];  // 0x28B2(0x6)
	struct USaveGame* K2Node_CustomEvent_SaveGame_5;  // 0x28B8(0x8)
	char pad_10432_1 : 7;  // 0x28C0(0x1)
	bool K2Node_CustomEvent_bSuccess_5 : 1;  // 0x28C0(0x1)
	char pad_10433[3];  // 0x28C1(0x3)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue_2;  // 0x28C4(0xC)
	char pad_10448_1 : 7;  // 0x28D0(0x1)
	bool CallFunc_GetFaceDir_FacingFront_ : 1;  // 0x28D0(0x1)
	char pad_10449_1 : 7;  // 0x28D1(0x1)
	bool CallFunc_IsFalling_ReturnValue_2 : 1;  // 0x28D1(0x1)
	char pad_10450[2];  // 0x28D2(0x2)
	struct FVector K2Node_CustomEvent_LaunchVelocity;  // 0x28D4(0xC)
	float K2Node_Select_Default_5;  // 0x28E0(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x28E4(0xC)
	struct UObject* Temp_object_Variable_17;  // 0x28F0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_13;  // 0x28F8(0x10)
	struct UMaterialInterface* K2Node_DynamicCast_AsMaterial_Interface;  // 0x2908(0x8)
	char pad_10512_1 : 7;  // 0x2910(0x1)
	bool K2Node_DynamicCast_bSuccess_36 : 1;  // 0x2910(0x1)
	char pad_10513[3];  // 0x2911(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x2914(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_3;  // 0x2918(0x10)
	struct FVector CallFunc_GetForwardVector_ReturnValue_2;  // 0x2928(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_11;  // 0x2934(0xC)
	float K2Node_CustomEvent_Time_7;  // 0x2940(0x4)
	float K2Node_CustomEvent_Length_2;  // 0x2944(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x2948(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x2954(0xC)
	char pad_10592_1 : 7;  // 0x2960(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x2960(0x1)
	char pad_10593[7];  // 0x2961(0x7)
	struct TArray<struct FHitResult> CallFunc_SphereTraceMultiForObjects_OutHits;  // 0x2968(0x10)
	char pad_10616_1 : 7;  // 0x2978(0x1)
	bool CallFunc_SphereTraceMultiForObjects_ReturnValue : 1;  // 0x2978(0x1)
	char pad_10617[3];  // 0x2979(0x3)
	float K2Node_Select_Default_6;  // 0x297C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_3;  // 0x2980(0x4)
	char pad_10628_1 : 7;  // 0x2984(0x1)
	bool CallFunc_IsValid_ReturnValue_32 : 1;  // 0x2984(0x1)
	char pad_10629[3];  // 0x2985(0x3)
	struct FST_ItemBase CallFunc_Array_Get_Item_13;  // 0x2988(0x90)
	char pad_10776_1 : 7;  // 0x2A18(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_5 : 1;  // 0x2A18(0x1)
	char pad_10777_1 : 7;  // 0x2A19(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x2A19(0x1)
	char pad_10778[6];  // 0x2A1A(0x6)
	struct TScriptInterface<IBPI_Item_C> K2Node_DynamicCast_AsBPI_Item_2;  // 0x2A20(0x10)
	char pad_10800_1 : 7;  // 0x2A30(0x1)
	bool K2Node_DynamicCast_bSuccess_37 : 1;  // 0x2A30(0x1)
	char pad_10801[7];  // 0x2A31(0x7)
	struct TScriptInterface<IBPI_Item_C> K2Node_DynamicCast_AsBPI_Item_3;  // 0x2A38(0x10)
	char pad_10824_1 : 7;  // 0x2A48(0x1)
	bool K2Node_DynamicCast_bSuccess_38 : 1;  // 0x2A48(0x1)
	char pad_10825_1 : 7;  // 0x2A49(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_6 : 1;  // 0x2A49(0x1)
	char pad_10826[6];  // 0x2A4A(0x6)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Hitter;  // 0x2A50(0x8)
	float K2Node_CustomEvent_Damage_11;  // 0x2A58(0x4)
	char pad_10844_1 : 7;  // 0x2A5C(0x1)
	bool CallFunc_BooleanOR_ReturnValue_9 : 1;  // 0x2A5C(0x1)
	char pad_10845[3];  // 0x2A5D(0x3)
	struct FST_MeleeWeaponInfo CallFunc_MeleeWeapon_Weapon;  // 0x2A60(0x18)
	float CallFunc_MeleeSpeed_Hit_Delay;  // 0x2A78(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay;  // 0x2A7C(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_3;  // 0x2A80(0x4)
	char pad_10884[4];  // 0x2A84(0x4)
	struct UMaterialInstance* CallFunc_RandomBloodDecal_NewParam;  // 0x2A88(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x2A90(0x8)
	char pad_10904[8];  // 0x2A98(0x8)
	struct FTransform K2Node_CustomEvent_SpawnTransform_8;  // 0x2AA0(0x30)
	float K2Node_CustomEvent_Time_6;  // 0x2AD0(0x4)
	struct FVector K2Node_CustomEvent_Launch;  // 0x2AD4(0xC)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x2AE0(0x8)
	char pad_10984[8];  // 0x2AE8(0x8)
	struct FTransform K2Node_CustomEvent_SpawnTransform_7;  // 0x2AF0(0x30)
	struct APawn* K2Node_CustomEvent_Instigator_4;  // 0x2B20(0x8)
	float K2Node_CustomEvent_Intensity;  // 0x2B28(0x4)
	float K2Node_CustomEvent_Radius;  // 0x2B2C(0x4)
	char pad_11056_1 : 7;  // 0x2B30(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_12 : 1;  // 0x2B30(0x1)
	char pad_11057[7];  // 0x2B31(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_3;  // 0x2B38(0x8)
	struct AExplosion_BP_C* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0x2B40(0x8)
	struct ABP_Dynamite_Thrown_C* CallFunc_FinishSpawningActor_ReturnValue_3;  // 0x2B48(0x8)
	struct FST_MeleeWeaponInfo CallFunc_MeleeWeapon_Weapon_2;  // 0x2B50(0x18)
	float K2Node_CustomEvent_Length;  // 0x2B68(0x4)
	float CallFunc_MeleeSpeed_Hit_Delay_2;  // 0x2B6C(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay_2;  // 0x2B70(0x4)
	char pad_11124[4];  // 0x2B74(0x4)
	struct UchargeBar_C* CallFunc_AddCharge_widget_2;  // 0x2B78(0x8)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_7;  // 0x2B80(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_9;  // 0x2B88(0x8)
	char pad_11152_1 : 7;  // 0x2B90(0x1)
	bool CallFunc_IsPlayingSlotAnimation_ReturnValue : 1;  // 0x2B90(0x1)
	char pad_11153[3];  // 0x2B91(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_8;  // 0x2B94(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x2B98(0x4)
	char pad_11164[4];  // 0x2B9C(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_6;  // 0x2BA0(0x8)
	struct FName K2Node_CustomEvent_SlotNodeName_8;  // 0x2BA8(0x8)
	float K2Node_CustomEvent_BlendInTime_7;  // 0x2BB0(0x4)
	float K2Node_CustomEvent_BlendOutTime_7;  // 0x2BB4(0x4)
	float K2Node_CustomEvent_InPlayRate_6;  // 0x2BB8(0x4)
	float CallFunc_PlaySlotAnimation_ReturnValue;  // 0x2BBC(0x4)
	struct UObject* K2Node_CustomEvent_Loaded_2;  // 0x2BC0(0x8)
	struct TArray<struct AActor*> Temp_object_Variable_18;  // 0x2BC8(0x10)
	struct FVector Temp_struct_Variable_12;  // 0x2BD8(0xC)
	char pad_11236[4];  // 0x2BE4(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Attacker;  // 0x2BE8(0x8)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Target_11;  // 0x2BF0(0x8)
	struct FVector K2Node_CustomEvent_HitLocation;  // 0x2BF8(0xC)
	char pad_11268[4];  // 0x2C04(0x4)
	struct FString K2Node_CustomEvent_Validation_2;  // 0x2C08(0x10)
	char pad_11288_1 : 7;  // 0x2C18(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_7 : 1;  // 0x2C18(0x1)
	char pad_11289[3];  // 0x2C19(0x3)
	float K2Node_Select_Default_7;  // 0x2C1C(0x4)
	char pad_11296_1 : 7;  // 0x2C20(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_6 : 1;  // 0x2C20(0x1)
	char pad_11297[3];  // 0x2C21(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_12;  // 0x2C24(0xC)
	char pad_11312_1 : 7;  // 0x2C30(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_7 : 1;  // 0x2C30(0x1)
	char pad_11313_1 : 7;  // 0x2C31(0x1)
	bool CallFunc_BooleanOR_ReturnValue_10 : 1;  // 0x2C31(0x1)
	char pad_11314[2];  // 0x2C32(0x2)
	float CallFunc_GetDistanceTo_ReturnValue_6;  // 0x2C34(0x4)
	char pad_11320_1 : 7;  // 0x2C38(0x1)
	bool CallFunc_BooleanAND_ReturnValue_15 : 1;  // 0x2C38(0x1)
	char pad_11321_1 : 7;  // 0x2C39(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_14 : 1;  // 0x2C39(0x1)
	char pad_11322_1 : 7;  // 0x2C3A(0x1)
	bool CallFunc_IsValid_ReturnValue_33 : 1;  // 0x2C3A(0x1)
	char pad_11323[5];  // 0x2C3B(0x5)
	struct AController* CallFunc_GetController_ReturnValue_14;  // 0x2C40(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x2C48(0x8)
	char pad_11344_1 : 7;  // 0x2C50(0x1)
	bool K2Node_DynamicCast_bSuccess_39 : 1;  // 0x2C50(0x1)
	char pad_11345[3];  // 0x2C51(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x2C54(0xC)
	float CallFunc_BreakVector_X_3;  // 0x2C60(0x4)
	float CallFunc_BreakVector_Y_3;  // 0x2C64(0x4)
	float CallFunc_BreakVector_Z_3;  // 0x2C68(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x2C6C(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_3;  // 0x2C78(0xC)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0x2C84(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_4;  // 0x2C90(0xC)
	float CallFunc_BreakVector_X_4;  // 0x2C9C(0x4)
	float CallFunc_BreakVector_Y_4;  // 0x2CA0(0x4)
	float CallFunc_BreakVector_Z_4;  // 0x2CA4(0x4)
	float CallFunc_Dot_VectorVector_ReturnValue;  // 0x2CA8(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x2CAC(0xC)
	char pad_11448_1 : 7;  // 0x2CB8(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x2CB8(0x1)
	char pad_11449[3];  // 0x2CB9(0x3)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // 0x2CBC(0xC)
	char pad_11464_1 : 7;  // 0x2CC8(0x1)
	bool CallFunc_BooleanAND_ReturnValue_16 : 1;  // 0x2CC8(0x1)
	char pad_11465[3];  // 0x2CC9(0x3)
	struct FVector CallFunc_GetForwardVector_ReturnValue_5;  // 0x2CCC(0xC)
	char pad_11480_1 : 7;  // 0x2CD8(0x1)
	bool CallFunc_BooleanAND_ReturnValue_17 : 1;  // 0x2CD8(0x1)
	char pad_11481[3];  // 0x2CD9(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_4;  // 0x2CDC(0xC)
	char pad_11496_1 : 7;  // 0x2CE8(0x1)
	bool CallFunc_BooleanAND_ReturnValue_18 : 1;  // 0x2CE8(0x1)
	char pad_11497[7];  // 0x2CE9(0x7)
	struct FST_MeleeWeaponInfo CallFunc_MeleeWeapon_Weapon_3;  // 0x2CF0(0x18)
	float CallFunc_Multiply_FloatFloat_ReturnValue_9;  // 0x2D08(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_5;  // 0x2D0C(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_6;  // 0x2D18(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_10;  // 0x2D24(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x2D28(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_11;  // 0x2D34(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x2D38(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_12;  // 0x2D44(0x4)
	float CallFunc_ApplyDamage_ReturnValue_4;  // 0x2D48(0x4)
	char pad_11596_1 : 7;  // 0x2D4C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_13 : 1;  // 0x2D4C(0x1)
	char pad_11597[3];  // 0x2D4D(0x3)
	int32_t Temp_int_Array_Index_Variable_29;  // 0x2D50(0x4)
	char pad_11604[4];  // 0x2D54(0x4)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item_14;  // 0x2D58(0x8)
	struct FVector K2Node_CustomEvent_Location_20;  // 0x2D60(0xC)
	struct FVector K2Node_CustomEvent_Normal_3;  // 0x2D6C(0xC)
	float K2Node_CustomEvent_Damage_10;  // 0x2D78(0x4)
	char pad_11644[4];  // 0x2D7C(0x4)
	struct AMovable_Object_Replicated_C* K2Node_CustomEvent_Target_10;  // 0x2D80(0x8)
	struct FST_MeleeWeaponInfo CallFunc_MeleeWeapon_Weapon_4;  // 0x2D88(0x18)
	struct FVector K2Node_CustomEvent_Location_19;  // 0x2DA0(0xC)
	struct FVector K2Node_CustomEvent_Scale_8;  // 0x2DAC(0xC)
	float K2Node_CustomEvent_VolumeMultiplier_5;  // 0x2DB8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_13;  // 0x2DBC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_14;  // 0x2DC0(0x4)
	float K2Node_CustomEvent_Distance;  // 0x2DC4(0x4)
	float K2Node_CustomEvent_Time_5;  // 0x2DC8(0x4)
	float K2Node_CustomEvent_MaxIntensity_2;  // 0x2DCC(0x4)
	float K2Node_CustomEvent_StartTime;  // 0x2DD0(0x4)
	struct FVector K2Node_CustomEvent_Location_18;  // 0x2DD4(0xC)
	struct FVector K2Node_CustomEvent_Scale_7;  // 0x2DE0(0xC)
	char pad_11756_1 : 7;  // 0x2DEC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_14 : 1;  // 0x2DEC(0x1)
	char pad_11757[3];  // 0x2DED(0x3)
	float CallFunc_Lerp_ReturnValue;  // 0x2DF0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_11;  // 0x2DF4(0x4)
	uint8_t  Temp_byte_Variable_4;  // 0x2DF8(0x1)
	char pad_11769[7];  // 0x2DF9(0x7)
	struct FTransform K2Node_CustomEvent_SpawnTransform_6;  // 0x2E00(0x30)
	struct APawn* K2Node_CustomEvent_Instigator_3;  // 0x2E30(0x8)
	float K2Node_CustomEvent_Damage_9;  // 0x2E38(0x4)
	int32_t K2Node_CustomEvent_ID_11;  // 0x2E3C(0x4)
	ABP_Projectile_C* K2Node_CustomEvent_Class_3;  // 0x2E40(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_4;  // 0x2E48(0x8)
	char pad_11856_1 : 7;  // 0x2E50(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_5 : 1;  // 0x2E50(0x1)
	char pad_11857[7];  // 0x2E51(0x7)
	struct ABP_Projectile_C* CallFunc_FinishSpawningActor_ReturnValue_4;  // 0x2E58(0x8)
	int32_t K2Node_CustomEvent_ID_10;  // 0x2E60(0x4)
	float K2Node_CustomEvent_Damage_8;  // 0x2E64(0x4)
	struct APawn* K2Node_CustomEvent_Instigator_2;  // 0x2E68(0x8)
	struct FTransform K2Node_CustomEvent_SpawnTransform_5;  // 0x2E70(0x30)
	ABP_Projectile_C* K2Node_CustomEvent_Class_2;  // 0x2EA0(0x8)
	uint8_t  Temp_byte_Variable_5;  // 0x2EA8(0x1)
	char pad_11945[3];  // 0x2EA9(0x3)
	int32_t K2Node_CustomEvent_Initiator_6;  // 0x2EAC(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_5;  // 0x2EB0(0x8)
	float K2Node_CustomEvent_BlendInTime_6;  // 0x2EB8(0x4)
	float K2Node_CustomEvent_BlendOutTime_6;  // 0x2EBC(0x4)
	struct FName K2Node_CustomEvent_SlotNodeName_7;  // 0x2EC0(0x8)
	float K2Node_CustomEvent_InPlayRate_5;  // 0x2EC8(0x4)
	char pad_11980_1 : 7;  // 0x2ECC(0x1)
	bool Temp_bool_Variable_22 : 1;  // 0x2ECC(0x1)
	uint8_t  K2Node_Select_Default_8;  // 0x2ECD(0x1)
	char pad_11982[2];  // 0x2ECE(0x2)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_5;  // 0x2ED0(0x8)
	int32_t K2Node_CustomEvent_Initiator_5;  // 0x2ED8(0x4)
	char pad_11996[4];  // 0x2EDC(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_4;  // 0x2EE0(0x8)
	float K2Node_CustomEvent_BlendInTime_5;  // 0x2EE8(0x4)
	float K2Node_CustomEvent_BlendOutTime_5;  // 0x2EEC(0x4)
	struct FName K2Node_CustomEvent_SlotNodeName_6;  // 0x2EF0(0x8)
	float K2Node_CustomEvent_InPlayRate_4;  // 0x2EF8(0x4)
	float CallFunc_PlaySlotAnimation_ReturnValue_2;  // 0x2EFC(0x4)
	char pad_12032_1 : 7;  // 0x2F00(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_6 : 1;  // 0x2F00(0x1)
	char pad_12033[3];  // 0x2F01(0x3)
	struct FVector Temp_struct_Variable_13;  // 0x2F04(0xC)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Hit_2;  // 0x2F10(0x8)
	float K2Node_CustomEvent_ResultingDamage;  // 0x2F18(0x4)
	char pad_12060_1 : 7;  // 0x2F1C(0x1)
	bool K2Node_CustomEvent_CriticalHit : 1;  // 0x2F1C(0x1)
	char pad_12061_1 : 7;  // 0x2F1D(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_8 : 1;  // 0x2F1D(0x1)
	char pad_12062_1 : 7;  // 0x2F1E(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_8 : 1;  // 0x2F1E(0x1)
	char pad_12063_1 : 7;  // 0x2F1F(0x1)
	bool CallFunc_BooleanOR_ReturnValue_11 : 1;  // 0x2F1F(0x1)
	float CallFunc_Multiply_FloatFloat_ReturnValue_15;  // 0x2F20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_16;  // 0x2F24(0x4)
	struct AController* CallFunc_GetController_ReturnValue_15;  // 0x2F28(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_17;  // 0x2F30(0x4)
	char pad_12084[4];  // 0x2F34(0x4)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_2;  // 0x2F38(0x8)
	char pad_12096_1 : 7;  // 0x2F40(0x1)
	bool K2Node_DynamicCast_bSuccess_40 : 1;  // 0x2F40(0x1)
	char pad_12097_1 : 7;  // 0x2F41(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_4 : 1;  // 0x2F41(0x1)
	char pad_12098[2];  // 0x2F42(0x2)
	float K2Node_CustomEvent_ConstDamageMultiplier;  // 0x2F44(0x4)
	char pad_12104_1 : 7;  // 0x2F48(0x1)
	bool CallFunc_Can_Attack_ReturnValue_3 : 1;  // 0x2F48(0x1)
	char pad_12105_1 : 7;  // 0x2F49(0x1)
	bool K2Node_CustomEvent_Blocking_3 : 1;  // 0x2F49(0x1)
	char pad_12106_1 : 7;  // 0x2F4A(0x1)
	bool CallFunc_Can_Attack_ReturnValue_4 : 1;  // 0x2F4A(0x1)
	char pad_12107[1];  // 0x2F4B(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_5;  // 0x2F4C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_13;  // 0x2F58(0xC)
	float CallFunc_BreakVector_X_5;  // 0x2F64(0x4)
	float CallFunc_BreakVector_Y_5;  // 0x2F68(0x4)
	float CallFunc_BreakVector_Z_5;  // 0x2F6C(0x4)
	struct TScriptInterface<IBPI_Item_C> K2Node_DynamicCast_AsBPI_Item_4;  // 0x2F70(0x10)
	char pad_12160_1 : 7;  // 0x2F80(0x1)
	bool K2Node_DynamicCast_bSuccess_41 : 1;  // 0x2F80(0x1)
	char pad_12161[3];  // 0x2F81(0x3)
	struct FVector CallFunc_MakeVector_ReturnValue_3;  // 0x2F84(0xC)
	float CallFunc_SelectFloat_ReturnValue;  // 0x2F90(0x4)
	char pad_12180[4];  // 0x2F94(0x4)
	struct TScriptInterface<IBPI_Item_C> K2Node_DynamicCast_AsBPI_Item_5;  // 0x2F98(0x10)
	char pad_12200_1 : 7;  // 0x2FA8(0x1)
	bool K2Node_DynamicCast_bSuccess_42 : 1;  // 0x2FA8(0x1)
	char pad_12201_1 : 7;  // 0x2FA9(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_11 : 1;  // 0x2FA9(0x1)
	uint8_t  Temp_byte_Variable_6;  // 0x2FAA(0x1)
	char pad_12203[1];  // 0x2FAB(0x1)
	int32_t K2Node_CustomEvent_ID_9;  // 0x2FAC(0x4)
	int32_t K2Node_CustomEvent_ID_8;  // 0x2FB0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_4;  // 0x2FB4(0x4)
	struct FName K2Node_CustomEvent_EventName;  // 0x2FB8(0x8)
	float K2Node_CustomEvent_EmitterTime;  // 0x2FC0(0x4)
	int32_t K2Node_CustomEvent_ParticleTime;  // 0x2FC4(0x4)
	struct FVector K2Node_CustomEvent_Location_17;  // 0x2FC8(0xC)
	struct FVector K2Node_CustomEvent_Velocity_2;  // 0x2FD4(0xC)
	struct FVector K2Node_CustomEvent_Direction;  // 0x2FE0(0xC)
	struct FVector K2Node_CustomEvent_Normal_2;  // 0x2FEC(0xC)
	struct FName K2Node_CustomEvent_BoneName;  // 0x2FF8(0x8)
	struct UPhysicalMaterial* K2Node_CustomEvent_PhysMat;  // 0x3000(0x8)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // 0x3008(0xC)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue;  // 0x3014(0xC)
	float CallFunc_BreakVector_X_6;  // 0x3020(0x4)
	float CallFunc_BreakVector_Y_6;  // 0x3024(0x4)
	float CallFunc_BreakVector_Z_6;  // 0x3028(0x4)
	struct FRotator CallFunc_NegateRotator_ReturnValue;  // 0x302C(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_4;  // 0x3038(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_6;  // 0x3044(0xC)
	struct FVector CallFunc_RotateAngleAxis_ReturnValue;  // 0x3050(0xC)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue_2;  // 0x305C(0xC)
	struct UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue;  // 0x3068(0x8)
	char pad_12400_1 : 7;  // 0x3070(0x1)
	bool Temp_bool_Variable_23 : 1;  // 0x3070(0x1)
	char pad_12401[3];  // 0x3071(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_14;  // 0x3074(0xC)
	char pad_12416_1 : 7;  // 0x3080(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_5 : 1;  // 0x3080(0x1)
	char pad_12417[3];  // 0x3081(0x3)
	struct FVector K2Node_CustomEvent_Location_16;  // 0x3084(0xC)
	struct FVector K2Node_CustomEvent_Scale_6;  // 0x3090(0xC)
	float K2Node_CustomEvent_VolumeMultiplier_4;  // 0x309C(0x4)
	float K2Node_CustomEvent_PitchMultiplier_7;  // 0x30A0(0x4)
	char pad_12452[4];  // 0x30A4(0x4)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x30A8(0x8)
	int32_t Temp_int_Loop_Counter_Variable_30;  // 0x30B0(0x4)
	char pad_12468_1 : 7;  // 0x30B4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_10 : 1;  // 0x30B4(0x1)
	char pad_12469[3];  // 0x30B5(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_30;  // 0x30B8(0x4)
	char pad_12476_1 : 7;  // 0x30BC(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_6 : 1;  // 0x30BC(0x1)
	char pad_12477_1 : 7;  // 0x30BD(0x1)
	bool K2Node_CustomEvent_Charging_2 : 1;  // 0x30BD(0x1)
	char pad_12478[2];  // 0x30BE(0x2)
	float K2Node_CustomEvent_DamageMultiplier;  // 0x30C0(0x4)
	char pad_12484_1 : 7;  // 0x30C4(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_15 : 1;  // 0x30C4(0x1)
	char pad_12485_1 : 7;  // 0x30C5(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_16 : 1;  // 0x30C5(0x1)
	char pad_12486[2];  // 0x30C6(0x2)
	float K2Node_Select_Default_9;  // 0x30C8(0x4)
	float CallFunc_FClamp_ReturnValue_3;  // 0x30CC(0x4)
	float K2Node_CustomEvent_BlendOutTime_4;  // 0x30D0(0x4)
	float K2Node_CustomEvent_BlendInTime_4;  // 0x30D4(0x4)
	char pad_12504_1 : 7;  // 0x30D8(0x1)
	bool K2Node_CustomEvent_Charging : 1;  // 0x30D8(0x1)
	char pad_12505[7];  // 0x30D9(0x7)
	struct FString K2Node_CustomEvent_Validation;  // 0x30E0(0x10)
	char pad_12528_1 : 7;  // 0x30F0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_9 : 1;  // 0x30F0(0x1)
	char pad_12529[7];  // 0x30F1(0x7)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_AttackAnim_2;  // 0x30F8(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_BlockAnim_2;  // 0x3100(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ShoveAnim_2;  // 0x3108(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ChargeAnim_2;  // 0x3110(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_idleAnim_2;  // 0x3118(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ThrowAnim_2;  // 0x3120(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_EquipAnim_2;  // 0x3128(0x8)
	struct AController* CallFunc_GetController_ReturnValue_16;  // 0x3130(0x8)
	uint8_t  Temp_byte_Variable_7;  // 0x3138(0x1)
	char pad_12601[7];  // 0x3139(0x7)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_14;  // 0x3140(0x8)
	char pad_12616_1 : 7;  // 0x3148(0x1)
	bool K2Node_DynamicCast_bSuccess_43 : 1;  // 0x3148(0x1)
	char pad_12617[7];  // 0x3149(0x7)
	struct UhitMarker_C* CallFunc_Create_ReturnValue;  // 0x3150(0x8)
	char pad_12632_1 : 7;  // 0x3158(0x1)
	bool K2Node_CustomEvent_HeadShot__3 : 1;  // 0x3158(0x1)
	char pad_12633[7];  // 0x3159(0x7)
	struct USoundBase* K2Node_Select_Default_10;  // 0x3160(0x8)
	ABP_Projectile_C* K2Node_CustomEvent_Class;  // 0x3168(0x8)
	struct FTransform K2Node_CustomEvent_SpawnTransform_4;  // 0x3170(0x30)
	float K2Node_CustomEvent_Damage_7;  // 0x31A0(0x4)
	char pad_12708[4];  // 0x31A4(0x4)
	struct APawn* K2Node_CustomEvent_Instigator;  // 0x31A8(0x8)
	struct AController* CallFunc_GetController_ReturnValue_17;  // 0x31B0(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_15;  // 0x31B8(0x8)
	char pad_12736_1 : 7;  // 0x31C0(0x1)
	bool K2Node_DynamicCast_bSuccess_44 : 1;  // 0x31C0(0x1)
	char pad_12737[7];  // 0x31C1(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_5;  // 0x31C8(0x8)
	struct ABP_Projectile_C* CallFunc_FinishSpawningActor_ReturnValue_5;  // 0x31D0(0x8)
	char pad_12760_1 : 7;  // 0x31D8(0x1)
	bool Temp_bool_Variable_24 : 1;  // 0x31D8(0x1)
	uint8_t  K2Node_Select_Default_11;  // 0x31D9(0x1)
	char pad_12762[2];  // 0x31DA(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_15;  // 0x31DC(0xC)
	struct FVector K2Node_CustomEvent_Stun_Location;  // 0x31E8(0xC)
	float K2Node_CustomEvent_Duration;  // 0x31F4(0x4)
	float K2Node_CustomEvent_KnockbackMultiplier;  // 0x31F8(0x4)
	char pad_12796_1 : 7;  // 0x31FC(0x1)
	bool K2Node_CustomEvent_ShortStun_ : 1;  // 0x31FC(0x1)
	char pad_12797[3];  // 0x31FD(0x3)
	struct AActor* K2Node_CustomEvent_Hit;  // 0x3200(0x8)
	char pad_12808_1 : 7;  // 0x3208(0x1)
	bool CallFunc_VerifyMaxMeleeRange_ReturnValue : 1;  // 0x3208(0x1)
	char pad_12809[3];  // 0x3209(0x3)
	float K2Node_Select_Default_12;  // 0x320C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_12;  // 0x3210(0x4)
	char pad_12820[4];  // 0x3214(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_3;  // 0x3218(0x8)
	char pad_12832_1 : 7;  // 0x3220(0x1)
	bool K2Node_DynamicCast_bSuccess_45 : 1;  // 0x3220(0x1)
	char pad_12833[7];  // 0x3221(0x7)
	UMatineeCameraShake* K2Node_Select_Default_13;  // 0x3228(0x8)
	struct UAnimSequenceBase* K2Node_Select_Default_14;  // 0x3230(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue_18;  // 0x3238(0x4)
	float CallFunc_PlaySlotAnimation_ReturnValue_3;  // 0x323C(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_13;  // 0x3240(0x4)
	float CallFunc_PlaySlotAnimation_ReturnValue_4;  // 0x3244(0x4)
	float CallFunc_BreakVector_X_7;  // 0x3248(0x4)
	float CallFunc_BreakVector_Y_7;  // 0x324C(0x4)
	float CallFunc_BreakVector_Z_7;  // 0x3250(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_5;  // 0x3254(0xC)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_3;  // 0x3260(0x8)
	float K2Node_CustomEvent_BlendInTime_3;  // 0x3268(0x4)
	float K2Node_CustomEvent_BlendOutTime_3;  // 0x326C(0x4)
	struct FName K2Node_CustomEvent_SlotName;  // 0x3270(0x8)
	float K2Node_CustomEvent_InPlayRate_3;  // 0x3278(0x4)
	char pad_12924_1 : 7;  // 0x327C(0x1)
	bool K2Node_CustomEvent_Exclusive_5 : 1;  // 0x327C(0x1)
	char pad_12925_1 : 7;  // 0x327D(0x1)
	bool K2Node_CustomEvent_reliable : 1;  // 0x327D(0x1)
	char pad_12926[2];  // 0x327E(0x2)
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue_2;  // 0x3280(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_7;  // 0x328C(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_2;  // 0x3298(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_7;  // 0x32A4(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_3;  // 0x32B0(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x32BC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_8;  // 0x32C8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0x32D4(0xC)
	char pad_13024_1 : 7;  // 0x32E0(0x1)
	bool K2Node_CustomEvent_Blocking_2 : 1;  // 0x32E0(0x1)
	char pad_13025[3];  // 0x32E1(0x3)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_4;  // 0x32E4(0xC)
	char pad_13040_1 : 7;  // 0x32F0(0x1)
	bool K2Node_CustomEvent_Blocking : 1;  // 0x32F0(0x1)
	char pad_13041_1 : 7;  // 0x32F1(0x1)
	bool CallFunc_BooleanAND_ReturnValue_19 : 1;  // 0x32F1(0x1)
	char pad_13042[2];  // 0x32F2(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_14;  // 0x32F4(0x10)
	char pad_13060_1 : 7;  // 0x3304(0x1)
	bool CallFunc_BooleanAND_ReturnValue_20 : 1;  // 0x3304(0x1)
	char pad_13061[3];  // 0x3305(0x3)
	float Temp_float_Variable_17;  // 0x3308(0x4)
	char pad_13068_1 : 7;  // 0x330C(0x1)
	bool CallFunc_BooleanOR_ReturnValue_12 : 1;  // 0x330C(0x1)
	char pad_13069_1 : 7;  // 0x330D(0x1)
	bool CallFunc_BooleanOR_ReturnValue_13 : 1;  // 0x330D(0x1)
	char pad_13070[2];  // 0x330E(0x2)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_6;  // 0x3310(0x8)
	float CallFunc_PlaySlotAnimation_ReturnValue_5;  // 0x3318(0x4)
	int32_t K2Node_CustomEvent_Initiator_4;  // 0x331C(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset_2;  // 0x3320(0x8)
	float K2Node_CustomEvent_BlendInTime_2;  // 0x3328(0x4)
	float K2Node_CustomEvent_BlendOutTime_2;  // 0x332C(0x4)
	struct FName K2Node_CustomEvent_SlotNodeName_5;  // 0x3330(0x8)
	float K2Node_CustomEvent_InPlayRate_2;  // 0x3338(0x4)
	int32_t K2Node_CustomEvent_Initiator_3;  // 0x333C(0x4)
	struct UAnimSequenceBase* K2Node_CustomEvent_Asset;  // 0x3340(0x8)
	float K2Node_CustomEvent_BlendInTime;  // 0x3348(0x4)
	float K2Node_CustomEvent_BlendOutTime;  // 0x334C(0x4)
	struct FName K2Node_CustomEvent_SlotNodeName_4;  // 0x3350(0x8)
	float K2Node_CustomEvent_InPlayRate;  // 0x3358(0x4)
	char pad_13148_1 : 7;  // 0x335C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_7 : 1;  // 0x335C(0x1)
	char pad_13149[3];  // 0x335D(0x3)
	struct FVector K2Node_CustomEvent_Location_15;  // 0x3360(0xC)
	struct FVector K2Node_CustomEvent_Scale_5;  // 0x336C(0xC)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_7;  // 0x3378(0x8)
	float CallFunc_PlaySlotAnimation_ReturnValue_6;  // 0x3380(0x4)
	char pad_13188_1 : 7;  // 0x3384(0x1)
	bool Temp_bool_Variable_25 : 1;  // 0x3384(0x1)
	char pad_13189_1 : 7;  // 0x3385(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_7 : 1;  // 0x3385(0x1)
	char pad_13190[2];  // 0x3386(0x2)
	float K2Node_Select_Default_15;  // 0x3388(0x4)
	char pad_13196[4];  // 0x338C(0x4)
	struct FKey Temp_struct_Variable_14;  // 0x3390(0x18)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x33A8(0x18)
	struct FKey K2Node_InputActionEvent_Key_4;  // 0x33C0(0x18)
	struct FKey Temp_struct_Variable_15;  // 0x33D8(0x18)
	char pad_13296_1 : 7;  // 0x33F0(0x1)
	bool CallFunc_IsValid_ReturnValue_34 : 1;  // 0x33F0(0x1)
	char pad_13297[3];  // 0x33F1(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_6;  // 0x33F4(0xC)
	char pad_13312_1 : 7;  // 0x3400(0x1)
	bool CallFunc_CheckObjectBlock_Blocked_3 : 1;  // 0x3400(0x1)
	char pad_13313[3];  // 0x3401(0x3)
	struct FHitResult CallFunc_CheckObjectBlock_OutHit_3;  // 0x3404(0x88)
	int32_t K2Node_CustomEvent_SlotIndex_4;  // 0x348C(0x4)
	struct ABP_ItemPickup_C* K2Node_CustomEvent_pickup_Actor;  // 0x3490(0x8)
	struct FST_ItemBase CallFunc_GetItem_Item;  // 0x3498(0x90)
	char pad_13608_1 : 7;  // 0x3528(0x1)
	bool CallFunc_IsPendingKill_ReturnValue : 1;  // 0x3528(0x1)
	char pad_13609_1 : 7;  // 0x3529(0x1)
	bool CallFunc_IsValid_ReturnValue_35 : 1;  // 0x3529(0x1)
	char pad_13610_1 : 7;  // 0x352A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_19 : 1;  // 0x352A(0x1)
	char pad_13611_1 : 7;  // 0x352B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_21 : 1;  // 0x352B(0x1)
	char pad_13612_1 : 7;  // 0x352C(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_20 : 1;  // 0x352C(0x1)
	char pad_13613[3];  // 0x352D(0x3)
	struct FST_ItemBase CallFunc_Array_Get_Item_15;  // 0x3530(0x90)
	char pad_13760_1 : 7;  // 0x35C0(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x35C0(0x1)
	char pad_13761_1 : 7;  // 0x35C1(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_10 : 1;  // 0x35C1(0x1)
	char pad_13762_1 : 7;  // 0x35C2(0x1)
	bool CallFunc_BooleanAND_ReturnValue_22 : 1;  // 0x35C2(0x1)
	char pad_13763_1 : 7;  // 0x35C3(0x1)
	bool CallFunc_BooleanAND_ReturnValue_23 : 1;  // 0x35C3(0x1)
	char pad_13764_1 : 7;  // 0x35C4(0x1)
	bool CallFunc_BooleanAND_ReturnValue_24 : 1;  // 0x35C4(0x1)
	char pad_13765_1 : 7;  // 0x35C5(0x1)
	bool CallFunc_BooleanAND_ReturnValue_25 : 1;  // 0x35C5(0x1)
	char pad_13766[2];  // 0x35C6(0x2)
	int32_t K2Node_CustomEvent_inventory_slot;  // 0x35C8(0x4)
	char pad_13772_1 : 7;  // 0x35CC(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_12 : 1;  // 0x35CC(0x1)
	char pad_13773_1 : 7;  // 0x35CD(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_8 : 1;  // 0x35CD(0x1)
	char pad_13774[2];  // 0x35CE(0x2)
	int32_t CallFunc_Clamp_ReturnValue;  // 0x35D0(0x4)
	char pad_13780_1 : 7;  // 0x35D4(0x1)
	bool Temp_bool_Variable_26 : 1;  // 0x35D4(0x1)
	char pad_13781[3];  // 0x35D5(0x3)
	struct USaveGame* K2Node_Select_Default_16;  // 0x35D8(0x8)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue_6;  // 0x35E0(0x8)
	char pad_13800_1 : 7;  // 0x35E8(0x1)
	bool CallFunc_IsValid_ReturnValue_36 : 1;  // 0x35E8(0x1)
	char pad_13801[3];  // 0x35E9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_14;  // 0x35EC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_3;  // 0x35F0(0x4)
	char pad_13812_1 : 7;  // 0x35F4(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_9 : 1;  // 0x35F4(0x1)
	char pad_13813_1 : 7;  // 0x35F5(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_10 : 1;  // 0x35F5(0x1)
	char pad_13814[2];  // 0x35F6(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_31;  // 0x35F8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_32;  // 0x35FC(0x4)
	int32_t CallFunc_Clamp_ReturnValue_2;  // 0x3600(0x4)
	int32_t CallFunc_Clamp_ReturnValue_3;  // 0x3604(0x4)
	int32_t K2Node_CustomEvent_SelectedInventorySlot;  // 0x3608(0x4)
	char pad_13836[4];  // 0x360C(0x4)
	struct AActor* K2Node_CustomEvent_TargetActor;  // 0x3610(0x8)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact_2;  // 0x3618(0x10)
	char pad_13864_1 : 7;  // 0x3628(0x1)
	bool K2Node_DynamicCast_bSuccess_46 : 1;  // 0x3628(0x1)
	char pad_13865[7];  // 0x3629(0x7)
	struct FKey K2Node_InputActionEvent_Key_5;  // 0x3630(0x18)
	struct FKey K2Node_InputActionEvent_Key_6;  // 0x3648(0x18)
	char pad_13920_1 : 7;  // 0x3660(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_28 : 1;  // 0x3660(0x1)
	char pad_13921[7];  // 0x3661(0x7)
	struct AItemBP_C* K2Node_DynamicCast_AsItem_BP;  // 0x3668(0x8)
	char pad_13936_1 : 7;  // 0x3670(0x1)
	bool K2Node_DynamicCast_bSuccess_47 : 1;  // 0x3670(0x1)
	char pad_13937_1 : 7;  // 0x3671(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_29 : 1;  // 0x3671(0x1)
	char pad_13938[6];  // 0x3672(0x6)
	struct ABP_ItemPickup_C* K2Node_CustomEvent_Pickup_4;  // 0x3678(0x8)
	int32_t K2Node_Select_Default_17;  // 0x3680(0x4)
	char pad_13956[4];  // 0x3684(0x4)
	AActor* CallFunc_GetObjectClass_ReturnValue;  // 0x3688(0x8)
	struct FTransform Temp_struct_Variable_16;  // 0x3690(0x30)
	char pad_14016_1 : 7;  // 0x36C0(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_3 : 1;  // 0x36C0(0x1)
	char pad_14017[7];  // 0x36C1(0x7)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x36C8(0x8)
	struct FST_ItemBase Temp_struct_Variable_17;  // 0x36D0(0x90)
	struct FST_ItemBase Temp_struct_Variable_18;  // 0x3760(0x90)
	struct FST_ItemBase Temp_struct_Variable_19;  // 0x37F0(0x90)
	char pad_14464_1 : 7;  // 0x3880(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_30 : 1;  // 0x3880(0x1)
	char pad_14465[3];  // 0x3881(0x3)
	int32_t K2Node_CustomEvent_EquipSlot;  // 0x3884(0x4)
	struct FST_ItemBase CallFunc_ReplaceWithFistIfEmpty_Out;  // 0x3888(0x90)
	char E_AnimType CallFunc_Item_Anim_Type_Type_3;  // 0x3918(0x1)
	char pad_14617_1 : 7;  // 0x3919(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x3919(0x1)
	char pad_14618_1 : 7;  // 0x391A(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable_13 : 1;  // 0x391A(0x1)
	char pad_14619[1];  // 0x391B(0x1)
	float Temp_float_Variable_18;  // 0x391C(0x4)
	char pad_14624_1 : 7;  // 0x3920(0x1)
	bool Temp_bool_Variable_27 : 1;  // 0x3920(0x1)
	char pad_14625[7];  // 0x3921(0x7)
	struct FKey Temp_struct_Variable_20;  // 0x3928(0x18)
	struct FKey K2Node_InputActionEvent_Key_7;  // 0x3940(0x18)
	struct FKey K2Node_InputActionEvent_Key_8;  // 0x3958(0x18)
	struct APlayerBRController_C* CallFunc_PC_pc_18;  // 0x3970(0x8)
	struct FString Temp_string_Variable;  // 0x3978(0x10)
	int32_t K2Node_CustomEvent_FirstIndex;  // 0x3988(0x4)
	int32_t K2Node_CustomEvent_SecondIndex;  // 0x398C(0x4)
	struct FKey Temp_struct_Variable_21;  // 0x3990(0x18)
	int32_t K2Node_CustomEvent_Slot_10;  // 0x39A8(0x4)
	char pad_14764_1 : 7;  // 0x39AC(0x1)
	bool Temp_bool_Variable_28 : 1;  // 0x39AC(0x1)
	char pad_14765[3];  // 0x39AD(0x3)
	struct FKey K2Node_InputActionEvent_Key_9;  // 0x39B0(0x18)
	int32_t K2Node_CustomEvent_Slot_9;  // 0x39C8(0x4)
	int32_t CallFunc_FindItemInInventory_index;  // 0x39CC(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item;  // 0x39D0(0x90)
	char pad_14944_1 : 7;  // 0x3A60(0x1)
	bool CallFunc_FindItemInInventory_Found : 1;  // 0x3A60(0x1)
	char pad_14945[15];  // 0x3A61(0xF)
	struct FTransform Temp_struct_Variable_22;  // 0x3A70(0x30)
	struct FTransform Temp_struct_Variable_23;  // 0x3AA0(0x30)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue_2;  // 0x3AD0(0x8)
	char pad_15064[8];  // 0x3AD8(0x8)
	struct FTransform Temp_struct_Variable_24;  // 0x3AE0(0x30)
	struct USkeletalMeshComponent* CallFunc_AddComponent_ReturnValue_3;  // 0x3B10(0x8)
	struct ABP_ItemPickup_C* K2Node_CustomEvent_Pickup_3;  // 0x3B18(0x8)
	struct FST_ItemBase K2Node_CustomEvent__Optional__Item_Override;  // 0x3B20(0x90)
	struct USkeletalMeshComponent* CallFunc_AddComponent_ReturnValue_4;  // 0x3BB0(0x8)
	char pad_15288_1 : 7;  // 0x3BB8(0x1)
	bool CallFunc_ItemValid__Valid : 1;  // 0x3BB8(0x1)
	char pad_15289_1 : 7;  // 0x3BB9(0x1)
	bool CallFunc_IsValid_ReturnValue_37 : 1;  // 0x3BB9(0x1)
	char pad_15290_1 : 7;  // 0x3BBA(0x1)
	bool CallFunc_IsPendingKill_ReturnValue_2 : 1;  // 0x3BBA(0x1)
	char pad_15291_1 : 7;  // 0x3BBB(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_21 : 1;  // 0x3BBB(0x1)
	char pad_15292_1 : 7;  // 0x3BBC(0x1)
	bool CallFunc_CanPickup_CanPickUp : 1;  // 0x3BBC(0x1)
	char pad_15293_1 : 7;  // 0x3BBD(0x1)
	bool CallFunc_BooleanAND_ReturnValue_26 : 1;  // 0x3BBD(0x1)
	char pad_15294_1 : 7;  // 0x3BBE(0x1)
	bool CallFunc_IsValid_ReturnValue_38 : 1;  // 0x3BBE(0x1)
	char pad_15295[1];  // 0x3BBF(0x1)
	struct FST_ItemBase CallFunc_GetItem_Item_2;  // 0x3BC0(0x90)
	char pad_15440_1 : 7;  // 0x3C50(0x1)
	bool CallFunc_BooleanOR_ReturnValue_14 : 1;  // 0x3C50(0x1)
	char pad_15441[7];  // 0x3C51(0x7)
	struct FST_ItemBase K2Node_Select_Default_18;  // 0x3C58(0x90)
	char pad_15592_1 : 7;  // 0x3CE8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x3CE8(0x1)
	char pad_15593_1 : 7;  // 0x3CE9(0x1)
	bool CallFunc_BooleanAND_ReturnValue_27 : 1;  // 0x3CE9(0x1)
	char pad_15594[6];  // 0x3CEA(0x6)
	struct FKey K2Node_InputActionEvent_Key_43;  // 0x3CF0(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_16;  // 0x3D08(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_8;  // 0x3D14(0xC)
	int32_t K2Node_CustomEvent_invenotry_slot;  // 0x3D20(0x4)
	struct FVector K2Node_CustomEvent_throw_vector;  // 0x3D24(0xC)
	float K2Node_CustomEvent_Damage_6;  // 0x3D30(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_9;  // 0x3D34(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_4;  // 0x3D40(0xC)
	char pad_15692[4];  // 0x3D4C(0x4)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue;  // 0x3D50(0x30)
	char pad_15744_1 : 7;  // 0x3D80(0x1)
	bool CallFunc_ItemValid__Valid_2 : 1;  // 0x3D80(0x1)
	char pad_15745[7];  // 0x3D81(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_6;  // 0x3D88(0x8)
	struct ABP_ItemPickup_C* CallFunc_FinishSpawningActor_ReturnValue_6;  // 0x3D90(0x8)
	char pad_15768_1 : 7;  // 0x3D98(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_31 : 1;  // 0x3D98(0x1)
	char pad_15769[7];  // 0x3D99(0x7)
	struct AItemBP_C* K2Node_DynamicCast_AsItem_BP_2;  // 0x3DA0(0x8)
	char pad_15784_1 : 7;  // 0x3DA8(0x1)
	bool K2Node_DynamicCast_bSuccess_48 : 1;  // 0x3DA8(0x1)
	char pad_15785[7];  // 0x3DA9(0x7)
	struct TScriptInterface<IBPI_Item_C> CallFunc_Unequip_self_CastInput;  // 0x3DB0(0x10)
	struct AItemBP_C* K2Node_DynamicCast_AsItem_BP_3;  // 0x3DC0(0x8)
	char pad_15816_1 : 7;  // 0x3DC8(0x1)
	bool K2Node_DynamicCast_bSuccess_49 : 1;  // 0x3DC8(0x1)
	char pad_15817[3];  // 0x3DC9(0x3)
	int32_t K2Node_CustomEvent_NewSlot_4;  // 0x3DCC(0x4)
	struct TScriptInterface<IBPI_Item_C> CallFunc_Equip_self_CastInput;  // 0x3DD0(0x10)
	struct FST_ItemBase CallFunc_ReplaceWithFistIfEmpty_Out_2;  // 0x3DE0(0x90)
	char E_AnimType CallFunc_Item_Anim_Type_Type_4;  // 0x3E70(0x1)
	char pad_15985_1 : 7;  // 0x3E71(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_2 : 1;  // 0x3E71(0x1)
	char pad_15986_1 : 7;  // 0x3E72(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_20 : 1;  // 0x3E72(0x1)
	char pad_15987[1];  // 0x3E73(0x1)
	int32_t CallFunc_FindItemInInventory_index_2;  // 0x3E74(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item_2;  // 0x3E78(0x90)
	char pad_16136_1 : 7;  // 0x3F08(0x1)
	bool CallFunc_FindItemInInventory_Found_2 : 1;  // 0x3F08(0x1)
	char pad_16137[3];  // 0x3F09(0x3)
	int32_t CallFunc_FindItemInInventory_index_3;  // 0x3F0C(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item_3;  // 0x3F10(0x90)
	char pad_16288_1 : 7;  // 0x3FA0(0x1)
	bool CallFunc_FindItemInInventory_Found_3 : 1;  // 0x3FA0(0x1)
	char pad_16289[7];  // 0x3FA1(0x7)
	struct ABP_ItemPickup_C* K2Node_CustomEvent_PickupActor;  // 0x3FA8(0x8)
	struct FST_ItemBase K2Node_CustomEvent_Item_5;  // 0x3FB0(0x90)
	int32_t K2Node_CustomEvent_Slot_8;  // 0x4040(0x4)
	char pad_16452[4];  // 0x4044(0x4)
	struct TMap<int32_t, struct FST_ItemBase> CallFunc_FindItemsInInventory_Items;  // 0x4048(0x50)
	char pad_16536_1 : 7;  // 0x4098(0x1)
	bool CallFunc_FindItemsInInventory_Found_ : 1;  // 0x4098(0x1)
	char pad_16537[7];  // 0x4099(0x7)
	struct TArray<int32_t> CallFunc_Map_Keys_Keys;  // 0x40A0(0x10)
	int32_t CallFunc_Array_Get_Item_16;  // 0x40B0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_15;  // 0x40B4(0x4)
	char pad_16568_1 : 7;  // 0x40B8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_11 : 1;  // 0x40B8(0x1)
	char pad_16569_1 : 7;  // 0x40B9(0x1)
	bool CallFunc_BooleanAND_ReturnValue_28 : 1;  // 0x40B9(0x1)
	char pad_16570[2];  // 0x40BA(0x2)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_4;  // 0x40BC(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_5;  // 0x40C0(0x4)
	char pad_16580[4];  // 0x40C4(0x4)
	struct FST_ItemBase K2Node_SetFieldsInStruct_StructOut;  // 0x40C8(0x90)
	char pad_16728_1 : 7;  // 0x4158(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_12 : 1;  // 0x4158(0x1)
	char pad_16729[3];  // 0x4159(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_33;  // 0x415C(0x4)
	char pad_16736_1 : 7;  // 0x4160(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x4160(0x1)
	char pad_16737_1 : 7;  // 0x4161(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable_8 : 1;  // 0x4161(0x1)
	char pad_16738[2];  // 0x4162(0x2)
	int32_t K2Node_CustomEvent_NewSlot_3;  // 0x4164(0x4)
	char pad_16744_1 : 7;  // 0x4168(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_22 : 1;  // 0x4168(0x1)
	char pad_16745_1 : 7;  // 0x4169(0x1)
	bool CallFunc_BooleanAND_ReturnValue_29 : 1;  // 0x4169(0x1)
	char pad_16746_1 : 7;  // 0x416A(0x1)
	bool Temp_bool_IsClosed_Variable_20 : 1;  // 0x416A(0x1)
	char pad_16747[1];  // 0x416B(0x1)
	struct FVector CallFunc_GetForwardVector_ReturnValue_9;  // 0x416C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_17;  // 0x4178(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_10;  // 0x4184(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_5;  // 0x4190(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_6;  // 0x419C(0xC)
	struct FKey K2Node_InputActionEvent_Key_44;  // 0x41A8(0x18)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_2;  // 0x41C0(0x30)
	struct FST_ItemBase K2Node_CustomEvent_Item_4;  // 0x41F0(0x90)
	char pad_17024_1 : 7;  // 0x4280(0x1)
	bool CallFunc_HasAuthority_ReturnValue_16 : 1;  // 0x4280(0x1)
	char pad_17025[7];  // 0x4281(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_7;  // 0x4288(0x8)
	struct ABP_ItemPickup_C* CallFunc_FinishSpawningActor_ReturnValue_7;  // 0x4290(0x8)
	struct FVector K2Node_CustomEvent_ThrowVector_2;  // 0x4298(0xC)
	float K2Node_CustomEvent_Damage_5;  // 0x42A4(0x4)
	struct FST_ItemBase K2Node_CustomEvent_Item_3;  // 0x42A8(0x90)
	int32_t K2Node_CustomEvent_Slot_7;  // 0x4338(0x4)
	char pad_17212[4];  // 0x433C(0x4)
	struct AActor* K2Node_CustomEvent_actor_6;  // 0x4340(0x8)
	struct ABP_ItemPickup_C* K2Node_DynamicCast_AsBP_Item_Pickup;  // 0x4348(0x8)
	char pad_17232_1 : 7;  // 0x4350(0x1)
	bool K2Node_DynamicCast_bSuccess_50 : 1;  // 0x4350(0x1)
	char pad_17233[3];  // 0x4351(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_15;  // 0x4354(0x10)
	int32_t K2Node_CustomEvent_Slot_6;  // 0x4364(0x4)
	int32_t K2Node_CustomEvent_Ammo;  // 0x4368(0x4)
	char pad_17260_1 : 7;  // 0x436C(0x1)
	bool K2Node_CustomEvent_Destroy_on_1 : 1;  // 0x436C(0x1)
	char pad_17261_1 : 7;  // 0x436D(0x1)
	bool K2Node_CustomEvent_Equip__3 : 1;  // 0x436D(0x1)
	char pad_17262[2];  // 0x436E(0x2)
	int32_t K2Node_CustomEvent_SlotIndex_3;  // 0x4370(0x4)
	char pad_17268_1 : 7;  // 0x4374(0x1)
	bool K2Node_CustomEvent_Equip__2 : 1;  // 0x4374(0x1)
	char pad_17269_1 : 7;  // 0x4375(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // 0x4375(0x1)
	char pad_17270[2];  // 0x4376(0x2)
	int32_t CallFunc_SelectInt_ReturnValue_13;  // 0x4378(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_34;  // 0x437C(0x4)
	struct FKey Temp_struct_Variable_25;  // 0x4380(0x18)
	char pad_17304_1 : 7;  // 0x4398(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x4398(0x1)
	char pad_17305_1 : 7;  // 0x4399(0x1)
	bool CallFunc_BooleanAND_ReturnValue_30 : 1;  // 0x4399(0x1)
	char pad_17306[2];  // 0x439A(0x2)
	int32_t K2Node_CustomEvent_ReplicatedSelectedSlot;  // 0x439C(0x4)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_8;  // 0x43A0(0x8)
	char pad_17320_1 : 7;  // 0x43A8(0x1)
	bool CallFunc_IsPlayingSlotAnimation_ReturnValue_2 : 1;  // 0x43A8(0x1)
	char E_AnimType K2Node_CustomEvent_Enumerator;  // 0x43A9(0x1)
	char E_AnimType K2Node_CustomEvent_type;  // 0x43AA(0x1)
	char pad_17323[5];  // 0x43AB(0x5)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_AttackAnim_3;  // 0x43B0(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_BlockAnim_3;  // 0x43B8(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ShoveAnim_3;  // 0x43C0(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ChargeAnim_3;  // 0x43C8(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_idleAnim_3;  // 0x43D0(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ThrowAnim_3;  // 0x43D8(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_EquipAnim_3;  // 0x43E0(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_AttackAnim_4;  // 0x43E8(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_BlockAnim_4;  // 0x43F0(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ShoveAnim_4;  // 0x43F8(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ChargeAnim_4;  // 0x4400(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_idleAnim_4;  // 0x4408(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ThrowAnim_4;  // 0x4410(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_EquipAnim_4;  // 0x4418(0x8)
	int32_t K2Node_CustomEvent__wood;  // 0x4420(0x4)
	int32_t K2Node_CustomEvent__metal;  // 0x4424(0x4)
	int32_t K2Node_CustomEvent__binder;  // 0x4428(0x4)
	char pad_17452[4];  // 0x442C(0x4)
	struct FKey Temp_struct_Variable_26;  // 0x4430(0x18)
	int32_t CallFunc_Add_IntInt_ReturnValue_35;  // 0x4448(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_36;  // 0x444C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_37;  // 0x4450(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_38;  // 0x4454(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x4458(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_14;  // 0x445C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_39;  // 0x4460(0x4)
	char pad_17508_1 : 7;  // 0x4464(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_15 : 1;  // 0x4464(0x1)
	char pad_17509[3];  // 0x4465(0x3)
	struct FKey K2Node_InputActionEvent_Key_10;  // 0x4468(0x18)
	struct TArray<struct UBaseHUD_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_2;  // 0x4480(0x10)
	struct UBaseHUD_C* CallFunc_Array_Get_Item_17;  // 0x4490(0x8)
	int32_t K2Node_CustomEvent_Wood;  // 0x4498(0x4)
	int32_t K2Node_CustomEvent_Metal;  // 0x449C(0x4)
	int32_t K2Node_CustomEvent_Binder;  // 0x44A0(0x4)
	char pad_17572[4];  // 0x44A4(0x4)
	struct FKey K2Node_InputActionEvent_Key_45;  // 0x44A8(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue_3;  // 0x44C0(0x10)
	char pad_17616_1 : 7;  // 0x44D0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_4 : 1;  // 0x44D0(0x1)
	char pad_17617[7];  // 0x44D1(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0x44D8(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_2;  // 0x44E8(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue_4;  // 0x4500(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0x4510(0x10)
	char pad_17696_1 : 7;  // 0x4520(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_5 : 1;  // 0x4520(0x1)
	char pad_17697[7];  // 0x4521(0x7)
	struct FText CallFunc_Conv_StringToText_ReturnValue_3;  // 0x4528(0x18)
	struct FString CallFunc_Conv_IntToString_ReturnValue_5;  // 0x4540(0x10)
	char pad_17744_1 : 7;  // 0x4550(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_6 : 1;  // 0x4550(0x1)
	char pad_17745[7];  // 0x4551(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0x4558(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue_4;  // 0x4568(0x18)
	struct TArray<struct UchargeBar_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_3;  // 0x4580(0x10)
	struct UchargeBar_C* CallFunc_Array_Get_Item_18;  // 0x4590(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_16;  // 0x4598(0x4)
	char pad_17820_1 : 7;  // 0x459C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_13 : 1;  // 0x459C(0x1)
	char pad_17821[3];  // 0x459D(0x3)
	struct TArray<struct UBaseHUD_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_4;  // 0x45A0(0x10)
	struct UBaseHUD_C* CallFunc_Array_Get_Item_19;  // 0x45B0(0x8)
	struct FKey K2Node_InputActionEvent_Key_11;  // 0x45B8(0x18)
	struct TArray<struct UBaseHUD_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_5;  // 0x45D0(0x10)
	struct UBaseHUD_C* CallFunc_Array_Get_Item_20;  // 0x45E0(0x8)
	struct UchargeBar_C* CallFunc_AddCharge_widget_3;  // 0x45E8(0x8)
	int32_t K2Node_CustomEvent_Slot_5;  // 0x45F0(0x4)
	int32_t K2Node_CustomEvent_Slot_4;  // 0x45F4(0x4)
	struct FST_ItemCosts CallFunc_GetItemCost_Cost;  // 0x45F8(0xC)
	char pad_17924[4];  // 0x4604(0x4)
	struct FST_ItemBase CallFunc_Array_Get_Item_21;  // 0x4608(0x90)
	char pad_18072_1 : 7;  // 0x4698(0x1)
	bool CallFunc_IsValidClass_ReturnValue : 1;  // 0x4698(0x1)
	char pad_18073_1 : 7;  // 0x4699(0x1)
	bool CallFunc_ItemValid__Valid_3 : 1;  // 0x4699(0x1)
	char pad_18074[6];  // 0x469A(0x6)
	struct FKey K2Node_InputActionEvent_Key_46;  // 0x46A0(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_18;  // 0x46B8(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_10;  // 0x46C4(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_11;  // 0x46D0(0xC)
	char pad_18140[4];  // 0x46DC(0x4)
	struct FST_ItemBase CallFunc_Array_Get_Item_22;  // 0x46E0(0x90)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_7;  // 0x4770(0xC)
	char pad_18300[4];  // 0x477C(0x4)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_3;  // 0x4780(0x30)
	char pad_18352_1 : 7;  // 0x47B0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_11 : 1;  // 0x47B0(0x1)
	char pad_18353[7];  // 0x47B1(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_8;  // 0x47B8(0x8)
	struct ABP_ItemPickup_C* CallFunc_FinishSpawningActor_ReturnValue_8;  // 0x47C0(0x8)
	struct FST_ItemBase K2Node_CustomEvent_Item_2;  // 0x47C8(0x90)
	struct FVector K2Node_CustomEvent_ThrowVector;  // 0x4858(0xC)
	float K2Node_CustomEvent_Damage_4;  // 0x4864(0x4)
	struct FST_CraftRecipe K2Node_CustomEvent_NewItem;  // 0x4868(0x28)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x4890(0x4)
	int32_t K2Node_CustomEvent_ID_7;  // 0x4894(0x4)
	AActor* K2Node_CustomEvent_InClass;  // 0x4898(0x8)
	struct FName K2Node_CustomEvent_SocketName;  // 0x48A0(0x8)
	int32_t K2Node_CustomEvent_SlotIndex_2;  // 0x48A8(0x4)
	char pad_18604_1 : 7;  // 0x48AC(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_3 : 1;  // 0x48AC(0x1)
	char pad_18605_1 : 7;  // 0x48AD(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_7 : 1;  // 0x48AD(0x1)
	char pad_18606[2];  // 0x48AE(0x2)
	struct FST_ItemBase CallFunc_ReplaceWithFistIfEmpty_Out_3;  // 0x48B0(0x90)
	char E_AnimType CallFunc_Item_Anim_Type_Type_5;  // 0x4940(0x1)
	char pad_18753[7];  // 0x4941(0x7)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_AttackAnim_5;  // 0x4948(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_BlockAnim_5;  // 0x4950(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ShoveAnim_5;  // 0x4958(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ChargeAnim_5;  // 0x4960(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_idleAnim_5;  // 0x4968(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_ThrowAnim_5;  // 0x4970(0x8)
	struct UAnimSequenceBase* CallFunc_GetAnimationFromSection_EquipAnim_5;  // 0x4978(0x8)
	char pad_18816_1 : 7;  // 0x4980(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_9 : 1;  // 0x4980(0x1)
	char pad_18817[3];  // 0x4981(0x3)
	float CallFunc_PlaySlotAnimation_ReturnValue_7;  // 0x4984(0x4)
	char pad_18824_1 : 7;  // 0x4988(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_11 : 1;  // 0x4988(0x1)
	char pad_18825[7];  // 0x4989(0x7)
	struct FST_ItemBase K2Node_CustomEvent_Item;  // 0x4990(0x90)
	int32_t K2Node_CustomEvent_SlotIndex;  // 0x4A20(0x4)
	char pad_18980_1 : 7;  // 0x4A24(0x1)
	bool K2Node_CustomEvent_Equip_ : 1;  // 0x4A24(0x1)
	char pad_18981[3];  // 0x4A25(0x3)
	float Temp_float_Variable_19;  // 0x4A28(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_40;  // 0x4A2C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_41;  // 0x4A30(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_16;  // 0x4A34(0x10)
	float Temp_float_Variable_20;  // 0x4A44(0x4)
	float Temp_float_Variable_21;  // 0x4A48(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_7;  // 0x4A4C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_8;  // 0x4A58(0xC)
	float Temp_float_Variable_22;  // 0x4A64(0x4)
	char pad_19048[8];  // 0x4A68(0x8)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_4;  // 0x4A70(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_9;  // 0x4AA0(0x8)
	struct FString CallFunc_GetCurrentLevelName_ReturnValue;  // 0x4AA8(0x10)
	struct ABP_GlobalAudio_C* CallFunc_FinishSpawningActor_ReturnValue_9;  // 0x4AB8(0x8)
	char pad_19136_1 : 7;  // 0x4AC0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_12 : 1;  // 0x4AC0(0x1)
	char pad_19137_1 : 7;  // 0x4AC1(0x1)
	bool Temp_bool_Variable_29 : 1;  // 0x4AC1(0x1)
	char pad_19138[2];  // 0x4AC2(0x2)
	float K2Node_CustomEvent_Time_4;  // 0x4AC4(0x4)
	float K2Node_CustomEvent_MaxIntensity;  // 0x4AC8(0x4)
	float K2Node_CustomEvent_Start_Time;  // 0x4ACC(0x4)
	char pad_19152_1 : 7;  // 0x4AD0(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_17 : 1;  // 0x4AD0(0x1)
	char pad_19153[3];  // 0x4AD1(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue_15;  // 0x4AD4(0x4)
	char pad_19160_1 : 7;  // 0x4AD8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_21 : 1;  // 0x4AD8(0x1)
	char pad_19161[7];  // 0x4AD9(0x7)
	struct FKey Temp_struct_Variable_27;  // 0x4AE0(0x18)
	struct APlayerBRController_C* CallFunc_PC_pc_19;  // 0x4AF8(0x8)
	char pad_19200_1 : 7;  // 0x4B00(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_32 : 1;  // 0x4B00(0x1)
	char pad_19201[7];  // 0x4B01(0x7)
	struct FKey K2Node_InputActionEvent_Key_12;  // 0x4B08(0x18)
	struct UActorComponent* K2Node_CustomEvent_Target_9;  // 0x4B20(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_19;  // 0x4B28(0xC)
	float CallFunc_RandomFloatInRange_ReturnValue_5;  // 0x4B34(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_6;  // 0x4B38(0x4)
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue_2;  // 0x4B3C(0xC)
	float K2Node_CustomEvent__;  // 0x4B48(0x4)
	char pad_19276[4];  // 0x4B4C(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Healing_Target;  // 0x4B50(0x8)
	char pad_19288_1 : 7;  // 0x4B58(0x1)
	bool CallFunc_IsValid_ReturnValue_39 : 1;  // 0x4B58(0x1)
	char pad_19289_1 : 7;  // 0x4B59(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_3 : 1;  // 0x4B59(0x1)
	char pad_19290_1 : 7;  // 0x4B5A(0x1)
	bool Temp_bool_IsClosed_Variable_21 : 1;  // 0x4B5A(0x1)
	char pad_19291[1];  // 0x4B5B(0x1)
	int32_t CallFunc_Array_LastIndex_ReturnValue;  // 0x4B5C(0x4)
	struct FKey K2Node_InputActionEvent_Key_13;  // 0x4B60(0x18)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x4B78(0x4)
	struct FName CallFunc_Array_Get_Item_23;  // 0x4B7C(0x8)
	char pad_19332[12];  // 0x4B84(0xC)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x4B90(0x30)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x4BC0(0x8)
	struct FVector CallFunc_BreakTransform_Location_2;  // 0x4BC8(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_2;  // 0x4BD4(0xC)
	struct FVector CallFunc_BreakTransform_Scale_2;  // 0x4BE0(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_11;  // 0x4BEC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_12;  // 0x4BF8(0xC)
	char pad_19460[4];  // 0x4C04(0x4)
	struct UMaterialInstance* CallFunc_RandomBloodDecal_NewParam_2;  // 0x4C08(0x8)
	struct FTransform K2Node_CustomEvent_SpawnTransform_3;  // 0x4C10(0x30)
	float K2Node_CustomEvent_Damage_3;  // 0x4C40(0x4)
	char pad_19524_1 : 7;  // 0x4C44(0x1)
	bool K2Node_CustomEvent_HeadShot__2 : 1;  // 0x4C44(0x1)
	char pad_19525[3];  // 0x4C45(0x3)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_DamagedTarget;  // 0x4C48(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_33;  // 0x4C50(0x8)
	struct TArray<struct USceneComponent*> CallFunc_GetChildrenComponents_Children;  // 0x4C58(0x10)
	struct UDecalComponent* CallFunc_SpawnDecalAttached_ReturnValue;  // 0x4C68(0x8)
	struct USceneComponent* CallFunc_Array_Get_Item_24;  // 0x4C70(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_17;  // 0x4C78(0x4)
	char pad_19580[4];  // 0x4C7C(0x4)
	struct UDecalComponent* K2Node_DynamicCast_AsDecal_Component;  // 0x4C80(0x8)
	char pad_19592_1 : 7;  // 0x4C88(0x1)
	bool K2Node_DynamicCast_bSuccess_51 : 1;  // 0x4C88(0x1)
	char pad_19593_1 : 7;  // 0x4C89(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_14 : 1;  // 0x4C89(0x1)
	char pad_19594[6];  // 0x4C8A(0x6)
	struct FST_ItemBase CallFunc_Array_Get_Item_25;  // 0x4C90(0x90)
	int32_t CallFunc_Array_Length_ReturnValue_18;  // 0x4D20(0x4)
	char pad_19748_1 : 7;  // 0x4D24(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_15 : 1;  // 0x4D24(0x1)
	char pad_19749_1 : 7;  // 0x4D25(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_13 : 1;  // 0x4D25(0x1)
	char pad_19750[2];  // 0x4D26(0x2)
	struct FVector CallFunc_RandomUnitVector_ReturnValue_3;  // 0x4D28(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_13;  // 0x4D34(0xC)
	struct FTransform K2Node_CustomEvent_SpawnTransform_2;  // 0x4D40(0x30)
	float K2Node_CustomEvent_Damage_2;  // 0x4D70(0x4)
	char pad_19828_1 : 7;  // 0x4D74(0x1)
	bool K2Node_CustomEvent_HeadShot_ : 1;  // 0x4D74(0x1)
	char pad_19829[3];  // 0x4D75(0x3)
	struct AController* CallFunc_GetController_ReturnValue_18;  // 0x4D78(0x8)
	struct FVector CallFunc_BreakTransform_Location_3;  // 0x4D80(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation_3;  // 0x4D8C(0xC)
	struct FVector CallFunc_BreakTransform_Scale_3;  // 0x4D98(0xC)
	char pad_19876[4];  // 0x4DA4(0x4)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_3;  // 0x4DA8(0x8)
	char pad_19888_1 : 7;  // 0x4DB0(0x1)
	bool K2Node_DynamicCast_bSuccess_52 : 1;  // 0x4DB0(0x1)
	char pad_19889_1 : 7;  // 0x4DB1(0x1)
	bool CallFunc_CheckObjectBlock_Blocked_4 : 1;  // 0x4DB1(0x1)
	char pad_19890[2];  // 0x4DB2(0x2)
	struct FHitResult CallFunc_CheckObjectBlock_OutHit_4;  // 0x4DB4(0x88)
	char pad_20028[4];  // 0x4E3C(0x4)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD_3;  // 0x4E40(0x8)
	char pad_20040_1 : 7;  // 0x4E48(0x1)
	bool K2Node_DynamicCast_bSuccess_53 : 1;  // 0x4E48(0x1)
	char pad_20041[3];  // 0x4E49(0x3)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_9;  // 0x4E4C(0xC)
	char pad_20056[8];  // 0x4E58(0x8)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_5;  // 0x4E60(0x30)
	struct FVector K2Node_CustomEvent_AttackerLoc_2;  // 0x4E90(0xC)
	char pad_20124[4];  // 0x4E9C(0x4)
	struct UWidgetComponent* CallFunc_AddComponent_ReturnValue_5;  // 0x4EA0(0x8)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x4EA8(0x4)
	char pad_20140[4];  // 0x4EAC(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x4EB0(0x8)
	struct AController* CallFunc_GetController_ReturnValue_19;  // 0x4EB8(0x8)
	struct UHitDamage_C* K2Node_DynamicCast_AsHit_Damage;  // 0x4EC0(0x8)
	char pad_20168_1 : 7;  // 0x4EC8(0x1)
	bool K2Node_DynamicCast_bSuccess_54 : 1;  // 0x4EC8(0x1)
	char pad_20169[7];  // 0x4EC9(0x7)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_4;  // 0x4ED0(0x8)
	char pad_20184_1 : 7;  // 0x4ED8(0x1)
	bool K2Node_DynamicCast_bSuccess_55 : 1;  // 0x4ED8(0x1)
	char pad_20185[7];  // 0x4ED9(0x7)
	struct UDamageIndicator_C* CallFunc_Create_ReturnValue_2;  // 0x4EE0(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_8;  // 0x4EE8(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_12;  // 0x4EF4(0xC)
	char pad_20224_1 : 7;  // 0x4F00(0x1)
	bool Temp_bool_Variable_30 : 1;  // 0x4F00(0x1)
	char pad_20225[3];  // 0x4F01(0x3)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_5;  // 0x4F04(0xC)
	struct FVector CallFunc_Normal_ReturnValue_2;  // 0x4F10(0xC)
	float K2Node_Select_Default_19;  // 0x4F1C(0x4)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue_2;  // 0x4F20(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_19;  // 0x4F2C(0x4)
	float CallFunc_BreakRotator_Roll_3;  // 0x4F30(0x4)
	float CallFunc_BreakRotator_Pitch_3;  // 0x4F34(0x4)
	float CallFunc_BreakRotator_Yaw_3;  // 0x4F38(0x4)
	struct FVector K2Node_CustomEvent_AttackerLoc;  // 0x4F3C(0xC)
	float K2Node_CustomEvent___Health;  // 0x4F48(0x4)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x4F4C(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue_16;  // 0x4F58(0x4)
	struct FVector CallFunc_Normal_ReturnValue_3;  // 0x4F5C(0xC)
	char pad_20328_1 : 7;  // 0x4F68(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_16 : 1;  // 0x4F68(0x1)
	char pad_20329[3];  // 0x4F69(0x3)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_6;  // 0x4F6C(0xC)
	struct FVector CallFunc_Normal_ReturnValue_4;  // 0x4F78(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue_3;  // 0x4F84(0xC)
	float CallFunc_BreakRotator_Roll_4;  // 0x4F90(0x4)
	float CallFunc_BreakRotator_Pitch_4;  // 0x4F94(0x4)
	float CallFunc_BreakRotator_Yaw_4;  // 0x4F98(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x4F9C(0x4)
	struct FVector CallFunc_RandomUnitVector_ReturnValue_4;  // 0x4FA0(0xC)
	struct FVector CallFunc_RandomUnitVector_ReturnValue_5;  // 0x4FAC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_14;  // 0x4FB8(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_15;  // 0x4FC4(0xC)
	struct AController* CallFunc_GetController_ReturnValue_20;  // 0x4FD0(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_20;  // 0x4FD8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_10;  // 0x4FE4(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_11;  // 0x4FF0(0xC)
	char pad_20476[4];  // 0x4FFC(0x4)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_6;  // 0x5000(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_10;  // 0x5030(0x8)
	struct ABP_ItemPickup_C* CallFunc_FinishSpawningActor_ReturnValue_10;  // 0x5038(0x8)
	float K2Node_Event_Damage;  // 0x5040(0x4)
	char pad_20548[4];  // 0x5044(0x4)
	struct UDamageType* K2Node_Event_DamageType;  // 0x5048(0x8)
	struct AController* K2Node_Event_InstigatedBy;  // 0x5050(0x8)
	struct AActor* K2Node_Event_DamageCauser;  // 0x5058(0x8)
	UDamageType* Temp_class_Variable_3;  // 0x5060(0x8)
	char pad_20584_1 : 7;  // 0x5068(0x1)
	bool CallFunc_GetGlobalVar_bool_3 : 1;  // 0x5068(0x1)
	char pad_20585[7];  // 0x5069(0x7)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue_7;  // 0x5070(0x8)
	struct FString CallFunc_BreakSteamID_ReturnValue_7;  // 0x5078(0x10)
	char pad_20616_1 : 7;  // 0x5088(0x1)
	bool CallFunc_IsDev_Server_ReturnValue_4 : 1;  // 0x5088(0x1)
	char pad_20617_1 : 7;  // 0x5089(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_23 : 1;  // 0x5089(0x1)
	char pad_20618[2];  // 0x508A(0x2)
	float CallFunc_GetTotalModifiedMaxSprintSpeed_ReturnValue;  // 0x508C(0x4)
	float CallFunc_GetTotalModifiedMaxSprintSpeed_ReturnValue_2;  // 0x5090(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_4;  // 0x5094(0x4)
	float CallFunc_SelectFloat_ReturnValue_2;  // 0x5098(0x4)
	float K2Node_CustomEvent_MaxWalkSpeed_4;  // 0x509C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_20;  // 0x50A0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_21;  // 0x50A4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_22;  // 0x50A8(0x4)
	char pad_20652_1 : 7;  // 0x50AC(0x1)
	bool CallFunc_BooleanOR_ReturnValue_15 : 1;  // 0x50AC(0x1)
	char pad_20653[3];  // 0x50AD(0x3)
	float K2Node_CustomEvent_Stims_Sprint_Speed_Multiplier_2;  // 0x50B0(0x4)
	float K2Node_CustomEvent_Stims_Sprint_Speed_Multiplier;  // 0x50B4(0x4)
	struct UMyCharacterMovementComponent* CallFunc_GetMyMovementComponent_ReturnValue_3;  // 0x50B8(0x8)
	struct UMyCharacterMovementComponent* K2Node_DynamicCast_AsMy_Character_Movement_Component;  // 0x50C0(0x8)
	char pad_20680_1 : 7;  // 0x50C8(0x1)
	bool K2Node_DynamicCast_bSuccess_56 : 1;  // 0x50C8(0x1)
	char pad_20681[7];  // 0x50C9(0x7)
	struct UMyCharacterMovementComponent* CallFunc_GetMyMovementComponent_ReturnValue_4;  // 0x50D0(0x8)
	struct UMyCharacterMovementComponent* CallFunc_GetMyMovementComponent_ReturnValue_5;  // 0x50D8(0x8)
	char pad_20704_1 : 7;  // 0x50E0(0x1)
	bool CallFunc_GetGlobalVar_bool_4 : 1;  // 0x50E0(0x1)
	char pad_20705_1 : 7;  // 0x50E1(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_17 : 1;  // 0x50E1(0x1)
	char pad_20706[6];  // 0x50E2(0x6)
	UDamageType* Temp_class_Variable_4;  // 0x50E8(0x8)
	float K2Node_CustomEvent_MaxWalkSpeed_3;  // 0x50F0(0x4)
	char pad_20724_1 : 7;  // 0x50F4(0x1)
	bool K2Node_CustomEvent_Sprinting__2 : 1;  // 0x50F4(0x1)
	char pad_20725_1 : 7;  // 0x50F5(0x1)
	bool K2Node_CustomEvent_Force : 1;  // 0x50F5(0x1)
	char pad_20726_1 : 7;  // 0x50F6(0x1)
	bool Temp_bool_Variable_31 : 1;  // 0x50F6(0x1)
	char pad_20727[1];  // 0x50F7(0x1)
	float K2Node_CustomEvent_MaxWalkSpeed_2;  // 0x50F8(0x4)
	int32_t K2Node_CustomEvent_Initiator_2;  // 0x50FC(0x4)
	char pad_20736_1 : 7;  // 0x5100(0x1)
	bool K2Node_CustomEvent_sprinting : 1;  // 0x5100(0x1)
	char pad_20737[7];  // 0x5101(0x7)
	UDamageType* K2Node_Select_Default_20;  // 0x5108(0x8)
	char pad_20752_1 : 7;  // 0x5110(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_12 : 1;  // 0x5110(0x1)
	char pad_20753[3];  // 0x5111(0x3)
	float CallFunc_ApplyDamage_ReturnValue_5;  // 0x5114(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_17;  // 0x5118(0x4)
	char pad_20764_1 : 7;  // 0x511C(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_18 : 1;  // 0x511C(0x1)
	char pad_20765[3];  // 0x511D(0x3)
	float K2Node_CustomEvent_MaxWalkSpeed;  // 0x5120(0x4)
	char pad_20772_1 : 7;  // 0x5124(0x1)
	bool K2Node_CustomEvent_Sprinting_ : 1;  // 0x5124(0x1)
	char pad_20773[3];  // 0x5125(0x3)
	int32_t K2Node_CustomEvent_Initiator;  // 0x5128(0x4)
	char pad_20780_1 : 7;  // 0x512C(0x1)
	bool K2Node_CustomEvent_Should_Change_Speed : 1;  // 0x512C(0x1)
	char pad_20781_1 : 7;  // 0x512D(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_19 : 1;  // 0x512D(0x1)
	char pad_20782_1 : 7;  // 0x512E(0x1)
	bool CallFunc_BooleanAND_ReturnValue_31 : 1;  // 0x512E(0x1)
	char pad_20783[1];  // 0x512F(0x1)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x5130(0x4)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_3;  // 0x5134(0x4)
	char pad_20792_1 : 7;  // 0x5138(0x1)
	bool Temp_bool_Variable_32 : 1;  // 0x5138(0x1)
	char pad_20793[3];  // 0x5139(0x3)
	float CallFunc_GetTotalModifiedMaxSprintSpeed_ReturnValue_3;  // 0x513C(0x4)
	char pad_20800_1 : 7;  // 0x5140(0x1)
	bool CallFunc_BooleanOR_ReturnValue_16 : 1;  // 0x5140(0x1)
	char pad_20801[7];  // 0x5141(0x7)
	struct UMyCharacterMovementComponent* K2Node_DynamicCast_AsMy_Character_Movement_Component_2;  // 0x5148(0x8)
	char pad_20816_1 : 7;  // 0x5150(0x1)
	bool K2Node_DynamicCast_bSuccess_57 : 1;  // 0x5150(0x1)
	char pad_20817_1 : 7;  // 0x5151(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_24 : 1;  // 0x5151(0x1)
	char pad_20818_1 : 7;  // 0x5152(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_20 : 1;  // 0x5152(0x1)
	char pad_20819_1 : 7;  // 0x5153(0x1)
	bool CallFunc_BooleanAND_ReturnValue_32 : 1;  // 0x5153(0x1)
	float CallFunc_Divide_FloatFloat_ReturnValue_18;  // 0x5154(0x4)
	char pad_20824_1 : 7;  // 0x5158(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_21 : 1;  // 0x5158(0x1)
	char pad_20825_1 : 7;  // 0x5159(0x1)
	bool CallFunc_IsFalling_ReturnValue_3 : 1;  // 0x5159(0x1)
	char pad_20826_1 : 7;  // 0x515A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_25 : 1;  // 0x515A(0x1)
	char pad_20827_1 : 7;  // 0x515B(0x1)
	bool CallFunc_IsValid_ReturnValue_40 : 1;  // 0x515B(0x1)
	char pad_20828[4];  // 0x515C(0x4)
	struct UMyCharacterMovementComponent* CallFunc_GetMyMovementComponent_ReturnValue_6;  // 0x5160(0x8)
	char pad_20840_1 : 7;  // 0x5168(0x1)
	bool CallFunc_CanSprint_ReturnValue : 1;  // 0x5168(0x1)
	char pad_20841[3];  // 0x5169(0x3)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue_2;  // 0x516C(0xC)
	float CallFunc_BreakVector_X_8;  // 0x5178(0x4)
	float CallFunc_BreakVector_Y_8;  // 0x517C(0x4)
	float CallFunc_BreakVector_Z_8;  // 0x5180(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_6;  // 0x5184(0xC)
	float CallFunc_VSize_ReturnValue_2;  // 0x5190(0x4)
	char pad_20884_1 : 7;  // 0x5194(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_18 : 1;  // 0x5194(0x1)
	char pad_20885[3];  // 0x5195(0x3)
	struct FDateTime CallFunc_Now_ReturnValue_34;  // 0x5198(0x8)
	char pad_20896_1 : 7;  // 0x51A0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_22 : 1;  // 0x51A0(0x1)
	char pad_20897[3];  // 0x51A1(0x3)
	int32_t Temp_int_Array_Index_Variable_30;  // 0x51A4(0x4)
	UC_Upgrade_C* CallFunc_Array_Get_Item_26;  // 0x51A8(0x8)
	UC_UpgradeVampire_C* K2Node_ClassDynamicCast_AsC_Upgrade_Vampire;  // 0x51B0(0x8)
	char pad_20920_1 : 7;  // 0x51B8(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_15 : 1;  // 0x51B8(0x1)
	char pad_20921[7];  // 0x51B9(0x7)
	struct FDateTime CallFunc_Now_ReturnValue_35;  // 0x51C0(0x8)
	float K2Node_InputAxisEvent_AxisValue;  // 0x51C8(0x4)
	float K2Node_CustomEvent_X;  // 0x51CC(0x4)
	struct FVector4 K2Node_MakeStruct_Vector4;  // 0x51D0(0x10)
	struct FST_ItemBase CallFunc_Array_Get_Item_27;  // 0x51E0(0x90)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_4;  // 0x5270(0x4)
	char pad_21108_1 : 7;  // 0x5274(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_10 : 1;  // 0x5274(0x1)
	char pad_21109_1 : 7;  // 0x5275(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_14 : 1;  // 0x5275(0x1)
	char pad_21110_1 : 7;  // 0x5276(0x1)
	bool CallFunc_BooleanOR_ReturnValue_17 : 1;  // 0x5276(0x1)
	char pad_21111_1 : 7;  // 0x5277(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_8 : 1;  // 0x5277(0x1)
	char pad_21112_1 : 7;  // 0x5278(0x1)
	bool CallFunc_BooleanAND_ReturnValue_33 : 1;  // 0x5278(0x1)
	char pad_21113_1 : 7;  // 0x5279(0x1)
	bool CallFunc_BooleanAND_ReturnValue_34 : 1;  // 0x5279(0x1)
	char pad_21114_1 : 7;  // 0x527A(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_9 : 1;  // 0x527A(0x1)
	char pad_21115[1];  // 0x527B(0x1)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_5;  // 0x527C(0x4)
	char pad_21120_1 : 7;  // 0x5280(0x1)
	bool CallFunc_BooleanAND_ReturnValue_35 : 1;  // 0x5280(0x1)
	char pad_21121_1 : 7;  // 0x5281(0x1)
	bool CallFunc_BooleanAND_ReturnValue_36 : 1;  // 0x5281(0x1)
	char pad_21122[6];  // 0x5282(0x6)
	struct APlayerBRController_C* CallFunc_PC_pc_20;  // 0x5288(0x8)
	char pad_21136_1 : 7;  // 0x5290(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_26 : 1;  // 0x5290(0x1)
	char pad_21137_1 : 7;  // 0x5291(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_33 : 1;  // 0x5291(0x1)
	char pad_21138_1 : 7;  // 0x5292(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_34 : 1;  // 0x5292(0x1)
	char pad_21139_1 : 7;  // 0x5293(0x1)
	bool CallFunc_BooleanAND_ReturnValue_37 : 1;  // 0x5293(0x1)
	char pad_21140_1 : 7;  // 0x5294(0x1)
	bool K2Node_CustomEvent_Workbench : 1;  // 0x5294(0x1)
	char pad_21141[3];  // 0x5295(0x3)
	struct AWorkbench_C* K2Node_CustomEvent_WorkbenchActor;  // 0x5298(0x8)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue;  // 0x52A0(0x8)
	float CallFunc_BreakVector2D_X;  // 0x52A8(0x4)
	float CallFunc_BreakVector2D_Y;  // 0x52AC(0x4)
	struct TArray<struct FST_CraftRecipe> CallFunc_WorkbenchOnlyRecipies_out;  // 0x52B0(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue_19;  // 0x52C0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_20;  // 0x52C4(0x4)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x52C8(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_2;  // 0x52CC(0x4)
	struct TArray<struct UCraftingMenu2_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_6;  // 0x52D0(0x10)
	struct AController* CallFunc_GetController_ReturnValue_21;  // 0x52E0(0x8)
	struct UCraftingMenu2_C* CallFunc_Array_Get_Item_28;  // 0x52E8(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_16;  // 0x52F0(0x8)
	char pad_21240_1 : 7;  // 0x52F8(0x1)
	bool K2Node_DynamicCast_bSuccess_58 : 1;  // 0x52F8(0x1)
	char pad_21241[7];  // 0x52F9(0x7)
	struct UCraftingMenu2_C* CallFunc_Create_ReturnValue_3;  // 0x5300(0x8)
	struct UCraftingMenu2_C* CallFunc_Create_ReturnValue_4;  // 0x5308(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_19;  // 0x5310(0x4)
	char pad_21268[4];  // 0x5314(0x4)
	struct USaveGame* Temp_object_Variable_19;  // 0x5318(0x8)
	char pad_21280_1 : 7;  // 0x5320(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_16 : 1;  // 0x5320(0x1)
	char pad_21281_1 : 7;  // 0x5321(0x1)
	bool Temp_bool_Variable_33 : 1;  // 0x5321(0x1)
	char pad_21282[6];  // 0x5322(0x6)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_9;  // 0x5328(0x8)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue_2;  // 0x5330(0x8)
	char pad_21304_1 : 7;  // 0x5338(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_35 : 1;  // 0x5338(0x1)
	char pad_21305_1 : 7;  // 0x5339(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_36 : 1;  // 0x5339(0x1)
	char pad_21306_1 : 7;  // 0x533A(0x1)
	bool K2Node_CustomEvent_Exclusive_4 : 1;  // 0x533A(0x1)
	char pad_21307[5];  // 0x533B(0x5)
	struct FTransform CallFunc_MakeTransform_ReturnValue_2;  // 0x5340(0x30)
	struct USkeletalMeshComponent* CallFunc_AddComponent_ReturnValue_6;  // 0x5370(0x8)
	char pad_21368_1 : 7;  // 0x5378(0x1)
	bool K2Node_CustomEvent_Exclusive_3 : 1;  // 0x5378(0x1)
	char pad_21369_1 : 7;  // 0x5379(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_4 : 1;  // 0x5379(0x1)
	char pad_21370_1 : 7;  // 0x537A(0x1)
	bool K2Node_CustomEvent_Exclusive_2 : 1;  // 0x537A(0x1)
	char pad_21371_1 : 7;  // 0x537B(0x1)
	bool K2Node_CustomEvent_Exclusive : 1;  // 0x537B(0x1)
	char pad_21372_1 : 7;  // 0x537C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_38 : 1;  // 0x537C(0x1)
	char pad_21373_1 : 7;  // 0x537D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_39 : 1;  // 0x537D(0x1)
	char pad_21374_1 : 7;  // 0x537E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_27 : 1;  // 0x537E(0x1)
	char pad_21375_1 : 7;  // 0x537F(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_28 : 1;  // 0x537F(0x1)
	char pad_21376_1 : 7;  // 0x5380(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_10 : 1;  // 0x5380(0x1)
	char pad_21377_1 : 7;  // 0x5381(0x1)
	bool Temp_bool_IsClosed_Variable_22 : 1;  // 0x5381(0x1)
	char pad_21378[2];  // 0x5382(0x2)
	int32_t Temp_int_Variable;  // 0x5384(0x4)
	char pad_21384_1 : 7;  // 0x5388(0x1)
	bool Temp_bool_Variable_34 : 1;  // 0x5388(0x1)
	char pad_21385[7];  // 0x5389(0x7)
	struct FDateTime Temp_wildcard_Variable_11;  // 0x5390(0x8)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_12;  // 0x5398(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_12;  // 0x53A0(0x4)
	char pad_21412[4];  // 0x53A4(0x4)
	struct USaveGame* K2Node_CustomEvent_SaveGame_6;  // 0x53A8(0x8)
	char pad_21424_1 : 7;  // 0x53B0(0x1)
	bool K2Node_CustomEvent_bSuccess_6 : 1;  // 0x53B0(0x1)
	char pad_21425[3];  // 0x53B1(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue_21;  // 0x53B4(0x4)
	char pad_21432_1 : 7;  // 0x53B8(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_22 : 1;  // 0x53B8(0x1)
	char pad_21433[7];  // 0x53B9(0x7)
	struct USoundAttenuation* Temp_object_Variable_20;  // 0x53C0(0x8)
	char pad_21448_1 : 7;  // 0x53C8(0x1)
	bool Temp_bool_Variable_35 : 1;  // 0x53C8(0x1)
	char pad_21449[7];  // 0x53C9(0x7)
	struct FKey Temp_struct_Variable_28;  // 0x53D0(0x18)
	struct FKey K2Node_InputActionEvent_Key_14;  // 0x53E8(0x18)
	char pad_21504_1 : 7;  // 0x5400(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_29 : 1;  // 0x5400(0x1)
	char pad_21505[7];  // 0x5401(0x7)
	struct FKey K2Node_InputActionEvent_Key_15;  // 0x5408(0x18)
	char pad_21536_1 : 7;  // 0x5420(0x1)
	bool CallFunc_HasAuthority_ReturnValue_17 : 1;  // 0x5420(0x1)
	char pad_21537[3];  // 0x5421(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_17;  // 0x5424(0x10)
	char pad_21556[4];  // 0x5434(0x4)
	struct AActor* K2Node_CustomEvent_actor_5;  // 0x5438(0x8)
	char pad_21568_1 : 7;  // 0x5440(0x1)
	bool K2Node_CustomEvent_bNewHidden_3 : 1;  // 0x5440(0x1)
	char pad_21569[7];  // 0x5441(0x7)
	struct AActor* K2Node_CustomEvent_Target_8;  // 0x5448(0x8)
	char pad_21584_1 : 7;  // 0x5450(0x1)
	bool K2Node_CustomEvent_bNewHidden_2 : 1;  // 0x5450(0x1)
	char pad_21585[7];  // 0x5451(0x7)
	struct AActor* K2Node_CustomEvent_actor_4;  // 0x5458(0x8)
	char pad_21600_1 : 7;  // 0x5460(0x1)
	bool K2Node_CustomEvent_bNewHidden : 1;  // 0x5460(0x1)
	char pad_21601_1 : 7;  // 0x5461(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_4 : 1;  // 0x5461(0x1)
	char pad_21602[6];  // 0x5462(0x6)
	struct UParticleSystem* K2Node_CustomEvent_EmitterTemplate_3;  // 0x5468(0x8)
	struct USceneComponent* K2Node_CustomEvent_AttachToComponent_7;  // 0x5470(0x8)
	struct FVector K2Node_CustomEvent_Scale_4;  // 0x5478(0xC)
	struct FVector K2Node_CustomEvent_Location_14;  // 0x5484(0xC)
	struct FRotator K2Node_CustomEvent_Rotation_6;  // 0x5490(0xC)
	char pad_21660[4];  // 0x549C(0x4)
	struct UParticleSystem* K2Node_CustomEvent_EmitterTemplate_2;  // 0x54A0(0x8)
	struct FVector K2Node_CustomEvent_Location_13;  // 0x54A8(0xC)
	struct FVector K2Node_CustomEvent_Scale_3;  // 0x54B4(0xC)
	struct USceneComponent* K2Node_CustomEvent_AttachToComponent_6;  // 0x54C0(0x8)
	struct FRotator K2Node_CustomEvent_Rotation_5;  // 0x54C8(0xC)
	char pad_21716[4];  // 0x54D4(0x4)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue_3;  // 0x54D8(0x8)
	char pad_21728_1 : 7;  // 0x54E0(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_5 : 1;  // 0x54E0(0x1)
	char pad_21729[7];  // 0x54E1(0x7)
	struct UParticleSystem* K2Node_CustomEvent_EmitterTemplate;  // 0x54E8(0x8)
	struct FVector K2Node_CustomEvent_Location_12;  // 0x54F0(0xC)
	struct FVector K2Node_CustomEvent_Scale_2;  // 0x54FC(0xC)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue_2;  // 0x5508(0x8)
	int32_t Temp_int_Array_Index_Variable_31;  // 0x5510(0x4)
	char pad_21780[4];  // 0x5514(0x4)
	struct ABP_Effect_C* CallFunc_Array_Get_Item_29;  // 0x5518(0x8)
	struct ABP_Effect_PoolBlast_C* K2Node_DynamicCast_AsBP_Effect_Pool_Blast;  // 0x5520(0x8)
	char pad_21800_1 : 7;  // 0x5528(0x1)
	bool K2Node_DynamicCast_bSuccess_59 : 1;  // 0x5528(0x1)
	char pad_21801_1 : 7;  // 0x5529(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_23 : 1;  // 0x5529(0x1)
	char pad_21802[2];  // 0x552A(0x2)
	int32_t CallFunc_FindItemInInventory_index_4;  // 0x552C(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item_4;  // 0x5530(0x90)
	char pad_21952_1 : 7;  // 0x55C0(0x1)
	bool CallFunc_FindItemInInventory_Found_4 : 1;  // 0x55C0(0x1)
	char pad_21953[7];  // 0x55C1(0x7)
	struct FST_CraftRecipe K2Node_CustomEvent_recipe_3;  // 0x55C8(0x28)
	struct AWorkbench_C* K2Node_CustomEvent_Target_7;  // 0x55F0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_20;  // 0x55F8(0x4)
	char pad_22012_1 : 7;  // 0x55FC(0x1)
	bool CallFunc_CanCraft_Can_Craft : 1;  // 0x55FC(0x1)
	char pad_22013_1 : 7;  // 0x55FD(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_8 : 1;  // 0x55FD(0x1)
	char pad_22014[2];  // 0x55FE(0x2)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_21;  // 0x5600(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue_13;  // 0x560C(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_16;  // 0x5618(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_12;  // 0x5624(0xC)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_7;  // 0x5630(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_11;  // 0x5660(0x8)
	struct ABP_ItemPickup_C* CallFunc_FinishSpawningActor_ReturnValue_11;  // 0x5668(0x8)
	struct FST_CraftRecipe K2Node_CustomEvent_recipe_2;  // 0x5670(0x28)
	struct FST_CraftRecipe K2Node_CustomEvent_recipe;  // 0x5698(0x28)
	char pad_22208_1 : 7;  // 0x56C0(0x1)
	bool CallFunc_CanCraft_Can_Craft_2 : 1;  // 0x56C0(0x1)
	char pad_22209[7];  // 0x56C1(0x7)
	struct FST_ItemBase CallFunc_GetItem_Item_3;  // 0x56C8(0x90)
	char pad_22360_1 : 7;  // 0x5758(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x5758(0x1)
	char pad_22361_1 : 7;  // 0x5759(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_2 : 1;  // 0x5759(0x1)
	char pad_22362_1 : 7;  // 0x575A(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_9 : 1;  // 0x575A(0x1)
	char pad_22363[1];  // 0x575B(0x1)
	int32_t CallFunc_FindItemInInventory_index_5;  // 0x575C(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item_5;  // 0x5760(0x90)
	char pad_22512_1 : 7;  // 0x57F0(0x1)
	bool CallFunc_FindItemInInventory_Found_5 : 1;  // 0x57F0(0x1)
	char pad_22513_1 : 7;  // 0x57F1(0x1)
	bool CallFunc_BooleanAND_ReturnValue_40 : 1;  // 0x57F1(0x1)
	char pad_22514_1 : 7;  // 0x57F2(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue_3 : 1;  // 0x57F2(0x1)
	char pad_22515_1 : 7;  // 0x57F3(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_17 : 1;  // 0x57F3(0x1)
	char pad_22516_1 : 7;  // 0x57F4(0x1)
	bool CallFunc_BooleanAND_ReturnValue_41 : 1;  // 0x57F4(0x1)
	char pad_22517_1 : 7;  // 0x57F5(0x1)
	bool CallFunc_BooleanAND_ReturnValue_42 : 1;  // 0x57F5(0x1)
	char pad_22518_1 : 7;  // 0x57F6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_43 : 1;  // 0x57F6(0x1)
	char pad_22519_1 : 7;  // 0x57F7(0x1)
	bool CallFunc_BooleanAND_ReturnValue_44 : 1;  // 0x57F7(0x1)
	char pad_22520_1 : 7;  // 0x57F8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_30 : 1;  // 0x57F8(0x1)
	char pad_22521[7];  // 0x57F9(0x7)
	struct FST_ItemBase CallFunc_GetItem_Item_4;  // 0x5800(0x90)
	char pad_22672_1 : 7;  // 0x5890(0x1)
	bool CallFunc_BooleanAND_ReturnValue_45 : 1;  // 0x5890(0x1)
	char pad_22673_1 : 7;  // 0x5891(0x1)
	bool CallFunc_BooleanAND_ReturnValue_46 : 1;  // 0x5891(0x1)
	char pad_22674_1 : 7;  // 0x5892(0x1)
	bool CallFunc_IsValid_ReturnValue_41 : 1;  // 0x5892(0x1)
	char pad_22675_1 : 7;  // 0x5893(0x1)
	bool Temp_bool_IsClosed_Variable_23 : 1;  // 0x5893(0x1)
	char pad_22676[4];  // 0x5894(0x4)
	struct TArray<struct UPlayerInfo_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_7;  // 0x5898(0x10)
	struct AActor* K2Node_CustomEvent_actor_3;  // 0x58A8(0x8)
	struct UPlayerInfo_C* CallFunc_Array_Get_Item_30;  // 0x58B0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_21;  // 0x58B8(0x4)
	char pad_22716_1 : 7;  // 0x58BC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_18 : 1;  // 0x58BC(0x1)
	char pad_22717_1 : 7;  // 0x58BD(0x1)
	bool CallFunc_IsValid_ReturnValue_42 : 1;  // 0x58BD(0x1)
	char pad_22718_1 : 7;  // 0x58BE(0x1)
	bool CallFunc_IsValid_ReturnValue_43 : 1;  // 0x58BE(0x1)
	char pad_22719[1];  // 0x58BF(0x1)
	struct FHitResult CallFunc_InteractionTrace_OutHit;  // 0x58C0(0x88)
	char pad_22856_1 : 7;  // 0x5948(0x1)
	bool CallFunc_InteractionTrace_ReturnValue : 1;  // 0x5948(0x1)
	char pad_22857_1 : 7;  // 0x5949(0x1)
	bool CallFunc_IsValid_ReturnValue_44 : 1;  // 0x5949(0x1)
	char pad_22858_1 : 7;  // 0x594A(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_5 : 1;  // 0x594A(0x1)
	char pad_22859_1 : 7;  // 0x594B(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_5 : 1;  // 0x594B(0x1)
	float CallFunc_BreakHitResult_Time_5;  // 0x594C(0x4)
	float CallFunc_BreakHitResult_Distance_5;  // 0x5950(0x4)
	struct FVector CallFunc_BreakHitResult_Location_5;  // 0x5954(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_5;  // 0x5960(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_5;  // 0x596C(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_5;  // 0x5978(0xC)
	char pad_22916[4];  // 0x5984(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_5;  // 0x5988(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_5;  // 0x5990(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_5;  // 0x5998(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_5;  // 0x59A0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_5;  // 0x59A8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_5;  // 0x59AC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_5;  // 0x59B0(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_5;  // 0x59B4(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_5;  // 0x59C0(0xC)
	char pad_22988[4];  // 0x59CC(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_4;  // 0x59D0(0x8)
	char pad_23000_1 : 7;  // 0x59D8(0x1)
	bool K2Node_DynamicCast_bSuccess_60 : 1;  // 0x59D8(0x1)
	char pad_23001_1 : 7;  // 0x59D9(0x1)
	bool CallFunc_IsValid_ReturnValue_45 : 1;  // 0x59D9(0x1)
	char pad_23002_1 : 7;  // 0x59DA(0x1)
	bool CallFunc_CheckObjectBlock_Blocked_5 : 1;  // 0x59DA(0x1)
	char pad_23003[1];  // 0x59DB(0x1)
	struct FHitResult CallFunc_CheckObjectBlock_OutHit_5;  // 0x59DC(0x88)
	char pad_23140_1 : 7;  // 0x5A64(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_31 : 1;  // 0x5A64(0x1)
	char pad_23141[3];  // 0x5A65(0x3)
	struct FHitResult CallFunc_InteractionTrace_OutHit_2;  // 0x5A68(0x88)
	char pad_23280_1 : 7;  // 0x5AF0(0x1)
	bool CallFunc_InteractionTrace_ReturnValue_2 : 1;  // 0x5AF0(0x1)
	char pad_23281_1 : 7;  // 0x5AF1(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_6 : 1;  // 0x5AF1(0x1)
	char pad_23282_1 : 7;  // 0x5AF2(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_6 : 1;  // 0x5AF2(0x1)
	char pad_23283[1];  // 0x5AF3(0x1)
	float CallFunc_BreakHitResult_Time_6;  // 0x5AF4(0x4)
	float CallFunc_BreakHitResult_Distance_6;  // 0x5AF8(0x4)
	struct FVector CallFunc_BreakHitResult_Location_6;  // 0x5AFC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_6;  // 0x5B08(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_6;  // 0x5B14(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_6;  // 0x5B20(0xC)
	char pad_23340[4];  // 0x5B2C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_6;  // 0x5B30(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_6;  // 0x5B38(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_6;  // 0x5B40(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_6;  // 0x5B48(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_6;  // 0x5B50(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_6;  // 0x5B54(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_6;  // 0x5B58(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_6;  // 0x5B5C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_6;  // 0x5B68(0xC)
	char pad_23412_1 : 7;  // 0x5B74(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_2 : 1;  // 0x5B74(0x1)
	char pad_23413_1 : 7;  // 0x5B75(0x1)
	bool CallFunc_CheckObjectBlock_Blocked_6 : 1;  // 0x5B75(0x1)
	char pad_23414[2];  // 0x5B76(0x2)
	struct FHitResult CallFunc_CheckObjectBlock_OutHit_6;  // 0x5B78(0x88)
	char pad_23552_1 : 7;  // 0x5C00(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_32 : 1;  // 0x5C00(0x1)
	char pad_23553_1 : 7;  // 0x5C01(0x1)
	bool CallFunc_IsValid_ReturnValue_46 : 1;  // 0x5C01(0x1)
	char pad_23554[2];  // 0x5C02(0x2)
	struct FHitResult CallFunc_InteractionTrace_OutHit_3;  // 0x5C04(0x88)
	char pad_23692_1 : 7;  // 0x5C8C(0x1)
	bool CallFunc_InteractionTrace_ReturnValue_3 : 1;  // 0x5C8C(0x1)
	char pad_23693_1 : 7;  // 0x5C8D(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_7 : 1;  // 0x5C8D(0x1)
	char pad_23694_1 : 7;  // 0x5C8E(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_7 : 1;  // 0x5C8E(0x1)
	char pad_23695[1];  // 0x5C8F(0x1)
	float CallFunc_BreakHitResult_Time_7;  // 0x5C90(0x4)
	float CallFunc_BreakHitResult_Distance_7;  // 0x5C94(0x4)
	struct FVector CallFunc_BreakHitResult_Location_7;  // 0x5C98(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_7;  // 0x5CA4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_7;  // 0x5CB0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_7;  // 0x5CBC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_7;  // 0x5CC8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_7;  // 0x5CD0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_7;  // 0x5CD8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_7;  // 0x5CE0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_7;  // 0x5CE8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_7;  // 0x5CEC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_7;  // 0x5CF0(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_7;  // 0x5CF4(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_7;  // 0x5D00(0xC)
	char pad_23820_1 : 7;  // 0x5D0C(0x1)
	bool CallFunc_CheckObjectBlock_Blocked_7 : 1;  // 0x5D0C(0x1)
	char pad_23821[3];  // 0x5D0D(0x3)
	struct FHitResult CallFunc_CheckObjectBlock_OutHit_7;  // 0x5D10(0x88)
	struct ABP_ItemPickup_C* K2Node_DynamicCast_AsBP_Item_Pickup_2;  // 0x5D98(0x8)
	char pad_23968_1 : 7;  // 0x5DA0(0x1)
	bool K2Node_DynamicCast_bSuccess_61 : 1;  // 0x5DA0(0x1)
	char pad_23969_1 : 7;  // 0x5DA1(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_33 : 1;  // 0x5DA1(0x1)
	char pad_23970[6];  // 0x5DA2(0x6)
	struct USaveGame* Temp_object_Variable_21;  // 0x5DA8(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_4;  // 0x5DB0(0x8)
	char pad_23992_1 : 7;  // 0x5DB8(0x1)
	bool K2Node_DynamicCast_bSuccess_62 : 1;  // 0x5DB8(0x1)
	char pad_23993_1 : 7;  // 0x5DB9(0x1)
	bool CallFunc_VerifyChosenRecipies_ReturnValue : 1;  // 0x5DB9(0x1)
	char pad_23994_1 : 7;  // 0x5DBA(0x1)
	bool Temp_bool_Variable_36 : 1;  // 0x5DBA(0x1)
	char pad_23995_1 : 7;  // 0x5DBB(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_6 : 1;  // 0x5DBB(0x1)
	char pad_23996_1 : 7;  // 0x5DBC(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_7 : 1;  // 0x5DBC(0x1)
	char pad_23997_1 : 7;  // 0x5DBD(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_34 : 1;  // 0x5DBD(0x1)
	char pad_23998_1 : 7;  // 0x5DBE(0x1)
	bool CallFunc_BooleanAND_ReturnValue_47 : 1;  // 0x5DBE(0x1)
	char pad_23999_1 : 7;  // 0x5DBF(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_8 : 1;  // 0x5DBF(0x1)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_6;  // 0x5DC0(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_7;  // 0x5DC4(0x4)
	char pad_24008_1 : 7;  // 0x5DC8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_24 : 1;  // 0x5DC8(0x1)
	char pad_24009_1 : 7;  // 0x5DC9(0x1)
	bool CallFunc_IsValid_ReturnValue_47 : 1;  // 0x5DC9(0x1)
	char pad_24010_1 : 7;  // 0x5DCA(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_9 : 1;  // 0x5DCA(0x1)
	char pad_24011_1 : 7;  // 0x5DCB(0x1)
	bool Temp_bool_IsClosed_Variable_24 : 1;  // 0x5DCB(0x1)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_8;  // 0x5DCC(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc_21;  // 0x5DD0(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_9;  // 0x5DD8(0x4)
	char pad_24028[4];  // 0x5DDC(0x4)
	struct UPlayerInfo_C* CallFunc_Create_ReturnValue_5;  // 0x5DE0(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_7;  // 0x5DE8(0x8)
	char pad_24048_1 : 7;  // 0x5DF0(0x1)
	bool K2Node_CustomEvent_bSuccess_7 : 1;  // 0x5DF0(0x1)
	char pad_24049[3];  // 0x5DF1(0x3)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_10;  // 0x5DF4(0x4)
	char pad_24056_1 : 7;  // 0x5DF8(0x1)
	bool K2Node_CustomEvent_Start_Look__3 : 1;  // 0x5DF8(0x1)
	char pad_24057[7];  // 0x5DF9(0x7)
	struct UObject* K2Node_CustomEvent_Target_6;  // 0x5E00(0x8)
	int32_t CallFunc_Subtract_IntInt_ReturnValue_11;  // 0x5E08(0x4)
	char pad_24076_1 : 7;  // 0x5E0C(0x1)
	bool K2Node_CustomEvent_Start_Look__2 : 1;  // 0x5E0C(0x1)
	char pad_24077[3];  // 0x5E0D(0x3)
	struct UObject* K2Node_CustomEvent_Target_5;  // 0x5E10(0x8)
	char pad_24088_1 : 7;  // 0x5E18(0x1)
	bool K2Node_CustomEvent_Start_Look_ : 1;  // 0x5E18(0x1)
	char pad_24089[7];  // 0x5E19(0x7)
	struct UObject* K2Node_CustomEvent_Target_4;  // 0x5E20(0x8)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact_3;  // 0x5E28(0x10)
	char pad_24120_1 : 7;  // 0x5E38(0x1)
	bool K2Node_DynamicCast_bSuccess_63 : 1;  // 0x5E38(0x1)
	char pad_24121[7];  // 0x5E39(0x7)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x5E40(0x8)
	char pad_24136_1 : 7;  // 0x5E48(0x1)
	bool K2Node_DynamicCast_bSuccess_64 : 1;  // 0x5E48(0x1)
	char pad_24137_1 : 7;  // 0x5E49(0x1)
	bool CallFunc_RecieveServerLook_Recieve_ : 1;  // 0x5E49(0x1)
	char pad_24138[2];  // 0x5E4A(0x2)
	int32_t Temp_int_Loop_Counter_Variable_31;  // 0x5E4C(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_18;  // 0x5E50(0x10)
	char pad_24160_1 : 7;  // 0x5E60(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_19 : 1;  // 0x5E60(0x1)
	char pad_24161[3];  // 0x5E61(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_42;  // 0x5E64(0x4)
	struct FKey Temp_struct_Variable_29;  // 0x5E68(0x18)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_19;  // 0x5E80(0x10)
	char pad_24208_1 : 7;  // 0x5E90(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_37 : 1;  // 0x5E90(0x1)
	char pad_24209[7];  // 0x5E91(0x7)
	struct FKey K2Node_InputActionEvent_Key_16;  // 0x5E98(0x18)
	char pad_24240_1 : 7;  // 0x5EB0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_38 : 1;  // 0x5EB0(0x1)
	char pad_24241_1 : 7;  // 0x5EB1(0x1)
	bool K2Node_CustomEvent_Look_ : 1;  // 0x5EB1(0x1)
	char pad_24242[6];  // 0x5EB2(0x6)
	struct UObject* K2Node_CustomEvent_Target_3;  // 0x5EB8(0x8)
	struct AActor* K2Node_DynamicCast_AsActor_2;  // 0x5EC0(0x8)
	char pad_24264_1 : 7;  // 0x5EC8(0x1)
	bool K2Node_DynamicCast_bSuccess_65 : 1;  // 0x5EC8(0x1)
	char pad_24265[7];  // 0x5EC9(0x7)
	struct AActor* K2Node_DynamicCast_AsActor_3;  // 0x5ED0(0x8)
	char pad_24280_1 : 7;  // 0x5ED8(0x1)
	bool K2Node_DynamicCast_bSuccess_66 : 1;  // 0x5ED8(0x1)
	char pad_24281[3];  // 0x5ED9(0x3)
	float CallFunc_Delay_Ping_delay_ping_4;  // 0x5EDC(0x4)
	struct FKey K2Node_InputActionEvent_Key_17;  // 0x5EE0(0x18)
	char pad_24312_1 : 7;  // 0x5EF8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_25 : 1;  // 0x5EF8(0x1)
	char pad_24313_1 : 7;  // 0x5EF9(0x1)
	bool Temp_bool_IsClosed_Variable_25 : 1;  // 0x5EF9(0x1)
	char pad_24314[6];  // 0x5EFA(0x6)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_actor_2;  // 0x5F00(0x8)
	struct FDateTime CallFunc_Now_ReturnValue_36;  // 0x5F08(0x8)
	char pad_24336_1 : 7;  // 0x5F10(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_26 : 1;  // 0x5F10(0x1)
	char pad_24337[7];  // 0x5F11(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x5F18(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x5F20(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x5F28(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x5F30(0x4)
	char pad_24372_1 : 7;  // 0x5F34(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x5F34(0x1)
	char pad_24373[3];  // 0x5F35(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x5F38(0x88)
	char pad_24512_1 : 7;  // 0x5FC0(0x1)
	bool K2Node_CustomEvent_bValue : 1;  // 0x5FC0(0x1)
	char pad_24513[7];  // 0x5FC1(0x7)
	struct UPrimitiveComponent* K2Node_CustomEvent_Target_2;  // 0x5FC8(0x8)
	char pad_24528_1 : 7;  // 0x5FD0(0x1)
	bool CallFunc_IsValid_ReturnValue_48 : 1;  // 0x5FD0(0x1)
	char pad_24529[7];  // 0x5FD1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x5FD8(0x8)
	struct ABP_ItemPickup_C* K2Node_DynamicCast_AsBP_Item_Pickup_3;  // 0x5FE0(0x8)
	char pad_24552_1 : 7;  // 0x5FE8(0x1)
	bool K2Node_DynamicCast_bSuccess_67 : 1;  // 0x5FE8(0x1)
	char pad_24553[7];  // 0x5FE9(0x7)
	struct TScriptInterface<IBPI_Interact_C> CallFunc_OnLook_self_CastInput;  // 0x5FF0(0x10)
	struct TScriptInterface<IBPI_Interact_C> CallFunc_OnStopLook_self_CastInput;  // 0x6000(0x10)
	char pad_24592_1 : 7;  // 0x6010(0x1)
	bool Temp_bool_IsClosed_Variable_26 : 1;  // 0x6010(0x1)
	char pad_24593[7];  // 0x6011(0x7)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x6018(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x6020(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x6028(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x6030(0x4)
	char pad_24628[4];  // 0x6034(0x4)
	struct AController* CallFunc_GetController_ReturnValue_22;  // 0x6038(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_5;  // 0x6040(0x8)
	char pad_24648_1 : 7;  // 0x6048(0x1)
	bool K2Node_DynamicCast_bSuccess_68 : 1;  // 0x6048(0x1)
	char pad_24649[7];  // 0x6049(0x7)
	struct USaveGame* Temp_object_Variable_22;  // 0x6050(0x8)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD_4;  // 0x6058(0x8)
	char pad_24672_1 : 7;  // 0x6060(0x1)
	bool K2Node_DynamicCast_bSuccess_69 : 1;  // 0x6060(0x1)
	char pad_24673[7];  // 0x6061(0x7)
	struct AController* CallFunc_GetController_ReturnValue_23;  // 0x6068(0x8)
	char pad_24688_1 : 7;  // 0x6070(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_39 : 1;  // 0x6070(0x1)
	char pad_24689_1 : 7;  // 0x6071(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_40 : 1;  // 0x6071(0x1)
	char pad_24690_1 : 7;  // 0x6072(0x1)
	bool Temp_bool_Variable_37 : 1;  // 0x6072(0x1)
	char pad_24691[5];  // 0x6073(0x5)
	struct TArray<struct UBaseHUD_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_8;  // 0x6078(0x10)
	struct AController* CallFunc_GetController_ReturnValue_24;  // 0x6088(0x8)
	struct UBaseHUD_C* CallFunc_Array_Get_Item_31;  // 0x6090(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_6;  // 0x6098(0x8)
	char pad_24736_1 : 7;  // 0x60A0(0x1)
	bool K2Node_DynamicCast_bSuccess_70 : 1;  // 0x60A0(0x1)
	char pad_24737[3];  // 0x60A1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_22;  // 0x60A4(0x4)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD_5;  // 0x60A8(0x8)
	char pad_24752_1 : 7;  // 0x60B0(0x1)
	bool K2Node_DynamicCast_bSuccess_71 : 1;  // 0x60B0(0x1)
	char pad_24753_1 : 7;  // 0x60B1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_20 : 1;  // 0x60B1(0x1)
	char pad_24754[6];  // 0x60B2(0x6)
	struct FString K2Node_CustomEvent_Tag_4;  // 0x60B8(0x10)
	char pad_24776_1 : 7;  // 0x60C8(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_15 : 1;  // 0x60C8(0x1)
	char pad_24777_1 : 7;  // 0x60C9(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_16 : 1;  // 0x60C9(0x1)
	char pad_24778[6];  // 0x60CA(0x6)
	struct FString K2Node_CustomEvent_InString;  // 0x60D0(0x10)
	struct FString K2Node_CustomEvent_SubText;  // 0x60E0(0x10)
	struct FString K2Node_CustomEvent_Tag_3;  // 0x60F0(0x10)
	char pad_24832_1 : 7;  // 0x6100(0x1)
	bool CallFunc_BooleanOR_ReturnValue_18 : 1;  // 0x6100(0x1)
	char pad_24833[7];  // 0x6101(0x7)
	struct FText CallFunc_Conv_StringToText_ReturnValue_5;  // 0x6108(0x18)
	struct FText CallFunc_Conv_StringToText_ReturnValue_6;  // 0x6120(0x18)
	struct TArray<struct UchargeBar_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_9;  // 0x6138(0x10)
	struct UchargeBar_C* CallFunc_Array_Get_Item_32;  // 0x6148(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_23;  // 0x6150(0x4)
	char pad_24916_1 : 7;  // 0x6154(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_21 : 1;  // 0x6154(0x1)
	char pad_24917[3];  // 0x6155(0x3)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x6158(0x8)
	char pad_24928_1 : 7;  // 0x6160(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_10 : 1;  // 0x6160(0x1)
	char pad_24929[7];  // 0x6161(0x7)
	struct FString K2Node_CustomEvent_Tag_2;  // 0x6168(0x10)
	char pad_24952_1 : 7;  // 0x6178(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_17 : 1;  // 0x6178(0x1)
	char pad_24953_1 : 7;  // 0x6179(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_18 : 1;  // 0x6179(0x1)
	char pad_24954[2];  // 0x617A(0x2)
	float K2Node_CustomEvent_TimeToCharge;  // 0x617C(0x4)
	struct AActor* K2Node_CustomEvent_Ref;  // 0x6180(0x8)
	struct FString K2Node_CustomEvent_Tag;  // 0x6188(0x10)
	char pad_24984_1 : 7;  // 0x6198(0x1)
	bool CallFunc_BooleanOR_ReturnValue_19 : 1;  // 0x6198(0x1)
	char pad_24985[7];  // 0x6199(0x7)
	struct UchargeBar_C* CallFunc_AddCharge_widget_4;  // 0x61A0(0x8)
	char pad_25000_1 : 7;  // 0x61A8(0x1)
	bool CallFunc_IsValid_ReturnValue_49 : 1;  // 0x61A8(0x1)
	char pad_25001[7];  // 0x61A9(0x7)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact_4;  // 0x61B0(0x10)
	char pad_25024_1 : 7;  // 0x61C0(0x1)
	bool K2Node_DynamicCast_bSuccess_72 : 1;  // 0x61C0(0x1)
	char pad_25025_1 : 7;  // 0x61C1(0x1)
	bool CallFunc_IsValid_ReturnValue_50 : 1;  // 0x61C1(0x1)
	char pad_25026_1 : 7;  // 0x61C2(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_3 : 1;  // 0x61C2(0x1)
	char pad_25027_1 : 7;  // 0x61C3(0x1)
	bool CallFunc_CanThrowHeldProp_ReturnValue : 1;  // 0x61C3(0x1)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_6;  // 0x61C4(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_3;  // 0x61C8(0x4)
	float CallFunc_FMax_ReturnValue;  // 0x61CC(0x4)
	char pad_25040_1 : 7;  // 0x61D0(0x1)
	bool CallFunc_CanThrowHeldProp_ReturnValue_2 : 1;  // 0x61D0(0x1)
	char pad_25041[7];  // 0x61D1(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc_22;  // 0x61D8(0x8)
	char pad_25056_1 : 7;  // 0x61E0(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_11 : 1;  // 0x61E0(0x1)
	char pad_25057_1 : 7;  // 0x61E1(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_12 : 1;  // 0x61E1(0x1)
	char pad_25058[2];  // 0x61E2(0x2)
	float CallFunc_Subtract_FloatFloat_ReturnValue_4;  // 0x61E4(0x4)
	char pad_25064_1 : 7;  // 0x61E8(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_11 : 1;  // 0x61E8(0x1)
	char pad_25065[3];  // 0x61E9(0x3)
	float CallFunc_FClamp_ReturnValue_4;  // 0x61EC(0x4)
	char pad_25072_1 : 7;  // 0x61F0(0x1)
	bool CallFunc_IsValid_ReturnValue_51 : 1;  // 0x61F0(0x1)
	char pad_25073[3];  // 0x61F1(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_22;  // 0x61F4(0xC)
	char pad_25088_1 : 7;  // 0x6200(0x1)
	bool CallFunc_BooleanAND_ReturnValue_48 : 1;  // 0x6200(0x1)
	char pad_25089[3];  // 0x6201(0x3)
	struct FVector CallFunc_GetActorBounds_Origin;  // 0x6204(0xC)
	struct FVector CallFunc_GetActorBounds_BoxExtent;  // 0x6210(0xC)
	float CallFunc_VSize_ReturnValue_3;  // 0x621C(0x4)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_4;  // 0x6220(0x10)
	float CallFunc_Divide_FloatFloat_ReturnValue_22;  // 0x6230(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_9;  // 0x6234(0xC)
	float CallFunc_Divide_FloatFloat_ReturnValue_23;  // 0x6240(0x4)
	float CallFunc_FClamp_ReturnValue_5;  // 0x6244(0x4)
	struct FRotator CallFunc_MakeShootTransform_Rotation;  // 0x6248(0xC)
	struct FVector CallFunc_MakeShootTransform_Location;  // 0x6254(0xC)
	struct USaveGame* K2Node_CustomEvent_SaveGame_8;  // 0x6260(0x8)
	char pad_25192_1 : 7;  // 0x6268(0x1)
	bool K2Node_CustomEvent_bSuccess_8 : 1;  // 0x6268(0x1)
	char pad_25193[3];  // 0x6269(0x3)
	struct FVector CallFunc_GetForwardVector_ReturnValue_14;  // 0x626C(0xC)
	char pad_25208_1 : 7;  // 0x6278(0x1)
	bool K2Node_CustomEvent_Throwing__2 : 1;  // 0x6278(0x1)
	char pad_25209_1 : 7;  // 0x6279(0x1)
	bool K2Node_CustomEvent_Throwing_ : 1;  // 0x6279(0x1)
	char pad_25210[6];  // 0x627A(0x6)
	struct UchargeBar_C* CallFunc_AddCharge_widget_5;  // 0x6280(0x8)
	char pad_25224_1 : 7;  // 0x6288(0x1)
	bool CallFunc_IsValid_ReturnValue_52 : 1;  // 0x6288(0x1)
	char pad_25225[3];  // 0x6289(0x3)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_17;  // 0x628C(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_18;  // 0x6298(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_23;  // 0x62A4(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_19;  // 0x62A8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_13;  // 0x62B4(0xC)
	float CallFunc_FClamp_ReturnValue_6;  // 0x62C0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_24;  // 0x62C4(0x4)
	char pad_25288_1 : 7;  // 0x62C8(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_13 : 1;  // 0x62C8(0x1)
	char pad_25289_1 : 7;  // 0x62C9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_27 : 1;  // 0x62C9(0x1)
	char pad_25290[2];  // 0x62CA(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_20;  // 0x62CC(0x10)
	struct FVector K2Node_CustomEvent_Location_11;  // 0x62DC(0xC)
	struct USoundBase* K2Node_CustomEvent_Sound_6;  // 0x62E8(0x8)
	int32_t K2Node_CustomEvent_ID_6;  // 0x62F0(0x4)
	float K2Node_CustomEvent_VolumeMultiplier_3;  // 0x62F4(0x4)
	float K2Node_CustomEvent_PitchMultiplier_6;  // 0x62F8(0x4)
	char pad_25340[4];  // 0x62FC(0x4)
	struct USoundAttenuation* K2Node_CustomEvent_AttenuationSettings_3;  // 0x6300(0x8)
	struct FVector K2Node_CustomEvent_Location_10;  // 0x6308(0xC)
	char pad_25364[4];  // 0x6314(0x4)
	struct USoundBase* K2Node_CustomEvent_Sound_5;  // 0x6318(0x8)
	int32_t K2Node_CustomEvent_ID_5;  // 0x6320(0x4)
	float K2Node_CustomEvent_VolumeMultiplier_2;  // 0x6324(0x4)
	float K2Node_CustomEvent_PitchMultiplier_5;  // 0x6328(0x4)
	char pad_25388[4];  // 0x632C(0x4)
	struct USoundAttenuation* K2Node_CustomEvent_AttenuationSettings_2;  // 0x6330(0x8)
	char pad_25400_1 : 7;  // 0x6338(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_13 : 1;  // 0x6338(0x1)
	char pad_25401_1 : 7;  // 0x6339(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_14 : 1;  // 0x6339(0x1)
	char pad_25402[2];  // 0x633A(0x2)
	struct FVector K2Node_CustomEvent_Location_9;  // 0x633C(0xC)
	struct USoundBase* K2Node_CustomEvent_Sound_4;  // 0x6348(0x8)
	float K2Node_CustomEvent_VolumeMultiplier;  // 0x6350(0x4)
	float K2Node_CustomEvent_PitchMultiplier_4;  // 0x6354(0x4)
	struct USoundAttenuation* K2Node_CustomEvent_AttenuationSettings;  // 0x6358(0x8)
	char pad_25440_1 : 7;  // 0x6360(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_12 : 1;  // 0x6360(0x1)
	char pad_25441[7];  // 0x6361(0x7)
	struct USoundAttenuation* K2Node_Select_Default_21;  // 0x6368(0x8)
	struct UchargeBar_C* CallFunc_AddCharge_widget_6;  // 0x6370(0x8)
	float Temp_float_Variable_23;  // 0x6378(0x4)
	int32_t K2Node_CustomEvent_Slot_3;  // 0x637C(0x4)
	struct USaveGame* Temp_object_Variable_23;  // 0x6380(0x8)
	struct FST_ItemBase CallFunc_Array_Get_Item_33;  // 0x6388(0x90)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_5;  // 0x6418(0x8)
	char pad_25632_1 : 7;  // 0x6420(0x1)
	bool K2Node_DynamicCast_bSuccess_73 : 1;  // 0x6420(0x1)
	char pad_25633_1 : 7;  // 0x6421(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_11 : 1;  // 0x6421(0x1)
	char pad_25634[6];  // 0x6422(0x6)
	AArmourBP_C* K2Node_ClassDynamicCast_AsArmour_BP;  // 0x6428(0x8)
	char pad_25648_1 : 7;  // 0x6430(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_16 : 1;  // 0x6430(0x1)
	char pad_25649_1 : 7;  // 0x6431(0x1)
	bool CallFunc_ValidateAudioCaptureDeviceName_Valid : 1;  // 0x6431(0x1)
	char pad_25650[6];  // 0x6432(0x6)
	struct FString K2Node_Select_Default_22;  // 0x6438(0x10)
	char pad_25672_1 : 7;  // 0x6448(0x1)
	bool Temp_bool_Variable_38 : 1;  // 0x6448(0x1)
	char pad_25673_1 : 7;  // 0x6449(0x1)
	bool Temp_bool_Variable_39 : 1;  // 0x6449(0x1)
	char pad_25674[6];  // 0x644A(0x6)
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue_2;  // 0x6450(0x8)
	struct AGS_BR_C* K2Node_DynamicCast_AsGS_BR_2;  // 0x6458(0x8)
	char pad_25696_1 : 7;  // 0x6460(0x1)
	bool K2Node_DynamicCast_bSuccess_74 : 1;  // 0x6460(0x1)
	char pad_25697[3];  // 0x6461(0x3)
	float K2Node_Select_Default_23;  // 0x6464(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_25;  // 0x6468(0x4)
	char pad_25708_1 : 7;  // 0x646C(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_12 : 1;  // 0x646C(0x1)
	char pad_25709[3];  // 0x646D(0x3)
	int32_t CallFunc_GetStatInt_Data;  // 0x6470(0x4)
	char pad_25716_1 : 7;  // 0x6474(0x1)
	bool CallFunc_GetStatInt_ReturnValue : 1;  // 0x6474(0x1)
	char pad_25717[3];  // 0x6475(0x3)
	int32_t K2Node_Select_Default_24;  // 0x6478(0x4)
	char pad_25724_1 : 7;  // 0x647C(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_41 : 1;  // 0x647C(0x1)
	char pad_25725[3];  // 0x647D(0x3)
	struct TArray<struct FST_EffectRep> CallFunc_EffectRep_Rep;  // 0x6480(0x10)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0x6490(0x10)
	struct FST_PlayerRepInfo K2Node_CustomEvent_Info;  // 0x64A0(0x38)
	struct FST_PlayerRepInfo K2Node_MakeStruct_ST_PlayerRepInfo;  // 0x64D8(0x38)
	struct FDateTime CallFunc_Now_ReturnValue_37;  // 0x6510(0x8)
	char pad_25880_1 : 7;  // 0x6518(0x1)
	bool Temp_bool_IsClosed_Variable_27 : 1;  // 0x6518(0x1)
	char pad_25881[3];  // 0x6519(0x3)
	float Temp_float_Variable_24;  // 0x651C(0x4)
	char pad_25888_1 : 7;  // 0x6520(0x1)
	bool Temp_bool_Variable_40 : 1;  // 0x6520(0x1)
	char pad_25889_1 : 7;  // 0x6521(0x1)
	bool Temp_bool_Variable_41 : 1;  // 0x6521(0x1)
	char pad_25890[2];  // 0x6522(0x2)
	float K2Node_Select_Default_25;  // 0x6524(0x4)
	float Temp_float_Variable_25;  // 0x6528(0x4)
	char pad_25900[4];  // 0x652C(0x4)
	struct AController* CallFunc_GetController_ReturnValue_25;  // 0x6530(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame_9;  // 0x6538(0x8)
	char pad_25920_1 : 7;  // 0x6540(0x1)
	bool K2Node_CustomEvent_bSuccess_9 : 1;  // 0x6540(0x1)
	char pad_25921[7];  // 0x6541(0x7)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController_7;  // 0x6548(0x8)
	char pad_25936_1 : 7;  // 0x6550(0x1)
	bool K2Node_DynamicCast_bSuccess_75 : 1;  // 0x6550(0x1)
	char pad_25937[7];  // 0x6551(0x7)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD_6;  // 0x6558(0x8)
	char pad_25952_1 : 7;  // 0x6560(0x1)
	bool K2Node_DynamicCast_bSuccess_76 : 1;  // 0x6560(0x1)
	char pad_25953[7];  // 0x6561(0x7)
	struct TArray<struct ABP_Effect_C*> K2Node_CustomEvent_Effects;  // 0x6568(0x10)
	struct ABP_Effect_C* CallFunc_Array_Get_Item_34;  // 0x6578(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_24;  // 0x6580(0x4)
	char pad_25988_1 : 7;  // 0x6584(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_22 : 1;  // 0x6584(0x1)
	char pad_25989[3];  // 0x6585(0x3)
	float K2Node_CustomEvent_IncomingDamageMultiplier;  // 0x6588(0x4)
	char pad_25996_1 : 7;  // 0x658C(0x1)
	bool K2Node_CustomEvent_CanMoveHeavyFurniture : 1;  // 0x658C(0x1)
	char pad_25997[3];  // 0x658D(0x3)
	struct FDateTime CallFunc_Now_ReturnValue_38;  // 0x6590(0x8)
	char pad_26008_1 : 7;  // 0x6598(0x1)
	bool K2Node_CustomEvent_CanMoveFurniture : 1;  // 0x6598(0x1)
	char pad_26009[7];  // 0x6599(0x7)
	struct FDateTime Temp_wildcard_Variable_12;  // 0x65A0(0x8)
	struct ABP_Effect_C* CallFunc_Array_Get_Item_35;  // 0x65A8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_25;  // 0x65B0(0x4)
	char pad_26036_1 : 7;  // 0x65B4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_23 : 1;  // 0x65B4(0x1)
	char pad_26037[3];  // 0x65B5(0x3)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_13;  // 0x65B8(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_13;  // 0x65C0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_24;  // 0x65C4(0x4)
	char pad_26056_1 : 7;  // 0x65C8(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_23 : 1;  // 0x65C8(0x1)
	char pad_26057[7];  // 0x65C9(0x7)
	struct FTransform CallFunc_MakeTransform_ReturnValue_3;  // 0x65D0(0x30)
	struct FST_Effect K2Node_CustomEvent_Effect;  // 0x6600(0x38)
	float K2Node_CustomEvent_New_Scale;  // 0x6638(0x4)
	char pad_26172[4];  // 0x663C(0x4)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Caster;  // 0x6640(0x8)
	struct FString K2Node_CustomEvent_Name_2;  // 0x6648(0x10)
	char pad_26200_1 : 7;  // 0x6658(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_19 : 1;  // 0x6658(0x1)
	char pad_26201[7];  // 0x6659(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_12;  // 0x6660(0x8)
	struct ABP_Effect_C* CallFunc_Array_Get_Item_36;  // 0x6668(0x8)
	char pad_26224_1 : 7;  // 0x6670(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x6670(0x1)
	char pad_26225_1 : 7;  // 0x6671(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_19 : 1;  // 0x6671(0x1)
	char pad_26226[6];  // 0x6672(0x6)
	struct ABP_Effect_C* CallFunc_FinishSpawningActor_ReturnValue_12;  // 0x6678(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_26;  // 0x6680(0x4)
	char pad_26244_1 : 7;  // 0x6684(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_24 : 1;  // 0x6684(0x1)
	char pad_26245[3];  // 0x6685(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0x6688(0x4)
	char pad_26252_1 : 7;  // 0x668C(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_20 : 1;  // 0x668C(0x1)
	char pad_26253[3];  // 0x668D(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_21;  // 0x6690(0x10)
	char pad_26272_1 : 7;  // 0x66A0(0x1)
	bool CallFunc_IsFalling_ReturnValue_4 : 1;  // 0x66A0(0x1)
	char pad_26273_1 : 7;  // 0x66A1(0x1)
	bool K2Node_CustomEvent_Crouched_2 : 1;  // 0x66A1(0x1)
	char pad_26274_1 : 7;  // 0x66A2(0x1)
	bool K2Node_CustomEvent_Crouch : 1;  // 0x66A2(0x1)
	char pad_26275[1];  // 0x66A3(0x1)
	float K2Node_Select_Default_26;  // 0x66A4(0x4)
	char pad_26280_1 : 7;  // 0x66A8(0x1)
	bool K2Node_CustomEvent_Crouched : 1;  // 0x66A8(0x1)
	char pad_26281_1 : 7;  // 0x66A9(0x1)
	bool Temp_bool_Variable_42 : 1;  // 0x66A9(0x1)
	char pad_26282[6];  // 0x66AA(0x6)
	struct APlayerBRController_C* CallFunc_PC_pc_23;  // 0x66B0(0x8)
	float K2Node_Select_Default_27;  // 0x66B8(0x4)
	float K2Node_Select_Default_28;  // 0x66BC(0x4)
	char pad_26304_1 : 7;  // 0x66C0(0x1)
	bool CallFunc_CanDoStuff___2 : 1;  // 0x66C0(0x1)
	char pad_26305[3];  // 0x66C1(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_26;  // 0x66C4(0x4)
	char pad_26312_1 : 7;  // 0x66C8(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_28 : 1;  // 0x66C8(0x1)
	char pad_26313[3];  // 0x66C9(0x3)
	float CallFunc_SelectFloat_ReturnValue_3;  // 0x66CC(0x4)
	float CallFunc_SelectFloat_ReturnValue_4;  // 0x66D0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_27;  // 0x66D4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_5;  // 0x66D8(0x4)
	char pad_26332_1 : 7;  // 0x66DC(0x1)
	bool CallFunc_IsValid_ReturnValue_53 : 1;  // 0x66DC(0x1)
	char pad_26333[3];  // 0x66DD(0x3)
	float CallFunc_FClamp_ReturnValue_7;  // 0x66E0(0x4)
	char pad_26340_1 : 7;  // 0x66E4(0x1)
	bool CallFunc_IsValid_ReturnValue_54 : 1;  // 0x66E4(0x1)
	char pad_26341[3];  // 0x66E5(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_10;  // 0x66E8(0xC)
	float CallFunc_Delay_Ping_delay_ping_5;  // 0x66F4(0x4)
	int32_t K2Node_CustomEvent_NewSlot_2;  // 0x66F8(0x4)
	char pad_26364_1 : 7;  // 0x66FC(0x1)
	bool Temp_bool_IsClosed_Variable_28 : 1;  // 0x66FC(0x1)
	char pad_26365_1 : 7;  // 0x66FD(0x1)
	bool CallFunc_ItemEquipped_bool : 1;  // 0x66FD(0x1)
	char pad_26366_1 : 7;  // 0x66FE(0x1)
	bool CallFunc_BooleanAND_ReturnValue_49 : 1;  // 0x66FE(0x1)
	char pad_26367[1];  // 0x66FF(0x1)
	struct FVector CallFunc_GetForwardVector_ReturnValue_15;  // 0x6700(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_20;  // 0x670C(0xC)
	struct UchargeBar_C* CallFunc_AddCharge_widget_7;  // 0x6718(0x8)
	struct APlayerBRController_C* CallFunc_PC_pc_24;  // 0x6720(0x8)
	char pad_26408_1 : 7;  // 0x6728(0x1)
	bool CallFunc_IsValid_ReturnValue_55 : 1;  // 0x6728(0x1)
	char pad_26409[3];  // 0x6729(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_28;  // 0x672C(0x4)
	char pad_26416_1 : 7;  // 0x6730(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_42 : 1;  // 0x6730(0x1)
	char pad_26417_1 : 7;  // 0x6731(0x1)
	bool CallFunc_BooleanAND_ReturnValue_50 : 1;  // 0x6731(0x1)
	char pad_26418[2];  // 0x6732(0x2)
	float K2Node_CustomEvent_Clipping_Distance;  // 0x6734(0x4)
	char pad_26424_1 : 7;  // 0x6738(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_14 : 1;  // 0x6738(0x1)
	char pad_26425[3];  // 0x6739(0x3)
	float CallFunc_Subtract_FloatFloat_ReturnValue_5;  // 0x673C(0x4)
	float CallFunc_FClamp_ReturnValue_8;  // 0x6740(0x4)
	char pad_26436_1 : 7;  // 0x6744(0x1)
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // 0x6744(0x1)
	char pad_26437[3];  // 0x6745(0x3)
	int32_t Temp_int_Array_Index_Variable_32;  // 0x6748(0x4)
	char pad_26444_1 : 7;  // 0x674C(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_29 : 1;  // 0x674C(0x1)
	char pad_26445[3];  // 0x674D(0x3)
	struct ABP_Effect_C* CallFunc_Array_Get_Item_37;  // 0x6750(0x8)
	struct ABP_Effect_Vampire_C* K2Node_DynamicCast_AsBP_Effect_Vampire;  // 0x6758(0x8)
	char pad_26464_1 : 7;  // 0x6760(0x1)
	bool K2Node_DynamicCast_bSuccess_77 : 1;  // 0x6760(0x1)
	char pad_26465[7];  // 0x6761(0x7)
	struct TArray<struct FST_RepCosmetic> K2Node_CustomEvent_SourceArray;  // 0x6768(0x10)
	struct USaveGame* Temp_object_Variable_24;  // 0x6778(0x8)
	char pad_26496_1 : 7;  // 0x6780(0x1)
	bool Temp_bool_Variable_43 : 1;  // 0x6780(0x1)
	char pad_26497[7];  // 0x6781(0x7)
	struct FKey Temp_struct_Variable_30;  // 0x6788(0x18)
	float CallFunc_Add_FloatFloat_ReturnValue_6;  // 0x67A0(0x4)
	char pad_26532[4];  // 0x67A4(0x4)
	struct FKey K2Node_InputActionEvent_Key_18;  // 0x67A8(0x18)
	float CallFunc_FClamp_ReturnValue_9;  // 0x67C0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_27;  // 0x67C4(0x4)
	char pad_26568_1 : 7;  // 0x67C8(0x1)
	bool Temp_bool_IsClosed_Variable_29 : 1;  // 0x67C8(0x1)
	char pad_26569[3];  // 0x67C9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_28;  // 0x67CC(0x4)
	char pad_26576_1 : 7;  // 0x67D0(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue_3 : 1;  // 0x67D0(0x1)
	char pad_26577[7];  // 0x67D1(0x7)
	struct FKey K2Node_InputActionEvent_Key_19;  // 0x67D8(0x18)
	struct AActor* K2Node_CustomEvent_actor;  // 0x67F0(0x8)
	float Temp_float_Variable_26;  // 0x67F8(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_11;  // 0x67FC(0xC)
	struct ABP_ItemPickup_C* K2Node_CustomEvent_Pickup_2;  // 0x6808(0x8)
	UC_Upgrade_C* K2Node_CustomEvent_upgrade_3;  // 0x6810(0x8)
	int32_t K2Node_CustomEvent_Slot_2;  // 0x6818(0x4)
	char pad_26652_1 : 7;  // 0x681C(0x1)
	bool CallFunc_IsValid_ReturnValue_56 : 1;  // 0x681C(0x1)
	char pad_26653_1 : 7;  // 0x681D(0x1)
	bool CallFunc_IsPendingKill_ReturnValue_3 : 1;  // 0x681D(0x1)
	char pad_26654_1 : 7;  // 0x681E(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_35 : 1;  // 0x681E(0x1)
	char pad_26655_1 : 7;  // 0x681F(0x1)
	bool CallFunc_CanPickup_CanPickUp_2 : 1;  // 0x681F(0x1)
	char pad_26656_1 : 7;  // 0x6820(0x1)
	bool CallFunc_BooleanAND_ReturnValue_51 : 1;  // 0x6820(0x1)
	char pad_26657[7];  // 0x6821(0x7)
	struct TArray<UC_Upgrade_C*> K2Node_CustomEvent_Array_3;  // 0x6828(0x10)
	char pad_26680_1 : 7;  // 0x6838(0x1)
	bool Temp_bool_Variable_44 : 1;  // 0x6838(0x1)
	char pad_26681[3];  // 0x6839(0x3)
	float K2Node_Select_Default_29;  // 0x683C(0x4)
	float CallFunc_SelectFloat_ReturnValue_5;  // 0x6840(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_29;  // 0x6844(0x4)
	char pad_26696_1 : 7;  // 0x6848(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_25 : 1;  // 0x6848(0x1)
	char pad_26697[7];  // 0x6849(0x7)
	struct UchargeBar_C* CallFunc_AddCharge_widget_8;  // 0x6850(0x8)
	UC_Upgrade_C* K2Node_CustomEvent_upgrade_2;  // 0x6858(0x8)
	int32_t K2Node_CustomEvent_Slot;  // 0x6860(0x4)
	char pad_26724[4];  // 0x6864(0x4)
	UC_Upgrade_C* K2Node_CustomEvent_upgrade;  // 0x6868(0x8)
	struct ABP_ItemPickup_C* K2Node_CustomEvent_Pickup;  // 0x6870(0x8)
	char pad_26744_1 : 7;  // 0x6878(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_13 : 1;  // 0x6878(0x1)
	char pad_26745_1 : 7;  // 0x6879(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_14 : 1;  // 0x6879(0x1)
	char pad_26746_1 : 7;  // 0x687A(0x1)
	bool CallFunc_BooleanAND_ReturnValue_52 : 1;  // 0x687A(0x1)
	char pad_26747_1 : 7;  // 0x687B(0x1)
	bool CallFunc_IsValid_ReturnValue_57 : 1;  // 0x687B(0x1)
	char pad_26748_1 : 7;  // 0x687C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_53 : 1;  // 0x687C(0x1)
	char pad_26749_1 : 7;  // 0x687D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_54 : 1;  // 0x687D(0x1)
	char pad_26750_1 : 7;  // 0x687E(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_13 : 1;  // 0x687E(0x1)
	char pad_26751_1 : 7;  // 0x687F(0x1)
	bool CallFunc_BooleanAND_ReturnValue_55 : 1;  // 0x687F(0x1)
	int32_t CallFunc_Array_Add_ReturnValue_4;  // 0x6880(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_30;  // 0x6884(0x4)
	char pad_26760_1 : 7;  // 0x6888(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_26 : 1;  // 0x6888(0x1)
	char pad_26761[7];  // 0x6889(0x7)
	struct USaveGame* K2Node_CustomEvent_SaveGame_10;  // 0x6890(0x8)
	char pad_26776_1 : 7;  // 0x6898(0x1)
	bool K2Node_CustomEvent_bSuccess_10 : 1;  // 0x6898(0x1)
	char pad_26777[7];  // 0x6899(0x7)
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> K2Node_MakeArray_Array_5;  // 0x68A0(0x10)
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> K2Node_MakeArray_Array_6;  // 0x68B0(0x10)
	struct FST_RepCosmetic K2Node_MakeStruct_ST_RepCosmetic;  // 0x68C0(0x38)
	struct FST_RepCosmetic K2Node_MakeStruct_ST_RepCosmetic_2;  // 0x68F8(0x38)
	struct TArray<struct FST_RepCosmetic> K2Node_MakeArray_Array_7;  // 0x6930(0x10)
	char pad_26944_1 : 7;  // 0x6940(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_20 : 1;  // 0x6940(0x1)
	char pad_26945[3];  // 0x6941(0x3)
	int32_t Temp_int_Loop_Counter_Variable_32;  // 0x6944(0x4)
	char pad_26952_1 : 7;  // 0x6948(0x1)
	bool CallFunc_IsSteamAvailable_ReturnValue : 1;  // 0x6948(0x1)
	char pad_26953_1 : 7;  // 0x6949(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_27 : 1;  // 0x6949(0x1)
	char pad_26954[2];  // 0x694A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_43;  // 0x694C(0x4)
	struct TSoftObjectPtr<USkeletalMesh> K2Node_CustomEvent_Mesh;  // 0x6950(0x28)
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> K2Node_CustomEvent_Materials;  // 0x6978(0x10)
	char pad_27016_1 : 7;  // 0x6988(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_43 : 1;  // 0x6988(0x1)
	char pad_27017[7];  // 0x6989(0x7)
	struct TSoftObjectPtr<UMaterialInterface> CallFunc_Array_Get_Item_38;  // 0x6990(0x28)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue;  // 0x69B8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_31;  // 0x69C0(0x4)
	char pad_27076[4];  // 0x69C4(0x4)
	struct UMaterialInterface* K2Node_DynamicCast_AsMaterial_Interface_2;  // 0x69C8(0x8)
	char pad_27088_1 : 7;  // 0x69D0(0x1)
	bool K2Node_DynamicCast_bSuccess_78 : 1;  // 0x69D0(0x1)
	char pad_27089_1 : 7;  // 0x69D1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_28 : 1;  // 0x69D1(0x1)
	char pad_27090[6];  // 0x69D2(0x6)
	struct UObject* CallFunc_LoadAsset_Blocking_ReturnValue_2;  // 0x69D8(0x8)
	struct USkeletalMesh* K2Node_DynamicCast_AsSkeletal_Mesh;  // 0x69E0(0x8)
	char pad_27112_1 : 7;  // 0x69E8(0x1)
	bool K2Node_DynamicCast_bSuccess_79 : 1;  // 0x69E8(0x1)
	char pad_27113_1 : 7;  // 0x69E9(0x1)
	bool CallFunc_Should_Hide_Cosmetic_hide_ : 1;  // 0x69E9(0x1)
	char pad_27114[6];  // 0x69EA(0x6)
	struct FDateTime Temp_wildcard_Variable_13;  // 0x69F0(0x8)
	char pad_27128_1 : 7;  // 0x69F8(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_44 : 1;  // 0x69F8(0x1)
	char pad_27129[7];  // 0x69F9(0x7)
	struct TArray<struct USceneComponent*> CallFunc_GetChildrenComponents_Children_2;  // 0x6A00(0x10)
	struct USceneComponent* CallFunc_Array_Get_Item_39;  // 0x6A10(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_32;  // 0x6A18(0x4)
	char pad_27164[4];  // 0x6A1C(0x4)
	struct USkeletalMeshComponent* K2Node_DynamicCast_AsSkeletal_Mesh_Component;  // 0x6A20(0x8)
	char pad_27176_1 : 7;  // 0x6A28(0x1)
	bool K2Node_DynamicCast_bSuccess_80 : 1;  // 0x6A28(0x1)
	char pad_27177_1 : 7;  // 0x6A29(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_29 : 1;  // 0x6A29(0x1)
	char pad_27178[6];  // 0x6A2A(0x6)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x6A30(0x8)
	struct TSoftObjectPtr<UMaterialInterface> CallFunc_Conv_ObjectToSoftObjectReference_ReturnValue;  // 0x6A38(0x28)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue_2;  // 0x6A60(0x8)
	struct TSoftObjectPtr<UMaterialInterface> CallFunc_Conv_ObjectToSoftObjectReference_ReturnValue_2;  // 0x6A68(0x28)
	struct TSoftObjectPtr<USkeletalMesh> CallFunc_Conv_ObjectToSoftObjectReference_ReturnValue_3;  // 0x6A90(0x28)
	char pad_27320_1 : 7;  // 0x6AB8(0x1)
	bool CallFunc_HasAuthority_ReturnValue_18 : 1;  // 0x6AB8(0x1)
	char pad_27321_1 : 7;  // 0x6AB9(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_5 : 1;  // 0x6AB9(0x1)
	char pad_27322[6];  // 0x6ABA(0x6)
	struct USkeletalMesh* K2Node_CustomEvent_NewMesh_2;  // 0x6AC0(0x8)
	char pad_27336_1 : 7;  // 0x6AC8(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_6 : 1;  // 0x6AC8(0x1)
	char pad_27337[7];  // 0x6AC9(0x7)
	struct USkeletalMesh* K2Node_CustomEvent_NewMesh;  // 0x6AD0(0x8)
	struct TArray<struct FST_RepCosmetic> K2Node_CustomEvent_Clothes;  // 0x6AD8(0x10)
	struct FST_RepCosmetic CallFunc_Array_Get_Item_40;  // 0x6AE8(0x38)
	int32_t CallFunc_Array_Length_ReturnValue_33;  // 0x6B20(0x4)
	char pad_27428_1 : 7;  // 0x6B24(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_30 : 1;  // 0x6B24(0x1)
	char pad_27429[3];  // 0x6B25(0x3)
	struct TSoftObjectPtr<UMaterialInterface> CallFunc_Array_Get_Item_41;  // 0x6B28(0x28)
	char pad_27472_1 : 7;  // 0x6B50(0x1)
	bool CallFunc_EqualEqual_SoftObjectReference_ReturnValue : 1;  // 0x6B50(0x1)
	char pad_27473[7];  // 0x6B51(0x7)
	struct TSoftObjectPtr<UMaterialInterface> CallFunc_Array_Get_Item_42;  // 0x6B58(0x28)
	int32_t CallFunc_Array_Length_ReturnValue_34;  // 0x6B80(0x4)
	char pad_27524_1 : 7;  // 0x6B84(0x1)
	bool CallFunc_EqualEqual_SoftObjectReference_ReturnValue_2 : 1;  // 0x6B84(0x1)
	char pad_27525_1 : 7;  // 0x6B85(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_15 : 1;  // 0x6B85(0x1)
	char pad_27526_1 : 7;  // 0x6B86(0x1)
	bool CallFunc_BooleanAND_ReturnValue_56 : 1;  // 0x6B86(0x1)
	char pad_27527_1 : 7;  // 0x6B87(0x1)
	bool CallFunc_BooleanOR_ReturnValue_20 : 1;  // 0x6B87(0x1)
	char pad_27528_1 : 7;  // 0x6B88(0x1)
	bool CallFunc_EqualEqual_SoftObjectReference_ReturnValue_3 : 1;  // 0x6B88(0x1)
	char pad_27529_1 : 7;  // 0x6B89(0x1)
	bool CallFunc_BooleanAND_ReturnValue_57 : 1;  // 0x6B89(0x1)
	char pad_27530[6];  // 0x6B8A(0x6)
	struct FDateTime CallFunc_Now_ReturnValue_39;  // 0x6B90(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_22;  // 0x6B98(0x10)
	struct UStaticMeshComponent* CallFunc_Array_Get_Item_43;  // 0x6BA8(0x8)
	int32_t CallFunc_Array_Add_ReturnValue_5;  // 0x6BB0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_35;  // 0x6BB4(0x4)
	struct TArray<struct FST_AttachedMesh> K2Node_CustomEvent_Array_2;  // 0x6BB8(0x10)
	char pad_27592_1 : 7;  // 0x6BC8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_31 : 1;  // 0x6BC8(0x1)
	char pad_27593[7];  // 0x6BC9(0x7)
	struct FST_AttachedMesh CallFunc_Array_Get_Item_44;  // 0x6BD0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_36;  // 0x6BE0(0x4)
	char pad_27620_1 : 7;  // 0x6BE4(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x6BE4(0x1)
	char pad_27621_1 : 7;  // 0x6BE5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_32 : 1;  // 0x6BE5(0x1)
	char pad_27622_1 : 7;  // 0x6BE6(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_7 : 1;  // 0x6BE6(0x1)
	char pad_27623[1];  // 0x6BE7(0x1)
	int32_t K2Node_CustomEvent_NewSlot;  // 0x6BE8(0x4)
	char pad_27628[4];  // 0x6BEC(0x4)
	struct USaveGame* Temp_object_Variable_25;  // 0x6BF0(0x8)
	struct TArray<struct FST_AttachedMesh> CallFunc_GetAttachSlots_meshes;  // 0x6BF8(0x10)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save_6;  // 0x6C08(0x8)
	char pad_27664_1 : 7;  // 0x6C10(0x1)
	bool K2Node_DynamicCast_bSuccess_81 : 1;  // 0x6C10(0x1)
	char pad_27665_1 : 7;  // 0x6C11(0x1)
	bool CallFunc_IsDev_Value : 1;  // 0x6C11(0x1)
	char pad_27666[6];  // 0x6C12(0x6)
	struct TArray<struct FST_Cosmetic> CallFunc_SteamIDsToCosmetics_Cosmetics;  // 0x6C18(0x10)
	char pad_27688_1 : 7;  // 0x6C28(0x1)
	bool Temp_bool_Variable_45 : 1;  // 0x6C28(0x1)
	char pad_27689[7];  // 0x6C29(0x7)
	struct TArray<struct FST_RepCosmetic> CallFunc_CosmeticsToRep_Meshes_2;  // 0x6C30(0x10)
	char pad_27712_1 : 7;  // 0x6C40(0x1)
	bool CallFunc_VerifyChosenCosmetics_Verified : 1;  // 0x6C40(0x1)
	char pad_27713[7];  // 0x6C41(0x7)
	struct USaveGame* K2Node_CustomEvent_SaveGame_11;  // 0x6C48(0x8)
	char pad_27728_1 : 7;  // 0x6C50(0x1)
	bool K2Node_CustomEvent_bSuccess_11 : 1;  // 0x6C50(0x1)
	char pad_27729[3];  // 0x6C51(0x3)
	struct FVector CallFunc_GetForwardVector_ReturnValue_16;  // 0x6C54(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_23;  // 0x6C60(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_21;  // 0x6C6C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_14;  // 0x6C78(0xC)
	char pad_27780[4];  // 0x6C84(0x4)
	struct FString K2Node_CustomEvent_Name;  // 0x6C88(0x10)
	struct APawn* CallFunc_SpawnAIFromClass_ReturnValue;  // 0x6C98(0x8)
	char pad_27808_1 : 7;  // 0x6CA0(0x1)
	bool K2Node_SwitchString_CmpSuccess : 1;  // 0x6CA0(0x1)
	char pad_27809[7];  // 0x6CA1(0x7)
	struct FST_ItemBase CallFunc_GetItem_Item_5;  // 0x6CA8(0x90)
	char pad_27960[8];  // 0x6D38(0x8)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_8;  // 0x6D40(0x30)
	char pad_28016_1 : 7;  // 0x6D70(0x1)
	bool CallFunc_BIsSubscribed_ReturnValue : 1;  // 0x6D70(0x1)
	char pad_28017[7];  // 0x6D71(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_13;  // 0x6D78(0x8)
	char pad_28032_1 : 7;  // 0x6D80(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_36 : 1;  // 0x6D80(0x1)
	char pad_28033[7];  // 0x6D81(0x7)
	struct ABP_Trampoline_C* CallFunc_FinishSpawningActor_ReturnValue_13;  // 0x6D88(0x8)
	char pad_28048_1 : 7;  // 0x6D90(0x1)
	bool CallFunc_BooleanOR_ReturnValue_21 : 1;  // 0x6D90(0x1)
	char pad_28049[7];  // 0x6D91(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_14;  // 0x6D98(0x8)
	struct AItemsCrate_C* CallFunc_FinishSpawningActor_ReturnValue_14;  // 0x6DA0(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_15;  // 0x6DA8(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_16;  // 0x6DB0(0x8)
	struct AFirstPersonCharacter_C* CallFunc_FinishSpawningActor_ReturnValue_15;  // 0x6DB8(0x8)
	struct AExplosiveBarrel_C* CallFunc_FinishSpawningActor_ReturnValue_16;  // 0x6DC0(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_17;  // 0x6DC8(0x8)
	struct ABP_ItemPickup_C* CallFunc_FinishSpawningActor_ReturnValue_17;  // 0x6DD0(0x8)
	struct AController* CallFunc_GetController_ReturnValue_26;  // 0x6DD8(0x8)
	struct AController* CallFunc_GetController_ReturnValue_27;  // 0x6DE0(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_17;  // 0x6DE8(0x8)
	char pad_28144_1 : 7;  // 0x6DF0(0x1)
	bool K2Node_DynamicCast_bSuccess_82 : 1;  // 0x6DF0(0x1)
	char pad_28145[7];  // 0x6DF1(0x7)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_18;  // 0x6DF8(0x8)
	char pad_28160_1 : 7;  // 0x6E00(0x1)
	bool K2Node_DynamicCast_bSuccess_83 : 1;  // 0x6E00(0x1)
	char pad_28161[7];  // 0x6E01(0x7)
	struct UDevMenu_C* CallFunc_Create_ReturnValue_6;  // 0x6E08(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_23;  // 0x6E10(0x10)
	struct TArray<struct APathSpline_C*> CallFunc_GetAllActorsOfClass_OutActors_2;  // 0x6E20(0x10)
	struct APathSpline_C* CallFunc_Array_Get_Item_45;  // 0x6E30(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_37;  // 0x6E38(0x4)
	char pad_28220_1 : 7;  // 0x6E3C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_33 : 1;  // 0x6E3C(0x1)
	char pad_28221[3];  // 0x6E3D(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_7;  // 0x6E40(0x4)
	char pad_28228[4];  // 0x6E44(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_8;  // 0x6E48(0x10)
	struct FVector CallFunc_GetForwardVector_ReturnValue_17;  // 0x6E58(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_24;  // 0x6E64(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_15;  // 0x6E70(0xC)
	float K2Node_CustomEvent_Velocity;  // 0x6E7C(0x4)
	struct AActor* K2Node_CustomEvent_Ignore;  // 0x6E80(0x8)
	float K2Node_CustomEvent_OverrideGravityZ;  // 0x6E88(0x4)
	char pad_28300[4];  // 0x6E8C(0x4)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue_9;  // 0x6E90(0x30)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_9;  // 0x6EC0(0x10)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_18;  // 0x6ED0(0x8)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_22;  // 0x6ED8(0xC)
	char pad_28388[4];  // 0x6EE4(0x4)
	struct APathSpline_C* CallFunc_FinishSpawningActor_ReturnValue_18;  // 0x6EE8(0x8)
	struct FHitResult CallFunc_Blueprint_PredictProjectilePath_ByObjectType_OutHit;  // 0x6EF0(0x88)
	struct TArray<struct FVector> CallFunc_Blueprint_PredictProjectilePath_ByObjectType_OutPathPositions;  // 0x6F78(0x10)
	struct FVector CallFunc_Blueprint_PredictProjectilePath_ByObjectType_OutLastTraceDestination;  // 0x6F88(0xC)
	char pad_28564_1 : 7;  // 0x6F94(0x1)
	bool CallFunc_Blueprint_PredictProjectilePath_ByObjectType_ReturnValue : 1;  // 0x6F94(0x1)
	char pad_28565_1 : 7;  // 0x6F95(0x1)
	bool CallFunc_IsValid_ReturnValue_58 : 1;  // 0x6F95(0x1)
	char pad_28566[2];  // 0x6F96(0x2)
	struct TArray<struct APawn*> CallFunc_GetAllPawnsFromState_ReturnValue;  // 0x6F98(0x10)
	struct APawn* CallFunc_Array_Get_Item_46;  // 0x6FA8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_38;  // 0x6FB0(0x4)
	char pad_28596[4];  // 0x6FB4(0x4)
	struct ASpectatorPawn_C* K2Node_DynamicCast_AsSpectator_Pawn;  // 0x6FB8(0x8)
	char pad_28608_1 : 7;  // 0x6FC0(0x1)
	bool K2Node_DynamicCast_bSuccess_84 : 1;  // 0x6FC0(0x1)
	char pad_28609_1 : 7;  // 0x6FC1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_34 : 1;  // 0x6FC1(0x1)
	char pad_28610[6];  // 0x6FC2(0x6)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_5;  // 0x6FC8(0x8)
	char pad_28624_1 : 7;  // 0x6FD0(0x1)
	bool K2Node_DynamicCast_bSuccess_85 : 1;  // 0x6FD0(0x1)
	char pad_28625[7];  // 0x6FD1(0x7)
	struct UVoipAudioComponent* CallFunc_GetComponentByClass_ReturnValue;  // 0x6FD8(0x8)
	char pad_28640_1 : 7;  // 0x6FE0(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_15 : 1;  // 0x6FE0(0x1)
	char pad_28641_1 : 7;  // 0x6FE1(0x1)
	bool CallFunc_IsValid_ReturnValue_59 : 1;  // 0x6FE1(0x1)
	char pad_28642[6];  // 0x6FE2(0x6)
	struct TArray<struct APawn*> CallFunc_GetAllPawnsFromState_ReturnValue_2;  // 0x6FE8(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_39;  // 0x6FF8(0x4)
	char pad_28668[4];  // 0x6FFC(0x4)
	struct TArray<char> K2Node_CustomEvent_CompressedVoiceData_2;  // 0x7000(0x10)
	struct AActor* K2Node_CustomEvent_Target;  // 0x7010(0x8)
	char pad_28696_1 : 7;  // 0x7018(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_10 : 1;  // 0x7018(0x1)
	char pad_28697[7];  // 0x7019(0x7)
	struct UVoipAudioComponent* CallFunc_GetComponentByClass_ReturnValue_2;  // 0x7020(0x8)
	struct TArray<char> K2Node_CustomEvent_CompressedVoiceData;  // 0x7028(0x10)
	struct TArray<char> K2Node_ComponentBoundEvent_VoiceData;  // 0x7038(0x10)
	float K2Node_ComponentBoundEvent_MicLevel;  // 0x7048(0x4)
	char pad_28748[4];  // 0x704C(0x4)
	struct AController* CallFunc_GetController_ReturnValue_28;  // 0x7050(0x8)
	char pad_28760_1 : 7;  // 0x7058(0x1)
	bool CallFunc_InitVoice_ReturnValue : 1;  // 0x7058(0x1)
	char pad_28761[7];  // 0x7059(0x7)
	struct FST_ItemBase CallFunc_Array_Get_Item_47;  // 0x7060(0x90)
	float CallFunc_VSize_ReturnValue_4;  // 0x70F0(0x4)
	char pad_28916_1 : 7;  // 0x70F4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_14 : 1;  // 0x70F4(0x1)
	char pad_28917[3];  // 0x70F5(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_29;  // 0x70F8(0x4)
	char pad_28924_1 : 7;  // 0x70FC(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_15 : 1;  // 0x70FC(0x1)
	char pad_28925[3];  // 0x70FD(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_30;  // 0x7100(0x4)
	char pad_28932_1 : 7;  // 0x7104(0x1)
	bool CallFunc_BooleanOR_ReturnValue_22 : 1;  // 0x7104(0x1)
	char pad_28933[3];  // 0x7105(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_7;  // 0x7108(0x4)
	float K2Node_Select_Default_30;  // 0x710C(0x4)
	float CallFunc_FClamp_ReturnValue_10;  // 0x7110(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_8;  // 0x7114(0x4)
	float CallFunc_FClamp_ReturnValue_11;  // 0x7118(0x4)
	char pad_28956[4];  // 0x711C(0x4)
	struct FWeightedBlendable K2Node_MakeStruct_WeightedBlendable;  // 0x7120(0x10)
	char pad_28976_1 : 7;  // 0x7130(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_30 : 1;  // 0x7130(0x1)
	char pad_28977[7];  // 0x7131(0x7)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x7138(0x8)
	char pad_28992_1 : 7;  // 0x7140(0x1)
	bool CallFunc_IsValid_ReturnValue_60 : 1;  // 0x7140(0x1)
	char pad_28993[7];  // 0x7141(0x7)
	struct FWeightedBlendable K2Node_MakeStruct_WeightedBlendable_2;  // 0x7148(0x10)
	struct TArray<struct FWeightedBlendable> K2Node_MakeArray_Array_10;  // 0x7158(0x10)
	struct FWeightedBlendables K2Node_MakeStruct_WeightedBlendables;  // 0x7168(0x10)
	APouch_bp_C* K2Node_ClassDynamicCast_AsPouch_Bp;  // 0x7178(0x8)
	char pad_29056_1 : 7;  // 0x7180(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_17 : 1;  // 0x7180(0x1)
	char pad_29057[7];  // 0x7181(0x7)
	ABackpack_BP_C* K2Node_ClassDynamicCast_AsBackpack_BP;  // 0x7188(0x8)
	char pad_29072_1 : 7;  // 0x7190(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_18 : 1;  // 0x7190(0x1)
	char pad_29073[3];  // 0x7191(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_6;  // 0x7194(0x4)
	char pad_29080_1 : 7;  // 0x7198(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_2 : 1;  // 0x7198(0x1)
	char pad_29081[3];  // 0x7199(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_7;  // 0x719C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_8;  // 0x71A0(0x4)
	char pad_29092_1 : 7;  // 0x71A4(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue_8 : 1;  // 0x71A4(0x1)
	char pad_29093_1 : 7;  // 0x71A5(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_3 : 1;  // 0x71A5(0x1)
	char pad_29094_1 : 7;  // 0x71A6(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue_4 : 1;  // 0x71A6(0x1)
	char pad_29095[9];  // 0x71A7(0x9)
	struct FTransform K2Node_CustomEvent_SpawnTransform;  // 0x71B0(0x30)
	float K2Node_CustomEvent_timeToGrow;  // 0x71E0(0x4)
	float K2Node_CustomEvent_Time_3;  // 0x71E4(0x4)
	float K2Node_CustomEvent_TargetSize;  // 0x71E8(0x4)
	char pad_29164_1 : 7;  // 0x71EC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_21 : 1;  // 0x71EC(0x1)
	char pad_29165[3];  // 0x71ED(0x3)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_19;  // 0x71F0(0x8)
	struct ADarkZone_C* CallFunc_FinishSpawningActor_ReturnValue_19;  // 0x71F8(0x8)
	char pad_29184_1 : 7;  // 0x7200(0x1)
	bool Temp_bool_Variable_46 : 1;  // 0x7200(0x1)
	char pad_29185[7];  // 0x7201(0x7)
	struct AMovable_Object_Replicated_C* K2Node_CustomEvent_prop;  // 0x7208(0x8)
	float K2Node_CustomEvent_Damage;  // 0x7210(0x4)
	struct FVector K2Node_CustomEvent_Location_8;  // 0x7214(0xC)
	struct FVector K2Node_CustomEvent_Normal;  // 0x7220(0xC)
	float K2Node_Select_Default_31;  // 0x722C(0x4)
	char pad_29232_1 : 7;  // 0x7230(0x1)
	bool Temp_bool_Variable_47 : 1;  // 0x7230(0x1)
	char pad_29233[7];  // 0x7231(0x7)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR_2;  // 0x7238(0x8)
	float K2Node_CustomEvent_Time_2;  // 0x7240(0x4)
	float K2Node_Select_Default_32;  // 0x7244(0x4)
	char pad_29256_1 : 7;  // 0x7248(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue : 1;  // 0x7248(0x1)
	char pad_29257_1 : 7;  // 0x7249(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_37 : 1;  // 0x7249(0x1)
	char pad_29258_1 : 7;  // 0x724A(0x1)
	bool CallFunc_BooleanOR_ReturnValue_23 : 1;  // 0x724A(0x1)
	char pad_29259_1 : 7;  // 0x724B(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // 0x724B(0x1)
	char pad_29260_1 : 7;  // 0x724C(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_45 : 1;  // 0x724C(0x1)
	char pad_29261_1 : 7;  // 0x724D(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_46 : 1;  // 0x724D(0x1)
	char pad_29262[2];  // 0x724E(0x2)
	struct USoundBase* K2Node_CustomEvent_Sound_3;  // 0x7250(0x8)
	struct FVector K2Node_CustomEvent_Location_7;  // 0x7258(0xC)
	char pad_29284[4];  // 0x7264(0x4)
	struct USceneComponent* K2Node_CustomEvent_AttachToComponent_5;  // 0x7268(0x8)
	float K2Node_CustomEvent_PitchMultiplier_3;  // 0x7270(0x4)
	char pad_29300[4];  // 0x7274(0x4)
	struct USoundBase* K2Node_CustomEvent_Sound_2;  // 0x7278(0x8)
	struct FVector K2Node_CustomEvent_Location_6;  // 0x7280(0xC)
	int32_t K2Node_CustomEvent_ID_4;  // 0x728C(0x4)
	struct USceneComponent* K2Node_CustomEvent_AttachToComponent_4;  // 0x7290(0x8)
	float K2Node_CustomEvent_PitchMultiplier_2;  // 0x7298(0x4)
	char pad_29340[4];  // 0x729C(0x4)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue;  // 0x72A0(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAtLocation_ReturnValue_2;  // 0x72A8(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x72B0(0x8)
	char pad_29368_1 : 7;  // 0x72B8(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_16 : 1;  // 0x72B8(0x1)
	char pad_29369_1 : 7;  // 0x72B9(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue : 1;  // 0x72B9(0x1)
	char pad_29370[6];  // 0x72BA(0x6)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue_2;  // 0x72C0(0x8)
	char pad_29384_1 : 7;  // 0x72C8(0x1)
	bool CallFunc_EqualEqual_VectorVector_ReturnValue_2 : 1;  // 0x72C8(0x1)
	char pad_29385[7];  // 0x72C9(0x7)
	struct USoundBase* K2Node_CustomEvent_Sound;  // 0x72D0(0x8)
	struct FVector K2Node_CustomEvent_Location_5;  // 0x72D8(0xC)
	int32_t K2Node_CustomEvent_ID_3;  // 0x72E4(0x4)
	struct USceneComponent* K2Node_CustomEvent_AttachToComponent_3;  // 0x72E8(0x8)
	float K2Node_CustomEvent_PitchMultiplier;  // 0x72F0(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_9;  // 0x72F4(0x4)
	int32_t Temp_int_Array_Index_Variable_33;  // 0x72F8(0x4)
	float CallFunc_FClamp_ReturnValue_12;  // 0x72FC(0x4)
	struct ABP_Effect_C* CallFunc_Array_Get_Item_48;  // 0x7300(0x8)
	struct ABP_Effect_Regen_C* K2Node_DynamicCast_AsBP_Effect_Regen;  // 0x7308(0x8)
	char pad_29456_1 : 7;  // 0x7310(0x1)
	bool K2Node_DynamicCast_bSuccess_86 : 1;  // 0x7310(0x1)
	char pad_29457[3];  // 0x7311(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_10;  // 0x7314(0x4)
	float CallFunc_FClamp_ReturnValue_13;  // 0x7318(0x4)
	char pad_29468_1 : 7;  // 0x731C(0x1)
	bool K2Node_CustomEvent_Down : 1;  // 0x731C(0x1)
	char pad_29469[3];  // 0x731D(0x3)
	struct AController* CallFunc_GetController_ReturnValue_29;  // 0x7320(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller_19;  // 0x7328(0x8)
	char pad_29488_1 : 7;  // 0x7330(0x1)
	bool K2Node_DynamicCast_bSuccess_87 : 1;  // 0x7330(0x1)
	char pad_29489[3];  // 0x7331(0x3)
	float CallFunc_BreakVector2D_X_2;  // 0x7334(0x4)
	float CallFunc_BreakVector2D_Y_2;  // 0x7338(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x733C(0xC)
	struct FVector2D K2Node_CustomEvent_Dir;  // 0x7348(0x8)
	float K2Node_CustomEvent_Random;  // 0x7350(0x4)
	float K2Node_CustomEvent_Scale;  // 0x7354(0x4)
	float K2Node_CustomEvent_delay;  // 0x7358(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_25;  // 0x735C(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_31;  // 0x7360(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue_7;  // 0x7364(0x4)
	float CallFunc_BreakVector2D_X_3;  // 0x7368(0x4)
	float CallFunc_BreakVector2D_Y_3;  // 0x736C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_11;  // 0x7370(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_12;  // 0x7374(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_13;  // 0x7378(0x4)
	float CallFunc_FClamp_ReturnValue_14;  // 0x737C(0x4)
	struct FVector2D CallFunc_MakeVector2D_ReturnValue;  // 0x7380(0x8)
	struct FVector2D CallFunc_Multiply_Vector2DFloat_ReturnValue;  // 0x7388(0x8)
	struct UMaterialInterface* K2Node_CustomEvent_DecalMaterial_2;  // 0x7390(0x8)
	struct FVector K2Node_CustomEvent_DecalSize_2;  // 0x7398(0xC)
	char pad_29604[4];  // 0x73A4(0x4)
	struct USceneComponent* K2Node_CustomEvent_AttachToComponent_2;  // 0x73A8(0x8)
	struct FVector K2Node_CustomEvent_Location_4;  // 0x73B0(0xC)
	struct FRotator K2Node_CustomEvent_Rotation_4;  // 0x73BC(0xC)
	struct FName K2Node_CustomEvent_AttachPointName_2;  // 0x73C8(0x8)
	struct UDecalComponent* CallFunc_SpawnDecalAttached_ReturnValue_2;  // 0x73D0(0x8)
	struct UMaterialInterface* K2Node_CustomEvent_DecalMaterial;  // 0x73D8(0x8)
	struct FVector K2Node_CustomEvent_DecalSize;  // 0x73E0(0xC)
	char pad_29676[4];  // 0x73EC(0x4)
	struct USceneComponent* K2Node_CustomEvent_AttachToComponent;  // 0x73F0(0x8)
	struct FVector K2Node_CustomEvent_Location_3;  // 0x73F8(0xC)
	struct FRotator K2Node_CustomEvent_Rotation_3;  // 0x7404(0xC)
	struct FName K2Node_CustomEvent_AttachPointName;  // 0x7410(0x8)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_8;  // 0x7418(0x4)
	float CallFunc_FInterpTo_ReturnValue;  // 0x741C(0x4)
	float K2Node_CustomEvent_Spread_Amount;  // 0x7420(0x4)
	float K2Node_CustomEvent_Time;  // 0x7424(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_26;  // 0x7428(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_24;  // 0x742C(0x10)
	float CallFunc_Multiply_FloatFloat_ReturnValue_32;  // 0x743C(0x4)
	int32_t CallFunc_ID_ID_5;  // 0x7440(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_14;  // 0x7444(0x4)
	int32_t CallFunc_ID_ID_6;  // 0x7448(0x4)
	float K2Node_CustomEvent_InBlendOutTime_3;  // 0x744C(0x4)
	struct FName K2Node_CustomEvent_SlotNodeName_3;  // 0x7450(0x8)
	int32_t K2Node_CustomEvent_ID_2;  // 0x7458(0x4)
	char pad_29788[4];  // 0x745C(0x4)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_10;  // 0x7460(0x8)
	char pad_29800_1 : 7;  // 0x7468(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_17 : 1;  // 0x7468(0x1)
	char pad_29801[3];  // 0x7469(0x3)
	float K2Node_CustomEvent_InBlendOutTime_2;  // 0x746C(0x4)
	struct FName K2Node_CustomEvent_SlotNodeName_2;  // 0x7470(0x8)
	int32_t K2Node_CustomEvent_ID;  // 0x7478(0x4)
	char pad_29820[4];  // 0x747C(0x4)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_11;  // 0x7480(0x8)
	float K2Node_CustomEvent_InBlendOutTime;  // 0x7488(0x4)
	struct FName K2Node_CustomEvent_SlotNodeName;  // 0x748C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_25;  // 0x7494(0x10)
	char pad_29860_1 : 7;  // 0x74A4(0x1)
	bool Temp_bool_IsClosed_Variable_30 : 1;  // 0x74A4(0x1)
	char pad_29861[3];  // 0x74A5(0x3)
	int32_t Temp_int_Loop_Counter_Variable_33;  // 0x74A8(0x4)
	char pad_29868_1 : 7;  // 0x74AC(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_31 : 1;  // 0x74AC(0x1)
	char pad_29869_1 : 7;  // 0x74AD(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_35 : 1;  // 0x74AD(0x1)
	char pad_29870[2];  // 0x74AE(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue_44;  // 0x74B0(0x4)
	char pad_29876_1 : 7;  // 0x74B4(0x1)
	bool Temp_bool_IsClosed_Variable_31 : 1;  // 0x74B4(0x1)
	char pad_29877[3];  // 0x74B5(0x3)
	struct APlayerBRController_C* CallFunc_PC_pc_25;  // 0x74B8(0x8)
	struct FST_CraftRecipe CallFunc_GetRandomWorkbenchBlueprint_RandomRecipe;  // 0x74C0(0x28)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD_7;  // 0x74E8(0x8)
	char pad_29936_1 : 7;  // 0x74F0(0x1)
	bool K2Node_DynamicCast_bSuccess_88 : 1;  // 0x74F0(0x1)
	char pad_29937[3];  // 0x74F1(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue_3;  // 0x74F4(0x4)
	struct TArray<int32_t> K2Node_CustomEvent_Array;  // 0x74F8(0x10)
	int32_t CallFunc_Array_Get_Item_49;  // 0x7508(0x4)
	char pad_29964_1 : 7;  // 0x750C(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_18 : 1;  // 0x750C(0x1)
	char pad_29965[3];  // 0x750D(0x3)
	struct FString CallFunc_Conv_IntToString_ReturnValue_6;  // 0x7510(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue_2;  // 0x7520(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_40;  // 0x7528(0x4)
	char pad_29996[4];  // 0x752C(0x4)
	struct FST_CraftRecipe CallFunc_GetDataTableRowFromName_OutRow_2;  // 0x7530(0x28)
	char pad_30040_1 : 7;  // 0x7558(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue_2 : 1;  // 0x7558(0x1)
	char pad_30041_1 : 7;  // 0x7559(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_36 : 1;  // 0x7559(0x1)
	char pad_30042_1 : 7;  // 0x755A(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_47 : 1;  // 0x755A(0x1)
	char pad_30043[1];  // 0x755B(0x1)
	int32_t CallFunc_Array_AddUnique_ReturnValue_4;  // 0x755C(0x4)
	char pad_30048_1 : 7;  // 0x7560(0x1)
	bool CallFunc_HasAuthority_ReturnValue_19 : 1;  // 0x7560(0x1)
	char pad_30049[7];  // 0x7561(0x7)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x7568(0x10)
	char pad_30072_1 : 7;  // 0x7578(0x1)
	bool K2Node_CustomEvent_Override : 1;  // 0x7578(0x1)
	char pad_30073[7];  // 0x7579(0x7)
	struct TArray<int32_t> K2Node_CustomEvent_OverrideRecipeIDs;  // 0x7580(0x10)
	struct FName CallFunc_Array_Get_Item_50;  // 0x7590(0x8)
	struct FST_CraftRecipe CallFunc_GetDataTableRowFromName_OutRow_3;  // 0x7598(0x28)
	char pad_30144_1 : 7;  // 0x75C0(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue_3 : 1;  // 0x75C0(0x1)
	char pad_30145[3];  // 0x75C1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue_41;  // 0x75C4(0x4)
	char pad_30152_1 : 7;  // 0x75C8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_37 : 1;  // 0x75C8(0x1)
	char pad_30153[3];  // 0x75C9(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_15;  // 0x75CC(0x4)
	struct TArray<struct FST_SteamItem> CallFunc_AllSteamItems_items;  // 0x75D0(0x10)
	char pad_30176_1 : 7;  // 0x75E0(0x1)
	bool CallFunc_AllSteamItems_empty : 1;  // 0x75E0(0x1)
	char pad_30177[3];  // 0x75E1(0x3)
	float CallFunc_FClamp_ReturnValue_15;  // 0x75E4(0x4)
	struct TArray<struct FST_SprayItem> CallFunc_GetSpraysFromSteamItems_Spray_Items;  // 0x75E8(0x10)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_11;  // 0x75F8(0x10)
	struct FVector CallFunc_GetForwardVector_ReturnValue_18;  // 0x7608(0xC)
	float CallFunc_Lerp_ReturnValue_2;  // 0x7614(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_23;  // 0x7618(0xC)
	float CallFunc_FClamp_ReturnValue_16;  // 0x7624(0x4)
	float CallFunc_FClamp_ReturnValue_17;  // 0x7628(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_25;  // 0x762C(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_16;  // 0x7638(0xC)
	int32_t CallFunc_GetCustomSpraySteamDefID_ID;  // 0x7644(0x4)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0x7648(0x88)
	char pad_30416_1 : 7;  // 0x76D0(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x76D0(0x1)
	char pad_30417_1 : 7;  // 0x76D1(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_8 : 1;  // 0x76D1(0x1)
	char pad_30418_1 : 7;  // 0x76D2(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_8 : 1;  // 0x76D2(0x1)
	char pad_30419[1];  // 0x76D3(0x1)
	float CallFunc_BreakHitResult_Time_8;  // 0x76D4(0x4)
	float CallFunc_BreakHitResult_Distance_8;  // 0x76D8(0x4)
	struct FVector CallFunc_BreakHitResult_Location_8;  // 0x76DC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_8;  // 0x76E8(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_8;  // 0x76F4(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_8;  // 0x7700(0xC)
	char pad_30476[4];  // 0x770C(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_8;  // 0x7710(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_8;  // 0x7718(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_8;  // 0x7720(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_8;  // 0x7728(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_8;  // 0x7730(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_8;  // 0x7734(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_8;  // 0x7738(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_8;  // 0x773C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_8;  // 0x7748(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue_4;  // 0x7754(0xC)
	float CallFunc_Dot_VectorVector_ReturnValue_2;  // 0x7760(0x4)
	float CallFunc_BreakRotator_Roll_5;  // 0x7764(0x4)
	float CallFunc_BreakRotator_Pitch_5;  // 0x7768(0x4)
	float CallFunc_BreakRotator_Yaw_5;  // 0x776C(0x4)
	char pad_30576_1 : 7;  // 0x7770(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue_2 : 1;  // 0x7770(0x1)
	char pad_30577[3];  // 0x7771(0x3)
	float CallFunc_Add_FloatFloat_ReturnValue_16;  // 0x7774(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue_3;  // 0x7778(0xC)
	float CallFunc_Dot_VectorVector_ReturnValue_3;  // 0x7784(0x4)
	struct FRotator K2Node_Select_Default_33;  // 0x7788(0xC)
	char pad_30612_1 : 7;  // 0x7794(0x1)
	bool CallFunc_EqualEqual_FloatFloat_ReturnValue_3 : 1;  // 0x7794(0x1)
	char pad_30613[3];  // 0x7795(0x3)
	struct TArray<struct UW_SpraysMenu_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_10;  // 0x7798(0x10)
	struct FVector K2Node_Select_Default_34;  // 0x77A8(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_42;  // 0x77B4(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_7;  // 0x77B8(0xC)
	char pad_30660_1 : 7;  // 0x77C4(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_11 : 1;  // 0x77C4(0x1)
	char pad_30661[11];  // 0x77C5(0xB)
	struct FTransform CallFunc_MakeTransform_ReturnValue_4;  // 0x77D0(0x30)
	struct APlayerBRController_C* CallFunc_PC_pc_26;  // 0x7800(0x8)
	int32_t CallFunc_GetCurrentInputMode_ReturnValue;  // 0x7808(0x4)
	char pad_30732_1 : 7;  // 0x780C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_15 : 1;  // 0x780C(0x1)
	char pad_30733_1 : 7;  // 0x780D(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_19 : 1;  // 0x780D(0x1)
	char pad_30734[2];  // 0x780E(0x2)
	struct FDateTime CallFunc_Now_ReturnValue_40;  // 0x7810(0x8)
	struct TSoftObjectPtr<UTexture2D> K2Node_CustomEvent_Texture;  // 0x7818(0x28)
	struct TSoftObjectPtr<UMaterialInterface> K2Node_CustomEvent_MaterialClass;  // 0x7840(0x28)
	char pad_30824[8];  // 0x7868(0x8)
	struct FTransform K2Node_CustomEvent_Transform;  // 0x7870(0x30)
	struct FString K2Node_CustomEvent_CustomURL;  // 0x78A0(0x10)
	struct FTimespan CallFunc_Subtract_DateTimeDateTime_ReturnValue_14;  // 0x78B0(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_20;  // 0x78B8(0x8)
	float CallFunc_GetTotalSeconds_ReturnValue_14;  // 0x78C0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_27;  // 0x78C4(0x4)
	char pad_30920_1 : 7;  // 0x78C8(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue_24 : 1;  // 0x78C8(0x1)
	char pad_30921[7];  // 0x78C9(0x7)
	struct ABP_Spray_C* CallFunc_FinishSpawningActor_ReturnValue_20;  // 0x78D0(0x8)
	struct FST_SprayItem K2Node_CustomEvent_Spray;  // 0x78D8(0x38)
	struct APlayerBRController_C* CallFunc_PC_pc_27;  // 0x7910(0x8)
	struct FString CallFunc_GetSprayCustomURL_Value;  // 0x7918(0x10)
	struct FST_SprayDef CallFunc_GetSpray_Spray;  // 0x7928(0x68)
	char pad_31120_1 : 7;  // 0x7990(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue_20 : 1;  // 0x7990(0x1)
	char pad_31121[7];  // 0x7991(0x7)
	struct TArray<struct UW_SpraysMenu_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets_11;  // 0x7998(0x10)
	struct APlayerBRController_C* CallFunc_PC_pc_28;  // 0x79A8(0x8)
	struct UW_SpraysMenu_C* CallFunc_Array_Get_Item_51;  // 0x79B0(0x8)
	struct UW_SpraysMenu_C* CallFunc_Create_ReturnValue_7;  // 0x79B8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_43;  // 0x79C0(0x4)
	char pad_31172[4];  // 0x79C4(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc_29;  // 0x79C8(0x8)
	char pad_31184_1 : 7;  // 0x79D0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_38 : 1;  // 0x79D0(0x1)
	char pad_31185[7];  // 0x79D1(0x7)
	struct APlayerBRController_C* CallFunc_PC_pc_30;  // 0x79D8(0x8)
	struct FVector2D CallFunc_GetViewportSize_ReturnValue_2;  // 0x79E0(0x8)
	char pad_31208_1 : 7;  // 0x79E8(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_48 : 1;  // 0x79E8(0x1)
	char pad_31209[3];  // 0x79E9(0x3)
	float CallFunc_BreakVector2D_X_4;  // 0x79EC(0x4)
	float CallFunc_BreakVector2D_Y_4;  // 0x79F0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_28;  // 0x79F4(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_29;  // 0x79F8(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_3;  // 0x79FC(0x4)
	int32_t CallFunc_FTrunc_ReturnValue_4;  // 0x7A00(0x4)
	char pad_31236[4];  // 0x7A04(0x4)
	struct FST_SprayItem K2Node_CustomEvent_SelectedSpray;  // 0x7A08(0x38)
	char pad_31296_1 : 7;  // 0x7A40(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_49 : 1;  // 0x7A40(0x1)
	char pad_31297_1 : 7;  // 0x7A41(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue_21 : 1;  // 0x7A41(0x1)
	char pad_31298_1 : 7;  // 0x7A42(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_38 : 1;  // 0x7A42(0x1)
	char pad_31299_1 : 7;  // 0x7A43(0x1)
	bool CallFunc_BooleanAND_ReturnValue_58 : 1;  // 0x7A43(0x1)
	char pad_31300_1 : 7;  // 0x7A44(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_32 : 1;  // 0x7A44(0x1)
	char pad_31301[3];  // 0x7A45(0x3)
	struct FKey K2Node_InputActionEvent_Key_20;  // 0x7A48(0x18)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_3;  // 0x7A60(0x8)
	struct FVector K2Node_CustomEvent_Location_2;  // 0x7A68(0xC)
	struct FRotator K2Node_CustomEvent_Rotation_2;  // 0x7A74(0xC)
	struct FString K2Node_CustomEvent_Link_3;  // 0x7A80(0x10)
	struct FVector K2Node_CustomEvent_Location;  // 0x7A90(0xC)
	struct FRotator K2Node_CustomEvent_Rotation;  // 0x7A9C(0xC)
	struct FString K2Node_CustomEvent_Link_2;  // 0x7AA8(0x10)
	struct UAsyncTaskDownloadImage* CallFunc_DownloadImage_ReturnValue;  // 0x7AB8(0x8)
	char pad_31424_1 : 7;  // 0x7AC0(0x1)
	bool CallFunc_IsValid_ReturnValue_61 : 1;  // 0x7AC0(0x1)
	char pad_31425[7];  // 0x7AC1(0x7)
	struct UTexture2DDynamic* CallFunc_Map_Find_Value;  // 0x7AC8(0x8)
	char pad_31440_1 : 7;  // 0x7AD0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x7AD0(0x1)
	char pad_31441[7];  // 0x7AD1(0x7)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array_12;  // 0x7AD8(0x10)
	struct UTexture2DDynamic* K2Node_Select_Default_35;  // 0x7AE8(0x8)
	struct FVector CallFunc_GetForwardVector_ReturnValue_19;  // 0x7AF0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_26;  // 0x7AFC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_24;  // 0x7B08(0xC)
	int32_t CallFunc_DynamicTextureSize_sizeX;  // 0x7B14(0x4)
	int32_t CallFunc_DynamicTextureSize_sizeY;  // 0x7B18(0x4)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_17;  // 0x7B1C(0xC)
	float CallFunc_Conv_IntToFloat_ReturnValue_3;  // 0x7B28(0x4)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit_2;  // 0x7B2C(0x88)
	char pad_31668_1 : 7;  // 0x7BB4(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue_2 : 1;  // 0x7BB4(0x1)
	char pad_31669[3];  // 0x7BB5(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_33;  // 0x7BB8(0x4)
	char pad_31676_1 : 7;  // 0x7BBC(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit_9 : 1;  // 0x7BBC(0x1)
	char pad_31677_1 : 7;  // 0x7BBD(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap_9 : 1;  // 0x7BBD(0x1)
	char pad_31678[2];  // 0x7BBE(0x2)
	float CallFunc_BreakHitResult_Time_9;  // 0x7BC0(0x4)
	float CallFunc_BreakHitResult_Distance_9;  // 0x7BC4(0x4)
	struct FVector CallFunc_BreakHitResult_Location_9;  // 0x7BC8(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint_9;  // 0x7BD4(0xC)
	struct FVector CallFunc_BreakHitResult_Normal_9;  // 0x7BE0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal_9;  // 0x7BEC(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat_9;  // 0x7BF8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor_9;  // 0x7C00(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent_9;  // 0x7C08(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName_9;  // 0x7C10(0x8)
	int32_t CallFunc_BreakHitResult_HitItem_9;  // 0x7C18(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex_9;  // 0x7C1C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex_9;  // 0x7C20(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart_9;  // 0x7C24(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd_9;  // 0x7C30(0xC)
	float CallFunc_Conv_IntToFloat_ReturnValue_4;  // 0x7C3C(0x4)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue_3;  // 0x7C40(0xC)
	float CallFunc_Multiply_FloatFloat_ReturnValue_34;  // 0x7C4C(0x4)
	struct FRotator CallFunc_NegateRotator_ReturnValue_2;  // 0x7C50(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_7;  // 0x7C5C(0xC)
	float CallFunc_BreakRotator_Roll_6;  // 0x7C68(0x4)
	float CallFunc_BreakRotator_Pitch_6;  // 0x7C6C(0x4)
	float CallFunc_BreakRotator_Yaw_6;  // 0x7C70(0x4)
	char pad_31860[4];  // 0x7C74(0x4)
	struct UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue_2;  // 0x7C78(0x8)
	float CallFunc_Add_FloatFloat_ReturnValue_17;  // 0x7C80(0x4)
	char pad_31876[4];  // 0x7C84(0x4)
	struct FString K2Node_CustomEvent_Link;  // 0x7C88(0x10)
	struct FRotator CallFunc_MakeRotator_ReturnValue_4;  // 0x7C98(0xC)
	char pad_31908[4];  // 0x7CA4(0x4)
	struct FDateTime CallFunc_Now_ReturnValue_41;  // 0x7CA8(0x8)
	char pad_31920_1 : 7;  // 0x7CB0(0x1)
	bool Temp_bool_IsClosed_Variable_32 : 1;  // 0x7CB0(0x1)
	char pad_31921[3];  // 0x7CB1(0x3)
	float CallFunc_GetWorldDeltaSeconds_ReturnValue_9;  // 0x7CB4(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_6;  // 0x7CB8(0x4)
	float CallFunc_FClamp_ReturnValue_18;  // 0x7CBC(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingBlindEffectFromFireExtinguisher
// Size: 0x8(Inherited: 0x0) 
struct FServerTryAddingBlindEffectFromFireExtinguisher
{
	struct AFirstPersonCharacter_C* BlindedTarget;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSpray
// Size: 0x10(Inherited: 0x0) 
struct FClientSpray
{
	struct FString Link;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpray_Link
// Size: 0x28(Inherited: 0x0) 
struct FServerSpray_Link
{
	struct FVector Location;  // 0x0(0xC)
	struct FRotator Rotation;  // 0xC(0xC)
	struct FString Link;  // 0x18(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetClothingClip
// Size: 0x4(Inherited: 0x0) 
struct FClientSetClothingClip
{
	float Clipping Distance;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSoundEffect
// Size: 0x28(Inherited: 0x0) 
struct FClientSoundEffect
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct USoundBase* Sound;  // 0x10(0x8)
	float VolumeMultiplier;  // 0x18(0x4)
	float PitchMultiplier;  // 0x1C(0x4)
	struct USoundAttenuation* AttenuationSettings;  // 0x20(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetRandomWorkbenchBlueprint
// Size: 0xA4(Inherited: 0x0) 
struct FGetRandomWorkbenchBlueprint
{
	struct TArray<struct FST_CraftRecipe> Current;  // 0x0(0x10)
	struct FST_CraftRecipe RandomRecipe;  // 0x10(0x28)
	struct TArray<struct FName> All;  // 0x38(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x48(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x58(0x10)
	struct FName CallFunc_Array_Get_Item;  // 0x68(0x8)
	struct FST_CraftRecipe CallFunc_GetDataTableRowFromName_OutRow;  // 0x70(0x28)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xA2(0x1)
	char pad_163_1 : 7;  // 0xA3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xA3(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GameInstance
// Size: 0x19(Inherited: 0x0) 
struct FGameInstance
{
	struct UGI_BR_C* AsGI BR;  // 0x0(0x8)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x8(0x8)
	struct UGI_BR_C* K2Node_DynamicCast_AsGI_BR;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnPlayerSettingsChanged
// Size: 0x30(Inherited: 0x0) 
struct FOnPlayerSettingsChanged
{
	struct FST_PlayerSettings New Settings;  // 0x0(0x30)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.FadeCamera
// Size: 0xC(Inherited: 0x0) 
struct FFadeCamera
{
	float FromAlpha;  // 0x0(0x4)
	float ToAlpha;  // 0x4(0x4)
	float Duration;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSpray_Link
// Size: 0x28(Inherited: 0x0) 
struct FMultiSpray_Link
{
	struct FVector Location;  // 0x0(0xC)
	struct FRotator Rotation;  // 0xC(0xC)
	struct FString Link;  // 0x18(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ReplaceWithFistIfEmpty
// Size: 0x1B8(Inherited: 0x0) 
struct FReplaceWithFistIfEmpty
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	struct FST_ItemBase Out;  // 0x90(0x90)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool Temp_bool_Variable : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_ItemValid__Valid : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct FST_ItemBase K2Node_Select_Default;  // 0x128(0x90)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientGetHit
// Size: 0xC(Inherited: 0x0) 
struct FClientGetHit
{
	struct FVector AttackerLoc;  // 0x0(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddSkeletalMesh
// Size: 0x8(Inherited: 0x0) 
struct FServerAddSkeletalMesh
{
	struct USkeletalMesh* NewMesh;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetActorHidden
// Size: 0x9(Inherited: 0x0) 
struct FServerSetActorHidden
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bNewHidden : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.DevSpawn
// Size: 0x10(Inherited: 0x0) 
struct FDevSpawn
{
	struct FString Name;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client_SprayItem
// Size: 0x38(Inherited: 0x0) 
struct FClient_SprayItem
{
	struct FST_SprayItem Spray;  // 0x0(0x38)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpray_Texture
// Size: 0x90(Inherited: 0x0) 
struct FServerSpray_Texture
{
	struct TSoftObjectPtr<UTexture2D> Texture;  // 0x0(0x28)
	struct TSoftObjectPtr<UMaterialInterface> MaterialClass;  // 0x28(0x28)
	struct FTransform Transform;  // 0x50(0x30)
	struct FString CustomURL;  // 0x80(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 3_K2Node_InputActionEvent_26
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 3_K2Node_InputActionEvent_26
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AddDefaultRecipies
// Size: 0x18(Inherited: 0x0) 
struct FAddDefaultRecipies
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Override : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<int32_t> OverrideRecipeIDs;  // 0x8(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 2_K2Node_InputActionEvent_23
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 2_K2Node_InputActionEvent_23
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server update info
// Size: 0x38(Inherited: 0x0) 
struct FServer update info
{
	struct FST_PlayerRepInfo Info;  // 0x0(0x38)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetWorkbenchDefaultBlueprints
// Size: 0x10(Inherited: 0x0) 
struct FSetWorkbenchDefaultBlueprints
{
	struct TArray<int32_t> Array;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientRemoteEquip
// Size: 0x4(Inherited: 0x0) 
struct FClientRemoteEquip
{
	int32_t EquipSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Multi Spawn Decal
// Size: 0x40(Inherited: 0x0) 
struct FMulti Spawn Decal
{
	struct UMaterialInterface* DecalMaterial;  // 0x0(0x8)
	struct FVector DecalSize;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct USceneComponent* AttachToComponent;  // 0x18(0x8)
	struct FVector Location;  // 0x20(0xC)
	struct FRotator Rotation;  // 0x2C(0xC)
	struct FName AttachPointName;  // 0x38(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStopSlotAnimation
// Size: 0xC(Inherited: 0x0) 
struct FClientStopSlotAnimation
{
	float InBlendOutTime;  // 0x0(0x4)
	struct FName SlotNodeName;  // 0x4(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSpawnSound
// Size: 0x24(Inherited: 0x0) 
struct FClientSpawnSound
{
	struct USoundBase* Sound;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct USceneComponent* AttachToComponent;  // 0x18(0x8)
	float PitchMultiplier;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStopSlotAnimation
// Size: 0x10(Inherited: 0x0) 
struct FServerStopSlotAnimation
{
	float InBlendOutTime;  // 0x0(0x4)
	struct FName SlotNodeName;  // 0x4(0x8)
	int32_t ID;  // 0xC(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientOnHitSomeone
// Size: 0x40(Inherited: 0x0) 
struct FClientOnHitSomeone
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	float Damage;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool HeadShot? : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct AFirstPersonCharacter_C* DamagedTarget;  // 0x38(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStopSlotAnimation
// Size: 0x10(Inherited: 0x0) 
struct FMultiStopSlotAnimation
{
	float InBlendOutTime;  // 0x0(0x4)
	struct FName SlotNodeName;  // 0x4(0x8)
	int32_t ID;  // 0xC(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetCanMoveHeavyFurniture
// Size: 0x1(Inherited: 0x0) 
struct FServerSetCanMoveHeavyFurniture
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanMoveHeavyFurniture : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server_CraftInHand_Start
// Size: 0x1(Inherited: 0x0) 
struct FServer_CraftInHand_Start
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Exclusive : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPlayVoice
// Size: 0x18(Inherited: 0x0) 
struct FClientPlayVoice
{
	struct TArray<char> CompressedVoiceData;  // 0x0(0x10)
	struct AActor* Target;  // 0x10(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client Spread Curve
// Size: 0x8(Inherited: 0x0) 
struct FClient Spread Curve
{
	float Spread Amount;  // 0x0(0x4)
	float Time;  // 0x4(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Decal
// Size: 0x40(Inherited: 0x0) 
struct FServer Spawn Decal
{
	struct UMaterialInterface* DecalMaterial;  // 0x0(0x8)
	struct FVector DecalSize;  // 0x8(0xC)
	char pad_20[4];  // 0x14(0x4)
	struct USceneComponent* AttachToComponent;  // 0x18(0x8)
	struct FVector Location;  // 0x20(0xC)
	struct FRotator Rotation;  // 0x2C(0xC)
	struct FName AttachPointName;  // 0x38(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Add Effect
// Size: 0x48(Inherited: 0x0) 
struct FServer Add Effect
{
	struct FST_Effect Effect;  // 0x0(0x38)
	float New Scale;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct AFirstPersonCharacter_C* caster;  // 0x40(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AddRecoil
// Size: 0x14(Inherited: 0x0) 
struct FAddRecoil
{
	struct FVector2D Dir;  // 0x0(0x8)
	float Random;  // 0x8(0x4)
	float Scale;  // 0xC(0x4)
	float Delay;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Do Block
// Size: 0x1(Inherited: 0x0) 
struct FDo Block
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Blocking : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerLMB
// Size: 0x1(Inherited: 0x0) 
struct FServerLMB
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Ping In S
// Size: 0xC(Inherited: 0x0) 
struct FPing In S
{
	float ReturnValue;  // 0x0(0x4)
	float CallFunc_Conv_ByteToFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAudioComponentPlay
// Size: 0x24(Inherited: 0x0) 
struct FServerAudioComponentPlay
{
	struct USoundBase* Sound;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0xC)
	int32_t ID;  // 0x14(0x4)
	struct USceneComponent* AttachToComponent;  // 0x18(0x8)
	float PitchMultiplier;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.BndEvt__VoipManager_K2Node_ComponentBoundEvent_0_VoiceGenerated__DelegateSignature
// Size: 0x14(Inherited: 0x0) 
struct FBndEvt__VoipManager_K2Node_ComponentBoundEvent_0_VoiceGenerated__DelegateSignature
{
	struct TArray<char> VoiceData;  // 0x0(0x10)
	float MicLevel;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.KickAndBan
// Size: 0x4A(Inherited: 0x0) 
struct FKickAndBan
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ABR_PS_C* K2Node_DynamicCast_AsBR_PS;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FSteamID CallFunc_MakeSteamID_ReturnValue;  // 0x20(0x8)
	uint8_t  CallFunc_IsSteamIDValid_Exec_Result;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsDev_Server_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2B(0x1)
	char pad_44[4];  // 0x2C(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x30(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x38(0x8)
	struct AGM_BR_C* K2Node_DynamicCast_AsGM_BR;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x49(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAudioComponentPlay
// Size: 0x24(Inherited: 0x0) 
struct FMultiAudioComponentPlay
{
	struct USoundBase* Sound;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0xC)
	int32_t ID;  // 0x14(0x4)
	struct USceneComponent* AttachToComponent;  // 0x18(0x8)
	float PitchMultiplier;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSoundEffect
// Size: 0x30(Inherited: 0x0) 
struct FMultiSoundEffect
{
	struct FVector Location;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct USoundBase* Sound;  // 0x10(0x8)
	int32_t ID;  // 0x18(0x4)
	float VolumeMultiplier;  // 0x1C(0x4)
	float PitchMultiplier;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct USoundAttenuation* AttenuationSettings;  // 0x28(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.EEVent
// Size: 0x4(Inherited: 0x0) 
struct FEEVent
{
	int32_t NewSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.WalkingSurfaceTrace
// Size: 0x1A(Inherited: 0x0) 
struct FWalkingSurfaceTrace
{
	char EPhysicalSurface SurfaceType;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x8(0x8)
	struct UCharacter_AnimBP_C* K2Node_DynamicCast_AsCharacter_Anim_BP;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char EPhysicalSurface CallFunc_WalkingSurfaceTrace_SurfaceType;  // 0x19(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDamage Prop
// Size: 0x24(Inherited: 0x0) 
struct FServerDamage Prop
{
	struct AMovable_Object_Replicated_C* Prop;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)
	struct FVector Location;  // 0xC(0xC)
	struct FVector Normal;  // 0x18(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDoLocalBleedDamage
// Size: 0x8(Inherited: 0x0) 
struct FServerDoLocalBleedDamage
{
	struct AFirstPersonCharacter_C* DamageCauser;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddUpgrade
// Size: 0xC(Inherited: 0x0) 
struct FServerAddUpgrade
{
	UC_Upgrade_C* Upgrade;  // 0x0(0x8)
	int32_t Slot;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAddSkeletalMesh
// Size: 0x8(Inherited: 0x0) 
struct FMultiAddSkeletalMesh
{
	struct USkeletalMesh* NewMesh;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Equip
// Size: 0x4(Inherited: 0x0) 
struct FEquip
{
	int32_t SlotIndex;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnDarkZone
// Size: 0x3C(Inherited: 0x0) 
struct FServerSpawnDarkZone
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	float timeToGrow;  // 0x30(0x4)
	float Time;  // 0x34(0x4)
	float TargetSize;  // 0x38(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetTeamMate
// Size: 0x8(Inherited: 0x0) 
struct FServerSetTeamMate
{
	struct AFirstPersonCharacter_C* Teammate;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnProjectile
// Size: 0x50(Inherited: 0x0) 
struct FServerSpawnProjectile
{
	ABP_Projectile_C* Class;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x30)
	float Damage;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct APawn* Instigator;  // 0x48(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddPath
// Size: 0x14(Inherited: 0x0) 
struct FClientAddPath
{
	float Velocity;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* Ignore;  // 0x8(0x8)
	float OverrideGravityZ;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.EffectRep
// Size: 0x7C(Inherited: 0x0) 
struct FEffectRep
{
	struct TArray<struct ABP_Effect_C*> Effects;  // 0x0(0x10)
	struct TArray<struct FST_EffectRep> Rep;  // 0x10(0x10)
	struct TArray<struct FST_EffectRep> effectsd;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct ABP_Effect_C* CallFunc_Array_Get_Item;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x4C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct FST_EffectRep K2Node_MakeStruct_ST_EffectRep;  // 0x58(0x20)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x78(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetAttachSockets
// Size: 0x10(Inherited: 0x0) 
struct FClientSetAttachSockets
{
	struct TArray<struct FST_AttachedMesh> Array;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Set Prop Spring Length
// Size: 0x74(Inherited: 0x0) 
struct FSet Prop Spring Length
{
	struct AMovable_Object_Replicated_C* Prop;  // 0x0(0x8)
	struct FVector CallFunc_GetLocalBounds_Min;  // 0x8(0xC)
	struct FVector CallFunc_GetLocalBounds_Max;  // 0x14(0xC)
	struct FBoxSphereBounds CallFunc_GetBounds_ReturnValue;  // 0x20(0x1C)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x3C(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // 0x48(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x54(0xC)
	float CallFunc_BreakVector_X;  // 0x60(0x4)
	float CallFunc_BreakVector_Y;  // 0x64(0x4)
	float CallFunc_BreakVector_Z;  // 0x68(0x4)
	float CallFunc_Abs_ReturnValue;  // 0x6C(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x70(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 6_K2Node_InputActionEvent_32
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 6_K2Node_InputActionEvent_32
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Spray_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Spray_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AttachCosmetic
// Size: 0x38(Inherited: 0x0) 
struct FAttachCosmetic
{
	struct TSoftObjectPtr<USkeletalMesh> Mesh;  // 0x0(0x28)
	struct TArray<struct TSoftObjectPtr<UMaterialInterface>> Materials;  // 0x28(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddUpgrade
// Size: 0x10(Inherited: 0x0) 
struct FClientAddUpgrade
{
	UC_Upgrade_C* Upgrade;  // 0x0(0x8)
	struct ABP_ItemPickup_C* Pickup;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryApplyUpgrade
// Size: 0x14(Inherited: 0x0) 
struct FServerTryApplyUpgrade
{
	struct ABP_ItemPickup_C* Pickup;  // 0x0(0x8)
	UC_Upgrade_C* Upgrade;  // 0x8(0x8)
	int32_t Slot;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.splitSlotMap
// Size: 0xC8(Inherited: 0x0) 
struct FsplitSlotMap
{
	struct TMap<struct FName, struct UStaticMesh*> Map;  // 0x0(0x50)
	struct TArray<struct FName> Name;  // 0x50(0x10)
	struct TArray<struct UStaticMesh*> Mesh;  // 0x60(0x10)
	struct TArray<struct UStaticMesh*> Meshes;  // 0x70(0x10)
	struct TArray<struct FName> Names;  // 0x80(0x10)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys;  // 0x90(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0xA0(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA4(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0xA8(0x8)
	struct UStaticMesh* CallFunc_Map_Find_Value;  // 0xB0(0x8)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xBC(0x4)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC4(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoseFocus_Event_Upgrade
// Size: 0x8(Inherited: 0x0) 
struct FOnLoseFocus_Event_Upgrade
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SoundDampenTick_Fucntion
// Size: 0x167(Inherited: 0x0) 
struct FSoundDampenTick_Fucntion
{
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x0(0x10)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors;  // 0x10(0x10)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x20(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x30(0x8)
	struct AAmbientSound* K2Node_DynamicCast_AsAmbient_Sound;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x50(0xC)
	struct FHitResult CallFunc_SphereTraceSingleForObjects_OutHit;  // 0x5C(0x88)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_SphereTraceSingleForObjects_ReturnValue : 1;  // 0xE4(0x1)
	char pad_229_1 : 7;  // 0xE5(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0xE5(0x1)
	char pad_230_1 : 7;  // 0xE6(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0xE6(0x1)
	char pad_231[1];  // 0xE7(0x1)
	float CallFunc_BreakHitResult_Time;  // 0xE8(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0xEC(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0xF0(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xFC(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x108(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x114(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x120(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x128(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x130(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x138(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x140(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x144(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x148(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x14C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x158(0xC)
	char pad_356_1 : 7;  // 0x164(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x164(0x1)
	char pad_357_1 : 7;  // 0x165(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x165(0x1)
	char pad_358_1 : 7;  // 0x166(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x166(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetSelectedSlot
// Size: 0x4(Inherited: 0x0) 
struct FServerSetSelectedSlot
{
	int32_t SelectedInventorySlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client Set Upgrades
// Size: 0x10(Inherited: 0x0) 
struct FClient Set Upgrades
{
	struct TArray<UC_Upgrade_C*> Array;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.CanThrowHeldProp
// Size: 0x4(Inherited: 0x0) 
struct FCanThrowHeldProp
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddClothing
// Size: 0x10(Inherited: 0x0) 
struct FServerAddClothing
{
	struct TArray<struct FST_RepCosmetic> SourceArray;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerCrouch
// Size: 0x1(Inherited: 0x0) 
struct FServerCrouch
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Crouched : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCrouch
// Size: 0x1(Inherited: 0x0) 
struct FClientCrouch
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Crouched : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientChangeStamina
// Size: 0x14(Inherited: 0x0) 
struct FClientChangeStamina
{
	float +;  // 0x0(0x4)
	float StaminaBuffer;  // 0x4(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float CallFunc_FClamp_ReturnValue;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Remove Effect
// Size: 0x10(Inherited: 0x0) 
struct FServer Remove Effect
{
	struct FString Name;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ShouldReceiveFallDamage
// Size: 0x119(Inherited: 0x0) 
struct FShouldReceiveFallDamage
{
	struct FHitResult Hit;  // 0x0(0x88)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool Result : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x8A(0x1)
	char pad_139[1];  // 0x8B(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x8C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x90(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x94(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0xA0(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0xAC(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0xB8(0xC)
	char pad_196[4];  // 0xC4(0x4)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0xC8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0xD0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0xD8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0xE0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0xE8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0xEC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xF0(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0xF4(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x100(0xC)
	char pad_268[4];  // 0x10C(0x4)
	struct ABP_Trampoline_C* K2Node_DynamicCast_AsBP_Trampoline;  // 0x110(0x8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x118(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetMoveFurniture
// Size: 0x1(Inherited: 0x0) 
struct FServerSetMoveFurniture
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CanMoveFurniture : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetConstIncomingDamageMultiplier
// Size: 0x4(Inherited: 0x0) 
struct FSetConstIncomingDamageMultiplier
{
	float IncomingDamageMultiplier;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.TrySwitchSlotsAfterHold
// Size: 0xC(Inherited: 0x0) 
struct FTrySwitchSlotsAfterHold
{
	int32_t CallFunc_GetHeldDownSlotKeyIndex_SlotIndex;  // 0x0(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientUpdateHUDEffects
// Size: 0x10(Inherited: 0x0) 
struct FClientUpdateHUDEffects
{
	struct TArray<struct ABP_Effect_C*> Effects;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.LongHitTrace
// Size: 0x30(Inherited: 0x0) 
struct FLongHitTrace
{
	float Time;  // 0x0(0x4)
	float Length;  // 0x4(0x4)
	struct TArray<struct FHitResult> OutHits;  // 0x8(0x10)
	float CurrentTime;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct FHitResult> Hits;  // 0x20(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddArmour
// Size: 0x4(Inherited: 0x0) 
struct FServerAddArmour
{
	int32_t Slot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetThrowingServer
// Size: 0x1(Inherited: 0x0) 
struct FSetThrowingServer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Throwing? : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientThrowingFurniture
// Size: 0x1(Inherited: 0x0) 
struct FClientThrowingFurniture
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Throwing? : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCharge
// Size: 0x20(Inherited: 0x0) 
struct FClientCharge
{
	float TimetoCharge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* Ref;  // 0x8(0x8)
	struct FString Tag;  // 0x10(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.RemoveCharge
// Size: 0x10(Inherited: 0x0) 
struct FRemoveCharge
{
	struct FString Tag;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddAmmo
// Size: 0xA(Inherited: 0x0) 
struct FClientAddAmmo
{
	int32_t Slot;  // 0x0(0x4)
	int32_t Ammo;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Destroy on 0 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Equip? : 1;  // 0x9(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ShowToolTip
// Size: 0x30(Inherited: 0x0) 
struct FShowToolTip
{
	struct FString inString;  // 0x0(0x10)
	struct FString SubText;  // 0x10(0x10)
	struct FString Tag;  // 0x20(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingBoltEffectFromUpgrade
// Size: 0xC(Inherited: 0x0) 
struct FServerTryAddingBoltEffectFromUpgrade
{
	struct AFirstPersonCharacter_C* AttackedTarget;  // 0x0(0x8)
	float BoltScale;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSwapInventorySlots
// Size: 0x8(Inherited: 0x0) 
struct FServerSwapInventorySlots
{
	int32_t FirstIndex;  // 0x0(0x4)
	int32_t SecondIndex;  // 0x4(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.HideToolTip
// Size: 0x10(Inherited: 0x0) 
struct FHideToolTip
{
	struct FString Tag;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.BndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OutlinePickup
// Size: 0x10(Inherited: 0x0) 
struct FOutlinePickup
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UPrimitiveComponent* Target;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Reload_K2Node_InputActionEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Reload_K2Node_InputActionEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.BndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__ItemTrace_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ShowPlayerInfo
// Size: 0x8(Inherited: 0x0) 
struct FShowPlayerInfo
{
	struct AFirstPersonCharacter_C* Actor;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.LookAtObject
// Size: 0x10(Inherited: 0x0) 
struct FLookAtObject
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Look? : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* Target;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AddToInventory
// Size: 0x95(Inherited: 0x0) 
struct FAddToInventory
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	int32_t SlotIndex;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool Equip? : 1;  // 0x94(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.CallOnLook
// Size: 0x10(Inherited: 0x0) 
struct FCallOnLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Start Look? : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* Target;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddBP
// Size: 0x28(Inherited: 0x0) 
struct FClientAddBP
{
	struct FST_CraftRecipe Recipe;  // 0x0(0x28)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C._ClientCallOnLook
// Size: 0x10(Inherited: 0x0) 
struct F_ClientCallOnLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Start Look? : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* Target;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetClosestPlayer
// Size: 0x53(Inherited: 0x0) 
struct FGetClosestPlayer
{
	struct AFirstPersonCharacter_C* ClosestPlayer1;  // 0x0(0x8)
	struct AFirstPersonCharacter_C* ClosestPlayer;  // 0x8(0x8)
	float MinDistance;  // 0x10(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x1C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct AFirstPersonCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x28(0x10)
	struct AFirstPersonCharacter_C* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x44(0x4)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x4B(0x1)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue_2 : 1;  // 0x52(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Jump_K2Node_InputActionEvent_45
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Jump_K2Node_InputActionEvent_45
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryScrapGarbagePile
// Size: 0x8(Inherited: 0x0) 
struct FServerTryScrapGarbagePile
{
	struct AGarbagePile_C* Pile;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C._ServerCallOnLook
// Size: 0x10(Inherited: 0x0) 
struct F_ServerCallOnLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Start Look? : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UObject* Target;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.HidePlayerInfo
// Size: 0x8(Inherited: 0x0) 
struct FHidePlayerInfo
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerCraft
// Size: 0x28(Inherited: 0x0) 
struct FServerCraft
{
	struct FST_CraftRecipe Recipe;  // 0x0(0x28)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCraft
// Size: 0x28(Inherited: 0x0) 
struct FClientCraft
{
	struct FST_CraftRecipe Recipe;  // 0x0(0x28)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.WorkbenchCraft
// Size: 0x30(Inherited: 0x0) 
struct FWorkbenchCraft
{
	struct FST_CraftRecipe Recipe;  // 0x0(0x28)
	struct AWorkbench_C* Target;  // 0x28(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiParticles
// Size: 0x20(Inherited: 0x0) 
struct FMultiParticles
{
	struct UParticleSystem* EmitterTemplate;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0xC)
	struct FVector Scale;  // 0x14(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Use Current Stim
// Size: 0x4(Inherited: 0x0) 
struct FServer Use Current Stim
{
	int32_t SelectedSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Particle
// Size: 0x34(Inherited: 0x0) 
struct FServer Spawn Particle
{
	struct UParticleSystem* EmitterTemplate;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0xC)
	struct FVector Scale;  // 0x14(0xC)
	struct USceneComponent* AttachToComponent;  // 0x20(0x8)
	struct FRotator Rotation;  // 0x28(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSpawnParticleAttached
// Size: 0x34(Inherited: 0x0) 
struct FMultiSpawnParticleAttached
{
	struct UParticleSystem* EmitterTemplate;  // 0x0(0x8)
	struct USceneComponent* AttachToComponent;  // 0x8(0x8)
	struct FVector Scale;  // 0x10(0xC)
	struct FVector Location;  // 0x1C(0xC)
	struct FRotator Rotation;  // 0x28(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiSetActorHidden
// Size: 0x9(Inherited: 0x0) 
struct FMultiSetActorHidden
{
	struct AActor* Target;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bNewHidden : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ToolTipForPickup
// Size: 0x278(Inherited: 0x0) 
struct FToolTipForPickup
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	struct FString tool tip;  // 0x90(0x10)
	struct FString sub tip;  // 0xA0(0x10)
	struct FString SubTip;  // 0xB0(0x10)
	struct FString Tooltip;  // 0xC0(0x10)
	struct FString CallFunc_AddInputToString_out;  // 0xD0(0x10)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0xE1(0x1)
	char pad_226_1 : 7;  // 0xE2(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xE2(0x1)
	char pad_227[5];  // 0xE3(0x5)
	ABP_UpgradeItem_C* K2Node_ClassDynamicCast_AsBP_Upgrade_Item;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xF0(0x1)
	char pad_241[3];  // 0xF1(0x3)
	int32_t CallFunc_FindItemInInventory_index;  // 0xF4(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item;  // 0xF8(0x90)
	char pad_392_1 : 7;  // 0x188(0x1)
	bool CallFunc_FindItemInInventory_Found : 1;  // 0x188(0x1)
	char pad_393[3];  // 0x189(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x18C(0x4)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct FString CallFunc_AddInputToString_out_2;  // 0x198(0x10)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_EqualEqual_StriStri_ReturnValue : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x1A9(0x1)
	char pad_426[6];  // 0x1AA(0x6)
	struct FString CallFunc_AddInputToString_out_3;  // 0x1B0(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1C0(0x4)
	char pad_452_1 : 7;  // 0x1C4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x1C4(0x1)
	char pad_453_1 : 7;  // 0x1C5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1C5(0x1)
	char pad_454_1 : 7;  // 0x1C6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x1C6(0x1)
	char pad_455[1];  // 0x1C7(0x1)
	int32_t CallFunc_FindItemInInventory_index_2;  // 0x1C8(0x4)
	char pad_460[4];  // 0x1CC(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item_2;  // 0x1D0(0x90)
	char pad_608_1 : 7;  // 0x260(0x1)
	bool CallFunc_FindItemInInventory_Found_2 : 1;  // 0x260(0x1)
	char pad_609[7];  // 0x261(0x7)
	struct FString CallFunc_AddInputToString_out_4;  // 0x268(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetActorHidden
// Size: 0x9(Inherited: 0x0) 
struct FClientSetActorHidden
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bNewHidden : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Interact_K2Node_InputActionEvent_44
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Interact_K2Node_InputActionEvent_44
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientChangeSaturation
// Size: 0x4(Inherited: 0x0) 
struct FClientChangeSaturation
{
	float X;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Multi_CraftInHand_Start
// Size: 0x1(Inherited: 0x0) 
struct FMulti_CraftInHand_Start
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Exclusive : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Multi_CraftInHand_Stop
// Size: 0x1(Inherited: 0x0) 
struct FMulti_CraftInHand_Stop
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Exclusive : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server_CraftInHand_Stop
// Size: 0x1(Inherited: 0x0) 
struct FServer_CraftInHand_Stop
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Exclusive : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Open Crafting Menu
// Size: 0x10(Inherited: 0x0) 
struct FOpen Crafting Menu
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Workbench : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AWorkbench_C* WorkbenchActor;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAnim
// Size: 0x24(Inherited: 0x0) 
struct FMultiAnim
{
	int32_t initiator;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAnimSequenceBase* Asset;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	struct FName SlotNodeName;  // 0x18(0x8)
	float InPlayRate;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnGetHitClient
// Size: 0xC(Inherited: 0x0) 
struct FOnGetHitClient
{
	struct AFirstPersonCharacter_C* Hitter;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SprintMulti
// Size: 0x9(Inherited: 0x0) 
struct FSprintMulti
{
	float MaxWalkSpeed;  // 0x0(0x4)
	int32_t initiator;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool sprinting : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Clientsprint
// Size: 0x6(Inherited: 0x0) 
struct FClientsprint
{
	float MaxWalkSpeed;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Sprinting? : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Force : 1;  // 0x5(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MeleeWeapon
// Size: 0x68(Inherited: 0x0) 
struct FMeleeWeapon
{
	struct FST_MeleeWeaponInfo Weapon;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FST_MeleeWeaponInfo K2Node_MakeStruct_ST_MeleeWeaponInfo;  // 0x20(0x18)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FST_MeleeWeaponInfo K2Node_Select_Default;  // 0x50(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Set Stims Sprint Multiplier
// Size: 0x4(Inherited: 0x0) 
struct FServer Set Stims Sprint Multiplier
{
	float Stims Sprint Speed Multiplier;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server set Bolt Sprint Multiplier
// Size: 0x4(Inherited: 0x0) 
struct FServer set Bolt Sprint Multiplier
{
	float Stims Sprint Speed Multiplier;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientUpdateSprintSpeed
// Size: 0x4(Inherited: 0x0) 
struct FClientUpdateSprintSpeed
{
	float MaxWalkSpeed;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ReceiveAnyDamage
// Size: 0x20(Inherited: 0x20) 
struct FReceiveAnyDamage : public FReceiveAnyDamage
{
	float Damage;  // 0x0(0x4)
	struct UDamageType* DamageType;  // 0x8(0x8)
	struct AController* InstigatedBy;  // 0x10(0x8)
	struct AActor* DamageCauser;  // 0x18(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetFaceDir
// Size: 0x5E(Inherited: 0x0) 
struct FGetFaceDir
{
	struct FVector Incoming;  // 0x0(0xC)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool FacingFront? : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x10(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x1C(0xC)
	float CallFunc_BreakVector_X;  // 0x28(0x4)
	float CallFunc_BreakVector_Y;  // 0x2C(0x4)
	float CallFunc_BreakVector_Z;  // 0x30(0x4)
	float CallFunc_BreakVector_X_2;  // 0x34(0x4)
	float CallFunc_BreakVector_Y_2;  // 0x38(0x4)
	float CallFunc_BreakVector_Z_2;  // 0x3C(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x40(0xC)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x4C(0xC)
	float CallFunc_Dot_VectorVector_ReturnValue;  // 0x58(0x4)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5D(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerCommitHeal
// Size: 0x4(Inherited: 0x0) 
struct FServerCommitHeal
{
	float + Health;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ShowHitDamage
// Size: 0x35(Inherited: 0x0) 
struct FShowHitDamage
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	float Damage;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool HeadShot? : 1;  // 0x34(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Try Switch with pickup
// Size: 0x4(Inherited: 0x0) 
struct FTry Switch with pickup
{
	int32_t inventory slot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Heal Other
// Size: 0x10(Inherited: 0x0) 
struct FServer Heal Other
{
	float +;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Healing Target;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientDestroyComponent
// Size: 0x8(Inherited: 0x0) 
struct FClientDestroyComponent
{
	struct UActorComponent* Target;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client Chromatic Abberation Curve
// Size: 0xC(Inherited: 0x0) 
struct FClient Chromatic Abberation Curve
{
	float Time;  // 0x0(0x4)
	float MaxIntensity;  // 0x4(0x4)
	float Start Time;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPickup
// Size: 0x8(Inherited: 0x0) 
struct FClientPickup
{
	struct AActor* Actor;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiEquip
// Size: 0x18(Inherited: 0x0) 
struct FMultiEquip
{
	int32_t ID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	AActor* inClass;  // 0x8(0x8)
	struct FName SocketName;  // 0x10(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AddRecipe
// Size: 0x28(Inherited: 0x0) 
struct FAddRecipe
{
	struct FST_CraftRecipe NewItem;  // 0x0(0x28)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDropItem
// Size: 0xA0(Inherited: 0x0) 
struct FServerDropItem
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	struct FVector ThrowVector;  // 0x90(0xC)
	float Damage;  // 0x9C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDismantle
// Size: 0x4(Inherited: 0x0) 
struct FServerDismantle
{
	int32_t Slot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientDismantle
// Size: 0x4(Inherited: 0x0) 
struct FClientDismantle
{
	int32_t Slot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Hitmarker
// Size: 0x1(Inherited: 0x0) 
struct FHitmarker
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool HeadShot? : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAddMaterialsEffect
// Size: 0xC(Inherited: 0x0) 
struct FClientAddMaterialsEffect
{
	int32_t Wood;  // 0x0(0x4)
	int32_t Metal;  // 0x4(0x4)
	int32_t Binder;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddMaterials
// Size: 0xC(Inherited: 0x0) 
struct FServerAddMaterials
{
	int32_t +wood;  // 0x0(0x4)
	int32_t +metal;  // 0x4(0x4)
	int32_t +binder;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientAnimSet
// Size: 0x1(Inherited: 0x0) 
struct FClientAnimSet
{
	char E_AnimType Type;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Drop_K2Node_InputActionEvent_20
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Drop_K2Node_InputActionEvent_20
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAnimSet
// Size: 0x1(Inherited: 0x0) 
struct FServerAnimSet
{
	char E_AnimType Enumerator;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerEquip
// Size: 0x4(Inherited: 0x0) 
struct FServerEquip
{
	int32_t ReplicatedSelectedSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStopLoopedAnimation
// Size: 0x14(Inherited: 0x0) 
struct FServerStopLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)
	int32_t ID;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.RemoveCurrentItem
// Size: 0x5(Inherited: 0x0) 
struct FRemoveCurrentItem
{
	int32_t SlotIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Equip? : 1;  // 0x4(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerChangeInventory
// Size: 0x94(Inherited: 0x0) 
struct FServerChangeInventory
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	int32_t Slot;  // 0x90(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client drop current item
// Size: 0x10(Inherited: 0x0) 
struct FClient drop current item
{
	struct FVector ThrowVector;  // 0x0(0xC)
	float Damage;  // 0xC(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnNewItem
// Size: 0x90(Inherited: 0x0) 
struct FServerSpawnNewItem
{
	struct FST_ItemBase Item;  // 0x0(0x90)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnEquip_Event
// Size: 0x4(Inherited: 0x0) 
struct FOnEquip_Event
{
	int32_t NewSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetUpgrades
// Size: 0x155(Inherited: 0x0) 
struct FSetUpgrades
{
	struct TArray<UC_Upgrade_C*> Array;  // 0x0(0x10)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40(0x4)
	char pad_68[12];  // 0x44(0xC)
	struct FTransform Temp_struct_Variable_2;  // 0x50(0x30)
	struct FTransform Temp_struct_Variable_3;  // 0x80(0x30)
	int32_t Temp_int_Array_Index_Variable;  // 0xB0(0x4)
	char pad_180[12];  // 0xB4(0xC)
	struct FTransform Temp_struct_Variable_4;  // 0xC0(0x30)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xF0(0x4)
	char pad_244_1 : 7;  // 0xF4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xF4(0x1)
	char pad_245[3];  // 0xF5(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xF8(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0xFC(0x4)
	UC_Upgrade_C* CallFunc_Array_Get_Item;  // 0x100(0x8)
	struct UC_UpgradeBolt_C* CallFunc_AddComponent_ReturnValue;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_2 : 1;  // 0x111(0x1)
	char pad_274_1 : 7;  // 0x112(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_3 : 1;  // 0x112(0x1)
	char pad_275_1 : 7;  // 0x113(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_4 : 1;  // 0x113(0x1)
	char pad_276[4];  // 0x114(0x4)
	struct UC_UpgradeVampire_C* CallFunc_AddComponent_ReturnValue_2;  // 0x118(0x8)
	struct UC_UpgradeDrain_C* CallFunc_AddComponent_ReturnValue_3;  // 0x120(0x8)
	struct UC_UpgradeBleed_C* CallFunc_AddComponent_ReturnValue_4;  // 0x128(0x8)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x130(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x134(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x138(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x13C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_3;  // 0x140(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_4;  // 0x144(0x4)
	struct UC_Upgrade_C* CallFunc_Array_Get_Item_2;  // 0x148(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x150(0x4)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x154(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetNewChargeSpeed
// Size: 0xDC(Inherited: 0x0) 
struct FSetNewChargeSpeed
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	float Speed;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	ABP_Throwable_C* K2Node_ClassDynamicCast_AsBP_Throwable;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178[2];  // 0xB2(0x2)
	float CallFunc_MeleeSpeed_Hit_Delay;  // 0xB4(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue_2 : 1;  // 0xBC(0x1)
	char pad_189[3];  // 0xBD(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0xC0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0xC4(0x4)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201[3];  // 0xC9(0x3)
	float CallFunc_MeleeSpeed_Hit_Delay_2;  // 0xCC(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay_2;  // 0xD0(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_3;  // 0xD4(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0xD8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.DiscoverNewRecipe
// Size: 0x4(Inherited: 0x0) 
struct FDiscoverNewRecipe
{
	int32_t ItemId;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Client Drop Item
// Size: 0x4(Inherited: 0x0) 
struct FClient Drop Item
{
	int32_t Slot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerPickupAmmo
// Size: 0x98(Inherited: 0x0) 
struct FServerPickupAmmo
{
	struct ABP_ItemPickup_C* PickupActor;  // 0x0(0x8)
	struct FST_ItemBase Item;  // 0x8(0x90)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientOwnerEquip
// Size: 0x4(Inherited: 0x0) 
struct FClientOwnerEquip
{
	int32_t NewSlot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Actually Drop Item
// Size: 0x14(Inherited: 0x0) 
struct FServer Actually Drop Item
{
	int32_t invenotry slot;  // 0x0(0x4)
	struct FVector throw vector;  // 0x4(0xC)
	float Damage;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Pickup
// Size: 0x98(Inherited: 0x0) 
struct FServer Pickup
{
	struct ABP_ItemPickup_C* Pickup;  // 0x0(0x8)
	struct FST_ItemBase (Optional) Item Override;  // 0x8(0x90)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Equip Slot
// Size: 0x4(Inherited: 0x0) 
struct FEquip Slot
{
	int32_t Slot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetHeldDownSlotKeyIndex
// Size: 0xB2(Inherited: 0x0) 
struct FGetHeldDownSlotKeyIndex
{
	int32_t SlotIndex;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x10(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x38(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x48(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x54(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x58(0x8)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct UInputSettings* CallFunc_GetInputSettings_ReturnValue;  // 0x68(0x8)
	struct TArray<struct FInputActionKeyMapping> CallFunc_GetActionMappingByName_OutMappings;  // 0x70(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct FInputActionKeyMapping CallFunc_Array_Get_Item;  // 0x88(0x28)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_IsInputKeyDown_ReturnValue : 1;  // 0xB1(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Remove Item
// Size: 0x4(Inherited: 0x0) 
struct FServer Remove Item
{
	int32_t Slot;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.CanAiAttack
// Size: 0x6(Inherited: 0x0) 
struct FCanAiAttack
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Attack : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerPickupActor
// Size: 0x8(Inherited: 0x0) 
struct FServerPickupActor
{
	struct ABP_ItemPickup_C* Pickup;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.TickDarkZoneEffects
// Size: 0x36(Inherited: 0x0) 
struct FTickDarkZoneEffects
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Overlapping : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool InZone : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	struct TArray<struct ADarkZone_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x10(0x10)
	struct ADarkZone_C* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_OverlapVsPlayerCheck_Overlapping : 1;  // 0x2D(0x1)
	char pad_46_1 : 7;  // 0x2E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x2F(0x1)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x34(0x1)
	char pad_53_1 : 7;  // 0x35(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x35(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientCallOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FClientCallOnStopLook
{
	struct AActor* TargetActor;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Switch with pickup
// Size: 0x10(Inherited: 0x0) 
struct FServer Switch with pickup
{
	int32_t SlotIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ABP_ItemPickup_C* pickup Actor;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAnim
// Size: 0x24(Inherited: 0x0) 
struct FServerAnim
{
	int32_t initiator;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAnimSequenceBase* Asset;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	struct FName SlotNodeName;  // 0x18(0x8)
	float InPlayRate;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerBlock
// Size: 0x1(Inherited: 0x0) 
struct FServerBlock
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Blocking : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSlotAnim
// Size: 0x1E(Inherited: 0x0) 
struct FClientSlotAnim
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	float BlendInTime;  // 0x8(0x4)
	float BlendOutTime;  // 0xC(0x4)
	struct FName SlotName;  // 0x10(0x8)
	float InPlayRate;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Exclusive : 1;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool reliable : 1;  // 0x1D(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerShove
// Size: 0x8(Inherited: 0x0) 
struct FServerShove
{
	struct AActor* Hit;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStun
// Size: 0x15(Inherited: 0x0) 
struct FClientStun
{
	struct FVector Stun Location;  // 0x0(0xC)
	float Duration;  // 0xC(0x4)
	float KnockbackMultiplier;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ShortStun? : 1;  // 0x14(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MeleeAttack
// Size: 0x20(Inherited: 0x0) 
struct FMeleeAttack
{
	float BlendOutTime;  // 0x0(0x4)
	float BlendInTime;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Charging : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FString Validation;  // 0x10(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetDamageMultiplier
// Size: 0x4(Inherited: 0x0) 
struct FServerSetDamageMultiplier
{
	float DamageMultiplier;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerKeycardOpen
// Size: 0x8(Inherited: 0x0) 
struct FServerKeycardOpen
{
	struct AKeyCardReader_BP_C* reader;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetChargingServer
// Size: 0x1(Inherited: 0x0) 
struct FSetChargingServer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Charging : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStunEffects
// Size: 0x20(Inherited: 0x0) 
struct FMultiStunEffects
{
	struct FVector Location;  // 0x0(0xC)
	struct FVector Scale;  // 0xC(0xC)
	float VolumeMultiplier;  // 0x18(0x4)
	float PitchMultiplier;  // 0x1C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.BloodDecal
// Size: 0x50(Inherited: 0x0) 
struct FBloodDecal
{
	struct FName EventName;  // 0x0(0x8)
	float EmitterTime;  // 0x8(0x4)
	int32_t ParticleTime;  // 0xC(0x4)
	struct FVector Location;  // 0x10(0xC)
	struct FVector Velocity;  // 0x1C(0xC)
	struct FVector Direction;  // 0x28(0xC)
	struct FVector Normal;  // 0x34(0xC)
	struct FName BoneName;  // 0x40(0x8)
	struct UPhysicalMaterial* PhysMat;  // 0x48(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDynamiteExplodeInHands
// Size: 0x8(Inherited: 0x0) 
struct FServerDynamiteExplodeInHands
{
	float Intensity;  // 0x0(0x4)
	float Radius;  // 0x4(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AI_Block
// Size: 0x1(Inherited: 0x0) 
struct FAI_Block
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Blocking : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerChargeSound
// Size: 0x4(Inherited: 0x0) 
struct FServerChargeSound
{
	int32_t ID;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetConstDamageMultiplier
// Size: 0x4(Inherited: 0x0) 
struct FServerSetConstDamageMultiplier
{
	float ConstDamageMultiplier;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAnimReliable
// Size: 0x24(Inherited: 0x0) 
struct FServerAnimReliable
{
	int32_t initiator;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAnimSequenceBase* Asset;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	struct FName SlotNodeName;  // 0x18(0x8)
	float InPlayRate;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientHitsomeone
// Size: 0xD(Inherited: 0x0) 
struct FClientHitsomeone
{
	struct AFirstPersonCharacter_C* Hit;  // 0x0(0x8)
	float ResultingDamage;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CriticalHit : 1;  // 0xC(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerThrowDynamite
// Size: 0x40(Inherited: 0x0) 
struct FServerThrowDynamite
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	float Time;  // 0x30(0x4)
	struct FVector Launch;  // 0x34(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiAnimReliable
// Size: 0x24(Inherited: 0x0) 
struct FMultiAnimReliable
{
	int32_t initiator;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UAnimSequenceBase* Asset;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	struct FName SlotNodeName;  // 0x18(0x8)
	float InPlayRate;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiProjectile
// Size: 0x48(Inherited: 0x0) 
struct FMultiProjectile
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	struct APawn* Instigator;  // 0x30(0x8)
	float Damage;  // 0x38(0x4)
	int32_t ID;  // 0x3C(0x4)
	ABP_Projectile_C* Class;  // 0x40(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerMeleeHitEffects
// Size: 0x18(Inherited: 0x0) 
struct FServerMeleeHitEffects
{
	struct FVector Location;  // 0x0(0xC)
	struct FVector Scale;  // 0xC(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientBlurCurve
// Size: 0xC(Inherited: 0x0) 
struct FClientBlurCurve
{
	float Time;  // 0x0(0x4)
	float MaxIntensity;  // 0x4(0x4)
	float StartTime;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStartMeleeHit
// Size: 0x4(Inherited: 0x0) 
struct FClientStartMeleeHit
{
	float Distance;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStunEffects
// Size: 0x1C(Inherited: 0x0) 
struct FServerStunEffects
{
	struct FVector Location;  // 0x0(0xC)
	struct FVector Scale;  // 0xC(0xC)
	float VolumeMultiplier;  // 0x18(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDoMeleeHit
// Size: 0x30(Inherited: 0x0) 
struct FServerDoMeleeHit
{
	struct AFirstPersonCharacter_C* Attacker;  // 0x0(0x8)
	struct AFirstPersonCharacter_C* Target;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)
	struct FString Validation;  // 0x20(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.HandleIncomingDamage
// Size: 0x14F(Inherited: 0x0) 
struct FHandleIncomingDamage
{
	float Damage;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UDamageType* Type;  // 0x8(0x8)
	struct AActor* DamageCauser;  // 0x10(0x8)
	struct AGS_BR_C* GameState;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Headshot : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CausedByEnvironment : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	float InitialDamage;  // 0x24(0x4)
	struct AFirstPersonCharacter_C* Causer;  // 0x28(0x8)
	float FinalReceivedDamage;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UDamageType_Headshot_C* K2Node_DynamicCast_AsDamage_Type_Headshot;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UDmgTypeBP_Environmental_C* K2Node_DynamicCast_AsDmg_Type_BP_Environmental;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x60(0x1)
	char E_HitDirection Temp_byte_Variable;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct UAnimSequenceBase* Temp_object_Variable;  // 0x68(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_2;  // 0x70(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_3;  // 0x78(0x8)
	struct UAnimSequenceBase* Temp_object_Variable_4;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool Temp_bool_Variable : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	float Temp_float_Variable;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x92(0x1)
	char pad_147_1 : 7;  // 0x93(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x93(0x1)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x95(0x1)
	char pad_150[2];  // 0x96(0x2)
	float Temp_float_Variable_2;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue_2 : 1;  // 0x9C(0x1)
	char E_HitDirection CallFunc_GetHitDirection_Direction;  // 0x9D(0x1)
	char pad_158_1 : 7;  // 0x9E(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x9E(0x1)
	char pad_159[1];  // 0x9F(0x1)
	struct UAnimSequenceBase* K2Node_Select_Default;  // 0xA0(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool CallFunc_IsPlayingSlotAnimation_ReturnValue : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool CallFunc_IsPlayingSlotAnimation_ReturnValue_2 : 1;  // 0xB2(0x1)
	char pad_179_1 : 7;  // 0xB3(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xB3(0x1)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xB8(0xC)
	char pad_196[12];  // 0xC4(0xC)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0xD0(0x30)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x108(0x8)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x110(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x114(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x118(0xC)
	float K2Node_Select_Default_2;  // 0x124(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue_2;  // 0x128(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x12C(0x4)
	struct APlayerBRController_C* CallFunc_PC_pc_2;  // 0x130(0x8)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x138(0x4)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x13C(0x1)
	char pad_317[3];  // 0x13D(0x3)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x140(0x4)
	float K2Node_Select_Default_3;  // 0x144(0x4)
	float K2Node_Select_Default_4;  // 0x148(0x4)
	char pad_332_1 : 7;  // 0x14C(0x1)
	bool CallFunc_IsSimulatingPhysics_ReturnValue : 1;  // 0x14C(0x1)
	char pad_333_1 : 7;  // 0x14D(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x14D(0x1)
	char pad_334_1 : 7;  // 0x14E(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x14E(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.StartLoopedAnimation
// Size: 0x1C(Inherited: 0x0) 
struct FStartLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	float InPlayRate;  // 0x18(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.StopLoopedAnimation
// Size: 0x10(Inherited: 0x0) 
struct FStopLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnSuccess_C4A8050440B47C9C595135BBAA0CF89B
// Size: 0x8(Inherited: 0x0) 
struct FOnSuccess_C4A8050440B47C9C595135BBAA0CF89B
{
	struct UTexture2DDynamic* Texture;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStartShove
// Size: 0x4(Inherited: 0x0) 
struct FClientStartShove
{
	float Length;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnExplosion
// Size: 0x40(Inherited: 0x0) 
struct FServerSpawnExplosion
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	struct APawn* Instigator;  // 0x30(0x8)
	float Intensity;  // 0x38(0x4)
	float Radius;  // 0x3C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientHitSomeoneWithProjectile
// Size: 0x98(Inherited: 0x0) 
struct FClientHitSomeoneWithProjectile
{
	struct AFirstPersonCharacter_C* OtherPlayer;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool Headshot : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	float Damage;  // 0x94(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSpawnDynamite
// Size: 0x40(Inherited: 0x0) 
struct FServerSpawnDynamite
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	float Time;  // 0x30(0x4)
	struct FVector Launch;  // 0x34(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.WorkbenchOnlyRecipies
// Size: 0x74(Inherited: 0x0) 
struct FWorkbenchOnlyRecipies
{
	struct TArray<struct FST_CraftRecipe> Array;  // 0x0(0x10)
	struct TArray<struct FST_CraftRecipe> Out;  // 0x10(0x10)
	struct TArray<struct FST_CraftRecipe> Local;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FST_CraftRecipe CallFunc_Array_Get_Item;  // 0x40(0x28)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x6C(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x70(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.StartLongTrace
// Size: 0x8(Inherited: 0x0) 
struct FStartLongTrace
{
	float Time;  // 0x0(0x4)
	float Length;  // 0x4(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.DestroySkeletalMesh
// Size: 0x10(Inherited: 0x0) 
struct FDestroySkeletalMesh
{
	struct USkeletalMeshComponent* Mesh;  // 0x0(0x8)
	struct USkeletalMesh* Out;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Reload_K2Node_InputActionEvent_6
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Reload_K2Node_InputActionEvent_6
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddAmmoAndDestroyActor
// Size: 0x10(Inherited: 0x0) 
struct FServerAddAmmoAndDestroyActor
{
	int32_t Slot;  // 0x0(0x4)
	int32_t Ammo;  // 0x4(0x4)
	struct AActor* Actor;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Do Launch
// Size: 0xC(Inherited: 0x0) 
struct FDo Launch
{
	struct FVector LaunchVelocity;  // 0x0(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetMeleeChargePitch
// Size: 0x38(Inherited: 0x0) 
struct FGetMeleeChargePitch
{
	float Pitch;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CallFunc_MeleeSpeed_Hit_Delay;  // 0x8(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay;  // 0xC(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	UObject* K2Node_Select_Default;  // 0x18(0x8)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float CallFunc_MeleeSpeed_Hit_Delay_2;  // 0x2C(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay_2;  // 0x30(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue_2;  // 0x34(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientBloodSplatter
// Size: 0x18(Inherited: 0x0) 
struct FClientBloodSplatter
{
	struct FVector Location;  // 0x0(0xC)
	struct FVector Scale;  // 0xC(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStartLoopedAnimation
// Size: 0x1C(Inherited: 0x0) 
struct FClientStartLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	float InPlayRate;  // 0x18(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerStartLoopedAnimation
// Size: 0x20(Inherited: 0x0) 
struct FServerStartLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	float InPlayRate;  // 0x18(0x4)
	int32_t ID;  // 0x1C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStartLoopedAnimation
// Size: 0x20(Inherited: 0x0) 
struct FMultiStartLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)
	float BlendInTime;  // 0x10(0x4)
	float BlendOutTime;  // 0x14(0x4)
	float InPlayRate;  // 0x18(0x4)
	int32_t ID;  // 0x1C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.CheckObjectBlock
// Size: 0x15D(Inherited: 0x0) 
struct FCheckObjectBlock
{
	struct FVector HitLocation;  // 0x0(0xC)
	char pad_12[4];  // 0xC(0x4)
	struct AActor* Actor to ignore;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bLocked : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FHitResult OutHit;  // 0x1C(0x88)
	char pad_164[4];  // 0xA4(0x4)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0xA8(0x10)
	struct TArray<struct AActor*> K2Node_MakeArray_Array_2;  // 0xB8(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xC8(0xC)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0xD4(0x88)
	char pad_348_1 : 7;  // 0x15C(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x15C(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientStopLoopedAnimation
// Size: 0x10(Inherited: 0x0) 
struct FClientStopLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MultiStopLoopedAnimation
// Size: 0x14(Inherited: 0x0) 
struct FMultiStopLoopedAnimation
{
	struct UAnimSequenceBase* Asset;  // 0x0(0x8)
	struct FName SlotNodeName;  // 0x8(0x8)
	int32_t ID;  // 0x10(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Multi_Grab
// Size: 0x14(Inherited: 0x0) 
struct FMulti_Grab
{
	struct AMovable_Object_Replicated_C* Mesh;  // 0x0(0x8)
	struct FVector Teleport Loaction;  // 0x8(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server E press
// Size: 0x98(Inherited: 0x0) 
struct FServer E press
{
	struct FHitResult Hit;  // 0x0(0x88)
	int32_t InventorySlot;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	struct AActor* Target;  // 0x90(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Release_Server
// Size: 0x14(Inherited: 0x0) 
struct FRelease_Server
{
	struct AMovable_Object_Replicated_C* Prop;  // 0x0(0x8)
	struct FVector ThrowVector;  // 0x8(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientInteract
// Size: 0x1(Inherited: 0x0) 
struct FClientInteract
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Interact : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB385F9E8ED85
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB385F9E8ED85
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_CraftingMenu_K2Node_InputActionEvent_16
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_CraftingMenu_K2Node_InputActionEvent_16
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerInteract
// Size: 0x1(Inherited: 0x0) 
struct FServerInteract
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Interacting : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerAddMaterials_Dev
// Size: 0xC(Inherited: 0x0) 
struct FServerAddMaterials_Dev
{
	int32_t +wood;  // 0x0(0x4)
	int32_t +metal;  // 0x4(0x4)
	int32_t +binder;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnLanded_FallDamage
// Size: 0x88(Inherited: 0x0) 
struct FOnLanded_FallDamage
{
	struct FHitResult Hit;  // 0x0(0x88)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Crouch_K2Node_InputActionEvent_13
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Crouch_K2Node_InputActionEvent_13
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnFail_C4A8050440B47C9C595135BBAA0CF89B
// Size: 0x8(Inherited: 0x0) 
struct FOnFail_C4A8050440B47C9C595135BBAA0CF89B
{
	struct UTexture2DDynamic* Texture;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPlayFootstep
// Size: 0xA(Inherited: 0x0) 
struct FClientPlayFootstep
{
	float VolumeMultiplier;  // 0x0(0x4)
	float PitchMultiplier;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Priority : 1;  // 0x8(0x1)
	char EPhysicalSurface SurfaceType;  // 0x9(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientTryLoadMeatballLauncher
// Size: 0x8(Inherited: 0x0) 
struct FClientTryLoadMeatballLauncher
{
	struct ABP_ItemPickup_C* Pickup;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Can Attack
// Size: 0xF(Inherited: 0x0) 
struct FCan Attack
{
	float Attack delay Threshold;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Ignore Blocking? : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool Temp_bool_Variable : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool K2Node_Select_Default : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xE(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientPlayLocalAudio
// Size: 0xC(Inherited: 0x0) 
struct FClientPlayLocalAudio
{
	struct USoundBase* NewSound;  // 0x0(0x8)
	float fadeInDuration;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetHudVisibility
// Size: 0x1(Inherited: 0x0) 
struct FSetHudVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Index : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 4_K2Node_InputActionEvent_27
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 4_K2Node_InputActionEvent_27
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetGodMode
// Size: 0x1(Inherited: 0x0) 
struct FServerSetGodMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool GodMode : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnLanded
// Size: 0x88(Inherited: 0x88) 
struct FOnLanded : public FOnLanded
{
	struct FHitResult Hit;  // 0x0(0x88)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowProp_K2Node_InputActionEvent_14
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ThrowProp_K2Node_InputActionEvent_14
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ReceivePossessed
// Size: 0x8(Inherited: 0x8) 
struct FReceivePossessed : public FReceivePossessed
{
	struct AController* NewController;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.StartSlotSwitchTimer
// Size: 0x18(Inherited: 0x0) 
struct FStartSlotSwitchTimer
{
	struct FTimerHandle CallFunc_K2_InvalidateTimerHandle_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_K2_IsValidTimerHandle_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // 0x10(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnClientPossessed
// Size: 0x8(Inherited: 0x0) 
struct FOnClientPossessed
{
	struct APlayerBRController_C* PC;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetTeammateFromID
// Size: 0x10(Inherited: 0x0) 
struct FSetTeammateFromID
{
	struct FString ID;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Placable
// Size: 0x40(Inherited: 0x0) 
struct FServer Spawn Placable
{
	ABP_Placable_C* Class;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x30)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetSpineRotation
// Size: 0x4(Inherited: 0x0) 
struct FServerSetSpineRotation
{
	float SpineRotationX;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_193
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveRight_K2Node_InputAxisEvent_193
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_182
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveForward_K2Node_InputAxisEvent_182
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_173
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookUp_K2Node_InputAxisEvent_173
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ApplyFrenzyEffects
// Size: 0x238(Inherited: 0x0) 
struct FApplyFrenzyEffects
{
	float Duration;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FST_Effect CallFunc_EffectFromName_Effect;  // 0x8(0x38)
	struct FST_Effect CallFunc_EffectFromName_Effect_2;  // 0x40(0x38)
	struct FST_Effect K2Node_MakeStruct_ST_Effect;  // 0x78(0x38)
	struct FST_Effect K2Node_MakeStruct_ST_Effect_2;  // 0xB0(0x38)
	struct FST_Effect CallFunc_EffectFromName_Effect_3;  // 0xE8(0x38)
	struct FST_Effect CallFunc_EffectFromName_Effect_4;  // 0x120(0x38)
	struct FST_Effect K2Node_MakeStruct_ST_Effect_3;  // 0x158(0x38)
	struct FST_Effect K2Node_MakeStruct_ST_Effect_4;  // 0x190(0x38)
	struct FST_Effect CallFunc_EffectFromName_Effect_5;  // 0x1C8(0x38)
	struct FST_Effect K2Node_MakeStruct_ST_Effect_5;  // 0x200(0x38)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_158
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Turn_K2Node_InputAxisEvent_158
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerExplodeExplosiveArrow
// Size: 0x30(Inherited: 0x0) 
struct FServerExplodeExplosiveArrow
{
	struct FTransform ExplosiveArrow;  // 0x0(0x30)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Server Spawn Projectile And Remove Current Item
// Size: 0x50(Inherited: 0x0) 
struct FServer Spawn Projectile And Remove Current Item
{
	ABP_Projectile_C* Class;  // 0x0(0x8)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform SpawnTransform;  // 0x10(0x30)
	struct APawn* Instigator;  // 0x40(0x8)
	float Damage;  // 0x48(0x4)
	int32_t SlotIndex;  // 0x4C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingVampireEffectFromUpgrade
// Size: 0xC(Inherited: 0x0) 
struct FServerTryAddingVampireEffectFromUpgrade
{
	struct AFirstPersonCharacter_C* AttackedTarget;  // 0x0(0x8)
	float VampireScale;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingDrainEffectFromUpgrade
// Size: 0xC(Inherited: 0x0) 
struct FServerTryAddingDrainEffectFromUpgrade
{
	struct AFirstPersonCharacter_C* AttackedTarget;  // 0x0(0x8)
	float DrainScale;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB385958C1072
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB385958C1072
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerTryAddingBleedEffectFromUpgrade
// Size: 0xC(Inherited: 0x0) 
struct FServerTryAddingBleedEffectFromUpgrade
{
	struct AFirstPersonCharacter_C* AttackedTarget;  // 0x0(0x8)
	float BleedScale;  // 0x8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerDoDamageDev
// Size: 0x4(Inherited: 0x0) 
struct FServerDoDamageDev
{
	float BaseDamage;  // 0x0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowProp_K2Node_InputActionEvent_15
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ThrowProp_K2Node_InputActionEvent_15
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerHitByProjectile
// Size: 0xA0(Inherited: 0x0) 
struct FServerHitByProjectile
{
	struct AFirstPersonCharacter_C* Causer;  // 0x0(0x8)
	struct AFirstPersonCharacter_C* HitTarget;  // 0x8(0x8)
	struct FHitResult Hit;  // 0x10(0x88)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool Headshot : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	float Damage;  // 0x9C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerSetStun
// Size: 0x1(Inherited: 0x0) 
struct FServerSetStun
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Stun : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 6_K2Node_InputActionEvent_31
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 6_K2Node_InputActionEvent_31
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Spray_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Spray_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ClientSetStun
// Size: 0x1(Inherited: 0x0) 
struct FClientSetStun
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Stunned : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnStopLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ServerOnLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnChargeUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOnChargeUpdate
{
	float Charge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Caller;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnLook
// Size: 0x8(Inherited: 0x0) 
struct FOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnInteract
// Size: 0x94(Inherited: 0x0) 
struct FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoaded_FE24A16848CBD59DA5C1EA9AF9FCF33C
// Size: 0x8(Inherited: 0x0) 
struct FOnLoaded_FE24A16848CBD59DA5C1EA9AF9FCF33C
{
	struct UObject* Loaded;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnLoaded_AABEDF7046651F2141E4228B1A1613B1
// Size: 0x8(Inherited: 0x0) 
struct FOnLoaded_AABEDF7046651F2141E4228B1A1613B1
{
	struct UObject* Loaded;  // 0x0(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Attack_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Attack_K2Node_InputActionEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_VoiceChat_K2Node_InputActionEvent_7
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_VoiceChat_K2Node_InputActionEvent_7
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_VoiceChat_K2Node_InputActionEvent_8
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_VoiceChat_K2Node_InputActionEvent_8
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ToggleDevMode_K2Node_InputActionEvent_9
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ToggleDevMode_K2Node_InputActionEvent_9
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.DestroyStaticMesh
// Size: 0x10(Inherited: 0x0) 
struct FDestroyStaticMesh
{
	struct UStaticMeshComponent* Mesh;  // 0x0(0x8)
	struct UStaticMesh* Out;  // 0x8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_sprint_K2Node_InputActionEvent_19
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_sprint_K2Node_InputActionEvent_19
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ThrowWeapon_K2Node_InputActionEvent_11
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ThrowWeapon_K2Node_InputActionEvent_11
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Crouch_K2Node_InputActionEvent_12
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Crouch_K2Node_InputActionEvent_12
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_CraftingMenu_K2Node_InputActionEvent_17
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_CraftingMenu_K2Node_InputActionEvent_17
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.VerifyMaxMeleeRange
// Size: 0x11(Inherited: 0x0) 
struct FVerifyMaxMeleeRange
{
	struct AActor* Target;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_MouseScrollUp_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_MouseScrollUp_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_MouseScrollDown_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_MouseScrollDown_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 1_K2Node_InputActionEvent_21
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 1_K2Node_InputActionEvent_21
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 1_K2Node_InputActionEvent_22
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 1_K2Node_InputActionEvent_22
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 2_K2Node_InputActionEvent_24
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 2_K2Node_InputActionEvent_24
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 3_K2Node_InputActionEvent_25
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 3_K2Node_InputActionEvent_25
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 4_K2Node_InputActionEvent_28
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 4_K2Node_InputActionEvent_28
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_Inventory
// Size: 0x2(Inherited: 0x0) 
struct FOnRep_Inventory
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x1(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 5_K2Node_InputActionEvent_29
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 5_K2Node_InputActionEvent_29
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Slot 5_K2Node_InputActionEvent_30
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Slot 5_K2Node_InputActionEvent_30
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_block_K2Node_InputActionEvent_33
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_block_K2Node_InputActionEvent_33
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_block_K2Node_InputActionEvent_34
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_block_K2Node_InputActionEvent_34
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.FindItemInInventory
// Size: 0x15B(Inherited: 0x0) 
struct FFindItemInInventory
{
	struct FString Item Name;  // 0x0(0x10)
	int32_t Index;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FST_ItemBase Item;  // 0x18(0x90)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool found : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool Temp_bool_Whether_the_gate_is_currently_open_or_close_Variable : 1;  // 0xAA(0x1)
	char pad_171[1];  // 0xAB(0x1)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xAC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xBD(0x1)
	char pad_190[2];  // 0xBE(0x2)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC0(0x4)
	char pad_196[4];  // 0xC4(0x4)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0xC8(0x90)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x159(0x1)
	char pad_346_1 : 7;  // 0x15A(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x15A(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Shove_K2Node_InputActionEvent_36
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Shove_K2Node_InputActionEvent_36
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_37
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Attack_K2Node_InputActionEvent_37
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_38
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Attack_K2Node_InputActionEvent_38
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_39
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Attack_K2Node_InputActionEvent_39
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.MeshNames
// Size: 0x5C(Inherited: 0x0) 
struct FMeshNames
{
	struct TArray<struct FST_AttachedMesh> attached meshes;  // 0x0(0x10)
	struct TArray<struct FName> Names;  // 0x10(0x10)
	struct TArray<struct FName> Name;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x34(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FST_AttachedMesh CallFunc_Array_Get_Item;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[3];  // 0x51(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x54(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x58(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Attack_K2Node_InputActionEvent_40
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Attack_K2Node_InputActionEvent_40
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB3856319EF00
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB3856319EF00
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC73977101874C
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73977101874C
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_ToggleHUD_K2Node_InputActionEvent_41
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ToggleHUD_K2Node_InputActionEvent_41
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Text Chat_K2Node_InputActionEvent_42
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Text Chat_K2Node_InputActionEvent_42
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC7397EBF085C9
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC7397EBF085C9
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Interact_K2Node_InputActionEvent_43
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Interact_K2Node_InputActionEvent_43
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InpActEvt_Jump_K2Node_InputActionEvent_46
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Jump_K2Node_InputActionEvent_46
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC73977B02835F
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73977B02835F
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB385691AEB13
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB385691AEB13
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_215CB37D43646A0095BC739792E00CC9
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC739792E00CC9
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Completed_6F07F8864F50B817CAEDB38580F86485
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB38580F86485
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.LineTraceFromCamera
// Size: 0x179(Inherited: 0x0) 
struct FLineTraceFromCamera
{
	float Length;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<char EObjectTypeQuery> ObjectTypes;  // 0x8(0x10)
	struct USceneComponent* Camera;  // 0x18(0x8)
	struct FHitResult Hit;  // 0x20(0x88)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool Hit? : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0xB0(0x10)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xC0(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xCC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xD8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xE4(0xC)
	struct FHitResult CallFunc_LineTraceSingleForObjects_OutHit;  // 0xF0(0x88)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_LineTraceSingleForObjects_ReturnValue : 1;  // 0x178(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.FindIDininventory
// Size: 0x235(Inherited: 0x0) 
struct FFindIDininventory
{
	struct TArray<int32_t> ID;  // 0x0(0x10)
	struct TMap<int32_t, int32_t> Found ID's;  // 0x10(0x50)
	struct TArray<int32_t> Not Found ID's;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool Found? : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct TArray<int32_t> SI;  // 0x78(0x10)
	struct TArray<int32_t> NF;  // 0x88(0x10)
	struct TMap<int32_t, int32_t> F;  // 0x98(0x50)
	int32_t Temp_int_Array_Index_Variable;  // 0xE8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xEC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xF0(0x4)
	int32_t CallFunc_Map_Length_ReturnValue;  // 0xF4(0x4)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0xF8(0x1)
	char pad_249[7];  // 0xF9(0x7)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0x100(0x90)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x190(0x4)
	int32_t CallFunc_FindItemInInventory_index;  // 0x194(0x4)
	struct FST_ItemBase CallFunc_FindItemInInventory_item;  // 0x198(0x90)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_FindItemInInventory_Found : 1;  // 0x228(0x1)
	char pad_553_1 : 7;  // 0x229(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x229(0x1)
	char pad_554[2];  // 0x22A(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x22C(0x4)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x230(0x4)
	char pad_564_1 : 7;  // 0x234(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0x234(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AddCharge
// Size: 0xC0(Inherited: 0x0) 
struct FAddCharge
{
	float TimetoCharge;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Reverse : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Color on end : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float ColorChangeLevel;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString Tag;  // 0x10(0x10)
	struct UchargeBar_C* Widget;  // 0x20(0x8)
	struct FLinearColor Temp_struct_Variable;  // 0x28(0x10)
	struct FLinearColor Temp_struct_Variable_2;  // 0x38(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x48(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool Temp_bool_Variable : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x58(0x8)
	struct TArray<struct UchargeBar_C*> CallFunc_GetAllWidgetsOfClass_FoundWidgets;  // 0x60(0x10)
	struct FLinearColor K2Node_Select_Default;  // 0x70(0x10)
	struct UchargeBar_C* CallFunc_Array_Get_Item;  // 0x80(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct APlayerController* CallFunc_GetOwningPlayer_ReturnValue;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0xA0(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct UchargeBar_C* CallFunc_Create_ReturnValue;  // 0xB8(0x8)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.IsInteractableActorInFocus
// Size: 0xA(Inherited: 0x0) 
struct FIsInteractableActorInFocus
{
	struct AActor* InteractableActor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Value : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ShouldPlayhit
// Size: 0xA6(Inherited: 0x0) 
struct FShouldPlayhit
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Canplay : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x10(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x14(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // 0x20(0x10)
	struct FName CallFunc_Array_Get_Item;  // 0x30(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x38(0x8)
	struct FST_AnimSet CallFunc_GetDataTableRowFromName_OutRow;  // 0x40(0x48)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x88(0x1)
	char pad_137[3];  // 0x89(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_IsPlayingSlotAnimation_ReturnValue : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool CallFunc_IsPlayingSlotAnimation_ReturnValue_2 : 1;  // 0x92(0x1)
	char pad_147[5];  // 0x93(0x5)
	struct UAnimSequenceBase* CallFunc_Array_Get_Item_2;  // 0x98(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool CallFunc_IsPlayingSlotAnimation_ReturnValue_3 : 1;  // 0xA4(0x1)
	char pad_165_1 : 7;  // 0xA5(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xA5(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Item Anim Type
// Size: 0x95(Inherited: 0x0) 
struct FItem Anim Type
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	char E_AnimType Type;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool Temp_bool_Variable : 1;  // 0x91(0x1)
	char E_AnimType Temp_byte_Variable;  // 0x92(0x1)
	char pad_147_1 : 7;  // 0x93(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x93(0x1)
	char E_AnimType K2Node_Select_Default;  // 0x94(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ItemEquipped
// Size: 0x9A(Inherited: 0x0) 
struct FItemEquipped
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Bool : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0x8(0x90)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x99(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.HUD
// Size: 0x31(Inherited: 0x0) 
struct FHUD
{
	struct UBaseHUD_C* AsBase HUD;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Valid : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x10(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UBaseHUD_C* K2Node_DynamicCast_AsBase_HUD;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x30(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetAttachSlots
// Size: 0x1B4(Inherited: 0x0) 
struct FGetAttachSlots
{
	int32_t NewSlot;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FST_AttachedMesh> Meshes;  // 0x8(0x10)
	struct TArray<struct FST_AttachedMesh> Slot;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FName Temp_name_Variable;  // 0x2C(0x8)
	struct FName Temp_name_Variable_2;  // 0x34(0x8)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FName Temp_name_Variable_3;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FName Temp_name_Variable_4;  // 0x4C(0x8)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FName Temp_name_Variable_5;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	struct FName Temp_name_Variable_6;  // 0x64(0x8)
	struct FName Temp_name_Variable_7;  // 0x6C(0x8)
	struct FName Temp_name_Variable_8;  // 0x74(0x8)
	struct FName Temp_name_Variable_9;  // 0x7C(0x8)
	struct FName Temp_name_Variable_10;  // 0x84(0x8)
	struct FName Temp_name_Variable_11;  // 0x8C(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x94(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x98(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x9C(0x4)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct TArray<struct FName> CallFunc_MeshNames_names;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0xC0(0x90)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x150(0x4)
	char pad_340_1 : 7;  // 0x154(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x154(0x1)
	char pad_341_1 : 7;  // 0x155(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x155(0x1)
	char pad_342_1 : 7;  // 0x156(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x156(0x1)
	char pad_343_1 : 7;  // 0x157(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x157(0x1)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_Array_Contains_ReturnValue_3 : 1;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	struct FName K2Node_Select_Default;  // 0x15C(0x8)
	struct FName K2Node_Select_Default_2;  // 0x164(0x8)
	char pad_364_1 : 7;  // 0x16C(0x1)
	bool CallFunc_Array_Contains_ReturnValue_4 : 1;  // 0x16C(0x1)
	char pad_365[3];  // 0x16D(0x3)
	struct FName K2Node_Select_Default_3;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_Array_Contains_ReturnValue_5 : 1;  // 0x178(0x1)
	char pad_377[3];  // 0x179(0x3)
	struct FName K2Node_Select_Default_4;  // 0x17C(0x8)
	char pad_388_1 : 7;  // 0x184(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x184(0x1)
	char pad_389_1 : 7;  // 0x185(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x185(0x1)
	char pad_390[2];  // 0x186(0x2)
	struct FName K2Node_Select_Default_5;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x194(0x8)
	char pad_412_1 : 7;  // 0x19C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x19C(0x1)
	char pad_413[3];  // 0x19D(0x3)
	struct FST_AttachedMesh K2Node_MakeStruct_ST_AttachedMesh;  // 0x1A0(0x10)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x1B0(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Delay-Ping
// Size: 0x20(Inherited: 0x0) 
struct FDelay-Ping
{
	float Delay;  // 0x0(0x4)
	float Max -;  // 0x4(0x4)
	float Delay-Ping;  // 0x8(0x4)
	float CallFunc_Conv_ByteToFloat_ReturnValue;  // 0xC(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x10(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x14(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x18(0x4)
	float CallFunc_FClamp_ReturnValue_2;  // 0x1C(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetHitDirection
// Size: 0xC3(Inherited: 0x0) 
struct FGetHitDirection
{
	struct AFirstPersonCharacter_C* Hitter;  // 0x0(0x8)
	char E_HitDirection Direction;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xC(0xC)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x18(0x1)
	char E_HitDirection Temp_byte_Variable;  // 0x19(0x1)
	char E_HitDirection Temp_byte_Variable_2;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x1B(0x1)
	char E_HitDirection Temp_byte_Variable_3;  // 0x1C(0x1)
	char pad_29_1 : 7;  // 0x1D(0x1)
	bool Temp_bool_Variable_3 : 1;  // 0x1D(0x1)
	char E_HitDirection Temp_byte_Variable_4;  // 0x1E(0x1)
	char pad_31_1 : 7;  // 0x1F(0x1)
	bool Temp_bool_Variable_4 : 1;  // 0x1F(0x1)
	char E_HitDirection Temp_byte_Variable_5;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool Temp_bool_Variable_5 : 1;  // 0x21(0x1)
	char E_HitDirection Temp_byte_Variable_6;  // 0x22(0x1)
	char pad_35[1];  // 0x23(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x24(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x30(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x3C(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x48(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x54(0xC)
	struct FVector CallFunc_Normal_ReturnValue_2;  // 0x60(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_2;  // 0x6C(0xC)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // 0x78(0xC)
	struct FVector CallFunc_Normal_ReturnValue_3;  // 0x84(0xC)
	float CallFunc_BreakRotator_Roll;  // 0x90(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x94(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x98(0x4)
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue_2;  // 0x9C(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0xA8(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0xAC(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0xB0(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185_1 : 7;  // 0xB9(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue_2 : 1;  // 0xB9(0x1)
	char pad_186_1 : 7;  // 0xBA(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue_3 : 1;  // 0xBA(0x1)
	char pad_187_1 : 7;  // 0xBB(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue_4 : 1;  // 0xBB(0x1)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool CallFunc_InRange_FloatFloat_ReturnValue_5 : 1;  // 0xBD(0x1)
	char E_HitDirection K2Node_Select_Default;  // 0xBE(0x1)
	char E_HitDirection K2Node_Select_Default_2;  // 0xBF(0x1)
	char E_HitDirection K2Node_Select_Default_3;  // 0xC0(0x1)
	char E_HitDirection K2Node_Select_Default_4;  // 0xC1(0x1)
	char E_HitDirection K2Node_Select_Default_5;  // 0xC2(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.CanDoStuff
// Size: 0x7(Inherited: 0x0) 
struct FCanDoStuff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ? : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x6(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.PlayersInRadius
// Size: 0x1D9(Inherited: 0x0) 
struct FPlayersInRadius
{
	struct FVector Start;  // 0x0(0xC)
	float Radius;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Spectators? : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool Ignore Self? : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool Found? : 1;  // 0x12(0x1)
	char pad_19[5];  // 0x13(0x5)
	struct TArray<struct AFirstPersonCharacter_C*> Players;  // 0x18(0x10)
	struct TArray<struct ASpectatorPawn_C*> Spectactors;  // 0x28(0x10)
	struct TArray<struct ASpectatorPawn_C*> Spectactor;  // 0x38(0x10)
	struct TArray<struct AFirstPersonCharacter_C*> pl;  // 0x48(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x58(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x5C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x68(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	struct TArray<char EObjectTypeQuery> K2Node_MakeArray_Array;  // 0x80(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x90(0x4)
	char pad_148[4];  // 0x94(0x4)
	struct TArray<struct FHitResult> CallFunc_SphereTraceMultiForObjects_OutHits;  // 0x98(0x10)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_SphereTraceMultiForObjects_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0xAA(0x1)
	char pad_171[1];  // 0xAB(0x1)
	struct FHitResult CallFunc_Array_Get_Item;  // 0xAC(0x88)
	char pad_308_1 : 7;  // 0x134(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x134(0x1)
	char pad_309_1 : 7;  // 0x135(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x135(0x1)
	char pad_310[2];  // 0x136(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x138(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x13C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x140(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x14C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x158(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x164(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x170(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x178(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x180(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x188(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x190(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x194(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x198(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x19C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x1A8(0xC)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x1B4(0x4)
	struct ASpectatorPawn_C* K2Node_DynamicCast_AsSpectator_Pawn;  // 0x1B8(0x8)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1C0(0x1)
	char pad_449_1 : 7;  // 0x1C1(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1C1(0x1)
	char pad_450[2];  // 0x1C2(0x2)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x1C4(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1D0(0x1)
	char pad_465[3];  // 0x1D1(0x3)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0x1D4(0x4)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1D8(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_Cosmetics_Meshes
// Size: 0x10(Inherited: 0x0) 
struct FOnRep_Cosmetics_Meshes
{
	struct TArray<struct USceneComponent*> Existing;  // 0x0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.FindItemsInInventory
// Size: 0x162(Inherited: 0x0) 
struct FFindItemsInInventory
{
	struct FString Name;  // 0x0(0x10)
	struct TMap<int32_t, struct FST_ItemBase> Items;  // 0x10(0x50)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool Found? : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct TMap<int32_t, struct FST_ItemBase> I;  // 0x68(0x50)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool F : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0xBC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC4(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct FST_ItemBase CallFunc_Array_Get_Item;  // 0xD0(0x90)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x160(0x1)
	char pad_353_1 : 7;  // 0x161(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x161(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.ID
// Size: 0x24(Inherited: 0x0) 
struct FID
{
	int32_t ID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x8(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	int32_t CallFunc_GetPlayerControllerID_ReturnValue;  // 0x1C(0x4)
	int32_t CallFunc_SelectInt_ReturnValue;  // 0x20(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.F_CallOnLook
// Size: 0x69(Inherited: 0x0) 
struct FF_CallOnLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Start Look? : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Server : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UObject* Target;  // 0x8(0x8)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact_2;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact_3;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TScriptInterface<IBPI_Interact_C> K2Node_DynamicCast_AsBPI_Interact_4;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x68(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.NumOfSpectators
// Size: 0x49(Inherited: 0x0) 
struct FNumOfSpectators
{
	int32_t Num;  // 0x0(0x4)
	int32_t Count;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x14(0x4)
	struct TArray<struct AActor*> CallFunc_GetAttachedActors_OutActors;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct ASpectatorPawn* K2Node_DynamicCast_AsSpectator_Pawn;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.PC
// Size: 0x19(Inherited: 0x0) 
struct FPC
{
	struct APlayerBRController_C* PC;  // 0x0(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x8(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetSpineRotationX
// Size: 0x48(Inherited: 0x0) 
struct FGetSpineRotationX
{
	float X (Roll);  // 0x0(0x4)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x4(0xC)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	float CallFunc_BreakRotator_Roll;  // 0x14(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x18(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x1C(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x20(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x24(0xC)
	struct FRotator CallFunc_NegateRotator_ReturnValue;  // 0x30(0xC)
	float CallFunc_BreakRotator_Roll_2;  // 0x3C(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x40(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x44(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_GrabbedObject
// Size: 0x22(Inherited: 0x0) 
struct FOnRep_GrabbedObject
{
	struct USceneComponent* CallFunc_GetChildComponent_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	struct AMovable_Object_Replicated_C* K2Node_DynamicCast_AsMovable_Object_Replicated;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_ChampionMode
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_ChampionMode
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnGrabProp
// Size: 0x20(Inherited: 0x0) 
struct FOnGrabProp
{
	struct AMovable_Object_Replicated_C* Prop;  // 0x0(0x8)
	struct FVector Teleport Location;  // 0x8(0xC)
	struct FVector TempVelocity;  // 0x14(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InteractionTrace
// Size: 0x159(Inherited: 0x0) 
struct FInteractionTrace
{
	char ETraceTypeQuery TraceChannel;  // 0x0(0x1)
	char EDrawDebugTrace DrawDebugType;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FHitResult OutHit;  // 0x4(0x88)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool ReturnValue : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x90(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xA0(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xAC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xB8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xC4(0xC)
	struct FHitResult CallFunc_SphereTraceSingle_OutHit;  // 0xD0(0x88)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_SphereTraceSingle_ReturnValue : 1;  // 0x158(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Set Heartbeat Volume Tick
// Size: 0x2C(Inherited: 0x0) 
struct FSet Heartbeat Volume Tick
{
	struct APlayerBRController_C* CallFunc_PC_pc;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AAI_Bot_C* K2Node_DynamicCast_AsAI_Bot;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsLocalController_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[1];  // 0x1B(0x1)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x1C(0x4)
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // 0x20(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x24(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x28(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Add Death Impulse
// Size: 0x80(Inherited: 0x0) 
struct FAdd Death Impulse
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Temp_bool_Variable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FVector Temp_struct_Variable;  // 0x4(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x20(0xC)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_GetComponentVelocity_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x50(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x5C(0xC)
	struct FVector K2Node_Select_Default;  // 0x68(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x74(0xC)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.IsLookingAtActor
// Size: 0x185(Inherited: 0x0) 
struct FIsLookingAtActor
{
	struct AActor* Actor;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Looking : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Hit : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool Temp_bool_True_if_break_was_hit_Variable : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x14(0x4)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x18(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x2C(0xC)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x38(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x44(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x50(0xC)
	char pad_92[4];  // 0x5C(0x4)
	struct TArray<struct FHitResult> CallFunc_SphereTraceMulti_OutHits;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_SphereTraceMulti_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x74(0x4)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x7C(0x88)
	char pad_260_1 : 7;  // 0x104(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x104(0x1)
	char pad_261_1 : 7;  // 0x105(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x105(0x1)
	char pad_262_1 : 7;  // 0x106(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x106(0x1)
	char pad_263[1];  // 0x107(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x108(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x10C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x110(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x11C(0xC)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x128(0xC)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x134(0xC)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x140(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x148(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x150(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x158(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x160(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x164(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x168(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x16C(0xC)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x178(0xC)
	char pad_388_1 : 7;  // 0x184(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x184(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.InteractTrace
// Size: 0x159(Inherited: 0x0) 
struct FInteractTrace
{
	struct FHitResult OutHit;  // 0x0(0x88)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool ReturnValue : 1;  // 0x88(0x1)
	char pad_137[7];  // 0x89(0x7)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x90(0x10)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0xA0(0xC)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xAC(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xB8(0xC)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xC4(0xC)
	struct FHitResult CallFunc_SphereTraceSingle_OutHit;  // 0xD0(0x88)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_SphereTraceSingle_ReturnValue : 1;  // 0x158(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.GetTotalModifiedMaxSprintSpeed
// Size: 0x10(Inherited: 0x0) 
struct FGetTotalModifiedMaxSprintSpeed
{
	float ReturnValue;  // 0x0(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x8(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_3;  // 0xC(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetAttackDelayOnSwitchingSlots
// Size: 0xCC(Inherited: 0x0) 
struct FSetAttackDelayOnSwitchingSlots
{
	struct FST_ItemBase Item;  // 0x0(0x90)
	float + attack delay;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_ItemValid__Valid : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x95(0x1)
	char pad_150[2];  // 0x96(0x2)
	ABP_Throwable_C* K2Node_ClassDynamicCast_AsBP_Throwable;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	AWeaponBP_C* K2Node_ClassDynamicCast_AsWeapon_BP;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_ClassDynamicCast_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float CallFunc_MeleeSpeed_Hit_Delay;  // 0xB4(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay;  // 0xB8(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue;  // 0xBC(0x4)
	float CallFunc_Add_FloatFloat_ReturnValue_2;  // 0xC0(0x4)
	float CallFunc_MeleeSpeed_Hit_Delay_2;  // 0xC4(0x4)
	float CallFunc_MeleeSpeed_ChargeDelay_2;  // 0xC8(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.OnRep_Effects
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_Effects
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.Add Camera Sway
// Size: 0xC0(Inherited: 0x0) 
struct FAdd Camera Sway
{
	float CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x0(0x4)
	float CallFunc_FClamp_ReturnValue;  // 0x4(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x8(0x4)
	float CallFunc_BreakRotator_Roll;  // 0xC(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x10(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x14(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x18(0xC)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x24(0xC)
	struct FQuat CallFunc_Quat_MakeFromEuler_ReturnValue;  // 0x30(0x10)
	float CallFunc_BreakRotator_Roll_2;  // 0x40(0x4)
	float CallFunc_BreakRotator_Pitch_2;  // 0x44(0x4)
	float CallFunc_BreakRotator_Yaw_2;  // 0x48(0x4)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x4C(0xC)
	char pad_88[8];  // 0x58(0x8)
	struct FQuat CallFunc_Quat_MakeFromEuler_ReturnValue_2;  // 0x60(0x10)
	struct FQuat CallFunc_SlerpQuat_ReturnValue;  // 0x70(0x10)
	struct FQuat CallFunc_Quat_Inversed_ReturnValue;  // 0x80(0x10)
	struct FRotator CallFunc_Quat_Rotator_ReturnValue;  // 0x90(0xC)
	char pad_156[4];  // 0x9C(0x4)
	struct FQuat CallFunc_Multiply_QuatQuat_ReturnValue;  // 0xA0(0x10)
	struct FQuat CallFunc_Quat_Inversed_ReturnValue_2;  // 0xB0(0x10)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.SetStencilForMeshAndCosmetics
// Size: 0x39(Inherited: 0x0) 
struct FSetStencilForMeshAndCosmetics
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Render Custom Depth : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Stencil Value;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct USkeletalMeshComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct USkeletalMeshComponent* CallFunc_Array_Get_Item;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.RecieveServerLook
// Size: 0x1(Inherited: 0x0) 
struct FRecieveServerLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Recieve? : 1;  // 0x0(0x1)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AddStaticMesh
// Size: 0x4C(Inherited: 0x0) 
struct FAddStaticMesh
{
	struct FName Tag;  // 0x0(0x8)
	struct UStaticMeshComponent* Mesh;  // 0x8(0x8)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x40(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x48(0x4)

}; 
// Function FirstPersonCharacter.FirstPersonCharacter_C.AddSkeletalMesh
// Size: 0x4C(Inherited: 0x0) 
struct FAddSkeletalMesh
{
	struct FName Tag;  // 0x0(0x8)
	struct USkeletalMeshComponent* Mesh;  // 0x8(0x8)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	struct USkeletalMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x40(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x48(0x4)

}; 
