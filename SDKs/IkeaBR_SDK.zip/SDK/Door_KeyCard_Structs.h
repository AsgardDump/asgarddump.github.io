#pragma once 
#include "SDK.h" 
 
 
// Function Door_KeyCard.Door_KeyCard_C.ExecuteUbergraph_Door_KeyCard
// Size: 0x16C(Inherited: 0x0) 
struct FExecuteUbergraph_Door_KeyCard
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x4(0xC)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_4;  // 0x10(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x18(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0xA0(0x4)
	float K2Node_Event_Charge;  // 0xA4(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_3;  // 0xA8(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player_2;  // 0xB0(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player;  // 0xB8(0x8)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_opener;  // 0xC0(0x8)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0xC8(0x88)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_2;  // 0x150(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x158(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x160(0xC)

}; 
// Function Door_KeyCard.Door_KeyCard_C.OnLook
// Size: 0x8(Inherited: 0x0) 
struct FOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function Door_KeyCard.Door_KeyCard_C.OnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function Door_KeyCard.Door_KeyCard_C.ServerOnLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function Door_KeyCard.Door_KeyCard_C.ServerOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnStopLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function Door_KeyCard.Door_KeyCard_C.Open Server
// Size: 0x8(Inherited: 0x0) 
struct FOpen Server
{
	struct AFirstPersonCharacter_C* opener;  // 0x0(0x8)

}; 
// Function Door_KeyCard.Door_KeyCard_C.OnChargeUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOnChargeUpdate
{
	float Charge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Caller;  // 0x8(0x8)

}; 
// Function Door_KeyCard.Door_KeyCard_C.RecieveServerLook
// Size: 0x1(Inherited: 0x0) 
struct FRecieveServerLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Recieve? : 1;  // 0x0(0x1)

}; 
// Function Door_KeyCard.Door_KeyCard_C.OnInteract
// Size: 0x94(Inherited: 0x0) 
struct FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
