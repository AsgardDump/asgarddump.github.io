#pragma once 
#include "SDK.h" 
 
 
// Function BP_BearTrap.BP_BearTrap_C.OnChargeUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOnChargeUpdate
{
	float Charge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Caller;  // 0x8(0x8)

}; 
// Function BP_BearTrap.BP_BearTrap_C.ExecuteUbergraph_BP_BearTrap
// Size: 0x2A8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BearTrap
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x25(0x1)
	char pad_38_1 : 7;  // 0x26(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x26(0x1)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x27(0x1)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_4;  // 0x28(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x30(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_3;  // 0xC0(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_2;  // 0xC8(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player_2;  // 0xD0(0x8)
	struct AFirstPersonCharacter_C* K2Node_Event_Player;  // 0xD8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0xE0(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0xE8(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0xF0(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0xF8(0x4)
	char pad_252_1 : 7;  // 0xFC(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0xFC(0x1)
	char pad_253[3];  // 0xFD(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x100(0x88)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x190(0x1)
	char pad_401[3];  // 0x191(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x194(0x10)
	char pad_420_1 : 7;  // 0x1A4(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x1A4(0x1)
	char pad_421_1 : 7;  // 0x1A5(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue_2 : 1;  // 0x1A5(0x1)
	char pad_422_1 : 7;  // 0x1A6(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x1A6(0x1)
	char pad_423_1 : 7;  // 0x1A7(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1A7(0x1)
	struct AActor* K2Node_CustomEvent_DamagedActor;  // 0x1A8(0x8)
	float K2Node_CustomEvent_Damage;  // 0x1B0(0x4)
	char pad_436[4];  // 0x1B4(0x4)
	struct UDamageType* K2Node_CustomEvent_DamageType;  // 0x1B8(0x8)
	struct AController* K2Node_CustomEvent_InstigatedBy;  // 0x1C0(0x8)
	struct AActor* K2Node_CustomEvent_DamageCauser;  // 0x1C8(0x8)
	struct UDmgTypeBP_Environmental_C* K2Node_DynamicCast_AsDmg_Type_BP_Environmental;  // 0x1D0(0x8)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x1D8(0x1)
	char pad_473[7];  // 0x1D9(0x7)
	struct UDamageType_Explosion_C* K2Node_DynamicCast_AsDamage_Type_Explosion;  // 0x1E0(0x8)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1E8(0x1)
	char pad_489_1 : 7;  // 0x1E9(0x1)
	bool K2Node_CustomEvent_Down : 1;  // 0x1E9(0x1)
	char pad_490[2];  // 0x1EA(0x2)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x1EC(0xC)
	float K2Node_Event_DeltaSeconds;  // 0x1F8(0x4)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x1FC(0xC)
	struct FHitResult CallFunc_K2_SetActorLocation_SweepHitResult;  // 0x208(0x88)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool CallFunc_K2_SetActorLocation_ReturnValue : 1;  // 0x290(0x1)
	char pad_657_1 : 7;  // 0x291(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x291(0x1)
	char pad_658[2];  // 0x292(0x2)
	float K2Node_Event_Charge;  // 0x294(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x2A0(0x1)
	char pad_673[3];  // 0x2A1(0x3)
	float CallFunc_ApplyDamage_ReturnValue;  // 0x2A4(0x4)

}; 
// Function BP_BearTrap.BP_BearTrap_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_BearTrap.BP_BearTrap_C.ServerOnLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BP_BearTrap.BP_BearTrap_C.Damage
// Size: 0x28(Inherited: 0x0) 
struct FDamage
{
	struct AActor* DamagedActor;  // 0x0(0x8)
	float Damage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UDamageType* DamageType;  // 0x10(0x8)
	struct AController* InstigatedBy;  // 0x18(0x8)
	struct AActor* DamageCauser;  // 0x20(0x8)

}; 
// Function BP_BearTrap.BP_BearTrap_C.ServerOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnStopLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function BP_BearTrap.BP_BearTrap_C.LMB
// Size: 0x1(Inherited: 0x0) 
struct FLMB
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
// Function BP_BearTrap.BP_BearTrap_C.BndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FBndEvt__Box_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0x88)

}; 
// Function BP_BearTrap.BP_BearTrap_C.OnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function BP_BearTrap.BP_BearTrap_C.OnLook
// Size: 0x8(Inherited: 0x0) 
struct FOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function BP_BearTrap.BP_BearTrap_C.RecieveServerLook
// Size: 0x1(Inherited: 0x0) 
struct FRecieveServerLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Recieve? : 1;  // 0x0(0x1)

}; 
// Function BP_BearTrap.BP_BearTrap_C.OnInteract
// Size: 0x94(Inherited: 0x0) 
struct FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
