#pragma once 
#include "SDK.h" 
 
 
// Function BP_ItemPickup_Upgrade.BP_ItemPickup_Upgrade_C.OnInteract
// Size: 0x94(Inherited: 0x94) 
struct FOnInteract : public FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
// Function BP_ItemPickup_Upgrade.BP_ItemPickup_Upgrade_C.ExecuteUbergraph_BP_ItemPickup_Upgrade
// Size: 0xAA(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ItemPickup_Upgrade
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x8(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x10(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0x98(0x4)
	char pad_156[4];  // 0x9C(0x4)
	ABP_UpgradeItem_C* K2Node_ClassDynamicCast_AsBP_Upgrade_Item;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool K2Node_ClassDynamicCast_bSuccess : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xA9(0x1)

}; 
