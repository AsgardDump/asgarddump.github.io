#pragma once 
#include <ClassicChair_Structs.h>
 
 
 
// BlueprintGeneratedClass ClassicChair.ClassicChair_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AClassicChair_C : public AMovable_Object_Replicated_C
{

}; 



