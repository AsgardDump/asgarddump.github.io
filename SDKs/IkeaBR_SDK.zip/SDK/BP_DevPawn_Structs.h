#pragma once 
#include "SDK.h" 
 
 
// Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveRight_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_Turn_K2Node_InputAxisEvent_158
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_Turn_K2Node_InputAxisEvent_158
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_DevPawn.BP_DevPawn_C.ExecuteUbergraph_BP_DevPawn
// Size: 0x150(Inherited: 0x0) 
struct FExecuteUbergraph_BP_DevPawn
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x8(0x8)
	struct APlayerBRController_C* K2Node_DynamicCast_AsPlayer_BRController;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct AController* CallFunc_GetController_ReturnValue_2;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FKey K2Node_InputActionEvent_Key;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct AController* CallFunc_GetController_ReturnValue_3;  // 0x50(0x8)
	struct APlayerController* K2Node_DynamicCast_AsPlayer_Controller;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	float K2Node_InputAxisEvent_AxisValue_4;  // 0x64(0x4)
	float K2Node_InputAxisEvent_AxisValue_3;  // 0x68(0x4)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x6C(0x4)
	float K2Node_InputAxisEvent_AxisValue;  // 0x70(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x74(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue_2;  // 0x78(0x4)
	struct FVector CallFunc_GetActorRightVector_ReturnValue;  // 0x7C(0xC)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x88(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x94(0xC)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0xA0(0xC)
	float K2Node_Event_DeltaSeconds;  // 0xAC(0x4)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0xB0(0xC)
	struct FRotator CallFunc_RInterpTo_ReturnValue;  // 0xBC(0xC)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0xC8(0x88)

}; 
// Function BP_DevPawn.BP_DevPawn_C.InpActEvt_Debug_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Debug_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_DevPawn.BP_DevPawn_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveForward_K2Node_InputAxisEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_DevPawn.BP_DevPawn_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_173
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookUp_K2Node_InputAxisEvent_173
{
	float AxisValue;  // 0x0(0x4)

}; 
