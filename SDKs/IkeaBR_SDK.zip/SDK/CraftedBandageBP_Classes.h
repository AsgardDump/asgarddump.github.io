#pragma once 
#include <CraftedBandageBP_Structs.h>
 
 
 
// BlueprintGeneratedClass CraftedBandageBP.CraftedBandageBP_C
// Size: 0x2A8(Inherited: 0x2A8) 
struct ACraftedBandageBP_C : public AHealingItemBP_C
{

}; 



