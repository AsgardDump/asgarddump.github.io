#pragma once 
#include "SDK.h" 
 
 
// Function BP_SpawnZone.BP_SpawnZone_C.ExecuteUbergraph_BP_SpawnZone
// Size: 0x39(Inherited: 0x0) 
struct FExecuteUbergraph_BP_SpawnZone
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_CustomEvent_Enabled_ : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool K2Node_CustomEvent_Enabled : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct ABP_ROE_SpawnPawn_C* K2Node_CustomEvent_Player;  // 0x8(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x10(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x14(0x4)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UW_SpawnZone_C* K2Node_DynamicCast_AsW_Spawn_Zone;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function BP_SpawnZone.BP_SpawnZone_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_SpawnZone.BP_SpawnZone_C.OnPlayerSelectMe
// Size: 0x8(Inherited: 0x0) 
struct FOnPlayerSelectMe
{
	struct ABP_ROE_SpawnPawn_C* Player;  // 0x0(0x8)

}; 
// Function BP_SpawnZone.BP_SpawnZone_C.Set Enabled
// Size: 0x1(Inherited: 0x0) 
struct FSet Enabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled? : 1;  // 0x0(0x1)

}; 
// Function BP_SpawnZone.BP_SpawnZone_C.Client_OnRepEnabled
// Size: 0x1(Inherited: 0x0) 
struct FClient_OnRepEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)

}; 
// Function BP_SpawnZone.BP_SpawnZone_C.UserConstructionScript
// Size: 0x9(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_SpawnZone.BP_SpawnZone_C.IsUnavailable
// Size: 0x9(Inherited: 0x0) 
struct FIsUnavailable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // 0x8(0x1)

}; 
