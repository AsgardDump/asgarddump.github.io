#pragma once 
#include "SDK.h" 
 
 
// Function DistanceToTarget.DistanceToTarget_C.ExecuteUbergraph_DistanceToTarget
// Size: 0x41(Inherited: 0x0) 
struct FExecuteUbergraph_DistanceToTarget
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AAIController* K2Node_Event_OwnerController;  // 0x8(0x8)
	struct APawn* K2Node_Event_ControlledPawn;  // 0x10(0x8)
	struct AActor* K2Node_Event_OwnerActor;  // 0x18(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct UObject* CallFunc_GetBlackboardValueAsObject_ReturnValue;  // 0x28(0x8)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0x40(0x1)

}; 
// Function DistanceToTarget.DistanceToTarget_C.ReceiveTick
// Size: 0xC(Inherited: 0x10) 
struct FReceiveTick : public FReceiveTick
{
	struct AActor* OwnerActor;  // 0x0(0x8)
	float DeltaSeconds;  // 0x8(0x4)

}; 
// Function DistanceToTarget.DistanceToTarget_C.ReceiveActivationAI
// Size: 0x10(Inherited: 0x10) 
struct FReceiveActivationAI : public FReceiveActivationAI
{
	struct AAIController* OwnerController;  // 0x0(0x8)
	struct APawn* ControlledPawn;  // 0x8(0x8)

}; 
