#pragma once 
#include "SDK.h" 
 
 
// Function Cosmetics_Slot.Cosmetics_Slot_C.ExecuteUbergraph_Cosmetics_Slot
// Size: 0x1D9(Inherited: 0x0) 
struct FExecuteUbergraph_Cosmetics_Slot
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct USaveGame* Temp_object_Variable;  // 0x8(0x8)
	struct USaveGame* K2Node_CustomEvent_SaveGame;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_CustomEvent_bSuccess : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct USaveGame* Temp_object_Variable_2;  // 0x30(0x8)
	struct USlotSave_C* K2Node_DynamicCast_AsSlot_Save;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct TArray<struct FST_UndiscoveredItem> CallFunc_GetUndiscoveredItems_Items;  // 0x48(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x58(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct UTexture2D* K2Node_CustomEvent_OutTexture_2;  // 0x70(0x8)
	struct UTexture2D* K2Node_CustomEvent_OutTexture;  // 0x78(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x80(0x10)
	struct UTexture2D* Temp_object_Variable_3;  // 0x90(0x8)
	struct USlotSave_C* CallFunc_CreateSaveGameObject_ReturnValue;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct USaveGame* K2Node_CustomEvent_SaveGame_2;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool K2Node_CustomEvent_bSuccess_2 : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FSteamID CallFunc_GetSteamID_Pure_ReturnValue;  // 0xB8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0xC0(0x10)
	struct FString CallFunc_BreakSteamID_ReturnValue;  // 0xD0(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xE0(0x4)
	char pad_228[4];  // 0xE4(0x4)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncSaveGameToSlot_ReturnValue;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241_1 : 7;  // 0xF1(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xF1(0x1)
	char pad_242[2];  // 0xF2(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xF4(0x4)
	struct UAsyncActionHandleSaveGame* CallFunc_AsyncLoadGameFromSlot_ReturnValue;  // 0xF8(0x8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool CallFunc_DoesSaveGameExist_ReturnValue : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x101(0x1)
	char pad_258[2];  // 0x102(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x104(0x4)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct FST_UndiscoveredItem CallFunc_Array_Get_Item;  // 0x110(0x30)
	struct FSteamItemDef K2Node_MakeStruct_SteamItemDef;  // 0x140(0x4)
	char pad_324[4];  // 0x144(0x4)
	struct FString CallFunc_GetItemDefinitionProperty_Value;  // 0x148(0x10)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue : 1;  // 0x158(0x1)
	char pad_345[7];  // 0x159(0x7)
	struct UAsyncDownloadImageCustom* CallFunc_DownloadImageCustom_ReturnValue;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x168(0x1)
	char pad_361[3];  // 0x169(0x3)
	struct FSteamItemDef K2Node_MakeStruct_SteamItemDef_2;  // 0x16C(0x4)
	struct FString CallFunc_GetItemDefinitionProperty_Value_2;  // 0x170(0x10)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_GetItemDefinitionProperty_ReturnValue_2 : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR;  // 0x188(0x8)
	int32_t CallFunc_Conv_StringToInt_ReturnValue;  // 0x190(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x194(0x4)
	struct UGI_BR_C* CallFunc_GameInstance_AsGI_BR_2;  // 0x198(0x8)
	char CallFunc_Conv_IntToByte_ReturnValue;  // 0x1A0(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x1A1(0x1)
	char pad_418[6];  // 0x1A2(0x6)
	struct UTexture2D* CallFunc_Map_Find_Value;  // 0x1A8(0x8)
	char pad_432_1 : 7;  // 0x1B0(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x1B0(0x1)
	char pad_433[3];  // 0x1B1(0x3)
	struct FLinearColor CallFunc_TierColor_color;  // 0x1B4(0x10)
	char pad_452[4];  // 0x1C4(0x4)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x1C8(0x10)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x1D8(0x1)

}; 
// Function Cosmetics_Slot.Cosmetics_Slot_C.OnSuccess_7ADC3D684F3D9BE49544449342590BAB
// Size: 0x8(Inherited: 0x0) 
struct FOnSuccess_7ADC3D684F3D9BE49544449342590BAB
{
	struct UTexture2D* OutTexture;  // 0x0(0x8)

}; 
// Function Cosmetics_Slot.Cosmetics_Slot_C.OnFail_7ADC3D684F3D9BE49544449342590BAB
// Size: 0x8(Inherited: 0x0) 
struct FOnFail_7ADC3D684F3D9BE49544449342590BAB
{
	struct UTexture2D* OutTexture;  // 0x0(0x8)

}; 
// Function Cosmetics_Slot.Cosmetics_Slot_C.Completed_6F07F8864F50B817CAEDB3853D81CBEA
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_6F07F8864F50B817CAEDB3853D81CBEA
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function Cosmetics_Slot.Cosmetics_Slot_C.Completed_215CB37D43646A0095BC73972F99A3A6
// Size: 0x9(Inherited: 0x0) 
struct FCompleted_215CB37D43646A0095BC73972F99A3A6
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuccess : 1;  // 0x8(0x1)

}; 
// Function Cosmetics_Slot.Cosmetics_Slot_C.SlotName
// Size: 0x40(Inherited: 0x0) 
struct FSlotName
{
	struct FText ReturnValue;  // 0x0(0x18)
	struct FString CallFunc_GetEnumeratorUserFriendlyName_ReturnValue;  // 0x18(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x28(0x18)

}; 
// Function Cosmetics_Slot.Cosmetics_Slot_C.GetItemName
// Size: 0x60(Inherited: 0x0) 
struct FGetItemName
{
	struct FText ReturnValue;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Variable : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString Temp_string_Variable;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString K2Node_Select_Default;  // 0x38(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x48(0x18)

}; 
