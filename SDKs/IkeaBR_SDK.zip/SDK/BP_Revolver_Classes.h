#pragma once 
#include <BP_Revolver_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Revolver.BP_Revolver_C
// Size: 0x2A8(Inherited: 0x2A0) 
struct ABP_Revolver_C : public ABP_Throwable_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A0(0x8)

	void LMB(bool Down); // Function BP_Revolver.BP_Revolver_C.LMB
	void Equip(); // Function BP_Revolver.BP_Revolver_C.Equip
	void Unequip(); // Function BP_Revolver.BP_Revolver_C.Unequip
	void ExecuteUbergraph_BP_Revolver(int32_t EntryPoint); // Function BP_Revolver.BP_Revolver_C.ExecuteUbergraph_BP_Revolver
}; 



