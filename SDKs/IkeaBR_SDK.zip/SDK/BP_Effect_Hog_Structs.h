#pragma once 
#include "SDK.h" 
 
 
// Function BP_Effect_Hog.BP_Effect_Hog_C.ExecuteUbergraph_BP_Effect_Hog
// Size: 0x18(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Effect_Hog
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent;  // 0x8(0x8)
	struct AFirstPersonCharacter_C* CallFunc_GetParent_parent_2;  // 0x10(0x8)

}; 
