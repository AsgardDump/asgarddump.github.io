#pragma once 
#include <BlindScreen_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BlindScreen.BlindScreen_C
// Size: 0x278(Inherited: 0x260) 
struct UBlindScreen_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UImage* Image_41;  // 0x268(0x8)
	struct ABP_Effect_Blinded_C* BlindEffect;  // 0x270(0x8)

	struct FLinearColor GetColorAndOpacity_1(); // Function BlindScreen.BlindScreen_C.GetColorAndOpacity_1
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function BlindScreen.BlindScreen_C.Tick
	void ExecuteUbergraph_BlindScreen(int32_t EntryPoint); // Function BlindScreen.BlindScreen_C.ExecuteUbergraph_BlindScreen
}; 



