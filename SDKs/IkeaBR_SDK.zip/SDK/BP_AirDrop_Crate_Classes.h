#pragma once 
#include <BP_AirDrop_Crate_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AirDrop_Crate.BP_AirDrop_Crate_C
// Size: 0x2F0(Inherited: 0x220) 
struct ABP_AirDrop_Crate_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UBoxComponent* PropCollisionBox;  // 0x228(0x8)
	struct UReplicatedPhysics* ReplicatedPhysics;  // 0x230(0x8)
	struct UBoxComponent* Box;  // 0x238(0x8)
	struct UStaticMeshComponent* CraneHook;  // 0x240(0x8)
	struct UStaticMeshComponent* CeilingHole;  // 0x248(0x8)
	struct UAudioComponent* AirDrop_Cue;  // 0x250(0x8)
	struct UParticleSystemComponent* Smoke;  // 0x258(0x8)
	struct USpotLightComponent* SpotLight;  // 0x260(0x8)
	struct USceneComponent* itemspawn;  // 0x268(0x8)
	struct UCableComponent* Cable;  // 0x270(0x8)
	struct USceneComponent* Root;  // 0x278(0x8)
	struct UPointLightComponent* PointLight;  // 0x280(0x8)
	float descend_f_CFE6E6C641BADC92DC7053ADABDAD50D;  // 0x288(0x4)
	char ETimelineDirection descend__Direction_CFE6E6C641BADC92DC7053ADABDAD50D;  // 0x28C(0x1)
	char pad_653[3];  // 0x28D(0x3)
	struct UTimelineComponent* descend;  // 0x290(0x8)
	float TimeToGetDown;  // 0x298(0x4)
	char pad_668[4];  // 0x29C(0x4)
	ABP_FlyingItemsCrate_C* CrateClass;  // 0x2A0(0x8)
	struct FLinearColor Color;  // 0x2A8(0x10)
	struct UMaterialInstanceDynamic* Mat;  // 0x2B8(0x8)
	float drop distance;  // 0x2C0(0x4)
	char pad_708[4];  // 0x2C4(0x4)
	struct AItemsCrate_C* itemref;  // 0x2C8(0x8)
	struct FVector InitialLoc;  // 0x2D0(0xC)
	char pad_732_1 : 7;  // 0x2DC(0x1)
	bool Dropped : 1;  // 0x2DC(0x1)
	char pad_733_1 : 7;  // 0x2DD(0x1)
	bool FinshedDescend : 1;  // 0x2DD(0x1)
	char pad_734[2];  // 0x2DE(0x2)
	struct FRotator initialRot;  // 0x2E0(0xC)
	float MaxDescendDistance;  // 0x2EC(0x4)

	void OnRep_FinshedDescend(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.OnRep_FinshedDescend
	void OnRep_Dropped(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.OnRep_Dropped
	void UpdateHook(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.UpdateHook
	void UserConstructionScript(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.UserConstructionScript
	void descend__FinishedFunc(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.descend__FinishedFunc
	void descend__UpdateFunc(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.descend__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ReceiveBeginPlay
	void ServerDescend(float NewRate); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ServerDescend
	void ReceiveTick(float DeltaSeconds); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ReceiveTick
	void ReleaseCrate(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ReleaseCrate
	void Stop(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.Stop
	void Reverse(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.Reverse
	void ClientReleaseCrate(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ClientReleaseCrate
	void BndEvt__PropCollisionBox_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.BndEvt__PropCollisionBox_K2Node_ComponentBoundEvent_2_ComponentBeginOverlapSignature__DelegateSignature
	void CustomRelease(); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.CustomRelease
	void ExecuteUbergraph_BP_AirDrop_Crate(int32_t EntryPoint); // Function BP_AirDrop_Crate.BP_AirDrop_Crate_C.ExecuteUbergraph_BP_AirDrop_Crate
}; 



