#pragma once 
#include <BodyArmourBP_Structs.h>
 
 
 
// BlueprintGeneratedClass BodyArmourBP.BodyArmourBP_C
// Size: 0x281(Inherited: 0x281) 
struct ABodyArmourBP_C : public AArmourBP_C
{

}; 



