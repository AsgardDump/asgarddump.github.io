#pragma once 
#include <DamageType_Explosion_Structs.h>
 
 
 
// BlueprintGeneratedClass DamageType_Explosion.DamageType_Explosion_C
// Size: 0x40(Inherited: 0x40) 
struct UDamageType_Explosion_C : public UDmgTypeBP_Environmental_C
{

}; 



