#pragma once 
#include "SDK.h" 
 
 
// Function GarbagePile.GarbagePile_C.ExecuteUbergraph_GarbagePile
// Size: 0x15C(Inherited: 0x0) 
struct FExecuteUbergraph_GarbagePile
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0x8(0x10)
	float K2Node_Event_Charge;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_4;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_GreaterEqual_FloatFloat_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_3;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x3C(0xC)
	struct AFirstPersonCharacter_C* K2Node_Event_Player_2;  // 0x48(0x8)
	struct FString CallFunc_ReplaceInputsInText_OutText;  // 0x50(0x10)
	struct FString CallFunc_GetObjectName_ReturnValue_2;  // 0x60(0x10)
	struct FString CallFunc_GetObjectName_ReturnValue_3;  // 0x70(0x10)
	struct AFirstPersonCharacter_C* K2Node_Event_Player;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_IsInteractableActorInFocus_Value : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x89(0x1)
	char pad_138[6];  // 0x8A(0x6)
	struct AFirstPersonCharacter_C* K2Node_Event_caller_2;  // 0x90(0x8)
	struct FHitResult K2Node_Event_Hit;  // 0x98(0x88)
	int32_t K2Node_Event_InventorySlot;  // 0x120(0x4)
	char pad_292[4];  // 0x124(0x4)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct AFirstPersonCharacter_C* K2Node_Event_caller;  // 0x138(0x8)
	float CallFunc_Delay_Ping_delay_ping;  // 0x140(0x4)
	char pad_324_1 : 7;  // 0x144(0x1)
	bool CallFunc_IsInteractableActorInFocus_Value_2 : 1;  // 0x144(0x1)
	char pad_325[3];  // 0x145(0x3)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x148(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character_2;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x159(0x1)
	char pad_346_1 : 7;  // 0x15A(0x1)
	bool CallFunc_IsInteractableActorInFocus_Value_3 : 1;  // 0x15A(0x1)
	char pad_347_1 : 7;  // 0x15B(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x15B(0x1)

}; 
// Function GarbagePile.GarbagePile_C.OnLook
// Size: 0x8(Inherited: 0x0) 
struct FOnLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function GarbagePile.GarbagePile_C.OnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FOnStopLook
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)

}; 
// Function GarbagePile.GarbagePile_C.RecieveServerLook
// Size: 0x1(Inherited: 0x0) 
struct FRecieveServerLook
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Recieve? : 1;  // 0x0(0x1)

}; 
// Function GarbagePile.GarbagePile_C.OnInteract
// Size: 0x94(Inherited: 0x0) 
struct FOnInteract
{
	struct AFirstPersonCharacter_C* Caller;  // 0x0(0x8)
	struct FHitResult Hit;  // 0x8(0x88)
	int32_t InventorySlot;  // 0x90(0x4)

}; 
// Function GarbagePile.GarbagePile_C.ServerOnStopLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnStopLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function GarbagePile.GarbagePile_C.ServerOnLook
// Size: 0x8(Inherited: 0x0) 
struct FServerOnLook
{
	struct AFirstPersonCharacter_C* Player;  // 0x0(0x8)

}; 
// Function GarbagePile.GarbagePile_C.OnChargeUpdate
// Size: 0x10(Inherited: 0x0) 
struct FOnChargeUpdate
{
	float Charge;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AFirstPersonCharacter_C* Caller;  // 0x8(0x8)

}; 
