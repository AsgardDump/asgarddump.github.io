#pragma once 
#include <DB_Recipie_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass DB_Recipie.DB_Recipie_C
// Size: 0x2B1(Inherited: 0x260) 
struct UDB_Recipie_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UDB_ItemCost_C* DB_ItemCost;  // 0x268(0x8)
	struct UImage* Image_102;  // 0x270(0x8)
	struct UImage* Image_108;  // 0x278(0x8)
	struct URR_Text_C* ItemName;  // 0x280(0x8)
	struct URR_Border_Plain_C* RR_Border_Plain_C_2;  // 0x288(0x8)
	struct URR_Button_C* RR_Button_C_2;  // 0x290(0x8)
	struct UW_NewNotification_C* W_NewNotification;  // 0x298(0x8)
	struct UDefaultBlueprints_C* Parent;  // 0x2A0(0x8)
	int32_t Recipe;  // 0x2A8(0x4)
	int32_t Index;  // 0x2AC(0x4)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool Enabled : 1;  // 0x2B0(0x1)

	struct FText Get_ItemName_Text_1(); // Function DB_Recipie.DB_Recipie_C.Get_ItemName_Text_1
	bool GetbIsEnabled_1(); // Function DB_Recipie.DB_Recipie_C.GetbIsEnabled_1
	struct FSlateBrush GetBrush_1(); // Function DB_Recipie.DB_Recipie_C.GetBrush_1
	void Completed_215CB37D43646A0095BC739773FE2E90(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Recipie.DB_Recipie_C.Completed_215CB37D43646A0095BC739773FE2E90
	void Completed_6F07F8864F50B817CAEDB38592B1E64B(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Recipie.DB_Recipie_C.Completed_6F07F8864F50B817CAEDB38592B1E64B
	void Completed_215CB37D43646A0095BC739780A98E07(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Recipie.DB_Recipie_C.Completed_215CB37D43646A0095BC739780A98E07
	void Completed_0914B3504C491F3C20AD179670FD4FF1(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Recipie.DB_Recipie_C.Completed_0914B3504C491F3C20AD179670FD4FF1
	void Completed_6F07F8864F50B817CAEDB38561E646DC(struct USaveGame* SaveGame, bool bSuccess); // Function DB_Recipie.DB_Recipie_C.Completed_6F07F8864F50B817CAEDB38561E646DC
	void BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature(); // Function DB_Recipie.DB_Recipie_C.BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_0_OnButtonClickedEvent__DelegateSignature
	void Construct(); // Function DB_Recipie.DB_Recipie_C.Construct
	void BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature(); // Function DB_Recipie.DB_Recipie_C.BndEvt__RR_Button_C_1_K2Node_ComponentBoundEvent_1_OnButtonHoverEvent__DelegateSignature
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function DB_Recipie.DB_Recipie_C.Tick
	void ExecuteUbergraph_DB_Recipie(int32_t EntryPoint); // Function DB_Recipie.DB_Recipie_C.ExecuteUbergraph_DB_Recipie
}; 



