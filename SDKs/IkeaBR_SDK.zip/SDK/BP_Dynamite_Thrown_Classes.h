#pragma once 
#include <BP_Dynamite_Thrown_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Dynamite_Thrown.BP_Dynamite_Thrown_C
// Size: 0x250(Inherited: 0x220) 
struct ABP_Dynamite_Thrown_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x228(0x8)
	struct UAudioComponent* Audio;  // 0x230(0x8)
	struct UParticleSystemComponent* ParticleSystem1;  // 0x238(0x8)
	float Time;  // 0x240(0x4)
	struct FVector Launch;  // 0x244(0xC)

	void ReceiveBeginPlay(); // Function BP_Dynamite_Thrown.BP_Dynamite_Thrown_C.ReceiveBeginPlay
	void MutliStart(struct FVector Impulse, float B); // Function BP_Dynamite_Thrown.BP_Dynamite_Thrown_C.MutliStart
	void BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Dynamite_Thrown.BP_Dynamite_Thrown_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void ExecuteUbergraph_BP_Dynamite_Thrown(int32_t EntryPoint); // Function BP_Dynamite_Thrown.BP_Dynamite_Thrown_C.ExecuteUbergraph_BP_Dynamite_Thrown
}; 



