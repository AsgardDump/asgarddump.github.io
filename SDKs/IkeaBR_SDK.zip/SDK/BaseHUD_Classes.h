#pragma once 
#include <BaseHUD_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BaseHUD.BaseHUD_C
// Size: 0x4A0(Inherited: 0x260) 
struct UBaseHUD_C : public UUserWidget
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x260(0x8)
	struct UWidgetAnimation* AlertAnim;  // 0x268(0x8)
	struct UWidgetAnimation* Recoil;  // 0x270(0x8)
	struct UWidgetAnimation* InjectorVignette;  // 0x278(0x8)
	struct UWidgetAnimation* BloodVignette;  // 0x280(0x8)
	struct UWidgetAnimation* ShowItemName;  // 0x288(0x8)
	struct UTextBlock* AlertText;  // 0x290(0x8)
	struct UImage* Blood;  // 0x298(0x8)
	struct UVerticalBox* BlueprintDiscoveryBox;  // 0x2A0(0x8)
	struct UUniformGridPanel* BlueprintProgressBox;  // 0x2A8(0x8)
	struct UImage* ChampionModeIcon;  // 0x2B0(0x8)
	struct USizeBox* Cost_size;  // 0x2B8(0x8)
	struct UHorizontalBox* Costs;  // 0x2C0(0x8)
	struct USizeBox* Crosshair;  // 0x2C8(0x8)
	struct UHorizontalBox* EffectBar;  // 0x2D0(0x8)
	struct UImage* Image;  // 0x2D8(0x8)
	struct UImage* Image_2;  // 0x2E0(0x8)
	struct UImage* Image_3;  // 0x2E8(0x8)
	struct UImage* Image_4;  // 0x2F0(0x8)
	struct UImage* Image_5;  // 0x2F8(0x8)
	struct UImage* Image_6;  // 0x300(0x8)
	struct UImage* Image_7;  // 0x308(0x8)
	struct UImage* Image_107;  // 0x310(0x8)
	struct UImage* Image_112;  // 0x318(0x8)
	struct UImage* Image_125;  // 0x320(0x8)
	struct UImage* Image_134;  // 0x328(0x8)
	struct UImage* Image_180;  // 0x330(0x8)
	struct UImage* Image_320;  // 0x338(0x8)
	struct UWidgetSwitcher* Item;  // 0x340(0x8)
	struct UItemBox_C* ItemBox;  // 0x348(0x8)
	struct UItemBox_C* ItemBox_2;  // 0x350(0x8)
	struct UItemBox_C* ItemBox_3;  // 0x358(0x8)
	struct UItemBox_C* ItemBox_4;  // 0x360(0x8)
	struct UItemBox_C* ItemBox_5;  // 0x368(0x8)
	struct UItemBox_C* ItemBox_6;  // 0x370(0x8)
	struct URR_Border_C* ItemDescription;  // 0x378(0x8)
	struct UVerticalBox* KillFeed;  // 0x380(0x8)
	struct UImage* MeleeCrosshair;  // 0x388(0x8)
	struct UProgressBar* MicProgressBar;  // 0x390(0x8)
	struct UScrollBox* Notifications;  // 0x398(0x8)
	struct UScrollBox* Notify;  // 0x3A0(0x8)
	struct UImage* PickupNorification;  // 0x3A8(0x8)
	struct UTextBlock* Ping;  // 0x3B0(0x8)
	struct UPlayerInfo_Pure_C* PlayerInfo_Pure;  // 0x3B8(0x8)
	struct UProgressBar* ProgressBar_81;  // 0x3C0(0x8)
	struct URR_ProgressBar_Plain_C* RR_ProgressBar_Plain_C_1;  // 0x3C8(0x8)
	struct URR_ProgressBar_Plain_C* RR_ProgressBar_Plain_C_2;  // 0x3D0(0x8)
	struct URR_ProgressBar_Plain_C* RR_ProgressBar_Plain_C_3;  // 0x3D8(0x8)
	struct URR_ProgressBar_Plain_C* RR_ProgressBar_Plain_C_4;  // 0x3E0(0x8)
	struct URR_Text_C* RR_Text_C_96;  // 0x3E8(0x8)
	struct URR_ProgressBar_Plain_C* Stamina;  // 0x3F0(0x8)
	struct UImage* StaminaIcon;  // 0x3F8(0x8)
	struct UTextBlock* SubTip;  // 0x400(0x8)
	struct UTextBlock* TextBlock;  // 0x408(0x8)
	struct UTextBlock* TextBlock_6;  // 0x410(0x8)
	struct UTextBlock* TextBlock_7;  // 0x418(0x8)
	struct UTextBlock* TextBlock_8;  // 0x420(0x8)
	struct UTextBlock* TextBlock_9;  // 0x428(0x8)
	struct UTextBlock* TextBlock_56;  // 0x430(0x8)
	struct UTextBlock* TextBlock_66;  // 0x438(0x8)
	struct UTextBlock* TextBlock_82;  // 0x440(0x8)
	struct UTextBlock* TextBlock_104;  // 0x448(0x8)
	struct UTextBlock* TextBlock_111;  // 0x450(0x8)
	struct UTextBlock* TextBlock_160;  // 0x458(0x8)
	struct UTextBlock* TextBlock_247;  // 0x460(0x8)
	struct UTextChat_C* TextChat;  // 0x468(0x8)
	struct UTextBlock* Time;  // 0x470(0x8)
	struct UTextBlock* Tooltip;  // 0x478(0x8)
	struct UImage* Vingette;  // 0x480(0x8)
	struct UW_HUD_Compass_C* W_HUD_Compass;  // 0x488(0x8)
	struct UW_HUD_RP_C* W_HUD_RP;  // 0x490(0x8)
	struct AFirstPersonCharacter_C* Owner;  // 0x498(0x8)

	uint8_t  Get_MicProgressBar_Visibility_1(); // Function BaseHUD.BaseHUD_C.Get_MicProgressBar_Visibility_1
	float Get_MicProgressBar_Percent_1(); // Function BaseHUD.BaseHUD_C.Get_MicProgressBar_Percent_1
	uint8_t  Get_ChampionModeIcon_Visibility_1(); // Function BaseHUD.BaseHUD_C.Get_ChampionModeIcon_Visibility_1
	bool Get_ChampionModeIcon_bIsEnabled_1(); // Function BaseHUD.BaseHUD_C.Get_ChampionModeIcon_bIsEnabled_1
	uint8_t  VisibleIfThereAreSpectators(); // Function BaseHUD.BaseHUD_C.VisibleIfThereAreSpectators
	struct FText GetSpectatorCount(); // Function BaseHUD.BaseHUD_C.GetSpectatorCount
	struct FText GetTeammateName(); // Function BaseHUD.BaseHUD_C.GetTeammateName
	struct FLinearColor GetMicBrush(); // Function BaseHUD.BaseHUD_C.GetMicBrush
	struct FText GetGameTimeClock(); // Function BaseHUD.BaseHUD_C.GetGameTimeClock
	uint8_t  Get_Crosshair_Visibility_1(); // Function BaseHUD.BaseHUD_C.Get_Crosshair_Visibility_1
	uint8_t  VisibleIfRanged(); // Function BaseHUD.BaseHUD_C.VisibleIfRanged
	struct FText GetItemDescription(); // Function BaseHUD.BaseHUD_C.GetItemDescription
	struct FText GetStaminaText(); // Function BaseHUD.BaseHUD_C.GetStaminaText
	struct FText GetDrainText(); // Function BaseHUD.BaseHUD_C.GetDrainText
	struct FText GetSpeedText(); // Function BaseHUD.BaseHUD_C.GetSpeedText
	struct FText GetDamageText(); // Function BaseHUD.BaseHUD_C.GetDamageText
	float GetArmorHealth(); // Function BaseHUD.BaseHUD_C.GetArmorHealth
	float GetDrainPercent(); // Function BaseHUD.BaseHUD_C.GetDrainPercent
	float GetWeaponSpeedPercent(); // Function BaseHUD.BaseHUD_C.GetWeaponSpeedPercent
	float GetWeaponDamagePercent(); // Function BaseHUD.BaseHUD_C.GetWeaponDamagePercent
	struct FText GetItemName(); // Function BaseHUD.BaseHUD_C.GetItemName
	uint8_t  Get_ItemDescription_Visibility(); // Function BaseHUD.BaseHUD_C.Get_ItemDescription_Visibility
	struct FText GetKills(); // Function BaseHUD.BaseHUD_C.GetKills
	struct FText GetNumAlive(); // Function BaseHUD.BaseHUD_C.GetNumAlive
	struct FText GetPing(); // Function BaseHUD.BaseHUD_C.GetPing
	float Get_Stamina_Percent(); // Function BaseHUD.BaseHUD_C.Get_Stamina_Percent
	struct FText GetHealthText(); // Function BaseHUD.BaseHUD_C.GetHealthText
	float GetHealthBarPercent(); // Function BaseHUD.BaseHUD_C.GetHealthBarPercent
	void ShowToolTip(struct FText InText, struct FText SubText); // Function BaseHUD.BaseHUD_C.ShowToolTip
	void HideToolTip(); // Function BaseHUD.BaseHUD_C.HideToolTip
	void ItemNotify(struct FText Text1, struct FText Text2, struct UTexture2D* Image, struct UTexture2D* Image2); // Function BaseHUD.BaseHUD_C.ItemNotify
	void Damage(float Health); // Function BaseHUD.BaseHUD_C.Damage
	void Add Effect(struct ABP_Effect_C* Effect); // Function BaseHUD.BaseHUD_C.Add Effect
	void CanCraftNotify(int32_t +wood, int32_t +metal, int32_t +binder); // Function BaseHUD.BaseHUD_C.CanCraftNotify
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function BaseHUD.BaseHUD_C.Tick
	void Construct(); // Function BaseHUD.BaseHUD_C.Construct
	void AddUpgrade(int32_t Slot, struct FST_Upgrade Upgrade); // Function BaseHUD.BaseHUD_C.AddUpgrade
	void ShowKill(struct FString KIller, struct FString Killed); // Function BaseHUD.BaseHUD_C.ShowKill
	void StimVignette(struct FLinearColor Color); // Function BaseHUD.BaseHUD_C.StimVignette
	void PropNotify(bool pickup?); // Function BaseHUD.BaseHUD_C.PropNotify
	void Alert(struct FText InText, struct FLinearColor Specified Color); // Function BaseHUD.BaseHUD_C.Alert
	void Equip(int32_t NewSlot); // Function BaseHUD.BaseHUD_C.Equip
	void BlueprintProgress(); // Function BaseHUD.BaseHUD_C.BlueprintProgress
	void SetTextChatVisbility(); // Function BaseHUD.BaseHUD_C.SetTextChatVisbility
	void OnDiscoverNewRecipe(int32_t RecipeID); // Function BaseHUD.BaseHUD_C.OnDiscoverNewRecipe
	void ExecuteUbergraph_BaseHUD(int32_t EntryPoint); // Function BaseHUD.BaseHUD_C.ExecuteUbergraph_BaseHUD
}; 



