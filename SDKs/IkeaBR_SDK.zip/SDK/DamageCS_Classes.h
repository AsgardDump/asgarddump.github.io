#pragma once 
#include <DamageCS_Structs.h>
 
 
 
// BlueprintGeneratedClass DamageCS.DamageCS_C
// Size: 0x1B0(Inherited: 0x1B0) 
struct UDamageCS_C : public UMatineeCameraShake
{

}; 



