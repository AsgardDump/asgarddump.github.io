#pragma once 
#include <AI_Bot_Structs.h>
 
 
 
// BlueprintGeneratedClass AI_Bot.AI_Bot_C
// Size: 0x1658(Inherited: 0x15C0) 
struct AAI_Bot_C : public AFirstPersonCharacter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x15C0(0x8)
	struct FST_ItemBase WeaponID;  // 0x15C8(0x90)

	void OnRep_WeaponID(); // Function AI_Bot.AI_Bot_C.OnRep_WeaponID
	void ReceiveBeginPlay(); // Function AI_Bot.AI_Bot_C.ReceiveBeginPlay
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function AI_Bot.AI_Bot_C.ReceiveAnyDamage
	void ExecuteUbergraph_AI_Bot(int32_t EntryPoint); // Function AI_Bot.AI_Bot_C.ExecuteUbergraph_AI_Bot
}; 



