#pragma once 
#include "SDK.h" 
 
 
// Function Backpack_BP.Backpack_BP_C.ExecuteUbergraph_Backpack_BP
// Size: 0x29(Inherited: 0x0) 
struct FExecuteUbergraph_Backpack_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UchargeBar_C* CallFunc_AddCharge_widget;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_Event_Down : 1;  // 0x28(0x1)

}; 
// Function Backpack_BP.Backpack_BP_C.LMB
// Size: 0x1(Inherited: 0x1) 
struct FLMB : public FLMB
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Down : 1;  // 0x0(0x1)

}; 
