#pragma once 
#include "SDK.h" 
 
 
// Function DarxUtilActor.DarxUtilActor_C.DestroyStaticMesh
// Size: 0x8(Inherited: 0x0) 
struct FDestroyStaticMesh
{
	struct UStaticMeshComponent* Mesh;  // 0x0(0x8)

}; 
// Function DarxUtilActor.DarxUtilActor_C.CreateStaticMesh
// Size: 0x48(Inherited: 0x0) 
struct FCreateStaticMesh
{
	struct AActor* Parent;  // 0x0(0x8)
	struct UStaticMeshComponent* ReturnValue;  // 0x8(0x8)
	struct FTransform Temp_struct_Variable;  // 0x10(0x30)
	struct UStaticMeshComponent* CallFunc_AddComponent_ReturnValue;  // 0x40(0x8)

}; 
