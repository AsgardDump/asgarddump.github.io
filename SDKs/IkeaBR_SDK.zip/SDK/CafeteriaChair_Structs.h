#pragma once 
#include "SDK.h" 
 
 
// Function CafeteriaChair.CafeteriaChair_C.ExecuteUbergraph_CafeteriaChair
// Size: 0x160(Inherited: 0x0) 
struct FExecuteUbergraph_CafeteriaChair
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0x4(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x8(0xC)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0x14(0xC)
	struct FHitResult CallFunc_K2_AddWorldRotation_SweepHitResult;  // 0x20(0x88)
	float CallFunc_Dot_VectorVector_ReturnValue;  // 0xA8(0x4)
	struct FVector CallFunc_RandomUnitVector_ReturnValue;  // 0xAC(0xC)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	float CallFunc_RandomFloatInRange_ReturnValue_2;  // 0xBC(0x4)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xC0(0xC)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0xCC(0xC)
	struct FHitResult CallFunc_K2_AddWorldOffset_SweepHitResult;  // 0xD8(0x88)

}; 
