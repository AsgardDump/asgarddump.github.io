#pragma once 
#include "SDK.h" 
 
 
// Function CheckForBanAction.CheckForBanAction_C.OnCallback_53466DB84CBA8014C1B404A22803ADD6
// Size: 0x11(Inherited: 0x0) 
struct FOnCallback_53466DB84CBA8014C1B404A22803ADD6
{
	struct FLeaderboardFindResult Data;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bWasSuccessful : 1;  // 0x10(0x1)

}; 
// Function CheckForBanAction.CheckForBanAction_C.OnResult__DelegateSignature
// Size: 0x2(Inherited: 0x0) 
struct FOnResult__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool success : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool IsBanned : 1;  // 0x1(0x1)

}; 
// Function CheckForBanAction.CheckForBanAction_C.ExecuteUbergraph_CheckForBanAction
// Size: 0xF9(Inherited: 0x0) 
struct FExecuteUbergraph_CheckForBanAction
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FLeaderboardFindResult K2Node_CustomEvent_Data_2;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_CustomEvent_bWasSuccessful_2 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x1C(0x10)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool Temp_bool_Variable : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct FLeaderboardFindResult Temp_struct_Variable;  // 0x30(0x10)
	struct USteamCoreUserStatsAsyncActionFindLeaderboard* CallFunc_FindLeaderboardAsync_ReturnValue;  // 0x40(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x48(0x10)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FLeaderboardScoresDownloadedForUsers K2Node_CustomEvent_Data;  // 0x60(0x18)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_CustomEvent_bWasSuccessful : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x79(0x1)
	char pad_122[6];  // 0x7A(0x6)
	struct FLeaderboardScoresDownloadedForUsers Temp_struct_Variable_2;  // 0x80(0x18)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct FSteamLeaderboardEntry CallFunc_GetDownloadedLeaderboardEntry_LeaderboardEntry;  // 0xA0(0x20)
	struct TArray<int32_t> CallFunc_GetDownloadedLeaderboardEntry_outDetails;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_GetDownloadedLeaderboardEntry_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0xD1(0x1)
	char pad_210[6];  // 0xD2(0x6)
	struct FSteamID K2Node_CustomEvent_SteamID;  // 0xD8(0x8)
	struct TArray<struct FSteamID> K2Node_MakeArray_Array;  // 0xE0(0x10)
	struct USteamCoreUserStatsAsyncActionDownloadLeaderboardEntriesForUsers* CallFunc_DownloadLeaderboardEntriesForUsersAsync_ReturnValue;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xF8(0x1)

}; 
// Function CheckForBanAction.CheckForBanAction_C.CheckForBan
// Size: 0x8(Inherited: 0x0) 
struct FCheckForBan
{
	struct FSteamID SteamID;  // 0x0(0x8)

}; 
// Function CheckForBanAction.CheckForBanAction_C.OnCallback_79FFEEA74A6DD8C0C1A499A17EF0F6EE
// Size: 0x19(Inherited: 0x0) 
struct FOnCallback_79FFEEA74A6DD8C0C1A499A17EF0F6EE
{
	struct FLeaderboardScoresDownloadedForUsers Data;  // 0x0(0x18)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bWasSuccessful : 1;  // 0x18(0x1)

}; 
