#pragma once 
#include <BP_FlyingItemsCrate_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_FlyingItemsCrate.BP_FlyingItemsCrate_C
// Size: 0x2F8(Inherited: 0x2D9) 
struct ABP_FlyingItemsCrate_C : public AItemsCrate_C
{
	char pad_729[7];  // 0x2D9(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2E0(0x8)
	struct USmoothSync* SmoothSync;  // 0x2E8(0x8)
	struct UParticleSystemComponent* Smoke;  // 0x2F0(0x8)

	void ReceiveBeginPlay(); // Function BP_FlyingItemsCrate.BP_FlyingItemsCrate_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_FlyingItemsCrate.BP_FlyingItemsCrate_C.ReceiveTick
	void ExecuteUbergraph_BP_FlyingItemsCrate(int32_t EntryPoint); // Function BP_FlyingItemsCrate.BP_FlyingItemsCrate_C.ExecuteUbergraph_BP_FlyingItemsCrate
}; 



