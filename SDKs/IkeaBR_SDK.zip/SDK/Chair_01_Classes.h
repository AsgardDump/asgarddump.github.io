#pragma once 
#include <Chair_01_Structs.h>
 
 
 
// BlueprintGeneratedClass Chair_01.Chair_01_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AChair_01_C : public AMovable_Object_Replicated_C
{

}; 



