#pragma once 
#include "SDK.h" 
 
 
// Function CrateOpenCinematic.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_2
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_2
{
	struct ABP_LootCrate_C* BP_LootCrate;  // 0x0(0x8)

}; 
// Function CrateOpenCinematic.SequenceDirector_C.BP_LootCrate_Event_3
// Size: 0x8(Inherited: 0x0) 
struct FBP_LootCrate_Event_3
{
	struct ABP_LootCrate_C* BP_LootCrate;  // 0x0(0x8)

}; 
// Function CrateOpenCinematic.SequenceDirector_C.ExecuteUbergraph_SequenceDirector
// Size: 0x20(Inherited: 0x0) 
struct FExecuteUbergraph_SequenceDirector
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ABP_LootCrate_C* K2Node_CustomEvent_BP_LootCrate;  // 0x8(0x8)
	struct ABP_LootCrate_C* K2Node_CustomEvent_BP_LootCrate_3;  // 0x10(0x8)
	struct ABP_LootCrate_C* K2Node_CustomEvent_BP_LootCrate_2;  // 0x18(0x8)

}; 
// Function CrateOpenCinematic.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_3
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_3
{
	struct ABP_LootCrate_C* BP_LootCrate;  // 0x0(0x8)

}; 
// Function CrateOpenCinematic.SequenceDirector_C.BP_LootCrate_Event_2
// Size: 0x8(Inherited: 0x0) 
struct FBP_LootCrate_Event_2
{
	struct ABP_LootCrate_C* BP_LootCrate;  // 0x0(0x8)

}; 
// Function CrateOpenCinematic.SequenceDirector_C.BP_LootCrate_Event_1
// Size: 0x8(Inherited: 0x0) 
struct FBP_LootCrate_Event_1
{
	struct ABP_LootCrate_C* BP_LootCrate;  // 0x0(0x8)

}; 
// Function CrateOpenCinematic.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1
// Size: 0x8(Inherited: 0x0) 
struct FSequenceEvent__ENTRYPOINTSequenceDirector_1
{
	struct ABP_LootCrate_C* BP_LootCrate;  // 0x0(0x8)

}; 
