#pragma once 
#include <FryingPan_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass FryingPan_BP.FryingPan_BP_C
// Size: 0x290(Inherited: 0x290) 
struct AFryingPan_BP_C : public AWeaponBP_C
{

}; 



