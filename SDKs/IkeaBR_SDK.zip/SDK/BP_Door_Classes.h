#pragma once 
#include <BP_Door_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Door.BP_Door_C
// Size: 0x289(Inherited: 0x220) 
struct ABP_Door_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UReplicatedPhysics* ReplicatedPhysics_Door2;  // 0x228(0x8)
	struct UReplicatedPhysics* ReplicatedPhysics_Door1;  // 0x230(0x8)
	struct UAudioComponent* Audio;  // 0x238(0x8)
	struct UStaticMeshComponent* Cube2;  // 0x240(0x8)
	struct UStaticMeshComponent* Cube1;  // 0x248(0x8)
	struct UStaticMeshComponent* Cube;  // 0x250(0x8)
	struct UStaticMeshComponent* DoorFrame;  // 0x258(0x8)
	struct UStaticMeshComponent* StaticMesh3;  // 0x260(0x8)
	struct UStaticMeshComponent* StaticMesh2;  // 0x268(0x8)
	struct UStaticMeshComponent* Door1;  // 0x270(0x8)
	struct UStaticMeshComponent* Door2;  // 0x278(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x280(0x8)
	char pad_648_1 : 7;  // 0x288(0x1)
	bool Big? : 1;  // 0x288(0x1)

	void UserConstructionScript(); // Function BP_Door.BP_Door_C.UserConstructionScript
	void BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Door.BP_Door_C.BndEvt__StaticMesh_K2Node_ComponentBoundEvent_0_ComponentHitSignature__DelegateSignature
	void BndEvt__StaticMesh1_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Door.BP_Door_C.BndEvt__StaticMesh1_K2Node_ComponentBoundEvent_2_ComponentHitSignature__DelegateSignature
	void OnHit(struct FVector Vel); // Function BP_Door.BP_Door_C.OnHit
	void MultiPlaySound(); // Function BP_Door.BP_Door_C.MultiPlaySound
	void ExecuteUbergraph_BP_Door(int32_t EntryPoint); // Function BP_Door.BP_Door_C.ExecuteUbergraph_BP_Door
}; 



