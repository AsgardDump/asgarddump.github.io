#pragma once 
#include <Carpet_04_Structs.h>
 
 
 
// BlueprintGeneratedClass Carpet_04.Carpet_04_C
// Size: 0x228(Inherited: 0x220) 
struct ACarpet_04_C : public AActor
{
	struct UStaticMeshComponent* StaticMesh;  // 0x220(0x8)

}; 



