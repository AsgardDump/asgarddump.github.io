#pragma once 
#include <CameraPawn_Structs.h>
 
 
 
// BlueprintGeneratedClass CameraPawn.CameraPawn_C
// Size: 0x2A1(Inherited: 0x280) 
struct ACameraPawn_C : public APawn
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x280(0x8)
	struct UParticleSystemComponent* ParticleSystem;  // 0x288(0x8)
	struct UCameraComponent* Camera;  // 0x290(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool TeleportToFirstCameraOnPlay : 1;  // 0x2A0(0x1)

	void ReceiveBeginPlay(); // Function CameraPawn.CameraPawn_C.ReceiveBeginPlay
	void ExecuteUbergraph_CameraPawn(int32_t EntryPoint); // Function CameraPawn.CameraPawn_C.ExecuteUbergraph_CameraPawn
}; 



