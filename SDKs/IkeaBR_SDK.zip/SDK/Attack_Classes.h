#pragma once 
#include <Attack_Structs.h>
 
 
 
// BlueprintGeneratedClass Attack.Attack_C
// Size: 0xB0(Inherited: 0xA8) 
struct UAttack_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function Attack.Attack_C.ReceiveExecuteAI
	void ExecuteUbergraph_Attack(int32_t EntryPoint); // Function Attack.Attack_C.ExecuteUbergraph_Attack
}; 



