#pragma once 
#include <EMP_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass EMP_BP.EMP_BP_C
// Size: 0x274(Inherited: 0x268) 
struct AEMP_BP_C : public AItemBP_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x268(0x8)
	int32_t CurrentSlot;  // 0x270(0x4)

	void LMB(bool Down); // Function EMP_BP.EMP_BP_C.LMB
	void ExecuteUbergraph_EMP_BP(int32_t EntryPoint); // Function EMP_BP.EMP_BP_C.ExecuteUbergraph_EMP_BP
}; 



