#pragma once 
#include <Armchair_Structs.h>
 
 
 
// BlueprintGeneratedClass Armchair.Armchair_C
// Size: 0x2B0(Inherited: 0x2B0) 
struct AArmchair_C : public AMovable_Object_Replicated_C
{

}; 



