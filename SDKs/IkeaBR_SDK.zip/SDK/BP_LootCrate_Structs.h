#pragma once 
#include "SDK.h" 
 
 
// Function BP_LootCrate.BP_LootCrate_C.ExecuteUbergraph_BP_LootCrate
// Size: 0x420(Inherited: 0x0) 
struct FExecuteUbergraph_BP_LootCrate
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct FST_SteamItem K2Node_CustomEvent_Item;  // 0x10(0x38)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x48(0x8)
	struct FST_Cosmetic CallFunc_GetCosmetic_cosmetic;  // 0x50(0x50)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_GetCosmetic_Exists : 1;  // 0xA0(0x1)
	char E_Tier CallFunc_GetSteamTier_Tier;  // 0xA1(0x1)
	char pad_162[2];  // 0xA2(0x2)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue;  // 0xA4(0x4)
	struct FLinearColor CallFunc_TierColor_color;  // 0xA8(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xB8(0x4)
	float CallFunc_Multiply_IntFloat_ReturnValue;  // 0xBC(0x4)
	struct TArray<struct ALevelSequenceActor*> CallFunc_GetAllActorsOfClass_OutActors;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_EqualEqual_StrStr_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct ALevelSequenceActor* CallFunc_Array_Get_Item;  // 0xD8(0x8)
	struct ULevelSequencePlayer* CallFunc_GetSequencePlayer_ReturnValue;  // 0xE0(0x8)
	struct TArray<struct ALevelSequenceActor*> CallFunc_GetAllActorsOfClass_OutActors_2;  // 0xE8(0x10)
	struct ALevelSequenceActor* CallFunc_Array_Get_Item_2;  // 0xF8(0x8)
	struct ULevelSequencePlayer* CallFunc_GetSequencePlayer_ReturnValue_2;  // 0x100(0x8)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // 0x108(0x8)
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue_2;  // 0x110(0x8)
	float K2Node_Event_DeltaSeconds;  // 0x118(0x4)
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // 0x11C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x120(0xC)
	char pad_300_1 : 7;  // 0x12C(0x1)
	bool CallFunc_IsSteamAvailable_ReturnValue : 1;  // 0x12C(0x1)
	char pad_301[3];  // 0x12D(0x3)
	struct FST_Cosmetic CallFunc_GetCosmetic_cosmetic_2;  // 0x130(0x50)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_GetCosmetic_Exists_2 : 1;  // 0x180(0x1)
	char pad_385[3];  // 0x181(0x3)
	float K2Node_CustomEvent_Time;  // 0x184(0x4)
	float K2Node_CustomEvent_From;  // 0x188(0x4)
	float K2Node_CustomEvent_To;  // 0x18C(0x4)
	float CallFunc_Lerp_ReturnValue;  // 0x190(0x4)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x194(0x4)
	float CallFunc_VictoryGetSoundVolume_ReturnValue;  // 0x198(0x4)
	char pad_412[4];  // 0x19C(0x4)
	struct ABP_PlayerPreview_C* K2Node_DynamicCast_AsBP_Player_Preview;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x1A8(0x1)
	char E_Tier CallFunc_GetSteamTier_Tier_2;  // 0x1A9(0x1)
	char pad_426[6];  // 0x1AA(0x6)
	struct TArray<struct FST_Cosmetic> K2Node_MakeArray_Array;  // 0x1B0(0x10)
	int32_t CallFunc_Conv_ByteToInt_ReturnValue_2;  // 0x1C0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x1C4(0x4)
	struct FLinearColor CallFunc_TierColor_color_2;  // 0x1C8(0x10)
	float CallFunc_Multiply_IntFloat_ReturnValue_2;  // 0x1D8(0x4)
	char pad_476_1 : 7;  // 0x1DC(0x1)
	bool CallFunc_IsVisible_ReturnValue : 1;  // 0x1DC(0x1)
	char pad_477[3];  // 0x1DD(0x3)
	struct FHitResult CallFunc_K2_AddRelativeRotation_SweepHitResult;  // 0x1E0(0x88)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue_2;  // 0x268(0x8)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x270(0x88)
	struct TArray<struct ACameraPawn_C*> CallFunc_GetAllActorsOfClassWithTag_OutActors;  // 0x2F8(0x10)
	struct ACameraPawn_C* CallFunc_Array_Get_Item_3;  // 0x308(0x8)
	struct FTransform CallFunc_GetTransform_ReturnValue;  // 0x310(0x30)
	struct FVector CallFunc_BreakTransform_Location;  // 0x340(0xC)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x34C(0xC)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x358(0xC)
	char pad_868[4];  // 0x364(0x4)
	struct TArray<struct ACameraPawn_C*> CallFunc_GetAllActorsOfClass_OutActors_3;  // 0x368(0x10)
	struct ACameraPawn_C* CallFunc_Array_Get_Item_4;  // 0x378(0x8)
	struct FHitResult CallFunc_K2_SetActorLocationAndRotation_SweepHitResult;  // 0x380(0x88)
	char pad_1032_1 : 7;  // 0x408(0x1)
	bool CallFunc_K2_SetActorLocationAndRotation_ReturnValue : 1;  // 0x408(0x1)
	char pad_1033[3];  // 0x409(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x40C(0x4)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x410(0x4)
	char pad_1044_1 : 7;  // 0x414(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x414(0x1)
	char pad_1045_1 : 7;  // 0x415(0x1)
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // 0x415(0x1)
	char pad_1046[2];  // 0x416(0x2)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0x418(0x8)

}; 
// Function BP_LootCrate.BP_LootCrate_C.OnDone__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnDone__DelegateSignature
{
	struct FST_Cosmetic Item;  // 0x0(0x50)

}; 
// Function BP_LootCrate.BP_LootCrate_C.FadeGlow
// Size: 0xC(Inherited: 0x0) 
struct FFadeGlow
{
	float Time;  // 0x0(0x4)
	float From;  // 0x4(0x4)
	float To;  // 0x8(0x4)

}; 
// Function BP_LootCrate.BP_LootCrate_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_LootCrate.BP_LootCrate_C.ItemRecieved
// Size: 0x38(Inherited: 0x0) 
struct FItemRecieved
{
	struct FST_SteamItem Item;  // 0x0(0x38)

}; 
// Function BP_LootCrate.BP_LootCrate_C.UserConstructionScript
// Size: 0x21(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FSingleAnimationPlayData K2Node_MakeStruct_SingleAnimationPlayData;  // 0x0(0x18)
	struct ABP_PlayerPreview_C* K2Node_DynamicCast_AsBP_Player_Preview;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)

}; 
