#pragma once 
#include <BP_SpawnBillboard_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SpawnBillboard.BP_SpawnBillboard_C
// Size: 0x239(Inherited: 0x220) 
struct ABP_SpawnBillboard_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x220(0x8)
	struct UWidgetComponent* Widget;  // 0x228(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x230(0x8)
	char E_LocationType LocationType;  // 0x238(0x1)

	void ReceiveTick(float DeltaSeconds); // Function BP_SpawnBillboard.BP_SpawnBillboard_C.ReceiveTick
	void ExecuteUbergraph_BP_SpawnBillboard(int32_t EntryPoint); // Function BP_SpawnBillboard.BP_SpawnBillboard_C.ExecuteUbergraph_BP_SpawnBillboard
}; 



