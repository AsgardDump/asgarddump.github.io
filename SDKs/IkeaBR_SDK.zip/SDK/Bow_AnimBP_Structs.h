#pragma once 
#include "SDK.h" 
 
 
// Function Bow_AnimBP.Bow_AnimBP_C.ExecuteUbergraph_Bow_AnimBP
// Size: 0x4C(Inherited: 0x0) 
struct FExecuteUbergraph_Bow_AnimBP
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x8(0x8)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct ABP_Bow_Base_C* K2Node_DynamicCast_AsBP_Bow_Base;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct AActor* CallFunc_GetParentActor_ReturnValue;  // 0x28(0x8)
	struct AFirstPersonCharacter_C* K2Node_DynamicCast_AsFirst_Person_Character;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_2;  // 0x3C(0x4)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float CallFunc_Divide_FloatFloat_ReturnValue;  // 0x44(0x4)
	float K2Node_Event_DeltaTimeX;  // 0x48(0x4)

}; 
// Function Bow_AnimBP.Bow_AnimBP_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function Bow_AnimBP.Bow_AnimBP_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
