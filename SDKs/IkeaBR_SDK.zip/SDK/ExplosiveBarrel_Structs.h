#pragma once 
#include "SDK.h" 
 
 
// Function ExplosiveBarrel.ExplosiveBarrel_C.GetDamaged
// Size: 0x28(Inherited: 0x28) 
struct FGetDamaged : public FGetDamaged
{
	float Damage;  // 0x0(0x4)
	struct AFirstPersonCharacter_C* Causer;  // 0x8(0x8)
	struct FVector Location;  // 0x10(0xC)
	struct FVector Normal;  // 0x1C(0xC)

}; 
// Function ExplosiveBarrel.ExplosiveBarrel_C.ExecuteUbergraph_ExplosiveBarrel
// Size: 0xB5(Inherited: 0x0) 
struct FExecuteUbergraph_ExplosiveBarrel
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float K2Node_Event_Damage;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AFirstPersonCharacter_C* K2Node_Event_Causer;  // 0x10(0x8)
	struct FVector K2Node_Event_Location;  // 0x18(0xC)
	struct FVector K2Node_Event_Normal;  // 0x24(0xC)
	struct FTransform K2Node_CustomEvent_SpawnTransform;  // 0x30(0x30)
	struct AFirstPersonCharacter_C* K2Node_CustomEvent_Causer;  // 0x60(0x8)
	char pad_104[8];  // 0x68(0x8)
	struct FTransform CallFunc_Conv_VectorToTransform_ReturnValue;  // 0x70(0x30)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0xA0(0x8)
	struct AExplosion_BP_C* CallFunc_FinishSpawningActor_ReturnValue;  // 0xA8(0x8)
	float CallFunc_RandomFloatInRange_ReturnValue;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // 0xB4(0x1)

}; 
// Function ExplosiveBarrel.ExplosiveBarrel_C.ExplodeServer
// Size: 0x38(Inherited: 0x0) 
struct FExplodeServer
{
	struct FTransform SpawnTransform;  // 0x0(0x30)
	struct AFirstPersonCharacter_C* Causer;  // 0x30(0x8)

}; 
