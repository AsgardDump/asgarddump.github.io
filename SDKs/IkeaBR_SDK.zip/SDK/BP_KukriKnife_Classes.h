#pragma once 
#include <BP_KukriKnife_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_KukriKnife.BP_KukriKnife_C
// Size: 0x290(Inherited: 0x290) 
struct ABP_KukriKnife_C : public AWeaponBP_C
{

}; 



