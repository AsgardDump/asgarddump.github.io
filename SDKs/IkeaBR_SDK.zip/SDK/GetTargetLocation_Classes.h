#pragma once 
#include <GetTargetLocation_Structs.h>
 
 
 
// BlueprintGeneratedClass GetTargetLocation.GetTargetLocation_C
// Size: 0x104(Inherited: 0xA8) 
struct UGetTargetLocation_C : public UBTTask_BlueprintBase
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA8(0x8)
	struct FBlackboardKeySelector Target;  // 0xB0(0x28)
	struct FBlackboardKeySelector Location;  // 0xD8(0x28)
	float RandomRadius;  // 0x100(0x4)

	void ReceiveExecuteAI(struct AAIController* OwnerController, struct APawn* ControlledPawn); // Function GetTargetLocation.GetTargetLocation_C.ReceiveExecuteAI
	void ExecuteUbergraph_GetTargetLocation(int32_t EntryPoint); // Function GetTargetLocation.GetTargetLocation_C.ExecuteUbergraph_GetTargetLocation
}; 



