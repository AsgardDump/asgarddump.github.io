#pragma once 
#include <FacialAnimation_Structs.h>
 
 
 
// Class FacialAnimation.AudioCurveSourceComponent
// Size: 0x8A0(Inherited: 0x860) 
struct UAudioCurveSourceComponent : public UAudioComponent
{
	char pad_2144[8];  // 0x860(0x8)
	struct FName CurveSourceBindingName;  // 0x868(0x8)
	float CurveSyncOffset;  // 0x870(0x4)
	char pad_2164[44];  // 0x874(0x2C)

}; 



