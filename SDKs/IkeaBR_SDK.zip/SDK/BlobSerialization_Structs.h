#pragma once 
#include "SDK.h" 
 
 
// Function BlobSerialization.BlobFunctionLibrary.Conv_StringToBinaryBlob
// Size: 0x20(Inherited: 0x0) 
struct FConv_StringToBinaryBlob
{
	struct FString a_base64String;  // 0x0(0x10)
	struct FBlob ReturnValue;  // 0x10(0x10)

}; 
// Function BlobSerialization.BlobFunctionLibrary.Conv_BinaryBlobToString
// Size: 0x20(Inherited: 0x0) 
struct FConv_BinaryBlobToString
{
	struct FBlob Blob;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function BlobSerialization.BlobFunctionLibrary.BlobToPolyObject
// Size: 0x30(Inherited: 0x0) 
struct FBlobToPolyObject
{
	struct FBlob InBlob;  // 0x0(0x10)
	struct UObject* InObject;  // 0x10(0x8)
	struct UObject* OutObject;  // 0x18(0x8)
	uint8_t  Behavior;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UObject* NetContext;  // 0x28(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.PolyObjectToBlob
// Size: 0x28(Inherited: 0x0) 
struct FPolyObjectToBlob
{
	struct UObject* InObject;  // 0x0(0x8)
	struct FBlob OutBlob;  // 0x8(0x10)
	uint8_t  Behavior;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UObject* NetContext;  // 0x20(0x8)

}; 
// ScriptStruct BlobSerialization.Blob
// Size: 0x10(Inherited: 0x0) 
struct FBlob
{
	struct TArray<char> byteArray;  // 0x0(0x10)

}; 
// Function BlobSerialization.BlobFunctionLibrary.BlobToObject
// Size: 0x30(Inherited: 0x0) 
struct FBlobToObject
{
	struct FBlob InBlob;  // 0x0(0x10)
	struct UObject* InObject;  // 0x10(0x8)
	struct UObject* OutObject;  // 0x18(0x8)
	uint8_t  Behavior;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UObject* NetContext;  // 0x28(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.BlobToPolyObjectArray
// Size: 0x40(Inherited: 0x0) 
struct FBlobToPolyObjectArray
{
	struct FBlob InBlob;  // 0x0(0x10)
	struct TArray<struct UObject*> InObjectArray;  // 0x10(0x10)
	struct TArray<struct UObject*> OutObjectArray;  // 0x20(0x10)
	uint8_t  Behavior;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UObject* NetContext;  // 0x38(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.IsEmpty
// Size: 0x18(Inherited: 0x0) 
struct FIsEmpty
{
	struct FBlob Blob;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BlobSerialization.BlobFunctionLibrary.SaveStringToFile
// Size: 0x28(Inherited: 0x0) 
struct FSaveStringToFile
{
	struct FString Filename;  // 0x0(0x10)
	struct FString FileContents;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function BlobSerialization.BlobFunctionLibrary.BlobToStruct
// Size: 0x20(Inherited: 0x0) 
struct FBlobToStruct
{
	struct FBlob InBlob;  // 0x0(0x10)
	int32_t OutStruct;  // 0x10(0x4)
	uint8_t  Behavior;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct UObject* NetContext;  // 0x18(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.JsonToObject
// Size: 0x18(Inherited: 0x0) 
struct FJsonToObject
{
	struct FString JsonString;  // 0x0(0x10)
	struct UObject* InObject;  // 0x10(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.JsonToStruct
// Size: 0x18(Inherited: 0x0) 
struct FJsonToStruct
{
	struct FString JsonString;  // 0x0(0x10)
	int32_t Struct;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function BlobSerialization.BlobFunctionLibrary.LoadFileToBlob
// Size: 0x28(Inherited: 0x0) 
struct FLoadFileToBlob
{
	struct FString Filename;  // 0x0(0x10)
	struct FBlob FileContents;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function BlobSerialization.BlobFunctionLibrary.PolyObjectArrayToBlob
// Size: 0x30(Inherited: 0x0) 
struct FPolyObjectArrayToBlob
{
	struct TArray<struct UObject*> InObjectArray;  // 0x0(0x10)
	struct FBlob OutBlob;  // 0x10(0x10)
	uint8_t  Behavior;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UObject* NetContext;  // 0x28(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.LoadFileToString
// Size: 0x28(Inherited: 0x0) 
struct FLoadFileToString
{
	struct FString Filename;  // 0x0(0x10)
	struct FString FileContents;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function BlobSerialization.BlobFunctionLibrary.ObjectToBlob
// Size: 0x28(Inherited: 0x0) 
struct FObjectToBlob
{
	struct UObject* InObject;  // 0x0(0x8)
	struct FBlob OutBlob;  // 0x8(0x10)
	uint8_t  Behavior;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UObject* NetContext;  // 0x20(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.ObjectToJson
// Size: 0x18(Inherited: 0x0) 
struct FObjectToJson
{
	struct UObject* InObject;  // 0x0(0x8)
	struct FString JsonString;  // 0x8(0x10)

}; 
// Function BlobSerialization.BlobFunctionLibrary.TypedBlobToStruct
// Size: 0x28(Inherited: 0x0) 
struct FTypedBlobToStruct
{
	struct FBlob InBlob;  // 0x0(0x10)
	int32_t OutStruct;  // 0x10(0x4)
	uint8_t  Behavior;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)
	struct UObject* NetContext;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function BlobSerialization.BlobFunctionLibrary.Reset
// Size: 0x10(Inherited: 0x0) 
struct FReset
{
	struct FBlob Blob;  // 0x0(0x10)

}; 
// Function BlobSerialization.BlobFunctionLibrary.SaveBlobToFile
// Size: 0x28(Inherited: 0x0) 
struct FSaveBlobToFile
{
	struct FString Filename;  // 0x0(0x10)
	struct FBlob FileContents;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function BlobSerialization.BlobFunctionLibrary.StructToBlob
// Size: 0x28(Inherited: 0x0) 
struct FStructToBlob
{
	int32_t InStruct;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FBlob OutBlob;  // 0x8(0x10)
	uint8_t  Behavior;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UObject* NetContext;  // 0x20(0x8)

}; 
// Function BlobSerialization.BlobFunctionLibrary.StructToJson
// Size: 0x18(Inherited: 0x0) 
struct FStructToJson
{
	int32_t Struct;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString JsonString;  // 0x8(0x10)

}; 
// Function BlobSerialization.BlobFunctionLibrary.StructToTypedBlob
// Size: 0x28(Inherited: 0x0) 
struct FStructToTypedBlob
{
	int32_t InStruct;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FBlob OutBlob;  // 0x8(0x10)
	uint8_t  Behavior;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UObject* NetContext;  // 0x20(0x8)

}; 
