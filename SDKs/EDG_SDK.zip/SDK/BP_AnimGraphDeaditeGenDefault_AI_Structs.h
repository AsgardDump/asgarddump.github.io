#pragma once 
#include "SDK.h" 
 
 
// Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.ExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI
{
	int32_t EntryPoint;  // 0x0(0x4)
	float CallFunc_GetHighestRecentGait_ReturnValue;  // 0x4(0x4)

}; 
// Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
