#pragma once 
#include <BossAction_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BossAction.BossAction_C
// Size: 0x398(Inherited: 0x360) 
struct UBossAction_C : public UEDHUDBossAbilityWidget
{
	struct UBP_PlatformIcon_C* AbilityButton;  // 0x360(0x8)
	struct UBP_PlatformIcon_C* AbilityButtonSecondary;  // 0x368(0x8)
	struct UImage* basic_bg;  // 0x370(0x8)
	struct UImage* Button_Image;  // 0x378(0x8)
	struct UImage* Padlock;  // 0x380(0x8)
	struct UImage* Red_Active_bg;  // 0x388(0x8)
	struct UImage* redEffect;  // 0x390(0x8)

}; 



