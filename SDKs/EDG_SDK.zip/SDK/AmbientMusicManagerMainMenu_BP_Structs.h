#pragma once 
#include "SDK.h" 
 
 
// Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.OnSceneAddedToStackEvent_Event_1
// Size: 0x9(Inherited: 0x0) 
struct FOnSceneAddedToStackEvent_Event_1
{
	struct FName SceneUID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bForce : 1;  // 0x8(0x1)

}; 
// Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.OnSceneRemovedFromStackEvent_Event_1
// Size: 0x9(Inherited: 0x0) 
struct FOnSceneRemovedFromStackEvent_Event_1
{
	struct FName SceneUID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bForce : 1;  // 0x8(0x1)

}; 
// Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.ExecuteUbergraph_AmbientMusicManagerMainMenu_BP
// Size: 0x53(Inherited: 0x0) 
struct FExecuteUbergraph_AmbientMusicManagerMainMenu_BP
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x28(0x8)
	struct UEDGameInstance* K2Node_DynamicCast_AsEDGame_Instance;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	struct FName K2Node_CustomEvent_SceneUID_2;  // 0x3C(0x8)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool K2Node_CustomEvent_bForce_2 : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FName K2Node_CustomEvent_SceneUID;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_CustomEvent_bForce : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue_2 : 1;  // 0x52(0x1)

}; 
