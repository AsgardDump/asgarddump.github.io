#pragma once 
#include <AmbientMusicManagerMainMenu_BP_Structs.h>
 
 
 
// BlueprintGeneratedClass AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C
// Size: 0x3E0(Inherited: 0x3C8) 
struct AAmbientMusicManagerMainMenu_BP_C : public AEDAmbientMusicManager
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3C8(0x8)
	struct FName CreditsSceneUID;  // 0x3D0(0x8)
	struct FGameplayTag MusicTagCredits;  // 0x3D8(0x8)

	void ReceiveBeginPlay(); // Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.ReceiveBeginPlay
	void OnSceneAddedToStackEvent_Event_1(struct FName SceneUID, bool bForce); // Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.OnSceneAddedToStackEvent_Event_1
	void OnSceneRemovedFromStackEvent_Event_1(struct FName SceneUID, bool bForce); // Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.OnSceneRemovedFromStackEvent_Event_1
	void ExecuteUbergraph_AmbientMusicManagerMainMenu_BP(int32_t EntryPoint); // Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.ExecuteUbergraph_AmbientMusicManagerMainMenu_BP
}; 



