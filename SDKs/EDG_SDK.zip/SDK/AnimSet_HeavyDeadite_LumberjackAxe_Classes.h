#pragma once 
#include <AnimSet_HeavyDeadite_LumberjackAxe_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_HeavyDeadite_LumberjackAxe.AnimSet_HeavyDeadite_LumberjackAxe_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_HeavyDeadite_LumberjackAxe_C : public UEDAnimSetMeleeWeapon
{

}; 



