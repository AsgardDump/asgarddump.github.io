#pragma once 
#include <AnimSet_Skeleton_Spear_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Skeleton_Spear.AnimSet_Skeleton_Spear_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Skeleton_Spear_C : public UEDAnimSetMeleeWeapon
{

}; 



