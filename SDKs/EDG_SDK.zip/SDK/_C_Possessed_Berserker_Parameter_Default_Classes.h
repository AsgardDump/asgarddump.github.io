#pragma once 
#include <_C_Possessed_Berserker_Parameter_Default_Structs.h>
 
 
 
// BlueprintGeneratedClass _C_Possessed_Berserker_Parameter_Default._C_Possessed_Berserker_Parameter_Default_C
// Size: 0x3AB8(Inherited: 0x3AB8) 
struct U_C_Possessed_Berserker_Parameter_Default_C : public UEDCharacterParameters
{

}; 



