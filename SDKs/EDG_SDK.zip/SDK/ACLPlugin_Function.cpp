#include "SDK.h" 
 
 
void UObject::SetVisualFidelity(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UAnimationCompressionLibraryDatabase* DatabaseAsset, uint8_t & Result, uint8_t  VisualFidelity){

	static UObject* p_SetVisualFidelity = UObject::FindObject<UFunction>("Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity");

	struct {
		struct UObject* WorldContextObject;
		struct FLatentActionInfo LatentInfo;
		struct UAnimationCompressionLibraryDatabase* DatabaseAsset;
		uint8_t & Result;
		uint8_t  VisualFidelity;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.LatentInfo = LatentInfo;
	parms.DatabaseAsset = DatabaseAsset;
	parms.Result = Result;
	parms.VisualFidelity = VisualFidelity;

	ProcessEvent(p_SetVisualFidelity, &parms);
}

uint8_t  UObject::GetVisualFidelity(struct UAnimationCompressionLibraryDatabase* DatabaseAsset){

	static UObject* p_GetVisualFidelity = UObject::FindObject<UFunction>("Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity");

	struct {
		struct UAnimationCompressionLibraryDatabase* DatabaseAsset;
		uint8_t  return_value;
	} parms;

	parms.DatabaseAsset = DatabaseAsset;

	ProcessEvent(p_GetVisualFidelity, &parms);
	return parms.return_value;
}

