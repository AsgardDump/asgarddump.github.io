#include "SDK.h" 
 
 
void UEDAnimInstanceFeetIK::AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.AnimGraph");

	struct {
		struct FPoseLink InPose;
		struct FPoseLink& AnimGraph;
	} parms;

	parms.InPose = InPose;
	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UEDAnimInstanceFeetIK::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UEDAnimInstanceFeetIK::ExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.ExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK, &parms);
}

