#pragma once 
#include <BP_AnimGraphDeadTree_5_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphDeadTree_5.BP_AnimGraphDeadTree_4_C
// Size: 0x358(Inherited: 0x2C0) 
struct UBP_AnimGraphDeadTree_4_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2F8(0x48)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x340(0x18)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BP_AnimGraphDeadTree_5.BP_AnimGraphDeadTree_4_C.AnimGraph
	void ExecuteUbergraph_BP_AnimGraphDeadTree_5(int32_t EntryPoint); // Function BP_AnimGraphDeadTree_5.BP_AnimGraphDeadTree_4_C.ExecuteUbergraph_BP_AnimGraphDeadTree_5
}; 



