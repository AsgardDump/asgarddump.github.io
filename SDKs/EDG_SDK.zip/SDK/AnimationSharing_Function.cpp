#include "SDK.h" 
 
 
void UAnimInstance::GetInstancedActors(struct TArray<struct AActor*>& Actors){

	static UObject* p_GetInstancedActors = UObject::FindObject<UFunction>("Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors");

	struct {
		struct TArray<struct AActor*>& Actors;
	} parms;

	parms.Actors = Actors;

	ProcessEvent(p_GetInstancedActors, &parms);
}

void UObject::ProcessActorState(int32_t& OutState, struct AActor* InActor, char CurrentState, char OnDemandState, bool& bShouldProcess){

	static UObject* p_ProcessActorState = UObject::FindObject<UFunction>("Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState");

	struct {
		int32_t& OutState;
		struct AActor* InActor;
		char CurrentState;
		char OnDemandState;
		bool& bShouldProcess;
	} parms;

	parms.OutState = OutState;
	parms.InActor = InActor;
	parms.CurrentState = CurrentState;
	parms.OnDemandState = OnDemandState;
	parms.bShouldProcess = bShouldProcess;

	ProcessEvent(p_ProcessActorState, &parms);
}

struct UEnum* UObject::GetAnimationStateEnum(){

	static UObject* p_GetAnimationStateEnum = UObject::FindObject<UFunction>("Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum");

	struct {
		struct UEnum* return_value;
	} parms;


	ProcessEvent(p_GetAnimationStateEnum, &parms);
	return parms.return_value;
}

void UObject::RegisterActorWithSkeletonBP(struct AActor* InActor, struct USkeleton* SharingSkeleton){

	static UObject* p_RegisterActorWithSkeletonBP = UObject::FindObject<UFunction>("Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP");

	struct {
		struct AActor* InActor;
		struct USkeleton* SharingSkeleton;
	} parms;

	parms.InActor = InActor;
	parms.SharingSkeleton = SharingSkeleton;

	ProcessEvent(p_RegisterActorWithSkeletonBP, &parms);
}

struct UAnimationSharingManager* UObject::GetAnimationSharingManager(struct UObject* WorldContextObject){

	static UObject* p_GetAnimationSharingManager = UObject::FindObject<UFunction>("Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager");

	struct {
		struct UObject* WorldContextObject;
		struct UAnimationSharingManager* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetAnimationSharingManager, &parms);
	return parms.return_value;
}

bool UObject::CreateAnimationSharingManager(struct UObject* WorldContextObject, struct UAnimationSharingSetup* Setup){

	static UObject* p_CreateAnimationSharingManager = UObject::FindObject<UFunction>("Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager");

	struct {
		struct UObject* WorldContextObject;
		struct UAnimationSharingSetup* Setup;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Setup = Setup;

	ProcessEvent(p_CreateAnimationSharingManager, &parms);
	return parms.return_value;
}

bool UObject::AnimationSharingEnabled(){

	static UObject* p_AnimationSharingEnabled = UObject::FindObject<UFunction>("Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_AnimationSharingEnabled, &parms);
	return parms.return_value;
}

