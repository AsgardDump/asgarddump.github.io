#pragma once 
#include <_C_Possessed_PlaguedSkeleton_Parameter_Default_3_Structs.h>
 
 
 
// BlueprintGeneratedClass _C_Possessed_PlaguedSkeleton_Parameter_Default_3._C_Possessed_PlaguedSkeleton_Parameter_Default_2_C
// Size: 0x3AB8(Inherited: 0x3AB8) 
struct U_C_Possessed_PlaguedSkeleton_Parameter_Default_2_C : public U_C_Possessed_PlaguedSkeleton_Parameter_Default_C
{

}; 



