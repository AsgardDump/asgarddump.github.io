#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function BP_AnimGraphDeadTree_4.BP_AnimGraphDeadTree_3_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::ExecuteUbergraph_BP_AnimGraphDeadTree_4(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AnimGraphDeadTree_4 = UObject::FindObject<UFunction>("Function BP_AnimGraphDeadTree_4.BP_AnimGraphDeadTree_3_C.ExecuteUbergraph_BP_AnimGraphDeadTree_4");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AnimGraphDeadTree_4, &parms);
}

