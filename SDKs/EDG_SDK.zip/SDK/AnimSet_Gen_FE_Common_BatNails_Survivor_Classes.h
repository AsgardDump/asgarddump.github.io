#pragma once 
#include <AnimSet_Gen_FE_Common_BatNails_Survivor_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_FE_Common_BatNails_Survivor.AnimSet_Gen_FE_Common_BatNails_Survivor_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Gen_FE_Common_BatNails_Survivor_C : public UEDAnimSetMeleeWeapon
{

}; 



