#pragma once 
#include <AvED_Amanda_SkillTree_Structs.h>
 
 
 
// BlueprintGeneratedClass AvED_Amanda_SkillTree.AvED_Amanda_SkillTree_C
// Size: 0x108(Inherited: 0x108) 
struct UAvED_Amanda_SkillTree_C : public UHunter_SkillTree_C
{

}; 



