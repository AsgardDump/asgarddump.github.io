#pragma once 
#include <_C_Possessed_MeatPuppet_Parameter_Default_Structs.h>
 
 
 
// BlueprintGeneratedClass _C_Possessed_MeatPuppet_Parameter_Default._C_Possessed_MeatPuppet_Parameter_Default_C
// Size: 0x3E68(Inherited: 0x3E68) 
struct U_C_Possessed_MeatPuppet_Parameter_Default_C : public UEDCharacterParametersMeatPuppet
{

}; 



