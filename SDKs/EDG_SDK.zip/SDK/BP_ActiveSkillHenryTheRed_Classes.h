#pragma once 
#include <BP_ActiveSkillHenryTheRed_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillHenryTheRed.BP_ActiveSkillHenryTheRed_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillHenryTheRed_C : public UEDConditionsTriggerActiveSkillHenryTheRed
{

}; 



