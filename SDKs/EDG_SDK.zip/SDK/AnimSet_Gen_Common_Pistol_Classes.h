#pragma once 
#include <AnimSet_Gen_Common_Pistol_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_Pistol.AnimSet_Gen_Common_Pistol_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen_Common_Pistol_C : public UEDAnimSetRangedWeapon
{

}; 



