#pragma once 
#include <BossIcon_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass BossIcon.BossIcon_C
// Size: 0x550(Inherited: 0x538) 
struct UBossIcon_C : public UEDHUDBossIcon
{
	struct UImage* Bg_g;  // 0x538(0x8)
	struct UImage* Red_Active_bg;  // 0x540(0x8)
	struct UImage* RedStroke;  // 0x548(0x8)

}; 



