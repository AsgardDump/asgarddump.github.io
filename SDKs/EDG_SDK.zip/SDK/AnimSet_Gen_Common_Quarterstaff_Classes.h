#pragma once 
#include <AnimSet_Gen_Common_Quarterstaff_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_Quarterstaff.AnimSet_Gen_Common_Quarterstaff_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Gen_Common_Quarterstaff_C : public UEDAnimSetMeleeWeapon
{

}; 



