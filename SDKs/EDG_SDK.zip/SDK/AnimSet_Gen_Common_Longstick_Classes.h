#pragma once 
#include <AnimSet_Gen_Common_Longstick_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_Longstick.AnimSet_Gen_Common_Longstick_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen_Common_Longstick_C : public UEDAnimSetRangedWeapon
{

}; 



