#pragma once 
#include "SDK.h" 
 
 
// Function BP_AnimGraphCharacter_LeftLowerarmTwist.BP_AnimGraphCharacter_LeftLowerarmTwist_C.ExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function BP_AnimGraphCharacter_LeftLowerarmTwist.BP_AnimGraphCharacter_LeftLowerarmTwist_C.AnimGraph
// Size: 0x20(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink InPose;  // 0x0(0x10)
	struct FPoseLink AnimGraph;  // 0x10(0x10)

}; 
