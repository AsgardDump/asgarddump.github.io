#pragma once 
#include <_Pickup_TapeLootBox_Structs.h>
 
 
 
// BlueprintGeneratedClass _Pickup_TapeLootBox._Pickup_TapeLootBox_C
// Size: 0x2A8(Inherited: 0x288) 
struct A_Pickup_TapeLootBox_C : public AEDLootBoxPoint
{
	struct UTextRenderComponent* Area Name;  // 0x288(0x8)
	struct FText BP Name;  // 0x290(0x18)

	void Set World Rotation Z to 0(); // Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.Set World Rotation Z to 0
	void Set name as BP(); // Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.Set name as BP
	void UserConstructionScript(); // Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.UserConstructionScript
}; 



