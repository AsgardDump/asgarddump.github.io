#pragma once 
#include <AnimSet_Gen_Common_Crossbow_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_Crossbow.AnimSet_Gen_Common_Crossbow_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen_Common_Crossbow_C : public UEDAnimSetRangedWeapon
{

}; 



