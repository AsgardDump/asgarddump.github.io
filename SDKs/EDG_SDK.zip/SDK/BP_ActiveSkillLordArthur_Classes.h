#pragma once 
#include <BP_ActiveSkillLordArthur_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillLordArthur.BP_ActiveSkillLordArthur_C
// Size: 0x40(Inherited: 0x40) 
struct UBP_ActiveSkillLordArthur_C : public UEDConditionsTriggerActiveSkillLordArthur
{

}; 



