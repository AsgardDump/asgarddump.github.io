#pragma once 
#include "SDK.h" 
 
 
// Function BP_AnimGraph_MiniAsh.BP_AnimGraph_MiniAsh_C.ExecuteUbergraph_BP_AnimGraph_MiniAsh
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AnimGraph_MiniAsh
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function BP_AnimGraph_MiniAsh.BP_AnimGraph_MiniAsh_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
