#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::StopSession(struct UObject* WorldContextObject){

	static UObject* p_StopSession = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.StopSession");

	struct {
		struct UObject* WorldContextObject;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_StopSession, &parms);
}

void UBlueprintFunctionLibrary::StartSession(struct UObject* WorldContextObject){

	static UObject* p_StartSession = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.StartSession");

	struct {
		struct UObject* WorldContextObject;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_StartSession, &parms);
}

void UBlueprintFunctionLibrary::SetUIControlVisibility(struct UObject* WorldContextObject, char EUIControlEffectTarget UIControlTarget, bool bIsVisible){

	static UObject* p_SetUIControlVisibility = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetUIControlVisibility");

	struct {
		struct UObject* WorldContextObject;
		char EUIControlEffectTarget UIControlTarget;
		bool bIsVisible;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.UIControlTarget = UIControlTarget;
	parms.bIsVisible = bIsVisible;

	ProcessEvent(p_SetUIControlVisibility, &parms);
}

void UBlueprintFunctionLibrary::SetSettleFrames(int32_t NumSettleFrames){

	static UObject* p_SetSettleFrames = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetSettleFrames");

	struct {
		int32_t NumSettleFrames;
	} parms;

	parms.NumSettleFrames = NumSettleFrames;

	ProcessEvent(p_SetSettleFrames, &parms);
}

void UBlueprintFunctionLibrary::SetIsPhotographyAllowed(bool bIsPhotographyAllowed){

	static UObject* p_SetIsPhotographyAllowed = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetIsPhotographyAllowed");

	struct {
		bool bIsPhotographyAllowed;
	} parms;

	parms.bIsPhotographyAllowed = bIsPhotographyAllowed;

	ProcessEvent(p_SetIsPhotographyAllowed, &parms);
}

void UBlueprintFunctionLibrary::SetCameraMovementSpeed(float TranslationSpeed){

	static UObject* p_SetCameraMovementSpeed = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetCameraMovementSpeed");

	struct {
		float TranslationSpeed;
	} parms;

	parms.TranslationSpeed = TranslationSpeed;

	ProcessEvent(p_SetCameraMovementSpeed, &parms);
}

void UBlueprintFunctionLibrary::SetCameraConstraintDistance(float MaxCameraDistance){

	static UObject* p_SetCameraConstraintDistance = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetCameraConstraintDistance");

	struct {
		float MaxCameraDistance;
	} parms;

	parms.MaxCameraDistance = MaxCameraDistance;

	ProcessEvent(p_SetCameraConstraintDistance, &parms);
}

void UBlueprintFunctionLibrary::SetCameraConstraintCameraSize(float CameraSize){

	static UObject* p_SetCameraConstraintCameraSize = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetCameraConstraintCameraSize");

	struct {
		float CameraSize;
	} parms;

	parms.CameraSize = CameraSize;

	ProcessEvent(p_SetCameraConstraintCameraSize, &parms);
}

void UBlueprintFunctionLibrary::SetAutoPostprocess(bool bShouldAutoPostprocess){

	static UObject* p_SetAutoPostprocess = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetAutoPostprocess");

	struct {
		bool bShouldAutoPostprocess;
	} parms;

	parms.bShouldAutoPostprocess = bShouldAutoPostprocess;

	ProcessEvent(p_SetAutoPostprocess, &parms);
}

void UBlueprintFunctionLibrary::SetAutoPause(bool bShouldAutoPause){

	static UObject* p_SetAutoPause = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.SetAutoPause");

	struct {
		bool bShouldAutoPause;
	} parms;

	parms.bShouldAutoPause = bShouldAutoPause;

	ProcessEvent(p_SetAutoPause, &parms);
}

bool UBlueprintFunctionLibrary::IsPhotographyAvailable(){

	static UObject* p_IsPhotographyAvailable = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.IsPhotographyAvailable");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPhotographyAvailable, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsPhotographyAllowed(){

	static UObject* p_IsPhotographyAllowed = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.IsPhotographyAllowed");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPhotographyAllowed, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConstrainCameraByGeometry(struct UObject* WorldContextObject, struct FVector NewCameraLocation, struct FVector PreviousCameraLocation, struct FVector OriginalCameraLocation, struct FVector& OutCameraLocation){

	static UObject* p_ConstrainCameraByGeometry = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.ConstrainCameraByGeometry");

	struct {
		struct UObject* WorldContextObject;
		struct FVector NewCameraLocation;
		struct FVector PreviousCameraLocation;
		struct FVector OriginalCameraLocation;
		struct FVector& OutCameraLocation;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.NewCameraLocation = NewCameraLocation;
	parms.PreviousCameraLocation = PreviousCameraLocation;
	parms.OriginalCameraLocation = OriginalCameraLocation;
	parms.OutCameraLocation = OutCameraLocation;

	ProcessEvent(p_ConstrainCameraByGeometry, &parms);
}

void UBlueprintFunctionLibrary::ConstrainCameraByExtents(struct FVector NewCameraLocation, struct FVector OriginalLocation, struct FVector& OutCameraLocation, struct FVector& Extents){

	static UObject* p_ConstrainCameraByExtents = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.ConstrainCameraByExtents");

	struct {
		struct FVector NewCameraLocation;
		struct FVector OriginalLocation;
		struct FVector& OutCameraLocation;
		struct FVector& Extents;
	} parms;

	parms.NewCameraLocation = NewCameraLocation;
	parms.OriginalLocation = OriginalLocation;
	parms.OutCameraLocation = OutCameraLocation;
	parms.Extents = Extents;

	ProcessEvent(p_ConstrainCameraByExtents, &parms);
}

void UBlueprintFunctionLibrary::ConstrainCameraByDistance(struct UObject* WorldContextObject, struct FVector NewCameraLocation, struct FVector PreviousCameraLocation, struct FVector OriginalCameraLocation, struct FVector& OutCameraLocation, float MaxDistance){

	static UObject* p_ConstrainCameraByDistance = UObject::FindObject<UFunction>("Function Ansel.AnselFunctionLibrary.ConstrainCameraByDistance");

	struct {
		struct UObject* WorldContextObject;
		struct FVector NewCameraLocation;
		struct FVector PreviousCameraLocation;
		struct FVector OriginalCameraLocation;
		struct FVector& OutCameraLocation;
		float MaxDistance;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.NewCameraLocation = NewCameraLocation;
	parms.PreviousCameraLocation = PreviousCameraLocation;
	parms.OriginalCameraLocation = OriginalCameraLocation;
	parms.OutCameraLocation = OutCameraLocation;
	parms.MaxDistance = MaxDistance;

	ProcessEvent(p_ConstrainCameraByDistance, &parms);
}

