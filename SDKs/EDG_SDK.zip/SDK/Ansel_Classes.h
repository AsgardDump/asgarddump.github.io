#pragma once 
#include <Ansel_Structs.h>
 
 
 
// Class Ansel.AnselFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UAnselFunctionLibrary : public UBlueprintFunctionLibrary
{

	void StopSession(struct UObject* WorldContextObject); // Function Ansel.AnselFunctionLibrary.StopSession
	void StartSession(struct UObject* WorldContextObject); // Function Ansel.AnselFunctionLibrary.StartSession
	void SetUIControlVisibility(struct UObject* WorldContextObject, char EUIControlEffectTarget UIControlTarget, bool bIsVisible); // Function Ansel.AnselFunctionLibrary.SetUIControlVisibility
	void SetSettleFrames(int32_t NumSettleFrames); // Function Ansel.AnselFunctionLibrary.SetSettleFrames
	void SetIsPhotographyAllowed(bool bIsPhotographyAllowed); // Function Ansel.AnselFunctionLibrary.SetIsPhotographyAllowed
	void SetCameraMovementSpeed(float TranslationSpeed); // Function Ansel.AnselFunctionLibrary.SetCameraMovementSpeed
	void SetCameraConstraintDistance(float MaxCameraDistance); // Function Ansel.AnselFunctionLibrary.SetCameraConstraintDistance
	void SetCameraConstraintCameraSize(float CameraSize); // Function Ansel.AnselFunctionLibrary.SetCameraConstraintCameraSize
	void SetAutoPostprocess(bool bShouldAutoPostprocess); // Function Ansel.AnselFunctionLibrary.SetAutoPostprocess
	void SetAutoPause(bool bShouldAutoPause); // Function Ansel.AnselFunctionLibrary.SetAutoPause
	bool IsPhotographyAvailable(); // Function Ansel.AnselFunctionLibrary.IsPhotographyAvailable
	bool IsPhotographyAllowed(); // Function Ansel.AnselFunctionLibrary.IsPhotographyAllowed
	void ConstrainCameraByGeometry(struct UObject* WorldContextObject, struct FVector NewCameraLocation, struct FVector PreviousCameraLocation, struct FVector OriginalCameraLocation, struct FVector& OutCameraLocation); // Function Ansel.AnselFunctionLibrary.ConstrainCameraByGeometry
	void ConstrainCameraByExtents(struct FVector NewCameraLocation, struct FVector OriginalLocation, struct FVector& OutCameraLocation, struct FVector& Extents); // Function Ansel.AnselFunctionLibrary.ConstrainCameraByExtents
	void ConstrainCameraByDistance(struct UObject* WorldContextObject, struct FVector NewCameraLocation, struct FVector PreviousCameraLocation, struct FVector OriginalCameraLocation, struct FVector& OutCameraLocation, float MaxDistance); // Function Ansel.AnselFunctionLibrary.ConstrainCameraByDistance
}; 



