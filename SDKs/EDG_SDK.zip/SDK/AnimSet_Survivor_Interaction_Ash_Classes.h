#pragma once 
#include <AnimSet_Survivor_Interaction_Ash_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Survivor_Interaction_Ash.AnimSet_Survivor_Interaction_Ash_C
// Size: 0x98(Inherited: 0x98) 
struct UAnimSet_Survivor_Interaction_Ash_C : public UAnimSet_Survivor_Interaction_C
{

}; 



