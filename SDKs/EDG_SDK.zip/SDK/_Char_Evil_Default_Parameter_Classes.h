#pragma once 
#include <_Char_Evil_Default_Parameter_Structs.h>
 
 
 
// BlueprintGeneratedClass _Char_Evil_Default_Parameter._Char_Evil_Default_Parameter_C
// Size: 0x4140(Inherited: 0x4140) 
struct U_Char_Evil_Default_Parameter_C : public UEDCharacterParametersEvilPlayer
{

}; 



