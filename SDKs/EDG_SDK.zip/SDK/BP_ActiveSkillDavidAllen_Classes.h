#pragma once 
#include <BP_ActiveSkillDavidAllen_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillDavidAllen.BP_ActiveSkillDavidAllen_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillDavidAllen_C : public UEDConditionsTriggerActiveSkillDavidAllen
{

}; 



