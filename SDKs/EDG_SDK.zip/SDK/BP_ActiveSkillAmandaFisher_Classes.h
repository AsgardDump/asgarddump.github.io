#pragma once 
#include <BP_ActiveSkillAmandaFisher_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillAmandaFisher.BP_ActiveSkillAmandaFisher_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillAmandaFisher_C : public UEDConditionsTriggerActiveSkillAmandaFisher
{

}; 



