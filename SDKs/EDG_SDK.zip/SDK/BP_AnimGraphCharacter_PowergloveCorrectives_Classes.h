#pragma once 
#include <BP_AnimGraphCharacter_PowergloveCorrectives_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphCharacter_PowergloveCorrectives.BP_AnimGraphCharacter_PowergloveCorrectives_C
// Size: 0x1170(Inherited: 0x2C0) 
struct UBP_AnimGraphCharacter_PowergloveCorrectives_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;  // 0x2C8(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_12;  // 0x3E0(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_11;  // 0x4F8(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_10;  // 0x610(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_9;  // 0x728(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_8;  // 0x840(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_7;  // 0x958(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_6;  // 0xA70(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_5;  // 0xB88(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_4;  // 0xCA0(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_3;  // 0xDB8(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController_2;  // 0xED0(0x118)
	struct FAnimNode_BoneDrivenController AnimGraphNode_BoneDrivenController;  // 0xFE8(0x118)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x1100(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x1120(0x20)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x1140(0x30)

	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function BP_AnimGraphCharacter_PowergloveCorrectives.BP_AnimGraphCharacter_PowergloveCorrectives_C.AnimGraph
	void ExecuteUbergraph_BP_AnimGraphCharacter_PowergloveCorrectives(int32_t EntryPoint); // Function BP_AnimGraphCharacter_PowergloveCorrectives.BP_AnimGraphCharacter_PowergloveCorrectives_C.ExecuteUbergraph_BP_AnimGraphCharacter_PowergloveCorrectives
}; 



