#include "SDK.h" 
 
 
void UEDAnimInstanceDeadite::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Left_NotMoving(){

	static UObject* p_AnimNotify_Left_NotMoving = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_NotMoving");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Left_NotMoving, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Entered_NotMoving(){

	static UObject* p_AnimNotify_Entered_NotMoving = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_NotMoving");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Entered_NotMoving, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Entered_Moving(){

	static UObject* p_AnimNotify_Entered_Moving = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_Moving");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Entered_Moving, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Left_Moving(){

	static UObject* p_AnimNotify_Left_Moving = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_Moving");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Left_Moving, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Entered_Pivot(){

	static UObject* p_AnimNotify_Entered_Pivot = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_Pivot");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Entered_Pivot, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Left_Pivot(){

	static UObject* p_AnimNotify_Left_Pivot = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_Pivot");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Left_Pivot, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Entered_Stopping(){

	static UObject* p_AnimNotify_Entered_Stopping = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_Stopping");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Entered_Stopping, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Left_Stopping(){

	static UObject* p_AnimNotify_Left_Stopping = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_Stopping");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Left_Stopping, &parms);
}

void UEDAnimInstanceDeadite::AnimNotify_Land(){

	static UObject* p_AnimNotify_Land = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Land");

	struct {
	} parms;


	ProcessEvent(p_AnimNotify_Land, &parms);
}

void UEDAnimInstanceDeadite::ExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI = UObject::FindObject<UFunction>("Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.ExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI, &parms);
}

