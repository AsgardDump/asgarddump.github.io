#pragma once 
#include <BP_ActiveSkillMiaAllen_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillMiaAllen.BP_ActiveSkillMiaAllen_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillMiaAllen_C : public UEDConditionsTriggerActiveSkillMiaAllen
{

}; 



