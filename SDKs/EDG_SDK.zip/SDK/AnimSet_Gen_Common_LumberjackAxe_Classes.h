#pragma once 
#include <AnimSet_Gen_Common_LumberjackAxe_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_LumberjackAxe.AnimSet_Gen_Common_LumberjackAxe_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Gen_Common_LumberjackAxe_C : public UEDAnimSetMeleeWeapon
{

}; 



