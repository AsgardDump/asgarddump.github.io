#pragma once 
#include <ABP_DarkOne_5_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_DarkOne_5.ABP_DarkOne_4_C
// Size: 0xB40(Inherited: 0xB40) 
struct UABP_DarkOne_4_C : public UABP_DarkOne_C
{

}; 



