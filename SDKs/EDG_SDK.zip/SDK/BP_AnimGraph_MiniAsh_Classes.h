#pragma once 
#include <BP_AnimGraph_MiniAsh_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraph_MiniAsh.BP_AnimGraph_MiniAsh_C
// Size: 0x3C8(Inherited: 0x330) 
struct UBP_AnimGraph_MiniAsh_C : public UEDAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x330(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x338(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x368(0x48)
	struct FAnimNode_RefPose AnimGraphNode_LocalRefPose;  // 0x3B0(0x18)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BP_AnimGraph_MiniAsh.BP_AnimGraph_MiniAsh_C.AnimGraph
	void ExecuteUbergraph_BP_AnimGraph_MiniAsh(int32_t EntryPoint); // Function BP_AnimGraph_MiniAsh.BP_AnimGraph_MiniAsh_C.ExecuteUbergraph_BP_AnimGraph_MiniAsh
}; 



