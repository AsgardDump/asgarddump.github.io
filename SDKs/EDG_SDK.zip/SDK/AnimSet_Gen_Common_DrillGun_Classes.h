#pragma once 
#include <AnimSet_Gen_Common_DrillGun_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_DrillGun.AnimSet_Gen_Common_DrillGun_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen_Common_DrillGun_C : public UEDAnimSetRangedWeapon
{

}; 



