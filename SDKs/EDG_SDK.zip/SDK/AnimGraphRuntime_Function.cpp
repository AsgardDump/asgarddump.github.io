#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::K2_TwoBoneIK(struct FVector& RootPos, struct FVector& JointPos, struct FVector& EndPos, struct FVector& JointTarget, struct FVector& Effector, struct FVector& OutJointPos, struct FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale){

	static UObject* p_K2_TwoBoneIK = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK");

	struct {
		struct FVector& RootPos;
		struct FVector& JointPos;
		struct FVector& EndPos;
		struct FVector& JointTarget;
		struct FVector& Effector;
		struct FVector& OutJointPos;
		struct FVector& OutEndPos;
		bool bAllowStretching;
		float StartStretchRatio;
		float MaxStretchScale;
	} parms;

	parms.RootPos = RootPos;
	parms.JointPos = JointPos;
	parms.EndPos = EndPos;
	parms.JointTarget = JointTarget;
	parms.Effector = Effector;
	parms.OutJointPos = OutJointPos;
	parms.OutEndPos = OutEndPos;
	parms.bAllowStretching = bAllowStretching;
	parms.StartStretchRatio = StartStretchRatio;
	parms.MaxStretchScale = MaxStretchScale;

	ProcessEvent(p_K2_TwoBoneIK, &parms);
}

void UBlueprintFunctionLibrary::K2_StartProfilingTimer(){

	static UObject* p_K2_StartProfilingTimer = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer");

	struct {
	} parms;


	ProcessEvent(p_K2_StartProfilingTimer, &parms);
}

struct FVector UBlueprintFunctionLibrary::K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ){

	static UObject* p_K2_MakePerlinNoiseVectorAndRemap = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap");

	struct {
		float X;
		float Y;
		float Z;
		float RangeOutMinX;
		float RangeOutMaxX;
		float RangeOutMinY;
		float RangeOutMaxY;
		float RangeOutMinZ;
		float RangeOutMaxZ;
		struct FVector return_value;
	} parms;

	parms.X = X;
	parms.Y = Y;
	parms.Z = Z;
	parms.RangeOutMinX = RangeOutMinX;
	parms.RangeOutMaxX = RangeOutMaxX;
	parms.RangeOutMinY = RangeOutMinY;
	parms.RangeOutMaxY = RangeOutMaxY;
	parms.RangeOutMinZ = RangeOutMinZ;
	parms.RangeOutMaxZ = RangeOutMaxZ;

	ProcessEvent(p_K2_MakePerlinNoiseVectorAndRemap, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax){

	static UObject* p_K2_MakePerlinNoiseAndRemap = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap");

	struct {
		float Value;
		float RangeOutMin;
		float RangeOutMax;
		float return_value;
	} parms;

	parms.Value = Value;
	parms.RangeOutMin = RangeOutMin;
	parms.RangeOutMax = RangeOutMax;

	ProcessEvent(p_K2_MakePerlinNoiseAndRemap, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::K2_LookAt(struct FTransform& CurrentTransform, struct FVector& TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree){

	static UObject* p_K2_LookAt = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt");

	struct {
		struct FTransform& CurrentTransform;
		struct FVector& TargetPosition;
		struct FVector LookAtVector;
		bool bUseUpVector;
		struct FVector UpVector;
		float ClampConeInDegree;
		struct FTransform return_value;
	} parms;

	parms.CurrentTransform = CurrentTransform;
	parms.TargetPosition = TargetPosition;
	parms.LookAtVector = LookAtVector;
	parms.bUseUpVector = bUseUpVector;
	parms.UpVector = UpVector;
	parms.ClampConeInDegree = ClampConeInDegree;

	ProcessEvent(p_K2_LookAt, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_EndProfilingTimer(bool bLog, struct FString LogPrefix){

	static UObject* p_K2_EndProfilingTimer = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer");

	struct {
		bool bLog;
		struct FString LogPrefix;
		float return_value;
	} parms;

	parms.bLog = bLog;
	parms.LogPrefix = LogPrefix;

	ProcessEvent(p_K2_EndProfilingTimer, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_DistanceBetweenTwoSocketsAndMapRange(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameA, char ERelativeTransformSpace SocketSpaceA, struct FName SocketOrBoneNameB, char ERelativeTransformSpace SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax){

	static UObject* p_K2_DistanceBetweenTwoSocketsAndMapRange = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange");

	struct {
		struct USkeletalMeshComponent* Component;
		struct FName SocketOrBoneNameA;
		char ERelativeTransformSpace SocketSpaceA;
		struct FName SocketOrBoneNameB;
		char ERelativeTransformSpace SocketSpaceB;
		bool bRemapRange;
		float InRangeMin;
		float InRangeMax;
		float OutRangeMin;
		float OutRangeMax;
		float return_value;
	} parms;

	parms.Component = Component;
	parms.SocketOrBoneNameA = SocketOrBoneNameA;
	parms.SocketSpaceA = SocketSpaceA;
	parms.SocketOrBoneNameB = SocketOrBoneNameB;
	parms.SocketSpaceB = SocketSpaceB;
	parms.bRemapRange = bRemapRange;
	parms.InRangeMin = InRangeMin;
	parms.InRangeMax = InRangeMax;
	parms.OutRangeMin = OutRangeMin;
	parms.OutRangeMax = OutRangeMax;

	ProcessEvent(p_K2_DistanceBetweenTwoSocketsAndMapRange, &parms);
	return parms.return_value;
}

struct FVector UBlueprintFunctionLibrary::K2_DirectionBetweenSockets(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameFrom, struct FName SocketOrBoneNameTo){

	static UObject* p_K2_DirectionBetweenSockets = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets");

	struct {
		struct USkeletalMeshComponent* Component;
		struct FName SocketOrBoneNameFrom;
		struct FName SocketOrBoneNameTo;
		struct FVector return_value;
	} parms;

	parms.Component = Component;
	parms.SocketOrBoneNameFrom = SocketOrBoneNameFrom;
	parms.SocketOrBoneNameTo = SocketOrBoneNameTo;

	ProcessEvent(p_K2_DirectionBetweenSockets, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_CalculateVelocityFromSockets(float DeltaSeconds, struct USkeletalMeshComponent* Component, struct FName SocketOrBoneName, struct FName ReferenceSocketOrBone, char ERelativeTransformSpace SocketSpace, struct FVector OffsetInBoneSpace, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax, uint8_t  EasingType, struct FRuntimeFloatCurve& CustomCurve){

	static UObject* p_K2_CalculateVelocityFromSockets = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets");

	struct {
		float DeltaSeconds;
		struct USkeletalMeshComponent* Component;
		struct FName SocketOrBoneName;
		struct FName ReferenceSocketOrBone;
		char ERelativeTransformSpace SocketSpace;
		struct FVector OffsetInBoneSpace;
		struct FPositionHistory& History;
		int32_t NumberOfSamples;
		float VelocityMin;
		float VelocityMax;
		uint8_t  EasingType;
		struct FRuntimeFloatCurve& CustomCurve;
		float return_value;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;
	parms.Component = Component;
	parms.SocketOrBoneName = SocketOrBoneName;
	parms.ReferenceSocketOrBone = ReferenceSocketOrBone;
	parms.SocketSpace = SocketSpace;
	parms.OffsetInBoneSpace = OffsetInBoneSpace;
	parms.History = History;
	parms.NumberOfSamples = NumberOfSamples;
	parms.VelocityMin = VelocityMin;
	parms.VelocityMax = VelocityMax;
	parms.EasingType = EasingType;
	parms.CustomCurve = CustomCurve;

	ProcessEvent(p_K2_CalculateVelocityFromSockets, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_CalculateVelocityFromPositionHistory(float DeltaSeconds, struct FVector Position, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax){

	static UObject* p_K2_CalculateVelocityFromPositionHistory = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory");

	struct {
		float DeltaSeconds;
		struct FVector Position;
		struct FPositionHistory& History;
		int32_t NumberOfSamples;
		float VelocityMin;
		float VelocityMax;
		float return_value;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;
	parms.Position = Position;
	parms.History = History;
	parms.NumberOfSamples = NumberOfSamples;
	parms.VelocityMin = VelocityMin;
	parms.VelocityMax = VelocityMax;

	ProcessEvent(p_K2_CalculateVelocityFromPositionHistory, &parms);
	return parms.return_value;
}

void UObject::OnNotifyEndReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload){

	static UObject* p_OnNotifyEndReceived = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived");

	struct {
		struct FName NotifyName;
		struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload;
	} parms;

	parms.NotifyName = NotifyName;
	parms.BranchingPointNotifyPayload = BranchingPointNotifyPayload;

	ProcessEvent(p_OnNotifyEndReceived, &parms);
}

void UObject::OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload){

	static UObject* p_OnNotifyBeginReceived = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived");

	struct {
		struct FName NotifyName;
		struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload;
	} parms;

	parms.NotifyName = NotifyName;
	parms.BranchingPointNotifyPayload = BranchingPointNotifyPayload;

	ProcessEvent(p_OnNotifyBeginReceived, &parms);
}

void UObject::OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted){

	static UObject* p_OnMontageEnded = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded");

	struct {
		struct UAnimMontage* Montage;
		bool bInterrupted;
	} parms;

	parms.Montage = Montage;
	parms.bInterrupted = bInterrupted;

	ProcessEvent(p_OnMontageEnded, &parms);
}

void UObject::OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted){

	static UObject* p_OnMontageBlendingOut = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut");

	struct {
		struct UAnimMontage* Montage;
		bool bInterrupted;
	} parms;

	parms.Montage = Montage;
	parms.bInterrupted = bInterrupted;

	ProcessEvent(p_OnMontageBlendingOut, &parms);
}

struct UPlayMontageCallbackProxy* UObject::CreateProxyObjectForPlayMontage(struct USkeletalMeshComponent* InSkeletalMeshComponent, struct UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, struct FName StartingSection){

	static UObject* p_CreateProxyObjectForPlayMontage = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage");

	struct {
		struct USkeletalMeshComponent* InSkeletalMeshComponent;
		struct UAnimMontage* MontageToPlay;
		float PlayRate;
		float StartingPosition;
		struct FName StartingSection;
		struct UPlayMontageCallbackProxy* return_value;
	} parms;

	parms.InSkeletalMeshComponent = InSkeletalMeshComponent;
	parms.MontageToPlay = MontageToPlay;
	parms.PlayRate = PlayRate;
	parms.StartingPosition = StartingPosition;
	parms.StartingSection = StartingSection;

	ProcessEvent(p_CreateProxyObjectForPlayMontage, &parms);
	return parms.return_value;
}

