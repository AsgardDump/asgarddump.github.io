#pragma once 
#include <_Weapon_Survivor_Default_Parameter_Structs.h>
 
 
 
// BlueprintGeneratedClass _Weapon_Survivor_Default_Parameter._Weapon_Survivor_Default_Parameter_C
// Size: 0xB70(Inherited: 0xB70) 
struct U_Weapon_Survivor_Default_Parameter_C : public UEDWeaponProjectileParameters
{

}; 



