#pragma once 
#include <BP_AnimGraphDeaditeGenDefault_AI_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C
// Size: 0x2CB0(Inherited: 0xDD0) 
struct UBP_AnimGraphDeaditeGenDefault_AI_C : public UEDAnimInstanceDeadite
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xDD0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0xDD8(0x30)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // 0xE08(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0xF60(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_5;  // 0xF88(0x48)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0xFD0(0x158)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x1128(0x158)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x1280(0x158)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x13D8(0xA0)
	char pad_5240[8];  // 0x1478(0x8)
	struct FSBAnimNode_HeadLookAt SBAnimGraphNode_HeadLookAt;  // 0x1480(0x130)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x15B0(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x15D0(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_30;  // 0x15F0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_29;  // 0x1618(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_28;  // 0x1640(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_27;  // 0x1668(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_26;  // 0x1690(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_25;  // 0x16B8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_24;  // 0x16E0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_23;  // 0x1708(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_22;  // 0x1730(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_21;  // 0x1758(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_20;  // 0x1780(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19;  // 0x17A8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18;  // 0x17D0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17;  // 0x17F8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16;  // 0x1820(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0x1848(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_12;  // 0x18C8(0x30)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_11;  // 0x18F8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0x1928(0x80)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x19A8(0x50)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_2;  // 0x19F8(0xC8)
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // 0x1AC0(0xC8)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x1B88(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_10;  // 0x1C08(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15;  // 0x1C38(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14;  // 0x1C60(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13;  // 0x1C88(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot_4;  // 0x1CB0(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // 0x1CF8(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12;  // 0x1D40(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;  // 0x1D68(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;  // 0x1D90(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;  // 0x1DB8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;  // 0x1DE0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;  // 0x1E08(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;  // 0x1E30(0x28)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_5;  // 0x1E58(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_9;  // 0x1F40(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // 0x1F70(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x1F98(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x1FC0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x1FE8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x2010(0x28)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_4;  // 0x2038(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8;  // 0x2120(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_3;  // 0x2150(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7;  // 0x2238(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer_2;  // 0x2268(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6;  // 0x2350(0x30)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer;  // 0x2380(0xE8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5;  // 0x2468(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_4;  // 0x2498(0xB0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0x2548(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // 0x2578(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x25C0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x2640(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_3;  // 0x2670(0xB0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x2720(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2;  // 0x2750(0xB0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x2800(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x2830(0xB0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x28E0(0x80)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x2960(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x2988(0x28)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x29B0(0xC0)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x2A70(0x80)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x2AF0(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x2B18(0x48)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x2B60(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x2C68(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x2C88(0x20)
	float GaitBeforeStopping;  // 0x2CA8(0x4)
	float DirectionBeforeStopping;  // 0x2CAC(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimGraph
	void AnimNotify_Left_NotMoving(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_NotMoving
	void AnimNotify_Entered_NotMoving(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_NotMoving
	void AnimNotify_Entered_Moving(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_Moving
	void AnimNotify_Left_Moving(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_Moving
	void AnimNotify_Entered_Pivot(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_Pivot
	void AnimNotify_Left_Pivot(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_Pivot
	void AnimNotify_Entered_Stopping(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Entered_Stopping
	void AnimNotify_Left_Stopping(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Left_Stopping
	void AnimNotify_Land(); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.AnimNotify_Land
	void ExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI(int32_t EntryPoint); // Function BP_AnimGraphDeaditeGenDefault_AI.BP_AnimGraphDeaditeGenDefault_AI_C.ExecuteUbergraph_BP_AnimGraphDeaditeGenDefault_AI
}; 



