#pragma once 
#include <AnimSet_Gen-FE_Common_Blunderbuss_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen-FE_Common_Blunderbuss.AnimSet_Gen-FE_Common_Blunderbuss_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen-FE_Common_Blunderbuss_C : public UEDAnimSetRangedWeapon
{

}; 



