#pragma once 
#include <BP_ActiveSkillAnnieKnowby_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillAnnieKnowby.BP_ActiveSkillAnnieKnowby_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillAnnieKnowby_C : public UEDConditionsTriggerActiveSkillAnnieKnowby
{

}; 



