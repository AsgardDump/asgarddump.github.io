#pragma once 
#include <BP_AnimGraphCharacter_LeftLowerarmTwist_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphCharacter_LeftLowerarmTwist.BP_AnimGraphCharacter_LeftLowerarmTwist_C
// Size: 0x558(Inherited: 0x2C0) 
struct UBP_AnimGraphCharacter_LeftLowerarmTwist_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;  // 0x2F8(0x118)
	struct FAnimNode_Constraint AnimGraphNode_Constraint;  // 0x410(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x518(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x538(0x20)

	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function BP_AnimGraphCharacter_LeftLowerarmTwist.BP_AnimGraphCharacter_LeftLowerarmTwist_C.AnimGraph
	void ExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist(int32_t EntryPoint); // Function BP_AnimGraphCharacter_LeftLowerarmTwist.BP_AnimGraphCharacter_LeftLowerarmTwist_C.ExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist
}; 



