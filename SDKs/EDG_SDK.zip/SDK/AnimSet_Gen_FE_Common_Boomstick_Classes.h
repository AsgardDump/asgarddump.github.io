#pragma once 
#include <AnimSet_Gen_FE_Common_Boomstick_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_FE_Common_Boomstick.AnimSet_Gen_FE_Common_Boomstick_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen_FE_Common_Boomstick_C : public UEDAnimSetRangedWeapon
{

}; 



