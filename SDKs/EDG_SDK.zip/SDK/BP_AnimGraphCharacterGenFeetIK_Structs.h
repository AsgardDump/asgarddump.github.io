#pragma once 
#include "SDK.h" 
 
 
// Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.ExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaTimeX;  // 0x4(0x4)

}; 
// Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.AnimGraph
// Size: 0x20(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink InPose;  // 0x0(0x10)
	struct FPoseLink AnimGraph;  // 0x10(0x10)

}; 
