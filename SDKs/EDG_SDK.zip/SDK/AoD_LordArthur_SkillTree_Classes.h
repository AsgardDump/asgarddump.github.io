#pragma once 
#include <AoD_LordArthur_SkillTree_Structs.h>
 
 
 
// BlueprintGeneratedClass AoD_LordArthur_SkillTree.AoD_LordArthur_SkillTree_C
// Size: 0x108(Inherited: 0x108) 
struct UAoD_LordArthur_SkillTree_C : public ULeader_SkillTree_C
{

}; 



