#pragma once 
#include "SDK.h" 
 
 
// Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.Set name as BP
// Size: 0x50(Inherited: 0x0) 
struct FSet name as BP
{
	A_Pickup_TapeLootBox_C* CallFunc_GetObjectClass_ReturnValue;  // 0x0(0x8)
	struct FString CallFunc_GetClassDisplayName_ReturnValue;  // 0x8(0x10)
	struct FString CallFunc_LeftChop_ReturnValue;  // 0x18(0x10)
	struct FString CallFunc_RightChop_ReturnValue;  // 0x28(0x10)
	struct FText CallFunc_Conv_StringToText_ReturnValue;  // 0x38(0x18)

}; 
// Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.Set World Rotation Z to 0
// Size: 0xAC(Inherited: 0x0) 
struct FSet World Rotation Z to 0
{
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x0(0xC)
	float CallFunc_BreakRotator_Roll;  // 0xC(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x10(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x14(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x18(0xC)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x24(0x88)

}; 
