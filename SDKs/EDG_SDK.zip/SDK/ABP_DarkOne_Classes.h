#pragma once 
#include <ABP_DarkOne_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_DarkOne.ABP_DarkOne_C
// Size: 0xB40(Inherited: 0x2C0) 
struct UABP_DarkOne_C : public UEDAnimInstanceDarkOne
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x2C8(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19;  // 0x2F8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18;  // 0x320(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17;  // 0x348(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16;  // 0x370(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15;  // 0x398(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14;  // 0x3C0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13;  // 0x3E8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12;  // 0x410(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;  // 0x438(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;  // 0x460(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;  // 0x488(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;  // 0x4B0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;  // 0x4D8(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;  // 0x500(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // 0x528(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // 0x550(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x578(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x5A0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x5C8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_6;  // 0x5F0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6;  // 0x670(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // 0x6A0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5;  // 0x720(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x750(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // 0x7D0(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x800(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // 0x880(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x8B0(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x930(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x960(0x80)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x9E0(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0xA10(0xB0)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0xAC0(0x48)
	float RandomStartingAnimationTime;  // 0xB08(0x4)
	char pad_2828[4];  // 0xB0C(0x4)
	struct UAnimSequence* IdleAnimation;  // 0xB10(0x8)
	struct UAnimSequence* AgressiveIdleAnimation;  // 0xB18(0x8)
	struct UAnimSequence* DeathAnimation;  // 0xB20(0x8)
	struct UAnimSequence* ReceiveDamageAnimation;  // 0xB28(0x8)
	struct UAnimSequence* RefreshPhaseAnimation;  // 0xB30(0x8)
	struct UAnimSequence* TeleportAnimation;  // 0xB38(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_DarkOne.ABP_DarkOne_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_6CCD174942821D8F3F8774B19BD45CCE(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_6CCD174942821D8F3F8774B19BD45CCE
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_E16A16F64BD77E8B9F435EB406638DD0(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_E16A16F64BD77E8B9F435EB406638DD0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_15D1ECED4F36A2E9BF9E018E5B275598(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_15D1ECED4F36A2E9BF9E018E5B275598
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_7D90731C42FC315EC58FDE9DE548FEEC(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_7D90731C42FC315EC58FDE9DE548FEEC
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_B5559E064C89D32C70665EA0F978F13E(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_B5559E064C89D32C70665EA0F978F13E
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_1250EC1744D1E1D9BDE0BAB458A13983(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_1250EC1744D1E1D9BDE0BAB458A13983
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_A9EE8E22423A9FC8CFCE638ADF657C49(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_A9EE8E22423A9FC8CFCE638ADF657C49
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_58E00FAF46813BBCABC05FB00B159021(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_58E00FAF46813BBCABC05FB00B159021
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_C56B8E314C74931FAF3ABF89779AFA5A(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_C56B8E314C74931FAF3ABF89779AFA5A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_FD34EA2E4217F719A68DC0831C442CBB(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_FD34EA2E4217F719A68DC0831C442CBB
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_87BDDAE64B966583AAE081B3F7A3D80F(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_87BDDAE64B966583AAE081B3F7A3D80F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_0A78A40642E747B4501F0FA52F62995C(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_0A78A40642E747B4501F0FA52F62995C
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_4C170F544D9F14EE589D17BEDF619899(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_4C170F544D9F14EE589D17BEDF619899
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_4F3B274740FF2D97520BB49021B446C7(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_4F3B274740FF2D97520BB49021B446C7
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_D826BA8C4FACB5EC45F1D89D3BC077A9(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_D826BA8C4FACB5EC45F1D89D3BC077A9
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_AA0017914DAF8F47554861A88140B688(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_AA0017914DAF8F47554861A88140B688
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_9796F356455CA2895B8829AB28DAA662(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_9796F356455CA2895B8829AB28DAA662
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_BF56F89048D05995B6BB77B3FA971B52(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_BF56F89048D05995B6BB77B3FA971B52
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_494DE1A2409C82475A12BABDE75B2583(); // Function ABP_DarkOne.ABP_DarkOne_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_DarkOne_AnimGraphNode_TransitionResult_494DE1A2409C82475A12BABDE75B2583
	void BlueprintInitializeAnimation(); // Function ABP_DarkOne.ABP_DarkOne_C.BlueprintInitializeAnimation
	void ExecuteUbergraph_ABP_DarkOne(int32_t EntryPoint); // Function ABP_DarkOne.ABP_DarkOne_C.ExecuteUbergraph_ABP_DarkOne
}; 



