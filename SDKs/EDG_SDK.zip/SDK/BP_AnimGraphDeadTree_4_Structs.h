#pragma once 
#include "SDK.h" 
 
 
// Function BP_AnimGraphDeadTree_4.BP_AnimGraphDeadTree_3_C.ExecuteUbergraph_BP_AnimGraphDeadTree_4
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AnimGraphDeadTree_4
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function BP_AnimGraphDeadTree_4.BP_AnimGraphDeadTree_3_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
