#pragma once 
#include "SDK.h" 
 
 
// Function Ansel.AnselFunctionLibrary.IsPhotographyAvailable
// Size: 0x1(Inherited: 0x0) 
struct FIsPhotographyAvailable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Ansel.AnselFunctionLibrary.ConstrainCameraByDistance
// Size: 0x40(Inherited: 0x0) 
struct FConstrainCameraByDistance
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector NewCameraLocation;  // 0x8(0xC)
	struct FVector PreviousCameraLocation;  // 0x14(0xC)
	struct FVector OriginalCameraLocation;  // 0x20(0xC)
	struct FVector OutCameraLocation;  // 0x2C(0xC)
	float MaxDistance;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// Function Ansel.AnselFunctionLibrary.ConstrainCameraByExtents
// Size: 0x30(Inherited: 0x0) 
struct FConstrainCameraByExtents
{
	struct FVector NewCameraLocation;  // 0x0(0xC)
	struct FVector OriginalLocation;  // 0xC(0xC)
	struct FVector OutCameraLocation;  // 0x18(0xC)
	struct FVector Extents;  // 0x24(0xC)

}; 
// Function Ansel.AnselFunctionLibrary.IsPhotographyAllowed
// Size: 0x1(Inherited: 0x0) 
struct FIsPhotographyAllowed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Ansel.AnselFunctionLibrary.ConstrainCameraByGeometry
// Size: 0x38(Inherited: 0x0) 
struct FConstrainCameraByGeometry
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FVector NewCameraLocation;  // 0x8(0xC)
	struct FVector PreviousCameraLocation;  // 0x14(0xC)
	struct FVector OriginalCameraLocation;  // 0x20(0xC)
	struct FVector OutCameraLocation;  // 0x2C(0xC)

}; 
// Function Ansel.AnselFunctionLibrary.SetAutoPause
// Size: 0x1(Inherited: 0x0) 
struct FSetAutoPause
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldAutoPause : 1;  // 0x0(0x1)

}; 
// Function Ansel.AnselFunctionLibrary.StopSession
// Size: 0x8(Inherited: 0x0) 
struct FStopSession
{
	struct UObject* WorldContextObject;  // 0x0(0x8)

}; 
// Function Ansel.AnselFunctionLibrary.SetAutoPostprocess
// Size: 0x1(Inherited: 0x0) 
struct FSetAutoPostprocess
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldAutoPostprocess : 1;  // 0x0(0x1)

}; 
// Function Ansel.AnselFunctionLibrary.SetCameraConstraintCameraSize
// Size: 0x4(Inherited: 0x0) 
struct FSetCameraConstraintCameraSize
{
	float CameraSize;  // 0x0(0x4)

}; 
// Function Ansel.AnselFunctionLibrary.SetCameraConstraintDistance
// Size: 0x4(Inherited: 0x0) 
struct FSetCameraConstraintDistance
{
	float MaxCameraDistance;  // 0x0(0x4)

}; 
// Function Ansel.AnselFunctionLibrary.SetCameraMovementSpeed
// Size: 0x4(Inherited: 0x0) 
struct FSetCameraMovementSpeed
{
	float TranslationSpeed;  // 0x0(0x4)

}; 
// Function Ansel.AnselFunctionLibrary.SetUIControlVisibility
// Size: 0x10(Inherited: 0x0) 
struct FSetUIControlVisibility
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	char EUIControlEffectTarget UIControlTarget;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bIsVisible : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)

}; 
// Function Ansel.AnselFunctionLibrary.SetIsPhotographyAllowed
// Size: 0x1(Inherited: 0x0) 
struct FSetIsPhotographyAllowed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsPhotographyAllowed : 1;  // 0x0(0x1)

}; 
// Function Ansel.AnselFunctionLibrary.SetSettleFrames
// Size: 0x4(Inherited: 0x0) 
struct FSetSettleFrames
{
	int32_t NumSettleFrames;  // 0x0(0x4)

}; 
// Function Ansel.AnselFunctionLibrary.StartSession
// Size: 0x8(Inherited: 0x0) 
struct FStartSession
{
	struct UObject* WorldContextObject;  // 0x0(0x8)

}; 
