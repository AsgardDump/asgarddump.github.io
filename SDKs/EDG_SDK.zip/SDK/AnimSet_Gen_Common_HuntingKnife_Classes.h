#pragma once 
#include <AnimSet_Gen_Common_HuntingKnife_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_HuntingKnife.AnimSet_Gen_Common_HuntingKnife_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Gen_Common_HuntingKnife_C : public UEDAnimSetMeleeWeapon
{

}; 



