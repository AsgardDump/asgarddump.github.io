#pragma once 
#include <_Weapon_Pegasus_Projectile_Default_Parameter_Structs.h>
 
 
 
// BlueprintGeneratedClass _Weapon_Pegasus_Projectile_Default_Parameter._Weapon_Pegasus_Projectile_Default_Parameter_C
// Size: 0xB70(Inherited: 0xB70) 
struct U_Weapon_Pegasus_Projectile_Default_Parameter_C : public UEDWeaponProjectileParameters
{

}; 



