#include "SDK.h" 
 
 
void AEDAmbientMusicManager::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AEDAmbientMusicManager::OnSceneAddedToStackEvent_Event_1(struct FName SceneUID, bool bForce){

	static UObject* p_OnSceneAddedToStackEvent_Event_1 = UObject::FindObject<UFunction>("Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.OnSceneAddedToStackEvent_Event_1");

	struct {
		struct FName SceneUID;
		bool bForce;
	} parms;

	parms.SceneUID = SceneUID;
	parms.bForce = bForce;

	ProcessEvent(p_OnSceneAddedToStackEvent_Event_1, &parms);
}

void AEDAmbientMusicManager::OnSceneRemovedFromStackEvent_Event_1(struct FName SceneUID, bool bForce){

	static UObject* p_OnSceneRemovedFromStackEvent_Event_1 = UObject::FindObject<UFunction>("Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.OnSceneRemovedFromStackEvent_Event_1");

	struct {
		struct FName SceneUID;
		bool bForce;
	} parms;

	parms.SceneUID = SceneUID;
	parms.bForce = bForce;

	ProcessEvent(p_OnSceneRemovedFromStackEvent_Event_1, &parms);
}

void AEDAmbientMusicManager::ExecuteUbergraph_AmbientMusicManagerMainMenu_BP(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AmbientMusicManagerMainMenu_BP = UObject::FindObject<UFunction>("Function AmbientMusicManagerMainMenu_BP.AmbientMusicManagerMainMenu_BP_C.ExecuteUbergraph_AmbientMusicManagerMainMenu_BP");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AmbientMusicManagerMainMenu_BP, &parms);
}

