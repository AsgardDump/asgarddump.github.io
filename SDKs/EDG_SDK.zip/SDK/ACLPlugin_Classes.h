#pragma once 
#include <ACLPlugin_Structs.h>
 
 
 
// Class ACLPlugin.AnimBoneCompressionCodec_ACL
// Size: 0x40(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACL : public UAnimBoneCompressionCodec_ACLBase
{
	struct UAnimBoneCompressionCodec* SafetyFallbackCodec;  // 0x38(0x8)

}; 



// Class ACLPlugin.AnimationCompressionLibraryDatabase
// Size: 0x140(Inherited: 0x28) 
struct UAnimationCompressionLibraryDatabase : public UObject
{
	struct TArray<char> CookedCompressedBytes;  // 0x28(0x10)
	struct TArray<uint64_t> CookedAnimSequenceMappings;  // 0x38(0x10)
	char pad_72[216];  // 0x48(0xD8)
	uint32_t MaxStreamRequestSizeKB;  // 0x120(0x4)
	char pad_292[28];  // 0x124(0x1C)

	void SetVisualFidelity(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, struct UAnimationCompressionLibraryDatabase* DatabaseAsset, uint8_t & Result, uint8_t  VisualFidelity); // Function ACLPlugin.AnimationCompressionLibraryDatabase.SetVisualFidelity
	uint8_t  GetVisualFidelity(struct UAnimationCompressionLibraryDatabase* DatabaseAsset); // Function ACLPlugin.AnimationCompressionLibraryDatabase.GetVisualFidelity
}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACLBase
// Size: 0x38(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACLBase : public UAnimBoneCompressionCodec
{

}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACLCustom
// Size: 0x38(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACLCustom : public UAnimBoneCompressionCodec_ACLBase
{

}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACLSafe
// Size: 0x38(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACLSafe : public UAnimBoneCompressionCodec_ACLBase
{

}; 



// Class ACLPlugin.AnimBoneCompressionCodec_ACLDatabase
// Size: 0x40(Inherited: 0x38) 
struct UAnimBoneCompressionCodec_ACLDatabase : public UAnimBoneCompressionCodec_ACLBase
{
	struct UAnimationCompressionLibraryDatabase* DatabaseAsset;  // 0x38(0x8)

}; 



// Class ACLPlugin.AnimCurveCompressionCodec_ACL
// Size: 0x28(Inherited: 0x28) 
struct UAnimCurveCompressionCodec_ACL : public UAnimCurveCompressionCodec
{

}; 



