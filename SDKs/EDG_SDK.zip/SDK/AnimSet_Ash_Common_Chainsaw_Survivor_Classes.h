#pragma once 
#include <AnimSet_Ash_Common_Chainsaw_Survivor_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Ash_Common_Chainsaw_Survivor.AnimSet_Ash_Common_Chainsaw_Survivor_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Ash_Common_Chainsaw_Survivor_C : public UEDAnimSetMeleeWeapon
{

}; 



