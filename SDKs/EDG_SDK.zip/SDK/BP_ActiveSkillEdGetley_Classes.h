#pragma once 
#include <BP_ActiveSkillEdGetley_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillEdGetley.BP_ActiveSkillEdGetley_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillEdGetley_C : public UEDConditionsTriggerActiveSkillEdGetley
{

}; 



