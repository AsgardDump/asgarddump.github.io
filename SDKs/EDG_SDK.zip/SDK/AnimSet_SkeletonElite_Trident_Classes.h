#pragma once 
#include <AnimSet_SkeletonElite_Trident_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_SkeletonElite_Trident.AnimSet_SkeletonElite_Trident_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_SkeletonElite_Trident_C : public UEDAnimSetMeleeWeapon
{

}; 



