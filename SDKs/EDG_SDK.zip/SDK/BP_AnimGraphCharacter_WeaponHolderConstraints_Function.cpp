#include "SDK.h" 
 
 
void UEDAnimInstance::AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.AnimGraph");

	struct {
		struct FPoseLink InPose;
		struct FPoseLink& AnimGraph;
	} parms;

	parms.InPose = InPose;
	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UEDAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints_AnimGraphNode_ModifyBone_9A0AE18D4949EC65D64477A1EF34F295(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints_AnimGraphNode_ModifyBone_9A0AE18D4949EC65D64477A1EF34F295 = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.EvaluateGraphExposedInputs_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints_AnimGraphNode_ModifyBone_9A0AE18D4949EC65D64477A1EF34F295");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints_AnimGraphNode_ModifyBone_9A0AE18D4949EC65D64477A1EF34F295, &parms);
}

void UEDAnimInstance::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UEDAnimInstance::ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints, &parms);
}

