#pragma once 
#include <AvED_BrockWilliams_SkillTree_Structs.h>
 
 
 
// BlueprintGeneratedClass AvED_BrockWilliams_SkillTree.AvED_BrockWilliams_SkillTree_C
// Size: 0x108(Inherited: 0x108) 
struct UAvED_BrockWilliams_SkillTree_C : public ULeader_SkillTree_C
{

}; 



