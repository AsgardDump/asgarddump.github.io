#pragma once 
#include <AnimSet_Gen_Common_Nailgun_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_Nailgun.AnimSet_Gen_Common_Nailgun_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen_Common_Nailgun_C : public UEDAnimSetRangedWeapon
{

}; 



