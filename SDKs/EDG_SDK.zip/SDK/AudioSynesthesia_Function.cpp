#include "SDK.h" 
 
 
void UAudioSynesthesiaNRT::GetNormalizedLoudnessAtTime(float InSeconds, float& OutLoudness){

	static UObject* p_GetNormalizedLoudnessAtTime = UObject::FindObject<UFunction>("Function AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime");

	struct {
		float InSeconds;
		float& OutLoudness;
	} parms;

	parms.InSeconds = InSeconds;
	parms.OutLoudness = OutLoudness;

	ProcessEvent(p_GetNormalizedLoudnessAtTime, &parms);
}

void UAudioSynesthesiaNRT::GetNormalizedChannelLoudnessAtTime(float InSeconds, int32_t InChannel, float& OutLoudness){

	static UObject* p_GetNormalizedChannelLoudnessAtTime = UObject::FindObject<UFunction>("Function AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime");

	struct {
		float InSeconds;
		int32_t InChannel;
		float& OutLoudness;
	} parms;

	parms.InSeconds = InSeconds;
	parms.InChannel = InChannel;
	parms.OutLoudness = OutLoudness;

	ProcessEvent(p_GetNormalizedChannelLoudnessAtTime, &parms);
}

void UAudioSynesthesiaNRT::GetLoudnessAtTime(float InSeconds, float& OutLoudness){

	static UObject* p_GetLoudnessAtTime = UObject::FindObject<UFunction>("Function AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime");

	struct {
		float InSeconds;
		float& OutLoudness;
	} parms;

	parms.InSeconds = InSeconds;
	parms.OutLoudness = OutLoudness;

	ProcessEvent(p_GetLoudnessAtTime, &parms);
}

void UAudioSynesthesiaNRT::GetChannelLoudnessAtTime(float InSeconds, int32_t InChannel, float& OutLoudness){

	static UObject* p_GetChannelLoudnessAtTime = UObject::FindObject<UFunction>("Function AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime");

	struct {
		float InSeconds;
		int32_t InChannel;
		float& OutLoudness;
	} parms;

	parms.InSeconds = InSeconds;
	parms.InChannel = InChannel;
	parms.OutLoudness = OutLoudness;

	ProcessEvent(p_GetChannelLoudnessAtTime, &parms);
}

void UAudioSynesthesiaNRT::GetNormalizedChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32_t InChannel, struct TArray<float>& OutOnsetTimestamps, struct TArray<float>& OutOnsetStrengths){

	static UObject* p_GetNormalizedChannelOnsetsBetweenTimes = UObject::FindObject<UFunction>("Function AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes");

	struct {
		float InStartSeconds;
		float InEndSeconds;
		int32_t InChannel;
		struct TArray<float>& OutOnsetTimestamps;
		struct TArray<float>& OutOnsetStrengths;
	} parms;

	parms.InStartSeconds = InStartSeconds;
	parms.InEndSeconds = InEndSeconds;
	parms.InChannel = InChannel;
	parms.OutOnsetTimestamps = OutOnsetTimestamps;
	parms.OutOnsetStrengths = OutOnsetStrengths;

	ProcessEvent(p_GetNormalizedChannelOnsetsBetweenTimes, &parms);
}

void UAudioSynesthesiaNRT::GetChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32_t InChannel, struct TArray<float>& OutOnsetTimestamps, struct TArray<float>& OutOnsetStrengths){

	static UObject* p_GetChannelOnsetsBetweenTimes = UObject::FindObject<UFunction>("Function AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes");

	struct {
		float InStartSeconds;
		float InEndSeconds;
		int32_t InChannel;
		struct TArray<float>& OutOnsetTimestamps;
		struct TArray<float>& OutOnsetStrengths;
	} parms;

	parms.InStartSeconds = InStartSeconds;
	parms.InEndSeconds = InEndSeconds;
	parms.InChannel = InChannel;
	parms.OutOnsetTimestamps = OutOnsetTimestamps;
	parms.OutOnsetStrengths = OutOnsetStrengths;

	ProcessEvent(p_GetChannelOnsetsBetweenTimes, &parms);
}

void UAudioSynesthesiaNRT::GetNormalizedChannelConstantQAtTime(float InSeconds, int32_t InChannel, struct TArray<float>& OutConstantQ){

	static UObject* p_GetNormalizedChannelConstantQAtTime = UObject::FindObject<UFunction>("Function AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime");

	struct {
		float InSeconds;
		int32_t InChannel;
		struct TArray<float>& OutConstantQ;
	} parms;

	parms.InSeconds = InSeconds;
	parms.InChannel = InChannel;
	parms.OutConstantQ = OutConstantQ;

	ProcessEvent(p_GetNormalizedChannelConstantQAtTime, &parms);
}

void UAudioSynesthesiaNRT::GetChannelConstantQAtTime(float InSeconds, int32_t InChannel, struct TArray<float>& OutConstantQ){

	static UObject* p_GetChannelConstantQAtTime = UObject::FindObject<UFunction>("Function AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime");

	struct {
		float InSeconds;
		int32_t InChannel;
		struct TArray<float>& OutConstantQ;
	} parms;

	parms.InSeconds = InSeconds;
	parms.InChannel = InChannel;
	parms.OutConstantQ = OutConstantQ;

	ProcessEvent(p_GetChannelConstantQAtTime, &parms);
}

