#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::TakeGameplayAutomationScreenshot(struct FString ScreenshotName, float MaxGlobalError, float MaxLocalError, struct FString MapNameOverride){

	static UObject* p_TakeGameplayAutomationScreenshot = UObject::FindObject<UFunction>("Function AutomationUtils.AutomationUtilsBlueprintLibrary.TakeGameplayAutomationScreenshot");

	struct {
		struct FString ScreenshotName;
		float MaxGlobalError;
		float MaxLocalError;
		struct FString MapNameOverride;
	} parms;

	parms.ScreenshotName = ScreenshotName;
	parms.MaxGlobalError = MaxGlobalError;
	parms.MaxLocalError = MaxLocalError;
	parms.MapNameOverride = MapNameOverride;

	ProcessEvent(p_TakeGameplayAutomationScreenshot, &parms);
}

