#pragma once 
#include <_C_AI_Deadite_SurvivorDefault_Parameter_Structs.h>
 
 
 
// BlueprintGeneratedClass _C_AI_Deadite_SurvivorDefault_Parameter._C_AI_Deadite_SurvivorDefault_Parameter_C
// Size: 0x3DA8(Inherited: 0x3DA8) 
struct U_C_AI_Deadite_SurvivorDefault_Parameter_C : public U_C_AI_Deadite_Parameter_Default_C
{

}; 



