#pragma once 
#include <AoD_HenryTheRed_SkillTree_Structs.h>
 
 
 
// BlueprintGeneratedClass AoD_HenryTheRed_SkillTree.AoD_HenryTheRed_SkillTree_C
// Size: 0x108(Inherited: 0x108) 
struct UAoD_HenryTheRed_SkillTree_C : public UWarrior_SkillTree_C
{

}; 



