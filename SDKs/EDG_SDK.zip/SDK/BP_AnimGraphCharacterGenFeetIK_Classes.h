#pragma once 
#include <BP_AnimGraphCharacterGenFeetIK_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C
// Size: 0x13F0(Inherited: 0x4C0) 
struct UBP_AnimGraphCharacterGenFeetIK_C : public UEDAnimInstanceFeetIK
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x4C0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x4C8(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput;  // 0x4F8(0x118)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // 0x610(0x158)
	char pad_1896[8];  // 0x768(0x8)
	struct FEDAnimNode_HandToWeaponIK EDAnimGraphNode_HandToWeaponIK_2;  // 0x770(0x200)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x970(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x998(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x9B8(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0xAC0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0xBC8(0x108)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0xCD0(0x20)
	struct FEDAnimNode_HandToWeaponIK EDAnimGraphNode_HandToWeaponIK;  // 0xCF0(0x200)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0xEF0(0x158)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x1048(0xA0)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x10E8(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x1110(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x1138(0x158)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x1290(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x12B8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x12D8(0x20)
	struct FAnimNode_LegIK AnimGraphNode_LegIK;  // 0x12F8(0xF8)

	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.AnimGraph
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK(int32_t EntryPoint); // Function BP_AnimGraphCharacterGenFeetIK.BP_AnimGraphCharacterGenFeetIK_C.ExecuteUbergraph_BP_AnimGraphCharacterGenFeetIK
}; 



