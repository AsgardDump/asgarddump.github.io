#pragma once 
#include <_C_AI_PitDeadite_Parameter_Elite_Structs.h>
 
 
 
// BlueprintGeneratedClass _C_AI_PitDeadite_Parameter_Elite._C_AI_PitDeadite_Parameter_Elite_C
// Size: 0x3DA8(Inherited: 0x3DA8) 
struct U_C_AI_PitDeadite_Parameter_Elite_C : public UEDCharacterParametersNPC
{

}; 



