#include "SDK.h" 
 
 
void AEDLootBoxPoint::Set World Rotation Z to 0(){

	static UObject* p_Set World Rotation Z to 0 = UObject::FindObject<UFunction>("Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.Set World Rotation Z to 0");

	struct {
	} parms;


	ProcessEvent(p_Set World Rotation Z to 0, &parms);
}

void AEDLootBoxPoint::Set name as BP(){

	static UObject* p_Set name as BP = UObject::FindObject<UFunction>("Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.Set name as BP");

	struct {
	} parms;


	ProcessEvent(p_Set name as BP, &parms);
}

void AEDLootBoxPoint::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function _Pickup_TapeLootBox._Pickup_TapeLootBox_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

