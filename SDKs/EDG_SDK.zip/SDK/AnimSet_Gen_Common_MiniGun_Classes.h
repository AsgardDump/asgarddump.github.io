#pragma once 
#include <AnimSet_Gen_Common_MiniGun_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_MiniGun.AnimSet_Gen_Common_MiniGun_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen_Common_MiniGun_C : public UEDAnimSetRangedWeapon
{

}; 



