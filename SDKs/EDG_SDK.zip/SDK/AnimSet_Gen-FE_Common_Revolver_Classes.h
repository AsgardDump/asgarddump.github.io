#pragma once 
#include <AnimSet_Gen-FE_Common_Revolver_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen-FE_Common_Revolver.AnimSet_Gen-FE_Common_Revolver_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_Gen-FE_Common_Revolver_C : public UEDAnimSetRangedWeapon
{

}; 



