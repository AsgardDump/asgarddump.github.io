#pragma once 
#include <AnimSet_Survivor_Interaction_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Survivor_Interaction.AnimSet_Survivor_Interaction_C
// Size: 0x98(Inherited: 0x98) 
struct UAnimSet_Survivor_Interaction_C : public UEDAnimSetInteractable
{

}; 



