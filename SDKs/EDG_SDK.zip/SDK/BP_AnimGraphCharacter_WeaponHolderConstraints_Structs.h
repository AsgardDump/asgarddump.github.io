#pragma once 
#include "SDK.h" 
 
 
// Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints
// Size: 0x14(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsOwnerCrouching_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float K2Node_Event_DeltaTimeX;  // 0x8(0x4)
	int32_t CallFunc_Conv_BoolToInt_ReturnValue;  // 0xC(0x4)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x10(0x4)

}; 
// Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.AnimGraph
// Size: 0x20(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink InPose;  // 0x0(0x10)
	struct FPoseLink AnimGraph;  // 0x10(0x10)

}; 
