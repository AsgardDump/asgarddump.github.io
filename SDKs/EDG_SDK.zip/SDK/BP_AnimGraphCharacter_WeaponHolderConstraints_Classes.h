#pragma once 
#include <BP_AnimGraphCharacter_WeaponHolderConstraints_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C
// Size: 0xD18(Inherited: 0x330) 
struct UBP_AnimGraphCharacter_WeaponHolderConstraints_C : public UEDAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x330(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x338(0x30)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;  // 0x368(0x118)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_7;  // 0x480(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x588(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x5A8(0x20)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_6;  // 0x5C8(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_5;  // 0x6D0(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_4;  // 0x7D8(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_3;  // 0x8E0(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint_2;  // 0x9E8(0x108)
	struct FAnimNode_Constraint AnimGraphNode_Constraint;  // 0xAF0(0x108)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0xBF8(0x108)
	struct FVector Translation;  // 0xD00(0xC)
	struct FRotator Rotation;  // 0xD0C(0xC)

	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints_AnimGraphNode_ModifyBone_9A0AE18D4949EC65D64477A1EF34F295(); // Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.EvaluateGraphExposedInputs_ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints_AnimGraphNode_ModifyBone_9A0AE18D4949EC65D64477A1EF34F295
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints(int32_t EntryPoint); // Function BP_AnimGraphCharacter_WeaponHolderConstraints.BP_AnimGraphCharacter_WeaponHolderConstraints_C.ExecuteUbergraph_BP_AnimGraphCharacter_WeaponHolderConstraints
}; 



