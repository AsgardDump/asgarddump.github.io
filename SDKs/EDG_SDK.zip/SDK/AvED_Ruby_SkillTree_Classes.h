#pragma once 
#include <AvED_Ruby_SkillTree_Structs.h>
 
 
 
// BlueprintGeneratedClass AvED_Ruby_SkillTree.AvED_Ruby_SkillTree_C
// Size: 0x108(Inherited: 0x108) 
struct UAvED_Ruby_SkillTree_C : public ULeader_SkillTree_C
{

}; 



