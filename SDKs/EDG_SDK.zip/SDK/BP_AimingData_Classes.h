#pragma once 
#include <BP_AimingData_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AimingData.BP_AimingData_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_AimingData_C : public UEDAimingData
{

}; 



