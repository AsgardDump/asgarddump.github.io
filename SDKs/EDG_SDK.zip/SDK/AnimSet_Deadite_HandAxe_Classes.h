#pragma once 
#include <AnimSet_Deadite_HandAxe_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Deadite_HandAxe.AnimSet_Deadite_HandAxe_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Deadite_HandAxe_C : public UEDAnimSetMeleeWeapon
{

}; 



