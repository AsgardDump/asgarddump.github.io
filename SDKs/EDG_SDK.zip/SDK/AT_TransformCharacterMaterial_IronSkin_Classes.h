#pragma once 
#include <AT_TransformCharacterMaterial_IronSkin_Structs.h>
 
 
 
// BlueprintGeneratedClass AT_TransformCharacterMaterial_IronSkin.AT_TransformCharacterMaterial_IronSkin_C
// Size: 0x170(Inherited: 0x170) 
struct UAT_TransformCharacterMaterial_IronSkin_C : public UEDAbilityTask_TransformCharacterMaterial
{

}; 



