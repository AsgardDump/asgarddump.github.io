#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacter_LeftLowerarmTwist.BP_AnimGraphCharacter_LeftLowerarmTwist_C.AnimGraph");

	struct {
		struct FPoseLink InPose;
		struct FPoseLink& AnimGraph;
	} parms;

	parms.InPose = InPose;
	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::ExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist = UObject::FindObject<UFunction>("Function BP_AnimGraphCharacter_LeftLowerarmTwist.BP_AnimGraphCharacter_LeftLowerarmTwist_C.ExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AnimGraphCharacter_LeftLowerarmTwist, &parms);
}

