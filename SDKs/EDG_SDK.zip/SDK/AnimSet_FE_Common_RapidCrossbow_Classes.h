#pragma once 
#include <AnimSet_FE_Common_RapidCrossbow_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_FE_Common_RapidCrossbow.AnimSet_FE_Common_RapidCrossbow_C
// Size: 0x768(Inherited: 0x768) 
struct UAnimSet_FE_Common_RapidCrossbow_C : public UEDAnimSetRangedWeapon
{

}; 



