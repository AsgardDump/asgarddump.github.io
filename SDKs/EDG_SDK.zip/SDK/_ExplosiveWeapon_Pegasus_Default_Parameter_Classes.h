#pragma once 
#include <_ExplosiveWeapon_Pegasus_Default_Parameter_Structs.h>
 
 
 
// BlueprintGeneratedClass _ExplosiveWeapon_Pegasus_Default_Parameter._ExplosiveWeapon_Pegasus_Default_Parameter_C
// Size: 0xBD0(Inherited: 0xBD0) 
struct U_ExplosiveWeapon_Pegasus_Default_Parameter_C : public UEDWeaponProjectileExplosiveParameters
{

}; 



