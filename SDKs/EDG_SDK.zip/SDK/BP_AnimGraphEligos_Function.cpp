#include "SDK.h" 
 
 
void UEDAnimInstanceEligos::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function BP_AnimGraphEligos.BP_AnimGraphEligos_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UEDAnimInstanceEligos::ExecuteUbergraph_BP_AnimGraphEligos(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AnimGraphEligos = UObject::FindObject<UFunction>("Function BP_AnimGraphEligos.BP_AnimGraphEligos_C.ExecuteUbergraph_BP_AnimGraphEligos");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AnimGraphEligos, &parms);
}

