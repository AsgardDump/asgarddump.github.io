#pragma once 
#include <BP_ActiveSkillKellyMaxwell_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillKellyMaxwell.BP_ActiveSkillKellyMaxwell_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillKellyMaxwell_C : public UEDConditionsTriggerActiveSkillKellyMaxwell
{

}; 



