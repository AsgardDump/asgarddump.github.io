#pragma once 
#include <BP_ActiveSkillScotty_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillScotty.BP_ActiveSkillScotty_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillScotty_C : public UEDConditionsTriggerActiveSkillScotty
{

}; 



