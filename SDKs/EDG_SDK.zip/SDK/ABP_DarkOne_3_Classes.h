#pragma once 
#include <ABP_DarkOne_3_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_DarkOne_3.ABP_DarkOne_2_C
// Size: 0xB40(Inherited: 0xB40) 
struct UABP_DarkOne_2_C : public UABP_DarkOne_C
{

}; 



