#pragma once 
#include <BP_AnimGraphEligos_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphEligos.BP_AnimGraphEligos_C
// Size: 0x1008(Inherited: 0xDC0) 
struct UBP_AnimGraphEligos_C : public UEDAnimInstanceEligos
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xDC0(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0xDC8(0x30)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0xDF8(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0xE40(0x80)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0xEC0(0x108)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0xFC8(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0xFE8(0x20)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function BP_AnimGraphEligos.BP_AnimGraphEligos_C.AnimGraph
	void ExecuteUbergraph_BP_AnimGraphEligos(int32_t EntryPoint); // Function BP_AnimGraphEligos.BP_AnimGraphEligos_C.ExecuteUbergraph_BP_AnimGraphEligos
}; 



