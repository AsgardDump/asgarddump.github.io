#pragma once 
#include <AnimSet_Gen_FE_Common_Mace_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_FE_Common_Mace.AnimSet_Gen_FE_Common_Mace_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Gen_FE_Common_Mace_C : public UEDAnimSetMeleeWeapon
{

}; 



