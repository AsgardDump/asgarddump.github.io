#pragma once 
#include <AnimSet_Gen_Common_Sword_EvilAsh_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_Gen_Common_Sword_EvilAsh.AnimSet_Gen_Common_Sword_EvilAsh_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_Gen_Common_Sword_EvilAsh_C : public UEDAnimSetMeleeWeapon
{

}; 



