#pragma once 
#include <BP_AnimGraphDeaditeBerserkerGenDefault_Possessed_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass BP_AnimGraphDeaditeBerserkerGenDefault_Possessed.BP_AnimGraphDeaditeBerserkerGenDefault_Possessed_C
// Size: 0x2CB0(Inherited: 0x2CB0) 
struct UBP_AnimGraphDeaditeBerserkerGenDefault_Possessed_C : public UBP_AnimGraphDeaditeGenDefault_AI_C
{

}; 



