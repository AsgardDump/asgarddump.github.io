#pragma once 
#include <AoD_AshWilliams_SkillTree_Structs.h>
 
 
 
// BlueprintGeneratedClass AoD_AshWilliams_SkillTree.AoD_AshWilliams_SkillTree_C
// Size: 0x108(Inherited: 0x108) 
struct UAoD_AshWilliams_SkillTree_C : public UWarrior_SkillTree_C
{

}; 



