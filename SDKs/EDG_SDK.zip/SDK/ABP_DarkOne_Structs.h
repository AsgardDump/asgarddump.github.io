#pragma once 
#include "SDK.h" 
 
 
// Function ABP_DarkOne.ABP_DarkOne_C.ExecuteUbergraph_ABP_DarkOne
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_DarkOne
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x6(0x1)
	char pad_7_1 : 7;  // 0x7(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0x7(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_5 : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_6 : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_7 : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_8 : 1;  // 0xB(0x1)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_9 : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_10 : 1;  // 0xD(0x1)
	char pad_14_1 : 7;  // 0xE(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_11 : 1;  // 0xE(0x1)
	char pad_15_1 : 7;  // 0xF(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_12 : 1;  // 0xF(0x1)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_13 : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_14 : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_15 : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_16 : 1;  // 0x13(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_17 : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_18 : 1;  // 0x15(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_19 : 1;  // 0x16(0x1)
	char pad_23[1];  // 0x17(0x1)
	float CallFunc_RandomFloat_ReturnValue;  // 0x18(0x4)

}; 
// Function ABP_DarkOne.ABP_DarkOne_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
