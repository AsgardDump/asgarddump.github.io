#pragma once 
#include <AnimSet_PlaguedSkeleton_Swords_Structs.h>
 
 
 
// BlueprintGeneratedClass AnimSet_PlaguedSkeleton_Swords.AnimSet_PlaguedSkeleton_Swords_C
// Size: 0x358(Inherited: 0x358) 
struct UAnimSet_PlaguedSkeleton_Swords_C : public UEDAnimSetMeleeWeapon
{

}; 



