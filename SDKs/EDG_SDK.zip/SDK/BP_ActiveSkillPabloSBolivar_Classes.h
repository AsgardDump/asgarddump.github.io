#pragma once 
#include <BP_ActiveSkillPabloSBolivar_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActiveSkillPabloSBolivar.BP_ActiveSkillPabloSBolivar_C
// Size: 0x38(Inherited: 0x38) 
struct UBP_ActiveSkillPabloSBolivar_C : public UEDConditionsTriggerActiveSkillPabloSBolivar
{

}; 



