#pragma once 
#include <AbilityIcon_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass AbilityIcon.AbilityIcon_C
// Size: 0x3D8(Inherited: 0x3C8) 
struct UAbilityIcon_C : public UEDHUDAbilityIcon
{
	struct URichTextBlock* CooldownTimeText;  // 0x3C8(0x8)
	struct UImage* red_bg;  // 0x3D0(0x8)

}; 



