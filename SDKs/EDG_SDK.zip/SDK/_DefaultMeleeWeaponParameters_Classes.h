#pragma once 
#include <_DefaultMeleeWeaponParameters_Structs.h>
 
 
 
// BlueprintGeneratedClass _DefaultMeleeWeaponParameters._DefaultMeleeWeaponParameters_C
// Size: 0xC10(Inherited: 0xC10) 
struct U_DefaultMeleeWeaponParameters_C : public UEDWeaponMeleeParameters
{

}; 



