#pragma once 
#include <ActionIcon_Structs.h>
 
 
 
// WidgetBlueprintGeneratedClass ActionIcon.ActionIcon_C
// Size: 0x380(Inherited: 0x378) 
struct UActionIcon_C : public UEDHUDActionIcon
{
	struct UImage* red_bg;  // 0x378(0x8)

}; 



