#pragma once 
#include <ABP_CockRoach_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_CockRoach.ABP_CockRoach_C
// Size: 0x57D(Inherited: 0x350) 
struct UABP_CockRoach_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x360(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x368(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x370(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x390(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3E0(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x428(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x448(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x490(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4B0(0xC8)
	float PlayRate;  // 0x578(0x4)
	char pad_1404_1 : 7;  // 0x57C(0x1)
	bool IsEmfFive : 1;  // 0x57C(0x1)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_CockRoach.ABP_CockRoach_C.AnimGraph
	void ExecuteUbergraph_ABP_CockRoach(int32_t EntryPoint); // Function ABP_CockRoach.ABP_CockRoach_C.ExecuteUbergraph_ABP_CockRoach
}; 



