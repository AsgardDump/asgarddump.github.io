#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ABP_VoodooBaby.ABP_VoodooBaby_C.AnimBlueprintGeneratedConstantData
// Size: 0x120(Inherited: 0x120) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
