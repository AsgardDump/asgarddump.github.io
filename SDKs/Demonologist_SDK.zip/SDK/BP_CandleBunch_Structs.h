#pragma once 
#include "SDK.h" 
 
 
// Function BP_CandleBunch.BP_CandleBunch_C.LightProperties
// Size: 0x28(Inherited: 0x0) 
struct FLightProperties
{
	struct ULightComponent* Light Component;  // 0x0(0x8)
	double Light Intensity;  // 0x8(0x8)
	struct FColor Light Color;  // 0x10(0x4)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue;  // 0x14(0x10)
	float CallFunc_SetIntensity_NewIntensity_ImplicitCast;  // 0x24(0x4)

}; 
// Function BP_CandleBunch.BP_CandleBunch_C.MaterialProperties
// Size: 0x54(Inherited: 0x0) 
struct FMaterialProperties
{
	struct UStaticMeshComponent* Mesh;  // 0x0(0x8)
	double Light Intensity;  // 0x8(0x8)
	struct FColor Light Color;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool isLight : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool Temp_bool_Variable : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	struct FLinearColor CallFunc_Conv_ColorToLinearColor_ReturnValue;  // 0x18(0x10)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x28(0x8)
	struct UMaterialInterface* CallFunc_GetMaterial_ReturnValue;  // 0x30(0x8)
	double Temp_real_Variable;  // 0x38(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x40(0x8)
	double K2Node_Select_Default;  // 0x48(0x8)
	float CallFunc_SetScalarParameterValue_Value_ImplicitCast;  // 0x50(0x4)

}; 
// Function BP_CandleBunch.BP_CandleBunch_C.OverrideMeshMaterials
// Size: 0x5C(Inherited: 0x0) 
struct FOverrideMeshMaterials
{
	struct UStaticMeshComponent* Mesh;  // 0x0(0x8)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x8(0x10)
	struct TArray<struct UMaterialInterface*> InitMaterials;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t CallFunc_GetNumMaterials_ReturnValue;  // 0x2C(0x4)
	struct TArray<struct UMaterialInterface*> CallFunc_GetMaterials_ReturnValue;  // 0x30(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x40(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x44(0x4)
	struct UMaterialInterface* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x58(0x4)

}; 
