#pragma once 
#include <ABP_ThirdPersonFulu_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonFulu.ABP_ThirdPersonFulu_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonFulu_C : public UABP_ThirdPersonToolLayer_C
{

}; 



