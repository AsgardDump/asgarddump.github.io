#include "SDK.h" 
 
 
struct TArray<struct FVector> AActor::GetDegreePoints(){

	static UObject* p_GetDegreePoints = UObject::FindObject<UFunction>("Function BP_BasicEventBox.BP_BasicEventBox_C.GetDegreePoints");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetDegreePoints, &parms);
	return parms.return_value;
}

bool AActor::GetIsLookInteractionActive(){

	static UObject* p_GetIsLookInteractionActive = UObject::FindObject<UFunction>("Function BP_BasicEventBox.BP_BasicEventBox_C.GetIsLookInteractionActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsLookInteractionActive, &parms);
	return parms.return_value;
}

bool AActor::GetVisualActiveCondition(){

	static UObject* p_GetVisualActiveCondition = UObject::FindObject<UFunction>("Function BP_BasicEventBox.BP_BasicEventBox_C.GetVisualActiveCondition");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetVisualActiveCondition, &parms);
	return parms.return_value;
}

void AActor::GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule){

	static UObject* p_GetAttachmentDetails = UObject::FindObject<UFunction>("Function BP_BasicEventBox.BP_BasicEventBox_C.GetAttachmentDetails");

	struct {
		bool& IsManualAttachment;
		struct FTransform& RelativeTransform;
		struct USceneComponent*& AttachmentComponent;
		struct FName& SocketName;
		char& LocationRule;
		char& RotationRule;
		char& ScaleRule;
	} parms;

	parms.IsManualAttachment = IsManualAttachment;
	parms.RelativeTransform = RelativeTransform;
	parms.AttachmentComponent = AttachmentComponent;
	parms.SocketName = SocketName;
	parms.LocationRule = LocationRule;
	parms.RotationRule = RotationRule;
	parms.ScaleRule = ScaleRule;

	ProcessEvent(p_GetAttachmentDetails, &parms);
}

