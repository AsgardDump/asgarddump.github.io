#pragma once 
#include <A_Pickup_Rifle_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Pickup_Rifle.A_Pickup_Rifle_C
// Size: 0x2E0(Inherited: 0x2E0) 
struct AA_Pickup_Rifle_C : public AA_Pickup_C
{

}; 



