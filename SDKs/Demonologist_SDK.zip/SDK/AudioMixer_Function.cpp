#include "SDK.h" 
 
 
void USceneComponent::Stop(){

	static UObject* p_Stop = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.Stop");

	struct {
	} parms;


	ProcessEvent(p_Stop, &parms);
}

void USceneComponent::Start(){

	static UObject* p_Start = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.Start");

	struct {
	} parms;


	ProcessEvent(p_Start, &parms);
}

void USceneComponent::SetVolumeMultiplier(float VolumeMultiplier){

	static UObject* p_SetVolumeMultiplier = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.SetVolumeMultiplier");

	struct {
		float VolumeMultiplier;
	} parms;

	parms.VolumeMultiplier = VolumeMultiplier;

	ProcessEvent(p_SetVolumeMultiplier, &parms);
}

void USceneComponent::SetSubmixSend(struct USoundSubmixBase* Submix, float SendLevel){

	static UObject* p_SetSubmixSend = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.SetSubmixSend");

	struct {
		struct USoundSubmixBase* Submix;
		float SendLevel;
	} parms;

	parms.Submix = Submix;
	parms.SendLevel = SendLevel;

	ProcessEvent(p_SetSubmixSend, &parms);
}

void USceneComponent::SetOutputToBusOnly(bool bInOutputToBusOnly){

	static UObject* p_SetOutputToBusOnly = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.SetOutputToBusOnly");

	struct {
		bool bInOutputToBusOnly;
	} parms;

	parms.bInOutputToBusOnly = bInOutputToBusOnly;

	ProcessEvent(p_SetOutputToBusOnly, &parms);
}

void USceneComponent::SetLowPassFilterFrequency(float InLowPassFilterFrequency){

	static UObject* p_SetLowPassFilterFrequency = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.SetLowPassFilterFrequency");

	struct {
		float InLowPassFilterFrequency;
	} parms;

	parms.InLowPassFilterFrequency = InLowPassFilterFrequency;

	ProcessEvent(p_SetLowPassFilterFrequency, &parms);
}

void USceneComponent::SetLowPassFilterEnabled(bool InLowPassFilterEnabled){

	static UObject* p_SetLowPassFilterEnabled = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.SetLowPassFilterEnabled");

	struct {
		bool InLowPassFilterEnabled;
	} parms;

	parms.InLowPassFilterEnabled = InLowPassFilterEnabled;

	ProcessEvent(p_SetLowPassFilterEnabled, &parms);
}

bool USceneComponent::IsPlaying(){

	static UObject* p_IsPlaying = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.IsPlaying");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPlaying, &parms);
	return parms.return_value;
}

void USceneComponent::FadeOut(float FadeOutDuration, float FadeVolumeLevel, uint8_t  FadeCurve){

	static UObject* p_FadeOut = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.FadeOut");

	struct {
		float FadeOutDuration;
		float FadeVolumeLevel;
		uint8_t  FadeCurve;
	} parms;

	parms.FadeOutDuration = FadeOutDuration;
	parms.FadeVolumeLevel = FadeVolumeLevel;
	parms.FadeCurve = FadeCurve;

	ProcessEvent(p_FadeOut, &parms);
}

void USceneComponent::FadeIn(float FadeInDuration, float FadeVolumeLevel, float StartTime, uint8_t  FadeCurve){

	static UObject* p_FadeIn = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.FadeIn");

	struct {
		float FadeInDuration;
		float FadeVolumeLevel;
		float StartTime;
		uint8_t  FadeCurve;
	} parms;

	parms.FadeInDuration = FadeInDuration;
	parms.FadeVolumeLevel = FadeVolumeLevel;
	parms.StartTime = StartTime;
	parms.FadeCurve = FadeCurve;

	ProcessEvent(p_FadeIn, &parms);
}

void USceneComponent::AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel, uint8_t  FadeCurve){

	static UObject* p_AdjustVolume = UObject::FindObject<UFunction>("Function AudioMixer.SynthComponent.AdjustVolume");

	struct {
		float AdjustVolumeDuration;
		float AdjustVolumeLevel;
		uint8_t  FadeCurve;
	} parms;

	parms.AdjustVolumeDuration = AdjustVolumeDuration;
	parms.AdjustVolumeLevel = AdjustVolumeLevel;
	parms.FadeCurve = FadeCurve;

	ProcessEvent(p_AdjustVolume, &parms);
}

void USoundEffectSubmixPreset::SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel){

	static UObject* p_SetSettingsWithReverbEffect = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect");

	struct {
		struct UReverbEffect* InReverbEffect;
		float WetLevel;
		float DryLevel;
	} parms;

	parms.InReverbEffect = InReverbEffect;
	parms.WetLevel = WetLevel;
	parms.DryLevel = DryLevel;

	ProcessEvent(p_SetSettingsWithReverbEffect, &parms);
}

void USoundEffectSubmixPreset::SetSettings(struct FSubmixEffectReverbSettings& InSettings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectReverbPreset.SetSettings");

	struct {
		struct FSubmixEffectReverbSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetSettings, &parms);
}

float UBlueprintFunctionLibrary::TrimAudioCache(float InMegabytesToFree){

	static UObject* p_TrimAudioCache = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache");

	struct {
		float InMegabytesToFree;
		float return_value;
	} parms;

	parms.InMegabytesToFree = InMegabytesToFree;

	ProcessEvent(p_TrimAudioCache, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::SwapAudioOutputDevice(struct UObject* WorldContextObject, struct FString NewDeviceId, struct FDelegate& OnCompletedDeviceSwap){

	static UObject* p_SwapAudioOutputDevice = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.SwapAudioOutputDevice");

	struct {
		struct UObject* WorldContextObject;
		struct FString NewDeviceId;
		struct FDelegate& OnCompletedDeviceSwap;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.NewDeviceId = NewDeviceId;
	parms.OnCompletedDeviceSwap = OnCompletedDeviceSwap;

	ProcessEvent(p_SwapAudioOutputDevice, &parms);
}

struct USoundWave* UBlueprintFunctionLibrary::StopRecordingOutput(struct UObject* WorldContextObject, uint8_t  ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite){

	static UObject* p_StopRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		uint8_t  ExportType;
		struct FString Name;
		struct FString Path;
		struct USoundSubmix* SubmixToRecord;
		struct USoundWave* ExistingSoundWaveToOverwrite;
		struct USoundWave* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ExportType = ExportType;
	parms.Name = Name;
	parms.Path = Path;
	parms.SubmixToRecord = SubmixToRecord;
	parms.ExistingSoundWaveToOverwrite = ExistingSoundWaveToOverwrite;

	ProcessEvent(p_StopRecordingOutput, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::StopAudioBus(struct UObject* WorldContextObject, struct UAudioBus* AudioBus){

	static UObject* p_StopAudioBus = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StopAudioBus");

	struct {
		struct UObject* WorldContextObject;
		struct UAudioBus* AudioBus;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AudioBus = AudioBus;

	ProcessEvent(p_StopAudioBus, &parms);
}

void UBlueprintFunctionLibrary::StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing){

	static UObject* p_StopAnalyzingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToStopAnalyzing;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToStopAnalyzing = SubmixToStopAnalyzing;

	ProcessEvent(p_StopAnalyzingOutput, &parms);
}

void UBlueprintFunctionLibrary::StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord){

	static UObject* p_StartRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		float ExpectedDuration;
		struct USoundSubmix* SubmixToRecord;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ExpectedDuration = ExpectedDuration;
	parms.SubmixToRecord = SubmixToRecord;

	ProcessEvent(p_StartRecordingOutput, &parms);
}

void UBlueprintFunctionLibrary::StartAudioBus(struct UObject* WorldContextObject, struct UAudioBus* AudioBus){

	static UObject* p_StartAudioBus = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StartAudioBus");

	struct {
		struct UObject* WorldContextObject;
		struct UAudioBus* AudioBus;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AudioBus = AudioBus;

	ProcessEvent(p_StartAudioBus, &parms);
}

void UBlueprintFunctionLibrary::StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, uint8_t  FFTSize, uint8_t  InterpolationMethod, uint8_t  WindowType, float HopSize, uint8_t  SpectrumType){

	static UObject* p_StartAnalyzingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToAnalyze;
		uint8_t  FFTSize;
		uint8_t  InterpolationMethod;
		uint8_t  WindowType;
		float HopSize;
		uint8_t  SpectrumType;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToAnalyze = SubmixToAnalyze;
	parms.FFTSize = FFTSize;
	parms.InterpolationMethod = InterpolationMethod;
	parms.WindowType = WindowType;
	parms.HopSize = HopSize;
	parms.SpectrumType = SpectrumType;

	ProcessEvent(p_StartAnalyzingOutput, &parms);
}

void UBlueprintFunctionLibrary::SetSubmixEffectChainOverride(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct TArray<struct USoundEffectSubmixPreset*> SubmixEffectPresetChain, float FadeTimeSec){

	static UObject* p_SetSubmixEffectChainOverride = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.SetSubmixEffectChainOverride");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		struct TArray<struct USoundEffectSubmixPreset*> SubmixEffectPresetChain;
		float FadeTimeSec;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixEffectPresetChain = SubmixEffectPresetChain;
	parms.FadeTimeSec = FadeTimeSec;

	ProcessEvent(p_SetSubmixEffectChainOverride, &parms);
}

void UBlueprintFunctionLibrary::SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed){

	static UObject* p_SetBypassSourceEffectChainEntry = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		int32_t EntryIndex;
		bool bBypassed;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;
	parms.EntryIndex = EntryIndex;
	parms.bBypassed = bBypassed;

	ProcessEvent(p_SetBypassSourceEffectChainEntry, &parms);
}

void UBlueprintFunctionLibrary::ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause){

	static UObject* p_ResumeRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToPause;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToPause = SubmixToPause;

	ProcessEvent(p_ResumeRecordingOutput, &parms);
}

void UBlueprintFunctionLibrary::ReplaceSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_ReplaceSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* InSoundSubmix;
		int32_t SubmixChainIndex;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InSoundSubmix = InSoundSubmix;
	parms.SubmixChainIndex = SubmixChainIndex;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_ReplaceSubmixEffect, &parms);
}

void UBlueprintFunctionLibrary::ReplaceSoundEffectSubmix(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_ReplaceSoundEffectSubmix = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* InSoundSubmix;
		int32_t SubmixChainIndex;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InSoundSubmix = InSoundSubmix;
	parms.SubmixChainIndex = SubmixChainIndex;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_ReplaceSoundEffectSubmix, &parms);
}

void UBlueprintFunctionLibrary::RemoveSubmixEffectPresetAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex){

	static UObject* p_RemoveSubmixEffectPresetAtIndex = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		int32_t SubmixChainIndex;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixChainIndex = SubmixChainIndex;

	ProcessEvent(p_RemoveSubmixEffectPresetAtIndex, &parms);
}

void UBlueprintFunctionLibrary::RemoveSubmixEffectPreset(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_RemoveSubmixEffectPreset = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_RemoveSubmixEffectPreset, &parms);
}

void UBlueprintFunctionLibrary::RemoveSubmixEffectAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex){

	static UObject* p_RemoveSubmixEffectAtIndex = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectAtIndex");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		int32_t SubmixChainIndex;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixChainIndex = SubmixChainIndex;

	ProcessEvent(p_RemoveSubmixEffectAtIndex, &parms);
}

void UBlueprintFunctionLibrary::RemoveSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_RemoveSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_RemoveSubmixEffect, &parms);
}

void UBlueprintFunctionLibrary::RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex){

	static UObject* p_RemoveSourceEffectFromPresetChain = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		int32_t EntryIndex;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;
	parms.EntryIndex = EntryIndex;

	ProcessEvent(p_RemoveSourceEffectFromPresetChain, &parms);
}

void UBlueprintFunctionLibrary::RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_RemoveMasterSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_RemoveMasterSubmixEffect, &parms);
}

void UBlueprintFunctionLibrary::PrimeSoundForPlayback(struct USoundWave* SoundWave, struct FDelegate OnLoadCompletion){

	static UObject* p_PrimeSoundForPlayback = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback");

	struct {
		struct USoundWave* SoundWave;
		struct FDelegate OnLoadCompletion;
	} parms;

	parms.SoundWave = SoundWave;
	parms.OnLoadCompletion = OnLoadCompletion;

	ProcessEvent(p_PrimeSoundForPlayback, &parms);
}

void UBlueprintFunctionLibrary::PrimeSoundCueForPlayback(struct USoundCue* SoundCue){

	static UObject* p_PrimeSoundCueForPlayback = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback");

	struct {
		struct USoundCue* SoundCue;
	} parms;

	parms.SoundCue = SoundCue;

	ProcessEvent(p_PrimeSoundCueForPlayback, &parms);
}

void UBlueprintFunctionLibrary::PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause){

	static UObject* p_PauseRecordingOutput = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SubmixToPause;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixToPause = SubmixToPause;

	ProcessEvent(p_PauseRecordingOutput, &parms);
}

struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> UBlueprintFunctionLibrary::MakePresetSpectralAnalysisBandSettings(uint8_t  InBandPresetType, int32_t InNumBands, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec){

	static UObject* p_MakePresetSpectralAnalysisBandSettings = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.MakePresetSpectralAnalysisBandSettings");

	struct {
		uint8_t  InBandPresetType;
		int32_t InNumBands;
		int32_t InAttackTimeMsec;
		int32_t InReleaseTimeMsec;
		struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> return_value;
	} parms;

	parms.InBandPresetType = InBandPresetType;
	parms.InNumBands = InNumBands;
	parms.InAttackTimeMsec = InAttackTimeMsec;
	parms.InReleaseTimeMsec = InReleaseTimeMsec;

	ProcessEvent(p_MakePresetSpectralAnalysisBandSettings, &parms);
	return parms.return_value;
}

struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> UBlueprintFunctionLibrary::MakeMusicalSpectralAnalysisBandSettings(int32_t InNumSemitones, uint8_t  InStartingMusicalNote, int32_t InStartingOctave, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec){

	static UObject* p_MakeMusicalSpectralAnalysisBandSettings = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.MakeMusicalSpectralAnalysisBandSettings");

	struct {
		int32_t InNumSemitones;
		uint8_t  InStartingMusicalNote;
		int32_t InStartingOctave;
		int32_t InAttackTimeMsec;
		int32_t InReleaseTimeMsec;
		struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> return_value;
	} parms;

	parms.InNumSemitones = InNumSemitones;
	parms.InStartingMusicalNote = InStartingMusicalNote;
	parms.InStartingOctave = InStartingOctave;
	parms.InAttackTimeMsec = InAttackTimeMsec;
	parms.InReleaseTimeMsec = InReleaseTimeMsec;

	ProcessEvent(p_MakeMusicalSpectralAnalysisBandSettings, &parms);
	return parms.return_value;
}

struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> UBlueprintFunctionLibrary::MakeFullSpectrumSpectralAnalysisBandSettings(int32_t InNumBands, float InMinimumFrequency, float InMaximumFrequency, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec){

	static UObject* p_MakeFullSpectrumSpectralAnalysisBandSettings = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.MakeFullSpectrumSpectralAnalysisBandSettings");

	struct {
		int32_t InNumBands;
		float InMinimumFrequency;
		float InMaximumFrequency;
		int32_t InAttackTimeMsec;
		int32_t InReleaseTimeMsec;
		struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> return_value;
	} parms;

	parms.InNumBands = InNumBands;
	parms.InMinimumFrequency = InMinimumFrequency;
	parms.InMaximumFrequency = InMaximumFrequency;
	parms.InAttackTimeMsec = InAttackTimeMsec;
	parms.InReleaseTimeMsec = InReleaseTimeMsec;

	ProcessEvent(p_MakeFullSpectrumSpectralAnalysisBandSettings, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsAudioBusActive(struct UObject* WorldContextObject, struct UAudioBus* AudioBus){

	static UObject* p_IsAudioBusActive = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.IsAudioBusActive");

	struct {
		struct UObject* WorldContextObject;
		struct UAudioBus* AudioBus;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AudioBus = AudioBus;

	ProcessEvent(p_IsAudioBusActive, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze){

	static UObject* p_GetPhaseForFrequencies = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies");

	struct {
		struct UObject* WorldContextObject;
		struct TArray<float>& Frequencies;
		struct TArray<float>& Phases;
		struct USoundSubmix* SubmixToAnalyze;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Frequencies = Frequencies;
	parms.Phases = Phases;
	parms.SubmixToAnalyze = SubmixToAnalyze;

	ProcessEvent(p_GetPhaseForFrequencies, &parms);
}

int32_t UBlueprintFunctionLibrary::GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain){

	static UObject* p_GetNumberOfEntriesInSourceEffectChain = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;

	ProcessEvent(p_GetNumberOfEntriesInSourceEffectChain, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze){

	static UObject* p_GetMagnitudeForFrequencies = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies");

	struct {
		struct UObject* WorldContextObject;
		struct TArray<float>& Frequencies;
		struct TArray<float>& Magnitudes;
		struct USoundSubmix* SubmixToAnalyze;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Frequencies = Frequencies;
	parms.Magnitudes = Magnitudes;
	parms.SubmixToAnalyze = SubmixToAnalyze;

	ProcessEvent(p_GetMagnitudeForFrequencies, &parms);
}

void UBlueprintFunctionLibrary::GetCurrentAudioOutputDeviceName(struct UObject* WorldContextObject, struct FDelegate& OnObtainCurrentDeviceEvent){

	static UObject* p_GetCurrentAudioOutputDeviceName = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetCurrentAudioOutputDeviceName");

	struct {
		struct UObject* WorldContextObject;
		struct FDelegate& OnObtainCurrentDeviceEvent;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.OnObtainCurrentDeviceEvent = OnObtainCurrentDeviceEvent;

	ProcessEvent(p_GetCurrentAudioOutputDeviceName, &parms);
}

void UBlueprintFunctionLibrary::GetAvailableAudioOutputDevices(struct UObject* WorldContextObject, struct FDelegate& OnObtainDevicesEvent){

	static UObject* p_GetAvailableAudioOutputDevices = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.GetAvailableAudioOutputDevices");

	struct {
		struct UObject* WorldContextObject;
		struct FDelegate& OnObtainDevicesEvent;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.OnObtainDevicesEvent = OnObtainDevicesEvent;

	ProcessEvent(p_GetAvailableAudioOutputDevices, &parms);
}

struct FString UBlueprintFunctionLibrary::Conv_AudioOutputDeviceInfoToString(struct FAudioOutputDeviceInfo& Info){

	static UObject* p_Conv_AudioOutputDeviceInfoToString = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.Conv_AudioOutputDeviceInfoToString");

	struct {
		struct FAudioOutputDeviceInfo& Info;
		struct FString return_value;
	} parms;

	parms.Info = Info;

	ProcessEvent(p_Conv_AudioOutputDeviceInfoToString, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ClearSubmixEffects(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix){

	static UObject* p_ClearSubmixEffects = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;

	ProcessEvent(p_ClearSubmixEffects, &parms);
}

void UBlueprintFunctionLibrary::ClearSubmixEffectChainOverride(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, float FadeTimeSec){

	static UObject* p_ClearSubmixEffectChainOverride = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffectChainOverride");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		float FadeTimeSec;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.FadeTimeSec = FadeTimeSec;

	ProcessEvent(p_ClearSubmixEffectChainOverride, &parms);
}

void UBlueprintFunctionLibrary::ClearMasterSubmixEffects(struct UObject* WorldContextObject){

	static UObject* p_ClearMasterSubmixEffects = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects");

	struct {
		struct UObject* WorldContextObject;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_ClearMasterSubmixEffects, &parms);
}

int32_t UBlueprintFunctionLibrary::AddSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_AddSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundSubmix* SoundSubmix;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
		int32_t return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SoundSubmix = SoundSubmix;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_AddSubmixEffect, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry){

	static UObject* p_AddSourceEffectToPresetChain = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSourcePresetChain* PresetChain;
		struct FSourceEffectChainEntry Entry;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.PresetChain = PresetChain;
	parms.Entry = Entry;

	ProcessEvent(p_AddSourceEffectToPresetChain, &parms);
}

void UBlueprintFunctionLibrary::AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset){

	static UObject* p_AddMasterSubmixEffect = UObject::FindObject<UFunction>("Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect");

	struct {
		struct UObject* WorldContextObject;
		struct USoundEffectSubmixPreset* SubmixEffectPreset;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SubmixEffectPreset = SubmixEffectPreset;

	ProcessEvent(p_AddMasterSubmixEffect, &parms);
}

void USoundEffectSubmixPreset::SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings");

	struct {
		struct FSubmixEffectDynamicsProcessorSettings& Settings;
	} parms;

	parms.Settings = Settings;

	ProcessEvent(p_SetSettings, &parms);
}

void USoundEffectSubmixPreset::SetExternalSubmix(struct USoundSubmix* Submix){

	static UObject* p_SetExternalSubmix = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix");

	struct {
		struct USoundSubmix* Submix;
	} parms;

	parms.Submix = Submix;

	ProcessEvent(p_SetExternalSubmix, &parms);
}

void USoundEffectSubmixPreset::SetAudioBus(struct UAudioBus* AudioBus){

	static UObject* p_SetAudioBus = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetAudioBus");

	struct {
		struct UAudioBus* AudioBus;
	} parms;

	parms.AudioBus = AudioBus;

	ProcessEvent(p_SetAudioBus, &parms);
}

void USoundEffectSubmixPreset::ResetKey(){

	static UObject* p_ResetKey = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectDynamicsProcessorPreset.ResetKey");

	struct {
	} parms;


	ProcessEvent(p_ResetKey, &parms);
}

void USoundEffectSubmixPreset::SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings){

	static UObject* p_SetSettings = UObject::FindObject<UFunction>("Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings");

	struct {
		struct FSubmixEffectSubmixEQSettings& InSettings;
	} parms;

	parms.InSettings = InSettings;

	ProcessEvent(p_SetSettings, &parms);
}

void UObject::UnsubscribeFromTimeDivision(struct UObject* WorldContextObject, uint8_t  InQuantizationBoundary, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_UnsubscribeFromTimeDivision = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision");

	struct {
		struct UObject* WorldContextObject;
		uint8_t  InQuantizationBoundary;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InQuantizationBoundary = InQuantizationBoundary;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_UnsubscribeFromTimeDivision, &parms);
}

void UObject::UnsubscribeFromAllTimeDivisions(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_UnsubscribeFromAllTimeDivisions = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.UnsubscribeFromAllTimeDivisions");

	struct {
		struct UObject* WorldContextObject;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_UnsubscribeFromAllTimeDivisions, &parms);
}

void UObject::SubscribeToQuantizationEvent(struct UObject* WorldContextObject, uint8_t  InQuantizationBoundary, struct FDelegate& OnQuantizationEvent, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_SubscribeToQuantizationEvent = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.SubscribeToQuantizationEvent");

	struct {
		struct UObject* WorldContextObject;
		uint8_t  InQuantizationBoundary;
		struct FDelegate& OnQuantizationEvent;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InQuantizationBoundary = InQuantizationBoundary;
	parms.OnQuantizationEvent = OnQuantizationEvent;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_SubscribeToQuantizationEvent, &parms);
}

void UObject::SubscribeToAllQuantizationEvents(struct UObject* WorldContextObject, struct FDelegate& OnQuantizationEvent, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_SubscribeToAllQuantizationEvents = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.SubscribeToAllQuantizationEvents");

	struct {
		struct UObject* WorldContextObject;
		struct FDelegate& OnQuantizationEvent;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.OnQuantizationEvent = OnQuantizationEvent;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_SubscribeToAllQuantizationEvents, &parms);
}

void UObject::StopClock(struct UObject* WorldContextObject, bool CancelPendingEvents, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_StopClock = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.StopClock");

	struct {
		struct UObject* WorldContextObject;
		bool CancelPendingEvents;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.CancelPendingEvents = CancelPendingEvents;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_StopClock, &parms);
}

void UObject::StartOtherClock(struct UObject* WorldContextObject, struct FName OtherClockName, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate){

	static UObject* p_StartOtherClock = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.StartOtherClock");

	struct {
		struct UObject* WorldContextObject;
		struct FName OtherClockName;
		struct FQuartzQuantizationBoundary InQuantizationBoundary;
		struct FDelegate& InDelegate;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.OtherClockName = OtherClockName;
	parms.InQuantizationBoundary = InQuantizationBoundary;
	parms.InDelegate = InDelegate;

	ProcessEvent(p_StartOtherClock, &parms);
}

void UObject::StartClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_StartClock = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.StartClock");

	struct {
		struct UObject* WorldContextObject;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_StartClock, &parms);
}

void UObject::SetTicksPerSecond(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float TicksPerSecond){

	static UObject* p_SetTicksPerSecond = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.SetTicksPerSecond");

	struct {
		struct UObject* WorldContextObject;
		struct FQuartzQuantizationBoundary& QuantizationBoundary;
		struct FDelegate& Delegate;
		struct UQuartzClockHandle*& ClockHandle;
		float TicksPerSecond;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.QuantizationBoundary = QuantizationBoundary;
	parms.Delegate = Delegate;
	parms.ClockHandle = ClockHandle;
	parms.TicksPerSecond = TicksPerSecond;

	ProcessEvent(p_SetTicksPerSecond, &parms);
}

void UObject::SetThirtySecondNotesPerMinute(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float ThirtySecondsNotesPerMinute){

	static UObject* p_SetThirtySecondNotesPerMinute = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.SetThirtySecondNotesPerMinute");

	struct {
		struct UObject* WorldContextObject;
		struct FQuartzQuantizationBoundary& QuantizationBoundary;
		struct FDelegate& Delegate;
		struct UQuartzClockHandle*& ClockHandle;
		float ThirtySecondsNotesPerMinute;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.QuantizationBoundary = QuantizationBoundary;
	parms.Delegate = Delegate;
	parms.ClockHandle = ClockHandle;
	parms.ThirtySecondsNotesPerMinute = ThirtySecondsNotesPerMinute;

	ProcessEvent(p_SetThirtySecondNotesPerMinute, &parms);
}

void UObject::SetSecondsPerTick(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float SecondsPerTick){

	static UObject* p_SetSecondsPerTick = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.SetSecondsPerTick");

	struct {
		struct UObject* WorldContextObject;
		struct FQuartzQuantizationBoundary& QuantizationBoundary;
		struct FDelegate& Delegate;
		struct UQuartzClockHandle*& ClockHandle;
		float SecondsPerTick;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.QuantizationBoundary = QuantizationBoundary;
	parms.Delegate = Delegate;
	parms.ClockHandle = ClockHandle;
	parms.SecondsPerTick = SecondsPerTick;

	ProcessEvent(p_SetSecondsPerTick, &parms);
}

void UObject::SetMillisecondsPerTick(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float MillisecondsPerTick){

	static UObject* p_SetMillisecondsPerTick = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.SetMillisecondsPerTick");

	struct {
		struct UObject* WorldContextObject;
		struct FQuartzQuantizationBoundary& QuantizationBoundary;
		struct FDelegate& Delegate;
		struct UQuartzClockHandle*& ClockHandle;
		float MillisecondsPerTick;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.QuantizationBoundary = QuantizationBoundary;
	parms.Delegate = Delegate;
	parms.ClockHandle = ClockHandle;
	parms.MillisecondsPerTick = MillisecondsPerTick;

	ProcessEvent(p_SetMillisecondsPerTick, &parms);
}

void UObject::SetBeatsPerMinute(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float BeatsPerMinute){

	static UObject* p_SetBeatsPerMinute = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.SetBeatsPerMinute");

	struct {
		struct UObject* WorldContextObject;
		struct FQuartzQuantizationBoundary& QuantizationBoundary;
		struct FDelegate& Delegate;
		struct UQuartzClockHandle*& ClockHandle;
		float BeatsPerMinute;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.QuantizationBoundary = QuantizationBoundary;
	parms.Delegate = Delegate;
	parms.ClockHandle = ClockHandle;
	parms.BeatsPerMinute = BeatsPerMinute;

	ProcessEvent(p_SetBeatsPerMinute, &parms);
}

void UObject::ResumeClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_ResumeClock = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.ResumeClock");

	struct {
		struct UObject* WorldContextObject;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_ResumeClock, &parms);
}

void UObject::ResetTransportQuantized(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_ResetTransportQuantized = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.ResetTransportQuantized");

	struct {
		struct UObject* WorldContextObject;
		struct FQuartzQuantizationBoundary InQuantizationBoundary;
		struct FDelegate& InDelegate;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InQuantizationBoundary = InQuantizationBoundary;
	parms.InDelegate = InDelegate;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_ResetTransportQuantized, &parms);
}

void UObject::ResetTransport(struct UObject* WorldContextObject, struct FDelegate& InDelegate){

	static UObject* p_ResetTransport = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.ResetTransport");

	struct {
		struct UObject* WorldContextObject;
		struct FDelegate& InDelegate;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InDelegate = InDelegate;

	ProcessEvent(p_ResetTransport, &parms);
}

void UObject::PauseClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle){

	static UObject* p_PauseClock = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.PauseClock");

	struct {
		struct UObject* WorldContextObject;
		struct UQuartzClockHandle*& ClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockHandle = ClockHandle;

	ProcessEvent(p_PauseClock, &parms);
}

bool UObject::IsClockRunning(struct UObject* WorldContextObject){

	static UObject* p_IsClockRunning = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.IsClockRunning");

	struct {
		struct UObject* WorldContextObject;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_IsClockRunning, &parms);
	return parms.return_value;
}

float UObject::GetTicksPerSecond(struct UObject* WorldContextObject){

	static UObject* p_GetTicksPerSecond = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetTicksPerSecond");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetTicksPerSecond, &parms);
	return parms.return_value;
}

float UObject::GetThirtySecondNotesPerMinute(struct UObject* WorldContextObject){

	static UObject* p_GetThirtySecondNotesPerMinute = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetThirtySecondNotesPerMinute");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetThirtySecondNotesPerMinute, &parms);
	return parms.return_value;
}

float UObject::GetSecondsPerTick(struct UObject* WorldContextObject){

	static UObject* p_GetSecondsPerTick = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetSecondsPerTick");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetSecondsPerTick, &parms);
	return parms.return_value;
}

float UObject::GetMillisecondsPerTick(struct UObject* WorldContextObject){

	static UObject* p_GetMillisecondsPerTick = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetMillisecondsPerTick");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetMillisecondsPerTick, &parms);
	return parms.return_value;
}

float UObject::GetEstimatedRunTime(struct UObject* WorldContextObject){

	static UObject* p_GetEstimatedRunTime = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetEstimatedRunTime");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetEstimatedRunTime, &parms);
	return parms.return_value;
}

float UObject::GetDurationOfQuantizationTypeInSeconds(struct UObject* WorldContextObject, uint8_t & QuantizationType, float Multiplier){

	static UObject* p_GetDurationOfQuantizationTypeInSeconds = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetDurationOfQuantizationTypeInSeconds");

	struct {
		struct UObject* WorldContextObject;
		uint8_t & QuantizationType;
		float Multiplier;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.QuantizationType = QuantizationType;
	parms.Multiplier = Multiplier;

	ProcessEvent(p_GetDurationOfQuantizationTypeInSeconds, &parms);
	return parms.return_value;
}

struct FQuartzTransportTimeStamp UObject::GetCurrentTimestamp(struct UObject* WorldContextObject){

	static UObject* p_GetCurrentTimestamp = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetCurrentTimestamp");

	struct {
		struct UObject* WorldContextObject;
		struct FQuartzTransportTimeStamp return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetCurrentTimestamp, &parms);
	return parms.return_value;
}

float UObject::GetBeatsPerMinute(struct UObject* WorldContextObject){

	static UObject* p_GetBeatsPerMinute = UObject::FindObject<UFunction>("Function AudioMixer.QuartzClockHandle.GetBeatsPerMinute");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetBeatsPerMinute, &parms);
	return parms.return_value;
}

bool UTickableWorldSubsystem::IsQuartzEnabled(){

	static UObject* p_IsQuartzEnabled = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.IsQuartzEnabled");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsQuartzEnabled, &parms);
	return parms.return_value;
}

bool UTickableWorldSubsystem::IsClockRunning(struct UObject* WorldContextObject, struct FName ClockName){

	static UObject* p_IsClockRunning = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.IsClockRunning");

	struct {
		struct UObject* WorldContextObject;
		struct FName ClockName;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockName = ClockName;

	ProcessEvent(p_IsClockRunning, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetRoundTripMinLatency(struct UObject* WorldContextObject){

	static UObject* p_GetRoundTripMinLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetRoundTripMinLatency");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetRoundTripMinLatency, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetRoundTripMaxLatency(struct UObject* WorldContextObject){

	static UObject* p_GetRoundTripMaxLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetRoundTripMaxLatency");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetRoundTripMaxLatency, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetRoundTripAverageLatency(struct UObject* WorldContextObject){

	static UObject* p_GetRoundTripAverageLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetRoundTripAverageLatency");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetRoundTripAverageLatency, &parms);
	return parms.return_value;
}

struct UQuartzClockHandle* UTickableWorldSubsystem::GetHandleForClock(struct UObject* WorldContextObject, struct FName ClockName){

	static UObject* p_GetHandleForClock = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetHandleForClock");

	struct {
		struct UObject* WorldContextObject;
		struct FName ClockName;
		struct UQuartzClockHandle* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockName = ClockName;

	ProcessEvent(p_GetHandleForClock, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetGameThreadToAudioRenderThreadMinLatency(struct UObject* WorldContextObject){

	static UObject* p_GetGameThreadToAudioRenderThreadMinLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMinLatency");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetGameThreadToAudioRenderThreadMinLatency, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetGameThreadToAudioRenderThreadMaxLatency(struct UObject* WorldContextObject){

	static UObject* p_GetGameThreadToAudioRenderThreadMaxLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMaxLatency");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetGameThreadToAudioRenderThreadMaxLatency, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetGameThreadToAudioRenderThreadAverageLatency(struct UObject* WorldContextObject){

	static UObject* p_GetGameThreadToAudioRenderThreadAverageLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadAverageLatency");

	struct {
		struct UObject* WorldContextObject;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_GetGameThreadToAudioRenderThreadAverageLatency, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetEstimatedClockRunTime(struct UObject* WorldContextObject, struct FName& InClockName){

	static UObject* p_GetEstimatedClockRunTime = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetEstimatedClockRunTime");

	struct {
		struct UObject* WorldContextObject;
		struct FName& InClockName;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InClockName = InClockName;

	ProcessEvent(p_GetEstimatedClockRunTime, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetDurationOfQuantizationTypeInSeconds(struct UObject* WorldContextObject, struct FName ClockName, uint8_t & QuantizationType, float Multiplier){

	static UObject* p_GetDurationOfQuantizationTypeInSeconds = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetDurationOfQuantizationTypeInSeconds");

	struct {
		struct UObject* WorldContextObject;
		struct FName ClockName;
		uint8_t & QuantizationType;
		float Multiplier;
		float return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockName = ClockName;
	parms.QuantizationType = QuantizationType;
	parms.Multiplier = Multiplier;

	ProcessEvent(p_GetDurationOfQuantizationTypeInSeconds, &parms);
	return parms.return_value;
}

struct FQuartzTransportTimeStamp UTickableWorldSubsystem::GetCurrentClockTimestamp(struct UObject* WorldContextObject, struct FName& InClockName){

	static UObject* p_GetCurrentClockTimestamp = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetCurrentClockTimestamp");

	struct {
		struct UObject* WorldContextObject;
		struct FName& InClockName;
		struct FQuartzTransportTimeStamp return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InClockName = InClockName;

	ProcessEvent(p_GetCurrentClockTimestamp, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetAudioRenderThreadToGameThreadMinLatency(){

	static UObject* p_GetAudioRenderThreadToGameThreadMinLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMinLatency");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAudioRenderThreadToGameThreadMinLatency, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetAudioRenderThreadToGameThreadMaxLatency(){

	static UObject* p_GetAudioRenderThreadToGameThreadMaxLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMaxLatency");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAudioRenderThreadToGameThreadMaxLatency, &parms);
	return parms.return_value;
}

float UTickableWorldSubsystem::GetAudioRenderThreadToGameThreadAverageLatency(){

	static UObject* p_GetAudioRenderThreadToGameThreadAverageLatency = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadAverageLatency");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAudioRenderThreadToGameThreadAverageLatency, &parms);
	return parms.return_value;
}

bool UTickableWorldSubsystem::DoesClockExist(struct UObject* WorldContextObject, struct FName ClockName){

	static UObject* p_DoesClockExist = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.DoesClockExist");

	struct {
		struct UObject* WorldContextObject;
		struct FName ClockName;
		bool return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockName = ClockName;

	ProcessEvent(p_DoesClockExist, &parms);
	return parms.return_value;
}

void UTickableWorldSubsystem::DeleteClockByName(struct UObject* WorldContextObject, struct FName ClockName){

	static UObject* p_DeleteClockByName = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.DeleteClockByName");

	struct {
		struct UObject* WorldContextObject;
		struct FName ClockName;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockName = ClockName;

	ProcessEvent(p_DeleteClockByName, &parms);
}

void UTickableWorldSubsystem::DeleteClockByHandle(struct UObject* WorldContextObject, struct UQuartzClockHandle*& InClockHandle){

	static UObject* p_DeleteClockByHandle = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.DeleteClockByHandle");

	struct {
		struct UObject* WorldContextObject;
		struct UQuartzClockHandle*& InClockHandle;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.InClockHandle = InClockHandle;

	ProcessEvent(p_DeleteClockByHandle, &parms);
}

struct UQuartzClockHandle* UTickableWorldSubsystem::CreateNewClock(struct UObject* WorldContextObject, struct FName ClockName, struct FQuartzClockSettings InSettings, bool bOverrideSettingsIfClockExists, bool bUseAudioEngineClockManager){

	static UObject* p_CreateNewClock = UObject::FindObject<UFunction>("Function AudioMixer.QuartzSubsystem.CreateNewClock");

	struct {
		struct UObject* WorldContextObject;
		struct FName ClockName;
		struct FQuartzClockSettings InSettings;
		bool bOverrideSettingsIfClockExists;
		bool bUseAudioEngineClockManager;
		struct UQuartzClockHandle* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ClockName = ClockName;
	parms.InSettings = InSettings;
	parms.bOverrideSettingsIfClockExists = bOverrideSettingsIfClockExists;
	parms.bUseAudioEngineClockManager = bUseAudioEngineClockManager;

	ProcessEvent(p_CreateNewClock, &parms);
	return parms.return_value;
}

