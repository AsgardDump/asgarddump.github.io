#pragma once 
#include <BP_BasicCharacter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BasicCharacter.BP_BasicCharacter_C
// Size: 0x858(Inherited: 0x840) 
struct ABP_BasicCharacter_C : public ABP_PrimitiveCharacter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x840(0x8)
	struct UBP_PlayerComponent_C* BP_PlayerComponent;  // 0x848(0x8)
	double CameraPitchValue;  // 0x850(0x8)

	bool IsInteractionObjectExist(); // Function BP_BasicCharacter.BP_BasicCharacter_C.IsInteractionObjectExist
	void PreparePitchReplication(); // Function BP_BasicCharacter.BP_BasicCharacter_C.PreparePitchReplication
	void InitializeBasicCharacter(); // Function BP_BasicCharacter.BP_BasicCharacter_C.InitializeBasicCharacter
	void ReplicateCameraPitch(); // Function BP_BasicCharacter.BP_BasicCharacter_C.ReplicateCameraPitch
	struct FRotator GetLookDirection(); // Function BP_BasicCharacter.BP_BasicCharacter_C.GetLookDirection
	double GetCurrentObjectInteractionTime(); // Function BP_BasicCharacter.BP_BasicCharacter_C.GetCurrentObjectInteractionTime
	void InpActEvt_Interaction_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_BasicCharacter.BP_BasicCharacter_C.InpActEvt_Interaction_K2Node_InputActionEvent_2
	void InpActEvt_Interaction_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_BasicCharacter.BP_BasicCharacter_C.InpActEvt_Interaction_K2Node_InputActionEvent_1
	void ReceiveBeginPlay(); // Function BP_BasicCharacter.BP_BasicCharacter_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_BasicCharacter(int32_t EntryPoint); // Function BP_BasicCharacter.BP_BasicCharacter_C.ExecuteUbergraph_BP_BasicCharacter
}; 



