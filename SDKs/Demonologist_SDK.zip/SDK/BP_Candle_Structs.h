#pragma once 
#include "SDK.h" 
 
 
// Function BP_Candle.BP_Candle_C.InpActEvt_ToolInteraction_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ToolInteraction_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_Candle.BP_Candle_C.ExecuteUbergraph_BP_Candle
// Size: 0x328(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Candle
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FGameplayTag Temp_struct_Variable;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	struct ABP_SanityProtectionArea_C* CallFunc_GetProtectionArea_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct UTMWGlobalEventHandler* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x20(0x8)
	struct UTMWGlobalEventHandler* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct AActor* K2Node_ComponentBoundEvent_Instigator;  // 0x38(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct APawn* K2Node_Event_OldInstigator;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_Event_IsFirstInit : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct FKey K2Node_InputActionEvent_Key;  // 0x60(0x18)
	struct APawn* K2Node_CustomEvent_Instigator_2;  // 0x78(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x80(0x18)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x98(0x1)
	char pad_153[7];  // 0x99(0x7)
	struct UAudioComponent* CallFunc_SpawnSound2D_ReturnValue;  // 0xA0(0x8)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0xA8(0x10)
	float K2Node_Event_DeltaSeconds;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool CallFunc_IsServer_ReturnValue_2 : 1;  // 0xBD(0x1)
	char pad_190_1 : 7;  // 0xBE(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0xBE(0x1)
	char pad_191[1];  // 0xBF(0x1)
	struct UBP_Payload_QuestListenerInfo_C* CallFunc_SpawnObject_ReturnValue;  // 0xC0(0x8)
	struct FGameplayTag K2Node_CustomEvent_CompletedTag;  // 0xC8(0x8)
	double K2Node_CustomEvent_Progress;  // 0xD0(0x8)
	struct APawn* K2Node_CustomEvent_Instigator;  // 0xD8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xE0(0x10)
	struct ABP_Shivers_InGameState_C* CallFunc_Get_Shivers_in_Game_State_ReturnValue;  // 0xF0(0x8)
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // 0xF8(0x50)
	struct FS_QuestInformation CallFunc_FindQuestByType_ReturnValue;  // 0x148(0x70)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_FindQuestByType_IsSuccessful : 1;  // 0x1B8(0x1)
	char pad_441[3];  // 0x1B9(0x3)
	int32_t CallFunc_FindQuestByType_Index;  // 0x1BC(0x4)
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array_2;  // 0x1C0(0x10)
	struct FText CallFunc_Format_ReturnValue;  // 0x1D0(0x18)
	char pad_488_1 : 7;  // 0x1E8(0x1)
	bool CallFunc_CheckIsQuestProgressFinished_ReturnValue : 1;  // 0x1E8(0x1)
	char pad_489[7];  // 0x1E9(0x7)
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // 0x1F0(0x10)
	char pad_512_1 : 7;  // 0x200(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x200(0x1)
	char pad_513[7];  // 0x201(0x7)
	struct TArray<struct FS_QuestInformation> K2Node_CustomEvent_QuestTags;  // 0x208(0x10)
	struct ABP_Shivers_InGameState_C* CallFunc_Get_Shivers_in_Game_State_ReturnValue_2;  // 0x218(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x220(0x8)
	char pad_552_1 : 7;  // 0x228(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x228(0x1)
	char pad_553[7];  // 0x229(0x7)
	struct ABP_ShiversController_C* K2Node_DynamicCast_AsBP_Shivers_Controller;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x238(0x1)
	char pad_569_1 : 7;  // 0x239(0x1)
	bool CallFunc_RandomBoolWithWeight_ReturnValue : 1;  // 0x239(0x1)
	char pad_570[6];  // 0x23A(0x6)
	struct TArray<struct FName> K2Node_MakeArray_Array_3;  // 0x240(0x10)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool CallFunc_GetInteractionCondition_ReturnValue : 1;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct ABP_Entity_C* CallFunc_GetAiReference_ReturnValue;  // 0x258(0x8)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x260(0x8)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x268(0x4)
	char pad_620[4];  // 0x26C(0x4)
	struct ABP_Entity_C* CallFunc_GetAiReference_ReturnValue_2;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x278(0x1)
	char pad_633[3];  // 0x279(0x3)
	float CallFunc_GetDistanceTo_ReturnValue_2;  // 0x27C(0x4)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue_2 : 1;  // 0x280(0x1)
	char pad_641[3];  // 0x281(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x284(0x10)
	char pad_660_1 : 7;  // 0x294(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x294(0x1)
	char pad_661_1 : 7;  // 0x295(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x295(0x1)
	char pad_662[2];  // 0x296(0x2)
	struct TArray<struct FName> K2Node_MakeArray_Array_4;  // 0x298(0x10)
	struct FString K2Node_CustomEvent_result;  // 0x2A8(0x10)
	struct FName CallFunc_RecgonizeSpiritBoxCommand_MatchedCommand;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool CallFunc_RecgonizeSpiritBoxCommand_IsSuccessful : 1;  // 0x2C0(0x1)
	char pad_705[3];  // 0x2C1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x2C4(0x10)
	char pad_724[4];  // 0x2D4(0x4)
	struct TArray<struct FString> Temp_string_Variable;  // 0x2D8(0x10)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue_2;  // 0x2E8(0x8)
	struct TScriptInterface<IBPI_VoiceRecgonition_C> K2Node_DynamicCast_AsBPI_Voice_Recgonition;  // 0x2F0(0x10)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct USrsComponent* CallFunc_GetSrsComponent_ReturnValue;  // 0x308(0x8)
	char pad_784_1 : 7;  // 0x310(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x310(0x1)
	char pad_785[7];  // 0x311(0x7)
	double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast;  // 0x318(0x8)
	double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast_2;  // 0x320(0x8)

}; 
// Function BP_Candle.BP_Candle_C.BndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FBndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature
{
	struct AActor* Instigator;  // 0x0(0x8)

}; 
// Function BP_Candle.BP_Candle_C.GetInteractionCondition
// Size: 0x33(Inherited: 0x0) 
struct FGetInteractionCondition
{
	struct UObject* Payload;  // 0x0(0x8)
	struct TArray<struct FName> Identifier;  // 0x8(0x10)
	struct UBP_AiInteractionComponent_C* RequestInteractionComponent;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x32(0x1)

}; 
// Function BP_Candle.BP_Candle_C.GetIsFireOn
// Size: 0x1(Inherited: 0x0) 
struct FGetIsFireOn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Candle.BP_Candle_C.GetProtectionArea
// Size: 0x11(Inherited: 0x0) 
struct FGetProtectionArea
{
	struct ABP_SanityProtectionArea_C* ReturnValue;  // 0x0(0x8)
	struct ABP_SanityProtectionArea_C* K2Node_DynamicCast_AsBP_Sanity_Protection_Area;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_Candle.BP_Candle_C.OnCandleBlowAI
// Size: 0x8(Inherited: 0x0) 
struct FOnCandleBlowAI
{
	struct APawn* Instigator;  // 0x0(0x8)

}; 
// Function BP_Candle.BP_Candle_C.OnObjectInstigatorUpdatedCallback
// Size: 0x9(Inherited: 0x9) 
struct FOnObjectInstigatorUpdatedCallback : public FOnObjectInstigatorUpdatedCallback
{
	struct APawn* OldInstigator;  // 0x0(0x8)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IsFirstInit : 1;  // 0x8(0x1)

}; 
// Function BP_Candle.BP_Candle_C.OnQuestAddedCallback
// Size: 0x10(Inherited: 0x0) 
struct FOnQuestAddedCallback
{
	struct TArray<struct FS_QuestInformation> QuestTags;  // 0x0(0x10)

}; 
// Function BP_Candle.BP_Candle_C.OnQuestFinishedCallback
// Size: 0x18(Inherited: 0x0) 
struct FOnQuestFinishedCallback
{
	struct FGameplayTag CompletedTag;  // 0x0(0x8)
	double Progress;  // 0x8(0x8)
	struct APawn* Instigator;  // 0x10(0x8)

}; 
// Function BP_Candle.BP_Candle_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_Candle.BP_Candle_C.recognitionResultReceivedCallback
// Size: 0x10(Inherited: 0x0) 
struct FrecognitionResultReceivedCallback
{
	struct FString Result;  // 0x0(0x10)

}; 
// Function BP_Candle.BP_Candle_C.UpdateCandleVisibility
// Size: 0x38(Inherited: 0x0) 
struct FUpdateCandleVisibility
{
	double CallFunc_SelectFloat_ReturnValue;  // 0x0(0x8)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct ABP_SanityProtectionArea_C* CallFunc_GetProtectionArea_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct ABP_SanityProtectionArea_C* CallFunc_GetProtectionArea_ReturnValue_2;  // 0x28(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x30(0x4)
	float CallFunc_SetIntensity_NewIntensity_ImplicitCast;  // 0x34(0x4)

}; 
// Function BP_Candle.BP_Candle_C.UpdateFlameMovement
// Size: 0x148(Inherited: 0x0) 
struct FUpdateFlameMovement
{
	double CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x0(0x8)
	double CallFunc_GetWorldDeltaSeconds_ReturnValue_2;  // 0x8(0x8)
	double CallFunc_RandomFloatInRange_ReturnValue;  // 0x10(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue;  // 0x18(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0x20(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue_2;  // 0x28(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue_2;  // 0x30(0x8)
	double CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x38(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x40(0x18)
	float CallFunc_BreakVector3f_X;  // 0x58(0x4)
	float CallFunc_BreakVector3f_Y;  // 0x5C(0x4)
	float CallFunc_BreakVector3f_Z;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x68(0x18)
	float CallFunc_BreakVector3f_X_2;  // 0x80(0x4)
	float CallFunc_BreakVector3f_Y_2;  // 0x84(0x4)
	float CallFunc_BreakVector3f_Z_2;  // 0x88(0x4)
	char pad_140[4];  // 0x8C(0x4)
	double CallFunc_Subtract_DoubleDouble_ReturnValue_3;  // 0x90(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue_4;  // 0x98(0x8)
	double CallFunc_Divide_DoubleDouble_ReturnValue;  // 0xA0(0x8)
	double CallFunc_Divide_DoubleDouble_ReturnValue_2;  // 0xA8(0x8)
	double CallFunc_FClamp_ReturnValue;  // 0xB0(0x8)
	double CallFunc_FClamp_ReturnValue_2;  // 0xB8(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue_5;  // 0xC0(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue_6;  // 0xC8(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue_3;  // 0xD0(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue_4;  // 0xD8(0x8)
	double CallFunc_FClamp_ReturnValue_3;  // 0xE0(0x8)
	double CallFunc_FClamp_ReturnValue_4;  // 0xE8(0x8)
	double CallFunc_FClamp_ReturnValue_5;  // 0xF0(0x8)
	double CallFunc_FClamp_ReturnValue_6;  // 0xF8(0x8)
	float CallFunc_SetFloatParameter_Param_ImplicitCast;  // 0x100(0x4)
	float CallFunc_SetFloatParameter_Param_ImplicitCast_2;  // 0x104(0x4)
	struct FVector3f CallFunc_BreakVector3f_InVec_ImplicitCast;  // 0x108(0xC)
	char pad_276[4];  // 0x114(0x4)
	double K2Node_VariableSet_FlamePreviousLocationX_ImplicitCast;  // 0x118(0x8)
	double K2Node_VariableSet_PreviousLocationY_ImplicitCast;  // 0x120(0x8)
	struct FVector3f CallFunc_BreakVector3f_InVec_ImplicitCast_2;  // 0x128(0xC)
	char pad_308[4];  // 0x134(0x4)
	double CallFunc_Subtract_DoubleDouble_A_ImplicitCast;  // 0x138(0x8)
	double CallFunc_Subtract_DoubleDouble_A_ImplicitCast_2;  // 0x140(0x8)

}; 
