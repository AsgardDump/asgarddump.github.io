#pragma once 
#include "SDK.h" 
 
 
// Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.ExecuteUbergraph_ABP_UvLight_Tool
// Size: 0x52(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_UvLight_Tool
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x18(0x18)
	double CallFunc_VSize_ReturnValue;  // 0x30(0x8)
	float K2Node_Event_DeltaTimeX;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x40(0x8)
	struct ABP_BaseUvLight_C* K2Node_DynamicCast_AsBP_Base_Uv_Light;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x51(0x1)

}; 
// ScriptStruct ABP_UvLight_Tool.ABP_UvLight_Tool_C.AnimBlueprintGeneratedConstantData
// Size: 0x120(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_41;  // 0x4(0x8)
	struct FName __NameProperty_42;  // 0xC(0x8)
	int32_t __IntProperty_43;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool __BoolProperty_44 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float __FloatProperty_45;  // 0x1C(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_46;  // 0x20(0x2C)
	float __FloatProperty_47;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool __BoolProperty_48 : 1;  // 0x50(0x1)
	uint8_t  __EnumProperty_49;  // 0x51(0x1)
	char EAnimGroupRole __ByteProperty_50;  // 0x52(0x1)
	char pad_83[1];  // 0x53(0x1)
	struct FName __NameProperty_51;  // 0x54(0x8)
	struct FName __NameProperty_52;  // 0x5C(0x8)
	int32_t __IntProperty_53;  // 0x64(0x4)
	struct FAnimNodeFunctionRef __StructProperty_54;  // 0x68(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x88(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x108(0x18)

}; 
