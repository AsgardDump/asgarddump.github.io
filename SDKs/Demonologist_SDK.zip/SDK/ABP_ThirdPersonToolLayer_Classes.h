#pragma once 
#include <ABP_ThirdPersonToolLayer_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C
// Size: 0xB90(Inherited: 0x350) 
struct UABP_ThirdPersonToolLayer_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;  // 0x358(0x2)
	char pad_858[6];  // 0x35A(0x6)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x360(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x368(0x8)
	struct FAnimNode_Root AnimGraphNode_Root_2;  // 0x370(0x20)
	struct FAnimNode_LinkedInputPose AnimGraphNode_LinkedInputPose;  // 0x390(0xC8)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x458(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x480(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x4A8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x4F0(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x510(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x558(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x578(0xC8)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x640(0xE0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x720(0x48)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x768(0x48)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x7B0(0xE0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // 0x890(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // 0x998(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // 0x9C0(0x28)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x9E8(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0xAF0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0xB18(0x28)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0xB40(0x20)
	struct FVector K2Node_PropertyAccess;  // 0xB60(0x18)
	struct UAnimSequenceBase* IdleSequence;  // 0xB78(0x8)
	struct UAnimSequenceBase* WalkingSequence;  // 0xB80(0x8)
	char pad_2952_1 : 7;  // 0xB88(0x1)
	bool IsWalking : 1;  // 0xB88(0x1)
	char pad_2953_1 : 7;  // 0xB89(0x1)
	bool UseOnlyRightArm : 1;  // 0xB89(0x1)
	char pad_2954[2];  // 0xB8A(0x2)
	float BlendWeight;  // 0xB8C(0x4)

	void BaseState(struct FPoseLink BaseAnimation, struct FPoseLink& BaseState); // Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.BaseState
	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.BlueprintThreadSafeUpdateAnimation
	void ExecuteUbergraph_ABP_ThirdPersonToolLayer(int32_t EntryPoint); // Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.ExecuteUbergraph_ABP_ThirdPersonToolLayer
}; 



