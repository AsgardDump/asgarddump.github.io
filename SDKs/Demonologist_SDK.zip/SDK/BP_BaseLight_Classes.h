#pragma once 
#include <BP_BaseLight_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseLight.BP_BaseLight_C
// Size: 0x3A1(Inherited: 0x2A0) 
struct ABP_BaseLight_C : public AStaticMeshActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2A0(0x8)
	struct USphereComponent* MalFunctionCollision;  // 0x2A8(0x8)
	struct UAudioComponent* LightShattering;  // 0x2B0(0x8)
	float LightScenerio_LightIntensity_9015B65549CE4CFD0C625C886A38228A;  // 0x2B8(0x4)
	char ETimelineDirection LightScenerio__Direction_9015B65549CE4CFD0C625C886A38228A;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct UTimelineComponent* LightScenerio;  // 0x2C0(0x8)
	struct ULightComponent* LightReference;  // 0x2C8(0x8)
	struct TArray<struct UMaterialInstanceDynamic*> EmessiveMaterialInstances;  // 0x2D0(0x10)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool IsLightTurnOn : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)
	struct FMulticastInlineDelegate OnLightStatusChanged;  // 0x2E8(0x10)
	double LightIntensityMin;  // 0x2F8(0x8)
	double LightIntensityMax;  // 0x300(0x8)
	struct FName EmessivePowerParameterName;  // 0x308(0x8)
	double MeshEmessivePowerMin;  // 0x310(0x8)
	double MeshEmessivePowerMax;  // 0x318(0x8)
	struct FName EmessiveColorParameterName;  // 0x320(0x8)
	struct FLinearColor LightColor;  // 0x328(0x10)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool RangeIntensityAndEmessive : 1;  // 0x338(0x1)
	char pad_825[7];  // 0x339(0x7)
	struct FS_LightScenerio SelectedLightScenerio;  // 0x340(0x18)
	struct FS_LightScenerio InitialLightScenerio;  // 0x358(0x18)
	char E_SanityProtectionAreaType ProtectionAreaTypes;  // 0x370(0x1)
	char pad_881_1 : 7;  // 0x371(0x1)
	bool IsLightBroken : 1;  // 0x371(0x1)
	char pad_882[6];  // 0x372(0x6)
	struct FMulticastInlineDelegate OnLightBrokenStatusChanged;  // 0x378(0x10)
	char pad_904_1 : 7;  // 0x388(0x1)
	bool CanBeBroken : 1;  // 0x388(0x1)
	char pad_905_1 : 7;  // 0x389(0x1)
	bool CanEffectLightTension : 1;  // 0x389(0x1)
	char pad_906[6];  // 0x38A(0x6)
	struct TArray<struct ABP_BaseLight_C*> LightTensionLights;  // 0x390(0x10)
	char pad_928_1 : 7;  // 0x3A0(0x1)
	bool IsMalFunctioning : 1;  // 0x3A0(0x1)

	bool CanMalfunction(); // Function BP_BaseLight.BP_BaseLight_C.CanMalfunction
	void InitiliazeBaseLight(); // Function BP_BaseLight.BP_BaseLight_C.InitiliazeBaseLight
	bool GetIsLightActive(); // Function BP_BaseLight.BP_BaseLight_C.GetIsLightActive
	void OnRep_IsLightTurnOn(); // Function BP_BaseLight.BP_BaseLight_C.OnRep_IsLightTurnOn
	void OnRep_IsLightBroken(); // Function BP_BaseLight.BP_BaseLight_C.OnRep_IsLightBroken
	void GetIsLightTurnOn(bool& ReturnNode); // Function BP_BaseLight.BP_BaseLight_C.GetIsLightTurnOn
	void SetLightScenerio(struct FS_LightScenerio SelectedLightScenerio); // Function BP_BaseLight.BP_BaseLight_C.SetLightScenerio
	void OnRep_SelectedLightScenerio(); // Function BP_BaseLight.BP_BaseLight_C.OnRep_SelectedLightScenerio
	void UpdateEmessiveMaterialValues(); // Function BP_BaseLight.BP_BaseLight_C.UpdateEmessiveMaterialValues
	double GetTargetIntensity(); // Function BP_BaseLight.BP_BaseLight_C.GetTargetIntensity
	double GetLightIntensity(); // Function BP_BaseLight.BP_BaseLight_C.GetLightIntensity
	double GetTargetEmessivePower(double EmessivePercentage); // Function BP_BaseLight.BP_BaseLight_C.GetTargetEmessivePower
	void ReplaceMaterialsWithDynamics(); // Function BP_BaseLight.BP_BaseLight_C.ReplaceMaterialsWithDynamics
	void Set Light Turn Status(bool ActivationStatus, struct FName InstigatorIdentifier); // Function BP_BaseLight.BP_BaseLight_C.Set Light Turn Status
	void LightScenerio__FinishedFunc(); // Function BP_BaseLight.BP_BaseLight_C.LightScenerio__FinishedFunc
	void LightScenerio__UpdateFunc(); // Function BP_BaseLight.BP_BaseLight_C.LightScenerio__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_BaseLight.BP_BaseLight_C.ReceiveBeginPlay
	void SetLightScenerioServer(struct FS_LightScenerio LightScenerio); // Function BP_BaseLight.BP_BaseLight_C.SetLightScenerioServer
	void ChangeLightMode(struct FS_LightScenerio LightScenerio); // Function BP_BaseLight.BP_BaseLight_C.ChangeLightMode
	void ReceiveTick(float DeltaSeconds); // Function BP_BaseLight.BP_BaseLight_C.ReceiveTick
	void StartMalfunction(struct FName Identifier); // Function BP_BaseLight.BP_BaseLight_C.StartMalfunction
	void EndMalfunction(struct FName Identifier); // Function BP_BaseLight.BP_BaseLight_C.EndMalfunction
	void ExecuteUbergraph_BP_BaseLight(int32_t EntryPoint); // Function BP_BaseLight.BP_BaseLight_C.ExecuteUbergraph_BP_BaseLight
	void OnLightBrokenStatusChanged__DelegateSignature(); // Function BP_BaseLight.BP_BaseLight_C.OnLightBrokenStatusChanged__DelegateSignature
	void OnLightStatusChanged__DelegateSignature(bool IsActive); // Function BP_BaseLight.BP_BaseLight_C.OnLightStatusChanged__DelegateSignature
}; 



