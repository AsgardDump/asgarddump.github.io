#pragma once 
#include "SDK.h" 
 
 
// Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.CanInstigatorInteract
// Size: 0xC(Inherited: 0x76) 
struct FCanInstigatorInteract : public FCanInstigatorInteract
{
	struct AActor* Instigator;  // 0x0(0x8)
	char pad_126_1 : 7;  // 0x7E(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_127_1 : 7;  // 0x7F(0x1)
	bool CallFunc_CanInstigatorInteract_ReturnValue : 1;  // 0x9(0x1)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_CustomInteractionCondition_ReturnValue : 1;  // 0xA(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.ExecuteUbergraph_BP_AiEventInteractionComponent
// Size: 0xF9(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AiEventInteractionComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue;  // 0x8(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct AActor* K2Node_CustomEvent_Instigator;  // 0x18(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x20(0x8)
	struct TScriptInterface<IBPI_NewEntity_C> K2Node_DynamicCast_AsBPI_New_Entity;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UBP_EventBoxComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct TScriptInterface<IBPI_NewEntity_C> K2Node_DynamicCast_AsBPI_New_Entity_2;  // 0x50(0x10)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x71(0x1)
	char pad_114[2];  // 0x72(0x2)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x74(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x78(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x88(0x4)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool Temp_bool_Variable : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	struct TArray<struct AActor*> CallFunc_Map_Keys_Keys;  // 0x90(0x10)
	struct TArray<struct FName> CallFunc_Map_Values_Values;  // 0xA0(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0xB0(0x8)
	struct FName CallFunc_Array_Get_Item_2;  // 0xB8(0x8)
	struct USceneComponent* CallFunc_K2_GetRootComponent_ReturnValue_2;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct TArray<struct USceneComponent*> CallFunc_GetComponentsByTag_ReturnValue;  // 0xD0(0x10)
	struct USceneComponent* CallFunc_Array_Get_Item_3;  // 0xE0(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct USceneComponent* K2Node_Select_Default;  // 0xF0(0x8)
	char pad_248_1 : 7;  // 0xF8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xF8(0x1)

}; 
// Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.OnInteractionRequestedCallback
// Size: 0x8(Inherited: 0x0) 
struct FOnInteractionRequestedCallback
{
	struct AActor* Instigator;  // 0x0(0x8)

}; 
