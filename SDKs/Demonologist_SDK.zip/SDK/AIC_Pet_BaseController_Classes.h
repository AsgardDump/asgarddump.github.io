#pragma once 
#include <AIC_Pet_BaseController_Structs.h>
 
 
 
// BlueprintGeneratedClass AIC_Pet_BaseController.AIC_Pet_BaseController_C
// Size: 0x3C0(Inherited: 0x3B8) 
struct AAIC_Pet_BaseController_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3B8(0x8)

	void ReceiveBeginPlay(); // Function AIC_Pet_BaseController.AIC_Pet_BaseController_C.ReceiveBeginPlay
	void ExecuteUbergraph_AIC_Pet_BaseController(int32_t EntryPoint); // Function AIC_Pet_BaseController.AIC_Pet_BaseController_C.ExecuteUbergraph_AIC_Pet_BaseController
}; 



