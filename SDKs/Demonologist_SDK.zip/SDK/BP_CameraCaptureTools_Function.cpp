#include "SDK.h" 
 
 
bool ABP_Tool_C::CanDisableCaptureWhenOutsideOfRenderArea(){

	static UObject* p_CanDisableCaptureWhenOutsideOfRenderArea = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.CanDisableCaptureWhenOutsideOfRenderArea");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanDisableCaptureWhenOutsideOfRenderArea, &parms);
	return parms.return_value;
}

bool ABP_Tool_C::IsCurrentlyWatching(){

	static UObject* p_IsCurrentlyWatching = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.IsCurrentlyWatching");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsCurrentlyWatching, &parms);
	return parms.return_value;
}

struct ABP_ControlCamera_C* ABP_Tool_C::GetControlCameraReference(){

	static UObject* p_GetControlCameraReference = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.GetControlCameraReference");

	struct {
		struct ABP_ControlCamera_C* return_value;
	} parms;


	ProcessEvent(p_GetControlCameraReference, &parms);
	return parms.return_value;
}

bool ABP_Tool_C::IsOverlappingControlArea(){

	static UObject* p_IsOverlappingControlArea = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.IsOverlappingControlArea");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsOverlappingControlArea, &parms);
	return parms.return_value;
}

void ABP_Tool_C::InitializeCameraCaptureTool(){

	static UObject* p_InitializeCameraCaptureTool = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.InitializeCameraCaptureTool");

	struct {
	} parms;


	ProcessEvent(p_InitializeCameraCaptureTool, &parms);
}

void ABP_Tool_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_Tool_C::CheckCameraStatus(){

	static UObject* p_CheckCameraStatus = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.CheckCameraStatus");

	struct {
	} parms;


	ProcessEvent(p_CheckCameraStatus, &parms);
}

void ABP_Tool_C::ReceiveDestroyed(){

	static UObject* p_ReceiveDestroyed = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.ReceiveDestroyed");

	struct {
	} parms;


	ProcessEvent(p_ReceiveDestroyed, &parms);
}

void ABP_Tool_C::OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit){

	static UObject* p_OnObjectInstigatorUpdatedCallback = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.OnObjectInstigatorUpdatedCallback");

	struct {
		struct APawn* OldInstigator;
		bool IsFirstInit;
	} parms;

	parms.OldInstigator = OldInstigator;
	parms.IsFirstInit = IsFirstInit;

	ProcessEvent(p_OnObjectInstigatorUpdatedCallback, &parms);
}

void ABP_Tool_C::ExecuteUbergraph_BP_CameraCaptureTools(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_CameraCaptureTools = UObject::FindObject<UFunction>("Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.ExecuteUbergraph_BP_CameraCaptureTools");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_CameraCaptureTools, &parms);
}

