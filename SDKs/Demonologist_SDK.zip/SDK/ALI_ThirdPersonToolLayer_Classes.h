#pragma once 
#include <ALI_ThirdPersonToolLayer_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ALI_ThirdPersonToolLayer.ALI_ThirdPersonToolLayer_C
// Size: 0x28(Inherited: 0x28) 
struct UALI_ThirdPersonToolLayer_C : public UAnimLayerInterface
{

	void BaseState(struct FPoseLink BaseAnimation, struct FPoseLink& BaseState); // Function ALI_ThirdPersonToolLayer.ALI_ThirdPersonToolLayer_C.BaseState
}; 



