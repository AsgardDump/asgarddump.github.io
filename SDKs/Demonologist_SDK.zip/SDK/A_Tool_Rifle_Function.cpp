#include "SDK.h" 
 
 
void AA_Tool_Base_C::Trace Vectors(struct FVector& Start, struct FVector& End){

	static UObject* p_Trace Vectors = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Trace Vectors");

	struct {
		struct FVector& Start;
		struct FVector& End;
	} parms;

	parms.Start = Start;
	parms.End = End;

	ProcessEvent(p_Trace Vectors, &parms);
}

void AA_Tool_Base_C::Reset Attack(){

	static UObject* p_Reset Attack = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Reset Attack");

	struct {
	} parms;


	ProcessEvent(p_Reset Attack, &parms);
}

void AA_Tool_Base_C::Crosshair Widget(struct UCC_Rifle_Crosshair_C*& Widget){

	static UObject* p_Crosshair Widget = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Crosshair Widget");

	struct {
		struct UCC_Rifle_Crosshair_C*& Widget;
	} parms;

	parms.Widget = Widget;

	ProcessEvent(p_Crosshair Widget, &parms);
}

void AA_Tool_Base_C::Recoil(){

	static UObject* p_Recoil = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Recoil");

	struct {
	} parms;


	ProcessEvent(p_Recoil, &parms);
}

void AA_Tool_Base_C::OnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName){

	static UObject* p_OnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.OnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A, &parms);
}

void AA_Tool_Base_C::OnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName){

	static UObject* p_OnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.OnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A, &parms);
}

void AA_Tool_Base_C::OnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName){

	static UObject* p_OnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.OnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A, &parms);
}

void AA_Tool_Base_C::OnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName){

	static UObject* p_OnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.OnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A, &parms);
}

void AA_Tool_Base_C::OnCompleted_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName){

	static UObject* p_OnCompleted_21C0D91744C87DA0D66E4C88DD70F42A = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.OnCompleted_21C0D91744C87DA0D66E4C88DD70F42A");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnCompleted_21C0D91744C87DA0D66E4C88DD70F42A, &parms);
}

void AA_Tool_Base_C::Fire Rifle(){

	static UObject* p_Fire Rifle = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Fire Rifle");

	struct {
	} parms;


	ProcessEvent(p_Fire Rifle, &parms);
}

void AA_Tool_Base_C::Fire Rifle Timer(){

	static UObject* p_Fire Rifle Timer = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Fire Rifle Timer");

	struct {
	} parms;


	ProcessEvent(p_Fire Rifle Timer, &parms);
}

void AA_Tool_Base_C::Stop Rifle Timer(){

	static UObject* p_Stop Rifle Timer = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Stop Rifle Timer");

	struct {
	} parms;


	ProcessEvent(p_Stop Rifle Timer, &parms);
}

void AA_Tool_Base_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AA_Tool_Base_C::Rifle Line Trace(struct FVector Start, struct FVector End){

	static UObject* p_Rifle Line Trace = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Rifle Line Trace");

	struct {
		struct FVector Start;
		struct FVector End;
	} parms;

	parms.Start = Start;
	parms.End = End;

	ProcessEvent(p_Rifle Line Trace, &parms);
}

void AA_Tool_Base_C::MC Muzzle Flash(){

	static UObject* p_MC Muzzle Flash = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.MC Muzzle Flash");

	struct {
	} parms;


	ProcessEvent(p_MC Muzzle Flash, &parms);
}

void AA_Tool_Base_C::Reset Aim(){

	static UObject* p_Reset Aim = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Reset Aim");

	struct {
	} parms;


	ProcessEvent(p_Reset Aim, &parms);
}

void AA_Tool_Base_C::Aim Reset Timer(double Time){

	static UObject* p_Aim Reset Timer = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Aim Reset Timer");

	struct {
		double Time;
	} parms;

	parms.Time = Time;

	ProcessEvent(p_Aim Reset Timer, &parms);
}

void AA_Tool_Base_C::Clear Aim Timer(){

	static UObject* p_Clear Aim Timer = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Clear Aim Timer");

	struct {
	} parms;


	ProcessEvent(p_Clear Aim Timer, &parms);
}

void AA_Tool_Base_C::SRV Fire(){

	static UObject* p_SRV Fire = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Fire");

	struct {
	} parms;


	ProcessEvent(p_SRV Fire, &parms);
}

void AA_Tool_Base_C::MC Fire(){

	static UObject* p_MC Fire = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.MC Fire");

	struct {
	} parms;


	ProcessEvent(p_MC Fire, &parms);
}

void AA_Tool_Base_C::Set Aiming(bool Aiming){

	static UObject* p_Set Aiming = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Set Aiming");

	struct {
		bool Aiming;
	} parms;

	parms.Aiming = Aiming;

	ProcessEvent(p_Set Aiming, &parms);
}

void AA_Tool_Base_C::SRV Set Aiming(bool Aiming){

	static UObject* p_SRV Set Aiming = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Set Aiming");

	struct {
		bool Aiming;
	} parms;

	parms.Aiming = Aiming;

	ProcessEvent(p_SRV Set Aiming, &parms);
}

void AA_Tool_Base_C::Muzzle Flash(){

	static UObject* p_Muzzle Flash = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Muzzle Flash");

	struct {
	} parms;


	ProcessEvent(p_Muzzle Flash, &parms);
}

void AA_Tool_Base_C::SRV Rifle Line Trace(struct FVector Start, struct FVector End){

	static UObject* p_SRV Rifle Line Trace = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Rifle Line Trace");

	struct {
		struct FVector Start;
		struct FVector End;
	} parms;

	parms.Start = Start;
	parms.End = End;

	ProcessEvent(p_SRV Rifle Line Trace, &parms);
}

void AA_Tool_Base_C::Secondary Fire(){

	static UObject* p_Secondary Fire = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Secondary Fire");

	struct {
	} parms;


	ProcessEvent(p_Secondary Fire, &parms);
}

void AA_Tool_Base_C::Secondary Fire Release(){

	static UObject* p_Secondary Fire Release = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Secondary Fire Release");

	struct {
	} parms;


	ProcessEvent(p_Secondary Fire Release, &parms);
}

void AA_Tool_Base_C::Main Fire(){

	static UObject* p_Main Fire = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Main Fire");

	struct {
	} parms;


	ProcessEvent(p_Main Fire, &parms);
}

void AA_Tool_Base_C::Main Fire Release(){

	static UObject* p_Main Fire Release = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Main Fire Release");

	struct {
	} parms;


	ProcessEvent(p_Main Fire Release, &parms);
}

void AA_Tool_Base_C::Rifle Timer Reset(){

	static UObject* p_Rifle Timer Reset = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Rifle Timer Reset");

	struct {
	} parms;


	ProcessEvent(p_Rifle Timer Reset, &parms);
}

void AA_Tool_Base_C::Set Crosshair Size(double Size){

	static UObject* p_Set Crosshair Size = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Set Crosshair Size");

	struct {
		double Size;
	} parms;

	parms.Size = Size;

	ProcessEvent(p_Set Crosshair Size, &parms);
}

void AA_Tool_Base_C::Attack Combo(int32_t Count){

	static UObject* p_Attack Combo = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Attack Combo");

	struct {
		int32_t Count;
	} parms;

	parms.Count = Count;

	ProcessEvent(p_Attack Combo, &parms);
}

void AA_Tool_Base_C::Out Of Ammo Sound(){

	static UObject* p_Out Of Ammo Sound = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Out Of Ammo Sound");

	struct {
	} parms;


	ProcessEvent(p_Out Of Ammo Sound, &parms);
}

void AA_Tool_Base_C::Impact Effects(struct FVector Location, struct FVector& Normal, struct UPhysicalMaterial* Phys Mat, struct AActor* Actor){

	static UObject* p_Impact Effects = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Impact Effects");

	struct {
		struct FVector Location;
		struct FVector& Normal;
		struct UPhysicalMaterial* Phys Mat;
		struct AActor* Actor;
	} parms;

	parms.Location = Location;
	parms.Normal = Normal;
	parms.Phys Mat = Phys Mat;
	parms.Actor = Actor;

	ProcessEvent(p_Impact Effects, &parms);
}

void AA_Tool_Base_C::Update Ammo(){

	static UObject* p_Update Ammo = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.Update Ammo");

	struct {
	} parms;


	ProcessEvent(p_Update Ammo, &parms);
}

void AA_Tool_Base_C::ExecuteUbergraph_A_Tool_Rifle(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_A_Tool_Rifle = UObject::FindObject<UFunction>("Function A_Tool_Rifle.A_Tool_Rifle_C.ExecuteUbergraph_A_Tool_Rifle");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_A_Tool_Rifle, &parms);
}

