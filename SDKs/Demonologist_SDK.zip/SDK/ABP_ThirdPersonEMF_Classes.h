#pragma once 
#include <ABP_ThirdPersonEMF_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonEMF.ABP_ThirdPersonEMF_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonEMF_C : public UABP_ThirdPersonToolLayer_C
{

}; 



