#include "SDK.h" 
 
 
struct USkeletalMeshComponent* ABP_BasicCharacter_C::GetSkeletalMesh(){

	static UObject* p_GetSkeletalMesh = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetSkeletalMesh");

	struct {
		struct USkeletalMeshComponent* return_value;
	} parms;


	ProcessEvent(p_GetSkeletalMesh, &parms);
	return parms.return_value;
}

struct USkeletalMeshComponent* ABP_BasicCharacter_C::GetTpsMesh(){

	static UObject* p_GetTpsMesh = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetTpsMesh");

	struct {
		struct USkeletalMeshComponent* return_value;
	} parms;


	ProcessEvent(p_GetTpsMesh, &parms);
	return parms.return_value;
}

void ABP_BasicCharacter_C::UpdateCharacterCustomization(){

	static UObject* p_UpdateCharacterCustomization = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterCustomization");

	struct {
	} parms;


	ProcessEvent(p_UpdateCharacterCustomization, &parms);
}

void ABP_BasicCharacter_C::IsFocusedOnAnySmartTV(bool& Result){

	static UObject* p_IsFocusedOnAnySmartTV = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.IsFocusedOnAnySmartTV");

	struct {
		bool& Result;
	} parms;

	parms.Result = Result;

	ProcessEvent(p_IsFocusedOnAnySmartTV, &parms);
}

void ABP_BasicCharacter_C::OnRep_bCrouching(){

	static UObject* p_OnRep_bCrouching = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_bCrouching");

	struct {
	} parms;


	ProcessEvent(p_OnRep_bCrouching, &parms);
}

void ABP_BasicCharacter_C::SetVoiceMode(char E_VoiceInputMode VoiceInputMode){

	static UObject* p_SetVoiceMode = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetVoiceMode");

	struct {
		char E_VoiceInputMode VoiceInputMode;
	} parms;

	parms.VoiceInputMode = VoiceInputMode;

	ProcessEvent(p_SetVoiceMode, &parms);
}

void ABP_BasicCharacter_C::SetInputActive(bool bIsActive){

	static UObject* p_SetInputActive = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetInputActive");

	struct {
		bool bIsActive;
	} parms;

	parms.bIsActive = bIsActive;

	ProcessEvent(p_SetInputActive, &parms);
}

void ABP_BasicCharacter_C::SetMovementActive(bool bIsActive){

	static UObject* p_SetMovementActive = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetMovementActive");

	struct {
		bool bIsActive;
	} parms;

	parms.bIsActive = bIsActive;

	ProcessEvent(p_SetMovementActive, &parms);
}

void ABP_BasicCharacter_C::GetIsVoiceMuted(bool& bIsVivoxMuted){

	static UObject* p_GetIsVoiceMuted = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetIsVoiceMuted");

	struct {
		bool& bIsVivoxMuted;
	} parms;

	parms.bIsVivoxMuted = bIsVivoxMuted;

	ProcessEvent(p_GetIsVoiceMuted, &parms);
}

void ABP_BasicCharacter_C::SetIsVoiceMuted(bool bMuted){

	static UObject* p_SetIsVoiceMuted = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetIsVoiceMuted");

	struct {
		bool bMuted;
	} parms;

	parms.bMuted = bMuted;

	ProcessEvent(p_SetIsVoiceMuted, &parms);
}

void ABP_BasicCharacter_C::OnRep_CharacterLocalData(){

	static UObject* p_OnRep_CharacterLocalData = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_CharacterLocalData");

	struct {
	} parms;


	ProcessEvent(p_OnRep_CharacterLocalData, &parms);
}

void ABP_BasicCharacter_C::OnRep_CurrentCharacterSpeed(){

	static UObject* p_OnRep_CurrentCharacterSpeed = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_CurrentCharacterSpeed");

	struct {
	} parms;


	ProcessEvent(p_OnRep_CurrentCharacterSpeed, &parms);
}

void ABP_BasicCharacter_C::OnRep_CharacterCustomizationData(){

	static UObject* p_OnRep_CharacterCustomizationData = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_CharacterCustomizationData");

	struct {
	} parms;


	ProcessEvent(p_OnRep_CharacterCustomizationData, &parms);
}

void ABP_BasicCharacter_C::SetWidgetInteractionActive(bool bNewActive){

	static UObject* p_SetWidgetInteractionActive = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetWidgetInteractionActive");

	struct {
		bool bNewActive;
	} parms;

	parms.bNewActive = bNewActive;

	ProcessEvent(p_SetWidgetInteractionActive, &parms);
}

void ABP_BasicCharacter_C::CalculateIKHand(double DeltaSec){

	static UObject* p_CalculateIKHand = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CalculateIKHand");

	struct {
		double DeltaSec;
	} parms;

	parms.DeltaSec = DeltaSec;

	ProcessEvent(p_CalculateIKHand, &parms);
}

void ABP_BasicCharacter_C::UploadCharacterLocalDataToServer(){

	static UObject* p_UploadCharacterLocalDataToServer = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UploadCharacterLocalDataToServer");

	struct {
	} parms;


	ProcessEvent(p_UploadCharacterLocalDataToServer, &parms);
}

void ABP_BasicCharacter_C::SetTpsCastShadowVisibility(bool NewCastShadow){

	static UObject* p_SetTpsCastShadowVisibility = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetTpsCastShadowVisibility");

	struct {
		bool NewCastShadow;
	} parms;

	parms.NewCastShadow = NewCastShadow;

	ProcessEvent(p_SetTpsCastShadowVisibility, &parms);
}

void ABP_BasicCharacter_C::ReplicateCustomizationData(){

	static UObject* p_ReplicateCustomizationData = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReplicateCustomizationData");

	struct {
	} parms;


	ProcessEvent(p_ReplicateCustomizationData, &parms);
}

void ABP_BasicCharacter_C::CrouchingTimeLine__FinishedFunc(){

	static UObject* p_CrouchingTimeLine__FinishedFunc = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimeLine__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_CrouchingTimeLine__FinishedFunc, &parms);
}

void ABP_BasicCharacter_C::CrouchingTimeLine__UpdateFunc(){

	static UObject* p_CrouchingTimeLine__UpdateFunc = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimeLine__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_CrouchingTimeLine__UpdateFunc, &parms);
}

void ABP_BasicCharacter_C::CrouchingTimelineLocal__FinishedFunc(){

	static UObject* p_CrouchingTimelineLocal__FinishedFunc = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimelineLocal__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_CrouchingTimelineLocal__FinishedFunc, &parms);
}

void ABP_BasicCharacter_C::CrouchingTimelineLocal__UpdateFunc(){

	static UObject* p_CrouchingTimelineLocal__UpdateFunc = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimelineLocal__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_CrouchingTimelineLocal__UpdateFunc, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_Sprint_K2Node_InputActionEvent_8(struct FKey Key){

	static UObject* p_InpActEvt_Sprint_K2Node_InputActionEvent_8 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Sprint_K2Node_InputActionEvent_8");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_Sprint_K2Node_InputActionEvent_8, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_Sprint_K2Node_InputActionEvent_7(struct FKey Key){

	static UObject* p_InpActEvt_Sprint_K2Node_InputActionEvent_7 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Sprint_K2Node_InputActionEvent_7");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_Sprint_K2Node_InputActionEvent_7, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3(struct FKey Key){

	static UObject* p_InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2(struct FKey Key){

	static UObject* p_InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_SpaceBar_K2Node_InputKeyEvent_1(struct FKey Key){

	static UObject* p_InpActEvt_SpaceBar_K2Node_InputKeyEvent_1 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_SpaceBar_K2Node_InputKeyEvent_1");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_SpaceBar_K2Node_InputKeyEvent_1, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_CommandConsole_K2Node_InputActionEvent_6(struct FKey Key){

	static UObject* p_InpActEvt_CommandConsole_K2Node_InputActionEvent_6 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_CommandConsole_K2Node_InputActionEvent_6");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_CommandConsole_K2Node_InputActionEvent_6, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_EscapeMenu_K2Node_InputActionEvent_5(struct FKey Key){

	static UObject* p_InpActEvt_EscapeMenu_K2Node_InputActionEvent_5 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_EscapeMenu_K2Node_InputActionEvent_5");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_EscapeMenu_K2Node_InputActionEvent_5, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_PushToTalk_K2Node_InputActionEvent_4(struct FKey Key){

	static UObject* p_InpActEvt_PushToTalk_K2Node_InputActionEvent_4 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_PushToTalk_K2Node_InputActionEvent_4");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_PushToTalk_K2Node_InputActionEvent_4, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_PushToTalk_K2Node_InputActionEvent_3(struct FKey Key){

	static UObject* p_InpActEvt_PushToTalk_K2Node_InputActionEvent_3 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_PushToTalk_K2Node_InputActionEvent_3");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_PushToTalk_K2Node_InputActionEvent_3, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_Crouching_K2Node_InputActionEvent_2(struct FKey Key){

	static UObject* p_InpActEvt_Crouching_K2Node_InputActionEvent_2 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Crouching_K2Node_InputActionEvent_2");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_Crouching_K2Node_InputActionEvent_2, &parms);
}

void ABP_BasicCharacter_C::InpActEvt_VoicePromptLine_K2Node_InputActionEvent_1(struct FKey Key){

	static UObject* p_InpActEvt_VoicePromptLine_K2Node_InputActionEvent_1 = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_VoicePromptLine_K2Node_InputActionEvent_1");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_VoicePromptLine_K2Node_InputActionEvent_1, &parms);
}

void ABP_BasicCharacter_C::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void ABP_BasicCharacter_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_BasicCharacter_C::BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature(bool IsSprinting){

	static UObject* p_BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature");

	struct {
		bool IsSprinting;
	} parms;

	parms.IsSprinting = IsSprinting;

	ProcessEvent(p_BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature, &parms);
}

void ABP_BasicCharacter_C::UpdateCharacterMovementSpeed(float Max Walk Speed){

	static UObject* p_UpdateCharacterMovementSpeed = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterMovementSpeed");

	struct {
		float Max Walk Speed;
	} parms;

	parms.Max Walk Speed = Max Walk Speed;

	ProcessEvent(p_UpdateCharacterMovementSpeed, &parms);
}

void ABP_BasicCharacter_C::SendMessage On Server(struct FString Message){

	static UObject* p_SendMessage On Server = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SendMessage On Server");

	struct {
		struct FString Message;
	} parms;

	parms.Message = Message;

	ProcessEvent(p_SendMessage On Server, &parms);
}

void ABP_BasicCharacter_C::BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_1_OnTired__DelegateSignature(){

	static UObject* p_BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_1_OnTired__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_1_OnTired__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_1_OnTired__DelegateSignature, &parms);
}

void ABP_BasicCharacter_C::SetCharacterLocalData OnServer(struct FFCharacterLocalData CharacterLocalData){

	static UObject* p_SetCharacterLocalData OnServer = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetCharacterLocalData OnServer");

	struct {
		struct FFCharacterLocalData CharacterLocalData;
	} parms;

	parms.CharacterLocalData = CharacterLocalData;

	ProcessEvent(p_SetCharacterLocalData OnServer, &parms);
}

void ABP_BasicCharacter_C::UpdateCharacterMovementSpeedServer(float Max Walk Speed){

	static UObject* p_UpdateCharacterMovementSpeedServer = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterMovementSpeedServer");

	struct {
		float Max Walk Speed;
	} parms;

	parms.Max Walk Speed = Max Walk Speed;

	ProcessEvent(p_UpdateCharacterMovementSpeedServer, &parms);
}

void ABP_BasicCharacter_C::Set Character Customization Data On Server(struct FS_ShiversCharacterCustomizationRep New CC Rep Data){

	static UObject* p_Set Character Customization Data On Server = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.Set Character Customization Data On Server");

	struct {
		struct FS_ShiversCharacterCustomizationRep New CC Rep Data;
	} parms;

	parms.New CC Rep Data = New CC Rep Data;

	ProcessEvent(p_Set Character Customization Data On Server, &parms);
}

void ABP_BasicCharacter_C::DestoryCustomizationComponent(struct USkeletalMeshComponent* SkeletalMeshComponentReference){

	static UObject* p_DestoryCustomizationComponent = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.DestoryCustomizationComponent");

	struct {
		struct USkeletalMeshComponent* SkeletalMeshComponentReference;
	} parms;

	parms.SkeletalMeshComponentReference = SkeletalMeshComponentReference;

	ProcessEvent(p_DestoryCustomizationComponent, &parms);
}

void ABP_BasicCharacter_C::CrouchOnServer(bool bCrouch){

	static UObject* p_CrouchOnServer = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchOnServer");

	struct {
		bool bCrouch;
	} parms;

	parms.bCrouch = bCrouch;

	ProcessEvent(p_CrouchOnServer, &parms);
}

void ABP_BasicCharacter_C::CrouchingLocal(){

	static UObject* p_CrouchingLocal = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingLocal");

	struct {
	} parms;


	ProcessEvent(p_CrouchingLocal, &parms);
}

void ABP_BasicCharacter_C::CrouchEvent(bool bCrouching){

	static UObject* p_CrouchEvent = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchEvent");

	struct {
		bool bCrouching;
	} parms;

	parms.bCrouching = bCrouching;

	ProcessEvent(p_CrouchEvent, &parms);
}

void ABP_BasicCharacter_C::SetMovementInputServer(struct FVector MovementInput){

	static UObject* p_SetMovementInputServer = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetMovementInputServer");

	struct {
		struct FVector MovementInput;
	} parms;

	parms.MovementInput = MovementInput;

	ProcessEvent(p_SetMovementInputServer, &parms);
}

void ABP_BasicCharacter_C::ReplicateAnimationVariables(){

	static UObject* p_ReplicateAnimationVariables = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReplicateAnimationVariables");

	struct {
	} parms;


	ProcessEvent(p_ReplicateAnimationVariables, &parms);
}

void ABP_BasicCharacter_C::OnLevelUpdated(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData){

	static UObject* p_OnLevelUpdated = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnLevelUpdated");

	struct {
		struct UObject* Publisher;
		struct UObject* Payload;
		struct TArray<struct FString>& MetaData;
	} parms;

	parms.Publisher = Publisher;
	parms.Payload = Payload;
	parms.MetaData = MetaData;

	ProcessEvent(p_OnLevelUpdated, &parms);
}

void ABP_BasicCharacter_C::UpdateVivox3DPosition(){

	static UObject* p_UpdateVivox3DPosition = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateVivox3DPosition");

	struct {
	} parms;


	ProcessEvent(p_UpdateVivox3DPosition, &parms);
}

void ABP_BasicCharacter_C::ExecuteUbergraph_BP_BasePlayerCharacter(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BasePlayerCharacter = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ExecuteUbergraph_BP_BasePlayerCharacter");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BasePlayerCharacter, &parms);
}

void ABP_BasicCharacter_C::CharacterLocalDataChanged__DelegateSignature(){

	static UObject* p_CharacterLocalDataChanged__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CharacterLocalDataChanged__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_CharacterLocalDataChanged__DelegateSignature, &parms);
}

