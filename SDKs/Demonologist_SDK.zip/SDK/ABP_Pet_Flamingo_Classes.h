#pragma once 
#include <ABP_Pet_Flamingo_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Pet_Flamingo.ABP_Pet_Flamingo_C
// Size: 0x708(Inherited: 0x350) 
struct UABP_Pet_Flamingo_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x388(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3D8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x420(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x440(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x488(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4A8(0xC8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x570(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x678(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x6A0(0x48)
	struct FVector K2Node_PropertyAccess;  // 0x6E8(0x18)
	double Speed;  // 0x700(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.BlueprintThreadSafeUpdateAnimation
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_BCBFF5B54A5B7B6A9E7C7C96AA450BA2(); // Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_BCBFF5B54A5B7B6A9E7C7C96AA450BA2
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_C516F34B4719E4306EB61797E4C77064(); // Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_C516F34B4719E4306EB61797E4C77064
	void ExecuteUbergraph_ABP_Pet_Flamingo(int32_t EntryPoint); // Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.ExecuteUbergraph_ABP_Pet_Flamingo
}; 



