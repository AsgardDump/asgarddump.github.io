#pragma once 
#include <BP_AiCloseInteractionComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AiCloseInteractionComponent.BP_AiCloseInteractionComponent_C
// Size: 0x140(Inherited: 0x134) 
struct UBP_AiCloseInteractionComponent_C : public UBP_AiInteractionComponent_C
{
	char pad_308[4];  // 0x134(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x138(0x8)

	void ReceiveBeginPlay(); // Function BP_AiCloseInteractionComponent.BP_AiCloseInteractionComponent_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_AiCloseInteractionComponent(int32_t EntryPoint); // Function BP_AiCloseInteractionComponent.BP_AiCloseInteractionComponent_C.ExecuteUbergraph_BP_AiCloseInteractionComponent
}; 



