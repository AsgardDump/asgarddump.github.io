#pragma once 
#include <BP_BaseUvLight_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseUvLight.BP_BaseUvLight_C
// Size: 0x464(Inherited: 0x429) 
struct ABP_BaseUvLight_C : public ABP_Tool_C
{
	char pad_1065[7];  // 0x429(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct UPointLightComponent* PointLight;  // 0x438(0x8)
	struct UBoxComponent* UvLightDetection;  // 0x440(0x8)
	float UvMalFunction_FlashlightMultiplier_D67E100443850E13D521EE977C48002C;  // 0x448(0x4)
	char ETimelineDirection UvMalFunction__Direction_D67E100443850E13D521EE977C48002C;  // 0x44C(0x1)
	char pad_1101[3];  // 0x44D(0x3)
	struct UTimelineComponent* UvMalFunction;  // 0x450(0x8)
	struct FTimerHandle MalfunctionTimer;  // 0x458(0x8)
	float UvLightMultiplier;  // 0x460(0x4)

	void GetLightInformation(struct FVector TargetLocation, struct FVector& Location, double& Strenght); // Function BP_BaseUvLight.BP_BaseUvLight_C.GetLightInformation
	bool CanMalfunction(); // Function BP_BaseUvLight.BP_BaseUvLight_C.CanMalfunction
	double GetTargetIntensity(); // Function BP_BaseUvLight.BP_BaseUvLight_C.GetTargetIntensity
	void UvMalFunction__FinishedFunc(); // Function BP_BaseUvLight.BP_BaseUvLight_C.UvMalFunction__FinishedFunc
	void UvMalFunction__UpdateFunc(); // Function BP_BaseUvLight.BP_BaseUvLight_C.UvMalFunction__UpdateFunc
	void OnNotifyEnd_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName); // Function BP_BaseUvLight.BP_BaseUvLight_C.OnNotifyEnd_2AD36304431AADA067A1FAB270266A7B
	void OnNotifyBegin_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName); // Function BP_BaseUvLight.BP_BaseUvLight_C.OnNotifyBegin_2AD36304431AADA067A1FAB270266A7B
	void OnInterrupted_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName); // Function BP_BaseUvLight.BP_BaseUvLight_C.OnInterrupted_2AD36304431AADA067A1FAB270266A7B
	void OnBlendOut_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName); // Function BP_BaseUvLight.BP_BaseUvLight_C.OnBlendOut_2AD36304431AADA067A1FAB270266A7B
	void OnCompleted_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName); // Function BP_BaseUvLight.BP_BaseUvLight_C.OnCompleted_2AD36304431AADA067A1FAB270266A7B
	void ReceiveBeginPlay(); // Function BP_BaseUvLight.BP_BaseUvLight_C.ReceiveBeginPlay
	void UpdateUvLightIntensity(); // Function BP_BaseUvLight.BP_BaseUvLight_C.UpdateUvLightIntensity
	void OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit); // Function BP_BaseUvLight.BP_BaseUvLight_C.OnObjectInstigatorUpdatedCallback
	void PlayEquipMontage(); // Function BP_BaseUvLight.BP_BaseUvLight_C.PlayEquipMontage
	void EndMalfunction(struct FName Identifier); // Function BP_BaseUvLight.BP_BaseUvLight_C.EndMalfunction
	void EndUvLightMalFunction(); // Function BP_BaseUvLight.BP_BaseUvLight_C.EndUvLightMalFunction
	void StartUvLightMalFunction(); // Function BP_BaseUvLight.BP_BaseUvLight_C.StartUvLightMalFunction
	void StartMalfunction(struct FName Identifier); // Function BP_BaseUvLight.BP_BaseUvLight_C.StartMalfunction
	void ExecuteUbergraph_BP_BaseUvLight(int32_t EntryPoint); // Function BP_BaseUvLight.BP_BaseUvLight_C.ExecuteUbergraph_BP_BaseUvLight
}; 



