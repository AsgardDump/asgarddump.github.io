#pragma once 
#include "SDK.h" 
 
 
// Function A_Tool_Rifle.A_Tool_Rifle_C.OnCompleted_21C0D91744C87DA0D66E4C88DD70F42A
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_21C0D91744C87DA0D66E4C88DD70F42A
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Aim Reset Timer
// Size: 0x8(Inherited: 0x0) 
struct FAim Reset Timer
{
	double Time;  // 0x0(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.ExecuteUbergraph_A_Tool_Rifle
// Size: 0x5B4(Inherited: 0x0) 
struct FExecuteUbergraph_A_Tool_Rifle
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector CallFunc_Trace_Vectors_Start;  // 0x8(0x18)
	struct FVector CallFunc_Trace_Vectors_End;  // 0x20(0x18)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x38(0x8)
	char ENetRole CallFunc_GetLocalRole_ReturnValue;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x44(0x10)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x58(0x8)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_2;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	double Temp_real_Variable;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool Temp_bool_Variable : 1;  // 0x73(0x1)
	struct FName Temp_name_Variable;  // 0x74(0x8)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	int32_t CallFunc_Array_Get_Item;  // 0x80(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x84(0x10)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x98(0x8)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0xA8(0x8)
	int32_t CallFunc_Array_Get_Item_2;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xC0(0x1)
	char pad_193_1 : 7;  // 0xC1(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // 0xC1(0x1)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool CallFunc_IsPlayerControlled_ReturnValue : 1;  // 0xC2(0x1)
	char pad_195_1 : 7;  // 0xC3(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0xC3(0x1)
	char pad_196_1 : 7;  // 0xC4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0xC8(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn_2;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0xD9(0x1)
	char pad_218[2];  // 0xDA(0x2)
	struct FName K2Node_CustomEvent_NotifyName;  // 0xDC(0x8)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool CallFunc_HasAuthority_ReturnValue_3 : 1;  // 0xE4(0x1)
	char pad_229[3];  // 0xE5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0xE8(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // 0xF8(0x8)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x100(0x8)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x108(0x10)
	struct AController* CallFunc_GetController_ReturnValue;  // 0x118(0x8)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x120(0x8)
	struct FVector K2Node_CustomEvent_Start_2;  // 0x128(0x18)
	struct FVector K2Node_CustomEvent_End_2;  // 0x140(0x18)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x158(0xE8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_6;  // 0x248(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn_3;  // 0x250(0x8)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x258(0x1)
	char pad_601_1 : 7;  // 0x259(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x259(0x1)
	char pad_602_1 : 7;  // 0x25A(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x25A(0x1)
	char pad_603[1];  // 0x25B(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x25C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x260(0x4)
	char pad_612[4];  // 0x264(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x268(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x280(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x298(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x2B0(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x2C8(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x2D0(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x2D8(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x2E0(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x2E8(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x2F0(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x2F4(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x2F8(0x4)
	char pad_764[4];  // 0x2FC(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x300(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x318(0x18)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0x330(0x1)
	char pad_817[7];  // 0x331(0x7)
	double CallFunc_Map_Find_Value;  // 0x338(0x8)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x340(0x1)
	char pad_833[7];  // 0x341(0x7)
	double K2Node_Select_Default;  // 0x348(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x350(0x8)
	double K2Node_CustomEvent_Time;  // 0x358(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0x360(0x8)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_2;  // 0x368(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x370(0x8)
	char pad_888_1 : 7;  // 0x378(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x378(0x1)
	char pad_889_1 : 7;  // 0x379(0x1)
	bool K2Node_CustomEvent_Aiming_2 : 1;  // 0x379(0x1)
	char pad_890_1 : 7;  // 0x37A(0x1)
	bool K2Node_CustomEvent_Aiming : 1;  // 0x37A(0x1)
	char pad_891[5];  // 0x37B(0x5)
	struct FVector K2Node_CustomEvent_Start;  // 0x380(0x18)
	struct FVector K2Node_CustomEvent_End;  // 0x398(0x18)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x3B0(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue_7;  // 0x3C0(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn_4;  // 0x3C8(0x8)
	char pad_976_1 : 7;  // 0x3D0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x3D0(0x1)
	char pad_977_1 : 7;  // 0x3D1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_4 : 1;  // 0x3D1(0x1)
	char pad_978[6];  // 0x3D2(0x6)
	struct UCC_Rifle_Crosshair_C* CallFunc_Crosshair_Widget_Widget;  // 0x3D8(0x8)
	char pad_992_1 : 7;  // 0x3E0(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x3E0(0x1)
	char pad_993[7];  // 0x3E1(0x7)
	struct UCombat_C* CallFunc_Combat_Component_ReturnValue;  // 0x3E8(0x8)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x3F0(0x1)
	char pad_1009[7];  // 0x3F1(0x7)
	struct UCC_Rifle_Crosshair_C* CallFunc_Crosshair_Widget_Widget_2;  // 0x3F8(0x8)
	double K2Node_CustomEvent_Size;  // 0x400(0x8)
	char pad_1032_1 : 7;  // 0x408(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x408(0x1)
	char pad_1033[3];  // 0x409(0x3)
	int32_t K2Node_Event_Count;  // 0x40C(0x4)
	char pad_1040_1 : 7;  // 0x410(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x410(0x1)
	char pad_1041[7];  // 0x411(0x7)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x418(0x18)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_3;  // 0x430(0x8)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAttached_ReturnValue;  // 0x438(0x8)
	struct TScriptInterface<IBPI_CharacterCustomizer_C> K2Node_DynamicCast_AsBPI_Character_Customizer;  // 0x440(0x10)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x450(0x1)
	char pad_1105[15];  // 0x451(0xF)
	struct FTransform CallFunc_GetSocketTransform_ReturnValue;  // 0x460(0x60)
	struct FVector CallFunc_BreakTransform_Location;  // 0x4C0(0x18)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x4D8(0x18)
	struct FVector CallFunc_BreakTransform_Scale;  // 0x4F0(0x18)
	struct FVector K2Node_CustomEvent_Location;  // 0x508(0x18)
	struct FVector K2Node_CustomEvent_Normal;  // 0x520(0x18)
	struct UPhysicalMaterial* K2Node_CustomEvent_Phys_Mat;  // 0x538(0x8)
	struct AActor* K2Node_CustomEvent_Actor;  // 0x540(0x8)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x548(0x8)
	struct FRotator CallFunc_MakeRotFromX_ReturnValue;  // 0x550(0x18)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x568(0x10)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x578(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x580(0x10)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x590(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x598(0x10)
	struct UCC_Rifle_Crosshair_C* CallFunc_Crosshair_Widget_Widget_3;  // 0x5A8(0x8)
	float CallFunc_K2_SetTimerDelegate_Time_ImplicitCast;  // 0x5B0(0x4)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Attack Combo
// Size: 0x4(Inherited: 0x4) 
struct FAttack Combo : public FAttack Combo
{
	int32_t Count;  // 0x0(0x4)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Crosshair Widget
// Size: 0x11(Inherited: 0x0) 
struct FCrosshair Widget
{
	struct UCC_Rifle_Crosshair_C* Widget;  // 0x0(0x8)
	struct UCC_Rifle_Crosshair_C* K2Node_DynamicCast_AsCC_Rifle_Crosshair;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.OnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Impact Effects
// Size: 0x40(Inherited: 0x0) 
struct FImpact Effects
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector Normal;  // 0x18(0x18)
	struct UPhysicalMaterial* Phys Mat;  // 0x30(0x8)
	struct AActor* Actor;  // 0x38(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.OnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.OnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.OnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Recoil
// Size: 0x7C(Inherited: 0x0) 
struct FRecoil
{
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x0(0x8)
	struct UCC_Rifle_Crosshair_C* CallFunc_Crosshair_Widget_Widget;  // 0x8(0x8)
	double CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0x20(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x28(0x8)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	double CallFunc_Divide_DoubleDouble_ReturnValue;  // 0x38(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x40(0x4)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue_2;  // 0x44(0x4)
	double CallFunc_Divide_DoubleDouble_ReturnValue_2;  // 0x48(0x8)
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	double CallFunc_Divide_DoubleDouble_ReturnValue_3;  // 0x58(0x8)
	double CallFunc_Divide_DoubleDouble_A_ImplicitCast;  // 0x60(0x8)
	float CallFunc_AddControllerYawInput_Val_ImplicitCast;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	double CallFunc_Divide_DoubleDouble_A_ImplicitCast_2;  // 0x70(0x8)
	float CallFunc_AddControllerPitchInput_Val_ImplicitCast;  // 0x78(0x4)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Rifle Line Trace
// Size: 0x30(Inherited: 0x0) 
struct FRifle Line Trace
{
	struct FVector Start;  // 0x0(0x18)
	struct FVector End;  // 0x18(0x18)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Set Aiming
// Size: 0x1(Inherited: 0x0) 
struct FSet Aiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Aiming : 1;  // 0x0(0x1)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Set Crosshair Size
// Size: 0x8(Inherited: 0x0) 
struct FSet Crosshair Size
{
	double Size;  // 0x0(0x8)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Rifle Line Trace
// Size: 0x30(Inherited: 0x0) 
struct FSRV Rifle Line Trace
{
	struct FVector Start;  // 0x0(0x18)
	struct FVector End;  // 0x18(0x18)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Set Aiming
// Size: 0x1(Inherited: 0x0) 
struct FSRV Set Aiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Aiming : 1;  // 0x0(0x1)

}; 
// Function A_Tool_Rifle.A_Tool_Rifle_C.Trace Vectors
// Size: 0x198(Inherited: 0x0) 
struct FTrace Vectors
{
	struct FVector Start;  // 0x0(0x18)
	struct FVector End;  // 0x18(0x18)
	struct FVector CallFunc_GetSocketLocation_ReturnValue;  // 0x30(0x18)
	struct UCameraComponent* CallFunc_Active_Camera_ReturnValue;  // 0x48(0x8)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x50(0x8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x58(0x18)
	struct AAIController* CallFunc_GetAIController_ReturnValue;  // 0x70(0x8)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x78(0x18)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x98(0x18)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0xB0(0x18)
	struct AActor* CallFunc_GetFocusActor_ReturnValue;  // 0xC8(0x8)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xD0(0x18)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xF0(0x18)
	struct FVector CallFunc_GetForwardVector_ReturnValue_2;  // 0x108(0x18)
	struct FVector CallFunc_GetDirectionUnitVector_ReturnValue;  // 0x120(0x18)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x138(0x18)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_3;  // 0x150(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x168(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0x180(0x18)

}; 
