#pragma once 
#include <ABP_Zombie_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Zombie.ABP_Zombie_C
// Size: 0x6EC(Inherited: 0x6EC) 
struct UABP_Zombie_C : public UABP_BaseEntity_C
{

}; 



