#pragma once 
#include <ABP_ThirdPersonCamera_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonCamera.ABP_ThirdPersonCamera_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonCamera_C : public UABP_ThirdPersonToolLayer_C
{

}; 



