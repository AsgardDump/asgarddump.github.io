#include "SDK.h" 
 
 
bool UAnimInstance::GetIsAiming(){

	static UObject* p_GetIsAiming = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.GetIsAiming");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsAiming, &parms);
	return parms.return_value;
}

void UAnimInstance::IdleState(struct FPoseLink& IdleState){

	static UObject* p_IdleState = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.IdleState");

	struct {
		struct FPoseLink& IdleState;
	} parms;

	parms.IdleState = IdleState;

	ProcessEvent(p_IdleState, &parms);
}

void UAnimInstance::WalkingState(struct FPoseLink& WalkingState){

	static UObject* p_WalkingState = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.WalkingState");

	struct {
		struct FPoseLink& WalkingState;
	} parms;

	parms.WalkingState = WalkingState;

	ProcessEvent(p_WalkingState, &parms);
}

void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::BlueprintThreadSafeUpdateAnimation(float DeltaTime){

	static UObject* p_BlueprintThreadSafeUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.BlueprintThreadSafeUpdateAnimation");

	struct {
		float DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_BlueprintThreadSafeUpdateAnimation, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_BlendListByBool_96D15D1148B57EEC7CE69AA3D692D1AC(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_BlendListByBool_96D15D1148B57EEC7CE69AA3D692D1AC = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_BlendListByBool_96D15D1148B57EEC7CE69AA3D692D1AC");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_BlendListByBool_96D15D1148B57EEC7CE69AA3D692D1AC, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_IKRig_0CD4C9AA41FC572DE2C3A9B9FC6DDD00(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_IKRig_0CD4C9AA41FC572DE2C3A9B9FC6DDD00 = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_IKRig_0CD4C9AA41FC572DE2C3A9B9FC6DDD00");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_IKRig_0CD4C9AA41FC572DE2C3A9B9FC6DDD00, &parms);
}

void UAnimInstance::SetIsAiming(bool IsAiming){

	static UObject* p_SetIsAiming = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.SetIsAiming");

	struct {
		bool IsAiming;
	} parms;

	parms.IsAiming = IsAiming;

	ProcessEvent(p_SetIsAiming, &parms);
}

void UAnimInstance::SetIsSprinting(bool IsSprintins){

	static UObject* p_SetIsSprinting = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.SetIsSprinting");

	struct {
		bool IsSprintins;
	} parms;

	parms.IsSprintins = IsSprintins;

	ProcessEvent(p_SetIsSprinting, &parms);
}

void UAnimInstance::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_Base_Arms(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_Base_Arms = UObject::FindObject<UFunction>("Function ABP_Base_Arms.ABP_Base_Arms_C.ExecuteUbergraph_ABP_Base_Arms");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_Base_Arms, &parms);
}

