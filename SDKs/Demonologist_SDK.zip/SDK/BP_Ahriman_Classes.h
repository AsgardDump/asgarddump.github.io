#pragma once 
#include <BP_Ahriman_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ahriman.BP_Ahriman_C
// Size: 0xA98(Inherited: 0xA90) 
struct ABP_Ahriman_C : public ABP_Entity_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA90(0x8)

	bool GetCanPerformGhostAbility(); // Function BP_Ahriman.BP_Ahriman_C.GetCanPerformGhostAbility
	void ReceiveBeginPlay(); // Function BP_Ahriman.BP_Ahriman_C.ReceiveBeginPlay
	void recognitionResultReceivedOnRecgonitionReceived(struct FString Result); // Function BP_Ahriman.BP_Ahriman_C.recognitionResultReceivedOnRecgonitionReceived
	void OnAhrimanHearSwear(); // Function BP_Ahriman.BP_Ahriman_C.OnAhrimanHearSwear
	void ExecuteUbergraph_BP_Ahriman(int32_t EntryPoint); // Function BP_Ahriman.BP_Ahriman_C.ExecuteUbergraph_BP_Ahriman
}; 



