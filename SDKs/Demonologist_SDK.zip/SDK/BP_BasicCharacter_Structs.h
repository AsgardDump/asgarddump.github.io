#pragma once 
#include "SDK.h" 
 
 
// Function BP_BasicCharacter.BP_BasicCharacter_C.ExecuteUbergraph_BP_BasicCharacter
// Size: 0x70(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BasicCharacter
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x8(0x18)
	struct FKey Temp_struct_Variable;  // 0x20(0x18)
	struct FKey K2Node_InputActionEvent_Key;  // 0x38(0x18)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsInteractionObjectExist_ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	double CallFunc_GetCurrentObjectInteractionTime_ReturnValue;  // 0x58(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x60(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue_2;  // 0x68(0x8)

}; 
// Function BP_BasicCharacter.BP_BasicCharacter_C.PreparePitchReplication
// Size: 0x20(Inherited: 0x0) 
struct FPreparePitchReplication
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x18(0x8)

}; 
// Function BP_BasicCharacter.BP_BasicCharacter_C.GetCurrentObjectInteractionTime
// Size: 0x110(Inherited: 0x0) 
struct FGetCurrentObjectInteractionTime
{
	double ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)
	float CallFunc_BreakHitResult_Time;  // 0xC(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x18(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x30(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x48(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x60(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x78(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x80(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x88(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x90(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x98(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0xA0(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0xA4(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0xB0(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0xC8(0x18)
	struct UBP_InteractionComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	struct TScriptInterface<IBPI_PrimitiveInteraction_C> K2Node_DynamicCast_AsBPI_Primitive_Interaction;  // 0xF0(0x10)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x100(0x1)
	char pad_257[7];  // 0x101(0x7)
	double CallFunc_GetPressTimeToInteract_ReturnValue;  // 0x108(0x8)

}; 
// Function BP_BasicCharacter.BP_BasicCharacter_C.InpActEvt_Interaction_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Interaction_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasicCharacter.BP_BasicCharacter_C.GetLookDirection
// Size: 0x74(Inherited: 0x30) 
struct FGetLookDirection : public FGetLookDirection
{
	struct FRotator ReturnValue;  // 0x0(0x18)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // 0x18(0x18)
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue_2;  // 0x30(0x18)
	float CallFunc_BreakRotator_Roll;  // 0x48(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x4C(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x50(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x54(0x1)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x58(0x18)
	float CallFunc_MakeRotator_Pitch_ImplicitCast;  // 0x70(0x4)

}; 
// Function BP_BasicCharacter.BP_BasicCharacter_C.ReplicateCameraPitch
// Size: 0x30(Inherited: 0x0) 
struct FReplicateCameraPitch
{
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x0(0x18)
	float CallFunc_BreakRotator_Roll;  // 0x18(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x1C(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	double K2Node_VariableSet_CameraPitchValue_ImplicitCast;  // 0x28(0x8)

}; 
// Function BP_BasicCharacter.BP_BasicCharacter_C.InpActEvt_Interaction_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Interaction_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasicCharacter.BP_BasicCharacter_C.IsInteractionObjectExist
// Size: 0xE2(Inherited: 0x0) 
struct FIsInteractionObjectExist
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x2(0x1)
	char pad_3[1];  // 0x3(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x10(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x28(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x40(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x58(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x70(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x78(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x80(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x88(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x90(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x98(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x9C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0xA8(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0xC0(0x18)
	struct UBP_InteractionComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0xE1(0x1)

}; 
