#pragma once 
#include <ABP_FatDemon_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_FatDemon.ABP_FatDemon_C
// Size: 0x6EC(Inherited: 0x6EC) 
struct UABP_FatDemon_C : public UABP_BaseEntity_C
{

}; 



