#pragma once 
#include "SDK.h" 
 
 
// Function BP_ChatManager.BP_ChatManager_C.SendMessage OnMulticast
// Size: 0x20(Inherited: 0x0) 
struct FSendMessage OnMulticast
{
	struct FString Sender;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)

}; 
// Function BP_ChatManager.BP_ChatManager_C.BroadcastMessage
// Size: 0x21(Inherited: 0x0) 
struct FBroadcastMessage
{
	struct FString Sender;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_CanSendMessage_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_ChatManager.BP_ChatManager_C.BroadcastMessageDispatchers__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FBroadcastMessageDispatchers__DelegateSignature
{
	struct FString Sender;  // 0x0(0x10)
	struct FString Message;  // 0x10(0x10)

}; 
// Function BP_ChatManager.BP_ChatManager_C.SendMessage
// Size: 0x22(Inherited: 0x0) 
struct FSendMessage
{
	struct FString Message;  // 0x0(0x10)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x10(0x8)
	struct ABP_BasePlayerCharacter_C* K2Node_DynamicCast_AsBP_Base_Player_Character;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_CanSendMessage_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_ChatManager.BP_ChatManager_C.CanSendMessage
// Size: 0x1B(Inherited: 0x0) 
struct FCanSendMessage
{
	struct FString Message;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	int32_t CallFunc_Len_ReturnValue;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_NotEqual_IntInt_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function BP_ChatManager.BP_ChatManager_C.ExecuteUbergraph_BP_ChatManager
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ChatManager
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString K2Node_CustomEvent_Sender;  // 0x8(0x10)
	struct FString K2Node_CustomEvent_Message;  // 0x18(0x10)

}; 
