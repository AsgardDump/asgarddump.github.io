#pragma once 
#include <BP_BaseCollectableItem_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseCollectableItem.BP_BaseCollectableItem_C
// Size: 0x2D0(Inherited: 0x2B8) 
struct ABP_BaseCollectableItem_C : public ABP_BaseInteraction_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B8(0x8)
	struct FGameplayTag PublishTag;  // 0x2C0(0x8)
	struct USoundBase* SoundToPlay;  // 0x2C8(0x8)

	void PublishEvent(struct APawn* Instigator); // Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.PublishEvent
	bool GetIsLookInteractionActive(); // Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.GetIsLookInteractionActive
	bool GetVisualActiveCondition(); // Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.GetVisualActiveCondition
	bool CanPlayerInteract(struct APawn* PawnReference); // Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.CanPlayerInteract
	void BndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted); // Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.BndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
	void HandleInteractObjectDispatcher(struct APawn* Instigator, bool IsServerExecuted); // Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.HandleInteractObjectDispatcher
	void ExecuteUbergraph_BP_BaseCollectableItem(int32_t EntryPoint); // Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.ExecuteUbergraph_BP_BaseCollectableItem
}; 



