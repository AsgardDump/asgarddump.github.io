#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Cat_Pet.ABP_Cat_Pet_C.BlueprintThreadSafeUpdateAnimation
// Size: 0x10(Inherited: 0x4) 
struct FBlueprintThreadSafeUpdateAnimation : public FBlueprintThreadSafeUpdateAnimation
{
	float DeltaTime;  // 0x0(0x4)
	double CallFunc_VSize_ReturnValue;  // 0x8(0x8)

}; 
// Function ABP_Cat_Pet.ABP_Cat_Pet_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// ScriptStruct ABP_Cat_Pet.ABP_Cat_Pet_C.AnimBlueprintGeneratedConstantData
// Size: 0x128(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_46;  // 0x4(0x8)
	float __FloatProperty_47;  // 0xC(0x4)
	struct FName __NameProperty_48;  // 0x10(0x8)
	int32_t __IntProperty_49;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool __BoolProperty_50 : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float __FloatProperty_51;  // 0x20(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_52;  // 0x24(0x2C)
	float __FloatProperty_53;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool __BoolProperty_54 : 1;  // 0x54(0x1)
	uint8_t  __EnumProperty_55;  // 0x55(0x1)
	char EAnimGroupRole __ByteProperty_56;  // 0x56(0x1)
	char pad_87[1];  // 0x57(0x1)
	struct FName __NameProperty_57;  // 0x58(0x8)
	struct FName __NameProperty_58;  // 0x60(0x8)
	int32_t __IntProperty_59;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FAnimNodeFunctionRef __StructProperty_60;  // 0x70(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x90(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x110(0x18)

}; 
// Function ABP_Cat_Pet.ABP_Cat_Pet_C.ExecuteUbergraph_ABP_Cat_Pet
// Size: 0x6(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Cat_Pet
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x5(0x1)

}; 
