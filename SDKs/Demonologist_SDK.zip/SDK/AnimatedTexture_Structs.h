#pragma once 
#include "SDK.h" 
 
 
// Function AnimatedTexture.AnimatedTexture2D.SetLooping
// Size: 0x1(Inherited: 0x0) 
struct FSetLooping
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewLooping : 1;  // 0x0(0x1)

}; 
// Function AnimatedTexture.AnimatedTexture2D.GetPlayRate
// Size: 0x4(Inherited: 0x0) 
struct FGetPlayRate
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AnimatedTexture.AnimatedTexture2D.GetAnimationLength
// Size: 0x4(Inherited: 0x0) 
struct FGetAnimationLength
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AnimatedTexture.AnimatedTexture2D.IsPlaying
// Size: 0x1(Inherited: 0x0) 
struct FIsPlaying
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AnimatedTexture.AnimatedTexture2D.IsLooping
// Size: 0x1(Inherited: 0x0) 
struct FIsLooping
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function AnimatedTexture.AnimatedTexture2D.SetPlayRate
// Size: 0x4(Inherited: 0x0) 
struct FSetPlayRate
{
	float NewRate;  // 0x0(0x4)

}; 
