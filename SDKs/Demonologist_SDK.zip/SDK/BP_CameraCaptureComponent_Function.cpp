#include "SDK.h" 
 
 
struct USceneCaptureComponent2D* UActorComponent::GetSceneCaptureComponentReference(){

	static UObject* p_GetSceneCaptureComponentReference = UObject::FindObject<UFunction>("Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.GetSceneCaptureComponentReference");

	struct {
		struct USceneCaptureComponent2D* return_value;
	} parms;


	ProcessEvent(p_GetSceneCaptureComponentReference, &parms);
	return parms.return_value;
}

void UActorComponent::SetCaptureEveryFrameStatus(bool CaptureEveryFrame){

	static UObject* p_SetCaptureEveryFrameStatus = UObject::FindObject<UFunction>("Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.SetCaptureEveryFrameStatus");

	struct {
		bool CaptureEveryFrame;
	} parms;

	parms.CaptureEveryFrame = CaptureEveryFrame;

	ProcessEvent(p_SetCaptureEveryFrameStatus, &parms);
}

void UActorComponent::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void UActorComponent::ExecuteUbergraph_BP_CameraCaptureComponent(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_CameraCaptureComponent = UObject::FindObject<UFunction>("Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.ExecuteUbergraph_BP_CameraCaptureComponent");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_CameraCaptureComponent, &parms);
}

void UActorComponent::IsCapturing__DelegateSignature(bool IsCapturing){

	static UObject* p_IsCapturing__DelegateSignature = UObject::FindObject<UFunction>("Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.IsCapturing__DelegateSignature");

	struct {
		bool IsCapturing;
	} parms;

	parms.IsCapturing = IsCapturing;

	ProcessEvent(p_IsCapturing__DelegateSignature, &parms);
}

