#pragma once 
#include <ABP_FaceMonster_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_FaceMonster.ABP_FaceMonster_C
// Size: 0x6EC(Inherited: 0x6EC) 
struct UABP_FaceMonster_C : public UABP_BaseEntity_C
{

}; 



