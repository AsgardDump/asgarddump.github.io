#include "SDK.h" 
 
 
void UABP_BaseEntity_C::BlueprintInitializeAnimation(){

	static UObject* p_BlueprintInitializeAnimation = UObject::FindObject<UFunction>("Function ABP_Banshee.ABP_Banshee_C.BlueprintInitializeAnimation");

	struct {
	} parms;


	ProcessEvent(p_BlueprintInitializeAnimation, &parms);
}

void UABP_BaseEntity_C::ExecuteUbergraph_ABP_Banshee(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_Banshee = UObject::FindObject<UFunction>("Function ABP_Banshee.ABP_Banshee_C.ExecuteUbergraph_ABP_Banshee");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_Banshee, &parms);
}

