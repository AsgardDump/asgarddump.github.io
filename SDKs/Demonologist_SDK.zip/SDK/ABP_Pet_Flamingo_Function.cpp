#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::BlueprintThreadSafeUpdateAnimation(float DeltaTime){

	static UObject* p_BlueprintThreadSafeUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.BlueprintThreadSafeUpdateAnimation");

	struct {
		float DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_BlueprintThreadSafeUpdateAnimation, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_BCBFF5B54A5B7B6A9E7C7C96AA450BA2(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_BCBFF5B54A5B7B6A9E7C7C96AA450BA2 = UObject::FindObject<UFunction>("Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_BCBFF5B54A5B7B6A9E7C7C96AA450BA2");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_BCBFF5B54A5B7B6A9E7C7C96AA450BA2, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_C516F34B4719E4306EB61797E4C77064(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_C516F34B4719E4306EB61797E4C77064 = UObject::FindObject<UFunction>("Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_C516F34B4719E4306EB61797E4C77064");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Flamingo_AnimGraphNode_TransitionResult_C516F34B4719E4306EB61797E4C77064, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_Pet_Flamingo(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_Pet_Flamingo = UObject::FindObject<UFunction>("Function ABP_Pet_Flamingo.ABP_Pet_Flamingo_C.ExecuteUbergraph_ABP_Pet_Flamingo");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_Pet_Flamingo, &parms);
}

