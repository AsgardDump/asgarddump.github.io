#pragma once 
#include <ABP_Finger_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Finger.ABP_Finger_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_Finger_C : public UABP_ToolLayerArms_C
{

}; 



