#include "SDK.h" 
 
 
struct FTransform UARTrackedGeometry::GetWorldSpaceEyeTransform(uint8_t  Eye){

	static UObject* p_GetWorldSpaceEyeTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetWorldSpaceEyeTransform");

	struct {
		uint8_t  Eye;
		struct FTransform return_value;
	} parms;

	parms.Eye = Eye;

	ProcessEvent(p_GetWorldSpaceEyeTransform, &parms);
	return parms.return_value;
}

struct FTransform UARTrackedGeometry::GetLocalSpaceEyeTransform(uint8_t  Eye){

	static UObject* p_GetLocalSpaceEyeTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetLocalSpaceEyeTransform");

	struct {
		uint8_t  Eye;
		struct FTransform return_value;
	} parms;

	parms.Eye = Eye;

	ProcessEvent(p_GetLocalSpaceEyeTransform, &parms);
	return parms.return_value;
}

float UARTrackedGeometry::GetBlendShapeValue(uint8_t  BlendShape){

	static UObject* p_GetBlendShapeValue = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetBlendShapeValue");

	struct {
		uint8_t  BlendShape;
		float return_value;
	} parms;

	parms.BlendShape = BlendShape;

	ProcessEvent(p_GetBlendShapeValue, &parms);
	return parms.return_value;
}

struct TMap<uint8_t , float> UARTrackedGeometry::GetBlendShapes(){

	static UObject* p_GetBlendShapes = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceGeometry.GetBlendShapes");

	struct {
		struct TMap<uint8_t , float> return_value;
	} parms;


	ProcessEvent(p_GetBlendShapes, &parms);
	return parms.return_value;
}

struct UARGetCandidateObjectAsyncTaskBlueprintProxy* UARBaseAsyncTaskBlueprintProxy::ARGetCandidateObject(struct UObject* WorldContextObject, struct FVector Location, struct FVector Extent){

	static UObject* p_ARGetCandidateObject = UObject::FindObject<UFunction>("Function AugmentedReality.ARGetCandidateObjectAsyncTaskBlueprintProxy.ARGetCandidateObject");

	struct {
		struct UObject* WorldContextObject;
		struct FVector Location;
		struct FVector Extent;
		struct UARGetCandidateObjectAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Location = Location;
	parms.Extent = Extent;

	ProcessEvent(p_ARGetCandidateObject, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::UnpinComponent(struct USceneComponent* ComponentToUnpin){

	static UObject* p_UnpinComponent = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.UnpinComponent");

	struct {
		struct USceneComponent* ComponentToUnpin;
	} parms;

	parms.ComponentToUnpin = ComponentToUnpin;

	ProcessEvent(p_UnpinComponent, &parms);
}

bool UBlueprintFunctionLibrary::ToggleARCapture(bool bOnOff, uint8_t  CaptureType){

	static UObject* p_ToggleARCapture = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.ToggleARCapture");

	struct {
		bool bOnOff;
		uint8_t  CaptureType;
		bool return_value;
	} parms;

	parms.bOnOff = bOnOff;
	parms.CaptureType = CaptureType;

	ProcessEvent(p_ToggleARCapture, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::StopARSession(){

	static UObject* p_StopARSession = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.StopARSession");

	struct {
	} parms;


	ProcessEvent(p_StopARSession, &parms);
}

void UBlueprintFunctionLibrary::StartARSession(struct UARSessionConfig* SessionConfig){

	static UObject* p_StartARSession = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.StartARSession");

	struct {
		struct UARSessionConfig* SessionConfig;
	} parms;

	parms.SessionConfig = SessionConfig;

	ProcessEvent(p_StartARSession, &parms);
}

void UBlueprintFunctionLibrary::SetEnabledXRCamera(bool bOnOff){

	static UObject* p_SetEnabledXRCamera = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.SetEnabledXRCamera");

	struct {
		bool bOnOff;
	} parms;

	parms.bOnOff = bOnOff;

	ProcessEvent(p_SetEnabledXRCamera, &parms);
}

void UBlueprintFunctionLibrary::SetARWorldScale(float InWorldScale){

	static UObject* p_SetARWorldScale = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.SetARWorldScale");

	struct {
		float InWorldScale;
	} parms;

	parms.InWorldScale = InWorldScale;

	ProcessEvent(p_SetARWorldScale, &parms);
}

void UBlueprintFunctionLibrary::SetARWorldOriginLocationAndRotation(struct FVector OriginLocation, struct FRotator OriginRotation, bool bIsTransformInWorldSpace, bool bMaintainUpDirection){

	static UObject* p_SetARWorldOriginLocationAndRotation = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.SetARWorldOriginLocationAndRotation");

	struct {
		struct FVector OriginLocation;
		struct FRotator OriginRotation;
		bool bIsTransformInWorldSpace;
		bool bMaintainUpDirection;
	} parms;

	parms.OriginLocation = OriginLocation;
	parms.OriginRotation = OriginRotation;
	parms.bIsTransformInWorldSpace = bIsTransformInWorldSpace;
	parms.bMaintainUpDirection = bMaintainUpDirection;

	ProcessEvent(p_SetARWorldOriginLocationAndRotation, &parms);
}

void UBlueprintFunctionLibrary::SetAlignmentTransform(struct FTransform& InAlignmentTransform){

	static UObject* p_SetAlignmentTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.SetAlignmentTransform");

	struct {
		struct FTransform& InAlignmentTransform;
	} parms;

	parms.InAlignmentTransform = InAlignmentTransform;

	ProcessEvent(p_SetAlignmentTransform, &parms);
}

bool UBlueprintFunctionLibrary::SaveARPinToLocalStore(struct FName InSaveName, struct UARPin* InPin){

	static UObject* p_SaveARPinToLocalStore = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.SaveARPinToLocalStore");

	struct {
		struct FName InSaveName;
		struct UARPin* InPin;
		bool return_value;
	} parms;

	parms.InSaveName = InSaveName;
	parms.InPin = InPin;

	ProcessEvent(p_SaveARPinToLocalStore, &parms);
	return parms.return_value;
}

struct FIntPoint UBlueprintFunctionLibrary::ResizeXRCamera(struct FIntPoint& InSize){

	static UObject* p_ResizeXRCamera = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.ResizeXRCamera");

	struct {
		struct FIntPoint& InSize;
		struct FIntPoint return_value;
	} parms;

	parms.InSize = InSize;

	ProcessEvent(p_ResizeXRCamera, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::RemovePin(struct UARPin* PinToRemove){

	static UObject* p_RemovePin = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.RemovePin");

	struct {
		struct UARPin* PinToRemove;
	} parms;

	parms.PinToRemove = PinToRemove;

	ProcessEvent(p_RemovePin, &parms);
}

void UBlueprintFunctionLibrary::RemoveARPinFromLocalStore(struct FName InSaveName){

	static UObject* p_RemoveARPinFromLocalStore = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.RemoveARPinFromLocalStore");

	struct {
		struct FName InSaveName;
	} parms;

	parms.InSaveName = InSaveName;

	ProcessEvent(p_RemoveARPinFromLocalStore, &parms);
}

void UBlueprintFunctionLibrary::RemoveAllARPinsFromLocalStore(){

	static UObject* p_RemoveAllARPinsFromLocalStore = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.RemoveAllARPinsFromLocalStore");

	struct {
	} parms;


	ProcessEvent(p_RemoveAllARPinsFromLocalStore, &parms);
}

struct UARPin* UBlueprintFunctionLibrary::PinComponentToTraceResult(struct USceneComponent* ComponentToPin, struct FARTraceResult& TraceResult, struct FName DebugName){

	static UObject* p_PinComponentToTraceResult = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.PinComponentToTraceResult");

	struct {
		struct USceneComponent* ComponentToPin;
		struct FARTraceResult& TraceResult;
		struct FName DebugName;
		struct UARPin* return_value;
	} parms;

	parms.ComponentToPin = ComponentToPin;
	parms.TraceResult = TraceResult;
	parms.DebugName = DebugName;

	ProcessEvent(p_PinComponentToTraceResult, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::PinComponentToARPin(struct USceneComponent* ComponentToPin, struct UARPin* Pin){

	static UObject* p_PinComponentToARPin = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.PinComponentToARPin");

	struct {
		struct USceneComponent* ComponentToPin;
		struct UARPin* Pin;
		bool return_value;
	} parms;

	parms.ComponentToPin = ComponentToPin;
	parms.Pin = Pin;

	ProcessEvent(p_PinComponentToARPin, &parms);
	return parms.return_value;
}

struct UARPin* UBlueprintFunctionLibrary::PinComponent(struct USceneComponent* ComponentToPin, struct FTransform& PinToWorldTransform, struct UARTrackedGeometry* TrackedGeometry, struct FName DebugName){

	static UObject* p_PinComponent = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.PinComponent");

	struct {
		struct USceneComponent* ComponentToPin;
		struct FTransform& PinToWorldTransform;
		struct UARTrackedGeometry* TrackedGeometry;
		struct FName DebugName;
		struct UARPin* return_value;
	} parms;

	parms.ComponentToPin = ComponentToPin;
	parms.PinToWorldTransform = PinToWorldTransform;
	parms.TrackedGeometry = TrackedGeometry;
	parms.DebugName = DebugName;

	ProcessEvent(p_PinComponent, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::PauseARSession(){

	static UObject* p_PauseARSession = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.PauseARSession");

	struct {
	} parms;


	ProcessEvent(p_PauseARSession, &parms);
}

struct TMap<struct FName, struct UARPin*> UBlueprintFunctionLibrary::LoadARPinsFromLocalStore(){

	static UObject* p_LoadARPinsFromLocalStore = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.LoadARPinsFromLocalStore");

	struct {
		struct TMap<struct FName, struct UARPin*> return_value;
	} parms;


	ProcessEvent(p_LoadARPinsFromLocalStore, &parms);
	return parms.return_value;
}

struct TArray<struct FARTraceResult> UBlueprintFunctionLibrary::LineTraceTrackedObjects3D(struct FVector Start, struct FVector End, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon){

	static UObject* p_LineTraceTrackedObjects3D = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects3D");

	struct {
		struct FVector Start;
		struct FVector End;
		bool bTestFeaturePoints;
		bool bTestGroundPlane;
		bool bTestPlaneExtents;
		bool bTestPlaneBoundaryPolygon;
		struct TArray<struct FARTraceResult> return_value;
	} parms;

	parms.Start = Start;
	parms.End = End;
	parms.bTestFeaturePoints = bTestFeaturePoints;
	parms.bTestGroundPlane = bTestGroundPlane;
	parms.bTestPlaneExtents = bTestPlaneExtents;
	parms.bTestPlaneBoundaryPolygon = bTestPlaneBoundaryPolygon;

	ProcessEvent(p_LineTraceTrackedObjects3D, &parms);
	return parms.return_value;
}

struct TArray<struct FARTraceResult> UBlueprintFunctionLibrary::LineTraceTrackedObjects(struct FVector2D ScreenCoord, bool bTestFeaturePoints, bool bTestGroundPlane, bool bTestPlaneExtents, bool bTestPlaneBoundaryPolygon){

	static UObject* p_LineTraceTrackedObjects = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.LineTraceTrackedObjects");

	struct {
		struct FVector2D ScreenCoord;
		bool bTestFeaturePoints;
		bool bTestGroundPlane;
		bool bTestPlaneExtents;
		bool bTestPlaneBoundaryPolygon;
		struct TArray<struct FARTraceResult> return_value;
	} parms;

	parms.ScreenCoord = ScreenCoord;
	parms.bTestFeaturePoints = bTestFeaturePoints;
	parms.bTestGroundPlane = bTestGroundPlane;
	parms.bTestPlaneExtents = bTestPlaneExtents;
	parms.bTestPlaneBoundaryPolygon = bTestPlaneBoundaryPolygon;

	ProcessEvent(p_LineTraceTrackedObjects, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsSessionTypeSupported(uint8_t  SessionType){

	static UObject* p_IsSessionTypeSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsSessionTypeSupported");

	struct {
		uint8_t  SessionType;
		bool return_value;
	} parms;

	parms.SessionType = SessionType;

	ProcessEvent(p_IsSessionTypeSupported, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsSessionTrackingFeatureSupported(uint8_t  SessionType, uint8_t  SessionTrackingFeature){

	static UObject* p_IsSessionTrackingFeatureSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsSessionTrackingFeatureSupported");

	struct {
		uint8_t  SessionType;
		uint8_t  SessionTrackingFeature;
		bool return_value;
	} parms;

	parms.SessionType = SessionType;
	parms.SessionTrackingFeature = SessionTrackingFeature;

	ProcessEvent(p_IsSessionTrackingFeatureSupported, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsSceneReconstructionSupported(uint8_t  SessionType, uint8_t  SceneReconstructionMethod){

	static UObject* p_IsSceneReconstructionSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsSceneReconstructionSupported");

	struct {
		uint8_t  SessionType;
		uint8_t  SceneReconstructionMethod;
		bool return_value;
	} parms;

	parms.SessionType = SessionType;
	parms.SceneReconstructionMethod = SceneReconstructionMethod;

	ProcessEvent(p_IsSceneReconstructionSupported, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsARSupported(){

	static UObject* p_IsARSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsARSupported");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsARSupported, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsARPinLocalStoreSupported(){

	static UObject* p_IsARPinLocalStoreSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreSupported");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsARPinLocalStoreSupported, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsARPinLocalStoreReady(){

	static UObject* p_IsARPinLocalStoreReady = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.IsARPinLocalStoreReady");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsARPinLocalStoreReady, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetWorldMappingStatus(){

	static UObject* p_GetWorldMappingStatus = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetWorldMappingStatus");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetWorldMappingStatus, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetTrackingQualityReason(){

	static UObject* p_GetTrackingQualityReason = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetTrackingQualityReason");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingQualityReason, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetTrackingQuality(){

	static UObject* p_GetTrackingQuality = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetTrackingQuality");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingQuality, &parms);
	return parms.return_value;
}

struct TArray<struct FARVideoFormat> UBlueprintFunctionLibrary::GetSupportedVideoFormats(uint8_t  SessionType){

	static UObject* p_GetSupportedVideoFormats = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetSupportedVideoFormats");

	struct {
		uint8_t  SessionType;
		struct TArray<struct FARVideoFormat> return_value;
	} parms;

	parms.SessionType = SessionType;

	ProcessEvent(p_GetSupportedVideoFormats, &parms);
	return parms.return_value;
}

struct UARSessionConfig* UBlueprintFunctionLibrary::GetSessionConfig(){

	static UObject* p_GetSessionConfig = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetSessionConfig");

	struct {
		struct UARSessionConfig* return_value;
	} parms;


	ProcessEvent(p_GetSessionConfig, &parms);
	return parms.return_value;
}

struct TArray<struct FVector> UBlueprintFunctionLibrary::GetPointCloud(){

	static UObject* p_GetPointCloud = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetPointCloud");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetPointCloud, &parms);
	return parms.return_value;
}

struct UARTexture* UBlueprintFunctionLibrary::GetPersonSegmentationImage(){

	static UObject* p_GetPersonSegmentationImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationImage");

	struct {
		struct UARTexture* return_value;
	} parms;


	ProcessEvent(p_GetPersonSegmentationImage, &parms);
	return parms.return_value;
}

struct UARTexture* UBlueprintFunctionLibrary::GetPersonSegmentationDepthImage(){

	static UObject* p_GetPersonSegmentationDepthImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetPersonSegmentationDepthImage");

	struct {
		struct UARTexture* return_value;
	} parms;


	ProcessEvent(p_GetPersonSegmentationDepthImage, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetObjectClassificationAtLocation(struct FVector& InWorldLocation, uint8_t & OutClassification, struct FVector& OutClassificationLocation, float MaxLocationDiff){

	static UObject* p_GetObjectClassificationAtLocation = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetObjectClassificationAtLocation");

	struct {
		struct FVector& InWorldLocation;
		uint8_t & OutClassification;
		struct FVector& OutClassificationLocation;
		float MaxLocationDiff;
		bool return_value;
	} parms;

	parms.InWorldLocation = InWorldLocation;
	parms.OutClassification = OutClassification;
	parms.OutClassificationLocation = OutClassificationLocation;
	parms.MaxLocationDiff = MaxLocationDiff;

	ProcessEvent(p_GetObjectClassificationAtLocation, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetNumberOfTrackedFacesSupported(){

	static UObject* p_GetNumberOfTrackedFacesSupported = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetNumberOfTrackedFacesSupported");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetNumberOfTrackedFacesSupported, &parms);
	return parms.return_value;
}

struct UARLightEstimate* UBlueprintFunctionLibrary::GetCurrentLightEstimate(){

	static UObject* p_GetCurrentLightEstimate = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetCurrentLightEstimate");

	struct {
		struct UARLightEstimate* return_value;
	} parms;


	ProcessEvent(p_GetCurrentLightEstimate, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetCameraIntrinsics(struct FARCameraIntrinsics& OutCameraIntrinsics){

	static UObject* p_GetCameraIntrinsics = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetCameraIntrinsics");

	struct {
		struct FARCameraIntrinsics& OutCameraIntrinsics;
		bool return_value;
	} parms;

	parms.OutCameraIntrinsics = OutCameraIntrinsics;

	ProcessEvent(p_GetCameraIntrinsics, &parms);
	return parms.return_value;
}

struct UARTextureCameraImage* UBlueprintFunctionLibrary::GetCameraImage(){

	static UObject* p_GetCameraImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetCameraImage");

	struct {
		struct UARTextureCameraImage* return_value;
	} parms;


	ProcessEvent(p_GetCameraImage, &parms);
	return parms.return_value;
}

struct UARTextureCameraDepth* UBlueprintFunctionLibrary::GetCameraDepth(){

	static UObject* p_GetCameraDepth = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetCameraDepth");

	struct {
		struct UARTextureCameraDepth* return_value;
	} parms;


	ProcessEvent(p_GetCameraDepth, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetARWorldScale(){

	static UObject* p_GetARWorldScale = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetARWorldScale");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetARWorldScale, &parms);
	return parms.return_value;
}

struct UARTexture* UBlueprintFunctionLibrary::GetARTexture(uint8_t  TextureType){

	static UObject* p_GetARTexture = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetARTexture");

	struct {
		uint8_t  TextureType;
		struct UARTexture* return_value;
	} parms;

	parms.TextureType = TextureType;

	ProcessEvent(p_GetARTexture, &parms);
	return parms.return_value;
}

struct FARSessionStatus UBlueprintFunctionLibrary::GetARSessionStatus(){

	static UObject* p_GetARSessionStatus = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetARSessionStatus");

	struct {
		struct FARSessionStatus return_value;
	} parms;


	ProcessEvent(p_GetARSessionStatus, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedPose*> UBlueprintFunctionLibrary::GetAllTrackedPoses(){

	static UObject* p_GetAllTrackedPoses = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoses");

	struct {
		struct TArray<struct UARTrackedPose*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedPoses, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedPoint*> UBlueprintFunctionLibrary::GetAllTrackedPoints(){

	static UObject* p_GetAllTrackedPoints = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPoints");

	struct {
		struct TArray<struct UARTrackedPoint*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedPoints, &parms);
	return parms.return_value;
}

struct TArray<struct UARPlaneGeometry*> UBlueprintFunctionLibrary::GetAllTrackedPlanes(){

	static UObject* p_GetAllTrackedPlanes = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedPlanes");

	struct {
		struct TArray<struct UARPlaneGeometry*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedPlanes, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedImage*> UBlueprintFunctionLibrary::GetAllTrackedImages(){

	static UObject* p_GetAllTrackedImages = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedImages");

	struct {
		struct TArray<struct UARTrackedImage*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedImages, &parms);
	return parms.return_value;
}

struct TArray<struct UAREnvironmentCaptureProbe*> UBlueprintFunctionLibrary::GetAllTrackedEnvironmentCaptureProbes(){

	static UObject* p_GetAllTrackedEnvironmentCaptureProbes = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTrackedEnvironmentCaptureProbes");

	struct {
		struct TArray<struct UAREnvironmentCaptureProbe*> return_value;
	} parms;


	ProcessEvent(p_GetAllTrackedEnvironmentCaptureProbes, &parms);
	return parms.return_value;
}

struct TArray<struct FARPose2D> UBlueprintFunctionLibrary::GetAllTracked2DPoses(){

	static UObject* p_GetAllTracked2DPoses = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllTracked2DPoses");

	struct {
		struct TArray<struct FARPose2D> return_value;
	} parms;


	ProcessEvent(p_GetAllTracked2DPoses, &parms);
	return parms.return_value;
}

struct TArray<struct UARPin*> UBlueprintFunctionLibrary::GetAllPins(){

	static UObject* p_GetAllPins = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllPins");

	struct {
		struct TArray<struct UARPin*> return_value;
	} parms;


	ProcessEvent(p_GetAllPins, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedGeometry*> UBlueprintFunctionLibrary::GetAllGeometriesByClass(UARTrackedGeometry* GeometryClass){

	static UObject* p_GetAllGeometriesByClass = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllGeometriesByClass");

	struct {
		UARTrackedGeometry* GeometryClass;
		struct TArray<struct UARTrackedGeometry*> return_value;
	} parms;

	parms.GeometryClass = GeometryClass;

	ProcessEvent(p_GetAllGeometriesByClass, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedGeometry*> UBlueprintFunctionLibrary::GetAllGeometries(){

	static UObject* p_GetAllGeometries = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAllGeometries");

	struct {
		struct TArray<struct UARTrackedGeometry*> return_value;
	} parms;


	ProcessEvent(p_GetAllGeometries, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::GetAlignmentTransform(){

	static UObject* p_GetAlignmentTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.GetAlignmentTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetAlignmentTransform, &parms);
	return parms.return_value;
}

struct TArray<struct UARTrackedPoint*> UBlueprintFunctionLibrary::FindTrackedPointsByName(struct FString PointName){

	static UObject* p_FindTrackedPointsByName = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.FindTrackedPointsByName");

	struct {
		struct FString PointName;
		struct TArray<struct UARTrackedPoint*> return_value;
	} parms;

	parms.PointName = PointName;

	ProcessEvent(p_FindTrackedPointsByName, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::DebugDrawTrackedGeometry(struct UARTrackedGeometry* TrackedGeometry, struct UObject* WorldContextObject, struct FLinearColor Color, float OutlineThickness, float PersistForSeconds){

	static UObject* p_DebugDrawTrackedGeometry = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.DebugDrawTrackedGeometry");

	struct {
		struct UARTrackedGeometry* TrackedGeometry;
		struct UObject* WorldContextObject;
		struct FLinearColor Color;
		float OutlineThickness;
		float PersistForSeconds;
	} parms;

	parms.TrackedGeometry = TrackedGeometry;
	parms.WorldContextObject = WorldContextObject;
	parms.Color = Color;
	parms.OutlineThickness = OutlineThickness;
	parms.PersistForSeconds = PersistForSeconds;

	ProcessEvent(p_DebugDrawTrackedGeometry, &parms);
}

void UBlueprintFunctionLibrary::DebugDrawPin(struct UARPin* ARPin, struct UObject* WorldContextObject, struct FLinearColor Color, float Scale, float PersistForSeconds){

	static UObject* p_DebugDrawPin = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.DebugDrawPin");

	struct {
		struct UARPin* ARPin;
		struct UObject* WorldContextObject;
		struct FLinearColor Color;
		float Scale;
		float PersistForSeconds;
	} parms;

	parms.ARPin = ARPin;
	parms.WorldContextObject = WorldContextObject;
	parms.Color = Color;
	parms.Scale = Scale;
	parms.PersistForSeconds = PersistForSeconds;

	ProcessEvent(p_DebugDrawPin, &parms);
}

void UBlueprintFunctionLibrary::CalculateClosestIntersection(struct TArray<struct FVector>& StartPoints, struct TArray<struct FVector>& EndPoints, struct FVector& ClosestIntersection){

	static UObject* p_CalculateClosestIntersection = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.CalculateClosestIntersection");

	struct {
		struct TArray<struct FVector>& StartPoints;
		struct TArray<struct FVector>& EndPoints;
		struct FVector& ClosestIntersection;
	} parms;

	parms.StartPoints = StartPoints;
	parms.EndPoints = EndPoints;
	parms.ClosestIntersection = ClosestIntersection;

	ProcessEvent(p_CalculateClosestIntersection, &parms);
}

void UBlueprintFunctionLibrary::CalculateAlignmentTransform(struct FTransform& TransformInFirstCoordinateSystem, struct FTransform& TransformInSecondCoordinateSystem, struct FTransform& AlignmentTransform){

	static UObject* p_CalculateAlignmentTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.CalculateAlignmentTransform");

	struct {
		struct FTransform& TransformInFirstCoordinateSystem;
		struct FTransform& TransformInSecondCoordinateSystem;
		struct FTransform& AlignmentTransform;
	} parms;

	parms.TransformInFirstCoordinateSystem = TransformInFirstCoordinateSystem;
	parms.TransformInSecondCoordinateSystem = TransformInSecondCoordinateSystem;
	parms.AlignmentTransform = AlignmentTransform;

	ProcessEvent(p_CalculateAlignmentTransform, &parms);
}

bool UBlueprintFunctionLibrary::AddTrackedPointWithName(struct FTransform& WorldTransform, struct FString PointName, bool bDeletePointsWithSameName){

	static UObject* p_AddTrackedPointWithName = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.AddTrackedPointWithName");

	struct {
		struct FTransform& WorldTransform;
		struct FString PointName;
		bool bDeletePointsWithSameName;
		bool return_value;
	} parms;

	parms.WorldTransform = WorldTransform;
	parms.PointName = PointName;
	parms.bDeletePointsWithSameName = bDeletePointsWithSameName;

	ProcessEvent(p_AddTrackedPointWithName, &parms);
	return parms.return_value;
}

struct UARCandidateImage* UBlueprintFunctionLibrary::AddRuntimeCandidateImage(struct UARSessionConfig* SessionConfig, struct UTexture2D* CandidateTexture, struct FString FriendlyName, float PhysicalWidth){

	static UObject* p_AddRuntimeCandidateImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.AddRuntimeCandidateImage");

	struct {
		struct UARSessionConfig* SessionConfig;
		struct UTexture2D* CandidateTexture;
		struct FString FriendlyName;
		float PhysicalWidth;
		struct UARCandidateImage* return_value;
	} parms;

	parms.SessionConfig = SessionConfig;
	parms.CandidateTexture = CandidateTexture;
	parms.FriendlyName = FriendlyName;
	parms.PhysicalWidth = PhysicalWidth;

	ProcessEvent(p_AddRuntimeCandidateImage, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::AddManualEnvironmentCaptureProbe(struct FVector Location, struct FVector Extent){

	static UObject* p_AddManualEnvironmentCaptureProbe = UObject::FindObject<UFunction>("Function AugmentedReality.ARBlueprintLibrary.AddManualEnvironmentCaptureProbe");

	struct {
		struct FVector Location;
		struct FVector Extent;
		bool return_value;
	} parms;

	parms.Location = Location;
	parms.Extent = Extent;

	ProcessEvent(p_AddManualEnvironmentCaptureProbe, &parms);
	return parms.return_value;
}

struct UARComponent* AActor::AddARComponent(UARComponent* InComponentClass, struct FGuid& NativeID){

	static UObject* p_AddARComponent = UObject::FindObject<UFunction>("Function AugmentedReality.ARActor.AddARComponent");

	struct {
		UARComponent* InComponentClass;
		struct FGuid& NativeID;
		struct UARComponent* return_value;
	} parms;

	parms.InComponentClass = InComponentClass;
	parms.NativeID = NativeID;

	ProcessEvent(p_AddARComponent, &parms);
	return parms.return_value;
}

struct UARTrackedGeometry* UBlueprintFunctionLibrary::GetTrackedGeometry(struct FARTraceResult& TraceResult){

	static UObject* p_GetTrackedGeometry = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetTrackedGeometry");

	struct {
		struct FARTraceResult& TraceResult;
		struct UARTrackedGeometry* return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetTrackedGeometry, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::GetTraceChannel(struct FARTraceResult& TraceResult){

	static UObject* p_GetTraceChannel = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetTraceChannel");

	struct {
		struct FARTraceResult& TraceResult;
		uint8_t  return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetTraceChannel, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::GetLocalTransform(struct FARTraceResult& TraceResult){

	static UObject* p_GetLocalTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetLocalTransform");

	struct {
		struct FARTraceResult& TraceResult;
		struct FTransform return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetLocalTransform, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::GetLocalToWorldTransform(struct FARTraceResult& TraceResult){

	static UObject* p_GetLocalToWorldTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetLocalToWorldTransform");

	struct {
		struct FARTraceResult& TraceResult;
		struct FTransform return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetLocalToWorldTransform, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::GetLocalToTrackingTransform(struct FARTraceResult& TraceResult){

	static UObject* p_GetLocalToTrackingTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetLocalToTrackingTransform");

	struct {
		struct FARTraceResult& TraceResult;
		struct FTransform return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetLocalToTrackingTransform, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetDistanceFromCamera(struct FARTraceResult& TraceResult){

	static UObject* p_GetDistanceFromCamera = UObject::FindObject<UFunction>("Function AugmentedReality.ARTraceResultLibrary.GetDistanceFromCamera");

	struct {
		struct FARTraceResult& TraceResult;
		float return_value;
	} parms;

	parms.TraceResult = TraceResult;

	ProcessEvent(p_GetDistanceFromCamera, &parms);
	return parms.return_value;
}

void AGameMode::SetPreviewImageData(struct TArray<char> ImageData){

	static UObject* p_SetPreviewImageData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.SetPreviewImageData");

	struct {
		struct TArray<char> ImageData;
	} parms;

	parms.ImageData = ImageData;

	ProcessEvent(p_SetPreviewImageData, &parms);
}

void AGameMode::SetARWorldSharingIsReady(){

	static UObject* p_SetARWorldSharingIsReady = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.SetARWorldSharingIsReady");

	struct {
	} parms;


	ProcessEvent(p_SetARWorldSharingIsReady, &parms);
}

void AGameMode::SetARSharedWorldData(struct TArray<char> ARWorldData){

	static UObject* p_SetARSharedWorldData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.SetARSharedWorldData");

	struct {
		struct TArray<char> ARWorldData;
	} parms;

	parms.ARWorldData = ARWorldData;

	ProcessEvent(p_SetARSharedWorldData, &parms);
}

struct AARSharedWorldGameState* AGameMode::GetARSharedWorldGameState(){

	static UObject* p_GetARSharedWorldGameState = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameMode.GetARSharedWorldGameState");

	struct {
		struct AARSharedWorldGameState* return_value;
	} parms;


	ProcessEvent(p_GetARSharedWorldGameState, &parms);
	return parms.return_value;
}

void UARComponent::SetPlaneComponentDebugMode(uint8_t  NewDebugMode){

	static UObject* p_SetPlaneComponentDebugMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneComponent.SetPlaneComponentDebugMode");

	struct {
		uint8_t  NewDebugMode;
	} parms;

	parms.NewDebugMode = NewDebugMode;

	ProcessEvent(p_SetPlaneComponentDebugMode, &parms);
}

void UARComponent::SetObjectClassificationDebugColors(struct TMap<uint8_t , struct FLinearColor>& InColors){

	static UObject* p_SetObjectClassificationDebugColors = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneComponent.SetObjectClassificationDebugColors");

	struct {
		struct TMap<uint8_t , struct FLinearColor>& InColors;
	} parms;

	parms.InColors = InColors;

	ProcessEvent(p_SetObjectClassificationDebugColors, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARPlaneUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneComponent.ServerUpdatePayload");

	struct {
		struct FARPlaneUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARPlaneUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneComponent.ReceiveUpdate");

	struct {
		struct FARPlaneUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARPlaneUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneComponent.ReceiveAdd");

	struct {
		struct FARPlaneUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

struct TMap<uint8_t , struct FLinearColor> UARComponent::GetObjectClassificationDebugColors(){

	static UObject* p_GetObjectClassificationDebugColors = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneComponent.GetObjectClassificationDebugColors");

	struct {
		struct TMap<uint8_t , struct FLinearColor> return_value;
	} parms;


	ProcessEvent(p_GetObjectClassificationDebugColors, &parms);
	return parms.return_value;
}

float UARLightEstimate::GetAmbientIntensityLumens(){

	static UObject* p_GetAmbientIntensityLumens = UObject::FindObject<UFunction>("Function AugmentedReality.ARBasicLightEstimate.GetAmbientIntensityLumens");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAmbientIntensityLumens, &parms);
	return parms.return_value;
}

float UARLightEstimate::GetAmbientColorTemperatureKelvin(){

	static UObject* p_GetAmbientColorTemperatureKelvin = UObject::FindObject<UFunction>("Function AugmentedReality.ARBasicLightEstimate.GetAmbientColorTemperatureKelvin");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAmbientColorTemperatureKelvin, &parms);
	return parms.return_value;
}

struct FLinearColor UARLightEstimate::GetAmbientColor(){

	static UObject* p_GetAmbientColor = UObject::FindObject<UFunction>("Function AugmentedReality.ARBasicLightEstimate.GetAmbientColor");

	struct {
		struct FLinearColor return_value;
	} parms;


	ProcessEvent(p_GetAmbientColor, &parms);
	return parms.return_value;
}

void UARBaseAsyncTaskBlueprintProxy::GetGeoLocationDelegate__DelegateSignature(float Longitude, float Latitude, float Altitude, struct FString Error){

	static UObject* p_GetGeoLocationDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationDelegate__DelegateSignature");

	struct {
		float Longitude;
		float Latitude;
		float Altitude;
		struct FString Error;
	} parms;

	parms.Longitude = Longitude;
	parms.Latitude = Latitude;
	parms.Altitude = Altitude;
	parms.Error = Error;

	ProcessEvent(p_GetGeoLocationDelegate__DelegateSignature, &parms);
}

struct UGetGeoLocationAsyncTaskBlueprintProxy* UARBaseAsyncTaskBlueprintProxy::GetGeoLocationAtWorldPosition(struct UObject* WorldContextObject, struct FVector& WorldPosition){

	static UObject* p_GetGeoLocationAtWorldPosition = UObject::FindObject<UFunction>("Function AugmentedReality.GetGeoLocationAsyncTaskBlueprintProxy.GetGeoLocationAtWorldPosition");

	struct {
		struct UObject* WorldContextObject;
		struct FVector& WorldPosition;
		struct UGetGeoLocationAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.WorldPosition = WorldPosition;

	ProcessEvent(p_GetGeoLocationAtWorldPosition, &parms);
	return parms.return_value;
}

struct UARSaveWorldAsyncTaskBlueprintProxy* UARBaseAsyncTaskBlueprintProxy::ARSaveWorld(struct UObject* WorldContextObject){

	static UObject* p_ARSaveWorld = UObject::FindObject<UFunction>("Function AugmentedReality.ARSaveWorldAsyncTaskBlueprintProxy.ARSaveWorld");

	struct {
		struct UObject* WorldContextObject;
		struct UARSaveWorldAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_ARSaveWorld, &parms);
	return parms.return_value;
}

void USceneComponent::UpdateVisualization(){

	static UObject* p_UpdateVisualization = UObject::FindObject<UFunction>("Function AugmentedReality.ARComponent.UpdateVisualization");

	struct {
	} parms;


	ProcessEvent(p_UpdateVisualization, &parms);
}

void USceneComponent::SetNativeID(struct FGuid NativeID){

	static UObject* p_SetNativeID = UObject::FindObject<UFunction>("Function AugmentedReality.ARComponent.SetNativeID");

	struct {
		struct FGuid NativeID;
	} parms;

	parms.NativeID = NativeID;

	ProcessEvent(p_SetNativeID, &parms);
}

void USceneComponent::ReceiveRemove(){

	static UObject* p_ReceiveRemove = UObject::FindObject<UFunction>("Function AugmentedReality.ARComponent.ReceiveRemove");

	struct {
	} parms;


	ProcessEvent(p_ReceiveRemove, &parms);
}

void USceneComponent::OnRep_Payload(){

	static UObject* p_OnRep_Payload = UObject::FindObject<UFunction>("Function AugmentedReality.ARComponent.OnRep_Payload");

	struct {
	} parms;


	ProcessEvent(p_OnRep_Payload, &parms);
}

struct UMRMeshComponent* USceneComponent::GetMRMesh(){

	static UObject* p_GetMRMesh = UObject::FindObject<UFunction>("Function AugmentedReality.ARComponent.GetMRMesh");

	struct {
		struct UMRMeshComponent* return_value;
	} parms;


	ProcessEvent(p_GetMRMesh, &parms);
	return parms.return_value;
}

void UARComponent::ServerUpdatePayload(struct FARPointUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARPointComponent.ServerUpdatePayload");

	struct {
		struct FARPointUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARPointUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARPointComponent.ReceiveUpdate");

	struct {
		struct FARPointUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARPointUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARPointComponent.ReceiveAdd");

	struct {
		struct FARPointUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UARComponent::SetFaceComponentDebugMode(uint8_t  NewDebugMode){

	static UObject* p_SetFaceComponentDebugMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceComponent.SetFaceComponentDebugMode");

	struct {
		uint8_t  NewDebugMode;
	} parms;

	parms.NewDebugMode = NewDebugMode;

	ProcessEvent(p_SetFaceComponentDebugMode, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARFaceUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceComponent.ServerUpdatePayload");

	struct {
		struct FARFaceUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARFaceUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceComponent.ReceiveUpdate");

	struct {
		struct FARFaceUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARFaceUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARFaceComponent.ReceiveAdd");

	struct {
		struct FARFaceUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARObjectUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARObjectComponent.ServerUpdatePayload");

	struct {
		struct FARObjectUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARObjectUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARObjectComponent.ReceiveUpdate");

	struct {
		struct FARObjectUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARObjectUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARObjectComponent.ReceiveAdd");

	struct {
		struct FARObjectUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UARComponent::SetImageComponentDebugMode(uint8_t  NewDebugMode){

	static UObject* p_SetImageComponentDebugMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARImageComponent.SetImageComponentDebugMode");

	struct {
		uint8_t  NewDebugMode;
	} parms;

	parms.NewDebugMode = NewDebugMode;

	ProcessEvent(p_SetImageComponentDebugMode, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARImageUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARImageComponent.ServerUpdatePayload");

	struct {
		struct FARImageUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARImageUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARImageComponent.ReceiveUpdate");

	struct {
		struct FARImageUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARImageUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARImageComponent.ReceiveAdd");

	struct {
		struct FARImageUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UARComponent::SetQRCodeComponentDebugMode(uint8_t  NewDebugMode){

	static UObject* p_SetQRCodeComponentDebugMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARQRCodeComponent.SetQRCodeComponentDebugMode");

	struct {
		uint8_t  NewDebugMode;
	} parms;

	parms.NewDebugMode = NewDebugMode;

	ProcessEvent(p_SetQRCodeComponentDebugMode, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARQRCodeUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARQRCodeComponent.ServerUpdatePayload");

	struct {
		struct FARQRCodeUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARQRCodeUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARQRCodeComponent.ReceiveUpdate");

	struct {
		struct FARQRCodeUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARQRCodeUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARQRCodeComponent.ReceiveAdd");

	struct {
		struct FARQRCodeUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void USceneComponent::ServerSpawnARActor(UObject* ComponentClass, struct FGuid NativeID){

	static UObject* p_ServerSpawnARActor = UObject::FindObject<UFunction>("Function AugmentedReality.ARLifeCycleComponent.ServerSpawnARActor");

	struct {
		UObject* ComponentClass;
		struct FGuid NativeID;
	} parms;

	parms.ComponentClass = ComponentClass;
	parms.NativeID = NativeID;

	ProcessEvent(p_ServerSpawnARActor, &parms);
}

void USceneComponent::ServerDestroyARActor(struct AARActor* Actor){

	static UObject* p_ServerDestroyARActor = UObject::FindObject<UFunction>("Function AugmentedReality.ARLifeCycleComponent.ServerDestroyARActor");

	struct {
		struct AARActor* Actor;
	} parms;

	parms.Actor = Actor;

	ProcessEvent(p_ServerDestroyARActor, &parms);
}

void USceneComponent::InstanceARActorToBeDestroyedDelegate__DelegateSignature(struct AARActor* Actor){

	static UObject* p_InstanceARActorToBeDestroyedDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorToBeDestroyedDelegate__DelegateSignature");

	struct {
		struct AARActor* Actor;
	} parms;

	parms.Actor = Actor;

	ProcessEvent(p_InstanceARActorToBeDestroyedDelegate__DelegateSignature, &parms);
}

void USceneComponent::InstanceARActorSpawnedDelegate__DelegateSignature(UObject* ComponentClass, struct FGuid NativeID, struct AARActor* SpawnedActor){

	static UObject* p_InstanceARActorSpawnedDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AugmentedReality.ARLifeCycleComponent.InstanceARActorSpawnedDelegate__DelegateSignature");

	struct {
		UObject* ComponentClass;
		struct FGuid NativeID;
		struct AARActor* SpawnedActor;
	} parms;

	parms.ComponentClass = ComponentClass;
	parms.NativeID = NativeID;
	parms.SpawnedActor = SpawnedActor;

	ProcessEvent(p_InstanceARActorSpawnedDelegate__DelegateSignature, &parms);
}

void UARComponent::SetPoseComponentDebugMode(uint8_t  NewDebugMode){

	static UObject* p_SetPoseComponentDebugMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARPoseComponent.SetPoseComponentDebugMode");

	struct {
		uint8_t  NewDebugMode;
	} parms;

	parms.NewDebugMode = NewDebugMode;

	ProcessEvent(p_SetPoseComponentDebugMode, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARPoseUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARPoseComponent.ServerUpdatePayload");

	struct {
		struct FARPoseUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARPoseUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARPoseComponent.ReceiveUpdate");

	struct {
		struct FARPoseUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARPoseUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARPoseComponent.ReceiveAdd");

	struct {
		struct FARPoseUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UARComponent::ServerUpdatePayload(struct FAREnvironmentProbeUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.AREnvironmentProbeComponent.ServerUpdatePayload");

	struct {
		struct FAREnvironmentProbeUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FAREnvironmentProbeUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.AREnvironmentProbeComponent.ReceiveUpdate");

	struct {
		struct FAREnvironmentProbeUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FAREnvironmentProbeUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.AREnvironmentProbeComponent.ReceiveAdd");

	struct {
		struct FAREnvironmentProbeUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARMeshUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARMeshComponent.ServerUpdatePayload");

	struct {
		struct FARMeshUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARMeshUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARMeshComponent.ReceiveUpdate");

	struct {
		struct FARMeshUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARMeshUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARMeshComponent.ReceiveAdd");

	struct {
		struct FARMeshUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UARComponent::SetGeoAnchorComponentDebugMode(uint8_t  NewDebugMode){

	static UObject* p_SetGeoAnchorComponentDebugMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchorComponent.SetGeoAnchorComponentDebugMode");

	struct {
		uint8_t  NewDebugMode;
	} parms;

	parms.NewDebugMode = NewDebugMode;

	ProcessEvent(p_SetGeoAnchorComponentDebugMode, &parms);
}

void UARComponent::ServerUpdatePayload(struct FARGeoAnchorUpdatePayload NewPayload){

	static UObject* p_ServerUpdatePayload = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchorComponent.ServerUpdatePayload");

	struct {
		struct FARGeoAnchorUpdatePayload NewPayload;
	} parms;

	parms.NewPayload = NewPayload;

	ProcessEvent(p_ServerUpdatePayload, &parms);
}

void UARComponent::ReceiveUpdate(struct FARGeoAnchorUpdatePayload& Payload){

	static UObject* p_ReceiveUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchorComponent.ReceiveUpdate");

	struct {
		struct FARGeoAnchorUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveUpdate, &parms);
}

void UARComponent::ReceiveAdd(struct FARGeoAnchorUpdatePayload& Payload){

	static UObject* p_ReceiveAdd = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchorComponent.ReceiveAdd");

	struct {
		struct FARGeoAnchorUpdatePayload& Payload;
	} parms;

	parms.Payload = Payload;

	ProcessEvent(p_ReceiveAdd, &parms);
}

void UObject::StartARSessionLatent(struct UObject* WorldContextObject, struct UARSessionConfig* SessionConfig, struct FLatentActionInfo LatentInfo){

	static UObject* p_StartARSessionLatent = UObject::FindObject<UFunction>("Function AugmentedReality.ARDependencyHandler.StartARSessionLatent");

	struct {
		struct UObject* WorldContextObject;
		struct UARSessionConfig* SessionConfig;
		struct FLatentActionInfo LatentInfo;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SessionConfig = SessionConfig;
	parms.LatentInfo = LatentInfo;

	ProcessEvent(p_StartARSessionLatent, &parms);
}

void UObject::RequestARSessionPermission(struct UObject* WorldContextObject, struct UARSessionConfig* SessionConfig, struct FLatentActionInfo LatentInfo, uint8_t & OutPermissionResult){

	static UObject* p_RequestARSessionPermission = UObject::FindObject<UFunction>("Function AugmentedReality.ARDependencyHandler.RequestARSessionPermission");

	struct {
		struct UObject* WorldContextObject;
		struct UARSessionConfig* SessionConfig;
		struct FLatentActionInfo LatentInfo;
		uint8_t & OutPermissionResult;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.SessionConfig = SessionConfig;
	parms.LatentInfo = LatentInfo;
	parms.OutPermissionResult = OutPermissionResult;

	ProcessEvent(p_RequestARSessionPermission, &parms);
}

void UObject::InstallARService(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, uint8_t & OutInstallResult){

	static UObject* p_InstallARService = UObject::FindObject<UFunction>("Function AugmentedReality.ARDependencyHandler.InstallARService");

	struct {
		struct UObject* WorldContextObject;
		struct FLatentActionInfo LatentInfo;
		uint8_t & OutInstallResult;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.LatentInfo = LatentInfo;
	parms.OutInstallResult = OutInstallResult;

	ProcessEvent(p_InstallARService, &parms);
}

struct UARDependencyHandler* UObject::GetARDependencyHandler(){

	static UObject* p_GetARDependencyHandler = UObject::FindObject<UFunction>("Function AugmentedReality.ARDependencyHandler.GetARDependencyHandler");

	struct {
		struct UARDependencyHandler* return_value;
	} parms;


	ProcessEvent(p_GetARDependencyHandler, &parms);
	return parms.return_value;
}

void UObject::CheckARServiceAvailability(struct UObject* WorldContextObject, struct FLatentActionInfo LatentInfo, uint8_t & OutAvailability){

	static UObject* p_CheckARServiceAvailability = UObject::FindObject<UFunction>("Function AugmentedReality.ARDependencyHandler.CheckARServiceAvailability");

	struct {
		struct UObject* WorldContextObject;
		struct FLatentActionInfo LatentInfo;
		uint8_t & OutAvailability;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.LatentInfo = LatentInfo;
	parms.OutAvailability = OutAvailability;

	ProcessEvent(p_CheckARServiceAvailability, &parms);
}

void UDataAsset::SetFriendlyName(struct FString NewName){

	static UObject* p_SetFriendlyName = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.SetFriendlyName");

	struct {
		struct FString NewName;
	} parms;

	parms.NewName = NewName;

	ProcessEvent(p_SetFriendlyName, &parms);
}

void UDataAsset::SetCandidateObjectData(struct TArray<char>& InCandidateObject){

	static UObject* p_SetCandidateObjectData = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.SetCandidateObjectData");

	struct {
		struct TArray<char>& InCandidateObject;
	} parms;

	parms.InCandidateObject = InCandidateObject;

	ProcessEvent(p_SetCandidateObjectData, &parms);
}

void UDataAsset::SetBoundingBox(struct FBox& InBoundingBox){

	static UObject* p_SetBoundingBox = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.SetBoundingBox");

	struct {
		struct FBox& InBoundingBox;
	} parms;

	parms.InBoundingBox = InBoundingBox;

	ProcessEvent(p_SetBoundingBox, &parms);
}

struct FString UDataAsset::GetFriendlyName(){

	static UObject* p_GetFriendlyName = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.GetFriendlyName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetFriendlyName, &parms);
	return parms.return_value;
}

struct TArray<char> UDataAsset::GetCandidateObjectData(){

	static UObject* p_GetCandidateObjectData = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.GetCandidateObjectData");

	struct {
		struct TArray<char> return_value;
	} parms;


	ProcessEvent(p_GetCandidateObjectData, &parms);
	return parms.return_value;
}

struct FBox UDataAsset::GetBoundingBox(){

	static UObject* p_GetBoundingBox = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateObject.GetBoundingBox");

	struct {
		struct FBox return_value;
	} parms;


	ProcessEvent(p_GetBoundingBox, &parms);
	return parms.return_value;
}

struct UARGeoTrackingSupport* UObject::GetGeoTrackingSupport(){

	static UObject* p_GetGeoTrackingSupport = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingSupport");

	struct {
		struct UARGeoTrackingSupport* return_value;
	} parms;


	ProcessEvent(p_GetGeoTrackingSupport, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetGeoTrackingStateReason(){

	static UObject* p_GetGeoTrackingStateReason = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingStateReason");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetGeoTrackingStateReason, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetGeoTrackingState(){

	static UObject* p_GetGeoTrackingState = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingState");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetGeoTrackingState, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetGeoTrackingAccuracy(){

	static UObject* p_GetGeoTrackingAccuracy = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoTrackingSupport.GetGeoTrackingAccuracy");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetGeoTrackingAccuracy, &parms);
	return parms.return_value;
}

bool UObject::AddGeoAnchorAtLocationWithAltitude(float Longitude, float Latitude, float AltitudeMeters, struct FString OptionalAnchorName){

	static UObject* p_AddGeoAnchorAtLocationWithAltitude = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocationWithAltitude");

	struct {
		float Longitude;
		float Latitude;
		float AltitudeMeters;
		struct FString OptionalAnchorName;
		bool return_value;
	} parms;

	parms.Longitude = Longitude;
	parms.Latitude = Latitude;
	parms.AltitudeMeters = AltitudeMeters;
	parms.OptionalAnchorName = OptionalAnchorName;

	ProcessEvent(p_AddGeoAnchorAtLocationWithAltitude, &parms);
	return parms.return_value;
}

bool UObject::AddGeoAnchorAtLocation(float Longitude, float Latitude, struct FString OptionalAnchorName){

	static UObject* p_AddGeoAnchorAtLocation = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoTrackingSupport.AddGeoAnchorAtLocation");

	struct {
		float Longitude;
		float Latitude;
		struct FString OptionalAnchorName;
		bool return_value;
	} parms;

	parms.Longitude = Longitude;
	parms.Latitude = Latitude;
	parms.OptionalAnchorName = OptionalAnchorName;

	ProcessEvent(p_AddGeoAnchorAtLocation, &parms);
	return parms.return_value;
}

struct FVector UARTrackedGeometry::GetExtent(){

	static UObject* p_GetExtent = UObject::FindObject<UFunction>("Function AugmentedReality.AREnvironmentCaptureProbe.GetExtent");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetExtent, &parms);
	return parms.return_value;
}

struct UAREnvironmentCaptureProbeTexture* UARTrackedGeometry::GetEnvironmentCaptureTexture(){

	static UObject* p_GetEnvironmentCaptureTexture = UObject::FindObject<UFunction>("Function AugmentedReality.AREnvironmentCaptureProbe.GetEnvironmentCaptureTexture");

	struct {
		struct UAREnvironmentCaptureProbeTexture* return_value;
	} parms;


	ProcessEvent(p_GetEnvironmentCaptureTexture, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldResetTrackedObjects(){

	static UObject* p_ShouldResetTrackedObjects = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldResetTrackedObjects");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldResetTrackedObjects, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldResetCameraTracking(){

	static UObject* p_ShouldResetCameraTracking = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldResetCameraTracking");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldResetCameraTracking, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldRenderCameraOverlay(){

	static UObject* p_ShouldRenderCameraOverlay = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldRenderCameraOverlay");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldRenderCameraOverlay, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldEnableCameraTracking(){

	static UObject* p_ShouldEnableCameraTracking = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldEnableCameraTracking");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldEnableCameraTracking, &parms);
	return parms.return_value;
}

bool UDataAsset::ShouldEnableAutoFocus(){

	static UObject* p_ShouldEnableAutoFocus = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.ShouldEnableAutoFocus");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_ShouldEnableAutoFocus, &parms);
	return parms.return_value;
}

void UDataAsset::SetWorldMapData(struct TArray<char> WorldMapData){

	static UObject* p_SetWorldMapData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetWorldMapData");

	struct {
		struct TArray<char> WorldMapData;
	} parms;

	parms.WorldMapData = WorldMapData;

	ProcessEvent(p_SetWorldMapData, &parms);
}

void UDataAsset::SetSessionTrackingFeatureToEnable(uint8_t  InSessionTrackingFeature){

	static UObject* p_SetSessionTrackingFeatureToEnable = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetSessionTrackingFeatureToEnable");

	struct {
		uint8_t  InSessionTrackingFeature;
	} parms;

	parms.InSessionTrackingFeature = InSessionTrackingFeature;

	ProcessEvent(p_SetSessionTrackingFeatureToEnable, &parms);
}

void UDataAsset::SetSceneReconstructionMethod(uint8_t  InSceneReconstructionMethod){

	static UObject* p_SetSceneReconstructionMethod = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetSceneReconstructionMethod");

	struct {
		uint8_t  InSceneReconstructionMethod;
	} parms;

	parms.InSceneReconstructionMethod = InSceneReconstructionMethod;

	ProcessEvent(p_SetSceneReconstructionMethod, &parms);
}

void UDataAsset::SetResetTrackedObjects(bool bNewValue){

	static UObject* p_SetResetTrackedObjects = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetResetTrackedObjects");

	struct {
		bool bNewValue;
	} parms;

	parms.bNewValue = bNewValue;

	ProcessEvent(p_SetResetTrackedObjects, &parms);
}

void UDataAsset::SetResetCameraTracking(bool bNewValue){

	static UObject* p_SetResetCameraTracking = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetResetCameraTracking");

	struct {
		bool bNewValue;
	} parms;

	parms.bNewValue = bNewValue;

	ProcessEvent(p_SetResetCameraTracking, &parms);
}

void UDataAsset::SetFaceTrackingUpdate(uint8_t  InUpdate){

	static UObject* p_SetFaceTrackingUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetFaceTrackingUpdate");

	struct {
		uint8_t  InUpdate;
	} parms;

	parms.InUpdate = InUpdate;

	ProcessEvent(p_SetFaceTrackingUpdate, &parms);
}

void UDataAsset::SetFaceTrackingDirection(uint8_t  InDirection){

	static UObject* p_SetFaceTrackingDirection = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetFaceTrackingDirection");

	struct {
		uint8_t  InDirection;
	} parms;

	parms.InDirection = InDirection;

	ProcessEvent(p_SetFaceTrackingDirection, &parms);
}

void UDataAsset::SetEnableAutoFocus(bool bNewValue){

	static UObject* p_SetEnableAutoFocus = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetEnableAutoFocus");

	struct {
		bool bNewValue;
	} parms;

	parms.bNewValue = bNewValue;

	ProcessEvent(p_SetEnableAutoFocus, &parms);
}

void UDataAsset::SetDesiredVideoFormat(struct FARVideoFormat NewFormat){

	static UObject* p_SetDesiredVideoFormat = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetDesiredVideoFormat");

	struct {
		struct FARVideoFormat NewFormat;
	} parms;

	parms.NewFormat = NewFormat;

	ProcessEvent(p_SetDesiredVideoFormat, &parms);
}

void UDataAsset::SetCandidateObjectList(struct TArray<struct UARCandidateObject*>& InCandidateObjects){

	static UObject* p_SetCandidateObjectList = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.SetCandidateObjectList");

	struct {
		struct TArray<struct UARCandidateObject*>& InCandidateObjects;
	} parms;

	parms.InCandidateObjects = InCandidateObjects;

	ProcessEvent(p_SetCandidateObjectList, &parms);
}

struct TArray<char> UDataAsset::GetWorldMapData(){

	static UObject* p_GetWorldMapData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetWorldMapData");

	struct {
		struct TArray<char> return_value;
	} parms;


	ProcessEvent(p_GetWorldMapData, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetWorldAlignment(){

	static UObject* p_GetWorldAlignment = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetWorldAlignment");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetWorldAlignment, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetSessionType(){

	static UObject* p_GetSessionType = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetSessionType");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetSessionType, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetSceneReconstructionMethod(){

	static UObject* p_GetSceneReconstructionMethod = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetSceneReconstructionMethod");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetSceneReconstructionMethod, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetPlaneDetectionMode(){

	static UObject* p_GetPlaneDetectionMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetPlaneDetectionMode");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetPlaneDetectionMode, &parms);
	return parms.return_value;
}

int32_t UDataAsset::GetMaxNumSimultaneousImagesTracked(){

	static UObject* p_GetMaxNumSimultaneousImagesTracked = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetMaxNumSimultaneousImagesTracked");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetMaxNumSimultaneousImagesTracked, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetLightEstimationMode(){

	static UObject* p_GetLightEstimationMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetLightEstimationMode");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetLightEstimationMode, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetFrameSyncMode(){

	static UObject* p_GetFrameSyncMode = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetFrameSyncMode");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetFrameSyncMode, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetFaceTrackingUpdate(){

	static UObject* p_GetFaceTrackingUpdate = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetFaceTrackingUpdate");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetFaceTrackingUpdate, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetFaceTrackingDirection(){

	static UObject* p_GetFaceTrackingDirection = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetFaceTrackingDirection");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetFaceTrackingDirection, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetEnvironmentCaptureProbeType(){

	static UObject* p_GetEnvironmentCaptureProbeType = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetEnvironmentCaptureProbeType");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetEnvironmentCaptureProbeType, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetEnabledSessionTrackingFeature(){

	static UObject* p_GetEnabledSessionTrackingFeature = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetEnabledSessionTrackingFeature");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetEnabledSessionTrackingFeature, &parms);
	return parms.return_value;
}

struct FARVideoFormat UDataAsset::GetDesiredVideoFormat(){

	static UObject* p_GetDesiredVideoFormat = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetDesiredVideoFormat");

	struct {
		struct FARVideoFormat return_value;
	} parms;


	ProcessEvent(p_GetDesiredVideoFormat, &parms);
	return parms.return_value;
}

struct TArray<struct UARCandidateObject*> UDataAsset::GetCandidateObjectList(){

	static UObject* p_GetCandidateObjectList = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetCandidateObjectList");

	struct {
		struct TArray<struct UARCandidateObject*> return_value;
	} parms;


	ProcessEvent(p_GetCandidateObjectList, &parms);
	return parms.return_value;
}

struct TArray<struct UARCandidateImage*> UDataAsset::GetCandidateImageList(){

	static UObject* p_GetCandidateImageList = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.GetCandidateImageList");

	struct {
		struct TArray<struct UARCandidateImage*> return_value;
	} parms;


	ProcessEvent(p_GetCandidateImageList, &parms);
	return parms.return_value;
}

void UDataAsset::AddCandidateObject(struct UARCandidateObject* CandidateObject){

	static UObject* p_AddCandidateObject = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.AddCandidateObject");

	struct {
		struct UARCandidateObject* CandidateObject;
	} parms;

	parms.CandidateObject = CandidateObject;

	ProcessEvent(p_AddCandidateObject, &parms);
}

void UDataAsset::AddCandidateImage(struct UARCandidateImage* NewCandidateImage){

	static UObject* p_AddCandidateImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARSessionConfig.AddCandidateImage");

	struct {
		struct UARCandidateImage* NewCandidateImage;
	} parms;

	parms.NewCandidateImage = NewCandidateImage;

	ProcessEvent(p_AddCandidateImage, &parms);
}

void UARBaseAsyncTaskBlueprintProxy::GeoTrackingAvailabilityDelegate__DelegateSignature(bool bIsAvailable, struct FString Error){

	static UObject* p_GeoTrackingAvailabilityDelegate__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.GeoTrackingAvailabilityDelegate__DelegateSignature");

	struct {
		bool bIsAvailable;
		struct FString Error;
	} parms;

	parms.bIsAvailable = bIsAvailable;
	parms.Error = Error;

	ProcessEvent(p_GeoTrackingAvailabilityDelegate__DelegateSignature, &parms);
}

struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* UARBaseAsyncTaskBlueprintProxy::CheckGeoTrackingAvailabilityAtLocation(struct UObject* WorldContextObject, float Longitude, float Latitude){

	static UObject* p_CheckGeoTrackingAvailabilityAtLocation = UObject::FindObject<UFunction>("Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailabilityAtLocation");

	struct {
		struct UObject* WorldContextObject;
		float Longitude;
		float Latitude;
		struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.Longitude = Longitude;
	parms.Latitude = Latitude;

	ProcessEvent(p_CheckGeoTrackingAvailabilityAtLocation, &parms);
	return parms.return_value;
}

struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* UARBaseAsyncTaskBlueprintProxy::CheckGeoTrackingAvailability(struct UObject* WorldContextObject){

	static UObject* p_CheckGeoTrackingAvailability = UObject::FindObject<UFunction>("Function AugmentedReality.CheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy.CheckGeoTrackingAvailability");

	struct {
		struct UObject* WorldContextObject;
		struct UCheckGeoTrackingAvailabilityAsyncTaskBlueprintProxy* return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_CheckGeoTrackingAvailability, &parms);
	return parms.return_value;
}

float UDataAsset::GetPhysicalWidth(){

	static UObject* p_GetPhysicalWidth = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetPhysicalWidth");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPhysicalWidth, &parms);
	return parms.return_value;
}

float UDataAsset::GetPhysicalHeight(){

	static UObject* p_GetPhysicalHeight = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetPhysicalHeight");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPhysicalHeight, &parms);
	return parms.return_value;
}

uint8_t  UDataAsset::GetOrientation(){

	static UObject* p_GetOrientation = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetOrientation");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetOrientation, &parms);
	return parms.return_value;
}

struct FString UDataAsset::GetFriendlyName(){

	static UObject* p_GetFriendlyName = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetFriendlyName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetFriendlyName, &parms);
	return parms.return_value;
}

struct UTexture2D* UDataAsset::GetCandidateTexture(){

	static UObject* p_GetCandidateTexture = UObject::FindObject<UFunction>("Function AugmentedReality.ARCandidateImage.GetCandidateTexture");

	struct {
		struct UTexture2D* return_value;
	} parms;


	ProcessEvent(p_GetCandidateTexture, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetTrackingState(){

	static UObject* p_GetTrackingState = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetTrackingState");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingState, &parms);
	return parms.return_value;
}

struct UARTrackedGeometry* UObject::GetTrackedGeometry(){

	static UObject* p_GetTrackedGeometry = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetTrackedGeometry");

	struct {
		struct UARTrackedGeometry* return_value;
	} parms;


	ProcessEvent(p_GetTrackedGeometry, &parms);
	return parms.return_value;
}

struct USceneComponent* UObject::GetPinnedComponent(){

	static UObject* p_GetPinnedComponent = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetPinnedComponent");

	struct {
		struct USceneComponent* return_value;
	} parms;


	ProcessEvent(p_GetPinnedComponent, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToWorldTransform(){

	static UObject* p_GetLocalToWorldTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetLocalToWorldTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToWorldTransform, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToTrackingTransform(){

	static UObject* p_GetLocalToTrackingTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetLocalToTrackingTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToTrackingTransform, &parms);
	return parms.return_value;
}

struct FName UObject::GetDebugName(){

	static UObject* p_GetDebugName = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.GetDebugName");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetDebugName, &parms);
	return parms.return_value;
}

void UObject::DebugDraw(struct UWorld* World, struct FLinearColor& Color, float Scale, float PersistForSeconds){

	static UObject* p_DebugDraw = UObject::FindObject<UFunction>("Function AugmentedReality.ARPin.DebugDraw");

	struct {
		struct UWorld* World;
		struct FLinearColor& Color;
		float Scale;
		float PersistForSeconds;
	} parms;

	parms.World = World;
	parms.Color = Color;
	parms.Scale = Scale;
	parms.PersistForSeconds = PersistForSeconds;

	ProcessEvent(p_DebugDraw, &parms);
}

void AGameState::K2_OnARWorldMapIsReady(){

	static UObject* p_K2_OnARWorldMapIsReady = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldGameState.K2_OnARWorldMapIsReady");

	struct {
	} parms;


	ProcessEvent(p_K2_OnARWorldMapIsReady, &parms);
}

struct UARPlaneGeometry* UARTrackedGeometry::GetSubsumedBy(){

	static UObject* p_GetSubsumedBy = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetSubsumedBy");

	struct {
		struct UARPlaneGeometry* return_value;
	} parms;


	ProcessEvent(p_GetSubsumedBy, &parms);
	return parms.return_value;
}

uint8_t  UARTrackedGeometry::GetOrientation(){

	static UObject* p_GetOrientation = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetOrientation");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetOrientation, &parms);
	return parms.return_value;
}

struct FVector UARTrackedGeometry::GetExtent(){

	static UObject* p_GetExtent = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetExtent");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetExtent, &parms);
	return parms.return_value;
}

struct FVector UARTrackedGeometry::GetCenter(){

	static UObject* p_GetCenter = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetCenter");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetCenter, &parms);
	return parms.return_value;
}

struct TArray<struct FVector> UARTrackedGeometry::GetBoundaryPolygonInLocalSpace(){

	static UObject* p_GetBoundaryPolygonInLocalSpace = UObject::FindObject<UFunction>("Function AugmentedReality.ARPlaneGeometry.GetBoundaryPolygonInLocalSpace");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetBoundaryPolygonInLocalSpace, &parms);
	return parms.return_value;
}

void APlayerController::ServerMarkReadyForReceiving(){

	static UObject* p_ServerMarkReadyForReceiving = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ServerMarkReadyForReceiving");

	struct {
	} parms;


	ProcessEvent(p_ServerMarkReadyForReceiving, &parms);
}

void APlayerController::ClientUpdatePreviewImageData(int32_t Offset, struct TArray<char> Buffer){

	static UObject* p_ClientUpdatePreviewImageData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdatePreviewImageData");

	struct {
		int32_t Offset;
		struct TArray<char> Buffer;
	} parms;

	parms.Offset = Offset;
	parms.Buffer = Buffer;

	ProcessEvent(p_ClientUpdatePreviewImageData, &parms);
}

void APlayerController::ClientUpdateARWorldData(int32_t Offset, struct TArray<char> Buffer){

	static UObject* p_ClientUpdateARWorldData = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ClientUpdateARWorldData");

	struct {
		int32_t Offset;
		struct TArray<char> Buffer;
	} parms;

	parms.Offset = Offset;
	parms.Buffer = Buffer;

	ProcessEvent(p_ClientUpdateARWorldData, &parms);
}

void APlayerController::ClientInitSharedWorld(int32_t PreviewImageSize, int32_t ARWorldDataSize){

	static UObject* p_ClientInitSharedWorld = UObject::FindObject<UFunction>("Function AugmentedReality.ARSharedWorldPlayerController.ClientInitSharedWorld");

	struct {
		int32_t PreviewImageSize;
		int32_t ARWorldDataSize;
	} parms;

	parms.PreviewImageSize = PreviewImageSize;
	parms.ARWorldDataSize = ARWorldDataSize;

	ProcessEvent(p_ClientInitSharedWorld, &parms);
}

void ASkyLight::SetEnvironmentCaptureProbe(struct UAREnvironmentCaptureProbe* InCaptureProbe){

	static UObject* p_SetEnvironmentCaptureProbe = UObject::FindObject<UFunction>("Function AugmentedReality.ARSkyLight.SetEnvironmentCaptureProbe");

	struct {
		struct UAREnvironmentCaptureProbe* InCaptureProbe;
	} parms;

	parms.InCaptureProbe = InCaptureProbe;

	ProcessEvent(p_SetEnvironmentCaptureProbe, &parms);
}

bool UARTrackedGeometry::GetObjectClassificationAtLocation(struct FVector& InWorldLocation, uint8_t & OutClassification, struct FVector& OutClassificationLocation, float MaxLocationDiff){

	static UObject* p_GetObjectClassificationAtLocation = UObject::FindObject<UFunction>("Function AugmentedReality.ARMeshGeometry.GetObjectClassificationAtLocation");

	struct {
		struct FVector& InWorldLocation;
		uint8_t & OutClassification;
		struct FVector& OutClassificationLocation;
		float MaxLocationDiff;
		bool return_value;
	} parms;

	parms.InWorldLocation = InWorldLocation;
	parms.OutClassification = OutClassification;
	parms.OutClassificationLocation = OutClassificationLocation;
	parms.MaxLocationDiff = MaxLocationDiff;

	ProcessEvent(p_GetObjectClassificationAtLocation, &parms);
	return parms.return_value;
}

bool UObject::IsTracked(){

	static UObject* p_IsTracked = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.IsTracked");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsTracked, &parms);
	return parms.return_value;
}

bool UObject::HasSpatialMeshUsageFlag(uint8_t  InFlag){

	static UObject* p_HasSpatialMeshUsageFlag = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.HasSpatialMeshUsageFlag");

	struct {
		uint8_t  InFlag;
		bool return_value;
	} parms;

	parms.InFlag = InFlag;

	ProcessEvent(p_HasSpatialMeshUsageFlag, &parms);
	return parms.return_value;
}

struct UMRMeshComponent* UObject::GetUnderlyingMesh(){

	static UObject* p_GetUnderlyingMesh = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetUnderlyingMesh");

	struct {
		struct UMRMeshComponent* return_value;
	} parms;


	ProcessEvent(p_GetUnderlyingMesh, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetTrackingState(){

	static UObject* p_GetTrackingState = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetTrackingState");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetTrackingState, &parms);
	return parms.return_value;
}

uint8_t  UObject::GetObjectClassification(){

	static UObject* p_GetObjectClassification = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetObjectClassification");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetObjectClassification, &parms);
	return parms.return_value;
}

struct FString UObject::GetName(){

	static UObject* p_GetName = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetName");

	struct {
		struct FString return_value;
	} parms;


	ProcessEvent(p_GetName, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToWorldTransform(){

	static UObject* p_GetLocalToWorldTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLocalToWorldTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToWorldTransform, &parms);
	return parms.return_value;
}

struct FTransform UObject::GetLocalToTrackingTransform(){

	static UObject* p_GetLocalToTrackingTransform = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLocalToTrackingTransform");

	struct {
		struct FTransform return_value;
	} parms;


	ProcessEvent(p_GetLocalToTrackingTransform, &parms);
	return parms.return_value;
}

float UObject::GetLastUpdateTimestamp(){

	static UObject* p_GetLastUpdateTimestamp = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLastUpdateTimestamp");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetLastUpdateTimestamp, &parms);
	return parms.return_value;
}

int32_t UObject::GetLastUpdateFrameNumber(){

	static UObject* p_GetLastUpdateFrameNumber = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetLastUpdateFrameNumber");

	struct {
		int32_t return_value;
	} parms;


	ProcessEvent(p_GetLastUpdateFrameNumber, &parms);
	return parms.return_value;
}

struct FName UObject::GetDebugName(){

	static UObject* p_GetDebugName = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedGeometry.GetDebugName");

	struct {
		struct FName return_value;
	} parms;


	ProcessEvent(p_GetDebugName, &parms);
	return parms.return_value;
}

struct UARCandidateObject* UARTrackedGeometry::GetDetectedObject(){

	static UObject* p_GetDetectedObject = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedObject.GetDetectedObject");

	struct {
		struct UARCandidateObject* return_value;
	} parms;


	ProcessEvent(p_GetDetectedObject, &parms);
	return parms.return_value;
}

struct FVector2D UARTrackedGeometry::GetEstimateSize(){

	static UObject* p_GetEstimateSize = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedImage.GetEstimateSize");

	struct {
		struct FVector2D return_value;
	} parms;


	ProcessEvent(p_GetEstimateSize, &parms);
	return parms.return_value;
}

struct UARCandidateImage* UARTrackedGeometry::GetDetectedImage(){

	static UObject* p_GetDetectedImage = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedImage.GetDetectedImage");

	struct {
		struct UARCandidateImage* return_value;
	} parms;


	ProcessEvent(p_GetDetectedImage, &parms);
	return parms.return_value;
}

struct FARPose3D UARTrackedGeometry::GetTrackedPoseData(){

	static UObject* p_GetTrackedPoseData = UObject::FindObject<UFunction>("Function AugmentedReality.ARTrackedPose.GetTrackedPoseData");

	struct {
		struct FARPose3D return_value;
	} parms;


	ProcessEvent(p_GetTrackedPoseData, &parms);
	return parms.return_value;
}

float UARTrackedGeometry::GetLongitude(){

	static UObject* p_GetLongitude = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchor.GetLongitude");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetLongitude, &parms);
	return parms.return_value;
}

float UARTrackedGeometry::GetLatitude(){

	static UObject* p_GetLatitude = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchor.GetLatitude");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetLatitude, &parms);
	return parms.return_value;
}

uint8_t  UARTrackedGeometry::GetAltitudeSource(){

	static UObject* p_GetAltitudeSource = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchor.GetAltitudeSource");

	struct {
		uint8_t  return_value;
	} parms;


	ProcessEvent(p_GetAltitudeSource, &parms);
	return parms.return_value;
}

float UARTrackedGeometry::GetAltitudeMeters(){

	static UObject* p_GetAltitudeMeters = UObject::FindObject<UFunction>("Function AugmentedReality.ARGeoAnchor.GetAltitudeMeters");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAltitudeMeters, &parms);
	return parms.return_value;
}

