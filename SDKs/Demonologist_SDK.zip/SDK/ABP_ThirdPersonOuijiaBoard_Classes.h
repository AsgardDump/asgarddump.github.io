#pragma once 
#include <ABP_ThirdPersonOuijiaBoard_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonOuijiaBoard.ABP_ThirdPersonOuijiaBoard_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonOuijiaBoard_C : public UABP_ThirdPersonToolLayer_C
{

}; 



