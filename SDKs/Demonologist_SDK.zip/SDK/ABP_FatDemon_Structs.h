#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ABP_FatDemon.ABP_FatDemon_C.AnimBlueprintGeneratedConstantData
// Size: 0x138(Inherited: 0x138) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
