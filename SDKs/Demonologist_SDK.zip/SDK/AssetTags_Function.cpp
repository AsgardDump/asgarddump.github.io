#include "SDK.h" 
 
 
struct TArray<struct FName> UEngineSubsystem::K2_GetCollectionsContainingAsset(struct FSoftObjectPath& AssetPath){

	static UObject* p_K2_GetCollectionsContainingAsset = UObject::FindObject<UFunction>("Function AssetTags.AssetTagsSubsystem.K2_GetCollectionsContainingAsset");

	struct {
		struct FSoftObjectPath& AssetPath;
		struct TArray<struct FName> return_value;
	} parms;

	parms.AssetPath = AssetPath;

	ProcessEvent(p_K2_GetCollectionsContainingAsset, &parms);
	return parms.return_value;
}

struct TArray<struct FName> UEngineSubsystem::GetCollectionsContainingAssetPtr(struct UObject* AssetPtr){

	static UObject* p_GetCollectionsContainingAssetPtr = UObject::FindObject<UFunction>("Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetPtr");

	struct {
		struct UObject* AssetPtr;
		struct TArray<struct FName> return_value;
	} parms;

	parms.AssetPtr = AssetPtr;

	ProcessEvent(p_GetCollectionsContainingAssetPtr, &parms);
	return parms.return_value;
}

struct TArray<struct FName> UEngineSubsystem::GetCollectionsContainingAssetData(struct FAssetData& AssetData){

	static UObject* p_GetCollectionsContainingAssetData = UObject::FindObject<UFunction>("Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAssetData");

	struct {
		struct FAssetData& AssetData;
		struct TArray<struct FName> return_value;
	} parms;

	parms.AssetData = AssetData;

	ProcessEvent(p_GetCollectionsContainingAssetData, &parms);
	return parms.return_value;
}

struct TArray<struct FName> UEngineSubsystem::GetCollectionsContainingAsset(struct FName AssetPathName){

	static UObject* p_GetCollectionsContainingAsset = UObject::FindObject<UFunction>("Function AssetTags.AssetTagsSubsystem.GetCollectionsContainingAsset");

	struct {
		struct FName AssetPathName;
		struct TArray<struct FName> return_value;
	} parms;

	parms.AssetPathName = AssetPathName;

	ProcessEvent(p_GetCollectionsContainingAsset, &parms);
	return parms.return_value;
}

struct TArray<struct FName> UEngineSubsystem::GetCollections(){

	static UObject* p_GetCollections = UObject::FindObject<UFunction>("Function AssetTags.AssetTagsSubsystem.GetCollections");

	struct {
		struct TArray<struct FName> return_value;
	} parms;


	ProcessEvent(p_GetCollections, &parms);
	return parms.return_value;
}

struct TArray<struct FAssetData> UEngineSubsystem::GetAssetsInCollection(struct FName Name){

	static UObject* p_GetAssetsInCollection = UObject::FindObject<UFunction>("Function AssetTags.AssetTagsSubsystem.GetAssetsInCollection");

	struct {
		struct FName Name;
		struct TArray<struct FAssetData> return_value;
	} parms;

	parms.Name = Name;

	ProcessEvent(p_GetAssetsInCollection, &parms);
	return parms.return_value;
}

bool UEngineSubsystem::CollectionExists(struct FName Name){

	static UObject* p_CollectionExists = UObject::FindObject<UFunction>("Function AssetTags.AssetTagsSubsystem.CollectionExists");

	struct {
		struct FName Name;
		bool return_value;
	} parms;

	parms.Name = Name;

	ProcessEvent(p_CollectionExists, &parms);
	return parms.return_value;
}

