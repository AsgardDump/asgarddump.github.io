#pragma once 
#include <ABP_VoodooBaby_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_VoodooBaby.ABP_VoodooBaby_C
// Size: 0x5D0(Inherited: 0x5D0) 
struct UABP_VoodooBaby_C : public UABP_BaseTool_C
{

}; 



