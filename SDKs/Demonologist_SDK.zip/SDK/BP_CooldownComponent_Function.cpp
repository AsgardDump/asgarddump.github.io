#include "SDK.h" 
 
 
void UActorComponent::RegisterAndConsumeCooldownItem(struct FName CooldownUniqueIdentifier, double CooldownSeconds){

	static UObject* p_RegisterAndConsumeCooldownItem = UObject::FindObject<UFunction>("Function BP_CooldownComponent.BP_CooldownComponent_C.RegisterAndConsumeCooldownItem");

	struct {
		struct FName CooldownUniqueIdentifier;
		double CooldownSeconds;
	} parms;

	parms.CooldownUniqueIdentifier = CooldownUniqueIdentifier;
	parms.CooldownSeconds = CooldownSeconds;

	ProcessEvent(p_RegisterAndConsumeCooldownItem, &parms);
}

void UActorComponent::CanConsumeCooldownItem(struct FName& CooldownIItem, bool& ReturnNode){

	static UObject* p_CanConsumeCooldownItem = UObject::FindObject<UFunction>("Function BP_CooldownComponent.BP_CooldownComponent_C.CanConsumeCooldownItem");

	struct {
		struct FName& CooldownIItem;
		bool& ReturnNode;
	} parms;

	parms.CooldownIItem = CooldownIItem;
	parms.ReturnNode = ReturnNode;

	ProcessEvent(p_CanConsumeCooldownItem, &parms);
}

void UActorComponent::ConsumeCooldownItem(struct FName ConsumeCooldownItem){

	static UObject* p_ConsumeCooldownItem = UObject::FindObject<UFunction>("Function BP_CooldownComponent.BP_CooldownComponent_C.ConsumeCooldownItem");

	struct {
		struct FName ConsumeCooldownItem;
	} parms;

	parms.ConsumeCooldownItem = ConsumeCooldownItem;

	ProcessEvent(p_ConsumeCooldownItem, &parms);
}

void UActorComponent::RegisterCooldownItem(struct FName CooldownUniqueIdentifier, double CooldownSeconds){

	static UObject* p_RegisterCooldownItem = UObject::FindObject<UFunction>("Function BP_CooldownComponent.BP_CooldownComponent_C.RegisterCooldownItem");

	struct {
		struct FName CooldownUniqueIdentifier;
		double CooldownSeconds;
	} parms;

	parms.CooldownUniqueIdentifier = CooldownUniqueIdentifier;
	parms.CooldownSeconds = CooldownSeconds;

	ProcessEvent(p_RegisterCooldownItem, &parms);
}

void UActorComponent::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function BP_CooldownComponent.BP_CooldownComponent_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void UActorComponent::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_CooldownComponent.BP_CooldownComponent_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void UActorComponent::ExecuteUbergraph_BP_CooldownComponent(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_CooldownComponent = UObject::FindObject<UFunction>("Function BP_CooldownComponent.BP_CooldownComponent_C.ExecuteUbergraph_BP_CooldownComponent");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_CooldownComponent, &parms);
}

