#pragma once 
#include <BP_CameraFocusComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CameraFocusComponent.BP_CameraFocusComponent_C
// Size: 0xB8(Inherited: 0xA0) 
struct UBP_CameraFocusComponent_C : public UActorComponent
{
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool ShowMouseCursorWhenFocused : 1;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool IsFocused : 1;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool HideOtherPlayersWhenFocused : 1;  // 0xA2(0x1)
	char pad_163_1 : 7;  // 0xA3(0x1)
	bool EnableWidgetInteractionWhenFocused : 1;  // 0xA3(0x1)
	char pad_164[4];  // 0xA4(0x4)
	struct FMulticastInlineDelegate OnFocusUpdated;  // 0xA8(0x10)

	void OnTargetPlayerDied(struct ABP_Shivers_InGamePlayerState_C* PlayerState); // Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.OnTargetPlayerDied
	void UpdatePlayerVisibilities(bool IsFocused); // Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdatePlayerVisibilities
	bool GetIsPlayerDead(); // Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.GetIsPlayerDead
	void UpdateWorldVisibility(); // Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateWorldVisibility
	void UpdateShowMouseCursor(); // Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateShowMouseCursor
	void UpdateCameraFocus(bool FocusCamera); // Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateCameraFocus
	void OnFocusUpdated__DelegateSignature(bool IsFocused); // Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.OnFocusUpdated__DelegateSignature
}; 



