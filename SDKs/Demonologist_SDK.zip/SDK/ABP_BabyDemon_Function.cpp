#include "SDK.h" 
 
 
void UABP_BaseEntity_C::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_BabyDemon.ABP_BabyDemon_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UABP_BaseEntity_C::ExecuteUbergraph_ABP_BabyDemon(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_BabyDemon = UObject::FindObject<UFunction>("Function ABP_BabyDemon.ABP_BabyDemon_C.ExecuteUbergraph_ABP_BabyDemon");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_BabyDemon, &parms);
}

