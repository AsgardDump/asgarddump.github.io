#pragma once 
#include <ABP_ThirdPersonEasel_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonEasel.ABP_ThirdPersonEasel_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonEasel_C : public UABP_ThirdPersonToolLayer_C
{

}; 



