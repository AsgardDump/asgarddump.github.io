#pragma once 
#include <BP_AiGhostEventComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AiGhostEventComponent.BP_AiGhostEventComponent_C
// Size: 0x208(Inherited: 0x1A8) 
struct UBP_AiGhostEventComponent_C : public UBP_AiEventInteractionComponent_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x1A8(0x8)
	struct TMap<struct FName, double> SanityDrainByIdentifier;  // 0x1B0(0x50)
	struct AActor* SanityAreaToAffect;  // 0x200(0x8)

	bool CanInstigatorInteract(struct AActor* Instigator); // Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.CanInstigatorInteract
	double GetBaseEntityDrain(); // Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.GetBaseEntityDrain
	void ReceiveBeginPlay(); // Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.ReceiveBeginPlay
	void OnSequencePlayedCallback(struct FS_SequenceQueryInformation SequenceQuery); // Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.OnSequencePlayedCallback
	void ExecuteUbergraph_BP_AiGhostEventComponent(int32_t EntryPoint); // Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.ExecuteUbergraph_BP_AiGhostEventComponent
}; 



