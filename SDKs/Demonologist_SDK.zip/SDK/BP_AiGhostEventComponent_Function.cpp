#include "SDK.h" 
 
 
bool UBP_AiEventInteractionComponent_C::CanInstigatorInteract(struct AActor* Instigator){

	static UObject* p_CanInstigatorInteract = UObject::FindObject<UFunction>("Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.CanInstigatorInteract");

	struct {
		struct AActor* Instigator;
		bool return_value;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_CanInstigatorInteract, &parms);
	return parms.return_value;
}

double UBP_AiEventInteractionComponent_C::GetBaseEntityDrain(){

	static UObject* p_GetBaseEntityDrain = UObject::FindObject<UFunction>("Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.GetBaseEntityDrain");

	struct {
		double return_value;
	} parms;


	ProcessEvent(p_GetBaseEntityDrain, &parms);
	return parms.return_value;
}

void UBP_AiEventInteractionComponent_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void UBP_AiEventInteractionComponent_C::OnSequencePlayedCallback(struct FS_SequenceQueryInformation SequenceQuery){

	static UObject* p_OnSequencePlayedCallback = UObject::FindObject<UFunction>("Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.OnSequencePlayedCallback");

	struct {
		struct FS_SequenceQueryInformation SequenceQuery;
	} parms;

	parms.SequenceQuery = SequenceQuery;

	ProcessEvent(p_OnSequencePlayedCallback, &parms);
}

void UBP_AiEventInteractionComponent_C::ExecuteUbergraph_BP_AiGhostEventComponent(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AiGhostEventComponent = UObject::FindObject<UFunction>("Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.ExecuteUbergraph_BP_AiGhostEventComponent");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AiGhostEventComponent, &parms);
}

