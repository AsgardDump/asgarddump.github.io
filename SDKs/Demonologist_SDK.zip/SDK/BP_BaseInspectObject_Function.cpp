#include "SDK.h" 
 
 
void ABP_PickableObject_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BaseInspectObject.BP_BaseInspectObject_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_PickableObject_C::ExecuteUbergraph_BP_BaseInspectObject(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BaseInspectObject = UObject::FindObject<UFunction>("Function BP_BaseInspectObject.BP_BaseInspectObject_C.ExecuteUbergraph_BP_BaseInspectObject");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BaseInspectObject, &parms);
}

