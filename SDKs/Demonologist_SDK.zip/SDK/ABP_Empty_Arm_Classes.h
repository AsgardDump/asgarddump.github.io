#pragma once 
#include <ABP_Empty_Arm_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Empty_Arm.ABP_Empty_Arm_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_Empty_Arm_C : public UABP_ToolLayerArms_C
{

}; 



