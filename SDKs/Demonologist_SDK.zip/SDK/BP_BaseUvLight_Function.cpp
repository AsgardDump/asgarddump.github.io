#include "SDK.h" 
 
 
void ABP_Tool_C::GetLightInformation(struct FVector TargetLocation, struct FVector& Location, double& Strenght){

	static UObject* p_GetLightInformation = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.GetLightInformation");

	struct {
		struct FVector TargetLocation;
		struct FVector& Location;
		double& Strenght;
	} parms;

	parms.TargetLocation = TargetLocation;
	parms.Location = Location;
	parms.Strenght = Strenght;

	ProcessEvent(p_GetLightInformation, &parms);
}

bool ABP_Tool_C::CanMalfunction(){

	static UObject* p_CanMalfunction = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.CanMalfunction");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanMalfunction, &parms);
	return parms.return_value;
}

double ABP_Tool_C::GetTargetIntensity(){

	static UObject* p_GetTargetIntensity = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.GetTargetIntensity");

	struct {
		double return_value;
	} parms;


	ProcessEvent(p_GetTargetIntensity, &parms);
	return parms.return_value;
}

void ABP_Tool_C::UvMalFunction__FinishedFunc(){

	static UObject* p_UvMalFunction__FinishedFunc = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.UvMalFunction__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_UvMalFunction__FinishedFunc, &parms);
}

void ABP_Tool_C::UvMalFunction__UpdateFunc(){

	static UObject* p_UvMalFunction__UpdateFunc = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.UvMalFunction__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_UvMalFunction__UpdateFunc, &parms);
}

void ABP_Tool_C::OnNotifyEnd_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName){

	static UObject* p_OnNotifyEnd_2AD36304431AADA067A1FAB270266A7B = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.OnNotifyEnd_2AD36304431AADA067A1FAB270266A7B");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyEnd_2AD36304431AADA067A1FAB270266A7B, &parms);
}

void ABP_Tool_C::OnNotifyBegin_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName){

	static UObject* p_OnNotifyBegin_2AD36304431AADA067A1FAB270266A7B = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.OnNotifyBegin_2AD36304431AADA067A1FAB270266A7B");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyBegin_2AD36304431AADA067A1FAB270266A7B, &parms);
}

void ABP_Tool_C::OnInterrupted_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName){

	static UObject* p_OnInterrupted_2AD36304431AADA067A1FAB270266A7B = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.OnInterrupted_2AD36304431AADA067A1FAB270266A7B");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnInterrupted_2AD36304431AADA067A1FAB270266A7B, &parms);
}

void ABP_Tool_C::OnBlendOut_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName){

	static UObject* p_OnBlendOut_2AD36304431AADA067A1FAB270266A7B = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.OnBlendOut_2AD36304431AADA067A1FAB270266A7B");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnBlendOut_2AD36304431AADA067A1FAB270266A7B, &parms);
}

void ABP_Tool_C::OnCompleted_2AD36304431AADA067A1FAB270266A7B(struct FName NotifyName){

	static UObject* p_OnCompleted_2AD36304431AADA067A1FAB270266A7B = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.OnCompleted_2AD36304431AADA067A1FAB270266A7B");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnCompleted_2AD36304431AADA067A1FAB270266A7B, &parms);
}

void ABP_Tool_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_Tool_C::UpdateUvLightIntensity(){

	static UObject* p_UpdateUvLightIntensity = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.UpdateUvLightIntensity");

	struct {
	} parms;


	ProcessEvent(p_UpdateUvLightIntensity, &parms);
}

void ABP_Tool_C::OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit){

	static UObject* p_OnObjectInstigatorUpdatedCallback = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.OnObjectInstigatorUpdatedCallback");

	struct {
		struct APawn* OldInstigator;
		bool IsFirstInit;
	} parms;

	parms.OldInstigator = OldInstigator;
	parms.IsFirstInit = IsFirstInit;

	ProcessEvent(p_OnObjectInstigatorUpdatedCallback, &parms);
}

void ABP_Tool_C::PlayEquipMontage(){

	static UObject* p_PlayEquipMontage = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.PlayEquipMontage");

	struct {
	} parms;


	ProcessEvent(p_PlayEquipMontage, &parms);
}

void ABP_Tool_C::EndMalfunction(struct FName Identifier){

	static UObject* p_EndMalfunction = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.EndMalfunction");

	struct {
		struct FName Identifier;
	} parms;

	parms.Identifier = Identifier;

	ProcessEvent(p_EndMalfunction, &parms);
}

void ABP_Tool_C::EndUvLightMalFunction(){

	static UObject* p_EndUvLightMalFunction = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.EndUvLightMalFunction");

	struct {
	} parms;


	ProcessEvent(p_EndUvLightMalFunction, &parms);
}

void ABP_Tool_C::StartUvLightMalFunction(){

	static UObject* p_StartUvLightMalFunction = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.StartUvLightMalFunction");

	struct {
	} parms;


	ProcessEvent(p_StartUvLightMalFunction, &parms);
}

void ABP_Tool_C::StartMalfunction(struct FName Identifier){

	static UObject* p_StartMalfunction = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.StartMalfunction");

	struct {
		struct FName Identifier;
	} parms;

	parms.Identifier = Identifier;

	ProcessEvent(p_StartMalfunction, &parms);
}

void ABP_Tool_C::ExecuteUbergraph_BP_BaseUvLight(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BaseUvLight = UObject::FindObject<UFunction>("Function BP_BaseUvLight.BP_BaseUvLight_C.ExecuteUbergraph_BP_BaseUvLight");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BaseUvLight, &parms);
}

