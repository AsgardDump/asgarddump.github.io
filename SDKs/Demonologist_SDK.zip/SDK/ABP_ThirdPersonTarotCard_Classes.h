#pragma once 
#include <ABP_ThirdPersonTarotCard_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonTarotCard.ABP_ThirdPersonTarotCard_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonTarotCard_C : public UABP_ThirdPersonToolLayer_C
{

}; 



