#pragma once 
#include <BP_CandleBunch_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CandleBunch.BP_CandleBunch_C
// Size: 0x2E0(Inherited: 0x290) 
struct ABP_CandleBunch_C : public AActor
{
	struct UMaterialBillboardComponent* MaterialBillboard2;  // 0x290(0x8)
	struct UMaterialBillboardComponent* MaterialBillboard1;  // 0x298(0x8)
	struct UMaterialBillboardComponent* MaterialBillboard;  // 0x2A0(0x8)
	struct UPointLightComponent* PointLight;  // 0x2A8(0x8)
	struct UStaticMeshComponent* SM_Candle;  // 0x2B0(0x8)
	char pad_696_1 : 7;  // 0x2B8(0x1)
	bool Light : 1;  // 0x2B8(0x1)
	char pad_697[7];  // 0x2B9(0x7)
	double Light Intensity;  // 0x2C0(0x8)
	struct FColor Light Color;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)
	struct TArray<struct UMaterialInterface*> Override Materials;  // 0x2D0(0x10)

	void OverrideMeshMaterials(struct UStaticMeshComponent* Mesh, struct TArray<struct UMaterialInterface*>& Materials, struct TArray<struct UMaterialInterface*>& InitMaterials); // Function BP_CandleBunch.BP_CandleBunch_C.OverrideMeshMaterials
	void MaterialProperties(struct UStaticMeshComponent* Mesh, double Light Intensity, struct FColor Light Color, bool isLight); // Function BP_CandleBunch.BP_CandleBunch_C.MaterialProperties
	void LightProperties(struct ULightComponent* Light Component, double Light Intensity, struct FColor Light Color); // Function BP_CandleBunch.BP_CandleBunch_C.LightProperties
}; 



