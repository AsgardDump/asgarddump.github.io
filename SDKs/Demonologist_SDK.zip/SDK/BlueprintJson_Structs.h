#pragma once 
#include "SDK.h" 
 
 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_StringToJsonObject
// Size: 0x20(Inherited: 0x0) 
struct FConv_StringToJsonObject
{
	struct FString JsonString;  // 0x0(0x10)
	struct FBlueprintJsonObject ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToString
// Size: 0x20(Inherited: 0x0) 
struct FConv_JsonObjectToString
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToPrettyString
// Size: 0x20(Inherited: 0x0) 
struct FConv_JsonObjectToPrettyString
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// ScriptStruct BlueprintJson.BlueprintJsonObject
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintJsonObject
{
	char pad_0[16];  // 0x0(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeField
// Size: 0x40(Inherited: 0x0) 
struct FJsonMakeField
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString FieldName;  // 0x10(0x10)
	struct FBlueprintJsonValue Value;  // 0x20(0x10)
	struct FBlueprintJsonObject ReturnValue;  // 0x30(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToJsonValue
// Size: 0x30(Inherited: 0x0) 
struct FConv_JsonObjectToJsonValue
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString FieldName;  // 0x10(0x10)
	struct FBlueprintJsonValue ReturnValue;  // 0x20(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonHasField
// Size: 0x28(Inherited: 0x0) 
struct FJsonHasField
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString FieldName;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct BlueprintJson.BlueprintJsonValue
// Size: 0x10(Inherited: 0x0) 
struct FBlueprintJsonValue
{
	char pad_0[16];  // 0x0(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToArray
// Size: 0x20(Inherited: 0x0) 
struct FConv_JsonValueToArray
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	struct TArray<struct FBlueprintJsonValue> ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToBool
// Size: 0x18(Inherited: 0x0) 
struct FConv_JsonValueToBool
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToFloat
// Size: 0x18(Inherited: 0x0) 
struct FConv_JsonValueToFloat
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToInteger
// Size: 0x18(Inherited: 0x0) 
struct FConv_JsonValueToInteger
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	int32_t ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToObject
// Size: 0x20(Inherited: 0x0) 
struct FConv_JsonValueToObject
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	struct FBlueprintJsonObject ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToString
// Size: 0x20(Inherited: 0x0) 
struct FConv_JsonValueToString
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.EquaEqual_JsonValue
// Size: 0x28(Inherited: 0x0) 
struct FEquaEqual_JsonValue
{
	struct FBlueprintJsonValue A;  // 0x0(0x10)
	struct FBlueprintJsonValue B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonRemoveField
// Size: 0x30(Inherited: 0x0) 
struct FJsonRemoveField
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString FieldName;  // 0x10(0x10)
	struct FBlueprintJsonObject ReturnValue;  // 0x20(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeFloat
// Size: 0x18(Inherited: 0x0) 
struct FJsonMakeFloat
{
	float Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FBlueprintJsonValue ReturnValue;  // 0x8(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonHasTypedField
// Size: 0x28(Inherited: 0x0) 
struct FJsonHasTypedField
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString FieldName;  // 0x10(0x10)
	uint8_t  Type;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonIsNull
// Size: 0x18(Inherited: 0x0) 
struct FJsonIsNull
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMake
// Size: 0x10(Inherited: 0x0) 
struct FJsonMake
{
	struct FBlueprintJsonObject ReturnValue;  // 0x0(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeArray
// Size: 0x20(Inherited: 0x0) 
struct FJsonMakeArray
{
	struct TArray<struct FBlueprintJsonValue> Value;  // 0x0(0x10)
	struct FBlueprintJsonValue ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeBool
// Size: 0x18(Inherited: 0x0) 
struct FJsonMakeBool
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FBlueprintJsonValue ReturnValue;  // 0x8(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeInt
// Size: 0x18(Inherited: 0x0) 
struct FJsonMakeInt
{
	int32_t Value;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FBlueprintJsonValue ReturnValue;  // 0x8(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeNull
// Size: 0x10(Inherited: 0x0) 
struct FJsonMakeNull
{
	struct FBlueprintJsonValue ReturnValue;  // 0x0(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeObject
// Size: 0x20(Inherited: 0x0) 
struct FJsonMakeObject
{
	struct FBlueprintJsonObject Value;  // 0x0(0x10)
	struct FBlueprintJsonValue ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonMakeString
// Size: 0x20(Inherited: 0x0) 
struct FJsonMakeString
{
	struct FString Value;  // 0x0(0x10)
	struct FBlueprintJsonValue ReturnValue;  // 0x10(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonSetField
// Size: 0x40(Inherited: 0x0) 
struct FJsonSetField
{
	struct FBlueprintJsonObject JsonObject;  // 0x0(0x10)
	struct FString FieldName;  // 0x10(0x10)
	struct FBlueprintJsonValue JsonValue;  // 0x20(0x10)
	struct FBlueprintJsonObject ReturnValue;  // 0x30(0x10)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.JsonType
// Size: 0x18(Inherited: 0x0) 
struct FJsonType
{
	struct FBlueprintJsonValue JsonValue;  // 0x0(0x10)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function BlueprintJson.BlueprintJsonLibrary.NotEqual_JsonValue
// Size: 0x28(Inherited: 0x0) 
struct FNotEqual_JsonValue
{
	struct FBlueprintJsonValue A;  // 0x0(0x10)
	struct FBlueprintJsonValue B;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
