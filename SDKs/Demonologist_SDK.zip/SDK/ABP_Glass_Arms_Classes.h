#pragma once 
#include <ABP_Glass_Arms_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Glass_Arms.ABP_Glass_Arms_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_Glass_Arms_C : public UABP_ToolLayerArms_C
{

}; 



