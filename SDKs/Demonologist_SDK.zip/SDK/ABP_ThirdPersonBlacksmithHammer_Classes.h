#pragma once 
#include <ABP_ThirdPersonBlacksmithHammer_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonBlacksmithHammer.ABP_ThirdPersonBlacksmithHammer_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonBlacksmithHammer_C : public UABP_ThirdPersonToolLayer_C
{

}; 



