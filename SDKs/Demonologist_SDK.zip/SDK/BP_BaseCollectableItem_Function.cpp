#include "SDK.h" 
 
 
void ABP_BaseInteraction_C::PublishEvent(struct APawn* Instigator){

	static UObject* p_PublishEvent = UObject::FindObject<UFunction>("Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.PublishEvent");

	struct {
		struct APawn* Instigator;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_PublishEvent, &parms);
}

bool ABP_BaseInteraction_C::GetIsLookInteractionActive(){

	static UObject* p_GetIsLookInteractionActive = UObject::FindObject<UFunction>("Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.GetIsLookInteractionActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsLookInteractionActive, &parms);
	return parms.return_value;
}

bool ABP_BaseInteraction_C::GetVisualActiveCondition(){

	static UObject* p_GetVisualActiveCondition = UObject::FindObject<UFunction>("Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.GetVisualActiveCondition");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetVisualActiveCondition, &parms);
	return parms.return_value;
}

bool ABP_BaseInteraction_C::CanPlayerInteract(struct APawn* PawnReference){

	static UObject* p_CanPlayerInteract = UObject::FindObject<UFunction>("Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.CanPlayerInteract");

	struct {
		struct APawn* PawnReference;
		bool return_value;
	} parms;

	parms.PawnReference = PawnReference;

	ProcessEvent(p_CanPlayerInteract, &parms);
	return parms.return_value;
}

void ABP_BaseInteraction_C::BndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted){

	static UObject* p_BndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.BndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature");

	struct {
		struct APawn* CharacterPawn;
		struct FName Identifier;
		bool IsServerExucuted;
	} parms;

	parms.CharacterPawn = CharacterPawn;
	parms.Identifier = Identifier;
	parms.IsServerExucuted = IsServerExucuted;

	ProcessEvent(p_BndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature, &parms);
}

void ABP_BaseInteraction_C::HandleInteractObjectDispatcher(struct APawn* Instigator, bool IsServerExecuted){

	static UObject* p_HandleInteractObjectDispatcher = UObject::FindObject<UFunction>("Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.HandleInteractObjectDispatcher");

	struct {
		struct APawn* Instigator;
		bool IsServerExecuted;
	} parms;

	parms.Instigator = Instigator;
	parms.IsServerExecuted = IsServerExecuted;

	ProcessEvent(p_HandleInteractObjectDispatcher, &parms);
}

void ABP_BaseInteraction_C::ExecuteUbergraph_BP_BaseCollectableItem(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BaseCollectableItem = UObject::FindObject<UFunction>("Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.ExecuteUbergraph_BP_BaseCollectableItem");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BaseCollectableItem, &parms);
}

