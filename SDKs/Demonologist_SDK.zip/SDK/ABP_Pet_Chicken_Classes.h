#pragma once 
#include <ABP_Pet_Chicken_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Pet_Chicken.ABP_Pet_Chicken_C
// Size: 0x738(Inherited: 0x350) 
struct UABP_Pet_Chicken_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x388(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x3D8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x420(0x20)
	struct FAnimNode_RandomPlayer AnimGraphNode_RandomPlayer;  // 0x440(0x78)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x4B8(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4D8(0xC8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x5A0(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x6A8(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x6D0(0x48)
	struct FVector K2Node_PropertyAccess;  // 0x718(0x18)
	double Speed;  // 0x730(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Pet_Chicken.ABP_Pet_Chicken_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_Pet_Chicken.ABP_Pet_Chicken_C.BlueprintThreadSafeUpdateAnimation
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Chicken_AnimGraphNode_TransitionResult_529C157048F1F2E48863B6947C76F92C(); // Function ABP_Pet_Chicken.ABP_Pet_Chicken_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Chicken_AnimGraphNode_TransitionResult_529C157048F1F2E48863B6947C76F92C
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Chicken_AnimGraphNode_TransitionResult_26605AC14EF00D7E589EA59200D267DF(); // Function ABP_Pet_Chicken.ABP_Pet_Chicken_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Chicken_AnimGraphNode_TransitionResult_26605AC14EF00D7E589EA59200D267DF
	void ExecuteUbergraph_ABP_Pet_Chicken(int32_t EntryPoint); // Function ABP_Pet_Chicken.ABP_Pet_Chicken_C.ExecuteUbergraph_ABP_Pet_Chicken
}; 



