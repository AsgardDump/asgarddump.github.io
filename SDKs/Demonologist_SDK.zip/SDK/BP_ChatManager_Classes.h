#pragma once 
#include <BP_ChatManager_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ChatManager.BP_ChatManager_C
// Size: 0x2B8(Inherited: 0x290) 
struct ABP_ChatManager_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x298(0x8)
	int32_t MaxChatLength;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct FMulticastInlineDelegate BroadcastMessageDispatchers;  // 0x2A8(0x10)

	void BroadcastMessage(struct FString Sender, struct FString Message); // Function BP_ChatManager.BP_ChatManager_C.BroadcastMessage
	void SendMessage(struct FString Message); // Function BP_ChatManager.BP_ChatManager_C.SendMessage
	bool CanSendMessage(struct FString Message); // Function BP_ChatManager.BP_ChatManager_C.CanSendMessage
	void SendMessage OnMulticast(struct FString Sender, struct FString Message); // Function BP_ChatManager.BP_ChatManager_C.SendMessage OnMulticast
	void ExecuteUbergraph_BP_ChatManager(int32_t EntryPoint); // Function BP_ChatManager.BP_ChatManager_C.ExecuteUbergraph_BP_ChatManager
	void BroadcastMessageDispatchers__DelegateSignature(struct FString Sender, struct FString Message); // Function BP_ChatManager.BP_ChatManager_C.BroadcastMessageDispatchers__DelegateSignature
}; 



