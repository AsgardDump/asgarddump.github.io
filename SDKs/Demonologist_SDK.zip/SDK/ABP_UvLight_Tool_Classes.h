#pragma once 
#include <ABP_UvLight_Tool_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_UvLight_Tool.ABP_UvLight_Tool_C
// Size: 0x5C8(Inherited: 0x350) 
struct UABP_UvLight_Tool_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x388(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3D8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x420(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x440(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x488(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4A8(0xC8)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x570(0x48)
	double Speed;  // 0x5B8(0x8)
	struct ABP_BaseUvLight_C* UvLightTool;  // 0x5C0(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_B709192246FFE8DFF94E0CA448C6BDA0(); // Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_B709192246FFE8DFF94E0CA448C6BDA0
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_2ED9A1C84B68BE336A30CE9140F9F673(); // Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_2ED9A1C84B68BE336A30CE9140F9F673
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.BlueprintUpdateAnimation
	void BlueprintBeginPlay(); // Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.BlueprintBeginPlay
	void ExecuteUbergraph_ABP_UvLight_Tool(int32_t EntryPoint); // Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.ExecuteUbergraph_ABP_UvLight_Tool
}; 



