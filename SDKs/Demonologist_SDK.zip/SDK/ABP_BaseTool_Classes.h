#pragma once 
#include <ABP_BaseTool_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_BaseTool.ABP_BaseTool_C
// Size: 0x5D0(Inherited: 0x350) 
struct UABP_BaseTool_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x388(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3D8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x420(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x440(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x488(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4A8(0xC8)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x570(0x48)
	struct UAnimSequenceBase* IdleAnimation;  // 0x5B8(0x8)
	float Speed;  // 0x5C0(0x4)
	char pad_1476[4];  // 0x5C4(0x4)
	struct UAnimSequenceBase* WalkingAnimation;  // 0x5C8(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_BaseTool.ABP_BaseTool_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F2C82B2B473A84FEAA6A2B969441B175(); // Function ABP_BaseTool.ABP_BaseTool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F2C82B2B473A84FEAA6A2B969441B175
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F6501E7040F8A068BDBF94B1FBACB5DF(); // Function ABP_BaseTool.ABP_BaseTool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F6501E7040F8A068BDBF94B1FBACB5DF
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_BaseTool.ABP_BaseTool_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_BaseTool(int32_t EntryPoint); // Function ABP_BaseTool.ABP_BaseTool_C.ExecuteUbergraph_ABP_BaseTool
}; 



