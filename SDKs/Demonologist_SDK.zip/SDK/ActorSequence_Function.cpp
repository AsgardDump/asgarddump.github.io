#include "SDK.h" 
 
 
void UActorComponent::StopSequence(){

	static UObject* p_StopSequence = UObject::FindObject<UFunction>("Function ActorSequence.ActorSequenceComponent.StopSequence");

	struct {
	} parms;


	ProcessEvent(p_StopSequence, &parms);
}

void UActorComponent::PlaySequence(){

	static UObject* p_PlaySequence = UObject::FindObject<UFunction>("Function ActorSequence.ActorSequenceComponent.PlaySequence");

	struct {
	} parms;


	ProcessEvent(p_PlaySequence, &parms);
}

void UActorComponent::PauseSequence(){

	static UObject* p_PauseSequence = UObject::FindObject<UFunction>("Function ActorSequence.ActorSequenceComponent.PauseSequence");

	struct {
	} parms;


	ProcessEvent(p_PauseSequence, &parms);
}

