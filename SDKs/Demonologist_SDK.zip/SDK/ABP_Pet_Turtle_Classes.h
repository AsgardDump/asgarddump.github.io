#pragma once 
#include <ABP_Pet_Turtle_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Pet_Turtle.ABP_Pet_Turtle_C
// Size: 0x708(Inherited: 0x350) 
struct UABP_Pet_Turtle_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x388(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3D8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x420(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x440(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x488(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4A8(0xC8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x570(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x678(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x6A0(0x48)
	struct FVector K2Node_PropertyAccess;  // 0x6E8(0x18)
	double Speed;  // 0x700(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.BlueprintThreadSafeUpdateAnimation
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_19EB74FD4228A7D159612A8AC1F277FD(); // Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_19EB74FD4228A7D159612A8AC1F277FD
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_8CF53E3F49C47F4BF12B4EA838873E9B(); // Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_8CF53E3F49C47F4BF12B4EA838873E9B
	void ExecuteUbergraph_ABP_Pet_Turtle(int32_t EntryPoint); // Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.ExecuteUbergraph_ABP_Pet_Turtle
}; 



