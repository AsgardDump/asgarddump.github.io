#pragma once 
#include <ABP_SanityPills_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SanityPills.ABP_SanityPills_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_SanityPills_C : public UABP_ToolLayerArms_C
{

}; 



