#pragma once 
#include <BP_ApperalMesh_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ApperalMesh.BP_ApperalMesh_C
// Size: 0xF90(Inherited: 0xF80) 
struct UBP_ApperalMesh_C : public UBP_ShiversCustomizationMesh_C
{
	struct FName AssignedRowName;  // 0xF80(0x8)
	struct FName Skin;  // 0xF88(0x8)

}; 



