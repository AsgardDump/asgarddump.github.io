#pragma once 
#include <ABP_ThirdPersonSaltGun_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonSaltGun.ABP_ThirdPersonSaltGun_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonSaltGun_C : public UABP_ThirdPersonToolLayer_C
{

}; 



