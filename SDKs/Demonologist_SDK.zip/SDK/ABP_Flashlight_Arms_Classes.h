#pragma once 
#include <ABP_Flashlight_Arms_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Flashlight_Arms.ABP_Flashlight_Arms_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_Flashlight_Arms_C : public UABP_ToolLayerArms_C
{

}; 



