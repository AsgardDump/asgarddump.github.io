#include "SDK.h" 
 
 
void UAnimLayerInterface::WalkingState(struct FPoseLink& WalkingState){

	static UObject* p_WalkingState = UObject::FindObject<UFunction>("Function ALI_ToolAnimLayers.ALI_ToolAnimLayers_C.WalkingState");

	struct {
		struct FPoseLink& WalkingState;
	} parms;

	parms.WalkingState = WalkingState;

	ProcessEvent(p_WalkingState, &parms);
}

void UAnimLayerInterface::IdleState(struct FPoseLink& IdleState){

	static UObject* p_IdleState = UObject::FindObject<UFunction>("Function ALI_ToolAnimLayers.ALI_ToolAnimLayers_C.IdleState");

	struct {
		struct FPoseLink& IdleState;
	} parms;

	parms.IdleState = IdleState;

	ProcessEvent(p_IdleState, &parms);
}

