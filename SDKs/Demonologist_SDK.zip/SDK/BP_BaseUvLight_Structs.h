#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseUvLight.BP_BaseUvLight_C.CanMalfunction
// Size: 0x1(Inherited: 0x1) 
struct FCanMalfunction : public FCanMalfunction
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.EndMalfunction
// Size: 0x8(Inherited: 0x8) 
struct FEndMalfunction : public FEndMalfunction
{
	struct FName Identifier;  // 0x0(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.ExecuteUbergraph_BP_BaseUvLight
// Size: 0xE8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseUvLight
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x14(0x8)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x1C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x24(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x34(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x3C(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x4C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x54(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x64(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x6C(0x10)
	struct FName Temp_name_Variable;  // 0x7C(0x8)
	char pad_132[4];  // 0x84(0x4)
	struct APawn* K2Node_Event_OldInstigator;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_Event_IsFirstInit : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	double CallFunc_GetTargetIntensity_ReturnValue;  // 0x98(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	struct FName K2Node_Event_Identifier_2;  // 0xAC(0x8)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0xB4(0x1)
	char pad_181[3];  // 0xB5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0xB8(0x10)
	float CallFunc_GetTimelineLength_ReturnValue;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xD0(0x8)
	struct FName K2Node_Event_Identifier;  // 0xD8(0x8)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_SwitchName_CmpSuccess_2 : 1;  // 0xE0(0x1)
	char pad_225[3];  // 0xE1(0x3)
	float CallFunc_SetIntensity_NewIntensity_ImplicitCast;  // 0xE4(0x4)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.GetLightInformation
// Size: 0x88(Inherited: 0x0) 
struct FGetLightInformation
{
	struct FVector TargetLocation;  // 0x0(0x18)
	struct FVector Location;  // 0x18(0x18)
	double Strenght;  // 0x30(0x8)
	double CallFunc_MakeLiteralDouble_ReturnValue;  // 0x38(0x8)
	double CallFunc_Conv_FloatToDouble_ReturnValue;  // 0x40(0x8)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x48(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x50(0x18)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Conv_BoolToInt_ReturnValue;  // 0x6C(0x4)
	double CallFunc_Conv_IntToDouble_ReturnValue;  // 0x70(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x78(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0x80(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.OnCompleted_2AD36304431AADA067A1FAB270266A7B
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_2AD36304431AADA067A1FAB270266A7B
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.GetTargetIntensity
// Size: 0x40(Inherited: 0x0) 
struct FGetTargetIntensity
{
	double ReturnValue;  // 0x0(0x8)
	double CallFunc_MakeLiteralDouble_ReturnValue;  // 0x8(0x8)
	double CallFunc_Conv_FloatToDouble_ReturnValue;  // 0x10(0x8)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[3];  // 0x21(0x3)
	int32_t CallFunc_Conv_BoolToInt_ReturnValue;  // 0x24(0x4)
	double CallFunc_Conv_IntToDouble_ReturnValue;  // 0x28(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x30(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0x38(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.OnBlendOut_2AD36304431AADA067A1FAB270266A7B
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_2AD36304431AADA067A1FAB270266A7B
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.OnInterrupted_2AD36304431AADA067A1FAB270266A7B
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_2AD36304431AADA067A1FAB270266A7B
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.OnNotifyBegin_2AD36304431AADA067A1FAB270266A7B
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_2AD36304431AADA067A1FAB270266A7B
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.OnNotifyEnd_2AD36304431AADA067A1FAB270266A7B
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_2AD36304431AADA067A1FAB270266A7B
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.OnObjectInstigatorUpdatedCallback
// Size: 0x9(Inherited: 0x9) 
struct FOnObjectInstigatorUpdatedCallback : public FOnObjectInstigatorUpdatedCallback
{
	struct APawn* OldInstigator;  // 0x0(0x8)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IsFirstInit : 1;  // 0x8(0x1)

}; 
// Function BP_BaseUvLight.BP_BaseUvLight_C.StartMalfunction
// Size: 0x8(Inherited: 0x8) 
struct FStartMalfunction : public FStartMalfunction
{
	struct FName Identifier;  // 0x0(0x8)

}; 
