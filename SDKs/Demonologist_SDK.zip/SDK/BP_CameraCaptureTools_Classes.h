#pragma once 
#include <BP_CameraCaptureTools_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CameraCaptureTools.BP_CameraCaptureTools_C
// Size: 0x46D(Inherited: 0x429) 
struct ABP_CameraCaptureTools_C : public ABP_Tool_C
{
	char pad_1065[7];  // 0x429(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct UBP_CameraCaptureComponent_C* BP_CameraCaptureComponent;  // 0x438(0x8)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D;  // 0x440(0x8)
	struct UMaterialInstanceDynamic* CameraScreenMaterial;  // 0x448(0x8)
	struct FName CameraScreenMaterialToApply;  // 0x450(0x8)
	struct ABP_ControlCamera_C* ControlCameraReference;  // 0x458(0x8)
	int32_t RenderTargetWidth;  // 0x460(0x4)
	char pad_1124_1 : 7;  // 0x464(0x1)
	bool ConnectedToCameraControlComputer : 1;  // 0x464(0x1)
	char pad_1125[3];  // 0x465(0x3)
	int32_t RenderTargetHeight;  // 0x468(0x4)
	char ETextureRenderTargetFormat RenderFormat;  // 0x46C(0x1)

	bool CanDisableCaptureWhenOutsideOfRenderArea(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.CanDisableCaptureWhenOutsideOfRenderArea
	bool IsCurrentlyWatching(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.IsCurrentlyWatching
	struct ABP_ControlCamera_C* GetControlCameraReference(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.GetControlCameraReference
	bool IsOverlappingControlArea(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.IsOverlappingControlArea
	void InitializeCameraCaptureTool(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.InitializeCameraCaptureTool
	void ReceiveBeginPlay(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.ReceiveBeginPlay
	void CheckCameraStatus(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.CheckCameraStatus
	void ReceiveDestroyed(); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.ReceiveDestroyed
	void OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.OnObjectInstigatorUpdatedCallback
	void ExecuteUbergraph_BP_CameraCaptureTools(int32_t EntryPoint); // Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.ExecuteUbergraph_BP_CameraCaptureTools
}; 



