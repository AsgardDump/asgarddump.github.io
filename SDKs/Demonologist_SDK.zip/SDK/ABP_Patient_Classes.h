#pragma once 
#include <ABP_Patient_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Patient.ABP_Patient_C
// Size: 0x6EC(Inherited: 0x6EC) 
struct UABP_Patient_C : public UABP_BaseEntity_C
{

}; 



