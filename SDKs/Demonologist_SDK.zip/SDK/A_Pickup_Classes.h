#pragma once 
#include <A_Pickup_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Pickup.A_Pickup_C
// Size: 0x2E0(Inherited: 0x290) 
struct AA_Pickup_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct USphereComponent* Trace Sphere;  // 0x298(0x8)
	struct UWidgetComponent* Interact Widget;  // 0x2A0(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x2A8(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x2B0(0x8)
	float Timeline_0_Alpha_05907E494EBA193429048CBED8BA396B;  // 0x2B8(0x4)
	char ETimelineDirection Timeline_0__Direction_05907E494EBA193429048CBED8BA396B;  // 0x2BC(0x1)
	char pad_701[3];  // 0x2BD(0x3)
	struct UTimelineComponent* Timeline_1;  // 0x2C0(0x8)
	char Pickup_Type Pickup Type;  // 0x2C8(0x1)
	char pad_713[3];  // 0x2C9(0x3)
	int32_t Resource Current;  // 0x2CC(0x4)
	struct FDataTableRowHandle Tool Data;  // 0x2D0(0x10)

	void Interactable Check(struct APawn* Pawn, bool& Interactable); // Function A_Pickup.A_Pickup_C.Interactable Check
	void Get Interact Location(struct AActor* Actor, struct FVector& Location); // Function A_Pickup.A_Pickup_C.Get Interact Location
	void Get Focal Point(struct AActor* Pawn, struct FVector& Focal Point); // Function A_Pickup.A_Pickup_C.Get Focal Point
	void Pickup Event(struct ACharacter* Character); // Function A_Pickup.A_Pickup_C.Pickup Event
	void UserConstructionScript(); // Function A_Pickup.A_Pickup_C.UserConstructionScript
	void Timeline_0__FinishedFunc(); // Function A_Pickup.A_Pickup_C.Timeline_0__FinishedFunc
	void Timeline_0__UpdateFunc(); // Function A_Pickup.A_Pickup_C.Timeline_0__UpdateFunc
	void Interact(struct ACharacter* Character); // Function A_Pickup.A_Pickup_C.Interact
	void In Range(bool Value); // Function A_Pickup.A_Pickup_C.In Range
	void Spin(); // Function A_Pickup.A_Pickup_C.Spin
	void ExecuteUbergraph_A_Pickup(int32_t EntryPoint); // Function A_Pickup.A_Pickup_C.ExecuteUbergraph_A_Pickup
}; 



