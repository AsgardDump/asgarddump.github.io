#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseTool.BP_BaseTool_C.BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature
// Size: 0x101(Inherited: 0x0) 
struct FBndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature
{
	struct APlayerController* ControllerReference;  // 0x0(0x8)
	struct APawn* PawnReference;  // 0x8(0x8)
	double TraceInterval;  // 0x10(0x8)
	struct FHitResult Details;  // 0x18(0xE8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool IsLocallyControlled : 1;  // 0x100(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.GetIsLookInteractionActive
// Size: 0x1(Inherited: 0x0) 
struct FGetIsLookInteractionActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FBndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature
{
	struct APawn* CharacterPawn;  // 0x0(0x8)
	struct FName Identifier;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsServerExucuted : 1;  // 0x10(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.ExecuteUbergraph_BP_BaseTool
// Size: 0x2A1(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseTool
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* K2Node_CustomEvent_OldInstigator;  // 0x8(0x8)
	struct AActor* K2Node_CustomEvent_DestroyedActor;  // 0x10(0x8)
	struct APawn* K2Node_CustomEvent_CharacterReference;  // 0x18(0x8)
	struct FName K2Node_CustomEvent_Identity;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_CustomEvent_IsExecutedByServer : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct APlayerController* K2Node_ComponentBoundEvent_ControllerReference_2;  // 0x30(0x8)
	struct APawn* K2Node_ComponentBoundEvent_PawnReference_2;  // 0x38(0x8)
	double K2Node_ComponentBoundEvent_TraceInterval_2;  // 0x40(0x8)
	struct FHitResult K2Node_ComponentBoundEvent_Details_2;  // 0x48(0xE8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool K2Node_ComponentBoundEvent_IsLocallyControlled_2 : 1;  // 0x130(0x1)
	char pad_305[7];  // 0x131(0x7)
	struct APlayerController* K2Node_ComponentBoundEvent_ControllerReference;  // 0x138(0x8)
	struct APawn* K2Node_ComponentBoundEvent_PawnReference;  // 0x140(0x8)
	double K2Node_ComponentBoundEvent_TraceInterval;  // 0x148(0x8)
	struct FHitResult K2Node_ComponentBoundEvent_Details;  // 0x150(0xE8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool K2Node_ComponentBoundEvent_IsLocallyControlled : 1;  // 0x238(0x1)
	char pad_569[7];  // 0x239(0x7)
	struct APawn* K2Node_ComponentBoundEvent_CharacterPawn;  // 0x240(0x8)
	struct FName K2Node_ComponentBoundEvent_Identifier;  // 0x248(0x8)
	char pad_592_1 : 7;  // 0x250(0x1)
	bool K2Node_ComponentBoundEvent_IsServerExucuted : 1;  // 0x250(0x1)
	char pad_593[7];  // 0x251(0x7)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x258(0x8)
	struct TScriptInterface<IBPI_PlayerCharacter_C> K2Node_DynamicCast_AsBPI_Player_Character;  // 0x260(0x10)
	char pad_624_1 : 7;  // 0x270(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x270(0x1)
	char pad_625_1 : 7;  // 0x271(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x271(0x1)
	char pad_626[6];  // 0x272(0x6)
	struct UBP_PlayerInteractionComponent_C* CallFunc_GetInteractionComponent_ReturnValue;  // 0x278(0x8)
	char pad_640_1 : 7;  // 0x280(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x280(0x1)
	char pad_641[3];  // 0x281(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x284(0x10)
	char pad_660[4];  // 0x294(0x4)
	struct APawn* K2Node_CustomEvent_OldInstigator_2;  // 0x298(0x8)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool K2Node_CustomEvent_IsFirstInit : 1;  // 0x2A0(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.GetDegreePoints
// Size: 0x10(Inherited: 0x0) 
struct FGetDegreePoints
{
	struct TArray<struct FVector> ReturnValue;  // 0x0(0x10)

}; 
// Function BP_BaseTool.BP_BaseTool_C.GetAttachmentDetails
// Size: 0x83(Inherited: 0x0) 
struct FGetAttachmentDetails
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsManualAttachment : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FTransform RelativeTransform;  // 0x10(0x60)
	struct USceneComponent* AttachmentComponent;  // 0x70(0x8)
	struct FName SocketName;  // 0x78(0x8)
	char LocationRule;  // 0x80(0x1)
	char RotationRule;  // 0x81(0x1)
	char ScaleRule;  // 0x82(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.GetObjectInstigator
// Size: 0x8(Inherited: 0x0) 
struct FGetObjectInstigator
{
	struct APawn* ReturnValue;  // 0x0(0x8)

}; 
// Function BP_BaseTool.BP_BaseTool_C.GetVisualActiveCondition
// Size: 0x1(Inherited: 0x0) 
struct FGetVisualActiveCondition
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.InteractObject
// Size: 0x11(Inherited: 0x0) 
struct FInteractObject
{
	struct APawn* CharacterReference;  // 0x0(0x8)
	struct FName Identity;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsExecutedByServer : 1;  // 0x10(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.OnLooked
// Size: 0x101(Inherited: 0x0) 
struct FOnLooked
{
	struct APlayerController* ControllerReference;  // 0x0(0x8)
	struct APawn* PawnReference;  // 0x8(0x8)
	double TraceInterval;  // 0x10(0x8)
	struct FHitResult Details;  // 0x18(0xE8)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool IsLocallyControlled : 1;  // 0x100(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorChanged
// Size: 0x8(Inherited: 0x0) 
struct FOnObjectInstigatorChanged
{
	struct APawn* OldInstigator;  // 0x0(0x8)

}; 
// Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorUpdated__DelegateSignature
// Size: 0x9(Inherited: 0x0) 
struct FOnObjectInstigatorUpdated__DelegateSignature
{
	struct APawn* OldInstigator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsFirstInit : 1;  // 0x8(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorUpdatedCallback
// Size: 0x9(Inherited: 0x0) 
struct FOnObjectInstigatorUpdatedCallback
{
	struct APawn* OldInstigator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsFirstInit : 1;  // 0x8(0x1)

}; 
// Function BP_BaseTool.BP_BaseTool_C.SafeDestroyBaseTool
// Size: 0x8(Inherited: 0x0) 
struct FSafeDestroyBaseTool
{
	struct AActor* DestroyedActor;  // 0x0(0x8)

}; 
// Function BP_BaseTool.BP_BaseTool_C.SetToolRuntimeInformation
// Size: 0x70(Inherited: 0x0) 
struct FSetToolRuntimeInformation
{
	struct FS_ToolRuntimeInformation ToolRuntimeInformation;  // 0x0(0x70)

}; 
