#pragma once 
#include <BP_ChatLogObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ChatLogObject.BP_ChatLogObject_C
// Size: 0x48(Inherited: 0x28) 
struct UBP_ChatLogObject_C : public UObject
{
	struct FChatLogEntryStruct ChatData;  // 0x28(0x20)

}; 



