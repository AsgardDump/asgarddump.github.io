#pragma once 
#include <A_Tool_Rifle_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Tool_Rifle.A_Tool_Rifle_C
// Size: 0x430(Inherited: 0x3E8) 
struct AA_Tool_Rifle_C : public AA_Tool_Base_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3E8(0x8)
	double Spray Control;  // 0x3F0(0x8)
	double Spray Recoil Scale;  // 0x3F8(0x8)
	double Firing Time;  // 0x400(0x8)
	struct USoundBase* Firing Audio;  // 0x408(0x8)
	struct UMaterialInterface* Impact Decal Material;  // 0x410(0x8)
	struct UParticleSystem* Impact FX;  // 0x418(0x8)
	struct UParticleSystem* Muzzle Flash FX;  // 0x420(0x8)
	struct FTimerHandle Zoom Timer;  // 0x428(0x8)

	void Trace Vectors(struct FVector& Start, struct FVector& End); // Function A_Tool_Rifle.A_Tool_Rifle_C.Trace Vectors
	void Reset Attack(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Reset Attack
	void Crosshair Widget(struct UCC_Rifle_Crosshair_C*& Widget); // Function A_Tool_Rifle.A_Tool_Rifle_C.Crosshair Widget
	void Recoil(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Recoil
	void OnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName); // Function A_Tool_Rifle.A_Tool_Rifle_C.OnNotifyEnd_21C0D91744C87DA0D66E4C88DD70F42A
	void OnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName); // Function A_Tool_Rifle.A_Tool_Rifle_C.OnNotifyBegin_21C0D91744C87DA0D66E4C88DD70F42A
	void OnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName); // Function A_Tool_Rifle.A_Tool_Rifle_C.OnInterrupted_21C0D91744C87DA0D66E4C88DD70F42A
	void OnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName); // Function A_Tool_Rifle.A_Tool_Rifle_C.OnBlendOut_21C0D91744C87DA0D66E4C88DD70F42A
	void OnCompleted_21C0D91744C87DA0D66E4C88DD70F42A(struct FName NotifyName); // Function A_Tool_Rifle.A_Tool_Rifle_C.OnCompleted_21C0D91744C87DA0D66E4C88DD70F42A
	void Fire Rifle(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Fire Rifle
	void Fire Rifle Timer(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Fire Rifle Timer
	void Stop Rifle Timer(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Stop Rifle Timer
	void ReceiveBeginPlay(); // Function A_Tool_Rifle.A_Tool_Rifle_C.ReceiveBeginPlay
	void Rifle Line Trace(struct FVector Start, struct FVector End); // Function A_Tool_Rifle.A_Tool_Rifle_C.Rifle Line Trace
	void MC Muzzle Flash(); // Function A_Tool_Rifle.A_Tool_Rifle_C.MC Muzzle Flash
	void Reset Aim(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Reset Aim
	void Aim Reset Timer(double Time); // Function A_Tool_Rifle.A_Tool_Rifle_C.Aim Reset Timer
	void Clear Aim Timer(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Clear Aim Timer
	void SRV Fire(); // Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Fire
	void MC Fire(); // Function A_Tool_Rifle.A_Tool_Rifle_C.MC Fire
	void Set Aiming(bool Aiming); // Function A_Tool_Rifle.A_Tool_Rifle_C.Set Aiming
	void SRV Set Aiming(bool Aiming); // Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Set Aiming
	void Muzzle Flash(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Muzzle Flash
	void SRV Rifle Line Trace(struct FVector Start, struct FVector End); // Function A_Tool_Rifle.A_Tool_Rifle_C.SRV Rifle Line Trace
	void Secondary Fire(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Secondary Fire
	void Secondary Fire Release(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Secondary Fire Release
	void Main Fire(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Main Fire
	void Main Fire Release(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Main Fire Release
	void Rifle Timer Reset(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Rifle Timer Reset
	void Set Crosshair Size(double Size); // Function A_Tool_Rifle.A_Tool_Rifle_C.Set Crosshair Size
	void Attack Combo(int32_t Count); // Function A_Tool_Rifle.A_Tool_Rifle_C.Attack Combo
	void Out Of Ammo Sound(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Out Of Ammo Sound
	void Impact Effects(struct FVector Location, struct FVector& Normal, struct UPhysicalMaterial* Phys Mat, struct AActor* Actor); // Function A_Tool_Rifle.A_Tool_Rifle_C.Impact Effects
	void Update Ammo(); // Function A_Tool_Rifle.A_Tool_Rifle_C.Update Ammo
	void ExecuteUbergraph_A_Tool_Rifle(int32_t EntryPoint); // Function A_Tool_Rifle.A_Tool_Rifle_C.ExecuteUbergraph_A_Tool_Rifle
}; 



