#pragma once 
#include <BP_Ball_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Ball.BP_Ball_C
// Size: 0x2A8(Inherited: 0x290) 
struct ABP_Ball_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct UStaticMeshComponent* StaticMesh;  // 0x298(0x8)
	struct UAudioComponent* LastSpawnedHitSound;  // 0x2A0(0x8)

	void ReceiveTick(float DeltaSeconds); // Function BP_Ball.BP_Ball_C.ReceiveTick
	void ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_Ball.BP_Ball_C.ReceiveHit
	void ExecuteUbergraph_BP_Ball(int32_t EntryPoint); // Function BP_Ball.BP_Ball_C.ExecuteUbergraph_BP_Ball
}; 



