#pragma once 
#include "SDK.h" 
 
 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.CanInstigatorInteract
// Size: 0x76(Inherited: 0x0) 
struct FCanInstigatorInteract
{
	struct AActor* Instigator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	double CallFunc_RandomFloatInRange_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_GreaterEqual_DoubleDouble_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1A(0x1)
	char pad_27[5];  // 0x1B(0x5)
	double CallFunc_GetLastInteractedTime_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct TScriptInterface<IBPI_AiInteractionOwner_C> K2Node_DynamicCast_AsBPI_Ai_Interaction_Owner;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_2 : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_GetInteractionCondition_ReturnValue : 1;  // 0x52(0x1)
	char pad_83_1 : 7;  // 0x53(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x53(0x1)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_BooleanOR_ReturnValue_3 : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	double CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	double CallFunc_Subtract_DoubleDouble_ReturnValue;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_GreaterEqual_DoubleDouble_ReturnValue_2 : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x71(0x1)
	char pad_114_1 : 7;  // 0x72(0x1)
	bool CallFunc_BooleanOR_ReturnValue_4 : 1;  // 0x72(0x1)
	char pad_115_1 : 7;  // 0x73(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x73(0x1)
	char pad_116_1 : 7;  // 0x74(0x1)
	bool CallFunc_BooleanAND_ReturnValue_4 : 1;  // 0x74(0x1)
	char pad_117_1 : 7;  // 0x75(0x1)
	bool CallFunc_BooleanAND_ReturnValue_5 : 1;  // 0x75(0x1)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.GetLastInteractedTime
// Size: 0x48(Inherited: 0x0) 
struct FGetLastInteractedTime
{
	double ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x10(0x8)
	struct TScriptInterface<IBPI_GlobalParameterOwner_C> K2Node_DynamicCast_AsBPI_Global_Parameter_Owner;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString CallFunc_GetGlobalParameter_ReturnValue;  // 0x30(0x10)
	double CallFunc_Conv_StringToDouble_ReturnValue;  // 0x40(0x8)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.ExecuteUbergraph_BP_AiInteractionComponent
// Size: 0x14A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AiInteractionComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TScriptInterface<IBPI_NewEntity_C> K2Node_DynamicCast_AsBPI_New_Entity;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_CanInstigatorInteract_ReturnValue : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct UPrimitiveComponent* K2Node_CustomEvent_OverlappedComponent;  // 0x20(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor;  // 0x28(0x8)
	struct UPrimitiveComponent* K2Node_CustomEvent_OtherComp;  // 0x30(0x8)
	int32_t K2Node_CustomEvent_OtherBodyIndex;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool K2Node_CustomEvent_bFromSweep : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)
	struct FHitResult K2Node_CustomEvent_SweepResult;  // 0x40(0xE8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x128(0x8)
	struct FS_AiInteractionDetails K2Node_MakeStruct_S_AiInteractionDetails;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_RequestInteraction_Successful : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct AActor* K2Node_CustomEvent_Instigator;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool K2Node_CustomEvent_UseCustomInteractionMethod : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x149(0x1)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.InitializeAiInteractionComponent
// Size: 0xF4(Inherited: 0x0) 
struct FInitializeAiInteractionComponent
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	struct TArray<struct USceneComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x18(0x10)
	struct USceneComponent* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_NotEqual_NameName_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0x38(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x4C(0x8)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x54(0x1)
	char pad_85_1 : 7;  // 0x55(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x55(0x1)
	char pad_86[2];  // 0x56(0x2)
	struct UShapeComponent* CallFunc_GetInteractionComponentByName_ReturnValue;  // 0x58(0x8)
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // 0x60(0x60)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue_2 : 1;  // 0xC0(0x1)
	char pad_193[3];  // 0xC1(0x3)
	struct FName Temp_name_Variable;  // 0xC4(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0xCC(0x10)
	char pad_220[4];  // 0xDC(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0xE0(0x8)
	struct UBoxComponent* CallFunc_AddComponentByClass_ReturnValue;  // 0xE8(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xF0(0x4)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.GetInteractionComponentByName
// Size: 0x61(Inherited: 0x0) 
struct FGetInteractionComponentByName
{
	struct UShapeComponent* ReturnValue;  // 0x0(0x8)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct TArray<struct UShapeComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x20(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct UShapeComponent* CallFunc_Array_Get_Item;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString CallFunc_GetObjectName_ReturnValue;  // 0x48(0x10)
	struct FName CallFunc_Conv_StringToName_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x60(0x1)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.RequestAiInteraction
// Size: 0x9(Inherited: 0x0) 
struct FRequestAiInteraction
{
	struct AActor* Instigator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool UseCustomInteractionMethod : 1;  // 0x8(0x1)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.OnInteractionCollisionOverlapped
// Size: 0x108(Inherited: 0x0) 
struct FOnInteractionCollisionOverlapped
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0xE8)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.OnInteractionRequested__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnInteractionRequested__DelegateSignature
{
	struct AActor* Instigator;  // 0x0(0x8)

}; 
// Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.SetParametersWhenInteracted
// Size: 0x40(Inherited: 0x0) 
struct FSetParametersWhenInteracted
{
	double CallFunc_GetGameTimeInSeconds_ReturnValue;  // 0x0(0x8)
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // 0x8(0x8)
	struct FString CallFunc_Conv_DoubleToString_ReturnValue;  // 0x10(0x10)
	struct TScriptInterface<IBPI_GlobalParameterOwner_C> K2Node_DynamicCast_AsBPI_Global_Parameter_Owner;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_EqualEqual_NameName_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	double CallFunc_GetGameTimeInSeconds_ReturnValue_2;  // 0x38(0x8)

}; 
