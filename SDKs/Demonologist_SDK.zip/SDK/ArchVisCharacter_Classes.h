#pragma once 
#include <ArchVisCharacter_Structs.h>
 
 
 
// Class ArchVisCharacter.ArchVisCharacter
// Size: 0x680(Inherited: 0x620) 
struct AArchVisCharacter : public ACharacter
{
	struct FString LookUpAxisName;  // 0x618(0x10)
	struct FString LookUpAtRateAxisName;  // 0x628(0x10)
	struct FString TurnAxisName;  // 0x638(0x10)
	struct FString TurnAtRateAxisName;  // 0x648(0x10)
	struct FString MoveForwardAxisName;  // 0x658(0x10)
	struct FString MoveRightAxisName;  // 0x668(0x10)
	float MouseSensitivityScale_Pitch;  // 0x678(0x4)
	float MouseSensitivityScale_Yaw;  // 0x67C(0x4)

}; 



// Class ArchVisCharacter.ArchVisCharMovementComponent
// Size: 0xF90(Inherited: 0xF00) 
struct UArchVisCharMovementComponent : public UCharacterMovementComponent
{
	struct FRotator RotationalAcceleration;  // 0xEF8(0x18)
	struct FRotator RotationalDeceleration;  // 0xF10(0x18)
	struct FRotator MaxRotationalVelocity;  // 0xF28(0x18)
	float MinPitch;  // 0xF40(0x4)
	float MaxPitch;  // 0xF44(0x4)
	float WalkingFriction;  // 0xF48(0x4)
	float WalkingSpeed;  // 0xF4C(0x4)
	float WalkingAcceleration;  // 0xF50(0x4)
	char pad_3932[52];  // 0xF5C(0x34)

}; 



