#pragma once 
#include <BP_BansheeNew_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BansheeNew.BP_BansheeNew_C
// Size: 0xA98(Inherited: 0xA90) 
struct ABP_BansheeNew_C : public ABP_Entity_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA90(0x8)

	bool GetCanPerformGhostAbility(); // Function BP_BansheeNew.BP_BansheeNew_C.GetCanPerformGhostAbility
	struct USoundBase* GetSpiritBoxResponeCue(struct ABP_SpiritBox_C* SpiritBoxReference); // Function BP_BansheeNew.BP_BansheeNew_C.GetSpiritBoxResponeCue
	double GetBansheeDistanceBasedSpeedMultiplier(double Distance); // Function BP_BansheeNew.BP_BansheeNew_C.GetBansheeDistanceBasedSpeedMultiplier
	double GetHuntSpeed(); // Function BP_BansheeNew.BP_BansheeNew_C.GetHuntSpeed
	struct TArray<struct AActor*> GetAllCatchablePlayers(); // Function BP_BansheeNew.BP_BansheeNew_C.GetAllCatchablePlayers
	void OnPerceptionUpdatedCallback(struct TArray<struct AActor*>& UpdatedActors); // Function BP_BansheeNew.BP_BansheeNew_C.OnPerceptionUpdatedCallback
	void ExecuteUbergraph_BP_BansheeNew(int32_t EntryPoint); // Function BP_BansheeNew.BP_BansheeNew_C.ExecuteUbergraph_BP_BansheeNew
}; 



