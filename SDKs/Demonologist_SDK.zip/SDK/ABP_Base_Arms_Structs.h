#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Base_Arms.ABP_Base_Arms_C.SetIsAiming
// Size: 0x1(Inherited: 0x0) 
struct FSetIsAiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsAiming : 1;  // 0x0(0x1)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.BlueprintThreadSafeUpdateAnimation
// Size: 0x11(Inherited: 0x4) 
struct FBlueprintThreadSafeUpdateAnimation : public FBlueprintThreadSafeUpdateAnimation
{
	float DeltaTime;  // 0x0(0x4)
	double CallFunc_VSize_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.IdleState
// Size: 0x10(Inherited: 0x0) 
struct FIdleState
{
	struct FPoseLink IdleState;  // 0x0(0x10)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.ExecuteUbergraph_ABP_Base_Arms
// Size: 0x71(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Base_Arms
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x8(0x8)
	double CallFunc_SafeDivide_ReturnValue;  // 0x10(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x28(0x18)
	ABP_Tool_C* CallFunc_GetCurrentEquippedClass_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_EqualEqual_ClassClass_ReturnValue_2 : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_BooleanOR_ReturnValue : 1;  // 0x4A(0x1)
	char pad_75_1 : 7;  // 0x4B(0x1)
	bool K2Node_Event_IsAiming : 1;  // 0x4B(0x1)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_BooleanOR_ReturnValue_2 : 1;  // 0x4C(0x1)
	char pad_77_1 : 7;  // 0x4D(0x1)
	bool K2Node_Event_IsSprintins : 1;  // 0x4D(0x1)
	char pad_78[2];  // 0x4E(0x2)
	float K2Node_Event_DeltaTimeX;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	double CallFunc_SelectFloat_ReturnValue;  // 0x58(0x8)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x60(0x8)
	struct ABP_BasePlayerCharacter_C* K2Node_DynamicCast_AsBP_Base_Player_Character;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x70(0x1)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.GetIsAiming
// Size: 0x1(Inherited: 0x0) 
struct FGetIsAiming
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.SetIsSprinting
// Size: 0x1(Inherited: 0x0) 
struct FSetIsSprinting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsSprintins : 1;  // 0x0(0x1)

}; 
// Function ABP_Base_Arms.ABP_Base_Arms_C.WalkingState
// Size: 0x10(Inherited: 0x0) 
struct FWalkingState
{
	struct FPoseLink WalkingState;  // 0x0(0x10)

}; 
// ScriptStruct ABP_Base_Arms.ABP_Base_Arms_C.AnimBlueprintGeneratedConstantData
// Size: 0x120(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_54;  // 0x4(0x8)
	struct FName __NameProperty_55;  // 0xC(0x8)
	struct FName __NameProperty_56;  // 0x14(0x8)
	struct FName __NameProperty_57;  // 0x1C(0x8)
	int32_t __IntProperty_58;  // 0x24(0x4)
	struct FName __NameProperty_59;  // 0x28(0x8)
	struct FName __NameProperty_60;  // 0x30(0x8)
	int32_t __IntProperty_61;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct UBlendProfile* __BlendProfile_62;  // 0x40(0x8)
	struct UCurveFloat* __CurveFloat_63;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool __BoolProperty_64 : 1;  // 0x50(0x1)
	uint8_t  __EnumProperty_65;  // 0x51(0x1)
	uint8_t  __EnumProperty_66;  // 0x52(0x1)
	char pad_83[5];  // 0x53(0x5)
	struct TArray<float> __ArrayProperty_67;  // 0x58(0x10)
	struct FAnimNodeFunctionRef __StructProperty_68;  // 0x68(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x88(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x108(0x18)

}; 
// ScriptStruct ABP_Base_Arms.ABP_Base_Arms_C.AnimBlueprintGeneratedMutableData
// Size: 0x2(Inherited: 0x1) 
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool __BoolProperty : 1;  // 0x1(0x1)

}; 
