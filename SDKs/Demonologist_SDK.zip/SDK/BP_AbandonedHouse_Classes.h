#pragma once 
#include <BP_AbandonedHouse_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AbandonedHouse.BP_AbandonedHouse_C
// Size: 0x158(Inherited: 0x158) 
struct UBP_AbandonedHouse_C : public UBP_MapParameters_C
{

}; 



