#include "SDK.h" 
 
 
void AActor::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function BP_BookLayout01.BP_BookLayout01_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

