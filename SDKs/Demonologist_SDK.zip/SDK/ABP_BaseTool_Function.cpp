#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_BaseTool.ABP_BaseTool_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F2C82B2B473A84FEAA6A2B969441B175(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F2C82B2B473A84FEAA6A2B969441B175 = UObject::FindObject<UFunction>("Function ABP_BaseTool.ABP_BaseTool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F2C82B2B473A84FEAA6A2B969441B175");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F2C82B2B473A84FEAA6A2B969441B175, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F6501E7040F8A068BDBF94B1FBACB5DF(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F6501E7040F8A068BDBF94B1FBACB5DF = UObject::FindObject<UFunction>("Function ABP_BaseTool.ABP_BaseTool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F6501E7040F8A068BDBF94B1FBACB5DF");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseTool_AnimGraphNode_TransitionResult_F6501E7040F8A068BDBF94B1FBACB5DF, &parms);
}

void UAnimInstance::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_BaseTool.ABP_BaseTool_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_BaseTool(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_BaseTool = UObject::FindObject<UFunction>("Function ABP_BaseTool.ABP_BaseTool_C.ExecuteUbergraph_ABP_BaseTool");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_BaseTool, &parms);
}

