#pragma once 
#include <A_Pickup_1H_Weapon_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Pickup_1H_Weapon.A_Pickup_1H_Weapon_C
// Size: 0x2E0(Inherited: 0x2E0) 
struct AA_Pickup_1H_Weapon_C : public AA_Pickup_C
{

}; 



