#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.CanPlayerInteract
// Size: 0xA(Inherited: 0x9) 
struct FCanPlayerInteract : public FCanPlayerInteract
{
	struct APawn* PawnReference;  // 0x0(0x8)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_CanPlayerInteract_ReturnValue : 1;  // 0x9(0x1)

}; 
// Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.BndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FBndEvt__BP_WeaponPartOne_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
{
	struct APawn* CharacterPawn;  // 0x0(0x8)
	struct FName Identifier;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsServerExucuted : 1;  // 0x10(0x1)

}; 
// Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.ExecuteUbergraph_BP_BaseCollectableItem
// Size: 0x2A(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseCollectableItem
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct APawn* K2Node_ComponentBoundEvent_CharacterPawn;  // 0x8(0x8)
	struct FName K2Node_ComponentBoundEvent_Identifier;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_ComponentBoundEvent_IsServerExucuted : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct APawn* K2Node_CustomEvent_Instigator;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_CustomEvent_IsServerExecuted : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x29(0x1)

}; 
// Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.PublishEvent
// Size: 0x28(Inherited: 0x0) 
struct FPublishEvent
{
	struct APawn* Instigator;  // 0x0(0x8)
	struct UBP_Payload_QuestListenerInfo_C* CallFunc_SpawnObject_ReturnValue;  // 0x8(0x8)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x10(0x10)
	struct UTMWGlobalEventHandler* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x20(0x8)

}; 
// Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.GetVisualActiveCondition
// Size: 0x1(Inherited: 0x1) 
struct FGetVisualActiveCondition : public FGetVisualActiveCondition
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.GetIsLookInteractionActive
// Size: 0x1(Inherited: 0x1) 
struct FGetIsLookInteractionActive : public FGetIsLookInteractionActive
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BaseCollectableItem.BP_BaseCollectableItem_C.HandleInteractObjectDispatcher
// Size: 0x9(Inherited: 0x0) 
struct FHandleInteractObjectDispatcher
{
	struct APawn* Instigator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsServerExecuted : 1;  // 0x8(0x1)

}; 
