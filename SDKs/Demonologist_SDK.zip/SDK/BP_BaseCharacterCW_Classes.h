#pragma once 
#include <BP_BaseCharacterCW_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseCharacterCW.BP_BaseCharacterCW_C
// Size: 0x658(Inherited: 0x620) 
struct ABP_BaseCharacterCW_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x620(0x8)
	struct USkeletalMeshComponent* SkeletalMesh;  // 0x628(0x8)
	struct UCameraComponent* Camera;  // 0x630(0x8)
	double MouseSensitivity;  // 0x638(0x8)
	struct FTimerHandle OptionReceiveTimer;  // 0x640(0x8)
	double XAxisMultiplier;  // 0x648(0x8)
	double YAxisMultiplier;  // 0x650(0x8)

	struct FVector GetMovementRightVector(); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.GetMovementRightVector
	struct FVector GetMovementForwardVector(); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.GetMovementForwardVector
	void AddCharacterInput(char E_MovementDirection MovementDirection, double InputScale); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.AddCharacterInput
	void ReceiveOptionVariables(); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ReceiveOptionVariables
	void ReceiveDestroyed(); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ReceiveDestroyed
	void InpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15
	void InpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2
	void InpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7
	void InpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4
	void InpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1
	void InpAxisEvt_MoveRight_K2Node_InputAxisEvent_14(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_14
	void InpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11
	void InpAxisEvt_MoveForward_K2Node_InputAxisEvent_10(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_10
	void ReceiveBeginPlay(); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ReceiveBeginPlay
	void InpAxisEvt_LookRight_K2Node_InputAxisEvent_6(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookRight_K2Node_InputAxisEvent_6
	void InpAxisEvt_LookUp_K2Node_InputAxisEvent_5(float AxisValue); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_5
	void ExecuteUbergraph_BP_BaseCharacterCW(int32_t EntryPoint); // Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ExecuteUbergraph_BP_BaseCharacterCW
}; 



