#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ABP_Rat_Arms.ABP_Rat_Arms_C.AnimBlueprintGeneratedConstantData
// Size: 0x1C0(Inherited: 0x1C0) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
