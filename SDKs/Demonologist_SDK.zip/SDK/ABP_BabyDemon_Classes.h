#pragma once 
#include <ABP_BabyDemon_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_BabyDemon.ABP_BabyDemon_C
// Size: 0x6F8(Inherited: 0x6EC) 
struct UABP_BabyDemon_C : public UABP_BaseEntity_C
{
	char pad_1772[4];  // 0x6EC(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x6F0(0x8)

	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_BabyDemon.ABP_BabyDemon_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_BabyDemon(int32_t EntryPoint); // Function ABP_BabyDemon.ABP_BabyDemon_C.ExecuteUbergraph_ABP_BabyDemon
}; 



