#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::BlueprintThreadSafeUpdateAnimation(float DeltaTime){

	static UObject* p_BlueprintThreadSafeUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.BlueprintThreadSafeUpdateAnimation");

	struct {
		float DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_BlueprintThreadSafeUpdateAnimation, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_19EB74FD4228A7D159612A8AC1F277FD(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_19EB74FD4228A7D159612A8AC1F277FD = UObject::FindObject<UFunction>("Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_19EB74FD4228A7D159612A8AC1F277FD");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_19EB74FD4228A7D159612A8AC1F277FD, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_8CF53E3F49C47F4BF12B4EA838873E9B(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_8CF53E3F49C47F4BF12B4EA838873E9B = UObject::FindObject<UFunction>("Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_8CF53E3F49C47F4BF12B4EA838873E9B");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Turtle_AnimGraphNode_TransitionResult_8CF53E3F49C47F4BF12B4EA838873E9B, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_Pet_Turtle(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_Pet_Turtle = UObject::FindObject<UFunction>("Function ABP_Pet_Turtle.ABP_Pet_Turtle_C.ExecuteUbergraph_ABP_Pet_Turtle");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_Pet_Turtle, &parms);
}

