#pragma once 
#include <ABP_VoodooDoll_Arms_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_VoodooDoll_Arms.ABP_VoodooDoll_Arms_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_VoodooDoll_Arms_C : public UABP_ToolLayerArms_C
{

}; 



