#include "SDK.h" 
 
 
void UAnimInstance::IdleState(struct FPoseLink& IdleState){

	static UObject* p_IdleState = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.IdleState");

	struct {
		struct FPoseLink& IdleState;
	} parms;

	parms.IdleState = IdleState;

	ProcessEvent(p_IdleState, &parms);
}

void UAnimInstance::WalkingState(struct FPoseLink& WalkingState){

	static UObject* p_WalkingState = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.WalkingState");

	struct {
		struct FPoseLink& WalkingState;
	} parms;

	parms.WalkingState = WalkingState;

	ProcessEvent(p_WalkingState, &parms);
}

void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::ProcessIdleBreakTransitionLogic(double DeltaTime){

	static UObject* p_ProcessIdleBreakTransitionLogic = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ProcessIdleBreakTransitionLogic");

	struct {
		double DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_ProcessIdleBreakTransitionLogic, &parms);
}

void UAnimInstance::OnIdleUpdate(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node){

	static UObject* p_OnIdleUpdate = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleUpdate");

	struct {
		struct FAnimUpdateContext& Context;
		struct FAnimNodeReference& Node;
	} parms;

	parms.Context = Context;
	parms.Node = Node;

	ProcessEvent(p_OnIdleUpdate, &parms);
}

void UAnimInstance::ResetIdleRemainingTime(){

	static UObject* p_ResetIdleRemainingTime = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ResetIdleRemainingTime");

	struct {
	} parms;


	ProcessEvent(p_ResetIdleRemainingTime, &parms);
}

void UAnimInstance::OnIdleBecomeRelevant(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node){

	static UObject* p_OnIdleBecomeRelevant = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleBecomeRelevant");

	struct {
		struct FAnimUpdateContext& Context;
		struct FAnimNodeReference& Node;
	} parms;

	parms.Context = Context;
	parms.Node = Node;

	ProcessEvent(p_OnIdleBecomeRelevant, &parms);
}

bool UAnimInstance::CanPlayBreakIdle(){

	static UObject* p_CanPlayBreakIdle = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.CanPlayBreakIdle");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanPlayBreakIdle, &parms);
	return parms.return_value;
}

struct UABP_Base_Arms_C* UAnimInstance::GetMainAnimInstance(){

	static UObject* p_GetMainAnimInstance = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.GetMainAnimInstance");

	struct {
		struct UABP_Base_Arms_C* return_value;
	} parms;


	ProcessEvent(p_GetMainAnimInstance, &parms);
	return parms.return_value;
}

void UAnimInstance::BlueprintThreadSafeUpdateAnimation(float DeltaTime){

	static UObject* p_BlueprintThreadSafeUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.BlueprintThreadSafeUpdateAnimation");

	struct {
		float DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_BlueprintThreadSafeUpdateAnimation, &parms);
}

void UAnimInstance::OnWalkingAnimationUpdated(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node){

	static UObject* p_OnWalkingAnimationUpdated = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnWalkingAnimationUpdated");

	struct {
		struct FAnimUpdateContext& Context;
		struct FAnimNodeReference& Node;
	} parms;

	parms.Context = Context;
	parms.Node = Node;

	ProcessEvent(p_OnWalkingAnimationUpdated, &parms);
}

void UAnimInstance::OnIdleAnimationUpdate(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node){

	static UObject* p_OnIdleAnimationUpdate = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleAnimationUpdate");

	struct {
		struct FAnimUpdateContext& Context;
		struct FAnimNodeReference& Node;
	} parms;

	parms.Context = Context;
	parms.Node = Node;

	ProcessEvent(p_OnIdleAnimationUpdate, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_EEF859B344E32E43DAF57B9BF0AC2479(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_EEF859B344E32E43DAF57B9BF0AC2479 = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_EEF859B344E32E43DAF57B9BF0AC2479");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_EEF859B344E32E43DAF57B9BF0AC2479, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_F519701647874C45E44D3F9AD951152B(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_F519701647874C45E44D3F9AD951152B = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_F519701647874C45E44D3F9AD951152B");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_F519701647874C45E44D3F9AD951152B, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_ToolLayerArms(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_ToolLayerArms = UObject::FindObject<UFunction>("Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ExecuteUbergraph_ABP_ToolLayerArms");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_ToolLayerArms, &parms);
}

