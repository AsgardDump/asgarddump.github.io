#include "SDK.h" 
 
 
void UBP_AiInteractionComponent_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_AiCloseInteractionComponent.BP_AiCloseInteractionComponent_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void UBP_AiInteractionComponent_C::ExecuteUbergraph_BP_AiCloseInteractionComponent(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AiCloseInteractionComponent = UObject::FindObject<UFunction>("Function BP_AiCloseInteractionComponent.BP_AiCloseInteractionComponent_C.ExecuteUbergraph_BP_AiCloseInteractionComponent");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AiCloseInteractionComponent, &parms);
}

