#include "SDK.h" 
 
 
void UWidget::SetMeterValueColor(struct FLinearColor InValue){

	static UObject* p_SetMeterValueColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetMeterValueColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetMeterValueColor, &parms);
}

void UWidget::SetMeterScaleLabelColor(struct FLinearColor InValue){

	static UObject* p_SetMeterScaleLabelColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetMeterScaleLabelColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetMeterScaleLabelColor, &parms);
}

void UWidget::SetMeterScaleColor(struct FLinearColor InValue){

	static UObject* p_SetMeterScaleColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetMeterScaleColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetMeterScaleColor, &parms);
}

void UWidget::SetMeterPeakColor(struct FLinearColor InValue){

	static UObject* p_SetMeterPeakColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetMeterPeakColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetMeterPeakColor, &parms);
}

void UWidget::SetMeterClippingColor(struct FLinearColor InValue){

	static UObject* p_SetMeterClippingColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetMeterClippingColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetMeterClippingColor, &parms);
}

void UWidget::SetMeterChannelInfo(struct TArray<struct FMeterChannelInfo>& InMeterChannelInfo){

	static UObject* p_SetMeterChannelInfo = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetMeterChannelInfo");

	struct {
		struct TArray<struct FMeterChannelInfo>& InMeterChannelInfo;
	} parms;

	parms.InMeterChannelInfo = InMeterChannelInfo;

	ProcessEvent(p_SetMeterChannelInfo, &parms);
}

void UWidget::SetMeterBackgroundColor(struct FLinearColor InValue){

	static UObject* p_SetMeterBackgroundColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetMeterBackgroundColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetMeterBackgroundColor, &parms);
}

void UWidget::SetBackgroundColor(struct FLinearColor InValue){

	static UObject* p_SetBackgroundColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.SetBackgroundColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetBackgroundColor, &parms);
}

struct TArray<struct FMeterChannelInfo> UWidget::GetMeterChannelInfo__DelegateSignature(){

	static UObject* p_GetMeterChannelInfo__DelegateSignature = UObject::FindObject<UFunction>("DelegateFunction AudioWidgets.AudioMeter.GetMeterChannelInfo__DelegateSignature");

	struct {
		struct TArray<struct FMeterChannelInfo> return_value;
	} parms;


	ProcessEvent(p_GetMeterChannelInfo__DelegateSignature, &parms);
	return parms.return_value;
}

struct TArray<struct FMeterChannelInfo> UWidget::GetMeterChannelInfo(){

	static UObject* p_GetMeterChannelInfo = UObject::FindObject<UFunction>("Function AudioWidgets.AudioMeter.GetMeterChannelInfo");

	struct {
		struct TArray<struct FMeterChannelInfo> return_value;
	} parms;


	ProcessEvent(p_GetMeterChannelInfo, &parms);
	return parms.return_value;
}

void UWidget::SetWidgetLayout(char EAudioRadialSliderLayout InLayout){

	static UObject* p_SetWidgetLayout = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetWidgetLayout");

	struct {
		char EAudioRadialSliderLayout InLayout;
	} parms;

	parms.InLayout = InLayout;

	ProcessEvent(p_SetWidgetLayout, &parms);
}

void UWidget::SetValueTextReadOnly(bool bIsReadOnly){

	static UObject* p_SetValueTextReadOnly = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetValueTextReadOnly");

	struct {
		bool bIsReadOnly;
	} parms;

	parms.bIsReadOnly = bIsReadOnly;

	ProcessEvent(p_SetValueTextReadOnly, &parms);
}

void UWidget::SetUnitsTextReadOnly(bool bIsReadOnly){

	static UObject* p_SetUnitsTextReadOnly = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetUnitsTextReadOnly");

	struct {
		bool bIsReadOnly;
	} parms;

	parms.bIsReadOnly = bIsReadOnly;

	ProcessEvent(p_SetUnitsTextReadOnly, &parms);
}

void UWidget::SetUnitsText(struct FText Units){

	static UObject* p_SetUnitsText = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetUnitsText");

	struct {
		struct FText Units;
	} parms;

	parms.Units = Units;

	ProcessEvent(p_SetUnitsText, &parms);
}

void UWidget::SetTextLabelBackgroundColor(struct FSlateColor InColor){

	static UObject* p_SetTextLabelBackgroundColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetTextLabelBackgroundColor");

	struct {
		struct FSlateColor InColor;
	} parms;

	parms.InColor = InColor;

	ProcessEvent(p_SetTextLabelBackgroundColor, &parms);
}

void UWidget::SetSliderThickness(float InThickness){

	static UObject* p_SetSliderThickness = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetSliderThickness");

	struct {
		float InThickness;
	} parms;

	parms.InThickness = InThickness;

	ProcessEvent(p_SetSliderThickness, &parms);
}

void UWidget::SetSliderProgressColor(struct FLinearColor InValue){

	static UObject* p_SetSliderProgressColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetSliderProgressColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderProgressColor, &parms);
}

void UWidget::SetSliderBarColor(struct FLinearColor InValue){

	static UObject* p_SetSliderBarColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetSliderBarColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderBarColor, &parms);
}

void UWidget::SetShowUnitsText(bool bShowUnitsText){

	static UObject* p_SetShowUnitsText = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetShowUnitsText");

	struct {
		bool bShowUnitsText;
	} parms;

	parms.bShowUnitsText = bShowUnitsText;

	ProcessEvent(p_SetShowUnitsText, &parms);
}

void UWidget::SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover){

	static UObject* p_SetShowLabelOnlyOnHover = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetShowLabelOnlyOnHover");

	struct {
		bool bShowLabelOnlyOnHover;
	} parms;

	parms.bShowLabelOnlyOnHover = bShowLabelOnlyOnHover;

	ProcessEvent(p_SetShowLabelOnlyOnHover, &parms);
}

void UWidget::SetOutputRange(struct FVector2D InOutputRange){

	static UObject* p_SetOutputRange = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetOutputRange");

	struct {
		struct FVector2D InOutputRange;
	} parms;

	parms.InOutputRange = InOutputRange;

	ProcessEvent(p_SetOutputRange, &parms);
}

void UWidget::SetHandStartEndRatio(struct FVector2D InHandStartEndRatio){

	static UObject* p_SetHandStartEndRatio = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetHandStartEndRatio");

	struct {
		struct FVector2D InHandStartEndRatio;
	} parms;

	parms.InHandStartEndRatio = InHandStartEndRatio;

	ProcessEvent(p_SetHandStartEndRatio, &parms);
}

void UWidget::SetCenterBackgroundColor(struct FLinearColor InValue){

	static UObject* p_SetCenterBackgroundColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.SetCenterBackgroundColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetCenterBackgroundColor, &parms);
}

float UWidget::GetSliderValue(float OutputValue){

	static UObject* p_GetSliderValue = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.GetSliderValue");

	struct {
		float OutputValue;
		float return_value;
	} parms;

	parms.OutputValue = OutputValue;

	ProcessEvent(p_GetSliderValue, &parms);
	return parms.return_value;
}

float UWidget::GetOutputValue(float InSliderValue){

	static UObject* p_GetOutputValue = UObject::FindObject<UFunction>("Function AudioWidgets.AudioRadialSlider.GetOutputValue");

	struct {
		float InSliderValue;
		float return_value;
	} parms;

	parms.InSliderValue = InSliderValue;

	ProcessEvent(p_GetOutputValue, &parms);
	return parms.return_value;
}

void UWidget::SetWidgetBackgroundColor(struct FLinearColor InValue){

	static UObject* p_SetWidgetBackgroundColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetWidgetBackgroundColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetWidgetBackgroundColor, &parms);
}

void UWidget::SetValueTextReadOnly(bool bIsReadOnly){

	static UObject* p_SetValueTextReadOnly = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetValueTextReadOnly");

	struct {
		bool bIsReadOnly;
	} parms;

	parms.bIsReadOnly = bIsReadOnly;

	ProcessEvent(p_SetValueTextReadOnly, &parms);
}

void UWidget::SetUnitsTextReadOnly(bool bIsReadOnly){

	static UObject* p_SetUnitsTextReadOnly = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetUnitsTextReadOnly");

	struct {
		bool bIsReadOnly;
	} parms;

	parms.bIsReadOnly = bIsReadOnly;

	ProcessEvent(p_SetUnitsTextReadOnly, &parms);
}

void UWidget::SetUnitsText(struct FText Units){

	static UObject* p_SetUnitsText = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetUnitsText");

	struct {
		struct FText Units;
	} parms;

	parms.Units = Units;

	ProcessEvent(p_SetUnitsText, &parms);
}

void UWidget::SetTextLabelBackgroundColor(struct FSlateColor InColor){

	static UObject* p_SetTextLabelBackgroundColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetTextLabelBackgroundColor");

	struct {
		struct FSlateColor InColor;
	} parms;

	parms.InColor = InColor;

	ProcessEvent(p_SetTextLabelBackgroundColor, &parms);
}

void UWidget::SetSliderThumbColor(struct FLinearColor InValue){

	static UObject* p_SetSliderThumbColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetSliderThumbColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderThumbColor, &parms);
}

void UWidget::SetSliderBarColor(struct FLinearColor InValue){

	static UObject* p_SetSliderBarColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetSliderBarColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderBarColor, &parms);
}

void UWidget::SetSliderBackgroundColor(struct FLinearColor InValue){

	static UObject* p_SetSliderBackgroundColor = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetSliderBackgroundColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderBackgroundColor, &parms);
}

void UWidget::SetShowUnitsText(bool bShowUnitsText){

	static UObject* p_SetShowUnitsText = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetShowUnitsText");

	struct {
		bool bShowUnitsText;
	} parms;

	parms.bShowUnitsText = bShowUnitsText;

	ProcessEvent(p_SetShowUnitsText, &parms);
}

void UWidget::SetShowLabelOnlyOnHover(bool bShowLabelOnlyOnHover){

	static UObject* p_SetShowLabelOnlyOnHover = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.SetShowLabelOnlyOnHover");

	struct {
		bool bShowLabelOnlyOnHover;
	} parms;

	parms.bShowLabelOnlyOnHover = bShowLabelOnlyOnHover;

	ProcessEvent(p_SetShowLabelOnlyOnHover, &parms);
}

float UWidget::GetSliderValue(float OutputValue){

	static UObject* p_GetSliderValue = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.GetSliderValue");

	struct {
		float OutputValue;
		float return_value;
	} parms;

	parms.OutputValue = OutputValue;

	ProcessEvent(p_GetSliderValue, &parms);
	return parms.return_value;
}

float UWidget::GetOutputValue(float InSliderValue){

	static UObject* p_GetOutputValue = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.GetOutputValue");

	struct {
		float InSliderValue;
		float return_value;
	} parms;

	parms.InSliderValue = InSliderValue;

	ProcessEvent(p_GetOutputValue, &parms);
	return parms.return_value;
}

float UWidget::GetLinValue(float OutputValue){

	static UObject* p_GetLinValue = UObject::FindObject<UFunction>("Function AudioWidgets.AudioSliderBase.GetLinValue");

	struct {
		float OutputValue;
		float return_value;
	} parms;

	parms.OutputValue = OutputValue;

	ProcessEvent(p_GetLinValue, &parms);
	return parms.return_value;
}

