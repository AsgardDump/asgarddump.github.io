#pragma once 
#include <ABP_Katana_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Katana.ABP_Katana_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_Katana_C : public UABP_ToolLayerArms_C
{

}; 



