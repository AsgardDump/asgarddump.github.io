#pragma once 
#include <A_Tool_1H_Weapon_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Tool_1H_Weapon.A_Tool_1H_Weapon_C
// Size: 0x430(Inherited: 0x3E8) 
struct AA_Tool_1H_Weapon_C : public AA_Tool_Base_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3E8(0x8)
	char pad_1008_1 : 7;  // 0x3F0(0x1)
	bool SaveAttack : 1;  // 0x3F0(0x1)
	char pad_1009[3];  // 0x3F1(0x3)
	int32_t Combo Count;  // 0x3F4(0x4)
	int32_t Auto Combo Count;  // 0x3F8(0x4)
	char pad_1020[4];  // 0x3FC(0x4)
	struct USoundBase* Swing 1 Audio;  // 0x400(0x8)
	struct USoundBase* Swing 2 Audio;  // 0x408(0x8)
	struct USoundBase* Swing 3 Audio;  // 0x410(0x8)
	struct UAnimMontage* Montage 1;  // 0x418(0x8)
	struct UAnimMontage* Montage 2;  // 0x420(0x8)
	struct UAnimMontage* Montage 3;  // 0x428(0x8)

	struct FRotator Trace Angle(struct FRotator Offset); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Trace Angle
	void Reset Attack(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Reset Attack
	void Distance Check(bool& Target In Proximity); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Distance Check
	void Attack Combo(int32_t Count); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Attack Combo
	struct FVector Trace Vector(double Forward, double Up, double Right); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Trace Vector
	void OnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00
	void OnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00
	void OnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00
	void OnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00
	void OnCompleted_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnCompleted_D8FB08CA49198DE439D2FCA751AFAA00
	void Attack(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Attack
	void Swing Trace(struct FVector Location, struct FVector Half Size, struct FRotator Orientation); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Trace
	void MC Swing Montage(int32_t Swing); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.MC Swing Montage
	void Reset Combo(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Reset Combo
	void Saved Attack(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Saved Attack
	void Swing Montage(int32_t Swing); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Montage
	void SRV Swing Montage(int32_t Swing); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.SRV Swing Montage
	void Swing Audio(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Audio
	void Main Fire(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Main Fire
	void Continue Combo(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Continue Combo
	void Auto Attack(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Auto Attack
	void ReceiveBeginPlay(); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.ReceiveBeginPlay
	void ExecuteUbergraph_A_Tool_1H_Weapon(int32_t EntryPoint); // Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.ExecuteUbergraph_A_Tool_1H_Weapon
}; 



