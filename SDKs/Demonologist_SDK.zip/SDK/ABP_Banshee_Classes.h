#pragma once 
#include <ABP_Banshee_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Banshee.ABP_Banshee_C
// Size: 0x6F8(Inherited: 0x6EC) 
struct UABP_Banshee_C : public UABP_BaseEntity_C
{
	char pad_1772[4];  // 0x6EC(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x6F0(0x8)

	void BlueprintInitializeAnimation(); // Function ABP_Banshee.ABP_Banshee_C.BlueprintInitializeAnimation
	void ExecuteUbergraph_ABP_Banshee(int32_t EntryPoint); // Function ABP_Banshee.ABP_Banshee_C.ExecuteUbergraph_ABP_Banshee
}; 



