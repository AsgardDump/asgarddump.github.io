#pragma once 
#include "SDK.h" 
 
 
// Function ALI_ThirdPersonToolLayer.ALI_ThirdPersonToolLayer_C.BaseState
// Size: 0x20(Inherited: 0x0) 
struct FBaseState
{
	struct FPoseLink BaseAnimation;  // 0x0(0x10)
	struct FPoseLink BaseState;  // 0x10(0x10)

}; 
