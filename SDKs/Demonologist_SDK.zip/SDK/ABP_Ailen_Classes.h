#pragma once 
#include <ABP_Ailen_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Ailen.ABP_Ailen_C
// Size: 0x6EC(Inherited: 0x6EC) 
struct UABP_Ailen_C : public UABP_BaseEntity_C
{

}; 



