#pragma once 
#include <ABP_ThirdPersonFinger_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonFinger.ABP_ThirdPersonFinger_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonFinger_C : public UABP_ThirdPersonToolLayer_C
{

}; 



