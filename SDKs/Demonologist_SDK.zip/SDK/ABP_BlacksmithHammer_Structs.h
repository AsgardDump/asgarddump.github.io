#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ABP_BlacksmithHammer.ABP_BlacksmithHammer_C.AnimBlueprintGeneratedConstantData
// Size: 0x1C0(Inherited: 0x1C0) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
