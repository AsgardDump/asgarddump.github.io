#pragma once 
#include <ABP_EvilDemon_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_EvilDemon.ABP_EvilDemon_C
// Size: 0x6EC(Inherited: 0x6EC) 
struct UABP_EvilDemon_C : public UABP_BaseEntity_C
{

}; 



