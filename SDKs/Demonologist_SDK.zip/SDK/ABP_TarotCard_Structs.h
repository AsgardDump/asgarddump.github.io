#pragma once 
#include "SDK.h" 
 
 
// Function ABP_TarotCard.ABP_TarotCard_C.BlueprintThreadSafeUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintThreadSafeUpdateAnimation : public FBlueprintThreadSafeUpdateAnimation
{
	float DeltaTime;  // 0x0(0x4)

}; 
// Function ABP_TarotCard.ABP_TarotCard_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// ScriptStruct ABP_TarotCard.ABP_TarotCard_C.AnimBlueprintGeneratedConstantData
// Size: 0x140(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_22;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct UBlendProfile* __BlendProfile_23;  // 0x10(0x8)
	struct UCurveFloat* __CurveFloat_24;  // 0x18(0x8)
	uint8_t  __EnumProperty_25;  // 0x20(0x1)
	uint8_t  __EnumProperty_26;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct TArray<float> __ArrayProperty_27;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool __BoolProperty_28 : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float __FloatProperty_29;  // 0x3C(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_30;  // 0x40(0x2C)
	float __FloatProperty_31;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool __BoolProperty_32 : 1;  // 0x70(0x1)
	uint8_t  __EnumProperty_33;  // 0x71(0x1)
	char EAnimGroupRole __ByteProperty_34;  // 0x72(0x1)
	char pad_115[1];  // 0x73(0x1)
	struct FName __NameProperty_35;  // 0x74(0x8)
	struct FName __NameProperty_36;  // 0x7C(0x8)
	int32_t __IntProperty_37;  // 0x84(0x4)
	struct FAnimNodeFunctionRef __StructProperty_38;  // 0x88(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0xA8(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x128(0x18)

}; 
// Function ABP_TarotCard.ABP_TarotCard_C.ExecuteUbergraph_ABP_TarotCard
// Size: 0x3A(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_TarotCard
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x8(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x10(0x10)
	struct ABP_TarotCards_C* K2Node_DynamicCast_AsBP_Tarot_Cards;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct APawn* K2Node_CustomEvent_OldInstigator;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_CustomEvent_IsFirstInit : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsLocalInstigator_ReturnValue : 1;  // 0x39(0x1)

}; 
// Function ABP_TarotCard.ABP_TarotCard_C.OnObjectInstigatorUpdatedCallback
// Size: 0x9(Inherited: 0x0) 
struct FOnObjectInstigatorUpdatedCallback
{
	struct APawn* OldInstigator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool IsFirstInit : 1;  // 0x8(0x1)

}; 
// ScriptStruct ABP_TarotCard.ABP_TarotCard_C.AnimBlueprintGeneratedMutableData
// Size: 0x2(Inherited: 0x1) 
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool __BoolProperty : 1;  // 0x1(0x1)

}; 
