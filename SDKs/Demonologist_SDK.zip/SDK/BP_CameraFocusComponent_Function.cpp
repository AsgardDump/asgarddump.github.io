#include "SDK.h" 
 
 
void UActorComponent::OnTargetPlayerDied(struct ABP_Shivers_InGamePlayerState_C* PlayerState){

	static UObject* p_OnTargetPlayerDied = UObject::FindObject<UFunction>("Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.OnTargetPlayerDied");

	struct {
		struct ABP_Shivers_InGamePlayerState_C* PlayerState;
	} parms;

	parms.PlayerState = PlayerState;

	ProcessEvent(p_OnTargetPlayerDied, &parms);
}

void UActorComponent::UpdatePlayerVisibilities(bool IsFocused){

	static UObject* p_UpdatePlayerVisibilities = UObject::FindObject<UFunction>("Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdatePlayerVisibilities");

	struct {
		bool IsFocused;
	} parms;

	parms.IsFocused = IsFocused;

	ProcessEvent(p_UpdatePlayerVisibilities, &parms);
}

bool UActorComponent::GetIsPlayerDead(){

	static UObject* p_GetIsPlayerDead = UObject::FindObject<UFunction>("Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.GetIsPlayerDead");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsPlayerDead, &parms);
	return parms.return_value;
}

void UActorComponent::UpdateWorldVisibility(){

	static UObject* p_UpdateWorldVisibility = UObject::FindObject<UFunction>("Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateWorldVisibility");

	struct {
	} parms;


	ProcessEvent(p_UpdateWorldVisibility, &parms);
}

void UActorComponent::UpdateShowMouseCursor(){

	static UObject* p_UpdateShowMouseCursor = UObject::FindObject<UFunction>("Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateShowMouseCursor");

	struct {
	} parms;


	ProcessEvent(p_UpdateShowMouseCursor, &parms);
}

void UActorComponent::UpdateCameraFocus(bool FocusCamera){

	static UObject* p_UpdateCameraFocus = UObject::FindObject<UFunction>("Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateCameraFocus");

	struct {
		bool FocusCamera;
	} parms;

	parms.FocusCamera = FocusCamera;

	ProcessEvent(p_UpdateCameraFocus, &parms);
}

void UActorComponent::OnFocusUpdated__DelegateSignature(bool IsFocused){

	static UObject* p_OnFocusUpdated__DelegateSignature = UObject::FindObject<UFunction>("Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.OnFocusUpdated__DelegateSignature");

	struct {
		bool IsFocused;
	} parms;

	parms.IsFocused = IsFocused;

	ProcessEvent(p_OnFocusUpdated__DelegateSignature, &parms);
}

