#include "SDK.h" 
 
 
void AActor::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function BP_Ball.BP_Ball_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void AActor::ReceiveHit(struct UPrimitiveComponent* MyComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, bool bSelfMoved, struct FVector HitLocation, struct FVector HitNormal, struct FVector NormalImpulse, struct FHitResult& Hit){

	static UObject* p_ReceiveHit = UObject::FindObject<UFunction>("Function BP_Ball.BP_Ball_C.ReceiveHit");

	struct {
		struct UPrimitiveComponent* MyComp;
		struct AActor* Other;
		struct UPrimitiveComponent* OtherComp;
		bool bSelfMoved;
		struct FVector HitLocation;
		struct FVector HitNormal;
		struct FVector NormalImpulse;
		struct FHitResult& Hit;
	} parms;

	parms.MyComp = MyComp;
	parms.Other = Other;
	parms.OtherComp = OtherComp;
	parms.bSelfMoved = bSelfMoved;
	parms.HitLocation = HitLocation;
	parms.HitNormal = HitNormal;
	parms.NormalImpulse = NormalImpulse;
	parms.Hit = Hit;

	ProcessEvent(p_ReceiveHit, &parms);
}

void AActor::ExecuteUbergraph_BP_Ball(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Ball = UObject::FindObject<UFunction>("Function BP_Ball.BP_Ball_C.ExecuteUbergraph_BP_Ball");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Ball, &parms);
}

