#pragma once 
#include <ABP_ThirdPersonGlass_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonGlass.ABP_ThirdPersonGlass_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonGlass_C : public UABP_ThirdPersonToolLayer_C
{

}; 



