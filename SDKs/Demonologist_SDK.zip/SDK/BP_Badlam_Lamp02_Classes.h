#pragma once 
#include <BP_Badlam_Lamp02_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Badlam_Lamp02.BP_Badlam_Lamp02_C
// Size: 0x3B8(Inherited: 0x3B8) 
struct ABP_Badlam_Lamp02_C : public ABP_PointLight_C
{

}; 



