#pragma once 
#include <BP_Candle_Started_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Candle_Started.BP_Candle_Started_C
// Size: 0x2D2(Inherited: 0x290) 
struct ABP_Candle_Started_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct UPointLightComponent* SSSlight;  // 0x298(0x8)
	struct UParticleSystemComponent* PS_CandleFlame;  // 0x2A0(0x8)
	struct UStaticMeshComponent* SM_Candle01;  // 0x2A8(0x8)
	float CandleFlicker_Intensity_5BB2B3C041E47DB229A1E68E0663D367;  // 0x2B0(0x4)
	char ETimelineDirection CandleFlicker__Direction_5BB2B3C041E47DB229A1E68E0663D367;  // 0x2B4(0x1)
	char pad_693[3];  // 0x2B5(0x3)
	struct UTimelineComponent* CandleFlicker;  // 0x2B8(0x8)
	double MinIntensity;  // 0x2C0(0x8)
	double MaxIntensity;  // 0x2C8(0x8)
	char pad_720_1 : 7;  // 0x2D0(0x1)
	bool Enabled : 1;  // 0x2D0(0x1)
	char pad_721_1 : 7;  // 0x2D1(0x1)
	bool Cinematic On : 1;  // 0x2D1(0x1)

	void SetEnabled(bool Enabled); // Function BP_Candle_Started.BP_Candle_Started_C.SetEnabled
	void UserConstructionScript(); // Function BP_Candle_Started.BP_Candle_Started_C.UserConstructionScript
	void CandleFlicker__FinishedFunc(); // Function BP_Candle_Started.BP_Candle_Started_C.CandleFlicker__FinishedFunc
	void CandleFlicker__UpdateFunc(); // Function BP_Candle_Started.BP_Candle_Started_C.CandleFlicker__UpdateFunc
	void ReceiveBeginPlay(); // Function BP_Candle_Started.BP_Candle_Started_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_Candle_Started(int32_t EntryPoint); // Function BP_Candle_Started.BP_Candle_Started_C.ExecuteUbergraph_BP_Candle_Started
}; 



