#pragma once 
#include <BP_BirdPainting_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BirdPainting.BP_BirdPainting_C
// Size: 0x2A0(Inherited: 0x298) 
struct ABP_BirdPainting_C : public ABP_BaseSafeHouseCustomizationActor_C
{
	struct UStaticMeshComponent* StaticMesh;  // 0x298(0x8)

}; 



