#pragma once 
#include <BP_Candle_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Candle.BP_Candle_C
// Size: 0x488(Inherited: 0x429) 
struct ABP_Candle_C : public ABP_Tool_C
{
	char pad_1065[7];  // 0x429(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct UNiagaraComponent* Flame;  // 0x438(0x8)
	struct UPointLightComponent* CandleLight;  // 0x440(0x8)
	struct UBoxComponent* AiInteractionArea;  // 0x448(0x8)
	struct UBP_AiCloseInteractionComponent_C* BP_AiCloseInteractionComponent;  // 0x450(0x8)
	struct UChildActorComponent* ProtectionArea;  // 0x458(0x8)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool IsCandleOn : 1;  // 0x460(0x1)
	char pad_1121[7];  // 0x461(0x7)
	double FlameCurrentSpeedX;  // 0x468(0x8)
	double FlameCurrentSpeedY;  // 0x470(0x8)
	double FlamePreviousLocationX;  // 0x478(0x8)
	double PreviousLocationY;  // 0x480(0x8)

	bool GetInteractionCondition(struct UObject* Payload, struct TArray<struct FName>& Identifier, struct UBP_AiInteractionComponent_C* RequestInteractionComponent); // Function BP_Candle.BP_Candle_C.GetInteractionCondition
	bool GetIsFireOn(); // Function BP_Candle.BP_Candle_C.GetIsFireOn
	void UpdateFlameMovement(); // Function BP_Candle.BP_Candle_C.UpdateFlameMovement
	struct ABP_SanityProtectionArea_C* GetProtectionArea(); // Function BP_Candle.BP_Candle_C.GetProtectionArea
	void UpdateCandleVisibility(); // Function BP_Candle.BP_Candle_C.UpdateCandleVisibility
	void OnRep_IsCandleOn(); // Function BP_Candle.BP_Candle_C.OnRep_IsCandleOn
	void InpActEvt_ToolInteraction_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_Candle.BP_Candle_C.InpActEvt_ToolInteraction_K2Node_InputActionEvent_1
	void ReceiveBeginPlay(); // Function BP_Candle.BP_Candle_C.ReceiveBeginPlay
	void ReceiveDestroyed(); // Function BP_Candle.BP_Candle_C.ReceiveDestroyed
	void ToggleCandleStatusServer(); // Function BP_Candle.BP_Candle_C.ToggleCandleStatusServer
	void BndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature(struct AActor* Instigator); // Function BP_Candle.BP_Candle_C.BndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature
	void OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit); // Function BP_Candle.BP_Candle_C.OnObjectInstigatorUpdatedCallback
	void OnCandleBlowAI(struct APawn* Instigator); // Function BP_Candle.BP_Candle_C.OnCandleBlowAI
	void BlowFire(); // Function BP_Candle.BP_Candle_C.BlowFire
	void ReceiveTick(float DeltaSeconds); // Function BP_Candle.BP_Candle_C.ReceiveTick
	void OnQuestFinishedCallback(struct FGameplayTag CompletedTag, double Progress, struct APawn* Instigator); // Function BP_Candle.BP_Candle_C.OnQuestFinishedCallback
	void CheckCandleQuest(); // Function BP_Candle.BP_Candle_C.CheckCandleQuest
	void OnQuestAddedCallback(struct TArray<struct FS_QuestInformation>& QuestTags); // Function BP_Candle.BP_Candle_C.OnQuestAddedCallback
	void CustomCandleInteraction(); // Function BP_Candle.BP_Candle_C.CustomCandleInteraction
	void recognitionResultReceivedCallback(struct FString Result); // Function BP_Candle.BP_Candle_C.recognitionResultReceivedCallback
	void ExecuteUbergraph_BP_Candle(int32_t EntryPoint); // Function BP_Candle.BP_Candle_C.ExecuteUbergraph_BP_Candle
}; 



