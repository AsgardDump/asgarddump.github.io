#pragma once 
#include "SDK.h" 
 
 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.InpActEvt_ToolInteraction_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_ToolInteraction_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.CanAttack
// Size: 0x1A(Inherited: 0x0) 
struct FCanAttack
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USkeletalMeshComponent* CallFunc_GetFpsArms_ReturnValue;  // 0x8(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsAnyMontagePlaying_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.ExecuteUbergraph_BP_BlacksmithHammer
// Size: 0x408(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BlacksmithHammer
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x4(0x8)
	struct FName K2Node_CustomEvent_NotifyName;  // 0xC(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x14(0x10)
	struct FName Temp_name_Variable;  // 0x24(0x8)
	int32_t Temp_int_Variable;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct UAnimMontage* Temp_object_Variable;  // 0x38(0x8)
	struct UAnimMontage* Temp_object_Variable_2;  // 0x40(0x8)
	char CallFunc_MakeLiteralByte_ReturnValue;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x4C(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x5C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x64(0x10)
	char pad_116[4];  // 0x74(0x4)
	struct USkeletalMeshComponent* CallFunc_GetFpsArms_ReturnValue;  // 0x78(0x8)
	struct USkeletalMeshComponent* CallFunc_GetTpsMesh_ReturnValue;  // 0x80(0x8)
	struct UAnimInstance* CallFunc_GetLinkedAnimLayerInstanceByClass_ReturnValue;  // 0x88(0x8)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x90(0x8)
	float CallFunc_Montage_Play_ReturnValue;  // 0x98(0x4)
	char pad_156_1 : 7;  // 0x9C(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0xA0(0x8)
	struct TScriptInterface<IBPI_GenericPlayer_C> K2Node_DynamicCast_AsBPI_Generic_Player;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct TScriptInterface<IBPI_GenericPlayer_C> K2Node_DynamicCast_AsBPI_Generic_Player_2;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct UCameraComponent* CallFunc_GetCameraReference_ReturnValue;  // 0xD8(0x8)
	struct FRotator CallFunc_GetLookDirection_ReturnValue;  // 0xE0(0x18)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0xF8(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x110(0x18)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x128(0x18)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x140(0x10)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x150(0x18)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool K2Node_CustomEvent_bTrueHit_2 : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct FVector K2Node_CustomEvent_Location_2;  // 0x170(0x18)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x188(0x8)
	struct ABP_HammerUvObject_C* K2Node_DynamicCast_AsBP_Hammer_Uv_Object;  // 0x190(0x8)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x198(0x1)
	char pad_409[7];  // 0x199(0x7)
	struct ABP_UVWall_C* K2Node_DynamicCast_AsBP_UVWall;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool K2Node_CustomEvent_bTrueHit : 1;  // 0x1A9(0x1)
	char pad_426[6];  // 0x1AA(0x6)
	struct FVector K2Node_CustomEvent_Location;  // 0x1B0(0x18)
	struct ABP_HammerUvObject_C* K2Node_CustomEvent_WallUvObject;  // 0x1C8(0x8)
	char pad_464_1 : 7;  // 0x1D0(0x1)
	bool CallFunc_RandomBoolWithWeight_ReturnValue : 1;  // 0x1D0(0x1)
	char pad_465[3];  // 0x1D1(0x3)
	int32_t CallFunc_Conv_BoolToInt_ReturnValue;  // 0x1D4(0x4)
	char pad_472_1 : 7;  // 0x1D8(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x1D8(0x1)
	char pad_473[7];  // 0x1D9(0x7)
	struct UAnimMontage* K2Node_Select_Default;  // 0x1E0(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x1E8(0x8)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x1F0(0x1)
	char pad_497_1 : 7;  // 0x1F1(0x1)
	bool CallFunc_CanAttack_ReturnValue : 1;  // 0x1F1(0x1)
	char pad_498[2];  // 0x1F2(0x2)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x1F4(0x10)
	char pad_516[4];  // 0x204(0x4)
	struct ABP_UVWall_C* CallFunc_GetActorOfClass_ReturnValue;  // 0x208(0x8)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x210(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x218(0x10)
	struct FKey K2Node_InputActionEvent_Key;  // 0x228(0x18)
	char CallFunc_MakeLiteralByte_ReturnValue_2;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x248(0xE8)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x330(0x1)
	char pad_817_1 : 7;  // 0x331(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x331(0x1)
	char pad_818_1 : 7;  // 0x332(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x332(0x1)
	char pad_819[1];  // 0x333(0x1)
	float CallFunc_BreakHitResult_Time;  // 0x334(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x340(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x358(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x370(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x388(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x3A0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x3A8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x3B0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x3B8(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x3C0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x3C8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x3CC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x3D0(0x4)
	char pad_980[4];  // 0x3D4(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x3D8(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x3F0(0x18)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HitUvObject
// Size: 0x28(Inherited: 0x0) 
struct FHitUvObject
{
	struct FVector Location;  // 0x0(0x18)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0x18(0x8)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue_2;  // 0x20(0x8)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HammerHitOnServer
// Size: 0x28(Inherited: 0x0) 
struct FHammerHitOnServer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTrueHit : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVector Location;  // 0x8(0x18)
	struct ABP_HammerUvObject_C* WallUvObject;  // 0x20(0x8)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HammerHitWall On Multicast
// Size: 0x20(Inherited: 0x0) 
struct FHammerHitWall On Multicast
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bTrueHit : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVector Location;  // 0x8(0x18)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HitWall
// Size: 0x20(Inherited: 0x0) 
struct FHitWall
{
	struct FVector Location;  // 0x0(0x18)
	struct UNiagaraComponent* CallFunc_SpawnSystemAtLocation_ReturnValue;  // 0x18(0x8)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
