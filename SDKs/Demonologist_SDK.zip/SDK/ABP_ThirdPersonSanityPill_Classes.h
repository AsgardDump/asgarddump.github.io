#pragma once 
#include <ABP_ThirdPersonSanityPill_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonSanityPill.ABP_ThirdPersonSanityPill_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonSanityPill_C : public UABP_ThirdPersonToolLayer_C
{

}; 



