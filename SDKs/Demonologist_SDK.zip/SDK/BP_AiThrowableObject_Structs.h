#pragma once 
#include "SDK.h" 
 
 
// Function BP_AiThrowableObject.BP_AiThrowableObject_C.ExecuteUbergraph_BP_AiThrowableObject
// Size: 0x200(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AiThrowableObject
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetThrowableItems_ReturnValue;  // 0x8(0x10)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x18(0x8)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x29(0x1)
	char pad_42[6];  // 0x2A(0x6)
	struct AActor* K2Node_CustomEvent_Instigator_2;  // 0x30(0x8)
	struct UObject* K2Node_CustomEvent_Instigator;  // 0x38(0x8)
	struct FVector K2Node_CustomEvent_Impulse;  // 0x40(0x18)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetThrowableItems_ReturnValue_2;  // 0x58(0x10)
	struct TScriptInterface<IBPI_NewEntity_C> K2Node_DynamicCast_AsBPI_New_Entity;  // 0x68(0x10)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x78(0x1)
	char pad_121[3];  // 0x79(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x7C(0x4)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[3];  // 0x81(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x84(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x94(0x4)
	struct ABP_Entity_C* CallFunc_GetAiReference_ReturnValue;  // 0x98(0x8)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item_2;  // 0xA0(0x8)
	struct FVector CallFunc_GetGhostThrowTargetImpulse_ReturnValue;  // 0xA8(0x18)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0xC0(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xD0(0x4)
	char pad_212[4];  // 0xD4(0x4)
	struct UPrimitiveComponent* K2Node_CustomEvent_HitComponent;  // 0xD8(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor;  // 0xE0(0x8)
	struct UPrimitiveComponent* K2Node_CustomEvent_OtherComp;  // 0xE8(0x8)
	struct FVector K2Node_CustomEvent_NormalImpulse;  // 0xF0(0x18)
	struct FHitResult K2Node_CustomEvent_Hit;  // 0x108(0xE8)
	double CallFunc_VSize_ReturnValue;  // 0x1F0(0x8)
	char pad_504_1 : 7;  // 0x1F8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1F8(0x1)
	char pad_505_1 : 7;  // 0x1F9(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x1F9(0x1)
	char pad_506[2];  // 0x1FA(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1FC(0x4)

}; 
// Function BP_AiThrowableObject.BP_AiThrowableObject_C.OnInteractionRequestedCallback
// Size: 0x8(Inherited: 0x0) 
struct FOnInteractionRequestedCallback
{
	struct AActor* Instigator;  // 0x0(0x8)

}; 
// Function BP_AiThrowableObject.BP_AiThrowableObject_C.GetThrowableItems
// Size: 0x69(Inherited: 0x0) 
struct FGetThrowableItems
{
	struct TArray<struct UPrimitiveComponent*> ReturnValue;  // 0x0(0x10)
	struct TArray<struct UPrimitiveComponent*> ThrowableItems;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	struct FName Temp_name_Variable;  // 0x2C(0x8)
	char pad_52[4];  // 0x34(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x38(0x8)
	struct TArray<struct UPrimitiveComponent*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x40(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[3];  // 0x61(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x64(0x4)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x68(0x1)

}; 
// Function BP_AiThrowableObject.BP_AiThrowableObject_C.InitializeThrowableMeshes
// Size: 0x39(Inherited: 0x0) 
struct FInitializeThrowableMeshes
{
	int32_t Temp_int_Loop_Counter_Variable;  // 0x0(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	struct TArray<struct UPrimitiveComponent*> CallFunc_GetThrowableItems_ReturnValue;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)

}; 
// Function BP_AiThrowableObject.BP_AiThrowableObject_C.OnComponentHit_Event
// Size: 0x118(Inherited: 0x0) 
struct FOnComponentHit_Event
{
	struct UPrimitiveComponent* HitComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	struct FVector NormalImpulse;  // 0x18(0x18)
	struct FHitResult Hit;  // 0x30(0xE8)

}; 
// Function BP_AiThrowableObject.BP_AiThrowableObject_C.ThrowableObjectInteractionMulticast
// Size: 0x20(Inherited: 0x0) 
struct FThrowableObjectInteractionMulticast
{
	struct UObject* Instigator;  // 0x0(0x8)
	struct FVector Impulse;  // 0x8(0x18)

}; 
