#pragma once 
#include <ABP_ThirdPersonESG_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonESG.ABP_ThirdPersonESG_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonESG_C : public UABP_ThirdPersonToolLayer_C
{

}; 



