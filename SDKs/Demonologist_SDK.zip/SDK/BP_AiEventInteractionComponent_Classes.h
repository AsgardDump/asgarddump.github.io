#pragma once 
#include <BP_AiEventInteractionComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C
// Size: 0x1A8(Inherited: 0x140) 
struct UBP_AiEventInteractionComponent_C : public UBP_AiCloseInteractionComponent_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x140(0x8)
	struct UBP_EventBoxComponent_C* EventBoxComponentReference;  // 0x148(0x8)
	struct AActor* HauntedAreaAttachActor;  // 0x150(0x8)
	struct TMap<struct AActor*, struct FName> FingerprintAttachMapping;  // 0x158(0x50)

	bool CanInstigatorInteract(struct AActor* Instigator); // Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.CanInstigatorInteract
	void ReceiveBeginPlay(); // Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.ReceiveBeginPlay
	void OnInteractionRequestedCallback(struct AActor* Instigator); // Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.OnInteractionRequestedCallback
	void ExecuteUbergraph_BP_AiEventInteractionComponent(int32_t EntryPoint); // Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.ExecuteUbergraph_BP_AiEventInteractionComponent
}; 



