#pragma once 
#include <ALI_ToolAnimLayers_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ALI_ToolAnimLayers.ALI_ToolAnimLayers_C
// Size: 0x28(Inherited: 0x28) 
struct UALI_ToolAnimLayers_C : public UAnimLayerInterface
{

	void WalkingState(struct FPoseLink& WalkingState); // Function ALI_ToolAnimLayers.ALI_ToolAnimLayers_C.WalkingState
	void IdleState(struct FPoseLink& IdleState); // Function ALI_ToolAnimLayers.ALI_ToolAnimLayers_C.IdleState
}; 



