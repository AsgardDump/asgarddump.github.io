#include "SDK.h" 
 
 
bool ABP_Tool_C::GetInteractionCondition(struct UObject* Payload, struct TArray<struct FName>& Identifier, struct UBP_AiInteractionComponent_C* RequestInteractionComponent){

	static UObject* p_GetInteractionCondition = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.GetInteractionCondition");

	struct {
		struct UObject* Payload;
		struct TArray<struct FName>& Identifier;
		struct UBP_AiInteractionComponent_C* RequestInteractionComponent;
		bool return_value;
	} parms;

	parms.Payload = Payload;
	parms.Identifier = Identifier;
	parms.RequestInteractionComponent = RequestInteractionComponent;

	ProcessEvent(p_GetInteractionCondition, &parms);
	return parms.return_value;
}

bool ABP_Tool_C::GetIsFireOn(){

	static UObject* p_GetIsFireOn = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.GetIsFireOn");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsFireOn, &parms);
	return parms.return_value;
}

void ABP_Tool_C::UpdateFlameMovement(){

	static UObject* p_UpdateFlameMovement = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.UpdateFlameMovement");

	struct {
	} parms;


	ProcessEvent(p_UpdateFlameMovement, &parms);
}

struct ABP_SanityProtectionArea_C* ABP_Tool_C::GetProtectionArea(){

	static UObject* p_GetProtectionArea = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.GetProtectionArea");

	struct {
		struct ABP_SanityProtectionArea_C* return_value;
	} parms;


	ProcessEvent(p_GetProtectionArea, &parms);
	return parms.return_value;
}

void ABP_Tool_C::UpdateCandleVisibility(){

	static UObject* p_UpdateCandleVisibility = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.UpdateCandleVisibility");

	struct {
	} parms;


	ProcessEvent(p_UpdateCandleVisibility, &parms);
}

void ABP_Tool_C::OnRep_IsCandleOn(){

	static UObject* p_OnRep_IsCandleOn = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.OnRep_IsCandleOn");

	struct {
	} parms;


	ProcessEvent(p_OnRep_IsCandleOn, &parms);
}

void ABP_Tool_C::InpActEvt_ToolInteraction_K2Node_InputActionEvent_1(struct FKey Key){

	static UObject* p_InpActEvt_ToolInteraction_K2Node_InputActionEvent_1 = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.InpActEvt_ToolInteraction_K2Node_InputActionEvent_1");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_ToolInteraction_K2Node_InputActionEvent_1, &parms);
}

void ABP_Tool_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_Tool_C::ReceiveDestroyed(){

	static UObject* p_ReceiveDestroyed = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.ReceiveDestroyed");

	struct {
	} parms;


	ProcessEvent(p_ReceiveDestroyed, &parms);
}

void ABP_Tool_C::ToggleCandleStatusServer(){

	static UObject* p_ToggleCandleStatusServer = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.ToggleCandleStatusServer");

	struct {
	} parms;


	ProcessEvent(p_ToggleCandleStatusServer, &parms);
}

void ABP_Tool_C::BndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature(struct AActor* Instigator){

	static UObject* p_BndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.BndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature");

	struct {
		struct AActor* Instigator;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_BndEvt__BP_Candle_BP_AiCloseInteractionComponent_K2Node_ComponentBoundEvent_0_OnInteractionRequested__DelegateSignature, &parms);
}

void ABP_Tool_C::OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit){

	static UObject* p_OnObjectInstigatorUpdatedCallback = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.OnObjectInstigatorUpdatedCallback");

	struct {
		struct APawn* OldInstigator;
		bool IsFirstInit;
	} parms;

	parms.OldInstigator = OldInstigator;
	parms.IsFirstInit = IsFirstInit;

	ProcessEvent(p_OnObjectInstigatorUpdatedCallback, &parms);
}

void ABP_Tool_C::OnCandleBlowAI(struct APawn* Instigator){

	static UObject* p_OnCandleBlowAI = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.OnCandleBlowAI");

	struct {
		struct APawn* Instigator;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_OnCandleBlowAI, &parms);
}

void ABP_Tool_C::BlowFire(){

	static UObject* p_BlowFire = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.BlowFire");

	struct {
	} parms;


	ProcessEvent(p_BlowFire, &parms);
}

void ABP_Tool_C::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void ABP_Tool_C::OnQuestFinishedCallback(struct FGameplayTag CompletedTag, double Progress, struct APawn* Instigator){

	static UObject* p_OnQuestFinishedCallback = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.OnQuestFinishedCallback");

	struct {
		struct FGameplayTag CompletedTag;
		double Progress;
		struct APawn* Instigator;
	} parms;

	parms.CompletedTag = CompletedTag;
	parms.Progress = Progress;
	parms.Instigator = Instigator;

	ProcessEvent(p_OnQuestFinishedCallback, &parms);
}

void ABP_Tool_C::CheckCandleQuest(){

	static UObject* p_CheckCandleQuest = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.CheckCandleQuest");

	struct {
	} parms;


	ProcessEvent(p_CheckCandleQuest, &parms);
}

void ABP_Tool_C::OnQuestAddedCallback(struct TArray<struct FS_QuestInformation>& QuestTags){

	static UObject* p_OnQuestAddedCallback = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.OnQuestAddedCallback");

	struct {
		struct TArray<struct FS_QuestInformation>& QuestTags;
	} parms;

	parms.QuestTags = QuestTags;

	ProcessEvent(p_OnQuestAddedCallback, &parms);
}

void ABP_Tool_C::CustomCandleInteraction(){

	static UObject* p_CustomCandleInteraction = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.CustomCandleInteraction");

	struct {
	} parms;


	ProcessEvent(p_CustomCandleInteraction, &parms);
}

void ABP_Tool_C::recognitionResultReceivedCallback(struct FString Result){

	static UObject* p_recognitionResultReceivedCallback = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.recognitionResultReceivedCallback");

	struct {
		struct FString Result;
	} parms;

	parms.Result = Result;

	ProcessEvent(p_recognitionResultReceivedCallback, &parms);
}

void ABP_Tool_C::ExecuteUbergraph_BP_Candle(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Candle = UObject::FindObject<UFunction>("Function BP_Candle.BP_Candle_C.ExecuteUbergraph_BP_Candle");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Candle, &parms);
}

