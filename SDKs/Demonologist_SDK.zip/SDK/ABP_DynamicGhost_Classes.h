#pragma once 
#include <ABP_DynamicGhost_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_DynamicGhost.ABP_DynamicGhost_C
// Size: 0x4C4(Inherited: 0x350) 
struct UABP_DynamicGhost_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x360(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x368(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x370(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x390(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x3D8(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x3F8(0xC8)
	float PlayRate;  // 0x4C0(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_DynamicGhost.ABP_DynamicGhost_C.AnimGraph
	void ExecuteUbergraph_ABP_DynamicGhost(int32_t EntryPoint); // Function ABP_DynamicGhost.ABP_DynamicGhost_C.ExecuteUbergraph_ABP_DynamicGhost
}; 



