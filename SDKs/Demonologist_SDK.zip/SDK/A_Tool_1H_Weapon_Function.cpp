#include "SDK.h" 
 
 
struct FRotator AA_Tool_Base_C::Trace Angle(struct FRotator Offset){

	static UObject* p_Trace Angle = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Trace Angle");

	struct {
		struct FRotator Offset;
		struct FRotator return_value;
	} parms;

	parms.Offset = Offset;

	ProcessEvent(p_Trace Angle, &parms);
	return parms.return_value;
}

void AA_Tool_Base_C::Reset Attack(){

	static UObject* p_Reset Attack = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Reset Attack");

	struct {
	} parms;


	ProcessEvent(p_Reset Attack, &parms);
}

void AA_Tool_Base_C::Distance Check(bool& Target In Proximity){

	static UObject* p_Distance Check = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Distance Check");

	struct {
		bool& Target In Proximity;
	} parms;

	parms.Target In Proximity = Target In Proximity;

	ProcessEvent(p_Distance Check, &parms);
}

void AA_Tool_Base_C::Attack Combo(int32_t Count){

	static UObject* p_Attack Combo = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Attack Combo");

	struct {
		int32_t Count;
	} parms;

	parms.Count = Count;

	ProcessEvent(p_Attack Combo, &parms);
}

struct FVector AA_Tool_Base_C::Trace Vector(double Forward, double Up, double Right){

	static UObject* p_Trace Vector = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Trace Vector");

	struct {
		double Forward;
		double Up;
		double Right;
		struct FVector return_value;
	} parms;

	parms.Forward = Forward;
	parms.Up = Up;
	parms.Right = Right;

	ProcessEvent(p_Trace Vector, &parms);
	return parms.return_value;
}

void AA_Tool_Base_C::OnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName){

	static UObject* p_OnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00 = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00, &parms);
}

void AA_Tool_Base_C::OnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName){

	static UObject* p_OnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00 = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00, &parms);
}

void AA_Tool_Base_C::OnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName){

	static UObject* p_OnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00 = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00, &parms);
}

void AA_Tool_Base_C::OnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName){

	static UObject* p_OnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00 = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00, &parms);
}

void AA_Tool_Base_C::OnCompleted_D8FB08CA49198DE439D2FCA751AFAA00(struct FName NotifyName){

	static UObject* p_OnCompleted_D8FB08CA49198DE439D2FCA751AFAA00 = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnCompleted_D8FB08CA49198DE439D2FCA751AFAA00");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnCompleted_D8FB08CA49198DE439D2FCA751AFAA00, &parms);
}

void AA_Tool_Base_C::Attack(){

	static UObject* p_Attack = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Attack");

	struct {
	} parms;


	ProcessEvent(p_Attack, &parms);
}

void AA_Tool_Base_C::Swing Trace(struct FVector Location, struct FVector Half Size, struct FRotator Orientation){

	static UObject* p_Swing Trace = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Trace");

	struct {
		struct FVector Location;
		struct FVector Half Size;
		struct FRotator Orientation;
	} parms;

	parms.Location = Location;
	parms.Half Size = Half Size;
	parms.Orientation = Orientation;

	ProcessEvent(p_Swing Trace, &parms);
}

void AA_Tool_Base_C::MC Swing Montage(int32_t Swing){

	static UObject* p_MC Swing Montage = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.MC Swing Montage");

	struct {
		int32_t Swing;
	} parms;

	parms.Swing = Swing;

	ProcessEvent(p_MC Swing Montage, &parms);
}

void AA_Tool_Base_C::Reset Combo(){

	static UObject* p_Reset Combo = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Reset Combo");

	struct {
	} parms;


	ProcessEvent(p_Reset Combo, &parms);
}

void AA_Tool_Base_C::Saved Attack(){

	static UObject* p_Saved Attack = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Saved Attack");

	struct {
	} parms;


	ProcessEvent(p_Saved Attack, &parms);
}

void AA_Tool_Base_C::Swing Montage(int32_t Swing){

	static UObject* p_Swing Montage = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Montage");

	struct {
		int32_t Swing;
	} parms;

	parms.Swing = Swing;

	ProcessEvent(p_Swing Montage, &parms);
}

void AA_Tool_Base_C::SRV Swing Montage(int32_t Swing){

	static UObject* p_SRV Swing Montage = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.SRV Swing Montage");

	struct {
		int32_t Swing;
	} parms;

	parms.Swing = Swing;

	ProcessEvent(p_SRV Swing Montage, &parms);
}

void AA_Tool_Base_C::Swing Audio(){

	static UObject* p_Swing Audio = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Audio");

	struct {
	} parms;


	ProcessEvent(p_Swing Audio, &parms);
}

void AA_Tool_Base_C::Main Fire(){

	static UObject* p_Main Fire = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Main Fire");

	struct {
	} parms;


	ProcessEvent(p_Main Fire, &parms);
}

void AA_Tool_Base_C::Continue Combo(){

	static UObject* p_Continue Combo = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Continue Combo");

	struct {
	} parms;


	ProcessEvent(p_Continue Combo, &parms);
}

void AA_Tool_Base_C::Auto Attack(){

	static UObject* p_Auto Attack = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Auto Attack");

	struct {
	} parms;


	ProcessEvent(p_Auto Attack, &parms);
}

void AA_Tool_Base_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AA_Tool_Base_C::ExecuteUbergraph_A_Tool_1H_Weapon(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_A_Tool_1H_Weapon = UObject::FindObject<UFunction>("Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.ExecuteUbergraph_A_Tool_1H_Weapon");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_A_Tool_1H_Weapon, &parms);
}

