#include "SDK.h" 
 
 
struct UWBP_CameraControl_C* ABP_SmartTV_C::GetTargetWidget(){

	static UObject* p_GetTargetWidget = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.GetTargetWidget");

	struct {
		struct UWBP_CameraControl_C* return_value;
	} parms;


	ProcessEvent(p_GetTargetWidget, &parms);
	return parms.return_value;
}

struct UMaterialInstanceDynamic* ABP_SmartTV_C::GetWidgetMaterial(){

	static UObject* p_GetWidgetMaterial = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.GetWidgetMaterial");

	struct {
		struct UMaterialInstanceDynamic* return_value;
	} parms;


	ProcessEvent(p_GetWidgetMaterial, &parms);
	return parms.return_value;
}

bool ABP_SmartTV_C::IsLocalPlayer(struct UObject* ActorReference){

	static UObject* p_IsLocalPlayer = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.IsLocalPlayer");

	struct {
		struct UObject* ActorReference;
		bool return_value;
	} parms;

	parms.ActorReference = ActorReference;

	ProcessEvent(p_IsLocalPlayer, &parms);
	return parms.return_value;
}

bool ABP_SmartTV_C::IsInRenderCameraArea(struct UBP_CameraCaptureComponent_C* ContestantCaptureComponent){

	static UObject* p_IsInRenderCameraArea = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.IsInRenderCameraArea");

	struct {
		struct UBP_CameraCaptureComponent_C* ContestantCaptureComponent;
		bool return_value;
	} parms;

	parms.ContestantCaptureComponent = ContestantCaptureComponent;

	ProcessEvent(p_IsInRenderCameraArea, &parms);
	return parms.return_value;
}

void ABP_SmartTV_C::OnWatchingCameraStatusChanged(bool IsCapturing){

	static UObject* p_OnWatchingCameraStatusChanged = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.OnWatchingCameraStatusChanged");

	struct {
		bool IsCapturing;
	} parms;

	parms.IsCapturing = IsCapturing;

	ProcessEvent(p_OnWatchingCameraStatusChanged, &parms);
}

void ABP_SmartTV_C::GetCameraSources(struct TArray<struct AActor*>& OutActors){

	static UObject* p_GetCameraSources = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.GetCameraSources");

	struct {
		struct TArray<struct AActor*>& OutActors;
	} parms;

	parms.OutActors = OutActors;

	ProcessEvent(p_GetCameraSources, &parms);
}

void ABP_SmartTV_C::ChangeCameraCaptureSource(){

	static UObject* p_ChangeCameraCaptureSource = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.ChangeCameraCaptureSource");

	struct {
	} parms;


	ProcessEvent(p_ChangeCameraCaptureSource, &parms);
}

void ABP_SmartTV_C::SetWatchingCameraComponent(struct UBP_CameraCaptureComponent_C* ContestantWatchingCamera){

	static UObject* p_SetWatchingCameraComponent = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.SetWatchingCameraComponent");

	struct {
		struct UBP_CameraCaptureComponent_C* ContestantWatchingCamera;
	} parms;

	parms.ContestantWatchingCamera = ContestantWatchingCamera;

	ProcessEvent(p_SetWatchingCameraComponent, &parms);
}

void ABP_SmartTV_C::InitializeControlCamera(){

	static UObject* p_InitializeControlCamera = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.InitializeControlCamera");

	struct {
	} parms;


	ProcessEvent(p_InitializeControlCamera, &parms);
}

void ABP_SmartTV_C::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

void ABP_SmartTV_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_SmartTV_C::CheckRenderAreaOverlap(struct AActor* OverlappedActor){

	static UObject* p_CheckRenderAreaOverlap = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.CheckRenderAreaOverlap");

	struct {
		struct AActor* OverlappedActor;
	} parms;

	parms.OverlappedActor = OverlappedActor;

	ProcessEvent(p_CheckRenderAreaOverlap, &parms);
}

void ABP_SmartTV_C::BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult){

	static UObject* p_BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature");

	struct {
		struct UPrimitiveComponent* OverlappedComponent;
		struct AActor* OtherActor;
		struct UPrimitiveComponent* OtherComp;
		int32_t OtherBodyIndex;
		bool bFromSweep;
		struct FHitResult& SweepResult;
	} parms;

	parms.OverlappedComponent = OverlappedComponent;
	parms.OtherActor = OtherActor;
	parms.OtherComp = OtherComp;
	parms.OtherBodyIndex = OtherBodyIndex;
	parms.bFromSweep = bFromSweep;
	parms.SweepResult = SweepResult;

	ProcessEvent(p_BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature, &parms);
}

void ABP_SmartTV_C::OnEndOverlappedRenderArea(struct AActor* EndOverlappedActor){

	static UObject* p_OnEndOverlappedRenderArea = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.OnEndOverlappedRenderArea");

	struct {
		struct AActor* EndOverlappedActor;
	} parms;

	parms.EndOverlappedActor = EndOverlappedActor;

	ProcessEvent(p_OnEndOverlappedRenderArea, &parms);
}

void ABP_SmartTV_C::BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex){

	static UObject* p_BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature");

	struct {
		struct UPrimitiveComponent* OverlappedComponent;
		struct AActor* OtherActor;
		struct UPrimitiveComponent* OtherComp;
		int32_t OtherBodyIndex;
	} parms;

	parms.OverlappedComponent = OverlappedComponent;
	parms.OtherActor = OtherActor;
	parms.OtherComp = OtherComp;
	parms.OtherBodyIndex = OtherBodyIndex;

	ProcessEvent(p_BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature, &parms);
}

void ABP_SmartTV_C::ExecuteUbergraph_BP_ControlCamera(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_ControlCamera = UObject::FindObject<UFunction>("Function BP_ControlCamera.BP_ControlCamera_C.ExecuteUbergraph_BP_ControlCamera");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_ControlCamera, &parms);
}

