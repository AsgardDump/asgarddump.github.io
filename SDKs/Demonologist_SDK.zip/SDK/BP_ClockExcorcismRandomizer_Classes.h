#pragma once 
#include <BP_ClockExcorcismRandomizer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C
// Size: 0x360(Inherited: 0x348) 
struct ABP_ClockExcorcismRandomizer_C : public ABP_ObjectiveRandomizer_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x348(0x8)
	double CorrectHour;  // 0x350(0x8)
	double CorrectMinute;  // 0x358(0x8)

	bool CheckClocks(); // Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.CheckClocks
	struct UBP_QuestManager_C* GetQuestManager(); // Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.GetQuestManager
	void RunRandomization(); // Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.RunRandomization
	void CheckClockTimer(); // Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.CheckClockTimer
	void PlayExcorcismSound(); // Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.PlayExcorcismSound
	void ExecuteUbergraph_BP_ClockExcorcismRandomizer(int32_t EntryPoint); // Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.ExecuteUbergraph_BP_ClockExcorcismRandomizer
}; 



