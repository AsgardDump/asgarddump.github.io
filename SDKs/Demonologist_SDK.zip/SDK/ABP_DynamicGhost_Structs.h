#pragma once 
#include "SDK.h" 
 
 
// Function ABP_DynamicGhost.ABP_DynamicGhost_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_DynamicGhost.ABP_DynamicGhost_C.ExecuteUbergraph_ABP_DynamicGhost
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_DynamicGhost
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// ScriptStruct ABP_DynamicGhost.ABP_DynamicGhost_C.AnimBlueprintGeneratedConstantData
// Size: 0x118(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_14;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool __BoolProperty_15 : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float __FloatProperty_16;  // 0x10(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_17;  // 0x14(0x2C)
	float __FloatProperty_18;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool __BoolProperty_19 : 1;  // 0x44(0x1)
	uint8_t  __EnumProperty_20;  // 0x45(0x1)
	char EAnimGroupRole __ByteProperty_21;  // 0x46(0x1)
	char pad_71[1];  // 0x47(0x1)
	struct FName __NameProperty_22;  // 0x48(0x8)
	struct FName __NameProperty_23;  // 0x50(0x8)
	int32_t __IntProperty_24;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FAnimNodeFunctionRef __StructProperty_25;  // 0x60(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x80(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x100(0x18)

}; 
// ScriptStruct ABP_DynamicGhost.ABP_DynamicGhost_C.AnimBlueprintGeneratedMutableData
// Size: 0x8(Inherited: 0x1) 
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
	char pad_1[3];  // 0x1(0x3)
	float __FloatProperty;  // 0x4(0x4)

}; 
