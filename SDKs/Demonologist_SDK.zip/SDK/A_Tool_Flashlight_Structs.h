#pragma once 
#include "SDK.h" 
 
 
// Function A_Tool_Flashlight.A_Tool_Flashlight_C.ExecuteUbergraph_A_Tool_Flashlight
// Size: 0x52(Inherited: 0x0) 
struct FExecuteUbergraph_A_Tool_Flashlight
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x8(0x18)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x20(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x38(0x8)
	struct TScriptInterface<IBPI_CharacterCustomizer_C> K2Node_DynamicCast_AsBPI_Character_Customizer;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x51(0x1)

}; 
