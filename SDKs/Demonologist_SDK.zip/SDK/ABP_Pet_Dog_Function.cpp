#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_Pet_Dog.ABP_Pet_Dog_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::BlueprintThreadSafeUpdateAnimation(float DeltaTime){

	static UObject* p_BlueprintThreadSafeUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_Pet_Dog.ABP_Pet_Dog_C.BlueprintThreadSafeUpdateAnimation");

	struct {
		float DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_BlueprintThreadSafeUpdateAnimation, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_14AF982249037F96917F418E6828B712(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_14AF982249037F96917F418E6828B712 = UObject::FindObject<UFunction>("Function ABP_Pet_Dog.ABP_Pet_Dog_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_14AF982249037F96917F418E6828B712");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_14AF982249037F96917F418E6828B712, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_FE233A2241EF532F702DFA91C2B55089(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_FE233A2241EF532F702DFA91C2B55089 = UObject::FindObject<UFunction>("Function ABP_Pet_Dog.ABP_Pet_Dog_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_FE233A2241EF532F702DFA91C2B55089");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_FE233A2241EF532F702DFA91C2B55089, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_Pet_Dog(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_Pet_Dog = UObject::FindObject<UFunction>("Function ABP_Pet_Dog.ABP_Pet_Dog_C.ExecuteUbergraph_ABP_Pet_Dog");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_Pet_Dog, &parms);
}

