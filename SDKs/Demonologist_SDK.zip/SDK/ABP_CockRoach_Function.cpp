#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_CockRoach.ABP_CockRoach_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_CockRoach(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_CockRoach = UObject::FindObject<UFunction>("Function ABP_CockRoach.ABP_CockRoach_C.ExecuteUbergraph_ABP_CockRoach");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_CockRoach, &parms);
}

