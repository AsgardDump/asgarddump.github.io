#include "SDK.h" 
 
 
void UInterface::SetTriggerParameter(struct FName InName){

	static UObject* p_SetTriggerParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetTriggerParameter");

	struct {
		struct FName InName;
	} parms;

	parms.InName = InName;

	ProcessEvent(p_SetTriggerParameter, &parms);
}

void UInterface::SetStringParameter(struct FName InName, struct FString InValue){

	static UObject* p_SetStringParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetStringParameter");

	struct {
		struct FName InName;
		struct FString InValue;
	} parms;

	parms.InName = InName;
	parms.InValue = InValue;

	ProcessEvent(p_SetStringParameter, &parms);
}

void UInterface::SetStringArrayParameter(struct FName InName, struct TArray<struct FString>& InValue){

	static UObject* p_SetStringArrayParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetStringArrayParameter");

	struct {
		struct FName InName;
		struct TArray<struct FString>& InValue;
	} parms;

	parms.InName = InName;
	parms.InValue = InValue;

	ProcessEvent(p_SetStringArrayParameter, &parms);
}

void UInterface::SetParameters_Blueprint(struct TArray<struct FAudioParameter>& InParameters){

	static UObject* p_SetParameters_Blueprint = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetParameters_Blueprint");

	struct {
		struct TArray<struct FAudioParameter>& InParameters;
	} parms;

	parms.InParameters = InParameters;

	ProcessEvent(p_SetParameters_Blueprint, &parms);
}

void UInterface::SetObjectParameter(struct FName InName, struct UObject* InValue){

	static UObject* p_SetObjectParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetObjectParameter");

	struct {
		struct FName InName;
		struct UObject* InValue;
	} parms;

	parms.InName = InName;
	parms.InValue = InValue;

	ProcessEvent(p_SetObjectParameter, &parms);
}

void UInterface::SetObjectArrayParameter(struct FName InName, struct TArray<struct UObject*>& InValue){

	static UObject* p_SetObjectArrayParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetObjectArrayParameter");

	struct {
		struct FName InName;
		struct TArray<struct UObject*>& InValue;
	} parms;

	parms.InName = InName;
	parms.InValue = InValue;

	ProcessEvent(p_SetObjectArrayParameter, &parms);
}

void UInterface::SetIntParameter(struct FName InName, int32_t inInt){

	static UObject* p_SetIntParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetIntParameter");

	struct {
		struct FName InName;
		int32_t inInt;
	} parms;

	parms.InName = InName;
	parms.inInt = inInt;

	ProcessEvent(p_SetIntParameter, &parms);
}

void UInterface::SetIntArrayParameter(struct FName InName, struct TArray<int32_t>& InValue){

	static UObject* p_SetIntArrayParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetIntArrayParameter");

	struct {
		struct FName InName;
		struct TArray<int32_t>& InValue;
	} parms;

	parms.InName = InName;
	parms.InValue = InValue;

	ProcessEvent(p_SetIntArrayParameter, &parms);
}

void UInterface::SetFloatParameter(struct FName InName, float InFloat){

	static UObject* p_SetFloatParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetFloatParameter");

	struct {
		struct FName InName;
		float InFloat;
	} parms;

	parms.InName = InName;
	parms.InFloat = InFloat;

	ProcessEvent(p_SetFloatParameter, &parms);
}

void UInterface::SetFloatArrayParameter(struct FName InName, struct TArray<float>& InValue){

	static UObject* p_SetFloatArrayParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetFloatArrayParameter");

	struct {
		struct FName InName;
		struct TArray<float>& InValue;
	} parms;

	parms.InName = InName;
	parms.InValue = InValue;

	ProcessEvent(p_SetFloatArrayParameter, &parms);
}

void UInterface::SetBoolParameter(struct FName InName, bool InBool){

	static UObject* p_SetBoolParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetBoolParameter");

	struct {
		struct FName InName;
		bool InBool;
	} parms;

	parms.InName = InName;
	parms.InBool = InBool;

	ProcessEvent(p_SetBoolParameter, &parms);
}

void UInterface::SetBoolArrayParameter(struct FName InName, struct TArray<bool>& InValue){

	static UObject* p_SetBoolArrayParameter = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.SetBoolArrayParameter");

	struct {
		struct FName InName;
		struct TArray<bool>& InValue;
	} parms;

	parms.InName = InName;
	parms.InValue = InValue;

	ProcessEvent(p_SetBoolArrayParameter, &parms);
}

void UInterface::ResetParameters(){

	static UObject* p_ResetParameters = UObject::FindObject<UFunction>("Function AudioExtensions.AudioParameterControllerInterface.ResetParameters");

	struct {
	} parms;


	ProcessEvent(p_ResetParameters, &parms);
}

