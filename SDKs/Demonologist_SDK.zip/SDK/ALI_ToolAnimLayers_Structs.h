#pragma once 
#include "SDK.h" 
 
 
// Function ALI_ToolAnimLayers.ALI_ToolAnimLayers_C.IdleState
// Size: 0x10(Inherited: 0x0) 
struct FIdleState
{
	struct FPoseLink IdleState;  // 0x0(0x10)

}; 
// Function ALI_ToolAnimLayers.ALI_ToolAnimLayers_C.WalkingState
// Size: 0x10(Inherited: 0x0) 
struct FWalkingState
{
	struct FPoseLink WalkingState;  // 0x0(0x10)

}; 
