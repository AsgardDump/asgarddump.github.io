#pragma once 
#include "SDK.h" 
 
 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.MC Swing Montage
// Size: 0x4(Inherited: 0x0) 
struct FMC Swing Montage
{
	int32_t Swing;  // 0x0(0x4)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Attack Combo
// Size: 0x10(Inherited: 0x4) 
struct FAttack Combo : public FAttack Combo
{
	int32_t Count;  // 0x0(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x4(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool Temp_bool_Variable : 1;  // 0x5(0x1)
	int32_t CallFunc_RandomIntegerInRange_ReturnValue;  // 0x8(0x4)
	int32_t K2Node_Select_Default;  // 0xC(0x4)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.ExecuteUbergraph_A_Tool_1H_Weapon
// Size: 0x4C0(Inherited: 0x0) 
struct FExecuteUbergraph_A_Tool_1H_Weapon
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FRotator CallFunc_Trace_Angle_ReturnValue;  // 0x8(0x18)
	double Temp_real_Variable;  // 0x20(0x8)
	double Temp_real_Variable_2;  // 0x28(0x8)
	int32_t Temp_int_Variable;  // 0x30(0x4)
	int32_t Temp_int_Variable_2;  // 0x34(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x38(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x40(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct APawn* K2Node_DynamicCast_AsPawn_2;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x61(0x1)
	char pad_98_1 : 7;  // 0x62(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x62(0x1)
	char pad_99[1];  // 0x63(0x1)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x64(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x74(0x4)
	double Temp_real_Variable_3;  // 0x78(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x80(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x90(0x8)
	int32_t Temp_int_Variable_3;  // 0x98(0x4)
	char ENetRole CallFunc_GetLocalRole_ReturnValue;  // 0x9C(0x1)
	char pad_157[3];  // 0x9D(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xA8(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_2;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0xAA(0x1)
	char pad_171_1 : 7;  // 0xAB(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0xAB(0x1)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // 0xB0(0x8)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_3;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_6;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_5 : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	struct APawn* K2Node_DynamicCast_AsPawn_3;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0xD8(0x1)
	char pad_217_1 : 7;  // 0xD9(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0xD9(0x1)
	char pad_218_1 : 7;  // 0xDA(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_6 : 1;  // 0xDA(0x1)
	char pad_219[5];  // 0xDB(0x5)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0xE0(0x8)
	struct AController* CallFunc_GetController_ReturnValue;  // 0xE8(0x8)
	struct FName Temp_name_Variable;  // 0xF0(0x8)
	struct FVector K2Node_CustomEvent_Location;  // 0xF8(0x18)
	struct FVector K2Node_CustomEvent_Half_Size;  // 0x110(0x18)
	struct FRotator K2Node_CustomEvent_Orientation;  // 0x128(0x18)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0x140(0x1)
	char pad_321[3];  // 0x141(0x3)
	int32_t K2Node_CustomEvent_Swing_3;  // 0x144(0x4)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_2;  // 0x148(0x8)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x150(0x10)
	struct TArray<struct FHitResult> CallFunc_BoxTraceMulti_OutHits;  // 0x160(0x10)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_BoxTraceMulti_ReturnValue : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	struct TArray<struct FHitResult> CallFunc_Hit_Check_Valid_Hits;  // 0x178(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x188(0x4)
	char pad_396_1 : 7;  // 0x18C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x18C(0x1)
	char pad_397_1 : 7;  // 0x18D(0x1)
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // 0x18D(0x1)
	char pad_398[2];  // 0x18E(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x190(0x4)
	char pad_404[4];  // 0x194(0x4)
	struct FVector CallFunc_Trace_Vector_ReturnValue;  // 0x198(0x18)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x1B0(0xE8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x298(0x1)
	char pad_665_1 : 7;  // 0x299(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x299(0x1)
	char pad_666[2];  // 0x29A(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x29C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x2A8(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x2C0(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x2D8(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x2F0(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x308(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x310(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x318(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x320(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x328(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x330(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x334(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x340(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x358(0x18)
	struct FVector CallFunc_Trace_Vector_ReturnValue_2;  // 0x370(0x18)
	int32_t K2Node_CustomEvent_Swing_2;  // 0x388(0x4)
	int32_t K2Node_CustomEvent_Swing;  // 0x38C(0x4)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x390(0x8)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x398(0x18)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x3B0(0x4)
	char pad_948_1 : 7;  // 0x3B4(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x3B4(0x1)
	char pad_949[3];  // 0x3B5(0x3)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_3;  // 0x3B8(0x8)
	struct UCombat_C* CallFunc_Combat_Component_ReturnValue;  // 0x3C0(0x8)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue_2;  // 0x3C8(0x18)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x3E0(0x10)
	double K2Node_Select_Default;  // 0x3F0(0x8)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x3F8(0x8)
	struct USkeletalMeshComponent* CallFunc_Character_Mesh_Mesh;  // 0x400(0x8)
	struct UAnimMontage* K2Node_Select_Default_2;  // 0x408(0x8)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x410(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x418(0x10)
	char pad_1064_1 : 7;  // 0x428(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x428(0x1)
	char pad_1065[3];  // 0x429(0x3)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x42C(0x8)
	char pad_1076[4];  // 0x434(0x4)
	struct USoundBase* K2Node_Select_Default_3;  // 0x438(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x440(0x18)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x458(0x10)
	int32_t Temp_int_Variable_4;  // 0x468(0x4)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x46C(0x8)
	char pad_1140[4];  // 0x474(0x4)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_4;  // 0x478(0x8)
	struct TScriptInterface<IBPI_CharacterCustomizer_C> K2Node_DynamicCast_AsBPI_Character_Customizer;  // 0x480(0x10)
	char pad_1168_1 : 7;  // 0x490(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x490(0x1)
	char pad_1169[3];  // 0x491(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x494(0x10)
	char pad_1188[4];  // 0x4A4(0x4)
	struct FRotator CallFunc_Trace_Angle_ReturnValue_2;  // 0x4A8(0x18)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Distance Check
// Size: 0x279(Inherited: 0x0) 
struct FDistance Check
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Target In Proximity : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool In Proximity : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x10(0x8)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_2;  // 0x18(0x8)
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // 0x20(0x18)
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // 0x38(0x10)
	struct FVector CallFunc_Multiply_VectorInt_ReturnValue;  // 0x48(0x18)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x60(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x78(0x18)
	struct TArray<struct FHitResult> CallFunc_SphereTraceMulti_OutHits;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool CallFunc_SphereTraceMulti_ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[3];  // 0xA1(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA4(0x4)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)
	struct FHitResult CallFunc_Array_Get_Item;  // 0xB0(0xE8)
	char pad_408_1 : 7;  // 0x198(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x198(0x1)
	char pad_409_1 : 7;  // 0x199(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x199(0x1)
	char pad_410[2];  // 0x19A(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x19C(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1A0(0x4)
	char pad_420[4];  // 0x1A4(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x1A8(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x1C0(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x1D8(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x1F0(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x208(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x210(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x218(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x220(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x228(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x230(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x234(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x238(0x4)
	char pad_572[4];  // 0x23C(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x240(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x258(0x18)
	struct UCombat_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x278(0x1)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_D8FB08CA49198DE439D2FCA751AFAA00
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnCompleted_D8FB08CA49198DE439D2FCA751AFAA00
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_D8FB08CA49198DE439D2FCA751AFAA00
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_D8FB08CA49198DE439D2FCA751AFAA00
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_D8FB08CA49198DE439D2FCA751AFAA00
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.OnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_D8FB08CA49198DE439D2FCA751AFAA00
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.SRV Swing Montage
// Size: 0x4(Inherited: 0x0) 
struct FSRV Swing Montage
{
	int32_t Swing;  // 0x0(0x4)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Montage
// Size: 0x4(Inherited: 0x0) 
struct FSwing Montage
{
	int32_t Swing;  // 0x0(0x4)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Swing Trace
// Size: 0x48(Inherited: 0x0) 
struct FSwing Trace
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector Half Size;  // 0x18(0x18)
	struct FRotator Orientation;  // 0x30(0x18)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Trace Angle
// Size: 0x68(Inherited: 0x0) 
struct FTrace Angle
{
	struct FRotator Offset;  // 0x0(0x18)
	struct FRotator ReturnValue;  // 0x18(0x18)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x30(0x8)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x38(0x18)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x50(0x18)

}; 
// Function A_Tool_1H_Weapon.A_Tool_1H_Weapon_C.Trace Vector
// Size: 0x110(Inherited: 0x0) 
struct FTrace Vector
{
	double Forward;  // 0x0(0x8)
	double Up;  // 0x8(0x8)
	double Right;  // 0x10(0x8)
	struct FVector ReturnValue;  // 0x18(0x18)
	struct FVector CallFunc_Root_Bone_Vectors_Forward_Vector;  // 0x30(0x18)
	struct FVector CallFunc_Root_Bone_Vectors_Right_Vector;  // 0x48(0x18)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x60(0x18)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // 0x78(0x18)
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue_2;  // 0x90(0x18)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0xA8(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0xB0(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xC8(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0xE0(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_3;  // 0xF8(0x18)

}; 
