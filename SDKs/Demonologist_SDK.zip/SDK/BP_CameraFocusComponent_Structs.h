#pragma once 
#include "SDK.h" 
 
 
// Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.OnFocusUpdated__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnFocusUpdated__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsFocused : 1;  // 0x0(0x1)

}; 
// Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.GetIsPlayerDead
// Size: 0x22(Inherited: 0x0) 
struct FGetIsPlayerDead
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APawn* CallFunc_GetPlayerPawn_ReturnValue;  // 0x8(0x8)
	struct TScriptInterface<IBPI_GamePlayerState_C> K2Node_DynamicCast_AsBPI_Game_Player_State;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue : 1;  // 0x21(0x1)

}; 
// Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.OnTargetPlayerDied
// Size: 0x1A(Inherited: 0x0) 
struct FOnTargetPlayerDied
{
	struct ABP_Shivers_InGamePlayerState_C* PlayerState;  // 0x0(0x8)
	struct TScriptInterface<IBPI_GamePlayerState_C> K2Node_DynamicCast_AsBPI_Game_Player_State;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdatePlayerVisibilities
// Size: 0x13D(Inherited: 0x0) 
struct FUpdatePlayerVisibilities
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsFocused : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_BasePlayerCharacter_C* NextBasePlayer;  // 0x8(0x8)
	struct ABaseShiversController* BaseShiversController;  // 0x10(0x8)
	struct FString CallFunc_MakeLiteralString_ReturnValue;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_MakeLiteralBool_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x30(0x10)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_2;  // 0x48(0x10)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct FString CallFunc_Concat_StrStr_ReturnValue_3;  // 0x60(0x10)
	struct FString CallFunc_SelectString_ReturnValue;  // 0x70(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x80(0x4)
	char pad_132_1 : 7;  // 0x84(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x84(0x1)
	char pad_133[3];  // 0x85(0x3)
	struct TScriptInterface<IBPI_GamePlayerState_C> K2Node_DynamicCast_AsBPI_Game_Player_State;  // 0x88(0x10)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x98(0x1)
	char pad_153_1 : 7;  // 0x99(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue : 1;  // 0x99(0x1)
	char pad_154[6];  // 0x9A(0x6)
	struct FString CallFunc_GetDisplayName_ReturnValue;  // 0xA0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_4;  // 0xB0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_5;  // 0xC0(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue_6;  // 0xD0(0x10)
	struct FString CallFunc_SelectString_ReturnValue_2;  // 0xE0(0x10)
	struct TScriptInterface<IBPI_GamePlayerState_C> K2Node_DynamicCast_AsBPI_Game_Player_State_2;  // 0xF0(0x10)
	char pad_256_1 : 7;  // 0x100(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x100(0x1)
	char pad_257_1 : 7;  // 0x101(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue_2 : 1;  // 0x101(0x1)
	char pad_258_1 : 7;  // 0x102(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x102(0x1)
	char pad_259[5];  // 0x103(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x108(0x8)
	struct TArray<struct ABP_BasePlayerCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x110(0x10)
	struct ABaseShiversController* K2Node_DynamicCast_AsBase_Shivers_Controller;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct ABP_BasePlayerCharacter_C* CallFunc_Array_Get_Item;  // 0x130(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x138(0x4)
	char pad_316_1 : 7;  // 0x13C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x13C(0x1)

}; 
// Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateCameraFocus
// Size: 0xC1(Inherited: 0x0) 
struct FUpdateCameraFocus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FocusCamera : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x10(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x18(0x10)
	struct ABP_Shivers_InGamePlayerState_C* K2Node_DynamicCast_AsBP_Shivers_in_Game_Player_State;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x38(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x40(0x8)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_3;  // 0x48(0x8)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue_2;  // 0x50(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // 0x58(0x8)
	struct ABP_BasePlayerCharacter_C* K2Node_DynamicCast_AsBP_Base_Player_Character;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x68(0x1)
	char pad_105_1 : 7;  // 0x69(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x69(0x1)
	char pad_106[6];  // 0x6A(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_4;  // 0x70(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x78(0x8)
	struct APawn* CallFunc_K2_GetPawn_ReturnValue_2;  // 0x80(0x8)
	struct ABP_BasePlayerCharacter_C* K2Node_DynamicCast_AsBP_Base_Player_Character_2;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x91(0x1)
	char pad_146[6];  // 0x92(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x98(0x8)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue_3;  // 0xA0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0xA8(0x10)
	struct ABP_Shivers_InGamePlayerState_C* K2Node_DynamicCast_AsBP_Shivers_in_Game_Player_State_2;  // 0xB8(0x8)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0xC0(0x1)

}; 
// Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateShowMouseCursor
// Size: 0x8(Inherited: 0x0) 
struct FUpdateShowMouseCursor
{
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x0(0x8)

}; 
// Function BP_CameraFocusComponent.BP_CameraFocusComponent_C.UpdateWorldVisibility
// Size: 0x5B(Inherited: 0x0) 
struct FUpdateWorldVisibility
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct ABP_BasePlayerCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x10(0x10)
	struct ABP_BasePlayerCharacter_C* CallFunc_Array_Get_Item;  // 0x20(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	struct TScriptInterface<IBPI_GamePlayerState_C> K2Node_DynamicCast_AsBPI_Game_Player_State;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x48(0x8)
	struct ABaseShiversController* K2Node_DynamicCast_AsBase_Shivers_Controller;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue_2 : 1;  // 0x5A(0x1)

}; 
