#include "SDK.h" 
 
 
void UBP_AiInteractionComponent_C::InitializeThrowableMeshes(){

	static UObject* p_InitializeThrowableMeshes = UObject::FindObject<UFunction>("Function BP_AiThrowableObject.BP_AiThrowableObject_C.InitializeThrowableMeshes");

	struct {
	} parms;


	ProcessEvent(p_InitializeThrowableMeshes, &parms);
}

struct TArray<struct UPrimitiveComponent*> UBP_AiInteractionComponent_C::GetThrowableItems(){

	static UObject* p_GetThrowableItems = UObject::FindObject<UFunction>("Function BP_AiThrowableObject.BP_AiThrowableObject_C.GetThrowableItems");

	struct {
		struct TArray<struct UPrimitiveComponent*> return_value;
	} parms;


	ProcessEvent(p_GetThrowableItems, &parms);
	return parms.return_value;
}

void UBP_AiInteractionComponent_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_AiThrowableObject.BP_AiThrowableObject_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void UBP_AiInteractionComponent_C::OnInteractionRequestedCallback(struct AActor* Instigator){

	static UObject* p_OnInteractionRequestedCallback = UObject::FindObject<UFunction>("Function BP_AiThrowableObject.BP_AiThrowableObject_C.OnInteractionRequestedCallback");

	struct {
		struct AActor* Instigator;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_OnInteractionRequestedCallback, &parms);
}

void UBP_AiInteractionComponent_C::ThrowableObjectInteractionMulticast(struct UObject* Instigator, struct FVector Impulse){

	static UObject* p_ThrowableObjectInteractionMulticast = UObject::FindObject<UFunction>("Function BP_AiThrowableObject.BP_AiThrowableObject_C.ThrowableObjectInteractionMulticast");

	struct {
		struct UObject* Instigator;
		struct FVector Impulse;
	} parms;

	parms.Instigator = Instigator;
	parms.Impulse = Impulse;

	ProcessEvent(p_ThrowableObjectInteractionMulticast, &parms);
}

void UBP_AiInteractionComponent_C::OnComponentHit_Event(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit){

	static UObject* p_OnComponentHit_Event = UObject::FindObject<UFunction>("Function BP_AiThrowableObject.BP_AiThrowableObject_C.OnComponentHit_Event");

	struct {
		struct UPrimitiveComponent* HitComponent;
		struct AActor* OtherActor;
		struct UPrimitiveComponent* OtherComp;
		struct FVector NormalImpulse;
		struct FHitResult& Hit;
	} parms;

	parms.HitComponent = HitComponent;
	parms.OtherActor = OtherActor;
	parms.OtherComp = OtherComp;
	parms.NormalImpulse = NormalImpulse;
	parms.Hit = Hit;

	ProcessEvent(p_OnComponentHit_Event, &parms);
}

void UBP_AiInteractionComponent_C::ExecuteUbergraph_BP_AiThrowableObject(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AiThrowableObject = UObject::FindObject<UFunction>("Function BP_AiThrowableObject.BP_AiThrowableObject_C.ExecuteUbergraph_BP_AiThrowableObject");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AiThrowableObject, &parms);
}

