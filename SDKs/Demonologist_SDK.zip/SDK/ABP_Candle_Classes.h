#pragma once 
#include <ABP_Candle_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Candle.ABP_Candle_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_Candle_C : public UABP_ToolLayerArms_C
{

}; 



