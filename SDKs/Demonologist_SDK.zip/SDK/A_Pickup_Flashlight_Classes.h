#pragma once 
#include <A_Pickup_Flashlight_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Pickup_Flashlight.A_Pickup_Flashlight_C
// Size: 0x2E0(Inherited: 0x2E0) 
struct AA_Pickup_Flashlight_C : public AA_Pickup_C
{

}; 



