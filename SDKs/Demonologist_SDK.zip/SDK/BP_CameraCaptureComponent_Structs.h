#pragma once 
#include "SDK.h" 
 
 
// Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.ExecuteUbergraph_BP_CameraCaptureComponent
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CameraCaptureComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)

}; 
// Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.SetCaptureEveryFrameStatus
// Size: 0x10(Inherited: 0x0) 
struct FSetCaptureEveryFrameStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CaptureEveryFrame : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct USceneCaptureComponent2D* CallFunc_GetSceneCaptureComponentReference_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.GetSceneCaptureComponentReference
// Size: 0x18(Inherited: 0x0) 
struct FGetSceneCaptureComponentReference
{
	struct USceneCaptureComponent2D* ReturnValue;  // 0x0(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct USceneCaptureComponent2D* CallFunc_GetComponentByClass_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.IsCapturing__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FIsCapturing__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsCapturing : 1;  // 0x0(0x1)

}; 
// Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
