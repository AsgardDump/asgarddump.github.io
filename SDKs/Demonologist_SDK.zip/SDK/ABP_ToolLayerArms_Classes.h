#pragma once 
#include <ABP_ToolLayerArms_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ToolLayerArms.ABP_ToolLayerArms_C
// Size: 0x720(Inherited: 0x350) 
struct UABP_ToolLayerArms_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x360(0x8)
	struct FAnimSubsystemInstance_NodeRelevancy AnimBlueprintExtension_NodeRelevancy;  // 0x368(0xA8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x410(0x8)
	struct FAnimNode_Root AnimGraphNode_Root_3;  // 0x418(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // 0x438(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x460(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x488(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x4B0(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x4F8(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x518(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x560(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x580(0xC8)
	struct FAnimNode_Root AnimGraphNode_Root_2;  // 0x648(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x668(0x48)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x6B0(0x20)
	struct UAnimInstance* K2Node_PropertyAccess_3;  // 0x6D0(0x8)
	struct UAnimSequenceBase* IdleSequence;  // 0x6D8(0x8)
	struct UAnimSequenceBase* IdleAimingSequence;  // 0x6E0(0x8)
	struct UAnimSequenceBase* WalkingSequence;  // 0x6E8(0x8)
	struct UAnimSequenceBase* WalkingAimingSequence;  // 0x6F0(0x8)
	struct UAnimSequenceBase* IdleBreakSequence;  // 0x6F8(0x8)
	double IdleBreakRemainingTime;  // 0x700(0x8)
	char pad_1800_1 : 7;  // 0x708(0x1)
	bool CanPlayIdleBreak : 1;  // 0x708(0x1)
	char pad_1801[7];  // 0x709(0x7)
	double IdleBreakDelayTime;  // 0x710(0x8)
	float WalkingBlendTime;  // 0x718(0x4)
	float IdleBlendTime;  // 0x71C(0x4)

	void IdleState(struct FPoseLink& IdleState); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.IdleState
	void WalkingState(struct FPoseLink& WalkingState); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.WalkingState
	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.AnimGraph
	void ProcessIdleBreakTransitionLogic(double DeltaTime); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ProcessIdleBreakTransitionLogic
	void OnIdleUpdate(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleUpdate
	void ResetIdleRemainingTime(); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ResetIdleRemainingTime
	void OnIdleBecomeRelevant(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleBecomeRelevant
	bool CanPlayBreakIdle(); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.CanPlayBreakIdle
	struct UABP_Base_Arms_C* GetMainAnimInstance(); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.GetMainAnimInstance
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.BlueprintThreadSafeUpdateAnimation
	void OnWalkingAnimationUpdated(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnWalkingAnimationUpdated
	void OnIdleAnimationUpdate(struct FAnimUpdateContext& Context, struct FAnimNodeReference& Node); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleAnimationUpdate
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_EEF859B344E32E43DAF57B9BF0AC2479(); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_EEF859B344E32E43DAF57B9BF0AC2479
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_F519701647874C45E44D3F9AD951152B(); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_ToolLayerArms_AnimGraphNode_TransitionResult_F519701647874C45E44D3F9AD951152B
	void ExecuteUbergraph_ABP_ToolLayerArms(int32_t EntryPoint); // Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ExecuteUbergraph_ABP_ToolLayerArms
}; 



