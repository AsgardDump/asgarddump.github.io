#include "SDK.h" 
 
 
bool AStaticMeshActor::CanMalfunction(){

	static UObject* p_CanMalfunction = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.CanMalfunction");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanMalfunction, &parms);
	return parms.return_value;
}

void AStaticMeshActor::InitiliazeBaseLight(){

	static UObject* p_InitiliazeBaseLight = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.InitiliazeBaseLight");

	struct {
	} parms;


	ProcessEvent(p_InitiliazeBaseLight, &parms);
}

bool AStaticMeshActor::GetIsLightActive(){

	static UObject* p_GetIsLightActive = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.GetIsLightActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsLightActive, &parms);
	return parms.return_value;
}

void AStaticMeshActor::OnRep_IsLightTurnOn(){

	static UObject* p_OnRep_IsLightTurnOn = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.OnRep_IsLightTurnOn");

	struct {
	} parms;


	ProcessEvent(p_OnRep_IsLightTurnOn, &parms);
}

void AStaticMeshActor::OnRep_IsLightBroken(){

	static UObject* p_OnRep_IsLightBroken = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.OnRep_IsLightBroken");

	struct {
	} parms;


	ProcessEvent(p_OnRep_IsLightBroken, &parms);
}

void AStaticMeshActor::GetIsLightTurnOn(bool& ReturnNode){

	static UObject* p_GetIsLightTurnOn = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.GetIsLightTurnOn");

	struct {
		bool& ReturnNode;
	} parms;

	parms.ReturnNode = ReturnNode;

	ProcessEvent(p_GetIsLightTurnOn, &parms);
}

void AStaticMeshActor::SetLightScenerio(struct FS_LightScenerio SelectedLightScenerio){

	static UObject* p_SetLightScenerio = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.SetLightScenerio");

	struct {
		struct FS_LightScenerio SelectedLightScenerio;
	} parms;

	parms.SelectedLightScenerio = SelectedLightScenerio;

	ProcessEvent(p_SetLightScenerio, &parms);
}

void AStaticMeshActor::OnRep_SelectedLightScenerio(){

	static UObject* p_OnRep_SelectedLightScenerio = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.OnRep_SelectedLightScenerio");

	struct {
	} parms;


	ProcessEvent(p_OnRep_SelectedLightScenerio, &parms);
}

void AStaticMeshActor::UpdateEmessiveMaterialValues(){

	static UObject* p_UpdateEmessiveMaterialValues = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.UpdateEmessiveMaterialValues");

	struct {
	} parms;


	ProcessEvent(p_UpdateEmessiveMaterialValues, &parms);
}

double AStaticMeshActor::GetTargetIntensity(){

	static UObject* p_GetTargetIntensity = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.GetTargetIntensity");

	struct {
		double return_value;
	} parms;


	ProcessEvent(p_GetTargetIntensity, &parms);
	return parms.return_value;
}

double AStaticMeshActor::GetLightIntensity(){

	static UObject* p_GetLightIntensity = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.GetLightIntensity");

	struct {
		double return_value;
	} parms;


	ProcessEvent(p_GetLightIntensity, &parms);
	return parms.return_value;
}

double AStaticMeshActor::GetTargetEmessivePower(double EmessivePercentage){

	static UObject* p_GetTargetEmessivePower = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.GetTargetEmessivePower");

	struct {
		double EmessivePercentage;
		double return_value;
	} parms;

	parms.EmessivePercentage = EmessivePercentage;

	ProcessEvent(p_GetTargetEmessivePower, &parms);
	return parms.return_value;
}

void AStaticMeshActor::ReplaceMaterialsWithDynamics(){

	static UObject* p_ReplaceMaterialsWithDynamics = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.ReplaceMaterialsWithDynamics");

	struct {
	} parms;


	ProcessEvent(p_ReplaceMaterialsWithDynamics, &parms);
}

void AStaticMeshActor::Set Light Turn Status(bool ActivationStatus, struct FName InstigatorIdentifier){

	static UObject* p_Set Light Turn Status = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.Set Light Turn Status");

	struct {
		bool ActivationStatus;
		struct FName InstigatorIdentifier;
	} parms;

	parms.ActivationStatus = ActivationStatus;
	parms.InstigatorIdentifier = InstigatorIdentifier;

	ProcessEvent(p_Set Light Turn Status, &parms);
}

void AStaticMeshActor::LightScenerio__FinishedFunc(){

	static UObject* p_LightScenerio__FinishedFunc = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.LightScenerio__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_LightScenerio__FinishedFunc, &parms);
}

void AStaticMeshActor::LightScenerio__UpdateFunc(){

	static UObject* p_LightScenerio__UpdateFunc = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.LightScenerio__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_LightScenerio__UpdateFunc, &parms);
}

void AStaticMeshActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AStaticMeshActor::SetLightScenerioServer(struct FS_LightScenerio LightScenerio){

	static UObject* p_SetLightScenerioServer = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.SetLightScenerioServer");

	struct {
		struct FS_LightScenerio LightScenerio;
	} parms;

	parms.LightScenerio = LightScenerio;

	ProcessEvent(p_SetLightScenerioServer, &parms);
}

void AStaticMeshActor::ChangeLightMode(struct FS_LightScenerio LightScenerio){

	static UObject* p_ChangeLightMode = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.ChangeLightMode");

	struct {
		struct FS_LightScenerio LightScenerio;
	} parms;

	parms.LightScenerio = LightScenerio;

	ProcessEvent(p_ChangeLightMode, &parms);
}

void AStaticMeshActor::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void AStaticMeshActor::StartMalfunction(struct FName Identifier){

	static UObject* p_StartMalfunction = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.StartMalfunction");

	struct {
		struct FName Identifier;
	} parms;

	parms.Identifier = Identifier;

	ProcessEvent(p_StartMalfunction, &parms);
}

void AStaticMeshActor::EndMalfunction(struct FName Identifier){

	static UObject* p_EndMalfunction = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.EndMalfunction");

	struct {
		struct FName Identifier;
	} parms;

	parms.Identifier = Identifier;

	ProcessEvent(p_EndMalfunction, &parms);
}

void AStaticMeshActor::ExecuteUbergraph_BP_BaseLight(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BaseLight = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.ExecuteUbergraph_BP_BaseLight");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BaseLight, &parms);
}

void AStaticMeshActor::OnLightBrokenStatusChanged__DelegateSignature(){

	static UObject* p_OnLightBrokenStatusChanged__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.OnLightBrokenStatusChanged__DelegateSignature");

	struct {
	} parms;


	ProcessEvent(p_OnLightBrokenStatusChanged__DelegateSignature, &parms);
}

void AStaticMeshActor::OnLightStatusChanged__DelegateSignature(bool IsActive){

	static UObject* p_OnLightStatusChanged__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BaseLight.BP_BaseLight_C.OnLightStatusChanged__DelegateSignature");

	struct {
		bool IsActive;
	} parms;

	parms.IsActive = IsActive;

	ProcessEvent(p_OnLightStatusChanged__DelegateSignature, &parms);
}

