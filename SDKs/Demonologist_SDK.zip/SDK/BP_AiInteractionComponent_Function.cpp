#include "SDK.h" 
 
 
struct UShapeComponent* UActorComponent::GetInteractionComponentByName(){

	static UObject* p_GetInteractionComponentByName = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.GetInteractionComponentByName");

	struct {
		struct UShapeComponent* return_value;
	} parms;


	ProcessEvent(p_GetInteractionComponentByName, &parms);
	return parms.return_value;
}

bool UActorComponent::CanInstigatorInteract(struct AActor* Instigator){

	static UObject* p_CanInstigatorInteract = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.CanInstigatorInteract");

	struct {
		struct AActor* Instigator;
		bool return_value;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_CanInstigatorInteract, &parms);
	return parms.return_value;
}

void UActorComponent::SetParametersWhenInteracted(){

	static UObject* p_SetParametersWhenInteracted = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.SetParametersWhenInteracted");

	struct {
	} parms;


	ProcessEvent(p_SetParametersWhenInteracted, &parms);
}

double UActorComponent::GetLastInteractedTime(){

	static UObject* p_GetLastInteractedTime = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.GetLastInteractedTime");

	struct {
		double return_value;
	} parms;


	ProcessEvent(p_GetLastInteractedTime, &parms);
	return parms.return_value;
}

void UActorComponent::InitializeAiInteractionComponent(){

	static UObject* p_InitializeAiInteractionComponent = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.InitializeAiInteractionComponent");

	struct {
	} parms;


	ProcessEvent(p_InitializeAiInteractionComponent, &parms);
}

void UActorComponent::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void UActorComponent::OnInteractionCollisionOverlapped(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult){

	static UObject* p_OnInteractionCollisionOverlapped = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.OnInteractionCollisionOverlapped");

	struct {
		struct UPrimitiveComponent* OverlappedComponent;
		struct AActor* OtherActor;
		struct UPrimitiveComponent* OtherComp;
		int32_t OtherBodyIndex;
		bool bFromSweep;
		struct FHitResult& SweepResult;
	} parms;

	parms.OverlappedComponent = OverlappedComponent;
	parms.OtherActor = OtherActor;
	parms.OtherComp = OtherComp;
	parms.OtherBodyIndex = OtherBodyIndex;
	parms.bFromSweep = bFromSweep;
	parms.SweepResult = SweepResult;

	ProcessEvent(p_OnInteractionCollisionOverlapped, &parms);
}

void UActorComponent::RequestAiInteraction(struct AActor* Instigator, bool UseCustomInteractionMethod){

	static UObject* p_RequestAiInteraction = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.RequestAiInteraction");

	struct {
		struct AActor* Instigator;
		bool UseCustomInteractionMethod;
	} parms;

	parms.Instigator = Instigator;
	parms.UseCustomInteractionMethod = UseCustomInteractionMethod;

	ProcessEvent(p_RequestAiInteraction, &parms);
}

void UActorComponent::ExecuteUbergraph_BP_AiInteractionComponent(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AiInteractionComponent = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.ExecuteUbergraph_BP_AiInteractionComponent");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AiInteractionComponent, &parms);
}

void UActorComponent::OnInteractionRequested__DelegateSignature(struct AActor* Instigator){

	static UObject* p_OnInteractionRequested__DelegateSignature = UObject::FindObject<UFunction>("Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.OnInteractionRequested__DelegateSignature");

	struct {
		struct AActor* Instigator;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_OnInteractionRequested__DelegateSignature, &parms);
}

