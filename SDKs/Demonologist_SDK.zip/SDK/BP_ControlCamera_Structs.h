#pragma once 
#include "SDK.h" 
 
 
// Function BP_ControlCamera.BP_ControlCamera_C.BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
// Size: 0x108(Inherited: 0x0) 
struct FBndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0xE8)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature
// Size: 0x1C(Inherited: 0x0) 
struct FBndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.CheckRenderAreaOverlap
// Size: 0x8(Inherited: 0x0) 
struct FCheckRenderAreaOverlap
{
	struct AActor* OverlappedActor;  // 0x0(0x8)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.ChangeCameraCaptureSource
// Size: 0x50(Inherited: 0x0) 
struct FChangeCameraCaptureSource
{
	struct TArray<struct AActor*> CallFunc_GetCameraSources_OutActors;  // 0x0(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x20(0x8)
	struct UBP_CameraCaptureComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x28(0x8)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x30(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AActor* CallFunc_Array_Get_Item_2;  // 0x40(0x8)
	struct UBP_CameraCaptureComponent_C* CallFunc_GetComponentByClass_ReturnValue_2;  // 0x48(0x8)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.ExecuteUbergraph_BP_ControlCamera
// Size: 0x390(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ControlCamera
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ABP_CCTV_C* CallFunc_GetActorOfClass_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct UBP_CameraCaptureComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x18(0x8)
	struct AActor* K2Node_CustomEvent_OverlappedActor;  // 0x20(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent_2;  // 0x28(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor_2;  // 0x30(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp_2;  // 0x38(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex_2;  // 0x40(0x4)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool K2Node_ComponentBoundEvent_bFromSweep : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FHitResult K2Node_ComponentBoundEvent_SweepResult;  // 0x48(0xE8)
	struct UBP_CameraCaptureComponent_C* CallFunc_GetComponentByClass_ReturnValue_2;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x139(0x1)
	char pad_314_1 : 7;  // 0x13A(0x1)
	bool CallFunc_IsLocalPlayer_ReturnValue : 1;  // 0x13A(0x1)
	char pad_315[5];  // 0x13B(0x5)
	struct AActor* K2Node_CustomEvent_EndOverlappedActor;  // 0x140(0x8)
	struct TScriptInterface<IBPI_ShiversTool_C> K2Node_DynamicCast_AsBPI_Shivers_Tool;  // 0x148(0x10)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue : 1;  // 0x159(0x1)
	char pad_346[6];  // 0x15A(0x6)
	struct AActor* CallFunc_GetToolObjectInstigator_ReturnValue;  // 0x160(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool CallFunc_IsLocalPlayer_ReturnValue_2 : 1;  // 0x168(0x1)
	char pad_361[7];  // 0x169(0x7)
	struct UBP_CameraCaptureComponent_C* CallFunc_GetComponentByClass_ReturnValue_3;  // 0x170(0x8)
	char pad_376_1 : 7;  // 0x178(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_2 : 1;  // 0x178(0x1)
	char pad_377_1 : 7;  // 0x179(0x1)
	bool CallFunc_IsLocalPlayer_ReturnValue_3 : 1;  // 0x179(0x1)
	char pad_378[6];  // 0x17A(0x6)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OverlappedComponent;  // 0x180(0x8)
	struct AActor* K2Node_ComponentBoundEvent_OtherActor;  // 0x188(0x8)
	struct UPrimitiveComponent* K2Node_ComponentBoundEvent_OtherComp;  // 0x190(0x8)
	int32_t K2Node_ComponentBoundEvent_OtherBodyIndex;  // 0x198(0x4)
	char pad_412_1 : 7;  // 0x19C(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x19C(0x1)
	char pad_413[3];  // 0x19D(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x1A0(0x8)
	struct TScriptInterface<IBPI_CameraCaptureTool_C> K2Node_DynamicCast_AsBPI_Camera_Capture_Tool;  // 0x1A8(0x10)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue_3 : 1;  // 0x1B9(0x1)
	char pad_442_1 : 7;  // 0x1BA(0x1)
	bool CallFunc_CanDisableCaptureWhenOutsideOfRenderArea_ReturnValue : 1;  // 0x1BA(0x1)
	char pad_443_1 : 7;  // 0x1BB(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x1BB(0x1)
	char pad_444[4];  // 0x1BC(0x4)
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x1C0(0xE8)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x2A8(0xE8)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.GetWidgetMaterial
// Size: 0x21(Inherited: 0x0) 
struct FGetWidgetMaterial
{
	struct UMaterialInstanceDynamic* ReturnValue;  // 0x0(0x8)
	struct UWBP_CameraControl_C* CallFunc_GetTargetWidget_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UMaterialInstanceDynamic* CallFunc_GetDynamicMaterial_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x20(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.GetTargetWidget
// Size: 0x19(Inherited: 0x0) 
struct FGetTargetWidget
{
	struct UWBP_CameraControl_C* ReturnValue;  // 0x0(0x8)
	struct UUserWidget* CallFunc_GetWidget_ReturnValue;  // 0x8(0x8)
	struct UWBP_CameraControl_C* K2Node_DynamicCast_AsWBP_Camera_Control;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.GetCameraSources
// Size: 0x53(Inherited: 0x0) 
struct FGetCameraSources
{
	struct TArray<struct AActor*> OutActors;  // 0x0(0x10)
	struct TArray<struct AActor*> ReflectedCameras;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllActorsWithTag_OutActors;  // 0x30(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x40(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x48(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue : 1;  // 0x51(0x1)
	char pad_82_1 : 7;  // 0x52(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x52(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.InitializeControlCamera
// Size: 0x11(Inherited: 0x0) 
struct FInitializeControlCamera
{
	struct UUserWidget* CallFunc_GetWidget_ReturnValue;  // 0x0(0x8)
	struct UWBP_CameraControl_C* K2Node_DynamicCast_AsWBP_Camera_Control;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.IsInRenderCameraArea
// Size: 0x59(Inherited: 0x0) 
struct FIsInRenderCameraArea
{
	struct UBP_CameraCaptureComponent_C* ContestantCaptureComponent;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TScriptInterface<IBPI_CameraCaptureTool_C> K2Node_DynamicCast_AsBPI_Camera_Capture_Tool;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_CanDisableCaptureWhenOutsideOfRenderArea_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59[5];  // 0x3B(0x5)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue_2;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue_2 : 1;  // 0x58(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.IsLocalPlayer
// Size: 0x19(Inherited: 0x0) 
struct FIsLocalPlayer
{
	struct UObject* ActorReference;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.SetWatchingCameraComponent
// Size: 0x52(Inherited: 0x0) 
struct FSetWatchingCameraComponent
{
	struct UBP_CameraCaptureComponent_C* ContestantWatchingCamera;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool CallFunc_IsInRenderCameraArea_ReturnValue : 1;  // 0x9(0x1)
	char pad_10[6];  // 0xA(0x6)
	struct UWBP_CameraControl_C* CallFunc_GetTargetWidget_ReturnValue;  // 0x10(0x8)
	struct TArray<struct AActor*> CallFunc_GetCameraSources_OutActors;  // 0x18(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x28(0x8)
	struct UMaterialInstanceDynamic* CallFunc_GetWidgetMaterial_ReturnValue;  // 0x30(0x8)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x38(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x3C(0x4)
	char CallFunc_Conv_IntToByte_ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct USceneCaptureComponent2D* CallFunc_GetSceneCaptureComponentReference_ReturnValue;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x50(0x1)
	char pad_81_1 : 7;  // 0x51(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x51(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.OnEndOverlappedRenderArea
// Size: 0x8(Inherited: 0x0) 
struct FOnEndOverlappedRenderArea
{
	struct AActor* EndOverlappedActor;  // 0x0(0x8)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.OnWatchingCameraStatusChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnWatchingCameraStatusChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsCapturing : 1;  // 0x0(0x1)

}; 
// Function BP_ControlCamera.BP_ControlCamera_C.UserConstructionScript
// Size: 0x1D0(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // 0x0(0xE8)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0xE8(0xE8)

}; 
