#pragma once 
#include <ABP_SaltGun_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SaltGun.ABP_SaltGun_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_SaltGun_C : public UABP_ToolLayerArms_C
{

}; 



