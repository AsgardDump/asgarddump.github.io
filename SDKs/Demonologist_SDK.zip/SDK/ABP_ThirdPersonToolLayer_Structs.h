#pragma once 
#include "SDK.h" 
 
 
// Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.ExecuteUbergraph_ABP_ThirdPersonToolLayer
// Size: 0x4(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_ThirdPersonToolLayer
{
	int32_t EntryPoint;  // 0x0(0x4)

}; 
// Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.BlueprintThreadSafeUpdateAnimation
// Size: 0x11(Inherited: 0x4) 
struct FBlueprintThreadSafeUpdateAnimation : public FBlueprintThreadSafeUpdateAnimation
{
	float DeltaTime;  // 0x0(0x4)
	double CallFunc_VSize_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.BaseState
// Size: 0x20(Inherited: 0x0) 
struct FBaseState
{
	struct FPoseLink BaseAnimation;  // 0x0(0x10)
	struct FPoseLink BaseState;  // 0x10(0x10)

}; 
// ScriptStruct ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.AnimBlueprintGeneratedConstantData
// Size: 0x150(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_76;  // 0x4(0x8)
	struct FName __NameProperty_77;  // 0xC(0x8)
	int32_t __IntProperty_78;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool __BoolProperty_79 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float __FloatProperty_80;  // 0x1C(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_81;  // 0x20(0x2C)
	float __FloatProperty_82;  // 0x4C(0x4)
	uint8_t  __EnumProperty_83;  // 0x50(0x1)
	char EAnimGroupRole __ByteProperty_84;  // 0x51(0x1)
	char pad_82[2];  // 0x52(0x2)
	struct FName __NameProperty_85;  // 0x54(0x8)
	int32_t __IntProperty_86;  // 0x5C(0x4)
	struct UBlendProfile* __BlendProfile_87;  // 0x60(0x8)
	struct UCurveFloat* __CurveFloat_88;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool __BoolProperty_89 : 1;  // 0x70(0x1)
	uint8_t  __EnumProperty_90;  // 0x71(0x1)
	uint8_t  __EnumProperty_91;  // 0x72(0x1)
	char pad_115[5];  // 0x73(0x5)
	struct TArray<float> __ArrayProperty_92;  // 0x78(0x10)
	struct FAnimNodeFunctionRef __StructProperty_93;  // 0x88(0x20)
	struct FName __NameProperty_94;  // 0xA8(0x8)
	struct FName __NameProperty_95;  // 0xB0(0x8)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0xB8(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x138(0x18)

}; 
// ScriptStruct ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.AnimBlueprintGeneratedMutableData
// Size: 0x2(Inherited: 0x1) 
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool __BoolProperty : 1;  // 0x1(0x1)

}; 
