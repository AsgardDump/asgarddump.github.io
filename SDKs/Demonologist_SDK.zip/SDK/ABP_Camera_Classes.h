#pragma once 
#include <ABP_Camera_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Camera.ABP_Camera_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_Camera_C : public UABP_ToolLayerArms_C
{

}; 



