#pragma once 
#include <ABP_TarotCard_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_TarotCard.ABP_TarotCard_C
// Size: 0x559(Inherited: 0x350) 
struct UABP_TarotCard_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;  // 0x358(0x2)
	char pad_858[6];  // 0x35A(0x6)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x360(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x368(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x370(0x20)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0x390(0x48)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x3D8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x420(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x440(0xC8)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x508(0x48)
	struct AActor* K2Node_PropertyAccess;  // 0x550(0x8)
	char pad_1368_1 : 7;  // 0x558(0x1)
	bool IsLocalInstigator : 1;  // 0x558(0x1)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_TarotCard.ABP_TarotCard_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_TarotCard.ABP_TarotCard_C.BlueprintThreadSafeUpdateAnimation
	void OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit); // Function ABP_TarotCard.ABP_TarotCard_C.OnObjectInstigatorUpdatedCallback
	void BlueprintBeginPlay(); // Function ABP_TarotCard.ABP_TarotCard_C.BlueprintBeginPlay
	void ExecuteUbergraph_ABP_TarotCard(int32_t EntryPoint); // Function ABP_TarotCard.ABP_TarotCard_C.ExecuteUbergraph_ABP_TarotCard
}; 



