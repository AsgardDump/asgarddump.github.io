#include "SDK.h" 
 
 
bool ABP_ObjectiveRandomizer_C::CheckClocks(){

	static UObject* p_CheckClocks = UObject::FindObject<UFunction>("Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.CheckClocks");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CheckClocks, &parms);
	return parms.return_value;
}

struct UBP_QuestManager_C* ABP_ObjectiveRandomizer_C::GetQuestManager(){

	static UObject* p_GetQuestManager = UObject::FindObject<UFunction>("Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.GetQuestManager");

	struct {
		struct UBP_QuestManager_C* return_value;
	} parms;


	ProcessEvent(p_GetQuestManager, &parms);
	return parms.return_value;
}

void ABP_ObjectiveRandomizer_C::RunRandomization(){

	static UObject* p_RunRandomization = UObject::FindObject<UFunction>("Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.RunRandomization");

	struct {
	} parms;


	ProcessEvent(p_RunRandomization, &parms);
}

void ABP_ObjectiveRandomizer_C::CheckClockTimer(){

	static UObject* p_CheckClockTimer = UObject::FindObject<UFunction>("Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.CheckClockTimer");

	struct {
	} parms;


	ProcessEvent(p_CheckClockTimer, &parms);
}

void ABP_ObjectiveRandomizer_C::PlayExcorcismSound(){

	static UObject* p_PlayExcorcismSound = UObject::FindObject<UFunction>("Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.PlayExcorcismSound");

	struct {
	} parms;


	ProcessEvent(p_PlayExcorcismSound, &parms);
}

void ABP_ObjectiveRandomizer_C::ExecuteUbergraph_BP_ClockExcorcismRandomizer(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_ClockExcorcismRandomizer = UObject::FindObject<UFunction>("Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.ExecuteUbergraph_BP_ClockExcorcismRandomizer");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_ClockExcorcismRandomizer, &parms);
}

