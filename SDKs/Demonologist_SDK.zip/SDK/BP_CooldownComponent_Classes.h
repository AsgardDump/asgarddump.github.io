#pragma once 
#include <BP_CooldownComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CooldownComponent.BP_CooldownComponent_C
// Size: 0x149(Inherited: 0xA0) 
struct UBP_CooldownComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA0(0x8)
	struct TMap<struct FName, double> CooldownMapping;  // 0xA8(0x50)
	struct TMap<struct FName, double> ConsumedCooldownMapping;  // 0xF8(0x50)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool IsDebugging : 1;  // 0x148(0x1)

	void RegisterAndConsumeCooldownItem(struct FName CooldownUniqueIdentifier, double CooldownSeconds); // Function BP_CooldownComponent.BP_CooldownComponent_C.RegisterAndConsumeCooldownItem
	void CanConsumeCooldownItem(struct FName& CooldownIItem, bool& ReturnNode); // Function BP_CooldownComponent.BP_CooldownComponent_C.CanConsumeCooldownItem
	void ConsumeCooldownItem(struct FName ConsumeCooldownItem); // Function BP_CooldownComponent.BP_CooldownComponent_C.ConsumeCooldownItem
	void RegisterCooldownItem(struct FName CooldownUniqueIdentifier, double CooldownSeconds); // Function BP_CooldownComponent.BP_CooldownComponent_C.RegisterCooldownItem
	void ReceiveTick(float DeltaSeconds); // Function BP_CooldownComponent.BP_CooldownComponent_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_CooldownComponent.BP_CooldownComponent_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_CooldownComponent(int32_t EntryPoint); // Function BP_CooldownComponent.BP_CooldownComponent_C.ExecuteUbergraph_BP_CooldownComponent
}; 



