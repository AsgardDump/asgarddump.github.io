#pragma once 
#include "SDK.h" 
 
 
// Function BP_Candle_Started.BP_Candle_Started_C.ExecuteUbergraph_BP_Candle_Started
// Size: 0x1C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Candle_Started
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	double CallFunc_Lerp_ReturnValue;  // 0x8(0x8)
	double CallFunc_Lerp_Alpha_ImplicitCast;  // 0x10(0x8)
	float CallFunc_SetIntensity_NewIntensity_ImplicitCast;  // 0x18(0x4)

}; 
// Function BP_Candle_Started.BP_Candle_Started_C.SetEnabled
// Size: 0x10(Inherited: 0x0) 
struct FSetEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UMaterialInstanceDynamic* NewLocalVar_1;  // 0x8(0x8)

}; 
