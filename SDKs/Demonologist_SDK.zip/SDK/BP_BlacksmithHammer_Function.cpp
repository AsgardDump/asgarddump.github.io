#include "SDK.h" 
 
 
void ABP_Tool_C::HitWall(struct FVector Location){

	static UObject* p_HitWall = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HitWall");

	struct {
		struct FVector Location;
	} parms;

	parms.Location = Location;

	ProcessEvent(p_HitWall, &parms);
}

void ABP_Tool_C::HitUvObject(struct FVector Location){

	static UObject* p_HitUvObject = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HitUvObject");

	struct {
		struct FVector Location;
	} parms;

	parms.Location = Location;

	ProcessEvent(p_HitUvObject, &parms);
}

bool ABP_Tool_C::CanAttack(){

	static UObject* p_CanAttack = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.CanAttack");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanAttack, &parms);
	return parms.return_value;
}

void ABP_Tool_C::InpActEvt_ToolInteraction_K2Node_InputActionEvent_1(struct FKey Key){

	static UObject* p_InpActEvt_ToolInteraction_K2Node_InputActionEvent_1 = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.InpActEvt_ToolInteraction_K2Node_InputActionEvent_1");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_ToolInteraction_K2Node_InputActionEvent_1, &parms);
}

void ABP_Tool_C::OnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName){

	static UObject* p_OnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C, &parms);
}

void ABP_Tool_C::OnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName){

	static UObject* p_OnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C, &parms);
}

void ABP_Tool_C::OnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName){

	static UObject* p_OnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C, &parms);
}

void ABP_Tool_C::OnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName){

	static UObject* p_OnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C, &parms);
}

void ABP_Tool_C::OnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName){

	static UObject* p_OnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C, &parms);
}

void ABP_Tool_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_Tool_C::BlacksmithHammerAttack On Server(){

	static UObject* p_BlacksmithHammerAttack On Server = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.BlacksmithHammerAttack On Server");

	struct {
	} parms;


	ProcessEvent(p_BlacksmithHammerAttack On Server, &parms);
}

void ABP_Tool_C::BlacksmithHammerAttack On Multicast(){

	static UObject* p_BlacksmithHammerAttack On Multicast = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.BlacksmithHammerAttack On Multicast");

	struct {
	} parms;


	ProcessEvent(p_BlacksmithHammerAttack On Multicast, &parms);
}

void ABP_Tool_C::HammerHitWall On Multicast(bool bTrueHit, struct FVector Location){

	static UObject* p_HammerHitWall On Multicast = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HammerHitWall On Multicast");

	struct {
		bool bTrueHit;
		struct FVector Location;
	} parms;

	parms.bTrueHit = bTrueHit;
	parms.Location = Location;

	ProcessEvent(p_HammerHitWall On Multicast, &parms);
}

void ABP_Tool_C::HammerHitOnServer(bool bTrueHit, struct FVector Location, struct ABP_HammerUvObject_C* WallUvObject){

	static UObject* p_HammerHitOnServer = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HammerHitOnServer");

	struct {
		bool bTrueHit;
		struct FVector Location;
		struct ABP_HammerUvObject_C* WallUvObject;
	} parms;

	parms.bTrueHit = bTrueHit;
	parms.Location = Location;
	parms.WallUvObject = WallUvObject;

	ProcessEvent(p_HammerHitOnServer, &parms);
}

void ABP_Tool_C::ExecuteUbergraph_BP_BlacksmithHammer(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BlacksmithHammer = UObject::FindObject<UFunction>("Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.ExecuteUbergraph_BP_BlacksmithHammer");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BlacksmithHammer, &parms);
}

