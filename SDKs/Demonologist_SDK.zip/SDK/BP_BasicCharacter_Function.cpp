#include "SDK.h" 
 
 
bool ABP_PrimitiveCharacter_C::IsInteractionObjectExist(){

	static UObject* p_IsInteractionObjectExist = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.IsInteractionObjectExist");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsInteractionObjectExist, &parms);
	return parms.return_value;
}

void ABP_PrimitiveCharacter_C::PreparePitchReplication(){

	static UObject* p_PreparePitchReplication = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.PreparePitchReplication");

	struct {
	} parms;


	ProcessEvent(p_PreparePitchReplication, &parms);
}

void ABP_PrimitiveCharacter_C::InitializeBasicCharacter(){

	static UObject* p_InitializeBasicCharacter = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.InitializeBasicCharacter");

	struct {
	} parms;


	ProcessEvent(p_InitializeBasicCharacter, &parms);
}

void ABP_PrimitiveCharacter_C::ReplicateCameraPitch(){

	static UObject* p_ReplicateCameraPitch = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.ReplicateCameraPitch");

	struct {
	} parms;


	ProcessEvent(p_ReplicateCameraPitch, &parms);
}

struct FRotator ABP_PrimitiveCharacter_C::GetLookDirection(){

	static UObject* p_GetLookDirection = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.GetLookDirection");

	struct {
		struct FRotator return_value;
	} parms;


	ProcessEvent(p_GetLookDirection, &parms);
	return parms.return_value;
}

double ABP_PrimitiveCharacter_C::GetCurrentObjectInteractionTime(){

	static UObject* p_GetCurrentObjectInteractionTime = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.GetCurrentObjectInteractionTime");

	struct {
		double return_value;
	} parms;


	ProcessEvent(p_GetCurrentObjectInteractionTime, &parms);
	return parms.return_value;
}

void ABP_PrimitiveCharacter_C::InpActEvt_Interaction_K2Node_InputActionEvent_2(struct FKey Key){

	static UObject* p_InpActEvt_Interaction_K2Node_InputActionEvent_2 = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.InpActEvt_Interaction_K2Node_InputActionEvent_2");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_Interaction_K2Node_InputActionEvent_2, &parms);
}

void ABP_PrimitiveCharacter_C::InpActEvt_Interaction_K2Node_InputActionEvent_1(struct FKey Key){

	static UObject* p_InpActEvt_Interaction_K2Node_InputActionEvent_1 = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.InpActEvt_Interaction_K2Node_InputActionEvent_1");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_Interaction_K2Node_InputActionEvent_1, &parms);
}

void ABP_PrimitiveCharacter_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_PrimitiveCharacter_C::ExecuteUbergraph_BP_BasicCharacter(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BasicCharacter = UObject::FindObject<UFunction>("Function BP_BasicCharacter.BP_BasicCharacter_C.ExecuteUbergraph_BP_BasicCharacter");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BasicCharacter, &parms);
}

