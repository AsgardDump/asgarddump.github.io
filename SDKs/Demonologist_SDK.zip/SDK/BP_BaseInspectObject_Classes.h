#pragma once 
#include <BP_BaseInspectObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseInspectObject.BP_BaseInspectObject_C
// Size: 0x388(Inherited: 0x378) 
struct ABP_BaseInspectObject_C : public ABP_PickableObject_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x378(0x8)
	struct ABP_InspectionLiveObjects_C* InspectObject;  // 0x380(0x8)

	void ReceiveBeginPlay(); // Function BP_BaseInspectObject.BP_BaseInspectObject_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_BaseInspectObject(int32_t EntryPoint); // Function BP_BaseInspectObject.BP_BaseInspectObject_C.ExecuteUbergraph_BP_BaseInspectObject
}; 



