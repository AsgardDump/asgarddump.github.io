#include "SDK.h" 
 
 
bool ABP_Entity_C::GetCanPerformGhostAbility(){

	static UObject* p_GetCanPerformGhostAbility = UObject::FindObject<UFunction>("Function BP_Abaddon.BP_Abaddon_C.GetCanPerformGhostAbility");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetCanPerformGhostAbility, &parms);
	return parms.return_value;
}

struct TArray<struct AActor*> ABP_Entity_C::FilterAbaddonCharacters(struct TArray<struct AActor*>& SeenActors){

	static UObject* p_FilterAbaddonCharacters = UObject::FindObject<UFunction>("Function BP_Abaddon.BP_Abaddon_C.FilterAbaddonCharacters");

	struct {
		struct TArray<struct AActor*>& SeenActors;
		struct TArray<struct AActor*> return_value;
	} parms;

	parms.SeenActors = SeenActors;

	ProcessEvent(p_FilterAbaddonCharacters, &parms);
	return parms.return_value;
}

void ABP_Entity_C::OnPerceptionUpdatedCallback(struct TArray<struct AActor*>& UpdatedActors){

	static UObject* p_OnPerceptionUpdatedCallback = UObject::FindObject<UFunction>("Function BP_Abaddon.BP_Abaddon_C.OnPerceptionUpdatedCallback");

	struct {
		struct TArray<struct AActor*>& UpdatedActors;
	} parms;

	parms.UpdatedActors = UpdatedActors;

	ProcessEvent(p_OnPerceptionUpdatedCallback, &parms);
}

void ABP_Entity_C::ExecuteUbergraph_BP_Abaddon(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Abaddon = UObject::FindObject<UFunction>("Function BP_Abaddon.BP_Abaddon_C.ExecuteUbergraph_BP_Abaddon");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Abaddon, &parms);
}

