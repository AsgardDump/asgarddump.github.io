#include "SDK.h" 
 
 
void UTexture::Stop(){

	static UObject* p_Stop = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.Stop");

	struct {
	} parms;


	ProcessEvent(p_Stop, &parms);
}

void UTexture::SetPlayRate(float NewRate){

	static UObject* p_SetPlayRate = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.SetPlayRate");

	struct {
		float NewRate;
	} parms;

	parms.NewRate = NewRate;

	ProcessEvent(p_SetPlayRate, &parms);
}

void UTexture::SetLooping(bool bNewLooping){

	static UObject* p_SetLooping = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.SetLooping");

	struct {
		bool bNewLooping;
	} parms;

	parms.bNewLooping = bNewLooping;

	ProcessEvent(p_SetLooping, &parms);
}

void UTexture::PlayFromStart(){

	static UObject* p_PlayFromStart = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.PlayFromStart");

	struct {
	} parms;


	ProcessEvent(p_PlayFromStart, &parms);
}

void UTexture::Play(){

	static UObject* p_Play = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.Play");

	struct {
	} parms;


	ProcessEvent(p_Play, &parms);
}

bool UTexture::IsPlaying(){

	static UObject* p_IsPlaying = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.IsPlaying");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsPlaying, &parms);
	return parms.return_value;
}

bool UTexture::IsLooping(){

	static UObject* p_IsLooping = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.IsLooping");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsLooping, &parms);
	return parms.return_value;
}

float UTexture::GetPlayRate(){

	static UObject* p_GetPlayRate = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.GetPlayRate");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetPlayRate, &parms);
	return parms.return_value;
}

float UTexture::GetAnimationLength(){

	static UObject* p_GetAnimationLength = UObject::FindObject<UFunction>("Function AnimatedTexture.AnimatedTexture2D.GetAnimationLength");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetAnimationLength, &parms);
	return parms.return_value;
}

