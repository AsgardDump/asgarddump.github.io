#pragma once 
#include <ABP_ThirdPersonEmpty_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonEmpty.ABP_ThirdPersonEmpty_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonEmpty_C : public UABP_ThirdPersonToolLayer_C
{

}; 



