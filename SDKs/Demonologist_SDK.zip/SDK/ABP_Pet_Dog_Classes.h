#pragma once 
#include <ABP_Pet_Dog_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Pet_Dog.ABP_Pet_Dog_C
// Size: 0x738(Inherited: 0x350) 
struct UABP_Pet_Dog_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x388(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x490(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x4B8(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x500(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x528(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x550(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x598(0x20)
	struct FAnimNode_RandomPlayer AnimGraphNode_RandomPlayer;  // 0x5B8(0x78)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x630(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x650(0xC8)
	struct FVector K2Node_PropertyAccess;  // 0x718(0x18)
	double Speed;  // 0x730(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Pet_Dog.ABP_Pet_Dog_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_Pet_Dog.ABP_Pet_Dog_C.BlueprintThreadSafeUpdateAnimation
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_14AF982249037F96917F418E6828B712(); // Function ABP_Pet_Dog.ABP_Pet_Dog_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_14AF982249037F96917F418E6828B712
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_FE233A2241EF532F702DFA91C2B55089(); // Function ABP_Pet_Dog.ABP_Pet_Dog_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Pet_Dog_AnimGraphNode_TransitionResult_FE233A2241EF532F702DFA91C2B55089
	void ExecuteUbergraph_ABP_Pet_Dog(int32_t EntryPoint); // Function ABP_Pet_Dog.ABP_Pet_Dog_C.ExecuteUbergraph_ABP_Pet_Dog
}; 



