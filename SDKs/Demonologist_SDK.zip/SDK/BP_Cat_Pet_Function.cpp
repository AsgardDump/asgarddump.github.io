#include "SDK.h" 
 
 
void ACharacter::GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule){

	static UObject* p_GetAttachmentDetails = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.GetAttachmentDetails");

	struct {
		bool& IsManualAttachment;
		struct FTransform& RelativeTransform;
		struct USceneComponent*& AttachmentComponent;
		struct FName& SocketName;
		char& LocationRule;
		char& RotationRule;
		char& ScaleRule;
	} parms;

	parms.IsManualAttachment = IsManualAttachment;
	parms.RelativeTransform = RelativeTransform;
	parms.AttachmentComponent = AttachmentComponent;
	parms.SocketName = SocketName;
	parms.LocationRule = LocationRule;
	parms.RotationRule = RotationRule;
	parms.ScaleRule = ScaleRule;

	ProcessEvent(p_GetAttachmentDetails, &parms);
}

bool ACharacter::GetVisualActiveCondition(){

	static UObject* p_GetVisualActiveCondition = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.GetVisualActiveCondition");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetVisualActiveCondition, &parms);
	return parms.return_value;
}

bool ACharacter::GetIsLookInteractionActive(){

	static UObject* p_GetIsLookInteractionActive = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.GetIsLookInteractionActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsLookInteractionActive, &parms);
	return parms.return_value;
}

bool ACharacter::CanPlayerInteract(struct APawn* PawnReference){

	static UObject* p_CanPlayerInteract = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.CanPlayerInteract");

	struct {
		struct APawn* PawnReference;
		bool return_value;
	} parms;

	parms.PawnReference = PawnReference;

	ProcessEvent(p_CanPlayerInteract, &parms);
	return parms.return_value;
}

void ACharacter::GetCatBehaviour(char E_CatBehaviour& CatBehaviour){

	static UObject* p_GetCatBehaviour = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.GetCatBehaviour");

	struct {
		char E_CatBehaviour& CatBehaviour;
	} parms;

	parms.CatBehaviour = CatBehaviour;

	ProcessEvent(p_GetCatBehaviour, &parms);
}

void ACharacter::OnRep_FatMorphTarget(){

	static UObject* p_OnRep_FatMorphTarget = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnRep_FatMorphTarget");

	struct {
	} parms;


	ProcessEvent(p_OnRep_FatMorphTarget, &parms);
}

void ACharacter::RequestAiCommand(){

	static UObject* p_RequestAiCommand = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.RequestAiCommand");

	struct {
	} parms;


	ProcessEvent(p_RequestAiCommand, &parms);
}

void ACharacter::SetCurrentAiStatus(char E_CatBehaviour TargetBehaviour){

	static UObject* p_SetCurrentAiStatus = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.SetCurrentAiStatus");

	struct {
		char E_CatBehaviour TargetBehaviour;
	} parms;

	parms.TargetBehaviour = TargetBehaviour;

	ProcessEvent(p_SetCurrentAiStatus, &parms);
}

void ACharacter::OnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName){

	static UObject* p_OnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0, &parms);
}

void ACharacter::OnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName){

	static UObject* p_OnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0, &parms);
}

void ACharacter::OnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName){

	static UObject* p_OnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0, &parms);
}

void ACharacter::OnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName){

	static UObject* p_OnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0, &parms);
}

void ACharacter::OnCompleted_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName){

	static UObject* p_OnCompleted_CDA379BB46AD02007842EEB72FA4B9E0 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnCompleted_CDA379BB46AD02007842EEB72FA4B9E0");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnCompleted_CDA379BB46AD02007842EEB72FA4B9E0, &parms);
}

void ACharacter::OnNotifyEnd_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName){

	static UObject* p_OnNotifyEnd_6DB031964564F00E967D65B8810E4EB4 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyEnd_6DB031964564F00E967D65B8810E4EB4");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyEnd_6DB031964564F00E967D65B8810E4EB4, &parms);
}

void ACharacter::OnNotifyBegin_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName){

	static UObject* p_OnNotifyBegin_6DB031964564F00E967D65B8810E4EB4 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyBegin_6DB031964564F00E967D65B8810E4EB4");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnNotifyBegin_6DB031964564F00E967D65B8810E4EB4, &parms);
}

void ACharacter::OnInterrupted_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName){

	static UObject* p_OnInterrupted_6DB031964564F00E967D65B8810E4EB4 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnInterrupted_6DB031964564F00E967D65B8810E4EB4");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnInterrupted_6DB031964564F00E967D65B8810E4EB4, &parms);
}

void ACharacter::OnBlendOut_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName){

	static UObject* p_OnBlendOut_6DB031964564F00E967D65B8810E4EB4 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnBlendOut_6DB031964564F00E967D65B8810E4EB4");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnBlendOut_6DB031964564F00E967D65B8810E4EB4, &parms);
}

void ACharacter::OnCompleted_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName){

	static UObject* p_OnCompleted_6DB031964564F00E967D65B8810E4EB4 = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnCompleted_6DB031964564F00E967D65B8810E4EB4");

	struct {
		struct FName NotifyName;
	} parms;

	parms.NotifyName = NotifyName;

	ProcessEvent(p_OnCompleted_6DB031964564F00E967D65B8810E4EB4, &parms);
}

void ACharacter::OnRoamingFinished(){

	static UObject* p_OnRoamingFinished = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnRoamingFinished");

	struct {
	} parms;


	ProcessEvent(p_OnRoamingFinished, &parms);
}

void ACharacter::OnCatBehaviourChanged(char E_CatBehaviour CurrentBehaviour){

	static UObject* p_OnCatBehaviourChanged = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnCatBehaviourChanged");

	struct {
		char E_CatBehaviour CurrentBehaviour;
	} parms;

	parms.CurrentBehaviour = CurrentBehaviour;

	ProcessEvent(p_OnCatBehaviourChanged, &parms);
}

void ACharacter::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ACharacter::PlayRoamingInterpret(struct UAnimMontage* MontageToPlay){

	static UObject* p_PlayRoamingInterpret = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.PlayRoamingInterpret");

	struct {
		struct UAnimMontage* MontageToPlay;
	} parms;

	parms.MontageToPlay = MontageToPlay;

	ProcessEvent(p_PlayRoamingInterpret, &parms);
}

void ACharacter::OnEatCompleted(){

	static UObject* p_OnEatCompleted = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.OnEatCompleted");

	struct {
	} parms;


	ProcessEvent(p_OnEatCompleted, &parms);
}

void ACharacter::CatStartEat(){

	static UObject* p_CatStartEat = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.CatStartEat");

	struct {
	} parms;


	ProcessEvent(p_CatStartEat, &parms);
}

void ACharacter::PlayCatMontage(struct UAnimMontage* MontageToPlay){

	static UObject* p_PlayCatMontage = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.PlayCatMontage");

	struct {
		struct UAnimMontage* MontageToPlay;
	} parms;

	parms.MontageToPlay = MontageToPlay;

	ProcessEvent(p_PlayCatMontage, &parms);
}

void ACharacter::AskForLove(){

	static UObject* p_AskForLove = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.AskForLove");

	struct {
	} parms;


	ProcessEvent(p_AskForLove, &parms);
}

void ACharacter::BndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted){

	static UObject* p_BndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.BndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature");

	struct {
		struct APawn* CharacterPawn;
		struct FName Identifier;
		bool IsServerExucuted;
	} parms;

	parms.CharacterPawn = CharacterPawn;
	parms.Identifier = Identifier;
	parms.IsServerExucuted = IsServerExucuted;

	ProcessEvent(p_BndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature, &parms);
}

void ACharacter::recognitionResultReceivedCallback(struct FString Result){

	static UObject* p_recognitionResultReceivedCallback = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.recognitionResultReceivedCallback");

	struct {
		struct FString Result;
	} parms;

	parms.Result = Result;

	ProcessEvent(p_recognitionResultReceivedCallback, &parms);
}

void ACharacter::ExecuteUbergraph_BP_Cat_Pet(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Cat_Pet = UObject::FindObject<UFunction>("Function BP_Cat_Pet.BP_Cat_Pet_C.ExecuteUbergraph_BP_Cat_Pet");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Cat_Pet, &parms);
}

