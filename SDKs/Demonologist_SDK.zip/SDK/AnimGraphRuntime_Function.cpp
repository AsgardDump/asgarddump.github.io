#include "SDK.h" 
 
 
bool UBlueprintFunctionLibrary::ShouldResetPlayTimeWhenBlendSpaceChanges(struct FBlendSpacePlayerReference& BlendSpacePlayer){

	static UObject* p_ShouldResetPlayTimeWhenBlendSpaceChanges = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.ShouldResetPlayTimeWhenBlendSpaceChanges");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		bool return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;

	ProcessEvent(p_ShouldResetPlayTimeWhenBlendSpaceChanges, &parms);
	return parms.return_value;
}

struct FBlendSpacePlayerReference UBlueprintFunctionLibrary::SetResetPlayTimeWhenBlendSpaceChanges(struct FBlendSpacePlayerReference& BlendSpacePlayer, bool bReset){

	static UObject* p_SetResetPlayTimeWhenBlendSpaceChanges = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.SetResetPlayTimeWhenBlendSpaceChanges");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		bool bReset;
		struct FBlendSpacePlayerReference return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;
	parms.bReset = bReset;

	ProcessEvent(p_SetResetPlayTimeWhenBlendSpaceChanges, &parms);
	return parms.return_value;
}

struct FBlendSpacePlayerReference UBlueprintFunctionLibrary::SetPlayRate(struct FBlendSpacePlayerReference& BlendSpacePlayer, float PlayRate){

	static UObject* p_SetPlayRate = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.SetPlayRate");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		float PlayRate;
		struct FBlendSpacePlayerReference return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;
	parms.PlayRate = PlayRate;

	ProcessEvent(p_SetPlayRate, &parms);
	return parms.return_value;
}

struct FBlendSpacePlayerReference UBlueprintFunctionLibrary::SetLoop(struct FBlendSpacePlayerReference& BlendSpacePlayer, bool bLoop){

	static UObject* p_SetLoop = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.SetLoop");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		bool bLoop;
		struct FBlendSpacePlayerReference return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;
	parms.bLoop = bLoop;

	ProcessEvent(p_SetLoop, &parms);
	return parms.return_value;
}

struct FBlendSpacePlayerReference UBlueprintFunctionLibrary::SetBlendSpaceWithInertialBlending(struct FAnimUpdateContext& UpdateContext, struct FBlendSpacePlayerReference& BlendSpacePlayer, struct UBlendSpace* BlendSpace, float BlendTime){

	static UObject* p_SetBlendSpaceWithInertialBlending = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.SetBlendSpaceWithInertialBlending");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		struct UBlendSpace* BlendSpace;
		float BlendTime;
		struct FBlendSpacePlayerReference return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.BlendSpacePlayer = BlendSpacePlayer;
	parms.BlendSpace = BlendSpace;
	parms.BlendTime = BlendTime;

	ProcessEvent(p_SetBlendSpaceWithInertialBlending, &parms);
	return parms.return_value;
}

struct FBlendSpacePlayerReference UBlueprintFunctionLibrary::SetBlendSpace(struct FBlendSpacePlayerReference& BlendSpacePlayer, struct UBlendSpace* BlendSpace){

	static UObject* p_SetBlendSpace = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.SetBlendSpace");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		struct UBlendSpace* BlendSpace;
		struct FBlendSpacePlayerReference return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;
	parms.BlendSpace = BlendSpace;

	ProcessEvent(p_SetBlendSpace, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetStartPosition(struct FBlendSpacePlayerReference& BlendSpacePlayer){

	static UObject* p_GetStartPosition = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.GetStartPosition");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		float return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;

	ProcessEvent(p_GetStartPosition, &parms);
	return parms.return_value;
}

struct FVector UBlueprintFunctionLibrary::GetPosition(struct FBlendSpacePlayerReference& BlendSpacePlayer){

	static UObject* p_GetPosition = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.GetPosition");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		struct FVector return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;

	ProcessEvent(p_GetPosition, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetPlayRate(struct FBlendSpacePlayerReference& BlendSpacePlayer){

	static UObject* p_GetPlayRate = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.GetPlayRate");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		float return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;

	ProcessEvent(p_GetPlayRate, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetLoop(struct FBlendSpacePlayerReference& BlendSpacePlayer){

	static UObject* p_GetLoop = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.GetLoop");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		bool return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;

	ProcessEvent(p_GetLoop, &parms);
	return parms.return_value;
}

struct UBlendSpace* UBlueprintFunctionLibrary::GetBlendSpace(struct FBlendSpacePlayerReference& BlendSpacePlayer){

	static UObject* p_GetBlendSpace = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.GetBlendSpace");

	struct {
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		struct UBlendSpace* return_value;
	} parms;

	parms.BlendSpacePlayer = BlendSpacePlayer;

	ProcessEvent(p_GetBlendSpace, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConvertToBlendSpacePlayerPure(struct FAnimNodeReference& Node, struct FBlendSpacePlayerReference& BlendSpacePlayer, bool& Result){

	static UObject* p_ConvertToBlendSpacePlayerPure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.ConvertToBlendSpacePlayerPure");

	struct {
		struct FAnimNodeReference& Node;
		struct FBlendSpacePlayerReference& BlendSpacePlayer;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.BlendSpacePlayer = BlendSpacePlayer;
	parms.Result = Result;

	ProcessEvent(p_ConvertToBlendSpacePlayerPure, &parms);
}

struct FBlendSpacePlayerReference UBlueprintFunctionLibrary::ConvertToBlendSpacePlayer(struct FAnimNodeReference& Node, uint8_t & Result){

	static UObject* p_ConvertToBlendSpacePlayer = UObject::FindObject<UFunction>("Function AnimGraphRuntime.BlendSpacePlayerLibrary.ConvertToBlendSpacePlayer");

	struct {
		struct FAnimNodeReference& Node;
		uint8_t & Result;
		struct FBlendSpacePlayerReference return_value;
	} parms;

	parms.Node = Node;
	parms.Result = Result;

	ProcessEvent(p_ConvertToBlendSpacePlayer, &parms);
	return parms.return_value;
}

struct FLayeredBoneBlendReference UBlueprintFunctionLibrary::SetBlendMask(struct FAnimUpdateContext& UpdateContext, struct FLayeredBoneBlendReference& LayeredBoneBlend, int32_t PoseIndex, struct FName BlendMaskName){

	static UObject* p_SetBlendMask = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LayeredBoneBlendLibrary.SetBlendMask");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FLayeredBoneBlendReference& LayeredBoneBlend;
		int32_t PoseIndex;
		struct FName BlendMaskName;
		struct FLayeredBoneBlendReference return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.LayeredBoneBlend = LayeredBoneBlend;
	parms.PoseIndex = PoseIndex;
	parms.BlendMaskName = BlendMaskName;

	ProcessEvent(p_SetBlendMask, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::GetNumPoses(struct FLayeredBoneBlendReference& LayeredBoneBlend){

	static UObject* p_GetNumPoses = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LayeredBoneBlendLibrary.GetNumPoses");

	struct {
		struct FLayeredBoneBlendReference& LayeredBoneBlend;
		int32_t return_value;
	} parms;

	parms.LayeredBoneBlend = LayeredBoneBlend;

	ProcessEvent(p_GetNumPoses, &parms);
	return parms.return_value;
}

struct FLayeredBoneBlendReference UBlueprintFunctionLibrary::ConvertToLayeredBoneBlend(struct FAnimNodeReference& Node, uint8_t & Result){

	static UObject* p_ConvertToLayeredBoneBlend = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LayeredBoneBlendLibrary.ConvertToLayeredBoneBlend");

	struct {
		struct FAnimNodeReference& Node;
		uint8_t & Result;
		struct FLayeredBoneBlendReference return_value;
	} parms;

	parms.Node = Node;
	parms.Result = Result;

	ProcessEvent(p_ConvertToLayeredBoneBlend, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConvertToLayeredBlendPerBonePure(struct FAnimNodeReference& Node, struct FLayeredBoneBlendReference& LayeredBoneBlend, bool& Result){

	static UObject* p_ConvertToLayeredBlendPerBonePure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LayeredBoneBlendLibrary.ConvertToLayeredBlendPerBonePure");

	struct {
		struct FAnimNodeReference& Node;
		struct FLayeredBoneBlendReference& LayeredBoneBlend;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.LayeredBoneBlend = LayeredBoneBlend;
	parms.Result = Result;

	ProcessEvent(p_ConvertToLayeredBlendPerBonePure, &parms);
}

void UBlueprintFunctionLibrary::SetState(struct FAnimUpdateContext& UpdateContext, struct FAnimationStateMachineReference& Node, struct FName TargetState, float Duration, char ETransitionLogicType BlendType, struct UBlendProfile* BlendProfile, uint8_t  AlphaBlendOption, struct UCurveFloat* CustomBlendCurve){

	static UObject* p_SetState = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.SetState");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FAnimationStateMachineReference& Node;
		struct FName TargetState;
		float Duration;
		char ETransitionLogicType BlendType;
		struct UBlendProfile* BlendProfile;
		uint8_t  AlphaBlendOption;
		struct UCurveFloat* CustomBlendCurve;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.Node = Node;
	parms.TargetState = TargetState;
	parms.Duration = Duration;
	parms.BlendType = BlendType;
	parms.BlendProfile = BlendProfile;
	parms.AlphaBlendOption = AlphaBlendOption;
	parms.CustomBlendCurve = CustomBlendCurve;

	ProcessEvent(p_SetState, &parms);
}

bool UBlueprintFunctionLibrary::IsStateBlendingOut(struct FAnimUpdateContext& UpdateContext, struct FAnimationStateResultReference& Node){

	static UObject* p_IsStateBlendingOut = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingOut");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FAnimationStateResultReference& Node;
		bool return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.Node = Node;

	ProcessEvent(p_IsStateBlendingOut, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::IsStateBlendingIn(struct FAnimUpdateContext& UpdateContext, struct FAnimationStateResultReference& Node){

	static UObject* p_IsStateBlendingIn = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.IsStateBlendingIn");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FAnimationStateResultReference& Node;
		bool return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.Node = Node;

	ProcessEvent(p_IsStateBlendingIn, &parms);
	return parms.return_value;
}

struct FName UBlueprintFunctionLibrary::GetState(struct FAnimUpdateContext& UpdateContext, struct FAnimationStateMachineReference& Node){

	static UObject* p_GetState = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.GetState");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FAnimationStateMachineReference& Node;
		struct FName return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.Node = Node;

	ProcessEvent(p_GetState, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetRelevantAnimTimeRemainingFraction(struct FAnimUpdateContext& UpdateContext, struct FAnimationStateResultReference& Node){

	static UObject* p_GetRelevantAnimTimeRemainingFraction = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemainingFraction");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FAnimationStateResultReference& Node;
		float return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.Node = Node;

	ProcessEvent(p_GetRelevantAnimTimeRemainingFraction, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetRelevantAnimTimeRemaining(struct FAnimUpdateContext& UpdateContext, struct FAnimationStateResultReference& Node){

	static UObject* p_GetRelevantAnimTimeRemaining = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.GetRelevantAnimTimeRemaining");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FAnimationStateResultReference& Node;
		float return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.Node = Node;

	ProcessEvent(p_GetRelevantAnimTimeRemaining, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConvertToAnimationStateResultPure(struct FAnimNodeReference& Node, struct FAnimationStateResultReference& AnimationState, bool& Result){

	static UObject* p_ConvertToAnimationStateResultPure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResultPure");

	struct {
		struct FAnimNodeReference& Node;
		struct FAnimationStateResultReference& AnimationState;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.AnimationState = AnimationState;
	parms.Result = Result;

	ProcessEvent(p_ConvertToAnimationStateResultPure, &parms);
}

void UBlueprintFunctionLibrary::ConvertToAnimationStateResult(struct FAnimNodeReference& Node, struct FAnimationStateResultReference& AnimationState, uint8_t & Result){

	static UObject* p_ConvertToAnimationStateResult = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateResult");

	struct {
		struct FAnimNodeReference& Node;
		struct FAnimationStateResultReference& AnimationState;
		uint8_t & Result;
	} parms;

	parms.Node = Node;
	parms.AnimationState = AnimationState;
	parms.Result = Result;

	ProcessEvent(p_ConvertToAnimationStateResult, &parms);
}

void UBlueprintFunctionLibrary::ConvertToAnimationStateMachinePure(struct FAnimNodeReference& Node, struct FAnimationStateMachineReference& AnimationState, bool& Result){

	static UObject* p_ConvertToAnimationStateMachinePure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachinePure");

	struct {
		struct FAnimNodeReference& Node;
		struct FAnimationStateMachineReference& AnimationState;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.AnimationState = AnimationState;
	parms.Result = Result;

	ProcessEvent(p_ConvertToAnimationStateMachinePure, &parms);
}

void UBlueprintFunctionLibrary::ConvertToAnimationStateMachine(struct FAnimNodeReference& Node, struct FAnimationStateMachineReference& AnimationState, uint8_t & Result){

	static UObject* p_ConvertToAnimationStateMachine = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimationStateMachineLibrary.ConvertToAnimationStateMachine");

	struct {
		struct FAnimNodeReference& Node;
		struct FAnimationStateMachineReference& AnimationState;
		uint8_t & Result;
	} parms;

	parms.Node = Node;
	parms.AnimationState = AnimationState;
	parms.Result = Result;

	ProcessEvent(p_ConvertToAnimationStateMachine, &parms);
}

struct FSkeletalControlReference UBlueprintFunctionLibrary::SetAlpha(struct FSkeletalControlReference& SkeletalControl, float Alpha){

	static UObject* p_SetAlpha = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SkeletalControlLibrary.SetAlpha");

	struct {
		struct FSkeletalControlReference& SkeletalControl;
		float Alpha;
		struct FSkeletalControlReference return_value;
	} parms;

	parms.SkeletalControl = SkeletalControl;
	parms.Alpha = Alpha;

	ProcessEvent(p_SetAlpha, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetAlpha(struct FSkeletalControlReference& SkeletalControl){

	static UObject* p_GetAlpha = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SkeletalControlLibrary.GetAlpha");

	struct {
		struct FSkeletalControlReference& SkeletalControl;
		float return_value;
	} parms;

	parms.SkeletalControl = SkeletalControl;

	ProcessEvent(p_GetAlpha, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConvertToSkeletalControlPure(struct FAnimNodeReference& Node, struct FSkeletalControlReference& SkeletalControl, bool& Result){

	static UObject* p_ConvertToSkeletalControlPure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControlPure");

	struct {
		struct FAnimNodeReference& Node;
		struct FSkeletalControlReference& SkeletalControl;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.SkeletalControl = SkeletalControl;
	parms.Result = Result;

	ProcessEvent(p_ConvertToSkeletalControlPure, &parms);
}

struct FSkeletalControlReference UBlueprintFunctionLibrary::ConvertToSkeletalControl(struct FAnimNodeReference& Node, uint8_t & Result){

	static UObject* p_ConvertToSkeletalControl = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SkeletalControlLibrary.ConvertToSkeletalControl");

	struct {
		struct FAnimNodeReference& Node;
		uint8_t & Result;
		struct FSkeletalControlReference return_value;
	} parms;

	parms.Node = Node;
	parms.Result = Result;

	ProcessEvent(p_ConvertToSkeletalControl, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetDeltaTime(struct FAnimUpdateContext& Context){

	static UObject* p_GetDeltaTime = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetDeltaTime");

	struct {
		struct FAnimUpdateContext& Context;
		float return_value;
	} parms;

	parms.Context = Context;

	ProcessEvent(p_GetDeltaTime, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetCurrentWeight(struct FAnimUpdateContext& Context){

	static UObject* p_GetCurrentWeight = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetCurrentWeight");

	struct {
		struct FAnimUpdateContext& Context;
		float return_value;
	} parms;

	parms.Context = Context;

	ProcessEvent(p_GetCurrentWeight, &parms);
	return parms.return_value;
}

struct FAnimNodeReference UBlueprintFunctionLibrary::GetAnimNodeReference(struct UAnimInstance* Instance, int32_t Index){

	static UObject* p_GetAnimNodeReference = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimNodeReference");

	struct {
		struct UAnimInstance* Instance;
		int32_t Index;
		struct FAnimNodeReference return_value;
	} parms;

	parms.Instance = Instance;
	parms.Index = Index;

	ProcessEvent(p_GetAnimNodeReference, &parms);
	return parms.return_value;
}

struct UAnimInstance* UBlueprintFunctionLibrary::GetAnimInstance(struct FAnimExecutionContext& Context){

	static UObject* p_GetAnimInstance = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.GetAnimInstance");

	struct {
		struct FAnimExecutionContext& Context;
		struct UAnimInstance* return_value;
	} parms;

	parms.Context = Context;

	ProcessEvent(p_GetAnimInstance, &parms);
	return parms.return_value;
}

struct FAnimUpdateContext UBlueprintFunctionLibrary::ConvertToUpdateContext(struct FAnimExecutionContext& Context, uint8_t & Result){

	static UObject* p_ConvertToUpdateContext = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToUpdateContext");

	struct {
		struct FAnimExecutionContext& Context;
		uint8_t & Result;
		struct FAnimUpdateContext return_value;
	} parms;

	parms.Context = Context;
	parms.Result = Result;

	ProcessEvent(p_ConvertToUpdateContext, &parms);
	return parms.return_value;
}

struct FAnimPoseContext UBlueprintFunctionLibrary::ConvertToPoseContext(struct FAnimExecutionContext& Context, uint8_t & Result){

	static UObject* p_ConvertToPoseContext = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToPoseContext");

	struct {
		struct FAnimExecutionContext& Context;
		uint8_t & Result;
		struct FAnimPoseContext return_value;
	} parms;

	parms.Context = Context;
	parms.Result = Result;

	ProcessEvent(p_ConvertToPoseContext, &parms);
	return parms.return_value;
}

struct FAnimInitializationContext UBlueprintFunctionLibrary::ConvertToInitializationContext(struct FAnimExecutionContext& Context, uint8_t & Result){

	static UObject* p_ConvertToInitializationContext = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToInitializationContext");

	struct {
		struct FAnimExecutionContext& Context;
		uint8_t & Result;
		struct FAnimInitializationContext return_value;
	} parms;

	parms.Context = Context;
	parms.Result = Result;

	ProcessEvent(p_ConvertToInitializationContext, &parms);
	return parms.return_value;
}

struct FAnimComponentSpacePoseContext UBlueprintFunctionLibrary::ConvertToComponentSpacePoseContext(struct FAnimExecutionContext& Context, uint8_t & Result){

	static UObject* p_ConvertToComponentSpacePoseContext = UObject::FindObject<UFunction>("Function AnimGraphRuntime.AnimExecutionContextLibrary.ConvertToComponentSpacePoseContext");

	struct {
		struct FAnimExecutionContext& Context;
		uint8_t & Result;
		struct FAnimComponentSpacePoseContext return_value;
	} parms;

	parms.Context = Context;
	parms.Result = Result;

	ProcessEvent(p_ConvertToComponentSpacePoseContext, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::K2_TwoBoneIK(struct FVector& RootPos, struct FVector& JointPos, struct FVector& EndPos, struct FVector& JointTarget, struct FVector& Effector, struct FVector& OutJointPos, struct FVector& OutEndPos, bool bAllowStretching, float StartStretchRatio, float MaxStretchScale){

	static UObject* p_K2_TwoBoneIK = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_TwoBoneIK");

	struct {
		struct FVector& RootPos;
		struct FVector& JointPos;
		struct FVector& EndPos;
		struct FVector& JointTarget;
		struct FVector& Effector;
		struct FVector& OutJointPos;
		struct FVector& OutEndPos;
		bool bAllowStretching;
		float StartStretchRatio;
		float MaxStretchScale;
	} parms;

	parms.RootPos = RootPos;
	parms.JointPos = JointPos;
	parms.EndPos = EndPos;
	parms.JointTarget = JointTarget;
	parms.Effector = Effector;
	parms.OutJointPos = OutJointPos;
	parms.OutEndPos = OutEndPos;
	parms.bAllowStretching = bAllowStretching;
	parms.StartStretchRatio = StartStretchRatio;
	parms.MaxStretchScale = MaxStretchScale;

	ProcessEvent(p_K2_TwoBoneIK, &parms);
}

void UBlueprintFunctionLibrary::K2_StartProfilingTimer(){

	static UObject* p_K2_StartProfilingTimer = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_StartProfilingTimer");

	struct {
	} parms;


	ProcessEvent(p_K2_StartProfilingTimer, &parms);
}

struct FVector UBlueprintFunctionLibrary::K2_MakePerlinNoiseVectorAndRemap(float X, float Y, float Z, float RangeOutMinX, float RangeOutMaxX, float RangeOutMinY, float RangeOutMaxY, float RangeOutMinZ, float RangeOutMaxZ){

	static UObject* p_K2_MakePerlinNoiseVectorAndRemap = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseVectorAndRemap");

	struct {
		float X;
		float Y;
		float Z;
		float RangeOutMinX;
		float RangeOutMaxX;
		float RangeOutMinY;
		float RangeOutMaxY;
		float RangeOutMinZ;
		float RangeOutMaxZ;
		struct FVector return_value;
	} parms;

	parms.X = X;
	parms.Y = Y;
	parms.Z = Z;
	parms.RangeOutMinX = RangeOutMinX;
	parms.RangeOutMaxX = RangeOutMaxX;
	parms.RangeOutMinY = RangeOutMinY;
	parms.RangeOutMaxY = RangeOutMaxY;
	parms.RangeOutMinZ = RangeOutMinZ;
	parms.RangeOutMaxZ = RangeOutMaxZ;

	ProcessEvent(p_K2_MakePerlinNoiseVectorAndRemap, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_MakePerlinNoiseAndRemap(float Value, float RangeOutMin, float RangeOutMax){

	static UObject* p_K2_MakePerlinNoiseAndRemap = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_MakePerlinNoiseAndRemap");

	struct {
		float Value;
		float RangeOutMin;
		float RangeOutMax;
		float return_value;
	} parms;

	parms.Value = Value;
	parms.RangeOutMin = RangeOutMin;
	parms.RangeOutMax = RangeOutMax;

	ProcessEvent(p_K2_MakePerlinNoiseAndRemap, &parms);
	return parms.return_value;
}

struct FTransform UBlueprintFunctionLibrary::K2_LookAt(struct FTransform& CurrentTransform, struct FVector& TargetPosition, struct FVector LookAtVector, bool bUseUpVector, struct FVector UpVector, float ClampConeInDegree){

	static UObject* p_K2_LookAt = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_LookAt");

	struct {
		struct FTransform& CurrentTransform;
		struct FVector& TargetPosition;
		struct FVector LookAtVector;
		bool bUseUpVector;
		struct FVector UpVector;
		float ClampConeInDegree;
		struct FTransform return_value;
	} parms;

	parms.CurrentTransform = CurrentTransform;
	parms.TargetPosition = TargetPosition;
	parms.LookAtVector = LookAtVector;
	parms.bUseUpVector = bUseUpVector;
	parms.UpVector = UpVector;
	parms.ClampConeInDegree = ClampConeInDegree;

	ProcessEvent(p_K2_LookAt, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_EndProfilingTimer(bool bLog, struct FString LogPrefix){

	static UObject* p_K2_EndProfilingTimer = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_EndProfilingTimer");

	struct {
		bool bLog;
		struct FString LogPrefix;
		float return_value;
	} parms;

	parms.bLog = bLog;
	parms.LogPrefix = LogPrefix;

	ProcessEvent(p_K2_EndProfilingTimer, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_DistanceBetweenTwoSocketsAndMapRange(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameA, char ERelativeTransformSpace SocketSpaceA, struct FName SocketOrBoneNameB, char ERelativeTransformSpace SocketSpaceB, bool bRemapRange, float InRangeMin, float InRangeMax, float OutRangeMin, float OutRangeMax){

	static UObject* p_K2_DistanceBetweenTwoSocketsAndMapRange = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_DistanceBetweenTwoSocketsAndMapRange");

	struct {
		struct USkeletalMeshComponent* Component;
		struct FName SocketOrBoneNameA;
		char ERelativeTransformSpace SocketSpaceA;
		struct FName SocketOrBoneNameB;
		char ERelativeTransformSpace SocketSpaceB;
		bool bRemapRange;
		float InRangeMin;
		float InRangeMax;
		float OutRangeMin;
		float OutRangeMax;
		float return_value;
	} parms;

	parms.Component = Component;
	parms.SocketOrBoneNameA = SocketOrBoneNameA;
	parms.SocketSpaceA = SocketSpaceA;
	parms.SocketOrBoneNameB = SocketOrBoneNameB;
	parms.SocketSpaceB = SocketSpaceB;
	parms.bRemapRange = bRemapRange;
	parms.InRangeMin = InRangeMin;
	parms.InRangeMax = InRangeMax;
	parms.OutRangeMin = OutRangeMin;
	parms.OutRangeMax = OutRangeMax;

	ProcessEvent(p_K2_DistanceBetweenTwoSocketsAndMapRange, &parms);
	return parms.return_value;
}

struct FVector UBlueprintFunctionLibrary::K2_DirectionBetweenSockets(struct USkeletalMeshComponent* Component, struct FName SocketOrBoneNameFrom, struct FName SocketOrBoneNameTo){

	static UObject* p_K2_DirectionBetweenSockets = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_DirectionBetweenSockets");

	struct {
		struct USkeletalMeshComponent* Component;
		struct FName SocketOrBoneNameFrom;
		struct FName SocketOrBoneNameTo;
		struct FVector return_value;
	} parms;

	parms.Component = Component;
	parms.SocketOrBoneNameFrom = SocketOrBoneNameFrom;
	parms.SocketOrBoneNameTo = SocketOrBoneNameTo;

	ProcessEvent(p_K2_DirectionBetweenSockets, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_CalculateVelocityFromSockets(float DeltaSeconds, struct USkeletalMeshComponent* Component, struct FName SocketOrBoneName, struct FName ReferenceSocketOrBone, char ERelativeTransformSpace SocketSpace, struct FVector OffsetInBoneSpace, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax, uint8_t  EasingType, struct FRuntimeFloatCurve& CustomCurve){

	static UObject* p_K2_CalculateVelocityFromSockets = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromSockets");

	struct {
		float DeltaSeconds;
		struct USkeletalMeshComponent* Component;
		struct FName SocketOrBoneName;
		struct FName ReferenceSocketOrBone;
		char ERelativeTransformSpace SocketSpace;
		struct FVector OffsetInBoneSpace;
		struct FPositionHistory& History;
		int32_t NumberOfSamples;
		float VelocityMin;
		float VelocityMax;
		uint8_t  EasingType;
		struct FRuntimeFloatCurve& CustomCurve;
		float return_value;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;
	parms.Component = Component;
	parms.SocketOrBoneName = SocketOrBoneName;
	parms.ReferenceSocketOrBone = ReferenceSocketOrBone;
	parms.SocketSpace = SocketSpace;
	parms.OffsetInBoneSpace = OffsetInBoneSpace;
	parms.History = History;
	parms.NumberOfSamples = NumberOfSamples;
	parms.VelocityMin = VelocityMin;
	parms.VelocityMax = VelocityMax;
	parms.EasingType = EasingType;
	parms.CustomCurve = CustomCurve;

	ProcessEvent(p_K2_CalculateVelocityFromSockets, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::K2_CalculateVelocityFromPositionHistory(float DeltaSeconds, struct FVector Position, struct FPositionHistory& History, int32_t NumberOfSamples, float VelocityMin, float VelocityMax){

	static UObject* p_K2_CalculateVelocityFromPositionHistory = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.K2_CalculateVelocityFromPositionHistory");

	struct {
		float DeltaSeconds;
		struct FVector Position;
		struct FPositionHistory& History;
		int32_t NumberOfSamples;
		float VelocityMin;
		float VelocityMax;
		float return_value;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;
	parms.Position = Position;
	parms.History = History;
	parms.NumberOfSamples = NumberOfSamples;
	parms.VelocityMin = VelocityMin;
	parms.VelocityMax = VelocityMax;

	ProcessEvent(p_K2_CalculateVelocityFromPositionHistory, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::CalculateDirection(struct FVector& Velocity, struct FRotator& BaseRotation){

	static UObject* p_CalculateDirection = UObject::FindObject<UFunction>("Function AnimGraphRuntime.KismetAnimationLibrary.CalculateDirection");

	struct {
		struct FVector& Velocity;
		struct FRotator& BaseRotation;
		float return_value;
	} parms;

	parms.Velocity = Velocity;
	parms.BaseRotation = BaseRotation;

	ProcessEvent(p_CalculateDirection, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::HasLinkedAnimInstance(struct FLinkedAnimGraphReference& Node){

	static UObject* p_HasLinkedAnimInstance = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LinkedAnimGraphLibrary.HasLinkedAnimInstance");

	struct {
		struct FLinkedAnimGraphReference& Node;
		bool return_value;
	} parms;

	parms.Node = Node;

	ProcessEvent(p_HasLinkedAnimInstance, &parms);
	return parms.return_value;
}

struct UAnimInstance* UBlueprintFunctionLibrary::GetLinkedAnimInstance(struct FLinkedAnimGraphReference& Node){

	static UObject* p_GetLinkedAnimInstance = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LinkedAnimGraphLibrary.GetLinkedAnimInstance");

	struct {
		struct FLinkedAnimGraphReference& Node;
		struct UAnimInstance* return_value;
	} parms;

	parms.Node = Node;

	ProcessEvent(p_GetLinkedAnimInstance, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConvertToLinkedAnimGraphPure(struct FAnimNodeReference& Node, struct FLinkedAnimGraphReference& LinkedAnimGraph, bool& Result){

	static UObject* p_ConvertToLinkedAnimGraphPure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraphPure");

	struct {
		struct FAnimNodeReference& Node;
		struct FLinkedAnimGraphReference& LinkedAnimGraph;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.LinkedAnimGraph = LinkedAnimGraph;
	parms.Result = Result;

	ProcessEvent(p_ConvertToLinkedAnimGraphPure, &parms);
}

struct FLinkedAnimGraphReference UBlueprintFunctionLibrary::ConvertToLinkedAnimGraph(struct FAnimNodeReference& Node, uint8_t & Result){

	static UObject* p_ConvertToLinkedAnimGraph = UObject::FindObject<UFunction>("Function AnimGraphRuntime.LinkedAnimGraphLibrary.ConvertToLinkedAnimGraph");

	struct {
		struct FAnimNodeReference& Node;
		uint8_t & Result;
		struct FLinkedAnimGraphReference return_value;
	} parms;

	parms.Node = Node;
	parms.Result = Result;

	ProcessEvent(p_ConvertToLinkedAnimGraph, &parms);
	return parms.return_value;
}

void UObject::OnNotifyEndReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload){

	static UObject* p_OnNotifyEndReceived = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyEndReceived");

	struct {
		struct FName NotifyName;
		struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload;
	} parms;

	parms.NotifyName = NotifyName;
	parms.BranchingPointNotifyPayload = BranchingPointNotifyPayload;

	ProcessEvent(p_OnNotifyEndReceived, &parms);
}

void UObject::OnNotifyBeginReceived(struct FName NotifyName, struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload){

	static UObject* p_OnNotifyBeginReceived = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnNotifyBeginReceived");

	struct {
		struct FName NotifyName;
		struct FBranchingPointNotifyPayload& BranchingPointNotifyPayload;
	} parms;

	parms.NotifyName = NotifyName;
	parms.BranchingPointNotifyPayload = BranchingPointNotifyPayload;

	ProcessEvent(p_OnNotifyBeginReceived, &parms);
}

void UObject::OnMontageEnded(struct UAnimMontage* Montage, bool bInterrupted){

	static UObject* p_OnMontageEnded = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageEnded");

	struct {
		struct UAnimMontage* Montage;
		bool bInterrupted;
	} parms;

	parms.Montage = Montage;
	parms.bInterrupted = bInterrupted;

	ProcessEvent(p_OnMontageEnded, &parms);
}

void UObject::OnMontageBlendingOut(struct UAnimMontage* Montage, bool bInterrupted){

	static UObject* p_OnMontageBlendingOut = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.OnMontageBlendingOut");

	struct {
		struct UAnimMontage* Montage;
		bool bInterrupted;
	} parms;

	parms.Montage = Montage;
	parms.bInterrupted = bInterrupted;

	ProcessEvent(p_OnMontageBlendingOut, &parms);
}

struct UPlayMontageCallbackProxy* UObject::CreateProxyObjectForPlayMontage(struct USkeletalMeshComponent* InSkeletalMeshComponent, struct UAnimMontage* MontageToPlay, float PlayRate, float StartingPosition, struct FName StartingSection){

	static UObject* p_CreateProxyObjectForPlayMontage = UObject::FindObject<UFunction>("Function AnimGraphRuntime.PlayMontageCallbackProxy.CreateProxyObjectForPlayMontage");

	struct {
		struct USkeletalMeshComponent* InSkeletalMeshComponent;
		struct UAnimMontage* MontageToPlay;
		float PlayRate;
		float StartingPosition;
		struct FName StartingSection;
		struct UPlayMontageCallbackProxy* return_value;
	} parms;

	parms.InSkeletalMeshComponent = InSkeletalMeshComponent;
	parms.MontageToPlay = MontageToPlay;
	parms.PlayRate = PlayRate;
	parms.StartingPosition = StartingPosition;
	parms.StartingSection = StartingSection;

	ProcessEvent(p_CreateProxyObjectForPlayMontage, &parms);
	return parms.return_value;
}

struct FSequenceEvaluatorReference UBlueprintFunctionLibrary::SetSequenceWithInertialBlending(struct FAnimUpdateContext& UpdateContext, struct FSequenceEvaluatorReference& SequenceEvaluator, struct UAnimSequenceBase* Sequence, float BlendTime){

	static UObject* p_SetSequenceWithInertialBlending = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequenceWithInertialBlending");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FSequenceEvaluatorReference& SequenceEvaluator;
		struct UAnimSequenceBase* Sequence;
		float BlendTime;
		struct FSequenceEvaluatorReference return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.SequenceEvaluator = SequenceEvaluator;
	parms.Sequence = Sequence;
	parms.BlendTime = BlendTime;

	ProcessEvent(p_SetSequenceWithInertialBlending, &parms);
	return parms.return_value;
}

struct FSequenceEvaluatorReference UBlueprintFunctionLibrary::SetSequence(struct FSequenceEvaluatorReference& SequenceEvaluator, struct UAnimSequenceBase* Sequence){

	static UObject* p_SetSequence = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetSequence");

	struct {
		struct FSequenceEvaluatorReference& SequenceEvaluator;
		struct UAnimSequenceBase* Sequence;
		struct FSequenceEvaluatorReference return_value;
	} parms;

	parms.SequenceEvaluator = SequenceEvaluator;
	parms.Sequence = Sequence;

	ProcessEvent(p_SetSequence, &parms);
	return parms.return_value;
}

struct FSequenceEvaluatorReference UBlueprintFunctionLibrary::SetExplicitTime(struct FSequenceEvaluatorReference& SequenceEvaluator, float Time){

	static UObject* p_SetExplicitTime = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.SetExplicitTime");

	struct {
		struct FSequenceEvaluatorReference& SequenceEvaluator;
		float Time;
		struct FSequenceEvaluatorReference return_value;
	} parms;

	parms.SequenceEvaluator = SequenceEvaluator;
	parms.Time = Time;

	ProcessEvent(p_SetExplicitTime, &parms);
	return parms.return_value;
}

struct UAnimSequenceBase* UBlueprintFunctionLibrary::GetSequence(struct FSequenceEvaluatorReference& SequenceEvaluator){

	static UObject* p_GetSequence = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetSequence");

	struct {
		struct FSequenceEvaluatorReference& SequenceEvaluator;
		struct UAnimSequenceBase* return_value;
	} parms;

	parms.SequenceEvaluator = SequenceEvaluator;

	ProcessEvent(p_GetSequence, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetAccumulatedTime(struct FSequenceEvaluatorReference& SequenceEvaluator){

	static UObject* p_GetAccumulatedTime = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.GetAccumulatedTime");

	struct {
		struct FSequenceEvaluatorReference& SequenceEvaluator;
		float return_value;
	} parms;

	parms.SequenceEvaluator = SequenceEvaluator;

	ProcessEvent(p_GetAccumulatedTime, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConvertToSequenceEvaluatorPure(struct FAnimNodeReference& Node, struct FSequenceEvaluatorReference& SequenceEvaluator, bool& Result){

	static UObject* p_ConvertToSequenceEvaluatorPure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluatorPure");

	struct {
		struct FAnimNodeReference& Node;
		struct FSequenceEvaluatorReference& SequenceEvaluator;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.SequenceEvaluator = SequenceEvaluator;
	parms.Result = Result;

	ProcessEvent(p_ConvertToSequenceEvaluatorPure, &parms);
}

struct FSequenceEvaluatorReference UBlueprintFunctionLibrary::ConvertToSequenceEvaluator(struct FAnimNodeReference& Node, uint8_t & Result){

	static UObject* p_ConvertToSequenceEvaluator = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.ConvertToSequenceEvaluator");

	struct {
		struct FAnimNodeReference& Node;
		uint8_t & Result;
		struct FSequenceEvaluatorReference return_value;
	} parms;

	parms.Node = Node;
	parms.Result = Result;

	ProcessEvent(p_ConvertToSequenceEvaluator, &parms);
	return parms.return_value;
}

struct FSequenceEvaluatorReference UBlueprintFunctionLibrary::AdvanceTime(struct FAnimUpdateContext& UpdateContext, struct FSequenceEvaluatorReference& SequenceEvaluator, float PlayRate){

	static UObject* p_AdvanceTime = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequenceEvaluatorLibrary.AdvanceTime");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FSequenceEvaluatorReference& SequenceEvaluator;
		float PlayRate;
		struct FSequenceEvaluatorReference return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.SequenceEvaluator = SequenceEvaluator;
	parms.PlayRate = PlayRate;

	ProcessEvent(p_AdvanceTime, &parms);
	return parms.return_value;
}

struct FSequencePlayerReference UBlueprintFunctionLibrary::SetStartPosition(struct FSequencePlayerReference& SequencePlayer, float StartPosition){

	static UObject* p_SetStartPosition = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.SetStartPosition");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		float StartPosition;
		struct FSequencePlayerReference return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;
	parms.StartPosition = StartPosition;

	ProcessEvent(p_SetStartPosition, &parms);
	return parms.return_value;
}

struct FSequencePlayerReference UBlueprintFunctionLibrary::SetSequenceWithInertialBlending(struct FAnimUpdateContext& UpdateContext, struct FSequencePlayerReference& SequencePlayer, struct UAnimSequenceBase* Sequence, float BlendTime){

	static UObject* p_SetSequenceWithInertialBlending = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.SetSequenceWithInertialBlending");

	struct {
		struct FAnimUpdateContext& UpdateContext;
		struct FSequencePlayerReference& SequencePlayer;
		struct UAnimSequenceBase* Sequence;
		float BlendTime;
		struct FSequencePlayerReference return_value;
	} parms;

	parms.UpdateContext = UpdateContext;
	parms.SequencePlayer = SequencePlayer;
	parms.Sequence = Sequence;
	parms.BlendTime = BlendTime;

	ProcessEvent(p_SetSequenceWithInertialBlending, &parms);
	return parms.return_value;
}

struct FSequencePlayerReference UBlueprintFunctionLibrary::SetSequence(struct FSequencePlayerReference& SequencePlayer, struct UAnimSequenceBase* Sequence){

	static UObject* p_SetSequence = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.SetSequence");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		struct UAnimSequenceBase* Sequence;
		struct FSequencePlayerReference return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;
	parms.Sequence = Sequence;

	ProcessEvent(p_SetSequence, &parms);
	return parms.return_value;
}

struct FSequencePlayerReference UBlueprintFunctionLibrary::SetPlayRate(struct FSequencePlayerReference& SequencePlayer, float PlayRate){

	static UObject* p_SetPlayRate = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.SetPlayRate");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		float PlayRate;
		struct FSequencePlayerReference return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;
	parms.PlayRate = PlayRate;

	ProcessEvent(p_SetPlayRate, &parms);
	return parms.return_value;
}

struct FSequencePlayerReference UBlueprintFunctionLibrary::SetAccumulatedTime(struct FSequencePlayerReference& SequencePlayer, float Time){

	static UObject* p_SetAccumulatedTime = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.SetAccumulatedTime");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		float Time;
		struct FSequencePlayerReference return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;
	parms.Time = Time;

	ProcessEvent(p_SetAccumulatedTime, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetStartPosition(struct FSequencePlayerReference& SequencePlayer){

	static UObject* p_GetStartPosition = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.GetStartPosition");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		float return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;

	ProcessEvent(p_GetStartPosition, &parms);
	return parms.return_value;
}

struct UAnimSequenceBase* UBlueprintFunctionLibrary::GetSequencePure(struct FSequencePlayerReference& SequencePlayer){

	static UObject* p_GetSequencePure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.GetSequencePure");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		struct UAnimSequenceBase* return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;

	ProcessEvent(p_GetSequencePure, &parms);
	return parms.return_value;
}

struct FSequencePlayerReference UBlueprintFunctionLibrary::GetSequence(struct FSequencePlayerReference& SequencePlayer, struct UAnimSequenceBase*& SequenceBase){

	static UObject* p_GetSequence = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.GetSequence");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		struct UAnimSequenceBase*& SequenceBase;
		struct FSequencePlayerReference return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;
	parms.SequenceBase = SequenceBase;

	ProcessEvent(p_GetSequence, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetPlayRate(struct FSequencePlayerReference& SequencePlayer){

	static UObject* p_GetPlayRate = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.GetPlayRate");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		float return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;

	ProcessEvent(p_GetPlayRate, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::GetLoopAnimation(struct FSequencePlayerReference& SequencePlayer){

	static UObject* p_GetLoopAnimation = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.GetLoopAnimation");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		bool return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;

	ProcessEvent(p_GetLoopAnimation, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::GetAccumulatedTime(struct FSequencePlayerReference& SequencePlayer){

	static UObject* p_GetAccumulatedTime = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.GetAccumulatedTime");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		float return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;

	ProcessEvent(p_GetAccumulatedTime, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::ConvertToSequencePlayerPure(struct FAnimNodeReference& Node, struct FSequencePlayerReference& SequencePlayer, bool& Result){

	static UObject* p_ConvertToSequencePlayerPure = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayerPure");

	struct {
		struct FAnimNodeReference& Node;
		struct FSequencePlayerReference& SequencePlayer;
		bool& Result;
	} parms;

	parms.Node = Node;
	parms.SequencePlayer = SequencePlayer;
	parms.Result = Result;

	ProcessEvent(p_ConvertToSequencePlayerPure, &parms);
}

struct FSequencePlayerReference UBlueprintFunctionLibrary::ConvertToSequencePlayer(struct FAnimNodeReference& Node, uint8_t & Result){

	static UObject* p_ConvertToSequencePlayer = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.ConvertToSequencePlayer");

	struct {
		struct FAnimNodeReference& Node;
		uint8_t & Result;
		struct FSequencePlayerReference return_value;
	} parms;

	parms.Node = Node;
	parms.Result = Result;

	ProcessEvent(p_ConvertToSequencePlayer, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::ComputePlayRateFromDuration(struct FSequencePlayerReference& SequencePlayer, float Duration){

	static UObject* p_ComputePlayRateFromDuration = UObject::FindObject<UFunction>("Function AnimGraphRuntime.SequencePlayerLibrary.ComputePlayRateFromDuration");

	struct {
		struct FSequencePlayerReference& SequencePlayer;
		float Duration;
		float return_value;
	} parms;

	parms.SequencePlayer = SequencePlayer;
	parms.Duration = Duration;

	ProcessEvent(p_ComputePlayRateFromDuration, &parms);
	return parms.return_value;
}

