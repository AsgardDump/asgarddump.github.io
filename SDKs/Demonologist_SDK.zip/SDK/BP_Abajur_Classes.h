#pragma once 
#include <BP_Abajur_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Abajur.BP_Abajur_C
// Size: 0x3B8(Inherited: 0x3B8) 
struct ABP_Abajur_C : public ABP_PointLight_C
{

}; 



