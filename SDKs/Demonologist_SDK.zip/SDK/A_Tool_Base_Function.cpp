#include "SDK.h" 
 
 
void AActor::Attack Combo(int32_t Count){

	static UObject* p_Attack Combo = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Attack Combo");

	struct {
		int32_t Count;
	} parms;

	parms.Count = Count;

	ProcessEvent(p_Attack Combo, &parms);
}

void AActor::Get Focal Point(struct AActor* Pawn, struct FVector& Focal Point){

	static UObject* p_Get Focal Point = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Get Focal Point");

	struct {
		struct AActor* Pawn;
		struct FVector& Focal Point;
	} parms;

	parms.Pawn = Pawn;
	parms.Focal Point = Focal Point;

	ProcessEvent(p_Get Focal Point, &parms);
}

void AActor::Get Interact Location(struct AActor* Actor, struct FVector& Location){

	static UObject* p_Get Interact Location = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Get Interact Location");

	struct {
		struct AActor* Actor;
		struct FVector& Location;
	} parms;

	parms.Actor = Actor;
	parms.Location = Location;

	ProcessEvent(p_Get Interact Location, &parms);
}

void AActor::Interactable Check(struct APawn* Pawn, bool& Interactable){

	static UObject* p_Interactable Check = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Interactable Check");

	struct {
		struct APawn* Pawn;
		bool& Interactable;
	} parms;

	parms.Pawn = Pawn;
	parms.Interactable = Interactable;

	ProcessEvent(p_Interactable Check, &parms);
}

void AActor::Character Mesh(struct USkeletalMeshComponent*& Mesh){

	static UObject* p_Character Mesh = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Character Mesh");

	struct {
		struct USkeletalMeshComponent*& Mesh;
	} parms;

	parms.Mesh = Mesh;

	ProcessEvent(p_Character Mesh, &parms);
}

void AActor::Reset Attack(){

	static UObject* p_Reset Attack = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Reset Attack");

	struct {
	} parms;


	ProcessEvent(p_Reset Attack, &parms);
}

struct UCombat_C* AActor::Combat Component(){

	static UObject* p_Combat Component = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Combat Component");

	struct {
		struct UCombat_C* return_value;
	} parms;


	ProcessEvent(p_Combat Component, &parms);
	return parms.return_value;
}

void AActor::Hit Check(struct TArray<struct FHitResult>& Hits, struct TArray<struct FHitResult>& Valid Hits){

	static UObject* p_Hit Check = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Hit Check");

	struct {
		struct TArray<struct FHitResult>& Hits;
		struct TArray<struct FHitResult>& Valid Hits;
	} parms;

	parms.Hits = Hits;
	parms.Valid Hits = Valid Hits;

	ProcessEvent(p_Hit Check, &parms);
}

void AActor::Root Bone Vectors(struct FVector& Forward Vector, struct FVector& Right Vector){

	static UObject* p_Root Bone Vectors = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Root Bone Vectors");

	struct {
		struct FVector& Forward Vector;
		struct FVector& Right Vector;
	} parms;

	parms.Forward Vector = Forward Vector;
	parms.Right Vector = Right Vector;

	ProcessEvent(p_Root Bone Vectors, &parms);
}

void AActor::Owner Character(struct ACharacter*& AsCharacter){

	static UObject* p_Owner Character = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Owner Character");

	struct {
		struct ACharacter*& AsCharacter;
	} parms;

	parms.AsCharacter = AsCharacter;

	ProcessEvent(p_Owner Character, &parms);
}

void AActor::Add Movement TL__FinishedFunc(){

	static UObject* p_Add Movement TL__FinishedFunc = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Add Movement TL__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_Add Movement TL__FinishedFunc, &parms);
}

void AActor::Add Movement TL__UpdateFunc(){

	static UObject* p_Add Movement TL__UpdateFunc = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Add Movement TL__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_Add Movement TL__UpdateFunc, &parms);
}

void AActor::Update Ammo(){

	static UObject* p_Update Ammo = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Update Ammo");

	struct {
	} parms;


	ProcessEvent(p_Update Ammo, &parms);
}

void AActor::Nav Left(){

	static UObject* p_Nav Left = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Nav Left");

	struct {
	} parms;


	ProcessEvent(p_Nav Left, &parms);
}

void AActor::Nav Right(){

	static UObject* p_Nav Right = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Nav Right");

	struct {
	} parms;


	ProcessEvent(p_Nav Right, &parms);
}

void AActor::Nav Up(){

	static UObject* p_Nav Up = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Nav Up");

	struct {
	} parms;


	ProcessEvent(p_Nav Up, &parms);
}

void AActor::Nav Down(){

	static UObject* p_Nav Down = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Nav Down");

	struct {
	} parms;


	ProcessEvent(p_Nav Down, &parms);
}

void AActor::Nav Release(){

	static UObject* p_Nav Release = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Nav Release");

	struct {
	} parms;


	ProcessEvent(p_Nav Release, &parms);
}

void AActor::Cancel(){

	static UObject* p_Cancel = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Cancel");

	struct {
	} parms;


	ProcessEvent(p_Cancel, &parms);
}

void AActor::Confirm(){

	static UObject* p_Confirm = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Confirm");

	struct {
	} parms;


	ProcessEvent(p_Confirm, &parms);
}

void AActor::Action 1(){

	static UObject* p_Action 1 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 1");

	struct {
	} parms;


	ProcessEvent(p_Action 1, &parms);
}

void AActor::Action 2(){

	static UObject* p_Action 2 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 2");

	struct {
	} parms;


	ProcessEvent(p_Action 2, &parms);
}

void AActor::Action 3(){

	static UObject* p_Action 3 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 3");

	struct {
	} parms;


	ProcessEvent(p_Action 3, &parms);
}

void AActor::Action 4(){

	static UObject* p_Action 4 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 4");

	struct {
	} parms;


	ProcessEvent(p_Action 4, &parms);
}

void AActor::Action 5(){

	static UObject* p_Action 5 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 5");

	struct {
	} parms;


	ProcessEvent(p_Action 5, &parms);
}

void AActor::Action 6(){

	static UObject* p_Action 6 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 6");

	struct {
	} parms;


	ProcessEvent(p_Action 6, &parms);
}

void AActor::Action 7(){

	static UObject* p_Action 7 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 7");

	struct {
	} parms;


	ProcessEvent(p_Action 7, &parms);
}

void AActor::Action 8(){

	static UObject* p_Action 8 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 8");

	struct {
	} parms;


	ProcessEvent(p_Action 8, &parms);
}

void AActor::Action 9(){

	static UObject* p_Action 9 = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action 9");

	struct {
	} parms;


	ProcessEvent(p_Action 9, &parms);
}

void AActor::Action Main(){

	static UObject* p_Action Main = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Action Main");

	struct {
	} parms;


	ProcessEvent(p_Action Main, &parms);
}

void AActor::Scroll Up(){

	static UObject* p_Scroll Up = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Scroll Up");

	struct {
	} parms;


	ProcessEvent(p_Scroll Up, &parms);
}

void AActor::Scroll Down(){

	static UObject* p_Scroll Down = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Scroll Down");

	struct {
	} parms;


	ProcessEvent(p_Scroll Down, &parms);
}

void AActor::Main Fire(){

	static UObject* p_Main Fire = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Main Fire");

	struct {
	} parms;


	ProcessEvent(p_Main Fire, &parms);
}

void AActor::Main Fire Release(){

	static UObject* p_Main Fire Release = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Main Fire Release");

	struct {
	} parms;


	ProcessEvent(p_Main Fire Release, &parms);
}

void AActor::Secondary Fire(){

	static UObject* p_Secondary Fire = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Secondary Fire");

	struct {
	} parms;


	ProcessEvent(p_Secondary Fire, &parms);
}

void AActor::Secondary Fire Release(){

	static UObject* p_Secondary Fire Release = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Secondary Fire Release");

	struct {
	} parms;


	ProcessEvent(p_Secondary Fire Release, &parms);
}

void AActor::Cycle Left(){

	static UObject* p_Cycle Left = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Cycle Left");

	struct {
	} parms;


	ProcessEvent(p_Cycle Left, &parms);
}

void AActor::Cycle Right(){

	static UObject* p_Cycle Right = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Cycle Right");

	struct {
	} parms;


	ProcessEvent(p_Cycle Right, &parms);
}

void AActor::Exit(){

	static UObject* p_Exit = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Exit");

	struct {
	} parms;


	ProcessEvent(p_Exit, &parms);
}

void AActor::Reset(){

	static UObject* p_Reset = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Reset");

	struct {
	} parms;


	ProcessEvent(p_Reset, &parms);
}

void AActor::Interact(struct ACharacter* Character){

	static UObject* p_Interact = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Interact");

	struct {
		struct ACharacter* Character;
	} parms;

	parms.Character = Character;

	ProcessEvent(p_Interact, &parms);
}

void AActor::In Range(bool Value){

	static UObject* p_In Range = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.In Range");

	struct {
		bool Value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_In Range, &parms);
}

void AActor::TL Move(double Duration (s), struct FVector Direction, double Input Scale){

	static UObject* p_TL Move = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.TL Move");

	struct {
		double Duration (s);
		struct FVector Direction;
		double Input Scale;
	} parms;

	parms.Duration (s) = Duration (s);
	parms.Direction = Direction;
	parms.Input Scale = Input Scale;

	ProcessEvent(p_TL Move, &parms);
}

void AActor::MC Sound(struct USoundBase* Sound, struct FVector Location, struct USoundAttenuation* Attenuation){

	static UObject* p_MC Sound = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.MC Sound");

	struct {
		struct USoundBase* Sound;
		struct FVector Location;
		struct USoundAttenuation* Attenuation;
	} parms;

	parms.Sound = Sound;
	parms.Location = Location;
	parms.Attenuation = Attenuation;

	ProcessEvent(p_MC Sound, &parms);
}

void AActor::MC Decal(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, double LifeSpan){

	static UObject* p_MC Decal = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.MC Decal");

	struct {
		struct UMaterialInterface* DecalMaterial;
		struct FVector DecalSize;
		struct FVector Location;
		struct FRotator Rotation;
		double LifeSpan;
	} parms;

	parms.DecalMaterial = DecalMaterial;
	parms.DecalSize = DecalSize;
	parms.Location = Location;
	parms.Rotation = Rotation;
	parms.LifeSpan = LifeSpan;

	ProcessEvent(p_MC Decal, &parms);
}

void AActor::Decal(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, double LifeSpan){

	static UObject* p_Decal = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Decal");

	struct {
		struct UMaterialInterface* DecalMaterial;
		struct FVector DecalSize;
		struct FVector Location;
		struct FRotator Rotation;
		double LifeSpan;
	} parms;

	parms.DecalMaterial = DecalMaterial;
	parms.DecalSize = DecalSize;
	parms.Location = Location;
	parms.Rotation = Rotation;
	parms.LifeSpan = LifeSpan;

	ProcessEvent(p_Decal, &parms);
}

void AActor::Play Sound(struct USoundBase* Sound, struct FVector Location, struct USoundAttenuation* Attenuation){

	static UObject* p_Play Sound = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Play Sound");

	struct {
		struct USoundBase* Sound;
		struct FVector Location;
		struct USoundAttenuation* Attenuation;
	} parms;

	parms.Sound = Sound;
	parms.Location = Location;
	parms.Attenuation = Attenuation;

	ProcessEvent(p_Play Sound, &parms);
}

void AActor::ReceiveDestroyed(){

	static UObject* p_ReceiveDestroyed = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.ReceiveDestroyed");

	struct {
	} parms;


	ProcessEvent(p_ReceiveDestroyed, &parms);
}

void AActor::Create Widget(){

	static UObject* p_Create Widget = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Create Widget");

	struct {
	} parms;


	ProcessEvent(p_Create Widget, &parms);
}

void AActor::Emitter(struct UParticleSystem* Emitter, struct FVector Location, struct FRotator Rotation, struct FVector Scale){

	static UObject* p_Emitter = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Emitter");

	struct {
		struct UParticleSystem* Emitter;
		struct FVector Location;
		struct FRotator Rotation;
		struct FVector Scale;
	} parms;

	parms.Emitter = Emitter;
	parms.Location = Location;
	parms.Rotation = Rotation;
	parms.Scale = Scale;

	ProcessEvent(p_Emitter, &parms);
}

void AActor::MC Emitter(struct UParticleSystem* Emitter, struct FVector Location, struct FRotator Rotation, struct FVector Scale){

	static UObject* p_MC Emitter = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.MC Emitter");

	struct {
		struct UParticleSystem* Emitter;
		struct FVector Location;
		struct FRotator Rotation;
		struct FVector Scale;
	} parms;

	parms.Emitter = Emitter;
	parms.Location = Location;
	parms.Rotation = Rotation;
	parms.Scale = Scale;

	ProcessEvent(p_MC Emitter, &parms);
}

void AActor::Phys Mat Impact(struct FVector Location, struct UPhysicalMaterial* Phys Mat){

	static UObject* p_Phys Mat Impact = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Phys Mat Impact");

	struct {
		struct FVector Location;
		struct UPhysicalMaterial* Phys Mat;
	} parms;

	parms.Location = Location;
	parms.Phys Mat = Phys Mat;

	ProcessEvent(p_Phys Mat Impact, &parms);
}

void AActor::Set Acceleration(double MaxAcceleration){

	static UObject* p_Set Acceleration = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Set Acceleration");

	struct {
		double MaxAcceleration;
	} parms;

	parms.MaxAcceleration = MaxAcceleration;

	ProcessEvent(p_Set Acceleration, &parms);
}

void AActor::Toggle Lock On Widget(struct AActor* Target){

	static UObject* p_Toggle Lock On Widget = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.Toggle Lock On Widget");

	struct {
		struct AActor* Target;
	} parms;

	parms.Target = Target;

	ProcessEvent(p_Toggle Lock On Widget, &parms);
}

void AActor::ExecuteUbergraph_A_Tool_Base(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_A_Tool_Base = UObject::FindObject<UFunction>("Function A_Tool_Base.A_Tool_Base_C.ExecuteUbergraph_A_Tool_Base");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_A_Tool_Base, &parms);
}

