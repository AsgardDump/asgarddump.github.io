#include "SDK.h" 
 
 
void UInterface::StopLink(){

	static UObject* p_StopLink = UObject::FindObject<UFunction>("Function AudioLinkEngine.AudioLinkBlueprintInterface.StopLink");

	struct {
	} parms;


	ProcessEvent(p_StopLink, &parms);
}

void UInterface::SetLinkSound(struct USoundBase* NewSound){

	static UObject* p_SetLinkSound = UObject::FindObject<UFunction>("Function AudioLinkEngine.AudioLinkBlueprintInterface.SetLinkSound");

	struct {
		struct USoundBase* NewSound;
	} parms;

	parms.NewSound = NewSound;

	ProcessEvent(p_SetLinkSound, &parms);
}

void UInterface::PlayLink(float StartTime){

	static UObject* p_PlayLink = UObject::FindObject<UFunction>("Function AudioLinkEngine.AudioLinkBlueprintInterface.PlayLink");

	struct {
		float StartTime;
	} parms;

	parms.StartTime = StartTime;

	ProcessEvent(p_PlayLink, &parms);
}

bool UInterface::IsLinkPlaying(){

	static UObject* p_IsLinkPlaying = UObject::FindObject<UFunction>("Function AudioLinkEngine.AudioLinkBlueprintInterface.IsLinkPlaying");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsLinkPlaying, &parms);
	return parms.return_value;
}

