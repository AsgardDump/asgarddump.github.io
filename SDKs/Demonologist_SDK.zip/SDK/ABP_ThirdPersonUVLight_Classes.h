#pragma once 
#include <ABP_ThirdPersonUVLight_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonUVLight.ABP_ThirdPersonUVLight_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonUVLight_C : public UABP_ThirdPersonToolLayer_C
{

}; 



