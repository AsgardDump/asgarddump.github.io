#pragma once 
#include <ABP_ThirdPersonSpiritBox_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonSpiritBox.ABP_ThirdPersonSpiritBox_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonSpiritBox_C : public UABP_ThirdPersonToolLayer_C
{

}; 



