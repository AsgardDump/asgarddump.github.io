#pragma once 
#include <ABP_ThirdPersonTape_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonTape.ABP_ThirdPersonTape_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonTape_C : public UABP_ThirdPersonToolLayer_C
{

}; 



