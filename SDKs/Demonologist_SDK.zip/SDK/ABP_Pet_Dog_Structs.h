#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Pet_Dog.ABP_Pet_Dog_C.BlueprintThreadSafeUpdateAnimation
// Size: 0x10(Inherited: 0x4) 
struct FBlueprintThreadSafeUpdateAnimation : public FBlueprintThreadSafeUpdateAnimation
{
	float DeltaTime;  // 0x0(0x4)
	double CallFunc_VSize_ReturnValue;  // 0x8(0x8)

}; 
// Function ABP_Pet_Dog.ABP_Pet_Dog_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_Pet_Dog.ABP_Pet_Dog_C.ExecuteUbergraph_ABP_Pet_Dog
// Size: 0x6(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Pet_Dog
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x5(0x1)

}; 
// ScriptStruct ABP_Pet_Dog.ABP_Pet_Dog_C.AnimBlueprintGeneratedConstantData
// Size: 0x128(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_37;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool __BoolProperty_38 : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)
	float __FloatProperty_39;  // 0x10(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_40;  // 0x14(0x2C)
	float __FloatProperty_41;  // 0x40(0x4)
	float __FloatProperty_42;  // 0x44(0x4)
	uint8_t  __EnumProperty_43;  // 0x48(0x1)
	char EAnimGroupRole __ByteProperty_44;  // 0x49(0x1)
	char pad_74[2];  // 0x4A(0x2)
	struct FName __NameProperty_45;  // 0x4C(0x8)
	int32_t __IntProperty_46;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool __BoolProperty_47 : 1;  // 0x58(0x1)
	char pad_89[3];  // 0x59(0x3)
	struct FName __NameProperty_48;  // 0x5C(0x8)
	struct FName __NameProperty_49;  // 0x64(0x8)
	int32_t __IntProperty_50;  // 0x6C(0x4)
	struct FAnimNodeFunctionRef __StructProperty_51;  // 0x70(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x90(0x80)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x110(0x18)

}; 
