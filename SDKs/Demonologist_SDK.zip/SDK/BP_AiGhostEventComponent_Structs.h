#pragma once 
#include "SDK.h" 
 
 
// Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.CanInstigatorInteract
// Size: 0xC(Inherited: 0xC) 
struct FCanInstigatorInteract : public FCanInstigatorInteract
{
	struct AActor* Instigator;  // 0x0(0x8)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool CallFunc_CanInstigatorInteract_ReturnValue : 1;  // 0x9(0x1)
	char pad_22_1 : 7;  // 0x16(0x1)
	bool CallFunc_CustomInteractionCondition_ReturnValue : 1;  // 0xA(0x1)
	char pad_23_1 : 7;  // 0x17(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.ExecuteUbergraph_BP_AiGhostEventComponent
// Size: 0xE0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_AiGhostEventComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FS_SequenceQueryInformation K2Node_CustomEvent_SequenceQuery;  // 0x10(0x20)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x30(0x8)
	struct TScriptInterface<IBPI_PlayerCharacter_C> K2Node_DynamicCast_AsBPI_Player_Character;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	double CallFunc_GetBaseEntityDrain_ReturnValue;  // 0x50(0x8)
	double CallFunc_Map_Find_Value;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsServer_ReturnValue_2 : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	double CallFunc_SelectFloat_ReturnValue;  // 0x68(0x8)
	double CallFunc_Map_Find_Value_2;  // 0x70(0x8)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool CallFunc_Map_Find_ReturnValue_2 : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x80(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x90(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x98(0x10)
	struct TScriptInterface<IBPI_PlayerCharacter_C> K2Node_DynamicCast_AsBPI_Player_Character_2;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xBC(0x4)
	double CallFunc_GetBaseEntityDrain_ReturnValue_2;  // 0xC0(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0xC8(0x4)
	char pad_204[4];  // 0xCC(0x4)
	double CallFunc_SelectFloat_ReturnValue_2;  // 0xD0(0x8)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xD8(0x1)
	char pad_217[3];  // 0xD9(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xDC(0x4)

}; 
// Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.OnSequencePlayedCallback
// Size: 0x20(Inherited: 0x0) 
struct FOnSequencePlayedCallback
{
	struct FS_SequenceQueryInformation SequenceQuery;  // 0x0(0x20)

}; 
// Function BP_AiGhostEventComponent.BP_AiGhostEventComponent_C.GetBaseEntityDrain
// Size: 0x28(Inherited: 0x0) 
struct FGetBaseEntityDrain
{
	double ReturnValue;  // 0x0(0x8)
	struct ABP_Entity_C* CallFunc_GetAiReference_ReturnValue;  // 0x8(0x8)
	struct ABP_Entity_C* K2Node_DynamicCast_AsBP_Entity;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	double CallFunc_GetGhostEventDrainRate_ReturnValue;  // 0x20(0x8)

}; 
