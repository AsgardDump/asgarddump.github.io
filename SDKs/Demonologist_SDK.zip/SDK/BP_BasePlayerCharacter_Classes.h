#pragma once 
#include <BP_BasePlayerCharacter_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BasePlayerCharacter.BP_BasePlayerCharacter_C
// Size: 0x9C0(Inherited: 0x858) 
struct ABP_BasePlayerCharacter_C : public ABP_BasicCharacter_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x858(0x8)
	struct UWidgetInteractionComponent* WidgetInteraction;  // 0x860(0x8)
	struct UBP_ShiversCharacterCustomization_C* BP_ShiversCharacterCustomization;  // 0x868(0x8)
	struct UBP_SprintComponent_C* BP_SprintComponent;  // 0x870(0x8)
	struct UBP_PlayerInteractionComponent_C* BP_InteractionComponent;  // 0x878(0x8)
	float CrouchingTimelineLocal_CrouchTrack_5343E86949F1C14A1ACE128491AE9DFC;  // 0x880(0x4)
	char ETimelineDirection CrouchingTimelineLocal__Direction_5343E86949F1C14A1ACE128491AE9DFC;  // 0x884(0x1)
	char pad_2181[3];  // 0x885(0x3)
	struct UTimelineComponent* CrouchingTimelineLocal;  // 0x888(0x8)
	float CrouchingTimeLine_CrouchTrack_30C07EAC4E45325FB2C937AB0FDB628E;  // 0x890(0x4)
	char ETimelineDirection CrouchingTimeLine__Direction_30C07EAC4E45325FB2C937AB0FDB628E;  // 0x894(0x1)
	char pad_2197[3];  // 0x895(0x3)
	struct UTimelineComponent* CrouchingTimeLine;  // 0x898(0x8)
	struct FTimerHandle StaminaUpdateTimer;  // 0x8A0(0x8)
	struct FRotator ControlRotation;  // 0x8A8(0x18)
	struct FVector MovementInput;  // 0x8C0(0x18)
	char pad_2264_1 : 7;  // 0x8D8(0x1)
	bool Is Sprinting : 1;  // 0x8D8(0x1)
	char pad_2265[7];  // 0x8D9(0x7)
	struct FS_ShiversCharacterCustomizationRep CharacterCustomizationData;  // 0x8E0(0xA8)
	double CurrentCharacterSpeed;  // 0x988(0x8)
	struct FFCharacterLocalData CharacterLocalData;  // 0x990(0x4)
	char pad_2452[4];  // 0x994(0x4)
	struct FMulticastInlineDelegate CharacterLocalDataChanged;  // 0x998(0x10)
	struct UAudioComponent* BreathSound;  // 0x9A8(0x8)
	char pad_2480_1 : 7;  // 0x9B0(0x1)
	bool bVoiceMuted : 1;  // 0x9B0(0x1)
	char E_VoiceInputMode VoiceInputMode;  // 0x9B1(0x1)
	char pad_2482_1 : 7;  // 0x9B2(0x1)
	bool bCrouching : 1;  // 0x9B2(0x1)
	char pad_2483_1 : 7;  // 0x9B3(0x1)
	bool bCrouchingLocal : 1;  // 0x9B3(0x1)
	char pad_2484[4];  // 0x9B4(0x4)
	double CrouchingValueLocal;  // 0x9B8(0x8)

	struct USkeletalMeshComponent* GetSkeletalMesh(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetSkeletalMesh
	struct USkeletalMeshComponent* GetTpsMesh(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetTpsMesh
	void UpdateCharacterCustomization(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterCustomization
	void IsFocusedOnAnySmartTV(bool& Result); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.IsFocusedOnAnySmartTV
	void OnRep_bCrouching(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_bCrouching
	void SetVoiceMode(char E_VoiceInputMode VoiceInputMode); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetVoiceMode
	void SetInputActive(bool bIsActive); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetInputActive
	void SetMovementActive(bool bIsActive); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetMovementActive
	void GetIsVoiceMuted(bool& bIsVivoxMuted); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetIsVoiceMuted
	void SetIsVoiceMuted(bool bMuted); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetIsVoiceMuted
	void OnRep_CharacterLocalData(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_CharacterLocalData
	void OnRep_CurrentCharacterSpeed(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_CurrentCharacterSpeed
	void OnRep_CharacterCustomizationData(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_CharacterCustomizationData
	void SetWidgetInteractionActive(bool bNewActive); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetWidgetInteractionActive
	void CalculateIKHand(double DeltaSec); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CalculateIKHand
	void UploadCharacterLocalDataToServer(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UploadCharacterLocalDataToServer
	void SetTpsCastShadowVisibility(bool NewCastShadow); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetTpsCastShadowVisibility
	void ReplicateCustomizationData(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReplicateCustomizationData
	void CrouchingTimeLine__FinishedFunc(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimeLine__FinishedFunc
	void CrouchingTimeLine__UpdateFunc(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimeLine__UpdateFunc
	void CrouchingTimelineLocal__FinishedFunc(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimelineLocal__FinishedFunc
	void CrouchingTimelineLocal__UpdateFunc(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingTimelineLocal__UpdateFunc
	void InpActEvt_Sprint_K2Node_InputActionEvent_8(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Sprint_K2Node_InputActionEvent_8
	void InpActEvt_Sprint_K2Node_InputActionEvent_7(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Sprint_K2Node_InputActionEvent_7
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3
	void InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2
	void InpActEvt_SpaceBar_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_SpaceBar_K2Node_InputKeyEvent_1
	void InpActEvt_CommandConsole_K2Node_InputActionEvent_6(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_CommandConsole_K2Node_InputActionEvent_6
	void InpActEvt_EscapeMenu_K2Node_InputActionEvent_5(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_EscapeMenu_K2Node_InputActionEvent_5
	void InpActEvt_PushToTalk_K2Node_InputActionEvent_4(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_PushToTalk_K2Node_InputActionEvent_4
	void InpActEvt_PushToTalk_K2Node_InputActionEvent_3(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_PushToTalk_K2Node_InputActionEvent_3
	void InpActEvt_Crouching_K2Node_InputActionEvent_2(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Crouching_K2Node_InputActionEvent_2
	void InpActEvt_VoicePromptLine_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_VoicePromptLine_K2Node_InputActionEvent_1
	void ReceiveTick(float DeltaSeconds); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReceiveTick
	void ReceiveBeginPlay(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReceiveBeginPlay
	void BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature(bool IsSprinting); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature
	void UpdateCharacterMovementSpeed(float Max Walk Speed); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterMovementSpeed
	void SendMessage On Server(struct FString Message); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SendMessage On Server
	void BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_1_OnTired__DelegateSignature(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_1_OnTired__DelegateSignature
	void SetCharacterLocalData OnServer(struct FFCharacterLocalData CharacterLocalData); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetCharacterLocalData OnServer
	void UpdateCharacterMovementSpeedServer(float Max Walk Speed); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterMovementSpeedServer
	void Set Character Customization Data On Server(struct FS_ShiversCharacterCustomizationRep New CC Rep Data); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.Set Character Customization Data On Server
	void DestoryCustomizationComponent(struct USkeletalMeshComponent* SkeletalMeshComponentReference); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.DestoryCustomizationComponent
	void CrouchOnServer(bool bCrouch); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchOnServer
	void CrouchingLocal(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchingLocal
	void CrouchEvent(bool bCrouching); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchEvent
	void SetMovementInputServer(struct FVector MovementInput); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetMovementInputServer
	void ReplicateAnimationVariables(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReplicateAnimationVariables
	void OnLevelUpdated(struct UObject* Publisher, struct UObject* Payload, struct TArray<struct FString>& MetaData); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnLevelUpdated
	void UpdateVivox3DPosition(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateVivox3DPosition
	void ExecuteUbergraph_BP_BasePlayerCharacter(int32_t EntryPoint); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ExecuteUbergraph_BP_BasePlayerCharacter
	void CharacterLocalDataChanged__DelegateSignature(); // Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CharacterLocalDataChanged__DelegateSignature
}; 



