#pragma once 
#include "SDK.h" 
 
 
// Function A_Tool_Base.A_Tool_Base_C.Attack Combo
// Size: 0x4(Inherited: 0x0) 
struct FAttack Combo
{
	int32_t Count;  // 0x0(0x4)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Emitter
// Size: 0x50(Inherited: 0x0) 
struct FEmitter
{
	struct UParticleSystem* Emitter;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)
	struct FRotator Rotation;  // 0x20(0x18)
	struct FVector Scale;  // 0x38(0x18)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Character Mesh
// Size: 0x10(Inherited: 0x0) 
struct FCharacter Mesh
{
	struct USkeletalMeshComponent* Mesh;  // 0x0(0x8)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x8(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.TL Move
// Size: 0x28(Inherited: 0x0) 
struct FTL Move
{
	double Duration (s);  // 0x0(0x8)
	struct FVector Direction;  // 0x8(0x18)
	double Input Scale;  // 0x20(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Get Interact Location
// Size: 0x20(Inherited: 0x0) 
struct FGet Interact Location
{
	struct AActor* Actor;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Decal
// Size: 0x58(Inherited: 0x0) 
struct FDecal
{
	struct UMaterialInterface* DecalMaterial;  // 0x0(0x8)
	struct FVector DecalSize;  // 0x8(0x18)
	struct FVector Location;  // 0x20(0x18)
	struct FRotator Rotation;  // 0x38(0x18)
	double LifeSpan;  // 0x50(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Combat Component
// Size: 0x18(Inherited: 0x0) 
struct FCombat Component
{
	struct UCombat_C* ReturnValue;  // 0x0(0x8)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x8(0x8)
	struct UCombat_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x10(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.ExecuteUbergraph_A_Tool_Base
// Size: 0x3F0(Inherited: 0x0) 
struct FExecuteUbergraph_A_Tool_Base
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Temp_bool_Variable : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue;  // 0x21(0x1)
	char pad_34_1 : 7;  // 0x22(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x22(0x1)
	char pad_35_1 : 7;  // 0x23(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x23(0x1)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x28(0x8)
	struct APawn* K2Node_DynamicCast_AsPawn_2;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_IsPlayerControlled_ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct APawn* K2Node_DynamicCast_AsPawn_3;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_IsPlayerControlled_ReturnValue_2 : 1;  // 0x5A(0x1)
	char pad_91_1 : 7;  // 0x5B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x5B(0x1)
	char pad_92_1 : 7;  // 0x5C(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0x5C(0x1)
	char pad_93_1 : 7;  // 0x5D(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x5D(0x1)
	char pad_94[2];  // 0x5E(0x2)
	struct ACharacter* K2Node_Event_Character;  // 0x60(0x8)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_Event_Value : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)
	double K2Node_CustomEvent_Duration__s_;  // 0x70(0x8)
	struct FVector K2Node_CustomEvent_Direction;  // 0x78(0x18)
	double K2Node_CustomEvent_Input_Scale;  // 0x90(0x8)
	double CallFunc_Divide_DoubleDouble_ReturnValue;  // 0x98(0x8)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_2;  // 0xA0(0x1)
	char pad_161_1 : 7;  // 0xA1(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_3 : 1;  // 0xA1(0x1)
	char pad_162_1 : 7;  // 0xA2(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_4 : 1;  // 0xA2(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_3;  // 0xA3(0x1)
	char pad_164[4];  // 0xA4(0x4)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_5 : 1;  // 0xB0(0x1)
	char pad_177[7];  // 0xB1(0x7)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0xB8(0x18)
	float CallFunc_BreakRotator_Roll;  // 0xD0(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0xD4(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0xD8(0x4)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_6 : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0xE0(0x8)
	float CallFunc_GetCurveValue_ReturnValue;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_2;  // 0xF0(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0xF8(0x18)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool CallFunc_NotEqual_DoubleDouble_ReturnValue : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x118(0x18)
	int32_t CallFunc_FCeil_ReturnValue;  // 0x130(0x4)
	char pad_308[4];  // 0x134(0x4)
	struct FVector K2Node_Select_Default;  // 0x138(0x18)
	float CallFunc_Conv_IntToFloat_ReturnValue;  // 0x150(0x4)
	char pad_340[4];  // 0x154(0x4)
	struct USoundBase* K2Node_CustomEvent_Sound_2;  // 0x158(0x8)
	struct FVector K2Node_CustomEvent_Location_7;  // 0x160(0x18)
	struct USoundAttenuation* K2Node_CustomEvent_Attenuation_2;  // 0x178(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x180(0x8)
	struct UMaterialInterface* K2Node_CustomEvent_DecalMaterial_2;  // 0x188(0x8)
	struct FVector K2Node_CustomEvent_DecalSize_2;  // 0x190(0x18)
	struct FVector K2Node_CustomEvent_Location_6;  // 0x1A8(0x18)
	struct FRotator K2Node_CustomEvent_Rotation_4;  // 0x1C0(0x18)
	double K2Node_CustomEvent_LifeSpan_2;  // 0x1D8(0x8)
	struct UMaterialInterface* K2Node_CustomEvent_DecalMaterial;  // 0x1E0(0x8)
	struct FVector K2Node_CustomEvent_DecalSize;  // 0x1E8(0x18)
	struct FVector K2Node_CustomEvent_Location_5;  // 0x200(0x18)
	struct FRotator K2Node_CustomEvent_Rotation_3;  // 0x218(0x18)
	double K2Node_CustomEvent_LifeSpan;  // 0x230(0x8)
	struct UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct UDecalComponent* CallFunc_SpawnDecalAtLocation_ReturnValue_2;  // 0x248(0x8)
	struct USoundBase* K2Node_CustomEvent_Sound;  // 0x250(0x8)
	struct FVector K2Node_CustomEvent_Location_4;  // 0x258(0x18)
	struct USoundAttenuation* K2Node_CustomEvent_Attenuation;  // 0x270(0x8)
	char pad_632_1 : 7;  // 0x278(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x278(0x1)
	char pad_633[7];  // 0x279(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x280(0x8)
	struct UUserWidget* CallFunc_Create_ReturnValue;  // 0x288(0x8)
	struct UParticleSystem* K2Node_CustomEvent_Emitter_2;  // 0x290(0x8)
	struct FVector K2Node_CustomEvent_Location_3;  // 0x298(0x18)
	struct FRotator K2Node_CustomEvent_Rotation_2;  // 0x2B0(0x18)
	struct FVector K2Node_CustomEvent_Scale_2;  // 0x2C8(0x18)
	struct UParticleSystem* K2Node_CustomEvent_Emitter;  // 0x2E0(0x8)
	struct FVector K2Node_CustomEvent_Location_2;  // 0x2E8(0x18)
	struct FRotator K2Node_CustomEvent_Rotation;  // 0x300(0x18)
	struct FVector K2Node_CustomEvent_Scale;  // 0x318(0x18)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue;  // 0x330(0x8)
	struct UParticleSystemComponent* CallFunc_SpawnEmitterAtLocation_ReturnValue_2;  // 0x338(0x8)
	struct FVector K2Node_CustomEvent_Location;  // 0x340(0x18)
	struct UPhysicalMaterial* K2Node_CustomEvent_Phys_Mat;  // 0x358(0x8)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_4;  // 0x360(0x1)
	char pad_865[7];  // 0x361(0x7)
	struct USoundBase* CallFunc_Map_Find_Value;  // 0x368(0x8)
	char pad_880_1 : 7;  // 0x370(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x370(0x1)
	char pad_881_1 : 7;  // 0x371(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_7 : 1;  // 0x371(0x1)
	char pad_882_1 : 7;  // 0x372(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_8 : 1;  // 0x372(0x1)
	char pad_883[5];  // 0x373(0x5)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter_3;  // 0x378(0x8)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x380(0x1)
	char pad_897[7];  // 0x381(0x7)
	double K2Node_CustomEvent_MaxAcceleration;  // 0x388(0x8)
	char pad_912_1 : 7;  // 0x390(0x1)
	bool CallFunc_IsStandalone_ReturnValue : 1;  // 0x390(0x1)
	char pad_913[7];  // 0x391(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x398(0x8)
	struct UCombat_C* CallFunc_Combat_Component_ReturnValue;  // 0x3A0(0x8)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_5;  // 0x3A8(0x1)
	char pad_937_1 : 7;  // 0x3A9(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_9 : 1;  // 0x3A9(0x1)
	char pad_938_1 : 7;  // 0x3AA(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x3AA(0x1)
	char pad_939_1 : 7;  // 0x3AB(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_10 : 1;  // 0x3AB(0x1)
	char pad_940[4];  // 0x3AC(0x4)
	struct AActor* K2Node_CustomEvent_Target;  // 0x3B0(0x8)
	struct UCombat_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x3B8(0x8)
	char ENetRole CallFunc_GetLocalRole_ReturnValue_6;  // 0x3C0(0x1)
	char pad_961_1 : 7;  // 0x3C1(0x1)
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // 0x3C1(0x1)
	char pad_962_1 : 7;  // 0x3C2(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_11 : 1;  // 0x3C2(0x1)
	char pad_963_1 : 7;  // 0x3C3(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_12 : 1;  // 0x3C3(0x1)
	float CallFunc_SetPlayRate_NewRate_ImplicitCast;  // 0x3C4(0x4)
	double CallFunc_FCeil_A_ImplicitCast;  // 0x3C8(0x8)
	double CallFunc_NotEqual_DoubleDouble_A_ImplicitCast;  // 0x3D0(0x8)
	double CallFunc_Multiply_DoubleDouble_B_ImplicitCast;  // 0x3D8(0x8)
	float CallFunc_AddMovementInput_ScaleValue_ImplicitCast;  // 0x3E0(0x4)
	float CallFunc_SpawnDecalAtLocation_LifeSpan_ImplicitCast;  // 0x3E4(0x4)
	float CallFunc_SpawnDecalAtLocation_LifeSpan_ImplicitCast_2;  // 0x3E8(0x4)
	float K2Node_VariableSet_MaxAcceleration_ImplicitCast;  // 0x3EC(0x4)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Get Focal Point
// Size: 0x20(Inherited: 0x0) 
struct FGet Focal Point
{
	struct AActor* Pawn;  // 0x0(0x8)
	struct FVector Focal Point;  // 0x8(0x18)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Hit Check
// Size: 0x234(Inherited: 0x0) 
struct FHit Check
{
	struct TArray<struct FHitResult> Hits;  // 0x0(0x10)
	struct TArray<struct FHitResult> Valid Hits;  // 0x10(0x10)
	struct TArray<struct FHitResult> Local Valid Hits;  // 0x20(0x10)
	struct TArray<struct AActor*> Local Valid Actors;  // 0x30(0x10)
	struct TArray<struct AActor*> NewLocalVar_1;  // 0x40(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x50(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x54(0x4)
	struct FHitResult CallFunc_Array_Get_Item;  // 0x58(0xE8)
	char pad_320_1 : 7;  // 0x140(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x140(0x1)
	char pad_321_1 : 7;  // 0x141(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x141(0x1)
	char pad_322[2];  // 0x142(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x144(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x148(0x4)
	char pad_332[4];  // 0x14C(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x150(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x168(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x180(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x198(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x1B0(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x1B8(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x1C0(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x1C8(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x1D0(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x1D8(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x1DC(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x1E0(0x4)
	char pad_484[4];  // 0x1E4(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x1E8(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x200(0x18)
	char pad_536_1 : 7;  // 0x218(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x218(0x1)
	char pad_537[3];  // 0x219(0x3)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x21C(0x4)
	int32_t CallFunc_Array_AddUnique_ReturnValue;  // 0x220(0x4)
	char pad_548_1 : 7;  // 0x224(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x224(0x1)
	char pad_549[3];  // 0x225(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x228(0x4)
	char pad_556_1 : 7;  // 0x22C(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x22C(0x1)
	char pad_557[3];  // 0x22D(0x3)
	int32_t CallFunc_Array_AddUnique_ReturnValue_2;  // 0x230(0x4)

}; 
// Function A_Tool_Base.A_Tool_Base_C.In Range
// Size: 0x1(Inherited: 0x0) 
struct FIn Range
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Interact
// Size: 0x8(Inherited: 0x0) 
struct FInteract
{
	struct ACharacter* Character;  // 0x0(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Owner Character
// Size: 0x19(Inherited: 0x0) 
struct FOwner Character
{
	struct ACharacter* AsCharacter;  // 0x0(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x8(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Interactable Check
// Size: 0x1A(Inherited: 0x0) 
struct FInteractable Check
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Interactable : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x19(0x1)

}; 
// Function A_Tool_Base.A_Tool_Base_C.MC Decal
// Size: 0x58(Inherited: 0x0) 
struct FMC Decal
{
	struct UMaterialInterface* DecalMaterial;  // 0x0(0x8)
	struct FVector DecalSize;  // 0x8(0x18)
	struct FVector Location;  // 0x20(0x18)
	struct FRotator Rotation;  // 0x38(0x18)
	double LifeSpan;  // 0x50(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.MC Emitter
// Size: 0x50(Inherited: 0x0) 
struct FMC Emitter
{
	struct UParticleSystem* Emitter;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)
	struct FRotator Rotation;  // 0x20(0x18)
	struct FVector Scale;  // 0x38(0x18)

}; 
// Function A_Tool_Base.A_Tool_Base_C.MC Sound
// Size: 0x28(Inherited: 0x0) 
struct FMC Sound
{
	struct USoundBase* Sound;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)
	struct USoundAttenuation* Attenuation;  // 0x20(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Toggle Lock On Widget
// Size: 0x8(Inherited: 0x0) 
struct FToggle Lock On Widget
{
	struct AActor* Target;  // 0x0(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Phys Mat Impact
// Size: 0x20(Inherited: 0x0) 
struct FPhys Mat Impact
{
	struct FVector Location;  // 0x0(0x18)
	struct UPhysicalMaterial* Phys Mat;  // 0x18(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Play Sound
// Size: 0x28(Inherited: 0x0) 
struct FPlay Sound
{
	struct USoundBase* Sound;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)
	struct USoundAttenuation* Attenuation;  // 0x20(0x8)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Root Bone Vectors
// Size: 0xD8(Inherited: 0x0) 
struct FRoot Bone Vectors
{
	struct FVector Forward Vector;  // 0x0(0x18)
	struct FVector Right Vector;  // 0x18(0x18)
	struct ACharacter* CallFunc_Owner_Character_AsCharacter;  // 0x30(0x8)
	struct FRotator CallFunc_GetSocketRotation_ReturnValue;  // 0x38(0x18)
	float CallFunc_BreakRotator_Roll;  // 0x50(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x54(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0x60(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x68(0x18)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x80(0x18)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x98(0x18)
	struct FVector CallFunc_GetRightVector_ReturnValue;  // 0xB0(0x18)
	double CallFunc_Add_DoubleDouble_A_ImplicitCast;  // 0xC8(0x8)
	float CallFunc_MakeRotator_Yaw_ImplicitCast;  // 0xD0(0x4)
	float CallFunc_MakeRotator_Yaw_ImplicitCast_2;  // 0xD4(0x4)

}; 
// Function A_Tool_Base.A_Tool_Base_C.Set Acceleration
// Size: 0x8(Inherited: 0x0) 
struct FSet Acceleration
{
	double MaxAcceleration;  // 0x0(0x8)

}; 
