#pragma once 
#include <BP_AiInteractionComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AiInteractionComponent.BP_AiInteractionComponent_C
// Size: 0x134(Inherited: 0xA0) 
struct UBP_AiInteractionComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA0(0x8)
	struct UShapeComponent* InteractionCollision;  // 0xA8(0x8)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool UseCustomInteractionMethodWithCollision : 1;  // 0xB0(0x1)
	char pad_177_1 : 7;  // 0xB1(0x1)
	bool InteractWithCollision : 1;  // 0xB1(0x1)
	char pad_178_1 : 7;  // 0xB2(0x1)
	bool IsInteractionActive : 1;  // 0xB2(0x1)
	char pad_179_1 : 7;  // 0xB3(0x1)
	bool IsEverInteracted : 1;  // 0xB3(0x1)
	char pad_180[4];  // 0xB4(0x4)
	double LastInteractedTime;  // 0xB8(0x8)
	double AiInteractionPercentage;  // 0xC0(0x8)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool CanInteractOnlyOneTime : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)
	double InteractionCooldown;  // 0xD0(0x8)
	struct FVector BoxExtent;  // 0xD8(0x18)
	struct FName LastInteractedGlobalParameterName;  // 0xF0(0x8)
	struct FMulticastInlineDelegate OnInteractionRequested;  // 0xF8(0x10)
	struct AActor* CurrentInstigator;  // 0x108(0x8)
	struct TArray<struct FName> InteractionIdentifiers;  // 0x110(0x10)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool BypassInteractionPercentage : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	struct FName InteractionBoxComponentName;  // 0x124(0x8)
	struct FName AttachComponent;  // 0x12C(0x8)

	struct UShapeComponent* GetInteractionComponentByName(); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.GetInteractionComponentByName
	bool CanInstigatorInteract(struct AActor* Instigator); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.CanInstigatorInteract
	void SetParametersWhenInteracted(); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.SetParametersWhenInteracted
	double GetLastInteractedTime(); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.GetLastInteractedTime
	void InitializeAiInteractionComponent(); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.InitializeAiInteractionComponent
	void ReceiveBeginPlay(); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.ReceiveBeginPlay
	void OnInteractionCollisionOverlapped(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.OnInteractionCollisionOverlapped
	void RequestAiInteraction(struct AActor* Instigator, bool UseCustomInteractionMethod); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.RequestAiInteraction
	void ExecuteUbergraph_BP_AiInteractionComponent(int32_t EntryPoint); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.ExecuteUbergraph_BP_AiInteractionComponent
	void OnInteractionRequested__DelegateSignature(struct AActor* Instigator); // Function BP_AiInteractionComponent.BP_AiInteractionComponent_C.OnInteractionRequested__DelegateSignature
}; 



