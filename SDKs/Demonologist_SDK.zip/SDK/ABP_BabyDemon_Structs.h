#pragma once 
#include "SDK.h" 
 
 
// Function ABP_BabyDemon.ABP_BabyDemon_C.ExecuteUbergraph_ABP_BabyDemon
// Size: 0x8(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_BabyDemon
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaTimeX;  // 0x4(0x4)

}; 
// Function ABP_BabyDemon.ABP_BabyDemon_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// ScriptStruct ABP_BabyDemon.ABP_BabyDemon_C.AnimBlueprintGeneratedConstantData
// Size: 0x138(Inherited: 0x138) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
