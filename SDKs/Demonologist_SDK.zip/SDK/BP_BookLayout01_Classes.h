#pragma once 
#include <BP_BookLayout01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BookLayout01.BP_BookLayout01_C
// Size: 0x394(Inherited: 0x290) 
struct ABP_BookLayout01_C : public AActor
{
	struct UInstancedStaticMeshComponent* InstancedStaticMesh;  // 0x290(0x8)
	struct UStaticMesh* Mesh to Spawn;  // 0x298(0x8)
	int32_t Number of Book;  // 0x2A0(0x4)
	char pad_676[4];  // 0x2A4(0x4)
	double Book Height Scale;  // 0x2A8(0x8)
	double BookLengthSum;  // 0x2B0(0x8)
	double Steps;  // 0x2B8(0x8)
	double Book Thickness;  // 0x2C0(0x8)
	struct FVector End Point;  // 0x2C8(0x18)
	double RandomScaleTemp;  // 0x2E0(0x8)
	double RandomRotateTemp;  // 0x2E8(0x8)
	double BookThicnessTemp;  // 0x2F0(0x8)
	char pad_760[8];  // 0x2F8(0x8)
	struct FTransform TransformTemp;  // 0x300(0x60)
	struct FRandomStream RandomStream;  // 0x360(0x8)
	struct FLinearColor CoverColor;  // 0x368(0x10)
	struct TArray<struct UMaterialInstance*> MatVarious;  // 0x378(0x10)
	double Color Control;  // 0x388(0x8)
	int32_t Design Number;  // 0x390(0x4)

	void UserConstructionScript(); // Function BP_BookLayout01.BP_BookLayout01_C.UserConstructionScript
}; 



