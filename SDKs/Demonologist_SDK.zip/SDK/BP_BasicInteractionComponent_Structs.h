#pragma once 
#include "SDK.h" 
 
 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.CanPlayerInteract
// Size: 0x14(Inherited: 0x17) 
struct FCanPlayerInteract : public FCanPlayerInteract
{
	struct APawn* PawnReference;  // 0x0(0x8)
	struct FName Identifier;  // 0x8(0x8)
	char pad_39_1 : 7;  // 0x27(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_EventBoxInteractionCondition_ReturnValue : 1;  // 0x11(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_GetCanPlayerInteractByAliveness_ReturnValue : 1;  // 0x12(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x13(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.EventBoxInteractionCondition
// Size: 0x1B(Inherited: 0x0) 
struct FEventBoxInteractionCondition
{
	struct APawn* Instigator;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool BypassAuthorization : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_DoesHaveDesiredItem_ReturnValue : 1;  // 0xA(0x1)
	char pad_11[5];  // 0xB(0x5)
	struct UBP_EventBoxComponent_C* CallFunc_GetEventboxComponent_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_CustomInteractionCondition_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.ExecuteUbergraph_BP_BasicInteractionComponent
// Size: 0x23F(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BasicInteractionComponent
{
	int32_t EntryPoint;  // 0x0(0x4)
	char E_InteractionMethods Temp_byte_Variable;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct APlayerController* K2Node_Event_ControllerReference;  // 0x8(0x8)
	struct APawn* K2Node_Event_PawnReference;  // 0x10(0x8)
	double K2Node_Event_TraceInterval;  // 0x18(0x8)
	struct FHitResult K2Node_Event_Details;  // 0x20(0xE8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_Event_IsLocallyControlled : 1;  // 0x108(0x1)
	char pad_265_1 : 7;  // 0x109(0x1)
	bool CallFunc_LookInteractionCondition_ReturnValue : 1;  // 0x109(0x1)
	char pad_266[6];  // 0x10A(0x6)
	struct APawn* K2Node_Event_CharacterPawn;  // 0x110(0x8)
	struct FName K2Node_Event_Identifier;  // 0x118(0x8)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_Event_IsServerExucuted : 1;  // 0x120(0x1)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool CallFunc_EventBoxInteractionCondition_ReturnValue : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct UPrimitiveComponent* K2Node_CustomEvent_OverlappedComponent;  // 0x128(0x8)
	struct AActor* K2Node_CustomEvent_OtherActor;  // 0x130(0x8)
	struct UPrimitiveComponent* K2Node_CustomEvent_OtherComp;  // 0x138(0x8)
	int32_t K2Node_CustomEvent_OtherBodyIndex;  // 0x140(0x4)
	char pad_324_1 : 7;  // 0x144(0x1)
	bool K2Node_CustomEvent_bFromSweep : 1;  // 0x144(0x1)
	char pad_325[3];  // 0x145(0x3)
	struct FHitResult K2Node_CustomEvent_SweepResult;  // 0x148(0xE8)
	struct APawn* K2Node_DynamicCast_AsPawn;  // 0x230(0x8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x238(0x1)
	char pad_569_1 : 7;  // 0x239(0x1)
	bool CallFunc_EventBoxInteractionCondition_ReturnValue_2 : 1;  // 0x239(0x1)
	char pad_570_1 : 7;  // 0x23A(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x23A(0x1)
	char pad_571_1 : 7;  // 0x23B(0x1)
	bool CallFunc_Array_Contains_ReturnValue : 1;  // 0x23B(0x1)
	char pad_572_1 : 7;  // 0x23C(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x23C(0x1)
	char E_InteractionMethods Temp_byte_Variable_2;  // 0x23D(0x1)
	char pad_574_1 : 7;  // 0x23E(0x1)
	bool CallFunc_Array_Contains_ReturnValue_2 : 1;  // 0x23E(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetDegreeBetweenTwoPoints
// Size: 0x1A8(Inherited: 0x0) 
struct FGetDegreeBetweenTwoPoints
{
	struct UObject* CharacterReference;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)
	double ReturnValue;  // 0x20(0x8)
	struct TScriptInterface<IBPI_GenericPlayer_C> K2Node_DynamicCast_AsBPI_Generic_Player;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	double CallFunc_BreakVector_X;  // 0x40(0x8)
	double CallFunc_BreakVector_Y;  // 0x48(0x8)
	double CallFunc_BreakVector_Z;  // 0x50(0x8)
	struct UCameraComponent* CallFunc_GetCameraReference_ReturnValue;  // 0x58(0x8)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x60(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x78(0x18)
	struct TScriptInterface<IBPI_GenericPlayer_C> K2Node_DynamicCast_AsBPI_Generic_Player_2;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	double CallFunc_BreakVector_X_2;  // 0xA8(0x8)
	double CallFunc_BreakVector_Y_2;  // 0xB0(0x8)
	double CallFunc_BreakVector_Z_2;  // 0xB8(0x8)
	struct FRotator CallFunc_GetLookDirection_ReturnValue;  // 0xC0(0x18)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0xD8(0x18)
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // 0xF0(0x18)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x108(0x18)
	struct FVector CallFunc_Normal_ReturnValue;  // 0x120(0x18)
	struct FVector CallFunc_Normal_ReturnValue_2;  // 0x138(0x18)
	double CallFunc_Dot_VectorVector_ReturnValue;  // 0x150(0x8)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x158(0x18)
	double CallFunc_DegAcos_ReturnValue;  // 0x170(0x8)
	double CallFunc_BreakVector_X_3;  // 0x178(0x8)
	double CallFunc_BreakVector_Y_3;  // 0x180(0x8)
	double CallFunc_BreakVector_Z_3;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	double CallFunc_SelectFloat_ReturnValue;  // 0x198(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x1A0(0x8)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.LookEventSuccessful
// Size: 0x9(Inherited: 0x8) 
struct FLookEventSuccessful : public FLookEventSuccessful
{
	struct APawn* Instigator;  // 0x0(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_LookInteractionCondition_ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.InteractObject
// Size: 0x11(Inherited: 0x11) 
struct FInteractObject : public FInteractObject
{
	struct APawn* CharacterPawn;  // 0x0(0x8)
	struct FName Identifier;  // 0x8(0x8)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool IsServerExucuted : 1;  // 0x10(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetDegreePoints
// Size: 0x10(Inherited: 0x0) 
struct FGetDegreePoints
{
	struct TArray<struct FVector> ReturnValue;  // 0x0(0x10)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.InitializeBasicInteraction
// Size: 0x95(Inherited: 0x0) 
struct FInitializeBasicInteraction
{
	int32_t Temp_int_Loop_Counter_Variable;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UBP_EventBoxComponent_C* CallFunc_GetEventboxComponent_ReturnValue;  // 0x10(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UBP_EventBoxComponent_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x38(0x8)
	struct TScriptInterface<IBPI_BasicInteractionOwner_C> K2Node_DynamicCast_AsBPI_Basic_Interaction_Owner;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct TArray<struct FVector> CallFunc_GetDegreePoints_ReturnValue;  // 0x58(0x10)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x68(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x70(0x10)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool CallFunc_DoesImplementInterface_ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UPrimitiveComponent* CallFunc_Array_Get_Item;  // 0x88(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x94(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetEventboxComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetEventboxComponent
{
	struct UBP_EventBoxComponent_C* ReturnValue;  // 0x0(0x8)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.IsDegreeConditionMatch
// Size: 0x109(Inherited: 0x0) 
struct FIsDegreeConditionMatch
{
	struct APawn* PawnReference;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x18(0x8)
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // 0x20(0x8)
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // 0x28(0x18)
	struct FVector CallFunc_GetActorScale3D_ReturnValue;  // 0x40(0x18)
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // 0x58(0x8)
	struct TArray<struct FVector> CallFunc_GetDegreePoints_ReturnValue;  // 0x60(0x10)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x70(0x18)
	struct FVector CallFunc_Array_Get_Item;  // 0x88(0x18)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0xA8(0x18)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct FVector CallFunc_GreaterGreater_VectorRotator_ReturnValue;  // 0xC8(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0xE0(0x18)
	double CallFunc_GetDegreeBetweenTwoPoints_ReturnValue;  // 0xF8(0x8)
	double CallFunc_Abs_ReturnValue;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool CallFunc_Less_DoubleDouble_ReturnValue : 1;  // 0x108(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.IsInteractable
// Size: 0x11(Inherited: 0x0) 
struct FIsInteractable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_EventBoxInteractionCondition_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.LookInteractionCondition
// Size: 0xC(Inherited: 0x0) 
struct FLookInteractionCondition
{
	struct APawn* PawnReference;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool BypassAuthorization : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool CallFunc_EventBoxInteractionCondition_ReturnValue : 1;  // 0xA(0x1)
	char pad_11_1 : 7;  // 0xB(0x1)
	bool CallFunc_IsDegreeConditionMatch_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnInteractionBoxesTriggered
// Size: 0x108(Inherited: 0x0) 
struct FOnInteractionBoxesTriggered
{
	struct UPrimitiveComponent* OverlappedComponent;  // 0x0(0x8)
	struct AActor* OtherActor;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult SweepResult;  // 0x20(0xE8)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnInteractionTriggered__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnInteractionTriggered__DelegateSignature
{
	char E_InteractionMethods InteractionMethod;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APawn* InstigatorReference;  // 0x8(0x8)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnLooked
// Size: 0x101(Inherited: 0x101) 
struct FOnLooked : public FOnLooked
{
	struct APlayerController* ControllerReference;  // 0x0(0x8)
	struct APawn* PawnReference;  // 0x8(0x8)
	double TraceInterval;  // 0x10(0x8)
	struct FHitResult Details;  // 0x18(0xE8)
	char pad_513_1 : 7;  // 0x201(0x1)
	bool IsLocallyControlled : 1;  // 0x100(0x1)

}; 
// Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.RequestInteraction
// Size: 0x10(Inherited: 0x0) 
struct FRequestInteraction
{
	struct APawn* SequenceInstigator;  // 0x0(0x8)
	struct UBP_EventBoxComponent_C* CallFunc_GetEventboxComponent_ReturnValue;  // 0x8(0x8)

}; 
