#pragma once 
#include <ABP_BaseEntity_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_BaseEntity.ABP_BaseEntity_C
// Size: 0x6EC(Inherited: 0x350) 
struct UABP_BaseEntity_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_BlendSpaceGraph;  // 0x360(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x368(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x370(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x390(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B8(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // 0x3E0(0x48)
	struct FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult_3;  // 0x428(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // 0x448(0x48)
	struct FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult_2;  // 0x490(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x4B0(0x48)
	struct FAnimNode_BlendSpaceSampleResult AnimGraphNode_BlendSpaceSampleResult;  // 0x4F8(0x20)
	struct FAnimNode_BlendSpaceGraph AnimGraphNode_BlendSpaceGraph;  // 0x518(0x68)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x580(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x5A0(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x5E8(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x608(0xC8)
	struct UAnimSequenceBase* IdleAnimation;  // 0x6D0(0x8)
	struct UAnimSequenceBase* WalkingAnimation;  // 0x6D8(0x8)
	struct UAnimSequenceBase* RunningAnimation;  // 0x6E0(0x8)
	float SpeedGate;  // 0x6E8(0x4)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_BaseEntity.ABP_BaseEntity_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_CCC274064A0E873E759813960706D066(); // Function ABP_BaseEntity.ABP_BaseEntity_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_CCC274064A0E873E759813960706D066
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_EBB946774B2B98A87D83F49F059226F7(); // Function ABP_BaseEntity.ABP_BaseEntity_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_EBB946774B2B98A87D83F49F059226F7
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_BaseEntity.ABP_BaseEntity_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_BaseEntity(int32_t EntryPoint); // Function ABP_BaseEntity.ABP_BaseEntity_C.ExecuteUbergraph_ABP_BaseEntity
}; 



