#include "SDK.h" 
 
 
void AAIController::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AIC_Entity.AIC_Entity_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AAIController::ExecuteUbergraph_AIC_Entity(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AIC_Entity = UObject::FindObject<UFunction>("Function AIC_Entity.AIC_Entity_C.ExecuteUbergraph_AIC_Entity");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AIC_Entity, &parms);
}

