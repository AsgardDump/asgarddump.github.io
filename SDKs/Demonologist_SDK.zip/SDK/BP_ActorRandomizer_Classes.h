#pragma once 
#include <BP_ActorRandomizer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ActorRandomizer.BP_ActorRandomizer_C
// Size: 0x338(Inherited: 0x290) 
struct ABP_ActorRandomizer_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct USceneComponent* Scene;  // 0x298(0x8)
	struct UBillboardComponent* Billboard;  // 0x2A0(0x8)
	struct TArray<struct FTransform> RandomAreaItems;  // 0x2A8(0x10)
	struct TMap<int32_t, struct AActor*> AttachingMapping;  // 0x2B8(0x50)
	int32_t SpawnRandomItemCount;  // 0x308(0x4)
	char pad_780[4];  // 0x30C(0x4)
	AActor* SpawnClass;  // 0x310(0x8)
	struct TArray<struct AActor*> SpawnedActors;  // 0x318(0x10)
	struct TArray<struct AActor*> PreviewMeshReferences;  // 0x328(0x10)

	void DebugRandomItem(); // Function BP_ActorRandomizer.BP_ActorRandomizer_C.DebugRandomItem
	void ClearSpawnedActors(); // Function BP_ActorRandomizer.BP_ActorRandomizer_C.ClearSpawnedActors
	void RunRandomization(); // Function BP_ActorRandomizer.BP_ActorRandomizer_C.RunRandomization
	void PreviewMeshes(); // Function BP_ActorRandomizer.BP_ActorRandomizer_C.PreviewMeshes
	void ClearPreviewActors(); // Function BP_ActorRandomizer.BP_ActorRandomizer_C.ClearPreviewActors
	void ExecuteUbergraph_BP_ActorRandomizer(int32_t EntryPoint); // Function BP_ActorRandomizer.BP_ActorRandomizer_C.ExecuteUbergraph_BP_ActorRandomizer
}; 



