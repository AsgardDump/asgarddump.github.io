#pragma once 
#include <BP_Cat_Pet_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Cat_Pet.BP_Cat_Pet_C
// Size: 0x660(Inherited: 0x620) 
struct ABP_Cat_Pet_C : public ACharacter
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x620(0x8)
	struct UBillboardComponent* Billboard;  // 0x628(0x8)
	struct UBoxComponent* InteractionBox;  // 0x630(0x8)
	struct UBP_VisualInteractionComponent_C* BP_VisualInteractionComponent;  // 0x638(0x8)
	struct UBP_InteractionVisualizationComponent_C* BP_InteractionVisualizationComponent;  // 0x640(0x8)
	struct TArray<struct UAnimMontage*> RoamingInterprets;  // 0x648(0x10)
	double FatMorphTarget;  // 0x658(0x8)

	void GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule); // Function BP_Cat_Pet.BP_Cat_Pet_C.GetAttachmentDetails
	bool GetVisualActiveCondition(); // Function BP_Cat_Pet.BP_Cat_Pet_C.GetVisualActiveCondition
	bool GetIsLookInteractionActive(); // Function BP_Cat_Pet.BP_Cat_Pet_C.GetIsLookInteractionActive
	bool CanPlayerInteract(struct APawn* PawnReference); // Function BP_Cat_Pet.BP_Cat_Pet_C.CanPlayerInteract
	void GetCatBehaviour(char E_CatBehaviour& CatBehaviour); // Function BP_Cat_Pet.BP_Cat_Pet_C.GetCatBehaviour
	void OnRep_FatMorphTarget(); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnRep_FatMorphTarget
	void RequestAiCommand(); // Function BP_Cat_Pet.BP_Cat_Pet_C.RequestAiCommand
	void SetCurrentAiStatus(char E_CatBehaviour TargetBehaviour); // Function BP_Cat_Pet.BP_Cat_Pet_C.SetCurrentAiStatus
	void OnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0
	void OnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0
	void OnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0
	void OnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0
	void OnCompleted_CDA379BB46AD02007842EEB72FA4B9E0(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnCompleted_CDA379BB46AD02007842EEB72FA4B9E0
	void OnNotifyEnd_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyEnd_6DB031964564F00E967D65B8810E4EB4
	void OnNotifyBegin_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyBegin_6DB031964564F00E967D65B8810E4EB4
	void OnInterrupted_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnInterrupted_6DB031964564F00E967D65B8810E4EB4
	void OnBlendOut_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnBlendOut_6DB031964564F00E967D65B8810E4EB4
	void OnCompleted_6DB031964564F00E967D65B8810E4EB4(struct FName NotifyName); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnCompleted_6DB031964564F00E967D65B8810E4EB4
	void OnRoamingFinished(); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnRoamingFinished
	void OnCatBehaviourChanged(char E_CatBehaviour CurrentBehaviour); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnCatBehaviourChanged
	void ReceiveBeginPlay(); // Function BP_Cat_Pet.BP_Cat_Pet_C.ReceiveBeginPlay
	void PlayRoamingInterpret(struct UAnimMontage* MontageToPlay); // Function BP_Cat_Pet.BP_Cat_Pet_C.PlayRoamingInterpret
	void OnEatCompleted(); // Function BP_Cat_Pet.BP_Cat_Pet_C.OnEatCompleted
	void CatStartEat(); // Function BP_Cat_Pet.BP_Cat_Pet_C.CatStartEat
	void PlayCatMontage(struct UAnimMontage* MontageToPlay); // Function BP_Cat_Pet.BP_Cat_Pet_C.PlayCatMontage
	void AskForLove(); // Function BP_Cat_Pet.BP_Cat_Pet_C.AskForLove
	void BndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted); // Function BP_Cat_Pet.BP_Cat_Pet_C.BndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
	void recognitionResultReceivedCallback(struct FString Result); // Function BP_Cat_Pet.BP_Cat_Pet_C.recognitionResultReceivedCallback
	void ExecuteUbergraph_BP_Cat_Pet(int32_t EntryPoint); // Function BP_Cat_Pet.BP_Cat_Pet_C.ExecuteUbergraph_BP_Cat_Pet
}; 



