#include "SDK.h" 
 
 
void UAnimInstance::BaseState(struct FPoseLink BaseAnimation, struct FPoseLink& BaseState){

	static UObject* p_BaseState = UObject::FindObject<UFunction>("Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.BaseState");

	struct {
		struct FPoseLink BaseAnimation;
		struct FPoseLink& BaseState;
	} parms;

	parms.BaseAnimation = BaseAnimation;
	parms.BaseState = BaseState;

	ProcessEvent(p_BaseState, &parms);
}

void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::BlueprintThreadSafeUpdateAnimation(float DeltaTime){

	static UObject* p_BlueprintThreadSafeUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.BlueprintThreadSafeUpdateAnimation");

	struct {
		float DeltaTime;
	} parms;

	parms.DeltaTime = DeltaTime;

	ProcessEvent(p_BlueprintThreadSafeUpdateAnimation, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_ThirdPersonToolLayer(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_ThirdPersonToolLayer = UObject::FindObject<UFunction>("Function ABP_ThirdPersonToolLayer.ABP_ThirdPersonToolLayer_C.ExecuteUbergraph_ABP_ThirdPersonToolLayer");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_ThirdPersonToolLayer, &parms);
}

