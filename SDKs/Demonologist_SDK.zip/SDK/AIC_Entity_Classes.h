#pragma once 
#include <AIC_Entity_Structs.h>
 
 
 
// BlueprintGeneratedClass AIC_Entity.AIC_Entity_C
// Size: 0x3C8(Inherited: 0x3B8) 
struct AAIC_Entity_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3B8(0x8)
	struct UAIPerceptionComponent* AIPerception;  // 0x3C0(0x8)

	void ReceiveBeginPlay(); // Function AIC_Entity.AIC_Entity_C.ReceiveBeginPlay
	void ExecuteUbergraph_AIC_Entity(int32_t EntryPoint); // Function AIC_Entity.AIC_Entity_C.ExecuteUbergraph_AIC_Entity
}; 



