#include "SDK.h" 
 
 
void UObject::StopAnalyzing(struct UObject* WorldContextObject){

	static UObject* p_StopAnalyzing = UObject::FindObject<UFunction>("Function AudioAnalyzer.AudioAnalyzer.StopAnalyzing");

	struct {
		struct UObject* WorldContextObject;
	} parms;

	parms.WorldContextObject = WorldContextObject;

	ProcessEvent(p_StopAnalyzing, &parms);
}

void UObject::StartAnalyzing(struct UObject* WorldContextObject, struct UAudioBus* AudioBusToAnalyze){

	static UObject* p_StartAnalyzing = UObject::FindObject<UFunction>("Function AudioAnalyzer.AudioAnalyzer.StartAnalyzing");

	struct {
		struct UObject* WorldContextObject;
		struct UAudioBus* AudioBusToAnalyze;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.AudioBusToAnalyze = AudioBusToAnalyze;

	ProcessEvent(p_StartAnalyzing, &parms);
}

