#pragma once 
#include "SDK.h" 
 
 
// Function BP_Ball.BP_Ball_C.ExecuteUbergraph_BP_Ball
// Size: 0x171(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Ball
{
	int32_t EntryPoint;  // 0x0(0x4)
	float K2Node_Event_DeltaSeconds;  // 0x4(0x4)
	struct UPrimitiveComponent* K2Node_Event_MyComp;  // 0x8(0x8)
	struct AActor* K2Node_Event_Other;  // 0x10(0x8)
	struct UPrimitiveComponent* K2Node_Event_OtherComp;  // 0x18(0x8)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_Event_bSelfMoved : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FVector K2Node_Event_HitLocation;  // 0x28(0x18)
	struct FVector K2Node_Event_HitNormal;  // 0x40(0x18)
	struct FVector K2Node_Event_NormalImpulse;  // 0x58(0x18)
	struct FHitResult K2Node_Event_Hit;  // 0x70(0xE8)
	struct ABP_BasePlayerCharacter_C* K2Node_DynamicCast_AsBP_Base_Player_Character;  // 0x158(0x8)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x160(0x1)
	char pad_353[7];  // 0x161(0x7)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x170(0x1)

}; 
// Function BP_Ball.BP_Ball_C.ReceiveHit
// Size: 0x150(Inherited: 0x150) 
struct FReceiveHit : public FReceiveHit
{
	struct UPrimitiveComponent* MyComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	char pad_360_1 : 7;  // 0x168(0x1)
	bool bSelfMoved : 1;  // 0x18(0x1)
	struct FVector HitLocation;  // 0x20(0x18)
	struct FVector HitNormal;  // 0x38(0x18)
	struct FVector NormalImpulse;  // 0x50(0x18)
	struct FHitResult Hit;  // 0x68(0xE8)

}; 
// Function BP_Ball.BP_Ball_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
