#pragma once 
#include <BP_ControlCamera_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ControlCamera.BP_ControlCamera_C
// Size: 0x1138(Inherited: 0x10C0) 
struct ABP_ControlCamera_C : public ABP_SmartTV_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x10C0(0x8)
	struct UBoxComponent* RenderArea;  // 0x10C8(0x8)
	struct UBP_InteractionVisualizationComponent_C* BP_InteractionVisualizationComponent;  // 0x10D0(0x8)
	struct UBP_CameraCaptureComponent_C* WatchingCameraReference;  // 0x10D8(0x8)
	struct UMaterialInstanceDynamic* ScreenMaterialReference;  // 0x10E0(0x8)
	char pad_4328_1 : 7;  // 0x10E8(0x1)
	bool IsReflectingCapture : 1;  // 0x10E8(0x1)
	char pad_4329[7];  // 0x10E9(0x7)
	struct FVector RenderAreaExtend;  // 0x10F0(0x18)
	struct FVector RenderAreaLocation;  // 0x1108(0x18)
	struct FRotator RenderAreaRotation;  // 0x1120(0x18)

	struct UWBP_CameraControl_C* GetTargetWidget(); // Function BP_ControlCamera.BP_ControlCamera_C.GetTargetWidget
	struct UMaterialInstanceDynamic* GetWidgetMaterial(); // Function BP_ControlCamera.BP_ControlCamera_C.GetWidgetMaterial
	bool IsLocalPlayer(struct UObject* ActorReference); // Function BP_ControlCamera.BP_ControlCamera_C.IsLocalPlayer
	bool IsInRenderCameraArea(struct UBP_CameraCaptureComponent_C* ContestantCaptureComponent); // Function BP_ControlCamera.BP_ControlCamera_C.IsInRenderCameraArea
	void OnWatchingCameraStatusChanged(bool IsCapturing); // Function BP_ControlCamera.BP_ControlCamera_C.OnWatchingCameraStatusChanged
	void GetCameraSources(struct TArray<struct AActor*>& OutActors); // Function BP_ControlCamera.BP_ControlCamera_C.GetCameraSources
	void ChangeCameraCaptureSource(); // Function BP_ControlCamera.BP_ControlCamera_C.ChangeCameraCaptureSource
	void SetWatchingCameraComponent(struct UBP_CameraCaptureComponent_C* ContestantWatchingCamera); // Function BP_ControlCamera.BP_ControlCamera_C.SetWatchingCameraComponent
	void InitializeControlCamera(); // Function BP_ControlCamera.BP_ControlCamera_C.InitializeControlCamera
	void UserConstructionScript(); // Function BP_ControlCamera.BP_ControlCamera_C.UserConstructionScript
	void ReceiveBeginPlay(); // Function BP_ControlCamera.BP_ControlCamera_C.ReceiveBeginPlay
	void CheckRenderAreaOverlap(struct AActor* OverlappedActor); // Function BP_ControlCamera.BP_ControlCamera_C.CheckRenderAreaOverlap
	void BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_ControlCamera.BP_ControlCamera_C.BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_3_ComponentBeginOverlapSignature__DelegateSignature
	void OnEndOverlappedRenderArea(struct AActor* EndOverlappedActor); // Function BP_ControlCamera.BP_ControlCamera_C.OnEndOverlappedRenderArea
	void BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function BP_ControlCamera.BP_ControlCamera_C.BndEvt__BP_ControlCamera_RenderArea_K2Node_ComponentBoundEvent_4_ComponentEndOverlapSignature__DelegateSignature
	void ExecuteUbergraph_BP_ControlCamera(int32_t EntryPoint); // Function BP_ControlCamera.BP_ControlCamera_C.ExecuteUbergraph_BP_ControlCamera
}; 



