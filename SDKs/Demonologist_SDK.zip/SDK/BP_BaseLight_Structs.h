#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseLight.BP_BaseLight_C.CanMalfunction
// Size: 0x1(Inherited: 0x0) 
struct FCanMalfunction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BaseLight.BP_BaseLight_C.EndMalfunction
// Size: 0x8(Inherited: 0x0) 
struct FEndMalfunction
{
	struct FName Identifier;  // 0x0(0x8)

}; 
// Function BP_BaseLight.BP_BaseLight_C.ChangeLightMode
// Size: 0x18(Inherited: 0x0) 
struct FChangeLightMode
{
	struct FS_LightScenerio LightScenerio;  // 0x0(0x18)

}; 
// Function BP_BaseLight.BP_BaseLight_C.GetIsLightActive
// Size: 0x4(Inherited: 0x0) 
struct FGetIsLightActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_GetIsLightTurnOn_ReturnNode : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_BaseLight.BP_BaseLight_C.ExecuteUbergraph_BP_BaseLight
// Size: 0x9C(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseLight
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FS_LightScenerio K2Node_MakeStruct_S_LightScenerio;  // 0x8(0x18)
	double CallFunc_GetTargetIntensity_ReturnValue;  // 0x20(0x8)
	struct FS_LightScenerio K2Node_CustomEvent_LightScenerio_2;  // 0x28(0x18)
	struct FS_LightScenerio K2Node_CustomEvent_LightScenerio;  // 0x40(0x18)
	float CallFunc_GetTimeRange_MinTime;  // 0x58(0x4)
	float CallFunc_GetTimeRange_MaxTime;  // 0x5C(0x4)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x61(0x1)
	char pad_98[2];  // 0x62(0x2)
	float K2Node_Event_DeltaSeconds;  // 0x64(0x4)
	struct FName K2Node_Event_Identifier_2;  // 0x68(0x8)
	double CallFunc_SelectFloat_ReturnValue;  // 0x70(0x8)
	struct FName K2Node_Event_Identifier;  // 0x78(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x89(0x1)
	char pad_138_1 : 7;  // 0x8A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x8A(0x1)
	char pad_139_1 : 7;  // 0x8B(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x8B(0x1)
	char pad_140_1 : 7;  // 0x8C(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x8C(0x1)
	char pad_141[3];  // 0x8D(0x3)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast;  // 0x90(0x8)
	float CallFunc_SetIntensity_NewIntensity_ImplicitCast;  // 0x98(0x4)

}; 
// Function BP_BaseLight.BP_BaseLight_C.GetIsLightTurnOn
// Size: 0x1(Inherited: 0x0) 
struct FGetIsLightTurnOn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnNode : 1;  // 0x0(0x1)

}; 
// Function BP_BaseLight.BP_BaseLight_C.GetLightIntensity
// Size: 0x10(Inherited: 0x0) 
struct FGetLightIntensity
{
	double ReturnValue;  // 0x0(0x8)
	double K2Node_FunctionResult_ReturnValue_ImplicitCast;  // 0x8(0x8)

}; 
// Function BP_BaseLight.BP_BaseLight_C.GetTargetEmessivePower
// Size: 0x50(Inherited: 0x0) 
struct FGetTargetEmessivePower
{
	double EmessivePercentage;  // 0x0(0x8)
	double ReturnValue;  // 0x8(0x8)
	double CallFunc_GetLightIntensity_ReturnValue;  // 0x10(0x8)
	double CallFunc_MapRangeClamped_ReturnValue;  // 0x18(0x8)
	double CallFunc_SelectFloat_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_NotEqual_DoubleDouble_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	double CallFunc_Divide_DoubleDouble_ReturnValue;  // 0x30(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x38(0x8)
	double CallFunc_SelectFloat_ReturnValue_2;  // 0x40(0x8)
	double CallFunc_SelectFloat_ReturnValue_3;  // 0x48(0x8)

}; 
// Function BP_BaseLight.BP_BaseLight_C.StartMalfunction
// Size: 0x8(Inherited: 0x0) 
struct FStartMalfunction
{
	struct FName Identifier;  // 0x0(0x8)

}; 
// Function BP_BaseLight.BP_BaseLight_C.GetTargetIntensity
// Size: 0x18(Inherited: 0x0) 
struct FGetTargetIntensity
{
	double ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_GetIsLightActive_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	double CallFunc_SelectFloat_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_BaseLight.BP_BaseLight_C.InitiliazeBaseLight
// Size: 0x10(Inherited: 0x0) 
struct FInitiliazeBaseLight
{
	double CallFunc_GetTargetIntensity_ReturnValue;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float CallFunc_SetIntensity_NewIntensity_ImplicitCast;  // 0xC(0x4)

}; 
// Function BP_BaseLight.BP_BaseLight_C.OnLightStatusChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnLightStatusChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsActive : 1;  // 0x0(0x1)

}; 
// Function BP_BaseLight.BP_BaseLight_C.OnRep_IsLightBroken
// Size: 0x18(Inherited: 0x0) 
struct FOnRep_IsLightBroken
{
	struct FS_LightScenerio K2Node_MakeStruct_S_LightScenerio;  // 0x0(0x18)

}; 
// Function BP_BaseLight.BP_BaseLight_C.OnRep_IsLightTurnOn
// Size: 0x1(Inherited: 0x0) 
struct FOnRep_IsLightTurnOn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_GetIsLightTurnOn_ReturnNode : 1;  // 0x0(0x1)

}; 
// Function BP_BaseLight.BP_BaseLight_C.Set Light Turn Status
// Size: 0xC(Inherited: 0x0) 
struct FSet Light Turn Status
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ActivationStatus : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName InstigatorIdentifier;  // 0x4(0x8)

}; 
// Function BP_BaseLight.BP_BaseLight_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_BaseLight.BP_BaseLight_C.ReplaceMaterialsWithDynamics
// Size: 0x21(Inherited: 0x0) 
struct FReplaceMaterialsWithDynamics
{
	int32_t Temp_int_Variable;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x8(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x10(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x14(0x4)
	int32_t CallFunc_GetNumMaterials_ReturnValue;  // 0x18(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x1C(0x4)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x20(0x1)

}; 
// Function BP_BaseLight.BP_BaseLight_C.SetLightScenerio
// Size: 0x18(Inherited: 0x0) 
struct FSetLightScenerio
{
	struct FS_LightScenerio SelectedLightScenerio;  // 0x0(0x18)

}; 
// Function BP_BaseLight.BP_BaseLight_C.SetLightScenerioServer
// Size: 0x18(Inherited: 0x0) 
struct FSetLightScenerioServer
{
	struct FS_LightScenerio LightScenerio;  // 0x0(0x18)

}; 
// Function BP_BaseLight.BP_BaseLight_C.UpdateEmessiveMaterialValues
// Size: 0x40(Inherited: 0x0) 
struct FUpdateEmessiveMaterialValues
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	double CallFunc_GetTargetEmessivePower_ReturnValue;  // 0x10(0x8)
	struct FLinearColor CallFunc_GetLightColor_ReturnValue;  // 0x18(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct UMaterialInstanceDynamic* CallFunc_Array_Get_Item;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float CallFunc_SetScalarParameterValue_Value_ImplicitCast;  // 0x3C(0x4)

}; 
