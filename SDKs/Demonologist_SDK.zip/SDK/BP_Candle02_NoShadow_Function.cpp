#include "SDK.h" 
 
 
void AActor::SetEnabled(bool Enabled){

	static UObject* p_SetEnabled = UObject::FindObject<UFunction>("Function BP_Candle02_NoShadow.BP_Candle02_NoShadow_C.SetEnabled");

	struct {
		bool Enabled;
	} parms;

	parms.Enabled = Enabled;

	ProcessEvent(p_SetEnabled, &parms);
}

void AActor::UserConstructionScript(){

	static UObject* p_UserConstructionScript = UObject::FindObject<UFunction>("Function BP_Candle02_NoShadow.BP_Candle02_NoShadow_C.UserConstructionScript");

	struct {
	} parms;


	ProcessEvent(p_UserConstructionScript, &parms);
}

void AActor::CandleFlicker__FinishedFunc(){

	static UObject* p_CandleFlicker__FinishedFunc = UObject::FindObject<UFunction>("Function BP_Candle02_NoShadow.BP_Candle02_NoShadow_C.CandleFlicker__FinishedFunc");

	struct {
	} parms;


	ProcessEvent(p_CandleFlicker__FinishedFunc, &parms);
}

void AActor::CandleFlicker__UpdateFunc(){

	static UObject* p_CandleFlicker__UpdateFunc = UObject::FindObject<UFunction>("Function BP_Candle02_NoShadow.BP_Candle02_NoShadow_C.CandleFlicker__UpdateFunc");

	struct {
	} parms;


	ProcessEvent(p_CandleFlicker__UpdateFunc, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Candle02_NoShadow.BP_Candle02_NoShadow_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::ExecuteUbergraph_BP_Candle02_NoShadow(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Candle02_NoShadow = UObject::FindObject<UFunction>("Function BP_Candle02_NoShadow.BP_Candle02_NoShadow_C.ExecuteUbergraph_BP_Candle02_NoShadow");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Candle02_NoShadow, &parms);
}

