#pragma once 
#include <BP_BasicEventBox_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BasicEventBox.BP_BasicEventBox_C
// Size: 0x2D0(Inherited: 0x290) 
struct ABP_BasicEventBox_C : public AActor
{
	struct UBillboardComponent* Billboard;  // 0x290(0x8)
	struct USceneComponent* Scene;  // 0x298(0x8)
	struct UBoxComponent* InteractionBox;  // 0x2A0(0x8)
	struct UBP_InteractionVisualizationComponent_C* BP_InteractionVisualizationComponent;  // 0x2A8(0x8)
	struct UBP_BasicInteractionComponent_C* BP_BasicInteractionComponent;  // 0x2B0(0x8)
	struct UBP_EventBoxComponent_C* BP_EventBoxComponent;  // 0x2B8(0x8)
	struct TArray<struct FVector> DegreePoints;  // 0x2C0(0x10)

	struct TArray<struct FVector> GetDegreePoints(); // Function BP_BasicEventBox.BP_BasicEventBox_C.GetDegreePoints
	bool GetIsLookInteractionActive(); // Function BP_BasicEventBox.BP_BasicEventBox_C.GetIsLookInteractionActive
	bool GetVisualActiveCondition(); // Function BP_BasicEventBox.BP_BasicEventBox_C.GetVisualActiveCondition
	void GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule); // Function BP_BasicEventBox.BP_BasicEventBox_C.GetAttachmentDetails
}; 



