#pragma once 
#include "SDK.h" 
 
 
// Function BP_BasicEventBox.BP_BasicEventBox_C.GetDegreePoints
// Size: 0x10(Inherited: 0x0) 
struct FGetDegreePoints
{
	struct TArray<struct FVector> ReturnValue;  // 0x0(0x10)

}; 
// Function BP_BasicEventBox.BP_BasicEventBox_C.GetAttachmentDetails
// Size: 0x83(Inherited: 0x0) 
struct FGetAttachmentDetails
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsManualAttachment : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FTransform RelativeTransform;  // 0x10(0x60)
	struct USceneComponent* AttachmentComponent;  // 0x70(0x8)
	struct FName SocketName;  // 0x78(0x8)
	char LocationRule;  // 0x80(0x1)
	char RotationRule;  // 0x81(0x1)
	char ScaleRule;  // 0x82(0x1)

}; 
// Function BP_BasicEventBox.BP_BasicEventBox_C.GetIsLookInteractionActive
// Size: 0x1(Inherited: 0x0) 
struct FGetIsLookInteractionActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BasicEventBox.BP_BasicEventBox_C.GetVisualActiveCondition
// Size: 0x1(Inherited: 0x0) 
struct FGetVisualActiveCondition
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
