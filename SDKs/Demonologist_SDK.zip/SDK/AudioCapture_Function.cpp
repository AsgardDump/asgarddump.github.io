#include "SDK.h" 
 
 
struct UAudioCapture* UBlueprintFunctionLibrary::CreateAudioCapture(){

	static UObject* p_CreateAudioCapture = UObject::FindObject<UFunction>("Function AudioCapture.AudioCaptureFunctionLibrary.CreateAudioCapture");

	struct {
		struct UAudioCapture* return_value;
	} parms;


	ProcessEvent(p_CreateAudioCapture, &parms);
	return parms.return_value;
}

void UAudioGenerator::StopCapturingAudio(){

	static UObject* p_StopCapturingAudio = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.StopCapturingAudio");

	struct {
	} parms;


	ProcessEvent(p_StopCapturingAudio, &parms);
}

void UAudioGenerator::StartCapturingAudio(){

	static UObject* p_StartCapturingAudio = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.StartCapturingAudio");

	struct {
	} parms;


	ProcessEvent(p_StartCapturingAudio, &parms);
}

bool UAudioGenerator::IsCapturingAudio(){

	static UObject* p_IsCapturingAudio = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.IsCapturingAudio");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsCapturingAudio, &parms);
	return parms.return_value;
}

bool UAudioGenerator::GetAudioCaptureDeviceInfo(struct FAudioCaptureDeviceInfo& OutInfo){

	static UObject* p_GetAudioCaptureDeviceInfo = UObject::FindObject<UFunction>("Function AudioCapture.AudioCapture.GetAudioCaptureDeviceInfo");

	struct {
		struct FAudioCaptureDeviceInfo& OutInfo;
		bool return_value;
	} parms;

	parms.OutInfo = OutInfo;

	ProcessEvent(p_GetAudioCaptureDeviceInfo, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::GetAvailableAudioInputDevices(struct UObject* WorldContextObject, struct FDelegate& OnObtainDevicesEvent){

	static UObject* p_GetAvailableAudioInputDevices = UObject::FindObject<UFunction>("Function AudioCapture.AudioCaptureBlueprintLibrary.GetAvailableAudioInputDevices");

	struct {
		struct UObject* WorldContextObject;
		struct FDelegate& OnObtainDevicesEvent;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.OnObtainDevicesEvent = OnObtainDevicesEvent;

	ProcessEvent(p_GetAvailableAudioInputDevices, &parms);
}

struct FString UBlueprintFunctionLibrary::Conv_AudioInputDeviceInfoToString(struct FAudioInputDeviceInfo& Info){

	static UObject* p_Conv_AudioInputDeviceInfoToString = UObject::FindObject<UFunction>("Function AudioCapture.AudioCaptureBlueprintLibrary.Conv_AudioInputDeviceInfoToString");

	struct {
		struct FAudioInputDeviceInfo& Info;
		struct FString return_value;
	} parms;

	parms.Info = Info;

	ProcessEvent(p_Conv_AudioInputDeviceInfoToString, &parms);
	return parms.return_value;
}

