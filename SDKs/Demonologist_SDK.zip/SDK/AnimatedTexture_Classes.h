#pragma once 
#include <AnimatedTexture_Structs.h>
 
 
 
// Class AnimatedTexture.AnimatedTexture2D
// Size: 0x240(Inherited: 0x1F0) 
struct UAnimatedTexture2D : public UTexture
{
	char pad_496[8];  // 0x1F0(0x8)
	char TextureAddress AddressX;  // 0x1F8(0x1)
	char TextureAddress AddressY;  // 0x1F9(0x1)
	char pad_506_1 : 7;  // 0x1FA(0x1)
	bool SupportsTransparency : 1;  // 0x1FA(0x1)
	char pad_507[1];  // 0x1FB(0x1)
	float DefaultFrameDelay;  // 0x1FC(0x4)
	float PlayRate;  // 0x200(0x4)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool bLooping : 1;  // 0x204(0x1)
	uint8_t  FileType;  // 0x205(0x1)
	char pad_518[2];  // 0x206(0x2)
	struct TArray<char> FileBlob;  // 0x208(0x10)
	char pad_536[40];  // 0x218(0x28)

	void Stop(); // Function AnimatedTexture.AnimatedTexture2D.Stop
	void SetPlayRate(float NewRate); // Function AnimatedTexture.AnimatedTexture2D.SetPlayRate
	void SetLooping(bool bNewLooping); // Function AnimatedTexture.AnimatedTexture2D.SetLooping
	void PlayFromStart(); // Function AnimatedTexture.AnimatedTexture2D.PlayFromStart
	void Play(); // Function AnimatedTexture.AnimatedTexture2D.Play
	bool IsPlaying(); // Function AnimatedTexture.AnimatedTexture2D.IsPlaying
	bool IsLooping(); // Function AnimatedTexture.AnimatedTexture2D.IsLooping
	float GetPlayRate(); // Function AnimatedTexture.AnimatedTexture2D.GetPlayRate
	float GetAnimationLength(); // Function AnimatedTexture.AnimatedTexture2D.GetAnimationLength
}; 



// Class AnimatedTexture.MtlExpTextureSampleParameterAnim
// Size: 0x240(Inherited: 0x240) 
struct UMtlExpTextureSampleParameterAnim : public UMaterialExpressionTextureSampleParameter
{

}; 



