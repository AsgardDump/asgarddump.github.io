#pragma once 
#include <ABP_Cat_Pet_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Cat_Pet.ABP_Cat_Pet_C
// Size: 0x708(Inherited: 0x350) 
struct UABP_Cat_Pet_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x358(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x360(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x368(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x388(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3B0(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // 0x3D8(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x420(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x440(0x48)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x488(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x4A8(0xC8)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x570(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x678(0x28)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x6A0(0x48)
	struct FVector K2Node_PropertyAccess;  // 0x6E8(0x18)
	double Speed;  // 0x700(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Cat_Pet.ABP_Cat_Pet_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_Cat_Pet.ABP_Cat_Pet_C.BlueprintThreadSafeUpdateAnimation
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Cat_Pet_AnimGraphNode_TransitionResult_868FEADA4BB2B221273849A6A3E9B0A3(); // Function ABP_Cat_Pet.ABP_Cat_Pet_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Cat_Pet_AnimGraphNode_TransitionResult_868FEADA4BB2B221273849A6A3E9B0A3
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Cat_Pet_AnimGraphNode_TransitionResult_5F79AF2F45E0C7CE2D72D98354349DB2(); // Function ABP_Cat_Pet.ABP_Cat_Pet_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Cat_Pet_AnimGraphNode_TransitionResult_5F79AF2F45E0C7CE2D72D98354349DB2
	void ExecuteUbergraph_ABP_Cat_Pet(int32_t EntryPoint); // Function ABP_Cat_Pet.ABP_Cat_Pet_C.ExecuteUbergraph_ABP_Cat_Pet
}; 



