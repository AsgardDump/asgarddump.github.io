#pragma once 
#include <BP_BaseInteraction_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseInteraction.BP_BaseInteraction_C
// Size: 0x2B8(Inherited: 0x290) 
struct ABP_BaseInteraction_C : public AActor
{
	struct UBP_InteractionVisualizationComponent_C* BP_InteractionVisualizationComponent;  // 0x290(0x8)
	struct UBillboardComponent* Billboard;  // 0x298(0x8)
	struct UBoxComponent* InteractionBox;  // 0x2A0(0x8)
	struct USceneComponent* Root;  // 0x2A8(0x8)
	struct UBP_VisualInteractionComponent_C* BP_VisualInteractionComponent;  // 0x2B0(0x8)

	bool CanPlayerInteract(struct APawn* PawnReference); // Function BP_BaseInteraction.BP_BaseInteraction_C.CanPlayerInteract
	void GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule); // Function BP_BaseInteraction.BP_BaseInteraction_C.GetAttachmentDetails
	bool GetVisualActiveCondition(); // Function BP_BaseInteraction.BP_BaseInteraction_C.GetVisualActiveCondition
	bool GetIsLookInteractionActive(); // Function BP_BaseInteraction.BP_BaseInteraction_C.GetIsLookInteractionActive
}; 



