#include "SDK.h" 
 
 
void UBlueprintFunctionLibrary::RemoveActorFromLayer(struct AActor* InActor, struct FActorLayer& Layer){

	static UObject* p_RemoveActorFromLayer = UObject::FindObject<UFunction>("Function ActorLayerUtilities.LayersBlueprintLibrary.RemoveActorFromLayer");

	struct {
		struct AActor* InActor;
		struct FActorLayer& Layer;
	} parms;

	parms.InActor = InActor;
	parms.Layer = Layer;

	ProcessEvent(p_RemoveActorFromLayer, &parms);
}

struct TArray<struct AActor*> UBlueprintFunctionLibrary::GetActors(struct UObject* WorldContextObject, struct FActorLayer& ActorLayer){

	static UObject* p_GetActors = UObject::FindObject<UFunction>("Function ActorLayerUtilities.LayersBlueprintLibrary.GetActors");

	struct {
		struct UObject* WorldContextObject;
		struct FActorLayer& ActorLayer;
		struct TArray<struct AActor*> return_value;
	} parms;

	parms.WorldContextObject = WorldContextObject;
	parms.ActorLayer = ActorLayer;

	ProcessEvent(p_GetActors, &parms);
	return parms.return_value;
}

void UBlueprintFunctionLibrary::AddActorToLayer(struct AActor* InActor, struct FActorLayer& Layer){

	static UObject* p_AddActorToLayer = UObject::FindObject<UFunction>("Function ActorLayerUtilities.LayersBlueprintLibrary.AddActorToLayer");

	struct {
		struct AActor* InActor;
		struct FActorLayer& Layer;
	} parms;

	parms.InActor = InActor;
	parms.Layer = Layer;

	ProcessEvent(p_AddActorToLayer, &parms);
}

