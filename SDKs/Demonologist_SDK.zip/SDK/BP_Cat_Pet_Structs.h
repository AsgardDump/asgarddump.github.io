#pragma once 
#include "SDK.h" 
 
 
// Function BP_Cat_Pet.BP_Cat_Pet_C.BndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FBndEvt__BP_Cat_Pet_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
{
	struct APawn* CharacterPawn;  // 0x0(0x8)
	struct FName Identifier;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsServerExucuted : 1;  // 0x10(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.GetVisualActiveCondition
// Size: 0x1(Inherited: 0x0) 
struct FGetVisualActiveCondition
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.CanPlayerInteract
// Size: 0x9(Inherited: 0x0) 
struct FCanPlayerInteract
{
	struct APawn* PawnReference;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.GetIsLookInteractionActive
// Size: 0x1(Inherited: 0x0) 
struct FGetIsLookInteractionActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyEnd_6DB031964564F00E967D65B8810E4EB4
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_6DB031964564F00E967D65B8810E4EB4
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.ExecuteUbergraph_BP_Cat_Pet
// Size: 0x278(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Cat_Pet
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	struct FName K2Node_CustomEvent_NotifyName_6;  // 0x14(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x1C(0x10)
	struct FName Temp_name_Variable;  // 0x2C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // 0x34(0x10)
	struct FName K2Node_CustomEvent_NotifyName_5;  // 0x44(0x8)
	struct FName K2Node_CustomEvent_NotifyName_4;  // 0x4C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // 0x54(0x10)
	struct FName K2Node_CustomEvent_NotifyName_3;  // 0x64(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // 0x6C(0x10)
	struct FName K2Node_CustomEvent_NotifyName_2;  // 0x7C(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // 0x84(0x10)
	struct FName K2Node_CustomEvent_NotifyName;  // 0x94(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // 0x9C(0x10)
	struct FName Temp_name_Variable_2;  // 0xAC(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // 0xB4(0x10)
	char E_CatBehaviour K2Node_CustomEvent_CurrentBehaviour;  // 0xC4(0x1)
	char pad_197[3];  // 0xC5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // 0xC8(0x10)
	char pad_216_1 : 7;  // 0xD8(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)
	double CallFunc_RandomFloatInRange_ReturnValue;  // 0xE0(0x8)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0xE8(0x8)
	char pad_240_1 : 7;  // 0xF0(0x1)
	bool CallFunc_RandomBoolWithWeight_ReturnValue : 1;  // 0xF0(0x1)
	char pad_241[7];  // 0xF1(0x7)
	struct UAnimMontage* CallFunc_Array_Random_OutItem;  // 0xF8(0x8)
	int32_t CallFunc_Array_Random_OutIndex;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)
	struct UAnimMontage* K2Node_CustomEvent_MontageToPlay_2;  // 0x108(0x8)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x110(0x1)
	char pad_273_1 : 7;  // 0x111(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x111(0x1)
	char pad_274[6];  // 0x112(0x6)
	double CallFunc_RandomFloatInRange_ReturnValue_2;  // 0x118(0x8)
	struct UAnimMontage* K2Node_CustomEvent_MontageToPlay;  // 0x120(0x8)
	char pad_296_1 : 7;  // 0x128(0x1)
	bool CallFunc_IsServer_ReturnValue_2 : 1;  // 0x128(0x1)
	char pad_297[7];  // 0x129(0x7)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // 0x130(0x8)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x138(0x1)
	char pad_313_1 : 7;  // 0x139(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x139(0x1)
	char pad_314[6];  // 0x13A(0x6)
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue_2;  // 0x140(0x8)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool CallFunc_IsServer_ReturnValue_3 : 1;  // 0x149(0x1)
	char pad_330[6];  // 0x14A(0x6)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x158(0x1)
	char pad_345[3];  // 0x159(0x3)
	struct FName K2Node_CustomEvent_NotifyName_10;  // 0x15C(0x8)
	float CallFunc_GetMorphTarget_ReturnValue;  // 0x164(0x4)
	struct FName K2Node_CustomEvent_NotifyName_7;  // 0x168(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0x170(0x8)
	double CallFunc_FClamp_ReturnValue;  // 0x178(0x8)
	struct APawn* K2Node_ComponentBoundEvent_CharacterPawn;  // 0x180(0x8)
	struct FName K2Node_ComponentBoundEvent_Identifier;  // 0x188(0x8)
	char pad_400_1 : 7;  // 0x190(0x1)
	bool K2Node_ComponentBoundEvent_IsServerExucuted : 1;  // 0x190(0x1)
	char pad_401[7];  // 0x191(0x7)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // 0x198(0x8)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x1A0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_10;  // 0x1A8(0x10)
	char E_CatBehaviour CallFunc_GetCatBehaviour_CatBehaviour;  // 0x1B8(0x1)
	char pad_441_1 : 7;  // 0x1B9(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x1B9(0x1)
	char pad_442[2];  // 0x1BA(0x2)
	struct FName K2Node_CustomEvent_NotifyName_8;  // 0x1BC(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_11;  // 0x1C4(0x10)
	struct FName K2Node_CustomEvent_NotifyName_9;  // 0x1D4(0x8)
	char pad_476[4];  // 0x1DC(0x4)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x1E0(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_12;  // 0x1E8(0x10)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x1F8(0x4)
	char pad_508_1 : 7;  // 0x1FC(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x1FC(0x1)
	char pad_509[3];  // 0x1FD(0x3)
	struct UAudioComponent* CallFunc_SpawnSoundAttached_ReturnValue;  // 0x200(0x8)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x208(0x10)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue_2;  // 0x218(0x8)
	struct FString K2Node_CustomEvent_result;  // 0x220(0x10)
	struct TScriptInterface<IBPI_VoiceRecgonition_C> K2Node_DynamicCast_AsBPI_Voice_Recgonition;  // 0x230(0x10)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x240(0x1)
	char pad_577[3];  // 0x241(0x3)
	struct FName CallFunc_RecgonizeSpiritBoxCommand_MatchedCommand;  // 0x244(0x8)
	char pad_588_1 : 7;  // 0x24C(0x1)
	bool CallFunc_RecgonizeSpiritBoxCommand_IsSuccessful : 1;  // 0x24C(0x1)
	char pad_589[3];  // 0x24D(0x3)
	struct USrsComponent* CallFunc_GetSrsComponent_ReturnValue;  // 0x250(0x8)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x258(0x1)
	char pad_601_1 : 7;  // 0x259(0x1)
	bool CallFunc_IsPlayerControlled_ReturnValue : 1;  // 0x259(0x1)
	char pad_602[2];  // 0x25A(0x2)
	float CallFunc_K2_SetTimerDelegate_Time_ImplicitCast;  // 0x25C(0x4)
	float CallFunc_Delay_Duration_ImplicitCast;  // 0x260(0x4)
	char pad_612[4];  // 0x264(0x4)
	double CallFunc_Add_DoubleDouble_A_ImplicitCast;  // 0x268(0x8)
	double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast;  // 0x270(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.GetCatBehaviour
// Size: 0x1A(Inherited: 0x0) 
struct FGetCatBehaviour
{
	char E_CatBehaviour CatBehaviour;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x10(0x8)
	char CallFunc_GetValueAsEnum_ReturnValue;  // 0x18(0x1)
	char CallFunc_GetValidValue_ReturnValue;  // 0x19(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.GetAttachmentDetails
// Size: 0x83(Inherited: 0x0) 
struct FGetAttachmentDetails
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsManualAttachment : 1;  // 0x0(0x1)
	char pad_1[15];  // 0x1(0xF)
	struct FTransform RelativeTransform;  // 0x10(0x60)
	struct USceneComponent* AttachmentComponent;  // 0x70(0x8)
	struct FName SocketName;  // 0x78(0x8)
	char LocationRule;  // 0x80(0x1)
	char RotationRule;  // 0x81(0x1)
	char ScaleRule;  // 0x82(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnBlendOut_6DB031964564F00E967D65B8810E4EB4
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_6DB031964564F00E967D65B8810E4EB4
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0
// Size: 0x8(Inherited: 0x0) 
struct FOnBlendOut_CDA379BB46AD02007842EEB72FA4B9E0
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnCatBehaviourChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnCatBehaviourChanged
{
	char E_CatBehaviour CurrentBehaviour;  // 0x0(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnCompleted_6DB031964564F00E967D65B8810E4EB4
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_6DB031964564F00E967D65B8810E4EB4
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnCompleted_CDA379BB46AD02007842EEB72FA4B9E0
// Size: 0x8(Inherited: 0x0) 
struct FOnCompleted_CDA379BB46AD02007842EEB72FA4B9E0
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnInterrupted_6DB031964564F00E967D65B8810E4EB4
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_6DB031964564F00E967D65B8810E4EB4
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0
// Size: 0x8(Inherited: 0x0) 
struct FOnInterrupted_CDA379BB46AD02007842EEB72FA4B9E0
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyBegin_6DB031964564F00E967D65B8810E4EB4
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_6DB031964564F00E967D65B8810E4EB4
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyBegin_CDA379BB46AD02007842EEB72FA4B9E0
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0
// Size: 0x8(Inherited: 0x0) 
struct FOnNotifyEnd_CDA379BB46AD02007842EEB72FA4B9E0
{
	struct FName NotifyName;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.OnRep_FatMorphTarget
// Size: 0x4(Inherited: 0x0) 
struct FOnRep_FatMorphTarget
{
	float CallFunc_SetMorphTarget_Value_ImplicitCast;  // 0x0(0x4)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.PlayCatMontage
// Size: 0x8(Inherited: 0x0) 
struct FPlayCatMontage
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.PlayRoamingInterpret
// Size: 0x8(Inherited: 0x0) 
struct FPlayRoamingInterpret
{
	struct UAnimMontage* MontageToPlay;  // 0x0(0x8)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.recognitionResultReceivedCallback
// Size: 0x10(Inherited: 0x0) 
struct FrecognitionResultReceivedCallback
{
	struct FString Result;  // 0x0(0x10)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.RequestAiCommand
// Size: 0x4(Inherited: 0x0) 
struct FRequestAiCommand
{
	char E_CatBehaviour CallFunc_GetCatBehaviour_CatBehaviour;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_RandomBoolWithWeight_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_RandomBoolWithWeight_ReturnValue_2 : 1;  // 0x3(0x1)

}; 
// Function BP_Cat_Pet.BP_Cat_Pet_C.SetCurrentAiStatus
// Size: 0x18(Inherited: 0x0) 
struct FSetCurrentAiStatus
{
	char E_CatBehaviour TargetBehaviour;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // 0x10(0x8)

}; 
