#pragma once 
#include <BP_AiThrowableObject_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AiThrowableObject.BP_AiThrowableObject_C
// Size: 0x195(Inherited: 0x134) 
struct UBP_AiThrowableObject_C : public UBP_AiInteractionComponent_C
{
	char pad_308[4];  // 0x134(0x4)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x138(0x8)
	struct TMap<struct UPrimitiveComponent*, struct ABP_InteractedHauntedArea_C*> SpawnedHauntedAreas;  // 0x140(0x50)
	int32_t ThrowableObjectSoundType;  // 0x190(0x4)
	char pad_404_1 : 7;  // 0x194(0x1)
	bool IsPhysicsSoundActive : 1;  // 0x194(0x1)

	void InitializeThrowableMeshes(); // Function BP_AiThrowableObject.BP_AiThrowableObject_C.InitializeThrowableMeshes
	struct TArray<struct UPrimitiveComponent*> GetThrowableItems(); // Function BP_AiThrowableObject.BP_AiThrowableObject_C.GetThrowableItems
	void ReceiveBeginPlay(); // Function BP_AiThrowableObject.BP_AiThrowableObject_C.ReceiveBeginPlay
	void OnInteractionRequestedCallback(struct AActor* Instigator); // Function BP_AiThrowableObject.BP_AiThrowableObject_C.OnInteractionRequestedCallback
	void ThrowableObjectInteractionMulticast(struct UObject* Instigator, struct FVector Impulse); // Function BP_AiThrowableObject.BP_AiThrowableObject_C.ThrowableObjectInteractionMulticast
	void OnComponentHit_Event(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function BP_AiThrowableObject.BP_AiThrowableObject_C.OnComponentHit_Event
	void ExecuteUbergraph_BP_AiThrowableObject(int32_t EntryPoint); // Function BP_AiThrowableObject.BP_AiThrowableObject_C.ExecuteUbergraph_BP_AiThrowableObject
}; 



