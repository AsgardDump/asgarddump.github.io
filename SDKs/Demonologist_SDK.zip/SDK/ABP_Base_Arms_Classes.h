#pragma once 
#include <ABP_Base_Arms_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_Base_Arms.ABP_Base_Arms_C
// Size: 0xC1A(Inherited: 0x350) 
struct UABP_Base_Arms_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;  // 0x358(0x2)
	char pad_858[6];  // 0x35A(0x6)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x360(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x368(0x8)
	struct FAnimNode_Root AnimGraphNode_Root_3;  // 0x370(0x20)
	struct FAnimNode_Root AnimGraphNode_Root_2;  // 0x390(0x20)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x3B0(0x20)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // 0x3D0(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // 0x3F8(0x28)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer_2;  // 0x420(0xC8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // 0x4E8(0x20)
	struct FAnimNode_LinkedAnimLayer AnimGraphNode_LinkedAnimLayer;  // 0x508(0xC8)
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // 0x5D0(0x20)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // 0x5F0(0xC8)
	struct FAnimNode_Slot AnimGraphNode_Slot;  // 0x6B8(0x48)
	struct FAnimNode_Inertialization AnimGraphNode_Inertialization;  // 0x700(0x100)
	struct FAnimNode_IKRig AnimGraphNode_IKRig;  // 0x800(0x1E0)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x9E0(0x108)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0xAE8(0x48)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0xB30(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0xB58(0x28)
	struct FVector K2Node_PropertyAccess_2;  // 0xB80(0x18)
	struct FVector K2Node_PropertyAccess;  // 0xB98(0x18)
	double __CustomProperty_PositionAlpha_hand_l_Goal_0CD4C9AA41FC572DE2C3A9B9FC6DDD00;  // 0xBB0(0x8)
	struct FVector __CustomProperty_Position_hand_l_Goal_0CD4C9AA41FC572DE2C3A9B9FC6DDD00;  // 0xBB8(0x18)
	double __CustomProperty_PositionAlpha_hand_r_Goal_0CD4C9AA41FC572DE2C3A9B9FC6DDD00;  // 0xBD0(0x8)
	struct FVector __CustomProperty_Position_hand_r_Goal_0CD4C9AA41FC572DE2C3A9B9FC6DDD00;  // 0xBD8(0x18)
	char pad_3056_1 : 7;  // 0xBF0(0x1)
	bool IsWalking : 1;  // 0xBF0(0x1)
	char pad_3057_1 : 7;  // 0xBF1(0x1)
	bool IsAiming : 1;  // 0xBF1(0x1)
	char pad_3058[6];  // 0xBF2(0x6)
	double WalkingSpeedRate;  // 0xBF8(0x8)
	double IKHandValue;  // 0xC00(0x8)
	char pad_3080_1 : 7;  // 0xC08(0x1)
	bool bRHandHit : 1;  // 0xC08(0x1)
	char pad_3081[7];  // 0xC09(0x7)
	struct ABP_BasePlayerCharacter_C* OwningCharacter;  // 0xC10(0x8)
	char pad_3096_1 : 7;  // 0xC18(0x1)
	bool bIsCrouching : 1;  // 0xC18(0x1)
	char pad_3097_1 : 7;  // 0xC19(0x1)
	bool bIsDisableIKHand : 1;  // 0xC19(0x1)

	bool GetIsAiming(); // Function ABP_Base_Arms.ABP_Base_Arms_C.GetIsAiming
	void IdleState(struct FPoseLink& IdleState); // Function ABP_Base_Arms.ABP_Base_Arms_C.IdleState
	void WalkingState(struct FPoseLink& WalkingState); // Function ABP_Base_Arms.ABP_Base_Arms_C.WalkingState
	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Base_Arms.ABP_Base_Arms_C.AnimGraph
	void BlueprintThreadSafeUpdateAnimation(float DeltaTime); // Function ABP_Base_Arms.ABP_Base_Arms_C.BlueprintThreadSafeUpdateAnimation
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_BlendListByBool_96D15D1148B57EEC7CE69AA3D692D1AC(); // Function ABP_Base_Arms.ABP_Base_Arms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_BlendListByBool_96D15D1148B57EEC7CE69AA3D692D1AC
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_IKRig_0CD4C9AA41FC572DE2C3A9B9FC6DDD00(); // Function ABP_Base_Arms.ABP_Base_Arms_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Base_Arms_AnimGraphNode_IKRig_0CD4C9AA41FC572DE2C3A9B9FC6DDD00
	void SetIsAiming(bool IsAiming); // Function ABP_Base_Arms.ABP_Base_Arms_C.SetIsAiming
	void SetIsSprinting(bool IsSprintins); // Function ABP_Base_Arms.ABP_Base_Arms_C.SetIsSprinting
	void BlueprintUpdateAnimation(float DeltaTimeX); // Function ABP_Base_Arms.ABP_Base_Arms_C.BlueprintUpdateAnimation
	void ExecuteUbergraph_ABP_Base_Arms(int32_t EntryPoint); // Function ABP_Base_Arms.ABP_Base_Arms_C.ExecuteUbergraph_ABP_Base_Arms
}; 



