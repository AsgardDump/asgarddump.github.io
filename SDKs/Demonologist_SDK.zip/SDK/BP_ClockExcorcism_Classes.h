#pragma once 
#include <BP_ClockExcorcism_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_ClockExcorcism.BP_ClockExcorcism_C
// Size: 0x31A(Inherited: 0x2B8) 
struct ABP_ClockExcorcism_C : public ABP_BaseInteraction_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B8(0x8)
	struct UBP_CameraFocusComponent_C* BP_CameraFocusComponent;  // 0x2C0(0x8)
	struct UPointLightComponent* PointLight;  // 0x2C8(0x8)
	struct UStaticMeshComponent* SM_ClockPendulum;  // 0x2D0(0x8)
	struct UCameraComponent* Camera;  // 0x2D8(0x8)
	struct UStaticMeshComponent* SM_ClockMinuteHand;  // 0x2E0(0x8)
	struct UStaticMeshComponent* SM_ClockHourHand;  // 0x2E8(0x8)
	struct UStaticMeshComponent* BaseClock;  // 0x2F0(0x8)
	double Minute;  // 0x2F8(0x8)
	struct ABP_ClockExcorcismRandomizer_C* ClockExcorcism;  // 0x300(0x8)
	struct FTimerHandle ClockWiseMovementTimerHandle;  // 0x308(0x8)
	struct FTimerHandle NonClockWiseMovementTimerHandle;  // 0x310(0x8)
	char pad_792_1 : 7;  // 0x318(0x1)
	bool IsEverMovedClockWise : 1;  // 0x318(0x1)
	char pad_793_1 : 7;  // 0x319(0x1)
	bool IsEverMovedNonClockWise : 1;  // 0x319(0x1)

	bool GetVisualActiveCondition(); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetVisualActiveCondition
	bool GetIsLookInteractionActive(); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetIsLookInteractionActive
	bool CanPlayerInteract(struct APawn* PawnReference); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.CanPlayerInteract
	void GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetAttachmentDetails
	bool CanInteractWithClock(); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.CanInteractWithClock
	void GetHourAndMinute(double& Hour, double& Minute); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetHourAndMinute
	void InpActEvt_D_K2Node_InputKeyEvent_5(struct FKey Key); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_D_K2Node_InputKeyEvent_5
	void InpActEvt_D_K2Node_InputKeyEvent_4(struct FKey Key); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_D_K2Node_InputKeyEvent_4
	void InpActEvt_A_K2Node_InputKeyEvent_3(struct FKey Key); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_A_K2Node_InputKeyEvent_3
	void InpActEvt_A_K2Node_InputKeyEvent_2(struct FKey Key); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_A_K2Node_InputKeyEvent_2
	void InpActEvt_Interaction_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_Interaction_K2Node_InputActionEvent_1
	void InpActEvt_Escape_K2Node_InputKeyEvent_1(struct FKey Key); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_Escape_K2Node_InputKeyEvent_1
	void MinuteMovement(bool IsClockWise); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.MinuteMovement
	void BndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.BndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
	void ReceiveBeginPlay(); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.ReceiveBeginPlay
	void ReceiveTick(float DeltaSeconds); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.ReceiveTick
	void ClockWiseMovement(); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.ClockWiseMovement
	void BndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature(bool IsFocused); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.BndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature
	void NonClockWiseMovement(); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.NonClockWiseMovement
	void ExecuteUbergraph_BP_ClockExcorcism(int32_t EntryPoint); // Function BP_ClockExcorcism.BP_ClockExcorcism_C.ExecuteUbergraph_BP_ClockExcorcism
}; 



