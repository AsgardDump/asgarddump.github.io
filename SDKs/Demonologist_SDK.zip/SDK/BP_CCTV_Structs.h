#pragma once 
#include "SDK.h" 
 
 
// Function BP_CCTV.BP_CCTV_C.ExecuteUbergraph_BP_CCTV
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CCTV
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool K2Node_Event_ReflectCapture : 1;  // 0x4(0x1)

}; 
// Function BP_CCTV.BP_CCTV_C.CanReflectCapture
// Size: 0x1(Inherited: 0x0) 
struct FCanReflectCapture
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_CCTV.BP_CCTV_C.SetReflectCaptureStatus
// Size: 0x1(Inherited: 0x0) 
struct FSetReflectCaptureStatus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReflectCapture : 1;  // 0x0(0x1)

}; 
// Function BP_CCTV.BP_CCTV_C.InitializeCamera
// Size: 0x8(Inherited: 0x0) 
struct FInitializeCamera
{
	struct UTextureRenderTarget2D* CallFunc_CreateRenderTarget2D_ReturnValue;  // 0x0(0x8)

}; 
