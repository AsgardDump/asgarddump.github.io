#include "SDK.h" 
 
 
void AActor::OverrideMeshMaterials(struct UStaticMeshComponent* Mesh, struct TArray<struct UMaterialInterface*>& Materials, struct TArray<struct UMaterialInterface*>& InitMaterials){

	static UObject* p_OverrideMeshMaterials = UObject::FindObject<UFunction>("Function BP_CandleBunch.BP_CandleBunch_C.OverrideMeshMaterials");

	struct {
		struct UStaticMeshComponent* Mesh;
		struct TArray<struct UMaterialInterface*>& Materials;
		struct TArray<struct UMaterialInterface*>& InitMaterials;
	} parms;

	parms.Mesh = Mesh;
	parms.Materials = Materials;
	parms.InitMaterials = InitMaterials;

	ProcessEvent(p_OverrideMeshMaterials, &parms);
}

void AActor::MaterialProperties(struct UStaticMeshComponent* Mesh, double Light Intensity, struct FColor Light Color, bool isLight){

	static UObject* p_MaterialProperties = UObject::FindObject<UFunction>("Function BP_CandleBunch.BP_CandleBunch_C.MaterialProperties");

	struct {
		struct UStaticMeshComponent* Mesh;
		double Light Intensity;
		struct FColor Light Color;
		bool isLight;
	} parms;

	parms.Mesh = Mesh;
	parms.Light Intensity = Light Intensity;
	parms.Light Color = Light Color;
	parms.isLight = isLight;

	ProcessEvent(p_MaterialProperties, &parms);
}

void AActor::LightProperties(struct ULightComponent* Light Component, double Light Intensity, struct FColor Light Color){

	static UObject* p_LightProperties = UObject::FindObject<UFunction>("Function BP_CandleBunch.BP_CandleBunch_C.LightProperties");

	struct {
		struct ULightComponent* Light Component;
		double Light Intensity;
		struct FColor Light Color;
	} parms;

	parms.Light Component = Light Component;
	parms.Light Intensity = Light Intensity;
	parms.Light Color = Light Color;

	ProcessEvent(p_LightProperties, &parms);
}

