#pragma once 
#include <BP_Badlam_Lamp01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Badlam_Lamp01.BP_Badlam_Lamp01_C
// Size: 0x3B8(Inherited: 0x3B8) 
struct ABP_Badlam_Lamp01_C : public ABP_PointLight_C
{

}; 



