#pragma once 
#include <BP_BaseTool_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseTool.BP_BaseTool_C
// Size: 0x350(Inherited: 0x290) 
struct ABP_BaseTool_C : public ABaseTool
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct USkeletalMeshComponent* NewMeshTool;  // 0x298(0x8)
	struct UBP_VisualInteractionComponent_C* BP_VisualInteractionComponent;  // 0x2A0(0x8)
	struct UBP_InteractionVisualizationComponent_C* BP_InteractionVisualizationComponent;  // 0x2A8(0x8)
	struct FMulticastInlineDelegate OnObjectInstigatorUpdated;  // 0x2B0(0x10)
	struct APawn* OldInstigator;  // 0x2C0(0x8)
	struct FString MetaDataInformation;  // 0x2C8(0x10)
	char pad_728[8];  // 0x2D8(0x8)
	struct FS_ToolRuntimeInformation ToolRuntimeInformation;  // 0x2E0(0x70)

	bool GetIsLookInteractionActive(); // Function BP_BaseTool.BP_BaseTool_C.GetIsLookInteractionActive
	bool GetVisualActiveCondition(); // Function BP_BaseTool.BP_BaseTool_C.GetVisualActiveCondition
	void GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule); // Function BP_BaseTool.BP_BaseTool_C.GetAttachmentDetails
	struct TArray<struct FVector> GetDegreePoints(); // Function BP_BaseTool.BP_BaseTool_C.GetDegreePoints
	void OnRep_ToolRuntimeInformation(); // Function BP_BaseTool.BP_BaseTool_C.OnRep_ToolRuntimeInformation
	void SetToolRuntimeInformation(struct FS_ToolRuntimeInformation ToolRuntimeInformation); // Function BP_BaseTool.BP_BaseTool_C.SetToolRuntimeInformation
	struct APawn* GetObjectInstigator(); // Function BP_BaseTool.BP_BaseTool_C.GetObjectInstigator
	void ReceiveBeginPlay(); // Function BP_BaseTool.BP_BaseTool_C.ReceiveBeginPlay
	void SafeDestroyBaseTool(struct AActor* DestroyedActor); // Function BP_BaseTool.BP_BaseTool_C.SafeDestroyBaseTool
	void InteractObject(struct APawn* CharacterReference, struct FName Identity, bool IsExecutedByServer); // Function BP_BaseTool.BP_BaseTool_C.InteractObject
	void OnLooked(struct APlayerController* ControllerReference, struct APawn* PawnReference, double TraceInterval, struct FHitResult Details, bool IsLocallyControlled); // Function BP_BaseTool.BP_BaseTool_C.OnLooked
	void BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature(struct APlayerController* ControllerReference, struct APawn* PawnReference, double TraceInterval, struct FHitResult Details, bool IsLocallyControlled); // Function BP_BaseTool.BP_BaseTool_C.BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature
	void BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted); // Function BP_BaseTool.BP_BaseTool_C.BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature
	void OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit); // Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorUpdatedCallback
	void OnObjectInstigatorChanged(struct APawn* OldInstigator); // Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorChanged
	void ExecuteUbergraph_BP_BaseTool(int32_t EntryPoint); // Function BP_BaseTool.BP_BaseTool_C.ExecuteUbergraph_BP_BaseTool
	void OnObjectInstigatorUpdated__DelegateSignature(struct APawn* OldInstigator, bool IsFirstInit); // Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorUpdated__DelegateSignature
}; 



