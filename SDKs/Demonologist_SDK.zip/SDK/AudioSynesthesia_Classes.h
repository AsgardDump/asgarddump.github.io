#pragma once 
#include <AudioSynesthesia_Structs.h>
 
 
 
// Class AudioSynesthesia.AudioSynesthesiaSettings
// Size: 0x28(Inherited: 0x28) 
struct UAudioSynesthesiaSettings : public UAudioAnalyzerSettings
{

}; 



// Class AudioSynesthesia.LoudnessNRT
// Size: 0x80(Inherited: 0x78) 
struct ULoudnessNRT : public UAudioSynesthesiaNRT
{
	struct ULoudnessNRTSettings* Settings;  // 0x78(0x8)

	void GetNormalizedLoudnessAtTime(float InSeconds, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetNormalizedLoudnessAtTime
	void GetNormalizedChannelLoudnessAtTime(float InSeconds, int32_t InChannel, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetNormalizedChannelLoudnessAtTime
	void GetLoudnessAtTime(float InSeconds, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetLoudnessAtTime
	void GetChannelLoudnessAtTime(float InSeconds, int32_t InChannel, float& OutLoudness); // Function AudioSynesthesia.LoudnessNRT.GetChannelLoudnessAtTime
}; 



// Class AudioSynesthesia.ConstantQNRTSettings
// Size: 0x48(Inherited: 0x28) 
struct UConstantQNRTSettings : public UAudioSynesthesiaNRTSettings
{
	float StartingFrequency;  // 0x28(0x4)
	int32_t NumBands;  // 0x2C(0x4)
	float NumBandsPerOctave;  // 0x30(0x4)
	float AnalysisPeriod;  // 0x34(0x4)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bDownmixToMono : 1;  // 0x38(0x1)
	uint8_t  FFTSize;  // 0x39(0x1)
	uint8_t  WindowType;  // 0x3A(0x1)
	uint8_t  SpectrumType;  // 0x3B(0x1)
	float BandWidthStretch;  // 0x3C(0x4)
	uint8_t  CQTNormalization;  // 0x40(0x1)
	char pad_65[3];  // 0x41(0x3)
	float NoiseFloorDb;  // 0x44(0x4)

}; 



// Class AudioSynesthesia.SynesthesiaSpectrumAnalysisSettings
// Size: 0x30(Inherited: 0x28) 
struct USynesthesiaSpectrumAnalysisSettings : public UAudioSynesthesiaSettings
{
	float AnalysisPeriod;  // 0x28(0x4)
	uint8_t  FFTSize;  // 0x2C(0x1)
	uint8_t  SpectrumType;  // 0x2D(0x1)
	uint8_t  WindowType;  // 0x2E(0x1)
	char pad_47_1 : 7;  // 0x2F(0x1)
	bool bDownmixToMono : 1;  // 0x2F(0x1)

}; 



// Class AudioSynesthesia.LoudnessSettings
// Size: 0x40(Inherited: 0x28) 
struct ULoudnessSettings : public UAudioSynesthesiaSettings
{
	float AnalysisPeriod;  // 0x28(0x4)
	float MinimumFrequency;  // 0x2C(0x4)
	float MaximumFrequency;  // 0x30(0x4)
	uint8_t  CurveType;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	float NoiseFloorDb;  // 0x38(0x4)
	float ExpectedMaxLoudness;  // 0x3C(0x4)

}; 



// Class AudioSynesthesia.SynesthesiaSpectrumAnalyzer
// Size: 0xE8(Inherited: 0x90) 
struct USynesthesiaSpectrumAnalyzer : public UAudioAnalyzer
{
	struct USynesthesiaSpectrumAnalysisSettings* Settings;  // 0x90(0x8)
	struct FMulticastInlineDelegate OnSpectrumResults;  // 0x98(0x10)
	char pad_168[24];  // 0xA8(0x18)
	struct FMulticastInlineDelegate OnLatestSpectrumResults;  // 0xC0(0x10)
	char pad_208[24];  // 0xD0(0x18)

	int32_t GetNumCenterFrequencies(); // Function AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetNumCenterFrequencies
	void GetCenterFrequencies(float InSampleRate, struct TArray<float>& OutCenterFrequencies); // Function AudioSynesthesia.SynesthesiaSpectrumAnalyzer.GetCenterFrequencies
}; 



// Class AudioSynesthesia.AudioSynesthesiaNRTSettings
// Size: 0x28(Inherited: 0x28) 
struct UAudioSynesthesiaNRTSettings : public UAudioAnalyzerNRTSettings
{

}; 



// Class AudioSynesthesia.AudioSynesthesiaNRT
// Size: 0x78(Inherited: 0x78) 
struct UAudioSynesthesiaNRT : public UAudioAnalyzerNRT
{

}; 



// Class AudioSynesthesia.ConstantQNRT
// Size: 0x80(Inherited: 0x78) 
struct UConstantQNRT : public UAudioSynesthesiaNRT
{
	struct UConstantQNRTSettings* Settings;  // 0x78(0x8)

	void GetNormalizedChannelConstantQAtTime(float InSeconds, int32_t InChannel, struct TArray<float>& OutConstantQ); // Function AudioSynesthesia.ConstantQNRT.GetNormalizedChannelConstantQAtTime
	void GetChannelConstantQAtTime(float InSeconds, int32_t InChannel, struct TArray<float>& OutConstantQ); // Function AudioSynesthesia.ConstantQNRT.GetChannelConstantQAtTime
}; 



// Class AudioSynesthesia.LoudnessAnalyzer
// Size: 0xD8(Inherited: 0x90) 
struct ULoudnessAnalyzer : public UAudioAnalyzer
{
	struct ULoudnessSettings* Settings;  // 0x90(0x8)
	struct FMulticastInlineDelegate OnOverallLoudnessResults;  // 0x98(0x10)
	struct FMulticastInlineDelegate OnPerChannelLoudnessResults;  // 0xA8(0x10)
	struct FMulticastInlineDelegate OnLatestOverallLoudnessResults;  // 0xB8(0x10)
	struct FMulticastInlineDelegate OnLatestPerChannelLoudnessResults;  // 0xC8(0x10)

}; 



// Class AudioSynesthesia.LoudnessNRTSettings
// Size: 0x40(Inherited: 0x28) 
struct ULoudnessNRTSettings : public UAudioSynesthesiaNRTSettings
{
	float AnalysisPeriod;  // 0x28(0x4)
	float MinimumFrequency;  // 0x2C(0x4)
	float MaximumFrequency;  // 0x30(0x4)
	uint8_t  CurveType;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	float NoiseFloorDb;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class AudioSynesthesia.MeterSettings
// Size: 0x40(Inherited: 0x28) 
struct UMeterSettings : public UAudioSynesthesiaSettings
{
	float AnalysisPeriod;  // 0x28(0x4)
	uint8_t  PeakMode;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)
	int32_t MeterAttackTime;  // 0x30(0x4)
	int32_t MeterReleaseTime;  // 0x34(0x4)
	int32_t PeakHoldTime;  // 0x38(0x4)
	float ClippingThreshold;  // 0x3C(0x4)

}; 



// Class AudioSynesthesia.MeterAnalyzer
// Size: 0x138(Inherited: 0x90) 
struct UMeterAnalyzer : public UAudioAnalyzer
{
	struct UMeterSettings* Settings;  // 0x90(0x8)
	struct FMulticastInlineDelegate OnOverallMeterResults;  // 0x98(0x10)
	char pad_168[24];  // 0xA8(0x18)
	struct FMulticastInlineDelegate OnPerChannelMeterResults;  // 0xC0(0x10)
	char pad_208[24];  // 0xD0(0x18)
	struct FMulticastInlineDelegate OnLatestOverallMeterResults;  // 0xE8(0x10)
	char pad_248[24];  // 0xF8(0x18)
	struct FMulticastInlineDelegate OnLatestPerChannelMeterResults;  // 0x110(0x10)
	char pad_288[24];  // 0x120(0x18)

}; 



// Class AudioSynesthesia.OnsetNRTSettings
// Size: 0x40(Inherited: 0x28) 
struct UOnsetNRTSettings : public UAudioSynesthesiaNRTSettings
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bDownmixToMono : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	float GranularityInSeconds;  // 0x2C(0x4)
	float Sensitivity;  // 0x30(0x4)
	float MinimumFrequency;  // 0x34(0x4)
	float MaximumFrequency;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 



// Class AudioSynesthesia.OnsetNRT
// Size: 0x80(Inherited: 0x78) 
struct UOnsetNRT : public UAudioSynesthesiaNRT
{
	struct UOnsetNRTSettings* Settings;  // 0x78(0x8)

	void GetNormalizedChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32_t InChannel, struct TArray<float>& OutOnsetTimestamps, struct TArray<float>& OutOnsetStrengths); // Function AudioSynesthesia.OnsetNRT.GetNormalizedChannelOnsetsBetweenTimes
	void GetChannelOnsetsBetweenTimes(float InStartSeconds, float InEndSeconds, int32_t InChannel, struct TArray<float>& OutOnsetTimestamps, struct TArray<float>& OutOnsetStrengths); // Function AudioSynesthesia.OnsetNRT.GetChannelOnsetsBetweenTimes
}; 



