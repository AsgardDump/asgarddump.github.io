#pragma once 
#include "SDK.h" 
 
 
// Function BP_ActorRandomizer.BP_ActorRandomizer_C.ExecuteUbergraph_BP_ActorRandomizer
// Size: 0xE4(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ActorRandomizer
{
	int32_t EntryPoint;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0xC(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x10(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x14(0x4)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform CallFunc_Array_Get_Item;  // 0x20(0x60)
	struct AActor* CallFunc_Array_Get_Item_2;  // 0x80(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x88(0x8)
	struct AActor* CallFunc_FinishSpawningActor_ReturnValue;  // 0x90(0x8)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue_2;  // 0x98(0x8)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0xA0(0x4)
	char pad_164[4];  // 0xA4(0x4)
	struct ATextRenderActor* CallFunc_FinishSpawningActor_ReturnValue_2;  // 0xA8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0xB0(0x4)
	int32_t CallFunc_Array_Add_ReturnValue_2;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct FText CallFunc_Conv_IntToText_ReturnValue;  // 0xC0(0x18)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xD8(0x4)
	char pad_220_1 : 7;  // 0xDC(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0xDC(0x1)
	char pad_221[3];  // 0xDD(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0xE0(0x4)

}; 
// Function BP_ActorRandomizer.BP_ActorRandomizer_C.ClearSpawnedActors
// Size: 0x19(Inherited: 0x0) 
struct FClearSpawnedActors
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_ActorRandomizer.BP_ActorRandomizer_C.DebugRandomItem
// Size: 0xC0(Inherited: 0x0) 
struct FDebugRandomItem
{
	int32_t Temp_int_Array_Index_Variable;  // 0x0(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8(0x4)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0xC(0x4)
	struct FTransform CallFunc_Array_Get_Item;  // 0x10(0x60)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)
	struct FVector CallFunc_BreakTransform_Location;  // 0x78(0x18)
	struct FRotator CallFunc_BreakTransform_Rotation;  // 0x90(0x18)
	struct FVector CallFunc_BreakTransform_Scale;  // 0xA8(0x18)

}; 
// Function BP_ActorRandomizer.BP_ActorRandomizer_C.RunRandomization
// Size: 0x11D(Inherited: 0x0) 
struct FRunRandomization
{
	struct FTransform SelectedTransform;  // 0x0(0x60)
	struct TArray<struct FTransform> Buffer;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsServer_ReturnValue : 1;  // 0x70(0x1)
	char pad_113[3];  // 0x71(0x3)
	int32_t CallFunc_Array_Find_ReturnValue;  // 0x74(0x4)
	int32_t Temp_int_Variable;  // 0x78(0x4)
	char pad_124[4];  // 0x7C(0x4)
	struct AActor* CallFunc_Map_Find_Value;  // 0x80(0x8)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x89(0x1)
	char pad_138[2];  // 0x8A(0x2)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x8C(0x4)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_Array_RemoveItem_ReturnValue : 1;  // 0x90(0x1)
	char pad_145[7];  // 0x91(0x7)
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // 0x98(0x8)
	struct AActor* CallFunc_FinishSpawningActor_ReturnValue;  // 0xA0(0x8)
	char pad_168[8];  // 0xA8(0x8)
	struct FTransform CallFunc_Array_Random_OutItem;  // 0xB0(0x60)
	int32_t CallFunc_Array_Random_OutIndex;  // 0x110(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x114(0x4)
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // 0x118(0x4)
	char pad_284_1 : 7;  // 0x11C(0x1)
	bool CallFunc_LessEqual_IntInt_ReturnValue : 1;  // 0x11C(0x1)

}; 
