#pragma once 
#include "SDK.h" 
 
 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.ExecuteUbergraph_BP_ClockExcorcism
// Size: 0x374(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ClockExcorcism
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FKey K2Node_InputKeyEvent_Key_4;  // 0x8(0x18)
	struct FKey Temp_struct_Variable;  // 0x20(0x18)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x38(0x18)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x50(0x18)
	struct FKey Temp_struct_Variable_2;  // 0x68(0x18)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x80(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x90(0x8)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x98(0x10)
	struct FKey K2Node_InputActionEvent_Key;  // 0xA8(0x18)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue_2;  // 0xC0(0x8)
	struct FKey K2Node_InputKeyEvent_Key;  // 0xC8(0x18)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool K2Node_CustomEvent_IsClockwise : 1;  // 0xE0(0x1)
	char pad_225[7];  // 0xE1(0x7)
	double CallFunc_SelectFloat_ReturnValue;  // 0xE8(0x8)
	double CallFunc_MapRangeUnclamped_ReturnValue;  // 0xF0(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0xF8(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x100(0x18)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0x118(0xE8)
	struct FKey K2Node_InputKeyEvent_Key_5;  // 0x200(0x18)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x218(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // 0x220(0x18)
	struct ABP_ShiversController_C* K2Node_DynamicCast_AsBP_Shivers_Controller;  // 0x238(0x8)
	char pad_576_1 : 7;  // 0x240(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x240(0x1)
	char pad_577[7];  // 0x241(0x7)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult_2;  // 0x248(0xE8)
	struct APawn* K2Node_ComponentBoundEvent_CharacterPawn;  // 0x330(0x8)
	struct FName K2Node_ComponentBoundEvent_Identifier;  // 0x338(0x8)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool K2Node_ComponentBoundEvent_IsServerExucuted : 1;  // 0x340(0x1)
	char pad_833[3];  // 0x341(0x3)
	float K2Node_Event_DeltaSeconds;  // 0x344(0x4)
	struct ABP_ClockExcorcismRandomizer_C* CallFunc_GetActorOfClass_ReturnValue;  // 0x348(0x8)
	char pad_848_1 : 7;  // 0x350(0x1)
	bool CallFunc_CanInteractWithClock_ReturnValue : 1;  // 0x350(0x1)
	char pad_849_1 : 7;  // 0x351(0x1)
	bool CallFunc_CanInteractWithClock_ReturnValue_2 : 1;  // 0x351(0x1)
	char pad_850_1 : 7;  // 0x352(0x1)
	bool K2Node_ComponentBoundEvent_IsFocused : 1;  // 0x352(0x1)
	char pad_851[5];  // 0x353(0x5)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x358(0x8)
	struct ABP_ShiversController_C* K2Node_DynamicCast_AsBP_Shivers_Controller_2;  // 0x360(0x8)
	char pad_872_1 : 7;  // 0x368(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x368(0x1)
	char pad_873[3];  // 0x369(0x3)
	float CallFunc_MakeRotator_Roll_ImplicitCast;  // 0x36C(0x4)
	float CallFunc_MakeRotator_Roll_ImplicitCast_2;  // 0x370(0x4)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.BndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsFocused : 1;  // 0x0(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.BndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
// Size: 0x11(Inherited: 0x0) 
struct FBndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature
{
	struct APawn* CharacterPawn;  // 0x0(0x8)
	struct FName Identifier;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool IsServerExucuted : 1;  // 0x10(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.CanPlayerInteract
// Size: 0xC(Inherited: 0x9) 
struct FCanPlayerInteract : public FCanPlayerInteract
{
	struct APawn* PawnReference;  // 0x0(0x8)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool CallFunc_CanInteractWithClock_ReturnValue : 1;  // 0x9(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool CallFunc_CanPlayerInteract_ReturnValue : 1;  // 0xA(0x1)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0xB(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.CanInteractWithClock
// Size: 0x32(Inherited: 0x0) 
struct FCanInteractWithClock
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_Shivers_InGameState_C* CallFunc_Get_Shivers_in_Game_State_ReturnValue;  // 0x8(0x8)
	struct FGameplayTagContainer CallFunc_MakeGameplayTagContainerFromArray_ReturnValue;  // 0x10(0x20)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_HasTag_ReturnValue : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x31(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetAttachmentDetails
// Size: 0x83(Inherited: 0x83) 
struct FGetAttachmentDetails : public FGetAttachmentDetails
{
	char pad_131_1 : 7;  // 0x83(0x1)
	bool IsManualAttachment : 1;  // 0x0(0x1)
	struct FTransform RelativeTransform;  // 0x10(0x60)
	struct USceneComponent* AttachmentComponent;  // 0x70(0x8)
	struct FName SocketName;  // 0x78(0x8)
	char LocationRule;  // 0x80(0x1)
	char RotationRule;  // 0x81(0x1)
	char ScaleRule;  // 0x82(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetIsLookInteractionActive
// Size: 0x4(Inherited: 0x1) 
struct FGetIsLookInteractionActive : public FGetIsLookInteractionActive
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_CanInteractWithClock_ReturnValue : 1;  // 0x1(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_D_K2Node_InputKeyEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_D_K2Node_InputKeyEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetHourAndMinute
// Size: 0x60(Inherited: 0x0) 
struct FGetHourAndMinute
{
	double Hour;  // 0x0(0x8)
	double Minute;  // 0x8(0x8)
	double CallFunc_Divide_DoubleDouble_ReturnValue;  // 0x10(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue;  // 0x18(0x8)
	double CallFunc_Percent_FloatFloat_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_GreaterEqual_DoubleDouble_ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	double CallFunc_SelectFloat_ReturnValue;  // 0x30(0x8)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	double CallFunc_Conv_IntToDouble_ReturnValue;  // 0x40(0x8)
	double CallFunc_Conv_IntToDouble_ReturnValue_2;  // 0x48(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue_2;  // 0x50(0x8)
	double CallFunc_MapRangeClamped_ReturnValue;  // 0x58(0x8)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetVisualActiveCondition
// Size: 0x4(Inherited: 0x1) 
struct FGetVisualActiveCondition : public FGetVisualActiveCondition
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_CanInteractWithClock_ReturnValue : 1;  // 0x1(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_A_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_A_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_A_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_A_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_D_K2Node_InputKeyEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_D_K2Node_InputKeyEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_Escape_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Escape_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_Interaction_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Interaction_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.MinuteMovement
// Size: 0x1(Inherited: 0x0) 
struct FMinuteMovement
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsClockWise : 1;  // 0x0(0x1)

}; 
// Function BP_ClockExcorcism.BP_ClockExcorcism_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
