#pragma once 
#include "SDK.h" 
 
 
// UserDefinedStruct Apparel_DataTable_Info.Apparel_DataTable_Info
// Size: 0x160(Inherited: 0x0) 
struct FApparel_DataTable_Info
{
	struct USkeletalMesh* Mesh_92_3A264C984C4177BA053742B2AB2285FA;  // 0x0(0x8)
	struct FText Name_163_E9D561CD4615379EF3EFD19F621FAFE3;  // 0x8(0x18)
	struct TArray<struct UMaterialInterface*> Material00_129_96B249DD4EE359120DE3478D530A9FDE;  // 0x20(0x10)
	struct TArray<struct UMaterialInterface*> Material01_130_6A05896D4135E2064DF835946746CAE5;  // 0x30(0x10)
	struct TArray<struct UMaterialInterface*> Material02_143_1ED6D8614E09BFADE7657A91B488D7B8;  // 0x40(0x10)
	struct TArray<struct UMaterialInterface*> Material03_144_2C2D38234E6A438604A2B8A2F50FAA82;  // 0x50(0x10)
	struct TArray<struct UMaterialInterface*> Material04_145_000DC4D140A03084609F1293D9196311;  // 0x60(0x10)
	struct TArray<struct UMaterialInterface*> Material05_146_80DD005D48741EBBB25948BE815E872A;  // 0x70(0x10)
	struct TArray<struct UMaterialInterface*> Material06_200_883BD92E4D1374DB2732A6994D5404A8;  // 0x80(0x10)
	struct TArray<struct UMaterialInterface*> Material07_201_BEEFF0BE45FA285BB16E27841E50CBE8;  // 0x90(0x10)
	struct TArray<struct UMaterialInterface*> Material08_202_DB4F67DD4B790DDD0FE81DB28BBCA569;  // 0xA0(0x10)
	struct TArray<struct UTexture2D*> MaterialThumbnail_96_2AEB09AB47B3FAEF547356AAEF08FEF4;  // 0xB0(0x10)
	char Apparel_Type Type_159_972FCE92423EBA48BBC5719933DD1FD6;  // 0xC0(0x1)
	char pad_193[7];  // 0xC1(0x7)
	struct TArray<char Apparel_Type> OccupiesTheseTypes_212_02AE2B6B439B972BAAC32B808555DEB8;  // 0xC8(0x10)
	struct UTexture2D* Mask_99_1531A8FA45ACBF99463756B66A02A3CC;  // 0xD8(0x8)
	struct FVector FootTransforms_213_094E66F14A7BD8B9DA21B28FED06C88D;  // 0xE0(0x18)
	struct TMap<struct FName, float> BodyMorphs_153_215C32DB47A42BF921AA12942F6AAF35;  // 0xF8(0x50)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool HideHead_191_241BD28246BA0105D87B4E8798011D15 : 1;  // 0x148(0x1)
	char pad_329_1 : 7;  // 0x149(0x1)
	bool AddToMenu_206_5D7BB8874FE320CAAB073C955613FEA5 : 1;  // 0x149(0x1)
	char pad_330[6];  // 0x14A(0x6)
	struct TArray<struct FName> Tags_218_D18A5590460E8E2EC05B7EAD97962519;  // 0x150(0x10)

}; 
