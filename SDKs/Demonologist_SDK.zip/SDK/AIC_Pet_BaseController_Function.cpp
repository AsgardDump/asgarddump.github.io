#include "SDK.h" 
 
 
void AAIController::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AIC_Pet_BaseController.AIC_Pet_BaseController_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AAIController::ExecuteUbergraph_AIC_Pet_BaseController(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AIC_Pet_BaseController = UObject::FindObject<UFunction>("Function AIC_Pet_BaseController.AIC_Pet_BaseController_C.ExecuteUbergraph_AIC_Pet_BaseController");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AIC_Pet_BaseController, &parms);
}

