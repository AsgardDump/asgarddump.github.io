#pragma once 
#include <A_Tool_Base_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Tool_Base.A_Tool_Base_C
// Size: 0x3E8(Inherited: 0x290) 
struct AA_Tool_Base_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct UStaticMeshComponent* Mesh;  // 0x298(0x8)
	struct USceneComponent* Scene;  // 0x2A0(0x8)
	float Add_Movement_TL_Value_7DA2F8EF41A8C395799B61AE5E1E1A6D;  // 0x2A8(0x4)
	char ETimelineDirection Add_Movement_TL__Direction_7DA2F8EF41A8C395799B61AE5E1E1A6D;  // 0x2AC(0x1)
	char pad_685[3];  // 0x2AD(0x3)
	struct UTimelineComponent* Add Movement TL;  // 0x2B0(0x8)
	struct USoundBase* Equip Audio;  // 0x2B8(0x8)
	struct UAnimSequence* Idle Pose;  // 0x2C0(0x8)
	struct UBlendSpace* Moving Blendspace;  // 0x2C8(0x8)
	struct UAimOffsetBlendSpace* Aim Offset;  // 0x2D0(0x8)
	struct UAnimSequenceBase* Equip Montage;  // 0x2D8(0x8)
	double Damage;  // 0x2E0(0x8)
	struct TMap<struct FName, double> Damage Multiplier;  // 0x2E8(0x50)
	double Use Cooldown;  // 0x338(0x8)
	char pad_832_1 : 7;  // 0x340(0x1)
	bool Aiming : 1;  // 0x340(0x1)
	char pad_833_1 : 7;  // 0x341(0x1)
	bool Aim Zoom : 1;  // 0x341(0x1)
	char pad_834_1 : 7;  // 0x342(0x1)
	bool Using Tool : 1;  // 0x342(0x1)
	char pad_835[5];  // 0x343(0x5)
	UUserWidget* Widget Class;  // 0x348(0x8)
	struct UUserWidget* Widget Ref;  // 0x350(0x8)
	struct UTools_C* Tools Component;  // 0x358(0x8)
	struct TMap<struct UPhysicalMaterial*, struct USoundBase*> Phys Mat Impact Audio;  // 0x360(0x50)
	int32_t Current Ammo;  // 0x3B0(0x4)
	int32_t Max Ammo;  // 0x3B4(0x4)
	char pad_952_1 : 7;  // 0x3B8(0x1)
	bool Shakes : 1;  // 0x3B8(0x1)
	char pad_953[7];  // 0x3B9(0x7)
	struct FDataTableRowHandle Tool Data;  // 0x3C0(0x10)
	AA_Pickup_C* Pickup Class;  // 0x3D0(0x8)
	double Stun Chance;  // 0x3D8(0x8)
	struct USoundAttenuation* Impact Attenuation;  // 0x3E0(0x8)

	void Attack Combo(int32_t Count); // Function A_Tool_Base.A_Tool_Base_C.Attack Combo
	void Get Focal Point(struct AActor* Pawn, struct FVector& Focal Point); // Function A_Tool_Base.A_Tool_Base_C.Get Focal Point
	void Get Interact Location(struct AActor* Actor, struct FVector& Location); // Function A_Tool_Base.A_Tool_Base_C.Get Interact Location
	void Interactable Check(struct APawn* Pawn, bool& Interactable); // Function A_Tool_Base.A_Tool_Base_C.Interactable Check
	void Character Mesh(struct USkeletalMeshComponent*& Mesh); // Function A_Tool_Base.A_Tool_Base_C.Character Mesh
	void Reset Attack(); // Function A_Tool_Base.A_Tool_Base_C.Reset Attack
	struct UCombat_C* Combat Component(); // Function A_Tool_Base.A_Tool_Base_C.Combat Component
	void Hit Check(struct TArray<struct FHitResult>& Hits, struct TArray<struct FHitResult>& Valid Hits); // Function A_Tool_Base.A_Tool_Base_C.Hit Check
	void Root Bone Vectors(struct FVector& Forward Vector, struct FVector& Right Vector); // Function A_Tool_Base.A_Tool_Base_C.Root Bone Vectors
	void Owner Character(struct ACharacter*& AsCharacter); // Function A_Tool_Base.A_Tool_Base_C.Owner Character
	void Add Movement TL__FinishedFunc(); // Function A_Tool_Base.A_Tool_Base_C.Add Movement TL__FinishedFunc
	void Add Movement TL__UpdateFunc(); // Function A_Tool_Base.A_Tool_Base_C.Add Movement TL__UpdateFunc
	void Update Ammo(); // Function A_Tool_Base.A_Tool_Base_C.Update Ammo
	void Nav Left(); // Function A_Tool_Base.A_Tool_Base_C.Nav Left
	void Nav Right(); // Function A_Tool_Base.A_Tool_Base_C.Nav Right
	void Nav Up(); // Function A_Tool_Base.A_Tool_Base_C.Nav Up
	void Nav Down(); // Function A_Tool_Base.A_Tool_Base_C.Nav Down
	void Nav Release(); // Function A_Tool_Base.A_Tool_Base_C.Nav Release
	void Cancel(); // Function A_Tool_Base.A_Tool_Base_C.Cancel
	void Confirm(); // Function A_Tool_Base.A_Tool_Base_C.Confirm
	void Action 1(); // Function A_Tool_Base.A_Tool_Base_C.Action 1
	void Action 2(); // Function A_Tool_Base.A_Tool_Base_C.Action 2
	void Action 3(); // Function A_Tool_Base.A_Tool_Base_C.Action 3
	void Action 4(); // Function A_Tool_Base.A_Tool_Base_C.Action 4
	void Action 5(); // Function A_Tool_Base.A_Tool_Base_C.Action 5
	void Action 6(); // Function A_Tool_Base.A_Tool_Base_C.Action 6
	void Action 7(); // Function A_Tool_Base.A_Tool_Base_C.Action 7
	void Action 8(); // Function A_Tool_Base.A_Tool_Base_C.Action 8
	void Action 9(); // Function A_Tool_Base.A_Tool_Base_C.Action 9
	void Action Main(); // Function A_Tool_Base.A_Tool_Base_C.Action Main
	void Scroll Up(); // Function A_Tool_Base.A_Tool_Base_C.Scroll Up
	void Scroll Down(); // Function A_Tool_Base.A_Tool_Base_C.Scroll Down
	void Main Fire(); // Function A_Tool_Base.A_Tool_Base_C.Main Fire
	void Main Fire Release(); // Function A_Tool_Base.A_Tool_Base_C.Main Fire Release
	void Secondary Fire(); // Function A_Tool_Base.A_Tool_Base_C.Secondary Fire
	void Secondary Fire Release(); // Function A_Tool_Base.A_Tool_Base_C.Secondary Fire Release
	void Cycle Left(); // Function A_Tool_Base.A_Tool_Base_C.Cycle Left
	void Cycle Right(); // Function A_Tool_Base.A_Tool_Base_C.Cycle Right
	void Exit(); // Function A_Tool_Base.A_Tool_Base_C.Exit
	void Reset(); // Function A_Tool_Base.A_Tool_Base_C.Reset
	void Interact(struct ACharacter* Character); // Function A_Tool_Base.A_Tool_Base_C.Interact
	void In Range(bool Value); // Function A_Tool_Base.A_Tool_Base_C.In Range
	void TL Move(double Duration (s), struct FVector Direction, double Input Scale); // Function A_Tool_Base.A_Tool_Base_C.TL Move
	void MC Sound(struct USoundBase* Sound, struct FVector Location, struct USoundAttenuation* Attenuation); // Function A_Tool_Base.A_Tool_Base_C.MC Sound
	void MC Decal(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, double LifeSpan); // Function A_Tool_Base.A_Tool_Base_C.MC Decal
	void Decal(struct UMaterialInterface* DecalMaterial, struct FVector DecalSize, struct FVector Location, struct FRotator Rotation, double LifeSpan); // Function A_Tool_Base.A_Tool_Base_C.Decal
	void Play Sound(struct USoundBase* Sound, struct FVector Location, struct USoundAttenuation* Attenuation); // Function A_Tool_Base.A_Tool_Base_C.Play Sound
	void ReceiveDestroyed(); // Function A_Tool_Base.A_Tool_Base_C.ReceiveDestroyed
	void Create Widget(); // Function A_Tool_Base.A_Tool_Base_C.Create Widget
	void Emitter(struct UParticleSystem* Emitter, struct FVector Location, struct FRotator Rotation, struct FVector Scale); // Function A_Tool_Base.A_Tool_Base_C.Emitter
	void MC Emitter(struct UParticleSystem* Emitter, struct FVector Location, struct FRotator Rotation, struct FVector Scale); // Function A_Tool_Base.A_Tool_Base_C.MC Emitter
	void Phys Mat Impact(struct FVector Location, struct UPhysicalMaterial* Phys Mat); // Function A_Tool_Base.A_Tool_Base_C.Phys Mat Impact
	void Set Acceleration(double MaxAcceleration); // Function A_Tool_Base.A_Tool_Base_C.Set Acceleration
	void Toggle Lock On Widget(struct AActor* Target); // Function A_Tool_Base.A_Tool_Base_C.Toggle Lock On Widget
	void ExecuteUbergraph_A_Tool_Base(int32_t EntryPoint); // Function A_Tool_Base.A_Tool_Base_C.ExecuteUbergraph_A_Tool_Base
}; 



