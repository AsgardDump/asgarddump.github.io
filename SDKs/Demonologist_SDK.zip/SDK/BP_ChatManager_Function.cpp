#include "SDK.h" 
 
 
void AActor::BroadcastMessage(struct FString Sender, struct FString Message){

	static UObject* p_BroadcastMessage = UObject::FindObject<UFunction>("Function BP_ChatManager.BP_ChatManager_C.BroadcastMessage");

	struct {
		struct FString Sender;
		struct FString Message;
	} parms;

	parms.Sender = Sender;
	parms.Message = Message;

	ProcessEvent(p_BroadcastMessage, &parms);
}

void AActor::SendMessage(struct FString Message){

	static UObject* p_SendMessage = UObject::FindObject<UFunction>("Function BP_ChatManager.BP_ChatManager_C.SendMessage");

	struct {
		struct FString Message;
	} parms;

	parms.Message = Message;

	ProcessEvent(p_SendMessage, &parms);
}

bool AActor::CanSendMessage(struct FString Message){

	static UObject* p_CanSendMessage = UObject::FindObject<UFunction>("Function BP_ChatManager.BP_ChatManager_C.CanSendMessage");

	struct {
		struct FString Message;
		bool return_value;
	} parms;

	parms.Message = Message;

	ProcessEvent(p_CanSendMessage, &parms);
	return parms.return_value;
}

void AActor::SendMessage OnMulticast(struct FString Sender, struct FString Message){

	static UObject* p_SendMessage OnMulticast = UObject::FindObject<UFunction>("Function BP_ChatManager.BP_ChatManager_C.SendMessage OnMulticast");

	struct {
		struct FString Sender;
		struct FString Message;
	} parms;

	parms.Sender = Sender;
	parms.Message = Message;

	ProcessEvent(p_SendMessage OnMulticast, &parms);
}

void AActor::ExecuteUbergraph_BP_ChatManager(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_ChatManager = UObject::FindObject<UFunction>("Function BP_ChatManager.BP_ChatManager_C.ExecuteUbergraph_BP_ChatManager");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_ChatManager, &parms);
}

void AActor::BroadcastMessageDispatchers__DelegateSignature(struct FString Sender, struct FString Message){

	static UObject* p_BroadcastMessageDispatchers__DelegateSignature = UObject::FindObject<UFunction>("Function BP_ChatManager.BP_ChatManager_C.BroadcastMessageDispatchers__DelegateSignature");

	struct {
		struct FString Sender;
		struct FString Message;
	} parms;

	parms.Sender = Sender;
	parms.Message = Message;

	ProcessEvent(p_BroadcastMessageDispatchers__DelegateSignature, &parms);
}

