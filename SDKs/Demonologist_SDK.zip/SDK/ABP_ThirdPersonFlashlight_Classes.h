#pragma once 
#include <ABP_ThirdPersonFlashlight_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonFlashlight.ABP_ThirdPersonFlashlight_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonFlashlight_C : public UABP_ThirdPersonToolLayer_C
{

}; 



