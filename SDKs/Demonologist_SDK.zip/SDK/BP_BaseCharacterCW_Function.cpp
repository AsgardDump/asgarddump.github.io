#include "SDK.h" 
 
 
struct FVector ACharacter::GetMovementRightVector(){

	static UObject* p_GetMovementRightVector = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.GetMovementRightVector");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetMovementRightVector, &parms);
	return parms.return_value;
}

struct FVector ACharacter::GetMovementForwardVector(){

	static UObject* p_GetMovementForwardVector = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.GetMovementForwardVector");

	struct {
		struct FVector return_value;
	} parms;


	ProcessEvent(p_GetMovementForwardVector, &parms);
	return parms.return_value;
}

void ACharacter::AddCharacterInput(char E_MovementDirection MovementDirection, double InputScale){

	static UObject* p_AddCharacterInput = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.AddCharacterInput");

	struct {
		char E_MovementDirection MovementDirection;
		double InputScale;
	} parms;

	parms.MovementDirection = MovementDirection;
	parms.InputScale = InputScale;

	ProcessEvent(p_AddCharacterInput, &parms);
}

void ACharacter::ReceiveOptionVariables(){

	static UObject* p_ReceiveOptionVariables = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ReceiveOptionVariables");

	struct {
	} parms;


	ProcessEvent(p_ReceiveOptionVariables, &parms);
}

void ACharacter::ReceiveDestroyed(){

	static UObject* p_ReceiveDestroyed = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ReceiveDestroyed");

	struct {
	} parms;


	ProcessEvent(p_ReceiveDestroyed, &parms);
}

void ACharacter::InpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15(float AxisValue){

	static UObject* p_InpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15, &parms);
}

void ACharacter::InpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2(float AxisValue){

	static UObject* p_InpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2, &parms);
}

void ACharacter::InpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7(float AxisValue){

	static UObject* p_InpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7, &parms);
}

void ACharacter::InpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4(float AxisValue){

	static UObject* p_InpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4, &parms);
}

void ACharacter::InpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1(float AxisValue){

	static UObject* p_InpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1, &parms);
}

void ACharacter::InpAxisEvt_MoveRight_K2Node_InputAxisEvent_14(float AxisValue){

	static UObject* p_InpAxisEvt_MoveRight_K2Node_InputAxisEvent_14 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_14");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_MoveRight_K2Node_InputAxisEvent_14, &parms);
}

void ACharacter::InpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11(float AxisValue){

	static UObject* p_InpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11, &parms);
}

void ACharacter::InpAxisEvt_MoveForward_K2Node_InputAxisEvent_10(float AxisValue){

	static UObject* p_InpAxisEvt_MoveForward_K2Node_InputAxisEvent_10 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_10");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_MoveForward_K2Node_InputAxisEvent_10, &parms);
}

void ACharacter::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ACharacter::InpAxisEvt_LookRight_K2Node_InputAxisEvent_6(float AxisValue){

	static UObject* p_InpAxisEvt_LookRight_K2Node_InputAxisEvent_6 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookRight_K2Node_InputAxisEvent_6");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_LookRight_K2Node_InputAxisEvent_6, &parms);
}

void ACharacter::InpAxisEvt_LookUp_K2Node_InputAxisEvent_5(float AxisValue){

	static UObject* p_InpAxisEvt_LookUp_K2Node_InputAxisEvent_5 = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_5");

	struct {
		float AxisValue;
	} parms;

	parms.AxisValue = AxisValue;

	ProcessEvent(p_InpAxisEvt_LookUp_K2Node_InputAxisEvent_5, &parms);
}

void ACharacter::ExecuteUbergraph_BP_BaseCharacterCW(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BaseCharacterCW = UObject::FindObject<UFunction>("Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ExecuteUbergraph_BP_BaseCharacterCW");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BaseCharacterCW, &parms);
}

