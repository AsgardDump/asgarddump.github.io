#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_BaseEntity.ABP_BaseEntity_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_CCC274064A0E873E759813960706D066(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_CCC274064A0E873E759813960706D066 = UObject::FindObject<UFunction>("Function ABP_BaseEntity.ABP_BaseEntity_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_CCC274064A0E873E759813960706D066");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_CCC274064A0E873E759813960706D066, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_EBB946774B2B98A87D83F49F059226F7(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_EBB946774B2B98A87D83F49F059226F7 = UObject::FindObject<UFunction>("Function ABP_BaseEntity.ABP_BaseEntity_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_EBB946774B2B98A87D83F49F059226F7");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_BaseEntity_AnimGraphNode_TransitionResult_EBB946774B2B98A87D83F49F059226F7, &parms);
}

void UAnimInstance::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_BaseEntity.ABP_BaseEntity_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_BaseEntity(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_BaseEntity = UObject::FindObject<UFunction>("Function ABP_BaseEntity.ABP_BaseEntity_C.ExecuteUbergraph_ABP_BaseEntity");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_BaseEntity, &parms);
}

