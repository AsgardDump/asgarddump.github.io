#pragma once 
#include <BP_Abaddon_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Abaddon.BP_Abaddon_C
// Size: 0xA98(Inherited: 0xA90) 
struct ABP_Abaddon_C : public ABP_Entity_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA90(0x8)

	bool GetCanPerformGhostAbility(); // Function BP_Abaddon.BP_Abaddon_C.GetCanPerformGhostAbility
	struct TArray<struct AActor*> FilterAbaddonCharacters(struct TArray<struct AActor*>& SeenActors); // Function BP_Abaddon.BP_Abaddon_C.FilterAbaddonCharacters
	void OnPerceptionUpdatedCallback(struct TArray<struct AActor*>& UpdatedActors); // Function BP_Abaddon.BP_Abaddon_C.OnPerceptionUpdatedCallback
	void ExecuteUbergraph_BP_Abaddon(int32_t EntryPoint); // Function BP_Abaddon.BP_Abaddon_C.ExecuteUbergraph_BP_Abaddon
}; 



