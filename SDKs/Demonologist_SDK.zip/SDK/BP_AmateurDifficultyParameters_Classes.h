#pragma once 
#include <BP_AmateurDifficultyParameters_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_AmateurDifficultyParameters.BP_AmateurDifficultyParameters_C
// Size: 0xB8(Inherited: 0xB8) 
struct UBP_AmateurDifficultyParameters_C : public UBP_DifficultyParameters_C
{

}; 



