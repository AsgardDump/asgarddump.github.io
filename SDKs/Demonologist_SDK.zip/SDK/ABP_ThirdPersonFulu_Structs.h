#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ABP_ThirdPersonFulu.ABP_ThirdPersonFulu_C.AnimBlueprintGeneratedConstantData
// Size: 0x150(Inherited: 0x150) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
