#include "SDK.h" 
 
 
bool AActor::CanReflectCapture(){

	static UObject* p_CanReflectCapture = UObject::FindObject<UFunction>("Function BP_CCTV.BP_CCTV_C.CanReflectCapture");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanReflectCapture, &parms);
	return parms.return_value;
}

void AActor::InitializeCamera(){

	static UObject* p_InitializeCamera = UObject::FindObject<UFunction>("Function BP_CCTV.BP_CCTV_C.InitializeCamera");

	struct {
	} parms;


	ProcessEvent(p_InitializeCamera, &parms);
}

void AActor::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_CCTV.BP_CCTV_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AActor::SetReflectCaptureStatus(bool ReflectCapture){

	static UObject* p_SetReflectCaptureStatus = UObject::FindObject<UFunction>("Function BP_CCTV.BP_CCTV_C.SetReflectCaptureStatus");

	struct {
		bool ReflectCapture;
	} parms;

	parms.ReflectCapture = ReflectCapture;

	ProcessEvent(p_SetReflectCaptureStatus, &parms);
}

void AActor::ExecuteUbergraph_BP_CCTV(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_CCTV = UObject::FindObject<UFunction>("Function BP_CCTV.BP_CCTV_C.ExecuteUbergraph_BP_CCTV");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_CCTV, &parms);
}

