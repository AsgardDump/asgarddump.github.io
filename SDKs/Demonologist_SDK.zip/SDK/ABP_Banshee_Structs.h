#pragma once 
#include "SDK.h" 
 
 
// Function ABP_Banshee.ABP_Banshee_C.ExecuteUbergraph_ABP_Banshee
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_Banshee
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AActor* CallFunc_GetOwningActor_ReturnValue;  // 0x8(0x8)
	struct ACharacter* K2Node_DynamicCast_AsCharacter;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
// ScriptStruct ABP_Banshee.ABP_Banshee_C.AnimBlueprintGeneratedConstantData
// Size: 0x138(Inherited: 0x138) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
