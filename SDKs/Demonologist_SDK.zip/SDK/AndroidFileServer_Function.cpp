#include "SDK.h" 
 
 
bool UBlueprintFunctionLibrary::StopFileServer(bool bUSB, bool bNetwork){

	static UObject* p_StopFileServer = UObject::FindObject<UFunction>("Function AndroidFileServer.AndroidFileServerBPLibrary.StopFileServer");

	struct {
		bool bUSB;
		bool bNetwork;
		bool return_value;
	} parms;

	parms.bUSB = bUSB;
	parms.bNetwork = bNetwork;

	ProcessEvent(p_StopFileServer, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::StartFileServer(bool bUSB, bool bNetwork, int32_t Port){

	static UObject* p_StartFileServer = UObject::FindObject<UFunction>("Function AndroidFileServer.AndroidFileServerBPLibrary.StartFileServer");

	struct {
		bool bUSB;
		bool bNetwork;
		int32_t Port;
		bool return_value;
	} parms;

	parms.bUSB = bUSB;
	parms.bNetwork = bNetwork;
	parms.Port = Port;

	ProcessEvent(p_StartFileServer, &parms);
	return parms.return_value;
}

char EAFSActiveType UBlueprintFunctionLibrary::IsFileServerRunning(){

	static UObject* p_IsFileServerRunning = UObject::FindObject<UFunction>("Function AndroidFileServer.AndroidFileServerBPLibrary.IsFileServerRunning");

	struct {
		char EAFSActiveType return_value;
	} parms;


	ProcessEvent(p_IsFileServerRunning, &parms);
	return parms.return_value;
}

