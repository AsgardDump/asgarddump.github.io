#pragma once 
#include "SDK.h" 
 
 
// Function A_Pickup.A_Pickup_C.ExecuteUbergraph_A_Pickup
// Size: 0x2AC(Inherited: 0x0) 
struct FExecuteUbergraph_A_Pickup
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x8(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0x10(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0x18(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue_2;  // 0x20(0x8)
	struct ACharacter* K2Node_Event_Character;  // 0x28(0x8)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x30(0x18)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x48(0x8)
	struct UCC_Interact_C* CallFunc_Create_ReturnValue;  // 0x50(0x8)
	struct UUserWidget* CallFunc_GetUserWidgetObject_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x60(0x1)
	char pad_97_1 : 7;  // 0x61(0x1)
	bool K2Node_Event_Value : 1;  // 0x61(0x1)
	char pad_98[6];  // 0x62(0x6)
	struct FText Temp_text_Variable;  // 0x68(0x18)
	double CallFunc_GetWorldDeltaSeconds_ReturnValue;  // 0x80(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_3;  // 0x88(0x8)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x90(0x18)
	struct FHitResult CallFunc_K2_SetRelativeRotation_SweepHitResult;  // 0xA8(0xE8)
	struct FRotator CallFunc_ComposeRotators_ReturnValue;  // 0x190(0x18)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool CallFunc_HasAuthority_ReturnValue : 1;  // 0x1A8(0x1)
	char pad_425[7];  // 0x1A9(0x7)
	struct FHitResult CallFunc_K2_SetRelativeLocationAndRotation_SweepHitResult;  // 0x1B0(0xE8)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast;  // 0x298(0x8)
	double CallFunc_Add_DoubleDouble_A_ImplicitCast;  // 0x2A0(0x8)
	float CallFunc_MakeRotator_Yaw_ImplicitCast;  // 0x2A8(0x4)

}; 
// Function A_Pickup.A_Pickup_C.Get Focal Point
// Size: 0x20(Inherited: 0x0) 
struct FGet Focal Point
{
	struct AActor* Pawn;  // 0x0(0x8)
	struct FVector Focal Point;  // 0x8(0x18)

}; 
// Function A_Pickup.A_Pickup_C.Get Interact Location
// Size: 0x20(Inherited: 0x0) 
struct FGet Interact Location
{
	struct AActor* Actor;  // 0x0(0x8)
	struct FVector Location;  // 0x8(0x18)

}; 
// Function A_Pickup.A_Pickup_C.Interact
// Size: 0x8(Inherited: 0x0) 
struct FInteract
{
	struct ACharacter* Character;  // 0x0(0x8)

}; 
// Function A_Pickup.A_Pickup_C.In Range
// Size: 0x1(Inherited: 0x0) 
struct FIn Range
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Value : 1;  // 0x0(0x1)

}; 
// Function A_Pickup.A_Pickup_C.Interactable Check
// Size: 0x9(Inherited: 0x0) 
struct FInteractable Check
{
	struct APawn* Pawn;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Interactable : 1;  // 0x8(0x1)

}; 
// Function A_Pickup.A_Pickup_C.Pickup Event
// Size: 0x8A(Inherited: 0x0) 
struct FPickup Event
{
	struct ACharacter* Character;  // 0x0(0x8)
	struct FTool_Data DT Row;  // 0x8(0x38)
	struct ACharacter* Pickup Character;  // 0x40(0x8)
	struct UTools_C* CallFunc_GetComponentByClass_ReturnValue;  // 0x48(0x8)
	struct FTool_Data CallFunc_GetDataTableRowFromName_OutRow;  // 0x50(0x38)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x88(0x1)
	char pad_137_1 : 7;  // 0x89(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x89(0x1)

}; 
// Function A_Pickup.A_Pickup_C.UserConstructionScript
// Size: 0x3B(Inherited: 0x0) 
struct FUserConstructionScript : public FUserConstructionScript
{
	struct FTool_Data CallFunc_GetDataTableRowFromName_OutRow;  // 0x0(0x38)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_SetStaticMesh_ReturnValue : 1;  // 0x3A(0x1)

}; 
