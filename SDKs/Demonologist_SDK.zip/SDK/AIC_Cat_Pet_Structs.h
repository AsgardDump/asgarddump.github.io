#pragma once 
#include "SDK.h" 
 
 
// Function AIC_Cat_Pet.AIC_Cat_Pet_C.ExecuteUbergraph_AIC_Cat_Pet
// Size: 0x5(Inherited: 0x0) 
struct FExecuteUbergraph_AIC_Cat_Pet
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_RunBehaviorTree_ReturnValue : 1;  // 0x4(0x1)

}; 
