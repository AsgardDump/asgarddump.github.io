#include "SDK.h" 
 
 
void AA_Tool_Base_C::Reset Attack(){

	static UObject* p_Reset Attack = UObject::FindObject<UFunction>("Function A_Tool_Flashlight.A_Tool_Flashlight_C.Reset Attack");

	struct {
	} parms;


	ProcessEvent(p_Reset Attack, &parms);
}

void AA_Tool_Base_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function A_Tool_Flashlight.A_Tool_Flashlight_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AA_Tool_Base_C::Main Fire(){

	static UObject* p_Main Fire = UObject::FindObject<UFunction>("Function A_Tool_Flashlight.A_Tool_Flashlight_C.Main Fire");

	struct {
	} parms;


	ProcessEvent(p_Main Fire, &parms);
}

void AA_Tool_Base_C::ExecuteUbergraph_A_Tool_Flashlight(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_A_Tool_Flashlight = UObject::FindObject<UFunction>("Function A_Tool_Flashlight.A_Tool_Flashlight_C.ExecuteUbergraph_A_Tool_Flashlight");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_A_Tool_Flashlight, &parms);
}

