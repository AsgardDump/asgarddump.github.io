#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseInspectObject.BP_BaseInspectObject_C.ExecuteUbergraph_BP_BaseInspectObject
// Size: 0x31(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseInspectObject
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UGameInstance* CallFunc_GetGameInstance_ReturnValue;  // 0x8(0x8)
	struct TScriptInterface<IBPI_InspectMainObject_C> K2Node_DynamicCast_AsBPI_Inspect_Main_Object;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct ABP_InspectionLiveObjects_C* CallFunc_GetInspectObject_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_GetInspectObject_IsSuccessful : 1;  // 0x30(0x1)

}; 
