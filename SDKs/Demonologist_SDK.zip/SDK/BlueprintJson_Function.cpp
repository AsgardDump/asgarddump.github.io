#include "SDK.h" 
 
 
bool UBlueprintFunctionLibrary::NotEqual_JsonValue(struct FBlueprintJsonValue& A, struct FBlueprintJsonValue& B){

	static UObject* p_NotEqual_JsonValue = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.NotEqual_JsonValue");

	struct {
		struct FBlueprintJsonValue& A;
		struct FBlueprintJsonValue& B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_NotEqual_JsonValue, &parms);
	return parms.return_value;
}

uint8_t  UBlueprintFunctionLibrary::JsonType(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_JsonType = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonType");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		uint8_t  return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_JsonType, &parms);
	return parms.return_value;
}

struct FBlueprintJsonObject UBlueprintFunctionLibrary::JsonSetField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName, struct FBlueprintJsonValue& JsonValue){

	static UObject* p_JsonSetField = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonSetField");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString FieldName;
		struct FBlueprintJsonValue& JsonValue;
		struct FBlueprintJsonObject return_value;
	} parms;

	parms.JsonObject = JsonObject;
	parms.FieldName = FieldName;
	parms.JsonValue = JsonValue;

	ProcessEvent(p_JsonSetField, &parms);
	return parms.return_value;
}

struct FBlueprintJsonObject UBlueprintFunctionLibrary::JsonRemoveField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName){

	static UObject* p_JsonRemoveField = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonRemoveField");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString FieldName;
		struct FBlueprintJsonObject return_value;
	} parms;

	parms.JsonObject = JsonObject;
	parms.FieldName = FieldName;

	ProcessEvent(p_JsonRemoveField, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::JsonMakeString(struct FString Value){

	static UObject* p_JsonMakeString = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeString");

	struct {
		struct FString Value;
		struct FBlueprintJsonValue return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_JsonMakeString, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::JsonMakeObject(struct FBlueprintJsonObject& Value){

	static UObject* p_JsonMakeObject = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeObject");

	struct {
		struct FBlueprintJsonObject& Value;
		struct FBlueprintJsonValue return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_JsonMakeObject, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::JsonMakeNull(){

	static UObject* p_JsonMakeNull = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeNull");

	struct {
		struct FBlueprintJsonValue return_value;
	} parms;


	ProcessEvent(p_JsonMakeNull, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::JsonMakeInt(int32_t Value){

	static UObject* p_JsonMakeInt = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeInt");

	struct {
		int32_t Value;
		struct FBlueprintJsonValue return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_JsonMakeInt, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::JsonMakeFloat(float Value){

	static UObject* p_JsonMakeFloat = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeFloat");

	struct {
		float Value;
		struct FBlueprintJsonValue return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_JsonMakeFloat, &parms);
	return parms.return_value;
}

struct FBlueprintJsonObject UBlueprintFunctionLibrary::JsonMakeField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName, struct FBlueprintJsonValue& Value){

	static UObject* p_JsonMakeField = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeField");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString FieldName;
		struct FBlueprintJsonValue& Value;
		struct FBlueprintJsonObject return_value;
	} parms;

	parms.JsonObject = JsonObject;
	parms.FieldName = FieldName;
	parms.Value = Value;

	ProcessEvent(p_JsonMakeField, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::JsonMakeBool(bool Value){

	static UObject* p_JsonMakeBool = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeBool");

	struct {
		bool Value;
		struct FBlueprintJsonValue return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_JsonMakeBool, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::JsonMakeArray(struct TArray<struct FBlueprintJsonValue>& Value){

	static UObject* p_JsonMakeArray = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMakeArray");

	struct {
		struct TArray<struct FBlueprintJsonValue>& Value;
		struct FBlueprintJsonValue return_value;
	} parms;

	parms.Value = Value;

	ProcessEvent(p_JsonMakeArray, &parms);
	return parms.return_value;
}

struct FBlueprintJsonObject UBlueprintFunctionLibrary::JsonMake(){

	static UObject* p_JsonMake = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonMake");

	struct {
		struct FBlueprintJsonObject return_value;
	} parms;


	ProcessEvent(p_JsonMake, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::JsonIsNull(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_JsonIsNull = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonIsNull");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		bool return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_JsonIsNull, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::JsonHasTypedField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName, uint8_t  Type){

	static UObject* p_JsonHasTypedField = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonHasTypedField");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString FieldName;
		uint8_t  Type;
		bool return_value;
	} parms;

	parms.JsonObject = JsonObject;
	parms.FieldName = FieldName;
	parms.Type = Type;

	ProcessEvent(p_JsonHasTypedField, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::JsonHasField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName){

	static UObject* p_JsonHasField = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.JsonHasField");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString FieldName;
		bool return_value;
	} parms;

	parms.JsonObject = JsonObject;
	parms.FieldName = FieldName;

	ProcessEvent(p_JsonHasField, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::EquaEqual_JsonValue(struct FBlueprintJsonValue& A, struct FBlueprintJsonValue& B){

	static UObject* p_EquaEqual_JsonValue = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.EquaEqual_JsonValue");

	struct {
		struct FBlueprintJsonValue& A;
		struct FBlueprintJsonValue& B;
		bool return_value;
	} parms;

	parms.A = A;
	parms.B = B;

	ProcessEvent(p_EquaEqual_JsonValue, &parms);
	return parms.return_value;
}

struct FBlueprintJsonObject UBlueprintFunctionLibrary::Conv_StringToJsonObject(struct FString JsonString){

	static UObject* p_Conv_StringToJsonObject = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_StringToJsonObject");

	struct {
		struct FString JsonString;
		struct FBlueprintJsonObject return_value;
	} parms;

	parms.JsonString = JsonString;

	ProcessEvent(p_Conv_StringToJsonObject, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_JsonValueToString(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_Conv_JsonValueToString = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToString");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		struct FString return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_Conv_JsonValueToString, &parms);
	return parms.return_value;
}

struct FBlueprintJsonObject UBlueprintFunctionLibrary::Conv_JsonValueToObject(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_Conv_JsonValueToObject = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToObject");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		struct FBlueprintJsonObject return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_Conv_JsonValueToObject, &parms);
	return parms.return_value;
}

int32_t UBlueprintFunctionLibrary::Conv_JsonValueToInteger(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_Conv_JsonValueToInteger = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToInteger");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		int32_t return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_Conv_JsonValueToInteger, &parms);
	return parms.return_value;
}

float UBlueprintFunctionLibrary::Conv_JsonValueToFloat(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_Conv_JsonValueToFloat = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToFloat");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		float return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_Conv_JsonValueToFloat, &parms);
	return parms.return_value;
}

bool UBlueprintFunctionLibrary::Conv_JsonValueToBool(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_Conv_JsonValueToBool = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToBool");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		bool return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_Conv_JsonValueToBool, &parms);
	return parms.return_value;
}

struct TArray<struct FBlueprintJsonValue> UBlueprintFunctionLibrary::Conv_JsonValueToArray(struct FBlueprintJsonValue& JsonValue){

	static UObject* p_Conv_JsonValueToArray = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToArray");

	struct {
		struct FBlueprintJsonValue& JsonValue;
		struct TArray<struct FBlueprintJsonValue> return_value;
	} parms;

	parms.JsonValue = JsonValue;

	ProcessEvent(p_Conv_JsonValueToArray, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_JsonObjectToString(struct FBlueprintJsonObject& JsonObject){

	static UObject* p_Conv_JsonObjectToString = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToString");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString return_value;
	} parms;

	parms.JsonObject = JsonObject;

	ProcessEvent(p_Conv_JsonObjectToString, &parms);
	return parms.return_value;
}

struct FString UBlueprintFunctionLibrary::Conv_JsonObjectToPrettyString(struct FBlueprintJsonObject& JsonObject){

	static UObject* p_Conv_JsonObjectToPrettyString = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToPrettyString");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString return_value;
	} parms;

	parms.JsonObject = JsonObject;

	ProcessEvent(p_Conv_JsonObjectToPrettyString, &parms);
	return parms.return_value;
}

struct FBlueprintJsonValue UBlueprintFunctionLibrary::Conv_JsonObjectToJsonValue(struct FBlueprintJsonObject& JsonObject, struct FString FieldName){

	static UObject* p_Conv_JsonObjectToJsonValue = UObject::FindObject<UFunction>("Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToJsonValue");

	struct {
		struct FBlueprintJsonObject& JsonObject;
		struct FString FieldName;
		struct FBlueprintJsonValue return_value;
	} parms;

	parms.JsonObject = JsonObject;
	parms.FieldName = FieldName;

	ProcessEvent(p_Conv_JsonObjectToJsonValue, &parms);
	return parms.return_value;
}

