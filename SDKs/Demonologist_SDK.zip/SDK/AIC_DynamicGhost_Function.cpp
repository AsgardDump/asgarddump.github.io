#include "SDK.h" 
 
 
void AAIController::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function AIC_DynamicGhost.AIC_DynamicGhost_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void AAIController::ExecuteUbergraph_AIC_DynamicGhost(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_AIC_DynamicGhost = UObject::FindObject<UFunction>("Function AIC_DynamicGhost.AIC_DynamicGhost_C.ExecuteUbergraph_AIC_DynamicGhost");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_AIC_DynamicGhost, &parms);
}

