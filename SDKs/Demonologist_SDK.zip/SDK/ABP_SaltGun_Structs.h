#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ABP_SaltGun.ABP_SaltGun_C.AnimBlueprintGeneratedConstantData
// Size: 0x1C0(Inherited: 0x1C0) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
