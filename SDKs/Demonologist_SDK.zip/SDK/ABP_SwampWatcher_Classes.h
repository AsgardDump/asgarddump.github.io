#pragma once 
#include <ABP_SwampWatcher_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SwampWatcher.ABP_SwampWatcher_C
// Size: 0x6EC(Inherited: 0x6EC) 
struct UABP_SwampWatcher_C : public UABP_BaseEntity_C
{

}; 



