#pragma once 
#include "SDK.h" 
 
 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.BndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FBndEvt__BP_BasePlayerCharacter_BP_SprintComponent_K2Node_ComponentBoundEvent_0_OnSprintingStatusUpdated__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool IsSprinting : 1;  // 0x0(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_PushToTalk_K2Node_InputActionEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PushToTalk_K2Node_InputActionEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CalculateIKHand
// Size: 0x460(Inherited: 0x0) 
struct FCalculateIKHand
{
	double DeltaSec;  // 0x0(0x8)
	struct USceneComponent* ToolRoot;  // 0x8(0x8)
	struct UABP_Base_Arms_C* ArmAnimBP;  // 0x10(0x8)
	double Diff;  // 0x18(0x8)
	double TargetIKValue;  // 0x20(0x8)
	struct FHitResult HitResultLocal;  // 0x28(0xE8)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x110(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue_2;  // 0x128(0x18)
	struct USceneComponent* CallFunc_GetChildComponent_ReturnValue;  // 0x140(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x148(0x8)
	struct UABP_Base_Arms_C* K2Node_DynamicCast_AsABP_Base_Arms;  // 0x150(0x8)
	char pad_344_1 : 7;  // 0x158(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x159(0x1)
	char pad_346_1 : 7;  // 0x15A(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x15A(0x1)
	char pad_347[5];  // 0x15B(0x5)
	struct AActor* CallFunc_GetOwner_ReturnValue;  // 0x160(0x8)
	struct ABP_Tool_C* K2Node_DynamicCast_AsBP_Tool;  // 0x168(0x8)
	char pad_368_1 : 7;  // 0x170(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x170(0x1)
	char pad_369[7];  // 0x171(0x7)
	double CallFunc_FInterpTo_ReturnValue;  // 0x178(0x8)
	struct TArray<struct AActor*> Temp_object_Variable;  // 0x180(0x10)
	double CallFunc_MakeLiteralDouble_ReturnValue;  // 0x190(0x8)
	double CallFunc_Add_DoubleDouble_ReturnValue;  // 0x198(0x8)
	struct FVector CallFunc_Conv_DoubleToVector_ReturnValue;  // 0x1A0(0x18)
	double CallFunc_FClamp_ReturnValue;  // 0x1B8(0x8)
	struct FVector CallFunc_GetRightVector_ReturnValue;  // 0x1C0(0x18)
	struct FVector CallFunc_NegateVector_ReturnValue;  // 0x1D8(0x18)
	char pad_496_1 : 7;  // 0x1F0(0x1)
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // 0x1F0(0x1)
	char pad_497_1 : 7;  // 0x1F1(0x1)
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // 0x1F1(0x1)
	char pad_498[2];  // 0x1F2(0x2)
	float CallFunc_BreakHitResult_Time;  // 0x1F4(0x4)
	float CallFunc_BreakHitResult_Distance;  // 0x1F8(0x4)
	char pad_508[4];  // 0x1FC(0x4)
	struct FVector CallFunc_BreakHitResult_Location;  // 0x200(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // 0x218(0x18)
	struct FVector CallFunc_BreakHitResult_Normal;  // 0x230(0x18)
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // 0x248(0x18)
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // 0x260(0x8)
	struct AActor* CallFunc_BreakHitResult_HitActor;  // 0x268(0x8)
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // 0x270(0x8)
	struct FName CallFunc_BreakHitResult_HitBoneName;  // 0x278(0x8)
	struct FName CallFunc_BreakHitResult_BoneName;  // 0x280(0x8)
	int32_t CallFunc_BreakHitResult_HitItem;  // 0x288(0x4)
	int32_t CallFunc_BreakHitResult_ElementIndex;  // 0x28C(0x4)
	int32_t CallFunc_BreakHitResult_FaceIndex;  // 0x290(0x4)
	char pad_660[4];  // 0x294(0x4)
	struct FVector CallFunc_BreakHitResult_TraceStart;  // 0x298(0x18)
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // 0x2B0(0x18)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue;  // 0x2C8(0x18)
	double CallFunc_Subtract_DoubleDouble_ReturnValue;  // 0x2E0(0x8)
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // 0x2E8(0x18)
	double CallFunc_Abs_ReturnValue;  // 0x300(0x8)
	char pad_776_1 : 7;  // 0x308(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x308(0x1)
	char pad_777[7];  // 0x309(0x7)
	double CallFunc_MakeLiteralDouble_ReturnValue_2;  // 0x310(0x8)
	struct FVector CallFunc_Conv_DoubleToVector_ReturnValue_2;  // 0x318(0x18)
	char pad_816_1 : 7;  // 0x330(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x330(0x1)
	char pad_817[7];  // 0x331(0x7)
	struct FVector CallFunc_Multiply_VectorVector_ReturnValue_2;  // 0x338(0x18)
	struct FVector CallFunc_Add_VectorVector_ReturnValue_2;  // 0x350(0x18)
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // 0x368(0xE8)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // 0x450(0x1)
	char pad_1105[7];  // 0x451(0x7)
	double CallFunc_Subtract_DoubleDouble_B_ImplicitCast;  // 0x458(0x8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchOnServer
// Size: 0x1(Inherited: 0x0) 
struct FCrouchOnServer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCrouch : 1;  // 0x0(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.CrouchEvent
// Size: 0x1(Inherited: 0x0) 
struct FCrouchEvent
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCrouching : 1;  // 0x0(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetInputActive
// Size: 0x10(Inherited: 0x0) 
struct FSetInputActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.DestoryCustomizationComponent
// Size: 0x8(Inherited: 0x0) 
struct FDestoryCustomizationComponent
{
	struct USkeletalMeshComponent* SkeletalMeshComponentReference;  // 0x0(0x8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetTpsCastShadowVisibility
// Size: 0x1(Inherited: 0x0) 
struct FSetTpsCastShadowVisibility
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NewCastShadow : 1;  // 0x0(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftMouseButton_K2Node_InputKeyEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ExecuteUbergraph_BP_BasePlayerCharacter
// Size: 0x6AC(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BasePlayerCharacter
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Temp_bool_Variable : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x8(0x10)
	struct UTMWGlobalEventHandler* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x18(0x8)
	struct UShiversVivoxSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_2;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool CallFunc_IsLoggedIn_ReturnValue : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool CallFunc_IsJoinedChannel_ReturnValue : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x2A(0x1)
	char pad_43[1];  // 0x2B(0x1)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x40(0x8)
	struct UShiversVivoxSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_3;  // 0x48(0x8)
	struct FKey K2Node_InputActionEvent_Key_5;  // 0x50(0x18)
	float K2Node_Event_DeltaSeconds;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FKey K2Node_InputActionEvent_Key_6;  // 0x70(0x18)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue;  // 0x88(0x8)
	struct TScriptInterface<IBPI_ThirdPersonCharacterAnimInstance_C> K2Node_DynamicCast_AsBPI_Third_Person_Character_Anim_Instance;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FKey K2Node_InputKeyEvent_Key;  // 0xA8(0x18)
	struct FString CallFunc_GetPlayerName_ReturnValue;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool K2Node_ComponentBoundEvent_IsSprinting : 1;  // 0xD1(0x1)
	char pad_210[2];  // 0xD2(0x2)
	float K2Node_CustomEvent_Max_Walk_Speed_2;  // 0xD4(0x4)
	struct FString K2Node_CustomEvent_Message;  // 0xD8(0x10)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_2;  // 0xE8(0x8)
	struct UAnimInstance* CallFunc_GetAnimInstance_ReturnValue_3;  // 0xF0(0x8)
	struct TScriptInterface<IBPI_BaseArms_C> K2Node_DynamicCast_AsBPI_Base_Arms;  // 0xF8(0x10)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x108(0x1)
	char pad_265[7];  // 0x109(0x7)
	struct TScriptInterface<IBPI_BaseArms_C> K2Node_DynamicCast_AsBPI_Base_Arms_2;  // 0x110(0x10)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	struct FFCharacterLocalData K2Node_CustomEvent_CharacterLocalData;  // 0x124(0x4)
	struct UAudioComponent* CallFunc_SpawnSound2D_ReturnValue;  // 0x128(0x8)
	char pad_304_1 : 7;  // 0x130(0x1)
	bool CallFunc_ExitFocusedTV_Success : 1;  // 0x130(0x1)
	char pad_305[3];  // 0x131(0x3)
	float K2Node_CustomEvent_Max_Walk_Speed;  // 0x134(0x4)
	char pad_312_1 : 7;  // 0x138(0x1)
	bool Temp_bool_Variable_2 : 1;  // 0x138(0x1)
	char pad_313[7];  // 0x139(0x7)
	struct UWBP_EscapeMenu_C* CallFunc_GetEscapeMenu_EscapeMenu;  // 0x140(0x8)
	struct FKey Temp_struct_Variable;  // 0x148(0x18)
	char pad_352_1 : 7;  // 0x160(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x160(0x1)
	char pad_353[7];  // 0x161(0x7)
	struct FKey K2Node_InputKeyEvent_Key_2;  // 0x168(0x18)
	char pad_384_1 : 7;  // 0x180(0x1)
	bool CallFunc_GetIsEditor_ReturnValue : 1;  // 0x180(0x1)
	char pad_385[7];  // 0x181(0x7)
	struct UWBP_DevConsole_C* CallFunc_GetDevConsole_DevConsole;  // 0x188(0x8)
	struct FS_ShiversCharacterCustomizationRep K2Node_CustomEvent_New_CC_Rep_Data;  // 0x190(0xA8)
	char pad_568_1 : 7;  // 0x238(0x1)
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // 0x238(0x1)
	char pad_569_1 : 7;  // 0x239(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x239(0x1)
	char pad_570[6];  // 0x23A(0x6)
	struct UWBP_EscapeMenu_C* CallFunc_GetEscapeMenu_EscapeMenu_2;  // 0x240(0x8)
	char pad_584_1 : 7;  // 0x248(0x1)
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // 0x248(0x1)
	char pad_585[7];  // 0x249(0x7)
	struct UWBP_DevConsole_C* CallFunc_GetDevConsole_DevConsole_2;  // 0x250(0x8)
	char pad_600_1 : 7;  // 0x258(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x258(0x1)
	char pad_601_1 : 7;  // 0x259(0x1)
	bool K2Node_SwitchEnum_CmpSuccess_2 : 1;  // 0x259(0x1)
	char pad_602[6];  // 0x25A(0x6)
	struct UWBP_VoicePromptLine_C* CallFunc_Create_ReturnValue;  // 0x260(0x8)
	struct FKey K2Node_InputActionEvent_Key;  // 0x268(0x18)
	struct USkeletalMeshComponent* K2Node_Event_SkeletalMeshComponentReference;  // 0x280(0x8)
	struct FKey K2Node_InputKeyEvent_Key_3;  // 0x288(0x18)
	char pad_672_1 : 7;  // 0x2A0(0x1)
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // 0x2A0(0x1)
	char pad_673_1 : 7;  // 0x2A1(0x1)
	bool K2Node_CustomEvent_bCrouch : 1;  // 0x2A1(0x1)
	char pad_674_1 : 7;  // 0x2A2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2A2(0x1)
	char pad_675[5];  // 0x2A3(0x5)
	struct ABP_ChatManager_C* CallFunc_GetChatManager_ChatManager;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool K2Node_CustomEvent_bCrouching : 1;  // 0x2B0(0x1)
	char pad_689[7];  // 0x2B1(0x7)
	struct FKey Temp_struct_Variable_2;  // 0x2B8(0x18)
	struct FKey K2Node_InputActionEvent_Key_7;  // 0x2D0(0x18)
	struct TScriptInterface<IBPI_GamePlayerState_C> K2Node_DynamicCast_AsBPI_Game_Player_State;  // 0x2E8(0x10)
	char pad_760_1 : 7;  // 0x2F8(0x1)
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // 0x2F8(0x1)
	char pad_761_1 : 7;  // 0x2F9(0x1)
	bool CallFunc_IsFocusedOnAnySmartTV_Result : 1;  // 0x2F9(0x1)
	char pad_762_1 : 7;  // 0x2FA(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue : 1;  // 0x2FA(0x1)
	char pad_763_1 : 7;  // 0x2FB(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x2FB(0x1)
	char pad_764_1 : 7;  // 0x2FC(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_3 : 1;  // 0x2FC(0x1)
	char ENetRole CallFunc_GetLocalRole_ReturnValue;  // 0x2FD(0x1)
	char pad_766_1 : 7;  // 0x2FE(0x1)
	bool CallFunc_BooleanAND_ReturnValue_3 : 1;  // 0x2FE(0x1)
	char pad_767_1 : 7;  // 0x2FF(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0x2FF(0x1)
	char pad_768_1 : 7;  // 0x300(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct FKey K2Node_InputActionEvent_Key_2;  // 0x308(0x18)
	struct FVector CallFunc_MakeVector_ReturnValue;  // 0x320(0x18)
	float CallFunc_GetInputAxisValue_ReturnValue;  // 0x338(0x4)
	char pad_828[4];  // 0x33C(0x4)
	struct FHitResult CallFunc_K2_SetRelativeLocation_SweepHitResult;  // 0x340(0xE8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0x428(0x8)
	float CallFunc_GetInputAxisValue_ReturnValue_2;  // 0x430(0x4)
	char pad_1076[4];  // 0x434(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0x438(0x8)
	struct FVector K2Node_CustomEvent_MovementInput;  // 0x440(0x18)
	char pad_1112_1 : 7;  // 0x458(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_2 : 1;  // 0x458(0x1)
	char pad_1113[3];  // 0x459(0x3)
	float CallFunc_GetInputAxisValue_ReturnValue_3;  // 0x45C(0x4)
	float CallFunc_GetInputAxisValue_ReturnValue_4;  // 0x460(0x4)
	char pad_1124[4];  // 0x464(0x4)
	double CallFunc_DetermineGreaterAbs_Smaller;  // 0x468(0x8)
	double CallFunc_DetermineGreaterAbs_Greater;  // 0x470(0x8)
	double CallFunc_DetermineGreaterAbs_Smaller_2;  // 0x478(0x8)
	double CallFunc_DetermineGreaterAbs_Greater_2;  // 0x480(0x8)
	struct UShiversVivoxSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue_4;  // 0x488(0x8)
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // 0x490(0x18)
	char pad_1192_1 : 7;  // 0x4A8(0x1)
	bool CallFunc_IsMuted_ReturnValue : 1;  // 0x4A8(0x1)
	char pad_1193_1 : 7;  // 0x4A9(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_4 : 1;  // 0x4A9(0x1)
	char pad_1194[6];  // 0x4AA(0x6)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x4B0(0x18)
	struct FKey K2Node_InputActionEvent_Key_8;  // 0x4C8(0x18)
	struct TScriptInterface<IBPI_GamePlayerState_C> K2Node_DynamicCast_AsBPI_Game_Player_State_2;  // 0x4E0(0x10)
	char pad_1264_1 : 7;  // 0x4F0(0x1)
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // 0x4F0(0x1)
	char pad_1265_1 : 7;  // 0x4F1(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_3 : 1;  // 0x4F1(0x1)
	char pad_1266_1 : 7;  // 0x4F2(0x1)
	bool CallFunc_GetIsPlayerDead_ReturnValue_2 : 1;  // 0x4F2(0x1)
	char pad_1267_1 : 7;  // 0x4F3(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_5 : 1;  // 0x4F3(0x1)
	char pad_1268_1 : 7;  // 0x4F4(0x1)
	bool K2Node_Select_Default : 1;  // 0x4F4(0x1)
	char pad_1269[3];  // 0x4F5(0x3)
	struct UObject* K2Node_CustomEvent_Publisher;  // 0x4F8(0x8)
	struct UObject* K2Node_CustomEvent_Payload;  // 0x500(0x8)
	struct TArray<struct FString> K2Node_CustomEvent_Metadata;  // 0x508(0x10)
	struct FKey Temp_struct_Variable_3;  // 0x518(0x18)
	struct FKey K2Node_InputActionEvent_Key_3;  // 0x530(0x18)
	char pad_1352_1 : 7;  // 0x548(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_4 : 1;  // 0x548(0x1)
	char pad_1353[7];  // 0x549(0x7)
	struct FKey K2Node_InputActionEvent_Key_4;  // 0x550(0x18)
	struct FVector CallFunc_GetUpVector_ReturnValue;  // 0x568(0x18)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x580(0x18)
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // 0x598(0x18)
	char pad_1456_1 : 7;  // 0x5B0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_5 : 1;  // 0x5B0(0x1)
	char pad_1457[7];  // 0x5B1(0x7)
	struct UBP_OptionsSaveGame_C* CallFunc_GetOptionsSaveGame_OptionsSaveGame;  // 0x5B8(0x8)
	struct FString CallFunc_GetOptionsSaveGame_SlotName;  // 0x5C0(0x10)
	char pad_1488_1 : 7;  // 0x5D0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_6 : 1;  // 0x5D0(0x1)
	char E_VoiceInputMode CallFunc_GetInputMode_InputMode;  // 0x5D1(0x1)
	char pad_1490[6];  // 0x5D2(0x6)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x5D8(0x8)
	struct UBP_OptionsSaveGame_C* CallFunc_GetOptionsSaveGame_OptionsSaveGame_2;  // 0x5E0(0x8)
	struct FString CallFunc_GetOptionsSaveGame_SlotName_2;  // 0x5E8(0x10)
	double CallFunc_GetFov_ReturnValue;  // 0x5F8(0x8)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x600(0x4)
	char pad_1540[4];  // 0x604(0x4)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x608(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x618(0x10)
	char pad_1576_1 : 7;  // 0x628(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue_7 : 1;  // 0x628(0x1)
	char pad_1577_1 : 7;  // 0x629(0x1)
	bool CallFunc_IsPlayerControlled_ReturnValue : 1;  // 0x629(0x1)
	char pad_1578[6];  // 0x62A(0x6)
	struct UWBP_DevConsole_C* CallFunc_Create_ReturnValue_2;  // 0x630(0x8)
	struct UWBP_EscapeMenu_C* CallFunc_Create_ReturnValue_3;  // 0x638(0x8)
	struct UBP_OptionsSaveGame_C* CallFunc_GetOptionsSaveGame_OptionsSaveGame_3;  // 0x640(0x8)
	struct FString CallFunc_GetOptionsSaveGame_SlotName_3;  // 0x648(0x10)
	double CallFunc_GetColorVisionDeficiencySeverity_ColorVisionDeficiencySeverity;  // 0x658(0x8)
	uint8_t  CallFunc_GetColorVisionDeficiencyType_ColorVisionDeficiencyType;  // 0x660(0x1)
	char pad_1633[7];  // 0x661(0x7)
	double CallFunc_CalculateIKHand_DeltaSec_ImplicitCast;  // 0x668(0x8)
	double K2Node_VariableSet_CurrentCharacterSpeed_ImplicitCast;  // 0x670(0x8)
	double K2Node_VariableSet_CurrentCharacterSpeed_ImplicitCast_2;  // 0x678(0x8)
	double CallFunc_MakeVector_Z_ImplicitCast;  // 0x680(0x8)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast;  // 0x688(0x8)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast_2;  // 0x690(0x8)
	double CallFunc_DetermineGreaterAbs_A_ImplicitCast;  // 0x698(0x8)
	double CallFunc_DetermineGreaterAbs_A_ImplicitCast_2;  // 0x6A0(0x8)
	float CallFunc_SetColorVisionDeficiencyType_Severity_ImplicitCast;  // 0x6A8(0x4)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetIsVoiceMuted
// Size: 0x1(Inherited: 0x0) 
struct FGetIsVoiceMuted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsVivoxMuted : 1;  // 0x0(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetSkeletalMesh
// Size: 0x8(Inherited: 0x0) 
struct FGetSkeletalMesh
{
	struct USkeletalMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterMovementSpeed
// Size: 0x4(Inherited: 0x0) 
struct FUpdateCharacterMovementSpeed
{
	float Max Walk Speed;  // 0x0(0x4)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.GetTpsMesh
// Size: 0x8(Inherited: 0x0) 
struct FGetTpsMesh
{
	struct USkeletalMeshComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_CommandConsole_K2Node_InputActionEvent_6
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_CommandConsole_K2Node_InputActionEvent_6
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Crouching_K2Node_InputActionEvent_2
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Crouching_K2Node_InputActionEvent_2
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_EscapeMenu_K2Node_InputActionEvent_5
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_EscapeMenu_K2Node_InputActionEvent_5
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetMovementActive
// Size: 0x5(Inherited: 0x0) 
struct FSetMovementActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsActive : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool Temp_bool_Variable : 1;  // 0x1(0x1)
	char EMovementMode Temp_byte_Variable;  // 0x2(0x1)
	char EMovementMode Temp_byte_Variable_2;  // 0x3(0x1)
	char EMovementMode K2Node_Select_Default;  // 0x4(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReceiveTick
// Size: 0x4(Inherited: 0x4) 
struct FReceiveTick : public FReceiveTick
{
	float DeltaSeconds;  // 0x0(0x4)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_LeftMouseButton_K2Node_InputKeyEvent_3
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.Set Character Customization Data On Server
// Size: 0xA8(Inherited: 0x0) 
struct FSet Character Customization Data On Server
{
	struct FS_ShiversCharacterCustomizationRep New CC Rep Data;  // 0x0(0xA8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_PushToTalk_K2Node_InputActionEvent_4
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_PushToTalk_K2Node_InputActionEvent_4
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_SpaceBar_K2Node_InputKeyEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_SpaceBar_K2Node_InputKeyEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Sprint_K2Node_InputActionEvent_7
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Sprint_K2Node_InputActionEvent_7
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_Sprint_K2Node_InputActionEvent_8
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_Sprint_K2Node_InputActionEvent_8
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.ReplicateCustomizationData
// Size: 0x308(Inherited: 0x0) 
struct FReplicateCustomizationData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UBP_PlayerAssets_C* CallFunc_GetPlayerAssetSaveGame_ReturnValue;  // 0x8(0x8)
	struct FString CallFunc_GetPlayerAssetSaveGame_SlotName;  // 0x10(0x10)
	struct FS_ShiversCharacterCustomizationInformation CallFunc_Map_Find_Value;  // 0x20(0x198)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool CallFunc_Map_Find_ReturnValue : 1;  // 0x1B8(0x1)
	char pad_441[7];  // 0x1B9(0x7)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys;  // 0x1C0(0x10)
	struct TArray<struct FLinearColor> CallFunc_Map_Values_Values;  // 0x1D0(0x10)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys_2;  // 0x1E0(0x10)
	struct TArray<struct FName> CallFunc_Map_Values_Values_2;  // 0x1F0(0x10)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys_3;  // 0x200(0x10)
	struct TArray<double> CallFunc_Map_Values_Values_3;  // 0x210(0x10)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys_4;  // 0x220(0x10)
	struct TArray<struct UTexture2D*> CallFunc_Map_Values_Values_4;  // 0x230(0x10)
	struct TArray<struct FName> CallFunc_Map_Keys_Keys_5;  // 0x240(0x10)
	struct TArray<double> CallFunc_Map_Values_Values_5;  // 0x250(0x10)
	struct FS_ShiversCharacterCustomizationRep K2Node_MakeStruct_S_ShiversCharacterCustomizationRep;  // 0x260(0xA8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.InpActEvt_VoicePromptLine_K2Node_InputActionEvent_1
// Size: 0x18(Inherited: 0x0) 
struct FInpActEvt_VoicePromptLine_K2Node_InputActionEvent_1
{
	struct FKey Key;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.IsFocusedOnAnySmartTV
// Size: 0x31(Inherited: 0x0) 
struct FIsFocusedOnAnySmartTV
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Result : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct TArray<struct ABP_SmartTV_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct ABP_SmartTV_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetCharacterLocalData OnServer
// Size: 0x4(Inherited: 0x0) 
struct FSetCharacterLocalData OnServer
{
	struct FFCharacterLocalData CharacterLocalData;  // 0x0(0x4)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnLevelUpdated
// Size: 0x20(Inherited: 0x0) 
struct FOnLevelUpdated
{
	struct UObject* Publisher;  // 0x0(0x8)
	struct UObject* Payload;  // 0x8(0x8)
	struct TArray<struct FString> MetaData;  // 0x10(0x10)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.OnRep_CurrentCharacterSpeed
// Size: 0x8(Inherited: 0x0) 
struct FOnRep_CurrentCharacterSpeed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float K2Node_VariableSet_MaxWalkSpeed_ImplicitCast;  // 0x4(0x4)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SendMessage On Server
// Size: 0x10(Inherited: 0x0) 
struct FSendMessage On Server
{
	struct FString Message;  // 0x0(0x10)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetIsVoiceMuted
// Size: 0x10(Inherited: 0x0) 
struct FSetIsVoiceMuted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bMuted : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UShiversVivoxSubsystem* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetMovementInputServer
// Size: 0x18(Inherited: 0x0) 
struct FSetMovementInputServer
{
	struct FVector MovementInput;  // 0x0(0x18)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterCustomization
// Size: 0x247(Inherited: 0x0) 
struct FUpdateCharacterCustomization
{
	struct FS_ShiversCharacterCustomizationInformation LocalInformationData;  // 0x0(0x198)
	int32_t Temp_int_Array_Index_Variable;  // 0x198(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x19C(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x1A0(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0x1A4(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x1A8(0x4)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x1AC(0x4)
	int32_t Temp_int_Loop_Counter_Variable_3;  // 0x1B0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // 0x1B4(0x4)
	int32_t Temp_int_Array_Index_Variable_3;  // 0x1B8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_4;  // 0x1BC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // 0x1C0(0x4)
	int32_t Temp_int_Array_Index_Variable_4;  // 0x1C4(0x4)
	int32_t Temp_int_Array_Index_Variable_5;  // 0x1C8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_5;  // 0x1CC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_5;  // 0x1D0(0x4)
	struct FName CallFunc_Array_Get_Item;  // 0x1D4(0x8)
	char pad_476[4];  // 0x1DC(0x4)
	double CallFunc_Array_Get_Item_2;  // 0x1E0(0x8)
	struct FName CallFunc_Array_Get_Item_3;  // 0x1E8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x1F0(0x4)
	char pad_500_1 : 7;  // 0x1F4(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x1F4(0x1)
	char pad_501[3];  // 0x1F5(0x3)
	struct FName CallFunc_Array_Get_Item_4;  // 0x1F8(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x200(0x4)
	char pad_516_1 : 7;  // 0x204(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x204(0x1)
	char pad_517[3];  // 0x205(0x3)
	struct UTexture2D* CallFunc_Array_Get_Item_5;  // 0x208(0x8)
	struct FName CallFunc_Array_Get_Item_6;  // 0x210(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_3;  // 0x218(0x4)
	char pad_540_1 : 7;  // 0x21C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // 0x21C(0x1)
	char pad_541[3];  // 0x21D(0x3)
	struct FName CallFunc_Array_Get_Item_7;  // 0x220(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_4;  // 0x228(0x4)
	char pad_556_1 : 7;  // 0x22C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // 0x22C(0x1)
	char pad_557[3];  // 0x22D(0x3)
	double CallFunc_Array_Get_Item_8;  // 0x230(0x8)
	struct FName CallFunc_Array_Get_Item_9;  // 0x238(0x8)
	int32_t CallFunc_Array_Length_ReturnValue_5;  // 0x240(0x4)
	char pad_580_1 : 7;  // 0x244(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_5 : 1;  // 0x244(0x1)
	char pad_581_1 : 7;  // 0x245(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x245(0x1)
	char pad_582_1 : 7;  // 0x246(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x246(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetVoiceMode
// Size: 0x2(Inherited: 0x0) 
struct FSetVoiceMode
{
	char E_VoiceInputMode VoiceInputMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // 0x1(0x1)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.SetWidgetInteractionActive
// Size: 0x14(Inherited: 0x0) 
struct FSetWidgetInteractionActive
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewActive : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double CallFunc_SelectFloat_ReturnValue;  // 0x8(0x8)
	float K2Node_VariableSet_InteractionDistance_ImplicitCast;  // 0x10(0x4)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UpdateCharacterMovementSpeedServer
// Size: 0x4(Inherited: 0x0) 
struct FUpdateCharacterMovementSpeedServer
{
	float Max Walk Speed;  // 0x0(0x4)

}; 
// Function BP_BasePlayerCharacter.BP_BasePlayerCharacter_C.UploadCharacterLocalDataToServer
// Size: 0x25(Inherited: 0x0) 
struct FUploadCharacterLocalDataToServer
{
	struct UBP_PlayerAssets_C* PlayerSave;  // 0x0(0x8)
	struct UBP_PlayerAssets_C* CallFunc_GetPlayerAssetSaveGame_ReturnValue;  // 0x8(0x8)
	struct FString CallFunc_GetPlayerAssetSaveGame_SlotName;  // 0x10(0x10)
	int32_t CallFunc_FTrunc_ReturnValue;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsLocallyControlled_ReturnValue : 1;  // 0x24(0x1)

}; 
