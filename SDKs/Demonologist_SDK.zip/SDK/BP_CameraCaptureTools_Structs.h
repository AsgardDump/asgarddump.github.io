#pragma once 
#include "SDK.h" 
 
 
// Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.CanDisableCaptureWhenOutsideOfRenderArea
// Size: 0x3(Inherited: 0x0) 
struct FCanDisableCaptureWhenOutsideOfRenderArea
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool CallFunc_IsLocalInstigator_ReturnValue : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x2(0x1)

}; 
// Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.ExecuteUbergraph_BP_CameraCaptureTools
// Size: 0x71(Inherited: 0x0) 
struct FExecuteUbergraph_BP_CameraCaptureTools
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APawn* CallFunc_GetObjectInstigator_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsOverlappingControlArea_ReturnValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)
	struct ABP_ControlCamera_C* CallFunc_GetControlCameraReference_ReturnValue;  // 0x18(0x8)
	struct ABP_ControlCamera_C* CallFunc_GetControlCameraReference_ReturnValue_2;  // 0x20(0x8)
	struct ABP_ControlCamera_C* CallFunc_GetControlCameraReference_ReturnValue_3;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct APawn* K2Node_Event_OldInstigator;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool K2Node_Event_IsFirstInit : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool CallFunc_IsLocalInstigator_ReturnValue : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x48(0x8)
	struct ABP_ControlCamera_C* CallFunc_GetControlCameraReference_ReturnValue_4;  // 0x50(0x8)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_IsCurrentlyWatching_ReturnValue : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue_2;  // 0x60(0x8)
	struct ABP_ControlCamera_C* CallFunc_GetControlCameraReference_ReturnValue_5;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool CallFunc_IsOverlappingActor_ReturnValue : 1;  // 0x70(0x1)

}; 
// Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.IsOverlappingControlArea
// Size: 0x19(Inherited: 0x0) 
struct FIsOverlappingControlArea
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct AActor*> CallFunc_GetOverlappingActors_OverlappingActors;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Array_IsValidIndex_ReturnValue : 1;  // 0x18(0x1)

}; 
// Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.IsCurrentlyWatching
// Size: 0x11(Inherited: 0x0) 
struct FIsCurrentlyWatching
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct ABP_ControlCamera_C* CallFunc_GetControlCameraReference_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.GetControlCameraReference
// Size: 0x11(Inherited: 0x0) 
struct FGetControlCameraReference
{
	struct ABP_ControlCamera_C* ReturnValue;  // 0x0(0x8)
	struct ABP_ControlCamera_C* CallFunc_GetActorOfClass_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.OnObjectInstigatorUpdatedCallback
// Size: 0x9(Inherited: 0x9) 
struct FOnObjectInstigatorUpdatedCallback : public FOnObjectInstigatorUpdatedCallback
{
	struct APawn* OldInstigator;  // 0x0(0x8)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool IsFirstInit : 1;  // 0x8(0x1)

}; 
// Function BP_CameraCaptureTools.BP_CameraCaptureTools_C.InitializeCameraCaptureTool
// Size: 0x70(Inherited: 0x0) 
struct FInitializeCameraCaptureTool
{
	int32_t Temp_int_Loop_Counter_Variable;  // 0x0(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x4(0x4)
	int32_t Temp_int_Array_Index_Variable;  // 0x8(0x4)
	int32_t Temp_int_Loop_Counter_Variable_2;  // 0xC(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct TArray<struct ABP_SpectatorCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x18(0x10)
	struct AActor* CallFunc_Array_Get_Item;  // 0x28(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x30(0x4)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct TArray<struct UBP_ShiversCustomizationMesh_C*> CallFunc_K2_GetComponentsByClass_ReturnValue;  // 0x38(0x10)
	int32_t CallFunc_Array_Length_ReturnValue_2;  // 0x48(0x4)
	char pad_76_1 : 7;  // 0x4C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // 0x4C(0x1)
	char pad_77[3];  // 0x4D(0x3)
	struct UTextureRenderTarget2D* CallFunc_CreateRenderTarget2D_ReturnValue;  // 0x50(0x8)
	int32_t Temp_int_Array_Index_Variable_2;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct UBP_ShiversCustomizationMesh_C* CallFunc_Array_Get_Item_2;  // 0x60(0x8)
	struct UMaterialInstanceDynamic* CallFunc_CreateDynamicMaterialInstance_ReturnValue;  // 0x68(0x8)

}; 
