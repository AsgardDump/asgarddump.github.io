#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct ABP_ThirdPersonSanityPill.ABP_ThirdPersonSanityPill_C.AnimBlueprintGeneratedConstantData
// Size: 0x150(Inherited: 0x150) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintGeneratedConstantData
{

}; 
