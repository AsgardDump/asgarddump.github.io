#pragma once 
#include <BlueprintJson_Structs.h>
 
 
 
// Class BlueprintJson.BlueprintJsonLibrary
// Size: 0x28(Inherited: 0x28) 
struct UBlueprintJsonLibrary : public UBlueprintFunctionLibrary
{

	bool NotEqual_JsonValue(struct FBlueprintJsonValue& A, struct FBlueprintJsonValue& B); // Function BlueprintJson.BlueprintJsonLibrary.NotEqual_JsonValue
	uint8_t  JsonType(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.JsonType
	struct FBlueprintJsonObject JsonSetField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName, struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.JsonSetField
	struct FBlueprintJsonObject JsonRemoveField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName); // Function BlueprintJson.BlueprintJsonLibrary.JsonRemoveField
	struct FBlueprintJsonValue JsonMakeString(struct FString Value); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeString
	struct FBlueprintJsonValue JsonMakeObject(struct FBlueprintJsonObject& Value); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeObject
	struct FBlueprintJsonValue JsonMakeNull(); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeNull
	struct FBlueprintJsonValue JsonMakeInt(int32_t Value); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeInt
	struct FBlueprintJsonValue JsonMakeFloat(float Value); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeFloat
	struct FBlueprintJsonObject JsonMakeField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName, struct FBlueprintJsonValue& Value); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeField
	struct FBlueprintJsonValue JsonMakeBool(bool Value); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeBool
	struct FBlueprintJsonValue JsonMakeArray(struct TArray<struct FBlueprintJsonValue>& Value); // Function BlueprintJson.BlueprintJsonLibrary.JsonMakeArray
	struct FBlueprintJsonObject JsonMake(); // Function BlueprintJson.BlueprintJsonLibrary.JsonMake
	bool JsonIsNull(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.JsonIsNull
	bool JsonHasTypedField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName, uint8_t  Type); // Function BlueprintJson.BlueprintJsonLibrary.JsonHasTypedField
	bool JsonHasField(struct FBlueprintJsonObject& JsonObject, struct FString FieldName); // Function BlueprintJson.BlueprintJsonLibrary.JsonHasField
	bool EquaEqual_JsonValue(struct FBlueprintJsonValue& A, struct FBlueprintJsonValue& B); // Function BlueprintJson.BlueprintJsonLibrary.EquaEqual_JsonValue
	struct FBlueprintJsonObject Conv_StringToJsonObject(struct FString JsonString); // Function BlueprintJson.BlueprintJsonLibrary.Conv_StringToJsonObject
	struct FString Conv_JsonValueToString(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToString
	struct FBlueprintJsonObject Conv_JsonValueToObject(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToObject
	int32_t Conv_JsonValueToInteger(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToInteger
	float Conv_JsonValueToFloat(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToFloat
	bool Conv_JsonValueToBool(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToBool
	struct TArray<struct FBlueprintJsonValue> Conv_JsonValueToArray(struct FBlueprintJsonValue& JsonValue); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonValueToArray
	struct FString Conv_JsonObjectToString(struct FBlueprintJsonObject& JsonObject); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToString
	struct FString Conv_JsonObjectToPrettyString(struct FBlueprintJsonObject& JsonObject); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToPrettyString
	struct FBlueprintJsonValue Conv_JsonObjectToJsonValue(struct FBlueprintJsonObject& JsonObject, struct FString FieldName); // Function BlueprintJson.BlueprintJsonLibrary.Conv_JsonObjectToJsonValue
}; 



