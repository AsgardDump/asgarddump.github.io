#pragma once 
#include <BP_BlacksmithHammer_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BlacksmithHammer.BP_BlacksmithHammer_C
// Size: 0x461(Inherited: 0x429) 
struct ABP_BlacksmithHammer_C : public ABP_Tool_C
{
	char pad_1065[7];  // 0x429(0x7)
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x430(0x8)
	struct USceneComponent* HammerScene;  // 0x438(0x8)
	struct FVector HitLocation;  // 0x440(0x18)
	struct AActor* HitActor;  // 0x458(0x8)
	char pad_1120_1 : 7;  // 0x460(0x1)
	bool bAlreadyHit : 1;  // 0x460(0x1)

	void HitWall(struct FVector Location); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HitWall
	void HitUvObject(struct FVector Location); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HitUvObject
	bool CanAttack(); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.CanAttack
	void InpActEvt_ToolInteraction_K2Node_InputActionEvent_1(struct FKey Key); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.InpActEvt_ToolInteraction_K2Node_InputActionEvent_1
	void OnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnNotifyEnd_3B5C42E44BE644E0BBDEB5A08B5C2F3C
	void OnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnNotifyBegin_3B5C42E44BE644E0BBDEB5A08B5C2F3C
	void OnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnInterrupted_3B5C42E44BE644E0BBDEB5A08B5C2F3C
	void OnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnBlendOut_3B5C42E44BE644E0BBDEB5A08B5C2F3C
	void OnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C(struct FName NotifyName); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.OnCompleted_3B5C42E44BE644E0BBDEB5A08B5C2F3C
	void ReceiveBeginPlay(); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.ReceiveBeginPlay
	void BlacksmithHammerAttack On Server(); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.BlacksmithHammerAttack On Server
	void BlacksmithHammerAttack On Multicast(); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.BlacksmithHammerAttack On Multicast
	void HammerHitWall On Multicast(bool bTrueHit, struct FVector Location); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HammerHitWall On Multicast
	void HammerHitOnServer(bool bTrueHit, struct FVector Location, struct ABP_HammerUvObject_C* WallUvObject); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.HammerHitOnServer
	void ExecuteUbergraph_BP_BlacksmithHammer(int32_t EntryPoint); // Function BP_BlacksmithHammer.BP_BlacksmithHammer_C.ExecuteUbergraph_BP_BlacksmithHammer
}; 



