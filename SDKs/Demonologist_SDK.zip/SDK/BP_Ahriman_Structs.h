#pragma once 
#include "SDK.h" 
 
 
// Function BP_Ahriman.BP_Ahriman_C.ExecuteUbergraph_BP_Ahriman
// Size: 0xB0(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Ahriman
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue;  // 0x8(0x8)
	struct TScriptInterface<IBPI_VoiceRecgonition_C> K2Node_DynamicCast_AsBPI_Voice_Recgonition;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x21(0x1)
	char pad_34[6];  // 0x22(0x6)
	struct USrsComponent* CallFunc_GetSrsComponent_ReturnValue;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString K2Node_CustomEvent_result;  // 0x38(0x10)
	struct ACharacter* CallFunc_GetPlayerCharacter_ReturnValue_2;  // 0x48(0x8)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x58(0x8)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct ABP_ShiversController_C* K2Node_DynamicCast_AsBP_Shivers_Controller;  // 0x68(0x8)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x70(0x1)
	char pad_113_1 : 7;  // 0x71(0x1)
	bool CallFunc_RandomBoolWithWeight_ReturnValue : 1;  // 0x71(0x1)
	char pad_114[6];  // 0x72(0x6)
	struct TArray<struct FName> K2Node_MakeArray_Array;  // 0x78(0x10)
	struct FName CallFunc_RecgonizeSpiritBoxCommand_MatchedCommand;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool CallFunc_RecgonizeSpiritBoxCommand_IsSuccessful : 1;  // 0x90(0x1)
	char pad_145[3];  // 0x91(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x94(0x10)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool K2Node_SwitchName_CmpSuccess : 1;  // 0xA4(0x1)
	char pad_165[3];  // 0xA5(0x3)
	double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast;  // 0xA8(0x8)

}; 
// Function BP_Ahriman.BP_Ahriman_C.GetCanPerformGhostAbility
// Size: 0x1(Inherited: 0x1) 
struct FGetCanPerformGhostAbility : public FGetCanPerformGhostAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_Ahriman.BP_Ahriman_C.recognitionResultReceivedOnRecgonitionReceived
// Size: 0x10(Inherited: 0x0) 
struct FrecognitionResultReceivedOnRecgonitionReceived
{
	struct FString Result;  // 0x0(0x10)

}; 
