#pragma once 
#include <AIC_Cat_Pet_Structs.h>
 
 
 
// BlueprintGeneratedClass AIC_Cat_Pet.AIC_Cat_Pet_C
// Size: 0x3C0(Inherited: 0x3B8) 
struct AAIC_Cat_Pet_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3B8(0x8)

	void ReceiveBeginPlay(); // Function AIC_Cat_Pet.AIC_Cat_Pet_C.ReceiveBeginPlay
	void ExecuteUbergraph_AIC_Cat_Pet(int32_t EntryPoint); // Function AIC_Cat_Pet.AIC_Cat_Pet_C.ExecuteUbergraph_AIC_Cat_Pet
}; 



