#pragma once 
#include <ABP_UvLight_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_UvLight.ABP_UvLight_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_UvLight_C : public UABP_ToolLayerArms_C
{

}; 



