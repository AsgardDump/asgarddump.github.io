#pragma once 
#include <BP_BasicInteractionComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BasicInteractionComponent.BP_BasicInteractionComponent_C
// Size: 0x1D0(Inherited: 0x190) 
struct UBP_BasicInteractionComponent_C : public UBP_VisualInteractionComponent_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x190(0x8)
	struct FMulticastInlineDelegate OnInteractionTriggered;  // 0x198(0x10)
	struct UBP_EventBoxComponent_C* EventBoxComponent;  // 0x1A8(0x8)
	struct TArray<struct FVector> DegreePoints;  // 0x1B0(0x10)
	char pad_448_1 : 7;  // 0x1C0(0x1)
	bool IsDegreeConditionEnabled : 1;  // 0x1C0(0x1)
	char pad_449[7];  // 0x1C1(0x7)
	double MinimumDegreeValue;  // 0x1C8(0x8)

	bool IsInteractable(); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.IsInteractable
	bool CanPlayerInteract(struct APawn* PawnReference, struct FName Identifier); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.CanPlayerInteract
	void LookEventSuccessful(struct APawn* Instigator); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.LookEventSuccessful
	double GetDegreeBetweenTwoPoints(struct UObject* CharacterReference, struct FVector Location); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetDegreeBetweenTwoPoints
	struct TArray<struct FVector> GetDegreePoints(); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetDegreePoints
	bool IsDegreeConditionMatch(struct APawn* PawnReference); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.IsDegreeConditionMatch
	struct UBP_EventBoxComponent_C* GetEventboxComponent(); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetEventboxComponent
	void InitializeBasicInteraction(); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.InitializeBasicInteraction
	bool EventBoxInteractionCondition(struct APawn* Instigator, bool BypassAuthorization); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.EventBoxInteractionCondition
	void RequestInteraction(struct APawn* SequenceInstigator); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.RequestInteraction
	bool LookInteractionCondition(struct APawn* PawnReference, bool BypassAuthorization); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.LookInteractionCondition
	void InteractObject(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.InteractObject
	void OnLooked(struct APlayerController* ControllerReference, struct APawn* PawnReference, double TraceInterval, struct FHitResult Details, bool IsLocallyControlled); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnLooked
	void OnInteractionBoxesTriggered(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnInteractionBoxesTriggered
	void ReceiveBeginPlay(); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_BasicInteractionComponent(int32_t EntryPoint); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.ExecuteUbergraph_BP_BasicInteractionComponent
	void OnInteractionTriggered__DelegateSignature(char E_InteractionMethods InteractionMethod, struct APawn* InstigatorReference); // Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnInteractionTriggered__DelegateSignature
}; 



