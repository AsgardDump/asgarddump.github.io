#pragma once 
#include <AvfMediaFactory_Structs.h>
 
 
 
// Class AvfMediaFactory.AvfMediaSettings
// Size: 0x30(Inherited: 0x28) 
struct UAvfMediaSettings : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool NativeAudioOut : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 



