#include "SDK.h" 
 
 
bool UBP_AiCloseInteractionComponent_C::CanInstigatorInteract(struct AActor* Instigator){

	static UObject* p_CanInstigatorInteract = UObject::FindObject<UFunction>("Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.CanInstigatorInteract");

	struct {
		struct AActor* Instigator;
		bool return_value;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_CanInstigatorInteract, &parms);
	return parms.return_value;
}

void UBP_AiCloseInteractionComponent_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void UBP_AiCloseInteractionComponent_C::OnInteractionRequestedCallback(struct AActor* Instigator){

	static UObject* p_OnInteractionRequestedCallback = UObject::FindObject<UFunction>("Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.OnInteractionRequestedCallback");

	struct {
		struct AActor* Instigator;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_OnInteractionRequestedCallback, &parms);
}

void UBP_AiCloseInteractionComponent_C::ExecuteUbergraph_BP_AiEventInteractionComponent(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_AiEventInteractionComponent = UObject::FindObject<UFunction>("Function BP_AiEventInteractionComponent.BP_AiEventInteractionComponent_C.ExecuteUbergraph_BP_AiEventInteractionComponent");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_AiEventInteractionComponent, &parms);
}

