#pragma once 
#include <BP_CameraCaptureComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CameraCaptureComponent.BP_CameraCaptureComponent_C
// Size: 0xB8(Inherited: 0xA0) 
struct UBP_CameraCaptureComponent_C : public UActorComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA0(0x8)
	struct FMulticastInlineDelegate IsCapturing;  // 0xA8(0x10)

	struct USceneCaptureComponent2D* GetSceneCaptureComponentReference(); // Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.GetSceneCaptureComponentReference
	void SetCaptureEveryFrameStatus(bool CaptureEveryFrame); // Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.SetCaptureEveryFrameStatus
	void ReceiveTick(float DeltaSeconds); // Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.ReceiveTick
	void ExecuteUbergraph_BP_CameraCaptureComponent(int32_t EntryPoint); // Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.ExecuteUbergraph_BP_CameraCaptureComponent
	void IsCapturing__DelegateSignature(bool IsCapturing); // Function BP_CameraCaptureComponent.BP_CameraCaptureComponent_C.IsCapturing__DelegateSignature
}; 



