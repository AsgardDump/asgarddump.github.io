#include "SDK.h" 
 
 
void UWidget::SetValueTags(struct TArray<float>& InValueTags){

	static UObject* p_SetValueTags = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetValueTags");

	struct {
		struct TArray<float>& InValueTags;
	} parms;

	parms.InValueTags = InValueTags;

	ProcessEvent(p_SetValueTags, &parms);
}

void UWidget::SetValue(float InValue){

	static UObject* p_SetValue = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetValue");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetValue, &parms);
}

void UWidget::SetUseVerticalDrag(bool InUseVerticalDrag){

	static UObject* p_SetUseVerticalDrag = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag");

	struct {
		bool InUseVerticalDrag;
	} parms;

	parms.InUseVerticalDrag = InUseVerticalDrag;

	ProcessEvent(p_SetUseVerticalDrag, &parms);
}

void UWidget::SetStepSize(float InValue){

	static UObject* p_SetStepSize = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetStepSize");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetStepSize, &parms);
}

void UWidget::SetSliderRange(struct FRuntimeFloatCurve& InSliderRange){

	static UObject* p_SetSliderRange = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetSliderRange");

	struct {
		struct FRuntimeFloatCurve& InSliderRange;
	} parms;

	parms.InSliderRange = InSliderRange;

	ProcessEvent(p_SetSliderRange, &parms);
}

void UWidget::SetSliderProgressColor(struct FLinearColor InValue){

	static UObject* p_SetSliderProgressColor = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetSliderProgressColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderProgressColor, &parms);
}

void UWidget::SetSliderHandleStartAngle(float InValue){

	static UObject* p_SetSliderHandleStartAngle = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderHandleStartAngle, &parms);
}

void UWidget::SetSliderHandleEndAngle(float InValue){

	static UObject* p_SetSliderHandleEndAngle = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderHandleEndAngle, &parms);
}

void UWidget::SetSliderHandleColor(struct FLinearColor InValue){

	static UObject* p_SetSliderHandleColor = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetSliderHandleColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderHandleColor, &parms);
}

void UWidget::SetSliderBarColor(struct FLinearColor InValue){

	static UObject* p_SetSliderBarColor = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetSliderBarColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetSliderBarColor, &parms);
}

void UWidget::SetShowSliderHandle(bool InShowSliderHandle){

	static UObject* p_SetShowSliderHandle = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetShowSliderHandle");

	struct {
		bool InShowSliderHandle;
	} parms;

	parms.InShowSliderHandle = InShowSliderHandle;

	ProcessEvent(p_SetShowSliderHandle, &parms);
}

void UWidget::SetShowSliderHand(bool InShowSliderHand){

	static UObject* p_SetShowSliderHand = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetShowSliderHand");

	struct {
		bool InShowSliderHand;
	} parms;

	parms.InShowSliderHand = InShowSliderHand;

	ProcessEvent(p_SetShowSliderHand, &parms);
}

void UWidget::SetLocked(bool InValue){

	static UObject* p_SetLocked = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetLocked");

	struct {
		bool InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetLocked, &parms);
}

void UWidget::SetHandStartEndRatio(struct FVector2D InValue){

	static UObject* p_SetHandStartEndRatio = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio");

	struct {
		struct FVector2D InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetHandStartEndRatio, &parms);
}

void UWidget::SetCustomDefaultValue(float InValue){

	static UObject* p_SetCustomDefaultValue = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetCustomDefaultValue, &parms);
}

void UWidget::SetCenterBackgroundColor(struct FLinearColor InValue){

	static UObject* p_SetCenterBackgroundColor = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor");

	struct {
		struct FLinearColor InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetCenterBackgroundColor, &parms);
}

void UWidget::SetAngularOffset(float InValue){

	static UObject* p_SetAngularOffset = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.SetAngularOffset");

	struct {
		float InValue;
	} parms;

	parms.InValue = InValue;

	ProcessEvent(p_SetAngularOffset, &parms);
}

float UWidget::GetValue(){

	static UObject* p_GetValue = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.GetValue");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetValue, &parms);
	return parms.return_value;
}

float UWidget::GetNormalizedSliderHandlePosition(){

	static UObject* p_GetNormalizedSliderHandlePosition = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetNormalizedSliderHandlePosition, &parms);
	return parms.return_value;
}

float UWidget::GetCustomDefaultValue(){

	static UObject* p_GetCustomDefaultValue = UObject::FindObject<UFunction>("Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue");

	struct {
		float return_value;
	} parms;


	ProcessEvent(p_GetCustomDefaultValue, &parms);
	return parms.return_value;
}

