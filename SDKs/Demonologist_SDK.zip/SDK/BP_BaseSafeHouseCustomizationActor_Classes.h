#pragma once 
#include <BP_BaseSafeHouseCustomizationActor_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BaseSafeHouseCustomizationActor.BP_BaseSafeHouseCustomizationActor_C
// Size: 0x298(Inherited: 0x290) 
struct ABP_BaseSafeHouseCustomizationActor_C : public AActor
{
	struct USceneComponent* DefaultSceneRoot;  // 0x290(0x8)

}; 



