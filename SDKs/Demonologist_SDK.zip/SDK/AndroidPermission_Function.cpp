#include "SDK.h" 
 
 
bool UBlueprintFunctionLibrary::CheckPermission(struct FString permission){

	static UObject* p_CheckPermission = UObject::FindObject<UFunction>("Function AndroidPermission.AndroidPermissionFunctionLibrary.CheckPermission");

	struct {
		struct FString permission;
		bool return_value;
	} parms;

	parms.permission = permission;

	ProcessEvent(p_CheckPermission, &parms);
	return parms.return_value;
}

struct UAndroidPermissionCallbackProxy* UBlueprintFunctionLibrary::AcquirePermissions(struct TArray<struct FString>& Permissions){

	static UObject* p_AcquirePermissions = UObject::FindObject<UFunction>("Function AndroidPermission.AndroidPermissionFunctionLibrary.AcquirePermissions");

	struct {
		struct TArray<struct FString>& Permissions;
		struct UAndroidPermissionCallbackProxy* return_value;
	} parms;

	parms.Permissions = Permissions;

	ProcessEvent(p_AcquirePermissions, &parms);
	return parms.return_value;
}

