#pragma once 
#include <ABP_ThirdPersonKatana_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonKatana.ABP_ThirdPersonKatana_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonKatana_C : public UABP_ThirdPersonToolLayer_C
{

}; 



