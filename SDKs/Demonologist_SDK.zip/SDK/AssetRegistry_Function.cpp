#include "SDK.h" 
 
 
struct FSoftObjectPath UObject::ToSoftObjectPath(struct FAssetData& InAssetData){

	static UObject* p_ToSoftObjectPath = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.ToSoftObjectPath");

	struct {
		struct FAssetData& InAssetData;
		struct FSoftObjectPath return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_ToSoftObjectPath, &parms);
	return parms.return_value;
}

struct FARFilter UObject::SetFilterTagsAndValues(struct FARFilter& InFilter, struct TArray<struct FTagAndValue>& InTagsAndValues){

	static UObject* p_SetFilterTagsAndValues = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.SetFilterTagsAndValues");

	struct {
		struct FARFilter& InFilter;
		struct TArray<struct FTagAndValue>& InTagsAndValues;
		struct FARFilter return_value;
	} parms;

	parms.InFilter = InFilter;
	parms.InTagsAndValues = InTagsAndValues;

	ProcessEvent(p_SetFilterTagsAndValues, &parms);
	return parms.return_value;
}

bool UObject::IsValid(struct FAssetData& InAssetData){

	static UObject* p_IsValid = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.IsValid");

	struct {
		struct FAssetData& InAssetData;
		bool return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_IsValid, &parms);
	return parms.return_value;
}

bool UObject::IsUAsset(struct FAssetData& InAssetData){

	static UObject* p_IsUAsset = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.IsUAsset");

	struct {
		struct FAssetData& InAssetData;
		bool return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_IsUAsset, &parms);
	return parms.return_value;
}

bool UObject::IsRedirector(struct FAssetData& InAssetData){

	static UObject* p_IsRedirector = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.IsRedirector");

	struct {
		struct FAssetData& InAssetData;
		bool return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_IsRedirector, &parms);
	return parms.return_value;
}

bool UObject::IsAssetLoaded(struct FAssetData& InAssetData){

	static UObject* p_IsAssetLoaded = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.IsAssetLoaded");

	struct {
		struct FAssetData& InAssetData;
		bool return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_IsAssetLoaded, &parms);
	return parms.return_value;
}

bool UObject::GetTagValue(struct FAssetData& InAssetData, struct FName& InTagName, struct FString& OutTagValue){

	static UObject* p_GetTagValue = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.GetTagValue");

	struct {
		struct FAssetData& InAssetData;
		struct FName& InTagName;
		struct FString& OutTagValue;
		bool return_value;
	} parms;

	parms.InAssetData = InAssetData;
	parms.InTagName = InTagName;
	parms.OutTagValue = OutTagValue;

	ProcessEvent(p_GetTagValue, &parms);
	return parms.return_value;
}

struct FString UObject::GetFullName(struct FAssetData& InAssetData){

	static UObject* p_GetFullName = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.GetFullName");

	struct {
		struct FAssetData& InAssetData;
		struct FString return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_GetFullName, &parms);
	return parms.return_value;
}

struct FString UObject::GetExportTextName(struct FAssetData& InAssetData){

	static UObject* p_GetExportTextName = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.GetExportTextName");

	struct {
		struct FAssetData& InAssetData;
		struct FString return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_GetExportTextName, &parms);
	return parms.return_value;
}

UObject* UObject::GetClass(struct FAssetData& InAssetData){

	static UObject* p_GetClass = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.GetClass");

	struct {
		struct FAssetData& InAssetData;
		UObject* return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_GetClass, &parms);
	return parms.return_value;
}

void UObject::GetBlueprintAssets(struct FARFilter& InFilter, struct TArray<struct FAssetData>& OutAssetData){

	static UObject* p_GetBlueprintAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.GetBlueprintAssets");

	struct {
		struct FARFilter& InFilter;
		struct TArray<struct FAssetData>& OutAssetData;
	} parms;

	parms.InFilter = InFilter;
	parms.OutAssetData = OutAssetData;

	ProcessEvent(p_GetBlueprintAssets, &parms);
}

struct TScriptInterface<IAssetRegistry> UObject::GetAssetRegistry(){

	static UObject* p_GetAssetRegistry = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.GetAssetRegistry");

	struct {
		struct TScriptInterface<IAssetRegistry> return_value;
	} parms;


	ProcessEvent(p_GetAssetRegistry, &parms);
	return parms.return_value;
}

struct UObject* UObject::GetAsset(struct FAssetData& InAssetData){

	static UObject* p_GetAsset = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.GetAsset");

	struct {
		struct FAssetData& InAssetData;
		struct UObject* return_value;
	} parms;

	parms.InAssetData = InAssetData;

	ProcessEvent(p_GetAsset, &parms);
	return parms.return_value;
}

struct FAssetData UObject::CreateAssetData(struct UObject* InAsset, bool bAllowBlueprintClass){

	static UObject* p_CreateAssetData = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistryHelpers.CreateAssetData");

	struct {
		struct UObject* InAsset;
		bool bAllowBlueprintClass;
		struct FAssetData return_value;
	} parms;

	parms.InAsset = InAsset;
	parms.bAllowBlueprintClass = bAllowBlueprintClass;

	ProcessEvent(p_CreateAssetData, &parms);
	return parms.return_value;
}

void UInterface::WaitForPackage(struct FString PackageName){

	static UObject* p_WaitForPackage = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.WaitForPackage");

	struct {
		struct FString PackageName;
	} parms;

	parms.PackageName = PackageName;

	ProcessEvent(p_WaitForPackage, &parms);
}

void UInterface::WaitForCompletion(){

	static UObject* p_WaitForCompletion = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.WaitForCompletion");

	struct {
	} parms;


	ProcessEvent(p_WaitForCompletion, &parms);
}

void UInterface::UseFilterToExcludeAssets(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& Filter){

	static UObject* p_UseFilterToExcludeAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.UseFilterToExcludeAssets");

	struct {
		struct TArray<struct FAssetData>& AssetDataList;
		struct FARFilter& Filter;
	} parms;

	parms.AssetDataList = AssetDataList;
	parms.Filter = Filter;

	ProcessEvent(p_UseFilterToExcludeAssets, &parms);
}

void UInterface::SearchAllAssets(bool bSynchronousSearch){

	static UObject* p_SearchAllAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.SearchAllAssets");

	struct {
		bool bSynchronousSearch;
	} parms;

	parms.bSynchronousSearch = bSynchronousSearch;

	ProcessEvent(p_SearchAllAssets, &parms);
}

void UInterface::ScanPathsSynchronous(struct TArray<struct FString>& InPaths, bool bForceRescan, bool bIgnoreDenyListScanFilters){

	static UObject* p_ScanPathsSynchronous = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.ScanPathsSynchronous");

	struct {
		struct TArray<struct FString>& InPaths;
		bool bForceRescan;
		bool bIgnoreDenyListScanFilters;
	} parms;

	parms.InPaths = InPaths;
	parms.bForceRescan = bForceRescan;
	parms.bIgnoreDenyListScanFilters = bIgnoreDenyListScanFilters;

	ProcessEvent(p_ScanPathsSynchronous, &parms);
}

void UInterface::ScanModifiedAssetFiles(struct TArray<struct FString>& InFilePaths){

	static UObject* p_ScanModifiedAssetFiles = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.ScanModifiedAssetFiles");

	struct {
		struct TArray<struct FString>& InFilePaths;
	} parms;

	parms.InFilePaths = InFilePaths;

	ProcessEvent(p_ScanModifiedAssetFiles, &parms);
}

void UInterface::ScanFilesSynchronous(struct TArray<struct FString>& InFilePaths, bool bForceRescan){

	static UObject* p_ScanFilesSynchronous = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.ScanFilesSynchronous");

	struct {
		struct TArray<struct FString>& InFilePaths;
		bool bForceRescan;
	} parms;

	parms.InFilePaths = InFilePaths;
	parms.bForceRescan = bForceRescan;

	ProcessEvent(p_ScanFilesSynchronous, &parms);
}

void UInterface::RunAssetsThroughFilter(struct TArray<struct FAssetData>& AssetDataList, struct FARFilter& Filter){

	static UObject* p_RunAssetsThroughFilter = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.RunAssetsThroughFilter");

	struct {
		struct TArray<struct FAssetData>& AssetDataList;
		struct FARFilter& Filter;
	} parms;

	parms.AssetDataList = AssetDataList;
	parms.Filter = Filter;

	ProcessEvent(p_RunAssetsThroughFilter, &parms);
}

void UInterface::PrioritizeSearchPath(struct FString PathToPrioritize){

	static UObject* p_PrioritizeSearchPath = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.PrioritizeSearchPath");

	struct {
		struct FString PathToPrioritize;
	} parms;

	parms.PathToPrioritize = PathToPrioritize;

	ProcessEvent(p_PrioritizeSearchPath, &parms);
}

bool UInterface::K2_GetReferencers(struct FName PackageName, struct FAssetRegistryDependencyOptions& ReferenceOptions, struct TArray<struct FName>& OutReferencers){

	static UObject* p_K2_GetReferencers = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.K2_GetReferencers");

	struct {
		struct FName PackageName;
		struct FAssetRegistryDependencyOptions& ReferenceOptions;
		struct TArray<struct FName>& OutReferencers;
		bool return_value;
	} parms;

	parms.PackageName = PackageName;
	parms.ReferenceOptions = ReferenceOptions;
	parms.OutReferencers = OutReferencers;

	ProcessEvent(p_K2_GetReferencers, &parms);
	return parms.return_value;
}

bool UInterface::K2_GetDependencies(struct FName PackageName, struct FAssetRegistryDependencyOptions& DependencyOptions, struct TArray<struct FName>& OutDependencies){

	static UObject* p_K2_GetDependencies = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.K2_GetDependencies");

	struct {
		struct FName PackageName;
		struct FAssetRegistryDependencyOptions& DependencyOptions;
		struct TArray<struct FName>& OutDependencies;
		bool return_value;
	} parms;

	parms.PackageName = PackageName;
	parms.DependencyOptions = DependencyOptions;
	parms.OutDependencies = OutDependencies;

	ProcessEvent(p_K2_GetDependencies, &parms);
	return parms.return_value;
}

struct FAssetData UInterface::K2_GetAssetByObjectPath(struct FSoftObjectPath& ObjectPath, bool bIncludeOnlyOnDiskAssets){

	static UObject* p_K2_GetAssetByObjectPath = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.K2_GetAssetByObjectPath");

	struct {
		struct FSoftObjectPath& ObjectPath;
		bool bIncludeOnlyOnDiskAssets;
		struct FAssetData return_value;
	} parms;

	parms.ObjectPath = ObjectPath;
	parms.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;

	ProcessEvent(p_K2_GetAssetByObjectPath, &parms);
	return parms.return_value;
}

bool UInterface::IsSearchAsync(){

	static UObject* p_IsSearchAsync = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.IsSearchAsync");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsSearchAsync, &parms);
	return parms.return_value;
}

bool UInterface::IsSearchAllAssets(){

	static UObject* p_IsSearchAllAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.IsSearchAllAssets");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsSearchAllAssets, &parms);
	return parms.return_value;
}

bool UInterface::IsLoadingAssets(){

	static UObject* p_IsLoadingAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.IsLoadingAssets");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsLoadingAssets, &parms);
	return parms.return_value;
}

bool UInterface::HasAssets(struct FName PackagePath, bool bRecursive){

	static UObject* p_HasAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.HasAssets");

	struct {
		struct FName PackagePath;
		bool bRecursive;
		bool return_value;
	} parms;

	parms.PackagePath = PackagePath;
	parms.bRecursive = bRecursive;

	ProcessEvent(p_HasAssets, &parms);
	return parms.return_value;
}

void UInterface::GetSubPaths(struct FString InBasePath, struct TArray<struct FString>& OutPathList, bool bInRecurse){

	static UObject* p_GetSubPaths = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetSubPaths");

	struct {
		struct FString InBasePath;
		struct TArray<struct FString>& OutPathList;
		bool bInRecurse;
	} parms;

	parms.InBasePath = InBasePath;
	parms.OutPathList = OutPathList;
	parms.bInRecurse = bInRecurse;

	ProcessEvent(p_GetSubPaths, &parms);
}

void UInterface::GetDerivedClassNames(struct TArray<struct FTopLevelAssetPath>& ClassNames, struct TSet<struct FTopLevelAssetPath>& ExcludedClassNames, struct TSet<struct FTopLevelAssetPath>& OutDerivedClassNames){

	static UObject* p_GetDerivedClassNames = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetDerivedClassNames");

	struct {
		struct TArray<struct FTopLevelAssetPath>& ClassNames;
		struct TSet<struct FTopLevelAssetPath>& ExcludedClassNames;
		struct TSet<struct FTopLevelAssetPath>& OutDerivedClassNames;
	} parms;

	parms.ClassNames = ClassNames;
	parms.ExcludedClassNames = ExcludedClassNames;
	parms.OutDerivedClassNames = OutDerivedClassNames;

	ProcessEvent(p_GetDerivedClassNames, &parms);
}

bool UInterface::GetAssetsByPaths(struct TArray<struct FName> PackagePaths, struct TArray<struct FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets){

	static UObject* p_GetAssetsByPaths = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAssetsByPaths");

	struct {
		struct TArray<struct FName> PackagePaths;
		struct TArray<struct FAssetData>& OutAssetData;
		bool bRecursive;
		bool bIncludeOnlyOnDiskAssets;
		bool return_value;
	} parms;

	parms.PackagePaths = PackagePaths;
	parms.OutAssetData = OutAssetData;
	parms.bRecursive = bRecursive;
	parms.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;

	ProcessEvent(p_GetAssetsByPaths, &parms);
	return parms.return_value;
}

bool UInterface::GetAssetsByPath(struct FName PackagePath, struct TArray<struct FAssetData>& OutAssetData, bool bRecursive, bool bIncludeOnlyOnDiskAssets){

	static UObject* p_GetAssetsByPath = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAssetsByPath");

	struct {
		struct FName PackagePath;
		struct TArray<struct FAssetData>& OutAssetData;
		bool bRecursive;
		bool bIncludeOnlyOnDiskAssets;
		bool return_value;
	} parms;

	parms.PackagePath = PackagePath;
	parms.OutAssetData = OutAssetData;
	parms.bRecursive = bRecursive;
	parms.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;

	ProcessEvent(p_GetAssetsByPath, &parms);
	return parms.return_value;
}

bool UInterface::GetAssetsByPackageName(struct FName PackageName, struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets, bool bSkipARFilteredAssets){

	static UObject* p_GetAssetsByPackageName = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAssetsByPackageName");

	struct {
		struct FName PackageName;
		struct TArray<struct FAssetData>& OutAssetData;
		bool bIncludeOnlyOnDiskAssets;
		bool bSkipARFilteredAssets;
		bool return_value;
	} parms;

	parms.PackageName = PackageName;
	parms.OutAssetData = OutAssetData;
	parms.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;
	parms.bSkipARFilteredAssets = bSkipARFilteredAssets;

	ProcessEvent(p_GetAssetsByPackageName, &parms);
	return parms.return_value;
}

bool UInterface::GetAssetsByClass(struct FTopLevelAssetPath ClassPathName, struct TArray<struct FAssetData>& OutAssetData, bool bSearchSubClasses){

	static UObject* p_GetAssetsByClass = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAssetsByClass");

	struct {
		struct FTopLevelAssetPath ClassPathName;
		struct TArray<struct FAssetData>& OutAssetData;
		bool bSearchSubClasses;
		bool return_value;
	} parms;

	parms.ClassPathName = ClassPathName;
	parms.OutAssetData = OutAssetData;
	parms.bSearchSubClasses = bSearchSubClasses;

	ProcessEvent(p_GetAssetsByClass, &parms);
	return parms.return_value;
}

bool UInterface::GetAssets(struct FARFilter& Filter, struct TArray<struct FAssetData>& OutAssetData, bool bSkipARFilteredAssets){

	static UObject* p_GetAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAssets");

	struct {
		struct FARFilter& Filter;
		struct TArray<struct FAssetData>& OutAssetData;
		bool bSkipARFilteredAssets;
		bool return_value;
	} parms;

	parms.Filter = Filter;
	parms.OutAssetData = OutAssetData;
	parms.bSkipARFilteredAssets = bSkipARFilteredAssets;

	ProcessEvent(p_GetAssets, &parms);
	return parms.return_value;
}

struct FAssetData UInterface::GetAssetByObjectPath(struct FName ObjectPath, bool bIncludeOnlyOnDiskAssets){

	static UObject* p_GetAssetByObjectPath = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAssetByObjectPath");

	struct {
		struct FName ObjectPath;
		bool bIncludeOnlyOnDiskAssets;
		struct FAssetData return_value;
	} parms;

	parms.ObjectPath = ObjectPath;
	parms.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;

	ProcessEvent(p_GetAssetByObjectPath, &parms);
	return parms.return_value;
}

bool UInterface::GetAncestorClassNames(struct FTopLevelAssetPath ClassPathName, struct TArray<struct FTopLevelAssetPath>& OutAncestorClassNames){

	static UObject* p_GetAncestorClassNames = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAncestorClassNames");

	struct {
		struct FTopLevelAssetPath ClassPathName;
		struct TArray<struct FTopLevelAssetPath>& OutAncestorClassNames;
		bool return_value;
	} parms;

	parms.ClassPathName = ClassPathName;
	parms.OutAncestorClassNames = OutAncestorClassNames;

	ProcessEvent(p_GetAncestorClassNames, &parms);
	return parms.return_value;
}

void UInterface::GetAllCachedPaths(struct TArray<struct FString>& OutPathList){

	static UObject* p_GetAllCachedPaths = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAllCachedPaths");

	struct {
		struct TArray<struct FString>& OutPathList;
	} parms;

	parms.OutPathList = OutPathList;

	ProcessEvent(p_GetAllCachedPaths, &parms);
}

bool UInterface::GetAllAssets(struct TArray<struct FAssetData>& OutAssetData, bool bIncludeOnlyOnDiskAssets){

	static UObject* p_GetAllAssets = UObject::FindObject<UFunction>("Function AssetRegistry.AssetRegistry.GetAllAssets");

	struct {
		struct TArray<struct FAssetData>& OutAssetData;
		bool bIncludeOnlyOnDiskAssets;
		bool return_value;
	} parms;

	parms.OutAssetData = OutAssetData;
	parms.bIncludeOnlyOnDiskAssets = bIncludeOnlyOnDiskAssets;

	ProcessEvent(p_GetAllAssets, &parms);
	return parms.return_value;
}

