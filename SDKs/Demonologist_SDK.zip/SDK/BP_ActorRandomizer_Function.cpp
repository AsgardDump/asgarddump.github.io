#include "SDK.h" 
 
 
void AActor::DebugRandomItem(){

	static UObject* p_DebugRandomItem = UObject::FindObject<UFunction>("Function BP_ActorRandomizer.BP_ActorRandomizer_C.DebugRandomItem");

	struct {
	} parms;


	ProcessEvent(p_DebugRandomItem, &parms);
}

void AActor::ClearSpawnedActors(){

	static UObject* p_ClearSpawnedActors = UObject::FindObject<UFunction>("Function BP_ActorRandomizer.BP_ActorRandomizer_C.ClearSpawnedActors");

	struct {
	} parms;


	ProcessEvent(p_ClearSpawnedActors, &parms);
}

void AActor::RunRandomization(){

	static UObject* p_RunRandomization = UObject::FindObject<UFunction>("Function BP_ActorRandomizer.BP_ActorRandomizer_C.RunRandomization");

	struct {
	} parms;


	ProcessEvent(p_RunRandomization, &parms);
}

void AActor::PreviewMeshes(){

	static UObject* p_PreviewMeshes = UObject::FindObject<UFunction>("Function BP_ActorRandomizer.BP_ActorRandomizer_C.PreviewMeshes");

	struct {
	} parms;


	ProcessEvent(p_PreviewMeshes, &parms);
}

void AActor::ClearPreviewActors(){

	static UObject* p_ClearPreviewActors = UObject::FindObject<UFunction>("Function BP_ActorRandomizer.BP_ActorRandomizer_C.ClearPreviewActors");

	struct {
	} parms;


	ProcessEvent(p_ClearPreviewActors, &parms);
}

void AActor::ExecuteUbergraph_BP_ActorRandomizer(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_ActorRandomizer = UObject::FindObject<UFunction>("Function BP_ActorRandomizer.BP_ActorRandomizer_C.ExecuteUbergraph_BP_ActorRandomizer");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_ActorRandomizer, &parms);
}

