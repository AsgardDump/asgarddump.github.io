#pragma once 
#include <BP_BloodBag_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_BloodBag.BP_BloodBag_C
// Size: 0x2D8(Inherited: 0x2D0) 
struct ABP_BloodBag_C : public ABP_BaseCollectableItem_C
{
	struct UStaticMeshComponent* BloodBag;  // 0x2D0(0x8)

}; 



