#include "SDK.h" 
 
 
void UAnimLayerInterface::BaseState(struct FPoseLink BaseAnimation, struct FPoseLink& BaseState){

	static UObject* p_BaseState = UObject::FindObject<UFunction>("Function ALI_ThirdPersonToolLayer.ALI_ThirdPersonToolLayer_C.BaseState");

	struct {
		struct FPoseLink BaseAnimation;
		struct FPoseLink& BaseState;
	} parms;

	parms.BaseAnimation = BaseAnimation;
	parms.BaseState = BaseState;

	ProcessEvent(p_BaseState, &parms);
}

