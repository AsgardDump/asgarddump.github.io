#pragma once 
#include "SDK.h" 
 
 
// Function BP_Abaddon.BP_Abaddon_C.ExecuteUbergraph_BP_Abaddon
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_Abaddon
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AActor*> K2Node_Event_UpdatedActors;  // 0x8(0x10)
	struct TArray<struct AActor*> CallFunc_FilterAbaddonCharacters_ReturnValue;  // 0x18(0x10)

}; 
// Function BP_Abaddon.BP_Abaddon_C.FilterAbaddonCharacters
// Size: 0xA0(Inherited: 0x0) 
struct FFilterAbaddonCharacters
{
	struct TArray<struct AActor*> SeenActors;  // 0x0(0x10)
	struct TArray<struct AActor*> ReturnValue;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool IsSeenCrucifix : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct AActor*> TargetCharacters;  // 0x28(0x10)
	struct TArray<struct AActor*> CallFunc_FilterCharactersByInHouse_ReturnValue;  // 0x38(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)
	struct AActor* CallFunc_Array_Get_Item;  // 0x50(0x8)
	struct TScriptInterface<IBPI_PlayerCharacter_C> K2Node_DynamicCast_AsBPI_Player_Character;  // 0x58(0x10)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x6C(0x4)
	struct UBP_PlayerInteractionComponent_C* CallFunc_GetInteractionComponent_ReturnValue;  // 0x70(0x8)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x78(0x4)
	char pad_124_1 : 7;  // 0x7C(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct ABP_Tool_C* CallFunc_GetEquippedItem_ReturnValue;  // 0x88(0x8)
	struct ABP_Crucifix_C* K2Node_DynamicCast_AsBP_Crucifix;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x98(0x1)
	char pad_153[3];  // 0x99(0x3)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x9C(0x4)

}; 
// Function BP_Abaddon.BP_Abaddon_C.OnPerceptionUpdatedCallback
// Size: 0x10(Inherited: 0x10) 
struct FOnPerceptionUpdatedCallback : public FOnPerceptionUpdatedCallback
{
	struct TArray<struct AActor*> UpdatedActors;  // 0x0(0x10)

}; 
// Function BP_Abaddon.BP_Abaddon_C.GetCanPerformGhostAbility
// Size: 0x1(Inherited: 0x1) 
struct FGetCanPerformGhostAbility : public FGetCanPerformGhostAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
