#pragma once 
#include "SDK.h" 
 
 
// Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.GetQuestManager
// Size: 0x10(Inherited: 0x10) 
struct FGetQuestManager : public FGetQuestManager
{
	struct UBP_QuestManager_C* ReturnValue;  // 0x0(0x8)
	struct ABP_Shivers_InGameState_C* CallFunc_Get_Shivers_in_Game_State_ReturnValue;  // 0x8(0x8)

}; 
// Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.CheckClocks
// Size: 0x4B(Inherited: 0x0) 
struct FCheckClocks
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t Temp_int_Array_Index_Variable;  // 0x4(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x8(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0xC(0x4)
	struct TArray<struct ABP_ClockExcorcism_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x10(0x10)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct ABP_ClockExcorcism_C* CallFunc_Array_Get_Item;  // 0x28(0x8)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	double CallFunc_GetHourAndMinute_Hour;  // 0x38(0x8)
	double CallFunc_GetHourAndMinute_Minute;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_NearlyEqual_FloatFloat_ReturnValue_2 : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x4A(0x1)

}; 
// Function BP_ClockExcorcismRandomizer.BP_ClockExcorcismRandomizer_C.ExecuteUbergraph_BP_ClockExcorcismRandomizer
// Size: 0x58(Inherited: 0x0) 
struct FExecuteUbergraph_BP_ClockExcorcismRandomizer
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UTMWGlobalEventHandler* CallFunc_GetGameInstanceSubsystem_ReturnValue;  // 0x8(0x8)
	struct UBP_Payload_QuestListenerInfo_C* CallFunc_SpawnObject_ReturnValue;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool Temp_bool_Has_Been_Initd_Variable : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool Temp_bool_IsClosed_Variable : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool Temp_bool_Has_Been_Initd_Variable_2 : 1;  // 0x1A(0x1)
	char pad_27_1 : 7;  // 0x1B(0x1)
	bool CallFunc_CheckClocks_ReturnValue : 1;  // 0x1B(0x1)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool Temp_bool_IsClosed_Variable_2 : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct ABP_FindCorrectTimeObjective_C* CallFunc_GetActorOfClass_ReturnValue;  // 0x20(0x8)
	struct FGameplayTag Temp_struct_Variable;  // 0x28(0x8)
	struct TArray<struct FString> K2Node_MakeArray_Array;  // 0x30(0x10)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x40(0x10)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x50(0x8)

}; 
