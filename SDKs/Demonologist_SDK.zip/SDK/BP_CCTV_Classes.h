#pragma once 
#include <BP_CCTV_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_CCTV.BP_CCTV_C
// Size: 0x2D0(Inherited: 0x290) 
struct ABP_CCTV_C : public AActor
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x290(0x8)
	struct UBP_CameraCaptureComponent_C* BP_CameraCaptureComponent;  // 0x298(0x8)
	struct USceneCaptureComponent2D* SceneCaptureComponent2D;  // 0x2A0(0x8)
	struct UStaticMeshComponent* CCTV;  // 0x2A8(0x8)
	struct UStaticMeshComponent* Frame;  // 0x2B0(0x8)
	struct USceneComponent* DefaultSceneRoot;  // 0x2B8(0x8)
	char pad_704_1 : 7;  // 0x2C0(0x1)
	bool Reflect Capture : 1;  // 0x2C0(0x1)
	char pad_705[7];  // 0x2C1(0x7)
	struct UMaterialInstanceDynamic* CameraScreenMaterial;  // 0x2C8(0x8)

	bool CanReflectCapture(); // Function BP_CCTV.BP_CCTV_C.CanReflectCapture
	void InitializeCamera(); // Function BP_CCTV.BP_CCTV_C.InitializeCamera
	void ReceiveBeginPlay(); // Function BP_CCTV.BP_CCTV_C.ReceiveBeginPlay
	void SetReflectCaptureStatus(bool ReflectCapture); // Function BP_CCTV.BP_CCTV_C.SetReflectCaptureStatus
	void ExecuteUbergraph_BP_CCTV(int32_t EntryPoint); // Function BP_CCTV.BP_CCTV_C.ExecuteUbergraph_BP_CCTV
}; 



