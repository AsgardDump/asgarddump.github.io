#pragma once 
#include <ABP_OuijaBoard_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_OuijaBoard.ABP_OuijaBoard_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_OuijaBoard_C : public UABP_ToolLayerArms_C
{

}; 



