#include "SDK.h" 
 
 
bool ABP_BaseInteraction_C::GetVisualActiveCondition(){

	static UObject* p_GetVisualActiveCondition = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetVisualActiveCondition");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetVisualActiveCondition, &parms);
	return parms.return_value;
}

bool ABP_BaseInteraction_C::GetIsLookInteractionActive(){

	static UObject* p_GetIsLookInteractionActive = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetIsLookInteractionActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsLookInteractionActive, &parms);
	return parms.return_value;
}

bool ABP_BaseInteraction_C::CanPlayerInteract(struct APawn* PawnReference){

	static UObject* p_CanPlayerInteract = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.CanPlayerInteract");

	struct {
		struct APawn* PawnReference;
		bool return_value;
	} parms;

	parms.PawnReference = PawnReference;

	ProcessEvent(p_CanPlayerInteract, &parms);
	return parms.return_value;
}

void ABP_BaseInteraction_C::GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule){

	static UObject* p_GetAttachmentDetails = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetAttachmentDetails");

	struct {
		bool& IsManualAttachment;
		struct FTransform& RelativeTransform;
		struct USceneComponent*& AttachmentComponent;
		struct FName& SocketName;
		char& LocationRule;
		char& RotationRule;
		char& ScaleRule;
	} parms;

	parms.IsManualAttachment = IsManualAttachment;
	parms.RelativeTransform = RelativeTransform;
	parms.AttachmentComponent = AttachmentComponent;
	parms.SocketName = SocketName;
	parms.LocationRule = LocationRule;
	parms.RotationRule = RotationRule;
	parms.ScaleRule = ScaleRule;

	ProcessEvent(p_GetAttachmentDetails, &parms);
}

bool ABP_BaseInteraction_C::CanInteractWithClock(){

	static UObject* p_CanInteractWithClock = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.CanInteractWithClock");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_CanInteractWithClock, &parms);
	return parms.return_value;
}

void ABP_BaseInteraction_C::GetHourAndMinute(double& Hour, double& Minute){

	static UObject* p_GetHourAndMinute = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.GetHourAndMinute");

	struct {
		double& Hour;
		double& Minute;
	} parms;

	parms.Hour = Hour;
	parms.Minute = Minute;

	ProcessEvent(p_GetHourAndMinute, &parms);
}

void ABP_BaseInteraction_C::InpActEvt_D_K2Node_InputKeyEvent_5(struct FKey Key){

	static UObject* p_InpActEvt_D_K2Node_InputKeyEvent_5 = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_D_K2Node_InputKeyEvent_5");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_D_K2Node_InputKeyEvent_5, &parms);
}

void ABP_BaseInteraction_C::InpActEvt_D_K2Node_InputKeyEvent_4(struct FKey Key){

	static UObject* p_InpActEvt_D_K2Node_InputKeyEvent_4 = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_D_K2Node_InputKeyEvent_4");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_D_K2Node_InputKeyEvent_4, &parms);
}

void ABP_BaseInteraction_C::InpActEvt_A_K2Node_InputKeyEvent_3(struct FKey Key){

	static UObject* p_InpActEvt_A_K2Node_InputKeyEvent_3 = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_A_K2Node_InputKeyEvent_3");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_A_K2Node_InputKeyEvent_3, &parms);
}

void ABP_BaseInteraction_C::InpActEvt_A_K2Node_InputKeyEvent_2(struct FKey Key){

	static UObject* p_InpActEvt_A_K2Node_InputKeyEvent_2 = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_A_K2Node_InputKeyEvent_2");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_A_K2Node_InputKeyEvent_2, &parms);
}

void ABP_BaseInteraction_C::InpActEvt_Interaction_K2Node_InputActionEvent_1(struct FKey Key){

	static UObject* p_InpActEvt_Interaction_K2Node_InputActionEvent_1 = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_Interaction_K2Node_InputActionEvent_1");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_Interaction_K2Node_InputActionEvent_1, &parms);
}

void ABP_BaseInteraction_C::InpActEvt_Escape_K2Node_InputKeyEvent_1(struct FKey Key){

	static UObject* p_InpActEvt_Escape_K2Node_InputKeyEvent_1 = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.InpActEvt_Escape_K2Node_InputKeyEvent_1");

	struct {
		struct FKey Key;
	} parms;

	parms.Key = Key;

	ProcessEvent(p_InpActEvt_Escape_K2Node_InputKeyEvent_1, &parms);
}

void ABP_BaseInteraction_C::MinuteMovement(bool IsClockWise){

	static UObject* p_MinuteMovement = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.MinuteMovement");

	struct {
		bool IsClockWise;
	} parms;

	parms.IsClockWise = IsClockWise;

	ProcessEvent(p_MinuteMovement, &parms);
}

void ABP_BaseInteraction_C::BndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted){

	static UObject* p_BndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.BndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature");

	struct {
		struct APawn* CharacterPawn;
		struct FName Identifier;
		bool IsServerExucuted;
	} parms;

	parms.CharacterPawn = CharacterPawn;
	parms.Identifier = Identifier;
	parms.IsServerExucuted = IsServerExucuted;

	ProcessEvent(p_BndEvt__BP_ClockExcorcism_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_0_InteractObjectDispatcher__DelegateSignature, &parms);
}

void ABP_BaseInteraction_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_BaseInteraction_C::ReceiveTick(float DeltaSeconds){

	static UObject* p_ReceiveTick = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.ReceiveTick");

	struct {
		float DeltaSeconds;
	} parms;

	parms.DeltaSeconds = DeltaSeconds;

	ProcessEvent(p_ReceiveTick, &parms);
}

void ABP_BaseInteraction_C::ClockWiseMovement(){

	static UObject* p_ClockWiseMovement = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.ClockWiseMovement");

	struct {
	} parms;


	ProcessEvent(p_ClockWiseMovement, &parms);
}

void ABP_BaseInteraction_C::BndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature(bool IsFocused){

	static UObject* p_BndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.BndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature");

	struct {
		bool IsFocused;
	} parms;

	parms.IsFocused = IsFocused;

	ProcessEvent(p_BndEvt__BP_ClockExcorcism_BP_CameraFocusComponent_K2Node_ComponentBoundEvent_2_OnFocusUpdated__DelegateSignature, &parms);
}

void ABP_BaseInteraction_C::NonClockWiseMovement(){

	static UObject* p_NonClockWiseMovement = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.NonClockWiseMovement");

	struct {
	} parms;


	ProcessEvent(p_NonClockWiseMovement, &parms);
}

void ABP_BaseInteraction_C::ExecuteUbergraph_BP_ClockExcorcism(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_ClockExcorcism = UObject::FindObject<UFunction>("Function BP_ClockExcorcism.BP_ClockExcorcism_C.ExecuteUbergraph_BP_ClockExcorcism");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_ClockExcorcism, &parms);
}

