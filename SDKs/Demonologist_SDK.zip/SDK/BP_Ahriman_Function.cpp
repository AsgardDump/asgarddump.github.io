#include "SDK.h" 
 
 
bool ABP_Entity_C::GetCanPerformGhostAbility(){

	static UObject* p_GetCanPerformGhostAbility = UObject::FindObject<UFunction>("Function BP_Ahriman.BP_Ahriman_C.GetCanPerformGhostAbility");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetCanPerformGhostAbility, &parms);
	return parms.return_value;
}

void ABP_Entity_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_Ahriman.BP_Ahriman_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABP_Entity_C::recognitionResultReceivedOnRecgonitionReceived(struct FString Result){

	static UObject* p_recognitionResultReceivedOnRecgonitionReceived = UObject::FindObject<UFunction>("Function BP_Ahriman.BP_Ahriman_C.recognitionResultReceivedOnRecgonitionReceived");

	struct {
		struct FString Result;
	} parms;

	parms.Result = Result;

	ProcessEvent(p_recognitionResultReceivedOnRecgonitionReceived, &parms);
}

void ABP_Entity_C::OnAhrimanHearSwear(){

	static UObject* p_OnAhrimanHearSwear = UObject::FindObject<UFunction>("Function BP_Ahriman.BP_Ahriman_C.OnAhrimanHearSwear");

	struct {
	} parms;


	ProcessEvent(p_OnAhrimanHearSwear, &parms);
}

void ABP_Entity_C::ExecuteUbergraph_BP_Ahriman(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_Ahriman = UObject::FindObject<UFunction>("Function BP_Ahriman.BP_Ahriman_C.ExecuteUbergraph_BP_Ahriman");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_Ahriman, &parms);
}

