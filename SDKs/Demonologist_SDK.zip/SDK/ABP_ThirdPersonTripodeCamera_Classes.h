#pragma once 
#include <ABP_ThirdPersonTripodeCamera_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonTripodeCamera.ABP_ThirdPersonTripodeCamera_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonTripodeCamera_C : public UABP_ThirdPersonToolLayer_C
{

}; 



