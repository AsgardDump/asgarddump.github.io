#pragma once 
#include "SDK.h" 
 
 
// Function BP_BansheeNew.BP_BansheeNew_C.ExecuteUbergraph_BP_BansheeNew
// Size: 0x28(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BansheeNew
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct AActor*> CallFunc_GetAllCatchablePlayers_ReturnValue;  // 0x8(0x10)
	struct TArray<struct AActor*> K2Node_Event_UpdatedActors;  // 0x18(0x10)

}; 
// Function BP_BansheeNew.BP_BansheeNew_C.GetAllCatchablePlayers
// Size: 0x5B(Inherited: 0x0) 
struct FGetAllCatchablePlayers
{
	struct TArray<struct AActor*> ReturnValue;  // 0x0(0x10)
	struct TArray<struct AActor*> Buffer;  // 0x10(0x10)
	int32_t Temp_int_Array_Index_Variable;  // 0x20(0x4)
	int32_t Temp_int_Loop_Counter_Variable;  // 0x24(0x4)
	int32_t CallFunc_Add_IntInt_ReturnValue;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)
	struct ABP_OutsideChecker_C* CallFunc_GetOutsideChecker_ReturnValue;  // 0x30(0x8)
	struct TArray<struct ABP_PlayerCharacter_C*> CallFunc_GetAllActorsOfClass_OutActors;  // 0x38(0x10)
	struct ABP_PlayerCharacter_C* CallFunc_Array_Get_Item;  // 0x48(0x8)
	int32_t CallFunc_Array_Length_ReturnValue;  // 0x50(0x4)
	int32_t CallFunc_Array_Add_ReturnValue;  // 0x54(0x4)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // 0x58(0x1)
	char pad_89_1 : 7;  // 0x59(0x1)
	bool CallFunc_DoesPlayerOverlapping_IsOverlapping : 1;  // 0x59(0x1)
	char pad_90_1 : 7;  // 0x5A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x5A(0x1)

}; 
// Function BP_BansheeNew.BP_BansheeNew_C.GetBansheeDistanceBasedSpeedMultiplier
// Size: 0x18(Inherited: 0x0) 
struct FGetBansheeDistanceBasedSpeedMultiplier
{
	double Distance;  // 0x0(0x8)
	double ReturnValue;  // 0x8(0x8)
	double CallFunc_MapRangeClamped_ReturnValue;  // 0x10(0x8)

}; 
// Function BP_BansheeNew.BP_BansheeNew_C.OnPerceptionUpdatedCallback
// Size: 0x10(Inherited: 0x10) 
struct FOnPerceptionUpdatedCallback : public FOnPerceptionUpdatedCallback
{
	struct TArray<struct AActor*> UpdatedActors;  // 0x0(0x10)

}; 
// Function BP_BansheeNew.BP_BansheeNew_C.GetSpiritBoxResponeCue
// Size: 0x28(Inherited: 0x10) 
struct FGetSpiritBoxResponeCue : public FGetSpiritBoxResponeCue
{
	struct ABP_SpiritBox_C* SpiritBoxReference;  // 0x0(0x8)
	struct USoundBase* ReturnValue;  // 0x8(0x8)
	struct USoundBase* CallFunc_GetSpiritBoxResponeCue_ReturnValue;  // 0x10(0x8)
	float CallFunc_GetDistanceTo_ReturnValue;  // 0x18(0x4)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool CallFunc_RandomBoolWithWeight_ReturnValue : 1;  // 0x1C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x1D(0x1)
	double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast;  // 0x20(0x8)

}; 
// Function BP_BansheeNew.BP_BansheeNew_C.GetCanPerformGhostAbility
// Size: 0x1(Inherited: 0x1) 
struct FGetCanPerformGhostAbility : public FGetCanPerformGhostAbility
{
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function BP_BansheeNew.BP_BansheeNew_C.GetHuntSpeed
// Size: 0x100(Inherited: 0x18) 
struct FGetHuntSpeed : public FGetHuntSpeed
{
	double ReturnValue;  // 0x0(0x8)
	double CallFunc_GetHuntSpeed_ReturnValue;  // 0x8(0x8)
	double CallFunc_GetHuntSpeed_ReturnValue_2;  // 0x10(0x8)
	double CallFunc_GetHuntSpeed_ReturnValue_3;  // 0x18(0x8)
	struct UObject* CallFunc_GetTargetSeenCharacter_ReturnValue;  // 0x20(0x8)
	struct AActor* K2Node_DynamicCast_AsActor;  // 0x28(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x30(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // 0x38(0x18)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // 0x50(0x18)
	struct UObject* CallFunc_GetTargetSeenCharacter_ReturnValue_2;  // 0x68(0x8)
	double CallFunc_Vector_Distance_ReturnValue;  // 0x70(0x8)
	struct AActor* K2Node_DynamicCast_AsActor_2;  // 0x78(0x8)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x80(0x1)
	double CallFunc_GetBansheeDistanceBasedSpeedMultiplier_ReturnValue;  // 0x88(0x8)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // 0x90(0x18)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0xA8(0x8)
	struct UObject* CallFunc_GetTargetSeenCharacter_ReturnValue_3;  // 0xB0(0x8)
	char pad_194_1 : 7;  // 0xC2(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0xB8(0x1)
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_4;  // 0xC0(0x18)
	float CallFunc_GetPathLength_PathLength;  // 0xD8(0x4)
	char ENavigationQueryResult CallFunc_GetPathLength_ReturnValue;  // 0xDC(0x1)
	double CallFunc_GetBansheeDistanceBasedSpeedMultiplier_ReturnValue_2;  // 0xE0(0x8)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // 0xE8(0x1)
	char pad_233[7];  // 0xE9(0x7)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0xF0(0x8)
	double CallFunc_GetBansheeDistanceBasedSpeedMultiplier_Distance_ImplicitCast;  // 0xF8(0x8)

}; 
