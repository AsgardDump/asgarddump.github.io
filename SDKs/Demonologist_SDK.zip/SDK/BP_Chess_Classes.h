#pragma once 
#include <BP_Chess_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Chess.BP_Chess_C
// Size: 0x2E0(Inherited: 0x298) 
struct ABP_Chess_C : public ABP_BaseSafeHouseCustomizationActor_C
{
	struct UChildActorComponent* furniture_chair_002_v1_2;  // 0x298(0x8)
	struct UChildActorComponent* furniture_chair_002_v1_3;  // 0x2A0(0x8)
	struct UChildActorComponent* furniture_chair_002_v1_4;  // 0x2A8(0x8)
	struct UChildActorComponent* gadget_chess_032_v1_1;  // 0x2B0(0x8)
	struct UChildActorComponent* cutlery_004_cup_v3_2;  // 0x2B8(0x8)
	struct UChildActorComponent* furniture_chair_002_v1_204;  // 0x2C0(0x8)
	struct UChildActorComponent* carpet_001_v2;  // 0x2C8(0x8)
	struct UChildActorComponent* furniture_table_002_v1_2;  // 0x2D0(0x8)
	struct UChildActorComponent* cutlery_004_cup_v2_80;  // 0x2D8(0x8)

}; 



