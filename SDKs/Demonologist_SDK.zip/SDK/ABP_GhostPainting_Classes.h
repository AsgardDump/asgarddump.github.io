#pragma once 
#include <ABP_GhostPainting_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_GhostPainting.ABP_GhostPainting_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_GhostPainting_C : public UABP_ToolLayerArms_C
{

}; 



