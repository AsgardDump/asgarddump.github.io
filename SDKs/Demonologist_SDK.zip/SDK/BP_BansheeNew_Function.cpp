#include "SDK.h" 
 
 
bool ABP_Entity_C::GetCanPerformGhostAbility(){

	static UObject* p_GetCanPerformGhostAbility = UObject::FindObject<UFunction>("Function BP_BansheeNew.BP_BansheeNew_C.GetCanPerformGhostAbility");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetCanPerformGhostAbility, &parms);
	return parms.return_value;
}

struct USoundBase* ABP_Entity_C::GetSpiritBoxResponeCue(struct ABP_SpiritBox_C* SpiritBoxReference){

	static UObject* p_GetSpiritBoxResponeCue = UObject::FindObject<UFunction>("Function BP_BansheeNew.BP_BansheeNew_C.GetSpiritBoxResponeCue");

	struct {
		struct ABP_SpiritBox_C* SpiritBoxReference;
		struct USoundBase* return_value;
	} parms;

	parms.SpiritBoxReference = SpiritBoxReference;

	ProcessEvent(p_GetSpiritBoxResponeCue, &parms);
	return parms.return_value;
}

double ABP_Entity_C::GetBansheeDistanceBasedSpeedMultiplier(double Distance){

	static UObject* p_GetBansheeDistanceBasedSpeedMultiplier = UObject::FindObject<UFunction>("Function BP_BansheeNew.BP_BansheeNew_C.GetBansheeDistanceBasedSpeedMultiplier");

	struct {
		double Distance;
		double return_value;
	} parms;

	parms.Distance = Distance;

	ProcessEvent(p_GetBansheeDistanceBasedSpeedMultiplier, &parms);
	return parms.return_value;
}

double ABP_Entity_C::GetHuntSpeed(){

	static UObject* p_GetHuntSpeed = UObject::FindObject<UFunction>("Function BP_BansheeNew.BP_BansheeNew_C.GetHuntSpeed");

	struct {
		double return_value;
	} parms;


	ProcessEvent(p_GetHuntSpeed, &parms);
	return parms.return_value;
}

struct TArray<struct AActor*> ABP_Entity_C::GetAllCatchablePlayers(){

	static UObject* p_GetAllCatchablePlayers = UObject::FindObject<UFunction>("Function BP_BansheeNew.BP_BansheeNew_C.GetAllCatchablePlayers");

	struct {
		struct TArray<struct AActor*> return_value;
	} parms;


	ProcessEvent(p_GetAllCatchablePlayers, &parms);
	return parms.return_value;
}

void ABP_Entity_C::OnPerceptionUpdatedCallback(struct TArray<struct AActor*>& UpdatedActors){

	static UObject* p_OnPerceptionUpdatedCallback = UObject::FindObject<UFunction>("Function BP_BansheeNew.BP_BansheeNew_C.OnPerceptionUpdatedCallback");

	struct {
		struct TArray<struct AActor*>& UpdatedActors;
	} parms;

	parms.UpdatedActors = UpdatedActors;

	ProcessEvent(p_OnPerceptionUpdatedCallback, &parms);
}

void ABP_Entity_C::ExecuteUbergraph_BP_BansheeNew(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BansheeNew = UObject::FindObject<UFunction>("Function BP_BansheeNew.BP_BansheeNew_C.ExecuteUbergraph_BP_BansheeNew");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BansheeNew, &parms);
}

