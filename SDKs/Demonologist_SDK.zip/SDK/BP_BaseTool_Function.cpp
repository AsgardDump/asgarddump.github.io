#include "SDK.h" 
 
 
bool ABaseTool::GetIsLookInteractionActive(){

	static UObject* p_GetIsLookInteractionActive = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.GetIsLookInteractionActive");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetIsLookInteractionActive, &parms);
	return parms.return_value;
}

bool ABaseTool::GetVisualActiveCondition(){

	static UObject* p_GetVisualActiveCondition = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.GetVisualActiveCondition");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_GetVisualActiveCondition, &parms);
	return parms.return_value;
}

void ABaseTool::GetAttachmentDetails(bool& IsManualAttachment, struct FTransform& RelativeTransform, struct USceneComponent*& AttachmentComponent, struct FName& SocketName, char& LocationRule, char& RotationRule, char& ScaleRule){

	static UObject* p_GetAttachmentDetails = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.GetAttachmentDetails");

	struct {
		bool& IsManualAttachment;
		struct FTransform& RelativeTransform;
		struct USceneComponent*& AttachmentComponent;
		struct FName& SocketName;
		char& LocationRule;
		char& RotationRule;
		char& ScaleRule;
	} parms;

	parms.IsManualAttachment = IsManualAttachment;
	parms.RelativeTransform = RelativeTransform;
	parms.AttachmentComponent = AttachmentComponent;
	parms.SocketName = SocketName;
	parms.LocationRule = LocationRule;
	parms.RotationRule = RotationRule;
	parms.ScaleRule = ScaleRule;

	ProcessEvent(p_GetAttachmentDetails, &parms);
}

struct TArray<struct FVector> ABaseTool::GetDegreePoints(){

	static UObject* p_GetDegreePoints = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.GetDegreePoints");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetDegreePoints, &parms);
	return parms.return_value;
}

void ABaseTool::OnRep_ToolRuntimeInformation(){

	static UObject* p_OnRep_ToolRuntimeInformation = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.OnRep_ToolRuntimeInformation");

	struct {
	} parms;


	ProcessEvent(p_OnRep_ToolRuntimeInformation, &parms);
}

void ABaseTool::SetToolRuntimeInformation(struct FS_ToolRuntimeInformation ToolRuntimeInformation){

	static UObject* p_SetToolRuntimeInformation = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.SetToolRuntimeInformation");

	struct {
		struct FS_ToolRuntimeInformation ToolRuntimeInformation;
	} parms;

	parms.ToolRuntimeInformation = ToolRuntimeInformation;

	ProcessEvent(p_SetToolRuntimeInformation, &parms);
}

struct APawn* ABaseTool::GetObjectInstigator(){

	static UObject* p_GetObjectInstigator = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.GetObjectInstigator");

	struct {
		struct APawn* return_value;
	} parms;


	ProcessEvent(p_GetObjectInstigator, &parms);
	return parms.return_value;
}

void ABaseTool::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void ABaseTool::SafeDestroyBaseTool(struct AActor* DestroyedActor){

	static UObject* p_SafeDestroyBaseTool = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.SafeDestroyBaseTool");

	struct {
		struct AActor* DestroyedActor;
	} parms;

	parms.DestroyedActor = DestroyedActor;

	ProcessEvent(p_SafeDestroyBaseTool, &parms);
}

void ABaseTool::InteractObject(struct APawn* CharacterReference, struct FName Identity, bool IsExecutedByServer){

	static UObject* p_InteractObject = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.InteractObject");

	struct {
		struct APawn* CharacterReference;
		struct FName Identity;
		bool IsExecutedByServer;
	} parms;

	parms.CharacterReference = CharacterReference;
	parms.Identity = Identity;
	parms.IsExecutedByServer = IsExecutedByServer;

	ProcessEvent(p_InteractObject, &parms);
}

void ABaseTool::OnLooked(struct APlayerController* ControllerReference, struct APawn* PawnReference, double TraceInterval, struct FHitResult Details, bool IsLocallyControlled){

	static UObject* p_OnLooked = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.OnLooked");

	struct {
		struct APlayerController* ControllerReference;
		struct APawn* PawnReference;
		double TraceInterval;
		struct FHitResult Details;
		bool IsLocallyControlled;
	} parms;

	parms.ControllerReference = ControllerReference;
	parms.PawnReference = PawnReference;
	parms.TraceInterval = TraceInterval;
	parms.Details = Details;
	parms.IsLocallyControlled = IsLocallyControlled;

	ProcessEvent(p_OnLooked, &parms);
}

void ABaseTool::BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature(struct APlayerController* ControllerReference, struct APawn* PawnReference, double TraceInterval, struct FHitResult Details, bool IsLocallyControlled){

	static UObject* p_BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature");

	struct {
		struct APlayerController* ControllerReference;
		struct APawn* PawnReference;
		double TraceInterval;
		struct FHitResult Details;
		bool IsLocallyControlled;
	} parms;

	parms.ControllerReference = ControllerReference;
	parms.PawnReference = PawnReference;
	parms.TraceInterval = TraceInterval;
	parms.Details = Details;
	parms.IsLocallyControlled = IsLocallyControlled;

	ProcessEvent(p_BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_3_OnLookedDispatcher__DelegateSignature, &parms);
}

void ABaseTool::BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted){

	static UObject* p_BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature");

	struct {
		struct APawn* CharacterPawn;
		struct FName Identifier;
		bool IsServerExucuted;
	} parms;

	parms.CharacterPawn = CharacterPawn;
	parms.Identifier = Identifier;
	parms.IsServerExucuted = IsServerExucuted;

	ProcessEvent(p_BndEvt__BP_BaseTool_BP_VisualInteractionComponent_K2Node_ComponentBoundEvent_4_InteractObjectDispatcher__DelegateSignature, &parms);
}

void ABaseTool::OnObjectInstigatorUpdatedCallback(struct APawn* OldInstigator, bool IsFirstInit){

	static UObject* p_OnObjectInstigatorUpdatedCallback = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorUpdatedCallback");

	struct {
		struct APawn* OldInstigator;
		bool IsFirstInit;
	} parms;

	parms.OldInstigator = OldInstigator;
	parms.IsFirstInit = IsFirstInit;

	ProcessEvent(p_OnObjectInstigatorUpdatedCallback, &parms);
}

void ABaseTool::OnObjectInstigatorChanged(struct APawn* OldInstigator){

	static UObject* p_OnObjectInstigatorChanged = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorChanged");

	struct {
		struct APawn* OldInstigator;
	} parms;

	parms.OldInstigator = OldInstigator;

	ProcessEvent(p_OnObjectInstigatorChanged, &parms);
}

void ABaseTool::ExecuteUbergraph_BP_BaseTool(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BaseTool = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.ExecuteUbergraph_BP_BaseTool");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BaseTool, &parms);
}

void ABaseTool::OnObjectInstigatorUpdated__DelegateSignature(struct APawn* OldInstigator, bool IsFirstInit){

	static UObject* p_OnObjectInstigatorUpdated__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BaseTool.BP_BaseTool_C.OnObjectInstigatorUpdated__DelegateSignature");

	struct {
		struct APawn* OldInstigator;
		bool IsFirstInit;
	} parms;

	parms.OldInstigator = OldInstigator;
	parms.IsFirstInit = IsFirstInit;

	ProcessEvent(p_OnObjectInstigatorUpdated__DelegateSignature, &parms);
}

