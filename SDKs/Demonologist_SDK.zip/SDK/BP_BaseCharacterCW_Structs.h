#pragma once 
#include "SDK.h" 
 
 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.AddCharacterInput
// Size: 0xA4(Inherited: 0x0) 
struct FAddCharacterInput
{
	char E_MovementDirection MovementDirection;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	double InputScale;  // 0x8(0x8)
	char E_MovementDirection Temp_byte_Variable;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x18(0x18)
	float CallFunc_BreakRotator_Roll;  // 0x30(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x34(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x40(0x18)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x58(0x18)
	struct FVector CallFunc_GetRightVector_ReturnValue;  // 0x70(0x18)
	struct FVector K2Node_Select_Default;  // 0x88(0x18)
	float CallFunc_AddMovementInput_ScaleValue_ImplicitCast;  // 0xA0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveRLGamepad_K2Node_InputAxisEvent_2
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.ExecuteUbergraph_BP_BaseCharacterCW
// Size: 0x1C8(Inherited: 0x0) 
struct FExecuteUbergraph_BP_BaseCharacterCW
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UBP_ShiversGameInstance_C* CallFunc_GetShiversGameInstance_ReturnValue;  // 0x8(0x8)
	struct TScriptInterface<IBPI_ShiversGameInstance_C> K2Node_DynamicCast_AsBPI_Shivers_Game_Instance;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct USaveGame* CallFunc_GetSaveGameByEnum_ReturnValue;  // 0x28(0x8)
	struct FString CallFunc_GetSaveGameByEnum_SlotName;  // 0x30(0x10)
	struct UBP_OptionsSaveGame_C* K2Node_DynamicCast_AsBP_Options_Save_Game;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool CallFunc_IsInvertedYAxis_InvertedYAxis : 1;  // 0x49(0x1)
	char pad_74_1 : 7;  // 0x4A(0x1)
	bool CallFunc_IsInvertedXAxis_InvertedXAxis : 1;  // 0x4A(0x1)
	char pad_75[5];  // 0x4B(0x5)
	double CallFunc_SelectFloat_ReturnValue;  // 0x50(0x8)
	double CallFunc_SelectFloat_ReturnValue_2;  // 0x58(0x8)
	double CallFunc_GetMouseSensitivity_ReturnValue;  // 0x60(0x8)
	struct FVector CallFunc_GetMovementForwardVector_ReturnValue;  // 0x68(0x18)
	float K2Node_InputAxisEvent_AxisValue_10;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct FVector CallFunc_GetMovementRightVector_ReturnValue;  // 0x88(0x18)
	float K2Node_InputAxisEvent_AxisValue_9;  // 0xA0(0x4)
	float K2Node_InputAxisEvent_AxisValue_8;  // 0xA4(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue;  // 0xA8(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_2;  // 0xB0(0x8)
	float K2Node_InputAxisEvent_AxisValue_7;  // 0xB8(0x4)
	char pad_188[4];  // 0xBC(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_3;  // 0xC0(0x8)
	struct FVector CallFunc_GetMovementRightVector_ReturnValue_2;  // 0xC8(0x18)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_4;  // 0xE0(0x8)
	float K2Node_InputAxisEvent_AxisValue_6;  // 0xE8(0x4)
	char pad_236[4];  // 0xEC(0x4)
	struct FVector CallFunc_GetMovementRightVector_ReturnValue_3;  // 0xF0(0x18)
	struct FVector CallFunc_GetMovementForwardVector_ReturnValue_2;  // 0x108(0x18)
	struct FVector CallFunc_GetMovementForwardVector_ReturnValue_3;  // 0x120(0x18)
	float K2Node_InputAxisEvent_AxisValue_5;  // 0x138(0x4)
	float K2Node_InputAxisEvent_AxisValue_4;  // 0x13C(0x4)
	float K2Node_InputAxisEvent_AxisValue_3;  // 0x140(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x144(0x10)
	char pad_340[4];  // 0x154(0x4)
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // 0x158(0x8)
	float K2Node_InputAxisEvent_AxisValue_2;  // 0x160(0x4)
	char pad_356[4];  // 0x164(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_5;  // 0x168(0x8)
	float K2Node_InputAxisEvent_AxisValue;  // 0x170(0x4)
	char pad_372[4];  // 0x174(0x4)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_6;  // 0x178(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_7;  // 0x180(0x8)
	double CallFunc_Multiply_DoubleDouble_ReturnValue_8;  // 0x188(0x8)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast;  // 0x190(0x8)
	float CallFunc_AddControllerYawInput_Val_ImplicitCast;  // 0x198(0x4)
	char pad_412[4];  // 0x19C(0x4)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast_2;  // 0x1A0(0x8)
	float CallFunc_AddControllerPitchInput_Val_ImplicitCast;  // 0x1A8(0x4)
	char pad_428[4];  // 0x1AC(0x4)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast_3;  // 0x1B0(0x8)
	double CallFunc_Multiply_DoubleDouble_A_ImplicitCast_4;  // 0x1B8(0x8)
	float CallFunc_AddControllerYawInput_Val_ImplicitCast_2;  // 0x1C0(0x4)
	float CallFunc_AddControllerPitchInput_Val_ImplicitCast_2;  // 0x1C4(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.GetMovementForwardVector
// Size: 0x70(Inherited: 0x0) 
struct FGetMovementForwardVector
{
	struct FVector ReturnValue;  // 0x0(0x18)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x18(0x18)
	float CallFunc_BreakRotator_Roll;  // 0x30(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x34(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x40(0x18)
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // 0x58(0x18)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookUpGamepad_K2Node_InputAxisEvent_4
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookRightGamepad_K2Node_InputAxisEvent_7
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.GetMovementRightVector
// Size: 0x70(Inherited: 0x0) 
struct FGetMovementRightVector
{
	struct FVector ReturnValue;  // 0x0(0x18)
	struct FRotator CallFunc_GetControlRotation_ReturnValue;  // 0x18(0x18)
	float CallFunc_BreakRotator_Roll;  // 0x30(0x4)
	float CallFunc_BreakRotator_Pitch;  // 0x34(0x4)
	float CallFunc_BreakRotator_Yaw;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // 0x40(0x18)
	struct FVector CallFunc_GetRightVector_ReturnValue;  // 0x58(0x18)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookRight_K2Node_InputAxisEvent_6
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookRight_K2Node_InputAxisEvent_6
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_LookUp_K2Node_InputAxisEvent_5
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_LookUp_K2Node_InputAxisEvent_5
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveBackward_K2Node_InputAxisEvent_11
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveFBGamepad_K2Node_InputAxisEvent_15
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveForward_K2Node_InputAxisEvent_10
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveForward_K2Node_InputAxisEvent_10
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveLeft_K2Node_InputAxisEvent_1
{
	float AxisValue;  // 0x0(0x4)

}; 
// Function BP_BaseCharacterCW.BP_BaseCharacterCW_C.InpAxisEvt_MoveRight_K2Node_InputAxisEvent_14
// Size: 0x4(Inherited: 0x0) 
struct FInpAxisEvt_MoveRight_K2Node_InputAxisEvent_14
{
	float AxisValue;  // 0x0(0x4)

}; 
