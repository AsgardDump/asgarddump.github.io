#pragma once 
#include <A_Tool_Flashlight_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Tool_Flashlight.A_Tool_Flashlight_C
// Size: 0x408(Inherited: 0x3E8) 
struct AA_Tool_Flashlight_C : public AA_Tool_Base_C
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3E8(0x8)
	struct USpotLightComponent* SpotLight;  // 0x3F0(0x8)
	double Min Brightness;  // 0x3F8(0x8)
	double Max Brightness;  // 0x400(0x8)

	void Reset Attack(); // Function A_Tool_Flashlight.A_Tool_Flashlight_C.Reset Attack
	void ReceiveBeginPlay(); // Function A_Tool_Flashlight.A_Tool_Flashlight_C.ReceiveBeginPlay
	void Main Fire(); // Function A_Tool_Flashlight.A_Tool_Flashlight_C.Main Fire
	void ExecuteUbergraph_A_Tool_Flashlight(int32_t EntryPoint); // Function A_Tool_Flashlight.A_Tool_Flashlight_C.ExecuteUbergraph_A_Tool_Flashlight
}; 



