#pragma once 
#include <A_Tool_Unarmed_Structs.h>
 
 
 
// BlueprintGeneratedClass A_Tool_Unarmed.A_Tool_Unarmed_C
// Size: 0x3E8(Inherited: 0x3E8) 
struct AA_Tool_Unarmed_C : public AA_Tool_Base_C
{

}; 



