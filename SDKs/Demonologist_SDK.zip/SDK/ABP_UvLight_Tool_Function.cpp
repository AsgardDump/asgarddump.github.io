#include "SDK.h" 
 
 
void UAnimInstance::AnimGraph(struct FPoseLink& AnimGraph){

	static UObject* p_AnimGraph = UObject::FindObject<UFunction>("Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.AnimGraph");

	struct {
		struct FPoseLink& AnimGraph;
	} parms;

	parms.AnimGraph = AnimGraph;

	ProcessEvent(p_AnimGraph, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_B709192246FFE8DFF94E0CA448C6BDA0(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_B709192246FFE8DFF94E0CA448C6BDA0 = UObject::FindObject<UFunction>("Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_B709192246FFE8DFF94E0CA448C6BDA0");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_B709192246FFE8DFF94E0CA448C6BDA0, &parms);
}

void UAnimInstance::EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_2ED9A1C84B68BE336A30CE9140F9F673(){

	static UObject* p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_2ED9A1C84B68BE336A30CE9140F9F673 = UObject::FindObject<UFunction>("Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_2ED9A1C84B68BE336A30CE9140F9F673");

	struct {
	} parms;


	ProcessEvent(p_EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_UvLight_Tool_AnimGraphNode_TransitionResult_2ED9A1C84B68BE336A30CE9140F9F673, &parms);
}

void UAnimInstance::BlueprintUpdateAnimation(float DeltaTimeX){

	static UObject* p_BlueprintUpdateAnimation = UObject::FindObject<UFunction>("Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.BlueprintUpdateAnimation");

	struct {
		float DeltaTimeX;
	} parms;

	parms.DeltaTimeX = DeltaTimeX;

	ProcessEvent(p_BlueprintUpdateAnimation, &parms);
}

void UAnimInstance::BlueprintBeginPlay(){

	static UObject* p_BlueprintBeginPlay = UObject::FindObject<UFunction>("Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.BlueprintBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_BlueprintBeginPlay, &parms);
}

void UAnimInstance::ExecuteUbergraph_ABP_UvLight_Tool(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_ABP_UvLight_Tool = UObject::FindObject<UFunction>("Function ABP_UvLight_Tool.ABP_UvLight_Tool_C.ExecuteUbergraph_ABP_UvLight_Tool");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_ABP_UvLight_Tool, &parms);
}

