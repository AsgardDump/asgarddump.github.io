#pragma once 
#include "SDK.h" 
 
 
// Function ABP_BaseEntity.ABP_BaseEntity_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_BaseEntity.ABP_BaseEntity_C.BlueprintUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintUpdateAnimation : public FBlueprintUpdateAnimation
{
	float DeltaTimeX;  // 0x0(0x4)

}; 
// Function ABP_BaseEntity.ABP_BaseEntity_C.ExecuteUbergraph_ABP_BaseEntity
// Size: 0x64(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_BaseEntity
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_Greater_DoubleDouble_ReturnValue : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	float K2Node_Event_DeltaTimeX;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct APawn* CallFunc_TryGetPawnOwner_ReturnValue;  // 0x10(0x8)
	struct FVector CallFunc_GetVelocity_ReturnValue;  // 0x18(0x18)
	double CallFunc_VSize_ReturnValue;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue_2 : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue_3 : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)
	double CallFunc_SelectFloat_ReturnValue;  // 0x40(0x8)
	double CallFunc_SelectFloat_ReturnValue_2;  // 0x48(0x8)
	double CallFunc_LessEqual_DoubleDouble_A_ImplicitCast;  // 0x50(0x8)
	double CallFunc_Greater_DoubleDouble_A_ImplicitCast;  // 0x58(0x8)
	float K2Node_VariableSet_SpeedGate_ImplicitCast;  // 0x60(0x4)

}; 
// ScriptStruct ABP_BaseEntity.ABP_BaseEntity_C.AnimBlueprintGeneratedConstantData
// Size: 0x138(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_82;  // 0x4(0x8)
	struct FName __NameProperty_83;  // 0xC(0x8)
	int32_t __IntProperty_84;  // 0x14(0x4)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool __BoolProperty_85 : 1;  // 0x18(0x1)
	char pad_25[3];  // 0x19(0x3)
	float __FloatProperty_86;  // 0x1C(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_87;  // 0x20(0x2C)
	float __FloatProperty_88;  // 0x4C(0x4)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool __BoolProperty_89 : 1;  // 0x50(0x1)
	uint8_t  __EnumProperty_90;  // 0x51(0x1)
	char EAnimGroupRole __ByteProperty_91;  // 0x52(0x1)
	char pad_83[1];  // 0x53(0x1)
	struct FName __NameProperty_92;  // 0x54(0x8)
	struct FName __NameProperty_93;  // 0x5C(0x8)
	int32_t __IntProperty_94;  // 0x64(0x4)
	struct FAnimNodeFunctionRef __StructProperty_95;  // 0x68(0x20)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x88(0x80)
	struct FAnimSubsystem_BlendSpaceGraph AnimBlueprintExtension_BlendSpaceGraph;  // 0x108(0x18)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x120(0x18)

}; 
