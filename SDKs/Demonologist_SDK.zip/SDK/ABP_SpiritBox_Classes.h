#pragma once 
#include <ABP_SpiritBox_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_SpiritBox.ABP_SpiritBox_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_SpiritBox_C : public UABP_ToolLayerArms_C
{

}; 



