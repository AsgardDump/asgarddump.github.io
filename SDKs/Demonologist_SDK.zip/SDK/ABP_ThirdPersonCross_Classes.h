#pragma once 
#include <ABP_ThirdPersonCross_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_ThirdPersonCross.ABP_ThirdPersonCross_C
// Size: 0xB90(Inherited: 0xB90) 
struct UABP_ThirdPersonCross_C : public UABP_ThirdPersonToolLayer_C
{

}; 



