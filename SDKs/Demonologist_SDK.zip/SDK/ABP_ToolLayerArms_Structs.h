#pragma once 
#include "SDK.h" 
 
 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.BlueprintThreadSafeUpdateAnimation
// Size: 0x4(Inherited: 0x4) 
struct FBlueprintThreadSafeUpdateAnimation : public FBlueprintThreadSafeUpdateAnimation
{
	float DeltaTime;  // 0x0(0x4)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.IdleState
// Size: 0x10(Inherited: 0x0) 
struct FIdleState
{
	struct FPoseLink IdleState;  // 0x0(0x10)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.GetMainAnimInstance
// Size: 0x11(Inherited: 0x0) 
struct FGetMainAnimInstance
{
	struct UABP_Base_Arms_C* ReturnValue;  // 0x0(0x8)
	struct UABP_Base_Arms_C* K2Node_DynamicCast_AsABP_Base_Arms;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x10(0x1)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.AnimGraph
// Size: 0x10(Inherited: 0x0) 
struct FAnimGraph
{
	struct FPoseLink AnimGraph;  // 0x0(0x10)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.CanPlayBreakIdle
// Size: 0x1B(Inherited: 0x0) 
struct FCanPlayBreakIdle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UABP_Base_Arms_C* CallFunc_GetMainAnimInstance_ReturnValue;  // 0x8(0x8)
	struct UABP_Base_Arms_C* CallFunc_GetMainAnimInstance_ReturnValue_2;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool CallFunc_Not_PreBool_ReturnValue_2 : 1;  // 0x19(0x1)
	char pad_26_1 : 7;  // 0x1A(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x1A(0x1)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleAnimationUpdate
// Size: 0x60(Inherited: 0x0) 
struct FOnIdleAnimationUpdate
{
	struct FAnimUpdateContext Context;  // 0x0(0x10)
	struct FAnimNodeReference Node;  // 0x10(0x10)
	struct UABP_Base_Arms_C* CallFunc_GetMainAnimInstance_ReturnValue;  // 0x20(0x8)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool Temp_bool_Variable : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)
	struct UAnimSequenceBase* K2Node_Select_Default;  // 0x30(0x8)
	struct FSequencePlayerReference CallFunc_ConvertToSequencePlayerPure_SequencePlayer;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool CallFunc_ConvertToSequencePlayerPure_Result : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FSequencePlayerReference CallFunc_SetSequenceWithInertialBlending_ReturnValue;  // 0x50(0x10)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ExecuteUbergraph_ABP_ToolLayerArms
// Size: 0x7(Inherited: 0x0) 
struct FExecuteUbergraph_ABP_ToolLayerArms
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool CallFunc_CanPlayBreakIdle_ReturnValue : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool CallFunc_LessEqual_DoubleDouble_ReturnValue : 1;  // 0x5(0x1)
	char pad_6_1 : 7;  // 0x6(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x6(0x1)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleBecomeRelevant
// Size: 0x20(Inherited: 0x0) 
struct FOnIdleBecomeRelevant
{
	struct FAnimUpdateContext Context;  // 0x0(0x10)
	struct FAnimNodeReference Node;  // 0x10(0x10)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnIdleUpdate
// Size: 0x48(Inherited: 0x0) 
struct FOnIdleUpdate
{
	struct FAnimUpdateContext Context;  // 0x0(0x10)
	struct FAnimNodeReference Node;  // 0x10(0x10)
	float CallFunc_GetDeltaTime_ReturnValue;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct FAnimationStateResultReference CallFunc_ConvertToAnimationStateResultPure_AnimationState;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_ConvertToAnimationStateResultPure_Result : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool CallFunc_IsStateBlendingOut_ReturnValue : 1;  // 0x39(0x1)
	char pad_58_1 : 7;  // 0x3A(0x1)
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // 0x3A(0x1)
	char pad_59_1 : 7;  // 0x3B(0x1)
	bool CallFunc_BooleanAND_ReturnValue : 1;  // 0x3B(0x1)
	char pad_60[4];  // 0x3C(0x4)
	double CallFunc_ProcessIdleBreakTransitionLogic_DeltaTime_ImplicitCast;  // 0x40(0x8)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.OnWalkingAnimationUpdated
// Size: 0x60(Inherited: 0x0) 
struct FOnWalkingAnimationUpdated
{
	struct FAnimUpdateContext Context;  // 0x0(0x10)
	struct FAnimNodeReference Node;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Temp_bool_Variable : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct FSequencePlayerReference CallFunc_ConvertToSequencePlayerPure_SequencePlayer;  // 0x28(0x10)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool CallFunc_ConvertToSequencePlayerPure_Result : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UABP_Base_Arms_C* CallFunc_GetMainAnimInstance_ReturnValue;  // 0x40(0x8)
	struct UAnimSequenceBase* K2Node_Select_Default;  // 0x48(0x8)
	struct FSequencePlayerReference CallFunc_SetSequenceWithInertialBlending_ReturnValue;  // 0x50(0x10)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.ProcessIdleBreakTransitionLogic
// Size: 0x11(Inherited: 0x0) 
struct FProcessIdleBreakTransitionLogic
{
	double DeltaTime;  // 0x0(0x8)
	double CallFunc_Subtract_DoubleDouble_ReturnValue;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool CallFunc_CanPlayBreakIdle_ReturnValue : 1;  // 0x10(0x1)

}; 
// Function ABP_ToolLayerArms.ABP_ToolLayerArms_C.WalkingState
// Size: 0x10(Inherited: 0x0) 
struct FWalkingState
{
	struct FPoseLink WalkingState;  // 0x0(0x10)

}; 
// ScriptStruct ABP_ToolLayerArms.ABP_ToolLayerArms_C.AnimBlueprintGeneratedConstantData
// Size: 0x1C0(Inherited: 0x1) 
struct FAnimBlueprintGeneratedConstantData : public FAnimBlueprintConstantData
{
	char pad_1[3];  // 0x1(0x3)
	struct FName __NameProperty_57;  // 0x4(0x8)
	struct FName __NameProperty_58;  // 0xC(0x8)
	int32_t __IntProperty_59;  // 0x14(0x4)
	struct FAnimNodeFunctionRef __StructProperty_60;  // 0x18(0x20)
	struct FAnimNodeFunctionRef __StructProperty_61;  // 0x38(0x20)
	struct FAnimNodeFunctionRef __StructProperty_62;  // 0x58(0x20)
	struct FName __NameProperty_63;  // 0x78(0x8)
	int32_t __IntProperty_64;  // 0x80(0x4)
	struct FName __NameProperty_65;  // 0x84(0x8)
	char pad_140[4];  // 0x8C(0x4)
	struct FAnimNodeFunctionRef __StructProperty_66;  // 0x90(0x20)
	char pad_176_1 : 7;  // 0xB0(0x1)
	bool __BoolProperty_67 : 1;  // 0xB0(0x1)
	char pad_177[3];  // 0xB1(0x3)
	float __FloatProperty_68;  // 0xB4(0x4)
	struct FInputScaleBiasClampConstants __StructProperty_69;  // 0xB8(0x2C)
	float __FloatProperty_70;  // 0xE4(0x4)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool __BoolProperty_71 : 1;  // 0xE8(0x1)
	uint8_t  __EnumProperty_72;  // 0xE9(0x1)
	char EAnimGroupRole __ByteProperty_73;  // 0xEA(0x1)
	char pad_235[5];  // 0xEB(0x5)
	struct FAnimNodeFunctionRef __StructProperty_74;  // 0xF0(0x20)
	struct FName __NameProperty_75;  // 0x110(0x8)
	struct FName __NameProperty_76;  // 0x118(0x8)
	struct FAnimSubsystem_PropertyAccess AnimBlueprintExtension_PropertyAccess;  // 0x120(0x80)
	struct FAnimSubsystem AnimBlueprintExtension_NodeRelevancy;  // 0x1A0(0x8)
	struct FAnimSubsystem_Base AnimBlueprintExtension_Base;  // 0x1A8(0x18)

}; 
// ScriptStruct ABP_ToolLayerArms.ABP_ToolLayerArms_C.AnimBlueprintGeneratedMutableData
// Size: 0x8(Inherited: 0x1) 
struct FAnimBlueprintGeneratedMutableData : public FAnimBlueprintMutableData
{
	char pad_1[3];  // 0x1(0x3)
	float __FloatProperty;  // 0x4(0x4)

}; 
