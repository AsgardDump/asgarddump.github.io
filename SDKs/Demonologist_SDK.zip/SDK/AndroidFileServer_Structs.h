#pragma once 
#include "SDK.h" 
 
 
// Function AndroidFileServer.AndroidFileServerBPLibrary.IsFileServerRunning
// Size: 0x1(Inherited: 0x0) 
struct FIsFileServerRunning
{
	char EAFSActiveType ReturnValue;  // 0x0(0x1)

}; 
// Function AndroidFileServer.AndroidFileServerBPLibrary.StartFileServer
// Size: 0xC(Inherited: 0x0) 
struct FStartFileServer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUSB : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bNetwork : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t Port;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function AndroidFileServer.AndroidFileServerBPLibrary.StopFileServer
// Size: 0x3(Inherited: 0x0) 
struct FStopFileServer
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUSB : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bNetwork : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool ReturnValue : 1;  // 0x2(0x1)

}; 
