#pragma once 
#include <ABP_BlacksmithHammer_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_BlacksmithHammer.ABP_BlacksmithHammer_C
// Size: 0x720(Inherited: 0x720) 
struct UABP_BlacksmithHammer_C : public UABP_ToolLayerArms_C
{

}; 



