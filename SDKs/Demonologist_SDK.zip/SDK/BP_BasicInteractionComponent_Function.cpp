#include "SDK.h" 
 
 
bool UBP_VisualInteractionComponent_C::IsInteractable(){

	static UObject* p_IsInteractable = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.IsInteractable");

	struct {
		bool return_value;
	} parms;


	ProcessEvent(p_IsInteractable, &parms);
	return parms.return_value;
}

bool UBP_VisualInteractionComponent_C::CanPlayerInteract(struct APawn* PawnReference, struct FName Identifier){

	static UObject* p_CanPlayerInteract = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.CanPlayerInteract");

	struct {
		struct APawn* PawnReference;
		struct FName Identifier;
		bool return_value;
	} parms;

	parms.PawnReference = PawnReference;
	parms.Identifier = Identifier;

	ProcessEvent(p_CanPlayerInteract, &parms);
	return parms.return_value;
}

void UBP_VisualInteractionComponent_C::LookEventSuccessful(struct APawn* Instigator){

	static UObject* p_LookEventSuccessful = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.LookEventSuccessful");

	struct {
		struct APawn* Instigator;
	} parms;

	parms.Instigator = Instigator;

	ProcessEvent(p_LookEventSuccessful, &parms);
}

double UBP_VisualInteractionComponent_C::GetDegreeBetweenTwoPoints(struct UObject* CharacterReference, struct FVector Location){

	static UObject* p_GetDegreeBetweenTwoPoints = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetDegreeBetweenTwoPoints");

	struct {
		struct UObject* CharacterReference;
		struct FVector Location;
		double return_value;
	} parms;

	parms.CharacterReference = CharacterReference;
	parms.Location = Location;

	ProcessEvent(p_GetDegreeBetweenTwoPoints, &parms);
	return parms.return_value;
}

struct TArray<struct FVector> UBP_VisualInteractionComponent_C::GetDegreePoints(){

	static UObject* p_GetDegreePoints = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetDegreePoints");

	struct {
		struct TArray<struct FVector> return_value;
	} parms;


	ProcessEvent(p_GetDegreePoints, &parms);
	return parms.return_value;
}

bool UBP_VisualInteractionComponent_C::IsDegreeConditionMatch(struct APawn* PawnReference){

	static UObject* p_IsDegreeConditionMatch = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.IsDegreeConditionMatch");

	struct {
		struct APawn* PawnReference;
		bool return_value;
	} parms;

	parms.PawnReference = PawnReference;

	ProcessEvent(p_IsDegreeConditionMatch, &parms);
	return parms.return_value;
}

struct UBP_EventBoxComponent_C* UBP_VisualInteractionComponent_C::GetEventboxComponent(){

	static UObject* p_GetEventboxComponent = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.GetEventboxComponent");

	struct {
		struct UBP_EventBoxComponent_C* return_value;
	} parms;


	ProcessEvent(p_GetEventboxComponent, &parms);
	return parms.return_value;
}

void UBP_VisualInteractionComponent_C::InitializeBasicInteraction(){

	static UObject* p_InitializeBasicInteraction = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.InitializeBasicInteraction");

	struct {
	} parms;


	ProcessEvent(p_InitializeBasicInteraction, &parms);
}

bool UBP_VisualInteractionComponent_C::EventBoxInteractionCondition(struct APawn* Instigator, bool BypassAuthorization){

	static UObject* p_EventBoxInteractionCondition = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.EventBoxInteractionCondition");

	struct {
		struct APawn* Instigator;
		bool BypassAuthorization;
		bool return_value;
	} parms;

	parms.Instigator = Instigator;
	parms.BypassAuthorization = BypassAuthorization;

	ProcessEvent(p_EventBoxInteractionCondition, &parms);
	return parms.return_value;
}

void UBP_VisualInteractionComponent_C::RequestInteraction(struct APawn* SequenceInstigator){

	static UObject* p_RequestInteraction = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.RequestInteraction");

	struct {
		struct APawn* SequenceInstigator;
	} parms;

	parms.SequenceInstigator = SequenceInstigator;

	ProcessEvent(p_RequestInteraction, &parms);
}

bool UBP_VisualInteractionComponent_C::LookInteractionCondition(struct APawn* PawnReference, bool BypassAuthorization){

	static UObject* p_LookInteractionCondition = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.LookInteractionCondition");

	struct {
		struct APawn* PawnReference;
		bool BypassAuthorization;
		bool return_value;
	} parms;

	parms.PawnReference = PawnReference;
	parms.BypassAuthorization = BypassAuthorization;

	ProcessEvent(p_LookInteractionCondition, &parms);
	return parms.return_value;
}

void UBP_VisualInteractionComponent_C::InteractObject(struct APawn* CharacterPawn, struct FName Identifier, bool IsServerExucuted){

	static UObject* p_InteractObject = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.InteractObject");

	struct {
		struct APawn* CharacterPawn;
		struct FName Identifier;
		bool IsServerExucuted;
	} parms;

	parms.CharacterPawn = CharacterPawn;
	parms.Identifier = Identifier;
	parms.IsServerExucuted = IsServerExucuted;

	ProcessEvent(p_InteractObject, &parms);
}

void UBP_VisualInteractionComponent_C::OnLooked(struct APlayerController* ControllerReference, struct APawn* PawnReference, double TraceInterval, struct FHitResult Details, bool IsLocallyControlled){

	static UObject* p_OnLooked = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnLooked");

	struct {
		struct APlayerController* ControllerReference;
		struct APawn* PawnReference;
		double TraceInterval;
		struct FHitResult Details;
		bool IsLocallyControlled;
	} parms;

	parms.ControllerReference = ControllerReference;
	parms.PawnReference = PawnReference;
	parms.TraceInterval = TraceInterval;
	parms.Details = Details;
	parms.IsLocallyControlled = IsLocallyControlled;

	ProcessEvent(p_OnLooked, &parms);
}

void UBP_VisualInteractionComponent_C::OnInteractionBoxesTriggered(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult){

	static UObject* p_OnInteractionBoxesTriggered = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnInteractionBoxesTriggered");

	struct {
		struct UPrimitiveComponent* OverlappedComponent;
		struct AActor* OtherActor;
		struct UPrimitiveComponent* OtherComp;
		int32_t OtherBodyIndex;
		bool bFromSweep;
		struct FHitResult& SweepResult;
	} parms;

	parms.OverlappedComponent = OverlappedComponent;
	parms.OtherActor = OtherActor;
	parms.OtherComp = OtherComp;
	parms.OtherBodyIndex = OtherBodyIndex;
	parms.bFromSweep = bFromSweep;
	parms.SweepResult = SweepResult;

	ProcessEvent(p_OnInteractionBoxesTriggered, &parms);
}

void UBP_VisualInteractionComponent_C::ReceiveBeginPlay(){

	static UObject* p_ReceiveBeginPlay = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.ReceiveBeginPlay");

	struct {
	} parms;


	ProcessEvent(p_ReceiveBeginPlay, &parms);
}

void UBP_VisualInteractionComponent_C::ExecuteUbergraph_BP_BasicInteractionComponent(int32_t EntryPoint){

	static UObject* p_ExecuteUbergraph_BP_BasicInteractionComponent = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.ExecuteUbergraph_BP_BasicInteractionComponent");

	struct {
		int32_t EntryPoint;
	} parms;

	parms.EntryPoint = EntryPoint;

	ProcessEvent(p_ExecuteUbergraph_BP_BasicInteractionComponent, &parms);
}

void UBP_VisualInteractionComponent_C::OnInteractionTriggered__DelegateSignature(char E_InteractionMethods InteractionMethod, struct APawn* InstigatorReference){

	static UObject* p_OnInteractionTriggered__DelegateSignature = UObject::FindObject<UFunction>("Function BP_BasicInteractionComponent.BP_BasicInteractionComponent_C.OnInteractionTriggered__DelegateSignature");

	struct {
		char E_InteractionMethods InteractionMethod;
		struct APawn* InstigatorReference;
	} parms;

	parms.InteractionMethod = InteractionMethod;
	parms.InstigatorReference = InstigatorReference;

	ProcessEvent(p_OnInteractionTriggered__DelegateSignature, &parms);
}

