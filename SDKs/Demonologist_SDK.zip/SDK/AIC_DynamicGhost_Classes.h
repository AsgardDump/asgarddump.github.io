#pragma once 
#include <AIC_DynamicGhost_Structs.h>
 
 
 
// BlueprintGeneratedClass AIC_DynamicGhost.AIC_DynamicGhost_C
// Size: 0x3C0(Inherited: 0x3B8) 
struct AAIC_DynamicGhost_C : public AAIController
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x3B8(0x8)

	void ReceiveBeginPlay(); // Function AIC_DynamicGhost.AIC_DynamicGhost_C.ReceiveBeginPlay
	void ExecuteUbergraph_AIC_DynamicGhost(int32_t EntryPoint); // Function AIC_DynamicGhost.AIC_DynamicGhost_C.ExecuteUbergraph_AIC_DynamicGhost
}; 



