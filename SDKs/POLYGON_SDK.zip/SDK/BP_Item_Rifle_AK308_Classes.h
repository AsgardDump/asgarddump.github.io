#pragma once 
#include <BP_Item_Rifle_AK308_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Rifle_AK308.BP_Item_Rifle_AK308_C
// Size: 0x760(Inherited: 0x750) 
struct ABP_Item_Rifle_AK308_C : public AItem_Gun_Rifle
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x750(0x8)
	struct UStaticMeshComponent* IronSight;  // 0x758(0x8)

	void SetSight(); // Function BP_Item_Rifle_AK308.BP_Item_Rifle_AK308_C.SetSight
	void ReceiveBeginPlay(); // Function BP_Item_Rifle_AK308.BP_Item_Rifle_AK308_C.ReceiveBeginPlay
	void OnSetGunModules_Event(); // Function BP_Item_Rifle_AK308.BP_Item_Rifle_AK308_C.OnSetGunModules_Event
	void ExecuteUbergraph_BP_Item_Rifle_AK308(int32_t EntryPoint); // Function BP_Item_Rifle_AK308.BP_Item_Rifle_AK308_C.ExecuteUbergraph_BP_Item_Rifle_AK308
}; 



