#pragma once 
#include <AutoSettingsInput_Structs.h>
 
 
 
// Class AutoSettingsInput.AutoSettingsInputSubsystem
// Size: 0x38(Inherited: 0x30) 
struct UAutoSettingsInputSubsystem : public UGameInstanceSubsystem
{
	char pad_48[8];  // 0x30(0x8)

}; 



// Class AutoSettingsInput.AxisMapping
// Size: 0x2C8(Inherited: 0x2B0) 
struct UAxisMapping : public UInputMapping
{
	struct FName AxisName;  // 0x2B0(0x8)
	float Scale;  // 0x2B8(0x4)
	char pad_700[4];  // 0x2BC(0x4)
	struct UAxisLabel* AxisLabel;  // 0x2C0(0x8)

}; 



// Class AutoSettingsInput.InputMapping
// Size: 0x2B0(Inherited: 0x278) 
struct UInputMapping : public UUserWidget
{
	int32_t MappingGroup;  // 0x278(0x4)
	struct FGameplayTag KeyGroup;  // 0x27C(0x8)
	char pad_644[4];  // 0x284(0x4)
	struct FGameplayTagContainer IconTags;  // 0x288(0x20)
	struct UBindCaptureButton* BindCaptureButton;  // 0x2A8(0x8)

	void UpdateMapping(); // Function AutoSettingsInput.InputMapping.UpdateMapping
	void UpdateLabel(); // Function AutoSettingsInput.InputMapping.UpdateLabel
	void ChordCaptured(struct FCapturedInput CapturedInput); // Function AutoSettingsInput.InputMapping.ChordCaptured
	void BindChord(struct FCapturedInput CapturedInput); // Function AutoSettingsInput.InputMapping.BindChord
}; 



// Class AutoSettingsInput.InputLabel
// Size: 0x2A8(Inherited: 0x278) 
struct UInputLabel : public UUserWidget
{
	int32_t MappingGroup;  // 0x278(0x4)
	struct FGameplayTag KeyGroup;  // 0x27C(0x8)
	char pad_644_1 : 7;  // 0x284(0x1)
	bool bUsePlayerKeyGroup : 1;  // 0x284(0x1)
	char pad_645[3];  // 0x285(0x3)
	struct FGameplayTagContainer IconTags;  // 0x288(0x20)

	void UpdateLabel(); // Function AutoSettingsInput.InputLabel.UpdateLabel
	void MappingsChanged(struct APlayerController* Player); // Function AutoSettingsInput.InputLabel.MappingsChanged
}; 



// Class AutoSettingsInput.ActionLabel
// Size: 0x310(Inherited: 0x2A8) 
struct UActionLabel : public UInputLabel
{
	struct FName ActionName;  // 0x2A8(0x8)
	UKeyLabel* KeyLabelWidgetClass;  // 0x2B0(0x8)
	UWidget* KeySeparatorWidgetClass;  // 0x2B8(0x8)
	struct UPanelWidget* KeyContainer;  // 0x2C0(0x8)
	struct UKeyLabel* PrimaryKeyLabel;  // 0x2C8(0x8)
	struct UKeyLabel* ShiftLabel;  // 0x2D0(0x8)
	struct UKeyLabel* CtrlLabel;  // 0x2D8(0x8)
	struct UKeyLabel* AltLabel;  // 0x2E0(0x8)
	struct UKeyLabel* CmdLabel;  // 0x2E8(0x8)
	struct UWidget* ShiftSeparator;  // 0x2F0(0x8)
	struct UWidget* CtrlSeparator;  // 0x2F8(0x8)
	struct UWidget* AltSeparator;  // 0x300(0x8)
	struct UWidget* CmdSeparator;  // 0x308(0x8)

}; 



// Class AutoSettingsInput.BindCaptureButton
// Size: 0x2A8(Inherited: 0x278) 
struct UBindCaptureButton : public UUserWidget
{
	struct FGameplayTag KeyGroup;  // 0x278(0x8)
	UBindCapturePrompt* BindCapturePromptClass;  // 0x280(0x8)
	int32_t CapturePromptZOrder;  // 0x288(0x4)
	char pad_652[20];  // 0x28C(0x14)
	struct UBindCapturePrompt* Prompt;  // 0x2A0(0x8)

	struct UBindCapturePrompt* StartCapture(); // Function AutoSettingsInput.BindCaptureButton.StartCapture
	void InitializePrompt(struct UBindCapturePrompt* PromptWidget); // Function AutoSettingsInput.BindCaptureButton.InitializePrompt
	void ChordCaptured(struct FCapturedInput CapturedInput); // Function AutoSettingsInput.BindCaptureButton.ChordCaptured
}; 



// Class AutoSettingsInput.ActionMapping
// Size: 0x2C0(Inherited: 0x2B0) 
struct UActionMapping : public UInputMapping
{
	struct FName ActionName;  // 0x2B0(0x8)
	struct UActionLabel* ActionLabel;  // 0x2B8(0x8)

}; 



// Class AutoSettingsInput.AutoSettingsInputConfig
// Size: 0x188(Inherited: 0x38) 
struct UAutoSettingsInputConfig : public UDeveloperSettings
{
	char pad_56[8];  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bAutoInitializePlayerInputOverrides : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool AllowModifierKeys : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct FText ShiftModifierOverrideText;  // 0x48(0x18)
	struct FText CtrlModifierOverrideText;  // 0x60(0x18)
	struct FText AltModifierOverrideText;  // 0x78(0x18)
	struct FText CmdModifierOverrideText;  // 0x90(0x18)
	struct TArray<struct FInputMappingPreset> InputPresets;  // 0xA8(0x10)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool AllowMultipleBindingsPerKey : 1;  // 0xB8(0x1)
	char pad_185[7];  // 0xB9(0x7)
	struct TArray<struct FMappingGroupLink> MappingGroupLinks;  // 0xC0(0x10)
	struct TArray<struct FName> PreservedActions;  // 0xD0(0x10)
	struct TArray<struct FName> PreservedAxes;  // 0xE0(0x10)
	struct TArray<struct FKeyIconSet> KeyIconSets;  // 0xF0(0x10)
	struct TArray<struct FKeyFriendlyName> KeyFriendlyNames;  // 0x100(0x10)
	struct TArray<struct FKeyGroup> KeyGroups;  // 0x110(0x10)
	struct TArray<struct FKey> AllowedKeys;  // 0x120(0x10)
	struct TArray<struct FKey> DisallowedKeys;  // 0x130(0x10)
	struct TArray<struct FKey> BindingEscapeKeys;  // 0x140(0x10)
	float MouseMoveCaptureDistance;  // 0x150(0x4)
	char pad_340[4];  // 0x154(0x4)
	struct TArray<struct FAxisAssociation> AxisAssociations;  // 0x158(0x10)
	struct TArray<struct FName> BlacklistedActions;  // 0x168(0x10)
	struct TArray<struct FName> BlacklistedAxes;  // 0x178(0x10)

}; 



// Class AutoSettingsInput.AutoSettingsInputConfigInterface
// Size: 0x28(Inherited: 0x28) 
struct UAutoSettingsInputConfigInterface : public UInterface
{

}; 



// Class AutoSettingsInput.AutoSettingsInputProjectConfig
// Size: 0x188(Inherited: 0x188) 
struct UAutoSettingsInputProjectConfig : public UAutoSettingsInputConfig
{

	struct TArray<struct UTexture*> LoadKeyIcons(struct FGameplayTagContainer KeyIconTags); // Function AutoSettingsInput.AutoSettingsInputProjectConfig.LoadKeyIcons
	struct FGameplayTag GetKeyGroupStatic(struct FKey Key); // Function AutoSettingsInput.AutoSettingsInputProjectConfig.GetKeyGroupStatic
	struct FText GetKeyFriendlyNameStatic(struct FKey Key); // Function AutoSettingsInput.AutoSettingsInputProjectConfig.GetKeyFriendlyNameStatic
}; 



// Class AutoSettingsInput.AutoSettingsInputValidationSubsystem
// Size: 0x30(Inherited: 0x30) 
struct UAutoSettingsInputValidationSubsystem : public UGameInstanceSubsystem
{

}; 



// Class AutoSettingsInput.AutoSettingsPlayer
// Size: 0x28(Inherited: 0x28) 
struct UAutoSettingsPlayer : public UInterface
{

	void SaveInputMappings(struct FPlayerInputMappings InputMappings); // Function AutoSettingsInput.AutoSettingsPlayer.SaveInputMappings
	struct FString GetUniquePlayerIdentifier(); // Function AutoSettingsInput.AutoSettingsPlayer.GetUniquePlayerIdentifier
	bool GetInputMappings(struct FPlayerInputMappings& InputMappings); // Function AutoSettingsInput.AutoSettingsPlayer.GetInputMappings
	struct FInputMappingPreset GetDefaultInputMappingPreset(); // Function AutoSettingsInput.AutoSettingsPlayer.GetDefaultInputMappingPreset
}; 



// Class AutoSettingsInput.AxisLabel
// Size: 0x2C0(Inherited: 0x2A8) 
struct UAxisLabel : public UInputLabel
{
	struct FName AxisName;  // 0x2A8(0x8)
	float Scale;  // 0x2B0(0x4)
	char pad_692[4];  // 0x2B4(0x4)
	struct UKeyLabel* KeyLabel;  // 0x2B8(0x8)

}; 



// Class AutoSettingsInput.BindCapturePrompt
// Size: 0x2E0(Inherited: 0x278) 
struct UBindCapturePrompt : public UUserWidget
{
	char pad_632_1 : 7;  // 0x278(0x1)
	bool bIgnoreGameViewportInputWhileCapturing : 1;  // 0x278(0x1)
	char pad_633_1 : 7;  // 0x279(0x1)
	bool bRestrictKeyGroup : 1;  // 0x279(0x1)
	uint8_t  CaptureMode;  // 0x27A(0x1)
	char pad_635[1];  // 0x27B(0x1)
	struct FGameplayTag KeyGroup;  // 0x27C(0x8)
	char pad_644[4];  // 0x284(0x4)
	struct FMulticastInlineDelegate OnChordCaptured;  // 0x288(0x10)
	struct FMulticastInlineDelegate OnChordRejected;  // 0x298(0x10)
	struct FMulticastInlineDelegate OnCapturePromptClosed;  // 0x2A8(0x10)
	struct TArray<struct FKey> KeysDown;  // 0x2B8(0x10)
	char pad_712_1 : 7;  // 0x2C8(0x1)
	bool PreviousIgnoreInput : 1;  // 0x2C8(0x1)
	char pad_713[7];  // 0x2C9(0x7)
	struct FVector2D AccumulatedMouseDelta;  // 0x2D0(0x10)

	bool IsKeyAllowed(struct FKey PrimaryKey); // Function AutoSettingsInput.BindCapturePrompt.IsKeyAllowed
	struct FGameplayTag GetKeyGroup(); // Function AutoSettingsInput.BindCapturePrompt.GetKeyGroup
	void Cancel(); // Function AutoSettingsInput.BindCapturePrompt.Cancel
}; 



// Class AutoSettingsInput.GlobalKeyIconTagManager
// Size: 0x58(Inherited: 0x28) 
struct UGlobalKeyIconTagManager : public UObject
{
	struct FMulticastInlineDelegate OnGlobalKeyIconTagsModified;  // 0x28(0x10)
	struct FGameplayTagContainer GlobalKeyIconTags;  // 0x38(0x20)

	void SetGlobalKeyIconTags(struct FGameplayTagContainer InGlobalIconTags); // Function AutoSettingsInput.GlobalKeyIconTagManager.SetGlobalKeyIconTags
	struct UTexture* GetIconForKey(struct FKey InKey, struct FGameplayTagContainer IconTags, float AxisScale); // Function AutoSettingsInput.GlobalKeyIconTagManager.GetIconForKey
}; 



// Class AutoSettingsInput.InputMappingManager
// Size: 0x60(Inherited: 0x30) 
struct UInputMappingManager : public UEngineSubsystem
{
	struct FMulticastInlineDelegate OnMappingsChanged;  // 0x30(0x10)
	struct TArray<struct FPlayerInputMappings> PlayerInputOverrides;  // 0x40(0x10)
	struct TArray<struct APlayerController*> RegisteredPlayerControllers;  // 0x50(0x10)

	void SetPlayerKeyGroupStatic(struct APlayerController* Player, struct FGameplayTag KeyGroup); // Function AutoSettingsInput.InputMappingManager.SetPlayerKeyGroupStatic
	void SetPlayerInputPresetStatic(struct APlayerController* Player, struct FInputMappingPreset Preset); // Function AutoSettingsInput.InputMappingManager.SetPlayerInputPresetStatic
	void SetPlayerInputPresetByTag(struct APlayerController* Player, struct FGameplayTag PresetTag); // Function AutoSettingsInput.InputMappingManager.SetPlayerInputPresetByTag
	void OnRegisteredPlayerControllerDestroyed(struct AActor* DestroyedActor); // Function AutoSettingsInput.InputMappingManager.OnRegisteredPlayerControllerDestroyed
	bool InitializePlayerInputOverridesStatic(struct APlayerController* Player); // Function AutoSettingsInput.InputMappingManager.InitializePlayerInputOverridesStatic
	void GetPlayerMappingsByKey(struct APlayerController* Player, struct FKey Key, struct TArray<struct FInputActionKeyMapping>& Actions, struct TArray<struct FInputAxisKeyMapping>& Axes); // Function AutoSettingsInput.InputMappingManager.GetPlayerMappingsByKey
	struct FPlayerInputMappings GetPlayerInputMappingsStatic(struct APlayerController* Player); // Function AutoSettingsInput.InputMappingManager.GetPlayerInputMappingsStatic
	struct FInputAxisKeyMapping GetPlayerAxisMappingStatic(struct APlayerController* Player, struct FName AxisName, float Scale, int32_t MappingGroup); // Function AutoSettingsInput.InputMappingManager.GetPlayerAxisMappingStatic
	struct TArray<struct FInputAxisKeyMapping> GetPlayerAxisMappings(struct APlayerController* Player, struct FName AxisName, float Scale, int32_t MappingGroup, struct FGameplayTag KeyGroup, bool bUsePlayerKeyGroup); // Function AutoSettingsInput.InputMappingManager.GetPlayerAxisMappings
	struct FInputAxisKeyMapping GetPlayerAxisMapping(struct APlayerController* Player, struct FName AxisName, float Scale, int32_t MappingGroup, struct FGameplayTag KeyGroup, bool bUsePlayerKeyGroup); // Function AutoSettingsInput.InputMappingManager.GetPlayerAxisMapping
	struct FInputActionKeyMapping GetPlayerActionMappingStatic(struct APlayerController* Player, struct FName ActionName, int32_t MappingGroup); // Function AutoSettingsInput.InputMappingManager.GetPlayerActionMappingStatic
	struct TArray<struct FInputActionKeyMapping> GetPlayerActionMappings(struct APlayerController* Player, struct FName ActionName, int32_t MappingGroup, struct FGameplayTag KeyGroup, bool bUsePlayerKeyGroup); // Function AutoSettingsInput.InputMappingManager.GetPlayerActionMappings
	struct FInputActionKeyMapping GetPlayerActionMapping(struct APlayerController* Player, struct FName ActionName, int32_t MappingGroup, struct FGameplayTag KeyGroup, bool bUsePlayerKeyGroup); // Function AutoSettingsInput.InputMappingManager.GetPlayerActionMapping
	struct TArray<struct FInputMappingPreset> GetDefaultInputPresets(); // Function AutoSettingsInput.InputMappingManager.GetDefaultInputPresets
	void AddPlayerAxisOverrideStatic(struct APlayerController* Player, struct FInputAxisKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettingsInput.InputMappingManager.AddPlayerAxisOverrideStatic
	void AddPlayerAxisOverride(struct APlayerController* Player, struct FInputAxisKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettingsInput.InputMappingManager.AddPlayerAxisOverride
	void AddPlayerActionOverrideStatic(struct APlayerController* Player, struct FInputActionKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettingsInput.InputMappingManager.AddPlayerActionOverrideStatic
	void AddPlayerActionOverride(struct APlayerController* Player, struct FInputActionKeyMapping& NewMapping, int32_t MappingGroup, bool bAnyKeyGroup); // Function AutoSettingsInput.InputMappingManager.AddPlayerActionOverride
}; 



// Class AutoSettingsInput.KeyLabel
// Size: 0x2E8(Inherited: 0x278) 
struct UKeyLabel : public UUserWidget
{
	struct FText KeyInvalidText;  // 0x278(0x18)
	struct FText LabelOverride;  // 0x290(0x18)
	struct FKey Key;  // 0x2A8(0x18)
	float AxisScale;  // 0x2C0(0x4)
	char pad_708[4];  // 0x2C4(0x4)
	struct FGameplayTagContainer IconTags;  // 0x2C8(0x20)

	void UpdateKeyLabel(); // Function AutoSettingsInput.KeyLabel.UpdateKeyLabel
	void OnGlobalKeyIconTagsModified(); // Function AutoSettingsInput.KeyLabel.OnGlobalKeyIconTagsModified
	bool HasValidKey(); // Function AutoSettingsInput.KeyLabel.HasValidKey
	bool HasIcon(); // Function AutoSettingsInput.KeyLabel.HasIcon
	uint8_t  GetIconVisibility(); // Function AutoSettingsInput.KeyLabel.GetIconVisibility
	struct FSlateBrush GetIconBrush(); // Function AutoSettingsInput.KeyLabel.GetIconBrush
	struct UTexture* GetIcon(); // Function AutoSettingsInput.KeyLabel.GetIcon
	uint8_t  GetDisplayNameVisibility(); // Function AutoSettingsInput.KeyLabel.GetDisplayNameVisibility
	struct FText GetDisplayName(); // Function AutoSettingsInput.KeyLabel.GetDisplayName
}; 



