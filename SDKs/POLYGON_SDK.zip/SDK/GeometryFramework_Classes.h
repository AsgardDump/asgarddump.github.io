#pragma once 
#include <GeometryFramework_Structs.h>
 
 
 
// Class GeometryFramework.BaseDynamicMeshComponent
// Size: 0x5E0(Inherited: 0x570) 
struct UBaseDynamicMeshComponent : public UMeshComponent
{
	char pad_1392[32];  // 0x570(0x20)
	char pad_1424_1 : 7;  // 0x590(0x1)
	bool bExplicitShowWireframe : 1;  // 0x590(0x1)
	char pad_1425[3];  // 0x591(0x3)
	struct FLinearColor WireframeColor;  // 0x594(0x10)
	uint8_t  ColorMode;  // 0x5A4(0x1)
	char pad_1445[3];  // 0x5A5(0x3)
	struct FColor ConstantColor;  // 0x5A8(0x4)
	char pad_1452_1 : 7;  // 0x5AC(0x1)
	bool bEnableFlatShading : 1;  // 0x5AC(0x1)
	char pad_1453_1 : 7;  // 0x5AD(0x1)
	bool bEnableViewModeOverrides : 1;  // 0x5AD(0x1)
	char pad_1454[2];  // 0x5AE(0x2)
	struct UMaterialInterface* OverrideRenderMaterial;  // 0x5B0(0x8)
	struct UMaterialInterface* SecondaryRenderMaterial;  // 0x5B8(0x8)
	char pad_1472[1];  // 0x5C0(0x1)
	char pad_1473_1 : 7;  // 0x5C1(0x1)
	bool bEnableRayTracing : 1;  // 0x5C1(0x1)
	char pad_1474[6];  // 0x5C2(0x6)
	struct TArray<struct UMaterialInterface*> BaseMaterials;  // 0x5C8(0x10)
	char pad_1496[8];  // 0x5D8(0x8)

	void SetViewModeOverridesEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetViewModeOverridesEnabled
	void SetShadowsEnabled(bool bEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetShadowsEnabled
	void SetSecondaryRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryRenderMaterial
	void SetSecondaryBuffersVisibility(bool bSetVisible); // Function GeometryFramework.BaseDynamicMeshComponent.SetSecondaryBuffersVisibility
	void SetOverrideRenderMaterial(struct UMaterialInterface* Material); // Function GeometryFramework.BaseDynamicMeshComponent.SetOverrideRenderMaterial
	void SetEnableWireframeRenderPass(bool bEnable); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableWireframeRenderPass
	void SetEnableRaytracing(bool bSetEnabled); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableRaytracing
	void SetEnableFlatShading(bool bEnable); // Function GeometryFramework.BaseDynamicMeshComponent.SetEnableFlatShading
	void SetConstantOverrideColor(struct FColor NewColor); // Function GeometryFramework.BaseDynamicMeshComponent.SetConstantOverrideColor
	void SetColorOverrideMode(uint8_t  NewMode); // Function GeometryFramework.BaseDynamicMeshComponent.SetColorOverrideMode
	bool HasOverrideRenderMaterial(int32_t K); // Function GeometryFramework.BaseDynamicMeshComponent.HasOverrideRenderMaterial
	bool GetViewModeOverridesEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetViewModeOverridesEnabled
	bool GetShadowsEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetShadowsEnabled
	struct UMaterialInterface* GetSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryRenderMaterial
	bool GetSecondaryBuffersVisibility(); // Function GeometryFramework.BaseDynamicMeshComponent.GetSecondaryBuffersVisibility
	struct UMaterialInterface* GetOverrideRenderMaterial(int32_t MaterialIndex); // Function GeometryFramework.BaseDynamicMeshComponent.GetOverrideRenderMaterial
	bool GetFlatShadingEnabled(); // Function GeometryFramework.BaseDynamicMeshComponent.GetFlatShadingEnabled
	bool GetEnableWireframeRenderPass(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableWireframeRenderPass
	bool GetEnableRaytracing(); // Function GeometryFramework.BaseDynamicMeshComponent.GetEnableRaytracing
	struct UDynamicMesh* GetDynamicMesh(); // Function GeometryFramework.BaseDynamicMeshComponent.GetDynamicMesh
	struct FColor GetConstantOverrideColor(); // Function GeometryFramework.BaseDynamicMeshComponent.GetConstantOverrideColor
	uint8_t  GetColorOverrideMode(); // Function GeometryFramework.BaseDynamicMeshComponent.GetColorOverrideMode
	void ClearSecondaryRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearSecondaryRenderMaterial
	void ClearOverrideRenderMaterial(); // Function GeometryFramework.BaseDynamicMeshComponent.ClearOverrideRenderMaterial
}; 



// Class GeometryFramework.MeshCommandChangeTarget
// Size: 0x28(Inherited: 0x28) 
struct UMeshCommandChangeTarget : public UInterface
{

}; 



// Class GeometryFramework.DynamicMeshGenerator
// Size: 0x28(Inherited: 0x28) 
struct UDynamicMeshGenerator : public UObject
{

}; 



// Class GeometryFramework.MeshReplacementCommandChangeTarget
// Size: 0x28(Inherited: 0x28) 
struct UMeshReplacementCommandChangeTarget : public UInterface
{

}; 



// Class GeometryFramework.MeshVertexCommandChangeTarget
// Size: 0x28(Inherited: 0x28) 
struct UMeshVertexCommandChangeTarget : public UInterface
{

}; 



// Class GeometryFramework.DynamicMesh
// Size: 0xB0(Inherited: 0x28) 
struct UDynamicMesh : public UObject
{
	char pad_40[72];  // 0x28(0x48)
	struct FMulticastInlineDelegate MeshModifiedBPEvent;  // 0x70(0x10)
	char pad_128[32];  // 0x80(0x20)
	struct UDynamicMeshGenerator* MeshGenerator;  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bEnableMeshGenerator : 1;  // 0xA8(0x1)
	char pad_169[7];  // 0xA9(0x7)

	struct UDynamicMesh* ResetToCube(); // Function GeometryFramework.DynamicMesh.ResetToCube
	struct UDynamicMesh* Reset(); // Function GeometryFramework.DynamicMesh.Reset
	bool IsEmpty(); // Function GeometryFramework.DynamicMesh.IsEmpty
	int32_t GetTriangleCount(); // Function GeometryFramework.DynamicMesh.GetTriangleCount
}; 



// Class GeometryFramework.DynamicMeshComponent
// Size: 0x7F0(Inherited: 0x5E0) 
struct UDynamicMeshComponent : public UBaseDynamicMeshComponent
{
	struct UDynamicMesh* MeshObject;  // 0x5E0(0x8)
	char pad_1512[248];  // 0x5E8(0xF8)
	uint8_t  TangentsType;  // 0x6E0(0x1)
	char pad_1761[63];  // 0x6E1(0x3F)
	char ECollisionTraceFlag CollisionType;  // 0x720(0x1)
	char pad_1825_1 : 7;  // 0x721(0x1)
	bool bUseAsyncCooking : 1;  // 0x721(0x1)
	char pad_1826_1 : 7;  // 0x722(0x1)
	bool bEnableComplexCollision : 1;  // 0x722(0x1)
	char pad_1827_1 : 7;  // 0x723(0x1)
	bool bDeferCollisionUpdates : 1;  // 0x723(0x1)
	char pad_1828[4];  // 0x724(0x4)
	struct UBodySetup* MeshBodySetup;  // 0x728(0x8)
	char pad_1840[56];  // 0x730(0x38)
	struct FKAggregateGeom AggGeom;  // 0x768(0x68)
	struct TArray<struct UBodySetup*> AsyncBodySetupQueue;  // 0x7D0(0x10)
	char pad_2016[16];  // 0x7E0(0x10)

	bool ValidateMaterialSlots(bool bCreateIfMissing, bool bDeleteExtraSlots); // Function GeometryFramework.DynamicMeshComponent.ValidateMaterialSlots
	void UpdateCollision(bool bOnlyIfPending); // Function GeometryFramework.DynamicMeshComponent.UpdateCollision
	void SetTangentsType(uint8_t  NewTangentsType); // Function GeometryFramework.DynamicMeshComponent.SetTangentsType
	void SetDynamicMesh(struct UDynamicMesh* NewMesh); // Function GeometryFramework.DynamicMeshComponent.SetDynamicMesh
	void SetDeferredCollisionUpdatesEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetDeferredCollisionUpdatesEnabled
	void SetComplexAsSimpleCollisionEnabled(bool bEnabled, bool bImmediateUpdate); // Function GeometryFramework.DynamicMeshComponent.SetComplexAsSimpleCollisionEnabled
	uint8_t  GetTangentsType(); // Function GeometryFramework.DynamicMeshComponent.GetTangentsType
	void EnableComplexAsSimpleCollision(); // Function GeometryFramework.DynamicMeshComponent.EnableComplexAsSimpleCollision
	void ConfigureMaterialSet(struct TArray<struct UMaterialInterface*>& NewMaterialSet); // Function GeometryFramework.DynamicMeshComponent.ConfigureMaterialSet
}; 



// Class GeometryFramework.DynamicMeshActor
// Size: 0x2A8(Inherited: 0x290) 
struct ADynamicMeshActor : public AActor
{
	struct UDynamicMeshComponent* DynamicMeshComponent;  // 0x290(0x8)
	char pad_664_1 : 7;  // 0x298(0x1)
	bool bEnableComputeMeshPool : 1;  // 0x298(0x1)
	char pad_665[7];  // 0x299(0x7)
	struct UDynamicMeshPool* DynamicMeshPool;  // 0x2A0(0x8)

	bool ReleaseComputeMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshActor.ReleaseComputeMesh
	void ReleaseAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.ReleaseAllComputeMeshes
	struct UDynamicMeshComponent* GetDynamicMeshComponent(); // Function GeometryFramework.DynamicMeshActor.GetDynamicMeshComponent
	struct UDynamicMeshPool* GetComputeMeshPool(); // Function GeometryFramework.DynamicMeshActor.GetComputeMeshPool
	void FreeAllComputeMeshes(); // Function GeometryFramework.DynamicMeshActor.FreeAllComputeMeshes
	struct UDynamicMesh* AllocateComputeMesh(); // Function GeometryFramework.DynamicMeshActor.AllocateComputeMesh
}; 



// Class GeometryFramework.DynamicMeshPool
// Size: 0x48(Inherited: 0x28) 
struct UDynamicMeshPool : public UObject
{
	struct TArray<struct UDynamicMesh*> CachedMeshes;  // 0x28(0x10)
	struct TArray<struct UDynamicMesh*> AllCreatedMeshes;  // 0x38(0x10)

	void ReturnMesh(struct UDynamicMesh* Mesh); // Function GeometryFramework.DynamicMeshPool.ReturnMesh
	void ReturnAllMeshes(); // Function GeometryFramework.DynamicMeshPool.ReturnAllMeshes
	struct UDynamicMesh* RequestMesh(); // Function GeometryFramework.DynamicMeshPool.RequestMesh
	void FreeAllMeshes(); // Function GeometryFramework.DynamicMeshPool.FreeAllMeshes
}; 



