#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Party.PartyMemberJoinInProgressRequest
// Size: 0x38(Inherited: 0x0) 
struct FPartyMemberJoinInProgressRequest
{
	struct FUniqueNetIdRepl Target;  // 0x0(0x30)
	int64_t time;  // 0x30(0x8)

}; 
// ScriptStruct Party.PartyMemberPlatformData
// Size: 0x98(Inherited: 0x0) 
struct FPartyMemberPlatformData
{
	struct FUserPlatform Platform;  // 0x0(0x58)
	struct FUniqueNetIdRepl UniqueId;  // 0x58(0x30)
	struct FString SessionId;  // 0x88(0x10)

}; 
// ScriptStruct Party.UserPlatform
// Size: 0x58(Inherited: 0x0) 
struct FUserPlatform
{
	struct FSocialPlatformDescription PlatformDescription;  // 0x0(0x58)

}; 
// ScriptStruct Party.PartyMemberJoinInProgressData
// Size: 0x48(Inherited: 0x0) 
struct FPartyMemberJoinInProgressData
{
	struct FPartyMemberJoinInProgressRequest Request;  // 0x0(0x38)
	struct TArray<struct FPartyMemberJoinInProgressResponse> Responses;  // 0x38(0x10)

}; 
// ScriptStruct Party.SocialPlatformDescription
// Size: 0x58(Inherited: 0x0) 
struct FSocialPlatformDescription
{
	struct FString Name;  // 0x0(0x10)
	struct FString PlatformType;  // 0x10(0x10)
	struct FName OnlineSubsystem;  // 0x20(0x8)
	struct FString SessionType;  // 0x28(0x10)
	struct FString ExternalAccountType;  // 0x38(0x10)
	struct FString CrossplayPool;  // 0x48(0x10)

}; 
// ScriptStruct Party.PartyMemberJoinInProgressResponse
// Size: 0x48(Inherited: 0x0) 
struct FPartyMemberJoinInProgressResponse
{
	struct FUniqueNetIdRepl Requester;  // 0x0(0x30)
	int64_t RequestTime;  // 0x30(0x8)
	int64_t ResponseTime;  // 0x38(0x8)
	char DenialReason;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// ScriptStruct Party.OnlinePartyRepDataBase
// Size: 0x18(Inherited: 0x0) 
struct FOnlinePartyRepDataBase
{
	char pad_0[24];  // 0x0(0x18)

}; 
// ScriptStruct Party.PartyMemberRepData
// Size: 0x268(Inherited: 0x18) 
struct FPartyMemberRepData : public FOnlinePartyRepDataBase
{
	char pad_24[8];  // 0x18(0x8)
	struct FPartyMemberPlatformData PlatformData;  // 0x20(0x98)
	char pad_184[144];  // 0xB8(0x90)
	uint8_t  CrossplayPreference;  // 0x148(0x1)
	char pad_329[55];  // 0x149(0x37)
	struct FString JoinMethod;  // 0x180(0x10)
	char pad_400[48];  // 0x190(0x30)
	struct FPartyMemberJoinInProgressData JoinInProgressData;  // 0x1C0(0x48)
	char pad_520[96];  // 0x208(0x60)

}; 
// ScriptStruct Party.PartyPlatformSessionInfo
// Size: 0x50(Inherited: 0x0) 
struct FPartyPlatformSessionInfo
{
	struct FString SessionType;  // 0x0(0x10)
	struct FString SessionId;  // 0x10(0x10)
	struct FUniqueNetIdRepl OwnerPrimaryId;  // 0x20(0x30)

}; 
// ScriptStruct Party.PartyPrivacySettings
// Size: 0x3(Inherited: 0x0) 
struct FPartyPrivacySettings
{
	uint8_t  PartyType;  // 0x0(0x1)
	uint8_t  PartyInviteRestriction;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bOnlyLeaderFriendsCanJoin : 1;  // 0x2(0x1)

}; 
// ScriptStruct Party.PartyRepData
// Size: 0x80(Inherited: 0x18) 
struct FPartyRepData : public FOnlinePartyRepDataBase
{
	char pad_24[8];  // 0x18(0x8)
	struct FPartyPrivacySettings PrivacySettings;  // 0x20(0x3)
	char pad_35[53];  // 0x23(0x35)
	struct TArray<struct FPartyPlatformSessionInfo> PlatformSessions;  // 0x58(0x10)
	char pad_104[24];  // 0x68(0x18)

}; 
// ScriptStruct Party.SocialChatChannelConfig
// Size: 0x40(Inherited: 0x0) 
struct FSocialChatChannelConfig
{
	struct USocialUser* SocialUser;  // 0x0(0x8)
	char pad_8[16];  // 0x8(0x10)
	struct TArray<struct USocialChatChannel*> ListenChannels;  // 0x18(0x10)
	char pad_40[24];  // 0x28(0x18)

}; 
