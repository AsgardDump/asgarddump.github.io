#pragma once 
#include <BP_Item_Gear_Watch_01_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Gear_Watch_01.BP_Item_Gear_Watch_01_C
// Size: 0x330(Inherited: 0x310) 
struct ABP_Item_Gear_Watch_01_C : public AItem_Watch_General
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x310(0x8)
	struct UStaticMeshComponent* Second;  // 0x318(0x8)
	struct UStaticMeshComponent* Minute;  // 0x320(0x8)
	struct UStaticMeshComponent* Hour;  // 0x328(0x8)

	void ReceiveBeginPlay(); // Function BP_Item_Gear_Watch_01.BP_Item_Gear_Watch_01_C.ReceiveBeginPlay
	void Watch(); // Function BP_Item_Gear_Watch_01.BP_Item_Gear_Watch_01_C.Watch
	void ExecuteUbergraph_BP_Item_Gear_Watch_01(int32_t EntryPoint); // Function BP_Item_Gear_Watch_01.BP_Item_Gear_Watch_01_C.ExecuteUbergraph_BP_Item_Gear_Watch_01
}; 



