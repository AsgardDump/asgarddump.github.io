#pragma once 
#include <Qos_Structs.h>
 
 
 
// Class Qos.QosBeaconClient
// Size: 0x358(Inherited: 0x320) 
struct AQosBeaconClient : public AOnlineBeaconClient
{
	char pad_800[56];  // 0x320(0x38)

	void ServerQosRequest(struct FString InSessionId); // Function Qos.QosBeaconClient.ServerQosRequest
	void ClientQosResponse(uint8_t  Response); // Function Qos.QosBeaconClient.ClientQosResponse
}; 



// Class Qos.QosRegionManager
// Size: 0xF8(Inherited: 0x28) 
struct UQosRegionManager : public UObject
{
	int32_t NumTestsPerRegion;  // 0x28(0x4)
	float PingTimeout;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bEnableSubspaceBiasOrder : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString SubspaceDelimiter;  // 0x38(0x10)
	struct TArray<struct FQosRegionInfo> RegionDefinitions;  // 0x48(0x10)
	struct TArray<struct FQosDatacenterInfo> DatacenterDefinitions;  // 0x58(0x10)
	struct FDateTime LastCheckTimestamp;  // 0x68(0x8)
	struct UQosEvaluator* Evaluator;  // 0x70(0x8)
	uint8_t  QosEvalResult;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct TArray<struct FRegionQosInstance> RegionOptions;  // 0x80(0x10)
	struct FString ForceRegionId;  // 0x90(0x10)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool bRegionForcedViaCommandline : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)
	struct FString SelectedRegionId;  // 0xA8(0x10)
	char pad_184[64];  // 0xB8(0x40)

}; 



// Class Qos.QosBeaconHost
// Size: 0x2C8(Inherited: 0x2B8) 
struct AQosBeaconHost : public AOnlineBeaconHostObject
{
	char pad_696[16];  // 0x2B8(0x10)

}; 



// Class Qos.QosEvaluator
// Size: 0x80(Inherited: 0x28) 
struct UQosEvaluator : public UObject
{
	char pad_40[32];  // 0x28(0x20)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bInProgress : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool bCancelOperation : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct TArray<struct FDatacenterQosInstance> Datacenters;  // 0x50(0x10)
	char pad_96[32];  // 0x60(0x20)

}; 



