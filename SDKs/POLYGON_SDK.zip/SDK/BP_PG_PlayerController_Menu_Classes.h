#pragma once 
#include <BP_PG_PlayerController_Menu_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C
// Size: 0x8D0(Inherited: 0x880) 
struct ABP_PG_PlayerController_Menu_C : public APG_PlayerController_Menu
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x880(0x8)
	struct UUI_Menu_GeneralMenuScreen_C* UI_GeneralMenuScreen;  // 0x888(0x8)
	struct ABP_PG_Menu_Character_C* MenuCharacter;  // 0x890(0x8)
	struct UUI_ErrorMessage_C* UI_ErrorMessage;  // 0x898(0x8)
	struct TArray<struct ACameraActor*> Cameras;  // 0x8A0(0x10)
	struct UUI_Menu_Squad_Invite_C* UI_Squad_Invite;  // 0x8B0(0x8)
	struct UUI_HardLoadingScreen_C* UI_HardLoadingScreen;  // 0x8B8(0x8)
	struct UUI_SoftLoadingScreen_C* UI_SoftLoadingScreen;  // 0x8C0(0x8)
	struct UAudioComponent* BackgroundMusic;  // 0x8C8(0x8)

	void SetVisibleHardLoadingScreen(bool IsVisible); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.SetVisibleHardLoadingScreen
	void SetVisibleSoftLoadingScreen(bool IsVisible); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.SetVisibleSoftLoadingScreen
	void SwitchCamera(struct FName CameraTag, double BlendTime); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.SwitchCamera
	void ReceiveBeginPlay(); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ReceiveBeginPlay
	void ShowError(struct FText& ErrorMessage, struct FText& ErrorDetails); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ShowError
	void ExecuteUbergraph_BP_PG_PlayerController_Menu(int32_t EntryPoint); // Function BP_PG_PlayerController_Menu.BP_PG_PlayerController_Menu_C.ExecuteUbergraph_BP_PG_PlayerController_Menu
}; 



