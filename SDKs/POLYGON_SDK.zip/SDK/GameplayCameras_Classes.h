#pragma once 
#include <GameplayCameras_Structs.h>
 
 
 
// Class GameplayCameras.LegacyCameraShake
// Size: 0x210(Inherited: 0xF0) 
struct ULegacyCameraShake : public UCameraShakeBase
{
	float OscillationDuration;  // 0xE8(0x4)
	float OscillationBlendInTime;  // 0xEC(0x4)
	float OscillationBlendOutTime;  // 0xF0(0x4)
	struct FROscillator RotOscillation;  // 0xF4(0x24)
	struct FVOscillator LocOscillation;  // 0x118(0x24)
	struct FFOscillator FOVOscillation;  // 0x13C(0xC)
	float AnimPlayRate;  // 0x148(0x4)
	float AnimScale;  // 0x14C(0x4)
	float AnimBlendInTime;  // 0x150(0x4)
	float AnimBlendOutTime;  // 0x154(0x4)
	float RandomAnimSegmentDuration;  // 0x158(0x4)
	struct UCameraAnimationSequence* AnimSequence;  // 0x160(0x8)
	char bRandomAnimSegment : 1;  // 0x168(0x1)
	float OscillatorTimeRemaining;  // 0x16C(0x4)
	char pad_368_1 : 7;  // 0x170(0x1)
	char pad_369[112];  // 0x171(0x70)
	struct USequenceCameraShakePattern* SequenceShakePattern;  // 0x1E0(0x8)
	char pad_488[40];  // 0x1E8(0x28)

	struct ULegacyCameraShake* StartLegacyCameraShakeFromSource(struct APlayerCameraManager* PlayerCameraManager, ULegacyCameraShake* ShakeClass, struct UCameraShakeSourceComponent* SourceComponent, float Scale, uint8_t  PlaySpace, struct FRotator UserPlaySpaceRot); // Function GameplayCameras.LegacyCameraShake.StartLegacyCameraShakeFromSource
	struct ULegacyCameraShake* StartLegacyCameraShake(struct APlayerCameraManager* PlayerCameraManager, ULegacyCameraShake* ShakeClass, float Scale, uint8_t  PlaySpace, struct FRotator UserPlaySpaceRot); // Function GameplayCameras.LegacyCameraShake.StartLegacyCameraShake
	void ReceiveStopShake(bool bImmediately); // Function GameplayCameras.LegacyCameraShake.ReceiveStopShake
	void ReceivePlayShake(float Scale); // Function GameplayCameras.LegacyCameraShake.ReceivePlayShake
	bool ReceiveIsFinished(); // Function GameplayCameras.LegacyCameraShake.ReceiveIsFinished
	void BlueprintUpdateCameraShake(float DeltaTime, float Alpha, struct FMinimalViewInfo& POV, struct FMinimalViewInfo& ModifiedPOV); // Function GameplayCameras.LegacyCameraShake.BlueprintUpdateCameraShake
}; 



// Class GameplayCameras.DefaultCameraShakeBase
// Size: 0xF0(Inherited: 0xF0) 
struct UDefaultCameraShakeBase : public UCameraShakeBase
{

}; 



// Class GameplayCameras.LegacyCameraShakePattern
// Size: 0x28(Inherited: 0x28) 
struct ULegacyCameraShakePattern : public UCameraShakePattern
{

}; 



// Class GameplayCameras.GameplayCamerasFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct UGameplayCamerasFunctionLibrary : public UBlueprintFunctionLibrary
{

	uint8_t  Conv_CameraShakePlaySpace(uint8_t  CameraAnimationPlaySpace); // Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraShakePlaySpace
	uint8_t  Conv_CameraAnimationPlaySpace(uint8_t  CameraShakePlaySpace); // Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraAnimationPlaySpace
	struct UCameraAnimationCameraModifier* Conv_CameraAnimationCameraModifier(struct APlayerCameraManager* PlayerCameraManager); // Function GameplayCameras.GameplayCamerasFunctionLibrary.Conv_CameraAnimationCameraModifier
}; 



// Class GameplayCameras.LegacyCameraShakeFunctionLibrary
// Size: 0x28(Inherited: 0x28) 
struct ULegacyCameraShakeFunctionLibrary : public UBlueprintFunctionLibrary
{

	struct ULegacyCameraShake* Conv_LegacyCameraShake(struct UCameraShakeBase* CameraShake); // Function GameplayCameras.LegacyCameraShakeFunctionLibrary.Conv_LegacyCameraShake
}; 



// Class GameplayCameras.CameraAnimationCameraModifier
// Size: 0x60(Inherited: 0x48) 
struct UCameraAnimationCameraModifier : public UCameraModifier
{
	struct TArray<struct FActiveCameraAnimationInfo> ActiveAnimations;  // 0x48(0x10)
	uint16_t NextInstanceSerialNumber;  // 0x58(0x2)
	char pad_90[6];  // 0x5A(0x6)

	void StopCameraAnimation(struct FCameraAnimationHandle& Handle, bool bImmediate); // Function GameplayCameras.CameraAnimationCameraModifier.StopCameraAnimation
	void StopAllCameraAnimationsOf(struct UCameraAnimationSequence* Sequence, bool bImmediate); // Function GameplayCameras.CameraAnimationCameraModifier.StopAllCameraAnimationsOf
	void StopAllCameraAnimations(bool bImmediate); // Function GameplayCameras.CameraAnimationCameraModifier.StopAllCameraAnimations
	struct FCameraAnimationHandle PlayCameraAnimation(struct UCameraAnimationSequence* Sequence, struct FCameraAnimationParams Params); // Function GameplayCameras.CameraAnimationCameraModifier.PlayCameraAnimation
	bool IsCameraAnimationActive(struct FCameraAnimationHandle& Handle); // Function GameplayCameras.CameraAnimationCameraModifier.IsCameraAnimationActive
	struct UCameraAnimationCameraModifier* GetCameraAnimationCameraModifierFromPlayerController(struct APlayerController* PlayerController); // Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifierFromPlayerController
	struct UCameraAnimationCameraModifier* GetCameraAnimationCameraModifierFromID(struct UObject* WorldContextObject, int32_t ControllerId); // Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifierFromID
	struct UCameraAnimationCameraModifier* GetCameraAnimationCameraModifier(struct UObject* WorldContextObject, int32_t PlayerIndex); // Function GameplayCameras.CameraAnimationCameraModifier.GetCameraAnimationCameraModifier
}; 



// Class GameplayCameras.CompositeCameraShakePattern
// Size: 0x48(Inherited: 0x28) 
struct UCompositeCameraShakePattern : public UCameraShakePattern
{
	struct TArray<struct UCameraShakePattern*> ChildPatterns;  // 0x28(0x10)
	char pad_56[16];  // 0x38(0x10)

}; 



// Class GameplayCameras.GameplayCamerasSubsystem
// Size: 0x30(Inherited: 0x30) 
struct UGameplayCamerasSubsystem : public UWorldSubsystem
{

	void StopCameraAnimation(struct APlayerController* PlayerController, struct FCameraAnimationHandle& Handle, bool bImmediate); // Function GameplayCameras.GameplayCamerasSubsystem.StopCameraAnimation
	void StopAllCameraAnimationsOf(struct APlayerController* PlayerController, struct UCameraAnimationSequence* Sequence, bool bImmediate); // Function GameplayCameras.GameplayCamerasSubsystem.StopAllCameraAnimationsOf
	void StopAllCameraAnimations(struct APlayerController* PlayerController, bool bImmediate); // Function GameplayCameras.GameplayCamerasSubsystem.StopAllCameraAnimations
	struct FCameraAnimationHandle PlayCameraAnimation(struct APlayerController* PlayerController, struct UCameraAnimationSequence* Sequence, struct FCameraAnimationParams Params); // Function GameplayCameras.GameplayCamerasSubsystem.PlayCameraAnimation
	bool IsCameraAnimationActive(struct APlayerController* PlayerController, struct FCameraAnimationHandle& Handle); // Function GameplayCameras.GameplayCamerasSubsystem.IsCameraAnimationActive
}; 



// Class GameplayCameras.SimpleCameraShakePattern
// Size: 0x38(Inherited: 0x28) 
struct USimpleCameraShakePattern : public UCameraShakePattern
{
	float Duration;  // 0x28(0x4)
	float BlendInTime;  // 0x2C(0x4)
	float BlendOutTime;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 



// Class GameplayCameras.PerlinNoiseCameraShakePattern
// Size: 0xB8(Inherited: 0x38) 
struct UPerlinNoiseCameraShakePattern : public USimpleCameraShakePattern
{
	float LocationAmplitudeMultiplier;  // 0x38(0x4)
	float LocationFrequencyMultiplier;  // 0x3C(0x4)
	struct FPerlinNoiseShaker X;  // 0x40(0x8)
	struct FPerlinNoiseShaker Y;  // 0x48(0x8)
	struct FPerlinNoiseShaker Z;  // 0x50(0x8)
	float RotationAmplitudeMultiplier;  // 0x58(0x4)
	float RotationFrequencyMultiplier;  // 0x5C(0x4)
	struct FPerlinNoiseShaker Pitch;  // 0x60(0x8)
	struct FPerlinNoiseShaker Yaw;  // 0x68(0x8)
	struct FPerlinNoiseShaker Roll;  // 0x70(0x8)
	struct FPerlinNoiseShaker FOV;  // 0x78(0x8)
	char pad_128[56];  // 0x80(0x38)

}; 



// Class GameplayCameras.WaveOscillatorCameraShakePattern
// Size: 0xD8(Inherited: 0x38) 
struct UWaveOscillatorCameraShakePattern : public USimpleCameraShakePattern
{
	float LocationAmplitudeMultiplier;  // 0x38(0x4)
	float LocationFrequencyMultiplier;  // 0x3C(0x4)
	struct FWaveOscillator X;  // 0x40(0xC)
	struct FWaveOscillator Y;  // 0x4C(0xC)
	struct FWaveOscillator Z;  // 0x58(0xC)
	float RotationAmplitudeMultiplier;  // 0x64(0x4)
	float RotationFrequencyMultiplier;  // 0x68(0x4)
	struct FWaveOscillator Pitch;  // 0x6C(0xC)
	struct FWaveOscillator Yaw;  // 0x78(0xC)
	struct FWaveOscillator Roll;  // 0x84(0xC)
	struct FWaveOscillator FOV;  // 0x90(0xC)
	char pad_156[60];  // 0x9C(0x3C)

}; 



// Class GameplayCameras.TestCameraShake
// Size: 0xF0(Inherited: 0xF0) 
struct UTestCameraShake : public UCameraShakeBase
{

}; 



// Class GameplayCameras.ConstantCameraShakePattern
// Size: 0x68(Inherited: 0x38) 
struct UConstantCameraShakePattern : public USimpleCameraShakePattern
{
	struct FVector LocationOffset;  // 0x38(0x18)
	struct FRotator RotationOffset;  // 0x50(0x18)

}; 



