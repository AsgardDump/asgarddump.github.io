#pragma once 
#include <BP_SupportBox_Ammo_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_SupportBox_Ammo.BP_SupportBox_Ammo_C
// Size: 0x2C0(Inherited: 0x2C0) 
struct ABP_SupportBox_Ammo_C : public ASupportBox_Ammo
{

}; 



