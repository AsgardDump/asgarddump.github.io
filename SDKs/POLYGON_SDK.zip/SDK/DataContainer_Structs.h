#pragma once 
#include "SDK.h" 
 
 
// Function DataContainer.DataContainerValue_Base.FindDataContainerValue
// Size: 0x18(Inherited: 0x0) 
struct FFindDataContainerValue
{
	struct FString tagPath;  // 0x0(0x10)
	struct UDataContainerValue_Base* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct DataContainer.DataContainerObjectWrapper
// Size: 0x8(Inherited: 0x0) 
struct FDataContainerObjectWrapper
{
	struct UDataContainerValue_DataObject* DataObject;  // 0x0(0x8)

}; 
