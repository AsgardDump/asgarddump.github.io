#pragma once 
#include "SDK.h" 
 
 
// Function AdvancedWidgets.RadialSlider.GetNormalizedSliderHandlePosition
// Size: 0x4(Inherited: 0x0) 
struct FGetNormalizedSliderHandlePosition
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.GetCustomDefaultValue
// Size: 0x4(Inherited: 0x0) 
struct FGetCustomDefaultValue
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.SetAngularOffset
// Size: 0x4(Inherited: 0x0) 
struct FSetAngularOffset
{
	float InValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.SetSliderHandleEndAngle
// Size: 0x4(Inherited: 0x0) 
struct FSetSliderHandleEndAngle
{
	float InValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.GetValue
// Size: 0x4(Inherited: 0x0) 
struct FGetValue
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.SetCenterBackgroundColor
// Size: 0x10(Inherited: 0x0) 
struct FSetCenterBackgroundColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AdvancedWidgets.RadialSlider.SetHandStartEndRatio
// Size: 0x10(Inherited: 0x0) 
struct FSetHandStartEndRatio
{
	struct FVector2D InValue;  // 0x0(0x10)

}; 
// Function AdvancedWidgets.RadialSlider.SetCustomDefaultValue
// Size: 0x4(Inherited: 0x0) 
struct FSetCustomDefaultValue
{
	float InValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.SetLocked
// Size: 0x1(Inherited: 0x0) 
struct FSetLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InValue : 1;  // 0x0(0x1)

}; 
// Function AdvancedWidgets.RadialSlider.SetShowSliderHand
// Size: 0x1(Inherited: 0x0) 
struct FSetShowSliderHand
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InShowSliderHand : 1;  // 0x0(0x1)

}; 
// Function AdvancedWidgets.RadialSlider.SetShowSliderHandle
// Size: 0x1(Inherited: 0x0) 
struct FSetShowSliderHandle
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InShowSliderHandle : 1;  // 0x0(0x1)

}; 
// Function AdvancedWidgets.RadialSlider.SetSliderBarColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderBarColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AdvancedWidgets.RadialSlider.SetSliderHandleColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderHandleColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AdvancedWidgets.RadialSlider.SetSliderHandleStartAngle
// Size: 0x4(Inherited: 0x0) 
struct FSetSliderHandleStartAngle
{
	float InValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.SetSliderProgressColor
// Size: 0x10(Inherited: 0x0) 
struct FSetSliderProgressColor
{
	struct FLinearColor InValue;  // 0x0(0x10)

}; 
// Function AdvancedWidgets.RadialSlider.SetSliderRange
// Size: 0x88(Inherited: 0x0) 
struct FSetSliderRange
{
	struct FRuntimeFloatCurve InSliderRange;  // 0x0(0x88)

}; 
// Function AdvancedWidgets.RadialSlider.SetStepSize
// Size: 0x4(Inherited: 0x0) 
struct FSetStepSize
{
	float InValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.SetUseVerticalDrag
// Size: 0x1(Inherited: 0x0) 
struct FSetUseVerticalDrag
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InUseVerticalDrag : 1;  // 0x0(0x1)

}; 
// Function AdvancedWidgets.RadialSlider.SetValue
// Size: 0x4(Inherited: 0x0) 
struct FSetValue
{
	float InValue;  // 0x0(0x4)

}; 
// Function AdvancedWidgets.RadialSlider.SetValueTags
// Size: 0x10(Inherited: 0x0) 
struct FSetValueTags
{
	struct TArray<float> InValueTags;  // 0x0(0x10)

}; 
