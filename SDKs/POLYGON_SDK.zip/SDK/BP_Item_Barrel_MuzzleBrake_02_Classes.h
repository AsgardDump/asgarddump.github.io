#pragma once 
#include <BP_Item_Barrel_MuzzleBrake_02_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Item_Barrel_MuzzleBrake_02.BP_Item_Barrel_MuzzleBrake_02_C
// Size: 0x348(Inherited: 0x348) 
struct ABP_Item_Barrel_MuzzleBrake_02_C : public AItem_Module_Barrel
{

}; 



