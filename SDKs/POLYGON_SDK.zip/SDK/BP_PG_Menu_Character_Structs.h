#pragma once 
#include "SDK.h" 
 
 
// Function BP_PG_Menu_Character.BP_PG_Menu_Character_C.ExecuteUbergraph_BP_PG_Menu_Character
// Size: 0x19(Inherited: 0x0) 
struct FExecuteUbergraph_BP_PG_Menu_Character
{
	int32_t EntryPoint;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x8(0x8)
	struct ABP_PG_PlayerController_Menu_C* K2Node_DynamicCast_AsBP_PG_Player_Controller_Menu;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool K2Node_DynamicCast_bSuccess : 1;  // 0x18(0x1)

}; 
