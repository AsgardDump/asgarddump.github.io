#pragma once 
#include "SDK.h" 
 
 
// Function HorizonUI.HorizonRadioButtonUserWidget.NativeOnCheckStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FNativeOnCheckStateChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// DelegateFunction HorizonUI.HorizonButtonUserWidget.OnHorizonButtonEvent__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnHorizonButtonEvent__DelegateSignature
{
	struct UHorizonButtonUserWidget* InButton;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetColorAndOpacity
// Size: 0x14(Inherited: 0x0) 
struct FSetColorAndOpacity
{
	struct FSlateColor InColorAndOpacity;  // 0x0(0x14)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetCurrentPageTextLength
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentPageTextLength
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonButtonUserWidget.ReceiveOnOnButtonFocusLost
// Size: 0x8(Inherited: 0x0) 
struct FReceiveOnOnButtonFocusLost
{
	struct FFocusEvent InFocusEvent;  // 0x0(0x8)

}; 
// DelegateFunction HorizonUI.HorizonButtonUserWidget.OnHorizonButtonFocusEvent__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnHorizonButtonFocusEvent__DelegateSignature
{
	struct UHorizonButtonUserWidget* InButton;  // 0x0(0x8)
	struct FFocusEvent InFocusEvent;  // 0x8(0x8)

}; 
// DelegateFunction HorizonUI.HorizonMultiToggleButtonWidget.OnHorizonMultiToggleButtonEvent__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnHorizonMultiToggleButtonEvent__DelegateSignature
{
	int32_t InCurrentStateIndex;  // 0x0(0x4)
	int32_t InToStateIndex;  // 0x4(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.IsDialogueMsgCompleted
// Size: 0x1(Inherited: 0x0) 
struct FIsDialogueMsgCompleted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonButtonUserWidget.ReceiveOnButtonFocus
// Size: 0x8(Inherited: 0x0) 
struct FReceiveOnButtonFocus
{
	struct FFocusEvent InFocusEvent;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetCurrentPageIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentPageIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsDialogueMsgText
// Size: 0x1(Inherited: 0x0) 
struct FSetIsDialogueMsgText
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool B : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetBlinkCursorWidget
// Size: 0x8(Inherited: 0x0) 
struct FGetBlinkCursorWidget
{
	struct UHorizonFlipbookWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonTextBlock.GetJustification
// Size: 0x1(Inherited: 0x0) 
struct FGetJustification
{
	char ETextJustify ReturnValue;  // 0x0(0x1)

}; 
// DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueCustomEvent__DelegateSignature
// Size: 0x280(Inherited: 0x0) 
struct FOnHorizonDialogueCustomEvent__DelegateSignature
{
	struct FString InEventName;  // 0x0(0x10)
	struct FHorizonDialogueSegmentInfo InSegInfo;  // 0x10(0x270)

}; 
// Function HorizonUI.HorizonMultiToggleButtonWidget.GetLoopToggleState
// Size: 0x1(Inherited: 0x0) 
struct FGetLoopToggleState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.IsAlphabetic
// Size: 0x8(Inherited: 0x0) 
struct FIsAlphabetic
{
	int32_t InCodePoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetRepeatDialogueMsgInterval
// Size: 0x4(Inherited: 0x0) 
struct FSetRepeatDialogueMsgInterval
{
	float interval;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetNumPage
// Size: 0x4(Inherited: 0x0) 
struct FGetNumPage
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetPageTextByIndex
// Size: 0x20(Inherited: 0x0) 
struct FGetPageTextByIndex
{
	int32_t PageIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FText ReturnValue;  // 0x8(0x18)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetShadowOffset
// Size: 0x18(Inherited: 0x0) 
struct FSetShadowOffset
{
	struct FVector2D InShadowOffset;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bForce : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetText
// Size: 0x18(Inherited: 0x0) 
struct FGetText
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function HorizonUI.HorizonFileSystem.LoadFont
// Size: 0x18(Inherited: 0x0) 
struct FLoadFont
{
	struct FString InPackageFilePath;  // 0x0(0x10)
	struct UFont* ReturnValue;  // 0x10(0x8)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetTextLength
// Size: 0x4(Inherited: 0x0) 
struct FGetTextLength
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.GetTextOverflowWrapMethod
// Size: 0x1(Inherited: 0x0) 
struct FGetTextOverflowWrapMethod
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.IsDialogueMsgPageEnd
// Size: 0x1(Inherited: 0x0) 
struct FIsDialogueMsgPageEnd
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetOpacity
// Size: 0x4(Inherited: 0x0) 
struct FSetOpacity
{
	float InOpacity;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonMultiToggleButtonWidget.GetToggleState_NextIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetToggleState_NextIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.NextDialogueMsgPage
// Size: 0x1(Inherited: 0x0) 
struct FNextDialogueMsgPage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldStartTick : 1;  // 0x0(0x1)

}; 
// ScriptStruct HorizonUI.HorizonDialogueHypertextResult
// Size: 0x78(Inherited: 0x0) 
struct FHorizonDialogueHypertextResult
{
	struct UHorizonDialogueMsgTextBlock* DialogueMsgTextBlock;  // 0x0(0x8)
	int32_t SegmentIndex;  // 0x8(0x4)
	int32_t LineIndex;  // 0xC(0x4)
	int32_t BlockIndex;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)
	struct FString HypertextReference;  // 0x18(0x10)
	struct TMap<struct FString, struct FString> UrlEncodeMap;  // 0x28(0x50)

}; 
// DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialogueCharAdvancedEvent__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FOnHorizonDialogueCharAdvancedEvent__DelegateSignature
{
	struct FHorizonDialogueBlockInfo InCurrentBlockInfo;  // 0x0(0x68)

}; 
// Function HorizonUI.HorizonMultiToggleButtonWidget.SetCurrentStateIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetCurrentStateIndex
{
	int32_t InStateIndex;  // 0x0(0x4)

}; 
// ScriptStruct HorizonUI.HorizonDialogueBlockInfo
// Size: 0x68(Inherited: 0x0) 
struct FHorizonDialogueBlockInfo
{
	struct FString MsgText;  // 0x0(0x10)
	char pad_16[16];  // 0x10(0x10)
	struct FString RubyText;  // 0x20(0x10)
	char pad_48[8];  // 0x30(0x8)
	int32_t CurrentCharIndex;  // 0x38(0x4)
	int32_t SegmentReferenceIndex;  // 0x3C(0x4)
	struct FName Name;  // 0x40(0x8)
	struct FVector2D BlockSize;  // 0x48(0x10)
	struct FVector2D RubyTextBlockSize;  // 0x58(0x10)

}; 
// Function HorizonUI.HorizonMultiToggleButtonWidget.GetCurrentStateIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentStateIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// ScriptStruct HorizonUI.HorizonDialogueSegmentInfo
// Size: 0x270(Inherited: 0x0) 
struct FHorizonDialogueSegmentInfo
{
	struct FString Text;  // 0x0(0x10)
	struct FSlateColor ColorAndOpacity;  // 0x10(0x14)
	char pad_36[4];  // 0x24(0x4)
	struct FSlateFontInfo Font;  // 0x28(0x58)
	struct FVector2D ShadowOffset;  // 0x80(0x10)
	struct FSlateColor ShadowColorAndOpacity;  // 0x90(0x14)
	float DialogueMsgSpeed;  // 0xA4(0x4)
	float DialogueMsgWait;  // 0xA8(0x4)
	char pad_172[4];  // 0xAC(0x4)
	struct FMargin PaddingMargin;  // 0xB0(0x10)
	struct FSlateColor HypertextHoveredColor;  // 0xC0(0x14)
	struct FSlateColor HypertextVisitedColor;  // 0xD4(0x14)
	UHorizonButton* BackgroundButtonClass;  // 0xE8(0x8)
	float DialogueSoundVolumeMultiplier;  // 0xF0(0x4)
	float DialogueSoundPitchMultiplier;  // 0xF4(0x4)
	float DialogueSoundStartTime;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)
	struct USoundBase* DialogueSound;  // 0x100(0x8)
	char pad_264[136];  // 0x108(0x88)
	struct FString EventPayload;  // 0x190(0x10)
	struct TArray<struct FString> Tags;  // 0x1A0(0x10)
	struct FHorizonDialogueRubyTextInfo RubyTextInfo;  // 0x1B0(0xC0)

}; 
// ScriptStruct HorizonUI.HorizonDialogueRubyTextInfo
// Size: 0xC0(Inherited: 0x0) 
struct FHorizonDialogueRubyTextInfo
{
	char pad_0[24];  // 0x0(0x18)
	struct FSlateColor ColorAndOpacity;  // 0x18(0x14)
	char pad_44[4];  // 0x2C(0x4)
	struct FSlateFontInfo Font;  // 0x30(0x58)
	struct FVector2D ShadowOffset;  // 0x88(0x10)
	struct FSlateColor ShadowColorAndOpacity;  // 0x98(0x14)
	struct FMargin PaddingMargin;  // 0xAC(0x10)
	char pad_188[4];  // 0xBC(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsStartTickDialogueMsg
// Size: 0x2(Inherited: 0x0) 
struct FSetIsStartTickDialogueMsg
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldStartTick : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bShouldResetDialogue : 1;  // 0x1(0x1)

}; 
// DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonDialoguePageEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnHorizonDialoguePageEvent__DelegateSignature
{
	struct FHorizonDialogueDialoguePageResult InResult;  // 0x0(0x4)

}; 
// ScriptStruct HorizonUI.HorizonDialogueDialoguePageResult
// Size: 0x4(Inherited: 0x0) 
struct FHorizonDialogueDialoguePageResult
{
	int32_t PageIndex;  // 0x0(0x4)

}; 
// ScriptStruct HorizonUI.HorizonDialogueBlinkingCursorInfo
// Size: 0x70(Inherited: 0x0) 
struct FHorizonDialogueBlinkingCursorInfo
{
	struct TSoftObjectPtr<UPaperFlipbook> Flipbook;  // 0x0(0x30)
	struct FSlateColor ColorAndOpacity;  // 0x30(0x14)
	char pad_68_1 : 7;  // 0x44(0x1)
	bool bUseSize : 1;  // 0x44(0x1)
	char pad_69[3];  // 0x45(0x3)
	struct FVector2D Size;  // 0x48(0x10)
	struct FVector2D PaddingPos;  // 0x58(0x10)
	char pad_104[8];  // 0x68(0x8)

}; 
// Function HorizonUI.HorizonTileView.RerouteItemHovered
// Size: 0x8(Inherited: 0x0) 
struct FRerouteItemHovered
{
	struct UObject* InItem;  // 0x0(0x8)

}; 
// DelegateFunction HorizonUI.HorizonDialogueMsgTextBlock.OnHorizonHypertextEvent__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnHorizonHypertextEvent__DelegateSignature
{
	struct FHorizonDialogueHypertextResult InResult;  // 0x0(0x78)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetShadowColorAndOpacity
// Size: 0x14(Inherited: 0x0) 
struct FSetShadowColorAndOpacity
{
	struct FLinearColor InShadowColorAndOpacity;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bForce : 1;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.PrevDialogueMsgPage
// Size: 0x1(Inherited: 0x0) 
struct FPrevDialogueMsgPage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldStartTick : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetAutoNextDialogueMsgPageIntervalRate
// Size: 0x4(Inherited: 0x0) 
struct FSetAutoNextDialogueMsgPageIntervalRate
{
	float InAutoNextDialogueMsgPageIntervalRate;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetDialogueMsgPage
// Size: 0x8(Inherited: 0x0) 
struct FSetDialogueMsgPage
{
	int32_t InPageIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bShouldStartTick : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct HorizonUI.HorizonDialogueSegmentInfoRubyTextStyle
// Size: 0x60(Inherited: 0x0) 
struct FHorizonDialogueSegmentInfoRubyTextStyle
{
	struct TArray<struct FString> Text;  // 0x0(0x10)
	struct TArray<struct FSlateColor> ColorAndOpacity;  // 0x10(0x10)
	struct TArray<struct FSlateFontInfo> Font;  // 0x20(0x10)
	struct TArray<struct FVector2D> ShadowOffset;  // 0x30(0x10)
	struct TArray<struct FSlateColor> ShadowColorAndOpacity;  // 0x40(0x10)
	struct TArray<struct FMargin> PaddingMargin;  // 0x50(0x10)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetDialogueMsgSpeed
// Size: 0x8(Inherited: 0x0) 
struct FSetDialogueMsgSpeed
{
	float Speed;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bForce : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetFont
// Size: 0x60(Inherited: 0x0) 
struct FSetFont
{
	struct FSlateFontInfo InFontInfo;  // 0x0(0x58)
	char pad_88_1 : 7;  // 0x58(0x1)
	bool bForce : 1;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function HorizonUI.HorizonTileView.BP_GetEntryWidgetFromItem
// Size: 0x10(Inherited: 0x0) 
struct FBP_GetEntryWidgetFromItem
{
	struct UObject* InItem;  // 0x0(0x8)
	struct UHorizonListViewItemWidget* ReturnValue;  // 0x8(0x8)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsRepeatDialogueMsg
// Size: 0x1(Inherited: 0x0) 
struct FSetIsRepeatDialogueMsg
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool B : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetFontSize
// Size: 0x4(Inherited: 0x0) 
struct FSetFontSize
{
	int32_t FontSize;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetIsAutoNextDialogueMsgPage
// Size: 0x1(Inherited: 0x0) 
struct FSetIsAutoNextDialogueMsgPage
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool B : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetJustification
// Size: 0x2(Inherited: 0x0) 
struct FSetJustification
{
	char ETextJustify InJustification;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bForce : 1;  // 0x1(0x1)

}; 
// Function HorizonUI.HorizonFlipbookWidget.SetCurrentAnimationDuration
// Size: 0x4(Inherited: 0x0) 
struct FSetCurrentAnimationDuration
{
	float InDuration;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetTextAndRebuildDialogue
// Size: 0x18(Inherited: 0x0) 
struct FSetTextAndRebuildDialogue
{
	struct FText InText;  // 0x0(0x18)

}; 
// Function HorizonUI.HorizonDialogueMsgTextBlock.SetTextOverflowWrapMethod
// Size: 0x1(Inherited: 0x0) 
struct FSetTextOverflowWrapMethod
{
	uint8_t  InOverflowWrapMethod;  // 0x0(0x1)

}; 
// ScriptStruct HorizonUI.HorizonDialogueSegmentInfoStyle
// Size: 0x278(Inherited: 0x0) 
struct FHorizonDialogueSegmentInfoStyle
{
	struct FName StyleName;  // 0x0(0x8)
	struct TArray<struct FString> Text;  // 0x8(0x10)
	struct TArray<struct FSlateColor> ColorAndOpacity;  // 0x18(0x10)
	struct TArray<struct FSlateFontInfo> Font;  // 0x28(0x10)
	struct TArray<int32_t> FontSize;  // 0x38(0x10)
	struct TArray<struct FName> TypefaceFontName;  // 0x48(0x10)
	struct TArray<struct FVector2D> ShadowOffset;  // 0x58(0x10)
	struct TArray<struct FSlateColor> ShadowColorAndOpacity;  // 0x68(0x10)
	struct TArray<float> DialogueMsgSpeed;  // 0x78(0x10)
	struct TArray<float> DialogueMsgWait;  // 0x88(0x10)
	struct TArray<struct FMargin> PaddingMargin;  // 0x98(0x10)
	struct TArray<struct FString> HypertextReference;  // 0xA8(0x10)
	struct TArray<struct FSlateColor> HypertextHoveredColor;  // 0xB8(0x10)
	struct TArray<struct FSlateColor> HypertextVisitedColor;  // 0xC8(0x10)
	struct TArray<UHorizonButton*> BackgroundButtonClass;  // 0xD8(0x10)
	struct TSoftObjectPtr<UTexture2D> Texture2D;  // 0xE8(0x30)
	struct TSoftObjectPtr<UMaterial> Material;  // 0x118(0x30)
	struct TSoftObjectPtr<UPaperSprite> PaperSprite;  // 0x148(0x30)
	struct TSoftObjectPtr<USoundBase> DialogueSound;  // 0x178(0x30)
	struct TArray<float> DialogueSoundVolumeMultiplier;  // 0x1A8(0x10)
	struct TArray<float> DialogueSoundPitchMultiplier;  // 0x1B8(0x10)
	struct TArray<float> DialogueSoundStartTime;  // 0x1C8(0x10)
	struct TSoftObjectPtr<UPaperFlipbook> PaperFlipbook;  // 0x1D8(0x30)
	struct TArray<struct FVector2D> ImageSize;  // 0x208(0x10)
	struct FHorizonDialogueSegmentInfoRubyTextStyle RubyTextStyleInfo;  // 0x218(0x60)

}; 
// Function HorizonUI.HorizonFlipbookWidget.GetCurrentAnimationDuration
// Size: 0x4(Inherited: 0x0) 
struct FGetCurrentAnimationDuration
{
	float ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction HorizonUI.HorizonFlipbookWidget.OnHorizonFlipbookStartEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnHorizonFlipbookStartEvent__DelegateSignature
{
	int32_t InCurrentNumOfLoop;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonFlipbookWidget.SetFlipbook
// Size: 0x8(Inherited: 0x0) 
struct FSetFlipbook
{
	struct UPaperFlipbook* InFlipbook;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonTileView.GetNumGeneratedChildren
// Size: 0x4(Inherited: 0x0) 
struct FGetNumGeneratedChildren
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonTileView.NavigateToAndSelectIndex
// Size: 0x4(Inherited: 0x0) 
struct FNavigateToAndSelectIndex
{
	int32_t InIndex;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonMultiToggleButtonWidget.GetToggleState_PrevIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetToggleState_PrevIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction HorizonUI.HorizonMultiToggleButtonWidget.OnHorizonMultiToggleButtonSyncEvent__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnHorizonMultiToggleButtonSyncEvent__DelegateSignature
{
	int32_t InCurrentStateIndex;  // 0x0(0x4)

}; 
// Function HorizonUI.HorizonMultiToggleButtonWidget.SetLoopToggleState
// Size: 0x1(Inherited: 0x0) 
struct FSetLoopToggleState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InLoopToggleState : 1;  // 0x0(0x1)

}; 
// ScriptStruct HorizonUI.HorizonMultiToggleButtonState
// Size: 0x100(Inherited: 0x0) 
struct FHorizonMultiToggleButtonState
{
	struct FText Text;  // 0x0(0x18)
	struct FLinearColor TextColor;  // 0x18(0x10)
	char pad_40[8];  // 0x28(0x8)
	struct FSlateBrush Brush;  // 0x30(0xD0)

}; 
// ScriptStruct HorizonUI.HorizonDialogueLineInfo
// Size: 0x38(Inherited: 0x0) 
struct FHorizonDialogueLineInfo
{
	int32_t CurrentDialogueBlockIndex;  // 0x0(0x4)
	int32_t MaxLineHeight;  // 0x4(0x4)
	int32_t LineWidth;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FHorizonDialogueBlockInfo> DialogueBlockInfoList;  // 0x10(0x10)
	struct FVector2D position;  // 0x20(0x10)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bNewPage : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function HorizonUI.HorizonRadioButtonUserWidget.BP_OnCheckStateChanged
// Size: 0x1(Inherited: 0x0) 
struct FBP_OnCheckStateChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsChecked : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonTileView.IsFocusable
// Size: 0x1(Inherited: 0x0) 
struct FIsFocusable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonTileView.IsPendingRefresh
// Size: 0x1(Inherited: 0x0) 
struct FIsPendingRefresh
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function HorizonUI.HorizonFileSystem.LoadSound
// Size: 0x18(Inherited: 0x0) 
struct FLoadSound
{
	struct FString InPackageFilePath;  // 0x0(0x10)
	struct USoundBase* ReturnValue;  // 0x10(0x8)

}; 
// DelegateFunction HorizonUI.HorizonTileView.OnInitListItemEvent__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnInitListItemEvent__DelegateSignature
{
	struct UHorizonTileView* InTileView;  // 0x0(0x8)

}; 
// DelegateFunction HorizonUI.HorizonTileView.OnItemEvent__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnItemEvent__DelegateSignature
{
	struct UObject* InItem;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonTileView.RerouteItemClicked
// Size: 0x8(Inherited: 0x0) 
struct FRerouteItemClicked
{
	struct UObject* InItem;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonTileView.RerouteItemPressed
// Size: 0x8(Inherited: 0x0) 
struct FRerouteItemPressed
{
	struct UObject* InItem;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonTileView.RerouteItemReleased
// Size: 0x8(Inherited: 0x0) 
struct FRerouteItemReleased
{
	struct UObject* InItem;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonTileView.RerouteItemUnhovered
// Size: 0x8(Inherited: 0x0) 
struct FRerouteItemUnhovered
{
	struct UObject* InItem;  // 0x0(0x8)

}; 
// ScriptStruct HorizonUI.HorizonDialoguePageInfo
// Size: 0xC(Inherited: 0x0) 
struct FHorizonDialoguePageInfo
{
	char pad_0[12];  // 0x0(0xC)

}; 
// Function HorizonUI.HorizonDialogueMsgDecorator.BuildSegment
// Size: 0x298(Inherited: 0x0) 
struct FBuildSegment
{
	struct UHorizonDialogueMsgTextBlock* InMsgTextBlock;  // 0x0(0x8)
	int32_t InCurrentSegInfoIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FHorizonDialogueSegmentInfo InCurrentSegInfo;  // 0x10(0x270)
	struct TArray<struct FHorizonDialogueSegmentInfo> InSegInfos;  // 0x280(0x10)
	char pad_656_1 : 7;  // 0x290(0x1)
	bool ReturnValue : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)

}; 
// Function HorizonUI.HorizonDialogueMsgDecorator.PreRun
// Size: 0x2E8(Inherited: 0x0) 
struct FPreRun
{
	struct UHorizonDialogueMsgTextBlock* InMsgTextBlock;  // 0x0(0x8)
	struct FHorizonDialogueBlockInfo InDialogueBlockInfo;  // 0x8(0x68)
	struct FHorizonDialogueSegmentInfo InSegInfo;  // 0x70(0x270)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool ReturnValue : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)

}; 
// Function HorizonUI.HorizonDialogueMsgDecorator.Run
// Size: 0x2E8(Inherited: 0x0) 
struct FRun
{
	struct UHorizonDialogueMsgTextBlock* InMsgTextBlock;  // 0x0(0x8)
	struct FHorizonDialogueBlockInfo InDialogueBlockInfo;  // 0x8(0x68)
	struct FHorizonDialogueSegmentInfo InSegInfo;  // 0x70(0x270)
	char pad_736_1 : 7;  // 0x2E0(0x1)
	bool ReturnValue : 1;  // 0x2E0(0x1)
	char pad_737[7];  // 0x2E1(0x7)

}; 
// Function HorizonUI.HorizonFileSystem.CreateDirectoryRecursively
// Size: 0x10(Inherited: 0x0) 
struct FCreateDirectoryRecursively
{
	struct FString InFolderToMake;  // 0x0(0x10)

}; 
// Function HorizonUI.HorizonFileSystem.GetInstance
// Size: 0x8(Inherited: 0x0) 
struct FGetInstance
{
	struct UHorizonFileSystem* ReturnValue;  // 0x0(0x8)

}; 
// Function HorizonUI.HorizonFileSystem.LoadMaterial
// Size: 0x18(Inherited: 0x0) 
struct FLoadMaterial
{
	struct FString InPackageFilePath;  // 0x0(0x10)
	struct UMaterial* ReturnValue;  // 0x10(0x8)

}; 
// Function HorizonUI.HorizonFileSystem.LoadPaperFlipbook
// Size: 0x18(Inherited: 0x0) 
struct FLoadPaperFlipbook
{
	struct FString InPackageFilePath;  // 0x0(0x10)
	struct UPaperFlipbook* ReturnValue;  // 0x10(0x8)

}; 
// Function HorizonUI.HorizonFileSystem.LoadTexture2D
// Size: 0x20(Inherited: 0x0) 
struct FLoadTexture2D
{
	struct FString InPackageFilePath;  // 0x0(0x10)
	int32_t OutWidth;  // 0x10(0x4)
	int32_t OutHeight;  // 0x14(0x4)
	struct UTexture2D* ReturnValue;  // 0x18(0x8)

}; 
// Function HorizonUI.HorizonFileSystem.LoadUAsset
// Size: 0x18(Inherited: 0x0) 
struct FLoadUAsset
{
	struct FString InPackageFilePath;  // 0x0(0x10)
	struct UObject* ReturnValue;  // 0x10(0x8)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.GetInputMode
// Size: 0x10(Inherited: 0x0) 
struct FGetInputMode
{
	struct APlayerController* InPC;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.GetParentCanvasPanelSlot
// Size: 0x10(Inherited: 0x0) 
struct FGetParentCanvasPanelSlot
{
	struct UWidget* pWidget;  // 0x0(0x8)
	struct UCanvasPanelSlot* ReturnValue;  // 0x8(0x8)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.GetUserIndex
// Size: 0x10(Inherited: 0x0) 
struct FGetUserIndex
{
	struct UWidget* InWidget;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.GetUserWidgetAnimation
// Size: 0x18(Inherited: 0x0) 
struct FGetUserWidgetAnimation
{
	struct UUserWidget* pUserWidget;  // 0x0(0x8)
	struct FName animeName;  // 0x8(0x8)
	struct UWidgetAnimation* ReturnValue;  // 0x10(0x8)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.GetWidgetFromNameRecursively
// Size: 0x18(Inherited: 0x0) 
struct FGetWidgetFromNameRecursively
{
	struct UUserWidget* pUserWidget;  // 0x0(0x8)
	struct FName InWidgetName;  // 0x8(0x8)
	struct UWidget* ReturnValue;  // 0x10(0x8)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.IsIdeographic
// Size: 0x8(Inherited: 0x0) 
struct FIsIdeographic
{
	int32_t InCodePoint;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.SetInputMode
// Size: 0x20(Inherited: 0x0) 
struct FSetInputMode
{
	struct APlayerController* InPC;  // 0x0(0x8)
	uint8_t  InInputMode;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)
	struct UWidget* InWidgetToFocus;  // 0x10(0x8)
	uint8_t  InMouseLockMode;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bInHideCursorDuringCapture : 1;  // 0x19(0x1)
	char pad_26[6];  // 0x1A(0x6)

}; 
// Function HorizonUI.HorizonWidgetFunctionLibrary.SetWidgetVisibility
// Size: 0x20(Inherited: 0x0) 
struct FSetWidgetVisibility
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct FName WidgetName;  // 0x8(0x8)
	uint8_t  eVisiblity;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UWidget* ReturnValue;  // 0x18(0x8)

}; 
