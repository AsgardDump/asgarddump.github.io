#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction GeometryCollectionEngine.OnChaosBreakEvent__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnChaosBreakEvent__DelegateSignature
{
	struct FChaosBreakEvent BreakEvent;  // 0x0(0x58)

}; 
// DelegateFunction GeometryCollectionEngine.OnChaosRemovalEvent__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnChaosRemovalEvent__DelegateSignature
{
	struct FChaosRemovalEvent RemovalEvent;  // 0x0(0x28)

}; 
// DelegateFunction GeometryCollectionEngine.OnChaosBreakingEvents__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnChaosBreakingEvents__DelegateSignature
{
	struct TArray<struct FChaosBreakingEventData> BreakingEvents;  // 0x0(0x10)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyBreaks
// Size: 0x1(Inherited: 0x0) 
struct FSetNotifyBreaks
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewNotifyBreaks : 1;  // 0x0(0x1)

}; 
// DelegateFunction GeometryCollectionEngine.OnChaosRemovalEvents__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnChaosRemovalEvents__DelegateSignature
{
	struct TArray<struct FChaosRemovalEventData> RemovalEvents;  // 0x0(0x10)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosBreakingEventRequestSettings
// Size: 0x18(Inherited: 0x0) 
struct FChaosBreakingEventRequestSettings
{
	int32_t MaxNumberOfResults;  // 0x0(0x4)
	float MinRadius;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinMass;  // 0xC(0x4)
	float MaxDistance;  // 0x10(0x4)
	uint8_t  SortMethod;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// DelegateFunction GeometryCollectionEngine.OnChaosCrumblingEvent__DelegateSignature
// Size: 0xC0(Inherited: 0x0) 
struct FOnChaosCrumblingEvent__DelegateSignature
{
	struct FChaosCrumblingEvent CrumbleEvent;  // 0x0(0xC0)

}; 
// ScriptStruct GeometryCollectionEngine.GeomComponentCacheParameters
// Size: 0x50(Inherited: 0x0) 
struct FGeomComponentCacheParameters
{
	uint8_t  CacheMode;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UGeometryCollectionCache* TargetCache;  // 0x8(0x8)
	float ReverseCacheBeginTime;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool SaveCollisionData : 1;  // 0x14(0x1)
	char pad_21_1 : 7;  // 0x15(0x1)
	bool DoGenerateCollisionData : 1;  // 0x15(0x1)
	char pad_22[2];  // 0x16(0x2)
	int32_t CollisionDataSizeMax;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool DoCollisionDataSpatialHash : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	float CollisionDataSpatialHashRadius;  // 0x20(0x4)
	int32_t MaxCollisionPerCell;  // 0x24(0x4)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool SaveBreakingData : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool DoGenerateBreakingData : 1;  // 0x29(0x1)
	char pad_42[2];  // 0x2A(0x2)
	int32_t BreakingDataSizeMax;  // 0x2C(0x4)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool DoBreakingDataSpatialHash : 1;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	float BreakingDataSpatialHashRadius;  // 0x34(0x4)
	int32_t MaxBreakingPerCell;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool SaveTrailingData : 1;  // 0x3C(0x1)
	char pad_61_1 : 7;  // 0x3D(0x1)
	bool DoGenerateTrailingData : 1;  // 0x3D(0x1)
	char pad_62[2];  // 0x3E(0x2)
	int32_t TrailingDataSizeMax;  // 0x40(0x4)
	float TrailingMinSpeedThreshold;  // 0x44(0x4)
	float TrailingMinVolumeThreshold;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// DelegateFunction GeometryCollectionEngine.OnChaosCollisionEvents__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnChaosCollisionEvents__DelegateSignature
{
	struct TArray<struct FChaosCollisionEventData> CollisionEvents;  // 0x0(0x10)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosBreakingEventData
// Size: 0x38(Inherited: 0x0) 
struct FChaosBreakingEventData
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector Velocity;  // 0x18(0x18)
	float Mass;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosTrailingEventRequestSettings
// Size: 0x18(Inherited: 0x0) 
struct FChaosTrailingEventRequestSettings
{
	int32_t MaxNumberOfResults;  // 0x0(0x4)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinAngularSpeed;  // 0xC(0x4)
	float MaxDistance;  // 0x10(0x4)
	uint8_t  SortMethod;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosCollisionEventData
// Size: 0x80(Inherited: 0x0) 
struct FChaosCollisionEventData
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector Normal;  // 0x18(0x18)
	struct FVector Velocity1;  // 0x30(0x18)
	struct FVector Velocity2;  // 0x48(0x18)
	float Mass1;  // 0x60(0x4)
	float Mass2;  // 0x64(0x4)
	struct FVector Impulse;  // 0x68(0x18)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosRemovalEventData
// Size: 0x20(Inherited: 0x0) 
struct FChaosRemovalEventData
{
	struct FVector Location;  // 0x0(0x18)
	float Mass;  // 0x18(0x4)
	int32_t ParticleIndex;  // 0x1C(0x4)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventRequestSettings
// Size: 0x18(Inherited: 0x0) 
struct FSetBreakingEventRequestSettings
{
	struct FChaosBreakingEventRequestSettings InSettings;  // 0x0(0x18)

}; 
// DelegateFunction GeometryCollectionEngine.OnChaosTrailingEvents__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnChaosTrailingEvents__DelegateSignature
{
	struct TArray<struct FChaosTrailingEventData> TrailingEvents;  // 0x0(0x10)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosTrailingEventData
// Size: 0x50(Inherited: 0x0) 
struct FChaosTrailingEventData
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector Velocity;  // 0x18(0x18)
	struct FVector AngularVelocity;  // 0x30(0x18)
	float Mass;  // 0x48(0x4)
	int32_t ParticleIndex;  // 0x4C(0x4)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyAngularVelocity
// Size: 0x20(Inherited: 0x0) 
struct FApplyAngularVelocity
{
	int32_t ItemIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector AngularVelocity;  // 0x8(0x18)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionLevelSetData
// Size: 0x10(Inherited: 0x0) 
struct FGeometryCollectionLevelSetData
{
	int32_t MinLevelSetResolution;  // 0x0(0x4)
	int32_t MaxLevelSetResolution;  // 0x4(0x4)
	int32_t MinClusterLevelSetResolution;  // 0x8(0x4)
	int32_t MaxClusterLevelSetResolution;  // 0xC(0x4)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyInternalStrain
// Size: 0x30(Inherited: 0x0) 
struct FApplyInternalStrain
{
	int32_t ItemIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector Location;  // 0x8(0x18)
	float Radius;  // 0x20(0x4)
	int32_t PropagationDepth;  // 0x24(0x4)
	float PropagationFactor;  // 0x28(0x4)
	float Strain;  // 0x2C(0x4)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyBreakingAngularVelocity
// Size: 0x20(Inherited: 0x0) 
struct FApplyBreakingAngularVelocity
{
	int32_t ItemIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector AngularVelocity;  // 0x8(0x18)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetCollisionEventEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsEnabled : 1;  // 0x0(0x1)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyBreakingLinearVelocity
// Size: 0x20(Inherited: 0x0) 
struct FApplyBreakingLinearVelocity
{
	int32_t ItemIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector LinearVelocity;  // 0x8(0x18)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.GetMassAndExtents
// Size: 0x40(Inherited: 0x0) 
struct FGetMassAndExtents
{
	int32_t ItemIndex;  // 0x0(0x4)
	float OutMass;  // 0x4(0x4)
	struct FBox OutExtents;  // 0x8(0x38)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyLinearVelocity
// Size: 0x20(Inherited: 0x0) 
struct FApplyLinearVelocity
{
	int32_t ItemIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector LinearVelocity;  // 0x8(0x18)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyExternalStrain
// Size: 0x30(Inherited: 0x0) 
struct FApplyExternalStrain
{
	int32_t ItemIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector Location;  // 0x8(0x18)
	float Radius;  // 0x20(0x4)
	int32_t PropagationDepth;  // 0x24(0x4)
	float PropagationFactor;  // 0x28(0x4)
	float Strain;  // 0x2C(0x4)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SortTrailingEvents
// Size: 0x18(Inherited: 0x0) 
struct FSortTrailingEvents
{
	struct TArray<struct FChaosTrailingEventData> TrailingEvents;  // 0x0(0x10)
	uint8_t  SortMethod;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyKinematicField
// Size: 0x20(Inherited: 0x0) 
struct FApplyKinematicField
{
	float Radius;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FVector position;  // 0x8(0x18)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionSizeSpecificData
// Size: 0x20(Inherited: 0x0) 
struct FGeometryCollectionSizeSpecificData
{
	float MaxSize;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct FGeometryCollectionCollisionTypeData> CollisionShapes;  // 0x8(0x10)
	int32_t DamageThreshold;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ApplyPhysicsField
// Size: 0x18(Inherited: 0x0) 
struct FApplyPhysicsField
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Enabled : 1;  // 0x0(0x1)
	uint8_t  Target;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct UFieldSystemMetaData* MetaData;  // 0x8(0x8)
	struct UFieldNodeBase* Field;  // 0x10(0x8)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyRemovals
// Size: 0x1(Inherited: 0x0) 
struct FSetNotifyRemovals
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewNotifyRemovals : 1;  // 0x0(0x1)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.CrumbleCluster
// Size: 0x4(Inherited: 0x0) 
struct FCrumbleCluster
{
	int32_t ItemIndex;  // 0x0(0x4)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventRequestSettings
// Size: 0x10(Inherited: 0x0) 
struct FSetRemovalEventRequestSettings
{
	struct FChaosRemovalEventRequestSettings InSettings;  // 0x0(0x10)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.GetInitialLevel
// Size: 0x8(Inherited: 0x0) 
struct FGetInitialLevel
{
	int32_t ItemIndex;  // 0x0(0x4)
	int32_t ReturnValue;  // 0x4(0x4)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionDebugDrawWarningMessage
// Size: 0x1(Inherited: 0x0) 
struct FGeometryCollectionDebugDrawWarningMessage
{
	char pad_0[1];  // 0x0(0x1)

}; 
// DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FNotifyGeometryCollectionPhysicsLoadingStateChange__DelegateSignature
{
	struct UGeometryCollectionComponent* FracturedComponent;  // 0x0(0x8)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventRequestSettings
// Size: 0x18(Inherited: 0x0) 
struct FSetTrailingEventRequestSettings
{
	struct FChaosTrailingEventRequestSettings InSettings;  // 0x0(0x18)

}; 
// DelegateFunction GeometryCollectionEngine.GeometryCollectionComponent.NotifyGeometryCollectionPhysicsStateChange__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FNotifyGeometryCollectionPhysicsStateChange__DelegateSignature
{
	struct UGeometryCollectionComponent* FracturedComponent;  // 0x0(0x8)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetCollisionEventRequestSettings
// Size: 0x18(Inherited: 0x0) 
struct FSetCollisionEventRequestSettings
{
	struct FChaosCollisionEventRequestSettings InSettings;  // 0x0(0x18)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.ReceivePhysicsCollision
// Size: 0xC0(Inherited: 0x0) 
struct FReceivePhysicsCollision
{
	struct FChaosPhysicsCollisionInfo CollisionInfo;  // 0x0(0xC0)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetTrailingEventEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetTrailingEventEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsEnabled : 1;  // 0x0(0x1)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.SetNotifyCrumblings
// Size: 0x1(Inherited: 0x0) 
struct FSetNotifyCrumblings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bNewNotifyCrumblings : 1;  // 0x0(0x1)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionDebugDrawActorSelectedRigidBody
// Size: 0x18(Inherited: 0x0) 
struct FGeometryCollectionDebugDrawActorSelectedRigidBody
{
	int32_t ID;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct AChaosSolverActor* Solver;  // 0x8(0x8)
	struct AGeometryCollectionActor* GeometryCollection;  // 0x10(0x8)

}; 
// Function GeometryCollectionEngine.GeometryCollectionComponent.SetRestCollection
// Size: 0x8(Inherited: 0x0) 
struct FSetRestCollection
{
	struct UGeometryCollection* RestCollectionIn;  // 0x0(0x8)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionRepData
// Size: 0x28(Inherited: 0x0) 
struct FGeometryCollectionRepData
{
	char pad_0[40];  // 0x0(0x28)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SortCollisionEvents
// Size: 0x18(Inherited: 0x0) 
struct FSortCollisionEvents
{
	struct TArray<struct FChaosCollisionEventData> CollisionEvents;  // 0x0(0x10)
	uint8_t  SortMethod;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionDamagePropagationData
// Size: 0xC(Inherited: 0x0) 
struct FGeometryCollectionDamagePropagationData
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float BreakDamagePropagationFactor;  // 0x4(0x4)
	float ShockDamagePropagationFactor;  // 0x8(0x4)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosCollisionEventRequestSettings
// Size: 0x18(Inherited: 0x0) 
struct FChaosCollisionEventRequestSettings
{
	int32_t MaxNumberResults;  // 0x0(0x4)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinImpulse;  // 0xC(0x4)
	float MaxDistance;  // 0x10(0x4)
	uint8_t  SortMethod;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.AddGeometryCollectionActor
// Size: 0x8(Inherited: 0x0) 
struct FAddGeometryCollectionActor
{
	struct AGeometryCollectionActor* GeometryCollectionActor;  // 0x0(0x8)

}; 
// ScriptStruct GeometryCollectionEngine.ChaosRemovalEventRequestSettings
// Size: 0x10(Inherited: 0x0) 
struct FChaosRemovalEventRequestSettings
{
	int32_t MaxNumberOfResults;  // 0x0(0x4)
	float MinMass;  // 0x4(0x4)
	float MaxDistance;  // 0x8(0x4)
	uint8_t  SortMethod;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionSource
// Size: 0xA0(Inherited: 0x0) 
struct FGeometryCollectionSource
{
	struct FSoftObjectPath SourceGeometryObject;  // 0x0(0x20)
	struct FTransform LocalTransform;  // 0x20(0x60)
	struct TArray<struct UMaterialInterface*> SourceMaterial;  // 0x80(0x10)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bAddInternalMaterials : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool bSplitComponents : 1;  // 0x91(0x1)
	char pad_146[14];  // 0x92(0xE)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.IsEventListening
// Size: 0x1(Inherited: 0x0) 
struct FIsEventListening
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionAutoInstanceMesh
// Size: 0x30(Inherited: 0x0) 
struct FGeometryCollectionAutoInstanceMesh
{
	struct FSoftObjectPath StaticMesh;  // 0x0(0x20)
	struct TArray<struct UMaterialInterface*> Materials;  // 0x20(0x10)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionEmbeddedExemplar
// Size: 0x30(Inherited: 0x0) 
struct FGeometryCollectionEmbeddedExemplar
{
	struct FSoftObjectPath StaticMeshExemplar;  // 0x0(0x20)
	float StartCullDistance;  // 0x20(0x4)
	float EndCullDistance;  // 0x24(0x4)
	int32_t InstanceCount;  // 0x28(0x4)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionCollisionParticleData
// Size: 0x8(Inherited: 0x0) 
struct FGeometryCollectionCollisionParticleData
{
	float CollisionParticlesFraction;  // 0x0(0x4)
	int32_t MaximumCollisionParticles;  // 0x4(0x4)

}; 
// ScriptStruct GeometryCollectionEngine.GeometryCollectionCollisionTypeData
// Size: 0x24(Inherited: 0x0) 
struct FGeometryCollectionCollisionTypeData
{
	uint8_t  CollisionType;  // 0x0(0x1)
	uint8_t  ImplicitType;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	struct FGeometryCollectionLevelSetData LevelSet;  // 0x4(0x10)
	struct FGeometryCollectionCollisionParticleData CollisionParticles;  // 0x14(0x8)
	float CollisionObjectReductionPercentage;  // 0x1C(0x4)
	float CollisionMarginFraction;  // 0x20(0x4)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.AddChaosSolverActor
// Size: 0x8(Inherited: 0x0) 
struct FAddChaosSolverActor
{
	struct AChaosSolverActor* ChaosSolverActor;  // 0x0(0x8)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.RemoveChaosSolverActor
// Size: 0x8(Inherited: 0x0) 
struct FRemoveChaosSolverActor
{
	struct AChaosSolverActor* ChaosSolverActor;  // 0x0(0x8)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.RemoveGeometryCollectionActor
// Size: 0x8(Inherited: 0x0) 
struct FRemoveGeometryCollectionActor
{
	struct AGeometryCollectionActor* GeometryCollectionActor;  // 0x0(0x8)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetBreakingEventEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetBreakingEventEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsEnabled : 1;  // 0x0(0x1)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SetRemovalEventEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetRemovalEventEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsEnabled : 1;  // 0x0(0x1)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SortBreakingEvents
// Size: 0x18(Inherited: 0x0) 
struct FSortBreakingEvents
{
	struct TArray<struct FChaosBreakingEventData> BreakingEvents;  // 0x0(0x10)
	uint8_t  SortMethod;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function GeometryCollectionEngine.ChaosDestructionListener.SortRemovalEvents
// Size: 0x18(Inherited: 0x0) 
struct FSortRemovalEvents
{
	struct TArray<struct FChaosRemovalEventData> RemovalEvents;  // 0x0(0x10)
	uint8_t  SortMethod;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function GeometryCollectionEngine.GeometryCollectionActor.RaycastSingle
// Size: 0x120(Inherited: 0x0) 
struct FRaycastSingle
{
	struct FVector Start;  // 0x0(0x18)
	struct FVector End;  // 0x18(0x18)
	struct FHitResult OutHit;  // 0x30(0xE8)
	char pad_280_1 : 7;  // 0x118(0x1)
	bool ReturnValue : 1;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)

}; 
