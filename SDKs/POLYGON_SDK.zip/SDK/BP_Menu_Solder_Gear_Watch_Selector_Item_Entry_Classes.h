#pragma once 
#include <BP_Menu_Solder_Gear_Watch_Selector_Item_Entry_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_Menu_Solder_Gear_Watch_Selector_Item_Entry.BP_Menu_Solder_Gear_Watch_Selector_Item_Entry_C
// Size: 0x40(Inherited: 0x28) 
struct UBP_Menu_Solder_Gear_Watch_Selector_Item_Entry_C : public UObject
{
	struct FST_ItemInfo WatchInfo;  // 0x28(0x10)
	struct UUI_Menu_Solder_Gear_Watch_Selector_Item_C* WidgetRef;  // 0x38(0x8)

}; 



