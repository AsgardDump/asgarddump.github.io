#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct MeshModelingToolsExp.BakeMultiMeshDetailProperties
// Size: 0x18(Inherited: 0x0) 
struct FBakeMultiMeshDetailProperties
{
	struct UStaticMesh* SourceMesh;  // 0x0(0x8)
	struct UTexture2D* SourceTexture;  // 0x8(0x8)
	int32_t SourceTextureUVLayer;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct MeshModelingToolsExp.PhysicsConvexData
// Size: 0x38(Inherited: 0x0) 
struct FPhysicsConvexData
{
	int32_t NumVertices;  // 0x0(0x4)
	int32_t NumFaces;  // 0x4(0x4)
	struct FKShapeElem Element;  // 0x8(0x30)

}; 
// ScriptStruct MeshModelingToolsExp.PhysicsCapsuleData
// Size: 0xA0(Inherited: 0x0) 
struct FPhysicsCapsuleData
{
	float Radius;  // 0x0(0x4)
	float Length;  // 0x4(0x4)
	char pad_8[8];  // 0x8(0x8)
	struct FTransform Transform;  // 0x10(0x60)
	struct FKShapeElem Element;  // 0x70(0x30)

}; 
// ScriptStruct MeshModelingToolsExp.PerlinLayerProperties
// Size: 0x8(Inherited: 0x0) 
struct FPerlinLayerProperties
{
	float Frequency;  // 0x0(0x4)
	float Intensity;  // 0x4(0x4)

}; 
// Function MeshModelingToolsExp.SelectiveTessellationProperties.GetMaterialIDsFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetMaterialIDsFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct MeshModelingToolsExp.EditPivotTarget
// Size: 0x10(Inherited: 0x0) 
struct FEditPivotTarget
{
	struct UTransformProxy* TransformProxy;  // 0x0(0x8)
	struct UCombinedTransformGizmo* TransformGizmo;  // 0x8(0x8)

}; 
// ScriptStruct MeshModelingToolsExp.PhysicsBoxData
// Size: 0xB0(Inherited: 0x0) 
struct FPhysicsBoxData
{
	struct FVector Dimensions;  // 0x0(0x18)
	char pad_24[8];  // 0x18(0x8)
	struct FTransform Transform;  // 0x20(0x60)
	struct FKShapeElem Element;  // 0x80(0x30)

}; 
// ScriptStruct MeshModelingToolsExp.PhysicsSphereData
// Size: 0xA0(Inherited: 0x0) 
struct FPhysicsSphereData
{
	float Radius;  // 0x0(0x4)
	char pad_4[12];  // 0x4(0xC)
	struct FTransform Transform;  // 0x10(0x60)
	struct FKShapeElem Element;  // 0x70(0x30)

}; 
// ScriptStruct MeshModelingToolsExp.PhysicsLevelSetData
// Size: 0x30(Inherited: 0x0) 
struct FPhysicsLevelSetData
{
	struct FKShapeElem Element;  // 0x0(0x30)

}; 
// ScriptStruct MeshModelingToolsExp.BrushToolRadius
// Size: 0x14(Inherited: 0x0) 
struct FBrushToolRadius
{
	uint8_t  SizeType;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float AdaptiveSize;  // 0x4(0x4)
	float WorldRadius;  // 0x8(0x4)
	char pad_12[8];  // 0xC(0x8)

}; 
// ScriptStruct MeshModelingToolsExp.TransformMeshesTarget
// Size: 0x10(Inherited: 0x0) 
struct FTransformMeshesTarget
{
	struct UTransformProxy* TransformProxy;  // 0x0(0x8)
	struct UCombinedTransformGizmo* TransformGizmo;  // 0x8(0x8)

}; 
// Function MeshModelingToolsExp.BakeInputMeshProperties.GetSourceUVLayerNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetSourceUVLayerNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.BakeRenderCaptureInputToolProperties.GetTargetUVLayerNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetTargetUVLayerNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.BakeMultiTexture2DProperties.GetUVLayerNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetUVLayerNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.BakeRenderCaptureToolProperties.GetMapPreviewNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetMapPreviewNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.BakeRenderCaptureInputToolProperties.GetTargetUVLayerIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetTargetUVLayerIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function MeshModelingToolsExp.OutputPolygroupLayerProperties.GetGroupOptionsList
// Size: 0x10(Inherited: 0x0) 
struct FGetGroupOptionsList
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.DisplaceMeshCommonProperties.GetWeightMapsFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetWeightMapsFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.MeshAttributePaintToolProperties.GetAttributeNames
// Size: 0x10(Inherited: 0x0) 
struct FGetAttributeNames
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.TransferMeshToolProperties.GetSourceLODNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetSourceLODNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function MeshModelingToolsExp.TransferMeshToolProperties.GetTargetLODNamesFunc
// Size: 0x10(Inherited: 0x0) 
struct FGetTargetLODNamesFunc
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
