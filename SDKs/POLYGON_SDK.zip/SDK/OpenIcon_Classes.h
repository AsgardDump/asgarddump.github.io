#pragma once 
#include <OpenIcon_Structs.h>
 
 
 
// Class OpenIcon.CustomIcon
// Size: 0x390(Inherited: 0x340) 
struct UCustomIcon : public UTextBlock
{
	struct UDataTable* IconData;  // 0x338(0x8)
	struct UObject* IconFont;  // 0x340(0x8)
	int32_t IconSize;  // 0x348(0x4)
	struct FString IconPack;  // 0x350(0x10)
	struct FString IconCategory;  // 0x360(0x10)
	struct FText IconSymbol;  // 0x370(0x18)
	char pad_908[4];  // 0x38C(0x4)

	void SetIconByID(struct FName IconID, int32_t Size); // Function OpenIcon.CustomIcon.SetIconByID
	void InitCustomIcon(struct UDataTable* InIconData, struct UObject* InIconFont); // Function OpenIcon.CustomIcon.InitCustomIcon
}; 



// Class OpenIcon.OpenIcon
// Size: 0x390(Inherited: 0x340) 
struct UOpenIcon : public UTextBlock
{
	uint8_t  IconSource;  // 0x338(0x1)
	uint8_t  FA_Category;  // 0x339(0x1)
	uint8_t  MD_Category;  // 0x33A(0x1)
	uint8_t  FK_Category;  // 0x33B(0x1)
	struct FString IconCategory;  // 0x340(0x10)
	int32_t IconSize;  // 0x350(0x4)
	struct FText IconSymbol;  // 0x358(0x18)
	struct UDataTable* OpenIconDT;  // 0x370(0x8)
	struct UObject* OpenIconFontObject;  // 0x378(0x8)
	char pad_896[16];  // 0x380(0x10)

	void SetIconByID(struct FName IconID, int32_t Size); // Function OpenIcon.OpenIcon.SetIconByID
	void SetIcon(uint8_t  Source, struct FString Category, struct FString IconUcode, int32_t Size); // Function OpenIcon.OpenIcon.SetIcon
}; 



// Class OpenIcon.OpenIconUtil
// Size: 0x28(Inherited: 0x28) 
struct UOpenIconUtil : public UBlueprintFunctionLibrary
{

	struct UTexture2D* OpenIconToTexture_Advanced(struct FVector2D Translation, struct FSlateColor ColorAndOpacity, struct FLinearColor ShadowColorAndOpacity, struct FVector2D ShadowOffset, struct FFontOutlineSettings OutlineSettings, struct FSlateBrush StrikeBrush, struct FName IconID, int32_t IconSize, uint8_t  OutputSize, struct FString Path, struct FString Filename, bool UseDefaultName); // Function OpenIcon.OpenIconUtil.OpenIconToTexture_Advanced
	struct UTexture2D* OpenIconToTexture(struct FName IconID, int32_t IconSize, uint8_t  OutputSize, struct FString Path, struct FString Filename, bool UseDefaultName); // Function OpenIcon.OpenIconUtil.OpenIconToTexture
	bool GetCustomIconDataFromTable(struct UDataTable* DataTable, struct TArray<struct FCustomIconData>& OutData); // Function OpenIcon.OpenIconUtil.GetCustomIconDataFromTable
	struct UTexture2D* CustomIconToTexture_Advanced(struct FVector2D Translation, struct FSlateColor ColorAndOpacity, struct FLinearColor ShadowColorAndOpacity, struct FVector2D ShadowOffset, struct FFontOutlineSettings OutlineSettings, struct FSlateBrush StrikeBrush, struct UDataTable* IconData, struct UFont* IconFont, struct FName IconID, int32_t IconSize, uint8_t  OutputSize, struct FString Path, struct FString Filename, bool UseDefaultName); // Function OpenIcon.OpenIconUtil.CustomIconToTexture_Advanced
	struct UTexture2D* CustomIconToTexture(struct UDataTable* IconData, struct UFont* IconFont, struct FName IconID, int32_t IconSize, uint8_t  OutputSize, struct FString Path, struct FString Filename, bool UseDefaultName); // Function OpenIcon.OpenIconUtil.CustomIconToTexture
	void CopyToClipboard(struct FString S); // Function OpenIcon.OpenIconUtil.CopyToClipboard
}; 



