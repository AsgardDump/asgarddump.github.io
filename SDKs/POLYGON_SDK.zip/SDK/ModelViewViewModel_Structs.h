#pragma once 
#include "SDK.h" 
 
 
// Function ModelViewViewModel.MVVMViewModelBase.K2_RemoveFieldValueChangedDelegate
// Size: 0x18(Inherited: 0x0) 
struct FK2_RemoveFieldValueChangedDelegate
{
	struct FFieldNotificationId FieldId;  // 0x0(0x8)
	struct FDelegate Delegate;  // 0x8(0x10)

}; 
// ScriptStruct ModelViewViewModel.MVVMBindingName
// Size: 0x8(Inherited: 0x0) 
struct FMVVMBindingName
{
	struct FName BindingName;  // 0x0(0x8)

}; 
// Function ModelViewViewModel.MVVMViewModelBase.K2_BroadcastFieldValueChanged
// Size: 0x8(Inherited: 0x0) 
struct FK2_BroadcastFieldValueChanged
{
	struct FFieldNotificationId FieldId;  // 0x0(0x8)

}; 
// ScriptStruct ModelViewViewModel.MVVMAvailableBinding
// Size: 0xC(Inherited: 0x0) 
struct FMVVMAvailableBinding
{
	struct FMVVMBindingName BindingName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsReadable : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool bIsWritable : 1;  // 0x9(0x1)
	char pad_10_1 : 7;  // 0xA(0x1)
	bool bHasNotify : 1;  // 0xA(0x1)
	char pad_11[1];  // 0xB(0x1)

}; 
// ScriptStruct ModelViewViewModel.MVVMVCompiledFields
// Size: 0x10(Inherited: 0x0) 
struct FMVVMVCompiledFields
{
	struct UStruct* ClassOrScriptStruct;  // 0x0(0x8)
	int16_t LibraryStartIndex;  // 0x8(0x2)
	int16_t NumberOfProperties;  // 0xA(0x2)
	int16_t NumberOfFunctions;  // 0xC(0x2)
	int16_t NumberOfFieldIds;  // 0xE(0x2)

}; 
// ScriptStruct ModelViewViewModel.MVVMViewModelContextInstance
// Size: 0x18(Inherited: 0x0) 
struct FMVVMViewModelContextInstance
{
	struct FMVVMViewModelContext Context;  // 0x0(0x10)
	struct UMVVMViewModelBase* Instance;  // 0x10(0x8)

}; 
// ScriptStruct ModelViewViewModel.MVVMViewModelContext
// Size: 0x10(Inherited: 0x0) 
struct FMVVMViewModelContext
{
	UMVVMViewModelBase* ContextClass;  // 0x0(0x8)
	struct FName ContextName;  // 0x8(0x8)

}; 
// ScriptStruct ModelViewViewModel.MVVMCompiledLoadedPropertyOrFunctionIndex
// Size: 0x4(Inherited: 0x0) 
struct FMVVMCompiledLoadedPropertyOrFunctionIndex
{
	int16_t Index;  // 0x0(0x2)
	char bIsObjectProperty : 1;  // 0x2(0x1)
	char bIsScriptStructProperty : 1;  // 0x2(0x1)
	char bIsProperty : 1;  // 0x2(0x1)
	char pad_2_1 : 5;  // 0x2(0x1)
	char pad_3[2];  // 0x3(0x2)

}; 
// ScriptStruct ModelViewViewModel.MVVMVCompiledFieldPath
// Size: 0x4(Inherited: 0x0) 
struct FMVVMVCompiledFieldPath
{
	int16_t StartIndex;  // 0x0(0x2)
	int16_t Num;  // 0x2(0x2)

}; 
// ScriptStruct ModelViewViewModel.MVVMVCompiledFieldId
// Size: 0x2(Inherited: 0x0) 
struct FMVVMVCompiledFieldId
{
	int16_t FieldIdIndex;  // 0x0(0x2)

}; 
// Function ModelViewViewModel.MVVMSubsystem.GetViewFromUserWidget
// Size: 0x10(Inherited: 0x0) 
struct FGetViewFromUserWidget
{
	struct UUserWidget* UserWidget;  // 0x0(0x8)
	struct UMVVMView* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct ModelViewViewModel.MVVMVCompiledBinding
// Size: 0xC(Inherited: 0x0) 
struct FMVVMVCompiledBinding
{
	struct FMVVMVCompiledFieldPath SourceFieldPath;  // 0x0(0x4)
	struct FMVVMVCompiledFieldPath DestinationFieldPath;  // 0x4(0x4)
	struct FMVVMVCompiledFieldPath ConversionFunctionFieldPath;  // 0x8(0x4)

}; 
// ScriptStruct ModelViewViewModel.MVVMCompiledBindingLibrary
// Size: 0x60(Inherited: 0x0) 
struct FMVVMCompiledBindingLibrary
{
	char pad_0[16];  // 0x0(0x10)
	struct TArray<struct UFunction*> LoadedFunctions;  // 0x10(0x10)
	char pad_32[16];  // 0x20(0x10)
	struct TArray<struct FMVVMCompiledLoadedPropertyOrFunctionIndex> FieldPaths;  // 0x30(0x10)
	struct TArray<struct FMVVMVCompiledFields> CompiledFields;  // 0x40(0x10)
	struct TArray<struct FName> CompiledFieldNames;  // 0x50(0x10)

}; 
// Function ModelViewViewModel.MVVMView.SetViewModel
// Size: 0x18(Inherited: 0x0) 
struct FSetViewModel
{
	struct FName ViewModelName;  // 0x0(0x8)
	struct UMVVMViewModelBase* ViewModel;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ModelViewViewModel.MVVMViewModelCollection
// Size: 0x28(Inherited: 0x0) 
struct FMVVMViewModelCollection
{
	struct TArray<struct FMVVMViewModelContextInstance> ViewModelInstances;  // 0x0(0x10)
	char pad_16[24];  // 0x10(0x18)

}; 
// ScriptStruct ModelViewViewModel.MVVMViewClass_SourceCreator
// Size: 0x28(Inherited: 0x0) 
struct FMVVMViewClass_SourceCreator
{
	UObject* ExpectedSourceType;  // 0x0(0x8)
	struct FMVVMViewModelContext GlobalViewModelInstance;  // 0x8(0x10)
	struct FMVVMVCompiledFieldPath FieldPath;  // 0x18(0x4)
	struct FName PropertyName;  // 0x1C(0x8)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool bCreateInstance : 1;  // 0x24(0x1)
	char pad_37_1 : 7;  // 0x25(0x1)
	bool bOptional : 1;  // 0x25(0x1)
	char pad_38[2];  // 0x26(0x2)

}; 
// Function ModelViewViewModel.MVVMViewModelCollectionObject.RemoveViewModel
// Size: 0x18(Inherited: 0x0) 
struct FRemoveViewModel
{
	struct FMVVMViewModelContext Context;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct ModelViewViewModel.MVVMViewClass_CompiledBinding
// Size: 0x1C(Inherited: 0x0) 
struct FMVVMViewClass_CompiledBinding
{
	struct FMVVMVCompiledFieldId FieldId;  // 0x0(0x2)
	char pad_2[2];  // 0x2(0x2)
	struct FName SourcePropertyName;  // 0x4(0x8)
	struct FMVVMVCompiledBinding Binding;  // 0xC(0xC)
	uint8_t  UpdateMode;  // 0x18(0x1)
	char Flags;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)

}; 
// Function ModelViewViewModel.MVVMViewModelCollectionObject.AddViewModelInstance
// Size: 0x20(Inherited: 0x0) 
struct FAddViewModelInstance
{
	struct FMVVMViewModelContext Context;  // 0x0(0x10)
	struct UMVVMViewModelBase* ViewModel;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function ModelViewViewModel.MVVMSubsystem.DoesWidgetTreeContainedWidget
// Size: 0x18(Inherited: 0x0) 
struct FDoesWidgetTreeContainedWidget
{
	struct UWidgetTree* WidgetTree;  // 0x0(0x8)
	struct UWidget* ViewWidget;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function ModelViewViewModel.MVVMViewModelCollectionObject.FindViewModelInstance
// Size: 0x18(Inherited: 0x0) 
struct FFindViewModelInstance
{
	struct FMVVMViewModelContext Context;  // 0x0(0x10)
	struct UMVVMViewModelBase* ReturnValue;  // 0x10(0x8)

}; 
// Function ModelViewViewModel.MVVMViewModelBase.K2_SetPropertyValue
// Size: 0xC(Inherited: 0x0) 
struct FK2_SetPropertyValue
{
	int32_t OldValue;  // 0x0(0x4)
	int32_t NewValue;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function ModelViewViewModel.MVVMSubsystem.GetAvailableBinding
// Size: 0x28(Inherited: 0x0) 
struct FGetAvailableBinding
{
	UObject* Class;  // 0x0(0x8)
	struct FMVVMBindingName BindingName;  // 0x8(0x8)
	UObject* Accessor;  // 0x10(0x8)
	struct FMVVMAvailableBinding ReturnValue;  // 0x18(0xC)
	char pad_36[4];  // 0x24(0x4)

}; 
// Function ModelViewViewModel.MVVMSubsystem.GetAvailableBindings
// Size: 0x20(Inherited: 0x0) 
struct FGetAvailableBindings
{
	UObject* Class;  // 0x0(0x8)
	UObject* Accessor;  // 0x8(0x8)
	struct TArray<struct FMVVMAvailableBinding> ReturnValue;  // 0x10(0x10)

}; 
// Function ModelViewViewModel.MVVMSubsystem.GetGlobalViewModelCollection
// Size: 0x8(Inherited: 0x0) 
struct FGetGlobalViewModelCollection
{
	struct UMVVMViewModelCollectionObject* ReturnValue;  // 0x0(0x8)

}; 
// Function ModelViewViewModel.MVVMViewModelBase.K2_AddFieldValueChangedDelegate
// Size: 0x18(Inherited: 0x0) 
struct FK2_AddFieldValueChangedDelegate
{
	struct FFieldNotificationId FieldId;  // 0x0(0x8)
	struct FDelegate Delegate;  // 0x8(0x10)

}; 
// Function ModelViewViewModel.MVVMViewModelCollectionObject.RemoveAllViewModelInstance
// Size: 0x10(Inherited: 0x0) 
struct FRemoveAllViewModelInstance
{
	struct UMVVMViewModelBase* ViewModel;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
