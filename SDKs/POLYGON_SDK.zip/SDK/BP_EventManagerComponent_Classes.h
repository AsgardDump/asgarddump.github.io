#pragma once 
#include <BP_EventManagerComponent_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_EventManagerComponent.BP_EventManagerComponent_C
// Size: 0xA8(Inherited: 0xA0) 
struct UBP_EventManagerComponent_C : public UEventManagerComponent
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0xA0(0x8)

	void OnAmmoBoxAction(); // Function BP_EventManagerComponent.BP_EventManagerComponent_C.OnAmmoBoxAction
	void ExecuteUbergraph_BP_EventManagerComponent(int32_t EntryPoint); // Function BP_EventManagerComponent.BP_EventManagerComponent_C.ExecuteUbergraph_BP_EventManagerComponent
}; 



