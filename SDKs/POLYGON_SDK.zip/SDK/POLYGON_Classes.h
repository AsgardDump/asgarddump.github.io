#pragma once 
#include <POLYGON_Structs.h>
 
 
 
// Class POLYGON.PlayerCoreComponent
// Size: 0x188(Inherited: 0xA0) 
struct UPlayerCoreComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnTotalProgress;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnNewLevelReceived;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnAddedGameScore;  // 0xC0(0x10)
	char pad_208[8];  // 0xD0(0x8)
	int32_t InitialTotalProgress;  // 0xD8(0x4)
	int32_t TotalProgress;  // 0xDC(0x4)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bHasVipStatus : 1;  // 0xE0(0x1)
	char pad_225[167];  // 0xE1(0xA7)

	void UpdatePlayerCombinedInfo(struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.PlayerCoreComponent.UpdatePlayerCombinedInfo
	void Reset(); // Function POLYGON.PlayerCoreComponent.Reset
	void OnRep_TotalProgress(); // Function POLYGON.PlayerCoreComponent.OnRep_TotalProgress
	void NotifyAddedGameScore_client(struct TArray<struct FScoreInfo> ScoreInfos); // Function POLYGON.PlayerCoreComponent.NotifyAddedGameScore_client
	struct FLevelInfo GetNextLevelInfo(); // Function POLYGON.PlayerCoreComponent.GetNextLevelInfo
	struct FLevelInfo GetNextLevelByLevelID(struct FName LevelID); // Function POLYGON.PlayerCoreComponent.GetNextLevelByLevelID
	struct FLevelInfo GetLevelByProgress(int32_t Progress); // Function POLYGON.PlayerCoreComponent.GetLevelByProgress
	struct FLevelInfo GetCurrentLevelInfo(); // Function POLYGON.PlayerCoreComponent.GetCurrentLevelInfo
	void AddCredits(int32_t AddCredits); // Function POLYGON.PlayerCoreComponent.AddCredits
}; 



// Class POLYGON.ClientBackendComponent
// Size: 0x120(Inherited: 0xE0) 
struct UClientBackendComponent : public UGeneralBackendComponent
{
	struct FMulticastInlineDelegate OnSetPlayerId;  // 0xE0(0x10)
	struct FMulticastInlineDelegate OnUpdatePlayerCombinedInfo;  // 0xF0(0x10)
	struct FString PlayerMasterId;  // 0x100(0x10)
	struct UPlayFabJsonObject* PlayerCombinedInfo;  // 0x110(0x8)
	struct UPlayFabJsonObject* PlayerExperiments;  // 0x118(0x8)

	void SetPlayerId(struct FString newPlayerMasterId); // Function POLYGON.ClientBackendComponent.SetPlayerId
	void SetPlayerCombinedInfo(struct UPlayFabJsonObject* newPlayerCombinedInfo, struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.ClientBackendComponent.SetPlayerCombinedInfo
	void SerPlayerExperiments(struct UPlayFabJsonObject* Experiments); // Function POLYGON.ClientBackendComponent.SerPlayerExperiments
	bool IsClientLoggedIn(); // Function POLYGON.ClientBackendComponent.IsClientLoggedIn
	void GiveVipLocal(struct FString ID); // Function POLYGON.ClientBackendComponent.GiveVipLocal
	struct UPlayFabJsonObject* GetPlayerExperiments(); // Function POLYGON.ClientBackendComponent.GetPlayerExperiments
	struct UPlayFabJsonObject* GetPlayerCombinedInfo(); // Function POLYGON.ClientBackendComponent.GetPlayerCombinedInfo
}; 



// Class POLYGON.PG_GameState_Game
// Size: 0x4F0(Inherited: 0x300) 
struct APG_GameState_Game : public AGameState
{
	struct FMulticastInlineDelegate OnChangeGameState;  // 0x300(0x10)
	struct FMulticastInlineDelegate OnGameTimer;  // 0x310(0x10)
	struct FMulticastInlineDelegate OnCanMovePlayers;  // 0x320(0x10)
	struct FMulticastInlineDelegate OnTeamWon;  // 0x330(0x10)
	struct FMulticastInlineDelegate OnChangePlayersArray;  // 0x340(0x10)
	struct FMulticastInlineDelegate OnChangeTeamAlphaArray;  // 0x350(0x10)
	struct FMulticastInlineDelegate OnChangeTeamBravoArray;  // 0x360(0x10)
	struct FMulticastInlineDelegate OnChangeTotalScore;  // 0x370(0x10)
	struct FMulticastInlineDelegate OnServerFps;  // 0x380(0x10)
	uint8_t  GameState;  // 0x390(0x1)
	char pad_913[7];  // 0x391(0x7)
	struct FMapInfo CurrentMapInfo;  // 0x398(0xE0)
	uint16_t GameTimer;  // 0x478(0x2)
	char pad_1146_1 : 7;  // 0x47A(0x1)
	bool bCanMovePlayers : 1;  // 0x47A(0x1)
	uint8_t  WinningTeam;  // 0x47B(0x1)
	char pad_1148[4];  // 0x47C(0x4)
	struct TArray<struct APG_PlayerState_Game*> Players;  // 0x480(0x10)
	struct TArray<struct APG_PlayerState_Game*> TeamAlpha;  // 0x490(0x10)
	struct TArray<struct APG_PlayerState_Game*> TeamBravo;  // 0x4A0(0x10)
	struct TArray<struct ATeamBase*> AllTeamBases;  // 0x4B0(0x10)
	struct TArray<struct AControlPoint*> AllControlPoints;  // 0x4C0(0x10)
	struct TArray<struct APlayerStart*> PlayerStarts;  // 0x4D0(0x10)
	uint16_t ScoreAlphaTeam;  // 0x4E0(0x2)
	uint16_t ScoreBravoTeam;  // 0x4E2(0x2)
	char pad_1252[2];  // 0x4E4(0x2)
	char ServerFps;  // 0x4E6(0x1)
	char pad_1255[9];  // 0x4E7(0x9)

	void SetCanMovePlayers(bool newMoveState); // Function POLYGON.PG_GameState_Game.SetCanMovePlayers
	void OnRep_WinningTeam(); // Function POLYGON.PG_GameState_Game.OnRep_WinningTeam
	void OnRep_TeamBravo(); // Function POLYGON.PG_GameState_Game.OnRep_TeamBravo
	void OnRep_TeamAlpha(); // Function POLYGON.PG_GameState_Game.OnRep_TeamAlpha
	void OnRep_ServerFps(); // Function POLYGON.PG_GameState_Game.OnRep_ServerFps
	void OnRep_ScoreBravoTeam(); // Function POLYGON.PG_GameState_Game.OnRep_ScoreBravoTeam
	void OnRep_ScoreAlphaTeam(); // Function POLYGON.PG_GameState_Game.OnRep_ScoreAlphaTeam
	void OnRep_Players(); // Function POLYGON.PG_GameState_Game.OnRep_Players
	void OnRep_GameTimer(); // Function POLYGON.PG_GameState_Game.OnRep_GameTimer
	void OnRep_GameState(); // Function POLYGON.PG_GameState_Game.OnRep_GameState
	void OnRep_CanMovePlayers(); // Function POLYGON.PG_GameState_Game.OnRep_CanMovePlayers
	void NotifyPlayerWasKicked(struct FString badGuyName, bool bNameWasOptimized); // Function POLYGON.PG_GameState_Game.NotifyPlayerWasKicked
	int32_t GetScoreBravoTeam(); // Function POLYGON.PG_GameState_Game.GetScoreBravoTeam
	int32_t GetScoreAlphaTeam(); // Function POLYGON.PG_GameState_Game.GetScoreAlphaTeam
	int32_t GetMaxScoreForWin(); // Function POLYGON.PG_GameState_Game.GetMaxScoreForWin
	int32_t GetGameTimer(); // Function POLYGON.PG_GameState_Game.GetGameTimer
}; 



// Class POLYGON.TraceProjectile
// Size: 0x4A0(Inherited: 0x290) 
struct ATraceProjectile : public AActor
{
	struct FVector Velocity;  // 0x290(0x18)
	struct FRandomStream RandomStream;  // 0x2A8(0x8)
	char pad_688_1 : 7;  // 0x2B0(0x1)
	bool OwnerSafe : 1;  // 0x2B0(0x1)
	char pad_689[103];  // 0x2B1(0x67)
	struct UParticleSystemComponent* ActiveTraceComponent;  // 0x318(0x8)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool DebugEnabled : 1;  // 0x320(0x1)
	char pad_801[3];  // 0x321(0x3)
	float DebugTrailTime;  // 0x324(0x4)
	float DebugTrailWidth;  // 0x328(0x4)
	struct FLinearColor DebugTrailColorFast;  // 0x32C(0x10)
	struct FLinearColor DebugTrailColorSlow;  // 0x33C(0x10)
	char pad_844_1 : 7;  // 0x34C(0x1)
	bool DebugPooling : 1;  // 0x34C(0x1)
	char pad_845[3];  // 0x34D(0x3)
	struct FVector Wind;  // 0x350(0x18)
	uint8_t  AtmosphereType;  // 0x368(0x1)
	char pad_873[3];  // 0x369(0x3)
	float SeaLevelAirDensity;  // 0x36C(0x4)
	float SeaLevelSpeedOfSound;  // 0x370(0x4)
	char pad_884[4];  // 0x374(0x4)
	struct UCurveFloat* AirDensityCurve;  // 0x378(0x8)
	char pad_896_1 : 7;  // 0x380(0x1)
	bool SpeedOfSoundVariesWithAltitude : 1;  // 0x380(0x1)
	char pad_897[7];  // 0x381(0x7)
	struct UCurveFloat* SpeedOfSoundCurve;  // 0x388(0x8)
	char pad_912[4];  // 0x390(0x4)
	float SeaLevelAirPressure;  // 0x394(0x4)
	float SeaLevelAirTemperature;  // 0x398(0x4)
	float TemperatureLapseRate;  // 0x39C(0x4)
	float TropopauseAltitude;  // 0x3A0(0x4)
	float SpecificGasConstant;  // 0x3A4(0x4)
	struct FVector WorldCenterLocation;  // 0x3A8(0x18)
	char pad_960_1 : 7;  // 0x3C0(0x1)
	bool SphericalAltitude : 1;  // 0x3C0(0x1)
	char pad_961[3];  // 0x3C1(0x3)
	float SeaLevelRadius;  // 0x3C4(0x4)
	char pad_968_1 : 7;  // 0x3C8(0x1)
	bool OverrideGravity : 1;  // 0x3C8(0x1)
	char pad_969[7];  // 0x3C9(0x7)
	struct FVector Gravity;  // 0x3D0(0x18)
	char pad_1000_1 : 7;  // 0x3E8(0x1)
	bool SafeLaunch : 1;  // 0x3E8(0x1)
	char pad_1001_1 : 7;  // 0x3E9(0x1)
	bool SafeLaunchIgnoreAttachParent : 1;  // 0x3E9(0x1)
	char pad_1002_1 : 7;  // 0x3EA(0x1)
	bool SafeLaunchIgnoreAllAttached : 1;  // 0x3EA(0x1)
	char pad_1003[1];  // 0x3EB(0x1)
	float SafeDelay;  // 0x3EC(0x4)
	struct TArray<struct AActor*> SafeLaunchIgnoredActors;  // 0x3F0(0x10)
	float MuzzleVelocityMin;  // 0x400(0x4)
	float MuzzleVelocityMax;  // 0x404(0x4)
	float Spread;  // 0x408(0x4)
	float Mass;  // 0x40C(0x4)
	float Diameter;  // 0x410(0x4)
	float FormFactor;  // 0x414(0x4)
	struct UCurveFloat* MachDragCurve;  // 0x418(0x8)
	float GrazingAngleExponent;  // 0x420(0x4)
	float MinPenetration;  // 0x424(0x4)
	float MaxPenetration;  // 0x428(0x4)
	float PenetrationNormalization;  // 0x42C(0x4)
	float PenetrationNormalizationGrazing;  // 0x430(0x4)
	float PenetrationEntryAngleSpread;  // 0x434(0x4)
	float PenetrationExitAngleSpread;  // 0x438(0x4)
	float RicochetProbability;  // 0x43C(0x4)
	float RicochetProbabilityGrazing;  // 0x440(0x4)
	float RicochetRestitution;  // 0x444(0x4)
	float RicochetFriction;  // 0x448(0x4)
	float RicochetSpread;  // 0x44C(0x4)
	char pad_1104_1 : 7;  // 0x450(0x1)
	bool SpeedControlsRicochetProbability : 1;  // 0x450(0x1)
	char pad_1105_1 : 7;  // 0x451(0x1)
	bool AddImpulse : 1;  // 0x451(0x1)
	char pad_1106[2];  // 0x452(0x2)
	float ImpulseMultiplier;  // 0x454(0x4)
	uint8_t  DefaultPenTraceType;  // 0x458(0x1)
	char pad_1113[7];  // 0x459(0x7)
	struct UBallisticMaterialResponseMap* MaterialResponseMap;  // 0x460(0x8)
	char pad_1128_1 : 7;  // 0x468(0x1)
	bool MaterialDensityControlsPenetrationDepth : 1;  // 0x468(0x1)
	char pad_1129_1 : 7;  // 0x469(0x1)
	bool MaterialRestitutionControlsRicochet : 1;  // 0x469(0x1)
	char pad_1130_1 : 7;  // 0x46A(0x1)
	bool AllowComponentCollisions : 1;  // 0x46A(0x1)
	char ECollisionChannel TraceChannel;  // 0x46B(0x1)
	char pad_1132_1 : 7;  // 0x46C(0x1)
	bool TraceComplex : 1;  // 0x46C(0x1)
	char pad_1133[3];  // 0x46D(0x3)
	float CollisionMargin;  // 0x470(0x4)
	float DespawnVelocity;  // 0x474(0x4)
	struct TArray<struct AActor*> IgnoredActors;  // 0x478(0x10)
	char pad_1160_1 : 7;  // 0x488(0x1)
	bool DoFirstStepImmediately : 1;  // 0x488(0x1)
	char pad_1161_1 : 7;  // 0x489(0x1)
	bool RandomFirstStepDelta : 1;  // 0x489(0x1)
	char pad_1162[2];  // 0x48A(0x2)
	int32_t MaxTracesPerStep;  // 0x48C(0x4)
	char pad_1168_1 : 7;  // 0x490(0x1)
	bool Retrace : 1;  // 0x490(0x1)
	char pad_1169_1 : 7;  // 0x491(0x1)
	bool RetraceOnAnotherChannel : 1;  // 0x491(0x1)
	char ECollisionChannel RetraceChannel;  // 0x492(0x1)
	char pad_1171_1 : 7;  // 0x493(0x1)
	bool RotateActor : 1;  // 0x493(0x1)
	char pad_1172_1 : 7;  // 0x494(0x1)
	bool RotateRandomRoll : 1;  // 0x494(0x1)
	char pad_1173_1 : 7;  // 0x495(0x1)
	bool EnablePooling : 1;  // 0x495(0x1)
	char pad_1174[2];  // 0x496(0x2)
	struct UParticleSystem* TraceFX;  // 0x498(0x8)

	struct FVector UpdateVelocity(struct FVector& Location, struct FVector& previousVelocity, float DeltaTime); // Function POLYGON.TraceProjectile.UpdateVelocity
	void SpawnWithExactVelocity(ATraceProjectile* bulletClass, struct AItem_Gun_General* Gun, struct FVector& spawnLocation, struct FVector& startVelocity, char RandomSeed); // Function POLYGON.TraceProjectile.SpawnWithExactVelocity
	void Spawn(ATraceProjectile* bulletClass, struct AItem_Gun_General* Gun, struct FVector& spawnLocation, struct FVector& startVelocity, char RandomSeed); // Function POLYGON.TraceProjectile.Spawn
	void OnTrajectoryUpdateReceived(struct FVector& Location, struct FVector& OldVelocity, struct FVector& NewVelocity); // Function POLYGON.TraceProjectile.OnTrajectoryUpdateReceived
	void OnTrace(struct FVector& StartLocation, struct FVector& EndLocation); // Function POLYGON.TraceProjectile.OnTrace
	void OnImpact(bool ricochet, bool passedThrough, struct FVector& exitVelocity, struct FVector& Impulse, float PenetrationDepth, struct FHitResult& HitResult); // Function POLYGON.TraceProjectile.OnImpact
	void OnDeactivated(); // Function POLYGON.TraceProjectile.OnDeactivated
	void Deactivate(); // Function POLYGON.TraceProjectile.Deactivate
	bool CollisionFilter(struct FHitResult& HitResult); // Function POLYGON.TraceProjectile.CollisionFilter
}; 



// Class POLYGON.Item_Gun_General
// Size: 0x750(Inherited: 0x2F8) 
struct AItem_Gun_General : public AItem_General
{
	char pad_760[8];  // 0x2F8(0x8)
	struct FMulticastInlineDelegate OnChangeCurrentNumberAmmo;  // 0x300(0x10)
	struct FMulticastInlineDelegate OnChangeStockAmmo;  // 0x310(0x10)
	struct FMulticastInlineDelegate OnSetGunModules;  // 0x320(0x10)
	char pad_816[8];  // 0x330(0x8)
	struct FMulticastInlineDelegate OnApplyGunDamage;  // 0x338(0x10)
	char pad_840[24];  // 0x348(0x18)
	struct TSoftObjectPtr<UTexture2D> GunWhileIcon;  // 0x360(0x30)
	int32_t LevelRequired;  // 0x390(0x4)
	char pad_916_1 : 7;  // 0x394(0x1)
	bool bIsAvailable : 1;  // 0x394(0x1)
	uint8_t  GunClass;  // 0x395(0x1)
	uint8_t  GunSlot;  // 0x396(0x1)
	uint8_t  GunShootingType;  // 0x397(0x1)
	struct TSoftClassPtr<UObject> ProjectileClass;  // 0x398(0x30)
	float BulletVelocityMultiplier;  // 0x3C8(0x4)
	char pad_972[4];  // 0x3CC(0x4)
	struct TArray<int32_t> Levels;  // 0x3D0(0x10)
	int32_t GunDamage;  // 0x3E0(0x4)
	float DamageMultiplierHead;  // 0x3E4(0x4)
	int32_t MaxMagazineAmmo;  // 0x3E8(0x4)
	int32_t MaxStockAmmo;  // 0x3EC(0x4)
	float TimeBetweenShots;  // 0x3F0(0x4)
	float GunUpRecoil;  // 0x3F4(0x4)
	float GunBackwardRecoil;  // 0x3F8(0x4)
	float GunRecoilAlphaPerShot;  // 0x3FC(0x4)
	float GunRecoilLift;  // 0x400(0x4)
	float GunRecoilControlMultiplier;  // 0x404(0x4)
	float FirstShotKickMultiplier;  // 0x408(0x4)
	float AccuracyHip;  // 0x40C(0x4)
	float SpreadShot;  // 0x410(0x4)
	float Mobility;  // 0x414(0x4)
	float AimDownTimeMultiplier;  // 0x418(0x4)
	float ReloadTimeMultiplier;  // 0x41C(0x4)
	float DrawTimeMultiplier;  // 0x420(0x4)
	char pad_1060[4];  // 0x424(0x4)
	struct TSoftObjectPtr<UGunModulesInfo> RelatedModulesInfo;  // 0x428(0x30)
	struct TSoftClassPtr<UObject> ProgressWidget;  // 0x458(0x30)
	struct UParticleSystem* SleeveFX;  // 0x488(0x8)
	struct USoundBase* SoundBulletCasingDrop;  // 0x490(0x8)
	UCameraShakeBase* ShotCameraShake;  // 0x498(0x8)
	struct UAnimSequence* IdleCharacterAnimation;  // 0x4A0(0x8)
	struct UAnimMontage* ReloadCharacterAnimation;  // 0x4A8(0x8)
	float ReloadCharacterAnimationAimingStartTime;  // 0x4B0(0x4)
	char pad_1204[4];  // 0x4B4(0x4)
	struct UAnimMontage* ReloadFullCharacterAnimation;  // 0x4B8(0x8)
	float ReloadFullCharacterAnimationAimingStartTime;  // 0x4C0(0x4)
	char pad_1220[4];  // 0x4C4(0x4)
	struct UAnimMontage* ShotCharacterAnimation;  // 0x4C8(0x8)
	struct UAnimMontage* EndShotCharacterAnimation;  // 0x4D0(0x8)
	struct UAnimMontage* BoltCharacterAnimation;  // 0x4D8(0x8)
	struct UAnimMontage* GrenadeThrowAdditiveAnimation;  // 0x4E0(0x8)
	struct UAnimMontage* EquipAnimation;  // 0x4E8(0x8)
	struct UAnimMontage* AimingEquipAnimation;  // 0x4F0(0x8)
	struct UAnimMontage* HolsterAnimation;  // 0x4F8(0x8)
	struct UAnimMontage* AimingAnimation;  // 0x500(0x8)
	struct UAnimSequence* ShotGunAnimation;  // 0x508(0x8)
	struct UAnimSequence* BoltGunAnimation;  // 0x510(0x8)
	struct UAnimSequence* ReloadGunAnimation;  // 0x518(0x8)
	struct UAnimSequence* ReloadFullGunAnimation;  // 0x520(0x8)
	struct UAnimSequence* NoAmmoGunAnimation;  // 0x528(0x8)
	struct FVector FirstPersonGunPosition;  // 0x530(0x18)
	struct FVector ThirdPersonGunPosition;  // 0x548(0x18)
	struct FTransform LeftHandOffset;  // 0x560(0x60)
	struct FVector SprintLiftGun;  // 0x5C0(0x18)
	char pad_1496[8];  // 0x5D8(0x8)
	struct FTransform WatchOffset;  // 0x5E0(0x60)
	struct TSoftObjectPtr<USoundBase> SoundShot;  // 0x640(0x30)
	struct USoundBase* SoundBlankShot;  // 0x670(0x8)
	struct USoundBase* SoundAiming;  // 0x678(0x8)
	struct TArray<struct TSoftObjectPtr<USoundBase>> CustomSounds;  // 0x680(0x10)
	char CallHardReset;  // 0x690(0x1)
	char pad_1681[3];  // 0x691(0x3)
	int32_t CurrentMagazineAmmo;  // 0x694(0x4)
	uint16_t CurrentStockAmmo;  // 0x698(0x2)
	char ReloadCaller;  // 0x69A(0x1)
	char pad_1691[5];  // 0x69B(0x5)
	struct TArray<struct TWeakObjectPtr<ATraceProjectile>> PoolProjectiles;  // 0x6A0(0x10)
	struct TArray<struct TWeakObjectPtr<ABullet_Casing_General>> PoolBulletCasings;  // 0x6B0(0x10)
	char pad_1728[4];  // 0x6C0(0x4)
	float CurrentSpread;  // 0x6C4(0x4)
	struct TArray<UObject*> CurrentGunModuleClasses;  // 0x6C8(0x10)
	struct TArray<struct AItem_Module_General*> CurrentGunModuleReferences;  // 0x6D8(0x10)
	struct FGunShot GunShot;  // 0x6E8(0x20)
	struct FVector_NetQuantize GunHitOfShortShot;  // 0x708(0x18)
	char pad_1824[8];  // 0x720(0x8)
	struct UAudioComponent* ActiveSoundShot;  // 0x728(0x8)
	struct UPlayFabJsonObject* ItemReference;  // 0x730(0x8)
	struct USkeletalMeshComponent* GunMesh;  // 0x738(0x8)
	struct UStaticMeshComponent* Magazine;  // 0x740(0x8)
	char pad_1864[8];  // 0x748(0x8)

	void UpdatePlayerCombinedInfo(struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.Item_Gun_General.UpdatePlayerCombinedInfo
	void SetGunModules(struct UPlayFabJsonObject* Modules); // Function POLYGON.Item_Gun_General.SetGunModules
	void RequestReload_server(char currentNumberAmmo); // Function POLYGON.Item_Gun_General.RequestReload_server
	void OnSetPlayerState(); // Function POLYGON.Item_Gun_General.OnSetPlayerState
	void OnRep_ReloadCaller(char PreviousValue); // Function POLYGON.Item_Gun_General.OnRep_ReloadCaller
	void OnRep_GunShot(struct FGunShot previousShot); // Function POLYGON.Item_Gun_General.OnRep_GunShot
	void OnRep_GunHitOfShortShot(struct FVector_NetQuantize PreviousValue); // Function POLYGON.Item_Gun_General.OnRep_GunHitOfShortShot
	void OnRep_CurrentStockAmmo(); // Function POLYGON.Item_Gun_General.OnRep_CurrentStockAmmo
	void OnRep_CurrentGunModuleClasses(); // Function POLYGON.Item_Gun_General.OnRep_CurrentGunModuleClasses
	void OnRep_CallHardReset(char PreviousValue); // Function POLYGON.Item_Gun_General.OnRep_CallHardReset
	void NotifyServerTraceHit(struct FGunHitOnCharacter hitOnCharacter); // Function POLYGON.Item_Gun_General.NotifyServerTraceHit
	void NotifyServerOfShot(struct FGunShot GunShot); // Function POLYGON.Item_Gun_General.NotifyServerOfShot
	void NotifyServerHitWithEnergy(struct FGunHitOnCharacter hitOnCharacter, char energy); // Function POLYGON.Item_Gun_General.NotifyServerHitWithEnergy
	void NotifyServerHit(struct FGunHitOnCharacter hitOnCharacter); // Function POLYGON.Item_Gun_General.NotifyServerHit
	void NotifyGrantedProgressDataContainer_client(struct FString ItemInstanceId); // Function POLYGON.Item_Gun_General.NotifyGrantedProgressDataContainer_client
	struct UPlayFabJsonObject* GetItemReference(); // Function POLYGON.Item_Gun_General.GetItemReference
	struct FVector GetForwardShot(); // Function POLYGON.Item_Gun_General.GetForwardShot
	int32_t GetCurrentStockAmmo(); // Function POLYGON.Item_Gun_General.GetCurrentStockAmmo
	void CockBolt_server(); // Function POLYGON.Item_Gun_General.CockBolt_server
	void CockBolt_multicast(); // Function POLYGON.Item_Gun_General.CockBolt_multicast
	void AddStockAmmo_server(int8_t addAmmo); // Function POLYGON.Item_Gun_General.AddStockAmmo_server
}; 



// Class POLYGON.GunModulesInfo
// Size: 0x40(Inherited: 0x30) 
struct UGunModulesInfo : public UDataAsset
{
	struct TArray<struct FGunModuleInfo> Modules;  // 0x30(0x10)

	struct FGunModuleInfo FindModule(struct TArray<struct FGunModuleInfo> Array, AItem_Module_General* ModuleClass); // Function POLYGON.GunModulesInfo.FindModule
}; 



// Class POLYGON.AnimNotify_PlaySoundLocal
// Size: 0x50(Inherited: 0x38) 
struct UAnimNotify_PlaySoundLocal : public UAnimNotify
{
	struct USoundBase* Sound;  // 0x38(0x8)
	float VolumeMultiplier;  // 0x40(0x4)
	float PitchMultiplier;  // 0x44(0x4)
	struct FName AttachName;  // 0x48(0x8)

}; 



// Class POLYGON.ServerGameInstance
// Size: 0x38(Inherited: 0x28) 
struct UServerGameInstance : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	void OnGSDKShutdown(); // Function POLYGON.ServerGameInstance.OnGSDKShutdown
	void OnGSDKServerActive(); // Function POLYGON.ServerGameInstance.OnGSDKServerActive
	void OnGSDKReadyForPlayers(); // Function POLYGON.ServerGameInstance.OnGSDKReadyForPlayers
	bool OnGSDKHealthCheck(); // Function POLYGON.ServerGameInstance.OnGSDKHealthCheck
}; 



// Class POLYGON.BallisticMaterialResponseMap
// Size: 0x80(Inherited: 0x30) 
struct UBallisticMaterialResponseMap : public UDataAsset
{
	struct TMap<struct UPhysicalMaterial*, struct FBallisticMaterialResponseMapEntry> List;  // 0x30(0x50)

}; 



// Class POLYGON.EOSSubsystemAvanced
// Size: 0x38(Inherited: 0x30) 
struct UEOSSubsystemAvanced : public UGameInstanceSubsystem
{
	char pad_48[8];  // 0x30(0x8)

	void StartLogin(struct FDelegate OnLoginComplete); // Function POLYGON.EOSSubsystemAvanced.StartLogin
	void StartCreateParty(struct UObject* WorldContextObject, int32_t PartyTypeId, struct FDelegate onDone); // Function POLYGON.EOSSubsystemAvanced.StartCreateParty
	struct TArray<struct UEOSPartyMemberId*> GetPartyMembers(struct UObject* WorldContextObject, struct UEOSPartyId* PartyId); // Function POLYGON.EOSSubsystemAvanced.GetPartyMembers
	struct TArray<struct UEOSPartyId*> GetJoinedParties(struct UObject* WorldContextObject); // Function POLYGON.EOSSubsystemAvanced.GetJoinedParties
}; 



// Class POLYGON.Bullet_Casing_General
// Size: 0x2A8(Inherited: 0x290) 
struct ABullet_Casing_General : public AActor
{
	struct USoundBase* SoundDrop;  // 0x290(0x8)
	struct UStaticMeshComponent* Mesh;  // 0x298(0x8)
	struct UProjectileMovementComponent* ProjectileMovementComponent;  // 0x2A0(0x8)

}; 



// Class POLYGON.FOVManagerInterface
// Size: 0x28(Inherited: 0x28) 
struct UFOVManagerInterface : public UInterface
{

	void SetCorrectiveFovMaterial(bool useFovMaterial); // Function POLYGON.FOVManagerInterface.SetCorrectiveFovMaterial
}; 



// Class POLYGON.ChatSystemComponent
// Size: 0xB0(Inherited: 0xA0) 
struct UChatSystemComponent : public UActorComponent
{
	struct TArray<struct FGameChatMessage> ChatHistory;  // 0xA0(0x10)

	void SentMessage_Multicast(struct FGameChatMessage Message); // Function POLYGON.ChatSystemComponent.SentMessage_Multicast
	void SendMessage_Server(struct FGameChatMessage Message); // Function POLYGON.ChatSystemComponent.SendMessage_Server
}; 



// Class POLYGON.ClientGameInstance
// Size: 0x88(Inherited: 0x28) 
struct UClientGameInstance : public UObject
{
	struct FMulticastInlineDelegate OnSetMasterId;  // 0x28(0x10)
	struct FText KickReason;  // 0x38(0x18)
	char pad_80[16];  // 0x50(0x10)
	struct UPlayFabJsonObject* PlayerCombinedInfo;  // 0x60(0x8)
	struct TArray<struct UUserEntry*> UsersCache;  // 0x68(0x10)
	char pad_120[16];  // 0x78(0x10)

	void SetServerTime(struct FDateTime& serverTime); // Function POLYGON.ClientGameInstance.SetServerTime
	void SetPlayerId(struct FString newPlayerMasterId); // Function POLYGON.ClientGameInstance.SetPlayerId
	void SetPlayerCombinedInfo(struct UPlayFabJsonObject* newPlayerCombinedInfo); // Function POLYGON.ClientGameInstance.SetPlayerCombinedInfo
	void HandleNetworkFailure(struct UWorld* World, struct UNetDriver* NetDriver, char ENetworkFailure FailureType, struct FString errorString); // Function POLYGON.ClientGameInstance.HandleNetworkFailure
	struct FDateTime GetServerTime(); // Function POLYGON.ClientGameInstance.GetServerTime
	struct FString GetPlayerMasterId(); // Function POLYGON.ClientGameInstance.GetPlayerMasterId
	struct UPlayFabJsonObject* GetPlayerCombinedInfo(); // Function POLYGON.ClientGameInstance.GetPlayerCombinedInfo
}; 



// Class POLYGON.PG_GameMode_Game_StandBy
// Size: 0x378(Inherited: 0x378) 
struct APG_GameMode_Game_StandBy : public AGameMode
{

}; 



// Class POLYGON.GeneralBackendComponent
// Size: 0xE0(Inherited: 0xA0) 
struct UGeneralBackendComponent : public UActorComponent
{
	char pad_160[64];  // 0xA0(0x40)

}; 



// Class POLYGON.ControlPoint
// Size: 0x300(Inherited: 0x290) 
struct AControlPoint : public AActor
{
	struct FMulticastInlineDelegate OnCapturedTeam;  // 0x290(0x10)
	struct FMulticastInlineDelegate OnIsCapture;  // 0x2A0(0x10)
	struct FMulticastInlineDelegate OnChangeCapturePoints;  // 0x2B0(0x10)
	uint8_t  ControlPointName;  // 0x2C0(0x1)
	uint8_t  CapturedTeam;  // 0x2C1(0x1)
	char pad_706_1 : 7;  // 0x2C2(0x1)
	bool bIsCapture : 1;  // 0x2C2(0x1)
	char pad_707[1];  // 0x2C3(0x1)
	int32_t CapturePointsAlphaTeam;  // 0x2C4(0x4)
	int32_t CapturePointsBravoTeam;  // 0x2C8(0x4)
	char pad_716[4];  // 0x2CC(0x4)
	struct TArray<struct APG_PlayerState_Game*> CapturePlayersAlphaTeam;  // 0x2D0(0x10)
	struct TArray<struct APG_PlayerState_Game*> CapturePlayersBravoTeam;  // 0x2E0(0x10)
	char pad_752[8];  // 0x2F0(0x8)
	struct USceneComponent* Root;  // 0x2F8(0x8)

	void OnRep_IsCapture(); // Function POLYGON.ControlPoint.OnRep_IsCapture
	void OnRep_CapturePointsBravoTeam(); // Function POLYGON.ControlPoint.OnRep_CapturePointsBravoTeam
	void OnRep_CapturePointsAlphaTeam(); // Function POLYGON.ControlPoint.OnRep_CapturePointsAlphaTeam
	void OnRep_CapturedTeam(); // Function POLYGON.ControlPoint.OnRep_CapturedTeam
	struct FString GetControlPointNameAsString(); // Function POLYGON.ControlPoint.GetControlPointNameAsString
	struct FString GetControlPointNameAsOneLetter(); // Function POLYGON.ControlPoint.GetControlPointNameAsOneLetter
	bool ContainsCharacter(struct ACharacter* Character); // Function POLYGON.ControlPoint.ContainsCharacter
}; 



// Class POLYGON.Item_Watch_General
// Size: 0x310(Inherited: 0x2F8) 
struct AItem_Watch_General : public AItem_General
{
	char pad_760[8];  // 0x2F8(0x8)
	uint8_t  Rare;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct UStaticMeshComponent* WatchMesh;  // 0x308(0x8)

}; 



// Class POLYGON.DataManagerLibrary
// Size: 0x28(Inherited: 0x28) 
struct UDataManagerLibrary : public UBlueprintFunctionLibrary
{

	struct UDataContainerAsset* GetDataTableReferences(); // Function POLYGON.DataManagerLibrary.GetDataTableReferences
}; 



// Class POLYGON.EOSPartyId
// Size: 0x38(Inherited: 0x28) 
struct UEOSPartyId : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FString ToString(); // Function POLYGON.EOSPartyId.ToString
}; 



// Class POLYGON.PG_PlayerState_Game
// Size: 0x448(Inherited: 0x3C0) 
struct APG_PlayerState_Game : public APG_PlayerState_Base
{
	struct FMulticastInlineDelegate OnSetTeam;  // 0x3C0(0x10)
	struct FMulticastInlineDelegate OnChangeNumberKills;  // 0x3D0(0x10)
	struct FMulticastInlineDelegate OnChangeNumberDeaths;  // 0x3E0(0x10)
	struct FMulticastInlineDelegate OnVoteKick;  // 0x3F0(0x10)
	char pad_1024[8];  // 0x400(0x8)
	struct TArray<struct APG_PlayerState_Game*> VoteKickPlayers;  // 0x408(0x10)
	uint8_t  Team;  // 0x418(0x1)
	char NumberKills;  // 0x419(0x1)
	char NumberDeaths;  // 0x41A(0x1)
	char NumberKillsByMe;  // 0x41B(0x1)
	char NumberKillsOfMe;  // 0x41C(0x1)
	char pad_1053[7];  // 0x41D(0x7)
	char pad_1060_1 : 7;  // 0x424(0x1)
	bool bIsAdmin : 1;  // 0x424(0x1)
	char pad_1061_1 : 7;  // 0x425(0x1)
	bool bIsPatron : 1;  // 0x425(0x1)
	char pad_1062[2];  // 0x426(0x2)
	struct UPlayerCoreComponent* PlayerCoreComponent;  // 0x428(0x8)
	struct UInventoryComponent_Game* InventoryComponent;  // 0x430(0x8)
	struct USquadComponent* SquadComponent;  // 0x438(0x8)
	struct UChatSystemComponent* ChatSystemComponent;  // 0x440(0x8)

	void SetTeam(uint8_t  newTeam); // Function POLYGON.PG_PlayerState_Game.SetTeam
	void OnRep_VoteKickPlayers(); // Function POLYGON.PG_PlayerState_Game.OnRep_VoteKickPlayers
	void OnRep_Team(); // Function POLYGON.PG_PlayerState_Game.OnRep_Team
	void OnRep_NumberKills(); // Function POLYGON.PG_PlayerState_Game.OnRep_NumberKills
	void OnRep_NumberDeaths(); // Function POLYGON.PG_PlayerState_Game.OnRep_NumberDeaths
	bool CustomIsInactive(); // Function POLYGON.PG_PlayerState_Game.CustomIsInactive
}; 



// Class POLYGON.EOSPartyMemberId
// Size: 0x38(Inherited: 0x28) 
struct UEOSPartyMemberId : public UObject
{
	char pad_40[16];  // 0x28(0x10)

	struct FString ToString(); // Function POLYGON.EOSPartyMemberId.ToString
}; 



// Class POLYGON.InventoryComponent_Menu
// Size: 0xD8(Inherited: 0xD8) 
struct UInventoryComponent_Menu : public UInventoryComponent_Base
{

}; 



// Class POLYGON.PG_PlayerController_Base
// Size: 0x880(Inherited: 0x850) 
struct APG_PlayerController_Base : public APlayerController
{
	struct FMulticastInlineDelegate OnSetPlayerState;  // 0x850(0x10)
	struct FMulticastInlineDelegate OnClientReset;  // 0x860(0x10)
	int32_t AimMode;  // 0x870(0x4)
	int32_t CrouchMode;  // 0x874(0x4)
	int32_t LeanMode;  // 0x878(0x4)
	int32_t SprintMode;  // 0x87C(0x4)

	void ShowError(struct FText& ErrorMessage, struct FText& ErrorDetails); // Function POLYGON.PG_PlayerController_Base.ShowError
	bool IsInvertMouse(); // Function POLYGON.PG_PlayerController_Base.IsInvertMouse
	float GetMouseSensitivityValue(); // Function POLYGON.PG_PlayerController_Base.GetMouseSensitivityValue
	float GetMouseSensitivityAimingValue(); // Function POLYGON.PG_PlayerController_Base.GetMouseSensitivityAimingValue
}; 



// Class POLYGON.EventManagerComponent
// Size: 0xA0(Inherited: 0xA0) 
struct UEventManagerComponent : public UActorComponent
{

	void OnAmmoBoxAction(); // Function POLYGON.EventManagerComponent.OnAmmoBoxAction
	void AmmoBoxAction(); // Function POLYGON.EventManagerComponent.AmmoBoxAction
}; 



// Class POLYGON.ServerBackendComponent
// Size: 0xE0(Inherited: 0xE0) 
struct UServerBackendComponent : public UGeneralBackendComponent
{

}; 



// Class POLYGON.Item_Module_Underbarrel_Grip
// Size: 0x3C0(Inherited: 0x348) 
struct AItem_Module_Underbarrel_Grip : public AItem_Module_Underbarrel
{
	char pad_840[8];  // 0x348(0x8)
	struct FTransform WatchOffset;  // 0x350(0x60)
	struct UAnimSequence* GripHandPose;  // 0x3B0(0x8)
	char pad_952[8];  // 0x3B8(0x8)

}; 



// Class POLYGON.FOVManagerComponent
// Size: 0xC0(Inherited: 0xA0) 
struct UFOVManagerComponent : public UActorComponent
{
	float AimingFOV_Alpha;  // 0xA0(0x4)
	float DefaultCameraFOV;  // 0xA4(0x4)
	float CurrentCameraFOV;  // 0xA8(0x4)
	float DefaultMeshFOV;  // 0xAC(0x4)
	float CurrentMeshFOV;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct UMaterialParameterCollection* MaterialCollection_CorrectFOV;  // 0xB8(0x8)

	void SetMeshFOV(float newMeshFOV); // Function POLYGON.FOVManagerComponent.SetMeshFOV
	void SetDefaultCameraFOV(float newDefaultCameraFOV); // Function POLYGON.FOVManagerComponent.SetDefaultCameraFOV
	void SetCameraFOV(float newCameraFOV); // Function POLYGON.FOVManagerComponent.SetCameraFOV
	void HardResetMeshFOV(); // Function POLYGON.FOVManagerComponent.HardResetMeshFOV
	void HardResetCameraFOV(); // Function POLYGON.FOVManagerComponent.HardResetCameraFOV
}; 



// Class POLYGON.GameSettings
// Size: 0x38(Inherited: 0x38) 
struct UGameSettings : public UDeveloperSettings
{

}; 



// Class POLYGON.HealthStatsComponent
// Size: 0x110(Inherited: 0xA0) 
struct UHealthStatsComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnChangeHealth;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnHealthProtection;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnIsAlive;  // 0xC0(0x10)
	char Health;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool bIsAlive : 1;  // 0xD1(0x1)
	char pad_210_1 : 7;  // 0xD2(0x1)
	bool bHealthProtection : 1;  // 0xD2(0x1)
	char pad_211[1];  // 0xD3(0x1)
	float LastTimeTakeDamage;  // 0xD4(0x4)
	float Stamina;  // 0xD8(0x4)
	char pad_220[4];  // 0xDC(0x4)
	struct TArray<struct FPlayerAssist> KillAssists;  // 0xE0(0x10)
	char pad_240[32];  // 0xF0(0x20)

	void OnRep_HealthProtection(); // Function POLYGON.HealthStatsComponent.OnRep_HealthProtection
	void OnRep_Health(char previousHealth); // Function POLYGON.HealthStatsComponent.OnRep_Health
	void KillSelf_server(); // Function POLYGON.HealthStatsComponent.KillSelf_server
	int32_t GetStamina(); // Function POLYGON.HealthStatsComponent.GetStamina
	bool GetHealthProtection(); // Function POLYGON.HealthStatsComponent.GetHealthProtection
	int32_t GetHealth(); // Function POLYGON.HealthStatsComponent.GetHealth
}; 



// Class POLYGON.InspectManagerComponent
// Size: 0xD0(Inherited: 0xA0) 
struct UInspectManagerComponent : public UActorComponent
{
	char pad_160[40];  // 0xA0(0x28)
	struct UBoxComponent* BoxCollision;  // 0xC8(0x8)

	void SetPivotOffset(struct FVector2D Offset); // Function POLYGON.InspectManagerComponent.SetPivotOffset
	void ResetRotation(); // Function POLYGON.InspectManagerComponent.ResetRotation
	void OnClicked(struct UPrimitiveComponent* TouchedComponent, struct FKey ButtonPressed); // Function POLYGON.InspectManagerComponent.OnClicked
	void EnableInspect(); // Function POLYGON.InspectManagerComponent.EnableInspect
	void DisableInspect(); // Function POLYGON.InspectManagerComponent.DisableInspect
}; 



// Class POLYGON.InteractInterface
// Size: 0x28(Inherited: 0x28) 
struct UInteractInterface : public UInterface
{

	void StopInteract(struct APG_Game_Character* Character); // Function POLYGON.InteractInterface.StopInteract
	void StartInteract(struct APG_Game_Character* Character); // Function POLYGON.InteractInterface.StartInteract
	void SetPlayerLooks(struct APG_Game_Character* Character, bool bIsLooks); // Function POLYGON.InteractInterface.SetPlayerLooks
}; 



// Class POLYGON.Item_Module_Skin
// Size: 0x358(Inherited: 0x340) 
struct AItem_Module_Skin : public AItem_Module_General
{
	uint8_t  Rare;  // 0x340(0x1)
	char pad_833[7];  // 0x341(0x7)
	struct UMaterialInstance* SkinMaterial;  // 0x348(0x8)
	struct UMaterialInstance* SkinMaterialCorrectFOV;  // 0x350(0x8)

}; 



// Class POLYGON.InventoryComponent_Base
// Size: 0xD8(Inherited: 0xA0) 
struct UInventoryComponent_Base : public UActorComponent
{
	struct FMulticastInlineDelegate OnSetPrimaryGun;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnSetSecondaryGun;  // 0xB0(0x10)
	struct AItem_Gun_General* PrimaryGun;  // 0xC0(0x8)
	struct AItem_Gun_General* SecondaryGun;  // 0xC8(0x8)
	AItem_Watch_General* WatchClass;  // 0xD0(0x8)

	void UpdatePlayerCombinedInfo(struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.InventoryComponent_Base.UpdatePlayerCombinedInfo
	void OnRep_SecondaryGun(); // Function POLYGON.InventoryComponent_Base.OnRep_SecondaryGun
	void OnRep_PrimaryGun(); // Function POLYGON.InventoryComponent_Base.OnRep_PrimaryGun
}; 



// Class POLYGON.Item_Grenade_General
// Size: 0x358(Inherited: 0x2F8) 
struct AItem_Grenade_General : public AItem_General
{
	float GrenadeDamage;  // 0x2F8(0x4)
	char pad_764[4];  // 0x2FC(0x4)
	struct FVector_NetQuantize ReplicatedPosition;  // 0x300(0x18)
	struct UParticleSystem* ExplosionFX;  // 0x318(0x8)
	struct USoundBase* SoundExplosion;  // 0x320(0x8)
	UCameraShakeBase* ExplosionCameraShakeFirst;  // 0x328(0x8)
	UCameraShakeBase* ExplosionCameraShakeSecond;  // 0x330(0x8)
	UCameraShakeBase* GrenadeThrowCameraShake;  // 0x338(0x8)
	struct UStaticMeshComponent* Mesh;  // 0x340(0x8)
	struct URadialForceComponent* RadialForce;  // 0x348(0x8)
	struct USphereComponent* GrenadeSphereRadius;  // 0x350(0x8)

	void OnMeshHit(struct UPrimitiveComponent* HitComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, struct FVector NormalImpulse, struct FHitResult& Hit); // Function POLYGON.Item_Grenade_General.OnMeshHit
	void OnGrenadeThrow(); // Function POLYGON.Item_Grenade_General.OnGrenadeThrow
	void NotifyThrow_server(struct FVector_NetQuantize StartPosition, struct FVector_NetQuantize Impulse); // Function POLYGON.Item_Grenade_General.NotifyThrow_server
}; 



// Class POLYGON.InventoryComponent_Game
// Size: 0x110(Inherited: 0xD8) 
struct UInventoryComponent_Game : public UInventoryComponent_Base
{
	struct FMulticastInlineDelegate OnSetCurrentGun;  // 0xD8(0x10)
	struct FMulticastInlineDelegate OnChangeNumberGrenades;  // 0xE8(0x10)
	struct AItem_Gun_General* CurrentGun;  // 0xF8(0x8)
	char GrenadesNumber;  // 0x100(0x1)
	char pad_257[15];  // 0x101(0xF)

	struct TArray<struct FString> SetGunModules(struct FString gunInstanceId, struct TArray<struct FString>& itemsInstanceId); // Function POLYGON.InventoryComponent_Game.SetGunModules
	void RequestSetGunModules_server(struct FString gunInstanceId, struct TArray<struct FString> itemsInstanceId); // Function POLYGON.InventoryComponent_Game.RequestSetGunModules_server
	void RequestEquipItems_server(struct TArray<struct FString> itemsInstanceId); // Function POLYGON.InventoryComponent_Game.RequestEquipItems_server
	void OnRep_GrenadesNumber(); // Function POLYGON.InventoryComponent_Game.OnRep_GrenadesNumber
	void OnRep_CurrentGun(struct AItem_Gun_General* previousGun); // Function POLYGON.InventoryComponent_Game.OnRep_CurrentGun
	struct TArray<struct FString> EquipItems(struct TArray<struct FString>& itemsInstanceId); // Function POLYGON.InventoryComponent_Game.EquipItems
	void AddGrenate_server(char Number); // Function POLYGON.InventoryComponent_Game.AddGrenate_server
}; 



// Class POLYGON.Item_General
// Size: 0x2F8(Inherited: 0x290) 
struct AItem_General : public AActor
{
	struct FString ItemId;  // 0x290(0x10)
	uint8_t  ItemType;  // 0x2A0(0x1)
	char pad_673[7];  // 0x2A1(0x7)
	struct FText ItemName;  // 0x2A8(0x18)
	struct TSoftObjectPtr<UTexture2D> ItemIcon;  // 0x2C0(0x30)
	struct FDataContainerObjectWrapper customData;  // 0x2F0(0x8)

}; 



// Class POLYGON.Item_Gun_Sniper
// Size: 0x750(Inherited: 0x750) 
struct AItem_Gun_Sniper : public AItem_Gun_General
{

}; 



// Class POLYGON.Item_Module_General
// Size: 0x340(Inherited: 0x2F8) 
struct AItem_Module_General : public AItem_General
{
	char pad_760[8];  // 0x2F8(0x8)
	uint8_t  GunModuleType;  // 0x300(0x1)
	char pad_769[7];  // 0x301(0x7)
	struct TSoftObjectPtr<UTexture2D> ModuleWhiteIcon;  // 0x308(0x30)
	char pad_824_1 : 7;  // 0x338(0x1)
	bool bIsDefault : 1;  // 0x338(0x1)
	char pad_825[7];  // 0x339(0x7)

}; 



// Class POLYGON.Item_Gun_Pistol
// Size: 0x750(Inherited: 0x750) 
struct AItem_Gun_Pistol : public AItem_Gun_General
{

}; 



// Class POLYGON.PG_Menu_Character
// Size: 0x2B8(Inherited: 0x290) 
struct APG_Menu_Character : public AActor
{
	struct TWeakObjectPtr<APG_Menu_Character> Instance;  // 0x290(0x8)
	struct USkeletalMeshComponent* Mesh;  // 0x298(0x8)
	struct USkeletalMeshComponent* Armor;  // 0x2A0(0x8)
	struct UStaticMeshComponent* HeadGear;  // 0x2A8(0x8)
	struct UStaticMeshComponent* Backpack;  // 0x2B0(0x8)

}; 



// Class POLYGON.Item_Gun_Rifle
// Size: 0x750(Inherited: 0x750) 
struct AItem_Gun_Rifle : public AItem_Gun_General
{

}; 



// Class POLYGON.Item_Module_Underbarrel
// Size: 0x348(Inherited: 0x340) 
struct AItem_Module_Underbarrel : public AItem_Module_General
{
	struct UStaticMeshComponent* ModuleMesh;  // 0x340(0x8)

}; 



// Class POLYGON.Item_Module_Accessory
// Size: 0x350(Inherited: 0x340) 
struct AItem_Module_Accessory : public AItem_Module_General
{
	struct FName MountingSocket;  // 0x340(0x8)
	struct UStaticMeshComponent* ModuleMesh;  // 0x348(0x8)

}; 



// Class POLYGON.Item_Module_Barrel
// Size: 0x348(Inherited: 0x340) 
struct AItem_Module_Barrel : public AItem_Module_General
{
	struct UStaticMeshComponent* ModuleMesh;  // 0x340(0x8)

}; 



// Class POLYGON.Item_Module_Flashlight
// Size: 0x368(Inherited: 0x350) 
struct AItem_Module_Flashlight : public AItem_Module_Accessory
{
	struct FMulticastInlineDelegate OnEnable;  // 0x350(0x10)
	char pad_864_1 : 7;  // 0x360(0x1)
	bool bIsEnable : 1;  // 0x360(0x1)
	char pad_865[7];  // 0x361(0x7)

	void SetFlashlightEnable_server(bool isEnable); // Function POLYGON.Item_Module_Flashlight.SetFlashlightEnable_server
	void SetFlashlightEnable(bool isEnable, bool bCallOnServer); // Function POLYGON.Item_Module_Flashlight.SetFlashlightEnable
	void OnSetCurrentGun(struct AItem_Gun_General* previousGun); // Function POLYGON.Item_Module_Flashlight.OnSetCurrentGun
	void OnRep_IsEnable(bool oldState); // Function POLYGON.Item_Module_Flashlight.OnRep_IsEnable
	void OnChangeEnableState(bool bPlaySound); // Function POLYGON.Item_Module_Flashlight.OnChangeEnableState
}; 



// Class POLYGON.Item_Module_Optic
// Size: 0x388(Inherited: 0x340) 
struct AItem_Module_Optic : public AItem_Module_General
{
	struct FName MountingSocket;  // 0x340(0x8)
	float FOV;  // 0x348(0x4)
	float StepsImpact;  // 0x34C(0x4)
	float BackwardRecoilMultiplier;  // 0x350(0x4)
	float BlurPower;  // 0x354(0x4)
	float BlurRadius;  // 0x358(0x4)
	float BlurDensity;  // 0x35C(0x4)
	float BlurBlackout;  // 0x360(0x4)
	char pad_868_1 : 7;  // 0x364(0x1)
	bool bIsScope : 1;  // 0x364(0x1)
	char pad_869[3];  // 0x365(0x3)
	struct UStaticMesh* AimingMesh;  // 0x368(0x8)
	float ActivateAimingMeshFovAlpha;  // 0x370(0x4)
	float DeactivateAimingMeshFovAlpha;  // 0x374(0x4)
	struct UMaterialInstance* AimingMaterial;  // 0x378(0x8)
	struct UStaticMeshComponent* ModuleMesh;  // 0x380(0x8)

	void ToggleAiming(bool IsAiming); // Function POLYGON.Item_Module_Optic.ToggleAiming
}; 



// Class POLYGON.Item_Module_Strap
// Size: 0x350(Inherited: 0x340) 
struct AItem_Module_Strap : public AItem_Module_General
{
	uint8_t  Rare;  // 0x340(0x1)
	char pad_833[7];  // 0x341(0x7)
	struct UStaticMeshComponent* ModuleMesh;  // 0x348(0x8)

}; 



// Class POLYGON.PG_PlayerState_Base
// Size: 0x3C0(Inherited: 0x3A8) 
struct APG_PlayerState_Base : public APlayerState
{
	struct FMulticastInlineDelegate OnPlayerNameChanged;  // 0x3A8(0x10)
	struct UClientBackendComponent* ClientBackendComponent;  // 0x3B8(0x8)

	void UpdatePlayerCombinedInfo(struct TArray<uint8_t >& ModifiedData, struct FString customDelegateString); // Function POLYGON.PG_PlayerState_Base.UpdatePlayerCombinedInfo
	void SetPlayerName(struct FString PlayerName); // Function POLYGON.PG_PlayerState_Base.SetPlayerName
	struct FUniqueNetIdRepl GetUniqueNetId(); // Function POLYGON.PG_PlayerState_Base.GetUniqueNetId
}; 



// Class POLYGON.PG_AnimInstance
// Size: 0x350(Inherited: 0x350) 
struct UPG_AnimInstance : public UAnimInstance
{

}; 



// Class POLYGON.PG_GameInstance
// Size: 0x1D0(Inherited: 0x1C0) 
struct UPG_GameInstance : public UGameInstance
{
	struct UServerGameInstance* ServerGameInstance;  // 0x1C0(0x8)
	struct UClientGameInstance* ClientGameInstance;  // 0x1C8(0x8)

	struct UServerGameInstance* GetServerGameInstance(); // Function POLYGON.PG_GameInstance.GetServerGameInstance
	struct UClientGameInstance* GetClientGameInstance(); // Function POLYGON.PG_GameInstance.GetClientGameInstance
}; 



// Class POLYGON.PG_CharacterMovementComponent
// Size: 0xF00(Inherited: 0xF00) 
struct UPG_CharacterMovementComponent : public UCharacterMovementComponent
{

}; 



// Class POLYGON.SquadComponent
// Size: 0xF0(Inherited: 0xA0) 
struct USquadComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnMembersUpdate;  // 0xA0(0x10)
	struct FMulticastInlineDelegate OnIsMemberMySquad;  // 0xB0(0x10)
	struct FMulticastInlineDelegate OnCooldownStarted;  // 0xC0(0x10)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bIsMemberMySquad : 1;  // 0xD0(0x1)
	char pad_209[7];  // 0xD1(0x7)
	struct TArray<struct APG_PlayerState_Game*> Members;  // 0xD8(0x10)
	char CooldownCounter;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	float CooldownStartTime;  // 0xEC(0x4)

	void OnRep_Members(); // Function POLYGON.SquadComponent.OnRep_Members
	void OnRep_CooldownCounter(); // Function POLYGON.SquadComponent.OnRep_CooldownCounter
}; 



// Class POLYGON.PG_FunctionLibraryKit
// Size: 0x28(Inherited: 0x28) 
struct UPG_FunctionLibraryKit : public UBlueprintFunctionLibrary
{

	struct FString ParseOption(struct FString Options, struct FString Key, struct FString Separator); // Function POLYGON.PG_FunctionLibraryKit.ParseOption
	uint8_t  GetRegionEnum(struct FString regionName); // Function POLYGON.PG_FunctionLibraryKit.GetRegionEnum
	float GetRateScale(struct UAnimSequenceBase* AnimationSequenceBase); // Function POLYGON.PG_FunctionLibraryKit.GetRateScale
	struct FString GetProjectVersion(); // Function POLYGON.PG_FunctionLibraryKit.GetProjectVersion
	int32_t GetBuildNumber(); // Function POLYGON.PG_FunctionLibraryKit.GetBuildNumber
	void ExitGame(); // Function POLYGON.PG_FunctionLibraryKit.ExitGame
}; 



// Class POLYGON.PG_GameMode_Base
// Size: 0x378(Inherited: 0x378) 
struct APG_GameMode_Base : public AGameMode
{

}; 



// Class POLYGON.PG_BeaconHostObject
// Size: 0x2B8(Inherited: 0x2B8) 
struct APG_BeaconHostObject : public AOnlineBeaconHostObject
{

}; 



// Class POLYGON.PG_GameMode_Game
// Size: 0x3D8(Inherited: 0x378) 
struct APG_GameMode_Game : public APG_GameMode_Base
{
	struct AOnlineBeaconHost* Beacon;  // 0x378(0x8)
	struct TArray<struct FBeaconSlotRequest> PlayersQueue;  // 0x380(0x10)
	struct TArray<struct UReservedSlot*> ReservedSlots;  // 0x390(0x10)
	struct TArray<struct FString> BlackListPlayersID;  // 0x3A0(0x10)
	char pad_944[16];  // 0x3B0(0x10)
	int32_t TotalGameTime;  // 0x3C0(0x4)
	char pad_964[4];  // 0x3C4(0x4)
	struct UPlayFabJsonObject* ServerData;  // 0x3C8(0x8)
	struct UServerBackendComponent* ServerBackendComponent;  // 0x3D0(0x8)

	void LoginPlayer(struct APG_PlayerController_Game* PlayerController, struct FString PlayerMasterId); // Function POLYGON.PG_GameMode_Game.LoginPlayer
}; 



// Class POLYGON.PG_GameMode_Menu
// Size: 0x378(Inherited: 0x378) 
struct APG_GameMode_Menu : public APG_GameMode_Base
{

}; 



// Class POLYGON.PG_Game_Character
// Size: 0x730(Inherited: 0x620) 
struct APG_Game_Character : public ACharacter
{
	char pad_1568[16];  // 0x620(0x10)
	struct FMulticastInlineDelegate OnSetPlayerState;  // 0x630(0x10)
	struct FMulticastInlineDelegate OnSetActorHiddenInGame;  // 0x640(0x10)
	char pad_1616[1];  // 0x650(0x1)
	uint8_t  PlayerAction;  // 0x651(0x1)
	char pad_1618[2];  // 0x652(0x2)
	float leanBodyAlpha;  // 0x654(0x4)
	char RespawnCounter;  // 0x658(0x1)
	char pad_1625[11];  // 0x659(0xB)
	float ControllerPitchRotation;  // 0x664(0x4)
	float ControllerYawRotation;  // 0x668(0x4)
	char pad_1644[12];  // 0x66C(0xC)
	struct AActor* FocusActor;  // 0x678(0x8)
	char pad_1664[8];  // 0x680(0x8)
	struct AActor* CurrentInteractActor;  // 0x688(0x8)
	char pad_1680[8];  // 0x690(0x8)
	struct UParticleSystem* ParticleDamageBlood;  // 0x698(0x8)
	struct USoundBase* SoundBullet;  // 0x6A0(0x8)
	UAnimInstance* FirstPersonAnimInstanceClass;  // 0x6A8(0x8)
	struct USkeletalMesh* FirstPersonCharacterMesh;  // 0x6B0(0x8)
	struct USkeletalMesh* ThirdPersonCharacterMesh;  // 0x6B8(0x8)
	struct UArrowComponent* ViewArrow;  // 0x6C0(0x8)
	struct UCameraComponent* FirstPersonCamera;  // 0x6C8(0x8)
	struct USpringArmComponent* ThirdPersonCameraBoom;  // 0x6D0(0x8)
	struct UCameraComponent* ThirdPersonCamera;  // 0x6D8(0x8)
	struct UInputComponent* PlayerInputComponent;  // 0x6E0(0x8)
	struct UWidgetComponent* WidgetPlayerMarker;  // 0x6E8(0x8)
	struct USpringArmComponent* SpectatorCameraBoom;  // 0x6F0(0x8)
	struct USceneCaptureComponent2D* SpectatorCameraCapture;  // 0x6F8(0x8)
	struct USkeletalMeshComponent* Armor;  // 0x700(0x8)
	struct UStaticMeshComponent* HeadGear;  // 0x708(0x8)
	struct UStaticMeshComponent* Backpack;  // 0x710(0x8)
	struct AItem_Watch_General* Watch;  // 0x718(0x8)
	struct UHealthStatsComponent* HealthStatsComponent;  // 0x720(0x8)
	struct UWeaponComponent* WeaponComponent;  // 0x728(0x8)

	void StopInteractWithObject_server(); // Function POLYGON.PG_Game_Character.StopInteractWithObject_server
	void StopInteractWithObject(); // Function POLYGON.PG_Game_Character.StopInteractWithObject
	void StartShooting(); // Function POLYGON.PG_Game_Character.StartShooting
	void StartInteractWithObject_server(struct AActor* interactActor); // Function POLYGON.PG_Game_Character.StartInteractWithObject_server
	void StartInteractWithObject(); // Function POLYGON.PG_Game_Character.StartInteractWithObject
	void SetNeutralizationVignetteImpact(float newNeutralizationVignetteImpact); // Function POLYGON.PG_Game_Character.SetNeutralizationVignetteImpact
	void SetIsSprinting_server(bool NewState); // Function POLYGON.PG_Game_Character.SetIsSprinting_server
	void Respawn_client(struct FVector_NetQuantize NewLocation, struct FVector_NetQuantizeNormal newRotator); // Function POLYGON.PG_Game_Character.Respawn_client
	void Respawn(); // Function POLYGON.PG_Game_Character.Respawn
	void PlayerLooks(); // Function POLYGON.PG_Game_Character.PlayerLooks
	void OnRep_RespawnCounter(char PreviousValue); // Function POLYGON.PG_Game_Character.OnRep_RespawnCounter
	void OnRep_PlayerAction(uint8_t  previousAction); // Function POLYGON.PG_Game_Character.OnRep_PlayerAction
	void NotifyDeathWithImpulse_multicast(struct APG_PlayerState_Game* killer, uint8_t  deathType, struct FVector_NetQuantize Impulse, char BoneIndex); // Function POLYGON.PG_Game_Character.NotifyDeathWithImpulse_multicast
	void NotifyDeath_multicast(struct APG_PlayerState_Game* killer, uint8_t  deathType); // Function POLYGON.PG_Game_Character.NotifyDeath_multicast
	void LeanBody_server(int8_t leanBodyAlpha); // Function POLYGON.PG_Game_Character.LeanBody_server
	void HitAtProtectedCharacter(); // Function POLYGON.PG_Game_Character.HitAtProtectedCharacter
	uint8_t  GetTeam(); // Function POLYGON.PG_Game_Character.GetTeam
	uint8_t  GetPlayerAction(); // Function POLYGON.PG_Game_Character.GetPlayerAction
	float GetNeutralizationVignetteImpact(); // Function POLYGON.PG_Game_Character.GetNeutralizationVignetteImpact
	bool GetIsSprinting(); // Function POLYGON.PG_Game_Character.GetIsSprinting
	struct UCameraComponent* GetActiveCamera(); // Function POLYGON.PG_Game_Character.GetActiveCamera
	void EventTakeDamage(struct FVector& Origin); // Function POLYGON.PG_Game_Character.EventTakeDamage
	void DeathEvent(struct APG_PlayerState_Game* killer, uint8_t  deathType); // Function POLYGON.PG_Game_Character.DeathEvent
	void ChangeIsAlive(); // Function POLYGON.PG_Game_Character.ChangeIsAlive
	void CameraNeutralizationEffectEvent(float Damage); // Function POLYGON.PG_Game_Character.CameraNeutralizationEffectEvent
	void ActionWhenTakeDamage_client(struct AActor* DamageCauser); // Function POLYGON.PG_Game_Character.ActionWhenTakeDamage_client
	void ActionWhenGunHit_client(struct APG_Game_Character* characterInstigator, char hitBoneIndex); // Function POLYGON.PG_Game_Character.ActionWhenGunHit_client
}; 



// Class POLYGON.PG_BeaconClient
// Size: 0x350(Inherited: 0x320) 
struct APG_BeaconClient : public AOnlineBeaconClient
{
	char pad_800[48];  // 0x320(0x30)

	void SendNumberInQueue_client(char Number); // Function POLYGON.PG_BeaconClient.SendNumberInQueue_client
	void ResponseReserveSlot_client(char Payload); // Function POLYGON.PG_BeaconClient.ResponseReserveSlot_client
	void RequestReserveSlot_server(struct TArray<struct FUniqueNetIdRepl> unequeIds, bool isUsedMatchmaker); // Function POLYGON.PG_BeaconClient.RequestReserveSlot_server
	void RequestReserveSlot(struct TArray<struct FUniqueNetIdRepl>& unequeIds, bool isUsedMatchmaker, struct FDelegate onResponseReserveSlot, struct FDelegate onPutInQueue); // Function POLYGON.PG_BeaconClient.RequestReserveSlot
	void LeaveQueue(); // Function POLYGON.PG_BeaconClient.LeaveQueue
	bool ConnectToServer(struct FString IP, int32_t BeaconPort, struct FDelegate onConnectedStateChange); // Function POLYGON.PG_BeaconClient.ConnectToServer
}; 



// Class POLYGON.PG_PlayerController_Game
// Size: 0x8B0(Inherited: 0x880) 
struct APG_PlayerController_Game : public APG_PlayerController_Base
{
	struct FMulticastInlineDelegate OnDeployIsAvailable;  // 0x880(0x10)
	float TimeVoteKick;  // 0x890(0x4)
	char pad_2196_1 : 7;  // 0x894(0x1)
	bool bDeployIsAvailable : 1;  // 0x894(0x1)
	char pad_2197[11];  // 0x895(0xB)
	struct UEventManagerComponent* EventManagerComponent;  // 0x8A0(0x8)
	struct UFOVManagerComponent* FOVManagerComponent;  // 0x8A8(0x8)

	void VoteKick(struct APG_PlayerState_Game* badGuy); // Function POLYGON.PG_PlayerController_Game.VoteKick
	void StopInteractionEvent(); // Function POLYGON.PG_PlayerController_Game.StopInteractionEvent
	void StopInteraction_Client(); // Function POLYGON.PG_PlayerController_Game.StopInteraction_Client
	void StartInteractionEvent(float interactionTime); // Function POLYGON.PG_PlayerController_Game.StartInteractionEvent
	void StartInteraction_Client(float interactionTime); // Function POLYGON.PG_PlayerController_Game.StartInteraction_Client
	void SetVisibleLoadingScreen(bool IsVisible); // Function POLYGON.PG_PlayerController_Game.SetVisibleLoadingScreen
	void RequestSpawnOnSquadMember_server(struct APG_PlayerState_Game* squadMember); // Function POLYGON.PG_PlayerController_Game.RequestSpawnOnSquadMember_server
	void RequestSpawnOnControlPoint_server(uint8_t  spawnToControlPoint); // Function POLYGON.PG_PlayerController_Game.RequestSpawnOnControlPoint_server
	void RequestSpawnOnBase_server(); // Function POLYGON.PG_PlayerController_Game.RequestSpawnOnBase_server
	void OnRep_DeployIsAvailable(); // Function POLYGON.PG_PlayerController_Game.OnRep_DeployIsAvailable
	void LoginPlayer_server(struct FString PlayerMasterId); // Function POLYGON.PG_PlayerController_Game.LoginPlayer_server
	void DisplayMessageToChatEvent(struct FGameChatMessage Message); // Function POLYGON.PG_PlayerController_Game.DisplayMessageToChatEvent
}; 



// Class POLYGON.PG_PlayerController_Menu
// Size: 0x880(Inherited: 0x880) 
struct APG_PlayerController_Menu : public APG_PlayerController_Base
{

}; 



// Class POLYGON.PG_PlayerState_Menu
// Size: 0x3C8(Inherited: 0x3C0) 
struct APG_PlayerState_Menu : public APG_PlayerState_Base
{
	struct UInventoryComponent_Menu* InventoryComponent;  // 0x3C0(0x8)

}; 



// Class POLYGON.ReservedSlot
// Size: 0x78(Inherited: 0x28) 
struct UReservedSlot : public UObject
{
	char pad_40[80];  // 0x28(0x50)

}; 



// Class POLYGON.SupportBox
// Size: 0x2B8(Inherited: 0x290) 
struct ASupportBox : public AActor
{
	char pad_656[8];  // 0x290(0x8)
	struct TArray<struct APG_Game_Character*> CoverageCharacters;  // 0x298(0x10)
	struct UStaticMeshComponent* BoxMesh;  // 0x2A8(0x8)
	struct UWidgetComponent* WidgetTypeSupportBox;  // 0x2B0(0x8)

	void OnCoverageEndOverlap(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex); // Function POLYGON.SupportBox.OnCoverageEndOverlap
	void OnCoverageBeginOverlap(struct UPrimitiveComponent* OverlappedComp, struct AActor* Other, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool fromSweep, struct FHitResult& SweepResult); // Function POLYGON.SupportBox.OnCoverageBeginOverlap
}; 



// Class POLYGON.SupportBox_Ammo
// Size: 0x2C0(Inherited: 0x2B8) 
struct ASupportBox_Ammo : public ASupportBox
{
	struct USoundBase* ActionSound;  // 0x2B8(0x8)

}; 



// Class POLYGON.SupportBox_Health
// Size: 0x2B8(Inherited: 0x2B8) 
struct ASupportBox_Health : public ASupportBox
{

}; 



// Class POLYGON.TeamBase
// Size: 0x298(Inherited: 0x290) 
struct ATeamBase : public AActor
{
	uint8_t  Team;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)

}; 



// Class POLYGON.UserEntry
// Size: 0x28(Inherited: 0x28) 
struct UUserEntry : public UObject
{

}; 



// Class POLYGON.WeaponComponent
// Size: 0x150(Inherited: 0xA0) 
struct UWeaponComponent : public UActorComponent
{
	struct FMulticastInlineDelegate OnAiming;  // 0xA0(0x10)
	char pad_176[29];  // 0xB0(0x1D)
	char pad_205_1 : 7;  // 0xCD(0x1)
	bool bIsAiming : 1;  // 0xCD(0x1)
	char pad_206_1 : 7;  // 0xCE(0x1)
	bool bGunIsDown : 1;  // 0xCE(0x1)
	char pad_207[1];  // 0xCF(0x1)
	struct UParticleSystem* FireFXLocal;  // 0xD0(0x8)
	struct UParticleSystem* FireFXSimulate;  // 0xD8(0x8)
	struct UParticleSystem* HitFX_Metal;  // 0xE0(0x8)
	struct UParticleSystem* HitFX_Stone;  // 0xE8(0x8)
	struct UParticleSystem* HitFX_Dirt;  // 0xF0(0x8)
	struct UParticleSystem* HitFX_Wood;  // 0xF8(0x8)
	struct UParticleSystem* HitFX_Water;  // 0x100(0x8)
	struct UParticleSystem* HitFX_Glass;  // 0x108(0x8)
	struct UParticleSystem* HitFX_Blood;  // 0x110(0x8)
	struct UMaterialInterface* DecalImpact;  // 0x118(0x8)
	struct USoundBase* SoundCharacterHit;  // 0x120(0x8)
	struct USoundBase* SoundCharacterHit_Protection;  // 0x128(0x8)
	struct USoundBase* SoundRicochetHit;  // 0x130(0x8)
	struct USoundBase* SoundBodyHit;  // 0x138(0x8)
	char pad_320[16];  // 0x140(0x10)

	void ToggleAiming_server(); // Function POLYGON.WeaponComponent.ToggleAiming_server
	void SetWantsToAiming_server(bool NewState); // Function POLYGON.WeaponComponent.SetWantsToAiming_server
	void SetStrivingGunRecoilAlpha_Pitch(float newStrivingPitchRecoil); // Function POLYGON.WeaponComponent.SetStrivingGunRecoilAlpha_Pitch
	void SetGunRecoilIsActive_Backward(); // Function POLYGON.WeaponComponent.SetGunRecoilIsActive_Backward
	void SetGunRecoilAlpha_Yaw(float newYawRecoil); // Function POLYGON.WeaponComponent.SetGunRecoilAlpha_Yaw
	void SetGunRecoilAlpha_Roll(float newRollRecoil); // Function POLYGON.WeaponComponent.SetGunRecoilAlpha_Roll
	void SelectGunSlot_server(char Slot); // Function POLYGON.WeaponComponent.SelectGunSlot_server
	void OnSetSecondaryGun(); // Function POLYGON.WeaponComponent.OnSetSecondaryGun
	void OnSetPrimaryGun(); // Function POLYGON.WeaponComponent.OnSetPrimaryGun
	void OnSetPlayerState(); // Function POLYGON.WeaponComponent.OnSetPlayerState
	void OnSetCurrentGun(struct AItem_Gun_General* OldCurrentGun); // Function POLYGON.WeaponComponent.OnSetCurrentGun
	void OnRep_IsAiming(); // Function POLYGON.WeaponComponent.OnRep_IsAiming
	void NotifyServerThrowGrenade(); // Function POLYGON.WeaponComponent.NotifyServerThrowGrenade
	bool IsWantsToAiming(); // Function POLYGON.WeaponComponent.IsWantsToAiming
	bool IsAiming(); // Function POLYGON.WeaponComponent.IsAiming
	bool GetIsShooting(); // Function POLYGON.WeaponComponent.GetIsShooting
	float GetGunRecoilAlpha_Yaw(); // Function POLYGON.WeaponComponent.GetGunRecoilAlpha_Yaw
	float GetGunRecoilAlpha_Roll(); // Function POLYGON.WeaponComponent.GetGunRecoilAlpha_Roll
	float GetGunRecoilAlpha_Pitch(); // Function POLYGON.WeaponComponent.GetGunRecoilAlpha_Pitch
	float GetGunRecoilAlpha_Backward(); // Function POLYGON.WeaponComponent.GetGunRecoilAlpha_Backward
	struct AItem_Gun_General* GetCurrentGun(); // Function POLYGON.WeaponComponent.GetCurrentGun
}; 



