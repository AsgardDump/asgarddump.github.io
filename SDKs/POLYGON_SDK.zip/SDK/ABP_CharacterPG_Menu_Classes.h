#pragma once 
#include <ABP_CharacterPG_Menu_Structs.h>
 
 
 
// AnimBlueprintGeneratedClass ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C
// Size: 0x19A8(Inherited: 0x350) 
struct UABP_CharacterPG_Menu_C : public UAnimInstance
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x350(0x8)
	struct FAnimBlueprintGeneratedMutableData __AnimBlueprintMutables;  // 0x358(0x20)
	struct FAnimSubsystemInstance AnimBlueprintExtension_PropertyAccess;  // 0x378(0x8)
	struct FAnimSubsystemInstance AnimBlueprintExtension_Base;  // 0x380(0x8)
	struct FAnimNode_Root AnimGraphNode_Root;  // 0x388(0x20)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // 0x3A8(0x48)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;  // 0x3F0(0x128)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // 0x518(0x20)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // 0x538(0xE0)
	char pad_1560[8];  // 0x618(0x8)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // 0x620(0x270)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // 0x890(0x20)
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // 0x8B0(0x270)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_2;  // 0xB20(0xF0)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator_2;  // 0xC10(0x40)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // 0xC50(0x128)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // 0xD78(0x128)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // 0xEA0(0x128)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // 0xFC8(0x48)
	struct FAnimNode_SequenceEvaluator AnimGraphNode_SequenceEvaluator;  // 0x1010(0x40)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // 0x1050(0x20)
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // 0x1070(0xE0)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // 0x1150(0x128)
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone;  // 0x1278(0xF0)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // 0x1368(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // 0x1388(0x20)
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // 0x13A8(0x108)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // 0x14B0(0x28)
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // 0x14D8(0x28)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // 0x1500(0x20)
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // 0x1520(0x20)
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // 0x1540(0x20)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // 0x1560(0x128)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // 0x1688(0x128)
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // 0x17B0(0x128)
	struct UAnimSequence* GunIdlePose;  // 0x18D8(0x8)
	struct ABP_PG_PlayerController_Menu_C* PlayerController;  // 0x18E0(0x8)
	char pad_6376[8];  // 0x18E8(0x8)
	struct FTransform GunLeftHandOffset;  // 0x18F0(0x60)
	char pad_6480_1 : 7;  // 0x1950(0x1)
	bool IsGripExists : 1;  // 0x1950(0x1)
	char pad_6481[7];  // 0x1951(0x7)
	struct UAnimSequence* GripHandPose;  // 0x1958(0x8)
	struct FVector IK_LeftHandPosition;  // 0x1960(0x18)
	struct FRotator IK_LeftHandRotation;  // 0x1978(0x18)
	struct ABP_PG_PlayerState_Menu_C* PlayerState;  // 0x1990(0x8)
	struct AItem_Gun_General* Current Gun;  // 0x1998(0x8)
	struct ABP_PG_Menu_Character_C* Character;  // 0x19A0(0x8)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.AnimGraph
	void CacheGunModulesValues(); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.CacheGunModulesValues
	void CacheGunValues(); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.CacheGunValues
	void BlueprintInitializeAnimation(); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.BlueprintInitializeAnimation
	void OnSetPrimaryGun_Event(); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.OnSetPrimaryGun_Event
	void OnSetPlayerState_Event(); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.OnSetPlayerState_Event
	void OnSetGunModules_Event(); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.OnSetGunModules_Event
	void ExecuteUbergraph_ABP_CharacterPG_Menu(int32_t EntryPoint); // Function ABP_CharacterPG_Menu.ABP_CharacterPG_Menu_C.ExecuteUbergraph_ABP_CharacterPG_Menu
}; 



