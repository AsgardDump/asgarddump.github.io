#pragma once 
#include "SDK.h" 
 
 
// Function LVL_Menu_v3.LVL_Menu_v3_C.ExecuteUbergraph_LVL_Menu_v3
// Size: 0x68(Inherited: 0x0) 
struct FExecuteUbergraph_LVL_Menu_v3
{
	int32_t EntryPoint;  // 0x0(0x4)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // 0x4(0x10)
	char pad_20[4];  // 0x14(0x4)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue;  // 0x18(0x8)
	int32_t K2Node_CustomEvent_NewValue_2;  // 0x20(0x4)
	char pad_36_1 : 7;  // 0x24(0x1)
	bool CallFunc_IsValid_ReturnValue : 1;  // 0x24(0x1)
	char pad_37[3];  // 0x25(0x3)
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // 0x28(0x10)
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // 0x38(0x10)
	struct APlayerController* CallFunc_GetPlayerController_ReturnValue_2;  // 0x48(0x8)
	int32_t K2Node_CustomEvent_NewValue;  // 0x50(0x4)
	char pad_84_1 : 7;  // 0x54(0x1)
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // 0x54(0x1)
	char pad_85[3];  // 0x55(0x3)
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // 0x58(0x10)

}; 
// Function LVL_Menu_v3.LVL_Menu_v3_C.ChangeLobbyFPSLimit
// Size: 0x4(Inherited: 0x0) 
struct FChangeLobbyFPSLimit
{
	int32_t NewValue;  // 0x0(0x4)

}; 
// Function LVL_Menu_v3.LVL_Menu_v3_C.ChangeShadowQualitySettings
// Size: 0x4(Inherited: 0x0) 
struct FChangeShadowQualitySettings
{
	int32_t NewValue;  // 0x0(0x4)

}; 
