#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Chaos.ManagedArrayCollection
// Size: 0xB0(Inherited: 0x0) 
struct FManagedArrayCollection
{
	char pad_0[176];  // 0x0(0xB0)

}; 
// ScriptStruct Chaos.ChaosSolverConfiguration
// Size: 0x68(Inherited: 0x0) 
struct FChaosSolverConfiguration
{
	int32_t PositionIterations;  // 0x0(0x4)
	int32_t VelocityIterations;  // 0x4(0x4)
	int32_t ProjectionIterations;  // 0x8(0x4)
	float CollisionMarginFraction;  // 0xC(0x4)
	float CollisionMarginMax;  // 0x10(0x4)
	float CollisionCullDistance;  // 0x14(0x4)
	float CollisionMaxPushOutVelocity;  // 0x18(0x4)
	float ClusterConnectionFactor;  // 0x1C(0x4)
	uint8_t  ClusterUnionConnectionType;  // 0x20(0x1)
	char pad_33_1 : 7;  // 0x21(0x1)
	bool bGenerateCollisionData : 1;  // 0x21(0x1)
	char pad_34[2];  // 0x22(0x2)
	struct FSolverCollisionFilterSettings CollisionFilterSettings;  // 0x24(0x10)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool bGenerateBreakData : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FSolverBreakingFilterSettings BreakingFilterSettings;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bGenerateTrailingData : 1;  // 0x48(0x1)
	char pad_73[3];  // 0x49(0x3)
	struct FSolverTrailingFilterSettings TrailingFilterSettings;  // 0x4C(0x10)
	int32_t Iterations;  // 0x5C(0x4)
	int32_t PushOutIterations;  // 0x60(0x4)
	char pad_100_1 : 7;  // 0x64(0x1)
	bool bGenerateContactGraph : 1;  // 0x64(0x1)
	char pad_101[3];  // 0x65(0x3)

}; 
// ScriptStruct Chaos.SolverCollisionFilterSettings
// Size: 0x10(Inherited: 0x0) 
struct FSolverCollisionFilterSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FilterEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinImpulse;  // 0xC(0x4)

}; 
// ScriptStruct Chaos.SolverRemovalFilterSettings
// Size: 0xC(Inherited: 0x0) 
struct FSolverRemovalFilterSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FilterEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float MinMass;  // 0x4(0x4)
	float MinVolume;  // 0x8(0x4)

}; 
// ScriptStruct Chaos.SolverTrailingFilterSettings
// Size: 0x10(Inherited: 0x0) 
struct FSolverTrailingFilterSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FilterEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinVolume;  // 0xC(0x4)

}; 
// ScriptStruct Chaos.SolverBreakingFilterSettings
// Size: 0x10(Inherited: 0x0) 
struct FSolverBreakingFilterSettings
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool FilterEnabled : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float MinMass;  // 0x4(0x4)
	float MinSpeed;  // 0x8(0x4)
	float MinVolume;  // 0xC(0x4)

}; 
// ScriptStruct Chaos.SolverTrailingData
// Size: 0x58(Inherited: 0x0) 
struct FSolverTrailingData
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector Velocity;  // 0x18(0x18)
	struct FVector AngularVelocity;  // 0x30(0x18)
	float Mass;  // 0x48(0x4)
	int32_t ParticleIndex;  // 0x4C(0x4)
	int32_t ParticleIndexMesh;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct Chaos.SolverCollisionData
// Size: 0xC0(Inherited: 0x0) 
struct FSolverCollisionData
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector AccumulatedImpulse;  // 0x18(0x18)
	struct FVector Normal;  // 0x30(0x18)
	struct FVector Velocity1;  // 0x48(0x18)
	struct FVector Velocity2;  // 0x60(0x18)
	struct FVector AngularVelocity1;  // 0x78(0x18)
	struct FVector AngularVelocity2;  // 0x90(0x18)
	float Mass1;  // 0xA8(0x4)
	float Mass2;  // 0xAC(0x4)
	int32_t ParticleIndex;  // 0xB0(0x4)
	int32_t LevelsetIndex;  // 0xB4(0x4)
	int32_t ParticleIndexMesh;  // 0xB8(0x4)
	int32_t LevelsetIndexMesh;  // 0xBC(0x4)

}; 
// ScriptStruct Chaos.SolverBreakingData
// Size: 0x58(Inherited: 0x0) 
struct FSolverBreakingData
{
	struct FVector Location;  // 0x0(0x18)
	struct FVector Velocity;  // 0x18(0x18)
	struct FVector AngularVelocity;  // 0x30(0x18)
	float Mass;  // 0x48(0x4)
	int32_t ParticleIndex;  // 0x4C(0x4)
	int32_t ParticleIndexMesh;  // 0x50(0x4)
	char pad_84[4];  // 0x54(0x4)

}; 
// ScriptStruct Chaos.RecordedFrame
// Size: 0xB8(Inherited: 0x0) 
struct FRecordedFrame
{
	struct TArray<struct FTransform> Transforms;  // 0x0(0x10)
	struct TArray<int32_t> TransformIndices;  // 0x10(0x10)
	struct TArray<int32_t> PreviousTransformIndices;  // 0x20(0x10)
	struct TArray<bool> DisabledFlags;  // 0x30(0x10)
	struct TArray<struct FSolverCollisionData> Collisions;  // 0x40(0x10)
	struct TArray<struct FSolverBreakingData> Breakings;  // 0x50(0x10)
	struct TSet<struct FSolverTrailingData> Trailings;  // 0x60(0x50)
	float Timestamp;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)

}; 
// ScriptStruct Chaos.RecordedTransformTrack
// Size: 0x10(Inherited: 0x0) 
struct FRecordedTransformTrack
{
	struct TArray<struct FRecordedFrame> Records;  // 0x0(0x10)

}; 
