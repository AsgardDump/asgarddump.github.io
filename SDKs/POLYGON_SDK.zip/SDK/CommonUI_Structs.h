#pragma once 
#include "SDK.h" 
 
 
// Function CommonUI.CommonNumericTextBlock.GetTargetValue
// Size: 0x4(Inherited: 0x0) 
struct FGetTargetValue
{
	float ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction CommonUI.CommonActionCommited__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FCommonActionCommited__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPassThrough : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonDateTimeTextBlock.GetDateTime
// Size: 0x8(Inherited: 0x0) 
struct FGetDateTime
{
	struct FDateTime ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonTabListWidgetBase.DisableTabWithReason
// Size: 0x20(Inherited: 0x0) 
struct FDisableTabWithReason
{
	struct FName TabNameID;  // 0x0(0x8)
	struct FText Reason;  // 0x8(0x18)

}; 
// DelegateFunction CommonUI.CommonActionProgress__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FCommonActionProgress__DelegateSignature
{
	float HeldPercent;  // 0x0(0x4)

}; 
// Function CommonUI.CommonTextBlock.SetLineHeightPercentage
// Size: 0x4(Inherited: 0x0) 
struct FSetLineHeightPercentage
{
	float InLineHeightPercentage;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonBase.GetSelected
// Size: 0x1(Inherited: 0x0) 
struct FGetSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction CommonUI.CommonActionProgressSingle__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FCommonActionProgressSingle__DelegateSignature
{
	float HeldPercent;  // 0x0(0x4)

}; 
// Function CommonUI.CommonTabListWidgetBase.RegisterTab
// Size: 0x20(Inherited: 0x0) 
struct FRegisterTab
{
	struct FName TabNameID;  // 0x0(0x8)
	UCommonButtonBase* ButtonWidgetType;  // 0x8(0x8)
	struct UWidget* ContentWidget;  // 0x10(0x8)
	int32_t TabIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// DelegateFunction CommonUI.OnCurrentPageIndexChanged__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnCurrentPageIndexChanged__DelegateSignature
{
	struct UCommonWidgetCarousel* CarouselWidget;  // 0x0(0x8)
	int32_t CurrentPageIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction CommonUI.CommonButtonBaseClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FCommonButtonBaseClicked__DelegateSignature
{
	struct UCommonButtonBase* Button;  // 0x0(0x8)

}; 
// DelegateFunction CommonUI.CommonSelectedStateChangedBase__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FCommonSelectedStateChangedBase__DelegateSignature
{
	struct UCommonButtonBase* Button;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Selected : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function CommonUI.CommonActionWidget.IsHeldAction
// Size: 0x1(Inherited: 0x0) 
struct FIsHeldAction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction CommonUI.HardwareVisibilityTagsChangedDynamicEvent__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FHardwareVisibilityTagsChangedDynamicEvent__DelegateSignature
{
	struct UCommonUIVisibilitySubsystem* TagSubsystem;  // 0x0(0x8)

}; 
// DelegateFunction CommonUI.OnItemClicked__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnItemClicked__DelegateSignature
{
	struct UUserWidget* Widget;  // 0x0(0x8)

}; 
// Function CommonUI.CommonDateTimeTextBlock.SetDateTimeValue
// Size: 0x10(Inherited: 0x0) 
struct FSetDateTimeValue
{
	struct FDateTime InDateTime;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bShowAsCountdown : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)
	float InRefreshDelay;  // 0xC(0x4)

}; 
// ScriptStruct CommonUI.CommonRegisteredTabInfo
// Size: 0x18(Inherited: 0x0) 
struct FCommonRegisteredTabInfo
{
	int32_t TabIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UCommonButtonBase* TabButton;  // 0x8(0x8)
	struct UWidget* ContentInstance;  // 0x10(0x8)

}; 
// DelegateFunction CommonUI.OnItemSelected__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnItemSelected__DelegateSignature
{
	struct UUserWidget* Widget;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool Selected : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction CommonUI.OnLoadGuardStateChangedDynamic__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnLoadGuardStateChangedDynamic__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsLoading : 1;  // 0x0(0x1)

}; 
// DelegateFunction CommonUI.OnRotated__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FOnRotated__DelegateSignature
{
	int32_t Value;  // 0x0(0x4)

}; 
// DelegateFunction CommonUI.SimpleButtonBaseGroupDelegate__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FSimpleButtonBaseGroupDelegate__DelegateSignature
{
	struct UCommonButtonBase* AssociatedButton;  // 0x0(0x8)
	int32_t ButtonIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// DelegateFunction CommonUI.CommonCustomNavigation.OnCustomNavigationEvent__DelegateSignature
// Size: 0x2(Inherited: 0x0) 
struct FOnCustomNavigationEvent__DelegateSignature
{
	uint8_t  NavigationType;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ReturnValue : 1;  // 0x1(0x1)

}; 
// Function CommonUI.CommonButtonBase.IsInteractionEnabled
// Size: 0x1(Inherited: 0x0) 
struct FIsInteractionEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonActionWidget.SetInputActions
// Size: 0x10(Inherited: 0x0) 
struct FSetInputActions
{
	struct TArray<struct FDataTableRowHandle> NewInputActions;  // 0x0(0x10)

}; 
// Function CommonUI.CommonActionWidget.GetDisplayText
// Size: 0x18(Inherited: 0x0) 
struct FGetDisplayText
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function CommonUI.CommonActionWidget.GetIcon
// Size: 0xD0(Inherited: 0x0) 
struct FGetIcon
{
	struct FSlateBrush ReturnValue;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonTabListWidgetBase.RemoveTab
// Size: 0xC(Inherited: 0x0) 
struct FRemoveTab
{
	struct FName TabNameID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function CommonUI.CommonTabListWidgetBase.SelectTabByID
// Size: 0xC(Inherited: 0x0) 
struct FSelectTabByID
{
	struct FName TabNameID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bSuppressClickFeedback : 1;  // 0x8(0x1)
	char pad_9_1 : 7;  // 0x9(0x1)
	bool ReturnValue : 1;  // 0x9(0x1)
	char pad_10[2];  // 0xA(0x2)

}; 
// DelegateFunction CommonUI.CommonActionWidget.OnInputMethodChanged__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnInputMethodChanged__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUsingGamepad : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonUserWidget.SetConsumePointerInput
// Size: 0x1(Inherited: 0x0) 
struct FSetConsumePointerInput
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInConsumePointerInput : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonActivatableWidget.SetBindVisibilities
// Size: 0x3(Inherited: 0x0) 
struct FSetBindVisibilities
{
	uint8_t  OnActivatedVisibility;  // 0x0(0x1)
	uint8_t  OnDeactivatedVisibility;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bInAllActive : 1;  // 0x2(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetStyle
// Size: 0x8(Inherited: 0x0) 
struct FSetStyle
{
	UCommonButtonStyle* InStyle;  // 0x0(0x8)

}; 
// Function CommonUI.CommonTabListWidgetBase.GetTabIdAtIndex
// Size: 0xC(Inherited: 0x0) 
struct FGetTabIdAtIndex
{
	int32_t Index;  // 0x0(0x4)
	struct FName ReturnValue;  // 0x4(0x8)

}; 
// Function CommonUI.CommonActionWidget.SetIconRimBrush
// Size: 0xD0(Inherited: 0x0) 
struct FSetIconRimBrush
{
	struct FSlateBrush InIconRimBrush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonActionWidget.SetInputAction
// Size: 0x10(Inherited: 0x0) 
struct FSetInputAction
{
	struct FDataTableRowHandle InputActionRow;  // 0x0(0x10)

}; 
// Function CommonUI.CommonTabListWidgetBase.HandleTabButtonSelected
// Size: 0x10(Inherited: 0x0) 
struct FHandleTabButtonSelected
{
	struct UCommonButtonBase* SelectedTabButton;  // 0x0(0x8)
	int32_t ButtonIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function CommonUI.CommonButtonBase.SetShouldSelectUponReceivingFocus
// Size: 0x1(Inherited: 0x0) 
struct FSetShouldSelectUponReceivingFocus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInShouldSelectUponReceivingFocus : 1;  // 0x0(0x1)

}; 
// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonRemoval__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnTabButtonRemoval__DelegateSignature
{
	struct FName TabId;  // 0x0(0x8)
	struct UCommonButtonBase* TabButton;  // 0x8(0x8)

}; 
// Function CommonUI.CommonLoadGuard.BP_GuardAndLoadAsset
// Size: 0x40(Inherited: 0x0) 
struct FBP_GuardAndLoadAsset
{
	struct TSoftObjectPtr<UObject> InLazyAsset;  // 0x0(0x30)
	struct FDelegate OnAssetLoaded;  // 0x30(0x10)

}; 
// Function CommonUI.CommonNumericTextBlock.InterpolateToValue
// Size: 0x10(Inherited: 0x0) 
struct FInterpolateToValue
{
	float TargetValue;  // 0x0(0x4)
	float MaximumInterpolationDuration;  // 0x4(0x4)
	float MinimumChangeRate;  // 0x8(0x4)
	float OutroOffset;  // 0xC(0x4)

}; 
// Function CommonUI.CommonTextStyle.GetFont
// Size: 0x58(Inherited: 0x0) 
struct FGetFont
{
	struct FSlateFontInfo OutFont;  // 0x0(0x58)

}; 
// Function CommonUI.CommonButtonBase.SetIsInteractionEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetIsInteractionEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsInteractionEnabled : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.GetShouldSelectUponReceivingFocus
// Size: 0x1(Inherited: 0x0) 
struct FGetShouldSelectUponReceivingFocus
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonLoadGuard.SetLoadingText
// Size: 0x18(Inherited: 0x0) 
struct FSetLoadingText
{
	struct FText InLoadingText;  // 0x0(0x18)

}; 
// DelegateFunction CommonUI.CommonLoadGuard.OnAssetLoaded__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnAssetLoaded__DelegateSignature
{
	struct UObject* Object;  // 0x0(0x8)

}; 
// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabButtonCreation__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnTabButtonCreation__DelegateSignature
{
	struct FName TabId;  // 0x0(0x8)
	struct UCommonButtonBase* TabButton;  // 0x8(0x8)

}; 
// Function CommonUI.CommonLazyWidget.IsLoading
// Size: 0x1(Inherited: 0x0) 
struct FIsLoading
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonLoadGuard.SetIsLoading
// Size: 0x1(Inherited: 0x0) 
struct FSetIsLoading
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsLoading : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonTextStyle.GetMargin
// Size: 0x10(Inherited: 0x0) 
struct FGetMargin
{
	struct FMargin OutMargin;  // 0x0(0x10)

}; 
// Function CommonUI.CommonTextBlock.SetMargin
// Size: 0x10(Inherited: 0x0) 
struct FSetMargin
{
	struct FMargin InMargin;  // 0x0(0x10)

}; 
// Function CommonUI.CommonTabListWidgetBase.HandleTabCreation
// Size: 0x10(Inherited: 0x0) 
struct FHandleTabCreation
{
	struct FName TabNameID;  // 0x0(0x8)
	struct UCommonButtonBase* TabButton;  // 0x8(0x8)

}; 
// Function CommonUI.CommonActivatableWidget.BindVisibilityToActivation
// Size: 0x8(Inherited: 0x0) 
struct FBindVisibilityToActivation
{
	struct UCommonActivatableWidget* ActivatableWidget;  // 0x0(0x8)

}; 
// Function CommonUI.CommonRichTextBlock.SetScrollingEnabled
// Size: 0x1(Inherited: 0x0) 
struct FSetScrollingEnabled
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsScrollingEnabled : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonTextBlock.SetTextCase
// Size: 0x1(Inherited: 0x0) 
struct FSetTextCase
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseAllCaps : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonTabListWidgetBase.GetActiveTab
// Size: 0x8(Inherited: 0x0) 
struct FGetActiveTab
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonTextBlock.SetWrapTextWidth
// Size: 0x4(Inherited: 0x0) 
struct FSetWrapTextWidth
{
	int32_t InWrapTextAt;  // 0x0(0x4)

}; 
// Function CommonUI.CommonNumericTextBlock.IsInterpolatingNumericValue
// Size: 0x1(Inherited: 0x0) 
struct FIsInterpolatingNumericValue
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationEnded__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnInterpolationEnded__DelegateSignature
{
	struct UCommonNumericTextBlock* NumericTextBlock;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool HadCompleted : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function CommonUI.CommonWidgetGroupBase.AddWidget
// Size: 0x8(Inherited: 0x0) 
struct FAddWidget
{
	struct UWidget* InWidget;  // 0x0(0x8)

}; 
// ScriptStruct CommonUI.CommonNumberFormattingOptions
// Size: 0x14(Inherited: 0x0) 
struct FCommonNumberFormattingOptions
{
	char ERoundingMode RoundingMode;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool UseGrouping : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t MinimumIntegralDigits;  // 0x4(0x4)
	int32_t MaximumIntegralDigits;  // 0x8(0x4)
	int32_t MinimumFractionalDigits;  // 0xC(0x4)
	int32_t MaximumFractionalDigits;  // 0x10(0x4)

}; 
// Function CommonUI.CommonTabListWidgetBase.GetSelectedTabId
// Size: 0x8(Inherited: 0x0) 
struct FGetSelectedTabId
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationStarted__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnInterpolationStarted__DelegateSignature
{
	struct UCommonNumericTextBlock* NumericTextBlock;  // 0x0(0x8)

}; 
// DelegateFunction CommonUI.CommonNumericTextBlock.OnInterpolationUpdated__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnInterpolationUpdated__DelegateSignature
{
	struct UCommonNumericTextBlock* NumericTextBlock;  // 0x0(0x8)
	float LastValue;  // 0x8(0x4)
	float NewValue;  // 0xC(0x4)

}; 
// DelegateFunction CommonUI.CommonNumericTextBlock.OnOutro__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnOutro__DelegateSignature
{
	struct UCommonNumericTextBlock* NumericTextBlock;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonStyle.GetDisabledTextStyle
// Size: 0x8(Inherited: 0x0) 
struct FGetDisabledTextStyle
{
	struct UCommonTextStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonNumericTextBlock.SetCurrentValue
// Size: 0x4(Inherited: 0x0) 
struct FSetCurrentValue
{
	float NewValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonTabListWidgetBase.GetLinkedSwitcher
// Size: 0x8(Inherited: 0x0) 
struct FGetLinkedSwitcher
{
	struct UCommonAnimatedSwitcher* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonNumericTextBlock.SetNumericType
// Size: 0x1(Inherited: 0x0) 
struct FSetNumericType
{
	uint8_t  InNumericType;  // 0x0(0x1)

}; 
// Function CommonUI.CommonTabListWidgetBase.GetTabButtonBaseByID
// Size: 0x10(Inherited: 0x0) 
struct FGetTabButtonBaseByID
{
	struct FName TabNameID;  // 0x0(0x8)
	struct UCommonButtonBase* ReturnValue;  // 0x8(0x8)

}; 
// Function CommonUI.UCommonVisibilityWidgetBase.GetRegisteredPlatforms
// Size: 0x10(Inherited: 0x0) 
struct FGetRegisteredPlatforms
{
	struct TArray<struct FName> ReturnValue;  // 0x0(0x10)

}; 
// Function CommonUI.CommonTabListWidgetBase.GetTabCount
// Size: 0x4(Inherited: 0x0) 
struct FGetTabCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonTabListWidgetBase.HandleNextTabInputAction
// Size: 0x1(Inherited: 0x0) 
struct FHandleNextTabInputAction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPassThrough : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonTabListWidgetBase.HandlePreviousTabInputAction
// Size: 0x1(Inherited: 0x0) 
struct FHandlePreviousTabInputAction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPassThrough : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonTabListWidgetBase.HandleTabRemoval
// Size: 0x10(Inherited: 0x0) 
struct FHandleTabRemoval
{
	struct FName TabNameID;  // 0x0(0x8)
	struct UCommonButtonBase* TabButton;  // 0x8(0x8)

}; 
// Function CommonUI.CommonTabListWidgetBase.SetTabEnabled
// Size: 0xC(Inherited: 0x0) 
struct FSetTabEnabled
{
	struct FName TabNameID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEnable : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction CommonUI.CommonTabListWidgetBase.OnTabSelected__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FOnTabSelected__DelegateSignature
{
	struct FName TabId;  // 0x0(0x8)

}; 
// Function CommonUI.CommonTabListWidgetBase.SetLinkedSwitcher
// Size: 0x8(Inherited: 0x0) 
struct FSetLinkedSwitcher
{
	struct UCommonAnimatedSwitcher* CommonSwitcher;  // 0x0(0x8)

}; 
// Function CommonUI.CommonTabListWidgetBase.SetListeningForInput
// Size: 0x1(Inherited: 0x0) 
struct FSetListeningForInput
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldListen : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.DisableButtonWithReason
// Size: 0x18(Inherited: 0x0) 
struct FDisableButtonWithReason
{
	struct FText DisabledReason;  // 0x0(0x18)

}; 
// Function CommonUI.CommonTabListWidgetBase.SetTabInteractionEnabled
// Size: 0xC(Inherited: 0x0) 
struct FSetTabInteractionEnabled
{
	struct FName TabNameID;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bEnable : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function CommonUI.CommonButtonGroupBase.GetHoveredButtonIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetHoveredButtonIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonTabListWidgetBase.SetTabVisibility
// Size: 0xC(Inherited: 0x0) 
struct FSetTabVisibility
{
	struct FName TabNameID;  // 0x0(0x8)
	uint8_t  NewVisibility;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function CommonUI.LoadGuardSlot.SetVerticalAlignment
// Size: 0x1(Inherited: 0x0) 
struct FSetVerticalAlignment
{
	char EVerticalAlignment InVerticalAlignment;  // 0x0(0x1)

}; 
// Function CommonUI.CommonLazyWidget.SetLazyContent
// Size: 0x30(Inherited: 0x0) 
struct FSetLazyContent
{
	struct TSoftClassPtr<UObject> SoftWidget;  // 0x0(0x30)

}; 
// ScriptStruct CommonUI.UITag
// Size: 0x8(Inherited: 0x8) 
struct FUITag : public FGameplayTag
{

}; 
// ScriptStruct CommonUI.UIActionTag
// Size: 0x8(Inherited: 0x8) 
struct FUIActionTag : public FUITag
{

}; 
// ScriptStruct CommonUI.CommonInputActionHandlerData
// Size: 0x20(Inherited: 0x0) 
struct FCommonInputActionHandlerData
{
	struct FDataTableRowHandle InputActionRow;  // 0x0(0x10)
	uint8_t  State;  // 0x10(0x1)
	char pad_17[15];  // 0x11(0xF)

}; 
// Function CommonUI.CommonButtonBase.SetIsLocked
// Size: 0x1(Inherited: 0x0) 
struct FSetIsLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsLocked : 1;  // 0x0(0x1)

}; 
// ScriptStruct CommonUI.CommonButtonStyleOptionalSlateSound
// Size: 0x20(Inherited: 0x0) 
struct FCommonButtonStyleOptionalSlateSound
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHasSound : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FSlateSound Sound;  // 0x8(0x18)

}; 
// ScriptStruct CommonUI.RichTextIconData
// Size: 0x60(Inherited: 0x8) 
struct FRichTextIconData : public FTableRowBase
{
	struct FText DisplayName;  // 0x8(0x18)
	struct TSoftObjectPtr<UObject> ResourceObject;  // 0x20(0x30)
	struct FVector2D ImageSize;  // 0x50(0x10)

}; 
// Function CommonUI.CommonButtonBase.SetLockedPressedSoundOverride
// Size: 0x8(Inherited: 0x0) 
struct FSetLockedPressedSoundOverride
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
// ScriptStruct CommonUI.CommonInputTypeInfo
// Size: 0xF0(Inherited: 0x0) 
struct FCommonInputTypeInfo
{
	struct FKey Key;  // 0x0(0x18)
	uint8_t  OverrrideState;  // 0x18(0x1)
	char pad_25_1 : 7;  // 0x19(0x1)
	bool bActionRequiresHold : 1;  // 0x19(0x1)
	char pad_26[2];  // 0x1A(0x2)
	float HoldTime;  // 0x1C(0x4)
	struct FSlateBrush OverrideBrush;  // 0x20(0xD0)

}; 
// ScriptStruct CommonUI.CommonInputActionDataBase
// Size: 0x360(Inherited: 0x8) 
struct FCommonInputActionDataBase : public FTableRowBase
{
	struct FText DisplayName;  // 0x8(0x18)
	struct FText HoldDisplayName;  // 0x20(0x18)
	int32_t NavBarPriority;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FCommonInputTypeInfo KeyboardInputTypeInfo;  // 0x40(0xF0)
	struct FCommonInputTypeInfo DefaultGamepadInputTypeInfo;  // 0x130(0xF0)
	struct TMap<struct FName, struct FCommonInputTypeInfo> GamepadInputOverrides;  // 0x220(0x50)
	struct FCommonInputTypeInfo TouchInputTypeInfo;  // 0x270(0xF0)

}; 
// Function CommonUI.CommonWidgetCarousel.GetWidgetAtIndex
// Size: 0x10(Inherited: 0x0) 
struct FGetWidgetAtIndex
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UWidget* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct CommonUI.UIActionKeyMapping
// Size: 0x20(Inherited: 0x0) 
struct FUIActionKeyMapping
{
	struct FKey Key;  // 0x0(0x18)
	float HoldTime;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)

}; 
// Function CommonUI.CommonRotator.PopulateTextLabels
// Size: 0x10(Inherited: 0x0) 
struct FPopulateTextLabels
{
	struct TArray<struct FText> Labels;  // 0x0(0x10)

}; 
// ScriptStruct CommonUI.UIInputAction
// Size: 0x30(Inherited: 0x0) 
struct FUIInputAction
{
	struct FUIActionTag ActionTag;  // 0x0(0x8)
	struct FText DefaultDisplayName;  // 0x8(0x18)
	struct TArray<struct FUIActionKeyMapping> KeyMappings;  // 0x20(0x10)

}; 
// Function CommonUI.CommonWidgetCarousel.SetActiveWidgetIndex
// Size: 0x4(Inherited: 0x0) 
struct FSetActiveWidgetIndex
{
	int32_t Index;  // 0x0(0x4)

}; 
// ScriptStruct CommonUI.CommonAnalogCursorSettings
// Size: 0x24(Inherited: 0x0) 
struct FCommonAnalogCursorSettings
{
	int32_t PreprocessorPriority;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bEnableCursorAcceleration : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	float CursorAcceleration;  // 0x8(0x4)
	float CursorMaxSpeed;  // 0xC(0x4)
	float CursorDeadZone;  // 0x10(0x4)
	float HoverSlowdownFactor;  // 0x14(0x4)
	float ScrollDeadZone;  // 0x18(0x4)
	float ScrollUpdatePeriod;  // 0x1C(0x4)
	float ScrollMultiplier;  // 0x20(0x4)

}; 
// Function CommonUI.CommonActivatableWidget.BP_GetDesiredFocusTarget
// Size: 0x8(Inherited: 0x0) 
struct FBP_GetDesiredFocusTarget
{
	struct UWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonActivatableWidget.BP_OnHandleBackAction
// Size: 0x1(Inherited: 0x0) 
struct FBP_OnHandleBackAction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonWidgetCarousel.BeginAutoScrolling
// Size: 0x4(Inherited: 0x0) 
struct FBeginAutoScrolling
{
	float ScrollInterval;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonBase.GetCurrentTextStyle
// Size: 0x8(Inherited: 0x0) 
struct FGetCurrentTextStyle
{
	struct UCommonTextStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonActivatableWidget.GetDesiredFocusTarget
// Size: 0x8(Inherited: 0x0) 
struct FGetDesiredFocusTarget
{
	struct UWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonActivatableWidget.IsActivated
// Size: 0x1(Inherited: 0x0) 
struct FIsActivated
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonRotator.BP_OnOptionsPopulated
// Size: 0x4(Inherited: 0x0) 
struct FBP_OnOptionsPopulated
{
	int32_t Count;  // 0x0(0x4)

}; 
// Function CommonUI.CommonAnimatedSwitcher.ActivateNextWidget
// Size: 0x1(Inherited: 0x0) 
struct FActivateNextWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCanWrap : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonAnimatedSwitcher.ActivatePreviousWidget
// Size: 0x1(Inherited: 0x0) 
struct FActivatePreviousWidget
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bCanWrap : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonAnimatedSwitcher.HasWidgets
// Size: 0x1(Inherited: 0x0) 
struct FHasWidgets
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonAnimatedSwitcher.IsCurrentlySwitching
// Size: 0x1(Inherited: 0x0) 
struct FIsCurrentlySwitching
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonAnimatedSwitcher.IsTransitionPlaying
// Size: 0x1(Inherited: 0x0) 
struct FIsTransitionPlaying
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonAnimatedSwitcher.SetDisableTransitionAnimation
// Size: 0x1(Inherited: 0x0) 
struct FSetDisableTransitionAnimation
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bDisableAnimation : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonBorderStyle.GetBackgroundBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetBackgroundBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetButtonPadding
// Size: 0x10(Inherited: 0x0) 
struct FGetButtonPadding
{
	struct FMargin OutButtonPadding;  // 0x0(0x10)

}; 
// Function CommonUI.CommonButtonStyle.GetCustomPadding
// Size: 0x10(Inherited: 0x0) 
struct FGetCustomPadding
{
	struct FMargin OutCustomPadding;  // 0x0(0x10)

}; 
// Function CommonUI.CommonButtonStyle.GetDisabledBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetDisabledBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetMaterialBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetMaterialBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonTextStyle.GetStrikeBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetStrikeBrush
{
	struct FSlateBrush OutStrikeBrush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetNormalBaseBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetNormalBaseBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetNormalHoveredBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetNormalHoveredBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetNormalHoveredTextStyle
// Size: 0x8(Inherited: 0x0) 
struct FGetNormalHoveredTextStyle
{
	struct UCommonTextStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonStyle.GetNormalPressedBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetNormalPressedBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonBase.SetMinDimensions
// Size: 0x8(Inherited: 0x0) 
struct FSetMinDimensions
{
	int32_t InMinWidth;  // 0x0(0x4)
	int32_t InMinHeight;  // 0x4(0x4)

}; 
// Function CommonUI.CommonButtonStyle.GetNormalTextStyle
// Size: 0x8(Inherited: 0x0) 
struct FGetNormalTextStyle
{
	struct UCommonTextStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonStyle.GetSelectedBaseBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetSelectedBaseBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetSelectedHoveredBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetSelectedHoveredBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetSelectedHoveredTextStyle
// Size: 0x8(Inherited: 0x0) 
struct FGetSelectedHoveredTextStyle
{
	struct UCommonTextStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonGroupBase.SelectPreviousButton
// Size: 0x1(Inherited: 0x0) 
struct FSelectPreviousButton
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllowWrap : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonStyle.GetSelectedPressedBrush
// Size: 0xD0(Inherited: 0x0) 
struct FGetSelectedPressedBrush
{
	struct FSlateBrush Brush;  // 0x0(0xD0)

}; 
// Function CommonUI.CommonButtonStyle.GetSelectedTextStyle
// Size: 0x8(Inherited: 0x0) 
struct FGetSelectedTextStyle
{
	struct UCommonTextStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.BP_OnInputMethodChanged
// Size: 0x1(Inherited: 0x0) 
struct FBP_OnInputMethodChanged
{
	uint8_t  CurrentInputType;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.GetIsFocusable
// Size: 0x1(Inherited: 0x0) 
struct FGetIsFocusable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.BP_OnLockedChanged
// Size: 0x1(Inherited: 0x0) 
struct FBP_OnLockedChanged
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsLocked : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonRotator.BP_OnOptionSelected
// Size: 0x4(Inherited: 0x0) 
struct FBP_OnOptionSelected
{
	int32_t Index;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonBase.GetLocked
// Size: 0x1(Inherited: 0x0) 
struct FGetLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.GetCurrentButtonPadding
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentButtonPadding
{
	struct FMargin OutButtonPadding;  // 0x0(0x10)

}; 
// Function CommonUI.CommonButtonBase.GetCurrentCustomPadding
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentCustomPadding
{
	struct FMargin OutCustomPadding;  // 0x0(0x10)

}; 
// Function CommonUI.CommonButtonBase.GetCurrentTextStyleClass
// Size: 0x8(Inherited: 0x0) 
struct FGetCurrentTextStyleClass
{
	UCommonTextStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.GetInputAction
// Size: 0x18(Inherited: 0x0) 
struct FGetInputAction
{
	struct FDataTableRowHandle InputActionRow;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function CommonUI.CommonWidgetCarousel.GetActiveWidgetIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetActiveWidgetIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonBase.GetSingleMaterialStyleMID
// Size: 0x8(Inherited: 0x0) 
struct FGetSingleMaterialStyleMID
{
	struct UMaterialInstanceDynamic* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.GetStyle
// Size: 0x8(Inherited: 0x0) 
struct FGetStyle
{
	struct UCommonButtonStyle* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.HandleTriggeringActionCommited
// Size: 0x1(Inherited: 0x0) 
struct FHandleTriggeringActionCommited
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPassThrough : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.IsPressed
// Size: 0x1(Inherited: 0x0) 
struct FIsPressed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.NativeOnActionProgress
// Size: 0x4(Inherited: 0x0) 
struct FNativeOnActionProgress
{
	float HeldPercent;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonBase.OnActionProgress
// Size: 0x4(Inherited: 0x0) 
struct FOnActionProgress
{
	float HeldPercent;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonBase.OnInputMethodChanged
// Size: 0x1(Inherited: 0x0) 
struct FOnInputMethodChanged
{
	uint8_t  CurrentInputType;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.OnTriggeredInputActionChanged
// Size: 0x10(Inherited: 0x0) 
struct FOnTriggeredInputActionChanged
{
	struct FDataTableRowHandle NewTriggeredAction;  // 0x0(0x10)

}; 
// Function CommonUI.CommonButtonBase.OnTriggeringInputActionChanged
// Size: 0x10(Inherited: 0x0) 
struct FOnTriggeringInputActionChanged
{
	struct FDataTableRowHandle NewTriggeredAction;  // 0x0(0x10)

}; 
// Function CommonUI.CommonButtonGroupBase.OnButtonBaseHovered
// Size: 0x8(Inherited: 0x0) 
struct FOnButtonBaseHovered
{
	struct UCommonButtonBase* BaseButton;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetClickMethod
// Size: 0x1(Inherited: 0x0) 
struct FSetClickMethod
{
	char EButtonClickMethod InClickMethod;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetHideInputAction
// Size: 0x1(Inherited: 0x0) 
struct FSetHideInputAction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInHideInputAction : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetHoveredSoundOverride
// Size: 0x8(Inherited: 0x0) 
struct FSetHoveredSoundOverride
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetInputActionProgressMaterial
// Size: 0xE0(Inherited: 0x0) 
struct FSetInputActionProgressMaterial
{
	struct FSlateBrush InProgressMaterialBrush;  // 0x0(0xD0)
	struct FName InProgressMaterialParam;  // 0xD0(0x8)
	char pad_216[8];  // 0xD8(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetIsFocusable
// Size: 0x1(Inherited: 0x0) 
struct FSetIsFocusable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsFocusable : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetIsInteractableWhenSelected
// Size: 0x1(Inherited: 0x0) 
struct FSetIsInteractableWhenSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInInteractableWhenSelected : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonGroupBase.GetSelectedButtonBase
// Size: 0x8(Inherited: 0x0) 
struct FGetSelectedButtonBase
{
	struct UCommonButtonBase* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetIsSelectable
// Size: 0x1(Inherited: 0x0) 
struct FSetIsSelectable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsSelectable : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetIsSelected
// Size: 0x2(Inherited: 0x0) 
struct FSetIsSelected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool InSelected : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bGiveClickFeedback : 1;  // 0x1(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetIsToggleable
// Size: 0x1(Inherited: 0x0) 
struct FSetIsToggleable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInIsToggleable : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetLockedHoveredSoundOverride
// Size: 0x8(Inherited: 0x0) 
struct FSetLockedHoveredSoundOverride
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetPressedSoundOverride
// Size: 0x8(Inherited: 0x0) 
struct FSetPressedSoundOverride
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetPressMethod
// Size: 0x1(Inherited: 0x0) 
struct FSetPressMethod
{
	char EButtonPressMethod InPressMethod;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetSelectedHoveredSoundOverride
// Size: 0x8(Inherited: 0x0) 
struct FSetSelectedHoveredSoundOverride
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetSelectedInternal
// Size: 0x3(Inherited: 0x0) 
struct FSetSelectedInternal
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInSelected : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool bAllowSound : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool bBroadcast : 1;  // 0x2(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetSelectedPressedSoundOverride
// Size: 0x8(Inherited: 0x0) 
struct FSetSelectedPressedSoundOverride
{
	struct USoundBase* Sound;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonBase.SetShouldUseFallbackDefaultInputAction
// Size: 0x1(Inherited: 0x0) 
struct FSetShouldUseFallbackDefaultInputAction
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInShouldUseFallbackDefaultInputAction : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetTouchMethod
// Size: 0x1(Inherited: 0x0) 
struct FSetTouchMethod
{
	char EButtonTouchMethod InTouchMethod;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonBase.SetTriggeredInputAction
// Size: 0x10(Inherited: 0x0) 
struct FSetTriggeredInputAction
{
	struct FDataTableRowHandle InputActionRow;  // 0x0(0x10)

}; 
// Function CommonUI.CommonButtonBase.SetTriggeringInputAction
// Size: 0x10(Inherited: 0x0) 
struct FSetTriggeringInputAction
{
	struct FDataTableRowHandle InputActionRow;  // 0x0(0x10)

}; 
// Function CommonUI.CommonDateTimeTextBlock.SetCountDownCompletionText
// Size: 0x18(Inherited: 0x0) 
struct FSetCountDownCompletionText
{
	struct FText InCompletionText;  // 0x0(0x18)

}; 
// Function CommonUI.CommonDateTimeTextBlock.SetTimespanValue
// Size: 0x8(Inherited: 0x0) 
struct FSetTimespanValue
{
	struct FTimespan InTimespan;  // 0x0(0x8)

}; 
// Function CommonUI.CommonLazyImage.SetBrushFromLazyDisplayAsset
// Size: 0x38(Inherited: 0x0) 
struct FSetBrushFromLazyDisplayAsset
{
	struct TSoftObjectPtr<UObject> LazyObject;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bMatchTextureSize : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function CommonUI.CommonLazyImage.SetBrushFromLazyMaterial
// Size: 0x30(Inherited: 0x0) 
struct FSetBrushFromLazyMaterial
{
	struct TSoftObjectPtr<UMaterialInterface> LazyMaterial;  // 0x0(0x30)

}; 
// Function CommonUI.CommonButtonGroupBase.GetSelectedButtonIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetSelectedButtonIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonLazyImage.SetBrushFromLazyTexture
// Size: 0x38(Inherited: 0x0) 
struct FSetBrushFromLazyTexture
{
	struct TSoftObjectPtr<UTexture2D> LazyTexture;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bMatchSize : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function CommonUI.CommonLazyImage.SetMaterialTextureParamName
// Size: 0x8(Inherited: 0x0) 
struct FSetMaterialTextureParamName
{
	struct FName TextureParamName;  // 0x0(0x8)

}; 
// Function CommonUI.CommonLazyWidget.GetContent
// Size: 0x8(Inherited: 0x0) 
struct FGetContent
{
	struct UUserWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonListView.SetEntrySpacing
// Size: 0x4(Inherited: 0x0) 
struct FSetEntrySpacing
{
	float InEntrySpacing;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseClicked
// Size: 0x8(Inherited: 0x0) 
struct FOnHandleButtonBaseClicked
{
	struct UCommonButtonBase* BaseButton;  // 0x0(0x8)

}; 
// Function CommonUI.CommonTextStyle.GetShadowOffset
// Size: 0x10(Inherited: 0x0) 
struct FGetShadowOffset
{
	struct FVector2D OutShadowOffset;  // 0x0(0x10)

}; 
// Function CommonUI.LoadGuardSlot.SetHorizontalAlignment
// Size: 0x1(Inherited: 0x0) 
struct FSetHorizontalAlignment
{
	char EHorizontalAlignment InHorizontalAlignment;  // 0x0(0x1)

}; 
// Function CommonUI.LoadGuardSlot.SetPadding
// Size: 0x10(Inherited: 0x0) 
struct FSetPadding
{
	struct FMargin InPadding;  // 0x0(0x10)

}; 
// Function CommonUI.CommonRotator.GetSelectedIndex
// Size: 0x4(Inherited: 0x0) 
struct FGetSelectedIndex
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonRotator.GetSelectedText
// Size: 0x18(Inherited: 0x0) 
struct FGetSelectedText
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function CommonUI.CommonRotator.SetSelectedItem
// Size: 0x4(Inherited: 0x0) 
struct FSetSelectedItem
{
	int32_t InValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonTextStyle.GetColor
// Size: 0x10(Inherited: 0x0) 
struct FGetColor
{
	struct FLinearColor OutColor;  // 0x0(0x10)

}; 
// Function CommonUI.CommonTextStyle.GetLineHeightPercentage
// Size: 0x4(Inherited: 0x0) 
struct FGetLineHeightPercentage
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonTextStyle.GetShadowColor
// Size: 0x10(Inherited: 0x0) 
struct FGetShadowColor
{
	struct FLinearColor OutColor;  // 0x0(0x10)

}; 
// Function CommonUI.CommonUILibrary.FindParentWidgetOfType
// Size: 0x18(Inherited: 0x0) 
struct FFindParentWidgetOfType
{
	struct UWidget* StartingWidget;  // 0x0(0x8)
	UWidget* Type;  // 0x8(0x8)
	struct UWidget* ReturnValue;  // 0x10(0x8)

}; 
// Function CommonUI.CommonUISubsystemBase.GetInputActionButtonIcon
// Size: 0xF0(Inherited: 0x0) 
struct FGetInputActionButtonIcon
{
	struct FDataTableRowHandle InputActionRowHandle;  // 0x0(0x10)
	uint8_t  InputType;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FName GamepadName;  // 0x14(0x8)
	char pad_28[4];  // 0x1C(0x4)
	struct FSlateBrush ReturnValue;  // 0x20(0xD0)

}; 
// Function CommonUI.CommonVisibilitySwitcher.DecrementActiveWidgetIndex
// Size: 0x1(Inherited: 0x0) 
struct FDecrementActiveWidgetIndex
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllowWrapping : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonActivatableWidgetContainerBase.GetActiveWidget
// Size: 0x8(Inherited: 0x0) 
struct FGetActiveWidget
{
	struct UCommonActivatableWidget* ReturnValue;  // 0x0(0x8)

}; 
// Function CommonUI.CommonVisibilitySwitcher.IncrementActiveWidgetIndex
// Size: 0x1(Inherited: 0x0) 
struct FIncrementActiveWidgetIndex
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllowWrapping : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonWidgetCarousel.SetActiveWidget
// Size: 0x8(Inherited: 0x0) 
struct FSetActiveWidget
{
	struct UWidget* Widget;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonGroupBase.OnSelectionStateChangedBase
// Size: 0x10(Inherited: 0x0) 
struct FOnSelectionStateChangedBase
{
	struct UCommonButtonBase* BaseButton;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bIsSelected : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function CommonUI.CommonWidgetCarouselNavBar.HandleButtonClicked
// Size: 0x10(Inherited: 0x0) 
struct FHandleButtonClicked
{
	struct UCommonButtonBase* AssociatedButton;  // 0x0(0x8)
	int32_t ButtonIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function CommonUI.CommonWidgetCarouselNavBar.HandlePageChanged
// Size: 0x10(Inherited: 0x0) 
struct FHandlePageChanged
{
	struct UCommonWidgetCarousel* CommonCarousel;  // 0x0(0x8)
	int32_t PageIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function CommonUI.CommonWidgetCarouselNavBar.SetLinkedCarousel
// Size: 0x8(Inherited: 0x0) 
struct FSetLinkedCarousel
{
	struct UCommonWidgetCarousel* CommonCarousel;  // 0x0(0x8)

}; 
// Function CommonUI.CommonActivatableWidgetContainerBase.RemoveWidget
// Size: 0x8(Inherited: 0x0) 
struct FRemoveWidget
{
	struct UCommonActivatableWidget* WidgetToRemove;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonGroupBase.FindButtonIndex
// Size: 0x10(Inherited: 0x0) 
struct FFindButtonIndex
{
	struct UCommonButtonBase* ButtonToFind;  // 0x0(0x8)
	int32_t ReturnValue;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)

}; 
// Function CommonUI.CommonButtonGroupBase.GetButtonBaseAtIndex
// Size: 0x10(Inherited: 0x0) 
struct FGetButtonBaseAtIndex
{
	int32_t Index;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct UCommonButtonBase* ReturnValue;  // 0x8(0x8)

}; 
// Function CommonUI.CommonButtonGroupBase.GetButtonCount
// Size: 0x4(Inherited: 0x0) 
struct FGetButtonCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonButtonGroupBase.HasAnyButtons
// Size: 0x1(Inherited: 0x0) 
struct FHasAnyButtons
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonGroupBase.OnButtonBaseUnhovered
// Size: 0x8(Inherited: 0x0) 
struct FOnButtonBaseUnhovered
{
	struct UCommonButtonBase* BaseButton;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonGroupBase.OnHandleButtonBaseDoubleClicked
// Size: 0x8(Inherited: 0x0) 
struct FOnHandleButtonBaseDoubleClicked
{
	struct UCommonButtonBase* BaseButton;  // 0x0(0x8)

}; 
// Function CommonUI.CommonButtonGroupBase.SelectButtonAtIndex
// Size: 0x8(Inherited: 0x0) 
struct FSelectButtonAtIndex
{
	int32_t ButtonIndex;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bAllowSound : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function CommonUI.CommonButtonGroupBase.SelectNextButton
// Size: 0x1(Inherited: 0x0) 
struct FSelectNextButton
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bAllowWrap : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonButtonGroupBase.SetSelectionRequired
// Size: 0x1(Inherited: 0x0) 
struct FSetSelectionRequired
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bRequireSelection : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonBoundActionBar.SetDisplayOwningPlayerActionsOnly
// Size: 0x1(Inherited: 0x0) 
struct FSetDisplayOwningPlayerActionsOnly
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bShouldOnlyDisplayOwningPlayerActions : 1;  // 0x0(0x1)

}; 
// Function CommonUI.CommonActivatableWidgetContainerBase.BP_AddWidget
// Size: 0x10(Inherited: 0x0) 
struct FBP_AddWidget
{
	UCommonActivatableWidget* ActivatableWidgetClass;  // 0x0(0x8)
	struct UCommonActivatableWidget* ReturnValue;  // 0x8(0x8)

}; 
// Function CommonUI.CommonActivatableWidgetContainerBase.GetTransitionDuration
// Size: 0x4(Inherited: 0x0) 
struct FGetTransitionDuration
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function CommonUI.CommonActivatableWidgetContainerBase.SetTransitionDuration
// Size: 0x4(Inherited: 0x0) 
struct FSetTransitionDuration
{
	float Duration;  // 0x0(0x4)

}; 
