#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Hotfix.UpdateContextDefinition
// Size: 0x68(Inherited: 0x0) 
struct FUpdateContextDefinition
{
	struct FString Name;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bEnabled : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bCheckAvailabilityOnly : 1;  // 0x11(0x1)
	char pad_18_1 : 7;  // 0x12(0x1)
	bool bPatchCheckEnabled : 1;  // 0x12(0x1)
	char pad_19_1 : 7;  // 0x13(0x1)
	bool bPlatformEnvironmentDetectionEnabled : 1;  // 0x13(0x1)
	char pad_20[4];  // 0x14(0x4)
	struct TSet<struct FString> AdditionalTags;  // 0x18(0x50)

}; 
