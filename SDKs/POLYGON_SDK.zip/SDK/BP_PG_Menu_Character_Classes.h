#pragma once 
#include <BP_PG_Menu_Character_Structs.h>
 
 
 
// BlueprintGeneratedClass BP_PG_Menu_Character.BP_PG_Menu_Character_C
// Size: 0x3B8(Inherited: 0x2B8) 
struct ABP_PG_Menu_Character_C : public APG_Menu_Character
{
	struct FPointerToUberGraphFrame UberGraphFrame;  // 0x2B8(0x8)
	struct UStaticMeshComponent* SM_Chr_Attach_Patch_Squad_03;  // 0x2C0(0x8)
	struct UStaticMeshComponent* SM_Item_Crowbar_01;  // 0x2C8(0x8)
	struct UStaticMeshComponent* SM_Item_Pencil_01;  // 0x2D0(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_03;  // 0x2D8(0x8)
	struct UStaticMeshComponent* Equipment_PouchB_01;  // 0x2E0(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_01;  // 0x2E8(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_02;  // 0x2F0(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_04;  // 0x2F8(0x8)
	struct UStaticMeshComponent* Equipment_Belt;  // 0x300(0x8)
	struct UStaticMeshComponent* Equipment_Glowstick_03;  // 0x308(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_03;  // 0x310(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_02;  // 0x318(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_01;  // 0x320(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_04;  // 0x328(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_03;  // 0x330(0x8)
	struct UStaticMeshComponent* Equipment_TactFlashlight_01;  // 0x338(0x8)
	struct UStaticMeshComponent* Equipment_Scissors_01;  // 0x340(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_06;  // 0x348(0x8)
	struct UStaticMeshComponent* Equipment_Radio_01;  // 0x350(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_02;  // 0x358(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Grenade_01;  // 0x360(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_05;  // 0x368(0x8)
	struct UStaticMeshComponent* Equipment_Grenade_Flash_01;  // 0x370(0x8)
	struct UStaticMeshComponent* Equipment_Grenade_Smoke_01;  // 0x378(0x8)
	struct UStaticMeshComponent* Equipment_Pouch_Mag_04;  // 0x380(0x8)
	struct UStaticMeshComponent* Equipment_Glowstick_01;  // 0x388(0x8)
	struct UStaticMeshComponent* Equipment_Glowstick_02;  // 0x390(0x8)
	struct UStaticMeshComponent* Equipment_PouchM_07;  // 0x398(0x8)
	struct UStaticMeshComponent* Equipment_Radio_02;  // 0x3A0(0x8)
	struct UStaticMeshComponent* Holster_mesh;  // 0x3A8(0x8)
	struct UDataContainerAsset* NewVar_1;  // 0x3B0(0x8)

	void ReceiveBeginPlay(); // Function BP_PG_Menu_Character.BP_PG_Menu_Character_C.ReceiveBeginPlay
	void ExecuteUbergraph_BP_PG_Menu_Character(int32_t EntryPoint); // Function BP_PG_Menu_Character.BP_PG_Menu_Character_C.ExecuteUbergraph_BP_PG_Menu_Character
}; 



