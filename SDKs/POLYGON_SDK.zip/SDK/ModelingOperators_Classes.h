#pragma once 
#include <ModelingOperators_Structs.h>
 
 
 
// Class ModelingOperators.RecomputeUVsToolProperties
// Size: 0xD8(Inherited: 0xA8) 
struct URecomputeUVsToolProperties : public UInteractiveToolPropertySet
{
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bEnablePolygroupSupport : 1;  // 0xA8(0x1)
	char pad_169[3];  // 0xA9(0x3)
	uint8_t  IslandGeneration;  // 0xAC(0x4)
	uint8_t  UnwrapType;  // 0xB0(0x4)
	uint8_t  AutoRotation;  // 0xB4(0x4)
	char pad_184_1 : 7;  // 0xB8(0x1)
	bool bPreserveIrregularity : 1;  // 0xB8(0x1)
	char pad_185[3];  // 0xB9(0x3)
	int32_t SmoothingSteps;  // 0xBC(0x4)
	float SmoothingAlpha;  // 0xC0(0x4)
	float MergingDistortionThreshold;  // 0xC4(0x4)
	float MergingAngleThreshold;  // 0xC8(0x4)
	uint8_t  LayoutType;  // 0xCC(0x4)
	int32_t TextureResolution;  // 0xD0(0x4)
	float NormalizeScale;  // 0xD4(0x4)

}; 



// Class ModelingOperators.UVLayoutProperties
// Size: 0xD0(Inherited: 0xA8) 
struct UUVLayoutProperties : public UInteractiveToolPropertySet
{
	uint8_t  LayoutType;  // 0xA8(0x4)
	int32_t TextureResolution;  // 0xAC(0x4)
	float Scale;  // 0xB0(0x4)
	char pad_180[4];  // 0xB4(0x4)
	struct FVector2D Translation;  // 0xB8(0x10)
	char pad_200_1 : 7;  // 0xC8(0x1)
	bool bAllowFlips : 1;  // 0xC8(0x1)
	char pad_201[7];  // 0xC9(0x7)

}; 



// Class ModelingOperators.RecomputeUVsOpFactory
// Size: 0xF0(Inherited: 0x28) 
struct URecomputeUVsOpFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct URecomputeUVsToolProperties* Settings;  // 0x30(0x8)
	char pad_56[184];  // 0x38(0xB8)

}; 



// Class ModelingOperators.UVLayoutOperatorFactory
// Size: 0xF0(Inherited: 0x28) 
struct UUVLayoutOperatorFactory : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UUVLayoutProperties* Settings;  // 0x30(0x8)
	char pad_56[184];  // 0x38(0xB8)

}; 



