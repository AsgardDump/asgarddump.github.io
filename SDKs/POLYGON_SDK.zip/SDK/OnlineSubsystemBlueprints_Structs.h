#pragma once 
#include "SDK.h" 
 
 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomJoinPublic_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FChat_ChatRoomJoinPublic_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Param3 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString Param4;  // 0x48(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineErrorInfo
// Size: 0x40(Inherited: 0x0) 
struct FOnlineErrorInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Successful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ErrorRaw;  // 0x8(0x10)
	struct FString ErrorCode;  // 0x18(0x10)
	struct FText ErrorMessage;  // 0x28(0x18)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemCreatePartyCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlinePartySubsystemCreatePartyCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	uint8_t  Result;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetTransmitMode
// Size: 0x1(Inherited: 0x0) 
struct FGetTransmitMode
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetConsumedCount
// Size: 0x4(Inherited: 0x0) 
struct FGetConsumedCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.GameActivity_GameActivityActivationRequested_BP__DelegateSignature
// Size: 0x1F0(Inherited: 0x0) 
struct FGameActivity_GameActivityActivationRequested_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FString ActivityId;  // 0x30(0x10)
	struct FOptionalOnlineSessionSearchResultBP SessionInfo;  // 0x40(0x1B0)

}; 
// DelegateFunction OnlineSubsystemBlueprints.ExternalUI_ExternalUIChange_BP__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FExternalUI_ExternalUIChange_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Param1 : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemUpdateParty.UpdateParty
// Size: 0x90(Inherited: 0x0) 
struct FUpdateParty
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UPartyId* PartyId;  // 0x38(0x8)
	struct FOnlinePartyConfiguration PartyConfig;  // 0x40(0x40)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bShouldRegenerateReservationKey : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)
	struct UOnlinePartySubsystemUpdateParty* ReturnValue;  // 0x88(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Achievements_AchievementUnlocked_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FAchievements_AchievementUnlocked_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetStatus
// Size: 0x10(Inherited: 0x0) 
struct FGetStatus
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomExit_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FChat_ChatRoomExit_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Param3 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString Param4;  // 0x48(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemPromoteMember.PromoteMember
// Size: 0x78(Inherited: 0x0) 
struct FPromoteMember
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UPartyId* PartyId;  // 0x38(0x8)
	struct FUniqueNetIdRepl TargetMemberId;  // 0x40(0x30)
	struct UOnlinePartySubsystemPromoteMember* ReturnValue;  // 0x70(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Identity_LoginStatusChanged_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FIdentity_LoginStatusChanged_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	uint8_t  OldStatus;  // 0x4(0x1)
	uint8_t  NewStatus;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	struct FUniqueNetIdRepl NewId;  // 0x8(0x30)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineSessionSettingsBP
// Size: 0x140(Inherited: 0x0) 
struct FOnlineSessionSettingsBP
{
	char pad_0[216];  // 0x0(0xD8)
	int32_t NumPublicConnections;  // 0xD8(0x4)
	int32_t NumPrivateConnections;  // 0xDC(0x4)
	char pad_224_1 : 7;  // 0xE0(0x1)
	bool bShouldAdvertise : 1;  // 0xE0(0x1)
	char pad_225_1 : 7;  // 0xE1(0x1)
	bool bAllowJoinInProgress : 1;  // 0xE1(0x1)
	char pad_226_1 : 7;  // 0xE2(0x1)
	bool bIsLANMatch : 1;  // 0xE2(0x1)
	char pad_227_1 : 7;  // 0xE3(0x1)
	bool bIsDedicated : 1;  // 0xE3(0x1)
	char pad_228_1 : 7;  // 0xE4(0x1)
	bool bUsesStats : 1;  // 0xE4(0x1)
	char pad_229_1 : 7;  // 0xE5(0x1)
	bool bAllowInvites : 1;  // 0xE5(0x1)
	char pad_230_1 : 7;  // 0xE6(0x1)
	bool bUsesPresence : 1;  // 0xE6(0x1)
	char pad_231_1 : 7;  // 0xE7(0x1)
	bool bAllowJoinViaPresence : 1;  // 0xE7(0x1)
	char pad_232_1 : 7;  // 0xE8(0x1)
	bool bAllowJoinViaPresenceFriendsOnly : 1;  // 0xE8(0x1)
	char pad_233_1 : 7;  // 0xE9(0x1)
	bool bAntiCheatProtected : 1;  // 0xE9(0x1)
	char pad_234_1 : 7;  // 0xEA(0x1)
	bool bUseLobbiesIfAvailable : 1;  // 0xEA(0x1)
	char pad_235_1 : 7;  // 0xEB(0x1)
	bool bUseLobbiesVoiceChatIfAvailable : 1;  // 0xEB(0x1)
	int32_t BuildUniqueId;  // 0xEC(0x4)
	struct TMap<struct FName, struct FOnlineSessionSettingBP> Settings;  // 0xF0(0x50)

}; 
// ScriptStruct OnlineSubsystemBlueprints.VoiceAdminChannelCredentialsBP
// Size: 0x50(Inherited: 0x0) 
struct FVoiceAdminChannelCredentialsBP
{
	struct FUniqueNetIdRepl TargetUserId;  // 0x0(0x30)
	struct FString PlayerName;  // 0x30(0x10)
	struct FString ChannelCredentials;  // 0x40(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemEndSessionCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemEndSessionCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomConfigured_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FChat_ChatRoomConfigured_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Param3 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString Param4;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomMemberJoin_BP__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FChat_ChatRoomMemberJoin_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	struct FUniqueNetIdRepl Param3;  // 0x40(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterLocalPlayer.UnregisterLocalPlayer
// Size: 0x48(Inherited: 0x0) 
struct FUnregisterLocalPlayer
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl PlayerId;  // 0x8(0x30)
	struct FName SessionName;  // 0x38(0x8)
	struct UOnlineSessionSubsystemUnregisterLocalPlayer* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineAchievementsSubsystemWriteAchievementsCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlineAchievementsSubsystemWriteAchievementsCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Param2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemJoinSession.JoinSession
// Size: 0x1F0(Inherited: 0x0) 
struct FJoinSession
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FName SessionName;  // 0x38(0x8)
	struct FOnlineSessionSearchResultBP DesiredSession;  // 0x40(0x1A8)
	struct UOnlineSessionSubsystemJoinSession* ReturnValue;  // 0x1E8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomMemberExit_BP__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FChat_ChatRoomMemberExit_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	struct FUniqueNetIdRepl Param3;  // 0x40(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowPlatformMessageBox
// Size: 0x38(Inherited: 0x0) 
struct FShowPlatformMessageBox
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	uint8_t  MessageType;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool ReturnValue : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemUpdateSessionCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemUpdateSessionCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomCreated_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FChat_ChatRoomCreated_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Param3 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString Param4;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineIdentitySubsystemRevokeAuthTokenCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineIdentitySubsystemRevokeAuthTokenCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FOnlineErrorInfo OnlineError;  // 0x30(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.ApproveJoinRequest
// Size: 0x78(Inherited: 0x0) 
struct FApproveJoinRequest
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl RecipientId;  // 0x38(0x30)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bIsApproved : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t DeniedResultCode;  // 0x6C(0x4)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageToUserUICallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineExternalUISubsystemShowSendMessageToUserUICallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bMessageSent : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetNumericPrice
// Size: 0x8(Inherited: 0x0) 
struct FGetNumericPrice
{
	int64_t ReturnValue;  // 0x0(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Lobby_MemberUpdate_BP__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FLobby_MemberUpdate_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemBlockPlayer.BlockPlayer
// Size: 0x48(Inherited: 0x0) 
struct FBlockPlayer
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl PlayerId;  // 0x10(0x30)
	struct UOnlineFriendsSubsystemBlockPlayer* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemDeleteUserFile.DeleteUserFile
// Size: 0x58(Inherited: 0x0) 
struct FDeleteUserFile
{
	struct UOnlineUserCloudSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bShouldCloudDelete : 1;  // 0x48(0x1)
	char pad_73_1 : 7;  // 0x49(0x1)
	bool bShouldLocallyDelete : 1;  // 0x49(0x1)
	char pad_74[6];  // 0x4A(0x6)
	struct UOnlineUserCloudSubsystemDeleteUserFile* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Identity_LoginChanged_BP__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FIdentity_LoginChanged_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemAutoLogin.AutoLogin
// Size: 0x18(Inherited: 0x0) 
struct FAutoLogin
{
	struct UOnlineIdentitySubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UOnlineIdentitySubsystemAutoLogin* ReturnValue;  // 0x10(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineLobbySearchQueryBP
// Size: 0x20(Inherited: 0x0) 
struct FOnlineLobbySearchQueryBP
{
	struct TArray<struct FOnlineLobbySearchQueryFilterBP> Filters;  // 0x0(0x10)
	int64_t Limit;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool HasLimit : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatarCallbackPin__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnlineAvatarSubsystemGetAvatarCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct UTexture* ResultTexture;  // 0x8(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlinePartyConfiguration
// Size: 0x40(Inherited: 0x0) 
struct FOnlinePartyConfiguration
{
	uint8_t  JoinRequestAction;  // 0x0(0x1)
	uint8_t  PresencePermissions;  // 0x1(0x1)
	uint8_t  InvitePermissions;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool ChatEnabled : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ShouldRemoveOnDisconnection : 1;  // 0x4(0x1)
	char pad_5_1 : 7;  // 0x5(0x1)
	bool IsAcceptingMembers : 1;  // 0x5(0x1)
	char pad_6[2];  // 0x6(0x2)
	int32_t NotAcceptingMembersReason;  // 0x8(0x4)
	int32_t MaxMembers;  // 0xC(0x4)
	struct FString Nickname;  // 0x10(0x10)
	struct FString Description;  // 0x20(0x10)
	struct FString Password;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserInfo.QueryUserInfo
// Size: 0x28(Inherited: 0x0) 
struct FQueryUserInfo
{
	struct UOnlineUserSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct TArray<struct FUniqueNetIdRepl> UserIds;  // 0x10(0x10)
	struct UOnlineUserSubsystemQueryUserInfo* ReturnValue;  // 0x20(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomJoinPrivate_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FChat_ChatRoomJoinPrivate_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool Param3 : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString Param4;  // 0x48(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.GetResolvedConnectStringByName
// Size: 0x30(Inherited: 0x0) 
struct FGetResolvedConnectStringByName
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FName SessionName;  // 0x8(0x8)
	struct FName PortType;  // 0x10(0x8)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bWasSuccessful : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)
	struct FString OutConnectInfo;  // 0x20(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundRank.ReadLeaderboardsAroundRank
// Size: 0x28(Inherited: 0x0) 
struct FReadLeaderboardsAroundRank
{
	struct UOnlineLeaderboardsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t Rank;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	int64_t Range;  // 0x10(0x8)
	struct UOnlineLeaderboardRead* ReadObject;  // 0x18(0x8)
	struct UOnlineLeaderboardsSubsystemReadLeaderboardsAroundRank* ReturnValue;  // 0x20(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Identity_LoginComplete_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FIdentity_LoginComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Error;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Chat_ChatRoomMemberUpdate_BP__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FChat_ChatRoomMemberUpdate_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	struct FString Param2;  // 0x30(0x10)
	struct FUniqueNetIdRepl Param3;  // 0x40(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetNamespace
// Size: 0x10(Inherited: 0x0) 
struct FGetNamespace
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemPromoteMemberCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlinePartySubsystemPromoteMemberCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	uint8_t  Result;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUserLogoutCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FVoiceChatUserLogoutCallbackPin__DelegateSignature
{
	struct FString PlayerName;  // 0x0(0x10)
	struct FVoiceChatResultBP Result;  // 0x10(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.RequestUsageInfo
// Size: 0x38(Inherited: 0x0) 
struct FRequestUsageInfo
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowStoreUICallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineExternalUISubsystemShowStoreUICallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bPurchased : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Entitlements_QueryEntitlementsComplete_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FEntitlements_QueryEntitlementsComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Namespace;  // 0x38(0x10)
	struct FString Error;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_BlockedPlayerComplete_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FFriends_BlockedPlayerComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FUniqueNetIdRepl UniqueId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.IsValid_LobbyId
// Size: 0x10(Inherited: 0x0) 
struct FIsValid_LobbyId
{
	struct ULobbyId* A;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMember
// Size: 0x70(Inherited: 0x0) 
struct FGetPartyMember
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	struct UBlueprintPartyMember* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_BlockListChange_BP__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FFriends_BlockListChange_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ListName;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedSharingSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedSharingSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineSharingSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_InviteAccepted_BP__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FFriends_InviteAccepted_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl FriendId;  // 0x30(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetMemberUserId
// Size: 0x78(Inherited: 0x0) 
struct FGetMemberUserId
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	int32_t MemberIndex;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FUniqueNetIdRepl OutMemberId;  // 0x40(0x30)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineSharedCloudSubsystem.WriteSharedFile
// Size: 0x50(Inherited: 0x0) 
struct FWriteSharedFile
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Filename;  // 0x30(0x10)
	struct UFileData* Contents;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemCreateParty.CreateParty
// Size: 0x88(Inherited: 0x0) 
struct FCreateParty
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	int64_t PartyTypeId;  // 0x38(0x8)
	struct FOnlinePartyConfiguration PartyConfig;  // 0x40(0x40)
	struct UOnlinePartySubsystemCreateParty* ReturnValue;  // 0x80(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_DeleteFriendComplete_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FFriends_DeleteFriendComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.TitleFile_ReadFileComplete_BP__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FTitleFile_ReadFileComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Filename;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_FriendRemoved_BP__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FFriends_FriendRemoved_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl FriendId;  // 0x30(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Lobby_MemberDisconnect_BP__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FLobby_MemberDisconnect_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bWasKicked : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineFriendSettingsSourceDataConfig
// Size: 0x1(Inherited: 0x0) 
struct FOnlineFriendSettingsSourceDataConfig
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool NeverShowAgain : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_FriendsChange_BP__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FFriends_FriendsChange_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioOutputVolume
// Size: 0x4(Inherited: 0x0) 
struct FGetAudioOutputVolume
{
	float ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_QueryBlockedPlayersComplete_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FFriends_QueryBlockedPlayersComplete_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString Error;  // 0x38(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.RespondToQueryJoinability
// Size: 0x78(Inherited: 0x0) 
struct FRespondToQueryJoinability
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl RecipientId;  // 0x38(0x30)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool bCanJoin : 1;  // 0x68(0x1)
	char pad_105[3];  // 0x69(0x3)
	int32_t DeniedResultCode;  // 0x6C(0x4)
	struct UReadablePartyData* PartyData;  // 0x70(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowLoginUICallbackPin__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnlineExternalUISubsystemShowLoginUICallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UniqueId;  // 0x0(0x30)
	int32_t ControllerIndex;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)
	struct FOnlineErrorInfo Error;  // 0x38(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Message_SendMessageComplete_BP__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FMessage_SendMessageComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Param1 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString Param2;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.UserCloud_WriteUserFileCanceled_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FUserCloud_WriteUserFileCanceled_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_FriendSettingsUpdated_BP__DelegateSignature
// Size: 0x98(Inherited: 0x0) 
struct FFriends_FriendSettingsUpdated_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bWasUpdate : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct FFriendSettingsData Settings;  // 0x38(0x50)
	struct FString ErrorStr;  // 0x88(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.PagedQueryBP
// Size: 0x8(Inherited: 0x0) 
struct FPagedQueryBP
{
	int32_t Start;  // 0x0(0x4)
	int32_t Count;  // 0x4(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsHeadsetPresent
// Size: 0x10(Inherited: 0x0) 
struct FIsHeadsetPresent
{
	int64_t LocalUserNum;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineEntitlementsSubsystemQueryEntitlementsCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineEntitlementsSubsystemQueryEntitlementsCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Namespace;  // 0x38(0x10)
	struct FString Error;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemUnblockPlayerCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineFriendsSubsystemUnblockPlayerCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UniqueId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineSessionSettingBP
// Size: 0x30(Inherited: 0x0) 
struct FOnlineSessionSettingBP
{
	struct FVariantDataBP Data;  // 0x0(0x28)
	uint8_t  AdvertisementType;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t ID;  // 0x2C(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreV2Subsystem.GetOffers
// Size: 0x10(Inherited: 0x0) 
struct FGetOffers
{
	struct TArray<struct UOnlineStoreOffer*> OutOffers;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_UpdateSessionComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_UpdateSessionComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_InviteRejected_BP__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FFriends_InviteRejected_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl FriendId;  // 0x30(0x30)

}; 
// ScriptStruct OnlineSubsystemBlueprints.FriendSettingsData
// Size: 0x50(Inherited: 0x0) 
struct FFriendSettingsData
{
	struct TMap<struct FString, struct FString> Data;  // 0x0(0x50)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_InviteAborted_BP__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FFriends_InviteAborted_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl FriendId;  // 0x30(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetAuthType
// Size: 0x10(Inherited: 0x0) 
struct FGetAuthType
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedVoiceSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedVoiceSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineVoiceSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OptionalOnlineSessionSearchResultBP
// Size: 0x1B0(Inherited: 0x0) 
struct FOptionalOnlineSessionSearchResultBP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSet : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FOnlineSessionSearchResultBP SearchResult;  // 0x8(0x1A8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_InviteReceived_BP__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FFriends_InviteReceived_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl FriendId;  // 0x30(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemUsage.ItemUsage
// Size: 0x60(Inherited: 0x0) 
struct FItemUsage
{
	struct UOnlineGameItemStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ItemUsedBy;  // 0x38(0x10)
	struct TArray<struct FString> ItemsUsed;  // 0x48(0x10)
	struct UOnlineGameItemStatsSubsystemItemUsage* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_UnblockedPlayerComplete_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FFriends_UnblockedPlayerComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FUniqueNetIdRepl UniqueId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePresenceSubsystem.GetCachedPresenceForApp
// Size: 0x120(Inherited: 0x0) 
struct FGetCachedPresenceForApp
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl User;  // 0x30(0x30)
	struct FString AppID;  // 0x60(0x10)
	struct FOnlineUserPresenceData OutPresence;  // 0x70(0xA8)
	uint8_t  ReturnValue;  // 0x118(0x1)
	char pad_281[7];  // 0x119(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_OutgoingInviteSent_BP__DelegateSignature
// Size: 0x4(Inherited: 0x0) 
struct FFriends_OutgoingInviteSent_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatPlayerTalkingUpdatedDelegate_BP__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatPlayerTalkingUpdatedDelegate_BP__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FString PlayerName;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bIsTalking : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineActivityPlayerLocationBP
// Size: 0x30(Inherited: 0x0) 
struct FOnlineActivityPlayerLocationBP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSet : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ZoneId;  // 0x8(0x10)
	struct FVector Coordinates;  // 0x18(0x18)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_QueryRecentPlayersComplete_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FFriends_QueryRecentPlayersComplete_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Namespace;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bWasSuccessful : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString Error;  // 0x48(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.VariantDataBP
// Size: 0x28(Inherited: 0x0) 
struct FVariantDataBP
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool AsBool : 1;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	int32_t AsInt;  // 0x4(0x4)
	float AsFloat;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	int64_t AsInt64;  // 0x10(0x8)
	struct FString AsString;  // 0x18(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.EqualEqual_LobbyIdLobbyId
// Size: 0x18(Inherited: 0x0) 
struct FEqualEqual_LobbyIdLobbyId
{
	struct ULobbyId* A;  // 0x0(0x8)
	struct ULobbyId* B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineSessionBP
// Size: 0x1A0(Inherited: 0x0) 
struct FOnlineSessionBP
{
	struct FUniqueNetIdRepl OwningUserId;  // 0x0(0x30)
	struct FString OwningUserName;  // 0x30(0x10)
	struct FOnlineSessionSettingsBP SessionSettings;  // 0x40(0x140)
	struct UOnlineSessionInfo* SessionInfo;  // 0x180(0x8)
	int32_t NumOpenPrivateConnections;  // 0x188(0x4)
	int32_t NumOpenPublicConnections;  // 0x18C(0x4)
	struct FString SessionId;  // 0x190(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineChatSubsystem.SendPrivateChat
// Size: 0x78(Inherited: 0x0) 
struct FSendPrivateChat
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl RecipientId;  // 0x30(0x30)
	struct FString MsgBody;  // 0x60(0x10)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_RecentPlayersAdded_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FFriends_RecentPlayersAdded_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct TArray<struct UOnlineRecentPlayerRef*> AddedPlayers;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.RemovePlayerFromSession
// Size: 0x40(Inherited: 0x0) 
struct FRemovePlayerFromSession
{
	int32_t LocalUserNum;  // 0x0(0x4)
	struct FName SessionName;  // 0x4(0x8)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl TargetPlayerId;  // 0x10(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_SessionInviteReceived_BP__DelegateSignature
// Size: 0x218(Inherited: 0x0) 
struct FSession_SessionInviteReceived_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl FromId;  // 0x30(0x30)
	struct FString AppID;  // 0x60(0x10)
	struct FOnlineSessionSearchResultBP InviteResult;  // 0x70(0x1A8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Friends_RejectInviteComplete_BP__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FFriends_RejectInviteComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineSessionSearchResultBP
// Size: 0x1A8(Inherited: 0x0) 
struct FOnlineSessionSearchResultBP
{
	struct FOnlineSessionBP Session;  // 0x0(0x1A0)
	int32_t PingInMs;  // 0x1A0(0x4)
	char pad_420[4];  // 0x1A4(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayName.SanitizeDisplayName
// Size: 0x20(Inherited: 0x0) 
struct FSanitizeDisplayName
{
	struct UOnlineMessageSanitizerSubsystem* Subsystem;  // 0x0(0x8)
	struct FString DisplayName;  // 0x8(0x10)
	struct UOnlineMessageSanitizerSubsystemSanitizeDisplayName* ReturnValue;  // 0x18(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowWebURLCallbackPin__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FOnlineExternalUISubsystemShowWebURLCallbackPin__DelegateSignature
{
	struct FString FinalUrl;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemQueryBlockedUserCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineMessageSanitizerSubsystemQueryBlockedUserCallbackPin__DelegateSignature
{
	struct FBlockedQueryResultInfo QueryResult;  // 0x0(0x18)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Identity_LoginFlowLogout_BP__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FIdentity_LoginFlowLogout_BP__DelegateSignature
{
	struct TArray<struct FString> LoginDomains;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Identity_LogoutComplete_BP__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FIdentity_LogoutComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Leaderboards_LeaderboardFlushComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FLeaderboards_LeaderboardFlushComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowAccountCreationUICallbackPin__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnlineExternalUISubsystemShowAccountCreationUICallbackPin__DelegateSignature
{
	int32_t ControllerIndex;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FOnlineAccountCredential AccountCredentials;  // 0x8(0x30)
	struct FOnlineErrorInfo Error;  // 0x38(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievementDescriptionsCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlineAchievementsSubsystemQueryAchievementDescriptionsCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedGameActivitySubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedGameActivitySubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineGameActivitySubsystem* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Message_EnumerateMessagesComplete_BP__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FMessage_EnumerateMessagesComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Param1 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString Param2;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.FUniqueNetIdIsValid
// Size: 0x38(Inherited: 0x0) 
struct FFUniqueNetIdIsValid
{
	struct FUniqueNetIdRepl InNetId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Leaderboards_LeaderboardReadComplete_BP__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FLeaderboards_LeaderboardReadComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemUpdatePartyCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlinePartySubsystemUpdatePartyCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	uint8_t  Result;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Lobby_LobbyDelete_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FLobby_LobbyDelete_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Lobby_LobbyUpdate_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FLobby_LobbyUpdate_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineStatsRowBP
// Size: 0x98(Inherited: 0x0) 
struct FOnlineStatsRowBP
{
	struct FString PlayerNickname;  // 0x0(0x10)
	struct FUniqueNetIdRepl PlayerId;  // 0x10(0x30)
	int32_t Rank;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct TMap<struct FName, struct FVariantDataBP> Columns;  // 0x48(0x50)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Lobby_MemberConnect_BP__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FLobby_MemberConnect_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievementsCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlineAchievementsSubsystemQueryAchievementsCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyJIPResponse_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FParty_PartyJIPResponse_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Success : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t DeniedResultCode;  // 0x3C(0x4)

}; 
// Function OnlineSubsystemBlueprints.Party.GetLeaderId
// Size: 0x30(Inherited: 0x0) 
struct FGetLeaderId
{
	struct FUniqueNetIdRepl ReturnValue;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPendingInvitedUsers
// Size: 0x50(Inherited: 0x0) 
struct FGetPendingInvitedUsers
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct TArray<struct FUniqueNetIdRepl> OutPendingInvitedUserArray;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatarUrlCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineAvatarSubsystemGetAvatarUrlCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString ResultAvatarUrl;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlementsSubsystem.GetItemEntitlement
// Size: 0x48(Inherited: 0x0) 
struct FGetItemEntitlement
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString ItemId;  // 0x30(0x10)
	struct UOnlineEntitlement* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineAccountCredential
// Size: 0x30(Inherited: 0x0) 
struct FOnlineAccountCredential
{
	struct FString Type;  // 0x0(0x10)
	struct FString ID;  // 0x10(0x10)
	struct FString Token;  // 0x20(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageUICallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineExternalUISubsystemShowSendMessageUICallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bMessageSent : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemAcceptInviteCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineFriendsSubsystemAcceptInviteCallbackPin__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineStatsSubsystemUpdateStatsCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlineStatsSubsystemUpdateStatsCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo ResultState;  // 0x0(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryOffersByFilter.QueryOffersByFilter
// Size: 0x70(Inherited: 0x0) 
struct FQueryOffersByFilter
{
	struct UOnlineStoreV2Subsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FOnlineStoreFilterBP Filter;  // 0x38(0x30)
	struct UOnlineStoreV2SubsystemQueryOffersByFilter* ReturnValue;  // 0x68(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemAddRecentPlayersCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineFriendsSubsystemAddRecentPlayersCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Error;  // 0x30(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemRestoreParties.RestoreParties
// Size: 0x40(Inherited: 0x0) 
struct FRestoreParties
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UOnlinePartySubsystemRestoreParties* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.MutablePartyData.SetAttribute
// Size: 0x38(Inherited: 0x0) 
struct FSetAttribute
{
	struct FString AttrName;  // 0x0(0x10)
	struct FVariantDataBP AttrValue;  // 0x10(0x28)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemBlockPlayerCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineFriendsSubsystemBlockPlayerCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UniqueId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.User_QueryUserInfoComplete_BP__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FUser_QueryUserInfoComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TArray<struct FUniqueNetIdRepl> UserIds;  // 0x8(0x10)
	struct FString ErrorStr;  // 0x18(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryCategoriesCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineStoreV2SubsystemQueryCategoriesCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Error;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendAliasCallbackPin__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnlineFriendsSubsystemDeleteFriendAliasCallbackPin__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FOnlineErrorInfo Error;  // 0x48(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_SessionParticipantsChange_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FSession_SessionParticipantsChange_BP__DelegateSignature
{
	struct FName Param1;  // 0x0(0x8)
	struct FUniqueNetIdRepl Param2;  // 0x8(0x30)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool Param3 : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineFriendsSubsystemDeleteFriendCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemDeleteLobbyCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineLobbySubsystemDeleteLobbyCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendsListCallbackPin__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnlineFriendsSubsystemDeleteFriendsListCallbackPin__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString ListName;  // 0x8(0x10)
	struct FString ErrorStr;  // 0x18(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryBlockedPlayersCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlineFriendsSubsystemQueryBlockedPlayersCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString Error;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryFriendSettingsCallbackPin__DelegateSignature
// Size: 0x98(Inherited: 0x0) 
struct FOnlineFriendsSubsystemQueryFriendSettingsCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool bWasUpdate : 1;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)
	struct FFriendSettingsData Settings;  // 0x38(0x50)
	struct FString ErrorStr;  // 0x88(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatLoggedInDelegate_BP__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatLoggedInDelegate_BP__DelegateSignature
{
	struct FString PlayerName;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.UpdatePartyMemberData
// Size: 0x50(Inherited: 0x0) 
struct FUpdatePartyMemberData
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FName Namespace;  // 0x38(0x8)
	struct UReadablePartyData* PartyMemberData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryRecentPlayersCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineFriendsSubsystemQueryRecentPlayersCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Namespace;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bWasSuccessful : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FString Error;  // 0x48(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetEndDate
// Size: 0x10(Inherited: 0x0) 
struct FGetEndDate
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemReadFriendsListCallbackPin__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnlineFriendsSubsystemReadFriendsListCallbackPin__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FString ListName;  // 0x8(0x10)
	struct FString ErrorStr;  // 0x18(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemRejectInviteCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineFriendsSubsystemRejectInviteCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemSendInviteCallbackPin__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FOnlineFriendsSubsystemSendInviteCallbackPin__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FString ErrorStr;  // 0x48(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendAliasCallbackPin__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnlineFriendsSubsystemSetFriendAliasCallbackPin__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct FOnlineErrorInfo Error;  // 0x48(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendSettingsCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlineFriendsSubsystemSetFriendSettingsCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Param2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FString Param3;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameActivitySubsystemEndActivityCallbackPin__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnlineGameActivitySubsystemEndActivityCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FString ActivityId;  // 0x30(0x10)
	uint8_t  Outcome;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct FOnlineErrorInfo Status;  // 0x48(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyInviteReceivedEx_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FParty_PartyInviteReceivedEx_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UOnlinePartyJoinInfo* Invitation;  // 0x30(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.RegisterLocalTalker
// Size: 0x10(Inherited: 0x0) 
struct FRegisterLocalTalker
{
	int64_t LocalUserNum;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserSubsystemQueryExternalIdMappings.QueryExternalIdMappings
// Size: 0x68(Inherited: 0x0) 
struct FQueryExternalIdMappings
{
	struct UOnlineUserSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FExternalIdQueryOptionsBP QueryOptions;  // 0x38(0x18)
	struct TArray<struct FString> ExternalIds;  // 0x50(0x10)
	struct UOnlineUserSubsystemQueryExternalIdMappings* ReturnValue;  // 0x60(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemKickMemberCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineLobbySubsystemKickMemberCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.StoreV2_QueryForAvailablePurchasesComplete_BP__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FStoreV2_QueryForAvailablePurchasesComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Param1 : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResetAllActiveActivitiesCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameActivitySubsystemResetAllActiveActivitiesCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.DumpCloudState
// Size: 0x30(Inherited: 0x0) 
struct FDumpCloudState
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineTurnBasedSubsystem.GetMatchDataSize
// Size: 0x4(Inherited: 0x0) 
struct FGetMatchDataSize
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResumeActivityCallbackPin__DelegateSignature
// Size: 0x80(Inherited: 0x0) 
struct FOnlineGameActivitySubsystemResumeActivityCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FString ActivityId;  // 0x30(0x10)
	struct FOnlineErrorInfo Status;  // 0x40(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityAvailabilityCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameActivitySubsystemSetActivityAvailabilityCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.UserCloud_WriteUserFileProgress_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FUserCloud_WriteUserFileProgress_BP__DelegateSignature
{
	int32_t BytesWritten;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetTransmitChannel
// Size: 0x10(Inherited: 0x0) 
struct FGetTransmitChannel
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityPriorityCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameActivitySubsystemSetActivityPriorityCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameActivitySubsystemStartActivityCallbackPin__DelegateSignature
// Size: 0x80(Inherited: 0x0) 
struct FOnlineGameActivitySubsystemStartActivityCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FString ActivityId;  // 0x30(0x10)
	struct FOnlineErrorInfo Status;  // 0x40(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemDisconnectLobbyCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineLobbySubsystemDisconnectLobbyCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemAvailabilityChangeCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameItemStatsSubsystemItemAvailabilityChangeCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemImpactCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameItemStatsSubsystemItemImpactCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemInventoryChangeCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameItemStatsSubsystemItemInventoryChangeCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemFindFriendSessionCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineSessionSubsystemFindFriendSessionCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FOnlineSessionSearchResultBP> FriendSearchResult;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemLoadoutChangeCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameItemStatsSubsystemItemLoadoutChangeCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUserLoginCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FVoiceChatUserLoginCallbackPin__DelegateSignature
{
	struct FString PlayerName;  // 0x0(0x10)
	struct FVoiceChatResultBP Result;  // 0x10(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterLocalPlayer.RegisterLocalPlayer
// Size: 0x48(Inherited: 0x0) 
struct FRegisterLocalPlayer
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl PlayerId;  // 0x8(0x30)
	struct FName SessionName;  // 0x38(0x8)
	struct UOnlineSessionSubsystemRegisterLocalPlayer* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemMitigationCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameItemStatsSubsystemItemMitigationCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemCreateChannelCredentialsCallbackPin__DelegateSignature
// Size: 0x80(Inherited: 0x0) 
struct FOnlineVoiceAdminSubsystemCreateChannelCredentialsCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Result;  // 0x0(0x40)
	struct FUniqueNetIdRepl LocalUserId;  // 0x40(0x30)
	struct TArray<struct FVoiceAdminChannelCredentialsBP> Credentials;  // 0x70(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemUsageCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineGameItemStatsSubsystemItemUsageCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Status;  // 0x30(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemKickParticipantCallbackPin__DelegateSignature
// Size: 0xA0(Inherited: 0x0) 
struct FOnlineVoiceAdminSubsystemKickParticipantCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Result;  // 0x0(0x40)
	struct FUniqueNetIdRepl LocalUserId;  // 0x40(0x30)
	struct FUniqueNetIdRepl TargetUserId;  // 0x70(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetRegularPrice
// Size: 0x8(Inherited: 0x0) 
struct FGetRegularPrice
{
	int64_t ReturnValue;  // 0x0(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineIdentitySubsystemAutoLoginCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlineIdentitySubsystemAutoLoginCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Error;  // 0x38(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemInventoryChange.ItemInventoryChange
// Size: 0x60(Inherited: 0x0) 
struct FItemInventoryChange
{
	struct UOnlineGameItemStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TArray<struct FString> ItemsToAdd;  // 0x38(0x10)
	struct TArray<struct FString> ItemsToRemove;  // 0x48(0x10)
	struct UOnlineGameItemStatsSubsystemItemInventoryChange* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.HasPresenceSession
// Size: 0x1(Inherited: 0x0) 
struct FHasPresenceSession
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemUnblockPlayer.UnblockPlayer
// Size: 0x48(Inherited: 0x0) 
struct FUnblockPlayer
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl PlayerId;  // 0x10(0x30)
	struct UOnlineFriendsSubsystemUnblockPlayer* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSharingSubsystem.ReadNewsFeed
// Size: 0xC(Inherited: 0x0) 
struct FReadNewsFeed
{
	int32_t LocalUserNum;  // 0x0(0x4)
	int32_t NumPostsToRead;  // 0x4(0x4)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineIdentitySubsystemGetUserPrivilegeCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlineIdentitySubsystemGetUserPrivilegeCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	uint8_t  Privilege;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	int64_t PrivilegeResult;  // 0x38(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineIdentitySubsystemLoginCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlineIdentitySubsystemLoginCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Error;  // 0x38(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ReceiptOfferEntryBP
// Size: 0x38(Inherited: 0x0) 
struct FReceiptOfferEntryBP
{
	struct FString Namespace;  // 0x0(0x10)
	struct FString OfferId;  // 0x10(0x10)
	int32_t Quantity;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct FLineItemInfoBP> LineItems;  // 0x28(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedStatsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedStatsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineStatsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineIdentitySubsystemLogoutCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineIdentitySubsystemLogoutCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundRankCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineLeaderboardsSubsystemReadLeaderboardsAroundRankCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundUserCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineLeaderboardsSubsystemReadLeaderboardsAroundUserCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.Lobby.GetId
// Size: 0x8(Inherited: 0x0) 
struct FGetId
{
	struct ULobbyId* ReturnValue;  // 0x0(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.PartyMemberConnectionStatusChanged__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FPartyMemberConnectionStatusChanged__DelegateSignature
{
	struct FUniqueNetIdRepl ChangedUserId;  // 0x0(0x30)
	uint8_t  NewStatus;  // 0x30(0x1)
	uint8_t  PreviousStatus;  // 0x31(0x1)
	char pad_50[6];  // 0x32(0x6)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineLeaderboardsSubsystemReadLeaderboardsCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsForFriendsCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineLeaderboardsSubsystemReadLeaderboardsForFriendsCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemConnectLobbyCallbackPin__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnlineLobbySubsystemConnectLobbyCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)
	struct ULobby* Lobby;  // 0x70(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.CloseWebURL
// Size: 0x1(Inherited: 0x0) 
struct FCloseWebURL
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUserJoinChannelCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FVoiceChatUserJoinChannelCallbackPin__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FVoiceChatResultBP Result;  // 0x10(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemCreateLobbyCallbackPin__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FOnlineLobbySubsystemCreateLobbyCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)
	struct ULobby* Lobby;  // 0x70(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemSearchCallbackPin__DelegateSignature
// Size: 0x80(Inherited: 0x0) 
struct FOnlineLobbySubsystemSearchCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)
	struct TArray<struct ULobbyId*> Lobbies;  // 0x70(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateLobbyCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineLobbySubsystemUpdateLobbyCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.Set3DPosition
// Size: 0x70(Inherited: 0x0) 
struct FSet3DPosition
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FVector SpeakerPosition;  // 0x10(0x18)
	struct FVector ListenerPosition;  // 0x28(0x18)
	struct FVector ListenerForwardDirection;  // 0x40(0x18)
	struct FVector ListenerUpDirection;  // 0x58(0x18)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateMemberSelfCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineLobbySubsystemUpdateMemberSelfCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Error;  // 0x0(0x40)
	struct FUniqueNetIdRepl UserId;  // 0x40(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageUI.ShowSendMessageUI
// Size: 0x108(Inherited: 0x0) 
struct FShowSendMessageUI
{
	struct UOnlineExternalUISubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FShowSendMessageParameters ShowParams;  // 0x10(0xF0)
	struct UOnlineExternalUISubsystemShowSendMessageUI* ReturnValue;  // 0x100(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.FUniqueNetIdGetType
// Size: 0x38(Inherited: 0x0) 
struct FFUniqueNetIdGetType
{
	struct FUniqueNetIdRepl InNetId;  // 0x0(0x30)
	struct FName ReturnValue;  // 0x30(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.BlockedQueryResultInfo
// Size: 0x18(Inherited: 0x0) 
struct FBlockedQueryResultInfo
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Blocked : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool BlockedNonFriends : 1;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString UserId;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemJoinPartyCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlinePartySubsystemJoinPartyCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	uint8_t  Result;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t NotApprovedReason;  // 0x3C(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayNameCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineMessageSanitizerSubsystemSanitizeDisplayNameCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSuccess : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString SanitizedMessage;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.IsMemberLeader
// Size: 0x70(Inherited: 0x0) 
struct FIsMemberLeader
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayNamesCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineMessageSanitizerSubsystemSanitizeDisplayNamesCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSuccess : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FString> SanitizedMessages;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_DestroySessionComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_DestroySessionComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.InsecureGetLoginToken
// Size: 0x20(Inherited: 0x0) 
struct FInsecureGetLoginToken
{
	struct FString PlayerName;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemCancelInvitationCallbackPin__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FOnlinePartySubsystemCancelInvitationCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl SenderUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl TargetUserId;  // 0x38(0x30)
	struct FOnlineErrorInfo Result;  // 0x68(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemCleanupPartiesCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlinePartySubsystemCleanupPartiesCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Result;  // 0x30(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.ReadFileDataAsString
// Size: 0x18(Inherited: 0x0) 
struct FReadFileDataAsString
{
	struct UFileData* FileData;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemKickMemberCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlinePartySubsystemKickMemberCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	uint8_t  Result;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemLeavePartyCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlinePartySubsystemLeavePartyCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	uint8_t  Result;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystemConnectLobby.ConnectLobby
// Size: 0x48(Inherited: 0x0) 
struct FConnectLobby
{
	struct UOnlineLobbySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct ULobbyId* LobbyId;  // 0x38(0x8)
	struct UOnlineLobbySubsystemConnectLobby* ReturnValue;  // 0x40(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemRejoinPartyCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlinePartySubsystemRejoinPartyCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	uint8_t  Result;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	int32_t NotApprovedReason;  // 0x3C(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemRestoreInvitesCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlinePartySubsystemRestoreInvitesCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Result;  // 0x30(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystemFinalizeReceiptValidationInfo.FinalizeReceiptValidationInfo
// Size: 0x50(Inherited: 0x0) 
struct FFinalizeReceiptValidationInfo
{
	struct UOnlinePurchaseSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString InReceiptValidationInfo;  // 0x38(0x10)
	struct UOnlinePurchaseSubsystemFinalizeReceiptValidationInfo* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemEndSession.EndSession
// Size: 0x18(Inherited: 0x0) 
struct FEndSession
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FName SessionName;  // 0x8(0x8)
	struct UOnlineSessionSubsystemEndSession* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineGroupsSubsystem.SetNamespace
// Size: 0x10(Inherited: 0x0) 
struct FSetNamespace
{
	struct FString Ns;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemRestorePartiesCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlinePartySubsystemRestorePartiesCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineErrorInfo Result;  // 0x30(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.MuteRemoteTalker
// Size: 0x40(Inherited: 0x0) 
struct FMuteRemoteTalker
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl PlayerId;  // 0x8(0x30)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bIsSystemWide : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePartySubsystemSendInvitationCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlinePartySubsystemSendInvitationCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl RecipientId;  // 0x38(0x30)
	uint8_t  Result;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedStoreV2Subsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedStoreV2Subsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineStoreV2Subsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetSessionSettings
// Size: 0x10(Inherited: 0x0) 
struct FGetSessionSettings
{
	struct FName SessionName;  // 0x0(0x8)
	struct UOnlineSessionSettings* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePresenceSubsystemQueryPresenceCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlinePresenceSubsystemQueryPresenceCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePresenceSubsystemSetPresenceCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlinePresenceSubsystemSetPresenceCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool bWasSuccessful : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePurchaseSubsystemCheckoutCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlinePurchaseSubsystemCheckoutCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Result;  // 0x0(0x40)
	struct UPurchaseReceipt* Receipt;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedEntitlementsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedEntitlementsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineEntitlementsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyMemberJoined_BP__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FParty_PartyMemberJoined_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_UnregisterPlayersComplete_BP__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FSession_UnregisterPlayersComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	struct TArray<struct FUniqueNetIdRepl> PlayerIds;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bWasSuccessful : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsSubsystemAvailable
// Size: 0x1(Inherited: 0x0) 
struct FIsSubsystemAvailable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePurchaseSubsystemFinalizeReceiptValidationInfoCallbackPin__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnlinePurchaseSubsystemFinalizeReceiptValidationInfoCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Result;  // 0x0(0x40)
	struct FString ValidationInfo;  // 0x40(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineStatsSubsystem.GetStats
// Size: 0xB0(Inherited: 0x0) 
struct FGetStats
{
	struct FUniqueNetIdRepl StatsUserId;  // 0x0(0x30)
	struct FOnlineStatsUserStatsBP ReturnValue;  // 0x30(0x80)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePurchaseSubsystemQueryReceiptsCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FOnlinePurchaseSubsystemQueryReceiptsCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Result;  // 0x0(0x40)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlinePurchaseSubsystemRedeemCodeCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlinePurchaseSubsystemRedeemCodeCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Result;  // 0x0(0x40)
	struct UPurchaseReceipt* Receipt;  // 0x40(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelFindSessionsCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineSessionSubsystemCancelFindSessionsCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelMatchmakingCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemCancelMatchmakingCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystem.UpdatePlayerLocation
// Size: 0x60(Inherited: 0x0) 
struct FUpdatePlayerLocation
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FOnlineActivityPlayerLocationBP ActivityPlayerLocation;  // 0x30(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemCreateSessionCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemCreateSessionCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemDestroySessionCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemDestroySessionCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Presence_PresenceArrayUpdated_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FPresence_PresenceArrayUpdated_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct TArray<struct FOnlineUserPresenceData> NewPresenceArray;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetBlockedPlayers
// Size: 0x48(Inherited: 0x0) 
struct FGetBlockedPlayers
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct TArray<struct UOnlineUserRef*> OutBlockedPlayers;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessionByIdCallbackPin__DelegateSignature
// Size: 0x1B0(Inherited: 0x0) 
struct FOnlineSessionSubsystemFindSessionByIdCallbackPin__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct FOnlineSessionSearchResultBP SearchResult;  // 0x8(0x1A8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetOutputDeviceInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetOutputDeviceInfo
{
	struct FVoiceChatDeviceInfoBP ReturnValue;  // 0x0(0x20)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessionsCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineSessionSubsystemFindSessionsCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineTitleFileSubsystemReadFileCallbackPin__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnlineTitleFileSubsystemReadFileCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Filename;  // 0x8(0x10)
	int64_t NumBytes;  // 0x18(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryOffersById.QueryOffersById
// Size: 0x50(Inherited: 0x0) 
struct FQueryOffersById
{
	struct UOnlineStoreV2Subsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct TArray<struct FString> OfferIds;  // 0x38(0x10)
	struct UOnlineStoreV2SubsystemQueryOffersById* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemJoinSessionCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemJoinSessionCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.EqualEqual_PartyIdPartyId
// Size: 0x18(Inherited: 0x0) 
struct FEqualEqual_PartyIdPartyId
{
	struct UPartyId* A;  // 0x0(0x8)
	struct UPartyId* B;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemPingSearchResultsCallbackPin__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FOnlineSessionSubsystemPingSearchResultsCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterLocalPlayerCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlineSessionSubsystemRegisterLocalPlayerCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	uint8_t  Param2;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterPlayersCallbackPin__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnlineSessionSubsystemRegisterPlayersCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	struct TArray<struct FUniqueNetIdRepl> PlayerIds;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bWasSuccessful : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetPublic
// Size: 0x1(Inherited: 0x0) 
struct FSetPublic
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Public : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemStartMatchmakingCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemStartMatchmakingCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMemberCount
// Size: 0x40(Inherited: 0x0) 
struct FGetPartyMemberCount
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	int64_t ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.IsConsumable
// Size: 0x1(Inherited: 0x0) 
struct FIsConsumable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemStartSessionCallbackPin__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FOnlineSessionSubsystemStartSessionCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterLocalPlayerCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlineSessionSubsystemUnregisterLocalPlayerCallbackPin__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Param2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemLeaveParty.LeaveParty
// Size: 0x50(Inherited: 0x0) 
struct FLeaveParty
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UPartyId* PartyId;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bSynchronizeLeave : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)
	struct UOnlinePartySubsystemLeaveParty* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterPlayersCallbackPin__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FOnlineSessionSubsystemUnregisterPlayersCallbackPin__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	struct TArray<struct FUniqueNetIdRepl> PlayerIds;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bWasSuccessful : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineStatsSubsystemQueryStatsCallbackPin__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnlineStatsSubsystemQueryStatsCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo ResultState;  // 0x0(0x40)
	struct TArray<struct FOnlineStatsUserStatsBP> UsersStatsResult;  // 0x40(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadAllMatchesCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineTurnBasedSubsystemLoadAllMatchesCallbackPin__DelegateSignature
{
	struct TArray<struct FString> Param1;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Param2 : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineStatsUserStatsBP
// Size: 0x80(Inherited: 0x0) 
struct FOnlineStatsUserStatsBP
{
	struct FUniqueNetIdRepl PlayerId;  // 0x0(0x30)
	struct TMap<struct FString, struct FVariantDataBP> Stats;  // 0x30(0x50)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryOffersByFilterCallbackPin__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnlineStoreV2SubsystemQueryOffersByFilterCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FString> OfferIds;  // 0x8(0x10)
	struct FString Error;  // 0x18(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryOffersByIdCallbackPin__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnlineStoreV2SubsystemQueryOffersByIdCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FString> OfferIds;  // 0x8(0x10)
	struct FString Error;  // 0x18(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineTitleFileSubsystemEnumerateFilesCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineTitleFileSubsystemEnumerateFilesCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Error;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineStatsSubsystemUpdateStats.UpdateStats
// Size: 0x50(Inherited: 0x0) 
struct FUpdateStats
{
	struct UOnlineStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TArray<struct FOnlineStatsUserUpdatedStatsBP> UpdatedUserStats;  // 0x38(0x10)
	struct UOnlineStatsSubsystemUpdateStats* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemCreateChannelCredentials.CreateChannelCredentials
// Size: 0x60(Inherited: 0x0) 
struct FCreateChannelCredentials
{
	struct UOnlineVoiceAdminSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ChannelName;  // 0x38(0x10)
	struct TArray<struct FUniqueNetIdRepl> TargetUserIds;  // 0x48(0x10)
	struct UOnlineVoiceAdminSubsystemCreateChannelCredentials* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadMatchWithIDCallbackPin__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FOnlineTurnBasedSubsystemLoadMatchWithIDCallbackPin__DelegateSignature
{
	struct FString Param1;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Param2 : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineUserCloudSubsystemDeleteUserFileCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlineUserCloudSubsystemDeleteUserFileCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Sharing_RequestNewReadPermissionsComplete_BP__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FSharing_RequestNewReadPermissionsComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Param1 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineUserCloudSubsystemEnumerateUserFilesCallbackPin__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FOnlineUserCloudSubsystemEnumerateUserFilesCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedSessionSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedSessionSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineSessionSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedAchievementsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedAchievementsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineAchievementsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineUserCloudSubsystemReadUserFileCallbackPin__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FOnlineUserCloudSubsystemReadUserFileCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineUserCloudSubsystemWriteUserFileCallbackPin__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FOnlineUserCloudSubsystemWriteUserFileCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)
	int32_t BytesWritten;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineUserSubsystemQueryExternalIdMappingsCallbackPin__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FOnlineUserSubsystemQueryExternalIdMappingsCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FExternalIdQueryOptionsBP QueryOptions;  // 0x38(0x18)
	struct TArray<struct FString> ExternalIds;  // 0x50(0x10)
	struct FString Error;  // 0x60(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ExternalIdQueryOptionsBP
// Size: 0x18(Inherited: 0x0) 
struct FExternalIdQueryOptionsBP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bLookupByDisplayName : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString AuthType;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserIdMappingCallbackPin__DelegateSignature
// Size: 0x88(Inherited: 0x0) 
struct FOnlineUserSubsystemQueryUserIdMappingCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString DisplayNameOrEmail;  // 0x38(0x10)
	struct FUniqueNetIdRepl FoundUserId;  // 0x48(0x30)
	struct FString Error;  // 0x78(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserInfoCallbackPin__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FOnlineUserSubsystemQueryUserInfoCallbackPin__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FUniqueNetIdRepl> UserIds;  // 0x8(0x10)
	struct FString ErrorStr;  // 0x18(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResetAllActiveActivities.ResetAllActiveActivities
// Size: 0x40(Inherited: 0x0) 
struct FResetAllActiveActivities
{
	struct UOnlineGameActivitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UOnlineGameActivitySubsystemResetAllActiveActivities* ReturnValue;  // 0x38(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemSetParticipantHardMuteCallbackPin__DelegateSignature
// Size: 0xA8(Inherited: 0x0) 
struct FOnlineVoiceAdminSubsystemSetParticipantHardMuteCallbackPin__DelegateSignature
{
	struct FOnlineErrorInfo Result;  // 0x0(0x40)
	struct FUniqueNetIdRepl LocalUserId;  // 0x40(0x30)
	struct FUniqueNetIdRepl TargetUserId;  // 0x70(0x30)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool bIsNowMuted : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemConnectCallbackPin__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnlineVoiceChatSubsystemConnectCallbackPin__DelegateSignature
{
	struct FVoiceChatResultBP Result;  // 0x0(0x30)

}; 
// ScriptStruct OnlineSubsystemBlueprints.VoiceChatResultBP
// Size: 0x30(Inherited: 0x0) 
struct FVoiceChatResultBP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Successful : 1;  // 0x0(0x1)
	uint8_t  ResultCode;  // 0x1(0x1)
	char pad_2[6];  // 0x2(0x6)
	struct FString ErrorCode;  // 0x8(0x10)
	int32_t ErrorNum;  // 0x18(0x4)
	char pad_28[4];  // 0x1C(0x4)
	struct FString ErrorDesc;  // 0x20(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemDisconnectCallbackPin__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FOnlineVoiceChatSubsystemDisconnectCallbackPin__DelegateSignature
{
	struct FVoiceChatResultBP Result;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.IsChannelPlayerMuted
// Size: 0x28(Inherited: 0x0) 
struct FIsChannelPlayerMuted
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FString PlayerName;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_FillPartyJoinRequestData_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FParty_FillPartyJoinRequestData_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct UMutablePartyData* PartyData;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePresenceSubsystem.GetCachedPresence
// Size: 0xE0(Inherited: 0x0) 
struct FGetCachedPresence
{
	struct FUniqueNetIdRepl User;  // 0x0(0x30)
	struct FOnlineUserPresenceData OutPresence;  // 0x30(0xA8)
	uint8_t  ReturnValue;  // 0xD8(0x1)
	char pad_217[7];  // 0xD9(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyConfigChanged_BP__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FParty_PartyConfigChanged_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FOnlinePartyConfiguration PartyConfig;  // 0x38(0x40)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUserLeaveChannel.LeaveChannel
// Size: 0x20(Inherited: 0x0) 
struct FLeaveChannel
{
	struct UVoiceChatUser* Subsystem;  // 0x0(0x8)
	struct FString ChannelName;  // 0x8(0x10)
	struct UVoiceChatUserLeaveChannel* ReturnValue;  // 0x18(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyDataReceived_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FParty_PartyDataReceived_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FName Namespace;  // 0x38(0x8)
	struct UReadablePartyData* PartyData;  // 0x40(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyExited_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FParty_PartyExited_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyJoined_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FParty_PartyJoined_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.IsFriend
// Size: 0x50(Inherited: 0x0) 
struct FIsFriend
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.LoginFlowComplete
// Size: 0x48(Inherited: 0x0) 
struct FLoginFlowComplete
{
	int32_t RequestId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FLoginFlowResultBP Result;  // 0x8(0x40)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetStartDate
// Size: 0x10(Inherited: 0x0) 
struct FGetStartDate
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyInviteRequestReceived_BP__DelegateSignature
// Size: 0x98(Inherited: 0x0) 
struct FParty_PartyInviteRequestReceived_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl SenderId;  // 0x38(0x30)
	struct FUniqueNetIdRepl RequestForId;  // 0x68(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Sharing_SharePostComplete_BP__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FSharing_SharePostComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Param1 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyInvitesChanged_BP__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FParty_PartyInvitesChanged_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyJIPRequestReceived_BP__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FParty_PartyJIPRequestReceived_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl SenderId;  // 0x38(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyMemberDataReceived_BP__DelegateSignature
// Size: 0x78(Inherited: 0x0) 
struct FParty_PartyMemberDataReceived_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	struct FName Namespace;  // 0x68(0x8)
	struct UReadablePartyData* PartyData;  // 0x70(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyMemberExited_BP__DelegateSignature
// Size: 0x70(Inherited: 0x0) 
struct FParty_PartyMemberExited_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	uint8_t  Reason;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyMemberPromoted_BP__DelegateSignature
// Size: 0x68(Inherited: 0x0) 
struct FParty_PartyMemberPromoted_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl NewLeaderId;  // 0x38(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyPromotionLockoutChanged_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FParty_PartyPromotionLockoutChanged_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bLockoutState : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriend.DeleteFriend
// Size: 0x58(Inherited: 0x0) 
struct FDeleteFriend
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x10(0x30)
	struct FString ListName;  // 0x40(0x10)
	struct UOnlineFriendsSubsystemDeleteFriend* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Party_PartyStateChanged_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FParty_PartyStateChanged_BP__DelegateSignature
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	uint8_t  State;  // 0x38(0x1)
	uint8_t  PreviousState;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// DelegateFunction OnlineSubsystemBlueprints.PartyMemberAttributeChanged__DelegateSignature
// Size: 0x60(Inherited: 0x0) 
struct FPartyMemberAttributeChanged__DelegateSignature
{
	struct FUniqueNetIdRepl ChangedUserId;  // 0x0(0x30)
	struct FString Attribute;  // 0x30(0x10)
	struct FString NewValue;  // 0x40(0x10)
	struct FString OldValue;  // 0x50(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSharedCloudSubsystem.ClearSharedFiles
// Size: 0x1(Inherited: 0x0) 
struct FClearSharedFiles
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetReadState
// Size: 0x1(Inherited: 0x0) 
struct FGetReadState
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineUserPresenceData
// Size: 0xA8(Inherited: 0x0) 
struct FOnlineUserPresenceData
{
	struct FUniqueNetIdRepl SessionId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool IsOnline : 1;  // 0x30(0x1)
	char pad_49_1 : 7;  // 0x31(0x1)
	bool IsPlaying : 1;  // 0x31(0x1)
	char pad_50_1 : 7;  // 0x32(0x1)
	bool IsPlayingThisGame : 1;  // 0x32(0x1)
	char pad_51_1 : 7;  // 0x33(0x1)
	bool IsJoinable : 1;  // 0x33(0x1)
	char pad_52_1 : 7;  // 0x34(0x1)
	bool HasVoiceSupport : 1;  // 0x34(0x1)
	char pad_53[3];  // 0x35(0x3)
	struct FDateTime LastOnline;  // 0x38(0x8)
	struct FOnlineUserPresenceStatusData Status;  // 0x40(0x68)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineUserPresenceStatusData
// Size: 0x68(Inherited: 0x0) 
struct FOnlineUserPresenceStatusData
{
	struct FString Status;  // 0x0(0x10)
	uint8_t  State;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct TMap<struct FString, struct FString> Properties;  // 0x18(0x50)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Presence_PresenceReceived_BP__DelegateSignature
// Size: 0xD8(Inherited: 0x0) 
struct FPresence_PresenceReceived_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FOnlineUserPresenceData Presence;  // 0x30(0xA8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Purchase_UnexpectedPurchaseReceipt_BP__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FPurchase_UnexpectedPurchaseReceipt_BP__DelegateSignature
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemRejectInvite.RejectInvite
// Size: 0x58(Inherited: 0x0) 
struct FRejectInvite
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x10(0x30)
	struct FString ListName;  // 0x40(0x10)
	struct UOnlineFriendsSubsystemRejectInvite* ReturnValue;  // 0x50(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_CancelFindSessionsComplete_BP__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FSession_CancelFindSessionsComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_CancelMatchmakingComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_CancelMatchmakingComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_CreateSessionComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_CreateSessionComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetName
// Size: 0x10(Inherited: 0x0) 
struct FGetName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemRejoinParty.RejoinParty
// Size: 0x60(Inherited: 0x0) 
struct FRejoinParty
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UPartyId* PartyId;  // 0x38(0x8)
	int64_t PartyTypeId;  // 0x40(0x8)
	struct TArray<struct FUniqueNetIdRepl> FormerMembers;  // 0x48(0x10)
	struct UOnlinePartySubsystemRejoinParty* ReturnValue;  // 0x58(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_EndSessionComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_EndSessionComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemRegisterPlayers.RegisterPlayers
// Size: 0x30(Inherited: 0x0) 
struct FRegisterPlayers
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FName SessionName;  // 0x8(0x8)
	struct TArray<struct FUniqueNetIdRepl> Players;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bWasInvited : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct UOnlineSessionSubsystemRegisterPlayers* ReturnValue;  // 0x28(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_FindFriendSessionComplete_BP__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FSession_FindFriendSessionComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool bWasSuccessful : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	struct TArray<struct FOnlineSessionSearchResultBP> FriendSearchResult;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.CreateFileDataFromString
// Size: 0x18(Inherited: 0x0) 
struct FCreateFileDataFromString
{
	struct FString String;  // 0x0(0x10)
	struct UFileData* ReturnValue;  // 0x10(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_FindSessionsComplete_BP__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FSession_FindSessionsComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreV2SubsystemQueryCategories.QueryCategories
// Size: 0x40(Inherited: 0x0) 
struct FQueryCategories
{
	struct UOnlineStoreV2Subsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct UOnlineStoreV2SubsystemQueryCategories* ReturnValue;  // 0x38(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_JoinSessionComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_JoinSessionComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	uint8_t  Result;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_MatchmakingComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_MatchmakingComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.ParseSerializedLobbyId
// Size: 0x18(Inherited: 0x0) 
struct FParseSerializedLobbyId
{
	struct FString InLobbyId;  // 0x0(0x10)
	struct ULobbyId* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.MakeJoinInfoJson
// Size: 0x48(Inherited: 0x0) 
struct FMakeJoinInfoJson
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FString ReturnValue;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_PingSearchResultsComplete_BP__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FSession_PingSearchResultsComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatPlayerVolumeUpdatedDelegate_BP__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatPlayerVolumeUpdatedDelegate_BP__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FString PlayerName;  // 0x10(0x10)
	float Volume;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_QosDataRequested_BP__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FSession_QosDataRequested_BP__DelegateSignature
{
	struct FName Param1;  // 0x0(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_RegisterPlayersComplete_BP__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FSession_RegisterPlayersComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	struct TArray<struct FUniqueNetIdRepl> PlayerIds;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool bWasSuccessful : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_SessionFailure_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FSession_SessionFailure_BP__DelegateSignature
{
	struct FUniqueNetIdRepl PlayerId;  // 0x0(0x30)
	uint8_t  FailureType;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystem.GetCachedAchievementDescription
// Size: 0x70(Inherited: 0x0) 
struct FGetCachedAchievementDescription
{
	struct FString AchievementId;  // 0x0(0x10)
	struct FOnlineAchievementDescBP OutAchievementDesc;  // 0x10(0x58)
	uint8_t  ReturnValue;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_SessionParticipantRemoved_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FSession_SessionParticipantRemoved_BP__DelegateSignature
{
	struct FName Param1;  // 0x0(0x8)
	struct FUniqueNetIdRepl Param2;  // 0x8(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.RegisterRemoteTalker
// Size: 0x38(Inherited: 0x0) 
struct FRegisterRemoteTalker
{
	struct FUniqueNetIdRepl UniqueId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatarUrl.GetAvatarUrl
// Size: 0x80(Inherited: 0x0) 
struct FGetAvatarUrl
{
	struct UOnlineAvatarSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FUniqueNetIdRepl TargetUserId;  // 0x38(0x30)
	struct FString DefaultAvatarUrl;  // 0x68(0x10)
	struct UOnlineAvatarSubsystemGetAvatarUrl* ReturnValue;  // 0x78(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_SessionParticipantSettingsUpdated_BP__DelegateSignature
// Size: 0x178(Inherited: 0x0) 
struct FSession_SessionParticipantSettingsUpdated_BP__DelegateSignature
{
	struct FName Param1;  // 0x0(0x8)
	struct FUniqueNetIdRepl Param2;  // 0x8(0x30)
	struct FOnlineSessionSettingsBP Param3;  // 0x38(0x140)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_SessionSettingsUpdated_BP__DelegateSignature
// Size: 0x148(Inherited: 0x0) 
struct FSession_SessionSettingsUpdated_BP__DelegateSignature
{
	struct FName Param1;  // 0x0(0x8)
	struct FOnlineSessionSettingsBP Param2;  // 0x8(0x140)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.CreateSessionIdFromString
// Size: 0x40(Inherited: 0x0) 
struct FCreateSessionIdFromString
{
	struct FString SessionIdStr;  // 0x0(0x10)
	struct FUniqueNetIdRepl ReturnValue;  // 0x10(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_SessionUserInviteAccepted_BP__DelegateSignature
// Size: 0x1E0(Inherited: 0x0) 
struct FSession_SessionUserInviteAccepted_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	int32_t ControllerId;  // 0x4(0x4)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FOnlineSessionSearchResultBP InviteResult;  // 0x38(0x1A8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Session_StartSessionComplete_BP__DelegateSignature
// Size: 0xC(Inherited: 0x0) 
struct FSession_StartSessionComplete_BP__DelegateSignature
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bWasSuccessful : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Sharing_ReadNewsFeedComplete_BP__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FSharing_ReadNewsFeedComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Param1 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemDisconnect.Disconnect
// Size: 0x10(Inherited: 0x0) 
struct FDisconnect
{
	struct UOnlineVoiceChatSubsystem* Subsystem;  // 0x0(0x8)
	struct UOnlineVoiceChatSubsystemDisconnect* ReturnValue;  // 0x8(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Sharing_RequestNewPublishPermissionsComplete_BP__DelegateSignature
// Size: 0x8(Inherited: 0x0) 
struct FSharing_RequestNewPublishPermissionsComplete_BP__DelegateSignature
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool Param1 : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowStoreUI.ShowStoreUI
// Size: 0x40(Inherited: 0x0) 
struct FShowStoreUI
{
	struct UOnlineExternalUISubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FShowStoreParameters ShowParams;  // 0x10(0x28)
	struct UOnlineExternalUISubsystemShowStoreUI* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.BlockPlayers
// Size: 0x10(Inherited: 0x0) 
struct FBlockPlayers
{
	struct TArray<struct FString> PlayerNames;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Time_QueryServerUtcTimeComplete_BP__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FTime_QueryServerUtcTimeComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Param1 : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Param2;  // 0x8(0x10)
	struct FString Param3;  // 0x18(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.TitleFile_EnumerateFilesComplete_BP__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FTitleFile_EnumerateFilesComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Error;  // 0x8(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.TitleFile_ReadFileProgress_BP__DelegateSignature
// Size: 0x18(Inherited: 0x0) 
struct FTitleFile_ReadFileProgress_BP__DelegateSignature
{
	struct FString Filename;  // 0x0(0x10)
	int64_t NumBytes;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserSubsystemQueryUserIdMapping.QueryUserIdMapping
// Size: 0x50(Inherited: 0x0) 
struct FQueryUserIdMapping
{
	struct UOnlineUserSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString DisplayNameOrEmail;  // 0x38(0x10)
	struct UOnlineUserSubsystemQueryUserIdMapping* ReturnValue;  // 0x48(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.UserCloud_DeleteUserFileComplete_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FUserCloud_DeleteUserFileComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.UserCloud_EnumerateUserFilesComplete_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FUserCloud_EnumerateUserFilesComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)

}; 
// Function OnlineSubsystemBlueprints.UserOnlineAccountRef.GetAccessToken
// Size: 0x10(Inherited: 0x0) 
struct FGetAccessToken
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.PurchaseOfferEntryBP
// Size: 0x28(Inherited: 0x0) 
struct FPurchaseOfferEntryBP
{
	struct FString OfferNamespace;  // 0x0(0x10)
	struct FString OfferId;  // 0x10(0x10)
	int32_t Quantity;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)

}; 
// DelegateFunction OnlineSubsystemBlueprints.UserCloud_ReadUserFileComplete_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FUserCloud_ReadUserFileComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.UserCloud_WriteUserFileComplete_BP__DelegateSignature
// Size: 0x48(Inherited: 0x0) 
struct FUserCloud_WriteUserFileComplete_BP__DelegateSignature
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWasSuccessful : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.Voice_PlayerTalkingStateChanged_BP__DelegateSignature
// Size: 0x38(Inherited: 0x0) 
struct FVoice_PlayerTalkingStateChanged_BP__DelegateSignature
{
	struct FUniqueNetIdRepl Param1;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool Param2 : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChat_OnVoiceChatDisconnectedDelegate_BP__DelegateSignature
// Size: 0x30(Inherited: 0x0) 
struct FVoiceChat_OnVoiceChatDisconnectedDelegate_BP__DelegateSignature
{
	struct FVoiceChatResultBP Reason;  // 0x0(0x30)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatChannelExitedDelegate_BP__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatChannelExitedDelegate_BP__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FVoiceChatResultBP Reason;  // 0x10(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedMessageSanitizerSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedMessageSanitizerSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineMessageSanitizerSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemPingSearchResults.PingSearchResults
// Size: 0x1B8(Inherited: 0x0) 
struct FPingSearchResults
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FOnlineSessionSearchResultBP SearchResult;  // 0x8(0x1A8)
	struct UOnlineSessionSubsystemPingSearchResults* ReturnValue;  // 0x1B0(0x8)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatChannelJoinedDelegate_BP__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatChannelJoinedDelegate_BP__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatLoggedOutDelegate_BP__DelegateSignature
// Size: 0x10(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatLoggedOutDelegate_BP__DelegateSignature
{
	struct FString PlayerName;  // 0x0(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatPlayerAddedDelegate_BP__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatPlayerAddedDelegate_BP__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FString PlayerName;  // 0x10(0x10)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatPlayerMuteUpdatedDelegate_BP__DelegateSignature
// Size: 0x28(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatPlayerMuteUpdatedDelegate_BP__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FString PlayerName;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bIsMuted : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUser_OnVoiceChatPlayerRemovedDelegate_BP__DelegateSignature
// Size: 0x20(Inherited: 0x0) 
struct FVoiceChatUser_OnVoiceChatPlayerRemovedDelegate_BP__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FString PlayerName;  // 0x10(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedExternalUISubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedExternalUISubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineExternalUISubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetLongDescription
// Size: 0x18(Inherited: 0x0) 
struct FGetLongDescription
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem.FlushLeaderboards
// Size: 0xC(Inherited: 0x0) 
struct FFlushLeaderboards
{
	struct FName SessionName;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// DelegateFunction OnlineSubsystemBlueprints.VoiceChatUserLeaveChannelCallbackPin__DelegateSignature
// Size: 0x40(Inherited: 0x0) 
struct FVoiceChatUserLeaveChannelCallbackPin__DelegateSignature
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FVoiceChatResultBP Result;  // 0x10(0x30)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineAchievementBP
// Size: 0x18(Inherited: 0x0) 
struct FOnlineAchievementBP
{
	struct FString ID;  // 0x0(0x10)
	float Progress;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineAchievementDescBP
// Size: 0x58(Inherited: 0x0) 
struct FOnlineAchievementDescBP
{
	struct FText Title;  // 0x0(0x18)
	struct FText LockedDesc;  // 0x18(0x18)
	struct FText UnlockedDesc;  // 0x30(0x18)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bIsHidden : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct FDateTime UnlockTime;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystemConnect.Connect
// Size: 0x10(Inherited: 0x0) 
struct FConnect
{
	struct UOnlineVoiceChatSubsystem* Subsystem;  // 0x0(0x8)
	struct UOnlineVoiceChatSubsystemConnect* ReturnValue;  // 0x8(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.PurchaseCheckoutRequestBP
// Size: 0x20(Inherited: 0x0) 
struct FPurchaseCheckoutRequestBP
{
	struct FString AccountId;  // 0x0(0x10)
	struct TArray<struct FPurchaseOfferEntryBP> PurchaseOffers;  // 0x10(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ExternalUIFlowHandlerRegistration
// Size: 0x18(Inherited: 0x0) 
struct FExternalUIFlowHandlerRegistration
{
	struct UObject* Interface;  // 0x0(0x8)
	char pad_8[16];  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemEnumerateUserFiles.EnumerateUserFiles
// Size: 0x40(Inherited: 0x0) 
struct FEnumerateUserFiles
{
	struct UOnlineUserCloudSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct UOnlineUserCloudSubsystemEnumerateUserFiles* ReturnValue;  // 0x38(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.LoginFlowResultBP
// Size: 0x40(Inherited: 0x0) 
struct FLoginFlowResultBP
{
	struct FString Token;  // 0x0(0x10)
	struct FText ErrorMessage;  // 0x10(0x18)
	struct FString ErrorRaw;  // 0x28(0x10)
	int32_t NumericErrorCode;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ShowWebUrlParameters
// Size: 0x38(Inherited: 0x0) 
struct FShowWebUrlParameters
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Embedded : 1;  // 0x0(0x1)
	char pad_1_1 : 7;  // 0x1(0x1)
	bool ShowCloseButton : 1;  // 0x1(0x1)
	char pad_2_1 : 7;  // 0x2(0x1)
	bool ShowBackground : 1;  // 0x2(0x1)
	char pad_3_1 : 7;  // 0x3(0x1)
	bool HideCursor : 1;  // 0x3(0x1)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ResetCookies : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)
	int32_t OffsetX;  // 0x8(0x4)
	int32_t OffsetY;  // 0xC(0x4)
	int32_t SizeX;  // 0x10(0x4)
	int32_t SizeY;  // 0x14(0x4)
	struct TArray<struct FString> AllowedDomains;  // 0x18(0x10)
	struct FString CallbackPath;  // 0x28(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ShowStoreParameters
// Size: 0x28(Inherited: 0x0) 
struct FShowStoreParameters
{
	struct FString Category;  // 0x0(0x10)
	struct FString ProductId;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool AddToCart : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.GetFileList
// Size: 0x10(Inherited: 0x0) 
struct FGetFileList
{
	struct TArray<struct FCloudFileHeaderBP> Files;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineMessageSubsystem.ClearMessageHeaders
// Size: 0x8(Inherited: 0x0) 
struct FClearMessageHeaders
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ShowSendMessageParameters
// Size: 0xF0(Inherited: 0x0) 
struct FShowSendMessageParameters
{
	struct FText DisplayTitle;  // 0x0(0x18)
	struct TMap<struct FString, struct FString> DisplayTitle_Loc;  // 0x18(0x50)
	struct FText DisplayMessage;  // 0x68(0x18)
	struct FText DisplayDetails;  // 0x80(0x18)
	struct TMap<struct FString, struct FString> DisplayDetails_Loc;  // 0x98(0x50)
	struct FOnlineMessagePayloadData DataPayload;  // 0xE8(0x1)
	char pad_233[3];  // 0xE9(0x3)
	int32_t MaxRecipients;  // 0xEC(0x4)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineMessagePayloadData
// Size: 0x1(Inherited: 0x0) 
struct FOnlineMessagePayloadData
{
	char pad_0[1];  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowAccountUpgradeUI
// Size: 0x38(Inherited: 0x0) 
struct FShowAccountUpgradeUI
{
	struct FUniqueNetIdRepl UniqueId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// ScriptStruct OnlineSubsystemBlueprints.CloudFileHeaderBP
// Size: 0x58(Inherited: 0x0) 
struct FCloudFileHeaderBP
{
	struct FString Hash;  // 0x0(0x10)
	struct FName HashType;  // 0x10(0x8)
	struct FString DLName;  // 0x18(0x10)
	struct FString Filename;  // 0x28(0x10)
	int32_t FileSize;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FString URL;  // 0x40(0x10)
	int64_t ChunkID;  // 0x50(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ReportPlayedWithUserInfo
// Size: 0x40(Inherited: 0x0) 
struct FReportPlayedWithUserInfo
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString PresenceStr;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.GetVoiceDebugState
// Size: 0x10(Inherited: 0x0) 
struct FGetVoiceDebugState
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineActivityTasksToResetBP
// Size: 0x28(Inherited: 0x0) 
struct FOnlineActivityTasksToResetBP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSet : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct TArray<struct FString> InProgressTasks;  // 0x8(0x10)
	struct TArray<struct FString> CompletedTasks;  // 0x18(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.ColumnMetaDataBP
// Size: 0xC(Inherited: 0x0) 
struct FColumnMetaDataBP
{
	struct FName ColumnName;  // 0x0(0x8)
	uint8_t  DataType;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemSanitizeDisplayNames.SanitizeDisplayNames
// Size: 0x20(Inherited: 0x0) 
struct FSanitizeDisplayNames
{
	struct UOnlineMessageSanitizerSubsystem* Subsystem;  // 0x0(0x8)
	struct TArray<struct FString> DisplayNames;  // 0x8(0x10)
	struct UOnlineMessageSanitizerSubsystemSanitizeDisplayNames* ReturnValue;  // 0x18(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineLobbySearchQueryFilterBP
// Size: 0x40(Inherited: 0x0) 
struct FOnlineLobbySearchQueryFilterBP
{
	struct FString Key;  // 0x0(0x10)
	struct FVariantDataBP Value;  // 0x10(0x28)
	uint8_t  Comparison;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// ScriptStruct OnlineSubsystemBlueprints.RedeemCodeRequestBP
// Size: 0x30(Inherited: 0x0) 
struct FRedeemCodeRequestBP
{
	struct FString Code;  // 0x0(0x10)
	struct FString CodeUseId;  // 0x10(0x10)
	struct FString FulfillmentSource;  // 0x20(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMemberData
// Size: 0x78(Inherited: 0x0) 
struct FGetPartyMemberData
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	struct FName Namespace;  // 0x68(0x8)
	struct UReadablePartyData* ReturnValue;  // 0x70(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.LineItemInfoBP
// Size: 0x30(Inherited: 0x0) 
struct FLineItemInfoBP
{
	struct FString ItemName;  // 0x0(0x10)
	struct FString UniqueId;  // 0x10(0x10)
	struct FString ValidationInfo;  // 0x20(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.NotifyLoginRedirectURL
// Size: 0x58(Inherited: 0x0) 
struct FNotifyLoginRedirectURL
{
	int32_t RequestId;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString URL;  // 0x8(0x10)
	struct FLoginFlowResultBP ReturnValue;  // 0x18(0x40)

}; 
// ScriptStruct OnlineSubsystemBlueprints.NamedOnlineSessionBP
// Size: 0x1F8(Inherited: 0x1A0) 
struct FNamedOnlineSessionBP : public FOnlineSessionBP
{
	struct FName SessionName;  // 0x1A0(0x8)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool bHosting : 1;  // 0x1A8(0x1)
	char pad_425[7];  // 0x1A9(0x7)
	struct FUniqueNetIdRepl LocalOwnerId;  // 0x1B0(0x30)
	struct TArray<struct FUniqueNetIdRepl> RegisteredPlayers;  // 0x1E0(0x10)
	uint8_t  SessionState;  // 0x1F0(0x1)
	char pad_497[7];  // 0x1F1(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemAvailabilityChange.ItemAvailabilityChange
// Size: 0x60(Inherited: 0x0) 
struct FItemAvailabilityChange
{
	struct UOnlineGameItemStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TArray<struct FString> AvailableItems;  // 0x38(0x10)
	struct TArray<struct FString> UnavailableItems;  // 0x48(0x10)
	struct UOnlineGameItemStatsSubsystemItemAvailabilityChange* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetDisplayRegularPrice
// Size: 0x18(Inherited: 0x0) 
struct FGetDisplayRegularPrice
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function OnlineSubsystemBlueprints.OnlineStatsSubsystemQueryStats.QueryStats
// Size: 0x60(Inherited: 0x0) 
struct FQueryStats
{
	struct UOnlineStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TArray<struct FUniqueNetIdRepl> StatUsers;  // 0x38(0x10)
	struct TArray<struct FString> StatNames;  // 0x48(0x10)
	struct UOnlineStatsSubsystemQueryStats* ReturnValue;  // 0x58(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.SessionSearchParamBP
// Size: 0x30(Inherited: 0x0) 
struct FSessionSearchParamBP
{
	struct FVariantDataBP Data;  // 0x0(0x28)
	uint8_t  Op;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	int32_t ID;  // 0x2C(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineTimeSubsystem.GetLastServerUtcTime
// Size: 0x10(Inherited: 0x0) 
struct FGetLastServerUtcTime
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineStatUpdateBP
// Size: 0x30(Inherited: 0x0) 
struct FOnlineStatUpdateBP
{
	uint8_t  Type;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FVariantDataBP Value;  // 0x8(0x28)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowAchievementsUI
// Size: 0x8(Inherited: 0x0) 
struct FShowAchievementsUI
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineStatsUserUpdatedStatsBP
// Size: 0x80(Inherited: 0x0) 
struct FOnlineStatsUserUpdatedStatsBP
{
	struct FUniqueNetIdRepl PlayerId;  // 0x0(0x30)
	struct TMap<struct FString, struct FOnlineStatUpdateBP> Stats;  // 0x30(0x50)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetPlayerMuted
// Size: 0x18(Inherited: 0x0) 
struct FSetPlayerMuted
{
	struct FString PlayerName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bMuted : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineStoreCategoryBP
// Size: 0x28(Inherited: 0x0) 
struct FOnlineStoreCategoryBP
{
	struct FString ID;  // 0x0(0x10)
	struct FText Description;  // 0x10(0x18)

}; 
// ScriptStruct OnlineSubsystemBlueprints.OnlineStoreFilterBP
// Size: 0x30(Inherited: 0x0) 
struct FOnlineStoreFilterBP
{
	struct TArray<struct FString> Keywords;  // 0x0(0x10)
	struct TArray<struct FOnlineStoreCategoryBP> IncludeCategories;  // 0x10(0x10)
	struct TArray<struct FOnlineStoreCategoryBP> ExcludeCategories;  // 0x20(0x10)

}; 
// ScriptStruct OnlineSubsystemBlueprints.VoiceChatDeviceInfoBP
// Size: 0x20(Inherited: 0x0) 
struct FVoiceChatDeviceInfoBP
{
	struct FString DisplayName;  // 0x0(0x10)
	struct FString ID;  // 0x10(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemGetUserPrivilege.GetUserPrivilege
// Size: 0x48(Inherited: 0x0) 
struct FGetUserPrivilege
{
	struct UOnlineIdentitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	uint8_t  Privilege;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UOnlineIdentitySubsystemGetUserPrivilege* ReturnValue;  // 0x40(0x8)

}; 
// ScriptStruct OnlineSubsystemBlueprints.VoiceChatChannel3dPropertiesBP
// Size: 0x10(Inherited: 0x0) 
struct FVoiceChatChannel3dPropertiesBP
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSet : 1;  // 0x0(0x1)
	uint8_t  AttenuationModel;  // 0x1(0x1)
	char pad_2[2];  // 0x2(0x2)
	float MinDistance;  // 0x4(0x4)
	float MaxDistance;  // 0x8(0x4)
	float Rolloff;  // 0xC(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetDisplayPrice
// Size: 0x18(Inherited: 0x0) 
struct FGetDisplayPrice
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystem.GetCachedAchievement
// Size: 0x60(Inherited: 0x0) 
struct FGetCachedAchievement
{
	struct FUniqueNetIdRepl PlayerId;  // 0x0(0x30)
	struct FString AchievementId;  // 0x30(0x10)
	struct FOnlineAchievementBP OutAchievement;  // 0x40(0x18)
	uint8_t  ReturnValue;  // 0x58(0x1)
	char pad_89[7];  // 0x59(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystem.GetCachedAchievements
// Size: 0x48(Inherited: 0x0) 
struct FGetCachedAchievements
{
	struct FUniqueNetIdRepl PlayerId;  // 0x0(0x30)
	struct TArray<struct FOnlineAchievementBP> OutAchievements;  // 0x30(0x10)
	uint8_t  ReturnValue;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystemWriteAchievements.WriteAchievements
// Size: 0x48(Inherited: 0x0) 
struct FWriteAchievements
{
	struct UOnlineAchievementsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl PlayerId;  // 0x8(0x30)
	struct UOnlineAchievementsWrite* WriteObject;  // 0x38(0x8)
	struct UOnlineAchievementsSubsystemWriteAchievements* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievements.QueryAchievements
// Size: 0x40(Inherited: 0x0) 
struct FQueryAchievements
{
	struct UOnlineAchievementsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl PlayerId;  // 0x8(0x30)
	struct UOnlineAchievementsSubsystemQueryAchievements* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineAchievementsSubsystemQueryAchievementDescriptions.QueryAchievementDescriptions
// Size: 0x40(Inherited: 0x0) 
struct FQueryAchievementDescriptions
{
	struct UOnlineAchievementsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl PlayerId;  // 0x8(0x30)
	struct UOnlineAchievementsSubsystemQueryAchievementDescriptions* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemReadFriendsList.ReadFriendsList
// Size: 0x28(Inherited: 0x0) 
struct FReadFriendsList
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString ListName;  // 0x10(0x10)
	struct UOnlineFriendsSubsystemReadFriendsList* ReturnValue;  // 0x20(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineAvatarSubsystemGetAvatar.GetAvatar
// Size: 0x78(Inherited: 0x0) 
struct FGetAvatar
{
	struct UOnlineAvatarSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FUniqueNetIdRepl TargetUserId;  // 0x38(0x30)
	struct UTexture* DefaultTexture;  // 0x68(0x8)
	struct UOnlineAvatarSubsystemGetAvatar* ReturnValue;  // 0x70(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineChatSubsystem.ExitRoom
// Size: 0x48(Inherited: 0x0) 
struct FExitRoom
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString RoomId;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineChatSubsystem.GetJoinedRooms
// Size: 0x40(Inherited: 0x0) 
struct FGetJoinedRooms
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct TArray<struct FString> OutRooms;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineChatSubsystem.IsChatAllowed
// Size: 0x68(Inherited: 0x0) 
struct FIsChatAllowed
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl RecipientId;  // 0x30(0x30)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.ToDebugString
// Size: 0x10(Inherited: 0x0) 
struct FToDebugString
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineChatSubsystem.SendRoomChat
// Size: 0x58(Inherited: 0x0) 
struct FSendRoomChat
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString RoomId;  // 0x30(0x10)
	struct FString MsgBody;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.GetResolvedConnectStringBySearchResult
// Size: 0x1D0(Inherited: 0x0) 
struct FGetResolvedConnectStringBySearchResult
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FOnlineSessionSearchResultBP SearchResult;  // 0x8(0x1A8)
	struct FName PortType;  // 0x1B0(0x8)
	char pad_440_1 : 7;  // 0x1B8(0x1)
	bool bWasSuccessful : 1;  // 0x1B8(0x1)
	char pad_441[7];  // 0x1B9(0x7)
	struct FString OutConnectInfo;  // 0x1C0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemLoadoutChange.ItemLoadoutChange
// Size: 0x60(Inherited: 0x0) 
struct FItemLoadoutChange
{
	struct UOnlineGameItemStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TArray<struct FString> EquippedItems;  // 0x38(0x10)
	struct TArray<struct FString> UnequippedItems;  // 0x48(0x10)
	struct UOnlineGameItemStatsSubsystemItemLoadoutChange* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePresenceSubsystemQueryPresence.QueryPresence
// Size: 0x40(Inherited: 0x0) 
struct FQueryPresence
{
	struct UOnlinePresenceSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl User;  // 0x8(0x30)
	struct UOnlinePresenceSubsystemQueryPresence* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlementsSubsystem.GetAllEntitlements
// Size: 0x50(Inherited: 0x0) 
struct FGetAllEntitlements
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Namespace;  // 0x30(0x10)
	struct TArray<struct UOnlineEntitlement*> OutUserEntitlements;  // 0x40(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryFriendSettings.QueryFriendSettings
// Size: 0x40(Inherited: 0x0) 
struct FQueryFriendSettings
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UOnlineFriendsSubsystemQueryFriendSettings* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.MakeUpdateLobbyTransaction
// Size: 0x40(Inherited: 0x0) 
struct FMakeUpdateLobbyTransaction
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	struct UOnlineLobbyTransaction* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlementsSubsystem.GetEntitlement
// Size: 0x48(Inherited: 0x0) 
struct FGetEntitlement
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString EntitlementId;  // 0x30(0x10)
	struct UOnlineEntitlement* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemJoinParty.JoinParty
// Size: 0x48(Inherited: 0x0) 
struct FJoinParty
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UOnlinePartyJoinInfo* OnlinePartyJoinInfo;  // 0x38(0x8)
	struct UOnlinePartySubsystemJoinParty* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlementsSubsystemQueryEntitlements.QueryEntitlements
// Size: 0x58(Inherited: 0x0) 
struct FQueryEntitlements
{
	struct UOnlineEntitlementsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Namespace;  // 0x38(0x10)
	struct FPagedQueryBP Page;  // 0x48(0x8)
	struct UOnlineEntitlementsSubsystemQueryEntitlements* ReturnValue;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.AddLoginFlowHandler
// Size: 0x10(Inherited: 0x0) 
struct FAddLoginFlowHandler
{
	struct TScriptInterface<IExternalUIFlowHandler> Handler;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.RemoveLoginFlowHandler
// Size: 0x10(Inherited: 0x0) 
struct FRemoveLoginFlowHandler
{
	struct TScriptInterface<IExternalUIFlowHandler> Handler;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowFriendsUI
// Size: 0x8(Inherited: 0x0) 
struct FShowFriendsUI
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowInviteUI
// Size: 0x10(Inherited: 0x0) 
struct FShowInviteUI
{
	int32_t LocalUserNum;  // 0x0(0x4)
	struct FName SessionName;  // 0x4(0x8)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool ReturnValue : 1;  // 0xC(0x1)
	char pad_13[3];  // 0xD(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystem.ShowLeaderboardUI
// Size: 0x18(Inherited: 0x0) 
struct FShowLeaderboardUI
{
	struct FString LeaderboardName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.DumpCloudFileState
// Size: 0x40(Inherited: 0x0) 
struct FDumpCloudFileState
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Filename;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowLoginUI.ShowLoginUI
// Size: 0x18(Inherited: 0x0) 
struct FShowLoginUI
{
	struct UOnlineExternalUISubsystem* Subsystem;  // 0x0(0x8)
	int32_t ControllerIndex;  // 0x8(0x4)
	char pad_12_1 : 7;  // 0xC(0x1)
	bool bShowOnlineOnly : 1;  // 0xC(0x1)
	char pad_13_1 : 7;  // 0xD(0x1)
	bool bShowSkipButton : 1;  // 0xD(0x1)
	char pad_14[2];  // 0xE(0x2)
	struct UOnlineExternalUISubsystemShowLoginUI* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowAccountCreationUI.ShowAccountCreationUI
// Size: 0x18(Inherited: 0x0) 
struct FShowAccountCreationUI
{
	struct UOnlineExternalUISubsystem* Subsystem;  // 0x0(0x8)
	int32_t ControllerIndex;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UOnlineExternalUISubsystemShowAccountCreationUI* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowWebURL.ShowWebURL
// Size: 0x58(Inherited: 0x0) 
struct FShowWebURL
{
	struct UOnlineExternalUISubsystem* Subsystem;  // 0x0(0x8)
	struct FString URL;  // 0x8(0x10)
	struct FShowWebUrlParameters ShowParams;  // 0x18(0x38)
	struct UOnlineExternalUISubsystemShowWebURL* ReturnValue;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.UnblockPlayers
// Size: 0x10(Inherited: 0x0) 
struct FUnblockPlayers
{
	struct TArray<struct FString> PlayerNames;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.SetMetadataByMap
// Size: 0x50(Inherited: 0x0) 
struct FSetMetadataByMap
{
	struct TMap<struct FString, struct FVariantDataBP> MetaData;  // 0x0(0x50)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowProfileUI.ShowProfileUI
// Size: 0x70(Inherited: 0x0) 
struct FShowProfileUI
{
	struct UOnlineExternalUISubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl Requestor;  // 0x8(0x30)
	struct FUniqueNetIdRepl Requestee;  // 0x38(0x30)
	struct UOnlineExternalUISubsystemShowProfileUI* ReturnValue;  // 0x68(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineExternalUISubsystemShowSendMessageToUserUI.ShowSendMessageToUserUI
// Size: 0x138(Inherited: 0x0) 
struct FShowSendMessageToUserUI
{
	struct UOnlineExternalUISubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl Recipient;  // 0x10(0x30)
	struct FShowSendMessageParameters ShowParams;  // 0x40(0xF0)
	struct UOnlineExternalUISubsystemShowSendMessageToUserUI* ReturnValue;  // 0x130(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemUnregisterPlayers.UnregisterPlayers
// Size: 0x28(Inherited: 0x0) 
struct FUnregisterPlayers
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FName SessionName;  // 0x8(0x8)
	struct TArray<struct FUniqueNetIdRepl> Players;  // 0x10(0x10)
	struct UOnlineSessionSubsystemUnregisterPlayers* ReturnValue;  // 0x20(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetFriend
// Size: 0x50(Inherited: 0x0) 
struct FGetFriend
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x8(0x30)
	struct FString ListName;  // 0x38(0x10)
	struct UOnlineFriendRef* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetFriendSettings
// Size: 0x88(Inherited: 0x0) 
struct FGetFriendSettings
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct TMap<struct FString, struct FOnlineFriendSettingsSourceDataConfig> OutSettings;  // 0x30(0x50)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool ReturnValue : 1;  // 0x80(0x1)
	char pad_129[7];  // 0x81(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetFriendsList
// Size: 0x30(Inherited: 0x0) 
struct FGetFriendsList
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ListName;  // 0x8(0x10)
	struct TArray<struct UOnlineFriendRef*> OutFriends;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool ReturnValue : 1;  // 0x28(0x1)
	char pad_41[7];  // 0x29(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem.FreeStats
// Size: 0x8(Inherited: 0x0) 
struct FFreeStats
{
	struct UOnlineLeaderboardRead* ReadObject;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystem.GetRecentPlayers
// Size: 0x58(Inherited: 0x0) 
struct FGetRecentPlayers
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Namespace;  // 0x30(0x10)
	struct TArray<struct UOnlineRecentPlayerRef*> OutRecentPlayers;  // 0x40(0x10)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool ReturnValue : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendsList.DeleteFriendsList
// Size: 0x28(Inherited: 0x0) 
struct FDeleteFriendsList
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString ListName;  // 0x10(0x10)
	struct UOnlineFriendsSubsystemDeleteFriendsList* ReturnValue;  // 0x20(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemSendInvite.SendInvite
// Size: 0x58(Inherited: 0x0) 
struct FSendInvite
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x10(0x30)
	struct FString ListName;  // 0x40(0x10)
	struct UOnlineFriendsSubsystemSendInvite* ReturnValue;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetNumSessions
// Size: 0x4(Inherited: 0x0) 
struct FGetNumSessions
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemAcceptInvite.AcceptInvite
// Size: 0x58(Inherited: 0x0) 
struct FAcceptInvite
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x10(0x30)
	struct FString ListName;  // 0x40(0x10)
	struct UOnlineFriendsSubsystemAcceptInvite* ReturnValue;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendAlias.SetFriendAlias
// Size: 0x68(Inherited: 0x0) 
struct FSetFriendAlias
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x10(0x30)
	struct FString ListName;  // 0x40(0x10)
	struct FString Alias;  // 0x50(0x10)
	struct UOnlineFriendsSubsystemSetFriendAlias* ReturnValue;  // 0x60(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemDeleteFriendAlias.DeleteFriendAlias
// Size: 0x58(Inherited: 0x0) 
struct FDeleteFriendAlias
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl FriendId;  // 0x10(0x30)
	struct FString ListName;  // 0x40(0x10)
	struct UOnlineFriendsSubsystemDeleteFriendAlias* ReturnValue;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemAddRecentPlayers.AddRecentPlayers
// Size: 0x60(Inherited: 0x0) 
struct FAddRecentPlayers
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct TArray<struct FReportPlayedWithUserInfo> InRecentPlayers;  // 0x38(0x10)
	struct FString ListName;  // 0x48(0x10)
	struct UOnlineFriendsSubsystemAddRecentPlayers* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryRecentPlayers.QueryRecentPlayers
// Size: 0x50(Inherited: 0x0) 
struct FQueryRecentPlayers
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Namespace;  // 0x38(0x10)
	struct UOnlineFriendsSubsystemQueryRecentPlayers* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemQueryBlockedPlayers.QueryBlockedPlayers
// Size: 0x40(Inherited: 0x0) 
struct FQueryBlockedPlayers
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct UOnlineFriendsSubsystemQueryBlockedPlayers* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendsSubsystemSetFriendSettings.SetFriendSettings
// Size: 0x58(Inherited: 0x0) 
struct FSetFriendSettings
{
	struct UOnlineFriendsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Source;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bNeverShowAgain : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UOnlineFriendsSubsystemSetFriendSettings* ReturnValue;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemStartActivity.StartActivity
// Size: 0xA0(Inherited: 0x0) 
struct FStartActivity
{
	struct UOnlineGameActivitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ActivityId;  // 0x38(0x10)
	struct TMap<struct FString, struct FVariantDataBP> Params;  // 0x48(0x50)
	struct UOnlineGameActivitySubsystemStartActivity* ReturnValue;  // 0x98(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemEndActivity.EndActivity
// Size: 0xA8(Inherited: 0x0) 
struct FEndActivity
{
	struct UOnlineGameActivitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ActivityId;  // 0x38(0x10)
	uint8_t  ActivityOutcome;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct TMap<struct FString, struct FVariantDataBP> Params;  // 0x50(0x50)
	struct UOnlineGameActivitySubsystemEndActivity* ReturnValue;  // 0xA0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemResumeActivity.ResumeActivity
// Size: 0x78(Inherited: 0x0) 
struct FResumeActivity
{
	struct UOnlineGameActivitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ActivityId;  // 0x38(0x10)
	struct FOnlineActivityTasksToResetBP TasksToReset;  // 0x48(0x28)
	struct UOnlineGameActivitySubsystemResumeActivity* ReturnValue;  // 0x70(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityAvailability.SetActivityAvailability
// Size: 0x58(Inherited: 0x0) 
struct FSetActivityAvailability
{
	struct UOnlineGameActivitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ActivityId;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool bEnabled : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)
	struct UOnlineGameActivitySubsystemSetActivityAvailability* ReturnValue;  // 0x50(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.Conv_ULobbyIdToUOnlinePartyJoinInfo
// Size: 0x48(Inherited: 0x0) 
struct FConv_ULobbyIdToUOnlinePartyJoinInfo
{
	struct FUniqueNetIdRepl InLocalUserId;  // 0x0(0x30)
	struct UOnlinePartySubsystem* InPartySubsystem;  // 0x30(0x8)
	struct ULobbyId* InLobbyId;  // 0x38(0x8)
	struct UOnlinePartyJoinInfo* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemRestoreInvites.RestoreInvites
// Size: 0x40(Inherited: 0x0) 
struct FRestoreInvites
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UOnlinePartySubsystemRestoreInvites* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameActivitySubsystemSetActivityPriority.SetActivityPriority
// Size: 0x90(Inherited: 0x0) 
struct FSetActivityPriority
{
	struct UOnlineGameActivitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TMap<struct FString, int32_t> PrioritizedActivities;  // 0x38(0x50)
	struct UOnlineGameActivitySubsystemSetActivityPriority* ReturnValue;  // 0x88(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.EqualEqual_FUniqueNetIdReplFUniqueNetIdRepl
// Size: 0x68(Inherited: 0x0) 
struct FEqualEqual_FUniqueNetIdReplFUniqueNetIdRepl
{
	struct FUniqueNetIdRepl InA;  // 0x0(0x30)
	struct FUniqueNetIdRepl InB;  // 0x30(0x30)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemImpact.ItemImpact
// Size: 0x70(Inherited: 0x0) 
struct FItemImpact
{
	struct UOnlineGameItemStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TArray<struct FString> TargetActors;  // 0x38(0x10)
	struct FString ImpactInitiatedBy;  // 0x48(0x10)
	struct TArray<struct FString> ItemsUsed;  // 0x58(0x10)
	struct UOnlineGameItemStatsSubsystemItemImpact* ReturnValue;  // 0x68(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedPresenceSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedPresenceSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlinePresenceSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystemRedeemCode.RedeemCode
// Size: 0x70(Inherited: 0x0) 
struct FRedeemCode
{
	struct UOnlinePurchaseSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FRedeemCodeRequestBP RedeemCodeRequest;  // 0x38(0x30)
	struct UOnlinePurchaseSubsystemRedeemCode* ReturnValue;  // 0x68(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineGameItemStatsSubsystemItemMitigation.ItemMitigation
// Size: 0x70(Inherited: 0x0) 
struct FItemMitigation
{
	struct UOnlineGameItemStatsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct TArray<struct FString> ItemsUsed;  // 0x38(0x10)
	struct TArray<struct FString> ImpactItemsMitigated;  // 0x48(0x10)
	struct FString ItemUsedBy;  // 0x58(0x10)
	struct UOnlineGameItemStatsSubsystemItemMitigation* ReturnValue;  // 0x68(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.Conv_FUniqueNetIdReplToString
// Size: 0x40(Inherited: 0x0) 
struct FConv_FUniqueNetIdReplToString
{
	struct FUniqueNetIdRepl InNetId;  // 0x0(0x30)
	struct FString ReturnValue;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.IsLoggedIn
// Size: 0x1(Inherited: 0x0) 
struct FIsLoggedIn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateMemberSelf.UpdateMemberSelf
// Size: 0x50(Inherited: 0x0) 
struct FUpdateMemberSelf
{
	struct UOnlineLobbySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct ULobbyId* LobbyId;  // 0x38(0x8)
	struct UOnlineLobbyMemberTransaction* Transaction;  // 0x40(0x8)
	struct UOnlineLobbySubsystemUpdateMemberSelf* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.CreateFileDataFromSaveGame
// Size: 0x10(Inherited: 0x0) 
struct FCreateFileDataFromSaveGame
{
	struct USaveGame* SaveGame;  // 0x0(0x8)
	struct UFileData* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreV2Subsystem.GetCategories
// Size: 0x10(Inherited: 0x0) 
struct FGetCategories
{
	struct TArray<struct FOnlineStoreCategoryBP> OutCategories;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.CreateMutablePartyData
// Size: 0x10(Inherited: 0x0) 
struct FCreateMutablePartyData
{
	struct UReadablePartyData* ReadOnlyPartyData;  // 0x0(0x8)
	struct UMutablePartyData* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.GetControllerUniqueNetId
// Size: 0x38(Inherited: 0x0) 
struct FGetControllerUniqueNetId
{
	struct APlayerController* PlayerController;  // 0x0(0x8)
	struct FUniqueNetIdRepl ReturnValue;  // 0x8(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.GetSourceUserId
// Size: 0x30(Inherited: 0x0) 
struct FGetSourceUserId
{
	struct FUniqueNetIdRepl ReturnValue;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.UpdatePartyData
// Size: 0x50(Inherited: 0x0) 
struct FUpdatePartyData
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FName Namespace;  // 0x38(0x8)
	struct UReadablePartyData* PartyData;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.GetCurrentSubsystemName
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrentSubsystemName
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct FName ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.GetPlayerStateUniqueNetId
// Size: 0x38(Inherited: 0x0) 
struct FGetPlayerStateUniqueNetId
{
	struct APlayerState* PlayerState;  // 0x0(0x8)
	struct FUniqueNetIdRepl ReturnValue;  // 0x8(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.GetPrimaryPartyType
// Size: 0x8(Inherited: 0x0) 
struct FGetPrimaryPartyType
{
	int64_t ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.IsValid_PartyId
// Size: 0x10(Inherited: 0x0) 
struct FIsValid_PartyId
{
	struct UPartyId* A;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedGroupsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedGroupsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineGroupsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineHelpers.ReadFileDataAsSaveGame
// Size: 0x10(Inherited: 0x0) 
struct FReadFileDataAsSaveGame
{
	struct UFileData* FileData;  // 0x0(0x8)
	struct USaveGame* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.MutablePartyData.RemoveAttribute
// Size: 0x10(Inherited: 0x0) 
struct FRemoveAttribute
{
	struct FString AttrName;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.ClearCachedAuthToken
// Size: 0x30(Inherited: 0x0) 
struct FClearCachedAuthToken
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.CreateUniquePlayerId
// Size: 0x40(Inherited: 0x0) 
struct FCreateUniquePlayerId
{
	struct FString Str;  // 0x0(0x10)
	struct FUniqueNetIdRepl ReturnValue;  // 0x10(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetAllUserAccounts
// Size: 0x10(Inherited: 0x0) 
struct FGetAllUserAccounts
{
	struct TArray<struct UUserOnlineAccountRef*> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetAuthToken
// Size: 0x18(Inherited: 0x0) 
struct FGetAuthToken
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetLoginStatus
// Size: 0x8(Inherited: 0x0) 
struct FGetLoginStatus
{
	int32_t LocalUserNum;  // 0x0(0x4)
	uint8_t  ReturnValue;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.SendSessionInviteToFriend
// Size: 0x70(Inherited: 0x0) 
struct FSendSessionInviteToFriend
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FName SessionName;  // 0x30(0x8)
	struct FUniqueNetIdRepl Friend;  // 0x38(0x30)
	char pad_104_1 : 7;  // 0x68(0x1)
	bool ReturnValue : 1;  // 0x68(0x1)
	char pad_105[7];  // 0x69(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetPlatformUserIdFromUniqueNetId
// Size: 0x38(Inherited: 0x0) 
struct FGetPlatformUserIdFromUniqueNetId
{
	struct FUniqueNetIdRepl UniqueNetId;  // 0x0(0x30)
	int32_t ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetPlayerNickname
// Size: 0x40(Inherited: 0x0) 
struct FGetPlayerNickname
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString ReturnValue;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendRef.GetInviteStatus
// Size: 0x1(Inherited: 0x0) 
struct FGetInviteStatus
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.ClearFile
// Size: 0x48(Inherited: 0x0) 
struct FClearFile
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Filename;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetSponsorUniquePlayerId
// Size: 0x38(Inherited: 0x0) 
struct FGetSponsorUniquePlayerId
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl ReturnValue;  // 0x8(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetUniquePlayerId
// Size: 0x38(Inherited: 0x0) 
struct FGetUniquePlayerId
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl ReturnValue;  // 0x8(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPendingInvites
// Size: 0x48(Inherited: 0x0) 
struct FGetPendingInvites
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct TArray<struct UOnlinePartyJoinInfo*> OutPendingInvitesArray;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystem.GetUserAccount
// Size: 0x38(Inherited: 0x0) 
struct FGetUserAccount
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct UUserOnlineAccountRef* ReturnValue;  // 0x30(0x8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUserLogin.Login
// Size: 0x38(Inherited: 0x0) 
struct FLogin
{
	struct UVoiceChatUser* Subsystem;  // 0x0(0x8)
	int32_t PlatformId;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString PlayerName;  // 0x10(0x10)
	struct FString Credentials;  // 0x20(0x10)
	struct UVoiceChatUserLogin* ReturnValue;  // 0x30(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedMessageSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedMessageSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineMessageSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUserLogout.Logout
// Size: 0x10(Inherited: 0x0) 
struct FLogout
{
	struct UVoiceChatUser* Subsystem;  // 0x0(0x8)
	struct UVoiceChatUserLogout* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineIdentitySubsystemRevokeAuthToken.RevokeAuthToken
// Size: 0x40(Inherited: 0x0) 
struct FRevokeAuthToken
{
	struct UOnlineIdentitySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UOnlineIdentitySubsystemRevokeAuthToken* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSearch.GetSearchState
// Size: 0x1(Inherited: 0x0) 
struct FGetSearchState
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.IsConnected
// Size: 0x1(Inherited: 0x0) 
struct FIsConnected
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystem.WriteLeaderboards
// Size: 0x48(Inherited: 0x0) 
struct FWriteLeaderboards
{
	struct FName SessionName;  // 0x0(0x8)
	struct FUniqueNetIdRepl Player;  // 0x8(0x30)
	struct UOnlineLeaderboardWrite* WriteObject;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboards.ReadLeaderboards
// Size: 0x28(Inherited: 0x0) 
struct FReadLeaderboards
{
	struct UOnlineLeaderboardsSubsystem* Subsystem;  // 0x0(0x8)
	struct TArray<struct FUniqueNetIdRepl> Players;  // 0x8(0x10)
	struct UOnlineLeaderboardRead* ReadObject;  // 0x18(0x8)
	struct UOnlineLeaderboardsSubsystemReadLeaderboards* ReturnValue;  // 0x20(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsForFriends.ReadLeaderboardsForFriends
// Size: 0x20(Inherited: 0x0) 
struct FReadLeaderboardsForFriends
{
	struct UOnlineLeaderboardsSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct UOnlineLeaderboardRead* ReadObject;  // 0x10(0x8)
	struct UOnlineLeaderboardsSubsystemReadLeaderboardsForFriends* ReturnValue;  // 0x18(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardsSubsystemReadLeaderboardsAroundUser.ReadLeaderboardsAroundUser
// Size: 0x50(Inherited: 0x0) 
struct FReadLeaderboardsAroundUser
{
	struct UOnlineLeaderboardsSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl Player;  // 0x8(0x30)
	int64_t Range;  // 0x38(0x8)
	struct UOnlineLeaderboardRead* ReadObject;  // 0x40(0x8)
	struct UOnlineLeaderboardsSubsystemReadLeaderboardsAroundUser* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemWriteUserFile.WriteUserFile
// Size: 0x60(Inherited: 0x0) 
struct FWriteUserFile
{
	struct UOnlineUserCloudSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)
	struct UFileData* FileContents;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bCompressBeforeUpload : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)
	struct UOnlineUserCloudSubsystemWriteUserFile* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetLobbyMetadataValue
// Size: 0x78(Inherited: 0x0) 
struct FGetLobbyMetadataValue
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	struct FString MetadataKey;  // 0x38(0x10)
	struct FVariantDataBP OutMetadataValue;  // 0x48(0x28)
	char pad_112_1 : 7;  // 0x70(0x1)
	bool ReturnValue : 1;  // 0x70(0x1)
	char pad_113[7];  // 0x71(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetMemberCount
// Size: 0x40(Inherited: 0x0) 
struct FGetMemberCount
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	int32_t OutMemberCount;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool ReturnValue : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.GetMemberMetadataValue
// Size: 0xA8(Inherited: 0x0) 
struct FGetMemberMetadataValue
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	struct FString MetadataKey;  // 0x68(0x10)
	struct FVariantDataBP OutMetadataValue;  // 0x78(0x28)
	char pad_160_1 : 7;  // 0xA0(0x1)
	bool ReturnValue : 1;  // 0xA0(0x1)
	char pad_161[7];  // 0xA1(0x7)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.TransmitToSpecificChannel
// Size: 0x10(Inherited: 0x0) 
struct FTransmitToSpecificChannel
{
	struct FString ChannelName;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.MakeCreateLobbyTransaction
// Size: 0x38(Inherited: 0x0) 
struct FMakeCreateLobbyTransaction
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct UOnlineLobbyTransaction* ReturnValue;  // 0x30(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystem.MakeUpdateLobbyMemberTransaction
// Size: 0x70(Inherited: 0x0) 
struct FMakeUpdateLobbyMemberTransaction
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct ULobbyId* LobbyId;  // 0x30(0x8)
	struct FUniqueNetIdRepl MemberId;  // 0x38(0x30)
	struct UOnlineLobbyMemberTransaction* ReturnValue;  // 0x68(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystemReadFile.ReadFile
// Size: 0x20(Inherited: 0x0) 
struct FReadFile
{
	struct UOnlineTitleFileSubsystem* Subsystem;  // 0x0(0x8)
	struct FString Filename;  // 0x8(0x10)
	struct UOnlineTitleFileSubsystemReadFile* ReturnValue;  // 0x18(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystemCreateLobby.CreateLobby
// Size: 0x48(Inherited: 0x0) 
struct FCreateLobby
{
	struct UOnlineLobbySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct UOnlineLobbyTransaction* Transaction;  // 0x38(0x8)
	struct UOnlineLobbySubsystemCreateLobby* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystemUpdateLobby.UpdateLobby
// Size: 0x50(Inherited: 0x0) 
struct FUpdateLobby
{
	struct UOnlineLobbySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct ULobbyId* LobbyId;  // 0x38(0x8)
	struct UOnlineLobbyTransaction* Transaction;  // 0x40(0x8)
	struct UOnlineLobbySubsystemUpdateLobby* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystemDeleteLobby.DeleteLobby
// Size: 0x48(Inherited: 0x0) 
struct FDeleteLobby
{
	struct UOnlineLobbySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct ULobbyId* LobbyId;  // 0x38(0x8)
	struct UOnlineLobbySubsystemDeleteLobby* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystemDisconnectLobby.DisconnectLobby
// Size: 0x48(Inherited: 0x0) 
struct FDisconnectLobby
{
	struct UOnlineLobbySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct ULobbyId* LobbyId;  // 0x38(0x8)
	struct UOnlineLobbySubsystemDisconnectLobby* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbySubsystemSearch.Search
// Size: 0x60(Inherited: 0x0) 
struct FSearch
{
	struct UOnlineLobbySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FOnlineLobbySearchQueryBP Query;  // 0x38(0x20)
	struct UOnlineLobbySubsystemSearch* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemKickMember.KickMember
// Size: 0x78(Inherited: 0x0) 
struct FKickMember
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UPartyId* PartyId;  // 0x38(0x8)
	struct FUniqueNetIdRepl TargetMemberId;  // 0x40(0x30)
	struct UOnlinePartySubsystemKickMember* ReturnValue;  // 0x70(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineMessageSanitizerSubsystemQueryBlockedUser.QueryBlockedUser
// Size: 0x38(Inherited: 0x0) 
struct FQueryBlockedUser
{
	struct UOnlineMessageSanitizerSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FString FromUserId;  // 0x10(0x10)
	struct FString FromPlatform;  // 0x20(0x10)
	struct UOnlineMessageSanitizerSubsystemQueryBlockedUser* ReturnValue;  // 0x30(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTournamentSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedTournamentSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineTournamentSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineMessageSubsystem.ClearMessages
// Size: 0x8(Inherited: 0x0) 
struct FClearMessages
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineMessageSubsystem.EnumerateMessages
// Size: 0x8(Inherited: 0x0) 
struct FEnumerateMessages
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4_1 : 7;  // 0x4(0x1)
	bool ReturnValue : 1;  // 0x4(0x1)
	char pad_5[3];  // 0x5(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetJoinedParties
// Size: 0x48(Inherited: 0x0) 
struct FGetJoinedParties
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct TArray<struct UPartyId*> OutPartyIdArray;  // 0x30(0x10)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool ReturnValue : 1;  // 0x40(0x1)
	char pad_65[7];  // 0x41(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetParty
// Size: 0x40(Inherited: 0x0) 
struct FGetParty
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct UParty* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyData
// Size: 0x48(Inherited: 0x0) 
struct FGetPartyData
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct FName Namespace;  // 0x38(0x8)
	struct UReadablePartyData* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.GetPartyMembers
// Size: 0x50(Inherited: 0x0) 
struct FGetPartyMembers
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct UPartyId* PartyId;  // 0x30(0x8)
	struct TArray<struct UBlueprintPartyMember*> OutPartyMembersArray;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.MakeTokenFromJoinInfo
// Size: 0x18(Inherited: 0x0) 
struct FMakeTokenFromJoinInfo
{
	struct UOnlinePartyJoinInfo* JoinInfo;  // 0x0(0x8)
	struct FString ReturnValue;  // 0x8(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystem.RejectInvitation
// Size: 0x68(Inherited: 0x0) 
struct FRejectInvitation
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FUniqueNetIdRepl SenderId;  // 0x30(0x30)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool ReturnValue : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystemCheckout.Checkout
// Size: 0x60(Inherited: 0x0) 
struct FCheckout
{
	struct UOnlinePurchaseSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FPurchaseCheckoutRequestBP CheckoutRequest;  // 0x38(0x20)
	struct UOnlinePurchaseSubsystemCheckout* ReturnValue;  // 0x58(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemCleanupParties.CleanupParties
// Size: 0x40(Inherited: 0x0) 
struct FCleanupParties
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UOnlinePartySubsystemCleanupParties* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemSendInvitation.SendInvitation
// Size: 0x78(Inherited: 0x0) 
struct FSendInvitation
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct UPartyId* PartyId;  // 0x38(0x8)
	struct FUniqueNetIdRepl Recipient;  // 0x40(0x30)
	struct UOnlinePartySubsystemSendInvitation* ReturnValue;  // 0x70(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartySubsystemCancelInvitation.CancelInvitation
// Size: 0x78(Inherited: 0x0) 
struct FCancelInvitation
{
	struct UOnlinePartySubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FUniqueNetIdRepl TargetUserId;  // 0x38(0x30)
	struct UPartyId* PartyId;  // 0x68(0x8)
	struct UOnlinePartySubsystemCancelInvitation* ReturnValue;  // 0x70(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePresenceSubsystemSetPresence.SetPresence
// Size: 0xA8(Inherited: 0x0) 
struct FSetPresence
{
	struct UOnlinePresenceSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl User;  // 0x8(0x30)
	struct FOnlineUserPresenceStatusData Status;  // 0x38(0x68)
	struct UOnlinePresenceSubsystemSetPresence* ReturnValue;  // 0xA0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystem.FinalizePurchase
// Size: 0x50(Inherited: 0x0) 
struct FFinalizePurchase
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString ReceiptId;  // 0x30(0x10)
	struct FString ReceiptInfo;  // 0x40(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystem.GetReceipts
// Size: 0x40(Inherited: 0x0) 
struct FGetReceipts
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct TArray<struct UPurchaseReceipt*> OutReceipts;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystem.IsAllowedToPurchase
// Size: 0x38(Inherited: 0x0) 
struct FIsAllowedToPurchase
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePurchaseSubsystemQueryReceipts.QueryReceipts
// Size: 0x48(Inherited: 0x0) 
struct FQueryReceipts
{
	struct UOnlinePurchaseSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bRestoreReceipts : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)
	struct UOnlinePurchaseSubsystemQueryReceipts* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetNamedSession
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedSession
{
	struct FName SessionName;  // 0x0(0x8)
	struct UNamedOnlineSession* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetInputDeviceId
// Size: 0x10(Inherited: 0x0) 
struct FSetInputDeviceId
{
	struct FString InputDeviceId;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.GetSessionState
// Size: 0xC(Inherited: 0x0) 
struct FGetSessionState
{
	struct FName SessionName;  // 0x0(0x8)
	uint8_t  ReturnValue;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemStartSession.StartSession
// Size: 0x18(Inherited: 0x0) 
struct FStartSession
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FName SessionName;  // 0x8(0x8)
	struct UOnlineSessionSubsystemStartSession* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetAvailableInputDeviceInfos
// Size: 0x10(Inherited: 0x0) 
struct FGetAvailableInputDeviceInfos
{
	struct TArray<struct FVoiceChatDeviceInfoBP> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.IsPlayerInSession
// Size: 0x40(Inherited: 0x0) 
struct FIsPlayerInSession
{
	struct FName SessionName;  // 0x0(0x8)
	struct FUniqueNetIdRepl UniqueId;  // 0x8(0x30)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.RemoveNamedSession
// Size: 0x8(Inherited: 0x0) 
struct FRemoveNamedSession
{
	struct FName SessionName;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystem.SendSessionInviteToFriends
// Size: 0x50(Inherited: 0x0) 
struct FSendSessionInviteToFriends
{
	struct FUniqueNetIdRepl LocalUserId;  // 0x0(0x30)
	struct FName SessionName;  // 0x30(0x8)
	struct TArray<struct FUniqueNetIdRepl> Friends;  // 0x38(0x10)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemCreateSession.CreateSession
// Size: 0x188(Inherited: 0x0) 
struct FCreateSession
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl HostingPlayerId;  // 0x8(0x30)
	struct FName SessionName;  // 0x38(0x8)
	struct FOnlineSessionSettingsBP NewSessionSettings;  // 0x40(0x140)
	struct UOnlineSessionSubsystemCreateSession* ReturnValue;  // 0x180(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemUpdateSession.UpdateSession
// Size: 0x160(Inherited: 0x0) 
struct FUpdateSession
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FName SessionName;  // 0x8(0x8)
	struct FOnlineSessionSettingsBP UpdatedSessionSettings;  // 0x10(0x140)
	char pad_336_1 : 7;  // 0x150(0x1)
	bool bShouldRefreshOnlineData : 1;  // 0x150(0x1)
	char pad_337[7];  // 0x151(0x7)
	struct UOnlineSessionSubsystemUpdateSession* ReturnValue;  // 0x158(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemDestroySession.DestroySession
// Size: 0x18(Inherited: 0x0) 
struct FDestroySession
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FName SessionName;  // 0x8(0x8)
	struct UOnlineSessionSubsystemDestroySession* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemStartMatchmaking.StartMatchmaking
// Size: 0x170(Inherited: 0x0) 
struct FStartMatchmaking
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct TArray<struct FUniqueNetIdRepl> LocalPlayers;  // 0x8(0x10)
	struct FName SessionName;  // 0x18(0x8)
	struct FOnlineSessionSettingsBP NewSessionSettings;  // 0x20(0x140)
	struct UOnlineSessionSearch* SearchSettings;  // 0x160(0x8)
	struct UOnlineSessionSubsystemStartMatchmaking* ReturnValue;  // 0x168(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelMatchmaking.CancelMatchmaking
// Size: 0x48(Inherited: 0x0) 
struct FCancelMatchmaking
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl SearchingPlayerId;  // 0x8(0x30)
	struct FName SessionName;  // 0x38(0x8)
	struct UOnlineSessionSubsystemCancelMatchmaking* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessions.FindSessions
// Size: 0x48(Inherited: 0x0) 
struct FFindSessions
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl SearchingPlayerId;  // 0x8(0x30)
	struct UOnlineSessionSearch* SearchSettings;  // 0x38(0x8)
	struct UOnlineSessionSubsystemFindSessions* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemFindSessionById.FindSessionById
// Size: 0xB0(Inherited: 0x0) 
struct FFindSessionById
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl SearchingUserId;  // 0x8(0x30)
	struct FUniqueNetIdRepl SessionId;  // 0x38(0x30)
	struct FUniqueNetIdRepl FriendId;  // 0x68(0x30)
	struct FString UserData;  // 0x98(0x10)
	struct UOnlineSessionSubsystemFindSessionById* ReturnValue;  // 0xA8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadAllMatches.LoadAllMatches
// Size: 0x10(Inherited: 0x0) 
struct FLoadAllMatches
{
	struct UOnlineTurnBasedSubsystem* Subsystem;  // 0x0(0x8)
	struct UOnlineTurnBasedSubsystemLoadAllMatches* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemCancelFindSessions.CancelFindSessions
// Size: 0x10(Inherited: 0x0) 
struct FCancelFindSessions
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	struct UOnlineSessionSubsystemCancelFindSessions* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSubsystemFindFriendSession.FindFriendSession
// Size: 0x48(Inherited: 0x0) 
struct FFindFriendSession
{
	struct UOnlineSessionSubsystem* Subsystem;  // 0x0(0x8)
	int32_t LocalUserNum;  // 0x8(0x4)
	char pad_12[4];  // 0xC(0x4)
	struct FUniqueNetIdRepl Friend;  // 0x10(0x30)
	struct UOnlineSessionSubsystemFindFriendSession* ReturnValue;  // 0x40(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreV2Subsystem.GetOffer
// Size: 0x18(Inherited: 0x0) 
struct FGetOffer
{
	struct FString OfferId;  // 0x0(0x10)
	struct UOnlineStoreOffer* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedAvatarSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedAvatarSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineAvatarSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedChatSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedChatSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineChatSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedEventsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedEventsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineEventsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedFriendsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedFriendsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineFriendsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedGameItemStatsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedGameItemStatsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineGameItemStatsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedLobbySubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedLobbySubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineLobbySubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedIdentitySubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedIdentitySubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineIdentitySubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedLeaderboardsSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedLeaderboardsSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineLeaderboardsSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedPartySubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedPartySubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlinePartySubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedPurchaseSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedPurchaseSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlinePurchaseSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetOutputDeviceId
// Size: 0x10(Inherited: 0x0) 
struct FSetOutputDeviceId
{
	struct FString OutputDeviceId;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedSharedCloudSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedSharedCloudSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineSharedCloudSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemKickParticipant.KickParticipant
// Size: 0x80(Inherited: 0x0) 
struct FKickParticipant
{
	struct UOnlineVoiceAdminSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ChannelName;  // 0x38(0x10)
	struct FUniqueNetIdRepl TargetUserId;  // 0x48(0x30)
	struct UOnlineVoiceAdminSubsystemKickParticipant* ReturnValue;  // 0x78(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTimeSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedTimeSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineTimeSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.DeleteMetadataByArray
// Size: 0x10(Inherited: 0x0) 
struct FDeleteMetadataByArray
{
	struct TArray<struct FString> MetaDataKeys;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTitleFileSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedTitleFileSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineTitleFileSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedTurnBasedSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedTurnBasedSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineTurnBasedSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedUserCloudSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedUserCloudSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineUserCloudSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedUserSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedUserSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineUserSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSubsystem.GetNamedVoiceAdminSubsystem
// Size: 0x10(Inherited: 0x0) 
struct FGetNamedVoiceAdminSubsystem
{
	struct FName SubsystemName;  // 0x0(0x8)
	struct UOnlineVoiceAdminSubsystem* ReturnValue;  // 0x8(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineTimeSubsystem.QueryServerUtcTime
// Size: 0x1(Inherited: 0x0) 
struct FQueryServerUtcTime
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.ClearFiles
// Size: 0x38(Inherited: 0x0) 
struct FClearFiles
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystem.DeleteCachedFiles
// Size: 0x1(Inherited: 0x0) 
struct FDeleteCachedFiles
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bSkipEnumerated : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.GetFileContents
// Size: 0x50(Inherited: 0x0) 
struct FGetFileContents
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Filename;  // 0x30(0x10)
	struct UFileData* FileContents;  // 0x40(0x8)
	char pad_72_1 : 7;  // 0x48(0x1)
	bool ReturnValue : 1;  // 0x48(0x1)
	char pad_73[7];  // 0x49(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.UnregisterRemoteTalker
// Size: 0x38(Inherited: 0x0) 
struct FUnregisterRemoteTalker
{
	struct FUniqueNetIdRepl UniqueId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineTitleFileSubsystemEnumerateFiles.EnumerateFiles
// Size: 0x18(Inherited: 0x0) 
struct FEnumerateFiles
{
	struct UOnlineTitleFileSubsystem* Subsystem;  // 0x0(0x8)
	struct FPagedQueryBP Page;  // 0x8(0x8)
	struct UOnlineTitleFileSubsystemEnumerateFiles* ReturnValue;  // 0x10(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineTurnBasedSubsystemLoadMatchWithID.LoadMatchWithID
// Size: 0x20(Inherited: 0x0) 
struct FLoadMatchWithID
{
	struct UOnlineTurnBasedSubsystem* Subsystem;  // 0x0(0x8)
	struct FString MatchID;  // 0x8(0x10)
	struct UOnlineTurnBasedSubsystemLoadMatchWithID* ReturnValue;  // 0x18(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.CancelWriteUserFile
// Size: 0x40(Inherited: 0x0) 
struct FCancelWriteUserFile
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct FString Filename;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystem.GetUserFileList
// Size: 0x40(Inherited: 0x0) 
struct FGetUserFileList
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	struct TArray<struct FCloudFileHeaderBP> UserFiles;  // 0x30(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserCloudSubsystemReadUserFile.ReadUserFile
// Size: 0x50(Inherited: 0x0) 
struct FReadUserFile
{
	struct UOnlineUserCloudSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct FString Filename;  // 0x38(0x10)
	struct UOnlineUserCloudSubsystemReadUserFile* ReturnValue;  // 0x48(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetAllUserInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetAllUserInfo
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct TArray<struct UOnlineUserRef*> OutUsers;  // 0x8(0x10)
	char pad_24_1 : 7;  // 0x18(0x1)
	bool ReturnValue : 1;  // 0x18(0x1)
	char pad_25[7];  // 0x19(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetExternalIdMapping
// Size: 0x58(Inherited: 0x0) 
struct FGetExternalIdMapping
{
	struct FExternalIdQueryOptionsBP QueryOptions;  // 0x0(0x18)
	struct FString ExternalId;  // 0x18(0x10)
	struct FUniqueNetIdRepl ReturnValue;  // 0x28(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetExternalIdMappings
// Size: 0x38(Inherited: 0x0) 
struct FGetExternalIdMappings
{
	struct FExternalIdQueryOptionsBP QueryOptions;  // 0x0(0x18)
	struct TArray<struct FString> ExternalIds;  // 0x18(0x10)
	struct TArray<struct FUniqueNetIdRepl> OutIds;  // 0x28(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserSubsystem.GetUserInfo
// Size: 0x40(Inherited: 0x0) 
struct FGetUserInfo
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl UserId;  // 0x8(0x30)
	struct UOnlineUserRef* ReturnValue;  // 0x38(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceAdminSubsystemSetParticipantHardMute.SetParticipantHardMute
// Size: 0x88(Inherited: 0x0) 
struct FSetParticipantHardMute
{
	struct UOnlineVoiceAdminSubsystem* Subsystem;  // 0x0(0x8)
	struct FUniqueNetIdRepl LocalUserId;  // 0x8(0x30)
	struct FString ChannelName;  // 0x38(0x10)
	struct FUniqueNetIdRepl TargetUserId;  // 0x48(0x30)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bMuted : 1;  // 0x78(0x1)
	char pad_121[7];  // 0x79(0x7)
	struct UOnlineVoiceAdminSubsystemSetParticipantHardMute* ReturnValue;  // 0x80(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.CreateUser
// Size: 0x8(Inherited: 0x0) 
struct FCreateUser
{
	struct UVoiceChatUser* ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.Initialize_
// Size: 0x1(Inherited: 0x0) 
struct FInitialize_
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.IsConnecting
// Size: 0x1(Inherited: 0x0) 
struct FIsConnecting
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.IsInitialized
// Size: 0x1(Inherited: 0x0) 
struct FIsInitialized
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceChatSubsystem.Uninitialize_
// Size: 0x1(Inherited: 0x0) 
struct FUninitialize_
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.GetAmplitudeOfRemoteTalker
// Size: 0x38(Inherited: 0x0) 
struct FGetAmplitudeOfRemoteTalker
{
	struct FUniqueNetIdRepl PlayerId;  // 0x0(0x30)
	float ReturnValue;  // 0x30(0x4)
	char pad_52[4];  // 0x34(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.GetNumLocalTalkers
// Size: 0x4(Inherited: 0x0) 
struct FGetNumLocalTalkers
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsLocalPlayerTalking
// Size: 0x10(Inherited: 0x0) 
struct FIsLocalPlayerTalking
{
	int64_t LocalUserNum;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsMuted
// Size: 0x40(Inherited: 0x0) 
struct FIsMuted
{
	int64_t LocalUserNum;  // 0x0(0x8)
	struct FUniqueNetIdRepl UniqueId;  // 0x8(0x30)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool ReturnValue : 1;  // 0x38(0x1)
	char pad_57[7];  // 0x39(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.IsRemotePlayerTalking
// Size: 0x38(Inherited: 0x0) 
struct FIsRemotePlayerTalking
{
	struct FUniqueNetIdRepl UniqueId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool ReturnValue : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.PatchLocalTalkerOutputToEndpoint
// Size: 0x18(Inherited: 0x0) 
struct FPatchLocalTalkerOutputToEndpoint
{
	struct FString InDeviceName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.PatchRemoteTalkerOutputToEndpoint
// Size: 0x18(Inherited: 0x0) 
struct FPatchRemoteTalkerOutputToEndpoint
{
	struct FString InDeviceName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bMuteInGameOutput : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool ReturnValue : 1;  // 0x11(0x1)
	char pad_18[6];  // 0x12(0x6)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.StartNetworkedVoice
// Size: 0x4(Inherited: 0x0) 
struct FStartNetworkedVoice
{
	int32_t LocalUserNum;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.StopNetworkedVoice
// Size: 0x4(Inherited: 0x0) 
struct FStopNetworkedVoice
{
	int32_t LocalUserNum;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.UnmuteRemoteTalker
// Size: 0x40(Inherited: 0x0) 
struct FUnmuteRemoteTalker
{
	int32_t LocalUserNum;  // 0x0(0x4)
	char pad_4[4];  // 0x4(0x4)
	struct FUniqueNetIdRepl PlayerId;  // 0x8(0x30)
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bIsSystemWide : 1;  // 0x38(0x1)
	char pad_57_1 : 7;  // 0x39(0x1)
	bool ReturnValue : 1;  // 0x39(0x1)
	char pad_58[6];  // 0x3A(0x6)

}; 
// Function OnlineSubsystemBlueprints.OnlineVoiceSubsystem.UnregisterLocalTalker
// Size: 0x10(Inherited: 0x0) 
struct FUnregisterLocalTalker
{
	int64_t LocalUserNum;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool ReturnValue : 1;  // 0x8(0x1)
	char pad_9[7];  // 0x9(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineAchievementsWrite.SetAchievementProgress
// Size: 0xC(Inherited: 0x0) 
struct FSetAchievementProgress
{
	struct FName AchievementId;  // 0x0(0x8)
	float AchievementProgress;  // 0x8(0x4)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetItemId
// Size: 0x10(Inherited: 0x0) 
struct FGetItemId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineEntitlement.GetRemainingCount
// Size: 0x4(Inherited: 0x0) 
struct FGetRemainingCount
{
	int32_t ReturnValue;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.ExternalUIFlowHandler.OnCreateAccountFlowUIRequired
// Size: 0x20(Inherited: 0x0) 
struct FOnCreateAccountFlowUIRequired
{
	struct FString RequestedURL;  // 0x0(0x10)
	struct UOnlineExternalUISubsystem* ExternalUIContext;  // 0x10(0x8)
	int32_t RequestId;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function OnlineSubsystemBlueprints.ExternalUIFlowHandler.OnLoginFlowUIRequired
// Size: 0x20(Inherited: 0x0) 
struct FOnLoginFlowUIRequired
{
	struct FString RequestedURL;  // 0x0(0x10)
	struct UOnlineExternalUISubsystem* ExternalUIContext;  // 0x10(0x8)
	int32_t RequestId;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetDisplayName
// Size: 0x20(Inherited: 0x0) 
struct FGetDisplayName
{
	struct FString Platform;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetRealName
// Size: 0x10(Inherited: 0x0) 
struct FGetRealName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetUserAttribute
// Size: 0x28(Inherited: 0x0) 
struct FGetUserAttribute
{
	struct FString AttrName;  // 0x0(0x10)
	struct FString OutAttrValue;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetSetting
// Size: 0x20(Inherited: 0x0) 
struct FSetSetting
{
	struct FString Name;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)

}; 
// Function OnlineSubsystemBlueprints.BlueprintPartyMember.GetUserId
// Size: 0x30(Inherited: 0x0) 
struct FGetUserId
{
	struct FUniqueNetIdRepl ReturnValue;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineUserRef.SetUserLocalAttribute
// Size: 0x28(Inherited: 0x0) 
struct FSetUserLocalAttribute
{
	struct FString Key;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool Success : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlineFriendRef.GetPresence
// Size: 0xA8(Inherited: 0x0) 
struct FGetPresence
{
	struct FOnlineUserPresenceData ReturnValue;  // 0x0(0xA8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.FindPlayerRecord
// Size: 0xD0(Inherited: 0x0) 
struct FFindPlayerRecord
{
	struct FUniqueNetIdRepl UserId;  // 0x0(0x30)
	char pad_48_1 : 7;  // 0x30(0x1)
	bool OutFound : 1;  // 0x30(0x1)
	char pad_49[7];  // 0x31(0x7)
	struct FOnlineStatsRowBP ReturnValue;  // 0x38(0x98)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetColumns
// Size: 0x10(Inherited: 0x0) 
struct FGetColumns
{
	struct TArray<struct FColumnMetaDataBP> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetLeaderboardName
// Size: 0x8(Inherited: 0x0) 
struct FGetLeaderboardName
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetRows
// Size: 0x10(Inherited: 0x0) 
struct FGetRows
{
	struct TArray<struct FOnlineStatsRowBP> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.GetSortedColumn
// Size: 0x8(Inherited: 0x0) 
struct FGetSortedColumn
{
	struct FName ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.SetColumns
// Size: 0x10(Inherited: 0x0) 
struct FSetColumns
{
	struct TArray<struct FColumnMetaDataBP> InColumns;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.SetLeaderboardName
// Size: 0x8(Inherited: 0x0) 
struct FSetLeaderboardName
{
	struct FName LeaderboardName;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLeaderboardRead.SetSortedColumn
// Size: 0x8(Inherited: 0x0) 
struct FSetSortedColumn
{
	struct FName SortedColumn;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.Lobby.GetOwnerId
// Size: 0x30(Inherited: 0x0) 
struct FGetOwnerId
{
	struct FUniqueNetIdRepl ReturnValue;  // 0x0(0x30)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.DeleteMetadata
// Size: 0x10(Inherited: 0x0) 
struct FDeleteMetadata
{
	struct FString Key;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetCapacity
// Size: 0x8(Inherited: 0x0) 
struct FSetCapacity
{
	int64_t Capacity;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbyTransaction.SetLocked
// Size: 0x1(Inherited: 0x0) 
struct FSetLocked
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool Locked : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.OnlineLobbyMemberTransaction.SetMetadata
// Size: 0x38(Inherited: 0x0) 
struct FSetMetadata
{
	struct FString Key;  // 0x0(0x10)
	struct FVariantDataBP Value;  // 0x10(0x28)

}; 
// Function OnlineSubsystemBlueprints.OnlineRecentPlayerRef.GetLastSeen
// Size: 0x8(Inherited: 0x0) 
struct FGetLastSeen
{
	struct FDateTime ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.UserOnlineAccountRef.GetAuthAttribute
// Size: 0x28(Inherited: 0x0) 
struct FGetAuthAttribute
{
	struct FString Key;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool Found : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FString ReturnValue;  // 0x18(0x10)

}; 
// Function OnlineSubsystemBlueprints.UserOnlineAccountRef.SetUserAttribute
// Size: 0x28(Inherited: 0x0) 
struct FSetUserAttribute
{
	struct FString Key;  // 0x0(0x10)
	struct FString Value;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool ReturnValue : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.GetPartyId
// Size: 0x8(Inherited: 0x0) 
struct FGetPartyId
{
	struct UPartyId* ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.Party.GetPartyTypeId
// Size: 0x8(Inherited: 0x0) 
struct FGetPartyTypeId
{
	int64_t ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.ReadablePartyData.GetAttribute
// Size: 0x40(Inherited: 0x0) 
struct FGetAttribute
{
	struct FString AttrName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool OutFound : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct FVariantDataBP OutAttrValue;  // 0x18(0x28)

}; 
// Function OnlineSubsystemBlueprints.OnlinePartyJoinInfo.GetSourceDisplayName
// Size: 0x10(Inherited: 0x0) 
struct FGetSourceDisplayName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.PurchaseReceipt.GetPurchaseTransactionState
// Size: 0x1(Inherited: 0x0) 
struct FGetPurchaseTransactionState
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.PurchaseReceipt.GetReceiptOffers
// Size: 0x10(Inherited: 0x0) 
struct FGetReceiptOffers
{
	struct TArray<struct FReceiptOfferEntryBP> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.PurchaseReceipt.GetTransactionId
// Size: 0x10(Inherited: 0x0) 
struct FGetTransactionId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.NamedOnlineSession.GetValue
// Size: 0x1F8(Inherited: 0x0) 
struct FGetValue
{
	struct FNamedOnlineSessionBP ReturnValue;  // 0x0(0x1F8)

}; 
// Function OnlineSubsystemBlueprints.OnlineSessionSearch.GetSearchResults
// Size: 0x10(Inherited: 0x0) 
struct FGetSearchResults
{
	struct TArray<struct FOnlineSessionSearchResultBP> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetCurrencyCode
// Size: 0x10(Inherited: 0x0) 
struct FGetCurrencyCode
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetDescription
// Size: 0x18(Inherited: 0x0) 
struct FGetDescription
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetDynamicFields
// Size: 0x50(Inherited: 0x0) 
struct FGetDynamicFields
{
	struct TMap<struct FString, struct FString> ReturnValue;  // 0x0(0x50)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetExpirationDate
// Size: 0x8(Inherited: 0x0) 
struct FGetExpirationDate
{
	struct FDateTime ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetOfferId
// Size: 0x10(Inherited: 0x0) 
struct FGetOfferId
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetReleaseDate
// Size: 0x8(Inherited: 0x0) 
struct FGetReleaseDate
{
	struct FDateTime ReturnValue;  // 0x0(0x8)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.GetTitle
// Size: 0x18(Inherited: 0x0) 
struct FGetTitle
{
	struct FText ReturnValue;  // 0x0(0x18)

}; 
// Function OnlineSubsystemBlueprints.OnlineStoreOffer.IsPurchasable
// Size: 0x1(Inherited: 0x0) 
struct FIsPurchasable
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioInputDeviceMuted
// Size: 0x1(Inherited: 0x0) 
struct FGetAudioInputDeviceMuted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioInputVolume
// Size: 0x4(Inherited: 0x0) 
struct FGetAudioInputVolume
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetAudioOutputDeviceMuted
// Size: 0x1(Inherited: 0x0) 
struct FGetAudioOutputDeviceMuted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetAvailableOutputDeviceInfos
// Size: 0x10(Inherited: 0x0) 
struct FGetAvailableOutputDeviceInfos
{
	struct TArray<struct FVoiceChatDeviceInfoBP> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetChannels
// Size: 0x10(Inherited: 0x0) 
struct FGetChannels
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetChannelType
// Size: 0x18(Inherited: 0x0) 
struct FGetChannelType
{
	struct FString ChannelName;  // 0x0(0x10)
	uint8_t  ReturnValue;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetDefaultInputDeviceInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetDefaultInputDeviceInfo
{
	struct FVoiceChatDeviceInfoBP ReturnValue;  // 0x0(0x20)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetDefaultOutputDeviceInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetDefaultOutputDeviceInfo
{
	struct FVoiceChatDeviceInfoBP ReturnValue;  // 0x0(0x20)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetInputDeviceInfo
// Size: 0x20(Inherited: 0x0) 
struct FGetInputDeviceInfo
{
	struct FVoiceChatDeviceInfoBP ReturnValue;  // 0x0(0x20)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetLoggedInPlayerName
// Size: 0x10(Inherited: 0x0) 
struct FGetLoggedInPlayerName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetPlayersInChannel
// Size: 0x20(Inherited: 0x0) 
struct FGetPlayersInChannel
{
	struct FString ChannelName;  // 0x0(0x10)
	struct TArray<struct FString> ReturnValue;  // 0x10(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetPlayerVolume
// Size: 0x18(Inherited: 0x0) 
struct FGetPlayerVolume
{
	struct FString PlayerName;  // 0x0(0x10)
	float ReturnValue;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.GetSetting
// Size: 0x20(Inherited: 0x0) 
struct FGetSetting
{
	struct FString Name;  // 0x0(0x10)
	struct FString ReturnValue;  // 0x10(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.InsecureGetJoinToken
// Size: 0x38(Inherited: 0x0) 
struct FInsecureGetJoinToken
{
	struct FString ChannelName;  // 0x0(0x10)
	uint8_t  ChannelType;  // 0x10(0x1)
	char pad_17[3];  // 0x11(0x3)
	struct FVoiceChatChannel3dPropertiesBP Channel3dProperties;  // 0x14(0x10)
	char pad_36[4];  // 0x24(0x4)
	struct FString ReturnValue;  // 0x28(0x10)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.IsLoggingIn
// Size: 0x1(Inherited: 0x0) 
struct FIsLoggingIn
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.IsPlayerMuted
// Size: 0x18(Inherited: 0x0) 
struct FIsPlayerMuted
{
	struct FString PlayerName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.IsPlayerTalking
// Size: 0x18(Inherited: 0x0) 
struct FIsPlayerTalking
{
	struct FString PlayerName;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool ReturnValue : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioInputDeviceMuted
// Size: 0x1(Inherited: 0x0) 
struct FSetAudioInputDeviceMuted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsMuted : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioInputVolume
// Size: 0x4(Inherited: 0x0) 
struct FSetAudioInputVolume
{
	float Volume;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioOutputDeviceMuted
// Size: 0x1(Inherited: 0x0) 
struct FSetAudioOutputDeviceMuted
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bIsMuted : 1;  // 0x0(0x1)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetAudioOutputVolume
// Size: 0x4(Inherited: 0x0) 
struct FSetAudioOutputVolume
{
	float Volume;  // 0x0(0x4)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetChannelPlayerMuted
// Size: 0x28(Inherited: 0x0) 
struct FSetChannelPlayerMuted
{
	struct FString ChannelName;  // 0x0(0x10)
	struct FString PlayerName;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bAudioMuted : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUser.SetPlayerVolume
// Size: 0x18(Inherited: 0x0) 
struct FSetPlayerVolume
{
	struct FString PlayerName;  // 0x0(0x10)
	float Volume;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// Function OnlineSubsystemBlueprints.VoiceChatUserJoinChannel.JoinChannel
// Size: 0x48(Inherited: 0x0) 
struct FJoinChannel
{
	struct UVoiceChatUser* Subsystem;  // 0x0(0x8)
	struct FString ChannelName;  // 0x8(0x10)
	struct FString ChannelCredentials;  // 0x18(0x10)
	uint8_t  ChannelType;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FVoiceChatChannel3dPropertiesBP Channel3dProperties;  // 0x2C(0x10)
	char pad_60[4];  // 0x3C(0x4)
	struct UVoiceChatUserJoinChannel* ReturnValue;  // 0x40(0x8)

}; 
