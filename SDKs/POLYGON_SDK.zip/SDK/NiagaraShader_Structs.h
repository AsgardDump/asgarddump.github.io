#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct NiagaraShader.NiagaraShaderScriptParametersMetadata
// Size: 0x58(Inherited: 0x0) 
struct FNiagaraShaderScriptParametersMetadata
{
	struct TArray<struct FNiagaraDataInterfaceGPUParamInfo> DataInterfaceParamInfo;  // 0x0(0x10)
	struct TArray<struct FString> LooseMetadataNames;  // 0x10(0x10)
	char pad_32_1 : 7;  // 0x20(0x1)
	bool bExternalConstantsInterpolated : 1;  // 0x20(0x1)
	char pad_33[7];  // 0x21(0x7)
	struct TArray<struct FNiagaraShaderScriptExternalConstant> ExternalConstants;  // 0x28(0x10)
	char pad_56[32];  // 0x38(0x20)

}; 
// ScriptStruct NiagaraShader.SimulationStageMetaData
// Size: 0x90(Inherited: 0x0) 
struct FSimulationStageMetaData
{
	struct FName SimulationStageName;  // 0x0(0x8)
	struct FName EnabledBinding;  // 0x8(0x8)
	struct FName ElementCountXBinding;  // 0x10(0x8)
	struct FName ElementCountYBinding;  // 0x18(0x8)
	struct FName ElementCountZBinding;  // 0x20(0x8)
	struct FName IterationSource;  // 0x28(0x8)
	uint8_t  ExecuteBehavior;  // 0x30(0x1)
	char pad_49[3];  // 0x31(0x3)
	char bWritesParticles : 1;  // 0x34(0x1)
	char bPartialParticleUpdate : 1;  // 0x34(0x1)
	char bParticleIterationStateEnabled : 1;  // 0x34(0x1)
	char bOverrideElementCount : 1;  // 0x34(0x1)
	char pad_52_1 : 4;  // 0x34(0x1)
	char pad_53[4];  // 0x35(0x4)
	struct FName ParticleIterationStateBinding;  // 0x38(0x8)
	char pad_64[4];  // 0x40(0x4)
	struct FIntPoint ParticleIterationStateRange;  // 0x44(0x8)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct FName> OutputDestinations;  // 0x50(0x10)
	struct TArray<struct FName> InputDataInterfaces;  // 0x60(0x10)
	int32_t NumIterations;  // 0x70(0x4)
	struct FName NumIterationsBinding;  // 0x74(0x8)
	uint8_t  GpuDispatchType;  // 0x7C(0x1)
	char pad_125[3];  // 0x7D(0x3)
	struct FIntVector GpuDispatchNumThreads;  // 0x80(0xC)
	char pad_140[4];  // 0x8C(0x4)

}; 
// ScriptStruct NiagaraShader.NiagaraShaderScriptExternalConstant
// Size: 0x18(Inherited: 0x0) 
struct FNiagaraShaderScriptExternalConstant
{
	struct FName Type;  // 0x0(0x8)
	struct FString Name;  // 0x8(0x10)

}; 
// ScriptStruct NiagaraShader.NiagaraDataInterfaceGPUParamInfo
// Size: 0x38(Inherited: 0x0) 
struct FNiagaraDataInterfaceGPUParamInfo
{
	struct FString DataInterfaceHLSLSymbol;  // 0x0(0x10)
	struct FString DIClassName;  // 0x10(0x10)
	uint32_t ShaderParametersOffset;  // 0x20(0x4)
	char pad_36[4];  // 0x24(0x4)
	struct TArray<struct FNiagaraDataInterfaceGeneratedFunction> GeneratedFunctions;  // 0x28(0x10)

}; 
// ScriptStruct NiagaraShader.NiagaraDataInterfaceGeneratedFunction
// Size: 0x28(Inherited: 0x0) 
struct FNiagaraDataInterfaceGeneratedFunction
{
	char pad_0[40];  // 0x0(0x28)

}; 
// ScriptStruct NiagaraShader.NiagaraCompileEvent
// Size: 0x68(Inherited: 0x0) 
struct FNiagaraCompileEvent
{
	uint8_t  Severity;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FString Message;  // 0x8(0x10)
	struct FString ShortDescription;  // 0x18(0x10)
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bDismissable : 1;  // 0x28(0x1)
	char pad_41[3];  // 0x29(0x3)
	struct FGuid NodeGuid;  // 0x2C(0x10)
	struct FGuid PinGuid;  // 0x3C(0x10)
	char pad_76[4];  // 0x4C(0x4)
	struct TArray<struct FGuid> StackGuids;  // 0x50(0x10)
	uint8_t  Source;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)

}; 
