#pragma once 
#include <Hotfix_Structs.h>
 
 
 
// Class Hotfix.OnlineHotfixManager
// Size: 0x238(Inherited: 0x28) 
struct UOnlineHotfixManager : public UObject
{
	char pad_40[464];  // 0x28(0x1D0)
	struct FString OSSName;  // 0x1F8(0x10)
	struct FString HotfixManagerClassName;  // 0x208(0x10)
	struct FString DebugPrefix;  // 0x218(0x10)
	struct TArray<struct UObject*> AssetsHotfixedFromIniFiles;  // 0x228(0x10)

	void StartHotfixProcess(); // Function Hotfix.OnlineHotfixManager.StartHotfixProcess
}; 



// Class Hotfix.UpdateManager
// Size: 0x1F0(Inherited: 0x28) 
struct UUpdateManager : public UObject
{
	char pad_40[96];  // 0x28(0x60)
	float HotfixCheckCompleteDelay;  // 0x88(0x4)
	float UpdateCheckCompleteDelay;  // 0x8C(0x4)
	float HotfixAvailabilityCheckCompleteDelay;  // 0x90(0x4)
	float UpdateCheckAvailabilityCompleteDelay;  // 0x94(0x4)
	char pad_152[4];  // 0x98(0x4)
	int32_t AppSuspendedUpdateCheckTimeSeconds;  // 0x9C(0x4)
	char pad_160[8];  // 0xA0(0x8)
	char pad_168_1 : 7;  // 0xA8(0x1)
	bool bPlatformEnvironmentDetected : 1;  // 0xA8(0x1)
	char pad_169_1 : 7;  // 0xA9(0x1)
	bool bInitialUpdateFinished : 1;  // 0xA9(0x1)
	char pad_170_1 : 7;  // 0xAA(0x1)
	bool bCheckHotfixAvailabilityOnly : 1;  // 0xAA(0x1)
	uint8_t  CurrentUpdateState;  // 0xAB(0x1)
	int32_t WorstNumFilesPendingLoadViewed;  // 0xAC(0x4)
	char pad_176[4];  // 0xB0(0x4)
	uint8_t  LastHotfixResult;  // 0xB4(0x1)
	char pad_181[35];  // 0xB5(0x23)
	struct FDateTime LastUpdateCheck[2];  // 0xD8(0x10)
	uint8_t  LastCompletionResult[2];  // 0xE8(0x2)
	char pad_234[38];  // 0xEA(0x26)
	struct UEnum* UpdateStateEnum;  // 0x110(0x8)
	struct UEnum* UpdateCompletionEnum;  // 0x118(0x8)
	struct FUpdateContextDefinition UpdateContextDefinitionUnknown;  // 0x120(0x68)
	struct TArray<struct FUpdateContextDefinition> UpdateContextDefinitions;  // 0x188(0x10)
	char pad_408[88];  // 0x198(0x58)

}; 



