#pragma once 
#include <ChaosSolverEngine_Structs.h>
 
 
 
// Class ChaosSolverEngine.ChaosDebugDrawComponent
// Size: 0xA8(Inherited: 0xA0) 
struct UChaosDebugDrawComponent : public UActorComponent
{
	char pad_160[8];  // 0xA0(0x8)

}; 



// Class ChaosSolverEngine.ChaosSolverActor
// Size: 0x388(Inherited: 0x290) 
struct AChaosSolverActor : public AActor
{
	struct FChaosSolverConfiguration Properties;  // 0x290(0x68)
	float TimeStepMultiplier;  // 0x2F8(0x4)
	int32_t CollisionIterations;  // 0x2FC(0x4)
	int32_t PushOutIterations;  // 0x300(0x4)
	int32_t PushOutPairIterations;  // 0x304(0x4)
	float ClusterConnectionFactor;  // 0x308(0x4)
	uint8_t  ClusterUnionConnectionType;  // 0x30C(0x1)
	char pad_781_1 : 7;  // 0x30D(0x1)
	bool DoGenerateCollisionData : 1;  // 0x30D(0x1)
	char pad_782[2];  // 0x30E(0x2)
	struct FSolverCollisionFilterSettings CollisionFilterSettings;  // 0x310(0x10)
	char pad_800_1 : 7;  // 0x320(0x1)
	bool DoGenerateBreakingData : 1;  // 0x320(0x1)
	char pad_801[3];  // 0x321(0x3)
	struct FSolverBreakingFilterSettings BreakingFilterSettings;  // 0x324(0x10)
	char pad_820_1 : 7;  // 0x334(0x1)
	bool DoGenerateTrailingData : 1;  // 0x334(0x1)
	char pad_821[3];  // 0x335(0x3)
	struct FSolverTrailingFilterSettings TrailingFilterSettings;  // 0x338(0x10)
	float MassScale;  // 0x348(0x4)
	char pad_844_1 : 7;  // 0x34C(0x1)
	bool bHasFloor : 1;  // 0x34C(0x1)
	char pad_845[3];  // 0x34D(0x3)
	float FloorHeight;  // 0x350(0x4)
	struct FChaosDebugSubstepControl ChaosDebugSubstepControl;  // 0x354(0x3)
	char pad_855[1];  // 0x357(0x1)
	struct UBillboardComponent* SpriteComponent;  // 0x358(0x8)
	char pad_864[24];  // 0x360(0x18)
	struct UChaosGameplayEventDispatcher* GameplayEventDispatcherComponent;  // 0x378(0x8)
	char pad_896[8];  // 0x380(0x8)

	void SetSolverActive(bool bActive); // Function ChaosSolverEngine.ChaosSolverActor.SetSolverActive
	void SetAsCurrentWorldSolver(); // Function ChaosSolverEngine.ChaosSolverActor.SetAsCurrentWorldSolver
}; 



// Class ChaosSolverEngine.ChaosEventListenerComponent
// Size: 0xA8(Inherited: 0xA0) 
struct UChaosEventListenerComponent : public UActorComponent
{
	char pad_160[8];  // 0xA0(0x8)

}; 



// Class ChaosSolverEngine.ChaosSolver
// Size: 0x28(Inherited: 0x28) 
struct UChaosSolver : public UObject
{

}; 



// Class ChaosSolverEngine.ChaosGameplayEventDispatcher
// Size: 0x308(Inherited: 0xA8) 
struct UChaosGameplayEventDispatcher : public UChaosEventListenerComponent
{
	char pad_168[272];  // 0xA8(0x110)
	struct TMap<struct UPrimitiveComponent*, struct FChaosHandlerSet> CollisionEventRegistrations;  // 0x1B8(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FBreakEventCallbackWrapper> BreakEventRegistrations;  // 0x208(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FRemovalEventCallbackWrapper> RemovalEventRegistrations;  // 0x258(0x50)
	struct TMap<struct UPrimitiveComponent*, struct FCrumblingEventCallbackWrapper> CrumblingEventRegistrations;  // 0x2A8(0x50)
	char pad_760[16];  // 0x2F8(0x10)

}; 



// Class ChaosSolverEngine.ChaosSolverSettings
// Size: 0x60(Inherited: 0x38) 
struct UChaosSolverSettings : public UDeveloperSettings
{
	char pad_56[8];  // 0x38(0x8)
	struct FSoftClassPath DefaultChaosSolverActorClass;  // 0x40(0x20)

}; 



// Class ChaosSolverEngine.ChaosNotifyHandlerInterface
// Size: 0x28(Inherited: 0x28) 
struct UChaosNotifyHandlerInterface : public UInterface
{

}; 



// Class ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary
// Size: 0x28(Inherited: 0x28) 
struct UChaosSolverEngineBlueprintLibrary : public UBlueprintFunctionLibrary
{

	struct FHitResult ConvertPhysicsCollisionToHitResult(struct FChaosPhysicsCollisionInfo& PhysicsCollision); // Function ChaosSolverEngine.ChaosSolverEngineBlueprintLibrary.ConvertPhysicsCollisionToHitResult
}; 



