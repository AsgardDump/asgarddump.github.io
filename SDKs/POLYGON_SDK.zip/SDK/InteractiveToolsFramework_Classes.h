#pragma once 
#include <InteractiveToolsFramework_Structs.h>
 
 
 
// Class InteractiveToolsFramework.InteractiveToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UInteractiveToolBuilder : public UObject
{

}; 



// Class InteractiveToolsFramework.GizmoTransformSource
// Size: 0x28(Inherited: 0x28) 
struct UGizmoTransformSource : public UInterface
{

	void SetTransform(struct FTransform& NewTransform); // Function InteractiveToolsFramework.GizmoTransformSource.SetTransform
	struct FTransform GetTransform(); // Function InteractiveToolsFramework.GizmoTransformSource.GetTransform
}; 



// Class InteractiveToolsFramework.MeshDescriptionCommitter
// Size: 0x28(Inherited: 0x28) 
struct UMeshDescriptionCommitter : public UInterface
{

}; 



// Class InteractiveToolsFramework.InputBehaviorSource
// Size: 0x28(Inherited: 0x28) 
struct UInputBehaviorSource : public UInterface
{

}; 



// Class InteractiveToolsFramework.GizmoElementLineBase
// Size: 0x158(Inherited: 0x108) 
struct UGizmoElementLineBase : public UGizmoElementBase
{
	struct FGizmoElementLineRenderStateAttributes LineRenderAttributes;  // 0x108(0x3C)
	float LineThickness;  // 0x144(0x4)
	char pad_328_1 : 7;  // 0x148(0x1)
	bool bScreenSpaceLine : 1;  // 0x148(0x1)
	char pad_329[3];  // 0x149(0x3)
	float HoverLineThicknessMultiplier;  // 0x14C(0x4)
	float InteractLineThicknessMultiplier;  // 0x150(0x4)
	char pad_340[4];  // 0x154(0x4)

}; 



// Class InteractiveToolsFramework.InteractiveToolPropertySet
// Size: 0xA8(Inherited: 0x28) 
struct UInteractiveToolPropertySet : public UObject
{
	char pad_40[16];  // 0x28(0x10)
	struct TMap<struct FString, struct UInteractiveToolPropertySet*> CachedPropertiesMap;  // 0x38(0x50)
	char pad_136_1 : 7;  // 0x88(0x1)
	bool bIsPropertySetEnabled : 1;  // 0x88(0x1)
	char pad_137[31];  // 0x89(0x1F)

}; 



// Class InteractiveToolsFramework.GizmoComponentHitTarget
// Size: 0x100(Inherited: 0x28) 
struct UGizmoComponentHitTarget : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UPrimitiveComponent* Component;  // 0x30(0x8)
	char pad_56[200];  // 0x38(0xC8)

}; 



// Class InteractiveToolsFramework.KeyAsModifierInputBehavior
// Size: 0x98(Inherited: 0x30) 
struct UKeyAsModifierInputBehavior : public UInputBehavior
{
	char pad_48[104];  // 0x30(0x68)

}; 



// Class InteractiveToolsFramework.GizmoBaseVec2ParameterSource
// Size: 0x48(Inherited: 0x28) 
struct UGizmoBaseVec2ParameterSource : public UObject
{
	char pad_40[32];  // 0x28(0x20)

}; 



// Class InteractiveToolsFramework.GizmoBaseComponent
// Size: 0x570(Inherited: 0x540) 
struct UGizmoBaseComponent : public UPrimitiveComponent
{
	struct FLinearColor Color;  // 0x538(0x10)
	float HoverSizeMultiplier;  // 0x548(0x4)
	float PixelHitDistanceThreshold;  // 0x54C(0x4)
	struct UGizmoViewContext* GizmoViewContext;  // 0x558(0x8)
	char pad_1376[16];  // 0x560(0x10)

	void UpdateWorldLocalState(bool bWorldIn); // Function InteractiveToolsFramework.GizmoBaseComponent.UpdateWorldLocalState
	void UpdateHoverState(bool bHoveringIn); // Function InteractiveToolsFramework.GizmoBaseComponent.UpdateHoverState
}; 



// Class InteractiveToolsFramework.InteractiveToolWithToolTargetsBuilder
// Size: 0x28(Inherited: 0x28) 
struct UInteractiveToolWithToolTargetsBuilder : public UInteractiveToolBuilder
{

}; 



// Class InteractiveToolsFramework.InputBehavior
// Size: 0x30(Inherited: 0x28) 
struct UInputBehavior : public UObject
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class InteractiveToolsFramework.InteractiveTool
// Size: 0x98(Inherited: 0x28) 
struct UInteractiveTool : public UObject
{
	char pad_40[56];  // 0x28(0x38)
	struct UInputBehaviorSet* InputBehaviors;  // 0x60(0x8)
	struct TArray<struct UObject*> ToolPropertyObjects;  // 0x68(0x10)
	char pad_120[32];  // 0x78(0x20)

}; 



// Class InteractiveToolsFramework.MultiSelectionTool
// Size: 0xB0(Inherited: 0x98) 
struct UMultiSelectionTool : public UInteractiveTool
{
	char pad_152[8];  // 0x98(0x8)
	struct TArray<struct UToolTarget*> Targets;  // 0xA0(0x10)

}; 



// Class InteractiveToolsFramework.MouseWheelInputBehavior
// Size: 0x130(Inherited: 0x80) 
struct UMouseWheelInputBehavior : public UAnyButtonInputBehavior
{
	char pad_128[176];  // 0x80(0xB0)

}; 



// Class InteractiveToolsFramework.ClickDragInputBehavior
// Size: 0x140(Inherited: 0x80) 
struct UClickDragInputBehavior : public UAnyButtonInputBehavior
{
	char pad_128[160];  // 0x80(0xA0)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bUpdateModifiersDuringDrag : 1;  // 0x120(0x1)
	char pad_289[31];  // 0x121(0x1F)

}; 



// Class InteractiveToolsFramework.SingleClickTool
// Size: 0xA0(Inherited: 0x98) 
struct USingleClickTool : public UInteractiveTool
{
	char pad_152[8];  // 0x98(0x8)

}; 



// Class InteractiveToolsFramework.MeshSurfacePointToolBuilder
// Size: 0x30(Inherited: 0x28) 
struct UMeshSurfacePointToolBuilder : public UInteractiveToolWithToolTargetsBuilder
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class InteractiveToolsFramework.ToolTargetFactory
// Size: 0x28(Inherited: 0x28) 
struct UToolTargetFactory : public UObject
{

}; 



// Class InteractiveToolsFramework.SingleSelectionTool
// Size: 0xA8(Inherited: 0x98) 
struct USingleSelectionTool : public UInteractiveTool
{
	char pad_152[8];  // 0x98(0x8)
	struct UToolTarget* Target;  // 0xA0(0x8)

}; 



// Class InteractiveToolsFramework.MeshSurfacePointTool
// Size: 0x100(Inherited: 0xA8) 
struct UMeshSurfacePointTool : public USingleSelectionTool
{
	char pad_168[80];  // 0xA8(0x50)
	struct TWeakObjectPtr<UWorld> TargetWorld;  // 0xF8(0x8)

}; 



// Class InteractiveToolsFramework.BaseBrushTool
// Size: 0x280(Inherited: 0x100) 
struct UBaseBrushTool : public UMeshSurfacePointTool
{
	struct UBrushBaseProperties* BrushProperties;  // 0x100(0x8)
	char pad_264_1 : 7;  // 0x108(0x1)
	bool bInBrushStroke : 1;  // 0x108(0x1)
	char pad_265[3];  // 0x109(0x3)
	float WorldToLocalScale;  // 0x10C(0x4)
	struct FBrushStampData LastBrushStamp;  // 0x110(0x128)
	char pad_568[16];  // 0x238(0x10)
	struct TSoftClassPtr<UObject> PropertyClass;  // 0x248(0x30)
	struct UBrushStampIndicator* BrushStampIndicator;  // 0x278(0x8)

}; 



// Class InteractiveToolsFramework.InteractiveGizmoBuilder
// Size: 0x28(Inherited: 0x28) 
struct UInteractiveGizmoBuilder : public UObject
{

}; 



// Class InteractiveToolsFramework.InteractiveCommand
// Size: 0x28(Inherited: 0x28) 
struct UInteractiveCommand : public UObject
{

}; 



// Class InteractiveToolsFramework.GizmoElementArc
// Size: 0x1D0(Inherited: 0x1C8) 
struct UGizmoElementArc : public UGizmoElementCircleBase
{
	double InnerRadius;  // 0x1C8(0x8)

}; 



// Class InteractiveToolsFramework.InteractionMechanic
// Size: 0x30(Inherited: 0x28) 
struct UInteractionMechanic : public UObject
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class InteractiveToolsFramework.GizmoConstantFrameAxisSource
// Size: 0x90(Inherited: 0x28) 
struct UGizmoConstantFrameAxisSource : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct FVector Origin;  // 0x30(0x18)
	struct FVector Direction;  // 0x48(0x18)
	struct FVector TangentX;  // 0x60(0x18)
	struct FVector TangentY;  // 0x78(0x18)

}; 



// Class InteractiveToolsFramework.InteractiveCommandArguments
// Size: 0x30(Inherited: 0x28) 
struct UInteractiveCommandArguments : public UObject
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class InteractiveToolsFramework.InternalToolFrameworkActor
// Size: 0x298(Inherited: 0x290) 
struct AInternalToolFrameworkActor : public AActor
{
	char pad_656_1 : 7;  // 0x290(0x1)
	bool bIsSelectableInEditor : 1;  // 0x290(0x1)
	char pad_657[7];  // 0x291(0x7)

}; 



// Class InteractiveToolsFramework.SingleKeyCaptureBehavior
// Size: 0x110(Inherited: 0x30) 
struct USingleKeyCaptureBehavior : public UInputBehavior
{
	char pad_48[224];  // 0x30(0xE0)

}; 



// Class InteractiveToolsFramework.GizmoAxisTranslationParameterSource
// Size: 0x150(Inherited: 0x48) 
struct UGizmoAxisTranslationParameterSource : public UGizmoBaseFloatParameterSource
{
	char pad_72[72];  // 0x48(0x48)
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x90(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource;  // 0xA0(0x10)
	float Parameter;  // 0xB0(0x4)
	struct FGizmoFloatParameterChange LastChange;  // 0xB4(0x8)
	char pad_188[4];  // 0xBC(0x4)
	struct FVector CurTranslationAxis;  // 0xC0(0x18)
	struct FVector CurTranslationOrigin;  // 0xD8(0x18)
	struct FTransform InitialTransform;  // 0xF0(0x60)

}; 



// Class InteractiveToolsFramework.GizmoVec2ParameterSource
// Size: 0x28(Inherited: 0x28) 
struct UGizmoVec2ParameterSource : public UInterface
{

	void SetParameter(struct FVector2D& NewValue); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.SetParameter
	struct FVector2D GetParameter(); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.GetParameter
	void EndModify(); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.EndModify
	void BeginModify(); // Function InteractiveToolsFramework.GizmoVec2ParameterSource.BeginModify
}; 



// Class InteractiveToolsFramework.MeshDescriptionProvider
// Size: 0x28(Inherited: 0x28) 
struct UMeshDescriptionProvider : public UInterface
{

}; 



// Class InteractiveToolsFramework.InteractiveToolExclusiveToolAPI
// Size: 0x28(Inherited: 0x28) 
struct UInteractiveToolExclusiveToolAPI : public UInterface
{

}; 



// Class InteractiveToolsFramework.GizmoBaseFloatParameterSource
// Size: 0x48(Inherited: 0x28) 
struct UGizmoBaseFloatParameterSource : public UObject
{
	char pad_40[32];  // 0x28(0x20)

}; 



// Class InteractiveToolsFramework.InteractiveToolNestedAcceptCancelAPI
// Size: 0x28(Inherited: 0x28) 
struct UInteractiveToolNestedAcceptCancelAPI : public UInterface
{

}; 



// Class InteractiveToolsFramework.SceneSnappingManager
// Size: 0x28(Inherited: 0x28) 
struct USceneSnappingManager : public UObject
{

}; 



// Class InteractiveToolsFramework.AssetBackedTarget
// Size: 0x28(Inherited: 0x28) 
struct UAssetBackedTarget : public UInterface
{

}; 



// Class InteractiveToolsFramework.AxisPositionGizmo
// Size: 0x1C0(Inherited: 0x38) 
struct UAxisPositionGizmo : public UInteractiveGizmo
{
	char pad_56[16];  // 0x38(0x10)
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x48(0x10)
	struct TScriptInterface<IGizmoFloatParameterSource> ParameterSource;  // 0x58(0x10)
	struct UGizmoViewContext* GizmoViewContext;  // 0x68(0x8)
	struct TScriptInterface<IGizmoClickTarget> HitTarget;  // 0x70(0x10)
	struct TScriptInterface<IGizmoStateTarget> StateTarget;  // 0x80(0x10)
	struct UClickDragInputBehavior* MouseBehavior;  // 0x90(0x8)
	char pad_152_1 : 7;  // 0x98(0x1)
	bool bEnableSignedAxis : 1;  // 0x98(0x1)
	char pad_153[136];  // 0x99(0x88)
	char pad_289_1 : 7;  // 0x121(0x1)
	bool bInInteraction : 1;  // 0x121(0x1)
	char pad_290[6];  // 0x122(0x6)
	struct FVector InteractionOrigin;  // 0x128(0x18)
	struct FVector InteractionAxis;  // 0x140(0x18)
	struct FVector InteractionStartPoint;  // 0x158(0x18)
	struct FVector InteractionCurPoint;  // 0x170(0x18)
	float InteractionStartParameter;  // 0x188(0x4)
	float InteractionCurParameter;  // 0x18C(0x4)
	float ParameterSign;  // 0x190(0x4)
	char pad_404[44];  // 0x194(0x2C)

}; 



// Class InteractiveToolsFramework.AnyButtonInputBehavior
// Size: 0x80(Inherited: 0x30) 
struct UAnyButtonInputBehavior : public UInputBehavior
{
	char pad_48[80];  // 0x30(0x50)

}; 



// Class InteractiveToolsFramework.GizmoAxisRotationParameterSource
// Size: 0x150(Inherited: 0x48) 
struct UGizmoAxisRotationParameterSource : public UGizmoBaseFloatParameterSource
{
	char pad_72[72];  // 0x48(0x48)
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x90(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource;  // 0xA0(0x10)
	float Angle;  // 0xB0(0x4)
	struct FGizmoFloatParameterChange LastChange;  // 0xB4(0x8)
	char pad_188[4];  // 0xBC(0x4)
	struct FVector CurRotationAxis;  // 0xC0(0x18)
	struct FVector CurRotationOrigin;  // 0xD8(0x18)
	struct FTransform InitialTransform;  // 0xF0(0x60)

}; 



// Class InteractiveToolsFramework.GizmoElementBase
// Size: 0x108(Inherited: 0x28) 
struct UGizmoElementBase : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bEnabled : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bEnabledForPerspectiveProjection : 1;  // 0x29(0x1)
	char pad_42_1 : 7;  // 0x2A(0x1)
	bool bEnabledForOrthographicProjection : 1;  // 0x2A(0x1)
	char pad_43_1 : 7;  // 0x2B(0x1)
	bool bEnabledForDefaultState : 1;  // 0x2B(0x1)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool bEnabledForHoveringState : 1;  // 0x2C(0x1)
	char pad_45_1 : 7;  // 0x2D(0x1)
	bool bEnabledForInteractingState : 1;  // 0x2D(0x1)
	char pad_46[2];  // 0x2E(0x2)
	uint32_t PartIdentifier;  // 0x30(0x4)
	struct FGizmoElementMeshRenderStateAttributes MeshRenderAttributes;  // 0x34(0x60)
	uint8_t  ElementState;  // 0x94(0x1)
	char pad_149[3];  // 0x95(0x3)
	uint8_t  ElementInteractionState;  // 0x98(0x4)
	uint8_t  ViewDependentType;  // 0x9C(0x4)
	struct FVector ViewDependentAxis;  // 0xA0(0x18)
	float ViewDependentAngleTol;  // 0xB8(0x4)
	float ViewDependentAxialMaxCosAngleTol;  // 0xBC(0x4)
	float ViewDependentPlanarMinCosAngleTol;  // 0xC0(0x4)
	uint8_t  ViewAlignType;  // 0xC4(0x4)
	struct FVector ViewAlignAxis;  // 0xC8(0x18)
	struct FVector ViewAlignNormal;  // 0xE0(0x18)
	float ViewAlignAxialAngleTol;  // 0xF8(0x4)
	float ViewAlignAxialMaxCosAngleTol;  // 0xFC(0x4)
	float PixelHitDistanceThreshold;  // 0x100(0x4)
	char pad_260[4];  // 0x104(0x4)

}; 



// Class InteractiveToolsFramework.GizmoElementCircleBase
// Size: 0x1C8(Inherited: 0x158) 
struct UGizmoElementCircleBase : public UGizmoElementLineBase
{
	struct FVector Center;  // 0x158(0x18)
	struct FVector Axis0;  // 0x170(0x18)
	struct FVector Axis1;  // 0x188(0x18)
	double Radius;  // 0x1A0(0x8)
	int32_t NumSegments;  // 0x1A8(0x4)
	uint8_t  PartialType;  // 0x1AC(0x4)
	double PartialStartAngle;  // 0x1B0(0x8)
	double PartialEndAngle;  // 0x1B8(0x8)
	double PartialViewDependentMaxCosTol;  // 0x1C0(0x8)

}; 



// Class InteractiveToolsFramework.InteractiveGizmo
// Size: 0x38(Inherited: 0x28) 
struct UInteractiveGizmo : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UInputBehaviorSet* InputBehaviors;  // 0x30(0x8)

}; 



// Class InteractiveToolsFramework.ToolTargetManager
// Size: 0x40(Inherited: 0x28) 
struct UToolTargetManager : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TArray<struct UToolTargetFactory*> Factories;  // 0x30(0x10)

}; 



// Class InteractiveToolsFramework.GizmoLineHandleComponent
// Size: 0x5B0(Inherited: 0x570) 
struct UGizmoLineHandleComponent : public UGizmoBaseComponent
{
	struct FVector Normal;  // 0x568(0x18)
	float HandleSize;  // 0x580(0x4)
	float Thickness;  // 0x584(0x4)
	struct FVector Direction;  // 0x588(0x18)
	float Length;  // 0x5A0(0x4)
	char pad_1452_1 : 7;  // 0x5AC(0x1)
	bool bImageScale : 1;  // 0x5A4(0x1)
	char pad_1453[3];  // 0x5AD(0x3)

}; 



// Class InteractiveToolsFramework.ToolContextTransactionProvider
// Size: 0x28(Inherited: 0x28) 
struct UToolContextTransactionProvider : public UInterface
{

}; 



// Class InteractiveToolsFramework.ToolFrameworkComponent
// Size: 0x28(Inherited: 0x28) 
struct UToolFrameworkComponent : public UInterface
{

}; 



// Class InteractiveToolsFramework.AxisPositionGizmoBuilder
// Size: 0x28(Inherited: 0x28) 
struct UAxisPositionGizmoBuilder : public UInteractiveGizmoBuilder
{

}; 



// Class InteractiveToolsFramework.ToolTarget
// Size: 0x28(Inherited: 0x28) 
struct UToolTarget : public UObject
{

}; 



// Class InteractiveToolsFramework.BrushStampIndicatorBuilder
// Size: 0x28(Inherited: 0x28) 
struct UBrushStampIndicatorBuilder : public UInteractiveGizmoBuilder
{

}; 



// Class InteractiveToolsFramework.InteractiveToolCameraFocusAPI
// Size: 0x28(Inherited: 0x28) 
struct UInteractiveToolCameraFocusAPI : public UInterface
{

}; 



// Class InteractiveToolsFramework.MaterialProvider
// Size: 0x28(Inherited: 0x28) 
struct UMaterialProvider : public UInterface
{

}; 



// Class InteractiveToolsFramework.AxisAngleGizmoBuilder
// Size: 0x28(Inherited: 0x28) 
struct UAxisAngleGizmoBuilder : public UInteractiveGizmoBuilder
{

}; 



// Class InteractiveToolsFramework.GizmoLocalVec2ParameterSource
// Size: 0x78(Inherited: 0x48) 
struct UGizmoLocalVec2ParameterSource : public UGizmoBaseVec2ParameterSource
{
	struct FVector2D Value;  // 0x48(0x10)
	struct FGizmoVec2ParameterChange LastChange;  // 0x58(0x20)

}; 



// Class InteractiveToolsFramework.GizmoPlaneTranslationParameterSource
// Size: 0x1A0(Inherited: 0x48) 
struct UGizmoPlaneTranslationParameterSource : public UGizmoBaseVec2ParameterSource
{
	char pad_72[72];  // 0x48(0x48)
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x90(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource;  // 0xA0(0x10)
	struct FVector2D Parameter;  // 0xB0(0x10)
	struct FGizmoVec2ParameterChange LastChange;  // 0xC0(0x20)
	struct FVector CurTranslationOrigin;  // 0xE0(0x18)
	struct FVector CurTranslationNormal;  // 0xF8(0x18)
	struct FVector CurTranslationAxisX;  // 0x110(0x18)
	struct FVector CurTranslationAxisY;  // 0x128(0x18)
	struct FTransform InitialTransform;  // 0x140(0x60)

}; 



// Class InteractiveToolsFramework.InputBehaviorSet
// Size: 0x38(Inherited: 0x28) 
struct UInputBehaviorSet : public UObject
{
	struct TArray<struct FBehaviorInfo> Behaviors;  // 0x28(0x10)

}; 



// Class InteractiveToolsFramework.GizmoUniformScaleParameterSource
// Size: 0x160(Inherited: 0x48) 
struct UGizmoUniformScaleParameterSource : public UGizmoBaseVec2ParameterSource
{
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x48(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource;  // 0x58(0x10)
	float ScaleMultiplier;  // 0x68(0x4)
	char pad_108[4];  // 0x6C(0x4)
	struct FVector2D Parameter;  // 0x70(0x10)
	struct FGizmoVec2ParameterChange LastChange;  // 0x80(0x20)
	struct FVector CurScaleOrigin;  // 0xA0(0x18)
	struct FVector CurScaleNormal;  // 0xB8(0x18)
	struct FVector CurScaleAxisX;  // 0xD0(0x18)
	struct FVector CurScaleAxisY;  // 0xE8(0x18)
	struct FTransform InitialTransform;  // 0x100(0x60)

}; 



// Class InteractiveToolsFramework.InteractiveToolManager
// Size: 0x180(Inherited: 0x28) 
struct UInteractiveToolManager : public UObject
{
	char pad_40[24];  // 0x28(0x18)
	struct UInteractiveTool* ActiveLeftTool;  // 0x40(0x8)
	struct UInteractiveTool* ActiveRightTool;  // 0x48(0x8)
	char pad_80[128];  // 0x50(0x80)
	struct TMap<struct FString, struct UInteractiveToolBuilder*> ToolBuilders;  // 0xD0(0x50)
	char pad_288[96];  // 0x120(0x60)

}; 



// Class InteractiveToolsFramework.PrimitiveComponentBackedTarget
// Size: 0x28(Inherited: 0x28) 
struct UPrimitiveComponentBackedTarget : public UInterface
{

}; 



// Class InteractiveToolsFramework.GizmoAxisScaleParameterSource
// Size: 0x110(Inherited: 0x48) 
struct UGizmoAxisScaleParameterSource : public UGizmoBaseFloatParameterSource
{
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x48(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource;  // 0x58(0x10)
	float ScaleMultiplier;  // 0x68(0x4)
	char pad_108_1 : 7;  // 0x6C(0x1)
	bool bClampToZero : 1;  // 0x6C(0x1)
	char pad_109[3];  // 0x6D(0x3)
	float Parameter;  // 0x70(0x4)
	struct FGizmoFloatParameterChange LastChange;  // 0x74(0x8)
	char pad_124[4];  // 0x7C(0x4)
	struct FVector CurScaleAxis;  // 0x80(0x18)
	struct FVector CurScaleOrigin;  // 0x98(0x18)
	struct FTransform InitialTransform;  // 0xB0(0x60)

}; 



// Class InteractiveToolsFramework.GizmoPlaneScaleParameterSource
// Size: 0x1B0(Inherited: 0x48) 
struct UGizmoPlaneScaleParameterSource : public UGizmoBaseVec2ParameterSource
{
	char pad_72[72];  // 0x48(0x48)
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x90(0x10)
	struct TScriptInterface<IGizmoTransformSource> TransformSource;  // 0xA0(0x10)
	float ScaleMultiplier;  // 0xB0(0x4)
	char pad_180_1 : 7;  // 0xB4(0x1)
	bool bUseEqualScaling : 1;  // 0xB4(0x1)
	char pad_181_1 : 7;  // 0xB5(0x1)
	bool bClampToZero : 1;  // 0xB5(0x1)
	char pad_182[2];  // 0xB6(0x2)
	struct FVector2D Parameter;  // 0xB8(0x10)
	struct FGizmoVec2ParameterChange LastChange;  // 0xC8(0x20)
	struct FVector CurScaleOrigin;  // 0xE8(0x18)
	struct FVector CurScaleNormal;  // 0x100(0x18)
	struct FVector CurScaleAxisX;  // 0x118(0x18)
	struct FVector CurScaleAxisY;  // 0x130(0x18)
	char pad_328[8];  // 0x148(0x8)
	struct FTransform InitialTransform;  // 0x150(0x60)

}; 



// Class InteractiveToolsFramework.PhysicsDataSource
// Size: 0x28(Inherited: 0x28) 
struct UPhysicsDataSource : public UInterface
{

}; 



// Class InteractiveToolsFramework.SkeletalMeshBackedTarget
// Size: 0x28(Inherited: 0x28) 
struct USkeletalMeshBackedTarget : public UAssetBackedTarget
{

}; 



// Class InteractiveToolsFramework.StaticMeshBackedTarget
// Size: 0x28(Inherited: 0x28) 
struct UStaticMeshBackedTarget : public UAssetBackedTarget
{

}; 



// Class InteractiveToolsFramework.LocalClickDragInputBehavior
// Size: 0x280(Inherited: 0x140) 
struct ULocalClickDragInputBehavior : public UClickDragInputBehavior
{
	char pad_320[320];  // 0x140(0x140)

}; 



// Class InteractiveToolsFramework.MouseHoverBehavior
// Size: 0x98(Inherited: 0x30) 
struct UMouseHoverBehavior : public UInputBehavior
{
	char pad_48[104];  // 0x30(0x68)

}; 



// Class InteractiveToolsFramework.LocalMouseHoverBehavior
// Size: 0x1A0(Inherited: 0x98) 
struct ULocalMouseHoverBehavior : public UMouseHoverBehavior
{
	char pad_152[264];  // 0x98(0x108)

}; 



// Class InteractiveToolsFramework.MultiClickSequenceInputBehavior
// Size: 0x130(Inherited: 0x80) 
struct UMultiClickSequenceInputBehavior : public UAnyButtonInputBehavior
{
	char pad_128[176];  // 0x80(0xB0)

}; 



// Class InteractiveToolsFramework.SingleClickInputBehavior
// Size: 0x130(Inherited: 0x80) 
struct USingleClickInputBehavior : public UAnyButtonInputBehavior
{
	char pad_128[64];  // 0x80(0x40)
	char pad_192_1 : 7;  // 0xC0(0x1)
	bool HitTestOnRelease : 1;  // 0xC0(0x1)
	char pad_193[111];  // 0xC1(0x6F)

}; 



// Class InteractiveToolsFramework.GizmoConstantAxisSource
// Size: 0x60(Inherited: 0x28) 
struct UGizmoConstantAxisSource : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct FVector Origin;  // 0x30(0x18)
	struct FVector Direction;  // 0x48(0x18)

}; 



// Class InteractiveToolsFramework.LocalSingleClickInputBehavior
// Size: 0x200(Inherited: 0x130) 
struct ULocalSingleClickInputBehavior : public USingleClickInputBehavior
{
	char pad_304[208];  // 0x130(0xD0)

}; 



// Class InteractiveToolsFramework.CombinedTransformGizmo
// Size: 0x2A0(Inherited: 0x38) 
struct UCombinedTransformGizmo : public UInteractiveGizmo
{
	struct UTransformProxy* ActiveTarget;  // 0x38(0x8)
	char pad_64_1 : 7;  // 0x40(0x1)
	bool bSnapToWorldGrid : 1;  // 0x40(0x1)
	char pad_65_1 : 7;  // 0x41(0x1)
	bool bGridSizeIsExplicit : 1;  // 0x41(0x1)
	char pad_66[6];  // 0x42(0x6)
	struct FVector ExplicitGridSize;  // 0x48(0x18)
	char pad_96_1 : 7;  // 0x60(0x1)
	bool bRotationGridSizeIsExplicit : 1;  // 0x60(0x1)
	char pad_97[7];  // 0x61(0x7)
	struct FRotator ExplicitRotationGridSize;  // 0x68(0x18)
	char pad_128_1 : 7;  // 0x80(0x1)
	bool bSnapToWorldRotGrid : 1;  // 0x80(0x1)
	char pad_129_1 : 7;  // 0x81(0x1)
	bool bUseContextCoordinateSystem : 1;  // 0x81(0x1)
	char pad_130[2];  // 0x82(0x2)
	uint8_t  CurrentCoordinateSystem;  // 0x84(0x4)
	char pad_136[200];  // 0x88(0xC8)
	struct TArray<struct UPrimitiveComponent*> ActiveComponents;  // 0x150(0x10)
	struct TArray<struct UPrimitiveComponent*> NonuniformScaleComponents;  // 0x160(0x10)
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos;  // 0x170(0x10)
	char pad_384[16];  // 0x180(0x10)
	struct UGizmoConstantFrameAxisSource* CameraAxisSource;  // 0x190(0x8)
	struct UGizmoComponentAxisSource* AxisXSource;  // 0x198(0x8)
	struct UGizmoComponentAxisSource* AxisYSource;  // 0x1A0(0x8)
	struct UGizmoComponentAxisSource* AxisZSource;  // 0x1A8(0x8)
	struct UGizmoComponentAxisSource* UnitAxisXSource;  // 0x1B0(0x8)
	struct UGizmoComponentAxisSource* UnitAxisYSource;  // 0x1B8(0x8)
	struct UGizmoComponentAxisSource* UnitAxisZSource;  // 0x1C0(0x8)
	struct UGizmoTransformChangeStateTarget* StateTarget;  // 0x1C8(0x8)
	char pad_464[208];  // 0x1D0(0xD0)

}; 



// Class InteractiveToolsFramework.SingleClickOrDragInputBehavior
// Size: 0x180(Inherited: 0x80) 
struct USingleClickOrDragInputBehavior : public UAnyButtonInputBehavior
{
	char pad_128[160];  // 0x80(0xA0)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bBeginDragIfClickTargetNotHit : 1;  // 0x120(0x1)
	char pad_289[3];  // 0x121(0x3)
	float ClickDistanceThreshold;  // 0x124(0x4)
	char pad_296[88];  // 0x128(0x58)

}; 



// Class InteractiveToolsFramework.WidgetBaseBehavior
// Size: 0x28(Inherited: 0x28) 
struct UWidgetBaseBehavior : public UInterface
{

}; 



// Class InteractiveToolsFramework.AxisAngleGizmo
// Size: 0x1D0(Inherited: 0x38) 
struct UAxisAngleGizmo : public UInteractiveGizmo
{
	char pad_56[16];  // 0x38(0x10)
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x48(0x10)
	struct TScriptInterface<IGizmoFloatParameterSource> AngleSource;  // 0x58(0x10)
	struct TScriptInterface<IGizmoClickTarget> HitTarget;  // 0x68(0x10)
	struct TScriptInterface<IGizmoStateTarget> StateTarget;  // 0x78(0x10)
	struct UClickDragInputBehavior* MouseBehavior;  // 0x88(0x8)
	char pad_144[128];  // 0x90(0x80)
	char pad_272_1 : 7;  // 0x110(0x1)
	bool bInInteraction : 1;  // 0x110(0x1)
	char pad_273[7];  // 0x111(0x7)
	struct FVector RotationOrigin;  // 0x118(0x18)
	struct FVector RotationAxis;  // 0x130(0x18)
	struct FVector RotationPlaneX;  // 0x148(0x18)
	struct FVector RotationPlaneY;  // 0x160(0x18)
	struct FVector InteractionStartPoint;  // 0x178(0x18)
	struct FVector InteractionCurPoint;  // 0x190(0x18)
	float InteractionStartAngle;  // 0x1A8(0x4)
	float InteractionCurAngle;  // 0x1AC(0x4)
	char pad_432[32];  // 0x1B0(0x20)

}; 



// Class InteractiveToolsFramework.GizmoWorldAxisSource
// Size: 0x50(Inherited: 0x28) 
struct UGizmoWorldAxisSource : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct FVector Origin;  // 0x30(0x18)
	int32_t AxisIndex;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 



// Class InteractiveToolsFramework.GizmoComponentAxisSource
// Size: 0x40(Inherited: 0x28) 
struct UGizmoComponentAxisSource : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct USceneComponent* Component;  // 0x30(0x8)
	int32_t AxisIndex;  // 0x38(0x4)
	char pad_60_1 : 7;  // 0x3C(0x1)
	bool bLocalAxes : 1;  // 0x3C(0x1)
	char pad_61[3];  // 0x3D(0x3)

}; 



// Class InteractiveToolsFramework.BrushStampIndicator
// Size: 0xD8(Inherited: 0x38) 
struct UBrushStampIndicator : public UInteractiveGizmo
{
	char pad_56_1 : 7;  // 0x38(0x1)
	bool bVisible : 1;  // 0x38(0x1)
	char pad_57[3];  // 0x39(0x3)
	float BrushRadius;  // 0x3C(0x4)
	float BrushFalloff;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct FVector BrushPosition;  // 0x48(0x18)
	struct FVector BrushNormal;  // 0x60(0x18)
	char pad_120_1 : 7;  // 0x78(0x1)
	bool bDrawIndicatorLines : 1;  // 0x78(0x1)
	char pad_121_1 : 7;  // 0x79(0x1)
	bool bDrawRadiusCircle : 1;  // 0x79(0x1)
	char pad_122[2];  // 0x7A(0x2)
	int32_t SampleStepCount;  // 0x7C(0x4)
	struct FLinearColor LineColor;  // 0x80(0x10)
	float LineThickness;  // 0x90(0x4)
	char pad_148_1 : 7;  // 0x94(0x1)
	bool bDepthTested : 1;  // 0x94(0x1)
	char pad_149_1 : 7;  // 0x95(0x1)
	bool bDrawSecondaryLines : 1;  // 0x95(0x1)
	char pad_150[2];  // 0x96(0x2)
	float SecondaryLineThickness;  // 0x98(0x4)
	struct FLinearColor SecondaryLineColor;  // 0x9C(0x10)
	char pad_172[4];  // 0xAC(0x4)
	struct UPrimitiveComponent* AttachedComponent;  // 0xB0(0x8)
	char pad_184[32];  // 0xB8(0x20)

}; 



// Class InteractiveToolsFramework.GizmoActor
// Size: 0x298(Inherited: 0x298) 
struct AGizmoActor : public AInternalToolFrameworkActor
{

}; 



// Class InteractiveToolsFramework.LocalInputBehaviorSource
// Size: 0x70(Inherited: 0x28) 
struct ULocalInputBehaviorSource : public UObject
{
	char pad_40[72];  // 0x28(0x48)

}; 



// Class InteractiveToolsFramework.CombinedTransformGizmoActor
// Size: 0x318(Inherited: 0x298) 
struct ACombinedTransformGizmoActor : public AGizmoActor
{
	struct UPrimitiveComponent* TranslateX;  // 0x298(0x8)
	struct UPrimitiveComponent* TranslateY;  // 0x2A0(0x8)
	struct UPrimitiveComponent* TranslateZ;  // 0x2A8(0x8)
	struct UPrimitiveComponent* TranslateYZ;  // 0x2B0(0x8)
	struct UPrimitiveComponent* TranslateXZ;  // 0x2B8(0x8)
	struct UPrimitiveComponent* TranslateXY;  // 0x2C0(0x8)
	struct UPrimitiveComponent* RotateX;  // 0x2C8(0x8)
	struct UPrimitiveComponent* RotateY;  // 0x2D0(0x8)
	struct UPrimitiveComponent* RotateZ;  // 0x2D8(0x8)
	struct UPrimitiveComponent* UniformScale;  // 0x2E0(0x8)
	struct UPrimitiveComponent* AxisScaleX;  // 0x2E8(0x8)
	struct UPrimitiveComponent* AxisScaleY;  // 0x2F0(0x8)
	struct UPrimitiveComponent* AxisScaleZ;  // 0x2F8(0x8)
	struct UPrimitiveComponent* PlaneScaleYZ;  // 0x300(0x8)
	struct UPrimitiveComponent* PlaneScaleXZ;  // 0x308(0x8)
	struct UPrimitiveComponent* PlaneScaleXY;  // 0x310(0x8)

}; 



// Class InteractiveToolsFramework.CombinedTransformGizmoBuilder
// Size: 0xF0(Inherited: 0x28) 
struct UCombinedTransformGizmoBuilder : public UInteractiveGizmoBuilder
{
	char pad_40[200];  // 0x28(0xC8)

}; 



// Class InteractiveToolsFramework.GizmoArrowComponent
// Size: 0x590(Inherited: 0x570) 
struct UGizmoArrowComponent : public UGizmoBaseComponent
{
	struct FVector Direction;  // 0x568(0x18)
	float Gap;  // 0x580(0x4)
	float Length;  // 0x584(0x4)
	float Thickness;  // 0x588(0x4)

}; 



// Class InteractiveToolsFramework.GizmoBoxComponent
// Size: 0x5C0(Inherited: 0x570) 
struct UGizmoBoxComponent : public UGizmoBaseComponent
{
	struct FVector Origin;  // 0x568(0x18)
	struct FQuat Rotation;  // 0x580(0x20)
	struct FVector Dimensions;  // 0x5A0(0x18)
	float LineThickness;  // 0x5B8(0x4)
	char pad_1476_1 : 7;  // 0x5C4(0x1)
	bool bRemoveHiddenLines : 1;  // 0x5BC(0x1)
	char pad_1477_1 : 7;  // 0x5C5(0x1)
	bool bEnableAxisFlip : 1;  // 0x5BD(0x1)

}; 



// Class InteractiveToolsFramework.GizmoRenderMultiTarget
// Size: 0x28(Inherited: 0x28) 
struct UGizmoRenderMultiTarget : public UInterface
{

	void UpdateVisibilityState(bool bVisible, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoRenderMultiTarget.UpdateVisibilityState
}; 



// Class InteractiveToolsFramework.GizmoCircleComponent
// Size: 0x590(Inherited: 0x570) 
struct UGizmoCircleComponent : public UGizmoBaseComponent
{
	struct FVector Normal;  // 0x568(0x18)
	float Radius;  // 0x580(0x4)
	float Thickness;  // 0x584(0x4)
	int32_t NumSides;  // 0x588(0x4)
	char pad_1428_1 : 7;  // 0x594(0x1)
	bool bViewAligned : 1;  // 0x58C(0x1)
	char pad_1429_1 : 7;  // 0x595(0x1)
	bool bDrawFullCircle : 1;  // 0x58D(0x1)
	char pad_1430_1 : 7;  // 0x596(0x1)
	bool bOnlyAllowFrontFacingHits : 1;  // 0x58E(0x1)

}; 



// Class InteractiveToolsFramework.GizmoElementArrow
// Size: 0x188(Inherited: 0x108) 
struct UGizmoElementArrow : public UGizmoElementBase
{
	char pad_264[8];  // 0x108(0x8)
	struct UGizmoElementCylinder* CylinderElement;  // 0x110(0x8)
	struct UGizmoElementCone* ConeElement;  // 0x118(0x8)
	struct UGizmoElementBox* BoxElement;  // 0x120(0x8)
	struct FVector Base;  // 0x128(0x18)
	struct FVector Direction;  // 0x140(0x18)
	struct FVector SideDirection;  // 0x158(0x18)
	float BodyLength;  // 0x170(0x4)
	float BodyRadius;  // 0x174(0x4)
	float HeadLength;  // 0x178(0x4)
	float HeadRadius;  // 0x17C(0x4)
	int32_t NumSides;  // 0x180(0x4)
	uint8_t  HeadType;  // 0x184(0x4)

}; 



// Class InteractiveToolsFramework.GizmoElementGroup
// Size: 0x170(Inherited: 0x158) 
struct UGizmoElementGroup : public UGizmoElementLineBase
{
	char pad_344_1 : 7;  // 0x158(0x1)
	bool bConstantScale : 1;  // 0x158(0x1)
	char pad_345_1 : 7;  // 0x159(0x1)
	bool bHitOwner : 1;  // 0x159(0x1)
	char pad_346[6];  // 0x15A(0x6)
	struct TArray<struct UGizmoElementBase*> Elements;  // 0x160(0x10)

}; 



// Class InteractiveToolsFramework.GizmoElementBox
// Size: 0x168(Inherited: 0x108) 
struct UGizmoElementBox : public UGizmoElementBase
{
	struct FVector Center;  // 0x108(0x18)
	struct FVector Dimensions;  // 0x120(0x18)
	struct FVector UpDirection;  // 0x138(0x18)
	struct FVector SideDirection;  // 0x150(0x18)

}; 



// Class InteractiveToolsFramework.GizmoElementCircle
// Size: 0x1D0(Inherited: 0x1C8) 
struct UGizmoElementCircle : public UGizmoElementCircleBase
{
	char pad_456_1 : 7;  // 0x1C8(0x1)
	bool bDrawMesh : 1;  // 0x1C8(0x1)
	char pad_457_1 : 7;  // 0x1C9(0x1)
	bool bDrawLine : 1;  // 0x1C9(0x1)
	char pad_458_1 : 7;  // 0x1CA(0x1)
	bool bHitMesh : 1;  // 0x1CA(0x1)
	char pad_459_1 : 7;  // 0x1CB(0x1)
	bool bHitLine : 1;  // 0x1CB(0x1)
	char pad_460[4];  // 0x1CC(0x4)

}; 



// Class InteractiveToolsFramework.GizmoElementCone
// Size: 0x148(Inherited: 0x108) 
struct UGizmoElementCone : public UGizmoElementBase
{
	struct FVector Origin;  // 0x108(0x18)
	struct FVector Direction;  // 0x120(0x18)
	float Height;  // 0x138(0x4)
	float Radius;  // 0x13C(0x4)
	int32_t NumSides;  // 0x140(0x4)
	char pad_324[4];  // 0x144(0x4)

}; 



// Class InteractiveToolsFramework.GizmoElementCylinder
// Size: 0x148(Inherited: 0x108) 
struct UGizmoElementCylinder : public UGizmoElementBase
{
	struct FVector Base;  // 0x108(0x18)
	struct FVector Direction;  // 0x120(0x18)
	float Height;  // 0x138(0x4)
	float Radius;  // 0x13C(0x4)
	int32_t NumSides;  // 0x140(0x4)
	char pad_324[4];  // 0x144(0x4)

}; 



// Class InteractiveToolsFramework.GizmoElementHitTarget
// Size: 0x90(Inherited: 0x28) 
struct UGizmoElementHitTarget : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UGizmoElementBase* GizmoElement;  // 0x30(0x8)
	struct UGizmoViewContext* GizmoViewContext;  // 0x38(0x8)
	struct UTransformProxy* GizmoTransformProxy;  // 0x40(0x8)
	char pad_72[72];  // 0x48(0x48)

}; 



// Class InteractiveToolsFramework.GizmoElementHitMultiTarget
// Size: 0x90(Inherited: 0x28) 
struct UGizmoElementHitMultiTarget : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct UGizmoElementBase* GizmoElement;  // 0x30(0x8)
	struct UGizmoViewContext* GizmoViewContext;  // 0x38(0x8)
	struct UTransformProxy* GizmoTransformProxy;  // 0x40(0x8)
	char pad_72[72];  // 0x48(0x48)

}; 



// Class InteractiveToolsFramework.GizmoElementRectangle
// Size: 0x1B0(Inherited: 0x158) 
struct UGizmoElementRectangle : public UGizmoElementLineBase
{
	struct FVector Center;  // 0x158(0x18)
	float Width;  // 0x170(0x4)
	float Height;  // 0x174(0x4)
	struct FVector UpDirection;  // 0x178(0x18)
	struct FVector SideDirection;  // 0x190(0x18)
	char pad_424_1 : 7;  // 0x1A8(0x1)
	bool bDrawMesh : 1;  // 0x1A8(0x1)
	char pad_425_1 : 7;  // 0x1A9(0x1)
	bool bDrawLine : 1;  // 0x1A9(0x1)
	char pad_426_1 : 7;  // 0x1AA(0x1)
	bool bHitMesh : 1;  // 0x1AA(0x1)
	char pad_427_1 : 7;  // 0x1AB(0x1)
	bool bHitLine : 1;  // 0x1AB(0x1)
	char pad_428[4];  // 0x1AC(0x4)

}; 



// Class InteractiveToolsFramework.GizmoElementTorus
// Size: 0x1D8(Inherited: 0x1C8) 
struct UGizmoElementTorus : public UGizmoElementCircleBase
{
	double InnerRadius;  // 0x1C8(0x8)
	int32_t NumInnerSlices;  // 0x1D0(0x4)
	char pad_468_1 : 7;  // 0x1D4(0x1)
	bool bEndCaps : 1;  // 0x1D4(0x1)
	char pad_469[3];  // 0x1D5(0x3)

}; 



// Class InteractiveToolsFramework.BrushBaseProperties
// Size: 0xC0(Inherited: 0xA8) 
struct UBrushBaseProperties : public UInteractiveToolPropertySet
{
	float BrushSize;  // 0xA8(0x4)
	char pad_172_1 : 7;  // 0xAC(0x1)
	bool bSpecifyRadius : 1;  // 0xAC(0x1)
	char pad_173[3];  // 0xAD(0x3)
	float BrushRadius;  // 0xB0(0x4)
	float BrushStrength;  // 0xB4(0x4)
	float BrushFalloffAmount;  // 0xB8(0x4)
	char pad_188_1 : 7;  // 0xBC(0x1)
	bool bShowStrength : 1;  // 0xBC(0x1)
	char pad_189_1 : 7;  // 0xBD(0x1)
	bool bShowFalloff : 1;  // 0xBD(0x1)
	char pad_190[2];  // 0xBE(0x2)

}; 



// Class InteractiveToolsFramework.GizmoAxisSource
// Size: 0x28(Inherited: 0x28) 
struct UGizmoAxisSource : public UInterface
{

	bool HasTangentVectors(); // Function InteractiveToolsFramework.GizmoAxisSource.HasTangentVectors
	void GetTangentVectors(struct FVector& TangentXOut, struct FVector& TangentYOut); // Function InteractiveToolsFramework.GizmoAxisSource.GetTangentVectors
	struct FVector GetOrigin(); // Function InteractiveToolsFramework.GizmoAxisSource.GetOrigin
	struct FVector GetDirection(); // Function InteractiveToolsFramework.GizmoAxisSource.GetDirection
}; 



// Class InteractiveToolsFramework.GizmoClickTarget
// Size: 0x28(Inherited: 0x28) 
struct UGizmoClickTarget : public UInterface
{

	void UpdateInteractingState(bool bInteracting); // Function InteractiveToolsFramework.GizmoClickTarget.UpdateInteractingState
	void UpdateHoverState(bool bHovering); // Function InteractiveToolsFramework.GizmoClickTarget.UpdateHoverState
}; 



// Class InteractiveToolsFramework.GizmoClickMultiTarget
// Size: 0x28(Inherited: 0x28) 
struct UGizmoClickMultiTarget : public UInterface
{

	void UpdateInteractingState(bool bInteracting, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateInteractingState
	void UpdateHoverState(bool bHovering, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateHoverState
	void UpdateHittableState(bool bHittable, uint32_t InPartIdentifier); // Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateHittableState
}; 



// Class InteractiveToolsFramework.GizmoRenderTarget
// Size: 0x28(Inherited: 0x28) 
struct UGizmoRenderTarget : public UInterface
{

}; 



// Class InteractiveToolsFramework.GizmoStateTarget
// Size: 0x28(Inherited: 0x28) 
struct UGizmoStateTarget : public UInterface
{

	void EndUpdate(); // Function InteractiveToolsFramework.GizmoStateTarget.EndUpdate
	void BeginUpdate(); // Function InteractiveToolsFramework.GizmoStateTarget.BeginUpdate
}; 



// Class InteractiveToolsFramework.GizmoFloatParameterSource
// Size: 0x28(Inherited: 0x28) 
struct UGizmoFloatParameterSource : public UInterface
{

	void SetParameter(float NewValue); // Function InteractiveToolsFramework.GizmoFloatParameterSource.SetParameter
	float GetParameter(); // Function InteractiveToolsFramework.GizmoFloatParameterSource.GetParameter
	void EndModify(); // Function InteractiveToolsFramework.GizmoFloatParameterSource.EndModify
	void BeginModify(); // Function InteractiveToolsFramework.GizmoFloatParameterSource.BeginModify
}; 



// Class InteractiveToolsFramework.GizmoComponentWorldTransformSource
// Size: 0x58(Inherited: 0x48) 
struct UGizmoComponentWorldTransformSource : public UGizmoBaseTransformSource
{
	struct USceneComponent* Component;  // 0x48(0x8)
	char pad_80_1 : 7;  // 0x50(0x1)
	bool bModifyComponentOnTransform : 1;  // 0x50(0x1)
	char pad_81[7];  // 0x51(0x7)

}; 



// Class InteractiveToolsFramework.GizmoRectangleComponent
// Size: 0x5C0(Inherited: 0x570) 
struct UGizmoRectangleComponent : public UGizmoBaseComponent
{
	struct FVector DirectionX;  // 0x568(0x18)
	struct FVector DirectionY;  // 0x580(0x18)
	char pad_1440_1 : 7;  // 0x5A0(0x1)
	bool bOrientYAccordingToCamera : 1;  // 0x598(0x1)
	float OffsetX;  // 0x59C(0x4)
	float OffsetY;  // 0x5A0(0x4)
	float LengthX;  // 0x5A4(0x4)
	float LengthY;  // 0x5A8(0x4)
	float Thickness;  // 0x5AC(0x4)
	char SegmentFlags;  // 0x5B0(0x1)
	char pad_1462[10];  // 0x5B6(0xA)

}; 



// Class InteractiveToolsFramework.GizmoViewContext
// Size: 0x1E0(Inherited: 0x28) 
struct UGizmoViewContext : public UObject
{
	char pad_40[440];  // 0x28(0x1B8)

}; 



// Class InteractiveToolsFramework.GizmoLambdaHitTarget
// Size: 0xF0(Inherited: 0x28) 
struct UGizmoLambdaHitTarget : public UObject
{
	char pad_40[200];  // 0x28(0xC8)

}; 



// Class InteractiveToolsFramework.IntervalGizmoActor
// Size: 0x2B0(Inherited: 0x298) 
struct AIntervalGizmoActor : public AGizmoActor
{
	struct UGizmoLineHandleComponent* UpIntervalComponent;  // 0x298(0x8)
	struct UGizmoLineHandleComponent* DownIntervalComponent;  // 0x2A0(0x8)
	struct UGizmoLineHandleComponent* ForwardIntervalComponent;  // 0x2A8(0x8)

}; 



// Class InteractiveToolsFramework.IntervalGizmoBuilder
// Size: 0xC0(Inherited: 0x28) 
struct UIntervalGizmoBuilder : public UInteractiveGizmoBuilder
{
	char pad_40[152];  // 0x28(0x98)

}; 



// Class InteractiveToolsFramework.IntervalGizmo
// Size: 0x200(Inherited: 0x38) 
struct UIntervalGizmo : public UInteractiveGizmo
{
	struct UGizmoTransformChangeStateTarget* StateTarget;  // 0x38(0x8)
	char pad_64[88];  // 0x40(0x58)
	struct UTransformProxy* TransformProxy;  // 0x98(0x8)
	struct TArray<struct UPrimitiveComponent*> ActiveComponents;  // 0xA0(0x10)
	struct TArray<struct UInteractiveGizmo*> ActiveGizmos;  // 0xB0(0x10)
	char pad_192[24];  // 0xC0(0x18)
	struct UGizmoComponentAxisSource* AxisYSource;  // 0xD8(0x8)
	struct UGizmoComponentAxisSource* AxisZSource;  // 0xE0(0x8)
	char pad_232[280];  // 0xE8(0x118)

}; 



// Class InteractiveToolsFramework.GizmoAxisIntervalParameterSource
// Size: 0x60(Inherited: 0x48) 
struct UGizmoAxisIntervalParameterSource : public UGizmoBaseFloatParameterSource
{
	struct TScriptInterface<IGizmoFloatParameterSource> FloatParameterSource;  // 0x48(0x10)
	float MinParameter;  // 0x58(0x4)
	float MaxParameter;  // 0x5C(0x4)

}; 



// Class InteractiveToolsFramework.GizmoLocalFloatParameterSource
// Size: 0x58(Inherited: 0x48) 
struct UGizmoLocalFloatParameterSource : public UGizmoBaseFloatParameterSource
{
	float Value;  // 0x48(0x4)
	struct FGizmoFloatParameterChange LastChange;  // 0x4C(0x8)
	char pad_84[4];  // 0x54(0x4)

}; 



// Class InteractiveToolsFramework.PlanePositionGizmoBuilder
// Size: 0x28(Inherited: 0x28) 
struct UPlanePositionGizmoBuilder : public UInteractiveGizmoBuilder
{

}; 



// Class InteractiveToolsFramework.PlanePositionGizmo
// Size: 0x270(Inherited: 0x38) 
struct UPlanePositionGizmo : public UInteractiveGizmo
{
	char pad_56[16];  // 0x38(0x10)
	struct TScriptInterface<IGizmoAxisSource> AxisSource;  // 0x48(0x10)
	struct TScriptInterface<IGizmoVec2ParameterSource> ParameterSource;  // 0x58(0x10)
	struct TScriptInterface<IGizmoClickTarget> HitTarget;  // 0x68(0x10)
	struct TScriptInterface<IGizmoStateTarget> StateTarget;  // 0x78(0x10)
	struct UClickDragInputBehavior* MouseBehavior;  // 0x88(0x8)
	char pad_144_1 : 7;  // 0x90(0x1)
	bool bEnableSignedAxis : 1;  // 0x90(0x1)
	char pad_145_1 : 7;  // 0x91(0x1)
	bool bFlipX : 1;  // 0x91(0x1)
	char pad_146_1 : 7;  // 0x92(0x1)
	bool bFlipY : 1;  // 0x92(0x1)
	char pad_147[141];  // 0x93(0x8D)
	char pad_288_1 : 7;  // 0x120(0x1)
	bool bInInteraction : 1;  // 0x120(0x1)
	char pad_289[7];  // 0x121(0x7)
	struct FVector InteractionOrigin;  // 0x128(0x18)
	struct FVector InteractionNormal;  // 0x140(0x18)
	struct FVector InteractionAxisX;  // 0x158(0x18)
	struct FVector InteractionAxisY;  // 0x170(0x18)
	struct FVector InteractionStartPoint;  // 0x188(0x18)
	struct FVector InteractionCurPoint;  // 0x1A0(0x18)
	struct FVector2D InteractionStartParameter;  // 0x1B8(0x10)
	struct FVector2D InteractionCurParameter;  // 0x1C8(0x10)
	struct FVector2D ParameterSigns;  // 0x1D8(0x10)
	char pad_488[136];  // 0x1E8(0x88)

}; 



// Class InteractiveToolsFramework.RepositionableTransformGizmoBuilder
// Size: 0xF0(Inherited: 0xF0) 
struct URepositionableTransformGizmoBuilder : public UCombinedTransformGizmoBuilder
{

}; 



// Class InteractiveToolsFramework.RepositionableTransformGizmo
// Size: 0x340(Inherited: 0x2A0) 
struct URepositionableTransformGizmo : public UCombinedTransformGizmo
{
	char pad_672[144];  // 0x2A0(0x90)
	struct UGizmoTransformChangeStateTarget* RepositionStateTarget;  // 0x330(0x8)
	char pad_824[8];  // 0x338(0x8)

}; 



// Class InteractiveToolsFramework.ScalableSphereGizmoBuilder
// Size: 0x28(Inherited: 0x28) 
struct UScalableSphereGizmoBuilder : public UInteractiveGizmoBuilder
{

}; 



// Class InteractiveToolsFramework.ScalableSphereGizmo
// Size: 0x100(Inherited: 0x38) 
struct UScalableSphereGizmo : public UInteractiveGizmo
{
	char pad_56[72];  // 0x38(0x48)
	float HitErrorThreshold;  // 0x80(0x4)
	char pad_132[4];  // 0x84(0x4)
	struct FText TransactionDescription;  // 0x88(0x18)
	float Radius;  // 0xA0(0x4)
	char pad_164_1 : 7;  // 0xA4(0x1)
	bool bIsHovering : 1;  // 0xA4(0x1)
	char pad_165_1 : 7;  // 0xA5(0x1)
	bool bIsDragging : 1;  // 0xA5(0x1)
	char pad_166[2];  // 0xA6(0x2)
	struct UTransformProxy* ActiveTarget;  // 0xA8(0x8)
	struct FVector ActiveAxis;  // 0xB0(0x18)
	struct FVector DragStartWorldPosition;  // 0xC8(0x18)
	struct FVector DragCurrentPositionProjected;  // 0xE0(0x18)
	float InteractionStartParameter;  // 0xF8(0x4)
	char pad_252[4];  // 0xFC(0x4)

}; 



// Class InteractiveToolsFramework.ScalableSphereGizmoInputBehavior
// Size: 0xD0(Inherited: 0x80) 
struct UScalableSphereGizmoInputBehavior : public UAnyButtonInputBehavior
{
	char pad_128[80];  // 0x80(0x50)

}; 



// Class InteractiveToolsFramework.GizmoNilStateTarget
// Size: 0x30(Inherited: 0x28) 
struct UGizmoNilStateTarget : public UObject
{
	char pad_40[8];  // 0x28(0x8)

}; 



// Class InteractiveToolsFramework.GizmoLambdaStateTarget
// Size: 0xB0(Inherited: 0x28) 
struct UGizmoLambdaStateTarget : public UObject
{
	char pad_40[136];  // 0x28(0x88)

}; 



// Class InteractiveToolsFramework.GizmoObjectModifyStateTarget
// Size: 0x60(Inherited: 0x28) 
struct UGizmoObjectModifyStateTarget : public UObject
{
	char pad_40[40];  // 0x28(0x28)
	struct TScriptInterface<IToolContextTransactionProvider> TransactionManager;  // 0x50(0x10)

}; 



// Class InteractiveToolsFramework.GizmoTransformChangeStateTarget
// Size: 0x140(Inherited: 0x28) 
struct UGizmoTransformChangeStateTarget : public UObject
{
	char pad_40[40];  // 0x28(0x28)
	struct TScriptInterface<IToolContextTransactionProvider> TransactionManager;  // 0x50(0x10)
	char pad_96[224];  // 0x60(0xE0)

}; 



// Class InteractiveToolsFramework.CombinedTransformGizmoContextObject
// Size: 0x40(Inherited: 0x28) 
struct UCombinedTransformGizmoContextObject : public UObject
{
	char pad_40[24];  // 0x28(0x18)

}; 



// Class InteractiveToolsFramework.TransformProxy
// Size: 0x1B0(Inherited: 0x28) 
struct UTransformProxy : public UObject
{
	char pad_40[168];  // 0x28(0xA8)
	char pad_208_1 : 7;  // 0xD0(0x1)
	bool bRotatePerObject : 1;  // 0xD0(0x1)
	char pad_209_1 : 7;  // 0xD1(0x1)
	bool bSetPivotMode : 1;  // 0xD1(0x1)
	char pad_210[30];  // 0xD2(0x1E)
	struct FTransform SharedTransform;  // 0xF0(0x60)
	struct FTransform InitialSharedTransform;  // 0x150(0x60)

}; 



// Class InteractiveToolsFramework.GizmoBaseTransformSource
// Size: 0x48(Inherited: 0x28) 
struct UGizmoBaseTransformSource : public UObject
{
	char pad_40[32];  // 0x28(0x20)

}; 



// Class InteractiveToolsFramework.GizmoScaledTransformSource
// Size: 0xE0(Inherited: 0x48) 
struct UGizmoScaledTransformSource : public UGizmoBaseTransformSource
{
	struct TScriptInterface<IGizmoTransformSource> ChildTransformSource;  // 0x48(0x10)
	char pad_88[136];  // 0x58(0x88)

}; 



// Class InteractiveToolsFramework.GizmoTransformProxyTransformSource
// Size: 0x70(Inherited: 0x48) 
struct UGizmoTransformProxyTransformSource : public UGizmoBaseTransformSource
{
	struct UTransformProxy* Proxy;  // 0x48(0x8)
	char pad_80[32];  // 0x50(0x20)

}; 



// Class InteractiveToolsFramework.GizmoScaledAndUnscaledTransformSources
// Size: 0x68(Inherited: 0x48) 
struct UGizmoScaledAndUnscaledTransformSources : public UGizmoBaseTransformSource
{
	struct TScriptInterface<IGizmoTransformSource> ScaledTransformSource;  // 0x48(0x10)
	struct TScriptInterface<IGizmoTransformSource> UnscaledTransformSource;  // 0x58(0x10)

}; 



// Class InteractiveToolsFramework.ClickDragToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct UClickDragToolBuilder : public UInteractiveToolBuilder
{

}; 



// Class InteractiveToolsFramework.ClickDragTool
// Size: 0xA0(Inherited: 0x98) 
struct UClickDragTool : public UInteractiveTool
{
	char pad_152[8];  // 0x98(0x8)

}; 



// Class InteractiveToolsFramework.SingleClickToolBuilder
// Size: 0x28(Inherited: 0x28) 
struct USingleClickToolBuilder : public UInteractiveToolBuilder
{

}; 



// Class InteractiveToolsFramework.ContextObjectStore
// Size: 0x38(Inherited: 0x28) 
struct UContextObjectStore : public UObject
{
	struct TArray<struct UObject*> ContextObjects;  // 0x28(0x10)

}; 



// Class InteractiveToolsFramework.InteractiveGizmoManager
// Size: 0xC0(Inherited: 0x28) 
struct UInteractiveGizmoManager : public UObject
{
	char pad_40[8];  // 0x28(0x8)
	struct TArray<struct FActiveGizmo> ActiveGizmos;  // 0x30(0x10)
	char pad_64[24];  // 0x40(0x18)
	struct TMap<struct FString, struct UInteractiveGizmoBuilder*> GizmoBuilders;  // 0x58(0x50)
	char pad_168[24];  // 0xA8(0x18)

}; 



// Class InteractiveToolsFramework.InputRouter
// Size: 0xB0(Inherited: 0x28) 
struct UInputRouter : public UObject
{
	char pad_40_1 : 7;  // 0x28(0x1)
	bool bAutoInvalidateOnHover : 1;  // 0x28(0x1)
	char pad_41_1 : 7;  // 0x29(0x1)
	bool bAutoInvalidateOnCapture : 1;  // 0x29(0x1)
	char pad_42[14];  // 0x2A(0xE)
	struct UInputBehaviorSet* ActiveInputBehaviors;  // 0x38(0x8)
	char pad_64[112];  // 0x40(0x70)

}; 



// Class InteractiveToolsFramework.InteractiveToolsContext
// Size: 0x330(Inherited: 0x28) 
struct UInteractiveToolsContext : public UObject
{
	char pad_40[48];  // 0x28(0x30)
	struct UInputRouter* InputRouter;  // 0x58(0x8)
	struct UToolTargetManager* TargetManager;  // 0x60(0x8)
	struct UInteractiveToolManager* ToolManager;  // 0x68(0x8)
	struct UInteractiveGizmoManager* GizmoManager;  // 0x70(0x8)
	struct UContextObjectStore* ContextObjectStore;  // 0x78(0x8)
	char pad_128[640];  // 0x80(0x280)
	struct TSoftClassPtr<UObject> ToolManagerClass;  // 0x300(0x30)

}; 



// Class InteractiveToolsFramework.SelectionSet
// Size: 0x40(Inherited: 0x28) 
struct USelectionSet : public UObject
{
	char pad_40[24];  // 0x28(0x18)

}; 



// Class InteractiveToolsFramework.MeshSelectionSet
// Size: 0x80(Inherited: 0x40) 
struct UMeshSelectionSet : public USelectionSet
{
	struct TArray<int32_t> Vertices;  // 0x40(0x10)
	struct TArray<int32_t> Edges;  // 0x50(0x10)
	struct TArray<int32_t> Faces;  // 0x60(0x10)
	struct TArray<int32_t> Groups;  // 0x70(0x10)

}; 



// Class InteractiveToolsFramework.PrimitiveComponentToolTarget
// Size: 0x38(Inherited: 0x28) 
struct UPrimitiveComponentToolTarget : public UToolTarget
{
	char pad_40[16];  // 0x28(0x10)

}; 



// Class InteractiveToolsFramework.PrimitiveComponentToolTargetFactory
// Size: 0x28(Inherited: 0x28) 
struct UPrimitiveComponentToolTargetFactory : public UToolTargetFactory
{

}; 



