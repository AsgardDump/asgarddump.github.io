#pragma once 
#include <ModelViewViewModel_Structs.h>
 
 
 
// Class ModelViewViewModel.MVVMViewModelBlueprintGeneratedClass
// Size: 0x398(Inherited: 0x380) 
struct UMVVMViewModelBlueprintGeneratedClass : public UBlueprintGeneratedClass
{
	struct TArray<struct FFieldNotificationId> FieldNotifyNames;  // 0x380(0x10)
	char pad_912[8];  // 0x390(0x8)

}; 



// Class ModelViewViewModel.MVVMViewModelBase
// Size: 0x68(Inherited: 0x28) 
struct UMVVMViewModelBase : public UObject
{
	char pad_40[64];  // 0x28(0x40)

	bool K2_SetPropertyValue(int32_t& OldValue, int32_t& NewValue); // Function ModelViewViewModel.MVVMViewModelBase.K2_SetPropertyValue
	void K2_RemoveFieldValueChangedDelegate(struct FFieldNotificationId FieldId, struct FDelegate Delegate); // Function ModelViewViewModel.MVVMViewModelBase.K2_RemoveFieldValueChangedDelegate
	void K2_BroadcastFieldValueChanged(struct FFieldNotificationId FieldId); // Function ModelViewViewModel.MVVMViewModelBase.K2_BroadcastFieldValueChanged
	void K2_AddFieldValueChangedDelegate(struct FFieldNotificationId FieldId, struct FDelegate Delegate); // Function ModelViewViewModel.MVVMViewModelBase.K2_AddFieldValueChangedDelegate
}; 



// Class ModelViewViewModel.MVVMSubsystem
// Size: 0x38(Inherited: 0x30) 
struct UMVVMSubsystem : public UEngineSubsystem
{
	struct UMVVMViewModelCollectionObject* GlobalViewModelCollection;  // 0x30(0x8)

	struct UMVVMView* GetViewFromUserWidget(struct UUserWidget* UserWidget); // Function ModelViewViewModel.MVVMSubsystem.GetViewFromUserWidget
	struct UMVVMViewModelCollectionObject* GetGlobalViewModelCollection(); // Function ModelViewViewModel.MVVMSubsystem.GetGlobalViewModelCollection
	struct TArray<struct FMVVMAvailableBinding> GetAvailableBindings(UObject* Class, UObject* Accessor); // Function ModelViewViewModel.MVVMSubsystem.GetAvailableBindings
	struct FMVVMAvailableBinding GetAvailableBinding(UObject* Class, struct FMVVMBindingName BindingName, UObject* Accessor); // Function ModelViewViewModel.MVVMSubsystem.GetAvailableBinding
	bool DoesWidgetTreeContainedWidget(struct UWidgetTree* WidgetTree, struct UWidget* ViewWidget); // Function ModelViewViewModel.MVVMSubsystem.DoesWidgetTreeContainedWidget
}; 



// Class ModelViewViewModel.MVVMViewClass
// Size: 0xB0(Inherited: 0x28) 
struct UMVVMViewClass : public UWidgetBlueprintGeneratedClassExtension
{
	struct TArray<struct FMVVMViewClass_SourceCreator> SourceCreators;  // 0x28(0x10)
	struct TArray<struct FMVVMViewClass_CompiledBinding> CompiledBindings;  // 0x38(0x10)
	struct FMVVMCompiledBindingLibrary BindingLibrary;  // 0x48(0x60)
	char pad_168[8];  // 0xA8(0x8)

}; 



// Class ModelViewViewModel.MVVMViewModelCollectionObject
// Size: 0x50(Inherited: 0x28) 
struct UMVVMViewModelCollectionObject : public UObject
{
	struct FMVVMViewModelCollection ViewModelCollection;  // 0x28(0x28)

	bool RemoveViewModel(struct FMVVMViewModelContext Context); // Function ModelViewViewModel.MVVMViewModelCollectionObject.RemoveViewModel
	int32_t RemoveAllViewModelInstance(struct UMVVMViewModelBase* ViewModel); // Function ModelViewViewModel.MVVMViewModelCollectionObject.RemoveAllViewModelInstance
	struct UMVVMViewModelBase* FindViewModelInstance(struct FMVVMViewModelContext Context); // Function ModelViewViewModel.MVVMViewModelCollectionObject.FindViewModelInstance
	bool AddViewModelInstance(struct FMVVMViewModelContext Context, struct UMVVMViewModelBase* ViewModel); // Function ModelViewViewModel.MVVMViewModelCollectionObject.AddViewModelInstance
}; 



// Class ModelViewViewModel.MVVMView
// Size: 0x68(Inherited: 0x28) 
struct UMVVMView : public UUserWidgetExtension
{
	struct UMVVMViewClass* ClassExtension;  // 0x28(0x8)
	char pad_48[56];  // 0x30(0x38)

	bool SetViewModel(struct FName ViewModelName, struct UMVVMViewModelBase* ViewModel); // Function ModelViewViewModel.MVVMView.SetViewModel
}; 



