#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct InteractiveToolsFramework.BrushStampData
// Size: 0x128(Inherited: 0x0) 
struct FBrushStampData
{
	char pad_0[296];  // 0x0(0x128)

}; 
// ScriptStruct InteractiveToolsFramework.GizmoElementMaterialAttribute
// Size: 0xC(Inherited: 0x0) 
struct FGizmoElementMaterialAttribute
{
	struct TWeakObjectPtr<UMaterialInterface> Value;  // 0x0(0x8)
	char pad_8_1 : 7;  // 0x8(0x1)
	bool bOverridesChildState : 1;  // 0x8(0x1)
	char pad_9[3];  // 0x9(0x3)

}; 
// ScriptStruct InteractiveToolsFramework.GizmoElementColorAttribute
// Size: 0x14(Inherited: 0x0) 
struct FGizmoElementColorAttribute
{
	struct FLinearColor Value;  // 0x0(0x10)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bHasValue : 1;  // 0x10(0x1)
	char pad_17_1 : 7;  // 0x11(0x1)
	bool bOverridesChildState : 1;  // 0x11(0x1)
	char pad_18[2];  // 0x12(0x2)

}; 
// ScriptStruct InteractiveToolsFramework.GizmoElementMeshRenderStateAttributes
// Size: 0x60(Inherited: 0x0) 
struct FGizmoElementMeshRenderStateAttributes
{
	struct FGizmoElementMaterialAttribute Material;  // 0x0(0xC)
	struct FGizmoElementMaterialAttribute HoverMaterial;  // 0xC(0xC)
	struct FGizmoElementMaterialAttribute InteractMaterial;  // 0x18(0xC)
	struct FGizmoElementColorAttribute VertexColor;  // 0x24(0x14)
	struct FGizmoElementColorAttribute HoverVertexColor;  // 0x38(0x14)
	struct FGizmoElementColorAttribute InteractVertexColor;  // 0x4C(0x14)

}; 
// ScriptStruct InteractiveToolsFramework.BehaviorInfo
// Size: 0x20(Inherited: 0x0) 
struct FBehaviorInfo
{
	struct UInputBehavior* Behavior;  // 0x0(0x8)
	char pad_8[24];  // 0x8(0x18)

}; 
// ScriptStruct InteractiveToolsFramework.GizmoElementLineRenderStateAttributes
// Size: 0x3C(Inherited: 0x0) 
struct FGizmoElementLineRenderStateAttributes
{
	struct FGizmoElementColorAttribute LineColor;  // 0x0(0x14)
	struct FGizmoElementColorAttribute HoverLineColor;  // 0x14(0x14)
	struct FGizmoElementColorAttribute InteractLineColor;  // 0x28(0x14)

}; 
// ScriptStruct InteractiveToolsFramework.GizmoFloatParameterChange
// Size: 0x8(Inherited: 0x0) 
struct FGizmoFloatParameterChange
{
	float InitialValue;  // 0x0(0x4)
	float CurrentValue;  // 0x4(0x4)

}; 
// ScriptStruct InteractiveToolsFramework.GizmoVec2ParameterChange
// Size: 0x20(Inherited: 0x0) 
struct FGizmoVec2ParameterChange
{
	struct FVector2D InitialValue;  // 0x0(0x10)
	struct FVector2D CurrentValue;  // 0x10(0x10)

}; 
// ScriptStruct InteractiveToolsFramework.InputRayHit
// Size: 0x38(Inherited: 0x0) 
struct FInputRayHit
{
	char pad_0[56];  // 0x0(0x38)

}; 
// ScriptStruct InteractiveToolsFramework.ActiveGizmo
// Size: 0x30(Inherited: 0x0) 
struct FActiveGizmo
{
	struct UInteractiveGizmo* Gizmo;  // 0x0(0x8)
	char pad_8[40];  // 0x8(0x28)

}; 
// Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateHoverState
// Size: 0x8(Inherited: 0x0) 
struct FUpdateHoverState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHovering : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	uint32_t InPartIdentifier;  // 0x4(0x4)

}; 
// Function InteractiveToolsFramework.GizmoBaseComponent.UpdateWorldLocalState
// Size: 0x1(Inherited: 0x0) 
struct FUpdateWorldLocalState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bWorldIn : 1;  // 0x0(0x1)

}; 
// Function InteractiveToolsFramework.GizmoTransformSource.GetTransform
// Size: 0x60(Inherited: 0x0) 
struct FGetTransform
{
	struct FTransform ReturnValue;  // 0x0(0x60)

}; 
// Function InteractiveToolsFramework.GizmoTransformSource.SetTransform
// Size: 0x60(Inherited: 0x0) 
struct FSetTransform
{
	struct FTransform NewTransform;  // 0x0(0x60)

}; 
// Function InteractiveToolsFramework.GizmoAxisSource.GetDirection
// Size: 0x18(Inherited: 0x0) 
struct FGetDirection
{
	struct FVector ReturnValue;  // 0x0(0x18)

}; 
// Function InteractiveToolsFramework.GizmoAxisSource.GetOrigin
// Size: 0x18(Inherited: 0x0) 
struct FGetOrigin
{
	struct FVector ReturnValue;  // 0x0(0x18)

}; 
// Function InteractiveToolsFramework.GizmoAxisSource.GetTangentVectors
// Size: 0x30(Inherited: 0x0) 
struct FGetTangentVectors
{
	struct FVector TangentXOut;  // 0x0(0x18)
	struct FVector TangentYOut;  // 0x18(0x18)

}; 
// Function InteractiveToolsFramework.GizmoAxisSource.HasTangentVectors
// Size: 0x1(Inherited: 0x0) 
struct FHasTangentVectors
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateInteractingState
// Size: 0x8(Inherited: 0x0) 
struct FUpdateInteractingState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bInteracting : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	uint32_t InPartIdentifier;  // 0x4(0x4)

}; 
// Function InteractiveToolsFramework.GizmoClickMultiTarget.UpdateHittableState
// Size: 0x8(Inherited: 0x0) 
struct FUpdateHittableState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bHittable : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	uint32_t InPartIdentifier;  // 0x4(0x4)

}; 
// Function InteractiveToolsFramework.GizmoRenderMultiTarget.UpdateVisibilityState
// Size: 0x8(Inherited: 0x0) 
struct FUpdateVisibilityState
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bVisible : 1;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	uint32_t InPartIdentifier;  // 0x4(0x4)

}; 
// Function InteractiveToolsFramework.GizmoVec2ParameterSource.GetParameter
// Size: 0x10(Inherited: 0x0) 
struct FGetParameter
{
	struct FVector2D ReturnValue;  // 0x0(0x10)

}; 
// Function InteractiveToolsFramework.GizmoVec2ParameterSource.SetParameter
// Size: 0x10(Inherited: 0x0) 
struct FSetParameter
{
	struct FVector2D NewValue;  // 0x0(0x10)

}; 
