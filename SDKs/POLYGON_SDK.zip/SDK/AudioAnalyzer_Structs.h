#pragma once 
#include "SDK.h" 
 
 
// Function AudioAnalyzer.AudioAnalyzer.StartAnalyzing
// Size: 0x10(Inherited: 0x0) 
struct FStartAnalyzing
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UAudioBus* AudioBusToAnalyze;  // 0x8(0x8)

}; 
// Function AudioAnalyzer.AudioAnalyzer.StopAnalyzing
// Size: 0x8(Inherited: 0x0) 
struct FStopAnalyzing
{
	struct UObject* WorldContextObject;  // 0x0(0x8)

}; 
