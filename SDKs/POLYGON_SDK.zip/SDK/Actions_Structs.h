#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Actions.RootAction
// Size: 0x18(Inherited: 0x0) 
struct FRootAction
{
	struct TWeakObjectPtr<UObject> Owner;  // 0x0(0x8)
	struct TArray<struct UAction*> Actions;  // 0x8(0x10)

}; 
// Function Actions.Action.ReceiveTick
// Size: 0x4(Inherited: 0x0) 
struct FReceiveTick
{
	float DeltaTime;  // 0x0(0x4)

}; 
// DelegateFunction Actions.ActionFinishedDelegate__DelegateSignature
// Size: 0x1(Inherited: 0x0) 
struct FActionFinishedDelegate__DelegateSignature
{
	uint8_t  Reason;  // 0x0(0x1)

}; 
// Function Actions.Action.GetState
// Size: 0x1(Inherited: 0x0) 
struct FGetState
{
	uint8_t  ReturnValue;  // 0x0(0x1)

}; 
// ScriptStruct Actions.ActionsTickGroup
// Size: 0x18(Inherited: 0x0) 
struct FActionsTickGroup
{
	float TickRate;  // 0x0(0x4)
	float TickTimeElapsed;  // 0x4(0x4)
	struct TArray<struct UAction*> Actions;  // 0x8(0x10)

}; 
// Function Actions.Action.GetParentAction
// Size: 0x8(Inherited: 0x0) 
struct FGetParentAction
{
	struct UAction* ReturnValue;  // 0x0(0x8)

}; 
// Function Actions.Action.Fail
// Size: 0x8(Inherited: 0x0) 
struct FFail
{
	struct FName Error;  // 0x0(0x8)

}; 
// Function Actions.Action.Failed
// Size: 0x1(Inherited: 0x0) 
struct FFailed
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Actions.Action.GetOwner
// Size: 0x8(Inherited: 0x0) 
struct FGetOwner
{
	struct UObject* ReturnValue;  // 0x0(0x8)

}; 
// Function Actions.Action.GetOwnerActor
// Size: 0x8(Inherited: 0x0) 
struct FGetOwnerActor
{
	struct AActor* ReturnValue;  // 0x0(0x8)

}; 
// Function Actions.Action.GetOwnerComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetOwnerComponent
{
	struct UActorComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function Actions.Action.GetParent
// Size: 0x8(Inherited: 0x0) 
struct FGetParent
{
	struct UObject* ReturnValue;  // 0x0(0x8)

}; 
// Function Actions.Action.GetTickRate
// Size: 0x4(Inherited: 0x0) 
struct FGetTickRate
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function Actions.Action.IsRunning
// Size: 0x1(Inherited: 0x0) 
struct FIsRunning
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Actions.Action.ReceiveCanActivate
// Size: 0x1(Inherited: 0x0) 
struct FReceiveCanActivate
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Actions.Action.ReceiveFinished
// Size: 0x1(Inherited: 0x0) 
struct FReceiveFinished
{
	uint8_t  Reason;  // 0x0(0x1)

}; 
// Function Actions.Action.Succeeded
// Size: 0x1(Inherited: 0x0) 
struct FSucceeded
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool ReturnValue : 1;  // 0x0(0x1)

}; 
// Function Actions.ActionLibrary.CreateAction
// Size: 0x20(Inherited: 0x0) 
struct FCreateAction
{
	struct UObject* Owner;  // 0x0(0x8)
	UAction* Type;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bAutoActivate : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	struct UAction* ReturnValue;  // 0x18(0x8)

}; 
// Function Actions.ActionsSubsystem.CancelAllByClass
// Size: 0x18(Inherited: 0x0) 
struct FCancelAllByClass
{
	UObject* actionClass;  // 0x0(0x8)
	struct TArray<struct UAction*> ignoreActions;  // 0x8(0x10)

}; 
// Function Actions.ActionsSubsystem.CancelAllByOwner
// Size: 0x8(Inherited: 0x0) 
struct FCancelAllByOwner
{
	struct UObject* Object;  // 0x0(0x8)

}; 
// Function Actions.BTT_RunAction.OnRunActionFinished
// Size: 0x1(Inherited: 0x0) 
struct FOnRunActionFinished
{
	uint8_t  Reason;  // 0x0(0x1)

}; 
