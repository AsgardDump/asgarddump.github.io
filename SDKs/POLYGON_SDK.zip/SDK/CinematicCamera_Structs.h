#pragma once 
#include "SDK.h" 
 
 
// Function CinematicCamera.CineCameraComponent.GetFilmbackPresetName
// Size: 0x10(Inherited: 0x0) 
struct FGetFilmbackPresetName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// ScriptStruct CinematicCamera.CameraFilmbackSettings
// Size: 0xC(Inherited: 0x0) 
struct FCameraFilmbackSettings
{
	float SensorWidth;  // 0x0(0x4)
	float SensorHeight;  // 0x4(0x4)
	float SensorAspectRatio;  // 0x8(0x4)

}; 
// ScriptStruct CinematicCamera.PlateCropSettings
// Size: 0x4(Inherited: 0x0) 
struct FPlateCropSettings
{
	float AspectRatio;  // 0x0(0x4)

}; 
// ScriptStruct CinematicCamera.NamedFilmbackPreset
// Size: 0x20(Inherited: 0x0) 
struct FNamedFilmbackPreset
{
	struct FString Name;  // 0x0(0x10)
	struct FCameraFilmbackSettings FilmbackSettings;  // 0x10(0xC)
	char pad_28[4];  // 0x1C(0x4)

}; 
// ScriptStruct CinematicCamera.CameraFocusSettings
// Size: 0x68(Inherited: 0x0) 
struct FCameraFocusSettings
{
	uint8_t  FocusMethod;  // 0x0(0x1)
	char pad_1[3];  // 0x1(0x3)
	float ManualFocusDistance;  // 0x4(0x4)
	struct FCameraTrackingFocusSettings TrackingFocusSettings;  // 0x8(0x50)
	char bSmoothFocusChanges : 1;  // 0x58(0x1)
	char pad_88_1 : 7;  // 0x58(0x1)
	char pad_89[4];  // 0x59(0x4)
	float FocusSmoothingInterpSpeed;  // 0x5C(0x4)
	float FocusOffset;  // 0x60(0x4)
	char pad_100[4];  // 0x64(0x4)

}; 
// ScriptStruct CinematicCamera.CameraLensSettings
// Size: 0x1C(Inherited: 0x0) 
struct FCameraLensSettings
{
	float MinFocalLength;  // 0x0(0x4)
	float MaxFocalLength;  // 0x4(0x4)
	float MinFStop;  // 0x8(0x4)
	float MaxFStop;  // 0xC(0x4)
	float MinimumFocusDistance;  // 0x10(0x4)
	float SqueezeFactor;  // 0x14(0x4)
	int32_t DiaphragmBladeCount;  // 0x18(0x4)

}; 
// ScriptStruct CinematicCamera.NamedPlateCropPreset
// Size: 0x18(Inherited: 0x0) 
struct FNamedPlateCropPreset
{
	struct FString Name;  // 0x0(0x10)
	struct FPlateCropSettings CropSettings;  // 0x10(0x4)
	char pad_20[4];  // 0x14(0x4)

}; 
// ScriptStruct CinematicCamera.NamedLensPreset
// Size: 0x30(Inherited: 0x0) 
struct FNamedLensPreset
{
	struct FString Name;  // 0x0(0x10)
	struct FCameraLensSettings LensSettings;  // 0x10(0x1C)
	char pad_44[4];  // 0x2C(0x4)

}; 
// ScriptStruct CinematicCamera.CameraTrackingFocusSettings
// Size: 0x50(Inherited: 0x0) 
struct FCameraTrackingFocusSettings
{
	struct TSoftObjectPtr<AActor> ActorToTrack;  // 0x0(0x30)
	struct FVector RelativeOffset;  // 0x30(0x18)
	char bDrawDebugTrackingFocusPoint : 1;  // 0x48(0x1)
	char pad_72_1 : 7;  // 0x48(0x1)
	char pad_73[8];  // 0x49(0x8)

}; 
// ScriptStruct CinematicCamera.CameraLookatTrackingSettings
// Size: 0x70(Inherited: 0x0) 
struct FCameraLookatTrackingSettings
{
	char bEnableLookAtTracking : 1;  // 0x0(0x1)
	char bDrawDebugLookAtTrackingPosition : 1;  // 0x0(0x1)
	char pad_0_1 : 6;  // 0x0(0x1)
	char pad_1[4];  // 0x1(0x4)
	float LookAtTrackingInterpSpeed;  // 0x4(0x4)
	char pad_8[24];  // 0x8(0x18)
	struct TSoftObjectPtr<AActor> ActorToTrack;  // 0x20(0x30)
	struct FVector RelativeOffset;  // 0x50(0x18)
	char bAllowRoll : 1;  // 0x68(0x1)
	char pad_104_1 : 7;  // 0x68(0x1)
	char pad_105[8];  // 0x69(0x8)

}; 
// Function CinematicCamera.CineCameraSettings.GetCropPresetByName
// Size: 0x18(Inherited: 0x0) 
struct FGetCropPresetByName
{
	struct FString PresetName;  // 0x0(0x10)
	struct FPlateCropSettings CropSettings;  // 0x10(0x4)
	char pad_20_1 : 7;  // 0x14(0x1)
	bool ReturnValue : 1;  // 0x14(0x1)
	char pad_21[3];  // 0x15(0x3)

}; 
// Function CinematicCamera.CineCameraSettings.GetCineCameraSettings
// Size: 0x8(Inherited: 0x0) 
struct FGetCineCameraSettings
{
	struct UCineCameraSettings* ReturnValue;  // 0x0(0x8)

}; 
// Function CinematicCamera.CineCameraSettings.SetDefaultCropPresetName
// Size: 0x10(Inherited: 0x0) 
struct FSetDefaultCropPresetName
{
	struct FString InDefaultCropPresetName;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraSettings.GetCropPresetNames
// Size: 0x10(Inherited: 0x0) 
struct FGetCropPresetNames
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraSettings.GetFilmbackPresetByName
// Size: 0x20(Inherited: 0x0) 
struct FGetFilmbackPresetByName
{
	struct FString PresetName;  // 0x0(0x10)
	struct FCameraFilmbackSettings FilmbackSettings;  // 0x10(0xC)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool ReturnValue : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)

}; 
// Function CinematicCamera.CineCameraComponent.GetVerticalFieldOfView
// Size: 0x4(Inherited: 0x0) 
struct FGetVerticalFieldOfView
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function CinematicCamera.CineCameraSettings.GetFilmbackPresetNames
// Size: 0x10(Inherited: 0x0) 
struct FGetFilmbackPresetNames
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraSettings.GetLensPresetByName
// Size: 0x30(Inherited: 0x0) 
struct FGetLensPresetByName
{
	struct FString PresetName;  // 0x0(0x10)
	struct FCameraLensSettings LensSettings;  // 0x10(0x1C)
	char pad_44_1 : 7;  // 0x2C(0x1)
	bool ReturnValue : 1;  // 0x2C(0x1)
	char pad_45[3];  // 0x2D(0x3)

}; 
// Function CinematicCamera.CineCameraSettings.GetLensPresetNames
// Size: 0x10(Inherited: 0x0) 
struct FGetLensPresetNames
{
	struct TArray<struct FString> ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraSettings.SetCropPresets
// Size: 0x10(Inherited: 0x0) 
struct FSetCropPresets
{
	struct TArray<struct FNamedPlateCropPreset> InCropPresets;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraSettings.SetDefaultLensFStop
// Size: 0x4(Inherited: 0x0) 
struct FSetDefaultLensFStop
{
	float InDefaultLensFStop;  // 0x0(0x4)

}; 
// Function CinematicCamera.CineCameraSettings.SetDefaultFilmbackPreset
// Size: 0x10(Inherited: 0x0) 
struct FSetDefaultFilmbackPreset
{
	struct FString InDefaultFilmbackPreset;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraSettings.SetDefaultLensFocalLength
// Size: 0x4(Inherited: 0x0) 
struct FSetDefaultLensFocalLength
{
	float InDefaultLensFocalLength;  // 0x0(0x4)

}; 
// Function CinematicCamera.CineCameraActor.GetCineCameraComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetCineCameraComponent
{
	struct UCineCameraComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function CinematicCamera.CineCameraSettings.SetDefaultLensPresetName
// Size: 0x10(Inherited: 0x0) 
struct FSetDefaultLensPresetName
{
	struct FString InDefaultLensPresetName;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraSettings.SetFilmbackPresets
// Size: 0x10(Inherited: 0x0) 
struct FSetFilmbackPresets
{
	struct TArray<struct FNamedFilmbackPreset> InFilmbackPresets;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.SetCurrentFocalLength
// Size: 0x4(Inherited: 0x0) 
struct FSetCurrentFocalLength
{
	float InFocalLength;  // 0x0(0x4)

}; 
// Function CinematicCamera.CineCameraSettings.SetLensPresets
// Size: 0x10(Inherited: 0x0) 
struct FSetLensPresets
{
	struct TArray<struct FNamedLensPreset> InLensPresets;  // 0x0(0x10)

}; 
// Function CinematicCamera.CameraRig_Rail.GetRailSplineComponent
// Size: 0x8(Inherited: 0x0) 
struct FGetRailSplineComponent
{
	struct USplineComponent* ReturnValue;  // 0x0(0x8)

}; 
// Function CinematicCamera.CineCameraComponent.GetCropPresetName
// Size: 0x10(Inherited: 0x0) 
struct FGetCropPresetName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.GetDefaultFilmbackPresetName
// Size: 0x10(Inherited: 0x0) 
struct FGetDefaultFilmbackPresetName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.GetFilmbackPresetsCopy
// Size: 0x10(Inherited: 0x0) 
struct FGetFilmbackPresetsCopy
{
	struct TArray<struct FNamedFilmbackPreset> ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.GetHorizontalFieldOfView
// Size: 0x4(Inherited: 0x0) 
struct FGetHorizontalFieldOfView
{
	float ReturnValue;  // 0x0(0x4)

}; 
// Function CinematicCamera.CineCameraComponent.GetLensPresetName
// Size: 0x10(Inherited: 0x0) 
struct FGetLensPresetName
{
	struct FString ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.GetLensPresetsCopy
// Size: 0x10(Inherited: 0x0) 
struct FGetLensPresetsCopy
{
	struct TArray<struct FNamedLensPreset> ReturnValue;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.SetCropPresetByName
// Size: 0x10(Inherited: 0x0) 
struct FSetCropPresetByName
{
	struct FString InPresetName;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.SetCropSettings
// Size: 0x4(Inherited: 0x0) 
struct FSetCropSettings
{
	struct FPlateCropSettings NewCropSettings;  // 0x0(0x4)

}; 
// Function CinematicCamera.CineCameraComponent.SetCurrentAperture
// Size: 0x4(Inherited: 0x0) 
struct FSetCurrentAperture
{
	float NewCurrentAperture;  // 0x0(0x4)

}; 
// Function CinematicCamera.CineCameraComponent.SetFilmback
// Size: 0xC(Inherited: 0x0) 
struct FSetFilmback
{
	struct FCameraFilmbackSettings NewFilmback;  // 0x0(0xC)

}; 
// Function CinematicCamera.CineCameraComponent.SetFilmbackPresetByName
// Size: 0x10(Inherited: 0x0) 
struct FSetFilmbackPresetByName
{
	struct FString InPresetName;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.SetFocusSettings
// Size: 0x68(Inherited: 0x0) 
struct FSetFocusSettings
{
	struct FCameraFocusSettings NewFocusSettings;  // 0x0(0x68)

}; 
// Function CinematicCamera.CineCameraComponent.SetLensPresetByName
// Size: 0x10(Inherited: 0x0) 
struct FSetLensPresetByName
{
	struct FString InPresetName;  // 0x0(0x10)

}; 
// Function CinematicCamera.CineCameraComponent.SetLensSettings
// Size: 0x1C(Inherited: 0x0) 
struct FSetLensSettings
{
	struct FCameraLensSettings NewLensSettings;  // 0x0(0x1C)

}; 
