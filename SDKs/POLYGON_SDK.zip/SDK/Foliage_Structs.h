#pragma once 
#include "SDK.h" 
 
 
// ScriptStruct Foliage.FoliageDensityFalloff
// Size: 0x90(Inherited: 0x0) 
struct FFoliageDensityFalloff
{
	char pad_0_1 : 7;  // 0x0(0x1)
	bool bUseFalloffCurve : 1;  // 0x0(0x1)
	char pad_1[7];  // 0x1(0x7)
	struct FRuntimeFloatCurve FalloffCurve;  // 0x8(0x88)

}; 
// DelegateFunction Foliage.InstancePointDamageSignature__DelegateSignature
// Size: 0x50(Inherited: 0x0) 
struct FInstancePointDamageSignature__DelegateSignature
{
	int32_t InstanceIndex;  // 0x0(0x4)
	float Damage;  // 0x4(0x4)
	struct AController* InstigatedBy;  // 0x8(0x8)
	struct FVector HitLocation;  // 0x10(0x18)
	struct FVector ShotFromDirection;  // 0x28(0x18)
	struct UDamageType* DamageType;  // 0x40(0x8)
	struct AActor* DamageCauser;  // 0x48(0x8)

}; 
// Function Foliage.ProceduralFoliageSpawner.Simulate
// Size: 0x4(Inherited: 0x0) 
struct FSimulate
{
	int32_t NumSteps;  // 0x0(0x4)

}; 
// Function Foliage.FoliageStatistics.FoliageOverlappingBoxCount
// Size: 0x50(Inherited: 0x0) 
struct FFoliageOverlappingBoxCount
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UStaticMesh* StaticMesh;  // 0x8(0x8)
	struct FBox Box;  // 0x10(0x38)
	int32_t ReturnValue;  // 0x48(0x4)
	char pad_76[4];  // 0x4C(0x4)

}; 
// ScriptStruct Foliage.FoliageTypeObject
// Size: 0x20(Inherited: 0x0) 
struct FFoliageTypeObject
{
	struct UObject* FoliageTypeObject;  // 0x0(0x8)
	struct UFoliageType* TypeInstance;  // 0x8(0x8)
	char pad_16_1 : 7;  // 0x10(0x1)
	bool bIsAsset : 1;  // 0x10(0x1)
	char pad_17[7];  // 0x11(0x7)
	UFoliageType_InstancedStaticMesh* Type;  // 0x18(0x8)

}; 
// DelegateFunction Foliage.InstanceRadialDamageSignature__DelegateSignature
// Size: 0x58(Inherited: 0x0) 
struct FInstanceRadialDamageSignature__DelegateSignature
{
	struct TArray<int32_t> Instances;  // 0x0(0x10)
	struct TArray<float> Damages;  // 0x10(0x10)
	struct AController* InstigatedBy;  // 0x20(0x8)
	struct FVector Origin;  // 0x28(0x18)
	float MaxRadius;  // 0x40(0x4)
	char pad_68[4];  // 0x44(0x4)
	struct UDamageType* DamageType;  // 0x48(0x8)
	struct AActor* DamageCauser;  // 0x50(0x8)

}; 
// ScriptStruct Foliage.FoliageVertexColorChannelMask
// Size: 0xC(Inherited: 0x0) 
struct FFoliageVertexColorChannelMask
{
	char UseMask : 1;  // 0x0(0x1)
	char pad_0_1 : 7;  // 0x0(0x1)
	char pad_1[4];  // 0x1(0x4)
	float MaskThreshold;  // 0x4(0x4)
	char InvertMask : 1;  // 0x8(0x1)
	char pad_8_1 : 7;  // 0x8(0x1)
	char pad_9[4];  // 0x9(0x4)

}; 
// Function Foliage.InteractiveFoliageActor.CapsuleTouched
// Size: 0x108(Inherited: 0x0) 
struct FCapsuleTouched
{
	struct UPrimitiveComponent* OverlappedComp;  // 0x0(0x8)
	struct AActor* Other;  // 0x8(0x8)
	struct UPrimitiveComponent* OtherComp;  // 0x10(0x8)
	int32_t OtherBodyIndex;  // 0x18(0x4)
	char pad_28_1 : 7;  // 0x1C(0x1)
	bool bFromSweep : 1;  // 0x1C(0x1)
	char pad_29[3];  // 0x1D(0x3)
	struct FHitResult OverlapInfo;  // 0x20(0xE8)

}; 
// ScriptStruct Foliage.ProceduralFoliageInstance
// Size: 0x80(Inherited: 0x0) 
struct FProceduralFoliageInstance
{
	struct FQuat Rotation;  // 0x0(0x20)
	struct FVector Location;  // 0x20(0x18)
	float Age;  // 0x38(0x4)
	char pad_60[4];  // 0x3C(0x4)
	struct FVector Normal;  // 0x40(0x18)
	float Scale;  // 0x58(0x4)
	char pad_92[4];  // 0x5C(0x4)
	struct UFoliageType* Type;  // 0x60(0x8)
	char pad_104[24];  // 0x68(0x18)

}; 
// Function Foliage.FoliageStatistics.FoliageOverlappingBoxTransforms
// Size: 0x58(Inherited: 0x0) 
struct FFoliageOverlappingBoxTransforms
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UStaticMesh* StaticMesh;  // 0x8(0x8)
	struct FBox Box;  // 0x10(0x38)
	struct TArray<struct FTransform> OutTransforms;  // 0x48(0x10)

}; 
// Function Foliage.FoliageStatistics.FoliageOverlappingSphereCount
// Size: 0x30(Inherited: 0x0) 
struct FFoliageOverlappingSphereCount
{
	struct UObject* WorldContextObject;  // 0x0(0x8)
	struct UStaticMesh* StaticMesh;  // 0x8(0x8)
	struct FVector CenterPosition;  // 0x10(0x18)
	float Radius;  // 0x28(0x4)
	int32_t ReturnValue;  // 0x2C(0x4)

}; 
